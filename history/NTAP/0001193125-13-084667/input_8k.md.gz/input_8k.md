# NTAP 8-K — 0001102624-13-000166 filed 2013-02-13

## item codes, every 8-K on or before 2013-02-28

- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2013-02-28

- none on or before 2013-02-28

## item 2.02 — earnings release, exhibit 99.1

[0001102624-13-000166:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-13-000166:8k_2_02:2]
exh99_1.htm

[0001102624-13-000166:8k_2_02:3]
Exhibit 99.1  Press release, dated February 13, 2013, reporting earnings for the fiscal quarter ended January 25, 2013.

[0001102624-13-000166:8k_2_02:4]
| Press Contact: | Investor Contact: |  |  |
| Ryan Lowry | Kris Newton |  |  |
| NetApp | NetApp |  |  |
| (408) 822-7544 | (408) 822-3312 |  |  |
| ryanl@netapp.com | kris.newton@netapp.com |  |  |

[0001102624-13-000166:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR THIRD

[0001102624-13-000166:8k_2_02:6]
QUARTER FISCAL YEAR 2013

[0001102624-13-000166:8k_2_02:7]
Reports Q3 FY’13 Revenues of $1.630 Billion; Non-GAAP

[0001102624-13-000166:8k_2_02:8]
Earnings per Share of $0.67

[0001102624-13-000166:8k_2_02:9]
Sunnyvale, Calif.—February 13, 2013—NetApp (NASDAQ: NTAP) today reported results for the third quarter of fiscal year 2013, which ended January 25, 2013. Revenues for the third quarter of fiscal year 2013 totaled $1.630 billion and were in line with prior guidance. Revenues for the same period a year ago totaled $1.566 billion.

[0001102624-13-000166:8k_2_02:10]
For the third quarter of fiscal year 2013, GAAP net income was $158 million, or $0.43 per share,1 compared to GAAP net income of $120 million, or $0.32 per share for the same period a year ago. Non-GAAP net income for the third quarter of fiscal year 2013 was $243 million, or $0.67 per share,2 compared to non-GAAP net income of $216 million, or $0.58 per share for the same period a year ago.

[0001102624-13-000166:8k_2_02:11]
Revenues for the first nine months of fiscal year 2013 totaled $4.616 billion compared to revenues of $4.531 billion for the first nine months of the prior fiscal year. GAAP net income for the first nine months of fiscal year 2013 totaled $332 million, or $0.90 per share, compared to GAAP net income of $425 million, or $1.10 per share for the first nine months of the prior fiscal year. Non-GAAP net income for the first nine months of fiscal year 2013 totaled $588 million, or $1.60 per share, compared to non-GAAP net income of $674 million, or $1.75 per share for the first nine months of the prior fiscal year.

[0001102624-13-000166:8k_2_02:12]
“NetApp delivered solid financial results again this quarter. The value proposition of Data ONTAP® for shared storage infrastructures and the price performance characteristics of the E-series for dedicated storage infrastructures helped drive strong growth in our branded business,” said Tom Georgens, president and CEO. “The robust adoption of clustered Data ONTAP, our industry-leading flash portfolio, and our best-of-breed partnerships position us well for continued growth.”

[0001102624-13-000166:8k_2_02:13]
Outlook

[0001102624-13-000166:8k_2_02:14]
NetApp’s outlook for the fourth quarter of fiscal year 2013 is based on current business expectations, market conditions, and continued uncertainty in the macroeconomic environment.

[0001102624-13-000166:8k_2_02:15]
| ● | NetApp estimates revenue for the fourth quarter of fiscal year 2013 to be in the range of $1.700 billion to $1.800 billion. |

[0001102624-13-000166:8k_2_02:16]
| ● | NetApp estimates GAAP earnings per share for the fourth quarter of fiscal year 2013 to be approximately $0.43 to $0.48 per share. NetApp estimates non-GAAP earnings per share for the fourth quarter of fiscal year 2013 to be approximately $0.65 to $0.70 per share. |

[0001102624-13-000166:8k_2_02:17]
| ● | NetApp estimates that the share count for the fourth quarter of fiscal year 2013 will increase to approximately 372 million shares. |

[0001102624-13-000166:8k_2_02:18]
Business Highlights

[0001102624-13-000166:8k_2_02:19]
During the third quarter of fiscal year 2013, NetApp extended its product and technology innovation leadership, strengthened its alliance ecosystem of strategic best-of-breed partnerships, and continued to be recognized as one of the world’s best places to work. On the product front, NetApp announced enhancements to its FAS3000 storage systems and its E-Series platform to address customers’ varied workload environments. NetApp also deepened its partnerships with industry leaders Cisco and Citrix, and announced a new integration with Amazon Web Services (AWS). Finally, NetApp became the official data storage provider of the NFL.

[0001102624-13-000166:8k_2_02:20]
Highlights include:

[0001102624-13-000166:8k_2_02:21]
NetApp Acquires ionGrid

[0001102624-13-000166:8k_2_02:22]
| ● | NetApp has completed the acquisition of ionGrid, a privately-held software company based in Mountain View, Calif. The acquisition provides NetApp customers with a secure, simple to use solution for accessing enterprise file shares from mobile devices. Financial terms of the acquisition are not being disclosed at this time. |

[0001102624-13-000166:8k_2_02:23]
FAS and E-Series Innovation Helps Customers Fuel Growth

[0001102624-13-000166:8k_2_02:24]
| ● | New FAS midrange storage systems provide foundation for agile data infrastructure. The new FAS3220 and FAS3250 systems are flash-enabled and leverage clustered Data ONTAP to address customer requirements for performance and nonstop operations. Both systems help enterprises and midsized businesses that are consolidating operations onto a shared storage platform improve performance by up to 80% and increase storage capacity up to 100% over existing midrange products. |

[0001102624-13-000166:8k_2_02:25]
| ● | Customers accelerate big data innovation and analysis with enhanced E-Series storage platform. The updated E-Series platform includes the addition of SSD cache for improved performance, a broadening of network interface support for the E5400 storage system for increased connectivity and network flexibility, and new mirroring and replication services for greater data protection. The enhanced platform provides customers with the foundation to build innovative storage systems that deliver superior performance for the most challenging big data workloads. |

[0001102624-13-000166:8k_2_02:26]
Deeper Integration with Partners Enables Customers to Innovate in the Cloud

[0001102624-13-000166:8k_2_02:27]
| ● | NetApp and Cisco expand partnership to unify branch office, data center, and public cloud environments with FlexPod® architecture. The partnership expansion includes efforts in technology integration, solution development, and continued go-to-market collaboration to make it easier for customers to deploy and access next-generation cloud infrastructure solutions. The announcement builds on the already strong momentum FlexPod is experiencing with more than 2,100 customers across more than 35 countries and over 700 channel partners. |

[0001102624-13-000166:8k_2_02:28]
7

[0001102624-13-000166:8k_2_02:29]
| ● | NetApp teams with Amazon Web Services to help customers connect their existing infrastructure to the AWS cloud. NetApp unveiled NetApp® Private Storage for AWS, an enterprise storage solution that allows customers to replicate data from on-premise NetApp storage environments to NetApp Private Storage, and through AWS Direct Connect they can leverage on-demand cloud services. With this solution customers can build an agile cloud infrastructure that balances internal data center resources along with AWS cloud resources to best meet their business needs. |

[0001102624-13-000166:8k_2_02:30]
| ● | NetApp and Citrix collaborate on secure file sharing and on-premise storage solution for enterprise customers. Citrix ShareFile customers now have access to NetApp FAS and V-Series storage systems running clustered Data ONTAP. The new solution will allow customers who store their data on premise to leverage NetApp Data ONTAP software to access data, scale performance and capacity, reduce data center footprint, and reduce costs. |

[0001102624-13-000166:8k_2_02:31]
Customers Build on NetApp to Accelerate Business Operations

[0001102624-13-000166:8k_2_02:32]
| ● | NetApp data storage delivers and protects NFL and Super Bowl XLVII game-day data. Starting with Super Bowl XLVII in New Orleans on February 3, 2013, NetApp kicked off a two-year relationship with the NFL, making NetApp the official data storage provider of the NFL. The NFL will leverage the FAS2220 and FAS2240 storage systems to enable its support of league-wide mission-critical activities. |

[0001102624-13-000166:8k_2_02:33]
| · | Sauber F1 Team relies on NetApp to thrive in Formula 1 racing. Data is one of the Sauber F1 Teams greatest competitive advantages and as a result the team has built its IT infrastructure on a NetApp storage foundation. The Sauber F1 Team leverages a FlexPod architecture and NetApp MetroCluster™ solution for the reliability, simplicity, efficiency, and high availability required to help drive the team’s success. |

[0001102624-13-000166:8k_2_02:34]
|  | NetApp Reinforces Its Standing as a Great Place to Work |

[0001102624-13-000166:8k_2_02:35]
| ● | For the second consecutive year, NetApp was ranked #6 on FORTUNE magazine’s “100 Best Companies to Work For” list for 2013. This is the fifth consecutive year that NetApp has ranked in the top 10 and seventh consecutive year it has ranked in the top 15. |

[0001102624-13-000166:8k_2_02:36]
Webcast and Conference Call Information

[0001102624-13-000166:8k_2_02:37]
The NetApp third quarter fiscal year 2013 conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, February 13, 2013, at 2:30 p.m. Pacific Time. This press release and any other information related to the call will be posted on the Web site at that location. An audio replay Webcast will be available after 4:30 p.m. Pacific Time on the Web site.

[0001102624-13-000166:8k_2_02:38]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-13-000166:8k_2_02:39]
About NetApp

[0001102624-13-000166:8k_2_02:40]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-13-000166:8k_2_02:41]
###

[0001102624-13-000166:8k_2_02:42]
NetApp, the NetApp logo, Go further, faster, Data ONTAP, FlexPod, and MetroCluster are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-13-000166:8k_2_02:43]
| 1GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-13-000166:8k_2_02:44]
| 2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. |

[0001102624-13-000166:8k_2_02:45]
9

[0001102624-13-000166:8k_2_02:46]
NetApp Usage of Non-GAAP Financials

[0001102624-13-000166:8k_2_02:47]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-13-000166:8k_2_02:48]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-13-000166:8k_2_02:49]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 6,723.9 |  |  | $ | 5,398.5 |  |
| Accounts receivable, net |  |  | 633.8 |  |  |  | 830.9 |  |
| Inventories |  |  | 172.9 |  |  |  | 161.5 |  |
| Other current assets |  |  | 518.0 |  |  |  | 435.6 |  |
| Total current assets |  |  | 8,048.6 |  |  |  | 6,826.5 |  |
| Property and equipment, net |  |  | 1,189.2 |  |  |  | 1,137.2 |  |
| Goodwill and other intangible assets, net |  |  | 1,171.9 |  |  |  | 1,141.2 |  |
| Other non-current assets |  |  | 456.2 |  |  |  | 427.4 |  |
| Total assets |  | $ | 10,865.9 |  |  | $ | 9,532.3 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 221.2 |  |  | $ | 233.1 |  |
| Accrued compensation and other current liabilities |  |  | 679.2 |  |  |  | 717.9 |  |
| Current portion of long-term debt |  |  | 1,243.3 |  |  |  | 1,202.3 |  |
| Short-term deferred revenue |  |  | 1,477.3 |  |  |  | 1,366.5 |  |
| Total current liabilities |  |  | 3,621.0 |  |  |  | 3,519.8 |  |
| Long-term debt |  |  | 994.3 |  |  |  | - |  |
| Other long-term liabilities |  |  | 226.9 |  |  |  | 206.9 |  |
| Long-term deferred revenue |  |  | 1,398.7 |  |  |  | 1,449.4 |  |
| Total liabilities |  |  | 6,240.9 |  |  |  | 5,176.1 |  |
| Convertible Notes |  |  | - |  |  |  | 62.6 |  |
| Stockholders' equity |  |  | 4,625.0 |  |  |  | 4,293.6 |  |
| Total liabilities and stockholders' equity |  | $ | 10,865.9 |  |  | $ | 9,532.3 |  |

[0001102624-13-000166:8k_2_02:50]
11

[0001102624-13-000166:8k_2_02:51]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,060.7 |  |  | $ | 1,062.7 |  |  | $ | 2,954.5 |  |  | $ | 3,044.6 |  |
| Software entitlements and maintenance |  |  | 228.6 |  |  |  | 203.5 |  |  |  | 666.5 |  |  |  | 599.7 |  |
| Service |  |  | 340.8 |  |  |  | 299.3 |  |  |  | 994.9 |  |  |  | 886.4 |  |
| Net revenues |  |  | 1,630.1 |  |  |  | 1,565.5 |  |  |  | 4,615.9 |  |  |  | 4,530.7 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 512.5 |  |  |  | 517.8 |  |  |  | 1,442.0 |  |  |  | 1,415.9 |  |
| Cost of software entitlements and maintenance |  |  | 7.3 |  |  |  | 6.2 |  |  |  | 20.9 |  |  |  | 17.1 |  |
| Cost of service |  |  | 145.4 |  |  |  | 133.0 |  |  |  | 424.1 |  |  |  | 379.3 |  |
| Total cost of revenues |  |  | 665.2 |  |  |  | 657.0 |  |  |  | 1,887.0 |  |  |  | 1,812.3 |  |
| Gross profit |  |  | 964.9 |  |  |  | 908.5 |  |  |  | 2,728.9 |  |  |  | 2,718.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 493.5 |  |  |  | 477.0 |  |  |  | 1,464.6 |  |  |  | 1,385.9 |  |
| Research and development |  |  | 215.6 |  |  |  | 208.3 |  |  |  | 660.8 |  |  |  | 606.6 |  |
| General and administrative |  |  | 66.2 |  |  |  | 63.2 |  |  |  | 198.4 |  |  |  | 193.4 |  |
| Acquisition-related expense |  |  | 1.7 |  |  |  | 3.5 |  |  |  | 1.7 |  |  |  | 7.4 |  |
| Total operating expenses |  |  | 777.0 |  |  |  | 752.0 |  |  |  | 2,325.5 |  |  |  | 2,193.3 |  |
| Income from operations |  |  | 187.9 |  |  |  | 156.5 |  |  |  | 403.4 |  |  |  | 525.1 |  |
| Other expense, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.3 |  |  |  | 8.7 |  |  |  | 32.1 |  |  |  | 27.6 |  |
| Interest expense |  |  | (24.0 | ) |  |  | (18.9 | ) |  |  | (63.7 | ) |  |  | (54.7 | ) |
| Other income (expense), net |  |  | 1.6 |  |  |  | 0.6 |  |  |  | 5.9 |  |  |  | (0.1 | ) |
| Total other expense, net |  |  | (12.1 | ) |  |  | (9.6 | ) |  |  | (25.7 | ) |  |  | (27.2 | ) |
| Income before income taxes |  |  | 175.8 |  |  |  | 146.9 |  |  |  | 377.7 |  |  |  | 497.9 |  |
| Provision for income taxes |  |  | 17.7 |  |  |  | 27.3 |  |  |  | 46.2 |  |  |  | 73.2 |  |
| Net income |  | $ | 158.1 |  |  | $ | 119.6 |  |  | $ | 331.5 |  |  | $ | 424.7 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.33 |  |  | $ | 0.91 |  |  | $ | 1.17 |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.32 |  |  | $ | 0.90 |  |  | $ | 1.10 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 359.5 |  |  |  | 360.3 |  |  |  | 362.5 |  |  |  | 364.0 |  |
| Diluted |  |  | 364.7 |  |  |  | 373.7 |  |  |  | 368.1 |  |  |  | 385.1 |  |

[0001102624-13-000166:8k_2_02:52]
12

[0001102624-13-000166:8k_2_02:53]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 158.1 |  |  | $ | 119.6 |  |  | $ | 331.5 |  |  | $ | 424.7 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 86.4 |  |  |  | 73.6 |  |  |  | 255.5 |  |  |  | 210.5 |  |
| Stock-based compensation |  |  | 67.3 |  |  |  | 76.7 |  |  |  | 211.5 |  |  |  | 197.8 |  |
| Accretion of discount and issuance costs on debt |  |  | 15.3 |  |  |  | 13.5 |  |  |  | 44.0 |  |  |  | 38.7 |  |
| Shortfall (excess tax benefit) from stock-based compensation |  |  | (9.4 | ) |  |  | 4.0 |  |  |  | (53.0 | ) |  |  | (80.7 | ) |
| Other, net |  |  | 3.4 |  |  |  | (1.9 | ) |  |  | (8.3 | ) |  |  | 2.8 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (19.8 | ) |  |  | (59.8 | ) |  |  | 193.1 |  |  |  | 55.8 |  |
| Inventories |  |  | 40.3 |  |  |  | 9.5 |  |  |  | (11.4 | ) |  |  | (8.8 | ) |
| Accounts payable |  |  | (29.9 | ) |  |  | (56.0 | ) |  |  | (16.0 | ) |  |  | (10.4 | ) |
| Accrued compensation and other current liabilities |  |  | (19.2 | ) |  |  | 12.6 |  |  |  | (35.1 | ) |  |  | (160.5 | ) |
| Deferred revenue |  |  | 105.3 |  |  |  | 107.6 |  |  |  | 62.7 |  |  |  | 234.5 |  |
| Changes in other operating assets and liabilities, net |  |  | (32.7 | ) |  |  | (30.2 | ) |  |  | (43.8 | ) |  |  | (24.4 | ) |
| Net cash provided by operating activities |  |  | 365.1 |  |  |  | 269.2 |  |  |  | 930.7 |  |  |  | 880.0 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 110.7 |  |  |  | (61.6 | ) |  |  | 204.1 |  |  |  | (21.2 | ) |
| Purchases of property and equipment |  |  | (110.7 | ) |  |  | (91.3 | ) |  |  | (239.7 | ) |  |  | (282.9 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | (89.4 | ) |  |  | - |  |  |  | (89.4 | ) |  |  | (480.0 | ) |
| Other investing activities, net |  |  | 0.2 |  |  |  | (2.0 | ) |  |  | 3.0 |  |  |  | - |  |
| Net cash used in investing activities |  |  | (89.2 | ) |  |  | (154.9 | ) |  |  | (122.0 | ) |  |  | (784.1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 50.4 |  |  |  | 49.1 |  |  |  | 95.5 |  |  |  | 101.0 |  |
| Repurchase and retirement of common stock |  |  | (61.7 | ) |  |  | - |  |  |  | (410.0 | ) |  |  | (600.0 | ) |
| Excess tax benefit (shortfall) from stock-based compensation |  |  | 9.4 |  |  |  | (4.0 | ) |  |  | 53.0 |  |  |  | 80.7 |  |
| Issuance of long-term debt, net |  |  | 987.3 |  |  |  | - |  |  |  | 987.3 |  |  |  | - |  |
| Other financing activities, net |  |  | (0.4 | ) |  |  | 1.5 |  |  |  | (0.7 | ) |  |  | 3.1 |  |
| Net cash provided by (used in) financing activities |  |  | 985.0 |  |  |  | 46.6 |  |  |  | 725.1 |  |  |  | (415.2 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 4.0 |  |  |  | (9.0 | ) |  |  | (1.9 | ) |  |  | (17.1 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 1,264.9 |  |  |  | 151.9 |  |  |  | 1,531.9 |  |  |  | (336.4 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,816.8 |  |  |  | 2,269.0 |  |  |  | 1,549.8 |  |  |  | 2,757.3 |  |
| End of period |  | $ | 3,081.7 |  |  | $ | 2,420.9 |  |  | $ | 3,081.7 |  |  | $ | 2,420.9 |  |

[0001102624-13-000166:8k_2_02:54]
13

[0001102624-13-000166:8k_2_02:55]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 158.1 |  |  | $ | 119.6 |  |  |  | 331.5 |  |  |  | 424.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.4 |  |  |  | 21.6 |  |  |  | 64.3 |  |  |  | 67.6 |  |
| Stock-based compensation |  |  | 67.3 |  |  |  | 76.7 |  |  |  | 211.5 |  |  |  | 197.8 |  |
| Acquisition-related expense |  |  | 1.7 |  |  |  | 3.5 |  |  |  | 1.7 |  |  |  | 15.4 |  |
| Non-cash interest expense |  |  | 15.3 |  |  |  | 13.5 |  |  |  | 44.0 |  |  |  | 38.7 |  |
| Gain on investments |  |  | (0.7 | ) |  |  | (0.7 | ) |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (20.4 | ) |  |  | (18.2 | ) |  |  | (64.2 | ) |  |  | (69.7 | ) |
| NON-GAAP NET INCOME |  | $ | 242.7 |  |  | $ | 216.0 |  |  | $ | 588.1 |  |  | $ | 673.8 |  |
| NET INCOME PER SHARE |  | $ | 0.434 |  |  | $ | 0.320 |  |  |  | 0.901 |  |  |  | 1.103 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.059 |  |  |  | 0.058 |  |  |  | 0.175 |  |  |  | 0.175 |  |
| Stock-based compensation |  |  | 0.184 |  |  |  | 0.205 |  |  |  | 0.574 |  |  |  | 0.514 |  |
| Acquisition-related expense |  |  | 0.005 |  |  |  | 0.010 |  |  |  | 0.005 |  |  |  | 0.040 |  |
| Non-cash interest expense |  |  | 0.042 |  |  |  | 0.036 |  |  |  | 0.119 |  |  |  | 0.101 |  |
| Gain on investments |  |  | (0.002 | ) |  |  | (0.002 | ) |  |  | (0.002 | ) |  |  | (0.002 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.057 | ) |  |  | (0.049 | ) |  |  | (0.174 | ) |  |  | (0.181 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.665 |  |  | $ | 0.578 |  |  | $ | 1.598 |  |  | $ | 1.750 |  |

[0001102624-13-000166:8k_2_02:56]
14

[0001102624-13-000166:8k_2_02:57]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended January 25, 2013 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.9 |  |  | $ | 1.4 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 15.3 |  |
| Cost of service revenues |  |  | - |  |  |  | 4.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4.8 |  |
| Sales and marketing expenses |  |  | 7.5 |  |  |  | 31.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 39.4 |  |
| Research and development expenses |  |  | - |  |  |  | 20.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 20.8 |  |
| General and administrative expenses |  |  | - |  |  |  | 8.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.4 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 15.3 |  |  |  | - |  |  |  | 15.3 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 21.4 |  |  | $ | 67.3 |  |  | $ | 1.7 |  |  | $ | 15.3 |  |  | $ | (0.7 | ) |  | $ | 105.0 |  |

[0001102624-13-000166:8k_2_02:58]
|  |  | Three Months Ended January 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.9 |  |  | $ | 1.6 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 15.5 |  |
| Cost of service revenues |  |  | - |  |  |  | 5.7 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5.7 |  |
| Sales and marketing expenses |  |  | 7.6 |  |  |  | 37.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 45.1 |  |
| Research and development expenses |  |  | 0.1 |  |  |  | 22.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 22.9 |  |
| General and administrative expenses |  |  | - |  |  |  | 9.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 9.1 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 3.5 |  |  |  | - |  |  |  | - |  |  |  | 3.5 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.5 |  |  |  | - |  |  |  | 13.5 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 21.6 |  |  | $ | 76.7 |  |  | $ | 3.5 |  |  | $ | 13.5 |  |  | $ | (0.7 | ) |  | $ | 114.6 |  |

[0001102624-13-000166:8k_2_02:59]
|  |  | Nine Months Ended January 25, 2013 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 41.8 |  |  | $ | 4.7 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 46.5 |  |
| Cost of service revenues |  |  | - |  |  |  | 15.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 15.0 |  |
| Sales and marketing expense |  |  | 22.4 |  |  |  | 101.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 124.2 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 63.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 63.9 |  |
| General and administrative expense |  |  | - |  |  |  | 26.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 26.2 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 44.0 |  |  |  | - |  |  |  | 44.0 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 64.3 |  |  | $ | 211.5 |  |  | $ | 1.7 |  |  | $ | 44.0 |  |  | $ | (0.7 | ) |  | $ | 320.8 |  |

[0001102624-13-000166:8k_2_02:60]
|  |  | Nine Months Ended January 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 41.8 |  |  | $ | 4.1 |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 51.3 |  |
| Cost of service revenues |  |  | - |  |  |  | 13.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.8 |  |
| Sales and marketing expense |  |  | 25.6 |  |  |  | 96.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 122.1 |  |
| Research and development expense |  |  | 0.2 |  |  |  | 57.0 |  |  |  | 2.6 |  |  |  | - |  |  |  | - |  |  |  | 59.8 |  |
| General and administrative expense |  |  | - |  |  |  | 26.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 26.4 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 7.4 |  |  |  | - |  |  |  | - |  |  |  | 7.4 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 38.7 |  |  |  | - |  |  |  | 38.7 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 67.6 |  |  | $ | 197.8 |  |  | $ | 15.4 |  |  | $ | 38.7 |  |  | $ | (0.7 | ) |  | $ | 318.8 |  |

[0001102624-13-000166:8k_2_02:61]
15

[0001102624-13-000166:8k_2_02:62]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | FOURTH QUARTER 2013 |
|  | (Unaudited) |
|  | Fourth Quarter |
|  | 2013 |
| Non-GAAP Guidance - Net Income Per Share | $0.65 - $0.70 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Fourth |  |
| Quarter 2013: |  |
| Amortization of intangible assets | (0.06) |
| Stock-based compensation expense | (0.18) |
| Non-cash interest expense | (0.04) |
| Income tax effect | 0.06 |
| Total Adjustments | (0.22) |
| GAAP Guidance - Net Income Per Share | $0.43 - $0.48 |

[0001102624-13-000166:8k_2_02:63]
16
