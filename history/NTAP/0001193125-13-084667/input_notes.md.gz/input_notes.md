# NTAP notes — 0001193125-13-084667


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-13-084667:notes:1]
Additional
information related to the purchase rights issued under the ESPP is
provided below (in millions, except per right and per share
information):

[0001193125-13-084667:notes:2]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Weighted-average fair value per right granted |  | $ | 10.37 |  |  | $ | 12.93 |  |  | $ | 10.36 |  |  | $ | 13.34 |  |
| Shares issued under the ESPP |  |  | 1.9 |  |  |  | 1.5 |  |  |  | 3.8 |  |  |  | 2.6 |  |
| Weighted-average price per share issued |  | $ | 25.02 |  |  | $ | 31.03 |  |  | $ | 25.16 |  |  | $ | 34.53 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-13-084667:notes:3]
[same as prior period, unchanged from 0001193125-12-487586:notes:3]

[0001193125-13-084667:notes:4]
[same as prior period, unchanged from 0001193125-12-487586:notes:4]

[0001193125-13-084667:notes:5]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of convertible debt |  | $ | 62.6 |  |  | $ | 114.6 |  |
| Acquisition of property and equipment outstanding in accounts payable |  | $ | 30.4 |  |  | $ | 37.4 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 0.8 |  |  | $ | 3.0 |  |
| Vested options assumed in acquisition |  | $ | 1.2 |  |  | $ | 0.0 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 33.9 |  |  | $ | 39.3 |  |
| Interest paid, net of capitalized interest |  | $ | 22.6 |  |  | $ | 21.3 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-084667:notes:6]
The following
is a calculation of basic and diluted net income per share (in
millions):

[0001193125-13-084667:notes:7]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 158.1 |  |  | $ | 119.6 |  |  | $ | 331.5 |  |  | $ | 424.7 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 359.5 |  |  |  | 360.3 |  |  |  | 362.5 |  |  |  | 364.0 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 5.1 |  |  |  | 7.6 |  |  |  | 5.1 |  |  |  | 9.1 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 0.1 |  |  |  | 5.8 |  |  |  | 0.5 |  |  |  | 9.3 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 2.7 |  |
| Shares used in diluted computation |  |  | 364.7 |  |  |  | 373.7 |  |  |  | 368.1 |  |  |  | 385.1 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.33 |  |  | $ | 0.91 |  |  | $ | 1.17 |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.32 |  |  | $ | 0.90 |  |  | $ | 1.10 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-13-084667:notes:8]
[same as prior period, unchanged from 0001193125-12-487586:notes:8]

[0001193125-13-084667:notes:9]
[same as prior period, unchanged from 0001193125-12-487586:notes:9]

[0001193125-13-084667:notes:10]
[same as prior period, unchanged from 0001193125-12-487586:notes:10]

[0001193125-13-084667:notes:11]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 27, 2012 |  |  | 20.6 |  |  | $ | 29.98 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 2.4 |  |  |  | 28.75 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (2.0 | ) |  |  | 17.43 |  |  |  |  |  |  |  |  |  |
| Options forfeited and expired |  |  | (0.7 | ) |  |  | 39.64 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 25, 2013 |  |  | 20.3 |  |  |  | 30.74 |  |  |  | 3.53 |  |  | $ | 166.1 |  |
| Options vested and expected to vest as of January 25, 2013 |  |  | 19.7 |  |  |  | 30.56 |  |  |  | 3.47 |  |  |  | 164.1 |  |
| Exercisable as of January 25, 2013 |  |  | 15.0 |  |  |  | 28.23 |  |  |  | 2.88 |  |  |  | 145.7 |  |

[0001193125-13-084667:notes:12]
The aggregate intrinsic value represents the pre-tax difference
between the exercise price of stock options and the quoted market
price of our stock on that day for all in-the-money options. As of
January 25, 2013, the total unrecognized compensation expense
related to stock options was $59.9 million, which is expected
to be recognized on a straight-line basis over a weighted-average
remaining service period of 2.2 years.

[0001193125-13-084667:notes:13]
[same as prior period, unchanged from 0001193125-12-487586:notes:13]

[0001193125-13-084667:notes:14]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Weighted-average fair value per share granted |  | $ | 20.53 |  |  | $ | 13.26 |  |  | $ | 11.54 |  |  | $ | 16.88 |  |
| Intrinsic value of options exercised |  | $ | 15.0 |  |  | $ | 21.0 |  |  | $ | 30.8 |  |  | $ | 71.6 |  |
| Proceeds received from the exercise of stock options |  | $ | 15.8 |  |  | $ | 19.5 |  |  | $ | 35.3 |  |  | $ | 62.2 |  |
| Fair value of options vested |  | $ | 14.5 |  |  | $ | 18.1 |  |  | $ | 44.0 |  |  | $ | 56.8 |  |

[0001193125-13-084667:notes:15]
[same as prior period, unchanged from 0001193125-12-487586:notes:15]

[0001193125-13-084667:notes:16]
[same as prior period, unchanged from 0001193125-12-487586:notes:16]

[0001193125-13-084667:notes:17]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 27, 2012 |  |  | 12.0 |  |  | $ | 43.28 |  |
| RSUs granted |  |  | 5.5 |  |  |  | 29.45 |  |
| RSUs vested |  |  | (3.5 | ) |  |  | 39.38 |  |
| RSUs forfeited |  |  | (0.9 | ) |  |  | 41.13 |  |
| Outstanding as of January 25, 2013 |  |  | 13.1 |  |  |  | 38.67 |  |

[0001193125-13-084667:notes:18]
RSUs are converted into common stock upon vesting. Upon the
vesting of RSUs, we primarily use the net share settlement
approach, where a portion of the shares are withheld as settlement
of statutory employee withholding taxes, which decreases the shares
issued to the employee by a corresponding value. The number and
value of the shares netted for employee taxes are summarized in the
table below (in millions):

[0001193125-13-084667:notes:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Shares withheld for taxes |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 1.1 |  |  |  | 1.0 |  |
| Fair value of shares withheld |  | $ | 12.2 |  |  | $ | 16.4 |  |  | $ | 34.8 |  |  | $ | 44.2 |  |

[0001193125-13-084667:notes:20]
As of January 25, 2013, the total unrecognized
compensation expense related to RSUs was $351.5 million, which is
expected to be recognized on a straight-line basis over a
weighted-average remaining service period of 2.7 years.

[0001193125-13-084667:notes:21]
[same as prior period, unchanged from 0001193125-12-487586:notes:21]

[0001193125-13-084667:notes:22]
[same as prior period, unchanged from 0001193125-12-487586:notes:22]

[0001193125-13-084667:notes:23]
As of January 25, 2013, the total unrecognized
compensation expense related to the ESPP was $58.1 million, which
is expected to be recognized on a straight-line basis over a
weighted-average remaining service period of 1.4 years.

[0001193125-13-084667:notes:24]
[same as prior period, unchanged from 0001193125-12-487586:notes:24]

[0001193125-13-084667:notes:25]
[same as prior period, unchanged from 0001193125-12-487586:notes:25]

[0001193125-13-084667:notes:26]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Cost of product revenues |  | $ | 1.4 |  |  | $ | 1.6 |  |  | $ | 4.7 |  |  | $ | 4.1 |  |
| Cost of service revenues |  |  | 4.8 |  |  |  | 5.7 |  |  |  | 15.0 |  |  |  | 13.8 |  |
| Sales and marketing |  |  | 31.9 |  |  |  | 37.5 |  |  |  | 101.8 |  |  |  | 96.5 |  |
| Research and development |  |  | 20.8 |  |  |  | 22.8 |  |  |  | 63.8 |  |  |  | 57.0 |  |
| General and administrative |  |  | 8.4 |  |  |  | 9.1 |  |  |  | 26.2 |  |  |  | 26.4 |  |
| Total stock-based compensation expense |  | $ | 67.3 |  |  | $ | 76.7 |  |  | $ | 211.5 |  |  | $ | 197.8 |  |

[0001193125-13-084667:notes:27]
[same as prior period, unchanged from 0001193125-12-487586:notes:27]

[0001193125-13-084667:notes:28]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Employee stock options |  | $ | 10.9 |  |  | $ | 13.8 |  |  | $ | 34.6 |  |  | $ | 43.0 |  |
| RSUs |  |  | 46.3 |  |  |  | 42.1 |  |  |  | 134.1 |  |  |  | 115.4 |  |
| ESPP |  |  | 10.1 |  |  |  | 20.8 |  |  |  | 42.8 |  |  |  | 39.4 |  |
| Total stock-based compensation expense |  | $ | 67.3 |  |  | $ | 76.7 |  |  | $ | 211.5 |  |  | $ | 197.8 |  |

[0001193125-13-084667:notes:29]
[same as prior period, unchanged from 0001193125-12-487586:notes:29]

[0001193125-13-084667:notes:30]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 35.4 |  |  | $ | 74.7 |  |

[0001193125-13-084667:notes:31]
[same as prior period, unchanged from 0001193125-12-487586:notes:31]

[0001193125-13-084667:notes:32]
[same as prior period, unchanged from 0001193125-12-487586:notes:32]

[0001193125-13-084667:notes:33]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Expected term in years |  |  | 4.5 |  |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 0.59 | % |  |  | 0.84 | % |  |  | 0.63 | % |  |  | 1.54 | % |
| Volatility |  |  | 43 | % |  |  | 43 | % |  |  | 42 | % |  |  | 36 | % |

[0001193125-13-084667:notes:34]
|  |  | ESPP |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.20 | % |  |  | 0.18 | % |  |  | 0.19 | % |  |  | 0.19 | % |
| Volatility |  |  | 41 | % |  |  | 45 | % |  |  | 40 | % |  |  | 44 | % |

[0001193125-13-084667:notes:35]
[same as prior period, unchanged from 0001193125-12-487586:notes:35]

[0001193125-13-084667:notes:36]
During the nine months ended January 25, 2013, we
repurchased and retired 12.8 million shares of our common
stock at an average price of $32.10 per share, for an aggregate
purchase price of $410.0 million, of which $122.8 million and
$287.2 million was allocated to additional paid-in capital and
retained earnings, respectively. Since the May 13, 2003
inception of our stock repurchase program through January 25,
2013, we repurchased a total of 131.7 million shares of our
common stock at an average price of $29.89 per share, for an
aggregate purchase price of $3.9 billion.

[0001193125-13-084667:notes:37]
As of January 25, 2013, our Board of Directors had
authorized the repurchase of up to $5.5 billion of our common stock
under our stock repurchase program, including an increase of $1.5
billion approved by our Board of Directors on November 14,
2012. As of January 25, 2013, the remaining authorized amount
for stock repurchases under this program was $1.6 billion with no
termination date. Under this program, we may purchase shares of our
outstanding common stock through open market and privately
negotiated transactions at prices deemed appropriate by our
management. The stock repurchase program may be suspended or
discontinued at any time.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-13-084667:notes:38]
The following
table presents cash, cash equivalents and short-term investments
held in the United States and internationally in various foreign
subsidiaries (in millions):

[0001193125-13-084667:notes:39]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| United States |  | $ | 3,351.4 |  |  | $ | 2,697.6 |  |
| International |  |  | 3,372.5 |  |  |  | 2,763.8 |  |
| Total |  | $ | 6,723.9 |  |  | $ | 5,461.4 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-13-084667:notes:40]
The following
table presents property and equipment information for geographic
areas based on the physical location of the assets (in
millions):

[0001193125-13-084667:notes:41]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| United States |  | $ | 1,093.7 |  |  | $ | 1,038.9 |  |
| International |  |  | 95.5 |  |  |  | 98.3 |  |
| Total |  | $ | 1,189.2 |  |  | $ | 1,137.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-13-084667:notes:42]
5.  Business
Combinations

[0001193125-13-084667:notes:43]
Fiscal
2013 Acquisition

[0001193125-13-084667:notes:44]
On November 14, 2012, we acquired all of the outstanding
shares of CacheIQ, Inc., a privately held storage solutions company
based in Austin, Texas, for $91.0 million in cash and equity. This
acquisition provides us with technology that extends our
capabilities to support non-disruptive operations for enterprise
data center environments. We will integrate this technology into
our product offerings over time.

[0001193125-13-084667:notes:45]
Consideration to acquire CacheIQ consisted of the following (in
millions):

[0001193125-13-084667:notes:46]
| Cash |  | $ | 89.8 |  |
| Equity |  |  | 1.2 |  |
| Total purchase price |  | $ | 91.0 |  |

[0001193125-13-084667:notes:47]
In connection with the acquisition, $15.0 million of the cash
consideration was placed in an escrow account to secure
CacheIQ’s obligations under certain indemnity provisions.
Subject to any claims for indemnity, the escrow funds will be
released between 12 months and 18 months from the closing date of
the acquisition.

[0001193125-13-084667:notes:48]
The purchase price was allocated to CacheIQ’s net
tangible and intangible assets as of the date of acquisition based
on various fair value estimates and analyses, including work
performed by third-party valuation specialists.

[0001193125-13-084667:notes:49]
The following are the preliminary estimated fair value of
assets acquired and liabilities assumed as of the closing date (in
millions):

[0001193125-13-084667:notes:50]
| Cash |  | $ | 0.4 |  |
| Other current assets |  |  | 4.0 |  |
| Finite-lived intangible assets |  |  | 22.0 |  |
| Goodwill |  |  | 72.9 |  |
| Other assets |  |  | 0.9 |  |
| Total assets acquired |  |  | 100.2 |  |
| Current liabilities |  |  | (0.5 | ) |
| Deferred income taxes |  |  | (8.7 | ) |
| Total purchase price |  | $ | 91.0 |  |

[0001193125-13-084667:notes:51]
The goodwill is comprised of expected synergies from
combining the operations of CacheIQ and that of the
Company.

[0001193125-13-084667:notes:52]
Adjustments may be made to the allocation of the purchase price
during the measurement period to reflect adjustments related to
facts existing at the time of the acquisition. None of the goodwill
recognized upon acquisition is deductible for tax purposes. The
finite-lived intangible assets consist of developed technology and
are amortized on a straight-line basis over a five year estimated
useful life.

[0001193125-13-084667:notes:53]
The results of operations of CacheIQ have been included in our
consolidated statements of operations from the acquisition date.
Pro forma results of operations have not been presented because the
acquisition was not material to our results of
operations.

[0001193125-13-084667:notes:54]
Fiscal
2012 Acquisition

[0001193125-13-084667:notes:55]
[same as prior period, unchanged from 0001193125-12-487586:notes:43]

[0001193125-13-084667:notes:56]
[same as prior period, unchanged from 0001193125-12-487586:notes:44]

[0001193125-13-084667:notes:57]
[same as prior period, unchanged from 0001193125-12-487586:notes:45]

[0001193125-13-084667:notes:58]
| Current assets |  | $ | 49.8 |  |
| Property and equipment |  |  | 33.3 |  |
| Finite-lived intangible assets |  |  | 272.1 |  |
| Goodwill |  |  | 143.7 |  |
| Other assets |  |  | 9.3 |  |
| Total assets acquired |  |  | 508.2 |  |
| Current liabilities |  |  | (20.9 | ) |
| Other liabilities |  |  | (7.3 | ) |
| Total purchase price |  | $ | 480.0 |  |

[0001193125-13-084667:notes:59]
[same as prior period, unchanged from 0001193125-12-487586:notes:47]


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-084667:notes:60]
[same as prior period, unchanged from 0001193125-12-487586:notes:48]

[0001193125-13-084667:notes:61]
The following is a calculation of basic and diluted net income
per share (in millions):

[0001193125-13-084667:notes:62]
[same as prior period, unchanged from 0001193125-12-487586:notes:49]

[0001193125-13-084667:notes:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Employee equity award plans |  |  | 15.0 |  |  |  | 13.5 |  |  |  | 16.4 |  |  |  | 10.9 |  |

[0001193125-13-084667:notes:64]
Dilutive shares outstanding during the three and nine months
ended January 25, 2013 and during the three months ended
January 27, 2012 do not include any effect resulting from
warrants, as their impact would have been anti-dilutive. The
Convertible Note hedges are not included in the calculation of
earnings per share for any period as their effect would have been
anti-dilutive. The Convertible Note hedges, if exercised upon
conversion of the Convertible Notes, are expected to reduce
approximately 80% of the dilutive effect of the Convertible Notes
when our stock price is above $31.85 per share.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-13-084667:notes:65]
Cash and cash equivalents (in
millions):

[0001193125-13-084667:notes:66]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Cash |  | $ | 1,069.4 |  |  | $ | 649.8 |  |
| Cash equivalents |  |  | 2,012.3 |  |  |  | 900.0 |  |
| Cash and cash equivalents |  | $ | 3,081.7 |  |  | $ | 1,549.8 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-13-084667:notes:67]
[same as prior period, unchanged from 0001193125-12-487586:notes:54]

[0001193125-13-084667:notes:68]
[same as prior period, unchanged from 0001193125-12-487586:notes:55]

[0001193125-13-084667:notes:69]
[same as prior period, unchanged from 0001193125-12-487586:notes:56]

[0001193125-13-084667:notes:70]
[same as prior period, unchanged from 0001193125-12-487586:notes:57]

[0001193125-13-084667:notes:71]
[same as prior period, unchanged from 0001193125-12-487586:notes:58]

[0001193125-13-084667:notes:72]
We consider an active market to be one in which transactions
for the asset or liability occur with sufficient frequency and
volume to provide pricing information on an on-going basis, and
consider an inactive market to be one in which there are infrequent
or few transactions for the asset or liability, the prices are not
current, or price quotations vary substantially either over time or
among market makers. Where appropriate, our own or the
counterparty’s non-performance risk is considered in
measuring the fair values of liabilities and assets,
respectively.

[0001193125-13-084667:notes:73]
[same as prior period, unchanged from 0001193125-12-487586:notes:60]

[0001193125-13-084667:notes:74]
The following is a summary of our available-for-sale
investments (in millions):

[0001193125-13-084667:notes:75]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,934.1 |  |  | $ | 13.2 |  |  | $ | (1.1 | ) |  | $ | 2,946.2 |  |  | $ | 2,665.2 |  |  | $ | 9.5 |  |  | $ | (1.4 | ) |  | $ | 2,673.3 |  |
| U.S. Treasury and government debt securities |  |  | 506.9 |  |  |  | 0.8 |  |  |  | 0.0 |  |  |  | 507.7 |  |  |  | 836.7 |  |  |  | 1.2 |  |  |  | (0.1 | ) |  |  | 837.8 |  |
| Commercial paper |  |  | 208.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 208.0 |  |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 164.6 |  |
| Certificates of deposit |  |  | 173.0 |  |  |  | 0.2 |  |  |  | 0.0 |  |  |  | 173.2 |  |  |  | 347.7 |  |  |  | 0.5 |  |  |  | 0.0 |  |  |  | 348.2 |  |
| Money market funds |  |  | 1,819.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,819.4 |  |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 724.8 |  |
| Auction rate securities |  |  | 44.8 |  |  |  | 0.4 |  |  |  | (3.0 | ) |  |  | 42.2 |  |  |  | 54.1 |  |  |  | 0.9 |  |  |  | (4.0 | ) |  |  | 51.0 |  |
| Equity funds |  |  | 27.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 27.6 |  |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 25.5 |  |
| Total debt and equity securities |  | $ | 5,713.8 |  |  | $ | 14.6 |  |  | $ | (4.1 | ) |  | $ | 5,724.3 |  |  | $ | 4,818.6 |  |  | $ | 12.1 |  |  | $ | (5.5 | ) |  | $ | 4,825.2 |  |

[0001193125-13-084667:notes:76]
The following table presents the contractual maturities of our
debt investments as of January 25, 2013 (in
millions):

[0001193125-13-084667:notes:77]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,456.7 |  |  | $ | 1,458.7 |  |
| Due in one through five years |  |  | 2,172.4 |  |  |  | 2,183.5 |  |
| Due after ten years* |  |  | 44.8 |  |  |  | 42.2 |  |
|  |  | $ | 3,673.9 |  |  | $ | 3,684.4 |  |

[0001193125-13-084667:notes:78]
[same as prior period, unchanged from 0001193125-12-487586:notes:65]

[0001193125-13-084667:notes:79]
[same as prior period, unchanged from 0001193125-12-487586:notes:66]

[0001193125-13-084667:notes:80]
The following table summarizes our financial assets and
liabilities measured at fair value on a recurring basis as of
January 25, 2013 (in millions):

[0001193125-13-084667:notes:81]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,946.2 |  |  | $ | 0.0 |  |  | $ | 2,946.2 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 507.7 |  |  |  | 233.3 |  |  |  | 274.4 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 208.0 |  |  |  | 0.0 |  |  |  | 208.0 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 173.2 |  |  |  | 0.0 |  |  |  | 173.2 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,819.4 |  |  |  | 1,819.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 42.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 42.2 |  |
| Equity funds |  |  | 27.6 |  |  |  | 27.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 2.2 |  |  |  | 0.0 |  |  |  | 2.2 |  |  |  | 0.0 |  |
| Total |  | $ | 5,726.5 |  |  | $ | 2,080.3 |  |  | $ | 3,604.0 |  |  | $ | 42.2 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 5.2 |  |  | $ | 0.0 |  |  | $ | 5.2 |  |  | $ | 0.0 |  |

[0001193125-13-084667:notes:82]
The following table summarizes the balance sheet
classifications of our financial assets and liabilities measured at
fair value on a recurring basis as of January 25, 2013 (in
millions):

[0001193125-13-084667:notes:83]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 2,012.3 |  |  | $ | 1,819.4 |  |  | $ | 192.9 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,642.2 |  |  |  | 233.3 |  |  |  | 3,408.9 |  |  |  | 0.0 |  |
| Other current assets |  |  | 8.1 |  |  |  | 5.9 |  |  |  | 2.2 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 63.9 |  |  |  | 21.7 |  |  |  | 0.0 |  |  |  | 42.2 |  |
| Total |  | $ | 5,726.5 |  |  | $ | 2,080.3 |  |  | $ | 3,604.0 |  |  | $ | 42.2 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 5.2 |  |  | $ | 0.0 |  |  | $ | 5.2 |  |  | $ | 0.0 |  |

[0001193125-13-084667:notes:84]
Level 2 investments are held by a custodian who prices some of
the investments itself using standard inputs in various asset price
models or obtains investment prices from a third-party pricing
provider that incorporates standard inputs in various asset price
models. We review Level 2 inputs and fair value for reasonableness
and the values may be further validated by comparison to multiple
independent pricing sources. In addition, we review third-party
pricing provider models, key inputs and assumptions and understand
the pricing processes at our third-party providers in determining
the overall reasonableness of the fair value of our Level 2
financial instruments. As of January 25, 2013 and
April 27, 2012, we have not made any adjustments to the prices
obtained from our third-party pricing providers.

[0001193125-13-084667:notes:85]
The unrealized losses on our available-for-sale investments
were caused by market value declines as a result of the economic
environment, as well as fluctuations in market interest rates.
Because the decline in market value is attributable to changes in
market conditions and not credit quality, and because we have
concluded currently that we neither intend to sell nor is it more
likely than not that we will be required to sell these investments
prior to a recovery of par value, we do not consider these
investments to be other-than temporarily impaired as of
January 25, 2013.

[0001193125-13-084667:notes:86]
[same as prior period, unchanged from 0001193125-12-487586:notes:73]

[0001193125-13-084667:notes:87]
|  |  | Fair Value as of January 25, 2013 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARS |  | $ | 42.2 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs – 11.7 yrs (8.7 yrs) |
|  |  |  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.7% - 3.1% (2.1%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.2% - 2.7% (1.6%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 4.3% - 9.6% (7.1%) |

[0001193125-13-084667:notes:88]
All of our auction rate securities (ARS) are classified as
other non-current assets and are backed by pools of student loans
guaranteed by the U.S. Department of Education. We estimate the
fair value of each individual ARS using an income (discounted cash
flow) and market approach that incorporate both observable and
unobservable inputs. Key inputs into the discounted cash flow
analysis include the time-to-economic maturity, liquidity risk
premium, market credit spread and other factors and a coupon rate.
The key input into the market approach is a discount rate. A
significant increase (decrease) in the time-to-economic maturity,
liquidity risk premium, market credit spread and other factors,
coupon rate or discount rate could result in a significantly lower
(higher) fair value estimate. We review the fair value of our Level
3 financial instruments for overall reasonableness by reviewing
service provider pricing methodologies, key inputs and assumptions
and by understanding the processes used by our third-party service
provider. We will continue to monitor our ARS investments in light
of the debt market environment and evaluate these investments for
impairment and classification.

[0001193125-13-084667:notes:89]
[same as prior period, unchanged from 0001193125-12-487586:notes:76]

[0001193125-13-084667:notes:90]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Balance at beginning of period |  | $ | 46.5 |  |  | $ | 56.0 |  |  | $ | 51.0 |  |  | $ | 65.1 |  |
| Total unrealized gains (losses), net included in other comprehensive income (loss) |  |  | 0.0 |  |  |  | (0.7 | ) |  |  | 0.5 |  |  |  | 0.6 |  |
| Total realized gains included in earnings |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 0.7 |  |
| Settlements |  |  | (5.0 | ) |  |  | (5.0 | ) |  |  | (10.0 | ) |  |  | (15.4 | ) |
| Balance at end of period |  | $ | 42.2 |  |  | $ | 51.0 |  |  | $ | 42.2 |  |  | $ | 51.0 |  |

[0001193125-13-084667:notes:91]
Fair
Value of Debt

[0001193125-13-084667:notes:92]
As of January 25, 2013, the fair value of our Senior Notes
was approximately $991.1 million and the fair value of our
Convertible Notes, which includes the debt and equity components of
such, was approximately $1,423.0 million. The fair value of our
debt was based on observable market prices in a less active market,
discounted cash flow models that take into consideration variables
such as credit-rating and interest rate changes, and in the case of
Convertible Notes, also takes into consideration the market price
of our stock. All of our debt obligations are categorized as Level
2 instruments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-13-084667:notes:93]
[same as prior period, unchanged from 0001193125-12-487586:notes:78]

[0001193125-13-084667:notes:94]
Cash and
cash equivalents (in millions):

[0001193125-13-084667:notes:95]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Cash |  | $ | 1,069.4 |  |  | $ | 649.8 |  |
| Cash equivalents |  |  | 2,012.3 |  |  |  | 900.0 |  |
| Cash and cash equivalents |  | $ | 3,081.7 |  |  | $ | 1,549.8 |  |
| Inventories (in millions): |  |  |  |  |  |  |  |  |
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Purchased components |  | $ | 21.7 |  |  | $ | 30.9 |  |
| Finished goods |  |  | 151.2 |  |  |  | 130.6 |  |
| Inventories |  | $ | 172.9 |  |  | $ | 161.5 |  |
| Other current assets (in millions): |  |  |  |  |  |  |  |  |
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Prepaid expenses and other current assets |  | $ | 247.3 |  |  | $ | 225.4 |  |
| Short-term restricted cash |  |  | 7.8 |  |  |  | 8.6 |  |
| Deferred tax assets |  |  | 262.9 |  |  |  | 201.6 |  |
| Other current assets |  | $ | 518.0 |  |  | $ | 435.6 |  |
| Property and equipment, net (in millions): |  |  |  |  |  |  |  |  |
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Land |  | $ | 265.5 |  |  | $ | 247.6 |  |
| Buildings and building improvements |  |  | 496.4 |  |  |  | 417.9 |  |
| Leasehold improvements |  |  | 99.3 |  |  |  | 96.5 |  |
| Computer, production, engineering and other equipment |  |  | 696.0 |  |  |  | 638.1 |  |
| Software |  |  | 412.6 |  |  |  | 381.6 |  |
| Furniture and fixtures |  |  | 82.2 |  |  |  | 71.7 |  |
| Construction-in-progress |  |  | 68.3 |  |  |  | 107.1 |  |
|  |  |  | 2,120.3 |  |  |  | 1,960.5 |  |
| Accumulated depreciation and amortization |  |  | (931.1 | ) |  |  | (823.3 | ) |
| Property and equipment, net |  | $ | 1,189.2 |  |  | $ | 1,137.2 |  |

[0001193125-13-084667:notes:96]
In December 2012 and January 2013, we exercised our options
under our three remaining synthetic leasing arrangements to
terminate the leases and purchase the facilities, including land
and buildings, for $69.6 million. The purchased facilities had a
fair value of $88.4 million at the dates of the respective
purchases. We had accounted for these leasing arrangements as
operating leases. The terminations did not result in a material
impact to our operating results for the three months ended
January 25, 2013.

[0001193125-13-084667:notes:97]
Software includes capitalized internal-use software development
costs with a net book value as follows (in millions):

[0001193125-13-084667:notes:98]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Computer software |  | $ | 170.2 |  |  | $ | 160.1 |  |

[0001193125-13-084667:notes:99]
[same as prior period, unchanged from 0001193125-12-487586:notes:82]

[0001193125-13-084667:notes:100]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Auction rate securities |  | $ | 42.2 |  |  | $ | 51.0 |  |
| Restricted cash |  |  | 2.6 |  |  |  | 2.6 |  |
| Deferred tax assets |  |  | 174.0 |  |  |  | 203.8 |  |
| Other assets |  |  | 237.4 |  |  |  | 170.0 |  |
| Other non-current assets |  | $ | 456.2 |  |  | $ | 427.4 |  |

[0001193125-13-084667:notes:101]
[same as prior period, unchanged from 0001193125-12-487586:notes:84]

[0001193125-13-084667:notes:102]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Product |  | $ | 29.0 |  |  | $ | 25.7 |  |
| Software entitlements and maintenance and service |  |  | 2,847.0 |  |  |  | 2,790.2 |  |
| Total |  | $ | 2,876.0 |  |  | $ | 2,815.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,477.3 |  |  | $ | 1,366.5 |  |
| Long-term |  |  | 1,398.7 |  |  |  | 1,449.4 |  |
| Total |  | $ | 2,876.0 |  |  | $ | 2,815.9 |  |

[0001193125-13-084667:notes:103]
[same as prior period, unchanged from 0001193125-12-487586:notes:86]

[0001193125-13-084667:notes:104]
[same as prior period, unchanged from 0001193125-12-487586:notes:87]

[0001193125-13-084667:notes:105]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Accumulated foreign currency translation adjustments |  | $ | 4.8 |  |  | $ | 4.9 |  |
| Accumulated defined benefit obligation adjustments |  |  | (4.2 | ) |  |  | (4.4 | ) |
| Accumulated unrealized gains on available-for-sale securities |  |  | 9.1 |  |  |  | 4.9 |  |
| Accumulated unrealized losses on derivatives instruments |  |  | (1.1 | ) |  |  | (0.5 | ) |
| Total accumulated other comprehensive income |  | $ | 8.6 |  |  | $ | 4.9 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-13-084667:notes:106]
The following
customer accounted for 10% or more of net accounts
receivable:

[0001193125-13-084667:notes:107]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Avnet, Inc. |  |  | N/A |  |  |  | 11 | % |

[0001193125-13-084667:notes:108]
N/A - Not
Applicable


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-13-084667:notes:109]
Goodwill
activity is summarized as follows (in millions):

[0001193125-13-084667:notes:110]
| April 27, 2012 |  | $ | 905.2 |  |
| Addition |  |  | 72.9 |  |
| January 25, 2013 |  | $ | 978.1 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-13-084667:notes:111]
As of
January 25, 2013, future amortization expense related to
purchased intangible assets is as follows (in millions):

[0001193125-13-084667:notes:112]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 21.0 |  |
| 2014 |  |  | 56.4 |  |
| 2015 |  |  | 55.1 |  |
| 2016 |  |  | 51.3 |  |
| 2017 |  |  | 6.7 |  |
| Thereafter |  |  | 3.3 |  |
| Total |  | $ | 193.8 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-13-084667:notes:113]
Summarized
revenues by geographic region from our internal management system
and utilized by our Chief Executive Officer, who is considered our
Chief Operating Decision Maker, is as follows (in
millions):

[0001193125-13-084667:notes:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Americas (United States, Canada and Latin America) |  | $ | 882.8 |  |  | $ | 853.7 |  |  | $ | 2,581.2 |  |  | $ | 2,564.2 |  |
| Europe, Middle East and Africa |  |  | 528.6 |  |  |  | 525.5 |  |  |  | 1,405.6 |  |  |  | 1,411.1 |  |
| Asia Pacific |  |  | 218.7 |  |  |  | 186.3 |  |  |  | 629.1 |  |  |  | 555.4 |  |
| Net revenues |  | $ | 1,630.1 |  |  | $ | 1,565.5 |  |  | $ | 4,615.9 |  |  | $ | 4,530.7 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-13-084667:notes:115]
6.  Goodwill
and Purchased Intangible Assets, net

[0001193125-13-084667:notes:116]
Goodwill activity is summarized as follows (in
millions):

[0001193125-13-084667:notes:117]
Purchased intangible assets, net consist of identifiable
finite-lived intangibles, as summarized below (in
millions):

[0001193125-13-084667:notes:118]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 304.1 |  |  | $ | (120.8 | ) |  | $ | 183.3 |  |  | $ | 282.1 |  |  | $ | (79.0 | ) |  | $ | 203.1 |  |
| Customer contracts/relationships |  |  | 54.7 |  |  |  | (46.8 | ) |  |  | 7.9 |  |  |  | 59.4 |  |  |  | (32.7 | ) |  |  | 26.7 |  |
| Trademarks and trade names |  |  | 9.9 |  |  |  | (8.0 | ) |  |  | 1.9 |  |  |  | 14.7 |  |  |  | (9.7 | ) |  |  | 5.0 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (1.5 | ) |  |  | 0.7 |  |  |  | 2.2 |  |  |  | (1.0 | ) |  |  | 1.2 |  |
| Total purchased intangible assets |  | $ | 370.9 |  |  | $ | (177.1 | ) |  | $ | 193.8 |  |  | $ | 358.4 |  |  | $ | (122.4 | ) |  | $ | 236.0 |  |

[0001193125-13-084667:notes:119]
Amortization expense for purchased intangible assets is
summarized below (in millions):

[0001193125-13-084667:notes:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of Operations |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | Classifications |
| Developed technology |  | $ | 13.9 |  |  | $ | 14.0 |  |  | $ | 41.8 |  |  | $ | 41.9 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 6.3 |  |  |  | 6.4 |  |  |  | 18.9 |  |  |  | 21.8 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 3.1 |  |  |  | 3.3 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.5 |  |  |  | 0.6 |  |  | Sales and marketing |
|  |  | $ | 21.4 |  |  | $ | 21.6 |  |  | $ | 64.3 |  |  | $ | 67.6 |  |  |  |

[0001193125-13-084667:notes:121]
As of January 25, 2013, future amortization expense
related to purchased intangible assets is as follows (in
millions):


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-13-084667:notes:122]
The notional
value of our outstanding foreign currency forward purchase
contracts that were entered into to hedge forecasted foreign
currency denominated sales and our foreign currency denominated
monetary asset and liability exposures consisted of the following
(in millions):

[0001193125-13-084667:notes:123]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 146.9 |  |  | $ | 96.9 |  |
| British Pound Sterling |  |  | 26.9 |  |  |  | 29.8 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 180.5 |  |  |  | 267.4 |  |
| British Pound Sterling |  |  | 48.3 |  |  |  | 86.4 |  |
| Australian Dollar |  |  | 91.6 |  |  |  | 54.3 |  |
| Israeli Shekel |  |  | 22.3 |  |  |  | 17.2 |  |
| Canadian Dollar |  |  | 19.7 |  |  |  | 38.5 |  |
| Swiss Franc |  |  | 10.3 |  |  |  | 7.3 |  |
| Other |  |  | 46.8 |  |  |  | 44.0 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-13-084667:notes:124]
The following
customers, each of which is a distributor, accounted for 10% or
more of our net revenues:

[0001193125-13-084667:notes:125]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Arrow Electronics, Inc. |  |  | 18 | % |  |  | 15 | % |  |  | 18 | % |  |  | 16 | % |
| Avnet, Inc. |  |  | 14 | % |  |  | 11 | % |  |  | 14 | % |  |  | 12 | % |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-13-084667:notes:126]
The following
table summarizes our warranty reserves (in millions):

[0001193125-13-084667:notes:127]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Beginning balance |  | $ | 111.8 |  |  | $ | 65.0 |  |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 23.5 |  |  |  | 14.1 |  |  |  | 74.3 |  |  |  | 41.5 |  |
| Warranty costs incurred |  |  | (18.5 | ) |  |  | (10.9 | ) |  |  | (40.6 | ) |  |  | (31.3 | ) |
| Ending balance |  | $ | 116.8 |  |  | $ | 68.2 |  |  | $ | 116.8 |  |  | $ | 68.2 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-13-084667:notes:128]
The effect of
derivative instruments not designated as hedges recognized in other
income (expense), net on our condensed consolidated statements of
operations was as follows (in millions):

[0001193125-13-084667:notes:129]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Derivatives Not Designated as Hedging Instruments |  | Gain Recognized into Income |  |  | Gain Recognized into Income |  |
| Foreign exchange forward purchase contracts |  | $ | 0.0 |  |  | $ | 10.7 |  |  | $ | 6.2 |  |  | $ | 24.9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-084667:notes:130]
[same as prior period, unchanged from 0001193125-12-487586:notes:113]

[0001193125-13-084667:notes:131]
[same as prior period, unchanged from 0001193125-12-487586:notes:114]

[0001193125-13-084667:notes:132]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Effective tax rates |  |  | 12.2 | % |  |  | 14.7 | % |

[0001193125-13-084667:notes:133]
Our effective tax rates reflect the impact of a significant
amount of our earnings being taxed in foreign jurisdictions at
rates below the U.S. statutory tax rate.

[0001193125-13-084667:notes:134]
On January 2, 2013, the American Taxpayer Relief Act of
2012 (the Act) was signed into law. Under the Act, the federal
research credit was retroactively extended for amounts paid or
incurred after December 31, 2011, and before January 1,
2014. As a result of the extension, during the three months ended
January 25, 2013, we recorded a benefit of $8.2 million
related to the current year research credit and a discrete benefit
of $3.2 million related to prior year credits that we will
retroactively claim. Unless extended again, the federal research
credit will expire on December 31, 2013.

[0001193125-13-084667:notes:135]
As of January 25, 2013, we had $170.0 million of
unrecognized tax benefits, of which $116.8 million has been
recorded in other long-term liabilities. Unrecognized tax benefits
of $100.8 million, including penalties and interest, would affect
our provision for income taxes if recognized. During the nine
months ended January 25, 2013, there was a gross increase in
our unrecognized tax benefits of $14.8 million for tax positions
related to the current year, and a gross increase of $1.0 million
and gross decrease of $6.8 million for tax positions related to
prior years.

[0001193125-13-084667:notes:136]
On March 26, 2012, we received a Revenue Agent’s
Report from the IRS for our fiscal 2005 through 2007 income tax
returns. On April 25, 2012, we filed a protest related to
transfer pricing matters comparable to similar matters that were
resolved in our favor in our last audit cycle. In September 2012,
we reached a tentative agreement with the IRS field examination
team on the transfer pricing matters under appeals. The IRS field
examination team is currently in the process of revising the
Revenue Agent’s Report for our fiscal 2005 through 2007
income tax returns. This report will be reviewed by certain higher
authorities within the IRS and Joint Committee on Taxation. In
February 2012, the IRS commenced an examination of our fiscal 2008
through 2010 income tax returns. Our open years in U.S. federal
jurisdictions are fiscal 2005 and later years. In addition, we are
effectively subject to federal tax examination adjustments for tax
years ended on or after fiscal year 2000, in that we have tax
attribute carryforwards from these years that could be subject to
adjustments, if and when utilized.

[0001193125-13-084667:notes:137]
[same as prior period, unchanged from 0001193125-12-487586:notes:118]

[0001193125-13-084667:notes:138]
[same as prior period, unchanged from 0001193125-12-487586:notes:119]

[0001193125-13-084667:notes:139]
[same as prior period, unchanged from 0001193125-12-487586:notes:120]


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-13-084667:notes:140]
As of
January 25, 2013, our aggregate future principal debt
maturities are as follows (in millions):

[0001193125-13-084667:notes:141]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 0.0 |  |
| 2014 |  |  | 1,264.9 |  |
| 2015 |  |  | 0.0 |  |
| 2016 |  |  | 0.0 |  |
| 2017 |  |  | 0.0 |  |
| Thereafter |  |  | 1,000.0 |  |
| Total |  | $ | 2,264.9 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-13-084667:notes:142]
9.  Financing
Arrangements

[0001193125-13-084667:notes:143]
Long-term
Debt

[0001193125-13-084667:notes:144]
The following table summarizes the carrying value of our
long-term debt (in millions):

[0001193125-13-084667:notes:145]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 0.0 |  |  |  | N/A |  |
| 1.75% Convertible Notes Due 2013 |  |  | 1,264.9 |  |  |  | 6.31 | % |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 2,264.9 |  |  |  |  |  |  |  | 1,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (27.3 | ) |  |  |  |  |  |  | (62.6 | ) |  |  |  |  |
| Total |  |  | 2,237.6 |  |  |  |  |  |  |  | 1,202.3 |  |  |  |  |  |
| Less: Current portion |  |  | (1,243.3 | ) |  |  |  |  |  |  | (1,202.3 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.3 |  |  |  |  |  |  | $ | 0.0 |  |  |  |  |  |

[0001193125-13-084667:notes:146]
2.00% Senior Notes due 2017 and 3.25% Senior Notes
due 2022

[0001193125-13-084667:notes:147]
In December 2012, we issued $750.0 million principal amount of
2.00% Senior Notes due on December 15, 2017 and $250.0 million
principal amount of 3.25% Senior Notes due on December 15,
2022 (collectively referred to as the Senior Notes). The proceeds
received were net of debt discounts of $5.8 million and issuance
costs of $6.9 million, both of which are amortized as additional
interest expense over the respective terms of the Senior Notes
using the effective interest method. The Senior Notes are
unsecured, unsubordinated obligations, which pay interest
semi-annually on June 15 and December 15 and rank equally
in right of payment with our other existing and future senior
unsecured indebtedness, including the Convertible Notes. During the
three months ended January 25, 2013, interest expense
associated with the Senior Notes was $3.1 million. The proceeds
from the Senior Notes are available for general corporate purposes,
including repayment of certain indebtedness, capital expenditures,
possible stock repurchases, working capital and potential
acquisitions and strategic transactions.

[0001193125-13-084667:notes:148]
We may redeem the Senior Notes in whole or in part, at any time
at our option at specified redemption prices. In addition, upon the
occurrence of certain change of control triggering events, we may
be required to repurchase the Senior Notes at 101% of their
aggregate principal amount, plus accrued and unpaid interest to the
date of repurchase. The Senior Notes also include covenants that
limit our ability to incur debt secured by liens on assets or on
shares of stock or indebtedness of our subsidiaries; to engage in
sale and lease-back transactions; and to consolidate, merge or sell
all or substantially all of our assets. As of January 25,
2013, we were in compliance with all covenants associated with the
Senior Notes.

[0001193125-13-084667:notes:149]
1.75% Convertible Senior Notes due 2013

[0001193125-13-084667:notes:150]
On June 10, 2008, we issued $1,265.0 million
aggregate principal amount of 1.75% Convertible Senior Notes
due 2013 (the Convertible Notes). The Convertible Notes are
unsecured, unsubordinated obligations of the Company, which pay
interest in cash semi-annually at a rate of 1.75% per annum.
The Convertible Notes will mature on June 1, 2013 unless
earlier repurchased or converted in accordance with their terms
prior to such date. The Convertible Notes may be converted, under
the conditions specified below, based on an initial conversion rate
of 31.40 shares of common stock per $1,000 principal amount of
Convertible Notes (which represents an initial effective conversion
price of the Convertible Notes of $31.85 per share), subject to
adjustment as described in the indenture governing the Convertible
Notes.

[0001193125-13-084667:notes:151]
The Convertible Notes are not redeemable by us prior to the
maturity date. In the event of a fundamental change (as defined in
the indenture for the Convertible Notes), holders of the
Convertible Notes may require us to repurchase all or a portion of
their Convertible Notes at a repurchase price equal to 100% of the
principal amount of the Convertible Notes plus accrued and unpaid
interest, if any, to, but excluding, the fundamental change
repurchase date.

[0001193125-13-084667:notes:152]
The holders of the Convertible Notes may convert their
Convertible Notes until the close of business on the scheduled
trading day immediately preceding the maturity date if any of the
following conditions are met: (1) during the five business day
period after any five consecutive trading day period (the
measurement period) in which the trading price of the Convertible
Notes for each day in the measurement period was less than 98% of
an amount equal to (i) the last reported sale price of our
common stock multiplied by (ii) the conversion rate for the
Convertible Notes on each such day; (2) during any calendar
quarter (and only during such calendar quarter) if the last
reported sale price of our common stock for 20 or more trading days
in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the
Convertible Notes on the last trading day of such immediately
preceding calendar quarter; or (3) upon the occurrence of
specified corporate transactions set forth in the indenture for the
Convertible Notes. On or after March 1, 2013, until the
scheduled trading day immediately preceding the maturity date,
holders of the Convertible Notes may convert their Convertible
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Convertible Notes,
and shares of our common stock for any conversion value in excess
of the principal amount of the Convertible Notes, if any. Holders
of the Convertible Notes who convert their Convertible Notes in
connection with a fundamental change will, under certain
circumstances, be entitled to a make-whole premium in the form of
an increase in the conversion rate.

[0001193125-13-084667:notes:153]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Convertible Notes for
at least 20 trading days during the 30 consecutive trading days
ended December 31, 2012, and accordingly, as of
January 25, 2013, the Convertible Notes were not convertible
at the option of the holders. Since the Convertible Notes were not
convertible, the difference between the principal amount and the
carrying value of the Convertible Notes was reflected as equity on
our condensed consolidated balance sheet as of January 25,
2013.

[0001193125-13-084667:notes:154]
The Convertible Notes become unconditionally convertible at the
option of the holders on March 1, 2013. At such time, the
difference between the principal amount and the carrying value of
the Convertible Notes will be reflected as convertible debt in
mezzanine on our condensed consolidated balance sheet.

[0001193125-13-084667:notes:155]
Upon conversion of the Convertible Notes, we deliver cash up to
the principal amount of the Convertible Notes and, with respect to
any excess conversion value greater than the principal amount of
the Convertible Notes, shares of our common stock. As of
January 25, 2013, shares issued related to the Convertible
Notes were minimal. Based on the closing price of our common stock
of $36.15 on January 25, 2013, the if-converted value of our
Convertible Notes exceeded their principal amount by approximately
$170.9 million.

[0001193125-13-084667:notes:156]
We separately account for the liability and equity components
of the Convertible Notes. The initial debt component of the
Convertible Notes was valued at $1,017.0 million based on the
contractual cash flows discounted at an appropriate comparable
market non-convertible debt borrowing rate at the date of issuance
of 6.31%, with the equity component representing the residual
amount of the proceeds of $248.0 million which was recorded as
a debt discount. Issuance costs were allocated pro-rata based on
the relative initial carrying amounts of the debt and equity
components. As a result, $5.2 million of the issuance costs
was allocated to the equity component of the Convertible Notes, and
$21.4 million of the issuance costs remained classified as
other non-current assets. The debt discount and the issuance costs
allocated to the debt component are amortized as additional
interest expense over the term of the Convertible Notes using the
effective interest method.

[0001193125-13-084667:notes:157]
Convertible
Note Hedges and Warrants

[0001193125-13-084667:notes:158]
Concurrent with the issuance of the Convertible Notes, we
purchased Convertible Note hedges and sold warrants. The separate
Convertible Note hedge and warrant transactions are structured to
reduce the potential future economic dilution associated with the
conversion of the Convertible Notes.

[0001193125-13-084667:notes:159]
• Convertible Note Hedges: As of January 25, 2013
and April 27, 2012, we had arrangements with counterparties to
buy up to approximately 31.8 million shares of our common
stock, subject to anti-dilution adjustments, at a price of $31.85
per share, subject to adjustment. The Convertible Note hedge
transactions will expire at the earlier of (1) the last day on
which any Convertible Notes remain outstanding or (2) the
scheduled trading day immediately preceding the maturity date of
the Convertible Notes. Upon exercise of the Convertible Note
hedges, we have the option to receive cash or shares of our common
stock equal to the difference between the then market price and the
strike price of the Convertible Note hedges.

[0001193125-13-084667:notes:160]
• Warrants: As of January 25, 2013 and
April 27, 2012, we had outstanding warrants for others to
acquire, subject to anti-dilution adjustments, 39.7 million
shares of our common stock at an exercise price of $41.28 per
share, subject to adjustment, on a series of days commencing on
September 3, 2013. Upon exercise of the warrants, we have the
option to deliver cash or shares of our common stock equal to the
difference between the then market price and the strike price of
the warrants.

[0001193125-13-084667:notes:161]
As of January 25, 2013, we were subject to potential
dilution on the approximately 20% unhedged portion of our
Convertible Notes upon conversion, if on the date of conversion,
the per-share market price of our common stock exceeds the
conversion price of $31.85.

[0001193125-13-084667:notes:162]
As of January 25, 2013, we received a minimal number of
shares related to the Convertible Note hedge transactions and no
cash or shares were delivered related to the warrant
transactions.

[0001193125-13-084667:notes:163]
Interest
Expense

[0001193125-13-084667:notes:164]
The following table presents the amount of interest expense
recognized related to the Convertible Notes (in
millions):

[0001193125-13-084667:notes:165]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.9 |  |  |  | 13.0 |  |  |  | 41.0 |  |  |  | 38.4 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 3.6 |  |  |  | 3.3 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (0.9 | ) |  |  | (1.1 | ) |  |  | (4.3 | ) |
| Total interest expense related to Convertible Notes |  | $ | 20.6 |  |  | $ | 18.7 |  |  | $ | 60.0 |  |  | $ | 53.9 |  |

[0001193125-13-084667:notes:166]
Debt
Maturities

[0001193125-13-084667:notes:167]
As of January 25, 2013, our aggregate future principal
debt maturities are as follows (in millions):

[0001193125-13-084667:notes:168]
Credit
Facility

[0001193125-13-084667:notes:169]
In December 2012, we entered into a credit agreement with a
syndicated group of lenders that provides for an unsecured $250.0
million five-year revolving credit facility that is comprised of
revolving loans, Eurocurrency loans and/or swingline loans. The
credit facility includes a $100.0 million foreign currency
sub-facility, a $50.0 million letter of credit sub-facility and a
$10.0 million swingline sub-facility available on same-day notice.
Available borrowings under the credit facility are reduced by the
amount of any outstanding borrowings on the sub-facilities. We may
also, subject to certain requirements, request an increase in the
facility up to an additional $100.0 million and request two
additional one-year extensions, subject to certain conditions. The
proceeds from the facility may be used by us for general corporate
purposes.

[0001193125-13-084667:notes:170]
Borrowings under the facility, except for swingline loans,
accrue interest in arrears at an alternate base rate as defined in
the credit agreement or, at our option, an adjusted London
Interbank Offered Rate (LIBOR) plus in each case, a spread (based
on our public debt ratings and the type of loan) ranging from 0.2%
to 1.2%. Swingline borrowings accrue interest at an alternate base
rate. In addition, we are required to pay fees to maintain the
credit facility, whether or not we have outstanding borrowings. The
facility terminates on December 21, 2017 if no extensions have
been requested and contains financial covenants requiring us to
maintain a maximum leverage ratio of not more than 3.0:1.0 and a
minimum interest coverage ratio of not less than 3.5:1.0. The
facility contains customary affirmative and negative covenants,
including covenants that limit our ability to incur debt secured by
liens on assets or indebtedness of our subsidiaries and to
consolidate, merge or sell all or substantially all of our assets.
As of January 25, 2013, no borrowings were outstanding under
the facility and we were in compliance with all covenants
associated with the facility.

[0001193125-13-084667:notes:171]
Other
Long-Term Financing Arrangements

[0001193125-13-084667:notes:172]
The following presents the amounts due under other long-term
financing arrangements (in millions):

[0001193125-13-084667:notes:173]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.6 |  |  |  | 3.5 |  |
| Total |  | $ | 12.0 |  |  | $ | 12.6 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-084667:notes:174]
15.  Commitments and Contingencies

[0001193125-13-084667:notes:175]
Lease
Commitments

[0001193125-13-084667:notes:176]
As of January 25, 2013, future annual minimum lease
payments under all non-cancelable facilities and equipment
operating leases with an initial term in excess of one year totaled
$222.5 million. In the three months ended January 25, 2013, we
terminated all of our remaining synthetic lease
arrangements.

[0001193125-13-084667:notes:177]
Purchase
Orders and Other Commitments

[0001193125-13-084667:notes:178]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. As of January 25, 2013, we had $282.4 million in
non-cancelable purchase commitments with our contract
manufacturers. In addition, we recorded a liability for firm,
non-cancelable and unconditional purchase commitments with contract
manufacturers for quantities in excess of our future demand
forecasts through a charge to cost of product sales. As of
January 25, 2013 and April 27, 2012, such liability
amounted to $8.1 million and $3.3 million, respectively, and is
included in other current liabilities in the condensed consolidated
balance sheets.

[0001193125-13-084667:notes:179]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of January 25,
2013, we had $93.6 million in capital purchase commitments and
$182.3 million in other purchase commitments.

[0001193125-13-084667:notes:180]
Product
Warranties

[0001193125-13-084667:notes:181]
We provide customers a warranty on software of ninety days to
five years and a warranty on hardware of one to five years. The
following table summarizes our warranty reserves (in
millions):

[0001193125-13-084667:notes:182]
Financing
Guarantees

[0001193125-13-084667:notes:183]
Some of our customers have entered into recourse and
non-recourse financing leasing arrangements using third-party
financing companies, and in some situations, we enter into customer
financing arrangements for our products and services that are
contemporaneously sold on a recourse or non-recourse basis to
third-party financing companies. Under the terms of recourse
leases, which are generally three years or less, we remain liable
for the aggregate unpaid remaining lease payments to the
third-party leasing companies in the event of end-user customer
default. These arrangements are generally collateralized by a
security interest in the underlying assets. Under the terms of the
nonrecourse leases, we do not have any continuing obligations or
liabilities to the third-party financing companies. Where we
provide a guarantee for recourse leases, we defer revenues subject
to the industry-specific software revenue recognition guidance, and
recognize revenues for non-software deliverables in accordance with
our multiple deliverable revenue arrangement policy.

[0001193125-13-084667:notes:184]
The aggregate amount of financing guarantees representing the
total maximum potential future payments under financing
arrangements with third parties, and the related deferred revenue
are summarized as follows (in millions):

[0001193125-13-084667:notes:185]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 180.9 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (164.4 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.5 |  |  | $ | 19.1 |  |

[0001193125-13-084667:notes:186]
To date, we have not experienced material losses under our
lease financing programs or other financing
arrangements.

[0001193125-13-084667:notes:187]
Legal
Contingencies

[0001193125-13-084667:notes:188]
When a loss is considered probable and reasonably estimable, we
record a liability in the amount of our best estimate for the
ultimate loss. However, the likelihood of a loss with respect to a
particular contingency is often difficult to predict and
determining a meaningful estimate of the loss or a range of loss
may not be practicable based on the information available and the
potential effect of future events and decisions by third parties
that will determine the ultimate resolution of the
contingency.

[0001193125-13-084667:notes:189]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of January 25, 2013 related to such
matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-084667:notes:190]
[same as prior period, unchanged from 0001193125-12-487586:notes:165]

[0001193125-13-084667:notes:191]
We operate in one industry segment: the design, manufacturing,
marketing, and technical support of high-performance networked
storage solutions. We conduct business globally, and our sales and
support activities are managed on a geographic basis. Our
management reviews financial information presented on a
consolidated basis, accompanied by disaggregated information it
receives from its internal management system about revenues by
geographic region, based on the location from which the customer
relationship is managed, for purposes of allocating resources and
evaluating financial performance. We do not allocate costs of
revenues, research and development, sales and marketing, or general
and administrative expenses to our geographic regions in this
internal management system because management does not review
operations or operating results, or make planning decisions, below
the consolidated entity level.

[0001193125-13-084667:notes:192]
Summarized revenues by geographic region from our internal
management system and utilized by our Chief Executive Officer, who
is considered our Chief Operating Decision Maker, is as follows (in
millions):

[0001193125-13-084667:notes:193]
Americas revenues consist of Americas commercial and U.S.
public sector markets. Sales to customers inside the United States
accounted for $778.9 million and $730.5 million of Americas net
revenues during the three months ended January 25, 2013 and
January 27, 2012, respectively, and $2,287.9 million and
$2,190.2 million of Americas net revenues during the nine months
ended January 25, 2013 and January 27, 2012,
respectively. Sales to Germany accounted for $163.8 million and
$181.9 million for the three months ended January 25, 2013 and
January 27, 2012, respectively, and $451.6 million and $470.9
million for the nine months ended January 25, 2013 and
January 27, 2012, respectively. No other foreign country
accounted for 10% or more of our net revenues.

[0001193125-13-084667:notes:194]
[same as prior period, unchanged from 0001193125-12-487586:notes:168]

[0001193125-13-084667:notes:195]
[same as prior period, unchanged from 0001193125-12-487586:notes:169]

[0001193125-13-084667:notes:196]
The following customers, each of which is a distributor,
accounted for 10% or more of our net revenues:

[0001193125-13-084667:notes:197]
The following customer accounted for 10% or more of net
accounts receivable:


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-084667:notes:198]
[same as prior period, unchanged from 0001193125-12-487586:notes:171]

[0001193125-13-084667:notes:199]
We use derivative instruments to manage exposures to foreign
currency risk. The maximum length of time over which forecasted
foreign currency denominated revenues are hedged is six months. The
notional value of our outstanding foreign currency forward purchase
contracts that were entered into to hedge forecasted foreign
currency denominated sales and our foreign currency denominated
monetary asset and liability exposures consisted of the following
(in millions):

[0001193125-13-084667:notes:200]
The fair value of our short-term foreign currency contracts was
not material as of January 25, 2013 and April 27, 2012.
We did not recognize any gains and losses in earnings due to hedge
ineffectiveness for any period presented.

[0001193125-13-084667:notes:201]
The effect of derivative instruments designated as cash flow
hedges recognized in net revenues on our condensed consolidated
statements of operations is presented in the condensed consolidated
statements of comprehensive income.

[0001193125-13-084667:notes:202]
[same as prior period, unchanged from 0001193125-12-487586:notes:174]


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-13-084667:notes:203]
The
following table summarizes the carrying value of our long-term debt
(in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-13-084667:notes:204]
[same as prior period, unchanged from 0001193125-12-487586:notes:175]

[0001193125-13-084667:notes:205]
There have been no significant changes in our significant
accounting policies as of and for the nine months ended
January 25, 2013, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.

[0001193125-13-084667:notes:206]
[same as prior period, unchanged from 0001193125-12-487586:notes:177]

[0001193125-13-084667:notes:207]
[same as prior period, unchanged from 0001193125-12-487586:notes:178]

[0001193125-13-084667:notes:208]
[same as prior period, unchanged from 0001193125-12-487586:notes:179]

[0001193125-13-084667:notes:209]
[same as prior period, unchanged from 0001193125-12-487586:notes:180]

[0001193125-13-084667:notes:210]
The preparation of the condensed consolidated financial
statements in conformity with GAAP requires management to make
estimates and assumptions that affect the reported amounts of
assets and liabilities and disclosure of contingent assets and
liabilities at the date of the financial statements and the
reported amounts of revenues and expenses during the reporting
periods. Such estimates include, but are not limited to, revenue
recognition, reserves and allowances; inventory valuation and
purchase order accruals; valuation of goodwill and intangibles;
restructuring reserves; product warranties; employee benefit
accruals; stock-based compensation; loss contingencies; investment
impairments; income taxes, and fair value measurements. Actual
results could differ materially from those estimates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-13-084667:notes:211]
[same as prior period, unchanged from 0001193125-12-487586:notes:182]

[0001193125-13-084667:notes:212]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The
first, second and third quarters of fiscal 2013 and 2012 were each
13-week periods.

[0001193125-13-084667:notes:213]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments, that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, comprehensive income and cash flows for the
interim periods presented. The statements have been prepared in
accordance with accounting principles generally accepted in the
United States of America (GAAP) for interim financial information
and in accordance with the instructions to Form 10-Q and Rule 10-01
of Regulation S-X. Accordingly, these statements do not include all
information and footnotes required by GAAP for annual consolidated
financial statements, and should be read in conjunction with our
audited consolidated financial statements as of and for the fiscal
year ended April 27, 2012 contained in our Annual Report on
Form 10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three and
nine months ended January 25, 2013 are not necessarily
indicative of the operating results to be expected for the full
fiscal year or future operating periods.
