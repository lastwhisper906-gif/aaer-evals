# NTAP notes — 0001193125-12-375807


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-12-375807:notes:1]
Additional information related to the purchase rights issued
under the ESPP is provided below (in millions, except per share
information):

[0001193125-12-375807:notes:2]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Weighted-average fair value per right granted |  | $ | 10.25 |  |  | $ | 15.88 |  |
| Shares issued under the ESPP |  |  | 1.9 |  |  |  | 1.1 |  |
| Weighted-average price per share issued |  | $ | 25.30 |  |  | $ | 39.17 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-12-375807:notes:3]
4.  Statements
of Cash Flows

[0001193125-12-375807:notes:4]
Non-cash investing and financing activities and supplemental
cash flow information are as follows (in millions):

[0001193125-12-375807:notes:5]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of convertible debt |  | $ | 62.6 |  |  | $ | 12.6 |  |
| Acquisition of property and equipment on account |  | $ | 27.4 |  |  | $ | 33.7 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 16.2 |  |  | $ | 13.1 |  |
| Interest paid, net of capitalized interest |  | $ | 11.2 |  |  | $ | 11.2 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-12-375807:notes:6]
The following is a calculation of basic and diluted net income
per share (in millions):

[0001193125-12-375807:notes:7]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 63.8 |  |  | $ | 139.5 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 366.1 |  |  |  | 370.3 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 4.9 |  |  |  | 11.8 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 0.2 |  |  |  | 15.4 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 8.0 |  |
| Shares used in diluted computation |  |  | 371.2 |  |  |  | 405.5 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.17 |  |  | $ | 0.38 |  |
| Diluted |  | $ | 0.17 |  |  | $ | 0.34 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-375807:notes:8]
10.  Stockholders’ Equity

[0001193125-12-375807:notes:9]
Stock
Options

[0001193125-12-375807:notes:10]
A summary of the activity under our stock option plans and
agreements is as follows (in millions, except for the exercise
price):

[0001193125-12-375807:notes:11]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding at April 27, 2012 |  |  | 20.6 |  |  | $ | 29.98 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 2.0 |  |  |  | 29.82 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (0.4 | ) |  |  | 17.16 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (0.3 | ) |  |  | 39.45 |  |  |  |  |  |  |  |  |  |
| Outstanding at July 27, 2012 |  |  | 21.9 |  |  |  | 30.04 |  |  |  | 3.82 |  |  | $ | 142.3 |  |
| Options vested and expected to vest as of July 27, 2012 |  |  | 21.1 |  |  |  | 29.75 |  |  |  | 3.75 |  |  |  | 140.7 |  |
| Exercisable at July 27, 2012 |  |  | 14.7 |  |  |  | 26.92 |  |  |  | 3.03 |  |  |  | 119.0 |  |

[0001193125-12-375807:notes:12]
The aggregate intrinsic value represents the pre-tax difference
between the exercise price of stock options and the quoted market
price of our stock on that day for all in-the-money options. As of
July 27, 2012, the total unrecognized compensation expense
related to stock options was $77.8 million, which is expected
to be recognized on a straight-line basis over a weighted-average
remaining service period of 2.4 years.

[0001193125-12-375807:notes:13]
Additional information related to our stock options is
summarized below (in millions, except per share
information):

[0001193125-12-375807:notes:14]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Weighted-average fair value per share granted |  | $ | 10.71 |  |  | $ | 17.24 |  |
| Intrinsic value of options exercised |  | $ | 5.4 |  |  | $ | 43.8 |  |
| Proceeds received from the exercise of stock options |  | $ | 6.7 |  |  | $ | 35.0 |  |
| Fair value of options vested |  | $ | 14.4 |  |  | $ | 18.4 |  |

[0001193125-12-375807:notes:15]
[same as prior period, unchanged from 0001193125-12-096831:notes:204]

[0001193125-12-375807:notes:16]
The following table summarizes activity related to our
restricted stock units (RSUs) (in millions, except for fair
value):

[0001193125-12-375807:notes:17]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding at April 27, 2012 |  |  | 12.0 |  |  | $ | 43.28 |  |
| RSUs granted |  |  | 4.5 |  |  |  | 29.03 |  |
| RSUs vested |  |  | (2.0 | ) |  |  | 39.85 |  |
| RSUs forfeitures and cancellations |  |  | (0.4 | ) |  |  | 42.10 |  |
| Outstanding at July 27, 2012 |  |  | 14.1 |  |  |  | 39.29 |  |

[0001193125-12-375807:notes:18]
RSUs are converted into common stock upon vesting. Upon the
vesting of RSUs, we primarily use the net share settlement
approach, where a portion of the shares are withheld and retired as
settlement of statutory employee withholding taxes, which decreases
the shares issued to the employee by a corresponding value. The
number and value of the shares netted for employee taxes are
summarized in the table below (in millions):

[0001193125-12-375807:notes:19]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Shares withheld for taxes |  |  | 0.7 |  |  |  | 0.5 |  |
| Fair value of shares withheld and retired |  | $ | 19.8 |  |  | $ | 25.3 |  |

[0001193125-12-375807:notes:20]
As of July 27, 2012, the total unrecognized compensation
expense related to RSUs was $410.7 million, which is expected to be
recognized on a straight-line basis over a weighted-average
remaining service period of 3.0 years.

[0001193125-12-375807:notes:21]
Employee
Stock Purchase Plan

[0001193125-12-375807:notes:22]
Under the Employee Stock Purchase Plan (ESPP), employees who
elect to participate are granted options that include a purchase
price adjustment provision under which the employees may purchase
common stock at a 15% discount from the market value of the common
stock at certain specified dates within a two-year offering period.
Additional information related to the purchase rights issued under
the ESPP is provided below (in millions, except per share
information):

[0001193125-12-375807:notes:23]
As of July 27, 2012, the total unrecognized compensation
expense related to the ESPP was $73.8 million, which is expected to
be recognized on a straight-line basis over a weighted-average
remaining service period of 1.8 years.

[0001193125-12-375807:notes:24]
[same as prior period, unchanged from 0001193125-12-096831:notes:210]

[0001193125-12-375807:notes:25]
Stock-based compensation expense included in the condensed
consolidated statements of operations is as follows (in
millions):

[0001193125-12-375807:notes:26]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Cost of product revenues |  | $ | 1.8 |  |  | $ | 1.1 |  |
| Cost of service revenues |  |  | 5.6 |  |  |  | 3.9 |  |
| Sales and marketing |  |  | 39.0 |  |  |  | 28.6 |  |
| Research and development |  |  | 23.7 |  |  |  | 16.0 |  |
| General and administrative |  |  | 9.1 |  |  |  | 8.5 |  |
| Total stock-based compensation expense |  | $ | 79.2 |  |  | $ | 58.1 |  |

[0001193125-12-375807:notes:27]
The following table summarizes stock-based compensation
associated with each type of award (in millions):

[0001193125-12-375807:notes:28]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Employee stock options |  | $ | 12.0 |  |  | $ | 14.5 |  |
| RSUs |  |  | 44.5 |  |  |  | 34.4 |  |
| ESPP |  |  | 22.7 |  |  |  | 9.2 |  |
| Total stock-based compensation expense |  | $ | 79.2 |  |  | $ | 58.1 |  |

[0001193125-12-375807:notes:29]
Stock-based compensation for the three months ended
July 27, 2012 includes a charge of $12.8 million related to
the purchase price adjustment provision under the ESPP.

[0001193125-12-375807:notes:30]
Total income tax benefit (charge) associated with employee
stock transactions and recognized in stockholders’ equity was
as follows (in millions):

[0001193125-12-375807:notes:31]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Income tax benefit (charge) associated with employee stock transactions |  | $ | (8.8 | ) |  | $ | 28.7 |  |

[0001193125-12-375807:notes:32]
Valuation
Assumptions

[0001193125-12-375807:notes:33]
The fair value of each award is estimated on the grant date
using the Black-Scholes option pricing model, assuming no expected
dividends and the following weighted-average
assumptions:

[0001193125-12-375807:notes:34]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 0.63 | % |  |  | 1.60 | % |
| Volatility |  |  | 41 | % |  |  | 35 | % |

[0001193125-12-375807:notes:35]
|  |  | ESPP |  |
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.18 | % |  |  | 0.25 | % |
| Volatility |  |  | 38 | % |  |  | 35 | % |

[0001193125-12-375807:notes:36]
Stock
Repurchase Program

[0001193125-12-375807:notes:37]
During the three months ended July 27, 2012, we
repurchased and retired 4.9 million shares of our common stock
at an average price of $30.31 per share, for an aggregate purchase
price of $150.0 million, of which $46.6 million and $103.4 million
was allocated to additional paid-in capital and retained earnings,
respectively. Since the May 13, 2003 inception of our stock
repurchase program through July 27, 2012, we repurchased a
total of 123.9 million shares of our common stock at an
average price of $29.68 per share, for an aggregate purchase price
of $3.7 billion.

[0001193125-12-375807:notes:38]
As of July 27, 2012, our Board of Directors had authorized
the repurchase of up to $4.0 billion of our common stock under our
stock repurchase program. As of July 27, 2012, the remaining
authorized amount for stock repurchases under this program was $0.3
billion with no termination date. The stock repurchase program may
be suspended or discontinued at any time.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-12-375807:notes:39]
The following table presents cash, cash equivalents and
short-term investments held in the United States and
internationally in various foreign subsidiaries (in
millions):

[0001193125-12-375807:notes:40]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| United States |  | $ | 2,568.4 |  |  | $ | 2,697.6 |  |
| International |  |  | 2,872.7 |  |  |  | 2,763.8 |  |
| Total |  | $ | 5,441.1 |  |  | $ | 5,461.4 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-12-375807:notes:41]
assets. The following table presents property and equipment
information for geographic areas (in millions):

[0001193125-12-375807:notes:42]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| United States |  | $ | 1,041.2 |  |  | $ | 1,038.9 |  |
| International |  |  | 97.9 |  |  |  | 98.3 |  |
| Total |  | $ | 1,139.1 |  |  | $ | 1,137.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-375807:notes:43]
5.  Business
Combination

[0001193125-12-375807:notes:44]
On May 6, 2011, we completed the acquisition of certain
assets related to the Engenio external storage systems business
(Engenio) of LSI Corporation (LSI). We paid LSI $480.0 million
in cash and also assumed certain liabilities related to Engenio.
During the three years following the acquisition, LSI will pay us a
total of $13.0 million to service certain LSI customer
warranties. This acquisition enables us to address growing customer
requirements in the areas of high bandwidth and intensive analytics
workloads such as video, including full-motion video capture and
digital video surveillance, as well as high-performance computing
applications, such as genomics sequencing and scientific
research.

[0001193125-12-375807:notes:45]
The purchase price was allocated to Engenio’s net
tangible and intangible assets as of the date of acquisition based
on various fair value estimates and analyses, including work
performed by third-party valuation specialists.

[0001193125-12-375807:notes:46]
The following are the estimated fair value of assets acquired
and liabilities assumed as of the closing date (in
millions):

[0001193125-12-375807:notes:47]
[same as prior period, unchanged from 0001193125-12-096831:notes:24]

[0001193125-12-375807:notes:48]
As this was an asset acquisition, U.S. goodwill is deductible
for income tax purposes. The goodwill is comprised of expected
synergies in utilizing Engenio’s technology in our products
and channels (and vice versa), reduction in future combined
research and development expenses, and intangible assets, such as
acquired workforce, that do not qualify for separate
recognition.


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-375807:notes:49]
13.  Net
Income per Share

[0001193125-12-375807:notes:50]
The following potential weighted-average shares of common stock
have been excluded from the diluted net income per share
calculations, as their effect would have been anti-dilutive (in
millions):

[0001193125-12-375807:notes:51]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Options and RSUs |  |  | 17.7 |  |  |  | 3.6 |  |

[0001193125-12-375807:notes:52]
Dilutive shares outstanding during the three months ended
July 27, 2012 do not include any effect resulting from
warrants, as their impact would have been anti-dilutive. The Note
hedges are not included in the calculation of earnings per share
for any period as their effect would have been anti-dilutive. The
Note hedges, if exercised upon conversion of the Notes, are
expected to reduce approximately 80% of the dilutive effect of the
Notes when our stock price is above $31.85 per share.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-12-375807:notes:53]
Cash and
cash equivalents (in millions):

[0001193125-12-375807:notes:54]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Cash |  | $ | 843.5 |  |  | $ | 649.8 |  |
| Cash equivalents |  |  | 685.9 |  |  |  | 900.0 |  |
| Cash and cash equivalents |  | $ | 1,529.4 |  |  | $ | 1,549.8 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-375807:notes:55]
8.  Financial
Instruments and Fair Value

[0001193125-12-375807:notes:56]
The accounting guidance for fair value measurements provides a
framework for measuring fair value on either a recurring or
nonrecurring basis whereby the inputs used in valuation techniques
are assigned a hierarchical level. The following are the three
levels of inputs to measure fair value:

[0001193125-12-375807:notes:57]
Level 1: Observable inputs that reflect quoted prices
(unadjusted) for identical assets or liabilities in active
markets.

[0001193125-12-375807:notes:58]
Level 2: Inputs that reflect quoted prices for identical
assets or liabilities in less active markets; quoted prices for
similar assets or liabilities in active markets; inputs other than
quoted prices that are observable for the assets or liabilities; or
inputs that are derived principally from or corroborated by
observable market data by correlation or other means.

[0001193125-12-375807:notes:59]
Level 3: Unobservable inputs that reflect our own
assumptions incorporated in valuation techniques used to measure
fair value. These assumptions are required to be consistent with
market participant assumptions that are reasonably
available.

[0001193125-12-375807:notes:60]
We consider an active market to be one in which transactions
for the asset or liability occur with sufficient frequency and
volume to provide pricing information on an on-going basis, and
consider an inactive market to be one in which there are infrequent
or few transactions for the asset or liability, the prices are not
current, or price quotations vary substantially either over time or
among market makers. Where appropriate, our own or the
counterparty’s non-performance risk is considered in
measuring the fair values of liabilities and assets,
respectively.

[0001193125-12-375807:notes:61]
[same as prior period, unchanged from 0001193125-12-096831:notes:115]

[0001193125-12-375807:notes:62]
The following is a summary of our investments (in
millions):

[0001193125-12-375807:notes:63]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,968.3 |  |  | $ | 12.4 |  |  | $ | (0.6 | ) |  | $ | 2,980.1 |  |  | $ | 2,665.2 |  |  | $ | 9.5 |  |  | $ | (1.4 | ) |  | $ | 2,673.3 |  |
| U.S. Treasury and government debt securities |  |  | 620.0 |  |  |  | 1.2 |  |  |  | 0.0 |  |  |  | 621.2 |  |  |  | 836.7 |  |  |  | 1.2 |  |  |  | (0.1 | ) |  |  | 837.8 |  |
| Commercial paper |  |  | 207.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 207.4 |  |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 164.6 |  |
| Certificates of deposit |  |  | 306.7 |  |  |  | 0.3 |  |  |  | 0.0 |  |  |  | 307.0 |  |  |  | 347.7 |  |  |  | 0.5 |  |  |  | 0.0 |  |  |  | 348.2 |  |
| Money market funds |  |  | 481.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 481.9 |  |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 724.8 |  |
| Auction rate securities |  |  | 49.1 |  |  |  | 0.8 |  |  |  | (3.6 | ) |  |  | 46.3 |  |  |  | 54.1 |  |  |  | 0.9 |  |  |  | (4.0 | ) |  |  | 51.0 |  |
| Equity funds |  |  | 26.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 26.4 |  |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 25.5 |  |
| Total debt and equity securities |  | $ | 4,659.8 |  |  | $ | 14.7 |  |  | $ | (4.2 | ) |  | $ | 4,670.3 |  |  | $ | 4,818.6 |  |  | $ | 12.1 |  |  | $ | (5.5 | ) |  | $ | 4,825.2 |  |

[0001193125-12-375807:notes:64]
The following table presents the contractual maturities of our
debt investments as of July 27, 2012 (in millions):

[0001193125-12-375807:notes:65]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,655.4 |  |  | $ | 1,658.8 |  |
| Due in one through five years |  |  | 2,243.0 |  |  |  | 2,252.9 |  |
| Due after ten years* |  |  | 49.1 |  |  |  | 46.3 |  |
|  |  | $ | 3,947.5 |  |  | $ | 3,958.0 |  |

[0001193125-12-375807:notes:66]
[same as prior period, unchanged from 0001193125-12-096831:notes:119]

[0001193125-12-375807:notes:67]
Fair
Value of Financial Instruments

[0001193125-12-375807:notes:68]
The following table summarizes our financial assets and
liabilities measured at fair value on a recurring basis as of
July 27, 2012 (in millions):

[0001193125-12-375807:notes:69]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,980.1 |  |  | $ | 0.0 |  |  | $ | 2,980.1 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 621.2 |  |  |  | 224.9 |  |  |  | 396.3 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 207.4 |  |  |  | 0.0 |  |  |  | 207.4 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 307.0 |  |  |  | 0.0 |  |  |  | 307.0 |  |  |  | 0.0 |  |
| Money market funds |  |  | 481.9 |  |  |  | 481.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 46.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 46.3 |  |
| Equity funds |  |  | 26.4 |  |  |  | 26.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 8.9 |  |  |  | 0.0 |  |  |  | 8.9 |  |  |  | 0.0 |  |
| Total |  | $ | 4,679.2 |  |  | $ | 733.2 |  |  | $ | 3,899.7 |  |  | $ | 46.3 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 0.4 |  |  | $ | 0.0 |  |  | $ | 0.4 |  |  | $ | 0.0 |  |

[0001193125-12-375807:notes:70]
[same as prior period, unchanged from 0001193125-12-096831:notes:123]

[0001193125-12-375807:notes:71]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 685.9 |  |  | $ | 481.9 |  |  | $ | 204.0 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,911.7 |  |  |  | 224.9 |  |  |  | 3,686.8 |  |  |  | 0.0 |  |
| Other current assets |  |  | 15.1 |  |  |  | 6.2 |  |  |  | 8.9 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 66.5 |  |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 46.3 |  |
| Total |  | $ | 4,679.2 |  |  | $ | 733.2 |  |  | $ | 3,899.7 |  |  | $ | 46.3 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 0.4 |  |  | $ | 0.0 |  |  | $ | 0.4 |  |  | $ | 0.0 |  |

[0001193125-12-375807:notes:72]
Level 2 investments are held by a custodian who prices some of
the investments themselves using standard inputs in various asset
price models or obtains investment prices from a third party
pricing provider that incorporates standard inputs in various asset
price models. We review Level 2 inputs and fair value for
reasonableness and the values may be further validated by
comparison to multiple independent pricing sources. In addition, we
review third-party pricing provider models, key inputs and
assumptions and understand the pricing processes at our third-party
providers in determining the overall reasonableness of the fair
value of our Level 2 financial instruments. As of July 27,
2012 and April 27, 2012, we have not made any adjustments to
the prices obtained from our third party pricing
providers.

[0001193125-12-375807:notes:73]
The unrealized losses on our available-for-sale investments in
corporate bonds were caused by market value declines as a result
of the economic environment, as well as fluctuations in market
interest rates. Because the decline in market value is attributable
to changes in market conditions and not credit quality, and because
we have concluded currently that we neither intend to sell nor is
it more likely than not that we will be required to sell these
investments prior to a recovery of par value, we do not consider
these investments to be other-than temporarily impaired as of
July 27, 2012.

[0001193125-12-375807:notes:74]
Quantitative information about our Level 3 fair value
measurements is as follows (fair value in millions):

[0001193125-12-375807:notes:75]
|  |  | Fair Value at July 27, 2012 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $ | 46.3 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs – 11.8 yrs (8.7 yrs) |
|  |  |  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.7% - 2.4% (2.0%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 0.0% - 2.8% (1.4%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 6.0% - 17.0% (12.7%) |

[0001193125-12-375807:notes:76]
All of our ARSs are classified as other non-current assets and
are backed by pools of student loans guaranteed by the U.S.
Department of Education. We estimate the fair value of each
individual ARS using an income (discounted cash flow) and market
approach that incorporate both observable and unobservable inputs.
Key inputs into the discounted cash flow analysis include the
time-to-economic maturity, liquidity risk premium, market credit
spread and other factors and a coupon rate. The key input into the
market approach is a discount rate. A significant increase
(decrease) in the time-to-economic maturity, liquidity risk
premium, market credit spread and other factors, coupon rate or
discount rate could result in a significantly lower (higher) fair
value estimate. We review the fair value of our Level 3 financial
instruments for overall reasonableness by reviewing service
provider pricing methodologies, key inputs and assumptions and by
understanding the processes used by our third-party service
providers. Based on our ability to access our cash and short-term
investments, our expected operating cash flows, and our other
sources of cash, we do not intend to sell these investments prior
to recovery of value. We will continue to monitor our ARS
investments in light of the debt market environment and evaluate
these investments for impairment and classification.

[0001193125-12-375807:notes:77]
The table below provides a reconciliation of the beginning and
ending balance of our Level 3 auction rate securities measured
at fair value on a recurring basis using significant unobservable
inputs (in millions):

[0001193125-12-375807:notes:78]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Balance at beginning of period |  | $ | 51.0 |  |  | $ | 65.1 |  |
| Total unrealized gains, net included in other comprehensive income |  |  | 0.3 |  |  |  | 0.9 |  |
| Settlements |  |  | (5.0 | ) |  |  | (9.7 | ) |
| Balance at end of period |  | $ | 46.3 |  |  | $ | 56.3 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-12-375807:notes:79]
7.  Balance
Sheet Details

[0001193125-12-375807:notes:80]
[same as prior period, unchanged from 0001193125-12-096831:notes:227]

[0001193125-12-375807:notes:81]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Purchased components |  | $ | 65.2 |  |  | $ | 30.9 |  |
| Finished goods |  |  | 138.5 |  |  |  | 130.6 |  |
| Inventories |  | $ | 203.7 |  |  | $ | 161.5 |  |

[0001193125-12-375807:notes:82]
Other
current assets (in millions):

[0001193125-12-375807:notes:83]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Deferred tax assets, net |  | $ | 228.0 |  |  | $ | 201.6 |  |
| Prepaid expenses and other current assets |  |  | 275.9 |  |  |  | 225.4 |  |
| Short-term restricted cash |  |  | 7.9 |  |  |  | 8.6 |  |
| Other current assets |  | $ | 511.8 |  |  | $ | 435.6 |  |

[0001193125-12-375807:notes:84]
Property
and equipment, net (in millions):

[0001193125-12-375807:notes:85]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Land |  | $ | 247.6 |  |  | $ | 247.6 |  |
| Buildings and building improvements |  |  | 444.0 |  |  |  | 417.9 |  |
| Leasehold improvements |  |  | 100.0 |  |  |  | 96.5 |  |
| Computer, production, engineering and other equipment |  |  | 669.7 |  |  |  | 638.1 |  |
| Software |  |  | 391.9 |  |  |  | 381.6 |  |
| Furniture and fixtures |  |  | 73.1 |  |  |  | 71.7 |  |
| Construction-in-progress |  |  | 90.3 |  |  |  | 107.1 |  |
|  |  |  | 2,016.6 |  |  |  | 1,960.5 |  |
| Accumulated depreciation and amortization |  |  | (877.5 | ) |  |  | (823.3 | ) |
| Property and equipment, net |  | $ | 1,139.1 |  |  | $ | 1.137.2 |  |

[0001193125-12-375807:notes:86]
Software includes capitalized internal-use software development
costs. The net book value of such is as follows (in
millions):

[0001193125-12-375807:notes:87]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Computer software |  | $ | 151.8 |  |  | $ | 160.1 |  |

[0001193125-12-375807:notes:88]
Other
non-current assets (in millions):

[0001193125-12-375807:notes:89]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Auction rate securities |  | $ | 46.3 |  |  | $ | 51.0 |  |
| Restricted cash |  |  | 2.4 |  |  |  | 2.6 |  |
| Deferred tax assets, net |  |  | 179.6 |  |  |  | 203.8 |  |
| Other assets |  |  | 178.0 |  |  |  | 170.0 |  |
| Other non-current assets |  | $ | 406.3 |  |  | $ | 427.4 |  |

[0001193125-12-375807:notes:90]
Short-term and long-term deferred revenue (in
millions):

[0001193125-12-375807:notes:91]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Product |  | $ | 25.3 |  |  | $ | 25.7 |  |
| SEM and service |  |  | 2,742.2 |  |  |  | 2,790.2 |  |
| Total |  | $ | 2,767.5 |  |  | $ | 2,815.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,404.4 |  |  | $ | 1,366.5 |  |
| Long-term |  |  | 1,363.1 |  |  |  | 1,449.4 |  |
| Total |  | $ | 2,767.5 |  |  | $ | 2,815.9 |  |

[0001193125-12-375807:notes:92]
Accumulated other comprehensive income (in
millions):

[0001193125-12-375807:notes:93]
The components of accumulated other comprehensive income
(AOCI), net of related immaterial tax effects, were as
follows:

[0001193125-12-375807:notes:94]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Accumulated foreign currency translation adjustments |  | $ | (0.3 | ) |  | $ | 4.9 |  |
| Accumulated defined benefit obligation adjustments |  |  | (4.3 | ) |  |  | (4.4 | ) |
| Accumulated unrealized gains on available-for-sale securities |  |  | 8.4 |  |  |  | 4.9 |  |
| Accumulated unrealized gains (losses) on derivatives instruments |  |  | 1.4 |  |  |  | (0.5 | ) |
| Total accumulated other comprehensive income |  | $ | 5.2 |  |  | $ | 4.9 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-12-375807:notes:95]
6.  Other
Intangible Assets, Net

[0001193125-12-375807:notes:96]
Other intangible assets, net consist of acquired finite-lived
intangibles, as summarized below (in millions):

[0001193125-12-375807:notes:97]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Other Intangible Assets, Net |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Other Intangible Assets, Net |  |
| Developed technology |  | $ | 282.1 |  |  | $ | (92.9 | ) |  | $ | 189.2 |  |  | $ | 282.1 |  |  | $ | (79.0 | ) |  | $ | 203.1 |  |
| Customer contracts/relationships |  |  | 54.6 |  |  |  | (34.2 | ) |  |  | 20.4 |  |  |  | 59.4 |  |  |  | (32.7 | ) |  |  | 26.7 |  |
| Trademarks and trade names |  |  | 9.9 |  |  |  | (5.9 | ) |  |  | 4.0 |  |  |  | 14.7 |  |  |  | (9.7 | ) |  |  | 5.0 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (1.2 | ) |  |  | 1.0 |  |  |  | 2.2 |  |  |  | (1.0 | ) |  |  | 1.2 |  |
| Total other intangible assets |  | $ | 348.8 |  |  | $ | (134.2 | ) |  | $ | 214.6 |  |  | $ | 358.4 |  |  | $ | (122.4 | ) |  | $ | 236.0 |  |

[0001193125-12-375807:notes:98]
Amortization expense for finite-lived intangible assets is
summarized below (in millions):

[0001193125-12-375807:notes:99]
|  |  | Three Months Ended |  |  | Statements of Operations |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |  | Classifications |
| Developed technology |  | $ | 13.9 |  |  | $ | 13.9 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 6.3 |  |  |  | 9.0 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 1.0 |  |  |  | 1.2 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.2 |  |  | Sales and marketing |
|  |  | $ | 21.4 |  |  | $ | 24.3 |  |  |  |

[0001193125-12-375807:notes:100]
As of July 27, 2012, future amortization expense related
to finite-lived intangible assets is as follows (in
millions):

[0001193125-12-375807:notes:101]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 62.8 |  |
| 2014 |  |  | 52.0 |  |
| 2015 |  |  | 50.6 |  |
| 2016 |  |  | 46.9 |  |
| 2017 |  |  | 2.3 |  |
| Total |  | $ | 214.6 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-12-375807:notes:102]
Summarized revenues by geographic region from our internal
management system and utilized by our Chief Executive Officer, who
is considered our Chief Operating Decision Maker, is as follows (in
millions):

[0001193125-12-375807:notes:103]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Americas (United States, Canada and Latin America)* |  | $ | 801.1 |  |  | $ | 813.4 |  |
| Europe, Middle East and Africa |  |  | 439.3 |  |  |  | 456.7 |  |
| Asia Pacific and Japan |  |  | 204.2 |  |  |  | 188.1 |  |
| Net revenues |  | $ | 1,444.6 |  |  | $ | 1,458.2 |  |

[0001193125-12-375807:notes:104]
| * | Americas revenues consist of Americas commercial and U.S. public sector markets. Sales to customers inside the United States comprised $711.4 million and $689.3 million of Americas net revenues during the three months ended July 27, 2012 and July 29, 2011, respectively. |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-12-375807:notes:105]
The notional value of our outstanding foreign currency forward
purchase contracts that were entered into to hedge forecasted
foreign denominated sales and our foreign currency denominated
monetary asset and liability exposures consisted of the following
(in millions):

[0001193125-12-375807:notes:106]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 103.5 |  |  | $ | 96.9 |  |
| British Pound Sterling |  |  | 29.3 |  |  |  | 29.8 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 188.0 |  |  |  | 267.4 |  |
| British Pound Sterling |  |  | 55.4 |  |  |  | 86.4 |  |
| Australian Dollar |  |  | 73.9 |  |  |  | 38.5 |  |
| Canadian Dollar |  |  | 20.7 |  |  |  | 54.3 |  |
| Israeli Shekel |  |  | 23.2 |  |  |  | 17.2 |  |
| Other |  |  | 59.2 |  |  |  | 51.3 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-375807:notes:107]
The following customers, each of which is a distributor,
accounted for ten percent or more of our net revenues (in
millions):

[0001193125-12-375807:notes:108]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Arrow Electronics, Inc. |  | $ | 229.5 |  |  | $ | 212.9 |  |
| Avnet, Inc. |  |  | 198.3 |  |  |  | 159.1 |  |


## us-gaap:ScheduleOfCashFlowHedgesIncludedInAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-12-375807:notes:109]
The effect of derivative instruments designated as cash flow
hedges recognized in net revenues on our condensed consolidated
statements of operations was as follows (in millions):

[0001193125-12-375807:notes:110]
|  |  | Three Months Ended July 27, 2012 |  |  | Three Months Ended July 29, 2011 |  |
| Derivatives in Cash Flow Hedging Relationships |  | Gain Recognized in AOCI |  |  | Gain Reclassified from AOCI into Income |  |  | Gain Recognized in AOCI |  |  | Gain Reclassified from AOCI into Income |  |
| Foreign exchange forward purchase contracts |  | $ | 6.4 |  |  | $ | 4.5 |  |  | $ | 4.4 |  |  | $ | 1.8 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-12-375807:notes:111]
The following table summarizes our warranty reserves (in
millions):

[0001193125-12-375807:notes:112]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Beginning balance |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 23.7 |  |  |  | 11.7 |  |
| Warranty costs incurred |  |  | (10.3 | ) |  |  | (10.2 | ) |
| Ending balance |  | $ | 96.5 |  |  | $ | 59.5 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-12-375807:notes:113]
The effect of derivative instruments not designated as hedges
recognized in other expense, net on our condensed consolidated
statements of operations was as follows (in millions):

[0001193125-12-375807:notes:114]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Derivatives Not Designated as Hedging Instruments |  | Gain Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | 15.9 |  |  | $ | 6.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-375807:notes:115]
12.  Income
Taxes

[0001193125-12-375807:notes:116]
Our effective tax rates for the periods presented were as
follows:

[0001193125-12-375807:notes:117]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Effective tax rates |  |  | 14.0 | % |  |  | 16.5 | % |

[0001193125-12-375807:notes:118]
Our effective tax rates reflect the impact of a significant
amount of our earnings being taxed in foreign jurisdictions at
rates below the U.S. statutory tax rate. As of July 27, 2012,
we had $162.8 million of unrecognized tax benefits, of which $107.5
million has been recorded in other long-term liabilities and $96.0
million, including penalties and interest, would affect our
provision for income taxes if recognized.

[0001193125-12-375807:notes:119]
On March 26, 2012, we received a Revenue Agent’s
Report from the IRS for our fiscal 2005 through 2007 tax returns.
On April 25, 2012, we filed a protest related to transfer
pricing matters comparable to similar matters that were resolved in
our favor in our last audit cycle. In February 2012, the IRS
commenced an examination of our fiscal 2008 through fiscal 2010
income tax returns. We are also under audit by the California
Franchise Tax Board for our fiscal 2007 and 2008 California income
tax returns. Our open years in U.S. federal jurisdictions are
fiscal 2005 and later years. In addition, we are effectively
subject to federal tax examination adjustments for tax years ended
on or after fiscal year 2000, in that we have tax attribute
carryforwards from these years that could be subject to
adjustments, if and when utilized.

[0001193125-12-375807:notes:120]
On September 17, 2010, the Danish Tax Authorities issued a
decision concluding that distributions declared in 2005 and 2006
from our Danish subsidiary were subject to Danish at-source
dividend withholding tax. We do not believe that our Danish
subsidiary is liable for withholding tax and filed an appeal with
the Danish Tax Tribunal to that effect. On December 19, 2011,
the Danish Tax Tribunal issued a ruling that our Danish subsidiary
was not liable for Danish withholding tax. The Danish tax
examination agency appealed to the Danish High Court in March
2012.

[0001193125-12-375807:notes:121]
We are in various stages of the examination and appeals process
in connection with tax audits worldwide and it is difficult to
determine when these examinations will be settled. It is reasonably
possible that over the next twelve-month period, we may experience
an increase or decrease in unrecognized tax benefits. It is not
possible to determine either the magnitude or the range of any
increase or decrease at this time.

[0001193125-12-375807:notes:122]
In April 2010 our Dutch subsidiary received a favorable tax
ruling from the Dutch tax authorities effective May 1, 2010
that replaces the previous Dutch tax ruling that expired on
April 30, 2010. This ruling results in both a lower level of
earnings subject to tax in the Netherlands and an extension of the
expiration date to April 30, 2015.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-375807:notes:123]
9.  Financing
Arrangements

[0001193125-12-375807:notes:124]
1.75% Convertible Senior Notes Due
2013

[0001193125-12-375807:notes:125]
On June 10, 2008, we issued $1,265.0 million
aggregate principal amount of 1.75% Convertible Senior Notes
due 2013 (the Notes). The Notes are unsecured, unsubordinated
obligations of the Company, which pay interest in cash
semi-annually at a rate of 1.75% per annum. The Notes will
mature on June 1, 2013 unless earlier repurchased or converted
in accordance with their terms prior to such date. The Notes may be
converted, under the conditions specified below, based on an
initial conversion rate of 31.40 shares of common stock per
$1,000 principal amount of Notes (which represents an initial
effective conversion price of the Notes of $31.85 per share),
subject to adjustment as described in the indenture governing the
Notes.

[0001193125-12-375807:notes:126]
The Notes are not redeemable by us prior to the maturity date.
In the event of a fundamental change (as defined in the indenture
for the Notes), holders of the Notes may require us to repurchase
all or a portion of their Notes at a repurchase price equal to 100%
of the principal amount of the Notes plus accrued and unpaid
interest, if any, to, but excluding, the fundamental change
repurchase date.

[0001193125-12-375807:notes:127]
The holders of the Notes may convert their Notes until the
close of business on the scheduled trading day immediately
preceding the maturity date if any of the following conditions are
met: (1) during the five business day period after any five
consecutive trading day period (the measurement period) in which
the trading price of the Notes for each day in the measurement
period was less than 98% of an amount equal to (i) the last
reported sale price of our common stock multiplied by (ii) the
conversion rate for the Notes on each such day; (2) during any
calendar quarter (and only during such calendar quarter) if the
last reported sale price of our common stock for 20 or more trading
days in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the Notes on
the last trading day of such immediately preceding calendar
quarter; or (3) upon the occurrence of specified corporate
transactions set forth in the indenture for the Notes. On or after
March 1, 2013, until the scheduled trading day immediately
preceding the maturity date, holders of the Notes may convert their
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Notes, and shares
of our common stock for any conversion value in excess of the
principal amount of the Notes, if any. Holders of the Notes who
convert their Notes in connection with a fundamental change will,
under certain circumstances, be entitled to a make-whole premium in
the form of an increase in the conversion rate.

[0001193125-12-375807:notes:128]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Notes for at least 20
trading days during the 30 consecutive trading days ended
June 30, 2012, and accordingly, as of July 27, 2012, the
Notes were not convertible at the option of the holder. Since the
Notes were not convertible, the difference between the principal
amount and the carrying value of the Notes was reflected as equity
on our condensed consolidated balance sheet as of July 27,
2012.

[0001193125-12-375807:notes:129]
The determination of whether or not the Notes are convertible
must continue to be performed quarterly. Consequently, the
Notes may be convertible in future quarters prior to March 1,
2013 at which time they become unconditionally convertible. If the
Notes become convertible at the option of the holder, the
difference between the principal amount and the carrying value of
the Notes would be reflected as convertible debt in mezzanine on
our condensed consolidated balance sheets.

[0001193125-12-375807:notes:130]
Upon conversion of the Notes, we deliver cash up to the
principal amount of the Notes and, with respect to any excess
conversion value greater than the principal amount of the Notes,
shares of our common stock. As of July 27, 2012, shares issued
related to the Notes were minimal. Based on the closing price of
our common stock of $32.91 on July 27, 2012, the if-converted
value of our Notes exceeded their principal amount by approximately
$42.2 million.

[0001193125-12-375807:notes:131]
We separately account for the liability and equity components
of the Notes. The initial debt component of the Notes was valued at
$1,017.0 million based on the contractual cash flows
discounted at an appropriate comparable market non-convertible debt
borrowing rate at the date of issuance of 6.31%, with the equity
component representing the residual amount of the proceeds of
$248.0 million which was recorded as a debt discount. Issuance
costs were allocated pro-rata based on the relative initial
carrying amounts of the debt and equity components. As a result,
$5.2 million of the issuance costs was allocated to the equity
component of the Notes, and $21.4 million of the issuance
costs remained classified as other non-current assets. The debt
discount and the issuance costs allocated to the debt component are
amortized as additional interest expense over the term of the Notes
using the effective interest method and an effective interest rate
of 6.31% for all periods presented.

[0001193125-12-375807:notes:132]
The following table reflects the carrying value of the Notes
(in millions):

[0001193125-12-375807:notes:133]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (49.1 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,215.8 |  |  | $ | 1,202.3 |  |

[0001193125-12-375807:notes:134]
The following table presents the amount of interest expense
recognized related to the Notes (in millions):

[0001193125-12-375807:notes:135]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 13.5 |  |  |  | 12.6 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |
| Less capitalized interest |  |  | (0.5 | ) |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 19.7 |  |  | $ | 19.2 |  |

[0001193125-12-375807:notes:136]
The following table reflects the remaining debt discount and
issuance costs as of July 27, 2012 (in millions):

[0001193125-12-375807:notes:137]
| Remaining debt discount |  | $ | 49.1 |  |
| Remaining issuance costs |  |  | 4.2 |  |
| Remaining life of the Notes (years) |  |  | 0.8 |  |

[0001193125-12-375807:notes:138]
Note
Hedges and Warrants

[0001193125-12-375807:notes:139]
Concurrent with the issuance of the Notes, we purchased Note
hedges and sold warrants. The separate Note hedge and warrant
transactions are structured to reduce the potential future economic
dilution associated with the conversion of the Notes.

[0001193125-12-375807:notes:140]
• Note Hedges: As of July 27, 2012 and
April 27, 2012, we had arrangements with counterparties to buy
up to approximately 31.8 million shares, subject to
anti-dilution adjustments, of our common stock at a price of $31.85
per share, subject to adjustment. The Note hedge transactions will
expire at the earlier of (1) the last day on which any Notes
remain outstanding or (2) the scheduled trading day
immediately preceding the maturity date of the Notes. Upon exercise
of the Note hedges, we have the option to receive cash or shares of
our common stock equal to the difference between the then market
price and the strike price of the hedges.

[0001193125-12-375807:notes:141]
• Warrants: As of July 27, 2012 and April 27,
2012, we had outstanding warrants for others to acquire, subject to
anti-dilution adjustments, 39.7 million shares of our common
stock at an exercise price of $41.28 per share, subject to
adjustment, on a series of days commencing on September 3,
2013. Upon exercise of the warrants, we have the option to deliver
cash or shares of our common stock equal to the difference between
the then market price and the strike price of the
warrants.

[0001193125-12-375807:notes:142]
As of July 27, 2012, we were subject to potential dilution
on the approximately 20% unhedged portion of our Notes upon
conversion, if on the date of conversion, the per-share market
price of our common stock exceeds the conversion price of
$31.85.

[0001193125-12-375807:notes:143]
As of July 27, 2012, we received a minimal number of
shares related to the Note hedge transactions and no cash or shares
were delivered related to the warrant transactions.

[0001193125-12-375807:notes:144]
Fair
Value of Notes

[0001193125-12-375807:notes:145]
As of July 27, 2012, the approximate fair value of the
principal amount of the Notes, which includes the debt and equity
components, was approximately $1,476.0 million, or 116.7% of the
face value of the Notes, based upon quoted market information
provided by third party pricing providers (Level 1).

[0001193125-12-375807:notes:146]
Other
Long-Term Financing Arrangements

[0001193125-12-375807:notes:147]
The following presents the amounts due under other long-term
financing arrangements (in millions):

[0001193125-12-375807:notes:148]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 2.7 |  |  |  | 3.5 |  |
| Total |  | $ | 10.6 |  |  | $ | 12.6 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-375807:notes:149]
15.  Commitments and Contingencies

[0001193125-12-375807:notes:150]
Lease
Commitments

[0001193125-12-375807:notes:151]
As of July 27, 2012, future annual minimum lease payments
under all non-cancelable facilities and equipment operating leases
with an initial term in excess of one year totaled $325.7
million.

[0001193125-12-375807:notes:152]
As of July 27, 2012, we have three leasing arrangements
with BNP Paribas LLC (BNPPLC), one of which require us to lease
certain of our land to BNPPLC for a period of 99 years and all
of which require us to lease approximately 0.3 million square
feet of office space from BNPPLC for our headquarters in Sunnyvale,
California, which had an original cost of $69.6 million. Under
these leasing arrangements, we pay BNPPLC minimum lease payments,
which vary based on a fixed rate on the costs of the facilities on
the respective lease commencement dates. We make payments for each
of the leases for a term of five years. We have the option to renew
each of the leases for two consecutive five-year periods upon
approval by BNPPLC. The initial lease terms expire in December 2012
and January 2013. Upon expiration (or upon any earlier termination)
of the lease terms, we must elect one of the following options:
(i) purchase the buildings from BNPPLC at cost; (ii) if
certain conditions are met, arrange for the sale of the buildings
by BNPPLC to a third-party, and be liable for any deficiency
between the net proceeds received from the third-party and
BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to
the residual guarantee, in which event we may recoup some or all of
such payments by arranging for a sale of each or all buildings by
BNPPLC during the ensuing two-year period.

[0001193125-12-375807:notes:153]
These leases require us to maintain specified financial
covenants with which we were in compliance as of July 27,
2012. Such financial covenants include a maximum ratio of Total
Debt to Earnings before Interest, Taxes, Depreciation and
Amortization of less than 3:1 and a minimum amount of Unencumbered
Cash and Short-Term Investments of $300.0 million.

[0001193125-12-375807:notes:154]
Purchase
Orders and Other Commitments

[0001193125-12-375807:notes:155]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. We had $281.0 million in non-cancelable purchase
commitments with our contract manufacturers as of July 27,
2012. In addition, we recorded a liability for firm, non-cancelable
and unconditional purchase commitments with contract manufacturers
for quantities in excess of our future demand forecasts through a
charge to product cost of sales. As of July 27, 2012 and
April 27, 2012, such liability amounted to $7.2 million and
$3.3 million, respectively, and is included in other current
liabilities in the condensed consolidated balance
sheets.

[0001193125-12-375807:notes:156]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of July 27, 2012,
we had $50.3 million in capital purchase commitments and $200.6
million in other purchase commitments.

[0001193125-12-375807:notes:157]
Product
Warranties

[0001193125-12-375807:notes:158]
We provide customers a warranty on software of ninety days to
five years and a warranty on hardware of one to five years. The
following table summarizes our warranty reserves (in
millions):

[0001193125-12-375807:notes:159]
Financing
Guarantees

[0001193125-12-375807:notes:160]
Some of our customers have entered into recourse and
nonrecourse financing leasing arrangements using third-party
financing companies. Under the terms of recourse leases, which are
generally three years or less, we remain liable for the aggregate
unpaid remaining lease payments to the third-party leasing
companies in the event of end-user customer default. These
arrangements are generally collateralized by a security interest in
the underlying assets. Under the terms of the nonrecourse leases,
we do not have any continuing obligations or liabilities to the
third-party financing companies. Where we provide a guarantee for
recourse leases, we defer revenues subject to the industry-specific
software revenue recognition guidance, and recognize revenues for
non-software deliverables in accordance with our multiple
deliverable revenue arrangement policy.

[0001193125-12-375807:notes:161]
The aggregate amount of financing guarantees representing the
total maximum potential future payments under financing
arrangements with third parties, and the related deferred revenue
are summarized as follows (in millions):

[0001193125-12-375807:notes:162]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 161.4 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (151.3 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 10.1 |  |  | $ | 19.1 |  |

[0001193125-12-375807:notes:163]
To date, we have not experienced material losses under our
lease financing programs or other financing
arrangements.

[0001193125-12-375807:notes:164]
Legal
Contingencies

[0001193125-12-375807:notes:165]
When a loss is considered probable and reasonably estimable, we
record a liability in the amount of our best estimate for the
ultimate loss. However, the likelihood of a loss with respect to a
particular contingency is often difficult to predict and
determining a meaningful estimate of the loss or a range of loss
may not be practicable based on the information available and the
potential effect of future events and decisions by third parties
that will determine the ultimate resolution of the
contingency.

[0001193125-12-375807:notes:166]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of July 27, 2012 related to such
matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-375807:notes:167]
14.  Segment,
Geographic, and Significant Customer Information

[0001193125-12-375807:notes:168]
We operate in one reportable industry segment: the design,
manufacturing, marketing, and technical support of high-performance
networked storage solutions. We conduct business globally, and our
sales and support activities are managed on a geographic basis. Our
management reviews financial information presented on a
consolidated basis, accompanied by disaggregated information it
receives from its internal management system about revenues by
geographic region, based on the location from which the customer
relationship is managed, for purposes of allocating resources and
evaluating financial performance. We do not allocate costs of
revenues, research and development, sales and marketing, or general
and administrative expenses to our geographic regions in this
internal management system because management does not review
operations or operating results, or make planning decisions, below
the consolidated entity level.

[0001193125-12-375807:notes:169]
The majority of our assets, excluding cash, cash equivalents,
restricted cash, short-term investments and accounts receivable,
were attributable to our domestic operations. The following
table presents cash, cash equivalents and short-term investments
held in the United States and internationally in various foreign
subsidiaries (in millions):

[0001193125-12-375807:notes:170]
Property and equipment information is based on the physical
location of the assets. The following table presents property and
equipment information for geographic areas (in
millions):

[0001193125-12-375807:notes:171]
No more than ten percent of property and equipment was located
in any single foreign country.

[0001193125-12-375807:notes:172]
International sales to a single foreign country that accounted
for ten percent or more of net revenues are as follows (in
millions):

[0001193125-12-375807:notes:173]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Germany |  | $ | 146.7 |  |  | $ | 147.8 |  |

[0001193125-12-375807:notes:174]
The following customer accounted for ten percent or more of net
accounts receivable (in millions):

[0001193125-12-375807:notes:175]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Avnet, Inc. |  | $ | 63.1 |  |  | $ | 92.5 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-375807:notes:176]
11.  Derivatives and Hedging
Activities

[0001193125-12-375807:notes:177]
We use derivative instruments to manage exposures to foreign
currency risk. The maximum length of time over which forecasted
foreign currency denominated revenues are hedged is six months. The
notional value of our outstanding foreign currency forward purchase
contracts that were entered into to hedge forecasted foreign
denominated sales and our foreign currency denominated monetary
asset and liability exposures consisted of the following (in
millions):

[0001193125-12-375807:notes:178]
The fair value of our short-term foreign currency contracts was
not material as of July 27, 2012 and April 27, 2012. We
did not recognize any gains and losses in earnings due to hedge
ineffectiveness for any period presented.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-375807:notes:179]
3.  Significant Accounting Policies

[0001193125-12-375807:notes:180]
There have been no significant changes in our significant
accounting policies as of and for the three months ended
July 27, 2012, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.

[0001193125-12-375807:notes:181]
Recent
Accounting Standards Not Yet Effective

[0001193125-12-375807:notes:182]
In September 2011, the FASB issued a revised accounting
standard intended to simplify how an entity tests goodwill for
impairment. The revised standard will allow an entity to first
assess qualitative factors to determine whether it is necessary to
perform the two-step quantitative goodwill impairment test. An
entity will no longer be required to calculate the fair value of a
reporting unit unless it determines, based on a qualitative
assessment, that it is more likely than not that its fair value is
less than its carrying amount. This guidance is effective for us
beginning in our fourth quarter of fiscal 2013. We do not expect
this guidance to have a material impact on our consolidated
financial statements.

[0001193125-12-375807:notes:183]
In December 2011, the Financial Accounting Standards Board
issued new guidance that will require us to disclose information
about offsetting arrangements associated with financial and
derivative instruments to enable users of our financial statements
to understand the effect of those arrangements on our financial
position. This guidance is effective for us beginning in our first
quarter of fiscal 2014, at which time we will include the
applicable disclosures required by this accounting standard
update.

[0001193125-12-375807:notes:184]
Use of
Estimates

[0001193125-12-375807:notes:185]
The preparation of the condensed consolidated financial
statements in conformity with GAAP requires management to make
estimates and assumptions that affect the reported amounts of
assets and liabilities and disclosure of contingent assets and
liabilities at the date of the financial statements and the
reported amounts of revenues and expenses during the reporting
periods. Such estimates include, but are not limited to, revenue
recognition, reserves and allowances; inventory valuation and
purchase order accruals; valuation of goodwill and intangibles;
restructuring reserves; product warranties; employee benefit
accruals; stock-based compensation; loss contingencies; investment
impairments; income taxes, and fair value measurements. Actual
results could differ materially from those estimates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-375807:notes:186]
2.  Condensed
Consolidated Financial Statements

[0001193125-12-375807:notes:187]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The first
quarters of fiscal 2013 and 2012 were each 13-week
periods.

[0001193125-12-375807:notes:188]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, and cash flows for the interim periods
presented. The statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (GAAP) for interim financial information and in accordance
with the instructions to Form 10-Q and Rule 10-01 of Regulation
S-X. Accordingly, these statements do not include all information
and footnotes required by GAAP for annual consolidated financial
statements, and should be read in conjunction with our audited
consolidated financial statements as of and for the fiscal year
ended April 27, 2012 contained in our Annual Report on Form
10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three months
ended July 27, 2012 are not necessarily indicative of the
operating results to be expected for the full fiscal year or future
operating periods.
