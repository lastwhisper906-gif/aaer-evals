# NTAP note change history — 0001193125-12-096831 → 0001193125-12-375807


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-08-30):
[0001193125-12-375807:note_history:1]
As of July 27, 2012, future annual minimum lease payments
under all non-cancelable facilities and equipment operating leases
with an initial term in excess of one year totaled $325.7
million.
  (was, 2012-03-05, similarity 0.9863):
[0001193125-12-096831:note_history:1]
As of January 27, 2012, future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year totaled $402.7 million.

- changed (2012-08-30):
[0001193125-12-375807:note_history:2]
As of July 27, 2012, we have three leasing arrangements
with BNP Paribas LLC (BNPPLC), one of which require us to lease
certain of our land to BNPPLC for a period of 99 years and all
of which require us to lease approximately 0.3 million square
feet of office space from BNPPLC for our headquarters in Sunnyvale,
California, which had an original cost of $69.6 million. Under
these leasing arrangements, we pay BNPPLC minimum lease payments,
which vary based on a fixed rate on the costs of the facilities on
the respective lease commencement dates. We make payments for each
of the leases for a term of five years. We have the option to renew
each of the leases for two consecutive five-year periods upon
approval by BNPPLC. The initial lease terms expire in December 2012
and January 2013. Upon expiration (or upon any earlier termination)
of the lease terms, we must elect one of the following options:
(i) purchase the buildings from BNPPLC at cost; (ii) if
certain conditions are met, arrange for the sale of the buildings
by BNPPLC to a third-party, and be liable for any deficiency
between the net proceeds received from the third-party and
BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to
the residual guarantee, in which event we may recoup some or all of
such payments by arranging for a sale of each or all buildings by
BNPPLC during the ensuing two-year period.
  (was, 2012-03-05, similarity 0.9266):
[0001193125-12-096831:note_history:2]
As of January 27, 2012, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC), some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost, up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC's cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

- added (2012-08-30):
[0001193125-12-375807:note_history:3]
These leases require us to maintain specified financial
covenants with which we were in compliance as of July 27,
2012. Such financial covenants include a maximum ratio of Total
Debt to Earnings before Interest, Taxes, Depreciation and
Amortization of less than 3:1 and a minimum amount of Unencumbered
Cash and Short-Term Investments of $300.0 million.

- changed (2012-08-30):
[0001193125-12-375807:note_history:4]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. We had $281.0 million in non-cancelable purchase
commitments with our contract manufacturers as of July 27,
2012. In addition, we recorded a liability for firm, non-cancelable
and unconditional purchase commitments with contract manufacturers
for quantities in excess of our future demand forecasts through a
charge to product cost of sales. As of July 27, 2012 and
April 27, 2012, such liability amounted to $7.2 million and
$3.3 million, respectively, and is included in other current
liabilities in the condensed consolidated balance
sheets.
  (was, 2012-03-05, similarity 0.9934):
[0001193125-12-096831:note_history:4]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $220.4 million in non-cancelable purchase commitments with our contract manufacturers as of January 27, 2012. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of January 27, 2012 and April 29, 2011, such liability amounted to $3.2 million and $4.5 million, respectively, and is included in other current liabilities in the condensed consolidated balance sheets.

- changed (2012-08-30):
[0001193125-12-375807:note_history:5]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of July 27, 2012,
we had $50.3 million in capital purchase commitments and $200.6
million in other purchase commitments.
  (was, 2012-03-05, similarity 0.9898):
[0001193125-12-096831:note_history:5]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. As of January 27, 2012, we had $48.5 million in capital purchase commitments and $230.7 million in other purchase commitments.

- added (2012-08-30):
[0001193125-12-375807:note_history:6]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Beginning balance |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 23.7 |  |  |  | 11.7 |  |
| Warranty costs incurred |  |  | (10.3 | ) |  |  | (10.2 | ) |
| Ending balance |  | $ | 96.5 |  |  | $ | 59.5 |  |

- added (2012-08-30):
[0001193125-12-375807:note_history:7]
Some of our customers have entered into recourse and
nonrecourse financing leasing arrangements using third-party
financing companies. Under the terms of recourse leases, which are
generally three years or less, we remain liable for the aggregate
unpaid remaining lease payments to the third-party leasing
companies in the event of end-user customer default. These
arrangements are generally collateralized by a security interest in
the underlying assets. Under the terms of the nonrecourse leases,
we do not have any continuing obligations or liabilities to the
third-party financing companies. Where we provide a guarantee for
recourse leases, we defer revenues subject to the industry-specific
software revenue recognition guidance, and recognize revenues for
non-software deliverables in accordance with our multiple
deliverable revenue arrangement policy.

- added (2012-08-30):
[0001193125-12-375807:note_history:8]
The aggregate amount of financing guarantees representing the
total maximum potential future payments under financing
arrangements with third parties, and the related deferred revenue
are summarized as follows (in millions):

- added (2012-08-30):
[0001193125-12-375807:note_history:9]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 161.4 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (151.3 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 10.1 |  |  | $ | 19.1 |  |

- added (2012-08-30):
[0001193125-12-375807:note_history:10]
To date, we have not experienced material losses under our
lease financing programs or other financing
arrangements.

- added (2012-08-30):
[0001193125-12-375807:note_history:11]
When a loss is considered probable and reasonably estimable, we
record a liability in the amount of our best estimate for the
ultimate loss. However, the likelihood of a loss with respect to a
particular contingency is often difficult to predict and
determining a meaningful estimate of the loss or a range of loss
may not be practicable based on the information available and the
potential effect of future events and decisions by third parties
that will determine the ultimate resolution of the
contingency.

- changed (2012-08-30):
[0001193125-12-375807:note_history:12]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of July 27, 2012 related to such
matters.
  (was, 2012-03-05, similarity 0.7003):
[0001193125-12-096831:note_history:12]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of January 27, 2012, as the outcome of these legal matters is currently not determinable.

- removed (2012-08-30):
[0001193125-12-096831:note_history:13]
These leases require us to maintain specified financial covenants with which we were in compliance as of January 27, 2012.

- removed (2012-08-30):
[0001193125-12-096831:note_history:14]
As of January 27, 2012, we estimated that the fair value of certain properties under synthetic lease was $51.0 million below the cost of the properties. We are accruing for this deficiency over the remaining terms of the respective leases. As of January 27, 2012, a deficiency reserve of $32.4 million was included in other current liabilities.

- removed (2012-08-30):
[0001193125-12-096831:note_history:15]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Beginning balance |  | $ | 65.0 |  |  | $ | 33.5 |  |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 14.1 |  |  |  | 8.0 |  |  |  | 41.5 |  |  |  | 20.9 |  |
| Warranty costs incurred |  |  | (10.9 | ) |  |  | (5.8 | ) |  |  | (31.3 | ) |  |  | (17.1 | ) |
| Ending balance |  | $ | 68.2 |  |  | $ | 35.7 |  |  | $ | 68.2 |  |  | $ | 35.7 |  |

- removed (2012-08-30):
[0001193125-12-096831:note_history:16]
We have both nonrecourse and recourse lease financing arrangements with third-party financing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of financing arrangements under which we could be called upon to make payments to these third-party financing companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party financing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. As of January 27, 2012, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $101.2 million, and the related deferred revenue and cost of revenues totaled approximately $98.9 million and $9.6 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- removed (2012-08-30):
[0001193125-12-096831:note_history:17]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named certain of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint included claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its complaint on or before September 16, 2011.

- removed (2012-08-30):
[0001193125-12-096831:note_history:18]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests. On December 5, 2011, the court allowed plaintiff to conduct a very limited document inspection. On February 6, 2012, the court denied plaintiff's motion to compel further document production.

- removed (2012-08-30):
[0001193125-12-096831:note_history:19]
The plaintiff filed an amended complaint for a third time on September 15, 2011. This complaint alleged the same claims and requests for relief as the previous complaints. On January 9, 2012, the defendants filed motions to dismiss the amended complaint. A hearing on our motion to dismiss the California lawsuit will be held on March 23, 2012.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-08-30):
[0001193125-12-375807:note_history:20]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The first
quarters of fiscal 2013 and 2012 were each 13-week
periods.
  (was, 2012-03-05, similarity 0.9477):
[0001193125-12-096831:note_history:20]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. The first, second and third quarters of fiscal 2012 and 2011 were each 13-week periods.

- changed (2012-08-30):
[0001193125-12-375807:note_history:21]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, and cash flows for the interim periods
presented. The statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (GAAP) for interim financial information and in accordance
with the instructions to Form 10-Q and Rule 10-01 of Regulation
S-X. Accordingly, these statements do not include all information
and footnotes required by GAAP for annual consolidated financial
statements, and should be read in conjunction with our audited
consolidated financial statements as of and for the fiscal year
ended April 27, 2012 contained in our Annual Report on Form
10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three months
ended July 27, 2012 are not necessarily indicative of the
operating results to be expected for the full fiscal year or future
operating periods.
  (was, 2012-03-05, similarity 0.9933):
[0001193125-12-096831:note_history:21]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three and nine months ended January 27, 2012 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- removed (2012-08-30):
[0001193125-12-096831:note_history:22]
Financial Statements Presentation — Certain prior period amounts have been reclassified in the accompanying condensed consolidated financial statements to conform to current year presentation.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-08-30):
[0001193125-12-375807:note_history:23]
There have been no significant changes in our significant
accounting policies as of and for the three months ended
July 27, 2012, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.
  (was, 2012-03-05, similarity 0.9724):
[0001193125-12-096831:note_history:23]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 27, 2012, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.

- changed (2012-08-30):
[0001193125-12-375807:note_history:24]
In September 2011, the FASB issued a revised accounting
standard intended to simplify how an entity tests goodwill for
impairment. The revised standard will allow an entity to first
assess qualitative factors to determine whether it is necessary to
perform the two-step quantitative goodwill impairment test. An
entity will no longer be required to calculate the fair value of a
reporting unit unless it determines, based on a qualitative
assessment, that it is more likely than not that its fair value is
less than its carrying amount. This guidance is effective for us
beginning in our fourth quarter of fiscal 2013. We do not expect
this guidance to have a material impact on our consolidated
financial statements.
  (was, 2012-03-05, similarity 0.9936):
[0001193125-12-096831:note_history:24]
In September 2011, the FASB issued a revised accounting standard intended to simplify how an entity tests goodwill for impairment. The revised standard will allow an entity to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. An entity will no longer be required to calculate the fair value of a reporting unit unless it determines, based on a qualitative assessment, that it is more likely than not that its fair value is less than its carrying amount. This guidance is effective for us beginning in our first quarter of fiscal 2013. We do not expect this guidance to have a material impact on our consolidated financial statements.

- changed (2012-08-30):
[0001193125-12-375807:note_history:25]
In December 2011, the Financial Accounting Standards Board
issued new guidance that will require us to disclose information
about offsetting arrangements associated with financial and
derivative instruments to enable users of our financial statements
to understand the effect of those arrangements on our financial
position. This guidance is effective for us beginning in our first
quarter of fiscal 2014, at which time we will include the
applicable disclosures required by this accounting standard
update.
  (was, 2012-03-05, similarity 0.747):
[0001193125-12-096831:note_history:25]
In December 2011, the FASB issued new guidance that will require us to disclose information about offsetting arrangements associated with financial and derivative instruments to enable users of our financial statements to understand the effect of those arrangements on our financial position. This guidance is effective for us beginning in our first quarter of fiscal 2014 and is required to be applied retrospectively. We are currently evaluating the impact of adoption on our consolidated financial statements.

- changed (2012-08-30):
[0001193125-12-375807:note_history:26]
The preparation of the condensed consolidated financial
statements in conformity with GAAP requires management to make
estimates and assumptions that affect the reported amounts of
assets and liabilities and disclosure of contingent assets and
liabilities at the date of the financial statements and the
reported amounts of revenues and expenses during the reporting
periods. Such estimates include, but are not limited to, revenue
recognition, reserves and allowances; inventory valuation and
purchase order accruals; valuation of goodwill and intangibles;
restructuring reserves; product warranties; employee benefit
accruals; stock-based compensation; loss contingencies; investment
impairments; income taxes, and fair value measurements. Actual
results could differ materially from those estimates.
  (was, 2012-03-05, similarity 0.9944):
[0001193125-12-096831:note_history:26]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefits; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ materially from those estimates.

- removed (2012-08-30):
[0001193125-12-096831:note_history:27]
Accounting Standards Recently Adopted

- removed (2012-08-30):
[0001193125-12-096831:note_history:28]
Revenue Recognition

- removed (2012-08-30):
[0001193125-12-096831:note_history:29]
In October 2009, the Financial Accounting Standards Board (FASB) amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

- removed (2012-08-30):
[0001193125-12-096831:note_history:30]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

- removed (2012-08-30):
[0001193125-12-096831:note_history:31]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

- removed (2012-08-30):
[0001193125-12-096831:note_history:32]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

- removed (2012-08-30):
[0001193125-12-096831:note_history:33]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010. Previously reported quarterly results have been adjusted to reflect the adoption of these standards and differ from the originally reported results.

- removed (2012-08-30):
[0001193125-12-096831:note_history:34]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

- removed (2012-08-30):
[0001193125-12-096831:note_history:35]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.

- removed (2012-08-30):
[0001193125-12-096831:note_history:36]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

- removed (2012-08-30):
[0001193125-12-096831:note_history:37]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

- removed (2012-08-30):
[0001193125-12-096831:note_history:38]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

- removed (2012-08-30):
[0001193125-12-096831:note_history:39]
When VSOE cannot be established, we attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

- removed (2012-08-30):
[0001193125-12-096831:note_history:40]
When we are unable to establish the selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- removed (2012-08-30):
[0001193125-12-096831:note_history:41]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

- removed (2012-08-30):
[0001193125-12-096831:note_history:42]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

- removed (2012-08-30):
[0001193125-12-096831:note_history:43]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements, particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in our fourth quarter of fiscal 2012. There will be no impact to our results of operations, financial position and cash flows as the guidance relates only to financial statement presentation.

- removed (2012-08-30):
[0001193125-12-096831:note_history:44]
In June 2011, as modified in December 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. The specific requirement to present items that are reclassified from accumulated other comprehensive income to net income separately within their respective components of net income and other comprehensive income has been deferred. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to our results of operations, financial position and cash flows as the guidance relates only to financial statement presentation.


## ntap:DebtDiscountAndIssuanceCostTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-08-30):
[0001193125-12-375807:note_history:45]
The following table reflects the remaining debt discount and
issuance costs as of July 27, 2012 (in millions):


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2012-08-30):
[0001193125-12-096831:note_history:46]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
| Total |  | $ | 14.7 |  |  | $ | 11.5 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-08-30):
[0001193125-12-375807:note_history:47]
The holders of the Notes may convert their Notes until the
close of business on the scheduled trading day immediately
preceding the maturity date if any of the following conditions are
met: (1) during the five business day period after any five
consecutive trading day period (the measurement period) in which
the trading price of the Notes for each day in the measurement
period was less than 98% of an amount equal to (i) the last
reported sale price of our common stock multiplied by (ii) the
conversion rate for the Notes on each such day; (2) during any
calendar quarter (and only during such calendar quarter) if the
last reported sale price of our common stock for 20 or more trading
days in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the Notes on
the last trading day of such immediately preceding calendar
quarter; or (3) upon the occurrence of specified corporate
transactions set forth in the indenture for the Notes. On or after
March 1, 2013, until the scheduled trading day immediately
preceding the maturity date, holders of the Notes may convert their
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Notes, and shares
of our common stock for any conversion value in excess of the
principal amount of the Notes, if any. Holders of the Notes who
convert their Notes in connection with a fundamental change will,
under certain circumstances, be entitled to a make-whole premium in
the form of an increase in the conversion rate.
  (was, 2012-03-05, similarity 0.9988):
[0001193125-12-096831:note_history:47]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of an amount equal to (i) the last reported sale price of our common stock multiplied by (ii) the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013, until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

- added (2012-08-30):
[0001193125-12-375807:note_history:48]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Notes for at least 20
trading days during the 30 consecutive trading days ended
June 30, 2012, and accordingly, as of July 27, 2012, the
Notes were not convertible at the option of the holder. Since the
Notes were not convertible, the difference between the principal
amount and the carrying value of the Notes was reflected as equity
on our condensed consolidated balance sheet as of July 27,
2012.

- changed (2012-08-30):
[0001193125-12-375807:note_history:49]
The determination of whether or not the Notes are convertible
must continue to be performed quarterly. Consequently, the
Notes may be convertible in future quarters prior to March 1,
2013 at which time they become unconditionally convertible. If the
Notes become convertible at the option of the holder, the
difference between the principal amount and the carrying value of
the Notes would be reflected as convertible debt in mezzanine on
our condensed consolidated balance sheets.
  (was, 2012-03-05, similarity 0.6679):
[0001193125-12-096831:note_history:49]
The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may be convertible in future quarters, and therefore may be classified as short-term debt, if the conversion thresholds are met in such quarters. Additionally, since the Notes would be convertible at the option of the holder and the principal amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in mezzanine on our condensed consolidated balance sheets.

- changed (2012-08-30):
[0001193125-12-375807:note_history:50]
Upon conversion of the Notes, we deliver cash up to the
principal amount of the Notes and, with respect to any excess
conversion value greater than the principal amount of the Notes,
shares of our common stock. As of July 27, 2012, shares issued
related to the Notes were minimal. Based on the closing price of
our common stock of $32.91 on July 27, 2012, the if-converted
value of our Notes exceeded their principal amount by approximately
$42.2 million.
  (was, 2012-03-05, similarity 0.9772):
[0001193125-12-096831:note_history:50]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of January 27, 2012, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $37.28 on January 27, 2012, the if-converted value of our Notes exceeded their principal amount by approximately $215.6 million.

- added (2012-08-30):
[0001193125-12-375807:note_history:51]
We separately account for the liability and equity components
of the Notes. The initial debt component of the Notes was valued at
$1,017.0 million based on the contractual cash flows
discounted at an appropriate comparable market non-convertible debt
borrowing rate at the date of issuance of 6.31%, with the equity
component representing the residual amount of the proceeds of
$248.0 million which was recorded as a debt discount. Issuance
costs were allocated pro-rata based on the relative initial
carrying amounts of the debt and equity components. As a result,
$5.2 million of the issuance costs was allocated to the equity
component of the Notes, and $21.4 million of the issuance
costs remained classified as other non-current assets. The debt
discount and the issuance costs allocated to the debt component are
amortized as additional interest expense over the term of the Notes
using the effective interest method and an effective interest rate
of 6.31% for all periods presented.

- changed (2012-08-30):
[0001193125-12-375807:note_history:52]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (49.1 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,215.8 |  |  | $ | 1,202.3 |  |
  (was, 2012-03-05, similarity 0.9069):
[0001193125-12-096831:note_history:52]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (76.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,188.8 |  |  | $ | 1,150.4 |  |

- changed (2012-08-30):
[0001193125-12-375807:note_history:53]
The following table presents the amount of interest expense
recognized related to the Notes (in millions):
  (was, 2012-03-05, similarity 0.6563):
[0001193125-12-096831:note_history:53]
We capitalize interest on facility assets under construction and on significant software development projects. The following table presents the amount of interest expense recognized related to the Notes (in millions):

- changed (2012-08-30):
[0001193125-12-375807:note_history:54]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 13.5 |  |  |  | 12.6 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |
| Less capitalized interest |  |  | (0.5 | ) |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 19.7 |  |  | $ | 19.2 |  |
  (was, 2012-03-05, similarity 0.7969):
[0001193125-12-096831:note_history:54]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.0 |  |  |  | 12.2 |  |  |  | 38.4 |  |  |  | 36.1 |  |
| Amortization of debt issuance costs |  |  | 1.1 |  |  |  | 1.1 |  |  |  | 3.3 |  |  |  | 3.1 |  |
| Less capitalized interest |  |  | (0.9 | ) |  |  | 0.0 |  |  |  | (4.3 | ) |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 18.7 |  |  | $ | 18.8 |  |  | $ | 53.9 |  |  | $ | 55.7 |  |

- changed (2012-08-30):
[0001193125-12-375807:note_history:55]
The following table reflects the remaining debt discount and
issuance costs as of July 27, 2012 (in millions):
  (was, 2012-03-05, similarity 0.9765):
[0001193125-12-096831:note_history:55]
The following table reflects the remaining debt discount and issuance costs as of January 27, 2012 (in millions):

- changed (2012-08-30):
[0001193125-12-375807:note_history:56]
• Note Hedges: As of July 27, 2012 and
April 27, 2012, we had arrangements with counterparties to buy
up to approximately 31.8 million shares, subject to
anti-dilution adjustments, of our common stock at a price of $31.85
per share, subject to adjustment. The Note hedge transactions will
expire at the earlier of (1) the last day on which any Notes
remain outstanding or (2) the scheduled trading day
immediately preceding the maturity date of the Notes. Upon exercise
of the Note hedges, we have the option to receive cash or shares of
our common stock equal to the difference between the then market
price and the strike price of the hedges.
  (was, 2012-03-05, similarity 0.9866):
[0001193125-12-096831:note_history:56]
|  | • |  | Note Hedges: As of January 27, 2012 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

- changed (2012-08-30):
[0001193125-12-375807:note_history:57]
• Warrants: As of July 27, 2012 and April 27,
2012, we had outstanding warrants for others to acquire, subject to
anti-dilution adjustments, 39.7 million shares of our common
stock at an exercise price of $41.28 per share, subject to
adjustment, on a series of days commencing on September 3,
2013. Upon exercise of the warrants, we have the option to deliver
cash or shares of our common stock equal to the difference between
the then market price and the strike price of the
warrants.
  (was, 2012-03-05, similarity 0.9819):
[0001193125-12-096831:note_history:57]
|  | • |  | Warrants: As of January 27, 2012 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

- added (2012-08-30):
[0001193125-12-375807:note_history:58]
As of July 27, 2012, we were subject to potential dilution
on the approximately 20% unhedged portion of our Notes upon
conversion, if on the date of conversion, the per-share market
price of our common stock exceeds the conversion price of
$31.85.

- changed (2012-08-30):
[0001193125-12-375807:note_history:59]
As of July 27, 2012, we received a minimal number of
shares related to the Note hedge transactions and no cash or shares
were delivered related to the warrant transactions.
  (was, 2012-03-05, similarity 0.9851):
[0001193125-12-096831:note_history:59]
As of January 27, 2012, we received a minimal number of shares related to the Note hedge transactions and no cash or shares were delivered related to the warrant transactions.

- changed (2012-08-30):
[0001193125-12-375807:note_history:60]
As of July 27, 2012, the approximate fair value of the
principal amount of the Notes, which includes the debt and equity
components, was approximately $1,476.0 million, or 116.7% of the
face value of the Notes, based upon quoted market information
provided by third party pricing providers (Level 1).
  (was, 2012-03-05, similarity 0.8863):
[0001193125-12-096831:note_history:60]
As of January 27, 2012, the approximate fair value of the principal amount of the Notes, which includes the debt and equity components, was approximately $1,630.8 million, or 129% of the face value of the Notes, based upon quoted market information.

- changed (2012-08-30):
[0001193125-12-375807:note_history:61]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 2.7 |  |  |  | 3.5 |  |
| Total |  | $ | 10.6 |  |  | $ | 12.6 |  |
  (was, 2012-03-05, similarity 0.9812):
[0001193125-12-096831:note_history:61]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
| Total |  | $ | 14.7 |  |  | $ | 11.5 |  |

- removed (2012-08-30):
[0001193125-12-096831:note_history:62]
Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for the Notes for at least 20 trading days during the 30 consecutive trading days ended December 31, 2011. Accordingly, as of January 27, 2012, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is reflected as equity on our condensed consolidated balance sheet as of that date.

- removed (2012-08-30):
[0001193125-12-096831:note_history:63]
Our common stock price exceeded the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended March 31, 2011. Accordingly, as of April 29, 2011, the Notes were convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as short-term debt. Since the Notes were convertible at the option of the holder and the principal amount would have been required to be paid in cash, the difference between the principal amount and the carrying value of the Notes was reflected as convertible debt in mezzanine on our condensed consolidated balance sheet as of April 29, 2011.

- removed (2012-08-30):
[0001193125-12-096831:note_history:64]
As of January 27, 2012, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of $31.85.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2012-08-30):
[0001193125-12-375807:note_history:65]
The following presents the amounts due under other long-term
financing arrangements (in millions):

- added (2012-08-30):
[0001193125-12-375807:note_history:66]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 2.7 |  |  |  | 3.5 |  |
| Total |  | $ | 10.6 |  |  | $ | 12.6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-08-30):
[0001193125-12-375807:note_history:67]
The following table reflects the carrying value of the Notes
(in millions):

- changed (2012-08-30):
[0001193125-12-375807:note_history:68]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (49.1 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,215.8 |  |  | $ | 1,202.3 |  |
  (was, 2012-03-05, similarity 0.9069):
[0001193125-12-096831:note_history:68]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (76.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,188.8 |  |  | $ | 1,150.4 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2012-08-30):
[0001193125-12-096831:note_history:69]
Revenue Recognition

- removed (2012-08-30):
[0001193125-12-096831:note_history:70]
In October 2009, the Financial Accounting Standards Board (FASB) amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

- removed (2012-08-30):
[0001193125-12-096831:note_history:71]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

- removed (2012-08-30):
[0001193125-12-096831:note_history:72]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

- removed (2012-08-30):
[0001193125-12-096831:note_history:73]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

- removed (2012-08-30):
[0001193125-12-096831:note_history:74]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010. Previously reported quarterly results have been adjusted to reflect the adoption of these standards and differ from the originally reported results.

- removed (2012-08-30):
[0001193125-12-096831:note_history:75]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

- removed (2012-08-30):
[0001193125-12-096831:note_history:76]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.

- removed (2012-08-30):
[0001193125-12-096831:note_history:77]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

- removed (2012-08-30):
[0001193125-12-096831:note_history:78]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

- removed (2012-08-30):
[0001193125-12-096831:note_history:79]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

- removed (2012-08-30):
[0001193125-12-096831:note_history:80]
When VSOE cannot be established, we attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

- removed (2012-08-30):
[0001193125-12-096831:note_history:81]
When we are unable to establish the selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- removed (2012-08-30):
[0001193125-12-096831:note_history:82]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

- removed (2012-08-30):
[0001193125-12-096831:note_history:83]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.
