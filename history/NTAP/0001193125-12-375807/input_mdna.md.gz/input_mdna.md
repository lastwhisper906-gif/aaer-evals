# NTAP MD&A — 0001193125-12-375807


## mdna

[0001193125-12-375807:mdna:1]
Item 2.  Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001193125-12-375807:mdna:2]
Forward-Looking Statements

[0001193125-12-375807:mdna:3]
[same as prior period, unchanged from 0001193125-12-096831:mdna:2]

[0001193125-12-375807:mdna:4]
[same as prior period, unchanged from 0001193125-12-096831:mdna:3]

[0001193125-12-375807:mdna:5]
[same as prior period, unchanged from 0001193125-12-096831:mdna:4]

[0001193125-12-375807:mdna:6]
[same as prior period, unchanged from 0001193125-12-096831:mdna:5]

[0001193125-12-375807:mdna:7]
[same as prior period, unchanged from 0001193125-12-096831:mdna:6]

[0001193125-12-375807:mdna:8]
|  | • |  | acquisitions and joint ventures, growth opportunities, investments and legal proceedings; |

[0001193125-12-375807:mdna:9]
[same as prior period, unchanged from 0001193125-12-096831:mdna:8]

[0001193125-12-375807:mdna:10]
[same as prior period, unchanged from 0001193125-12-096831:mdna:9]

[0001193125-12-375807:mdna:11]
[same as prior period, unchanged from 0001193125-12-096831:mdna:10]

[0001193125-12-375807:mdna:12]
[same as prior period, unchanged from 0001193125-12-096831:mdna:11]

[0001193125-12-375807:mdna:13]
|  | • |  | the dilutive effect of our 1.75% Convertible Senior Notes due June 2013 (the Notes) and associated warrants on our earnings per share; |

[0001193125-12-375807:mdna:14]
[same as prior period, unchanged from 0001193125-12-096831:mdna:13]

[0001193125-12-375807:mdna:15]
|  | • |  | compliance with laws, regulations and debt covenants; and |

[0001193125-12-375807:mdna:16]
|  | • |  | the continuation of our stock repurchase program |

[0001193125-12-375807:mdna:17]
[same as prior period, unchanged from 0001193125-12-096831:mdna:17]

[0001193125-12-375807:mdna:18]
[same as prior period, unchanged from 0001193125-12-096831:mdna:18]

[0001193125-12-375807:mdna:19]
|  | • |  | general economic and market conditions, particularly the continuing fiscal challenges in the United States and the Eurozone; |

[0001193125-12-375807:mdna:20]
[same as prior period, unchanged from 0001193125-12-096831:mdna:21]

[0001193125-12-375807:mdna:21]
[same as prior period, unchanged from 0001193125-12-096831:mdna:22]

[0001193125-12-375807:mdna:22]
[same as prior period, unchanged from 0001193125-12-096831:mdna:23]

[0001193125-12-375807:mdna:23]
[same as prior period, unchanged from 0001193125-12-096831:mdna:25]

[0001193125-12-375807:mdna:24]
|  | • |  | our ability to successfully execute on our strategies; |

[0001193125-12-375807:mdna:25]
[same as prior period, unchanged from 0001193125-12-096831:mdna:27]

[0001193125-12-375807:mdna:26]
[same as prior period, unchanged from 0001193125-12-096831:mdna:28]

[0001193125-12-375807:mdna:27]
[same as prior period, unchanged from 0001193125-12-096831:mdna:29]

[0001193125-12-375807:mdna:28]
[same as prior period, unchanged from 0001193125-12-096831:mdna:30]

[0001193125-12-375807:mdna:29]
[same as prior period, unchanged from 0001193125-12-096831:mdna:31]

[0001193125-12-375807:mdna:30]
[same as prior period, unchanged from 0001193125-12-096831:mdna:32]

[0001193125-12-375807:mdna:31]
[same as prior period, unchanged from 0001193125-12-096831:mdna:33]

[0001193125-12-375807:mdna:32]
[same as prior period, unchanged from 0001193125-12-096831:mdna:34]

[0001193125-12-375807:mdna:33]
[same as prior period, unchanged from 0001193125-12-096831:mdna:35]

[0001193125-12-375807:mdna:34]
[same as prior period, unchanged from 0001193125-12-096831:mdna:36]

[0001193125-12-375807:mdna:35]
[same as prior period, unchanged from 0001193125-12-096831:mdna:37]

[0001193125-12-375807:mdna:36]
[same as prior period, unchanged from 0001193125-12-096831:mdna:38]

[0001193125-12-375807:mdna:37]
[same as prior period, unchanged from 0001193125-12-096831:mdna:39]

[0001193125-12-375807:mdna:38]
[same as prior period, unchanged from 0001193125-12-096831:mdna:40]

[0001193125-12-375807:mdna:39]
[same as prior period, unchanged from 0001193125-12-096831:mdna:41]

[0001193125-12-375807:mdna:40]
[same as prior period, unchanged from 0001193125-12-096831:mdna:42]

[0001193125-12-375807:mdna:41]
[same as prior period, unchanged from 0001193125-12-096831:mdna:43]

[0001193125-12-375807:mdna:42]
|  | • |  | the results of our ongoing litigation, tax audits, government audits, inquiries and investigations; and |

[0001193125-12-375807:mdna:43]
[same as prior period, unchanged from 0001193125-12-096831:mdna:45]

[0001193125-12-375807:mdna:44]
Readers are cautioned not to place undue reliance on these forward-looking statements, which speak only as of the date
hereof and are based upon information available to us at this time. These statements are not guarantees of future performance. We disclaim any obligation to update information in any forward-looking statement. Actual results could vary from our
forward-looking statements due to foregoing factors as well as other important factors, including those described in the Risk Factors included in Part II Item 1A.

[0001193125-12-375807:mdna:45]
[same as prior period, unchanged from 0001193125-12-096831:mdna:52]

[0001193125-12-375807:mdna:46]
Our
discussion and analysis of financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of
America. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting periods and the reported amounts of assets, liabilities and equity as of the
date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate under the circumstances. However, future results may vary from our estimates.

[0001193125-12-375807:mdna:47]
23

[0001193125-12-375807:mdna:48]
We believe the accounting policies discussed under Item 7,
“Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended April 27, 2012 are significantly affected by critical accounting estimates and
that they are both highly important to the portrayal of our financial condition and results of operations and require difficult management judgments and assumptions about matters that are inherently uncertain. There have been no material changes to
the critical accounting policies and estimates as filed in such report.

[0001193125-12-375807:mdna:49]
[same as prior period, unchanged from 0001193125-12-096831:mdna:55]

[0001193125-12-375807:mdna:50]
See Note 3 of the accompanying condensed consolidated financial statements for a full description of new accounting
pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001193125-12-375807:mdna:51]
[same as prior period, unchanged from 0001193125-12-096831:mdna:58]

[0001193125-12-375807:mdna:52]
[same as prior period, unchanged from 0001193125-12-096831:mdna:59]

[0001193125-12-375807:mdna:53]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 62.2 | % |  |  | 66.2 | % |
| Software entitlements and maintenance |  |  | 15.1 |  |  |  | 13.6 |  |
| Service |  |  | 22.7 |  |  |  | 20.2 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 31.3 |  |  |  | 30.0 |  |
| Cost of software entitlements and maintenance |  |  | 0.5 |  |  |  | 0.4 |  |
| Cost of service |  |  | 9.4 |  |  |  | 8.1 |  |
| Gross profit |  |  | 58.8 |  |  |  | 61.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 33.4 |  |  |  | 31.2 |  |
| Research and development |  |  | 15.3 |  |  |  | 13.6 |  |
| General and administrative |  |  | 4.5 |  |  |  | 4.4 |  |
| Acquisition-related expense |  |  | — |  |  |  | 0.2 |  |
| Total operating expenses |  |  | 53.2 |  |  |  | 49.4 |  |
| Income from operations |  |  | 5.6 |  |  |  | 12.1 |  |
| Other expense, net |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Income before income taxes |  |  | 5.1 |  |  |  | 11.5 |  |
| Provision for income taxes |  |  | 0.7 |  |  |  | 1.9 |  |
| Net income |  |  | 4.4 | % |  |  | 9.6 | % |

[0001193125-12-375807:mdna:54]
[same as prior period, unchanged from 0001193125-12-096831:mdna:62]

[0001193125-12-375807:mdna:55]
[same as prior period, unchanged from 0001193125-12-096831:mdna:47]

[0001193125-12-375807:mdna:56]
Net revenues for the three months ended July 27, 2012 were $1,444.6 million, down $13.6 million, or 1%, compared to the prior year. The decrease in revenues was due to a decrease in product revenues,
primarily due to changes in product and customer mix and unfavorable foreign currency rates, partially offset by higher volume. The product revenue decrease was partially offset by increases in hardware maintenance contract and software entitlements
and maintenance (SEM) revenues.

[0001193125-12-375807:mdna:57]
Gross margin percentage decreased during the three months ended July 27,
2012 compared to the prior year, primarily due to changes in mix and a higher percentage of product sales derived from Original Equipment Manufacturer (OEM) revenues. In addition, gross margin was negatively impacted by unfavorable exchange rates.

[0001193125-12-375807:mdna:58]
Sales and marketing, research and development, and general and administrative expenses for the three months
ended July 27, 2012 totaled $769.9 million, up 7%, compared to the prior year. This increase was primarily due to a 13% increase in the average headcount during the three months ended July 27, 2012, compared to the prior year, partially
offset by lower compensation cost per headcount. In addition, exchange rates had a favorable impact on expenses.

[0001193125-12-375807:mdna:59]
Net
Revenues (in millions, except percentages):

[0001193125-12-375807:mdna:60]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Net revenues |  | $ | 1,444.6 |  |  | $ | 1,458.2 |  |  |  | (1 | )% |

[0001193125-12-375807:mdna:61]
Net revenues decreased by $13.6 million, or 1%, for the three months ended
July 27, 2012, compared to the prior year. The decrease in our net revenues was due to a decrease in product revenues, which comprised 62% of net revenues for the three months ended July 27, 2012, compared to 66% for the three months ended
July 29, 2011, partially offset by increases in both SEM and service revenues.

[0001193125-12-375807:mdna:62]
Sales through our
indirect channels represented 78% and 76% of net revenues for the three months ended July 27, 2012 and July 29, 2011, respectively. Included in indirect channel sales during the three months ended July 27, 2012 and July 29, 2011
is $208.9 million and $213.4 million of OEM revenue, respectively.

[0001193125-12-375807:mdna:63]
The following customers, each of which is
a distributor, accounted for 10% or more of net revenues (in millions, except percentages):

[0001193125-12-375807:mdna:64]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | % of NetRevenues |  |  | July 29,2011 |  |  | % of NetRevenues |  |
| Arrow Electronics, Inc. |  | $ | 229.5 |  |  |  | 16 | % |  | $ | 212.9 |  |  |  | 15 | % |
| Avnet, Inc. |  | $ | 198.3 |  |  |  | 14 | % |  | $ | 159.1 |  |  |  | 11 | % |

[0001193125-12-375807:mdna:65]
[same as prior period, unchanged from 0001193125-12-096831:mdna:69]

[0001193125-12-375807:mdna:66]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Product revenues |  | $ | 898.0 |  |  | $ | 965.7 |  |  |  | (7 | )% |

[0001193125-12-375807:mdna:67]
Product revenues decreased by $67.7 million, or 7%, for the three months ended
July 27, 2012 compared to the prior year. Product revenues consist of configured systems, which include bundled hardware and software products, and non-configured products, which consist primarily of add-on storage, OEM products and add-on
hardware and software products.

[0001193125-12-375807:mdna:68]
Total configured system revenues of $462.2 million decreased by $47.9
million, or 9%, during the three months ended July 27, 2012, compared to the prior year, primarily due to a decrease in the 3000 series systems, partially offset by an increase in the 2000 series systems. Configured systems unit volume
increased by 10% during the three months ended July 27, 2012, compared to the same period in the prior year. Unit volume of the 2000 series increased and unit volume of the 3000 series systems decreased, reflecting a shift in customer demand
from certain 3000 series systems to the recently introduced 2000 series systems. The average selling prices (ASPs) of total configured systems decreased during the three months ended July 27, 2012, compared to the prior year, due to a shift in
sales from higher priced 3000 series systems to lower priced 2000 series systems, as well as product mix within the various series and customer mix. In addition, ASPs decreased due to unfavorable foreign currency rates.

[0001193125-12-375807:mdna:69]
Non-configured product revenues of $435.8 million decreased $19.8 million, or 4%, during the three months ended
July 27, 2012, compared to the prior year. This decrease was primarily due to lower revenue from add-on storage. In addition, our revenues from OEM products declined 2% during the period. Non-configured product revenues were unfavorably
impacted by product and customer mix.

[0001193125-12-375807:mdna:70]
Our systems are highly configurable to respond to customer requirements
in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profit performance. Pricing changes, discounting practices, product
competition, foreign currency, unit volumes, customer mix, natural disasters and product material costs can also impact revenues, cost of revenues and/or gross profit performance. Disks are a significant component of our storage systems. Industry
disk pricing has fallen every year; however, when supplies are constrained, disk prices may increase. To the extent that disk prices increase or decrease, we intend to pass along those price increases or decreases to our customers while working to
maintain relatively constant profit margins on our disk drives. As our sales price per terabyte continues to decline, improved system performance, increased capacity and software to manage this increased capacity have an offsetting impact on product
revenues.

[0001193125-12-375807:mdna:71]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-12-375807:mdna:72]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 218.5 |  |  | $ | 198.2 |  |  |  | 10 | % |

[0001193125-12-375807:mdna:73]
25

[0001193125-12-375807:mdna:74]
SEM revenues increased by $20.3 million, or 10%, during the three months
ended July 27, 2012 compared to the prior year. This increase was due to an increase in the aggregate contract value of the installed base under SEM contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001193125-12-375807:mdna:75]
Service Revenues (in millions, except percentages):

[0001193125-12-375807:mdna:76]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Service revenues |  | $ | 328.1 |  |  | $ | 294.3 |  |  |  | 11 | % |

[0001193125-12-375807:mdna:77]
Service revenues include hardware maintenance, professional services and educational and
training services. Service revenues increased by $33.8 million, or 11%, during the three months ended July 27, 2012 compared to the prior year.

[0001193125-12-375807:mdna:78]
Hardware maintenance contract revenues constituted approximately 71% and 70% of our service revenues for the three months ended July 27, 2012 and July 29, 2011, respectively. Such revenues
increased $29.6 million, or 14%, during the three months ended July 27, 2012 compared to the prior year, as a result of an increase in the installed base under service contracts. Professional services and educational and training services
constituted approximately 29% and 30% of our service revenues for the three months ended July 27, 2012 and July 29, 2011, respectively.

[0001193125-12-375807:mdna:79]
[same as prior period, unchanged from 0001193125-12-096831:mdna:82]

[0001193125-12-375807:mdna:80]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 801.1 |  |  | $ | 813.4 |  |  |  | (2 | )% |
| Europe, Middle East and Africa (EMEA) |  |  | 439.3 |  |  |  | 456.7 |  |  |  | (4 | )% |
| Asia Pacific and Japan (APAC) |  |  | 204.2 |  |  |  | 188.1 |  |  |  | 9 | % |
| Net revenues |  | $ | 1,444.6 |  |  | $ | 1,458.2 |  |  |  |  |  |

[0001193125-12-375807:mdna:81]
Americas revenues consist of Americas commercial and U.S. public sector markets.

[0001193125-12-375807:mdna:82]
Sales to customers inside the United States comprised 89% and 85% of America’s net revenues during the
three months ended July 27, 2012 and July 29, 2011, respectively. EMEA revenues were negatively impacted by the general macroeconomic conditions in the region, as well as unfavorable foreign currency rates. Sales to Germany accounted for
10% of net revenues during each of the three months ended July 27, 2012 and July 29, 2011. No other single foreign country accounted for 10% or more of net revenues in any of the periods presented.

[0001193125-12-375807:mdna:83]
[same as prior period, unchanged from 0001193125-12-096831:mdna:85]

[0001193125-12-375807:mdna:84]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping of our storage products, amortization of purchased intangible
assets, inventory write-downs, and warranty costs; (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs and (3) cost of service revenues, which reflects costs associated with providing support activities
for hardware, global support partnership programs, professional services and educational and training services.

[0001193125-12-375807:mdna:85]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency,
product configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing
of support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our
gross profit could decline.

[0001193125-12-375807:mdna:86]
[same as prior period, unchanged from 0001193125-12-096831:mdna:88]

[0001193125-12-375807:mdna:87]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Cost of product revenues |  | $ | 452.2 |  |  | $ | 437.4 |  |  |  | 3 | % |

[0001193125-12-375807:mdna:88]
Cost of product revenues increased by $14.8 million, or 3%, during the three months ended
July 27, 2012, compared to the prior year. The changes were comprised of the following elements (in percentage points of the total change):

[0001193125-12-375807:mdna:89]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Materials cost |  |  | — |  |
| Warranty |  |  | 3 |  |
| Excess and obsolete inventory |  |  | 2 |  |
| Other |  |  | (2 | ) |
| Total change |  |  | 3 |  |

[0001193125-12-375807:mdna:90]
Material costs represent 81% and 83% of product costs for the three months ended
July 27, 2012 and July 29, 2011, respectively, and increased only $1.5 million from the prior period primarily due to a 10% unit volume increase in configured systems that was offset by unit material cost reductions reflecting a change in
mix towards lower cost 2000 series systems and OEM products. Other product costs of sales included a $12.1 million increase in hardware related warranty expense and a $7.0 million increase in inventory write-downs.

[0001193125-12-375807:mdna:91]
Cost of product revenues represented 50% of product revenue for the three months ended July 27, 2012 compared to 45%
in the prior year.

[0001193125-12-375807:mdna:92]
Cost of Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-12-375807:mdna:93]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 6.6 |  |  | $ | 5.3 |  |  |  | 25 | % |

[0001193125-12-375807:mdna:94]
Cost of SEM revenues increased by $1.3 million, or 25%, during the three months ended
July 27, 2012 compared to the prior year, primarily due to an increase in volume-related software support costs. Cost of SEM revenues represented 3% of SEM revenues for each of the three months ended July 27, 2012 and July 29, 2011.

[0001193125-12-375807:mdna:95]
[same as prior period, unchanged from 0001193125-12-096831:mdna:98]

[0001193125-12-375807:mdna:96]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Cost of service revenues |  | $ | 135.7 |  |  | $ | 118.6 |  |  |  | 14 | % |

[0001193125-12-375807:mdna:97]
Cost of service revenues increased by $17.1 million, or 14%, during the three months
ended July 27, 2012 compared to the prior year primarily due to an increase in service delivery and logistics costs. Costs represented 41% and 40% of service revenues for the three months ended July 27, 2012 and July 29, 2011,
respectively.

[0001193125-12-375807:mdna:98]
[same as prior period, unchanged from 0001193125-12-096831:mdna:101]

[0001193125-12-375807:mdna:99]
[same as prior period, unchanged from 0001193125-12-096831:mdna:102]

[0001193125-12-375807:mdna:100]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation costs and
employee incentive compensation plan costs. Compensation costs included in operating expenses increased approximately $39.7 million, or 10%, for the three months ended July 27, 2012 compared to the prior year, primarily due to:

[0001193125-12-375807:mdna:101]
(i) an increase in salaries, benefits and other compensation-related costs of $13.7 million due to an increase in average
headcount;

[0001193125-12-375807:mdna:102]
(ii) an increase in stock-based compensation of $18.6 million, which
includes $12.8 million of expense related to the reset of the employee stock purchase plan (ESPP) offering triggered by the decline in our stock price below the grant date prices of the offerings that vested in May 2012;

[0001193125-12-375807:mdna:103]
(iii) an increase in incentive compensation expense of $7.4 million reflecting increased headcount and stronger operating
performance.

[0001193125-12-375807:mdna:104]
Sales and Marketing Expenses (in millions, except percentages):

[0001193125-12-375807:mdna:105]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 482.9 |  |  | $ | 454.8 |  |  |  | 6 | % |

[0001193125-12-375807:mdna:106]
Sales and marketing expense consists primarily of compensation costs, commissions,
outside services, allocated facilities and IT costs, advertising and marketing promotional expense and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001193125-12-375807:mdna:107]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Salaries |  |  | 2 |  |
| Incentive plan compensation |  |  | 1 |  |
| Stock-based compensation |  |  | 2 |  |
| Other compensation and benefit costs |  |  | — |  |
| Total compensation costs |  |  | 5 |  |
| Outside services |  |  | (1 | ) |
| Amortization |  |  | (1 | ) |
| Facilities and IT support costs |  |  | 2 |  |
| Advertising and marketing promotional expense |  |  | 1 |  |
| Total change |  |  | 6 |  |

[0001193125-12-375807:mdna:108]
The increase in total compensation costs during the three months ended July 27, 2012
reflects a 12% increase in average sales and marketing headcount compared to the prior year and higher stock-based compensation expense. The increase in facilities and IT support costs during the three months ended July 27, 2012 reflects our
investment in sales systems and infrastructure.

[0001193125-12-375807:mdna:109]
Research and Development Expense (in millions, except percentages):

[0001193125-12-375807:mdna:110]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Research and development expenses |  | $ | 221.4 |  |  | $ | 198.6 |  |  |  | 11 | % |

[0001193125-12-375807:mdna:111]
Research and development expense consists primarily of compensation costs, allocated
facilities and IT costs, depreciation and amortization, equipment and software-related costs, prototypes, non-recurring engineering charges and other outside services costs. Research and development expense increased due to the following:

[0001193125-12-375807:mdna:112]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Salaries |  |  | 2 |  |
| Incentive plan compensation |  |  | 2 |  |
| Stock-based compensation |  |  | 4 |  |
| Other compensation and benefit costs |  |  | (1 | ) |
| Total compensation costs |  |  | 7 |  |
| Depreciation and amortization |  |  | 2 |  |
| Development projects |  |  | 3 |  |
| Other |  |  | (1 | ) |
| Total change |  |  | 11 |  |

[0001193125-12-375807:mdna:113]
The increase in total compensation costs during the three months ended
July 27, 2012 reflects a 15% increase in average engineering headcount compared to the prior year and higher stock-based compensation expense. Depreciation and amortization increased due to higher levels of investment in engineering equipment.
The increase in development project expense reflects increased spending on materials and services associated with engineering activities to develop new product lines and enhancements to existing products.

[0001193125-12-375807:mdna:114]
We believe that our future performance will depend in large part on our ability to maintain and enhance our current
product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future product development efforts, broaden
our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-12-375807:mdna:115]
General and Administrative
Expense (in millions, except percentages):

[0001193125-12-375807:mdna:116]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| General and administrative expense |  | $ | 65.6 |  |  | $ | 65.1 |  |  |  | 1 | % |

[0001193125-12-375807:mdna:117]
General and administrative expense consists primarily of compensation costs, professional
and corporate legal fees, outside services and allocated facilities and IT support costs. General and administrative expense increased due to the following:

[0001193125-12-375807:mdna:118]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Salaries |  |  | 1 |  |
| Incentive plan compensation |  |  | 2 |  |
| Stock-based compensation |  |  | 1 |  |
| Other compensation and benefit costs |  |  | 1 |  |
| Total compensation costs |  |  | 5 |  |
| Outside services |  |  | (5 | ) |
| Professional and corporate legal fees |  |  | 1 |  |
| Total change |  |  | 1 |  |

[0001193125-12-375807:mdna:119]
The increase in total compensation costs during the three months ended July 27, 2012
reflects a 9% increase in average general and administrative headcount compared to the prior year and higher stock-based compensation expense. The decrease in outside services during the three months ended July 27, 2012 reflects lower spending
on contractors and costs associated with Engenio integration activities that were completed in fiscal 2012 and various operational projects.

[0001193125-12-375807:mdna:120]
Acquisition-related Expense (in millions, except percentages):

[0001193125-12-375807:mdna:121]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Acquisition-related expense |  | $ | — |  |  | $ | 2.2 |  |  |  | (100 | )% |

[0001193125-12-375807:mdna:122]
During the three months ended July 29, 2011, we incurred due diligence and legal
costs of $0.7 million and other integration charges of $1.5 million associated with our acquisition of Engenio.

[0001193125-12-375807:mdna:123]
Other
Expense, Net

[0001193125-12-375807:mdna:124]
[same as prior period, unchanged from 0001193125-12-096831:mdna:127]

[0001193125-12-375807:mdna:125]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Interest income |  | $ | 10.8 |  |  | $ | 10.6 |  |  |  | 2 | % |

[0001193125-12-375807:mdna:126]
The increase in interest income during the three months ended July 27, 2012,
compared to the prior year, was primarily due to an increase in the investment portfolio.

[0001193125-12-375807:mdna:127]
Interest Expense (in millions, except percentages):

[0001193125-12-375807:mdna:128]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Interest expense |  | $ | (19.9 | ) |  | $ | (19.4 | ) |  |  | 3 | % |

[0001193125-12-375807:mdna:129]
Interest expense was relatively flat for the three months ended July 27, 2012
compared to the prior year.

[0001193125-12-375807:mdna:130]
During the three months ended July 27, 2012 and July 29, 2011, we
recognized non-cash interest expense from the amortization of debt discount and issuance costs related to our Notes, net of capitalized interest, of $14.3 million and $13.7 million, respectively. The coupon interest expense related to our Notes, net
of capitalized interest, was $5.4 million and $5.5 million during the three months ended July 27, 2012 and July 29, 2011, respectively.

[0001193125-12-375807:mdna:131]
Other Income (Expense), Net (in millions, except percentages):

[0001193125-12-375807:mdna:132]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Other income (expense), net |  | $ | 3.1 |  |  | $ | (0.3 | ) |  |  | NM |  |

[0001193125-12-375807:mdna:133]
NM - Not Meaningful

[0001193125-12-375807:mdna:134]
Other income (expense), net, increased $3.4
million primarily due to $3.1 million of net foreign exchange gains.

[0001193125-12-375807:mdna:135]
Provision for Income Taxes (in millions, except
percentages):

[0001193125-12-375807:mdna:136]
|  |  | Three Months Ended |  |
|  |  | July 27,2012 |  |  | July 29,2011 |  |  | % Change |  |
| Provision for income taxes |  | $ | 10.4 |  |  | $ | 27.6 |  |  |  | (62 | )% |

[0001193125-12-375807:mdna:137]
Our effective tax rate for the three months ended July 27, 2012 was 14.0% compared
to an effective tax rate of 16.5% for the three months ended July 29, 2011. Our effective tax rates for the three months ended July 27, 2012 and July 29, 2011 differ from the U.S. statutory rate of 35% because our foreign earnings are
taxed at rates lower than the U.S. statutory rate. Our provision for income taxes and our effective tax rate decreased for the three months ended July 27, 2012 compared to the three months ended July 29, 2011 as a result of lower pre-tax
income, primarily in the U.S.

[0001193125-12-375807:mdna:138]
As of July 27, 2012, we had $162.8 million of unrecognized tax benefits,
of which $107.5 million has been recorded in other long-term liabilities and of which $96.0 million, including penalties and interest, would affect our provision for income taxes if recognized.

[0001193125-12-375807:mdna:139]
[same as prior period, unchanged from 0001193125-12-096831:mdna:137]

[0001193125-12-375807:mdna:140]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and capital resources. The principal objectives of our investment policy
are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors
closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 27,
2012.

[0001193125-12-375807:mdna:141]
[same as prior period, unchanged from 0001193125-12-096831:mdna:139]

[0001193125-12-375807:mdna:142]
Our principal sources of liquidity as of July 27, 2012 consisted of approximately $5.4 billion in cash, cash
equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001193125-12-375807:mdna:143]
Cash, cash
equivalents and short-term investments consist of the following (in millions):

[0001193125-12-375807:mdna:144]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Cash and cash equivalents |  | $ | 1,529.4 |  |  | $ | 1,549.8 |  |
| Short-term investments |  |  | 3,911.7 |  |  |  | 3,848.7 |  |
| Total |  | $ | 5,441.1 |  |  | $ | 5,398.5 |  |

[0001193125-12-375807:mdna:145]
As of July 27, 2012, $2.5 billion of cash, cash equivalents and
short-term investments were held in the United States, while $2.9 billion were held in foreign countries. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S.
federal and state income taxes. If we were to repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state net operating loss
and tax credit carry forwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity
requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal
payments on our debt. Our contractual obligations as of July 27, 2012 are summarized below in the Contractual Obligations table.

[0001193125-12-375807:mdna:146]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and
inventories, our ability to effectively integrate acquired products, businesses and technologies and conversions of our Notes by holders. Based on our current business outlook, we believe that our sources of cash will satisfy our working capital
needs, capital expenditures, investment requirements, stock repurchases, contractual obligations, commitments, principal and interest payments on our Notes and other liquidity requirements associated with operations and meet our cash requirements
for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to
generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-12-375807:mdna:147]
Our investment portfolio, including auction rate securities, has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current
economic and market events to minimize our market risk on our investment portfolio. Based on our ability to access our cash and short-term investments, our expected operating cash flows, and our other potential sources of cash, we do not anticipate
that the lack of liquidity of these investments will impact our ability to fund working capital needs, capital expenditures, acquisitions, debt obligations or other cash requirements. We intend to and believe that we have the ability to hold these
investments until the market recovers. If current market conditions deteriorate, we may be required to record additional charges to earnings in future periods. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers
and counterparties. Our gross exposures to our investments in Greece, Italy, Portugal, and Spain are individually and collectively not material.

[0001193125-12-375807:mdna:148]
Debt Conversion and Redemption Requirements

[0001193125-12-375807:mdna:149]
Our
Notes, which have a principal amount of $1.265 billion, become unconditionally convertible at the option of the holders of the Notes on March 1, 2013 and mature on June 1, 2013 unless earlier repurchased or converted (see Note 9 of the
accompanying condensed consolidated financial statements). Our common stock price did not exceed the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended June 30, 2012, and accordingly, as
of July 27, 2012 the Notes were not convertible at the option of the holder. Upon conversion of our Notes, we will deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal
amount of the Notes, shares of our common stock.

[0001193125-12-375807:mdna:150]
[same as prior period, unchanged from 0001193125-12-096831:mdna:146]

[0001193125-12-375807:mdna:151]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases
and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will
depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing
facilities and those being developed in Sunnyvale, California; Research Triangle Park, North Carolina; India and other locations worldwide are adequate for our requirements over at least the next two years and that additional space will be available
as needed. Our capital expenditures were $61.9 million during the three months ended July 27, 2012. We anticipate capital expenditures for the remainder of fiscal 2013 to be between $200.0 million and $250.0 million, including $69.6 million for
the anticipated buyout of our properties subject to synthetic leases.

[0001193125-12-375807:mdna:152]
Share Repurchase

[0001193125-12-375807:mdna:153]
As of July 27, 2012, our Board of Directors had authorized the repurchase of up to $4.0 billion of our common stock
under our stock repurchase program. As of July 27, 2012, the remaining authorized amount for stock repurchases under our stock repurchase program was $0.3 billion with no termination date. The stock repurchase program may be suspended or
discontinued at any time.

[0001193125-12-375807:mdna:154]
[same as prior period, unchanged from 0001193125-12-096831:mdna:150]

[0001193125-12-375807:mdna:155]
As of July 27, 2012, our cash, cash equivalents and short-term and long-term investments increased by
$37.9 million from April 27, 2012, to $5.5 billion. The increase was primarily a result of $229.2 million of cash provided by operating activities and $35.0 million from issuances of common stock under employee equity award plans,
partially offset by $150.0 million in cash paid for the repurchase of common stock and $61.9 million in capital expenditures. We derive our liquidity and capital resources primarily from our operating cash flows and from working capital. Accounts
receivable days sales outstanding as of July 27, 2012 decreased to 37 days, compared to 44 days as of April 27, 2012, primarily due to improvements in shipment linearity and faster collections. Working capital decreased by
$25.8 million to $3.3 billion as of July 27, 2012, primarily due to a decrease in accounts receivable, partially offset by a decrease in accrued compensation and related benefits.

[0001193125-12-375807:mdna:156]
[same as prior period, unchanged from 0001193125-12-096831:mdna:152]

[0001193125-12-375807:mdna:157]
During the three months ended July 27, 2012, we generated cash from operating activities of $229.2 million. The primary sources of cash from operating activities during the three months ended
July 27, 2012 consisted of net income of $63.8 million, adjusted by depreciation and amortization of $82.4 million and stock-based compensation of $79.2 million. Significant changes in assets and liabilities impacting operating cash
flows included a decrease in accounts receivable of $244.2 million and a decrease in accrued compensation and related benefits of $123.1 million primarily attributable to employee payouts related to the fiscal year 2012 commissions and
incentive compensation plans.

[0001193125-12-375807:mdna:158]
We expect that cash provided by operating activities may fluctuate in future
periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based
compensation, and the timing and amount of compensation and other payments.

[0001193125-12-375807:mdna:159]
[same as prior period, unchanged from 0001193125-12-096831:mdna:155]

[0001193125-12-375807:mdna:160]
During the three months ended July 27, 2012, we purchased $66.1 million of investments, net of
redemptions, and paid $61.9 million for capital expenditures.

[0001193125-12-375807:mdna:161]
[same as prior period, unchanged from 0001193125-12-096831:mdna:157]

[0001193125-12-375807:mdna:162]
During the three months ended July 27, 2012, we used $112.1 million in financing activities, which consisted of
$150.0 million for the repurchase of 4.9 million shares of common stock at an average price of $30.31 per share and we generated $35.0 million from the issuance of common stock under our employee equity award programs.

[0001193125-12-375807:mdna:163]
[same as prior period, unchanged from 0001193125-12-096831:mdna:168]

[0001193125-12-375807:mdna:164]
The following table summarizes our contractual obligations as of July 27, 2012 and the effect such obligations are expected to have on our liquidity and cash flows in future periods (in millions):

[0001193125-12-375807:mdna:165]
|  |  | Remainderof2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 26.5 |  |  | $ | 40.0 |  |  | $ | 39.9 |  |  | $ | 34.4 |  |  | $ | 19.7 |  |  | $ | 53.8 |  |  | $ | 214.3 |  |
| Real estate lease payments(1) |  |  | 60.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 60.2 |  |
| Less: sublease income |  |  | (1.6 | ) |  |  | (1.5 | ) |  |  | (1.4 | ) |  |  | (1.0 | ) |  |  | — |  |  |  | — |  |  |  | (5.5 | ) |
| Equipment operating lease payments |  |  | 19.0 |  |  |  | 18.6 |  |  |  | 9.3 |  |  |  | 3.7 |  |  |  | 0.6 |  |  |  | — |  |  |  | 51.2 |  |
| Purchase commitments with contract manufacturers(2) |  |  | 279.6 |  |  |  | 1.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 281.0 |  |
| Capital expenditures |  |  | 26.4 |  |  |  | 1.0 |  |  |  | 19.0 |  |  |  | 3.9 |  |  |  | — |  |  |  | — |  |  |  | 50.3 |  |
| Other purchase obligations(3) |  |  | 107.3 |  |  |  | 38.6 |  |  |  | 25.7 |  |  |  | 15.5 |  |  |  | 12.0 |  |  |  | 1.5 |  |  |  | 200.6 |  |
| Total off balance-sheet commitments |  |  | 517.4 |  |  |  | 97.9 |  |  |  | 92.7 |  |  |  | 56.5 |  |  |  | 32.3 |  |  |  | 55.3 |  |  |  | 852.1 |  |
| 1.75% Convertible Notes(4) |  |  | 1,275.9 |  |  |  | 11.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,287.0 |  |
| Long-term financing arrangements |  |  | 8.4 |  |  |  | 4.6 |  |  |  | 2.0 |  |  |  | 1.5 |  |  |  | 0.7 |  |  |  | — |  |  |  | 17.2 |  |
| Uncertain tax positions(5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 109.7 |  |
| Total |  | $ | 1,801.7 |  |  | $ | 113.6 |  |  | $ | 94.7 |  |  | $ | 58.0 |  |  | $ | 33.0 |  |  | $ | 55.3 |  |  | $ | 2,266.0 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 9.7 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 1.7 |  |  | $ | 1.0 |  |  | $ | 13.1 |  |

[0001193125-12-375807:mdna:166]
| (1) | Included in real estate lease payments pursuant to three financing arrangements with BNP Paribas LLC (BNPPLC) are (i) lease commitments of $1.1 million, which are based on a fixed rate for terms of five years and (ii) at the expiration or termination of the leasing arrangements, a supplemental payment obligation equal to our minimum guarantee of $59.1 million in the event that we elect not to purchase or arrange for sale of the buildings. |

[0001193125-12-375807:mdna:167]
| (2) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. As of July 27, 2012, we recorded accruals of $7.2 million for firm, non-cancelable purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. |

[0001193125-12-375807:mdna:168]
[same as prior period, unchanged from 0001193125-12-096831:mdna:173]

[0001193125-12-375807:mdna:169]
| (4) | Included in these amounts are obligations related to the $1.265 billion principal amount of our Notes (see Note 9 of the accompanying condensed consolidated financial statements). Estimated interest payments for the Notes are $11.0 million and $11.1 million for the remainder of fiscal 2013 and fiscal 2014, respectively. |

[0001193125-12-375807:mdna:170]
| (5) | As of July 27, 2012, our liability for uncertain tax positions was $109.7 million, including interest and penalties, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-12-375807:mdna:171]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by
management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table. We expect to fund our contractual obligations and other commitments in
the table above through existing cash, cash equivalents, investments, and cash generated from operations or obtain additional financing, if necessary.

[0001193125-12-375807:mdna:172]
As of July 27, 2012, we have three leasing arrangements with BNPPLC, one of which requires us to lease certain of our land to BNPPLC for a period of 99 years and all of which require us to
lease approximately 0.3 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an aggregate original cost of $69.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease
payments, which vary based on a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two
consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain
conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC’s cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or
all buildings by BNPPLC during the ensuing two-year period. The following table summarizes the aggregate cost, the aggregate residual guarantee, the applicable fixed rates at July 27, 2012 and the lease commencement dates for our leasing
arrangements:

[0001193125-12-375807:mdna:173]
| Cost |  |  | ResidualGuarantee |  |  | Fixed Rates |  | Lease Commencement Dates |  | Term |
| $ | 69.6 million |  |  | $ | 59.1 million |  |  | 3.67% - 3.69% |  | December 2007 - January 2008 |  | 5 years |

[0001193125-12-375807:mdna:174]
These leasing arrangements require us to maintain specified financial covenants with
which we were in compliance as of July 27, 2012. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than 3:1 and a minimum amount of Unencumbered Cash and
Short-Term Investments of $300.0 million. Our failure to comply with these financial covenants could result in a default under the leases, which, subject to our right and ability to exercise our purchase option, would give BNPPLC the right to, among
other things, (i) terminate our possession of the leased property and require us to pay lease termination damages and other amounts as set forth in the lease agreements or (ii) exercise certain foreclosure remedies.

[0001193125-12-375807:mdna:175]
33

[0001193125-12-375807:mdna:176]
Based on a recent announcement by BNPPLC that it intends to phase out of its
synthetic lease activities, we expect to exercise our option to buy out our synthetic leases when their five year terms expire in December 2012 through January 2013.

[0001193125-12-375807:mdna:177]
Legal Contingencies

[0001193125-12-375807:mdna:178]
We are subject to various
legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 to our condensed consolidated financial statements.

[0001193125-12-375807:mdna:179]
[same as prior period, unchanged from 0001193125-12-096831:mdna:188]

[0001193125-12-375807:mdna:180]
During the ordinary
course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of July 27, 2012, our financial guarantees of
$13.1 million that were not recorded on our condensed consolidated balance sheet consisted of standby letters of credit related to workers’ compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and
surety bonds, which were primarily related to self-insurance.

[0001193125-12-375807:mdna:181]
We use derivative instruments to manage
exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency. The program is not designated for trading or speculative purposes.
Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related to firm commitments or nonmarketable investments. Our major foreign currency exchange exposures and related hedging programs are described below:

[0001193125-12-375807:mdna:182]
[same as prior period, unchanged from 0001193125-12-096831:mdna:191]

[0001193125-12-375807:mdna:183]
|  | • |  | We use foreign currency forward contracts to hedge exposures related to forecasted sales denominated in certain foreign currencies. These contracts are designated as cash flow hedges and in general closely match the underlying forecasted transactions in duration. |

[0001193125-12-375807:mdna:184]
As of July 27, 2012, the notional fair value of foreign currency forward and option contracts totaled $553.2 million. We do not believe that these derivatives present significant credit risks,
because of the short term maturity of the outstanding contracts at any point in time, the counterparties to the derivatives consist of major financial institutions, and we manage the notional amount of contracts entered into with any one
counterparty. Other than the risk associated with the financial condition of the counterparties, our maximum exposure related to foreign currency forward and option contracts is limited to the premiums paid. See Note 11 of the accompanying
condensed consolidated financial statements for more information related to our hedging activities.

[0001193125-12-375807:mdna:185]
In the
ordinary course of business, some of our customers have entered into recourse and nonrecourse financing leasing arrangements using third-party leasing companies. During the terms of recourse leases, which are generally three years or less, we remain
liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. Where we provide a guarantee for recourse leases, we defer revenues in accordance with our revenue recognition
policies. As of July 27, 2012, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $161.4 million, and the related deferred revenue totaled approximately $151.3 million.

[0001193125-12-375807:mdna:186]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these
indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet
arrangements under accounting guidance.

[0001193125-12-375807:mdna:187]
We have commitments related to three leasing arrangements with BNPPLC
for approximately 0.3 million square feet of office space for our headquarters in Sunnyvale, California (as further described above under “Contractual Obligations”). Our future minimum lease payments and residual guarantees under
these real estate leases will amount to a total of $60.2 million as discussed above in “Contractual Obligations.”
