# NTAP 8-K — 0001102624-12-000677 filed 2012-08-15

## item codes, every 8-K on or before 2012-08-30

- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2012-08-30

- none on or before 2012-08-30

## item 2.02 — earnings release, exhibit 99.1

[0001102624-12-000677:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-12-000677:8k_2_02:2]
exh99_1.htm

[0001102624-12-000677:8k_2_02:3]
Exhibit 99.1

[0001102624-12-000677:8k_2_02:4]
|  | Press Contact: | Investor Contact: |
|  | Ryan Lowry | Shauna O’Boyle |
|  | NetApp | NetApp |
|  | (408) 822-7544 | (408) 822-7655 |
|  | ryanl@netapp.com | oboyle@netapp.com |

[0001102624-12-000677:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR FIRST QUARTER FISCAL YEAR 2013

[0001102624-12-000677:8k_2_02:6]
Company Reports Q1 FY’13 Revenues of $1.445 billion; Non-GAAP Earnings per Share of $0.42

[0001102624-12-000677:8k_2_02:7]
Sunnyvale, Calif.—August 15, 2012—NetApp (NASDAQ: NTAP) today reported results for the first quarter of fiscal year 2013, which ended July 27, 2012. Revenues for the first quarter of fiscal year 2013 were in line with our prior guidance and totaled $1.445 billion, compared to revenues of $1.458 billion for the same period one year ago.

[0001102624-12-000677:8k_2_02:8]
For the first quarter of fiscal year 2013, GAAP net income was $64 million, or $0.17 per share,1 compared to GAAP net income of $140 million, or $0.34 per share for the same period a year ago. Non-GAAP net income for the first quarter of fiscal year 2013 was $156 million, or $0.42 per share,2 compared to non-GAAP net income of $222 million, or $0.55 per share for the same period a year ago.

[0001102624-12-000677:8k_2_02:9]
“NetApp produced non-GAAP earnings per share above and revenue in line with our prior guidance. In Q1, we announced further innovations in Data ONTAP® 8.1 that will enable customers to achieve an agile data infrastructure environment to cope with their dynamic business requirements,” said Tom Georgens, president and CEO. “We continue to deliver on multiple fronts, advancing our technology and partnerships. With our best-of-breed partnering strategy and ongoing innovation-led solutions, we enable our customers to scale their business without limits.”

[0001102624-12-000677:8k_2_02:10]
Outlook

[0001102624-12-000677:8k_2_02:11]
NetApp’s outlook for the second quarter of fiscal year 2013 is based on current business expectations, market conditions, and continued uncertainty in the macroeconomic environment.

[0001102624-12-000677:8k_2_02:12]
| ● | NetApp estimates revenue for the second quarter of fiscal year 2013 to be in the range of $1.5 billion to $1.6 billion. |

[0001102624-12-000677:8k_2_02:13]
| ● | NetApp estimates GAAP earnings per share for the second quarter of fiscal year 2013 to be approximately $0.23 to $0.28 per share. NetApp estimates non-GAAP earnings per share for the second quarter fiscal year 2013 to be approximately $0.45 to $0.50 per share. |
| ● | NetApp estimates that the share count for the second quarter of fiscal year 2013 will decrease to approximately 370 million shares, and will include an estimated 700 thousand shares from the Company’s outstanding convertible notes.3 Share count does not include the Company’s outstanding note hedges which are expected to offset 80% of the dilution from the convertible notes at maturity or conversion. |

[0001102624-12-000677:8k_2_02:14]
Business Highlights

[0001102624-12-000677:8k_2_02:15]
Fundamental to NetApp’s growth strategy is a commitment to innovation leadership across all facets of the storage industry with a goal to help propel its customers’ and partners’ business success.

[0001102624-12-000677:8k_2_02:16]
In its first quarter of fiscal year 2013, this focus on innovation spanned across NetApp® products, solutions, technologies, and its culture. NetApp strengthened its reputation as an innovation leader with the latest offering of Data ONTAP, the #1 storage operating system. Data ONTAP provides the foundation for customers who require an agile data infrastructure to thrive in today’s always-on global economy. Additionally, NetApp unveiled innovative new products, technologies, and programs that enable further penetration into the data center, help customers of all sizes capitalize on data growth to fuel their success and help channel partners expand their businesses. NetApp also continued to strengthen its relationship with industry leaders like Cisco and Microsoft. Finally, NetApp once again was recognized around the world for its culture, which continues to provide competitive differentiation that makes NetApp a preferred company to do business with for both customers and partners.

[0001102624-12-000677:8k_2_02:17]
Highlights for the quarter include the following:

[0001102624-12-000677:8k_2_02:18]
Agile Data Infrastructure Makes IT Intelligent, Immortal, and Infinite

[0001102624-12-000677:8k_2_02:19]
| ● | NetApp, in collaboration with its partners, is transforming how customers architect and manage their data storage infrastructures differently to be more agile in order to fuel business success. With the latest release of Data ONTAP, NetApp is helping IT departments more effectively respond to changing business requirements, maintain nondisruptive operations, and grow their businesses. Data ONTAP 8.1.1 is another milestone in NetApp’s innovation agenda that is the basis for delivering new approaches to managing data for business impact. |

[0001102624-12-000677:8k_2_02:20]
Midsize Business Customers Accelerate Growth and Leverage the Cloud with NetApp

[0001102624-12-000677:8k_2_02:21]
| ● | NetApp unveiled the new FAS2220, the latest member of its entry-level product portfolio which will provide midsize customers with innovative new technologies and increased value, enabling customers to start right, keep it simple, and grow smart. The FAS2220 builds on the momentum and success of the recently introduced FAS2240. Additionally, NetApp introduced an expanding ecosystem of value-added reseller partners to provide midsize businesses with cloud backup and disaster recovery services built on NetApp solutions, along with new channel enablement programs designed to help partners grow their businesses. |

[0001102624-12-000677:8k_2_02:22]
FlexPod Momentum Continues with Premium Partner Framework

[0001102624-12-000677:8k_2_02:23]
| ● | Cisco and NetApp launched a global channel initiative to accelerate market momentum of the FlexPod converged infrastructure solution that to date has almost 1,300 customers. The new FlexPod Premium Partner Framework will reward FlexPod channel partners for investing in sales capabilities and services practices. The new framework is a testament to NetApp’s continued focus on enabling its partners’ success as it will deliver increased differentiation, streamline multi-vendor interactions, and enhance profitability. |

[0001102624-12-000677:8k_2_02:24]
Customers Gain Greater Business Value from Big Data with NetApp Solutions

[0001102624-12-000677:8k_2_02:25]
| ● | NetApp and Hortonworks announced a joint development project to make Apache Hadoop solutions more enterprise ready, helping customers simplify access to their data and gain deeper business insights to make the right decisions. NetApp also unveiled the NetApp Open Solution for Hadoop Rack, offering customers greater choice and flexibility to deploy Hadoop in the enterprise. Finally, NetApp introduced enhanced data protection and simplified management capabilities to help customers accelerate their big data innovation on the NetApp E-Series platform. |

[0001102624-12-000677:8k_2_02:26]
Awards and Milestones

[0001102624-12-000677:8k_2_02:27]
| ● | Serving customer needs earns NetApp the Microsoft Private Cloud Partner of the Year Award for 2012. NetApp is focused on delivering innovative solutions that address customer challenges and help partners fuel their businesses. This recognition from Microsoft reinforces NetApp’s long-standing commitment to storage and storage management solutions for Microsoft environments that enable organizations to reduce costs, increase agility, improve efficiency, and utilize proven platforms. |

[0001102624-12-000677:8k_2_02:28]
| ● | NetApp continues to earn recognition as a great place to work. Built on a culture of innovation committed to partner and customer success, NetApp was ranked on several different “Best Places to Work” lists around the world. Rankings included #2 in Australia, #2 in Europe, #3 in Canada, #5 in the United Kingdom, #19 in India, and several local awards within the United States. |

[0001102624-12-000677:8k_2_02:29]
| ● | NetApp positioned in Leaders quadrant. Gartner, Inc. placed NetApp in the Leaders quadrant for storage resource management and SAN management software. Gartner asserted that vendors in the Leaders quadrant “have the highest combined measures of ability to execute and completeness of vision.”4 |

[0001102624-12-000677:8k_2_02:30]
Webcast and Conference Call Information

[0001102624-12-000677:8k_2_02:31]
The NetApp first quarter of fiscal year 2013 results conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, August 15, 2012, at 2:30 p.m. Pacific Time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4:30 p.m. Pacific Time on the Web site.

[0001102624-12-000677:8k_2_02:32]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-12-000677:8k_2_02:33]
8

[0001102624-12-000677:8k_2_02:34]
About NetApp

[0001102624-12-000677:8k_2_02:35]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-12-000677:8k_2_02:36]
###

[0001102624-12-000677:8k_2_02:37]
NetApp, the NetApp logo, Go further, faster, Data ONTAP, and FlexPod are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-12-000677:8k_2_02:38]
| 1GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000677:8k_2_02:39]
| 2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000677:8k_2_02:40]
| 380% hedged on maturity or conversion of the convertible notes. |

[0001102624-12-000677:8k_2_02:41]
| 4Gartner, Inc., Magic Quadrant for Storage Resource Management and SAN Management Software, Valdis Filks, Gene Ruth, March 27, 2012. |

[0001102624-12-000677:8k_2_02:42]
NetApp Usage of Non-GAAP Financials

[0001102624-12-000677:8k_2_02:43]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-12-000677:8k_2_02:44]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-12-000677:8k_2_02:45]
10

[0001102624-12-000677:8k_2_02:46]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,441.1 |  |  | $ | 5,398.5 |  |
| Accounts receivable, net |  |  | 584.2 |  |  |  | 830.9 |  |
| Inventories |  |  | 203.7 |  |  |  | 161.5 |  |
| Other current assets |  |  | 511.8 |  |  |  | 435.6 |  |
| Total current assets |  |  | 6,740.8 |  |  |  | 6,826.5 |  |
| Property and equipment, net |  |  | 1,139.1 |  |  |  | 1,137.2 |  |
| Goodwill and other intangible assets, net |  |  | 1,119.8 |  |  |  | 1,141.2 |  |
| Other non-current assets |  |  | 406.3 |  |  |  | 427.4 |  |
| Total assets |  | $ | 9,406.0 |  |  | $ | 9,532.3 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 275.6 |  |  | $ | 233.1 |  |
| Accrued compensation and other current liabilities |  |  | 564.1 |  |  |  | 717.9 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,215.8 |  |  |  | 1,202.3 |  |
| Short-term deferred revenue |  |  | 1,404.4 |  |  |  | 1,366.5 |  |
| Total current liabilities |  |  | 3,459.9 |  |  |  | 3,519.8 |  |
| Other long-term liabilities |  |  | 207.3 |  |  |  | 206.9 |  |
| Long-term deferred revenue |  |  | 1,363.1 |  |  |  | 1,449.4 |  |
| Total liabilities |  |  | 5,030.3 |  |  |  | 5,176.1 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 62.6 |  |
| Stockholders' equity |  |  | 4,375.7 |  |  |  | 4,293.6 |  |
| Total liabilities and stockholders' equity |  | $ | 9,406.0 |  |  | $ | 9,532.3 |  |

[0001102624-12-000677:8k_2_02:47]
11

[0001102624-12-000677:8k_2_02:48]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except net income per share amounts) |
| (Unaudited) |

[0001102624-12-000677:8k_2_02:49]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Revenues: |  |  |  |  |  |  |
| Product |  | $ | 898.0 |  |  | $ | 965.7 |  |
| Software entitlements and maintenance |  |  | 218.5 |  |  |  | 198.2 |  |
| Service |  |  | 328.1 |  |  |  | 294.3 |  |
| Net revenues |  |  | 1,444.6 |  |  |  | 1,458.2 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 452.2 |  |  |  | 437.4 |  |
| Cost of software entitlements and maintenance |  |  | 6.6 |  |  |  | 5.3 |  |
| Cost of service |  |  | 135.7 |  |  |  | 118.6 |  |
| Total cost of revenues |  |  | 594.5 |  |  |  | 561.3 |  |
| Gross profit |  |  | 850.1 |  |  |  | 896.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 482.9 |  |  |  | 454.8 |  |
| Research and development |  |  | 221.4 |  |  |  | 198.6 |  |
| General and administrative |  |  | 65.6 |  |  |  | 65.1 |  |
| Acquisition-related expense |  |  | - |  |  |  | 2.2 |  |
| Total operating expenses |  |  | 769.9 |  |  |  | 720.7 |  |
| Income from operations |  |  | 80.2 |  |  |  | 176.2 |  |
| Other expense, net |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.8 |  |  |  | 10.6 |  |
| Interest expense |  |  | (19.9 | ) |  |  | (19.4 | ) |
| Other income (expense), net |  |  | 3.1 |  |  |  | (0.3 | ) |
| Total other expense, net |  |  | (6.0 | ) |  |  | (9.1 | ) |
| Income before income taxes |  |  | 74.2 |  |  |  | 167.1 |  |
| Provision for income taxes |  |  | 10.4 |  |  |  | 27.6 |  |
| Net income |  | $ | 63.8 |  |  | $ | 139.5 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.17 |  |  | $ | 0.38 |  |
| Diluted |  | $ | 0.17 |  |  | $ | 0.34 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 366.1 |  |  |  | 370.3 |  |
| Diluted |  |  | 371.2 |  |  |  | 405.5 |  |

[0001102624-12-000677:8k_2_02:50]
12

[0001102624-12-000677:8k_2_02:51]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 63.8 |  |  | $ | 139.5 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 82.4 |  |  |  | 68.5 |  |
| Stock-based compensation |  |  | 79.2 |  |  |  | 58.1 |  |
| Accretion of discount and issuance costs on notes |  |  | 14.3 |  |  |  | 13.7 |  |
| Tax benefit (charge) from stock-based compensation |  |  | (8.8 | ) |  |  | 28.7 |  |
| Excess tax benefit from stock-based compensation |  |  | (4.9 | ) |  |  | (32.1 | ) |
| Other, net |  |  | (24.0 | ) |  |  | (30.6 | ) |
| Changes in assets and liabilities, net of acquisition of business: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 244.2 |  |  |  | 145.0 |  |
| Inventories |  |  | (42.2 | ) |  |  | 6.8 |  |
| Accounts payable |  |  | 41.9 |  |  |  | 22.8 |  |
| Accrued compensation and other current liabilities |  |  | (146.7 | ) |  |  | (248.3 | ) |
| Deferred revenue |  |  | (47.0 | ) |  |  | 66.7 |  |
| Changes in other operating assets and liabilities, net |  |  | (23.0 | ) |  |  | 1.8 |  |
| Net cash provided by operating activities |  |  | 229.2 |  |  |  | 240.6 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (66.1 | ) |  |  | 245.8 |  |
| Purchases of property and equipment |  |  | (61.9 | ) |  |  | (98.3 | ) |
| Acquisition of business |  |  | - |  |  |  | (480.0 | ) |
| Other investing activities, net |  |  | 1.3 |  |  |  | 1.7 |  |
| Net cash used in investing activities |  |  | (126.7 | ) |  |  | (330.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 35.0 |  |  |  | 46.6 |  |
| Repurchase and retirement of common stock |  |  | (150.0 | ) |  |  | (200.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 4.9 |  |  |  | 32.1 |  |
| Other financing activities, net |  |  | (2.0 | ) |  |  | 0.3 |  |
| Net cash used in financing activities |  |  | (112.1 | ) |  |  | (121.0 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (10.8 | ) |  |  | (2.9 | ) |
| Net decrease in cash and cash equivalents |  |  | (20.4 | ) |  |  | (214.1 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,549.8 |  |  |  | 2,757.3 |  |
| End of period |  | $ | 1,529.4 |  |  | $ | 2,543.2 |  |

[0001102624-12-000677:8k_2_02:52]
13

[0001102624-12-000677:8k_2_02:53]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |
| NET INCOME |  | $ | 63.8 |  |  | $ | 139.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.4 |  |  |  | 24.3 |  |
| Stock-based compensation |  |  | 79.2 |  |  |  | 58.1 |  |
| Acquisition-related expense |  |  | - |  |  |  | 10.2 |  |
| Non-cash interest expense |  |  | 14.3 |  |  |  | 13.7 |  |
| Income tax effect of non-GAAP adjustments |  |  | (22.3 | ) |  |  | (23.5 | ) |
| NON-GAAP NET INCOME |  | $ | 156.4 |  |  | $ | 222.3 |  |
| NET INCOME PER SHARE |  | $ | 0.172 |  |  | $ | 0.344 |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.058 |  |  |  | 0.060 |  |
| Stock-based compensation |  |  | 0.213 |  |  |  | 0.143 |  |
| Acquisition-related expense |  |  | - |  |  |  | 0.025 |  |
| Non-cash interest expense |  |  | 0.038 |  |  |  | 0.034 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.060 | ) |  |  | (0.058 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.421 |  |  | $ | 0.548 |  |

[0001102624-12-000677:8k_2_02:54]
14

[0001102624-12-000677:8k_2_02:55]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended July 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Total |  |
| Cost of product revenues |  | $ | 14.0 |  |  | $ | 1.8 |  |  | $ | - |  |  | $ | - |  |  | $ | 15.8 |  |
| Cost of service revenues |  |  | - |  |  |  | 5.6 |  |  |  | - |  |  |  | - |  |  |  | 5.6 |  |
| Sales and marketing expenses |  |  | 7.4 |  |  |  | 39.0 |  |  |  | - |  |  |  | - |  |  |  | 46.4 |  |
| Research and development expenses |  |  | - |  |  |  | 23.7 |  |  |  | - |  |  |  | - |  |  |  | 23.7 |  |
| General and administrative expenses |  |  | - |  |  |  | 9.1 |  |  |  | - |  |  |  | - |  |  |  | 9.1 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.3 |  |  |  | 14.3 |  |
| Effect on income before income taxes |  | $ | 21.4 |  |  | $ | 79.2 |  |  | $ | - |  |  | $ | 14.3 |  |  | $ | 114.9 |  |
|  |  | Three Months Ended July 29, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Total |  |
| Cost of product revenues |  | $ | 13.9 |  |  | $ | 1.1 |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | 20.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.9 |  |  |  | - |  |  |  | - |  |  |  | 3.9 |  |
| Sales and marketing expenses |  |  | 10.3 |  |  |  | 28.6 |  |  |  | - |  |  |  | - |  |  |  | 38.9 |  |
| Research and development expenses |  |  | 0.1 |  |  |  | 16.0 |  |  |  | 2.6 |  |  |  | - |  |  |  | 18.7 |  |
| General and administrative expenses |  |  | - |  |  |  | 8.5 |  |  |  | - |  |  |  | - |  |  |  | 8.5 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 2.2 |  |  |  | - |  |  |  | 2.2 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.7 |  |  |  | 13.7 |  |
| Effect on income before income taxes |  | $ | 24.3 |  |  | $ | 58.1 |  |  | $ | 10.2 |  |  | $ | 13.7 |  |  | $ | 106.3 |  |

[0001102624-12-000677:8k_2_02:56]
15

[0001102624-12-000677:8k_2_02:57]
| NETAPP, INC. |
| RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| SECOND QUARTER 2013 |
| (Unaudited) |
|  |  | Second Quarter |  |
|  |  | 2013 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $ | 0.45 - $0.50 |  |
| Adjustments of Specific Items to |  |  |  |  |
| Net Income Per Share for the Second |  |  |  |  |
| Quarter 2013: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.06 | ) |
| Stock-based compensation expense |  |  | (0.18 | ) |
| Non-cash interest expense |  |  | (0.04 | ) |
| Income tax effect |  |  | 0.06 |  |
| Total Adjustments |  |  | (0.22 | ) |
| GAAP Guidance - Net Income Per Share |  | $ | 0.23 - $0.28 |  |

[0001102624-12-000677:8k_2_02:58]
16
