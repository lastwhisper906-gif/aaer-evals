# NTAP MD&A — 0001564590-19-003270


## mdna

[0001564590-19-003270:mdna:1]
[same as prior period, unchanged from 0001564590-18-029831:mdna:1]

[0001564590-19-003270:mdna:2]
[same as prior period, unchanged from 0001564590-18-029831:mdna:17]

[0001564590-19-003270:mdna:3]
[same as prior period, unchanged from 0001564590-18-029831:mdna:3]

[0001564590-19-003270:mdna:4]
[same as prior period, unchanged from 0001564590-18-029831:mdna:4]

[0001564590-19-003270:mdna:5]
[same as prior period, unchanged from 0001564590-18-029831:mdna:5]

[0001564590-19-003270:mdna:6]
[same as prior period, unchanged from 0001564590-18-029831:mdna:6]

[0001564590-19-003270:mdna:7]
[same as prior period, unchanged from 0001564590-18-029831:mdna:7]

[0001564590-19-003270:mdna:8]
[same as prior period, unchanged from 0001564590-18-029831:mdna:8]

[0001564590-19-003270:mdna:9]
[same as prior period, unchanged from 0001564590-18-029831:mdna:9]

[0001564590-19-003270:mdna:10]
[same as prior period, unchanged from 0001564590-18-029831:mdna:10]

[0001564590-19-003270:mdna:11]
[same as prior period, unchanged from 0001564590-18-029831:mdna:11]

[0001564590-19-003270:mdna:12]
[same as prior period, unchanged from 0001564590-18-029831:mdna:12]

[0001564590-19-003270:mdna:13]
[same as prior period, unchanged from 0001564590-18-029831:mdna:13]

[0001564590-19-003270:mdna:14]
[same as prior period, unchanged from 0001564590-18-029831:mdna:14]

[0001564590-19-003270:mdna:15]
[same as prior period, unchanged from 0001564590-18-029831:mdna:15]

[0001564590-19-003270:mdna:16]
[same as prior period, unchanged from 0001564590-18-029831:mdna:16]

[0001564590-19-003270:mdna:17]
[same as prior period, unchanged from 0001564590-18-029831:mdna:31]

[0001564590-19-003270:mdna:18]
[same as prior period, unchanged from 0001564590-18-029831:mdna:18]

[0001564590-19-003270:mdna:19]
[same as prior period, unchanged from 0001564590-18-029831:mdna:19]

[0001564590-19-003270:mdna:20]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |
| Gross profit |  | $ | 982 |  |  | $ | 956 |  |  | $ | 2,919 |  |  | $ | 2,680 |  |
| Gross profit margin percentage |  |  | 63 | % |  |  | 62 | % |  |  | 64 | % |  |  | 63 | % |
| Income from operations |  | $ | 311 |  |  | $ | 490 |  |  | $ | 851 |  |  | $ | 846 |  |
| Income from operations as a percentage of net revenues |  |  | 20 | % |  |  | 32 | % |  |  | 19 | % |  |  | 20 | % |
| Net income (loss) |  | $ | 249 |  |  | $ | (479 | ) |  | $ | 773 |  |  | $ | (174 | ) |
| Diluted net income (loss) per share |  | $ | 0.98 |  |  | $ | (1.79 | ) |  | $ | 2.94 |  |  | $ | (0.65 | ) |
| Operating cash flows |  | $ | 451 |  |  | $ | 420 |  |  | $ | 942 |  |  | $ | 984 |  |

[0001564590-19-003270:mdna:21]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,357 |  |  | $ | 3,363 |  |
| Cash conversion cycle (days) |  |  | (11 | ) |  |  | (14 | ) |

[0001564590-19-003270:mdna:22]
[same as prior period, unchanged from 0001564590-18-029831:mdna:22]

[0001564590-19-003270:mdna:23]
During the first nine months of fiscal 2019, we repurchased 22 million shares of our common stock at an average price of $74.17 per share, for an aggregate of $1,611 million. We also declared aggregate cash dividends of $1.20 per share in that period, for which we paid an aggregate of $306 million.

[0001564590-19-003270:mdna:24]
[same as prior period, unchanged from 0001564590-18-029831:mdna:24]

[0001564590-19-003270:mdna:25]
As of the beginning of fiscal 2019, we adopted the new accounting standard Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and supplementary data, as presented herein, have been restated to conform to the new rules. As illustrated in Note 5 – Revenue of the Notes to Condensed Consolidated Financial Statements, the overall impact of adoption was not significant to prior periods. However, application of the new rules to our ELAs resulted in approximately $110 million of product revenues for such arrangements in the first nine months of fiscal 2019, that are incremental to the amounts we would have recognized under the old standard. None of this incremental revenue was recorded in the third quarter of fiscal 2019. Under ASC 606, we recognize the software license fee component of our ELAs up-front, whereas under the prior rules the software license fee was recognized over the term of the ELA.

[0001564590-19-003270:mdna:26]
[same as prior period, unchanged from 0001564590-18-029831:mdna:26]

[0001564590-19-003270:mdna:27]
[same as prior period, unchanged from 0001564590-18-029831:mdna:27]

[0001564590-19-003270:mdna:28]
[same as prior period, unchanged from 0001564590-18-029831:mdna:28]

[0001564590-19-003270:mdna:29]
[same as prior period, unchanged from 0001564590-18-029831:mdna:29]

[0001564590-19-003270:mdna:30]
[same as prior period, unchanged from 0001564590-18-029831:mdna:30]

[0001564590-19-003270:mdna:31]
[same as prior period, unchanged from 0001564590-18-029831:mdna:42]

[0001564590-19-003270:mdna:32]
[same as prior period, unchanged from 0001564590-18-029831:mdna:32]

[0001564590-19-003270:mdna:33]
[same as prior period, unchanged from 0001564590-18-029831:mdna:33]

[0001564590-19-003270:mdna:34]
[same as prior period, unchanged from 0001564590-18-029831:mdna:34]

[0001564590-19-003270:mdna:35]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 62 |  | % |  | 62 |  | % |  | 60 |  | % |  | 58 |  | % |
| Software maintenance |  |  | 15 |  |  |  | 14 |  |  |  | 15 |  |  |  | 16 |  |  |
| Hardware maintenance and other services |  |  | 23 |  |  |  | 24 |  |  |  | 24 |  |  |  | 26 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 30 |  |  |  | 30 |  |  |  | 28 |  |  |  | 29 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |  | 8 |  |  |
| Gross profit |  |  | 63 |  |  |  | 62 |  |  |  | 64 |  |  |  | 63 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 26 |  |  |  | 27 |  |  |  | 27 |  |  |  | 30 |  |  |
| Research and development |  |  | 13 |  |  |  | 13 |  |  |  | 14 |  |  |  | 14 |  |  |
| General and administrative |  |  | 4 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale of properties |  |  | — |  |  |  | (14 | ) |  |  | — |  |  |  | (5 | ) |  |
| Total operating expenses |  |  | 43 |  |  |  | 30 |  |  |  | 45 |  |  |  | 43 |  |  |
| Income from operations |  |  | 20 |  |  |  | 32 |  |  |  | 19 |  |  |  | 20 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 20 |  |  |  | 33 |  |  |  | 19 |  |  |  | 20 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 64 |  |  |  | 2 |  |  |  | 24 |  |  |
| Net income (loss) |  |  | 16 |  | % |  | (31 | ) | % |  | 17 |  | % |  | (4 | ) | % |

[0001564590-19-003270:mdna:36]
[same as prior period, unchanged from 0001564590-18-029831:mdna:36]

[0001564590-19-003270:mdna:37]
[same as prior period, unchanged from 0001564590-18-029831:mdna:37]

[0001564590-19-003270:mdna:38]
[same as prior period, unchanged from 0001564590-18-029831:mdna:38]

[0001564590-19-003270:mdna:39]
Net revenues for the third quarter and first nine months of fiscal 2019 were $1,563 million and $4,554 million, respectively, reflecting an increase of $24 million, or 2%, and $279 million, or 7%, respectively, compared to the corresponding periods of the prior year, primarily reflecting higher product revenues, partially offset by the unfavorable impact of foreign exchange rate fluctuations in the third quarter.

[0001564590-19-003270:mdna:40]
Gross profit as a percentage of net revenues for the third quarter increased by half of one percentage point compared to the corresponding period in fiscal 2018, and increased one and a half percentage points in the first nine months of fiscal 2019 when compared to the corresponding period in fiscal 2018, primarily reflecting higher margins on product revenues, partially offset by an unfavorable impact of foreign exchange rate fluctuations in the third quarter. Gross profit margins on product revenues increased by almost one percentage point in the third quarter of fiscal 2019 and three percentage points in the first nine months of fiscal 2019 compared to the corresponding periods of fiscal 2018, reflecting slightly higher average selling prices (ASPs), lower average materials costs in the third quarter, and for the nine months period, higher margins on revenue recognized during the current year related to the software license components of several ELAs.

[0001564590-19-003270:mdna:41]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and the first nine months of fiscal 2019 totaled $671 million, or 43% of net revenues and $2,049 million, or 45% of net revenues, respectively, representing a decrease of one and a half percentage points and three percentage points when compared to the third quarter and the first nine months of fiscal 2018, respectively, primarily due to higher net revenues in the current year periods.

[0001564590-19-003270:mdna:42]
[same as prior period, unchanged from 0001564590-18-029831:mdna:56]

[0001564590-19-003270:mdna:43]
[same as prior period, unchanged from 0001564590-18-029831:mdna:43]

[0001564590-19-003270:mdna:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  |  | 2 | % |  | $ | 4,554 |  |  | $ | 4,275 |  |  |  | 7 | % |

[0001564590-19-003270:mdna:45]
The increase in net revenues for the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of fiscal 2018 was primarily due to an increase in product revenues of $15 million and $257 million, respectively. Product revenues as a percentage of net revenues were flat in the third quarter of fiscal 2019 compared to the third quarter of fiscal 2018, and increased two percentage points in the first nine months of fiscal 2019 compared to the corresponding period of fiscal 2018.

[0001564590-19-003270:mdna:46]
[same as prior period, unchanged from 0001564590-18-029831:mdna:46]

[0001564590-19-003270:mdna:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 22 | % |  |  | 24 | % |  |  | 22 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 19 | % |  |  | 19 | % |  |  | 20 | % |

[0001564590-19-003270:mdna:48]
[same as prior period, unchanged from 0001564590-18-029831:mdna:48]

[0001564590-19-003270:mdna:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Product revenues |  | $ | 967 |  |  | $ | 952 |  |  |  | 2 | % |  | $ | 2,755 |  |  | $ | 2,498 |  |  |  | 10 | % |

[0001564590-19-003270:mdna:50]
[same as prior period, unchanged from 0001564590-18-029831:mdna:50]

[0001564590-19-003270:mdna:51]
Product revenues from strategic solutions represented 70% of product revenues in the third quarter and first nine months of fiscal 2019, compared to 69% in the corresponding periods of the prior year. Product revenues from mature solutions represented 30% of product revenues in the third quarter and first nine months of fiscal 2019, compared to 31% in the corresponding periods of the prior year.

[0001564590-19-003270:mdna:52]
Total product revenues from strategic solutions totaled $674 million in the third quarter of fiscal 2019 reflecting a 3% increase from $657 million in the third quarter of fiscal 2018, primarily due to increased sales of All-Flash FAS products and hyper-converged infrastructure solutions, partially offset by the unfavorable impact of foreign exchange rate fluctuations. Total product revenues from strategic solutions totaled $1,935 million in the first nine months of fiscal 2019 reflecting a 12% increase from $1,721 million in the first nine months of fiscal 2018. Contributing to this increase was over $110 million of revenues from the software license component of several ELAs in the first nine months of fiscal 2019 which, under ASC 606, were recognized up-front. Comparable ELA revenues were immaterial in the first nine months of fiscal 2018. Revenues generated from the sale of optional add-on software unrelated to ELAs, All-Flash FAS products and hyperconverged infrastructure solutions also increased in the first nine months of fiscal 2019, compared to the corresponding period of the prior year.

[0001564590-19-003270:mdna:53]
Total product revenue from mature solutions totaled $293 million in the third quarter of fiscal 2019 reflecting a 1% decrease from $295 million in the third quarter of fiscal 2018. Total product revenue from mature solutions totaled $820 million in the first nine months of fiscal 2019 reflecting a 6% increase from $777 million in the first nine months of fiscal 2018. Add-On hardware, storage & related OS software revenues increased by 4% and 8% in the third quarter and first nine months of fiscal 2019, respectively, compared to the corresponding periods of the prior year. These increases were partially offset by our discontinuation of the 7-mode systems in the first quarter of fiscal 2019, reflecting the movement of customers to our newer products.

[0001564590-19-003270:mdna:54]
[same as prior period, unchanged from 0001564590-18-029831:mdna:54]

[0001564590-19-003270:mdna:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 239 |  |  | $ | 221 |  |  |  | 8 | % |  | $ | 704 |  |  | $ | 668 |  |  |  | 5 | % |

[0001564590-19-003270:mdna:56]
[same as prior period, unchanged from 0001564590-18-029831:mdna:74]

[0001564590-19-003270:mdna:57]
[same as prior period, unchanged from 0001564590-18-029831:mdna:57]

[0001564590-19-003270:mdna:58]
[same as prior period, unchanged from 0001564590-18-029831:mdna:58]

[0001564590-19-003270:mdna:59]
[same as prior period, unchanged from 0001564590-18-029831:mdna:59]

[0001564590-19-003270:mdna:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 357 |  |  | $ | 366 |  |  |  | (2 | )% |  | $ | 1,095 |  |  | $ | 1,109 |  |  |  | (1 | )% |

[0001564590-19-003270:mdna:61]
[same as prior period, unchanged from 0001564590-18-029831:mdna:61]

[0001564590-19-003270:mdna:62]
Hardware maintenance contract revenues decreased slightly year over year, at $292 million and $898 million, respectively, for the third quarter and first nine months of fiscal 2019, compared to $300 million and $904 million, respectively, for the corresponding periods of the prior year.

[0001564590-19-003270:mdna:63]
Professional services and educational and training services revenues were $65 million and $197 million, respectively, for the third quarter and first nine months of fiscal 2019, compared to $66 million and $205 million, respectively, for the corresponding periods of the prior year.

[0001564590-19-003270:mdna:64]
[same as prior period, unchanged from 0001564590-18-029831:mdna:64]

[0001564590-19-003270:mdna:65]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| United States, Canada and Latin America (Americas) |  |  | 52 | % |  |  | 53 | % |  |  | 55 | % |  |  | 54 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 33 | % |  |  | 33 | % |  |  | 30 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |

[0001564590-19-003270:mdna:66]
[same as prior period, unchanged from 0001564590-18-029831:mdna:66]

[0001564590-19-003270:mdna:67]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of fiscal 2018. During the third quarter of fiscal 2019, Americas revenues were negatively impacted by general macroeconomic conditions in the region.

[0001564590-19-003270:mdna:68]
[same as prior period, unchanged from 0001564590-18-029831:mdna:68]

[0001564590-19-003270:mdna:69]
[same as prior period, unchanged from 0001564590-18-029831:mdna:69]

[0001564590-19-003270:mdna:70]
[same as prior period, unchanged from 0001564590-18-029831:mdna:70]

[0001564590-19-003270:mdna:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Cost of product revenues |  | $ | 469 |  |  | $ | 469 |  |  |  | — | % |  | $ | 1,295 |  |  | $ | 1,242 |  |  |  | 4 | % |

[0001564590-19-003270:mdna:72]
[same as prior period, unchanged from 0001564590-18-029831:mdna:72]

[0001564590-19-003270:mdna:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (2 | ) |  |  | 3 |  |
| Excess and obsolete inventory |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | — |  |  |  | 4 |  |

[0001564590-19-003270:mdna:74]
32

[0001564590-19-003270:mdna:75]
Cost of product revenues represented 49% and 47% of product revenues for the third quarter and first nine months of fiscal 2019, respectively, compared to 49% and 50% for the corresponding periods of fiscal 2018. Materials costs represented 90% of product costs for the third quarter and first nine months of fiscal 2019, compared to 91% and 90% in the corresponding periods of fiscal 2018.

[0001564590-19-003270:mdna:76]
Materials costs decreased $8 million in the third quarter of fiscal 2019, compared to the corresponding period of the prior year, primarily due to a decline in the price of certain product components. Materials costs increased $39 million in the first nine months of fiscal 2019, compared to the corresponding period of the prior year, primarily due to higher unit volumes of certain products.

[0001564590-19-003270:mdna:77]
The average unit materials costs of Clustered ONTAP systems decreased slightly in the third quarter of fiscal 2019, compared to the third quarter of fiscal 2018, while it increased slightly in the first nine months of fiscal 2019 compared to the corresponding period of the prior year.

[0001564590-19-003270:mdna:78]
Margins on revenue recognized for strategic solutions were relatively flat during the third quarter of fiscal 2019 compared to the third quarter of fiscal 2018, while they were higher during the first nine months of fiscal 2019 compared to the corresponding period of the prior year due to the benefit of high margins realized on the software license components of several ELAs, and, to a lesser extent, higher ASPs. Margins for mature products increased slightly in the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of the prior year.

[0001564590-19-003270:mdna:79]
[same as prior period, unchanged from 0001564590-18-029831:mdna:79]

[0001564590-19-003270:mdna:80]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 10 |  |  | $ | 6 |  |  |  | 67 | % |  | $ | 25 |  |  | $ | 19 |  |  |  | 32 | % |

[0001564590-19-003270:mdna:81]
Cost of software maintenance revenues in dollars was relatively flat in the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of fiscal 2018 and represented 4% of software maintenance revenues for both the third quarter and first nine months of fiscal 2019.

[0001564590-19-003270:mdna:82]
[same as prior period, unchanged from 0001564590-18-029831:mdna:82]

[0001564590-19-003270:mdna:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 102 |  |  | $ | 108 |  |  |  | (6 | )% |  | $ | 315 |  |  | $ | 334 |  |  |  | (6 | )% |

[0001564590-19-003270:mdna:84]
Cost of hardware maintenance and other services revenues decreased by $6 million, or 6%, and $19 million, or 6%, respectively, for the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of fiscal 2018, primarily due to the favorable impact of cost savings initiatives. Costs represented 29% of hardware maintenance and other services revenues in the third quarter and first nine months of fiscal 2019, compared to 30% in the corresponding periods of the prior year.

[0001564590-19-003270:mdna:85]
[same as prior period, unchanged from 0001564590-18-029831:mdna:85]

[0001564590-19-003270:mdna:86]
[same as prior period, unchanged from 0001564590-18-029831:mdna:86]

[0001564590-19-003270:mdna:87]
[same as prior period, unchanged from 0001564590-18-029831:mdna:87]

[0001564590-19-003270:mdna:88]
Total compensation costs included in operating expenses decreased by $5 million, or 1% in the third quarter of fiscal 2019, compared to the corresponding period of the prior year primarily due to lower incentive compensation expense and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations, partially offset by higher salaries and stock-based compensation expenses, reflecting a slight increase in average headcount.

[0001564590-19-003270:mdna:89]
Total compensation costs included in operating expenses increased by $5 million, or less than 1% in the first nine months of fiscal 2019, compared to the corresponding period in the prior year, primarily due to higher salaries and benefits expense, partially offset by lower incentive compensation expense.

[0001564590-19-003270:mdna:90]
[same as prior period, unchanged from 0001564590-18-029831:mdna:101]

[0001564590-19-003270:mdna:91]
[same as prior period, unchanged from 0001564590-18-029831:mdna:89]

[0001564590-19-003270:mdna:92]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 401 |  |  | $ | 419 |  |  |  | (4 | )% |  | $ | 1,218 |  |  | $ | 1,263 |  |  |  | (4 | )% |

[0001564590-19-003270:mdna:93]
[same as prior period, unchanged from 0001564590-18-029831:mdna:91]

[0001564590-19-003270:mdna:94]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | (1 | ) |
| Commissions |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (2 | ) |
| Total change |  |  | (4 | ) |  |  | (4 | ) |

[0001564590-19-003270:mdna:95]
Compensation costs decreased for the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of the prior year, reflecting a slight decrease in average headcount. Facilities and IT support costs decreased primarily due to cost containment efforts. Additionally, sales and marketing expenses in the third quarter of fiscal 2019 were favorably impacted by foreign exchange rate fluctuations.

[0001564590-19-003270:mdna:96]
[same as prior period, unchanged from 0001564590-18-029831:mdna:94]

[0001564590-19-003270:mdna:97]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Research and development expenses |  | $ | 203 |  |  | $ | 193 |  |  |  | 5 | % |  | $ | 622 |  |  | $ | 580 |  |  |  | 7 | % |

[0001564590-19-003270:mdna:98]
[same as prior period, unchanged from 0001564590-18-029831:mdna:96]

[0001564590-19-003270:mdna:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 2 |  |  |  | 4 |  |
| Development projects and outside services |  |  | — |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 5 |  |  |  | 7 |  |

[0001564590-19-003270:mdna:100]
The increase in compensation costs for the third quarter and first nine months of fiscal 2019 compared to the corresponding periods in the prior year was attributable to an increase in average headcount of 6% and 7%, respectively, resulting in higher salaries, benefits and stock-based compensation expense, partially offset by lower incentive compensation expense and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. The increase in headcount reflects our investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities. Development projects and outside services expense for the first nine months of fiscal 2019 increased as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance existing ones. Facilities and IT support costs increased in the current year periods in connection with the increase in average headcount.

[0001564590-19-003270:mdna:101]
[same as prior period, unchanged from 0001564590-18-029831:mdna:99]

[0001564590-19-003270:mdna:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| General and administrative expenses |  | $ | 67 |  |  | $ | 72 |  |  |  | (7 | )% |  | $ | 209 |  |  | $ | 209 |  |  |  | — | % |

[0001564590-19-003270:mdna:103]
[same as prior period, unchanged from 0001564590-18-029831:mdna:102]

[0001564590-19-003270:mdna:104]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (6 | ) |  |  | (2 | ) |
| Professional and legal fees and outside services |  |  | 2 |  |  |  | — |  |
| Facilities and IT support costs |  |  | (3 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 2 |  |
| Total change |  |  | (7 | ) |  |  | — |  |

[0001564590-19-003270:mdna:105]
The decrease in compensation costs for the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of the prior year was attributable to lower incentive compensation and salaries expense, and to a lesser extent, the favorable impact of foreign exchange rate fluctuations during the third quarter. While average headcount increased in the current year periods, salaries expense decreased because a greater percentage of employees were located in lower cost geographies. The decrease in facilities and IT support costs for the third quarter of fiscal 2019 compared to the corresponding period of the prior year was primarily due to lower spending levels on IT projects.

[0001564590-19-003270:mdna:106]
[same as prior period, unchanged from 0001564590-18-029831:mdna:105]

[0001564590-19-003270:mdna:107]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |
| Restructuring charges |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 19 |  |  | $ | — |  |  | NM |

[0001564590-19-003270:mdna:108]
[same as prior period, unchanged from 0001564590-18-029831:mdna:107]

[0001564590-19-003270:mdna:109]
[same as prior period, unchanged from 0001564590-18-029831:mdna:108]

[0001564590-19-003270:mdna:110]
Gain on Sale of Properties (in millions, except percentages):

[0001564590-19-003270:mdna:111]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |
| Gain on sale of properties |  | $ | — |  |  | $ | (218 | ) |  | NM |  | $ | — |  |  | $ | (218 | ) |  | NM |

[0001564590-19-003270:mdna:112]
NM – Not Meaningful

[0001564590-19-003270:mdna:113]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings. Upon the completion of the first closing in the third quarter of fiscal 2018, we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-19-003270:mdna:114]
During the third quarter of fiscal 2018, our continuing involvement with properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded a non-cash sale of properties, extinguished the associated financing obligation and recognized a gain of $76 million.

[0001564590-19-003270:mdna:115]
[same as prior period, unchanged from 0001564590-18-029831:mdna:109]

[0001564590-19-003270:mdna:116]
[same as prior period, unchanged from 0001564590-18-029831:mdna:110]

[0001564590-19-003270:mdna:117]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Interest income |  | $ | 22 |  |  | $ | 20 |  |  |  | 10 | % |  | $ | 68 |  |  | $ | 55 |  |  |  | 24 | % |
| Interest expense |  |  | (16 | ) |  |  | (17 | ) |  |  | (6 | )% |  |  | (44 | ) |  |  | (47 | ) |  |  | (6 | )% |
| Other income, net |  |  | 2 |  |  |  | 11 |  |  |  | (82 | )% |  |  | 9 |  |  |  | 17 |  |  |  | (47 | )% |
| Total |  | $ | 8 |  |  | $ | 14 |  |  |  | (43 | )% |  | $ | 33 |  |  | $ | 25 |  |  |  | 32 | % |

[0001564590-19-003270:mdna:118]
Interest income increased in the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of the prior year, primarily due to a shift in our investment portfolio to higher-yielding investments, partially offset by a decrease in the size of the portfolio. Interest expense declined in the current year periods due to a reduction in the average amount of interest-bearing debt outstanding. Other income, net decreased in the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of the prior year primarily due to lower net foreign exchange gains.

[0001564590-19-003270:mdna:119]
[same as prior period, unchanged from 0001564590-18-029831:mdna:113]

[0001564590-19-003270:mdna:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | % Change |  |
| Provision for income taxes |  | $ | 70 |  |  | $ | 983 |  |  |  | (93 | )% |  | $ | 111 |  |  | $ | 1,045 |  |  |  | (89 | )% |

[0001564590-19-003270:mdna:121]
Our effective tax rate for the third quarter of fiscal 2019 was 21.9% compared to an effective tax rate of 195.0% for the third quarter of fiscal 2018. Our effective tax rate for the first nine months of fiscal 2019 was 12.6% compared to an effective tax rate of 120.0% for the corresponding period of fiscal 2018. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rates decreased for the third quarter and first nine months of fiscal 2019 compared to the corresponding periods of the prior year primarily due to the provisional impacts of U.S. tax reform, and the sale of certain land in Sunnyvale, California, which resulted in aggregate discrete tax charges of $856 million and $72 million, respectively, in the third quarter of fiscal 2018. Our effective tax rates in the current year were also impacted by a reduction of the federal income tax rate under U.S. tax reform and discrete impacts related to stock-based compensation. Additionally, our effective tax rate for the first nine months of fiscal 2019 reflects a $34 million discrete tax benefit for certain intercompany transactions resulting from the retrospective application of the new revenue standard.

[0001564590-19-003270:mdna:122]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. ASC 740, Income Taxes, requires companies to recognize the effect of the tax law changes in the period of enactment. However, the SEC staff issued Staff Accounting Bulletin 118, which allowed companies to record provisional amounts during a measurement period not to extend beyond one year from the TCJA enactment date.

[0001564590-19-003270:mdna:123]
As a result of the U.S. federal corporate income tax rate change, effective as of January 1, 2018, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. During the third quarter of fiscal 2018, we recorded $117 million of tax expense related to all tax rate changes. Upon finalization of our provisional estimates during the third quarter of fiscal 2019, we recorded tax expense of $6 million related to deferred tax assets for equity-based compensation awards to our executives.

[0001564590-19-003270:mdna:124]
The TCJA imposes a mandatory, one-time transition tax on accumulated foreign earnings and profits not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. In the third quarter of fiscal 2018, we recorded a $739 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. In the third quarter of fiscal 2019, we finalized our computation of the transition tax and recorded a reduction of $5 million to our provisional amount.

[0001564590-19-003270:mdna:125]
We will continue to assess the impact of further guidance from federal and state tax authorities on our business and consolidated financial statements, and recognize any adjustments in the period in which they are determined.

[0001564590-19-003270:mdna:126]
Under the TCJA, the global minimum tax on intangible income (“GMT”) provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules, or (ii) account for GMT in a company’s measurement of deferred taxes. We have elected to recognize the GMT as a period cost.

[0001564590-19-003270:mdna:127]
As of January 25, 2019, we had $382 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $308 million would affect our provision for income taxes if recognized, and $326 million has been recorded in other long-term liabilities.

[0001564590-19-003270:mdna:128]
[same as prior period, unchanged from 0001564590-18-029831:mdna:118]

[0001564590-19-003270:mdna:129]
[same as prior period, unchanged from 0001564590-18-029831:mdna:119]

[0001564590-19-003270:mdna:130]
| (In millions, except percentages) |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,049 |  |  | $ | 5,391 |  |
| Principal amount of debt |  | $ | 1,714 |  |  | $ | 1,935 |  |

[0001564590-19-003270:mdna:131]
[same as prior period, unchanged from 0001564590-18-029831:mdna:121]

[0001564590-19-003270:mdna:132]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Net cash provided by operating activities |  | $ | 942 |  |  | $ | 984 |  |
| Net cash provided by (used in) investing activities |  |  | 521 |  |  |  | (141 | ) |
| Net cash used in financing activities |  |  | (2,117 | ) |  |  | (350 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (17 | ) |  |  | 37 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (671 | ) |  | $ | 530 |  |

[0001564590-19-003270:mdna:133]
[same as prior period, unchanged from 0001564590-18-029831:mdna:124]

[0001564590-19-003270:mdna:134]
As of January 25, 2019, our cash, cash equivalents and short-term investments were $4.0 billion, a decrease of $1.3 billion from April 27, 2018. The decrease was primarily due to $1.6 billion paid for the repurchase of our common stock, $306 million used for the payment of dividends, $221 million used for the net repayment of commercial paper notes, and $138 million in purchases of property and equipment, partially offset by $942 million of cash provided by operating activities. Working capital decreased by $1.5 billion to $1.9 billion as of January 25, 2019 compared to April 27, 2018 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above, and the reclassification of $400 million principal amount of our senior notes to current liabilities.

[0001564590-19-003270:mdna:135]
[same as prior period, unchanged from 0001564590-18-029831:mdna:126]

[0001564590-19-003270:mdna:136]
[same as prior period, unchanged from 0001564590-18-029831:mdna:127]

[0001564590-19-003270:mdna:137]
|  |  | Three Months Ended |  |
| (In days) |  | January 25, 2019 |  |  | April 27, 2018 |  |  | January 26, 2018 |  |
| Days sales outstanding (1) |  |  | 51 |  |  |  | 58 |  |  |  | 46 |  |
| Days inventory outstanding (2) |  |  | 16 |  |  |  | 18 |  |  |  | 14 |  |
| Days payables outstanding (3) |  |  | (78 | ) |  |  | (90 | ) |  |  | (71 | ) |
| Cash conversion cycle (4) |  |  | (11 | ) |  |  | (14 | ) |  |  | (12 | ) |

[0001564590-19-003270:mdna:138]
[same as prior period, unchanged from 0001564590-18-029831:mdna:129]

[0001564590-19-003270:mdna:139]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). DSO for the third quarter of fiscal 2019 increased compared to the corresponding period of fiscal 2018 primarily due to one of our major distributors choosing not to take advantage of an early payment discount in the current quarter, while it decreased compared to the fourth quarter of fiscal 2018 due to lower seasonal invoicing levels and more favorable shipping linearity. |

[0001564590-19-003270:mdna:140]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the third quarter of fiscal 2019 increased compared to the corresponding period of fiscal 2018, primarily due to higher levels of finished goods on hand at the end of the current quarter, while it decreased compared to the fourth quarter of fiscal 2018 due to lower levels of finished goods on hand at the end of the current quarter. |

[0001564590-19-003270:mdna:141]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the third quarter of fiscal 2019 increased compared to the corresponding period of fiscal 2018, due to differences in the timing of purchases from and payments to our suppliers. DPO for the third quarter of fiscal 2019 decreased compared to the fourth quarter of 2018, primarily due to the timing of purchases from contract manufacturers. |

[0001564590-19-003270:mdna:142]
[same as prior period, unchanged from 0001564590-18-029831:mdna:133]

[0001564590-19-003270:mdna:143]
[same as prior period, unchanged from 0001564590-18-029831:mdna:134]

[0001564590-19-003270:mdna:144]
During the first nine months of fiscal 2019, we generated cash from operating activities of $942 million, reflecting net income of $773 million, adjusted by non-cash depreciation and amortization of $149 million, and stock-based compensation of $121 million, compared to $984 million of cash generated from operating activities during the first nine months of fiscal 2018.

[0001564590-19-003270:mdna:145]
37

[0001564590-19-003270:mdna:146]
Changes in assets and liabilities in the first nine months of fiscal 2019 included the following:

[0001564590-19-003270:mdna:147]
|  | • | Accounts receivable decreased $165 million, reflecting lower DSO. |

[0001564590-19-003270:mdna:148]
|  | • | Accounts payable decreased $101 million, reflecting lower DPO. |

[0001564590-19-003270:mdna:149]
|  | • | Accrued expenses decreased $85 million, primarily due to employee compensation payouts related to fiscal year 2018 commissions and incentive compensation plans. |

[0001564590-19-003270:mdna:150]
|  | • | Long-term taxes payable decreased $60 million, primarily due to transition taxes associated with U.S. tax reform. |

[0001564590-19-003270:mdna:151]
[same as prior period, unchanged from 0001564590-18-029831:mdna:142]

[0001564590-19-003270:mdna:152]
[same as prior period, unchanged from 0001564590-18-029831:mdna:143]

[0001564590-19-003270:mdna:153]
During the first nine months of fiscal 2019, we generated $661 million from maturities and sales of investments, net of purchases, and paid $138 million for capital expenditures, while during the first nine months of fiscal 2018, we used $178 million for the purchase of investments, net of maturities and sales, and paid $97 million for capital expenditures. Additionally, during the first nine months of fiscal 2018, we paid $75 million to acquire two privately-held companies, and received proceeds of $210 million from the sale of properties.

[0001564590-19-003270:mdna:154]
[same as prior period, unchanged from 0001564590-18-029831:mdna:145]

[0001564590-19-003270:mdna:155]
During the first nine months of fiscal 2019, we used $1.6 billion for the repurchase of 22 million shares of our common stock, $306 million for the payment of dividends, and $221 million for the repayment of commercial paper notes, net, compared to $450 million used for the repurchase of 10 million shares of common stock, $161 million used for the payment of dividends, $750 million used for the repayment of one of our Senior Notes, $132 million generated from issuances of commercial paper notes, net, and $795 million generated from the issuance of long-term debt during the first nine months of fiscal 2018.

[0001564590-19-003270:mdna:156]
[same as prior period, unchanged from 0001564590-18-029831:mdna:147]

[0001564590-19-003270:mdna:157]
[same as prior period, unchanged from 0001564590-18-029831:mdna:148]

[0001564590-19-003270:mdna:158]
Our principal sources of liquidity as of January 25, 2019 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-19-003270:mdna:159]
[same as prior period, unchanged from 0001564590-18-029831:mdna:150]

[0001564590-19-003270:mdna:160]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Cash and cash equivalents |  | $ | 2,271 |  |  | $ | 2,941 |  |
| Short-term investments |  |  | 1,778 |  |  |  | 2,450 |  |
| Total |  | $ | 4,049 |  |  | $ | 5,391 |  |

[0001564590-19-003270:mdna:161]
As of January 25, 2019 and April 27, 2018, $3.8 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.2 billion and $0.9 billion, respectively, were available in the U.S. at the end of each period. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-19-003270:mdna:162]
[same as prior period, unchanged from 0001564590-18-029831:mdna:153]

[0001564590-19-003270:mdna:163]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 25, 2019.

[0001564590-19-003270:mdna:164]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-19-003270:mdna:165]
[same as prior period, unchanged from 0001564590-18-029831:mdna:157]

[0001564590-19-003270:mdna:166]
The following table summarizes the principal amount of our Senior Notes as of January 25, 2019 (in millions):

[0001564590-19-003270:mdna:167]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-19-003270:mdna:168]
[same as prior period, unchanged from 0001564590-18-029831:mdna:160]

[0001564590-19-003270:mdna:169]
Commercial Paper Program and Credit Facility

[0001564590-19-003270:mdna:170]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $164 million, a weighted-average interest rate of 2.87% and maturities ranging from 27 days to 36 days.

[0001564590-19-003270:mdna:171]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 25, 2019, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-19-003270:mdna:172]
[same as prior period, unchanged from 0001564590-18-029831:mdna:164]

[0001564590-19-003270:mdna:173]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2019 to be between $50 million and $100 million.

[0001564590-19-003270:mdna:174]
[same as prior period, unchanged from 0001564590-18-029831:mdna:166]

[0001564590-19-003270:mdna:175]
On February 13, 2019, we declared a cash dividend of $0.40 per share of common stock, payable on April 24, 2019 to holders of record as of the close of business on April 5, 2019.

[0001564590-19-003270:mdna:176]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 25, 2019, we repurchased a total of 306 million shares of our common stock at an average price of $36.72 per share, for an aggregate purchase price of $11.2 billion. As of January 25, 2019, the remaining authorized amount for stock repurchases under this program was $2.4 billion.

[0001564590-19-003270:mdna:177]
[same as prior period, unchanged from 0001564590-18-029831:mdna:169]

[0001564590-19-003270:mdna:178]
[same as prior period, unchanged from 0001564590-18-029831:mdna:170]

[0001564590-19-003270:mdna:179]
[same as prior period, unchanged from 0001564590-18-029831:mdna:171]

[0001564590-19-003270:mdna:180]
As of January 25, 2019, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $164 million.

[0001564590-19-003270:mdna:181]
[same as prior period, unchanged from 0001564590-18-029831:mdna:173]

[0001564590-19-003270:mdna:182]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 25, 2019, we had $501 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-003270:mdna:183]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of January 25, 2019, we had $4 million in construction related obligations and $220 million in other purchase obligations.

[0001564590-19-003270:mdna:184]
[same as prior period, unchanged from 0001564590-18-029831:mdna:176]

[0001564590-19-003270:mdna:185]
As of January 25, 2019, our liability for uncertain tax positions was $326 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-19-003270:mdna:186]
[same as prior period, unchanged from 0001564590-18-029831:mdna:178]

[0001564590-19-003270:mdna:187]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $54 million and $62 million of receivables during the nine months ended January 25, 2019 and January 26, 2018, respectively.

[0001564590-19-003270:mdna:188]
[same as prior period, unchanged from 0001564590-18-029831:mdna:180]

[0001564590-19-003270:mdna:189]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 25, 2019 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-003270:mdna:190]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-19-003270:mdna:191]
[same as prior period, unchanged from 0001564590-18-029831:mdna:184]

[0001564590-19-003270:mdna:192]
[same as prior period, unchanged from 0001564590-18-029831:mdna:185]

[0001564590-19-003270:mdna:193]
Legal Contingencies

[0001564590-19-003270:mdna:194]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.
