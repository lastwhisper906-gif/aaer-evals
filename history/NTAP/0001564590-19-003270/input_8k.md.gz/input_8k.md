# NTAP 8-K — 0001564590-19-002825 filed 2019-02-13

## item codes, every 8-K on or before 2019-02-19

- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2019-02-19

- none on or before 2019-02-19

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-002825:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-19-002825:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-19-002825:8k_2_02:3]
Exhibit 99.1

[0001564590-19-002825:8k_2_02:4]
NetApp Reports Third Quarter Fiscal Year 2019 Results

[0001564590-19-002825:8k_2_02:5]
Expanded Gross Margins, Operating Margins and Earnings Per Share

[0001564590-19-002825:8k_2_02:6]
| • | Net revenues of $1.56 billion grew 2% year-over-year |  |

[0001564590-19-002825:8k_2_02:7]
| • | Product revenue of $967 million grew 2% year-over-year |  |

[0001564590-19-002825:8k_2_02:8]
| • | All-flash array annualized net revenue run rate of $2.4 billion increased 19% year-over-year |  |

[0001564590-19-002825:8k_2_02:9]
| • | $649 million returned to shareholders in share repurchases and cash dividends |  |

[0001564590-19-002825:8k_2_02:10]
Sunnyvale, Calif.—February 13, 2019—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2019, which ended January 25, 2019.

[0001564590-19-002825:8k_2_02:11]
“Although I am disappointed that revenue came in at the low-end of our guidance range, we continue to demonstrate discipline in how we manage the business. We are playing into the big market transitions from a position of strength and are focused on execution to maximize our opportunity in an uncertain macroeconomic environment,” said George Kurian, chief executive officer. “Our flash, hybrid cloud infrastructure, and AI solutions are serving as pillars of customers’ new architectures and we are seeing adoption of our cloud offerings as part of our customers’ foundation for moving applications and data to the cloud. We have conviction in our strategy to drive long-term growth.”

[0001564590-19-002825:8k_2_02:12]
Third Quarter Fiscal Year 2019 Financial Results

[0001564590-19-002825:8k_2_02:13]
| • | Net Revenues: $1.56 billion, increased 2% year-over-year from $1.54 billion* in the third quarter of fiscal 2018 |  |

[0001564590-19-002825:8k_2_02:14]
| • | Net Income: GAAP net income of $249 million, compared to GAAP net loss of $479 million*1 in the third quarter of fiscal 2018; non-GAAP net income2 of $305 million, compared to non-GAAP net income of $289 million* in the third quarter of fiscal 2018 |  |

[0001564590-19-002825:8k_2_02:15]
| • | Earnings per Share: GAAP net income per share3 of $0.98 compared to GAAP net loss per share4 of $1.79*1 in the third quarter of fiscal 2018; non-GAAP net income per share of $1.20, compared to non-GAAP net income per share of $1.05* in the third quarter of fiscal 2018 |  |

[0001564590-19-002825:8k_2_02:16]
| • | Cash, Cash Equivalents and Investments: $4.0 billion at the end of the third quarter of fiscal 2019 |  |

[0001564590-19-002825:8k_2_02:17]
| • | Cash from Operations: $451 million, compared to $420 million in the third quarter of fiscal 2018 |  |

[0001564590-19-002825:8k_2_02:18]
| • | Share Repurchase and Dividend: Returned $649 million to shareholders through share repurchases and cash dividends |  |

[0001564590-19-002825:8k_2_02:19]
*In the first quarter of fiscal 2019, NetApp adopted Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, NetApp’s condensed consolidated balance sheet as of April 27, 2018, condensed consolidated statements of operations and cash flows for all fiscal 2018 periods presented, and all related financial statement metrics included herein, have been restated to conform to the new rules.

[0001564590-19-002825:8k_2_02:20]
Fourth Quarter Fiscal Year 2019 Financial Outlook

[0001564590-19-002825:8k_2_02:21]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2019:

[0001564590-19-002825:8k_2_02:22]
| •Net revenues are expected to be in the range of: | $1.590 billion to $1.690 billion |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $1.06-$1.12 | $1.22-$1.28 |

[0001564590-19-002825:8k_2_02:23]
Dividend

[0001564590-19-002825:8k_2_02:24]
Next cash dividend of $0.40 per share to be paid on April 24, 2019, to shareholders of record as of the close of business on April 5, 2019.

[0001564590-19-002825:8k_2_02:25]
Third Quarter Fiscal Year 2019 Business Highlights

[0001564590-19-002825:8k_2_02:26]
New World-Class Products and Solutions Help Manage Data Demands

[0001564590-19-002825:8k_2_02:27]
| - | NetApp announced new data services and solutions that empower customers to innovate in the cloud. These new offerings include the expanded availability of the Microsoft Azure NetApp™ Files preview. |

[0001564590-19-002825:8k_2_02:28]
| - | NetApp announced NetApp Element™ 11.0 software, which introduces new functionality for their NetApp HCI customers with Protection Domains. In addition, Element 11.0 has the ability to manage storage clusters running Element software on IPv6 networks, 16TiB volume support, and QoS histograms to help understand the user’s environment. |

[0001564590-19-002825:8k_2_02:29]
NetApp Strengthens Strategic Partnerships

[0001564590-19-002825:8k_2_02:30]
| - | NetApp announced NetApp Cloud Volumes Service for Google Cloud Platform will soon be available in Europe to help even more customers handle the configuring and managing of their storage infrastructures. |

[0001564590-19-002825:8k_2_02:31]
| - | NetApp announced VMware Validated Design for Private Cloud with NetApp HCI, NetApp Verified Architecture for VMware End-User Computing with NetApp HCI and NVIDIA GPUs and NetApp Technical Report for Object Storage with NetApp HCI. |

[0001564590-19-002825:8k_2_02:32]
Recognition for Industry Leading Products

[0001564590-19-002825:8k_2_02:33]
| - | NetApp’s AFF A800 took the top spot in the latest SPEC SFS2014 swbuild Result5 at the time of publication in Nov 2018. The AFF A800 delivered performance that was 3 times as fast as the nearest competitor. These results also highlighted the fact that ONTAP™ with FlexGroup volumes can do more work at lower latencies and higher throughput. |

[0001564590-19-002825:8k_2_02:34]
Webcast and Conference Call Information

[0001564590-19-002825:8k_2_02:35]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-19-002825:8k_2_02:36]
About NetApp

[0001564590-19-002825:8k_2_02:37]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-19-002825:8k_2_02:38]
###

[0001564590-19-002825:8k_2_02:39]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-19-002825:8k_2_02:40]
Footnotes

[0001564590-19-002825:8k_2_02:41]
1GAAP net loss for the third quarter of fiscal year 2018 included a one-time charge of $856 million which resulted from the enactment of the Tax Cuts and Jobs Act on December 22, 2017.

[0001564590-19-002825:8k_2_02:42]
2Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale of properties, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-

[0001564590-19-002825:8k_2_02:43]
GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-19-002825:8k_2_02:44]
3GAAP net income per share and non-GAAP income per share are calculated using the diluted number of shares.

[0001564590-19-002825:8k_2_02:45]
4GAAP net loss per share is calculated using the basic number of shares and excludes common stock equivalents because the impact would be anti-dilutive.

[0001564590-19-002825:8k_2_02:46]
5SPEC SFS®2014_swbuild Result. https://www.spec.org/sfs2014/results/res2018q4/sfs2014-20181112-00053.html

[0001564590-19-002825:8k_2_02:47]
NetApp Usage of Non-GAAP Financial Information

[0001564590-19-002825:8k_2_02:48]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-19-002825:8k_2_02:49]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in

[0001564590-19-002825:8k_2_02:50]
accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-19-002825:8k_2_02:51]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-19-002825:8k_2_02:52]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-19-002825:8k_2_02:53]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-19-002825:8k_2_02:54]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-19-002825:8k_2_02:55]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-19-002825:8k_2_02:56]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-19-002825:8k_2_02:57]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-19-002825:8k_2_02:58]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-19-002825:8k_2_02:59]
G. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-19-002825:8k_2_02:60]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-19-002825:8k_2_02:61]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-19-002825:8k_2_02:62]
NETAPP, INC.

[0001564590-19-002825:8k_2_02:63]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-002825:8k_2_02:64]
(In millions)

[0001564590-19-002825:8k_2_02:65]
(Unaudited)

[0001564590-19-002825:8k_2_02:66]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,049 |  |  | $ | 5,391 |  |
| Accounts receivable |  |  | 872 |  |  |  | 1,047 |  |
| Inventories |  |  | 100 |  |  |  | 122 |  |
| Other current assets |  |  | 340 |  |  |  | 392 |  |
| Total current assets |  |  | 5,361 |  |  |  | 6,952 |  |
| Property and equipment, net |  |  | 763 |  |  |  | 756 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,798 |  |  |  | 1,833 |  |
| Other non-current assets |  |  | 496 |  |  |  | 450 |  |
| Total assets |  | $ | 8,418 |  |  | $ | 9,991 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 497 |  |  | $ | 609 |  |
| Accrued expenses |  |  | 730 |  |  |  | 825 |  |
| Commercial paper notes |  |  | 163 |  |  |  | 385 |  |
| Current portion of long-term debt |  |  | 399 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,641 |  |  |  | 1,712 |  |
| Total current liabilities |  |  | 3,430 |  |  |  | 3,531 |  |
| Long-term debt |  |  | 1,144 |  |  |  | 1,541 |  |
| Other long-term liabilities |  |  | 898 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,716 |  |  |  | 1,651 |  |
| Total liabilities |  |  | 7,188 |  |  |  | 7,715 |  |
| Stockholders' equity |  |  | 1,230 |  |  |  | 2,276 |  |
| Total liabilities and stockholders' equity |  | $ | 8,418 |  |  | $ | 9,991 |  |

[0001564590-19-002825:8k_2_02:67]
NETAPP, INC.

[0001564590-19-002825:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-002825:8k_2_02:69]
(In millions, except per share amounts)

[0001564590-19-002825:8k_2_02:70]
(Unaudited)

[0001564590-19-002825:8k_2_02:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 967 |  |  | $ | 952 |  |  | $ | 2,755 |  |  | $ | 2,498 |  |
| Software maintenance |  |  | 239 |  |  |  | 221 |  |  |  | 704 |  |  |  | 668 |  |
| Hardware maintenance and other services |  |  | 357 |  |  |  | 366 |  |  |  | 1,095 |  |  |  | 1,109 |  |
| Net revenues |  |  | 1,563 |  |  |  | 1,539 |  |  |  | 4,554 |  |  |  | 4,275 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 469 |  |  |  | 469 |  |  |  | 1,295 |  |  |  | 1,242 |  |
| Cost of software maintenance |  |  | 10 |  |  |  | 6 |  |  |  | 25 |  |  |  | 19 |  |
| Cost of hardware maintenance and other services |  |  | 102 |  |  |  | 108 |  |  |  | 315 |  |  |  | 334 |  |
| Total cost of revenues |  |  | 581 |  |  |  | 583 |  |  |  | 1,635 |  |  |  | 1,595 |  |
| Gross profit |  |  | 982 |  |  |  | 956 |  |  |  | 2,919 |  |  |  | 2,680 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 401 |  |  |  | 419 |  |  |  | 1,218 |  |  |  | 1,263 |  |
| Research and development |  |  | 203 |  |  |  | 193 |  |  |  | 622 |  |  |  | 580 |  |
| General and administrative |  |  | 67 |  |  |  | 72 |  |  |  | 209 |  |  |  | 209 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 19 |  |  |  | — |  |
| Gain on sale of properties |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 671 |  |  |  | 466 |  |  |  | 2,068 |  |  |  | 1,834 |  |
| Income from operations |  |  | 311 |  |  |  | 490 |  |  |  | 851 |  |  |  | 846 |  |
| Other income, net |  |  | 8 |  |  |  | 14 |  |  |  | 33 |  |  |  | 25 |  |
| Income before income taxes |  |  | 319 |  |  |  | 504 |  |  |  | 884 |  |  |  | 871 |  |
| Provision for income taxes |  |  | 70 |  |  |  | 983 |  |  |  | 111 |  |  |  | 1,045 |  |
| Net income (loss) |  | $ | 249 |  |  | $ | (479 | ) |  | $ | 773 |  |  | $ | (174 | ) |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.00 |  |  | $ | (1.79 | ) |  | $ | 3.01 |  |  | $ | (0.65 | ) |
| Diluted |  | $ | 0.98 |  |  | $ | (1.79 | ) |  | $ | 2.94 |  |  | $ | (0.65 | ) |
| Shares used in net income (loss) per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 250 |  |  |  | 268 |  |  |  | 257 |  |  |  | 269 |  |
| Diluted |  |  | 255 |  |  |  | 268 |  |  |  | 263 |  |  |  | 269 |  |
| Cash dividends declared per share |  | $ | 0.40 |  |  | $ | 0.20 |  |  | $ | 1.20 |  |  | $ | 0.60 |  |

[0001564590-19-002825:8k_2_02:72]
NETAPP, INC.

[0001564590-19-002825:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-002825:8k_2_02:74]
(In millions)

[0001564590-19-002825:8k_2_02:75]
(Unaudited)

[0001564590-19-002825:8k_2_02:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 249 |  |  | $ | (479 | ) |  | $ | 773 |  |  | $ | (174 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 51 |  |  |  | 48 |  |  |  | 149 |  |  |  | 150 |  |
| Stock-based compensation |  |  | 43 |  |  |  | 38 |  |  |  | 121 |  |  |  | 125 |  |
| Deferred income taxes |  |  | 4 |  |  |  | 205 |  |  |  | (21 | ) |  |  | 245 |  |
| Gain on sale of properties |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Other items, net |  |  | (3 | ) |  |  | (3 | ) |  |  | 8 |  |  |  | (8 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (104 | ) |  |  | (156 | ) |  |  | 165 |  |  |  | (10 | ) |
| Inventories |  |  | (14 | ) |  |  | 10 |  |  |  | 22 |  |  |  | 68 |  |
| Accounts payable |  |  | 26 |  |  |  | 81 |  |  |  | (101 | ) |  |  | 115 |  |
| Accrued expenses |  |  | 77 |  |  |  | 126 |  |  |  | (85 | ) |  |  | 58 |  |
| Deferred revenue and financed unearned services revenue |  |  | 146 |  |  |  | 64 |  |  |  | 17 |  |  |  | (99 | ) |
| Long-term taxes payable |  |  | 3 |  |  |  | 721 |  |  |  | (60 | ) |  |  | 723 |  |
| Changes in other operating assets and liabilities, net |  |  | (27 | ) |  |  | (17 | ) |  |  | (46 | ) |  |  | 9 |  |
| Net cash provided by operating activities |  |  | 451 |  |  |  | 420 |  |  |  | 942 |  |  |  | 984 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 172 |  |  |  | (226 | ) |  |  | 661 |  |  |  | (178 | ) |
| Purchases of property and equipment |  |  | (31 | ) |  |  | (32 | ) |  |  | (138 | ) |  |  | (97 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | 210 |  |  |  | — |  |  |  | 210 |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | (75 | ) |
| Other investing activities, net |  |  | (1 | ) |  |  | (1 | ) |  |  | 1 |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | 140 |  |  |  | (49 | ) |  |  | 521 |  |  |  | (141 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 53 |  |  |  | 100 |  |  |  | 118 |  |  |  | 157 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (3 | ) |  |  | (7 | ) |  |  | (92 | ) |  |  | (67 | ) |
| Repurchase of common stock |  |  | (550 | ) |  |  | (150 | ) |  |  | (1,611 | ) |  |  | (450 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | (86 | ) |  |  | (86 | ) |  |  | (221 | ) |  |  | 132 |  |
| Issuance of long-term debt, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 795 |  |
| Repayment of long-term debt |  |  | — |  |  |  | (750 | ) |  |  | — |  |  |  | (750 | ) |
| Dividends paid |  |  | (99 | ) |  |  | (53 | ) |  |  | (306 | ) |  |  | (161 | ) |
| Other financing activities, net |  |  | (3 | ) |  |  | (5 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Net cash used in financing activities |  |  | (688 | ) |  |  | (951 | ) |  |  | (2,117 | ) |  |  | (350 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 8 |  |  |  | 24 |  |  |  | (17 | ) |  |  | 37 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (89 | ) |  |  | (556 | ) |  |  | (671 | ) |  |  | 530 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,365 |  |  |  | 3,536 |  |  |  | 2,947 |  |  |  | 2,450 |  |
| End of period |  | $ | 2,276 |  |  | $ | 2,980 |  |  | $ | 2,276 |  |  | $ | 2,980 |  |

[0001564590-19-002825:8k_2_02:77]
SELECTED CONDENSED CONSOLIDATED BALANCE SHEET LINE ITEMS

[0001564590-19-002825:8k_2_02:78]
(In millions)

[0001564590-19-002825:8k_2_02:79]
(Unaudited)

[0001564590-19-002825:8k_2_02:80]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  |  | 1,651 |  |
| Total stockholders' equity |  |  | 2,067 |  |  |  | 209 |  |  |  | 2,276 |  |

[0001564590-19-002825:8k_2_02:81]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 26, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 32 |  |  | $ | 952 |  |  | $ | 2,450 |  |  | $ | 48 |  |  | $ | 2,498 |  |
| Software maintenance |  |  | 237 |  |  |  | (16 | ) |  |  | 221 |  |  |  | 711 |  |  |  | (43 | ) |  |  | 668 |  |
| Hardware maintenance and other services |  |  | 366 |  |  |  | — |  |  |  | 366 |  |  |  | 1,109 |  |  |  | — |  |  |  | 1,109 |  |
| Net revenues |  |  | 1,523 |  |  |  | 16 |  |  |  | 1,539 |  |  |  | 4,270 |  |  |  | 5 |  |  |  | 4,275 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 468 |  |  |  | 1 |  |  |  | 469 |  |  |  | 1,238 |  |  |  | 4 |  |  |  | 1,242 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Cost of hardware maintenance and other services |  |  | 108 |  |  |  | — |  |  |  | 108 |  |  |  | 336 |  |  |  | (2 | ) |  |  | 334 |  |
| Total cost of revenues |  |  | 582 |  |  |  | 1 |  |  |  | 583 |  |  |  | 1,593 |  |  |  | 2 |  |  |  | 1,595 |  |
| Gross profit |  |  | 941 |  |  |  | 15 |  |  |  | 956 |  |  |  | 2,677 |  |  |  | 3 |  |  |  | 2,680 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 423 |  |  |  | (4 | ) |  |  | 419 |  |  |  | 1,268 |  |  |  | (5 | ) |  |  | 1,263 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |  |  | 580 |  |  |  | — |  |  |  | 580 |  |
| General and administrative |  |  | 72 |  |  |  | — |  |  |  | 72 |  |  |  | 209 |  |  |  | — |  |  |  | 209 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 470 |  |  |  | (4 | ) |  |  | 466 |  |  |  | 1,839 |  |  |  | (5 | ) |  |  | 1,834 |  |
| Income from operations |  |  | 471 |  |  |  | 19 |  |  |  | 490 |  |  |  | 838 |  |  |  | 8 |  |  |  | 846 |  |
| Other income, net |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Income before income taxes |  |  | 485 |  |  |  | 19 |  |  |  | 504 |  |  |  | 863 |  |  |  | 8 |  |  |  | 871 |  |
| Provision for income taxes |  |  | 991 |  |  |  | (8 | ) |  |  | 983 |  |  |  | 1,058 |  |  |  | (13 | ) |  |  | 1,045 |  |
| Net loss |  | $ | (506 | ) |  | $ | 27 |  |  | $ | (479 | ) |  | $ | (195 | ) |  | $ | 21 |  |  | $ | (174 | ) |
| Net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Shares used in net loss per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |
| Diluted |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |

[0001564590-19-002825:8k_2_02:82]
| NETAPP, INC. |
| SUPPLEMENTAL DATA |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |
| (Unaudited) |
|  |  | Q3 FY'19 |  |  | Q2 FY'19 |  |  | Q3 FY'18 |  |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 967 |  |  | $ | 913 |  |  | $ | 952 |  |  |
| Strategic |  | $ | 674 |  |  | $ | 649 |  |  | $ | 657 |  |  |
| Mature |  | $ | 293 |  |  | $ | 264 |  |  | $ | 295 |  |  |
| Software Maintenance |  | $ | 239 |  |  | $ | 236 |  |  | $ | 221 |  |  |
| Hardware Maintenance and Other Services |  | $ | 357 |  |  | $ | 368 |  |  | $ | 366 |  |  |
| Hardware Maintenance Support Contracts |  | $ | 292 |  |  | $ | 303 |  |  | $ | 300 |  |  |
| Professional and Other Services |  | $ | 65 |  |  | $ | 65 |  |  | $ | 66 |  |  |
| Net Revenues |  | $ | 1,563 |  |  | $ | 1,517 |  |  | $ | 1,539 |  |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'19 Revenue |  |  | % of Q2 FY'19 Revenue |  |  | % of Q3 FY'18 Revenue |  |  |
| Americas |  |  | 52 | % |  |  | 57 | % |  |  | 53 | % |  |
| Americas Commercial |  |  | 41 | % |  |  | 44 | % |  |  | 43 | % |  |
| U.S. Public Sector |  |  | 11 | % |  |  | 14 | % |  |  | 10 | % |  |
| EMEA |  |  | 33 | % |  |  | 28 | % |  |  | 33 | % |  |
| Asia Pacific |  |  | 14 | % |  |  | 15 | % |  |  | 14 | % |  |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'19 Revenue |  |  | % of Q2 FY'19 Revenue |  |  | % of Q3 FY'18 Revenue |  |  |
| Direct |  |  | 19 | % |  |  | 23 | % |  |  | 22 | % |  |
| Indirect |  |  | 81 | % |  |  | 77 | % |  |  | 78 | % |  |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'19 |  |  | Q2 FY'19 |  |  | Q3 FY'18 |  |  |
| Non-GAAP Gross Margin |  |  | 63.7 | % |  |  | 64.9 | % |  |  | 63.0 | % |  |
| Product |  |  | 52.6 | % |  |  | 54.1 | % |  |  | 51.8 | % |  |
| Software Maintenance |  |  | 95.8 | % |  |  | 96.6 | % |  |  | 97.3 | % |  |
| Hardware Maintenance and Other Services |  |  | 72.3 | % |  |  | 71.5 | % |  |  | 71.3 | % |  |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'19 |  |  | Q2 FY'19 |  |  | Q3 FY'18 |  |  |
| Non-GAAP Income from Operations |  | $ | 367 |  |  | $ | 336 |  |  | $ | 329 |  |  |
| % of Net Revenues |  |  | 23.5 | % |  |  | 22.1 | % |  |  | 21.4 | % |  |
| Non-GAAP Income before Income Taxes |  | $ | 375 |  |  | $ | 343 |  |  | $ | 343 |  |  |
| Non-GAAP Effective Tax Rate |  |  | 18.7 | % |  |  | 18.5 | % |  |  | 15.7 | % |  |

[0001564590-19-002825:8k_2_02:83]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'19 |  |  | Q2 FY'19 |  |  | Q3 FY'18 |  |  |
| Non-GAAP Net Income |  | $ | 305 |  |  | $ | 280 |  |  | $ | 289 |  |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 255 |  |  |  | 264 |  |  |  | 276 |  |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.20 |  |  | $ | 1.06 |  |  | $ | 1.05 |  |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'19 |  |  | Q2 FY'19 |  |  | Q3 FY'18 |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,357 |  |  | $ | 3,206 |  |  | $ | 3,143 |  |  |
| DSO (days) |  |  | 51 |  |  |  | 46 |  |  |  | 46 |  |  |
| DIO (days) |  |  | 16 |  |  |  | 14 |  |  |  | 14 |  |  |
| DPO (days) |  |  | 78 |  |  |  | 79 |  |  |  | 71 |  |  |
| CCC (days) |  |  | (11 | ) |  |  | (19 | ) |  |  | (12 | ) |  |
| Inventory Turns |  |  | 23 |  |  |  | 25 |  |  |  | 26 |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'19 |  |  | Q2 FY'19 |  |  | Q3 FY'18 |  |  |
| Net Cash Provided by Operating Activities |  | $ | 451 |  |  | $ | 165 |  |  | $ | 420 |  |  |
| Purchases of Property and Equipment |  | $ | 31 |  |  | $ | 43 |  |  | $ | 32 |  |  |
| Free Cash Flow |  | $ | 420 |  |  | $ | 122 |  |  | $ | 388 |  |  |
| Free Cash Flow as a % of Net Revenues |  |  | 26.9 | % |  |  | 8.0 | % |  |  | 25.2 | % |  |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |
| Some items may not add or recalculate due to rounding. |

[0001564590-19-002825:8k_2_02:84]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| NET INCOME |  | $ | 249 |  |  | $ | 241 |  |  | $ | (479 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 12 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 43 |  |  |  | 38 |  |  |  | 38 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |
| Income tax effects |  |  | — |  |  |  | (11 | ) |  |  | 73 |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | 856 |  |
| NON-GAAP NET INCOME |  | $ | 305 |  |  | $ | 280 |  |  | $ | 289 |  |
| COST OF REVENUES |  | $ | 581 |  |  | $ | 543 |  |  | $ | 583 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (2 | ) |  |  | (3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 567 |  |  | $ | 532 |  |  | $ | 570 |  |
| COST OF PRODUCT REVENUES |  | $ | 469 |  |  | $ | 428 |  |  | $ | 469 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 458 |  |  | $ | 419 |  |  | $ | 459 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 102 |  |  | $ | 107 |  |  | $ | 108 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 99 |  |  | $ | 105 |  |  | $ | 105 |  |
| GROSS PROFIT |  | $ | 982 |  |  | $ | 974 |  |  | $ | 956 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 9 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 2 |  |  |  | 3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 996 |  |  | $ | 985 |  |  | $ | 969 |  |

[0001564590-19-002825:8k_2_02:85]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| SALES AND MARKETING EXPENSES |  | $ | 401 |  |  | $ | 408 |  |  | $ | 419 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Stock-based compensation |  |  | (19 | ) |  |  | (16 | ) |  |  | (16 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 379 |  |  | $ | 389 |  |  | $ | 399 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 203 |  |  | $ | 211 |  |  | $ | 193 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (13 | ) |  |  | (12 | ) |  |  | (11 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 190 |  |  | $ | 199 |  |  | $ | 182 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 67 |  |  | $ | 69 |  |  | $ | 72 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60 |  |  | $ | 61 |  |  | $ | 59 |  |
| GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | (218 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | 218 |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 671 |  |  | $ | 688 |  |  | $ | 466 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Stock-based compensation |  |  | (39 | ) |  |  | (36 | ) |  |  | (35 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | 218 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 629 |  |  | $ | 649 |  |  | $ | 640 |  |

[0001564590-19-002825:8k_2_02:86]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| INCOME FROM OPERATIONS |  | $ | 311 |  |  | $ | 286 |  |  | $ | 490 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 12 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 43 |  |  |  | 38 |  |  |  | 38 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 367 |  |  | $ | 336 |  |  | $ | 329 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 319 |  |  | $ | 293 |  |  | $ | 504 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 12 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 43 |  |  |  | 38 |  |  |  | 38 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 375 |  |  | $ | 343 |  |  | $ | 343 |  |
| PROVISION FOR INCOME TAXES |  | $ | 70 |  |  | $ | 52 |  |  | $ | 983 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | — |  |  |  | 11 |  |  |  | (73 | ) |
| Tax reform |  |  | — |  |  |  | — |  |  |  | (856 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 70 |  |  | $ | 63 |  |  | $ | 54 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | 0.98 |  |  | $ | 0.91 |  |  | $ | (1.79 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.17 |  |  |  | 0.14 |  |  |  | 0.14 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 0.02 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (0.81 | ) |
| Income tax effects |  |  | — |  |  |  | (0.04 | ) |  |  | 0.27 |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | 3.19 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.20 |  |  | $ | 1.06 |  |  | $ | 1.05 |  |
| In Q3'FY18, our GAAP net loss per share was calculated using basic shares of 268 million, as the impact of common stock equivalents would have been anti-dilutive. Additionally, each adjustment presented in the reconciliation was computed using basic shares. However, because we reported net income on a non-GAAP basis, non-GAAP net income per share was computed using diluted shares of 276 million. As a result of the difference in the number of shares, the summation of GAAP net loss per share and the adjustments does not equal non-GAAP net income per share. |  |

[0001564590-19-002825:8k_2_02:87]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| Gross margin-GAAP |  |  | 62.8 | % |  |  | 64.2 | % |  |  | 62.1 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.7 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 63.7 | % |  |  | 64.9 | % |  |  | 63.0 | % |
| GAAP cost of revenues |  | $ | 581 |  |  | $ | 543 |  |  | $ | 583 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (2 | ) |  |  | (3 | ) |
| Non-GAAP cost of revenues |  | $ | 567 |  |  | $ | 532 |  |  | $ | 570 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,517 |  |  | $ | 1,539 |  |

[0001564590-19-002825:8k_2_02:88]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| Product gross margin-GAAP |  |  | 51.5 | % |  |  | 53.1 | % |  |  | 50.7 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.0 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 52.6 | % |  |  | 54.1 | % |  |  | 51.8 | % |
| GAAP cost of product revenues |  | $ | 469 |  |  | $ | 428 |  |  | $ | 469 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP cost of product revenues |  | $ | 458 |  |  | $ | 419 |  |  | $ | 459 |  |
| Product revenues |  | $ | 967 |  |  | $ | 913 |  |  | $ | 952 |  |

[0001564590-19-002825:8k_2_02:89]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 71.4 | % |  |  | 70.9 | % |  |  | 70.5 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 72.3 | % |  |  | 71.5 | % |  |  | 71.3 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 102 |  |  | $ | 107 |  |  | $ | 108 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 99 |  |  | $ | 105 |  |  | $ | 105 |  |
| Hardware maintenance and other services revenues |  | $ | 357 |  |  | $ | 368 |  |  | $ | 366 |  |

[0001564590-19-002825:8k_2_02:90]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| GAAP effective tax rate |  |  | 21.9 | % |  |  | 17.7 | % |  |  | 195.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (2.7 | )% |  |  | 0.8 | % |  |  | (9.5 | )% |
| Tax reform |  |  | — | % |  |  | — | % |  |  | (169.8 | )% |
| Non-GAAP effective tax rate |  |  | 19.3 | % |  |  | 18.5 | % |  |  | 15.7 | % |

[0001564590-19-002825:8k_2_02:91]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY19 |  |  | Q2'FY19 |  |  | Q3'FY18 |  |
| Net cash provided by operating activities |  | $ | 451 |  |  | $ | 165 |  |  | $ | 420 |  |
| Purchases of property and equipment |  |  | (31 | ) |  |  | (43 | ) |  |  | (32 | ) |
| Free cash flow |  | $ | 420 |  |  | $ | 122 |  |  | $ | 388 |  |

[0001564590-19-002825:8k_2_02:92]
Some items may not add or recalculate due to rounding.

[0001564590-19-002825:8k_2_02:93]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FOURTH QUARTER FISCAL 2019 |  |
|  |  | Fourth Quarter |  |
|  |  | Fiscal 2019 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $1.22 - $1.28 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Fourth Quarter Fiscal 2019: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.14 | ) |
| Income tax effects |  |  | 0.02 |  |
| Total Adjustments |  |  | (0.16 | ) |
| GAAP Guidance - Net Income Per Share |  | $1.06 - $1.12 |  |

[0001564590-19-002825:8k_2_02:94]
Press Contact:

[0001564590-19-002825:8k_2_02:95]
Madge Miller

[0001564590-19-002825:8k_2_02:96]
NetApp

[0001564590-19-002825:8k_2_02:97]
1 408 419 5263

[0001564590-19-002825:8k_2_02:98]
madge.miller@netapp.com

[0001564590-19-002825:8k_2_02:99]
Investor Contact:

[0001564590-19-002825:8k_2_02:100]
Kris Newton

[0001564590-19-002825:8k_2_02:101]
NetApp

[0001564590-19-002825:8k_2_02:102]
1 408 822 3312

[0001564590-19-002825:8k_2_02:103]
kris.newton@netapp.com
