# NTAP notes — 0001564590-19-003270


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-19-003270:notes:1]
[same as prior period, unchanged from 0001564590-18-029831:notes:1]

[0001564590-19-003270:notes:2]
[same as prior period, unchanged from 0001564590-18-029831:notes:2]

[0001564590-19-003270:notes:3]
[same as prior period, unchanged from 0001564590-18-029831:notes:3]

[0001564590-19-003270:notes:4]
[same as prior period, unchanged from 0001564590-18-029831:notes:4]

[0001564590-19-003270:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 25, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-19-003270:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-19-003270:notes:7]
[same as prior period, unchanged from 0001564590-18-029831:notes:7]

[0001564590-19-003270:notes:8]
[same as prior period, unchanged from 0001564590-18-029831:notes:8]

[0001564590-19-003270:notes:9]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the first quarter of fiscal 2019, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets.

[0001564590-19-003270:notes:10]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the nine months ended January 26, 2018, as presented herein, has been restated to comply with the new requirements. Refer to Note 4 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

[0001564590-19-003270:notes:11]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 25, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-003270:notes:12]
[same as prior period, unchanged from 0001564590-18-029831:notes:12]

[0001564590-19-003270:notes:13]
[same as prior period, unchanged from 0001564590-18-029831:notes:13]

[0001564590-19-003270:notes:14]
| Balance as of April 27, 2018 |  | $ | 1,739 |  |
| Additions |  |  | 3 |  |
| Balance as of January 25, 2019 |  | $ | 1,742 |  |

[0001564590-19-003270:notes:15]
[same as prior period, unchanged from 0001564590-18-029831:notes:15]

[0001564590-19-003270:notes:16]
[same as prior period, unchanged from 0001564590-18-029831:notes:16]

[0001564590-19-003270:notes:17]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 160 |  |  | $ | (104 | ) |  | $ | 56 |  |  | $ | 164 |  |  | $ | (80 | ) |  | $ | 84 |  |
| Customer contracts/relationships |  |  | 41 |  |  |  | (41 | ) |  |  | — |  |  |  | 43 |  |  |  | (33 | ) |  |  | 10 |  |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9 |  |  |  | (9 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 201 |  |  | $ | (145 | ) |  | $ | 56 |  |  | $ | 216 |  |  | $ | (122 | ) |  | $ | 94 |  |

[0001564590-19-003270:notes:18]
[same as prior period, unchanged from 0001564590-18-029831:notes:18]

[0001564590-19-003270:notes:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | Operations Classification |
| Developed technology |  | $ | 10 |  |  | $ | 10 |  |  | $ | 28 |  |  | $ | 27 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | 3 |  |  |  | 10 |  |  |  | 11 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 3 |  |  | Operating expenses |
| Total |  | $ | 13 |  |  | $ | 14 |  |  | $ | 38 |  |  | $ | 41 |  |  |  |

[0001564590-19-003270:notes:20]
As of January 25, 2019, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-19-003270:notes:21]
| Fiscal Year |  | Amount |  |
| Remainder of 2019 |  | $ | 9 |  |
| 2020 |  |  | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 56 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-003270:notes:22]
[same as prior period, unchanged from 0001564590-18-029831:notes:22]

[0001564590-19-003270:notes:23]
[same as prior period, unchanged from 0001564590-18-029831:notes:23]

[0001564590-19-003270:notes:24]
[same as prior period, unchanged from 0001564590-18-029831:notes:24]

[0001564590-19-003270:notes:25]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Cash |  | $ | 2,162 |  |  | $ | 2,727 |  |
| Cash equivalents |  |  | 109 |  |  |  | 214 |  |
| Cash and cash equivalents |  | $ | 2,271 |  |  | $ | 2,941 |  |
| Short-term restricted cash |  |  | 4 |  |  |  | 5 |  |
| Long-term restricted cash |  |  | 1 |  |  |  | 1 |  |
| Restricted cash |  | $ | 5 |  |  | $ | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,276 |  |  | $ | 2,947 |  |

[0001564590-19-003270:notes:26]
[same as prior period, unchanged from 0001564590-18-029831:notes:26]

[0001564590-19-003270:notes:27]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Purchased components |  | $ | 11 |  |  | $ | 12 |  |
| Finished goods |  |  | 89 |  |  |  | 110 |  |
| Inventories |  | $ | 100 |  |  | $ | 122 |  |

[0001564590-19-003270:notes:28]
[same as prior period, unchanged from 0001564590-18-029831:notes:28]

[0001564590-19-003270:notes:29]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Land |  | $ | 106 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 605 |  |  |  | 594 |  |
| Leasehold improvements |  |  | 87 |  |  |  | 88 |  |
| Computer, production, engineering and other equipment |  |  | 806 |  |  |  | 733 |  |
| Computer software |  |  | 357 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 104 |  |  |  | 99 |  |
| Construction-in-progress |  |  | 6 |  |  |  | 27 |  |
|  |  |  | 2,071 |  |  |  | 2,004 |  |
| Accumulated depreciation and amortization |  |  | (1,308 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 763 |  |  | $ | 756 |  |

[0001564590-19-003270:notes:30]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land with a net book value of $52 million, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheets as of January 25, 2019 and April 27, 2018. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the completion of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-19-003270:notes:31]
[same as prior period, unchanged from 0001564590-18-029831:notes:31]

[0001564590-19-003270:notes:32]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Deferred tax assets |  | $ | 219 |  |  | $ | 229 |  |
| Other assets |  |  | 277 |  |  |  | 221 |  |
| Other non-current assets |  | $ | 496 |  |  | $ | 450 |  |

[0001564590-19-003270:notes:33]
[same as prior period, unchanged from 0001564590-18-029831:notes:33]

[0001564590-19-003270:notes:34]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Accrued compensation and benefits |  | $ | 334 |  |  | $ | 441 |  |
| Product warranty liabilities |  |  | 25 |  |  |  | 25 |  |
| Other current liabilities |  |  | 371 |  |  |  | 359 |  |
| Accrued expenses |  | $ | 730 |  |  | $ | 825 |  |

[0001564590-19-003270:notes:35]
[same as prior period, unchanged from 0001564590-18-029831:notes:35]

[0001564590-19-003270:notes:36]
[same as prior period, unchanged from 0001564590-18-029831:notes:36]

[0001564590-19-003270:notes:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 39 |  |  | $ | 44 |  |  | $ | 40 |  |  | $ | 50 |  |
| Expense accrued during the period |  |  | 6 |  |  |  | 3 |  |  |  | 16 |  |  |  | 11 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (6 | ) |  |  | (17 | ) |  |  | (20 | ) |
| Balance at end of period |  | $ | 39 |  |  | $ | 41 |  |  | $ | 39 |  |  | $ | 41 |  |

[0001564590-19-003270:notes:38]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Accrued expenses |  | $ | 25 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 14 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 39 |  |  | $ | 40 |  |

[0001564590-19-003270:notes:39]
[same as prior period, unchanged from 0001564590-18-029831:notes:39]

[0001564590-19-003270:notes:40]
[same as prior period, unchanged from 0001564590-18-029831:notes:40]

[0001564590-19-003270:notes:41]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Liability for uncertain tax positions |  | $ | 326 |  |  | $ | 314 |  |
| Income taxes payable |  |  | 476 |  |  |  | 549 |  |
| Product warranty liabilities |  |  | 14 |  |  |  | 15 |  |
| Other liabilities |  |  | 82 |  |  |  | 114 |  |
| Other long-term liabilities |  | $ | 898 |  |  | $ | 992 |  |

[0001564590-19-003270:notes:42]
[same as prior period, unchanged from 0001564590-18-029831:notes:42]

[0001564590-19-003270:notes:43]
[same as prior period, unchanged from 0001564590-18-029831:notes:43]

[0001564590-19-003270:notes:44]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 6 |  |  | $ | 19 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | — |  |  | $ | 130 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 150 |  |  | $ | 51 |  |
| Interest paid |  | $ | 41 |  |  | $ | 45 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-003270:notes:45]
[same as prior period, unchanged from 0001564590-18-029831:notes:45]

[0001564590-19-003270:notes:46]
[same as prior period, unchanged from 0001564590-18-029831:notes:46]

[0001564590-19-003270:notes:47]
[same as prior period, unchanged from 0001564590-18-029831:notes:47]

[0001564590-19-003270:notes:48]
[same as prior period, unchanged from 0001564590-18-029831:notes:48]

[0001564590-19-003270:notes:49]
[same as prior period, unchanged from 0001564590-18-029831:notes:49]

[0001564590-19-003270:notes:50]
[same as prior period, unchanged from 0001564590-18-029831:notes:50]

[0001564590-19-003270:notes:51]
[same as prior period, unchanged from 0001564590-18-029831:notes:51]

[0001564590-19-003270:notes:52]
[same as prior period, unchanged from 0001564590-18-029831:notes:52]

[0001564590-19-003270:notes:53]
[same as prior period, unchanged from 0001564590-18-029831:notes:53]

[0001564590-19-003270:notes:54]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the third quarter and first nine months of fiscal 2018:

[0001564590-19-003270:notes:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 26, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 32 |  |  | $ | 952 |  |  | $ | 2,450 |  |  | $ | 48 |  |  | $ | 2,498 |  |
| Software maintenance |  |  | 237 |  |  |  | (16 | ) |  |  | 221 |  |  |  | 711 |  |  |  | (43 | ) |  |  | 668 |  |
| Hardware maintenance and other services |  |  | 366 |  |  |  | — |  |  |  | 366 |  |  |  | 1,109 |  |  |  | — |  |  |  | 1,109 |  |
| Net revenues |  |  | 1,523 |  |  |  | 16 |  |  |  | 1,539 |  |  |  | 4,270 |  |  |  | 5 |  |  |  | 4,275 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 468 |  |  |  | 1 |  |  |  | 469 |  |  |  | 1,238 |  |  |  | 4 |  |  |  | 1,242 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Cost of hardware maintenance and other services |  |  | 108 |  |  |  | — |  |  |  | 108 |  |  |  | 336 |  |  |  | (2 | ) |  |  | 334 |  |
| Total cost of revenues |  |  | 582 |  |  |  | 1 |  |  |  | 583 |  |  |  | 1,593 |  |  |  | 2 |  |  |  | 1,595 |  |
| Gross profit |  |  | 941 |  |  |  | 15 |  |  |  | 956 |  |  |  | 2,677 |  |  |  | 3 |  |  |  | 2,680 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 423 |  |  |  | (4 | ) |  |  | 419 |  |  |  | 1,268 |  |  |  | (5 | ) |  |  | 1,263 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |  |  | 580 |  |  |  | — |  |  |  | 580 |  |
| General and administrative |  |  | 72 |  |  |  | — |  |  |  | 72 |  |  |  | 209 |  |  |  | — |  |  |  | 209 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 470 |  |  |  | (4 | ) |  |  | 466 |  |  |  | 1,839 |  |  |  | (5 | ) |  |  | 1,834 |  |
| Income from operations |  |  | 471 |  |  |  | 19 |  |  |  | 490 |  |  |  | 838 |  |  |  | 8 |  |  |  | 846 |  |
| Other income, net |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Income before income taxes |  |  | 485 |  |  |  | 19 |  |  |  | 504 |  |  |  | 863 |  |  |  | 8 |  |  |  | 871 |  |
| Provision for income taxes |  |  | 991 |  |  |  | (8 | ) |  |  | 983 |  |  |  | 1,058 |  |  |  | (13 | ) |  |  | 1,045 |  |
| Net loss |  | $ | (506 | ) |  | $ | 27 |  |  | $ | (479 | ) |  | $ | (195 | ) |  | $ | 21 |  |  | $ | (174 | ) |
| Net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Shares used in net loss per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |
| Diluted |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |

[0001564590-19-003270:notes:56]
[same as prior period, unchanged from 0001564590-18-029831:notes:56]

[0001564590-19-003270:notes:57]
[same as prior period, unchanged from 0001564590-18-029831:notes:57]

[0001564590-19-003270:notes:58]
[same as prior period, unchanged from 0001564590-18-029831:notes:58]

[0001564590-19-003270:notes:59]
[same as prior period, unchanged from 0001564590-18-029831:notes:59]

[0001564590-19-003270:notes:60]
[same as prior period, unchanged from 0001564590-18-029831:notes:60]

[0001564590-19-003270:notes:61]
[same as prior period, unchanged from 0001564590-18-029831:notes:61]

[0001564590-19-003270:notes:62]
[same as prior period, unchanged from 0001564590-18-029831:notes:62]

[0001564590-19-003270:notes:63]
[same as prior period, unchanged from 0001564590-18-029831:notes:63]

[0001564590-19-003270:notes:64]
[same as prior period, unchanged from 0001564590-18-029831:notes:64]

[0001564590-19-003270:notes:65]
[same as prior period, unchanged from 0001564590-18-029831:notes:65]

[0001564590-19-003270:notes:66]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Product revenues |  | $ | 967 |  |  | $ | 952 |  |  | $ | 2,755 |  |  | $ | 2,498 |  |
| Strategic |  | 674 |  |  | 657 |  |  |  | 1,935 |  |  |  | 1,721 |  |
| Mature |  | 293 |  |  | 295 |  |  |  | 820 |  |  |  | 777 |  |
| Software maintenance revenues |  | 239 |  |  | 221 |  |  |  | 704 |  |  | 668 |  |
| Hardware maintenance and other services revenues |  | 357 |  |  | 366 |  |  |  | 1,095 |  |  |  | 1,109 |  |
| Hardware maintenance support contracts |  | 292 |  |  | 300 |  |  |  | 898 |  |  |  | 904 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 197 |  |  |  | 205 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |

[0001564590-19-003270:notes:67]
[same as prior period, unchanged from 0001564590-18-029831:notes:67]

[0001564590-19-003270:notes:68]
[same as prior period, unchanged from 0001564590-18-029831:notes:68]

[0001564590-19-003270:notes:69]
[same as prior period, unchanged from 0001564590-18-029831:notes:69]

[0001564590-19-003270:notes:70]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 80 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,195 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 82 |  |  |  | 122 |  |
| Total |  | $ | 3,357 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,641 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,716 |  |  |  | 1,651 |  |
| Total |  | $ | 3,357 |  |  | $ | 3,363 |  |

[0001564590-19-003270:notes:71]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-19-003270:notes:72]
[same as prior period, unchanged from 0001564590-18-029831:notes:72]

[0001564590-19-003270:notes:73]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 1,820 |  |  |  | 1,730 |  |
| Revenue recognized during the period |  |  | (1,826 | ) |  |  | (1,800 | ) |
| Balance at end of period |  | $ | 3,357 |  |  | $ | 3,143 |  |

[0001564590-19-003270:notes:74]
During the nine months ended January 25, 2019 and January 26, 2018, we recognized $1,410 million and $1,466 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-19-003270:notes:75]
As of January 25, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,357 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-19-003270:notes:76]
[same as prior period, unchanged from 0001564590-18-029831:notes:76]

[0001564590-19-003270:notes:77]
[same as prior period, unchanged from 0001564590-18-029831:notes:77]

[0001564590-19-003270:notes:78]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 62 |  |  |  | 56 |  |
| Expense recognized during the period |  |  | (60 | ) |  |  | (49 | ) |
| Balance at end of period |  | $ | 139 |  |  | $ | 120 |  |

[0001564590-19-003270:notes:79]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 64 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 75 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 139 |  |  | $ | 137 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-19-003270:notes:80]
[same as prior period, unchanged from 0001564590-18-029831:notes:80]

[0001564590-19-003270:notes:81]
[same as prior period, unchanged from 0001564590-18-029831:notes:81]

[0001564590-19-003270:notes:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Interest income |  | $ | 22 |  |  | $ | 20 |  |  | $ | 68 |  |  | $ | 55 |  |
| Interest expense |  |  | (16 | ) |  |  | (17 | ) |  |  | (44 | ) |  |  | (47 | ) |
| Other income, net |  |  | 2 |  |  |  | 11 |  |  |  | 9 |  |  |  | 17 |  |
| Total other income, net |  | $ | 8 |  |  | $ | 14 |  |  | $ | 33 |  |  | $ | 25 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-003270:notes:83]
[same as prior period, unchanged from 0001564590-18-029831:notes:83]

[0001564590-19-003270:notes:84]
[same as prior period, unchanged from 0001564590-18-029831:notes:84]

[0001564590-19-003270:notes:85]
[same as prior period, unchanged from 0001564590-18-029831:notes:85]

[0001564590-19-003270:notes:86]
[same as prior period, unchanged from 0001564590-18-029831:notes:86]

[0001564590-19-003270:notes:87]
[same as prior period, unchanged from 0001564590-18-029831:notes:87]

[0001564590-19-003270:notes:88]
[same as prior period, unchanged from 0001564590-18-029831:notes:88]

[0001564590-19-003270:notes:89]
[same as prior period, unchanged from 0001564590-18-029831:notes:89]

[0001564590-19-003270:notes:90]
[same as prior period, unchanged from 0001564590-18-029831:notes:90]

[0001564590-19-003270:notes:91]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,523 |  |  | $ | — |  |  | $ | (34 | ) |  | $ | 1,489 |  |  | $ | 1,865 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 1,827 |  |
| U.S. Treasury and government debt securities |  |  | 283 |  |  |  | — |  |  |  | (2 | ) |  |  | 281 |  |  |  | 497 |  |  |  | — |  |  |  | (5 | ) |  |  | 492 |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 230 |  |  |  | — |  |  |  | — |  |  |  | 230 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |  |  | 115 |  |  |  | — |  |  |  | — |  |  |  | 115 |  |
| Mutual funds |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 1,955 |  |  | $ | — |  |  | $ | (36 | ) |  | $ | 1,919 |  |  | $ | 2,738 |  |  | $ | 1 |  |  | $ | (44 | ) |  | $ | 2,695 |  |

[0001564590-19-003270:notes:92]
As of January 25, 2019 and April 27, 2018, the unrealized losses on our available-for-sale investments were caused by market value declines as a result of increasing market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have determined that no other-than-temporary impairments were required to be recognized on these investments as of January 25, 2019 and April 27, 2018.

[0001564590-19-003270:notes:93]
The following table presents the contractual maturities of our debt investments as of January 25, 2019 (in millions):

[0001564590-19-003270:notes:94]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 676 |  |  | $ | 673 |  |
| Due after one year through five years |  |  | 697 |  |  |  | 685 |  |
| Due after five years through ten years |  |  | 550 |  |  |  | 529 |  |
|  |  | $ | 1,923 |  |  | $ | 1,887 |  |

[0001564590-19-003270:notes:95]
[same as prior period, unchanged from 0001564590-18-029831:notes:95]

[0001564590-19-003270:notes:96]
[same as prior period, unchanged from 0001564590-18-029831:notes:96]

[0001564590-19-003270:notes:97]
[same as prior period, unchanged from 0001564590-18-029831:notes:97]

[0001564590-19-003270:notes:98]
|  |  | January 25, 2019 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,162 |  |  | $ | 2,162 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,489 |  |  |  | — |  |  |  | 1,489 |  |
| U.S. Treasury and government debt securities |  |  | 281 |  |  |  | 147 |  |  |  | 134 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | 117 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,049 |  |  | $ | 2,309 |  |  | $ | 1,740 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 27 |  |  | $ | 27 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001564590-19-003270:notes:99]
[same as prior period, unchanged from 0001564590-18-029831:notes:99]

[0001564590-19-003270:notes:100]
[same as prior period, unchanged from 0001564590-18-029831:notes:100]

[0001564590-19-003270:notes:101]
[same as prior period, unchanged from 0001564590-18-029831:notes:101]

[0001564590-19-003270:notes:102]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 25, 2019 and April 27, 2018, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-19-003270:notes:103]
[same as prior period, unchanged from 0001564590-18-029831:notes:103]

[0001564590-19-003270:notes:104]
As of January 25, 2019 and April 27, 2018, the fair value of our long-term debt was approximately $1,523 million. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-003270:notes:105]
8. Financing Arrangements

[0001564590-19-003270:notes:106]
Long-Term Debt

[0001564590-19-003270:notes:107]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-19-003270:notes:108]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

[0001564590-19-003270:notes:109]
Senior Notes

[0001564590-19-003270:notes:110]
Our 2.00% Senior Notes and 3.30% Senior Notes, each with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-19-003270:notes:111]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 25, 2019, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-19-003270:notes:112]
As of January 25, 2019, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-19-003270:notes:113]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-19-003270:notes:114]
Commercial Paper Program and Credit Facility

[0001564590-19-003270:notes:115]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $164 million, a weighted-average interest rate of 2.87% and maturities ranging from 27 days to 36 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

[0001564590-19-003270:notes:116]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 25, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-19-003270:notes:117]
[same as prior period, unchanged from 0001564590-18-029831:notes:117]

[0001564590-19-003270:notes:118]
[same as prior period, unchanged from 0001564590-18-029831:notes:118]

[0001564590-19-003270:notes:119]
As of January 25, 2019, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-19-003270:notes:120]
[same as prior period, unchanged from 0001564590-18-029831:notes:120]

[0001564590-19-003270:notes:121]
[same as prior period, unchanged from 0001564590-18-029831:notes:121]

[0001564590-19-003270:notes:122]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 27, 2018 |  |  | 1 |  |  | $ | 31.19 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 25, 2019 |  |  | 1 |  |  | $ | 29.75 |  |  |  | 3.17 |  |  | $ | 17 |  |
| Exercisable as of January 25, 2019 |  |  | 1 |  |  | $ | 30.91 |  |  |  | 2.90 |  |  | $ | 15 |  |

[0001564590-19-003270:notes:123]
[same as prior period, unchanged from 0001564590-18-029831:notes:123]

[0001564590-19-003270:notes:124]
[same as prior period, unchanged from 0001564590-18-029831:notes:124]

[0001564590-19-003270:notes:125]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Intrinsic value of exercises |  | $ | 28 |  |  | $ | 29 |  |
| Proceeds received from exercises |  | $ | 23 |  |  | $ | 72 |  |
| Fair value of options vested |  | $ | 2 |  |  | $ | 6 |  |

[0001564590-19-003270:notes:126]
[same as prior period, unchanged from 0001564590-18-029831:notes:126]

[0001564590-19-003270:notes:127]
In the nine months ended January 25, 2019, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends the last day of fiscal 2021. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the current year, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of fiscal 2021. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three year period from fiscal 2019 through 2021. The fair values of these awards were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in the current year was $24 million, which is being recognized to compensation expense over the remaining applicable performance / service periods.

[0001564590-19-003270:notes:128]
[same as prior period, unchanged from 0001564590-18-029831:notes:128]

[0001564590-19-003270:notes:129]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |
| Granted |  |  | 3 |  |  | $ | 63.31 |  |
| Vested |  |  | (3 | ) |  | $ | 31.86 |  |
| Forfeited |  |  | (1 | ) |  | $ | 35.16 |  |
| Outstanding as of January 25, 2019 |  |  | 8 |  |  | $ | 45.12 |  |

[0001564590-19-003270:notes:130]
[same as prior period, unchanged from 0001564590-18-029831:notes:130]

[0001564590-19-003270:notes:131]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 92 |  |  | $ | 67 |  |

[0001564590-19-003270:notes:132]
[same as prior period, unchanged from 0001564590-18-029831:notes:132]

[0001564590-19-003270:notes:133]
[same as prior period, unchanged from 0001564590-18-029831:notes:133]

[0001564590-19-003270:notes:134]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Shares issued under the ESPP |  |  | 3 |  |  |  | 4 |  |
| Proceeds from issuance of shares |  | $ | 96 |  |  | $ | 85 |  |

[0001564590-19-003270:notes:135]
[same as prior period, unchanged from 0001564590-18-029831:notes:135]

[0001564590-19-003270:notes:136]
[same as prior period, unchanged from 0001564590-18-029831:notes:136]

[0001564590-19-003270:notes:137]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 3 |  |  |  | 8 |  |  |  | 8 |  |
| Sales and marketing |  |  | 19 |  |  |  | 16 |  |  |  | 52 |  |  |  | 53 |  |
| Research and development |  |  | 13 |  |  |  | 11 |  |  |  | 37 |  |  |  | 38 |  |
| General and administrative |  |  | 7 |  |  |  | 8 |  |  |  | 22 |  |  |  | 24 |  |
| Total stock-based compensation expense |  | $ | 43 |  |  | $ | 38 |  |  | $ | 121 |  |  | $ | 125 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 1 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 23 |  |

[0001564590-19-003270:notes:138]
As of January 25, 2019, total unrecognized compensation expense related to our equity awards was $316 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001564590-19-003270:notes:139]
[same as prior period, unchanged from 0001564590-18-029831:notes:139]

[0001564590-19-003270:notes:140]
[same as prior period, unchanged from 0001564590-18-029831:notes:140]

[0001564590-19-003270:notes:141]
The following table summarizes activity related to this program for the nine months ended January 25, 2019 (in millions, except per share amounts):

[0001564590-19-003270:notes:142]
| Number of shares repurchased |  |  | 22 |  |
| Average price per share |  | $ | 74.17 |  |
| Aggregate purchase price |  | $ | 1,611 |  |
| Remaining authorization at end of period |  | $ | 2,389 |  |

[0001564590-19-003270:notes:143]
The aggregate purchase price of our stock repurchases for the nine months ended January 25, 2019 consisted of $1,611 million of open market purchases, of which $898 million and $713 million were allocated to additional paid-in capital and retained earnings (accumulated deficit), respectively.

[0001564590-19-003270:notes:144]
Since the May 13, 2003 inception of our stock repurchase program through January 25, 2019, we repurchased a total of 306 million shares of our common stock at an average price of $36.72 per share, for an aggregate purchase price of $11.2 billion.

[0001564590-19-003270:notes:145]
[same as prior period, unchanged from 0001564590-18-029831:notes:145]

[0001564590-19-003270:notes:146]
[same as prior period, unchanged from 0001564590-18-029831:notes:146]

[0001564590-19-003270:notes:147]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Dividends per share declared |  | $ | 1.20 |  |  | $ | 0.60 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 306 |  |  | $ | 53 |  |
| Dividend payments allocated to retained earnings (accumulated deficit) |  | $ | — |  |  | $ | 108 |  |

[0001564590-19-003270:notes:148]
On February 13, 2019, we declared a cash dividend of $0.40 per share of common stock, payable on April 24, 2019 to holders of record as of the close of business on April 5, 2019. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-19-003270:notes:149]
[same as prior period, unchanged from 0001564590-18-029831:notes:149]

[0001564590-19-003270:notes:150]
[same as prior period, unchanged from 0001564590-18-029831:notes:150]

[0001564590-19-003270:notes:151]
| Balance as of April 27, 2018 |  | $ | (9 | ) |
| Cumulative-effect of new accounting principle |  |  | (51 | ) |
| Net income |  |  | 773 |  |
| Repurchases of common stock |  |  | (713 | ) |
| Balance as of January 25, 2019 |  | $ | — |  |

[0001564590-19-003270:notes:152]
[same as prior period, unchanged from 0001564590-18-029831:notes:152]

[0001564590-19-003270:notes:153]
[same as prior period, unchanged from 0001564590-18-029831:notes:153]

[0001564590-19-003270:notes:154]
[same as prior period, unchanged from 0001564590-18-029831:notes:154]

[0001564590-19-003270:notes:155]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Total |  |
| Balance as of April 27, 2018 |  | $ | (27 | ) |  | $ | — |  |  | $ | (43 | ) |  | $ | (70 | ) |
| Other comprehensive income (loss), net of tax |  |  | (4 | ) |  |  | — |  |  |  | 7 |  |  |  | 3 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Total other comprehensive loss |  |  | (4 | ) |  |  | (1 | ) |  |  | 7 |  |  |  | 2 |  |
| Balance as of January 25, 2019 |  | $ | (31 | ) |  | $ | (1 | ) |  | $ | (36 | ) |  | $ | (68 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-003270:notes:156]
[same as prior period, unchanged from 0001564590-18-029831:notes:156]

[0001564590-19-003270:notes:157]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 25, 2019 or April 27, 2018. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-19-003270:notes:158]
[same as prior period, unchanged from 0001564590-18-029831:notes:158]

[0001564590-19-003270:notes:159]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 183 |  |  | $ | — |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 52 |  |  | $ | 115 |  |
| Forward contracts purchased |  | $ | 345 |  |  | $ | 412 |  |

[0001564590-19-003270:notes:160]
[same as prior period, unchanged from 0001564590-18-029831:notes:160]

[0001564590-19-003270:notes:161]
[same as prior period, unchanged from 0001564590-18-029831:notes:161]

[0001564590-19-003270:notes:162]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (2 | ) |  | $ | (12 | ) |  | $ | 10 |  |  | $ | (13 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-003270:notes:163]
[same as prior period, unchanged from 0001564590-18-029831:notes:163]

[0001564590-19-003270:notes:164]
[same as prior period, unchanged from 0001564590-18-029831:notes:164]

[0001564590-19-003270:notes:165]
Management previously approved the November 2016 Plan, under which we reduced our global workforce by approximately 6%. We completed all workforce related activities under this plan as of the end of fiscal 2017. The remaining balance as of January 25, 2019 principally relates to lease obligations that will be paid over their remaining terms.

[0001564590-19-003270:notes:166]
[same as prior period, unchanged from 0001564590-18-029831:notes:166]

[0001564590-19-003270:notes:167]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
|  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |  | November 2016 Plan |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |  | $ | 13 |  |
| Net charges |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  | — |  |
| Cash payments |  |  | (18 | ) |  |  | (2 | ) |  |  | (20 | ) |  |  | (7 | ) |
| Balance at end of period |  | $ | 1 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-003270:notes:168]
[same as prior period, unchanged from 0001564590-18-029831:notes:168]

[0001564590-19-003270:notes:169]
[same as prior period, unchanged from 0001564590-18-029831:notes:169]

[0001564590-19-003270:notes:170]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Effective tax rates |  |  | 12.6 | % |  |  | 120.0 | % |

[0001564590-19-003270:notes:171]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for the nine months ended January 25, 2019 and January 26, 2018 were primarily related to the fiscal 2018 impacts of U.S. tax reform and the sale of certain buildings and land in Sunnyvale, California. Our effective tax rates in the current year were impacted by the adoption of the new revenue standard, the reduced federal income tax rate due to U.S. tax reform, and differences in discrete benefits for stock-based compensation expenses.

[0001564590-19-003270:notes:172]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. ASC 740, Income Taxes, requires companies to recognize the effect of the tax law changes in the period of enactment. However, the SEC staff issued Staff Accounting Bulletin 118, which allowed companies to record provisional amounts during a measurement period not to extend beyond one year from the TCJA enactment date.

[0001564590-19-003270:notes:173]
As a result of the U.S. federal corporate income tax rate change, effective as of January 1, 2018, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. During the third quarter of fiscal 2018, we recorded $117 million of tax expense related to all tax rate changes. Upon finalization of our provisional estimates during the third quarter of fiscal 2019, we recorded tax expense of $6 million related to deferred tax assets for equity-based compensation awards to our executives.

[0001564590-19-003270:notes:174]
The TCJA imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. In the third quarter of fiscal year 2018, we recorded a $739 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. In the third quarter of fiscal 2019, we finalized our computation of the transition tax and recorded a reduction of $5 million to our provisional estimate.

[0001564590-19-003270:notes:175]
We will continue to assess the impact of further guidance from federal and state tax authorities on our business and consolidated financial statements, and recognize any adjustments in the period in which they are determined.

[0001564590-19-003270:notes:176]
Under the TCJA, the global minimum tax on intangible income (“GMT”) provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules, or (ii) account for GMT in a company’s measurement of deferred taxes.  We have elected to recognize the GMT as a period cost.

[0001564590-19-003270:notes:177]
The effective tax rate for the nine months ended January 26, 2018 has been restated to reflect the retrospective application of the new revenue standard. During the nine months ended January 25, 2019, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new standard.

[0001564590-19-003270:notes:178]
As of January 25, 2019, we had $382 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $308 million would affect our provision for income taxes if recognized, and $326 million has been recorded in other long-term liabilities.

[0001564590-19-003270:notes:179]
[same as prior period, unchanged from 0001564590-18-029831:notes:175]

[0001564590-19-003270:notes:180]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. During March 2018, the Advocate General issued an opinion which was largely in favor of NetApp, however, the CJEU is not bound by the opinion of the Advocate General. We expect that their ruling will be issued before the end of fiscal year 2019. Once this ruling has been issued, it will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will issue its final decision. We expect this decision to be issued by our fiscal year 2020.

[0001564590-19-003270:notes:181]
[same as prior period, unchanged from 0001564590-18-029831:notes:177]


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-003270:notes:182]
13. Net Income (Loss) per Share

[0001564590-19-003270:notes:183]
The following is a calculation of basic and diluted net income (loss) per share (in millions, except per share amounts):

[0001564590-19-003270:notes:184]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 249 |  |  | $ | (479 | ) |  | $ | 773 |  |  | $ | (174 | ) |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 250 |  |  |  | 268 |  |  |  | 257 |  |  |  | 269 |  |
| Dilutive impact of employee equity award plans |  |  | 5 |  |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Shares used in diluted computation |  |  | 255 |  |  |  | 268 |  |  |  | 263 |  |  |  | 269 |  |
| Net Income (Loss) per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.00 |  |  | $ | (1.79 | ) |  | $ | 3.01 |  |  | $ | (0.65 | ) |
| Diluted |  | $ | 0.98 |  |  | $ | (1.79 | ) |  | $ | 2.94 |  |  | $ | (0.65 | ) |

[0001564590-19-003270:notes:185]
Less than 1 million potential shares from outstanding employee equity awards were excluded from the diluted net income (loss) per share calculation for the three and nine months ended January 25, 2019. For the three and nine months ended January 26, 2018, 15 million and 17 million potential shares from outstanding awards, respectively, were excluded from the calculation as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-003270:notes:186]
[same as prior period, unchanged from 0001564590-18-029831:notes:182]

[0001564590-19-003270:notes:187]
[same as prior period, unchanged from 0001564590-18-029831:notes:183]

[0001564590-19-003270:notes:188]
[same as prior period, unchanged from 0001564590-18-029831:notes:184]

[0001564590-19-003270:notes:189]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| United States, Canada and Latin America (Americas) |  | $ | 814 |  |  | $ | 809 |  |  | $ | 2,525 |  |  | $ | 2,322 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 523 |  |  |  | 509 |  |  |  | 1,382 |  |  |  | 1,336 |  |
| Asia Pacific (APAC) |  |  | 226 |  |  |  | 221 |  |  |  | 647 |  |  |  | 617 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |

[0001564590-19-003270:notes:190]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $744 million and $731 million during the three months ended January 25, 2019 and January 26, 2018, respectively, and were $2,294 million and 2,092 million during the nine months ended January 25, 2019 and January 26, 2018, respectively.

[0001564590-19-003270:notes:191]
[same as prior period, unchanged from 0001564590-18-029831:notes:187]

[0001564590-19-003270:notes:192]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 254 |  |  | $ | 853 |  |
| International |  |  | 3,795 |  |  |  | 4,538 |  |
| Total |  | $ | 4,049 |  |  | $ | 5,391 |  |

[0001564590-19-003270:notes:193]
[same as prior period, unchanged from 0001564590-18-029831:notes:189]

[0001564590-19-003270:notes:194]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 578 |  |  | $ | 566 |  |
| International |  |  | 185 |  |  |  | 190 |  |
| Total |  | $ | 763 |  |  | $ | 756 |  |

[0001564590-19-003270:notes:195]
[same as prior period, unchanged from 0001564590-18-029831:notes:191]

[0001564590-19-003270:notes:196]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 22 | % |  |  | 24 | % |  |  | 22 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 19 | % |  |  | 19 | % |  |  | 20 | % |

[0001564590-19-003270:notes:197]
[same as prior period, unchanged from 0001564590-18-029831:notes:193]

[0001564590-19-003270:notes:198]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 17 | % |
| Tech Data Corporation |  |  | 16 | % |  |  | 17 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-003270:notes:199]
15. Commitments and Contingencies

[0001564590-19-003270:notes:200]
Operating Leases

[0001564590-19-003270:notes:201]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $164 million as of January 25, 2019.

[0001564590-19-003270:notes:202]
Purchase Orders and Other Commitments

[0001564590-19-003270:notes:203]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 25, 2019, we had $501 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2019 and April 27, 2018, such liability amounted to $17 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-003270:notes:204]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 25, 2019, we had $4 million in construction related obligations and $220 million in other purchase obligations.

[0001564590-19-003270:notes:205]
Financing Guarantees

[0001564590-19-003270:notes:206]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $54 million and $62 million of receivables during the nine months ended January 25, 2019 and January 26, 2018, respectively.

[0001564590-19-003270:notes:207]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-19-003270:notes:208]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 25, 2019 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-003270:notes:209]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-19-003270:notes:210]
Legal Contingencies

[0001564590-19-003270:notes:211]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-19-003270:notes:212]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-19-003270:notes:213]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 25, 2019 related to such matters.
