# NTAP note change history — 0001564590-18-029831 → 0001564590-19-003270


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0001564590-19-003270:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $164 million as of January 25, 2019.
  (was, 2018-11-19, similarity 0.971):
[0001564590-18-029831:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $172 million as of October 26, 2018.

- changed (2019-02-19):
[0001564590-19-003270:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 25, 2019, we had $501 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2019 and April 27, 2018, such liability amounted to $17 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2018-11-19, similarity 0.9859):
[0001564590-18-029831:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 26, 2018, we had $422 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2018 and April 27, 2018, such liability amounted to $16 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2019-02-19):
[0001564590-19-003270:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 25, 2019, we had $4 million in construction related obligations and $220 million in other purchase obligations.
  (was, 2018-11-19, similarity 0.9809):
[0001564590-18-029831:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 26, 2018, we had $5 million in construction related obligations and $187 million in other purchase obligations.

- changed (2019-02-19):
[0001564590-19-003270:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $54 million and $62 million of receivables during the nine months ended January 25, 2019 and January 26, 2018, respectively.
  (was, 2018-11-19, similarity 0.9689):
[0001564590-18-029831:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $43 million and $49 million of receivables during the six months ended October 26, 2018 and October 27, 2017, respectively.

- changed (2019-02-19):
[0001564590-19-003270:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 25, 2019 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2018-11-19, similarity 0.994):
[0001564590-18-029831:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of October 26, 2018 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2019-02-19):
[0001564590-19-003270:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2019-02-19):
[0001564590-19-003270:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 25, 2019 related to such matters.
  (was, 2018-11-19, similarity 0.9921):
[0001564590-18-029831:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 26, 2018 related to such matters.

- removed (2019-02-19):
[0001564590-18-029831:note_history:8]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0001564590-19-003270:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 25, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2018-11-19, similarity 0.8768):
[0001564590-18-029831:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 26, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2019-02-19):
[0001564590-19-003270:note_history:10]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the nine months ended January 26, 2018, as presented herein, has been restated to comply with the new requirements. Refer to Note 4 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.
  (was, 2018-11-19, similarity 0.6308):
[0001564590-18-029831:note_history:10]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the three and six months ended October 27, 2017, as presented herein, has been restated to comply with the new requirements. Refer to Note 4 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

- changed (2019-02-19):
[0001564590-19-003270:note_history:11]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 25, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.
  (was, 2018-11-19, similarity 0.9597):
[0001564590-18-029831:note_history:11]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 26, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0001564590-19-003270:note_history:12]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |
  (was, 2018-11-19, similarity 0.9916):
[0001564590-18-029831:note_history:12]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

- changed (2019-02-19):
[0001564590-19-003270:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 25, 2019, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2018-11-19, similarity 0.9892):
[0001564590-18-029831:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 26, 2018, we were in compliance with all covenants associated with the Senior Notes.

- changed (2019-02-19):
[0001564590-19-003270:note_history:14]
As of January 25, 2019, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2018-11-19, similarity 0.9362):
[0001564590-18-029831:note_history:14]
As of October 26, 2018, our aggregate future principal debt maturities are as follows (in millions):

- changed (2019-02-19):
[0001564590-19-003270:note_history:15]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $164 million, a weighted-average interest rate of 2.87% and maturities ranging from 27 days to 36 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.
  (was, 2018-11-19, similarity 0.9938):
[0001564590-18-029831:note_history:15]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $250 million, a weighted-average interest rate of 2.45% and maturities ranging from 4 days to 31 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

- changed (2019-02-19):
[0001564590-19-003270:note_history:16]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 25, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2018-11-19, similarity 0.9922):
[0001564590-18-029831:note_history:16]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 26, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0001564590-19-003270:note_history:17]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |
  (was, 2018-11-19, similarity 0.9916):
[0001564590-18-029831:note_history:17]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0001564590-19-003270:note_history:18]
As of January 25, 2019, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2018-11-19, similarity 0.9362):
[0001564590-18-029831:note_history:18]
As of October 26, 2018, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-02-19):
[0001564590-19-003270:note_history:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Product revenues |  | $ | 967 |  |  | $ | 952 |  |  | $ | 2,755 |  |  | $ | 2,498 |  |
| Strategic |  | 674 |  |  | 657 |  |  |  | 1,935 |  |  |  | 1,721 |  |
| Mature |  | 293 |  |  | 295 |  |  |  | 820 |  |  |  | 777 |  |
| Software maintenance revenues |  | 239 |  |  | 221 |  |  |  | 704 |  |  | 668 |  |
| Hardware maintenance and other services revenues |  | 357 |  |  | 366 |  |  |  | 1,095 |  |  |  | 1,109 |  |
| Hardware maintenance support contracts |  | 292 |  |  | 300 |  |  |  | 898 |  |  |  | 904 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 197 |  |  |  | 205 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |

- removed (2019-02-19):
[0001564590-18-029831:note_history:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Product revenues |  | $ | 913 |  |  | $ | 819 |  |  | $ | 1,788 |  |  | $ | 1,546 |  |
| Strategic |  | 649 |  |  | 566 |  |  |  | 1,261 |  |  |  | 1,064 |  |
| Mature |  | 264 |  |  | 253 |  |  |  | 527 |  |  |  | 482 |  |
| Software maintenance revenues |  | 236 |  |  | 224 |  |  |  | 465 |  |  | 447 |  |
| Hardware maintenance and other services revenues |  | 368 |  |  | 372 |  |  |  | 738 |  |  | 743 |  |
| Hardware maintenance support contracts |  | 303 |  |  | 306 |  |  |  | 606 |  |  |  | 604 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 132 |  |  |  | 139 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0001564590-19-003270:note_history:21]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the third quarter and first nine months of fiscal 2018:
  (was, 2018-11-19, similarity 0.953):
[0001564590-18-029831:note_history:21]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the second quarter and first six months of fiscal 2018:

- added (2019-02-19):
[0001564590-19-003270:note_history:22]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 26, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 32 |  |  | $ | 952 |  |  | $ | 2,450 |  |  | $ | 48 |  |  | $ | 2,498 |  |
| Software maintenance |  |  | 237 |  |  |  | (16 | ) |  |  | 221 |  |  |  | 711 |  |  |  | (43 | ) |  |  | 668 |  |
| Hardware maintenance and other services |  |  | 366 |  |  |  | — |  |  |  | 366 |  |  |  | 1,109 |  |  |  | — |  |  |  | 1,109 |  |
| Net revenues |  |  | 1,523 |  |  |  | 16 |  |  |  | 1,539 |  |  |  | 4,270 |  |  |  | 5 |  |  |  | 4,275 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 468 |  |  |  | 1 |  |  |  | 469 |  |  |  | 1,238 |  |  |  | 4 |  |  |  | 1,242 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Cost of hardware maintenance and other services |  |  | 108 |  |  |  | — |  |  |  | 108 |  |  |  | 336 |  |  |  | (2 | ) |  |  | 334 |  |
| Total cost of revenues |  |  | 582 |  |  |  | 1 |  |  |  | 583 |  |  |  | 1,593 |  |  |  | 2 |  |  |  | 1,595 |  |
| Gross profit |  |  | 941 |  |  |  | 15 |  |  |  | 956 |  |  |  | 2,677 |  |  |  | 3 |  |  |  | 2,680 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 423 |  |  |  | (4 | ) |  |  | 419 |  |  |  | 1,268 |  |  |  | (5 | ) |  |  | 1,263 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |  |  | 580 |  |  |  | — |  |  |  | 580 |  |
| General and administrative |  |  | 72 |  |  |  | — |  |  |  | 72 |  |  |  | 209 |  |  |  | — |  |  |  | 209 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 470 |  |  |  | (4 | ) |  |  | 466 |  |  |  | 1,839 |  |  |  | (5 | ) |  |  | 1,834 |  |
| Income from operations |  |  | 471 |  |  |  | 19 |  |  |  | 490 |  |  |  | 838 |  |  |  | 8 |  |  |  | 846 |  |
| Other income, net |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Income before income taxes |  |  | 485 |  |  |  | 19 |  |  |  | 504 |  |  |  | 863 |  |  |  | 8 |  |  |  | 871 |  |
| Provision for income taxes |  |  | 991 |  |  |  | (8 | ) |  |  | 983 |  |  |  | 1,058 |  |  |  | (13 | ) |  |  | 1,045 |  |
| Net loss |  | $ | (506 | ) |  | $ | 27 |  |  | $ | (479 | ) |  | $ | (195 | ) |  | $ | 21 |  |  | $ | (174 | ) |
| Net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Shares used in net loss per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |
| Diluted |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |

- added (2019-02-19):
[0001564590-19-003270:note_history:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Product revenues |  | $ | 967 |  |  | $ | 952 |  |  | $ | 2,755 |  |  | $ | 2,498 |  |
| Strategic |  | 674 |  |  | 657 |  |  |  | 1,935 |  |  |  | 1,721 |  |
| Mature |  | 293 |  |  | 295 |  |  |  | 820 |  |  |  | 777 |  |
| Software maintenance revenues |  | 239 |  |  | 221 |  |  |  | 704 |  |  | 668 |  |
| Hardware maintenance and other services revenues |  | 357 |  |  | 366 |  |  |  | 1,095 |  |  |  | 1,109 |  |
| Hardware maintenance support contracts |  | 292 |  |  | 300 |  |  |  | 898 |  |  |  | 904 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 197 |  |  |  | 205 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |

- changed (2019-02-19):
[0001564590-19-003270:note_history:24]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 80 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,195 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 82 |  |  |  | 122 |  |
| Total |  | $ | 3,357 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,641 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,716 |  |  |  | 1,651 |  |
| Total |  | $ | 3,357 |  |  | $ | 3,363 |  |
  (was, 2018-11-19, similarity 0.9812):
[0001564590-18-029831:note_history:24]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 102 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,010 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 94 |  |  |  | 122 |  |
| Total |  | $ | 3,206 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,538 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,668 |  |  |  | 1,651 |  |
| Total |  | $ | 3,206 |  |  | $ | 3,363 |  |

- added (2019-02-19):
[0001564590-19-003270:note_history:25]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 1,820 |  |  |  | 1,730 |  |
| Revenue recognized during the period |  |  | (1,826 | ) |  |  | (1,800 | ) |
| Balance at end of period |  | $ | 3,357 |  |  | $ | 3,143 |  |

- changed (2019-02-19):
[0001564590-19-003270:note_history:26]
During the nine months ended January 25, 2019 and January 26, 2018, we recognized $1,410 million and $1,466 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.
  (was, 2018-11-19, similarity 0.8912):
[0001564590-18-029831:note_history:26]
During the six months ended October 26, 2018 and October 27, 2017, we recognized $1,019 million and $1,017 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- changed (2019-02-19):
[0001564590-19-003270:note_history:27]
As of January 25, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,357 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.
  (was, 2018-11-19, similarity 0.9905):
[0001564590-18-029831:note_history:27]
As of October 26, 2018, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,206 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 48% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 27% in the next 13 to 24 months, and the remainder thereafter.

- added (2019-02-19):
[0001564590-19-003270:note_history:28]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 62 |  |  |  | 56 |  |
| Expense recognized during the period |  |  | (60 | ) |  |  | (49 | ) |
| Balance at end of period |  | $ | 139 |  |  | $ | 120 |  |

- changed (2019-02-19):
[0001564590-19-003270:note_history:29]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 64 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 75 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 139 |  |  | $ | 137 |  |
  (was, 2018-11-19, similarity 0.9684):
[0001564590-18-029831:note_history:29]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 61 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 70 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 131 |  |  | $ | 137 |  |

- removed (2019-02-19):
[0001564590-18-029831:note_history:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 27, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 807 |  |  | $ | 12 |  |  | $ | 819 |  |  | $ | 1,530 |  |  | $ | 16 |  |  | $ | 1,546 |  |
| Software maintenance |  |  | 240 |  |  |  | (16 | ) |  |  | 224 |  |  |  | 474 |  |  |  | (27 | ) |  |  | 447 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | (3 | ) |  |  | 372 |  |  |  | 743 |  |  |  | — |  |  |  | 743 |  |
| Net revenues |  |  | 1,422 |  |  |  | (7 | ) |  |  | 1,415 |  |  |  | 2,747 |  |  |  | (11 | ) |  |  | 2,736 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 399 |  |  |  | (2 | ) |  |  | 397 |  |  |  | 770 |  |  |  | 3 |  |  |  | 773 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Cost of hardware maintenance and other services |  |  | 115 |  |  |  | (3 | ) |  |  | 112 |  |  |  | 228 |  |  |  | (2 | ) |  |  | 226 |  |
| Total cost of revenues |  |  | 520 |  |  |  | (5 | ) |  |  | 515 |  |  |  | 1,011 |  |  |  | 1 |  |  |  | 1,012 |  |
| Gross profit |  |  | 902 |  |  |  | (2 | ) |  |  | 900 |  |  |  | 1,736 |  |  |  | (12 | ) |  |  | 1,724 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 420 |  |  |  | 1 |  |  |  | 421 |  |  |  | 845 |  |  |  | (1 | ) |  |  | 844 |  |
| Research and development |  |  | 194 |  |  |  | — |  |  |  | 194 |  |  |  | 387 |  |  |  | — |  |  |  | 387 |  |
| General and administrative |  |  | 69 |  |  |  | — |  |  |  | 69 |  |  |  | 137 |  |  |  | — |  |  |  | 137 |  |
| Total operating expenses |  |  | 683 |  |  |  | 1 |  |  |  | 684 |  |  |  | 1,369 |  |  |  | (1 | ) |  |  | 1,368 |  |
| Income from operations |  |  | 219 |  |  |  | (3 | ) |  |  | 216 |  |  |  | 367 |  |  |  | (11 | ) |  |  | 356 |  |
| Other income, net |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 11 |  |  |  | — |  |  |  | 11 |  |
| Income before income taxes |  |  | 225 |  |  |  | (3 | ) |  |  | 222 |  |  |  | 378 |  |  |  | (11 | ) |  |  | 367 |  |
| Provision for income taxes |  |  | 50 |  |  |  | (2 | ) |  |  | 48 |  |  |  | 67 |  |  |  | (5 | ) |  |  | 62 |  |
| Net income |  | $ | 175 |  |  | $ | (1 | ) |  | $ | 174 |  |  | $ | 311 |  |  | $ | (6 | ) |  | $ | 305 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | — |  |  | $ | 0.65 |  |  | $ | 1.15 |  |  | $ | (0.02 | ) |  | $ | 1.13 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |  | $ | 1.12 |  |  | $ | (0.02 | ) |  | $ | 1.10 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |  |  | 277 |  |  |  | 277 |  |  |  | 277 |  |

- removed (2019-02-19):
[0001564590-18-029831:note_history:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Product revenues |  | $ | 913 |  |  | $ | 819 |  |  | $ | 1,788 |  |  | $ | 1,546 |  |
| Strategic |  | 649 |  |  | 566 |  |  |  | 1,261 |  |  |  | 1,064 |  |
| Mature |  | 264 |  |  | 253 |  |  |  | 527 |  |  |  | 482 |  |
| Software maintenance revenues |  | 236 |  |  | 224 |  |  |  | 465 |  |  | 447 |  |
| Hardware maintenance and other services revenues |  | 368 |  |  | 372 |  |  |  | 738 |  |  | 743 |  |
| Hardware maintenance support contracts |  | 303 |  |  | 306 |  |  |  | 606 |  |  |  | 604 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 132 |  |  |  | 139 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |

- removed (2019-02-19):
[0001564590-18-029831:note_history:32]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 1,067 |  |  |  | 1,031 |  |
| Revenue recognized during the period |  |  | (1,224 | ) |  |  | (1,185 | ) |
| Balance at end of period |  | $ | 3,206 |  |  | $ | 3,059 |  |

- removed (2019-02-19):
[0001564590-18-029831:note_history:33]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 35 |  |  |  | 34 |  |
| Expense recognized during the period |  |  | (41 | ) |  |  | (32 | ) |
| Balance at end of period |  | $ | 131 |  |  | $ | 115 |  |
