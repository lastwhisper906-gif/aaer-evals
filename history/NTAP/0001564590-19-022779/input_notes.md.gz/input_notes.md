# NTAP notes — 0001564590-19-022779


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-19-022779:notes:1]
1. Description of Business and Significant Accounting Policies

[0001564590-19-022779:notes:2]
Description of Business — NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-19-022779:notes:3]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2019, which ended on April 26, 2019, fiscal year 2018, which ended on April 27, 2018, and fiscal year 2017, which ended on April 28, 2017, were each 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-19-022779:notes:4]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-19-022779:notes:5]
Accounting Changes

[0001564590-19-022779:notes:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the first quarter of fiscal 2019, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior periods consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 7 – Revenue for a summary of the impacts of adopting this standard.

[0001564590-19-022779:notes:7]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the first quarter of fiscal 2019, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our consolidated balance sheets.

[0001564590-19-022779:notes:8]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our consolidated statements of cash flows for fiscal 2018 and fiscal 2017, as presented herein, have been restated to comply with the new requirements. Refer to Note 6 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

[0001564590-19-022779:notes:9]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-19-022779:notes:10]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-19-022779:notes:11]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities, commercial paper and certificates of deposit. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-19-022779:notes:12]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses on our available-for-sale investments are calculated based on the specific identification method.

[0001564590-19-022779:notes:13]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-19-022779:notes:14]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-19-022779:notes:15]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-19-022779:notes:16]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-19-022779:notes:17]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-19-022779:notes:18]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-19-022779:notes:19]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-19-022779:notes:20]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-19-022779:notes:21]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-19-022779:notes:22]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-19-022779:notes:23]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are amortized on a straight-line basis over their economic lives of three to six years for developed technology, two to eight years for customer contracts/relationships, two to three years for covenants not to compete and two to seven years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001564590-19-022779:notes:24]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have a single reporting unit. The performance of the quantitative impairment test requires comparing the fair value of our reporting unit to its carrying amount, including goodwill. The fair value of our reporting unit is based on our entity level market capitalization, as determined through quoted market prices. An impairment exists if the fair value of our reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of our reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of goodwill. The fair value of our reporting unit has substantially exceeded its carrying amount in all periods presented.

[0001564590-19-022779:notes:25]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.

[0001564590-19-022779:notes:26]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0001564590-19-022779:notes:27]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001564590-19-022779:notes:28]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of operations. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss, as well as changes in the fair value of the derivative’s time value (which are excluded from the assessment of hedge effectiveness), are recognized in earnings.

[0001564590-19-022779:notes:29]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001564590-19-022779:notes:30]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0001564590-19-022779:notes:31]
|  | • | Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria: |

[0001564590-19-022779:notes:32]
|  | - | It is enforceable |

[0001564590-19-022779:notes:33]
|  | - | It defines each party’s rights |

[0001564590-19-022779:notes:34]
|  | - | It identifies the payment terms |

[0001564590-19-022779:notes:35]
|  | - | It has commercial substance, and |

[0001564590-19-022779:notes:36]
|  | - | We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay |

[0001564590-19-022779:notes:37]
|  | • | Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct. |

[0001564590-19-022779:notes:38]
|  | • | Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer. |

[0001564590-19-022779:notes:39]
|  | • | Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation. |

[0001564590-19-022779:notes:40]
|  | • | Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time. |

[0001564590-19-022779:notes:41]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0001564590-19-022779:notes:42]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0001564590-19-022779:notes:43]
Our contracts with customers may include hardware systems, software licenses, software maintenance, hardware maintenance and other services. Software maintenance contracts entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware maintenance services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0001564590-19-022779:notes:44]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct if it is capable of being distinct, where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, meaning the transfer of the good or service is separately identifiable from other promises in the contract.

[0001564590-19-022779:notes:45]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. A configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware maintenance, software maintenance, and different types of professional services are each separate performance obligations.

[0001564590-19-022779:notes:46]
In certain instances, we enter into enterprise license agreements (ELAs) with our customers which transfer to them the right to deploy an unlimited or capped number of OS or optional add-on software licenses and obligate us to provide software maintenance through the ELA term. In general, we treat the software license component and software maintenance component of ELAs as separate performance obligations.

[0001564590-19-022779:notes:47]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell professional services either on a time and materials basis or under fixed price projects.

[0001564590-19-022779:notes:48]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0001564590-19-022779:notes:49]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information such as market data and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0001564590-19-022779:notes:50]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward completion of the performance obligation. Our stand-ready services, including both hardware and software maintenance support, are transferred ratably over the period of the contract. For other services such as our fixed professional services contracts, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0001564590-19-022779:notes:51]
Deferred Commissions – We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of operations.

[0001564590-19-022779:notes:52]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, and estimated materials, distribution and labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-19-022779:notes:53]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.

[0001564590-19-022779:notes:54]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-19-022779:notes:55]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-19-022779:notes:56]
The fair value of employee time-based RSUs is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0001564590-19-022779:notes:57]
The fair value of each award is estimated on the grant date and is not remeasured as a result of subsequent stock price fluctuations. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-19-022779:notes:58]
We account for forfeitures of stock-based awards as they occur.

[0001564590-19-022779:notes:59]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001564590-19-022779:notes:60]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying consolidated statements of operations.

[0001564590-19-022779:notes:61]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0001564590-19-022779:notes:62]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-19-022779:notes:63]
3. Concentration of Risk

[0001564590-19-022779:notes:64]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001564590-19-022779:notes:65]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-19-022779:notes:66]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-19-022779:notes:67]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-022779:notes:68]
4. Business Combinations

[0001564590-19-022779:notes:69]
Fiscal 2019 Acquisition

[0001564590-19-022779:notes:70]
On September 17, 2018, we acquired all of the outstanding shares of a privately-held software company for $3 million in cash. Substantially all of the purchase price was recorded to goodwill.

[0001564590-19-022779:notes:71]
Fiscal 2018 Acquisitions

[0001564590-19-022779:notes:72]
On August 4, 2017, we acquired all of the outstanding shares of Greenqloud ehf., a privately-held provider of cloud management software based in Iceland, for $51 million in cash, of which we allocated $10 million to developed technology, $38 million to goodwill, and the remainder to other assets.

[0001564590-19-022779:notes:73]
On June 15, 2017, we acquired all of the outstanding shares of Plexistor Ltd., a privately-held provider of software defined memory architecture based in Israel, for $24 million in cash, of which we allocated $6 million to developed technology, $17 million to goodwill, and the remainder to other assets.

[0001564590-19-022779:notes:74]
Fiscal 2017 Acquisition

[0001564590-19-022779:notes:75]
On March 24, 2017, we acquired all of the outstanding shares of a privately-held consulting and software development company for $8 million in cash. Substantially all of the purchase price was recorded to goodwill.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-022779:notes:76]
5. Goodwill and Purchased Intangible Assets, Net

[0001564590-19-022779:notes:77]
Goodwill activity is summarized as follows (in millions):

[0001564590-19-022779:notes:78]
| Balance as of April 28, 2017 |  | $ | 1,684 |  |
| Additions |  |  | 55 |  |
| Balance as of April 27, 2018 |  |  | 1,739 |  |
| Additions |  |  | 3 |  |
| Derecognition |  |  | (7 | ) |
| Balance as of April 26, 2019 |  | $ | 1,735 |  |

[0001564590-19-022779:notes:79]
We derecognized goodwill during fiscal 2019 in connection with our contribution of a group of assets to a newly formed joint venture with Lenovo in exchange for a non-controlling ownership interest in the new entity. Refer to Note 6 – Supplemental Financial Information for additional details.

[0001564590-19-022779:notes:80]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-19-022779:notes:81]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 160 |  |  | $ | (113 | ) |  | $ | 47 |  |  | $ | 164 |  |  | $ | (80 | ) |  | $ | 84 |  |
| Customer contracts/relationships |  |  | 41 |  |  |  | (41 | ) |  |  | — |  |  |  | 43 |  |  |  | (33 | ) |  |  | 10 |  |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9 |  |  |  | (9 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 201 |  |  | $ | (154 | ) |  | $ | 47 |  |  | $ | 216 |  |  | $ | (122 | ) |  | $ | 94 |  |

[0001564590-19-022779:notes:82]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-19-022779:notes:83]
|  |  | Year Ended |  |  | Statement of |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | Operations Classifications |
| Developed technology |  | $ | 36 |  |  | $ | 36 |  |  | $ | 29 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 10 |  |  |  | 14 |  |  |  | 14 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 3 |  |  |  | 5 |  |  | Operating expenses |
| Total |  | $ | 46 |  |  | $ | 53 |  |  | $ | 48 |  |  |  |

[0001564590-19-022779:notes:84]
As of April 26, 2019, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-19-022779:notes:85]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 47 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-022779:notes:86]
6. Supplemental Financial Information

[0001564590-19-022779:notes:87]
Cash and cash equivalents (in millions):

[0001564590-19-022779:notes:88]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statement of cash flows in accordance with our adoption of the ASU discussed in Note 1 – Description of Business and Significant Accounting Policies.

[0001564590-19-022779:notes:89]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Cash |  | $ | 2,216 |  |  | $ | 2,727 |  |
| Cash equivalents |  |  | 109 |  |  |  | 214 |  |
| Cash and cash equivalents |  | $ | 2,325 |  |  | $ | 2,941 |  |
| Short-term restricted cash |  |  | 5 |  |  |  | 5 |  |
| Long-term restricted cash |  |  | 1 |  |  |  | 1 |  |
| Restricted cash |  | $ | 6 |  |  | $ | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,331 |  |  | $ | 2,947 |  |

[0001564590-19-022779:notes:90]
Inventories (in millions):

[0001564590-19-022779:notes:91]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Purchased components |  | $ | 8 |  |  | $ | 12 |  |
| Finished goods |  |  | 123 |  |  |  | 110 |  |
| Inventories |  | $ | 131 |  |  | $ | 122 |  |

[0001564590-19-022779:notes:92]
Property and equipment, net (in millions):

[0001564590-19-022779:notes:93]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Land |  | $ | 106 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 605 |  |  |  | 594 |  |
| Leasehold improvements |  |  | 86 |  |  |  | 88 |  |
| Computer, production, engineering and other equipment |  |  | 817 |  |  |  | 733 |  |
| Computer software |  |  | 357 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 105 |  |  |  | 99 |  |
| Construction-in-progress |  |  | 10 |  |  |  | 27 |  |
|  |  |  | 2,086 |  |  |  | 2,004 |  |
| Accumulated depreciation and amortization |  |  | (1,327 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 759 |  |  | $ | 756 |  |

[0001564590-19-022779:notes:94]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, with a book value of $118 million, for a total of $306 million, through two separate and independent closings. Upon the completion of the first closing in fiscal 2018, we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million. The remaining properties, consisting of land with a net book value of $52 million, were classified as assets held-for-sale, and included as other current assets in our consolidated balance sheets as of April 26, 2019 and April 27, 2018. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the completion of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-19-022779:notes:95]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-19-022779:notes:96]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Depreciation and amortization expense |  | $ | 150 |  |  | $ | 145 |  |  | $ | 178 |  |

[0001564590-19-022779:notes:97]
Other non-current assets (in millions):

[0001564590-19-022779:notes:98]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Deferred tax assets |  | $ | 201 |  |  | $ | 229 |  |
| Other assets |  |  | 389 |  |  |  | 221 |  |
| Other non-current assets |  | $ | 590 |  |  | $ | 450 |  |

[0001564590-19-022779:notes:99]
During fiscal 2019, we formed a joint venture with Lenovo (Beijing) Information Technology Ltd. (“Lenovo”) in China and, in February 2019, contributed assets to the newly formed entity, Lenovo NetApp Technology Limited (“LNTL”), in exchange for a non-controlling 49% equity interest. The group of assets we contributed and derecognized met the definition of a business and included cash, fixed assets, customer relationships and an allocation of goodwill, with an aggregate book value of $7 million. The fair value of our equity interest in LNTL was determined using discounted cash flow techniques to be $80 million, resulting in a non-cash gain of $73 million. We accounted for our ownership interest as an equity method investment and have presented it in Other non-current assets on our consolidated balance sheet as of April 26, 2019. LNTL will be integral to our sales channels strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. It will also endeavor to localize our products and services, and to develop new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001564590-19-022779:notes:100]
Accrued expenses (in millions):

[0001564590-19-022779:notes:101]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Accrued compensation and benefits |  | $ | 433 |  |  | $ | 441 |  |
| Product warranty liabilities |  |  | 25 |  |  |  | 25 |  |
| Other current liabilities |  |  | 393 |  |  |  | 359 |  |
| Accrued expenses |  | $ | 851 |  |  | $ | 825 |  |

[0001564590-19-022779:notes:102]
Product warranty liabilities:

[0001564590-19-022779:notes:103]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-19-022779:notes:104]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Balance at beginning of period |  | $ | 40 |  |  | $ | 50 |  |
| Expense accrued during the period |  |  | 22 |  |  |  | 16 |  |
| Warranty costs incurred |  |  | (22 | ) |  |  | (26 | ) |
| Balance at end of period |  | $ | 40 |  |  | $ | 40 |  |

[0001564590-19-022779:notes:105]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Accrued expenses |  | $ | 25 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 40 |  |  | $ | 40 |  |

[0001564590-19-022779:notes:106]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-19-022779:notes:107]
Other long-term liabilities (in millions):

[0001564590-19-022779:notes:108]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Liability for uncertain tax positions |  | $ | 252 |  |  | $ | 314 |  |
| Income taxes payable |  |  | 447 |  |  |  | 549 |  |
| Product warranty liabilities |  |  | 15 |  |  |  | 15 |  |
| Other liabilities |  |  | 83 |  |  |  | 114 |  |
| Other long-term liabilities |  | $ | 797 |  |  | $ | 992 |  |

[0001564590-19-022779:notes:109]
Statements of cash flows additional information (in millions):

[0001564590-19-022779:notes:110]
Non-cash investing and financing activities and supplemental cash flow information are as follows:

[0001564590-19-022779:notes:111]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 9 |  |  | $ | 24 |  |  | $ | 19 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | — |  |  | $ | 130 |  |  | $ | 19 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 205 |  |  | $ | 87 |  |  | $ | 102 |  |
| Interest paid |  | $ | 53 |  |  | $ | 58 |  |  | $ | 44 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-022779:notes:112]
7. Revenue

[0001564590-19-022779:notes:113]
Effective our first quarter of fiscal 2019, we adopted ASC 606 using the full retrospective method and have restated each prior reporting period presented to conform to the new rules. Refer to Note 1 for a detailed discussion of accounting policies related to revenue recognition, including deferred commissions. The most significant impact of the new standard relates to our accounting for arrangements containing software. For our enterprise software license agreements (ELAs), we now recognize the license fee component of such arrangements up front. Under the prior rules, the software license fee was recognized over the term of the enterprise license based on our inability to establish vendor specific objective evidence of fair value for the undelivered software support element of these arrangements. In addition, for other software arrangements, revenue deferred for the undelivered elements that was previously allocated based on the residual method is now allocated based on relative fair value, which generally results in more software arrangement revenue being recognized earlier. The new standard also impacts our estimation of variable consideration for certain arrangements with contract terms such as rights of return, potential penalties and acceptance clauses.

[0001564590-19-022779:notes:114]
The following table presents the impacts of adoption of ASC 606 to select line items of our consolidated balance sheet as of the end of fiscal 2018:

[0001564590-19-022779:notes:115]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  | $ | 126 |  |  | $ | (4 | ) |  |  |  | $ | 122 |  |
| Other current assets |  | $ | 330 |  |  | $ | 62 |  |  | (2 | ) | $ | 392 |  |
| Other non-current assets |  | $ | 420 |  |  | $ | 30 |  |  | (2 | ) | $ | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  | $ | 961 |  |  | $ | 31 |  |  | (4 | ) | $ | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  | $ | 1,673 |  |  | $ | (22 | ) |  | (3 | ) | $ | 1,651 |  |
| Accumulated deficit |  | $ | (218 | ) |  | $ | 209 |  |  | (5 | ) | $ | (9 | ) |

[0001564590-19-022779:notes:116]
|  | (1) | Netting of accounts receivable and deferred revenue balances for certain customer arrangements has been updated to reflect the impact of adoption |

[0001564590-19-022779:notes:117]
|  | (2) | Reflects capitalization of commissions and reduction of long-term deferred tax assets |

[0001564590-19-022779:notes:118]
|  | (3) | Reflects cumulative change in revenue and the impact of adoption to the netting of accounts receivable and deferred revenue balances for certain customer arrangements |

[0001564590-19-022779:notes:119]
|  | (4) | Reflects increase in long-term deferred tax liabilities |

[0001564590-19-022779:notes:120]
|  | (5) | Reflects cumulative impact to net income of which $197 million was the cumulative-effect of adoption as of the beginning of fiscal 2017 |

[0001564590-19-022779:notes:121]
The following tables present the impacts of adoption of ASC 606 to our consolidated statements of operations for the fiscal 2018 and 2017:

[0001564590-19-022779:notes:122]
|  | Year Ended |  |
|  | April 27, 2018 |  |
|  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 3,461 |  |  | $ | 64 |  |  | $ | 3,525 |  |
| Software maintenance |  | 958 |  |  |  | (56 | ) |  |  | 902 |  |
| Hardware maintenance and other services |  | 1,492 |  |  |  | — |  |  |  | 1,492 |  |
| Net revenues |  | 5,911 |  |  |  | 8 |  |  |  | 5,919 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Cost of software maintenance |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Cost of hardware maintenance and other services |  | 449 |  |  |  | (2 | ) |  |  | 447 |  |
| Total cost of revenues |  | 2,212 |  |  |  | (2 | ) |  |  | 2,210 |  |
| Gross profit |  | 3,699 |  |  |  | 10 |  |  |  | 3,709 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 1,729 |  |  |  | (23 | ) |  |  | 1,706 |  |
| Research and development |  | 783 |  |  |  | — |  |  |  | 783 |  |
| General and administrative |  | 280 |  |  |  | — |  |  |  | 280 |  |
| Gain on sale or derecognition of assets |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  | 2,574 |  |  |  | (23 | ) |  |  | 2,551 |  |
| Income from operations |  | 1,125 |  |  |  | 33 |  |  |  | 1,158 |  |
| Other income, net |  | 41 |  |  |  | — |  |  |  | 41 |  |
| Income before income taxes |  | 1,166 |  |  |  | 33 |  |  |  | 1,199 |  |
| Provision for income taxes |  | 1,090 |  |  |  | (7 | ) |  |  | 1,083 |  |
| Net income | $ | 76 |  |  | $ | 40 |  |  | $ | 116 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.43 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.14 |  |  | $ | 0.42 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 268 |  |  |  | 268 |  |  |  | 268 |  |
| Diluted |  | 276 |  |  |  | 276 |  |  |  | 276 |  |

[0001564590-19-022779:notes:123]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,006 |  |  | $ | 54 |  |  | $ | 3,060 |  |
| Software maintenance |  |  | 965 |  |  |  | (60 | ) |  |  | 905 |  |
| Hardware maintenance and other services |  |  | 1,548 |  |  |  | (22 | ) |  |  | 1,526 |  |
| Net revenues |  |  | 5,519 |  |  |  | (28 | ) |  |  | 5,491 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 1,614 |  |  |  | (2 | ) |  |  | 1,612 |  |
| Cost of software maintenance |  |  | 28 |  |  |  | — |  |  |  | 28 |  |
| Cost of hardware maintenance and other services |  |  | 487 |  |  |  | — |  |  |  | 487 |  |
| Total cost of revenues |  |  | 2,129 |  |  |  | (2 | ) |  |  | 2,127 |  |
| Gross profit |  |  | 3,390 |  |  |  | (26 | ) |  |  | 3,364 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 1,633 |  |  |  | 18 |  |  |  | 1,651 |  |
| Research and development |  |  | 779 |  |  |  | — |  |  |  | 779 |  |
| General and administrative |  |  | 271 |  |  |  | — |  |  |  | 271 |  |
| Restructuring charges |  |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |
| Total operating expenses |  |  | 2,725 |  |  |  | 18 |  |  |  | 2,743 |  |
| Income from operations |  |  | 665 |  |  |  | (44 | ) |  |  | 621 |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |
| Income before income taxes |  |  | 665 |  |  |  | (44 | ) |  |  | 621 |  |
| Provision for income taxes |  |  | 156 |  |  |  | (16 | ) |  |  | 140 |  |
| Net income |  | $ | 509 |  |  | $ | (28 | ) |  | $ | 481 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.85 |  |  | $ | (0.10 | ) |  | $ | 1.75 |  |
| Diluted |  | $ | 1.81 |  |  | $ | (0.10 | ) |  | $ | 1.71 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |
| Diluted |  |  | 281 |  |  |  | 281 |  |  |  | 281 |  |

[0001564590-19-022779:notes:124]
The adoption of ASC 606 had no impact to cash provided by or used in operating, investing or financing activities as presented on our consolidated statements of cash flows.

[0001564590-19-022779:notes:125]
Disaggregation of revenue

[0001564590-19-022779:notes:126]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we have historically grouped our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

[0001564590-19-022779:notes:127]
The following table depicts the disaggregation of revenue by our products and services (in millions):

[0001564590-19-022779:notes:128]
|  | Year Ended |  |
|  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Product revenues | $ | 3,755 |  |  | $ | 3,525 |  |  | $ | 3,060 |  |
| Strategic |  | 2,709 |  |  |  | 2,468 |  |  |  | 2,000 |  |
| Mature |  | 1,046 |  |  |  | 1,057 |  |  |  | 1,060 |  |
| Software maintenance revenues |  | 946 |  |  | 902 |  |  | 905 |  |
| Hardware maintenance and other services revenues |  | 1,445 |  |  |  | 1,492 |  |  |  | 1,526 |  |
| Hardware maintenance support contracts |  | 1,182 |  |  |  | 1,214 |  |  |  | 1,258 |  |
| Professional and other services |  | 263 |  |  |  | 278 |  |  |  | 268 |  |
| Net revenues | $ | 6,146 |  |  | $ | 5,919 |  |  | $ | 5,491 |  |

[0001564590-19-022779:notes:129]
Revenues by geographic region are presented in Note 16 – Segment, Geographic, and Significant Customer Information.

[0001564590-19-022779:notes:130]
Deferred revenue and financed unearned services revenue (in millions):

[0001564590-19-022779:notes:131]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our consolidated balance sheets (in millions):

[0001564590-19-022779:notes:132]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 84 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,502 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 82 |  |  |  | 122 |  |
| Total |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,825 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,843 |  |  |  | 1,651 |  |
| Total |  | $ | 3,668 |  |  | $ | 3,363 |  |

[0001564590-19-022779:notes:133]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 18 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-19-022779:notes:134]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

[0001564590-19-022779:notes:135]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 2,763 |  |  |  | 2,566 |  |
| Revenue recognized during the period |  |  | (2,458 | ) |  |  | (2,416 | ) |
| Balance at end of period |  | $ | 3,668 |  |  | $ | 3,363 |  |

[0001564590-19-022779:notes:136]
During the years ended April 26, 2019 and April 27, 2018, we recognized $1,722 million and $1,806 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-19-022779:notes:137]
As of April 26, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,668 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-19-022779:notes:138]
Deferred commissions

[0001564590-19-022779:notes:139]
As a result of our adoption of ASC 606, we capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized. We then amortize capitalized commissions based on the transfer of goods or services to which they relate. The following tables summarize the activity related to deferred commissions and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-19-022779:notes:140]
|  | Year Ended |  |
|  | April 26, 2019 |  |  | April 27, 2018 |  |
| Balance at beginning of period | $ | 137 |  |  | $ | 113 |  |
| Additions |  | 112 |  |  |  | 92 |  |
| Expense recognized during the period |  | (77 | ) |  |  | (68 | ) |
| Balance at end of period | $ | 172 |  |  | $ | 137 |  |

[0001564590-19-022779:notes:141]
|  | April 26, 2019 |  |  | April 27, 2018 |  |
| Other current assets | $ | 75 |  |  | $ | 66 |  |
| Other non-current assets |  | 97 |  |  |  | 71 |  |
| Total deferred commissions | $ | 172 |  |  | $ | 137 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-19-022779:notes:142]
8. Other income, net

[0001564590-19-022779:notes:143]
Other income, net consists of the following (in millions):

[0001564590-19-022779:notes:144]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Interest income |  | $ | 88 |  |  | $ | 79 |  |  | $ | 44 |  |
| Interest expense |  |  | (58 | ) |  |  | (62 | ) |  |  | (52 | ) |
| Other income, net |  |  | 17 |  |  |  | 24 |  |  |  | 8 |  |
| Other income, net |  | $ | 47 |  |  | $ | 41 |  |  | $ | — |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-022779:notes:145]
9. Financial Instruments and Fair Value Measurements

[0001564590-19-022779:notes:146]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-19-022779:notes:147]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-19-022779:notes:148]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-19-022779:notes:149]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-19-022779:notes:150]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-19-022779:notes:151]
Investments

[0001564590-19-022779:notes:152]
The following is a summary of our investments (in millions):

[0001564590-19-022779:notes:153]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,359 |  |  | $ | 2 |  |  | $ | (8 | ) |  | $ | 1,353 |  |  | $ | 1,865 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 1,827 |  |
| U.S. Treasury and government debt securities |  |  | 214 |  |  |  | — |  |  |  | (1 | ) |  |  | 213 |  |  |  | 497 |  |  |  | — |  |  |  | (5 | ) |  |  | 492 |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 230 |  |  |  | — |  |  |  | — |  |  |  | 230 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |  |  | 115 |  |  |  | — |  |  |  | — |  |  |  | 115 |  |
| Mutual funds |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 1,725 |  |  | $ | 2 |  |  | $ | (9 | ) |  | $ | 1,718 |  |  | $ | 2,738 |  |  | $ | 1 |  |  | $ | (44 | ) |  | $ | 2,695 |  |

[0001564590-19-022779:notes:154]
As of April 26, 2019 and April 27, 2018, the unrealized losses on our available-for-sale investments were caused by market value declines as a result of increasing market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have determined that no other-than-temporary impairments were required to be recognized on these investments as of April 26, 2019 or April 27, 2018.

[0001564590-19-022779:notes:155]
The following table presents the contractual maturities of our debt investments as of April 26, 2019 (in millions):

[0001564590-19-022779:notes:156]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 591 |  |  | $ | 589 |  |
| Due after one year through five years |  |  | 644 |  |  |  | 642 |  |
| Due after five years through ten years |  |  | 455 |  |  |  | 452 |  |
|  |  | $ | 1,690 |  |  | $ | 1,683 |  |

[0001564590-19-022779:notes:157]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-19-022779:notes:158]
Fair Value of Financial Instruments

[0001564590-19-022779:notes:159]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-19-022779:notes:160]
|  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,216 |  |  | $ | 2,216 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,353 |  |  |  | — |  |  |  | 1,353 |  |
| U.S. Treasury and government debt securities |  |  | 213 |  |  |  | 131 |  |  |  | 82 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | 117 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,899 |  |  | $ | 2,347 |  |  | $ | 1,552 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29 |  |  | $ | 29 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-19-022779:notes:161]
|  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,727 |  |  | $ | 2,727 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,827 |  |  |  | — |  |  |  | 1,827 |  |
| U.S. Treasury and government debt securities |  |  | 492 |  |  |  | 253 |  |  |  | 239 |  |
| Commercial paper |  |  | 230 |  |  |  | — |  |  |  | 230 |  |
| Certificates of deposit |  |  | 115 |  |  |  | — |  |  |  | 115 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,391 |  |  | $ | 2,980 |  |  | $ | 2,411 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 25 |  |  | $ | 25 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-19-022779:notes:162]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-19-022779:notes:163]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-19-022779:notes:164]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-19-022779:notes:165]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 26, 2019 and April 27, 2018, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-19-022779:notes:166]
Fair Value of Debt

[0001564590-19-022779:notes:167]
As of April 26, 2019 and April 27, 2018, the fair value of our long-term debt was approximately $1,553 million and $1,523 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-022779:notes:168]
10. Financing Arrangements

[0001564590-19-022779:notes:169]
Long-Term Debt

[0001564590-19-022779:notes:170]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-19-022779:notes:171]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,544 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (400 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

[0001564590-19-022779:notes:172]
Senior Notes

[0001564590-19-022779:notes:173]
Our 2.00% Senior Notes and 3.30% Senior Notes, each with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-19-022779:notes:174]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 26, 2019, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-19-022779:notes:175]
As of April 26, 2019, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-19-022779:notes:176]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-19-022779:notes:177]
Commercial Paper Program and Credit Facility

[0001564590-19-022779:notes:178]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $249 million, a weighted-average interest rate of 2.73% and maturities ranging from 27 days to 38 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

[0001564590-19-022779:notes:179]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 26, 2019, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-19-022779:notes:180]
Sale-leaseback Transactions

[0001564590-19-022779:notes:181]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates through December 31, 2017. These properties did not qualify for sale-leaseback accounting and as a result they were accounted for as financing transactions. During fiscal 2017, we terminated one of the leases and recorded a non-cash sale of properties with a net book value of $9 million, the extinguishment of $19 million in financing obligations, and a gain of $10 million. During fiscal 2018, we terminated the remaining leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million. There are no balances remaining on our consolidated balance sheets as of April 26, 2019 or April 27, 2018 associated with this sale-leaseback arrangement.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-19-022779:notes:182]
11. Stockholders’ Equity

[0001564590-19-022779:notes:183]
Equity Incentive Programs

[0001564590-19-022779:notes:184]
The 1999 Plan — As most recently amended on September 13, 2018, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. The Plan expires in August 2019, though activities required to extend it are currently in progress.

[0001564590-19-022779:notes:185]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the Plan generally vest over a four-year period. Options granted generally have a term of seven years after the grant date, subject to earlier termination upon the occurrence of certain events. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001564590-19-022779:notes:186]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock or restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-19-022779:notes:187]
During fiscal 2019, the shares reserved for issuance under the Plan were increased by 9 million shares of common stock. As of April 26, 2019, 28 million shares were available for grant under the Plan.

[0001564590-19-022779:notes:188]
Stock Options

[0001564590-19-022779:notes:189]
The following table summarizes information related to our stock options (in millions, except exercise price and contractual term):

[0001564590-19-022779:notes:190]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |
| Exercised |  |  | (3 | ) |  | $ | 25.61 |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 39.36 |  |
| Outstanding as of April 28, 2017 |  |  | 4 |  |  | $ | 35.76 |  |
| Exercised |  |  | (2 | ) |  | $ | 36.99 |  |
| Forfeited and expired |  |  | (1 | ) |  | $ | 40.50 |  |
| Outstanding as of April 27, 2018 |  |  | 1 |  |  | $ | 31.19 |  |
| Exercised |  |  | (1 | ) |  | $ | 32.50 |  |
| Forfeited and expired |  |  | — |  |  | N/A |  |
| Outstanding as of April 26, 2019 |  |  | — |  |  | N/A |  |
| Exercisable as of April 26, 2019 |  |  | — |  |  | N/A |  |

[0001564590-19-022779:notes:191]
__________________

[0001564590-19-022779:notes:192]
N/A - Not Applicable

[0001564590-19-022779:notes:193]
Additional information related to our stock options is summarized below (in millions):

[0001564590-19-022779:notes:194]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Intrinsic value of exercises |  | $ | 31 |  |  | $ | 37 |  |  | $ | 26 |  |
| Proceeds received from exercises |  | $ | 25 |  |  | $ | 88 |  |  | $ | 60 |  |
| Fair value of options vested |  | $ | 2 |  |  | $ | 8 |  |  | $ | 15 |  |

[0001564590-19-022779:notes:195]
Restricted Stock Units

[0001564590-19-022779:notes:196]
In fiscal 2019, 2018 and 2017, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends on the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in fiscal 2019, and all of the PBRSUs granted in fiscal 2018 and 2017, the number of shares issued   will depend upon our Total Stockholder Return (TSR) as compared to the TSR of an index that includes benchmark peers (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of these PBRSUs were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted in fiscal 2019, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three-year period from fiscal 2019 through 2021. The fair values of these PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in fiscal 2019, 2018 and 2017 was $24 million, $20 million and $15 million, respectively, and these amounts are being recognized to expense over the shorter of the remaining applicable performance or service periods.

[0001564590-19-022779:notes:197]
As of April 26, 2019 and April 27, 2018, there were approximately 1 million PBRSUs outstanding.

[0001564590-19-022779:notes:198]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-19-022779:notes:199]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |
| Granted |  |  | 5 |  |  | $ | 24.99 |  |
| Vested |  |  | (5 | ) |  | $ | 32.03 |  |
| Forfeited |  |  | (2 | ) |  | $ | 31.66 |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |
| Granted |  |  | 4 |  |  | $ | 39.74 |  |
| Vested |  |  | (5 | ) |  | $ | 30.59 |  |
| Forfeited |  |  | (1 | ) |  | $ | 29.54 |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |
| Granted |  |  | 3 |  |  | $ | 63.40 |  |
| Vested |  |  | (3 | ) |  | $ | 32.02 |  |
| Forfeited |  |  | (1 | ) |  | $ | 36.61 |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |

[0001564590-19-022779:notes:200]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-19-022779:notes:201]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 2 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 96 |  |  | $ | 75 |  |  | $ | 48 |  |

[0001564590-19-022779:notes:202]
Employee Stock Purchase Plan

[0001564590-19-022779:notes:203]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 13, 2018, the ESPP was amended to increase the shares reserved for issuance by 2 million shares of common stock. As of April 26, 2019, 7 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-19-022779:notes:204]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Shares issued under the ESPP |  |  | 3 |  |  |  | 4 |  |  |  | 4 |  |
| Proceeds from issuance of shares |  | $ | 96 |  |  | $ | 85 |  |  | $ | 80 |  |

[0001564590-19-022779:notes:205]
Stock-Based Compensation Expense

[0001564590-19-022779:notes:206]
Stock-based compensation expense is included in the consolidated statements of operations as follows (in millions):

[0001564590-19-022779:notes:207]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Cost of product revenues |  | $ | 4 |  |  | $ | 3 |  |  | $ | 4 |  |
| Cost of hardware maintenance and other services revenues |  |  | 10 |  |  |  | 10 |  |  |  | 13 |  |
| Sales and marketing |  |  | 67 |  |  |  | 68 |  |  |  | 84 |  |
| Research and development |  |  | 48 |  |  |  | 49 |  |  |  | 59 |  |
| General and administrative |  |  | 29 |  |  |  | 31 |  |  |  | 35 |  |
| Total stock-based compensation expense |  | $ | 158 |  |  | $ | 161 |  |  | $ | 195 |  |
| Income tax benefit for stock-based compensation |  | $ | 15 |  |  | $ | 29 |  |  | $ | 41 |  |

[0001564590-19-022779:notes:208]
As of April 26, 2019, total unrecognized compensation expense related to our equity awards was $285 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.1 years.

[0001564590-19-022779:notes:209]
Valuation Assumptions

[0001564590-19-022779:notes:210]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-19-022779:notes:211]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 2.6 | % |  |  | 1.4 | % |  |  | 1.0 | % |
| Expected dividend yield |  |  | 2.4 | % |  |  | 2.0 | % |  |  | 3.1 | % |
| Weighted-average fair value per share granted |  | $ | 63.40 |  |  | $ | 39.74 |  |  | $ | 24.99 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 2.6 | % |  |  | 1.4 | % |  |  | 0.8 | % |
| Expected volatility |  |  | 31 | % |  |  | 28 | % |  |  | 30 | % |
| Expected dividend yield |  |  | 2.4 | % |  |  | 2.0 | % |  |  | 3.1 | % |
| Weighted-average fair value per right granted |  | $ | 18.07 |  |  | $ | 12.34 |  |  | $ | 7.85 |  |

[0001564590-19-022779:notes:212]
Stock Repurchase Program

[0001564590-19-022779:notes:213]
As of April 26, 2019, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program . Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management.

[0001564590-19-022779:notes:214]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0001564590-19-022779:notes:215]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Number of shares repurchased |  |  | 29 |  |  |  | 15 |  |  |  | 22 |  |
| Average price per share |  | $ | 72.87 |  |  | $ | 51.57 |  |  | $ | 32.72 |  |
| Aggregate purchase price |  | $ | 2,111 |  |  | $ | 794 |  |  | $ | 705 |  |
| Remaining authorization at end of period |  | $ | 1,889 |  |  | $ | 4,000 |  |  | $ | 794 |  |

[0001564590-19-022779:notes:216]
The aggregate purchase price of our stock repurchases for fiscal 2019 consisted of $2.1 billion of open market purchases of which $1.0 billion and $1.1 billion were allocated to additional paid-in capital and retained earnings (accumulated deficit), respectively.

[0001564590-19-022779:notes:217]
Since the May 13, 2003 inception of our stock repurchase program through April 26, 2019, we repurchased a total of 313 million shares of our common stock at an average price of $37.46 per share, for an aggregate purchase price of $11.7 billion.

[0001564590-19-022779:notes:218]
Preferred Stock

[0001564590-19-022779:notes:219]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-19-022779:notes:220]
Dividends

[0001564590-19-022779:notes:221]
The following is a summary of our fiscal 2019, 2018 and 2017 activities related to dividends on our common stock (in millions, except per share amounts).

[0001564590-19-022779:notes:222]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Dividends per share declared |  | $ | 1.60 |  |  | $ | 0.80 |  |  | $ | 0.76 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 403 |  |  | $ | 106 |  |  | $ | 88 |  |
| Dividend payments allocated to retained earnings (accumulated deficit) |  | $ | — |  |  | $ | 108 |  |  | $ | 120 |  |

[0001564590-19-022779:notes:223]
On May 22, 2019, we declared a cash dividend of $0.48 per share of common stock, payable on July 24, 2019 to shareholders of record as of the close of business on July 5, 2019. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-19-022779:notes:224]
Accumulated Other Comprehensive Income (Loss)

[0001564590-19-022779:notes:225]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0001564590-19-022779:notes:226]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 28, 2017 |  | $ | (29 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (29 | ) |
| OCI before reclassifications, net of tax |  |  | 2 |  |  |  | 1 |  |  |  | (43 | ) |  |  | — |  |  |  | (40 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Total OCI |  |  | 2 |  |  |  | — |  |  |  | (43 | ) |  |  | — |  |  |  | (41 | ) |
| Balance as of April 27, 2018 |  |  | (27 | ) |  |  | — |  |  |  | (43 | ) |  |  | — |  |  |  | (70 | ) |
| OCI before reclassifications, net of tax |  |  | (7 | ) |  |  | (2 | ) |  |  | 36 |  |  |  | 2 |  |  |  | 29 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |
| Total OCI |  |  | (7 | ) |  |  | (3 | ) |  |  | 36 |  |  |  | 1 |  |  |  | 27 |  |
| Balance as of April 26, 2019 |  | $ | (34 | ) |  | $ | (3 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | (43 | ) |

[0001564590-19-022779:notes:227]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-19-022779:notes:228]
|  |  | Year Ended |  |  |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Classification |
| Recognized (gains) losses on defined benefit obligations |  | $ | (2 | ) |  | $ | (2 | ) |  |  | 1 |  |  | Operating expenses |
| Realized gains on cash flow hedges |  |  | (1 | ) |  |  | — |  |  |  | (6 | ) |  | Net revenues |
| Total reclassifications |  | $ | (3 | ) |  | $ | (2 | ) |  | $ | (5 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-022779:notes:229]
12. Derivatives and Hedging Activities

[0001564590-19-022779:notes:230]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 26, 2019 or April 27, 2018. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-19-022779:notes:231]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-19-022779:notes:232]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 103 |  |  | $ | — |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 121 |  |  | $ | 115 |  |
| Forward contracts purchased |  | $ | 363 |  |  | $ | 412 |  |

[0001564590-19-022779:notes:233]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 11 – Stockholders’ Equity.

[0001564590-19-022779:notes:234]
The effect of derivative instruments not designated as hedging instruments recognized in other income, net on our consolidated statements of operations was as follows (in millions):

[0001564590-19-022779:notes:235]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 15 |  |  | $ | (9 | ) |  | $ | 1 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-022779:notes:236]
13. Restructuring Charges

[0001564590-19-022779:notes:237]
Management has previously approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, including the March 2016 Plan,  November 2016 Plan,  May 2018 Plan and April 2019 plan, under which we reduced our global workforce by approximately 11% , 6%, less than 2%, and approximately 1%, respectively. Charges related to our restructuring plans consisted primarily of employee severance-related costs. We completed all workforce related activities under the March 2016 Plan and the November 2016 Plan as of the end of fiscal 2017. Substantially all activities under the May 2018 Plan were completed as of the end of fiscal 2019. The remaining balance under the November 2016 Plan as of April 26, 2019 principally relates to lease obligations that will be paid over their remaining terms. We expect to complete all activities associated with the April 2019 plan by the end of the third quarter of fiscal 2020 with no significant additional charges.

[0001564590-19-022779:notes:238]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001564590-19-022779:notes:239]
|  |  | April 2019 Plan |  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | March 2016 Plan |  |  | Total |  |
| Balance as of April 29, 2016 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 45 |  |  | $ | 45 |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Cash payments |  |  | — |  |  |  | — |  |  |  | (39 | ) |  |  | (45 | ) |  |  | (84 | ) |
| Balance as of April 28, 2017 |  |  | — |  |  |  | — |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Cash payments |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  | — |  |  |  | (7 | ) |
| Balance as of April 27, 2018 |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 6 |  |
| Net charges |  |  | 16 |  |  |  | 19 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Cash payments |  |  | (1 | ) |  |  | (19 | ) |  |  | (2 | ) |  |  | — |  |  |  | (22 | ) |
| Balance as of April 26, 2019 |  | $ | 15 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 19 |  |

[0001564590-19-022779:notes:240]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-022779:notes:241]
14. Income Taxes

[0001564590-19-022779:notes:242]
Income before income taxes is as follows (in millions):

[0001564590-19-022779:notes:243]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Domestic |  | $ | 678 |  |  | $ | 589 |  |  | $ | 166 |  |
| Foreign |  |  | 590 |  |  |  | 610 |  |  |  | 455 |  |
| Total |  | $ | 1,268 |  |  | $ | 1,199 |  |  | $ | 621 |  |

[0001564590-19-022779:notes:244]
The provision for income taxes consists of the following (in millions):

[0001564590-19-022779:notes:245]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 26 |  |  | $ | 764 |  |  | $ | 22 |  |
| State |  |  | 27 |  |  |  | 10 |  |  |  | 3 |  |
| Foreign |  |  | 49 |  |  |  | 39 |  |  |  | 41 |  |
| Total current |  |  | 102 |  |  |  | 813 |  |  |  | 66 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 35 |  |  |  | 239 |  |  |  | 61 |  |
| State |  |  | (6 | ) |  |  | 27 |  |  |  | 17 |  |
| Foreign |  |  | (32 | ) |  |  | 4 |  |  |  | (4 | ) |
| Total deferred |  |  | (3 | ) |  |  | 270 |  |  |  | 74 |  |
| Provision for income taxes |  | $ | 99 |  |  | $ | 1,083 |  |  | $ | 140 |  |

[0001564590-19-022779:notes:246]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-19-022779:notes:247]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Tax computed at federal statutory rate |  | $ | 266 |  |  | $ | 366 |  |  | $ | 218 |  |
| State income taxes, net of federal benefit |  |  | 16 |  |  |  | 18 |  |  |  | 8 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (84 | ) |  |  | (108 | ) |  |  | (100 | ) |
| Stock-based compensation |  |  | (19 | ) |  |  | (23 | ) |  |  | 16 |  |
| Research and development credits |  |  | (17 | ) |  |  | (10 | ) |  |  | (8 | ) |
| Resolution of income tax examinations |  |  | (48 | ) |  |  | — |  |  |  | — |  |
| Domestic production activities deduction |  |  | (13 | ) |  |  | (7 | ) |  |  | (4 | ) |
| Global minimum tax on intangible income |  |  | 22 |  |  |  | — |  |  |  | — |  |
| Tax rate changes |  |  | — |  |  |  | 108 |  |  |  | 5 |  |
| Non-taxable gain on joint venture formation |  |  | (14 | ) |  |  | — |  |  |  | — |  |
| Transition tax |  |  | (5 | ) |  |  | 732 |  |  |  | — |  |
| Other |  |  | (5 | ) |  |  | 7 |  |  |  | 5 |  |
| Provision for income taxes |  | $ | 99 |  |  | $ | 1,083 |  |  | $ | 140 |  |

[0001564590-19-022779:notes:248]
We generated foreign earnings in lower tax jurisdictions primarily related to income from our European operations.

[0001564590-19-022779:notes:249]
In February 2019, the Internal Revenue Service completed the examination of our fiscal 2012 to fiscal 2013 income tax returns. During fiscal 2019, we recognized a tax benefit of $48 million attributable to the effective settlement and the release of related tax reserves.

[0001564590-19-022779:notes:250]
On December 22, 2017, the Tax Cuts and Jobs Act (TCJA) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. ASC 740, Income Taxes, requires companies to recognize the effect of the tax law changes in the period of enactment. However, the SEC staff issued Staff Accounting Bulletin 118, which allowed companies to record provisional amounts during a measurement period not to extend beyond one year from the TCJA enactment date.

[0001564590-19-022779:notes:251]
As a result of the U.S. federal corporate income tax rate change, effective as of January 1, 2018, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. During fiscal 2018, we recorded $108 million of tax expense related to all tax rate changes. Upon finalization of our provisional estimates during the third quarter of fiscal 2019, we recorded tax expense of $6 million related to deferred tax assets for equity-based compensation awards to our executives.

[0001564590-19-022779:notes:252]
The TCJA imposes a mandatory, one-time transition tax on accumulated foreign earnings and profits not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. In fiscal 2018, we recorded a $732 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. In the third quarter of fiscal 2019, we finalized our computation of the transition tax and recorded a reduction of $5 million to our provisional estimate.

[0001564590-19-022779:notes:253]
As of April 26, 2019, we have completed the accounting for the tax impacts of the TCJA, however, we will continue to assess the impact of further guidance from federal and state tax authorities on our business and consolidated financial statements, and recognize any adjustments in the period in which they are determined.

[0001564590-19-022779:notes:254]
Under the TCJA, the global minimum tax on intangible income (GMT) provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules, or (ii) account for GMT in a company’s measurement of deferred taxes. We have elected to recognize the GMT as a period cost and thus recorded $22 million of tax expense for federal and state impacts for fiscal 2019.

[0001564590-19-022779:notes:255]
In October 2016, the FASB issued an ASU which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation.

[0001564590-19-022779:notes:256]
During fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements and recorded a tax charge of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-19-022779:notes:257]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-19-022779:notes:258]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 50 |  |  | $ | 57 |  |
| Net operating loss and credit carryforwards |  |  | 139 |  |  |  | 131 |  |
| Stock-based compensation |  |  | 16 |  |  |  | 22 |  |
| Deferred revenue |  |  | 205 |  |  |  | 156 |  |
| Other |  |  | 16 |  |  |  | 29 |  |
| Gross deferred tax assets |  |  | 426 |  |  |  | 395 |  |
| Valuation allowance |  |  | (123 | ) |  |  | (109 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 303 |  |  |  | 286 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 31 |  |  |  | 21 |  |
| Acquired intangibles |  |  | 32 |  |  |  | 29 |  |
| Property and equipment |  |  | 31 |  |  |  | 25 |  |
| Other |  |  | 10 |  |  |  | 14 |  |
| Total deferred tax liabilities |  |  | 104 |  |  |  | 89 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 199 |  |  | $ | 197 |  |

[0001564590-19-022779:notes:259]
The valuation allowance increased by $14 million in fiscal 2019. The increase is mainly attributable to corresponding changes in deferred tax assets, primarily foreign tax credit carryforwards and certain state tax credit carryforwards.

[0001564590-19-022779:notes:260]
As of April 26, 2019, we have federal net operating loss and tax credit carryforwards of approximately $2 million and $3 million, respectively. In addition, we have gross state net operating loss and tax credit carryforwards of $25 million and $138 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $4 million of foreign net operating losses, and $43 million of foreign tax credit carryforwards generated by our Dutch subsidiary which are fully offset by a valuation allowance. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal, state, and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2020 through 2038. The California research credit and Dutch foreign tax credit carryforwards do not expire.

[0001564590-19-022779:notes:261]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-19-022779:notes:262]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Balance at beginning of period |  | $ | 348 |  |  | $ | 218 |  |  | $ | 216 |  |
| Additions based on tax positions related to the current year |  |  | 11 |  |  |  | 131 |  |  |  | 7 |  |
| Additions for tax positions of prior years |  |  | 26 |  |  |  | — |  |  |  | 7 |  |
| Decreases for tax positions of prior years |  |  | (35 | ) |  |  | (1 | ) |  |  | — |  |
| Settlements |  |  | (54 | ) |  |  | — |  |  |  | (12 | ) |
| Balance at end of period |  | $ | 296 |  |  | $ | 348 |  |  | $ | 218 |  |

[0001564590-19-022779:notes:263]
As of April 26, 2019, we had $296 million of gross unrecognized tax benefits, of which $252 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $246 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. As a result of U.S. tax reform, we recorded provisional gross unrecognized tax benefits of $114 million during fiscal 2018.

[0001564590-19-022779:notes:264]
We recognized a benefit for adjustments to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of approximately $4 million in fiscal 2019 and expense of $5 million in each of fiscal 2018 and 2017. Accrued interest and penalties of $18 million and $22 million were recorded in the consolidated balance sheets as of April 26, 2019 and April 27, 2018, respectively.

[0001564590-19-022779:notes:265]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-19-022779:notes:266]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 26, 2019

[0001564590-19-022779:notes:267]
| 2014 — 2019 |  | United States — federal income tax |
| 2011 — 2019 |  | United States — state and local income tax |
| 2013 — 2019 |  | Australia |
| 2013 — 2019 |  | Germany |
| 2007 — 2019 |  | India |
| 2013 — 2019 |  | Japan |
| 2014 — 2019 |  | The Netherlands |
| 2016 — 2019 |  | United Kingdom |
| 2016 — 2019 |  | Canada |

[0001564590-19-022779:notes:268]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key issues under these audits and are often subject to dispute and appeals. We are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-19-022779:notes:269]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. The preliminary ruling will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will then issue its final decision. While the timing and outcome of a final decision on this matter is uncertain, we believe it is more likely than not that our distributions were not subject to withholding tax and we intend to vigorously defend any withholding tax claims by the Danish Tax Authorities.

[0001564590-19-022779:notes:270]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-19-022779:notes:271]
Prior to the passage of the TCJA, we had not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we had intended to indefinitely reinvest such earnings outside the U.S. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017 and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the provisional estimates recorded during fiscal 2018, we considered the impacts of the TCJA and reviewed our projected global cash requirements, and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested. As of April 26, 2019, we estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-022779:notes:272]
15. Net Income per Share

[0001564590-19-022779:notes:273]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-19-022779:notes:274]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,169 |  |  | $ | 116 |  |  | $ | 481 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 254 |  |  |  | 268 |  |  |  | 275 |  |
| Dilutive impact of employee equity award plans |  |  | 5 |  |  |  | 8 |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 259 |  |  |  | 276 |  |  |  | 281 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 4.60 |  |  | $ | 0.43 |  |  | $ | 1.75 |  |
| Diluted |  | $ | 4.51 |  |  | $ | 0.42 |  |  | $ | 1.71 |  |

[0001564590-19-022779:notes:275]
Potential shares from outstanding employee equity awards totaling 1 million, 1 million and 6 million for fiscal 2019, 2018 and 2017, respectively, were excluded from the diluted net income per share calculations as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-022779:notes:276]
16. Segment, Geographic, and Significant Customer Information

[0001564590-19-022779:notes:277]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-19-022779:notes:278]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-19-022779:notes:279]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,425 |  |  | $ | 3,207 |  |  | $ | 3,021 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,847 |  |  |  | 1,873 |  |  |  | 1,741 |  |
| Asia Pacific (APAC) |  |  | 874 |  |  |  | 839 |  |  |  | 729 |  |
| Net revenues |  | $ | 6,146 |  |  | $ | 5,919 |  |  | $ | 5,491 |  |

[0001564590-19-022779:notes:280]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $3,116 million, $2,878 million and $2,721 million during fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:notes:281]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-19-022779:notes:282]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 159 |  |  | $ | 853 |  |
| International |  |  | 3,740 |  |  |  | 4,538 |  |
| Total |  | $ | 3,899 |  |  | $ | 5,391 |  |

[0001564590-19-022779:notes:283]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-19-022779:notes:284]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 572 |  |  | $ | 566 |  |
| International |  |  | 187 |  |  |  | 190 |  |
| Total |  | $ | 759 |  |  | $ | 756 |  |

[0001564590-19-022779:notes:285]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-19-022779:notes:286]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 23 | % |  |  | 22 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-19-022779:notes:287]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-19-022779:notes:288]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 17 | % |
| Tech Data Corporation |  |  | 24 | % |  |  | 17 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-19-022779:notes:289]
17. Employee Benefits and Deferred Compensation

[0001564590-19-022779:notes:290]
Employee 401(k) Plan

[0001564590-19-022779:notes:291]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-19-022779:notes:292]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| 401(k) matching contributions |  | $ | 29 |  |  | $ | 28 |  |  | $ | 30 |  |

[0001564590-19-022779:notes:293]
Deferred Compensation Plan

[0001564590-19-022779:notes:294]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-19-022779:notes:295]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Deferred compensation plan assets |  | $ | 35 |  |  | $ | 31 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 6 |  |  | $ | 6 |  |
| Other long-term liabilities |  | $ | 29 |  |  | $ | 25 |  |

[0001564590-19-022779:notes:296]
Postretirement Health Care Plan

[0001564590-19-022779:notes:297]
Certain of our executive officers are eligible to participate in our Executive Retirement Medical Plan (the ERM Plan). The ERM Plan provides, upon retirement, medical benefits beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, years of service and position. The ERM Plan was unfunded as of April 26, 2019 and April 27, 2018, and there is no minimum funding requirement under the ERM Plan.

[0001564590-19-022779:notes:298]
In November 2016, we made certain amendments to the ERM Plan, which prior to amendment, provided group health insurance benefits to eligible retirees. Effective January 1, 2017, the amended ERM Plan provides each eligible retiree with a capped reimbursement of premiums for the period from January 1, 2017 through December 31, 2019. During the period from December 31, 2019 through December 31, 2021, participants in the ERM Plan will be eligible to receive a lump sum cash payment equal to two years of projected health care costs, or a prorated portion thereof, pursuant to the methodology set forth in the ERM Plan. Such payment will be made by us outside the ERM Plan as the ERM Plan is expected to terminate on December 31, 2019.

[0001564590-19-022779:notes:299]
These plan amendments resulted in a prior service credit adjustment of $14 million, net of taxes, which we recorded to other comprehensive income in fiscal 2017.

[0001564590-19-022779:notes:300]
Other Defined Benefit Plans

[0001564590-19-022779:notes:301]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0001564590-19-022779:notes:302]
Funded Status

[0001564590-19-022779:notes:303]
The funded status of our postretirement health care and other defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0001564590-19-022779:notes:304]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Fair value of plan assets |  | $ | 31 |  |  | $ | 25 |  |
| Benefit obligations |  |  | (61 | ) |  |  | (53 | ) |
| Unfunded obligations |  | $ | (30 | ) |  | $ | (28 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-022779:notes:305]
18. Commitments and Contingencies

[0001564590-19-022779:notes:306]
Operating Leases

[0001564590-19-022779:notes:307]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-19-022779:notes:308]
Future annual minimum lease payments under all non-cancelable operating leases with an initial term in excess of one year as of April 26, 2019 are as follows (in millions):

[0001564590-19-022779:notes:309]
|  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2023 |  |  |  | 2024 |  |  | Thereafter |  |  | Total |  |
| Operating lease commitments |  | $ | 47 |  |  | $ | 38 |  |  | $ | 26 |  |  | $ | 14 |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 151 |  |

[0001564590-19-022779:notes:310]
Rent expense under all cancelable and non-cancelable operating leases was $54 million, $59 million and $64 million in fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:notes:311]
Purchase Orders and Other Commitments

[0001564590-19-022779:notes:312]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 26, 2019, we had $449 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 26, 2019 and April 27, 2018, such liability amounted to $16 million and $14 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-022779:notes:313]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 26, 2019, we had $5 million in construction related obligations and $234 million in other purchase obligations.

[0001564590-19-022779:notes:314]
Financing Guarantees

[0001564590-19-022779:notes:315]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $87 million, $67 million and $183 million of receivables during fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:notes:316]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-19-022779:notes:317]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 26, 2019, and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-022779:notes:318]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 26, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-19-022779:notes:319]
Indemnification Agreements

[0001564590-19-022779:notes:320]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to the customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 26, 2019 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001564590-19-022779:notes:321]
Legal Contingencies

[0001564590-19-022779:notes:322]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-19-022779:notes:323]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-19-022779:notes:324]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of April 26, 2019 related to such matters.


## us-gaap:SubsequentEventsTextBlock

[0001564590-19-022779:notes:325]
19. Subsequent Event

[0001564590-19-022779:notes:326]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for approximately $56 million in cash. We are in the process of completing the purchase price allocation for this acquisition.
