# NTAP 8-K — 0001564590-19-020164 filed 2019-05-22

## item codes, every 8-K on or before 2019-06-18

- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2019-06-18

- none on or before 2019-06-18

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-020164:8k_2_02:1]
EX-99.1
3
ntap-ex991_6.htm
EX-99.1

[0001564590-19-020164:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-19-020164:8k_2_02:3]
Exhibit 99.1

[0001564590-19-020164:8k_2_02:4]
NetApp Reports Fourth Quarter and Fiscal Year 2019 Results

[0001564590-19-020164:8k_2_02:5]
Net Revenues of $1.59 Billion for the Fourth Quarter and $6.15 Billion for Fiscal Year 2019

[0001564590-19-020164:8k_2_02:6]
| • | Net revenues for fiscal year 2019 grew 4% year-over-year |  |

[0001564590-19-020164:8k_2_02:7]
| • | Product revenue for fiscal year 2019 grew 7% year-over-year |  |

[0001564590-19-020164:8k_2_02:8]
| • | All Flash Array revenue for fiscal year 2019 grew 25% year-over-year |  |

[0001564590-19-020164:8k_2_02:9]
| • | $2.51 billion returned to shareholders in share repurchases and cash dividends in fiscal year 2019 |  |

[0001564590-19-020164:8k_2_02:10]
| • | First quarter fiscal year 2020 dividend to increase by 20% to $0.48 per share |  |

[0001564590-19-020164:8k_2_02:11]
Sunnyvale, Calif.—May 22, 2019—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2019, which ended April 26, 2019.

[0001564590-19-020164:8k_2_02:12]
“Despite the modest shortfall relative to our fiscal year 2019 expectations, we made significant progress in the strategic markets of All-Flash, Private Cloud, and Cloud Data Services. Our Data Fabric strategy clearly differentiates us from our competitors,” said George Kurian, chief executive officer. “Enterprises are choosing NetApp to be a strategic partner in their digital transformations. Our opportunity is large and growing, and we are moving quickly to improve our execution.”

[0001564590-19-020164:8k_2_02:13]
Fourth Quarter Fiscal Year 2019 Financial Results*

[0001564590-19-020164:8k_2_02:14]
| • | Net Revenues: $1.59 billion, compared to $1.64 billion in the fourth quarter of fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:15]
| • | Net Income: GAAP net income of $396 million, compared to GAAP net income of $290 million in the fourth quarter of fiscal 2018; non-GAAP net income1 of $305 million, compared to non-GAAP net income of $307 million in the fourth quarter of fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:16]
| • | Earnings per Share: GAAP net income per share2 of $1.59 compared to GAAP net income per share of $1.06 in the fourth quarter of fiscal 2018; non-GAAP net income per share of $1.22, compared to non-GAAP net income per share of $1.12 in the fourth quarter of fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $3.9 billion at the end of fiscal 2019 |  |

[0001564590-19-020164:8k_2_02:18]
| • | Cash from Operations: $399 million, compared to $494 million in the fourth quarter of fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:19]
| • | Share Repurchase and Dividend: Returned $597 million to shareholders through share repurchases and cash dividends |  |

[0001564590-19-020164:8k_2_02:20]
Fiscal Year 2019 Financial Results*

[0001564590-19-020164:8k_2_02:21]
| • | Net Revenues: $6.15 billion, increased 4% year-over-year from $5.92 billion in fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:22]
| • | Net Income: GAAP net income of $1.17 billion, compared to GAAP net income of $116 million** in fiscal 2018; non-GAAP net income of $1.17 billion, compared to non-GAAP net income of $983 million in fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:23]
| • | Earnings per Share: GAAP net income per share of $4.51, compared to GAAP net income per share of $0.42** in fiscal 2018; non-GAAP net income per share of $4.52, compared to non-GAAP net income per share of $3.56 in fiscal 2018 |  |

[0001564590-19-020164:8k_2_02:24]
| • | Cash from Operations: $1.34 billion, compared to $1.48 billion in fiscal year 2018 |  |

[0001564590-19-020164:8k_2_02:25]
| • | Share Repurchase and Dividend: Returned $2.51 billion to shareholders through share repurchases and cash dividends |  |

[0001564590-19-020164:8k_2_02:26]
*In the first quarter of fiscal 2019, NetApp adopted Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, NetApp’s condensed consolidated balance sheet as of April 27, 2018, condensed consolidated statements of operations and cash flows for all fiscal 2018 periods presented, and all related financial statement metrics included herein, have been restated to conform to the new rules.

[0001564590-19-020164:8k_2_02:27]
**On December 22, 2017, the Tax Cuts and Jobs Act was enacted into law. This tax reform legislation contains several key tax provisions that affected the company, including a one-time mandatory transition tax on accumulated foreign earnings and a reduction of the U.S. corporate income tax rate to 21% effective January 1, 2018, among others. GAAP net income in fiscal year 2018 was impacted by a resulting one-time charge of approximately $850 million.

[0001564590-19-020164:8k_2_02:28]
First Quarter Fiscal Year 2020 Financial Outlook

[0001564590-19-020164:8k_2_02:29]
The Company provided the following financial guidance for the first quarter of fiscal year 2020:

[0001564590-19-020164:8k_2_02:30]
| •Net revenues are expected to be in the range of: | $1.315 billion to $1.465 billion |
|  | GAAP | Non-GAAP |

[0001564590-19-020164:8k_2_02:31]
| •Earnings per share is expected to be in the range of: | $0.56-$0.64 | $0.78-$0.86 |

[0001564590-19-020164:8k_2_02:32]
Full Fiscal Year 2020 Financial Outlook

[0001564590-19-020164:8k_2_02:33]
The Company provided the following financial guidance for the full fiscal year 2020:

[0001564590-19-020164:8k_2_02:34]
| •Net revenues are expected to grow at the low-end of mid-single-digit range |
|  | GAAP | Non-GAAP |
| •Consolidated gross margins are expected to be: | 63%-64% | 64%-65% |
| •Operating margins are expected to be in the range of: | 20%-21% | 23%-24% |
| •Effective tax rate is expected to be approximately 19.5% on both a GAAP and Non-GAAP basis |

[0001564590-19-020164:8k_2_02:35]
Dividend

[0001564590-19-020164:8k_2_02:36]
The Company will increase the first quarter fiscal year 2020 dividend by 20% to $0.48 per share. The quarterly dividend will be paid on July 24, 2019, to shareholders of record as of the close of business on July 5, 2019.

[0001564590-19-020164:8k_2_02:37]
Fourth Quarter Fiscal Year 2019 Business Highlights

[0001564590-19-020164:8k_2_02:38]
New Products Enable Digital Transformation

[0001564590-19-020164:8k_2_02:39]
| - | NetApp announced a variety of new and updated offerings that give customers more flexibility across hybrid multicloud environments for a range of use cases, including FlexPod™ AI platform; FlexPod for MEDITECH software; NetApp™ Service Level Manager; and the FlexCache™. |

[0001564590-19-020164:8k_2_02:40]
| - | OnCommand™ Workflow Automation 5.0 makes it easier for customers to automate, monitor, and maintain storage workflows. Changes in the web UI deliver a consistent user experience across OnCommand System Manager, Unified Manager, and Workflow Automation, resulting in improved simplicity and efficiency. |

[0001564590-19-020164:8k_2_02:41]
Industry-Leading Strategic Partnerships

[0001564590-19-020164:8k_2_02:42]
| - | Intel Optane DC Persistent Memory and NetApp Memory Accelerated Data extended their partnership to help customers realize the promise of solutions that offer shorter time to results with their data. |

[0001564590-19-020164:8k_2_02:43]
| - | NetApp partnered with H2O.ai and integrated NetApp Cloud Volumes Service, a cloud-native file storage service. H2O Driverless AI provides a platform for customers to collaborate, scale, and deploy AI solutions more quickly. |

[0001564590-19-020164:8k_2_02:44]
| - | Texas-based Soccour Solutions received HCI Champion Partner status after it embraced NetApp HCI as part of its customer offerings. |

[0001564590-19-020164:8k_2_02:45]
Industry Recognition

[0001564590-19-020164:8k_2_02:46]
| - | NetApp was named 2018 Google Cloud Technology Partner of the Year for Infrastructure at the Google Cloud Next 2019 Partner Summit. |

[0001564590-19-020164:8k_2_02:47]
| - | NetApp was awarded Brand of the Year by Think Global Awards, which recognizes achievements in promoting an awareness of thinking globally for individuals, communities, startups, small to medium-sized businesses, global brands, and large-scale international organizations. |

[0001564590-19-020164:8k_2_02:48]
Webcast and Conference Call Information

[0001564590-19-020164:8k_2_02:49]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-19-020164:8k_2_02:50]
About NetApp

[0001564590-19-020164:8k_2_02:51]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-19-020164:8k_2_02:52]
###

[0001564590-19-020164:8k_2_02:53]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-19-020164:8k_2_02:54]
Footnotes

[0001564590-19-020164:8k_2_02:55]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the

[0001564590-19-020164:8k_2_02:56]
measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-19-020164:8k_2_02:57]
2GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-19-020164:8k_2_02:58]
NetApp Usage of Non-GAAP Financial Information

[0001564590-19-020164:8k_2_02:59]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-19-020164:8k_2_02:60]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-19-020164:8k_2_02:61]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-19-020164:8k_2_02:62]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-19-020164:8k_2_02:63]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-19-020164:8k_2_02:64]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-19-020164:8k_2_02:65]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-19-020164:8k_2_02:66]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-19-020164:8k_2_02:67]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-19-020164:8k_2_02:68]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-19-020164:8k_2_02:69]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-19-020164:8k_2_02:70]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-

[0001564590-19-020164:8k_2_02:71]
GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-19-020164:8k_2_02:72]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-19-020164:8k_2_02:73]
NETAPP, INC.

[0001564590-19-020164:8k_2_02:74]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-020164:8k_2_02:75]
(In millions)

[0001564590-19-020164:8k_2_02:76]
(Unaudited)

[0001564590-19-020164:8k_2_02:77]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,899 |  |  | $ | 5,391 |  |
| Accounts receivable |  |  | 1,216 |  |  |  | 1,047 |  |
| Inventories |  |  | 131 |  |  |  | 122 |  |
| Other current assets |  |  | 364 |  |  |  | 392 |  |
| Total current assets |  |  | 5,610 |  |  |  | 6,952 |  |
| Property and equipment, net |  |  | 759 |  |  |  | 756 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,782 |  |  |  | 1,833 |  |
| Other non-current assets |  |  | 590 |  |  |  | 450 |  |
| Total assets |  | $ | 8,741 |  |  | $ | 9,991 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 542 |  |  | $ | 609 |  |
| Accrued expenses |  |  | 851 |  |  |  | 825 |  |
| Commercial paper notes |  |  | 249 |  |  |  | 385 |  |
| Current portion of long-term debt |  |  | 400 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,825 |  |  |  | 1,712 |  |
| Total current liabilities |  |  | 3,867 |  |  |  | 3,531 |  |
| Long-term debt |  |  | 1,144 |  |  |  | 1,541 |  |
| Other long-term liabilities |  |  | 797 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,843 |  |  |  | 1,651 |  |
| Total liabilities |  |  | 7,651 |  |  |  | 7,715 |  |
| Stockholders' equity |  |  | 1,090 |  |  |  | 2,276 |  |
| Total liabilities and stockholders' equity |  | $ | 8,741 |  |  | $ | 9,991 |  |

[0001564590-19-020164:8k_2_02:78]
NETAPP, INC.

[0001564590-19-020164:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-020164:8k_2_02:80]
(In millions, except per share amounts)

[0001564590-19-020164:8k_2_02:81]
(Unaudited)

[0001564590-19-020164:8k_2_02:82]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,000 |  |  | $ | 1,027 |  |  | $ | 3,755 |  |  | $ | 3,525 |  |
| Software maintenance |  |  | 242 |  |  |  | 234 |  |  |  | 946 |  |  |  | 902 |  |
| Hardware maintenance and other services |  |  | 350 |  |  |  | 383 |  |  |  | 1,445 |  |  |  | 1,492 |  |
| Net revenues |  |  | 1,592 |  |  |  | 1,644 |  |  |  | 6,146 |  |  |  | 5,919 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 457 |  |  |  | 496 |  |  |  | 1,752 |  |  |  | 1,738 |  |
| Cost of software maintenance |  |  | 10 |  |  |  | 6 |  |  |  | 35 |  |  |  | 25 |  |
| Cost of hardware maintenance and other services |  |  | 99 |  |  |  | 113 |  |  |  | 414 |  |  |  | 447 |  |
| Total cost of revenues |  |  | 566 |  |  |  | 615 |  |  |  | 2,201 |  |  |  | 2,210 |  |
| Gross profit |  |  | 1,026 |  |  |  | 1,029 |  |  |  | 3,945 |  |  |  | 3,709 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 439 |  |  |  | 443 |  |  |  | 1,657 |  |  |  | 1,706 |  |
| Research and development |  |  | 205 |  |  |  | 203 |  |  |  | 827 |  |  |  | 783 |  |
| General and administrative |  |  | 69 |  |  |  | 71 |  |  |  | 278 |  |  |  | 280 |  |
| Restructuring charges |  |  | 16 |  |  |  | — |  |  |  | 35 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (73 | ) |  |  | — |  |  |  | (73 | ) |  |  | (218 | ) |
| Total operating expenses |  |  | 656 |  |  |  | 717 |  |  |  | 2,724 |  |  |  | 2,551 |  |
| Income from operations |  |  | 370 |  |  |  | 312 |  |  |  | 1,221 |  |  |  | 1,158 |  |
| Other income, net |  |  | 14 |  |  |  | 16 |  |  |  | 47 |  |  |  | 41 |  |
| Income before income taxes |  |  | 384 |  |  |  | 328 |  |  |  | 1,268 |  |  |  | 1,199 |  |
| Provision (benefit) for income taxes |  |  | (12 | ) |  |  | 38 |  |  |  | 99 |  |  |  | 1,083 |  |
| Net income |  | $ | 396 |  |  | $ | 290 |  |  | $ | 1,169 |  |  | $ | 116 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.62 |  |  | $ | 1.09 |  |  | $ | 4.60 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 1.59 |  |  | $ | 1.06 |  |  | $ | 4.51 |  |  | $ | 0.42 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 245 |  |  |  | 265 |  |  |  | 254 |  |  |  | 268 |  |
| Diluted |  |  | 249 |  |  |  | 273 |  |  |  | 259 |  |  |  | 276 |  |
| Cash dividends declared per share |  | $ | 0.40 |  |  | $ | 0.20 |  |  | $ | 1.60 |  |  | $ | 0.80 |  |

[0001564590-19-020164:8k_2_02:83]
NETAPP, INC.

[0001564590-19-020164:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-020164:8k_2_02:85]
(In millions)

[0001564590-19-020164:8k_2_02:86]
(Unaudited)

[0001564590-19-020164:8k_2_02:87]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 396 |  |  | $ | 290 |  |  | $ | 1,169 |  |  | $ | 116 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48 |  |  |  | 48 |  |  |  | 197 |  |  |  | 198 |  |
| Stock-based compensation |  |  | 37 |  |  |  | 36 |  |  |  | 158 |  |  |  | 161 |  |
| Deferred income taxes |  |  | 18 |  |  |  | 25 |  |  |  | (3 | ) |  |  | 270 |  |
| Gain on sale or derecognition of assets |  |  | (73 | ) |  |  | — |  |  |  | (73 | ) |  |  | (218 | ) |
| Other items, net |  |  | (6 | ) |  |  | (19 | ) |  |  | 2 |  |  |  | (27 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (350 | ) |  |  | (279 | ) |  |  | (185 | ) |  |  | (289 | ) |
| Inventories |  |  | (31 | ) |  |  | (32 | ) |  |  | (9 | ) |  |  | 36 |  |
| Accounts payable |  |  | 44 |  |  |  | 147 |  |  |  | (57 | ) |  |  | 262 |  |
| Accrued expenses |  |  | 127 |  |  |  | 104 |  |  |  | 42 |  |  |  | 162 |  |
| Deferred revenue and financed unearned services revenue |  |  | 326 |  |  |  | 238 |  |  |  | 343 |  |  |  | 139 |  |
| Long-term taxes payable |  |  | (104 | ) |  |  | (9 | ) |  |  | (164 | ) |  |  | 714 |  |
| Changes in other operating assets and liabilities, net |  |  | (33 | ) |  |  | (55 | ) |  |  | (79 | ) |  |  | (46 | ) |
| Net cash provided by operating activities |  |  | 399 |  |  |  | 494 |  |  |  | 1,341 |  |  |  | 1,478 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 215 |  |  |  | 168 |  |  |  | 876 |  |  |  | (10 | ) |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (48 | ) |  |  | (173 | ) |  |  | (145 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 210 |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | (75 | ) |
| Other investing activities, net |  |  | 3 |  |  |  | — |  |  |  | 4 |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | 183 |  |  |  | 120 |  |  |  | 704 |  |  |  | (21 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 3 |  |  |  | 16 |  |  |  | 121 |  |  |  | 173 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (4 | ) |  |  | (8 | ) |  |  | (96 | ) |  |  | (75 | ) |
| Repurchase of common stock |  |  | (500 | ) |  |  | (344 | ) |  |  | (2,111 | ) |  |  | (794 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | 85 |  |  |  | (247 | ) |  |  | (136 | ) |  |  | (115 | ) |
| Issuance of long-term debt, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 795 |  |
| Repayment of long-term debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (750 | ) |
| Dividends paid |  |  | (97 | ) |  |  | (53 | ) |  |  | (403 | ) |  |  | (214 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | — |  |  |  | (6 | ) |  |  | (6 | ) |
| Net cash used in financing activities |  |  | (514 | ) |  |  | (636 | ) |  |  | (2,631 | ) |  |  | (986 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (13 | ) |  |  | (11 | ) |  |  | (30 | ) |  |  | 26 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 55 |  |  |  | (33 | ) |  |  | (616 | ) |  |  | 497 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,276 |  |  |  | 2,980 |  |  |  | 2,947 |  |  |  | 2,450 |  |
| End of period |  | $ | 2,331 |  |  | $ | 2,947 |  |  | $ | 2,331 |  |  | $ | 2,947 |  |

[0001564590-19-020164:8k_2_02:88]
SELECTED CONDENSED CONSOLIDATED BALANCE SHEET LINE ITEMS

[0001564590-19-020164:8k_2_02:89]
(In millions)

[0001564590-19-020164:8k_2_02:90]
(Unaudited)

[0001564590-19-020164:8k_2_02:91]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  |  | 1,651 |  |
| Total stockholders' equity |  |  | 2,067 |  |  |  | 209 |  |  |  | 2,276 |  |

[0001564590-19-020164:8k_2_02:92]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,011 |  |  | $ | 16 |  |  | $ | 1,027 |  |  | $ | 3,461 |  |  | $ | 64 |  |  | $ | 3,525 |  |
| Software maintenance |  |  | 247 |  |  |  | (13 | ) |  |  | 234 |  |  |  | 958 |  |  |  | (56 | ) |  |  | 902 |  |
| Hardware maintenance and other services |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | 1,492 |  |  |  | — |  |  |  | 1,492 |  |
| Net revenues |  |  | 1,641 |  |  |  | 3 |  |  |  | 1,644 |  |  |  | 5,911 |  |  |  | 8 |  |  |  | 5,919 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 500 |  |  |  | (4 | ) |  |  | 496 |  |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | — |  |  |  | 113 |  |  |  | 449 |  |  |  | (2 | ) |  |  | 447 |  |
| Total cost of revenues |  |  | 619 |  |  |  | (4 | ) |  |  | 615 |  |  |  | 2,212 |  |  |  | (2 | ) |  |  | 2,210 |  |
| Gross profit |  |  | 1,022 |  |  |  | 7 |  |  |  | 1,029 |  |  |  | 3,699 |  |  |  | 10 |  |  |  | 3,709 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 461 |  |  |  | (18 | ) |  |  | 443 |  |  |  | 1,729 |  |  |  | (23 | ) |  |  | 1,706 |  |
| Research and development |  |  | 203 |  |  |  | — |  |  |  | 203 |  |  |  | 783 |  |  |  | — |  |  |  | 783 |  |
| General and administrative |  |  | 71 |  |  |  | — |  |  |  | 71 |  |  |  | 280 |  |  |  | — |  |  |  | 280 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 735 |  |  |  | (18 | ) |  |  | 717 |  |  |  | 2,574 |  |  |  | (23 | ) |  |  | 2,551 |  |
| Income from operations |  |  | 287 |  |  |  | 25 |  |  |  | 312 |  |  |  | 1,125 |  |  |  | 33 |  |  |  | 1,158 |  |
| Other income, net |  |  | 16 |  |  |  | — |  |  |  | 16 |  |  |  | 41 |  |  |  | — |  |  |  | 41 |  |
| Income before income taxes |  |  | 303 |  |  |  | 25 |  |  |  | 328 |  |  |  | 1,166 |  |  |  | 33 |  |  |  | 1,199 |  |
| Provision for income taxes |  |  | 32 |  |  |  | 6 |  |  |  | 38 |  |  |  | 1,090 |  |  |  | (7 | ) |  |  | 1,083 |  |
| Net income |  | $ | 271 |  |  | $ | 19 |  |  | $ | 290 |  |  | $ | 76 |  |  | $ | 40 |  |  | $ | 116 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.02 |  |  | $ | 0.07 |  |  | $ | 1.09 |  |  | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.99 |  |  | $ | 0.07 |  |  | $ | 1.06 |  |  | $ | 0.28 |  |  | $ | 0.14 |  |  | $ | 0.42 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 265 |  |  |  | 265 |  |  |  | 265 |  |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |
| Diluted |  |  | 273 |  |  |  | 273 |  |  |  | 273 |  |  |  | 276 |  |  |  | 276 |  |  |  | 276 |  |

[0001564590-19-020164:8k_2_02:93]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q4 FY'19 |  |  | Q3 FY'19 |  |  | Q4 FY'18 |  |  | FY 2019 |  |  | FY2018 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,000 |  |  | $ | 967 |  |  | $ | 1,027 |  |  | $ | 3,755 |  |  | $ | 3,525 |  |
| Strategic |  | $ | 774 |  |  | $ | 674 |  |  | $ | 747 |  |  | $ | 2,709 |  |  | $ | 2,468 |  |
| Mature |  | $ | 226 |  |  | $ | 293 |  |  | $ | 280 |  |  | $ | 1,046 |  |  | $ | 1,057 |  |
| Software Maintenance |  | $ | 242 |  |  | $ | 239 |  |  | $ | 234 |  |  | $ | 946 |  |  | $ | 902 |  |
| Hardware Maintenance and Other Services |  | $ | 350 |  |  | $ | 357 |  |  | $ | 383 |  |  | $ | 1,445 |  |  | $ | 1,492 |  |
| Hardware Maintenance Support Contracts |  | $ | 284 |  |  | $ | 292 |  |  | $ | 310 |  |  | $ | 1,182 |  |  | $ | 1,214 |  |
| Professional and Other Services |  | $ | 66 |  |  | $ | 65 |  |  | $ | 73 |  |  | $ | 263 |  |  | $ | 278 |  |
| Net Revenues |  | $ | 1,592 |  |  | $ | 1,563 |  |  | $ | 1,644 |  |  | $ | 6,146 |  |  | $ | 5,919 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'19 Revenue |  |  | % of Q3 FY'19 Revenue |  |  | % of Q4 FY'18 Revenue |  |  | % of FY 2019 Revenue |  |  | % of FY 2018 Revenue |  |
| Americas |  |  | 57 | % |  |  | 52 | % |  |  | 54 | % |  |  | 56 | % |  |  | 54 | % |
| Americas Commercial |  |  | 45 | % |  |  | 41 | % |  |  | 42 | % |  |  | 44 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 11 | % |  |  | 11 | % |  |  | 12 | % |  |  | 12 | % |  |  | 13 | % |
| EMEA |  |  | 29 | % |  |  | 33 | % |  |  | 33 | % |  |  | 30 | % |  |  | 32 | % |
| Asia Pacific |  |  | 14 | % |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'19 Revenue |  |  | % of Q3 FY'19 Revenue |  |  | % of Q4 FY'18 Revenue |  |  | % of FY 2019 Revenue |  |  | % of FY 2018 Revenue |  |
| Direct |  |  | 24 | % |  |  | 19 | % |  |  | 21 | % |  |  | 24 | % |  |  | 21 | % |
| Indirect |  |  | 76 | % |  |  | 81 | % |  |  | 79 | % |  |  | 76 | % |  |  | 79 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'19 |  |  | Q3 FY'19 |  |  | Q4 FY'18 |  |  | FY 2019 |  |  | FY2018 |  |
| Non-GAAP Gross Margin |  |  | 65.2 | % |  |  | 63.7 | % |  |  | 63.3 | % |  |  | 65.0 | % |  |  | 63.5 | % |
| Product |  |  | 55.3 | % |  |  | 52.6 | % |  |  | 52.7 | % |  |  | 54.4 | % |  |  | 51.8 | % |
| Software Maintenance |  |  | 95.9 | % |  |  | 95.8 | % |  |  | 97.4 | % |  |  | 96.3 | % |  |  | 97.2 | % |
| Hardware Maintenance and Other Services |  |  | 72.3 | % |  |  | 72.3 | % |  |  | 71.0 | % |  |  | 72.0 | % |  |  | 70.7 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'19 |  |  | Q3 FY'19 |  |  | Q4 FY'18 |  |  | FY 2019 |  |  | FY2018 |  |
| Non-GAAP Income from Operations |  | $ | 358 |  |  | $ | 367 |  |  | $ | 360 |  |  | $ | 1,387 |  |  | $ | 1,159 |  |
| % of Net Revenues |  |  | 22.5 | % |  |  | 23.5 | % |  |  | 21.9 | % |  |  | 22.6 | % |  |  | 19.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 372 |  |  | $ | 375 |  |  | $ | 376 |  |  | $ | 1,434 |  |  | $ | 1,200 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.1 | % |  |  | 18.7 | % |  |  | 18.4 | % |  |  | 18.4 | % |  |  | 18.1 | % |

[0001564590-19-020164:8k_2_02:94]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'19 |  |  | Q3 FY'19 |  |  | Q4 FY'18 |  |  | FY 2019 |  |  | FY2018 |  |
| Non-GAAP Net Income |  | $ | 305 |  |  | $ | 305 |  |  | $ | 307 |  |  | $ | 1,171 |  |  | $ | 983 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 249 |  |  |  | 255 |  |  |  | 273 |  |  |  | 259 |  |  |  | 276 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.22 |  |  | $ | 1.20 |  |  | $ | 1.12 |  |  | $ | 4.52 |  |  | $ | 3.56 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'19 |  |  | Q3 FY'19 |  |  | Q4 FY'18 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,668 |  |  | $ | 3,357 |  |  | $ | 3,363 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 70 |  |  |  | 51 |  |  |  | 58 |  |  |  |  |  |  |  |  |  |
| DIO (days) |  |  | 21 |  |  |  | 16 |  |  |  | 18 |  |  |  |  |  |  |  |  |  |
| DPO (days) |  |  | 87 |  |  |  | 78 |  |  |  | 90 |  |  |  |  |  |  |  |  |  |
| CCC (days) |  |  | 3 |  |  |  | (11 | ) |  |  | (14 | ) |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 17 |  |  |  | 23 |  |  |  | 20 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |  |  |  |  |  |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'19 |  |  | Q3 FY'19 |  |  | Q4 FY'18 |  |  | FY 2019 |  |  | FY2018 |  |
| Net Cash Provided by Operating Activities |  | $ | 399 |  |  | $ | 451 |  |  | $ | 494 |  |  | $ | 1,341 |  |  | $ | 1,478 |  |
| Purchases of Property and Equipment |  | $ | 35 |  |  | $ | 31 |  |  | $ | 48 |  |  | $ | 173 |  |  | $ | 145 |  |
| Free Cash Flow |  | $ | 364 |  |  | $ | 420 |  |  | $ | 446 |  |  | $ | 1,168 |  |  | $ | 1,333 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 22.9 | % |  |  | 26.9 | % |  |  | 27.1 | % |  |  | 19.0 | % |  |  | 22.5 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |

[0001564590-19-020164:8k_2_02:95]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| NET INCOME |  | $ | 396 |  |  | $ | 249 |  |  | $ | 290 |  |  | $ | 1,169 |  |  | $ | 116 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 13 |  |  |  | 12 |  |  |  | 46 |  |  |  | 53 |  |
| Stock-based compensation |  |  | 37 |  |  |  | 43 |  |  |  | 36 |  |  |  | 158 |  |  |  | 161 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Restructuring charges |  |  | 16 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (73 | ) |  |  | — |  |  |  | — |  |  |  | (73 | ) |  |  | (218 | ) |
| Income tax effects |  |  | (31 | ) |  |  | — |  |  |  | (31 | ) |  |  | (82 | ) |  |  | 10 |  |
| Resolution of income tax examinations |  |  | (48 | ) |  |  | — |  |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (34 | ) |  |  | — |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 856 |  |
| NON-GAAP NET INCOME |  | $ | 305 |  |  | $ | 305 |  |  | $ | 307 |  |  | $ | 1,171 |  |  | $ | 983 |  |
| COST OF REVENUES |  | $ | 566 |  |  | $ | 581 |  |  | $ | 615 |  |  | $ | 2,201 |  |  | $ | 2,210 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (36 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |  |  | (14 | ) |  |  | (13 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 554 |  |  | $ | 567 |  |  | $ | 603 |  |  | $ | 2,151 |  |  | $ | 2,161 |  |
| COST OF PRODUCT REVENUES |  | $ | 457 |  |  | $ | 469 |  |  | $ | 496 |  |  | $ | 1,752 |  |  | $ | 1,738 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (36 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |  | (3 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 447 |  |  | $ | 458 |  |  | $ | 486 |  |  | $ | 1,712 |  |  | $ | 1,699 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 99 |  |  | $ | 102 |  |  | $ | 113 |  |  | $ | 414 |  |  | $ | 447 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |  |  | (10 | ) |  |  | (10 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 97 |  |  | $ | 99 |  |  | $ | 111 |  |  | $ | 404 |  |  | $ | 437 |  |
| GROSS PROFIT |  | $ | 1,026 |  |  | $ | 982 |  |  | $ | 1,029 |  |  | $ | 3,945 |  |  | $ | 3,709 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 10 |  |  |  | 9 |  |  |  | 36 |  |  |  | 36 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 4 |  |  |  | 3 |  |  |  | 14 |  |  |  | 13 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,038 |  |  | $ | 996 |  |  | $ | 1,041 |  |  | $ | 3,995 |  |  | $ | 3,758 |  |

[0001564590-19-020164:8k_2_02:96]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| SALES AND MARKETING EXPENSES |  | $ | 439 |  |  | $ | 401 |  |  | $ | 443 |  |  | $ | 1,657 |  |  | $ | 1,706 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | (3 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (17 | ) |
| Stock-based compensation |  |  | (15 | ) |  |  | (19 | ) |  |  | (15 | ) |  |  | (67 | ) |  |  | (68 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 424 |  |  | $ | 379 |  |  | $ | 425 |  |  | $ | 1,580 |  |  | $ | 1,621 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 205 |  |  | $ | 203 |  |  | $ | 203 |  |  | $ | 827 |  |  | $ | 783 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (11 | ) |  |  | (13 | ) |  |  | (11 | ) |  |  | (48 | ) |  |  | (49 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 194 |  |  | $ | 190 |  |  | $ | 192 |  |  | $ | 779 |  |  | $ | 734 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 278 |  |  | $ | 280 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (7 | ) |  |  | (29 | ) |  |  | (31 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62 |  |  | $ | 60 |  |  | $ | 64 |  |  | $ | 249 |  |  | $ | 244 |  |
| RESTRUCTURING CHARGES |  | $ | 16 |  |  | $ | — |  |  | $ | — |  |  | $ | 35 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (16 | ) |  |  | — |  |  |  | — |  |  |  | (35 | ) |  |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | (73 | ) |  | $ | — |  |  | $ | — |  |  | $ | (73 | ) |  | $ | (218 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | 73 |  |  |  | — |  |  |  | — |  |  |  | 73 |  |  |  | 218 |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 656 |  |  | $ | 671 |  |  | $ | 717 |  |  | $ | 2,724 |  |  | $ | 2,551 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | (3 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (17 | ) |
| Stock-based compensation |  |  | (33 | ) |  |  | (39 | ) |  |  | (33 | ) |  |  | (144 | ) |  |  | (148 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Restructuring charges |  |  | (16 | ) |  |  | — |  |  |  | — |  |  |  | (35 | ) |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | 73 |  |  |  | — |  |  |  | — |  |  |  | 73 |  |  |  | 218 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 680 |  |  | $ | 629 |  |  | $ | 681 |  |  | $ | 2,608 |  |  | $ | 2,599 |  |

[0001564590-19-020164:8k_2_02:97]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| INCOME FROM OPERATIONS |  | $ | 370 |  |  | $ | 311 |  |  | $ | 312 |  |  | $ | 1,221 |  |  | $ | 1,158 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 13 |  |  |  | 12 |  |  |  | 46 |  |  |  | 53 |  |
| Stock-based compensation |  |  | 37 |  |  |  | 43 |  |  |  | 36 |  |  |  | 158 |  |  |  | 161 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Restructuring charges |  |  | 16 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (73 | ) |  |  | — |  |  |  | — |  |  |  | (73 | ) |  |  | (218 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 358 |  |  | $ | 367 |  |  | $ | 360 |  |  | $ | 1,387 |  |  | $ | 1,159 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 384 |  |  | $ | 319 |  |  | $ | 328 |  |  | $ | 1,268 |  |  | $ | 1,199 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 13 |  |  |  | 12 |  |  |  | 46 |  |  |  | 53 |  |
| Stock-based compensation |  |  | 37 |  |  |  | 43 |  |  |  | 36 |  |  |  | 158 |  |  |  | 161 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Restructuring charges |  |  | 16 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (73 | ) |  |  | — |  |  |  | — |  |  |  | (73 | ) |  |  | (218 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 372 |  |  | $ | 375 |  |  | $ | 376 |  |  | $ | 1,434 |  |  | $ | 1,200 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | (12 | ) |  | $ | 70 |  |  | $ | 38 |  |  | $ | 99 |  |  | $ | 1,083 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 31 |  |  |  | — |  |  |  | 31 |  |  |  | 82 |  |  |  | (10 | ) |
| Resolution of income tax examinations |  |  | 48 |  |  |  | — |  |  |  | — |  |  |  | 48 |  |  |  | — |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | — |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (856 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 67 |  |  | $ | 70 |  |  | $ | 69 |  |  | $ | 263 |  |  | $ | 217 |  |
| NET INCOME PER SHARE |  | $ | 1.59 |  |  | $ | 0.98 |  |  | $ | 1.06 |  |  | $ | 4.51 |  |  | $ | 0.42 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.03 |  |  |  | 0.05 |  |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.19 |  |
| Stock-based compensation |  |  | 0.15 |  |  |  | 0.17 |  |  |  | 0.13 |  |  |  | 0.61 |  |  |  | 0.58 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.02 |  |
| Restructuring charges |  |  | 0.06 |  |  |  | — |  |  |  | — |  |  |  | 0.14 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (0.29 | ) |  |  | — |  |  |  | — |  |  |  | (0.28 | ) |  |  | (0.79 | ) |
| Income tax effects |  |  | (0.12 | ) |  |  | — |  |  |  | (0.11 | ) |  |  | (0.32 | ) |  |  | 0.04 |  |
| Resolution of income tax examinations |  |  | (0.19 | ) |  |  | — |  |  |  | — |  |  |  | (0.19 | ) |  |  | — |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.13 | ) |  |  | — |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3.10 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.22 |  |  | $ | 1.20 |  |  | $ | 1.12 |  |  | $ | 4.52 |  |  | $ | 3.56 |  |

[0001564590-19-020164:8k_2_02:98]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| Gross margin-GAAP |  |  | 64.4 | % |  |  | 62.8 | % |  |  | 62.6 | % |  |  | 64.2 | % |  |  | 62.7 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 0.9 | % |  |  | 0.7 | % |  |  | 0.8 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 65.2 | % |  |  | 63.7 | % |  |  | 63.3 | % |  |  | 65.0 | % |  |  | 63.5 | % |
| GAAP cost of revenues |  | $ | 566 |  |  | $ | 581 |  |  | $ | 615 |  |  | $ | 2,201 |  |  | $ | 2,210 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (36 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |  |  | (14 | ) |  |  | (13 | ) |
| Non-GAAP cost of revenues |  | $ | 554 |  |  | $ | 567 |  |  | $ | 603 |  |  | $ | 2,151 |  |  | $ | 2,161 |  |
| Net revenues |  | $ | 1,592 |  |  | $ | 1,563 |  |  | $ | 1,644 |  |  | $ | 6,146 |  |  | $ | 5,919 |  |

[0001564590-19-020164:8k_2_02:99]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| Product gross margin-GAAP |  |  | 54.3 | % |  |  | 51.5 | % |  |  | 51.7 | % |  |  | 53.3 | % |  |  | 50.7 | % |
| Cost of product revenues adjustments |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 55.3 | % |  |  | 52.6 | % |  |  | 52.7 | % |  |  | 54.4 | % |  |  | 51.8 | % |
| GAAP cost of product revenues |  | $ | 457 |  |  | $ | 469 |  |  | $ | 496 |  |  | $ | 1,752 |  |  | $ | 1,738 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (36 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Non-GAAP cost of product revenues |  | $ | 447 |  |  | $ | 458 |  |  | $ | 486 |  |  | $ | 1,712 |  |  | $ | 1,699 |  |
| Product revenues |  | $ | 1,000 |  |  | $ | 967 |  |  | $ | 1,027 |  |  | $ | 3,755 |  |  | $ | 3,525 |  |

[0001564590-19-020164:8k_2_02:100]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 71.7 | % |  |  | 71.4 | % |  |  | 70.5 | % |  |  | 71.3 | % |  |  | 70.0 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.6 | % |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.7 | % |  |  | 0.7 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 72.3 | % |  |  | 72.3 | % |  |  | 71.0 | % |  |  | 72.0 | % |  |  | 70.7 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 99 |  |  | $ | 102 |  |  | $ | 113 |  |  | $ | 414 |  |  | $ | 447 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |  |  | (10 | ) |  |  | (10 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 97 |  |  | $ | 99 |  |  | $ | 111 |  |  | $ | 404 |  |  | $ | 437 |  |
| Hardware maintenance and other services revenues |  | $ | 350 |  |  | $ | 357 |  |  | $ | 383 |  |  | $ | 1,445 |  |  | $ | 1,492 |  |

[0001564590-19-020164:8k_2_02:101]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| GAAP effective tax rate |  |  | (3.1 | )% |  |  | 21.9 | % |  |  | 11.6 | % |  |  | 7.8 | % |  |  | 90.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 8.3 | % |  |  | (3.2 | )% |  |  | 6.8 | % |  |  | 4.9 | % |  |  | (0.8 | )% |
| Resolution of income tax examinations |  |  | 12.9 | % |  |  | — | % |  |  | — | % |  |  | 3.3 | % |  |  | — | % |
| Income tax benefit of ASC 606 adoption |  |  | — | % |  |  | — | % |  |  | — | % |  |  | 2.4 | % |  |  | — | % |
| Tax reform |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | (71.4 | )% |
| Non-GAAP effective tax rate |  |  | 18.1 | % |  |  | 18.7 | % |  |  | 18.4 | % |  |  | 18.4 | % |  |  | 18.1 | % |

[0001564590-19-020164:8k_2_02:102]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY19 |  |  | Q3'FY19 |  |  | Q4'FY18 |  |  | FY2019 |  |  | FY2018 |  |
| Net cash provided by operating activities |  | $ | 399 |  |  | $ | 451 |  |  | $ | 494 |  |  | $ | 1,341 |  |  | $ | 1,478 |  |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (31 | ) |  |  | (48 | ) |  |  | (173 | ) |  |  | (145 | ) |
| Free cash flow |  | $ | 364 |  |  | $ | 420 |  |  | $ | 446 |  |  | $ | 1,168 |  |  | $ | 1,333 |  |

[0001564590-19-020164:8k_2_02:103]
Some items may not add or recalculate due to rounding.

[0001564590-19-020164:8k_2_02:104]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FIRST QUARTER FISCAL 2020 |  |
|  |  | First Quarter |  |
|  |  | Fiscal 2020 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.78 - $0.86 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the First Quarter Fiscal 2020: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.16 | ) |
| Restructuring charges |  |  | (0.07 | ) |
| Income tax effects |  |  | 0.05 |  |
| Total Adjustments |  |  | (0.22 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.56 - $0.64 |  |

[0001564590-19-020164:8k_2_02:105]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2020 |
| (Unaudited) |
|  |  | GROSS MARGIN |
| Gross Margin - Non-GAAP Guidance |  | 64% - 65% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 63% - 64% |
|  |  | OPERATING MARGIN |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (3)% |
| Gain on sale of properties |  | 1% |
| Operating Margin - GAAP Guidance |  | 20% - 21% |
| Some items may not add or recalculate due to rounding |  |  |

[0001564590-19-020164:8k_2_02:106]
Press Contact:

[0001564590-19-020164:8k_2_02:107]
Madge Miller

[0001564590-19-020164:8k_2_02:108]
NetApp

[0001564590-19-020164:8k_2_02:109]
1 408 419 5263

[0001564590-19-020164:8k_2_02:110]
madge.miller@netapp.com

[0001564590-19-020164:8k_2_02:111]
Investor Contact:

[0001564590-19-020164:8k_2_02:112]
Lance Berger

[0001564590-19-020164:8k_2_02:113]
NetApp

[0001564590-19-020164:8k_2_02:114]
1 408 822 6628

[0001564590-19-020164:8k_2_02:115]
lance.berger@netapp.com

## item 5.02 — body, verbatim

[0001564590-19-020164:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-19-020164:8k_body:2]
(e)

[0001564590-19-020164:8k_body:3]
Fiscal 2020 Compensation

[0001564590-19-020164:8k_body:4]
On May 16, 2019, the Compensation Committee (the “Committee”) of the Board of Directors of NetApp, Inc. (the “Company”) approved the fiscal year 2020 (“FY 20”) terms of cash compensation for the named executive officers identified below in the amounts reflected below:

[0001564590-19-020164:8k_body:5]
Named Executive Officer

[0001564590-19-020164:8k_body:6]
FY 20 Salary (1)

[0001564590-19-020164:8k_body:7]
FY 20 Target Incentive Compensation Award (2) (3)

[0001564590-19-020164:8k_body:8]
George Kurian

[0001564590-19-020164:8k_body:9]
Chief Executive Officer and President

[0001564590-19-020164:8k_body:10]
$950,000

[0001564590-19-020164:8k_body:11]
170%

[0001564590-19-020164:8k_body:12]
Ronald J. Pasek

[0001564590-19-020164:8k_body:13]
Executive Vice President and Chief Financial Officer

[0001564590-19-020164:8k_body:14]
$626,775

[0001564590-19-020164:8k_body:15]
110%

[0001564590-19-020164:8k_body:16]
Henri Richard

[0001564590-19-020164:8k_body:17]
Executive Vice President, Worldwide Field and Customer Operations

[0001564590-19-020164:8k_body:18]
$600,000

[0001564590-19-020164:8k_body:19]
110%

[0001564590-19-020164:8k_body:20]
Joel D. Reich

[0001564590-19-020164:8k_body:21]
Executive Vice President, Product Operations

[0001564590-19-020164:8k_body:22]
$524,000

[0001564590-19-020164:8k_body:23]
110%

[0001564590-19-020164:8k_body:24]
Matthew K. Fawcett

[0001564590-19-020164:8k_body:25]
Senior Vice President, General Counsel and Secretary

[0001564590-19-020164:8k_body:26]
$548,000

[0001564590-19-020164:8k_body:27]
80%

[0001564590-19-020164:8k_body:28]
(1)

[0001564590-19-020164:8k_body:29]
Effective April 27, 2019. The salaries for Messrs. Richard and Reich are unchanged from fiscal year 2019.

[0001564590-19-020164:8k_body:30]
(2)

[0001564590-19-020164:8k_body:31]
Expressed as a target percentage of base salary.  Incentive compensation for the Company’s named executive officers will be established pursuant and subject to the terms of the Company’s Executive Compensation Plan.

[0001564590-19-020164:8k_body:32]
(3)

[0001564590-19-020164:8k_body:33]
All target incentive compensation awards are unchanged from fiscal year 2019.

[0001564590-19-020164:8k_body:34]
Performance-Based Restricted Stock Units

[0001564590-19-020164:8k_body:35]
On May 16, 2019, the Committee approved terms of performance-based restricted stock units that are expected to be granted and become effective in June 2019 under one of two forms of Restricted Stock Unit Agreement (Performance-Based) (each, a “PBRSU Agreement” and together, the “PBRSU Agreements”).  The two forms of PBRSU Agreement are substantially similar except for the inclusion of the applicable performance metric in the applicable PBRSU Agreement.  The PBRSU Agreements have terms that are substantially consistent with the terms contained in the applicable form of Restricted Stock Unit Agreement (Performance-Based) included as exhibits to the Company’s Form 10-Q filed on August 21, 2018 (the “Prior Agreements”), subject to the following changes:

[0001564590-19-020164:8k_body:36]
•

[0001564590-19-020164:8k_body:37]
If the executive takes an approved leave of absence of 6 months or more during the performance period, then the number of PBRSUs that will be eligible to vest will be pro-rated based on the number of months that the executive was not on a leave of absence.

[0001564590-19-020164:8k_body:38]
•

[0001564590-19-020164:8k_body:39]
At the end of the performance period, the Company’s Total Stockholder Return (as such term is defined in the applicable PBRSU Agreement) and the total stockholder return of certain benchmark peers of the Company will be calculated and collectively listed from largest to smallest with the number of RSUs becoming eligible to vest based on the Company’s percentile ranking in this group.

[0001564590-19-020164:8k_body:40]
The foregoing summary of the PBRSU Agreements does not purport to be complete and is qualified in its entirety by the full text of the PBRSU Agreements, copies of which will be filed with the Company’s Annual Report on Form 10-K for the year ending April 26, 2019.

[0001564590-19-020164:8k_body:41]
Change of Control Severance Agreements

[0001564590-19-020164:8k_body:42]
On May 16, 2019, as a result of the expiration of the existing change of control agreements and in connection with a review of executive compensation, the Committee approved a new form of double trigger Change of Control Severance Agreement (the “Agreement”). The Company expects to enter into an Agreement with each of its named executive officers, including the Chief Executive Officer, and certain senior executives and the Agreement will be used on a going forward basis by the Company.

[0001564590-19-020164:8k_body:43]
The material terms of the Agreement are as follows:

[0001564590-19-020164:8k_body:44]
Severance Benefits. If the Company terminates an executive’s employment without Cause (as such term is defined in the Agreement) (and not by reason of executive’s death or Disability (as such term is defined in the Agreement)) or if the executive resigns for Good Reason (as such term is defined in the Agreement), and such termination occurs on or within 24 months after the first Change of Control (as such term is defined in the Agreement) that occurs after the effective date of the Agreement, then, subject to the executive signing and not revoking a separation agreement and release of claims in favor of the Company, the executive will receive the following from the Company:

[0001564590-19-020164:8k_body:45]
•

[0001564590-19-020164:8k_body:46]
A lump sum severance payment (less applicable withholding taxes) equal to the sum of (A) 150% (200% in the case of the Chief Executive Officer) of an executive’s annual base salary as in effect immediately prior to the executive’s termination date or (if greater) at the level in effect immediately prior to the Change of Control; and (B) 150% (200% in the case of the Chief Executive Officer) of an executive’s target annual bonus in effect immediately prior to the executive’s termination date or (if greater) at the level in effect immediately prior to the Change of Control.

[0001564590-19-020164:8k_body:47]
•

[0001564590-19-020164:8k_body:48]
A lump sum severance payment (less applicable withholding taxes) equal to the greater of (A) the executive’s target annual bonus in effect for the fiscal year in which the termination occurs or (if greater) in effect immediately prior to the Change of Control; or (B) the bonus the executive would have received for the fiscal year in which the termination occurs based on actual performance being accrued for financial accounting purposes at the time of termination against the performance goals applicable to the executive’s bonus arrangement in effect immediately prior to the executive’s termination date, in either case, which will be pro-rated for the period during the fiscal year executive was employed by the Company.

[0001564590-19-020164:8k_body:49]
•

[0001564590-19-020164:8k_body:50]
All outstanding equity awards that are subject to time-based vesting will vest as to that portion of the award that would have vested through the 48-month period following the executive’s termination date had the executive remained employed through such period. Additionally, unless otherwise provided in the applicable award agreement, the executive will be entitled to accelerated vesting as to an additional 100% of the then-unvested portion of all of his or her outstanding equity awards that are scheduled to vest pursuant to performance-based criteria, if any. Each executive will have one year following the date of his or her termination in which to exercise any outstanding stock options or other similar rights to acquire Company stock (but such post-termination exercise period will not extend beyond the original maximum term of the award).

[0001564590-19-020164:8k_body:51]
•

[0001564590-19-020164:8k_body:52]
If the executive elects continuation coverage pursuant to COBRA for executive and his or her eligible dependents, the Company will reimburse the executive for the COBRA premiums for such coverage until the earlier of (A) 18 months (24 months in the case of the Chief Executive Officer), (B) the date upon which the executive and/or the executive’s eligible dependents are covered under similar plans or (C) the date upon which executive ceases to be eligible for coverage under COBRA. If the Company determines that it cannot provide the foregoing benefit without violating applicable law or being subject to an excise tax, then the Company will, in lieu of the COBRA reimbursement, pay the executive a taxable lump-sum payment in an amount equal to the monthly COBRA premium that the executive would have been required to pay to continue the executive’s group health coverage multiplied by 18 (24 in the case of the Chief Executive Officer).

[0001564590-19-020164:8k_body:53]
Excise Tax. In the event that the severance payments and other benefits payable to an executive constitute “parachute payments” under Section 280G of the U.S. tax code and would be subject to the applicable excise tax, then the executive’s severance benefits will be either (A) delivered in full or (B) delivered to such lesser extent which would result in no portion of such benefits being subject to the excise tax, whichever results in the receipt by the executive on an after-tax basis of the greatest amount of benefits.

[0001564590-19-020164:8k_body:54]
Term. Each Agreement has an initial term of three years and renews for additional successive one-year terms unless either party provides the other party written notice of non-renewal 12 months in advance of the expiration date. If a Change of Control occurs and there are fewer than 24 months remaining in the term of the Agreement, the term of the Agreement will automatically be extended for 24 months following the effective date of the Change of Control. Additionally, if there is an initial occurrence of an act or omission by the Company that could constitute “Good Reason” for termination, and the expiration date of any Company cure period related to such act or omission could occur following the expiration of the term of the Agreement, then the term of the Agreement will extend automatically through the date that is 90 days following the expiration of such cure period. If an executive becomes entitled to severance benefits pursuant to his or her Agreement, the Agreement will not terminate until all obligations of the Company under the Agreement have been satisfied.

[0001564590-19-020164:8k_body:55]
The foregoing description of the material terms of the Agreement does not purport to be complete and is qualified in its entirety by the terms and conditions of the Agreement, the form of which is filed herewith as Exhibit 10.1.
