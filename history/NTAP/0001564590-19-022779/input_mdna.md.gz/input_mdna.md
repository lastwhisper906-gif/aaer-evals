# NTAP MD&A — 0001564590-19-022779


## mdna

[0001564590-19-022779:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001564590-19-022779:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0001564590-19-022779:mdna:3]
Executive Overview

[0001564590-19-022779:mdna:4]
Our Company

[0001564590-19-022779:mdna:5]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation and optimize their operations.

[0001564590-19-022779:mdna:6]
NetApp delivers a Data Fabric built for the data-driven world. Our Data Fabric simplifies the integration and orchestration of data for applications and analytics in clouds, across clouds and on-premises to accelerate digital transformation. We deliver a Data Fabric with consistent data services for data visibility and insights, data access and control, and data protection and security, that unleashes the power of data to achieve a new competitive advantage.

[0001564590-19-022779:mdna:7]
We focus on delivering an exceptional customer experience to become our customers’ preferred data partner. NetApp’s unique approach to data services enables organizations to inspire innovation with the cloud, build clouds to accelerate new services, and modernize IT architecture with cloud-connected flash.

[0001564590-19-022779:mdna:8]
With NetApp products and solutions, customers can:

[0001564590-19-022779:mdna:9]
|  | • | Continually fuel business growth by delivering data-rich customer experiences through new application deployments that easily use data and services regardless of where they reside or in what form. |

[0001564590-19-022779:mdna:10]
|  | • | Accelerate digital transformation by developing a next-generation, cloud-architected infrastructure that manages data and services as one integrated resource supporting both public and private clouds. |

[0001564590-19-022779:mdna:11]
|  | • | Free the resources necessary to fund transformation by deploying the industry’s leading flash storage solution, which is highly efficient and scales from the edge to the core to the cloud. |

[0001564590-19-022779:mdna:12]
Customers are attracted by the speed and scale benefits of the public cloud but need new data management capabilities to keep control of data as it moves beyond the walls of the enterprise. NetApp believes the hybrid cloud is fast becoming the dominant model for enterprise IT. Our Data Fabric approach enables our customers to manage, secure and protect their data from on-premises to public to hybrid clouds, all at the scale needed to accommodate the exponential data growth of the digital world.

[0001564590-19-022779:mdna:13]
Budget constraints and skill imbalances lead our customers to seek help in integrating, deploying and managing the solutions they need to stay competitive. This drives demand for converged and hyper-converged infrastructure solutions. FlexPod is the converged infrastructure of choice for many of the largest enterprises around the globe. Customers can break free from the limits of first-generation HCI with NetApp HCI and attain guaranteed performance with high levels of flexibility, scale, automation, and integration with the Data Fabric.

[0001564590-19-022779:mdna:14]
Flash plays a key role in customers’ digital transformation efforts as they seek to gain advantage through greater speed, responsiveness and value from key business applications—all while lowering total cost of ownership. All-flash array technology is the de facto choice as customers seek performance and economic benefits from replacing hard disk installations. With a highly differentiated and broad portfolio of all-flash and hybrid array offerings, NetApp is well positioned to enable customers to accomplish this transition.

[0001564590-19-022779:mdna:15]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we have historically grouped our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, enterprise software license agreements (ELAs) and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media.

[0001564590-19-022779:mdna:16]
Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively manage their data. Revenues generated by our Cloud Data Services offerings are included in software maintenance revenues.

[0001564590-19-022779:mdna:17]
30

[0001564590-19-022779:mdna:18]
Financial Results and Key Performance Metrics Overview

[0001564590-19-022779:mdna:19]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except per share amounts, percentages and cash conversion cycle):

[0001564590-19-022779:mdna:20]
|  |  | Year Ended |  |
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Net revenues |  | $ | 6,146 |  |  | $ | 5,919 |  |  | $ | 5,491 |  |
| Gross profit |  | $ | 3,945 |  |  | $ | 3,709 |  |  | $ | 3,364 |  |
| Gross profit margin percentage |  |  | 64 | % |  |  | 63 | % |  |  | 61 | % |
| Income from operations |  | $ | 1,221 |  |  | $ | 1,158 |  |  | $ | 621 |  |
| Income from operations as a percentage of net revenues |  |  | 20 | % |  |  | 20 | % |  |  | 11 | % |
| Provision for income taxes |  | $ | 99 |  |  | $ | 1,083 |  |  | $ | 140 |  |
| Net income |  | $ | 1,169 |  |  | $ | 116 |  |  | $ | 481 |  |
| Diluted net income per share |  | $ | 4.51 |  |  | $ | 0.42 |  |  | $ | 1.71 |  |
| Operating cash flows |  | $ | 1,341 |  |  | $ | 1,478 |  |  | $ | 986 |  |

[0001564590-19-022779:mdna:21]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Cash conversion cycle (days) |  |  | 3 |  |  |  | (14 | ) |

[0001564590-19-022779:mdna:22]
|  | • | Net revenues: Our net revenues increased 4% in fiscal 2019 compared to fiscal 2018. This was primarily due to an increase of 7% in product revenues, partially offset by a 3% decrease in software and hardware maintenance and other services revenues. |

[0001564590-19-022779:mdna:23]
|  | • | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues increased by one percentage point in fiscal 2019 compared to fiscal 2018, reflecting an increase in gross profit margin on product revenues, and, to a lesser extent, an increase in gross profit margin on hardware maintenance and other services revenues. |

[0001564590-19-022779:mdna:24]
|  | • | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues remained relatively flat in fiscal 2019 compared to fiscal 2018. |

[0001564590-19-022779:mdna:25]
|  | • | Provision for income taxes: Our provision for income taxes decreased significantly in fiscal 2019 compared to fiscal 2018 as significant charges were recorded in fiscal 2018 in connection with U.S. tax reform. |

[0001564590-19-022779:mdna:26]
|  | • | Net income and Diluted income per share: The increase in both net income and diluted net income per share in fiscal 2019 compared to fiscal 2018 reflect the factors discussed above. Diluted net income per share was favorably impacted by a 6% decrease in the annual weighted average number of dilutive shares, primarily due to share repurchases. |

[0001564590-19-022779:mdna:27]
|  | • | Operating cash flows: Operating cash flows decreased by 9% in fiscal 2019 compared to fiscal 2018, reflecting changes in operating assets and liabilities, partially offset by higher net income. |

[0001564590-19-022779:mdna:28]
|  | • | Deferred revenue and financed unearned services revenue: Total deferred revenue and financed unearned services revenue increased $305 million, or 9%, as of fiscal 2019 year end compared to fiscal 2018 year end primarily due to increases in the installed base and aggregate contract values under software and hardware maintenance contracts. |

[0001564590-19-022779:mdna:29]
|  | • | Cash Conversion Cycle: Our cash conversion cycle was 3 days in the fourth quarter of fiscal 2019, compared to (14) days in the corresponding period of fiscal 2018, reflecting lower Days Payables Outstanding, higher Days Inventory Outstanding, and higher Days Sales Outstanding. |

[0001564590-19-022779:mdna:30]
Stock Repurchase Program and Dividend Activity

[0001564590-19-022779:mdna:31]
During fiscal 2019, we repurchased 29 million shares of our common stock at an average price of $72.87 per share, for an aggregate purchase price of $2.1 billion. We also declared cash dividends of an aggregate of $1.60 per share in fiscal 2019, for which we paid an aggregate of $403 million.

[0001564590-19-022779:mdna:32]
Adoption of Revenue Accounting Standard

[0001564590-19-022779:mdna:33]
As of the beginning of fiscal 2019, we adopted the new accounting standard Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, our prior years consolidated financial statements and supplementary data, as presented herein, have been restated to conform to the new rules. As illustrated in Note 7 – Revenue of the Notes to Consolidated Financial Statements, the overall impact of adoption was not significant to prior years. However, application of the new rules to our ELAs resulted in over $100 million of product revenues for such arrangements in fiscal 2019, that are incremental to the amounts we would have recognized under the old standard. Under ASC 606, we recognize the software license fee component of our ELAs up-front, whereas under the prior rules the software license fee was recognized over the term of the ELA.

[0001564590-19-022779:mdna:34]
31

[0001564590-19-022779:mdna:35]
Restructuring Events

[0001564590-19-022779:mdna:36]
During fiscal 2019, we announced two separate restructuring and reduction in workforce plans designed to reduce costs and redirect resources to our highest return activities. In connection with these plans, we reduced our worldwide headcount by less than 3%, and incurred aggregate charges of approximately $35 million, consisting primarily of employee severance costs.

[0001564590-19-022779:mdna:37]
Joint Venture

[0001564590-19-022779:mdna:38]
During fiscal 2019, we formed a joint venture with Lenovo (Beijing) Information Technology Ltd. (“Lenovo”) in China and, in February 2019, contributed assets to the newly formed entity, Lenovo NetApp Technology Limited (“LNTL”), which began operations the same month, in exchange for a non-controlling 49% equity interest. The assets we contributed had an aggregate book value of $7 million, while the fair value of our equity interest in LNTL was determined to be $80 million, resulting in a gain of $73 million. LNTL will be integral to our sales channels strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. It will also endeavor to localize our products and services, and to develop new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001564590-19-022779:mdna:39]
Critical Accounting Policies and Estimates

[0001564590-19-022779:mdna:40]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001564590-19-022779:mdna:41]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001564590-19-022779:mdna:42]
Revenue Recognition

[0001564590-19-022779:mdna:43]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0001564590-19-022779:mdna:44]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  | • | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
| • | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  | • | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |

[0001564590-19-022779:mdna:45]
32

[0001564590-19-022779:mdna:46]
| • | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them using available information including, but not limited to, market data and other observable inputs. |  | • | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0001564590-19-022779:mdna:47]
Inventory Valuation and Purchase Order Accruals

[0001564590-19-022779:mdna:48]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001564590-19-022779:mdna:49]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  | • | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
| • | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | • | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001564590-19-022779:mdna:50]
Goodwill and Purchased Intangible Assets

[0001564590-19-022779:mdna:51]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0001564590-19-022779:mdna:52]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001564590-19-022779:mdna:53]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of our reporting unit may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2019, we performed a quantitative test and determined the fair value of our reporting unit substantially exceeded its carrying amount, therefore, found no impairment of goodwill.

[0001564590-19-022779:mdna:54]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and

[0001564590-19-022779:mdna:55]
purchased intangible assets:

[0001564590-19-022779:mdna:56]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | • | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
| • | Evaluations of possible goodwill and purchased intangible assets impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting unit and assets. |  | • | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting unit and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001564590-19-022779:mdna:57]
Product Warranties

[0001564590-19-022779:mdna:58]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-19-022779:mdna:59]
The following are the key estimates and assumptions and corresponding uncertainties for product warranties:

[0001564590-19-022779:mdna:60]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | Estimated future software and hardware warranty costs are based on historical and projected warranty claim rates, product failure rates, historical and projected materials and logistics costs, distribution and labor costs and knowledge of specific product failures that are outside of our typical experience. We also evaluate our estimates to assess the adequacy of our warranty liability considering the size of the installed base of products subject to warranty protection and adjust the estimates as necessary. |  | • | Although we engage in product quality programs and processes, if we experience unexpected quality issues resulting in higher failure rates or experience increases in costs to remediate product failures, additional warranty costs may be incurred. Additionally, for new products our warranty liability is based on limited historical experience. If our projections differ from such limited experience, our warranty costs may increase, which could adversely impact our gross margins. |

[0001564590-19-022779:mdna:61]
Valuation of Investment Securities

[0001564590-19-022779:mdna:62]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is subject to market price volatility until they are sold.

[0001564590-19-022779:mdna:63]
The following are the key estimates and assumptions and corresponding uncertainties for the valuation of our investment securities:

[0001564590-19-022779:mdna:64]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |

[0001564590-19-022779:mdna:65]
| • | The estimated fair value of our debt securities, and the associated accounting for unrealized losses is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent the security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. If we determine that an investment has an other-than-temporary decline in fair value, we recognize the investment loss in earnings. |  | • | The fair value of our investments in debt securities could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer, decreases in the marketability of the securities. If the fair value of our investments decreases significantly and, if because of changes in our ability and intent to continue to hold the securities or other factors, it is determined to be other-than-temporary, we may incur impairment charges that could adversely affect our results of operations. |

[0001564590-19-022779:mdna:66]
Income Taxes

[0001564590-19-022779:mdna:67]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001564590-19-022779:mdna:68]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0001564590-19-022779:mdna:69]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  | • | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
| • | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | • | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| • | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | • | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001564590-19-022779:mdna:70]
New Accounting Standards

[0001564590-19-022779:mdna:71]
See Note 2 – Recent Accounting Standards Not Yet Effective of the Notes to Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-19-022779:mdna:72]
35

[0001564590-19-022779:mdna:73]
Results of Operations

[0001564590-19-022779:mdna:74]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2019, which ended on April 26, 2019, fiscal year 2018, which ended on April 27, 2018, and fiscal year 2017, which ended on April 28, 2017, were each 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-19-022779:mdna:75]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001564590-19-022779:mdna:76]
|  |  | Fiscal Year |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 61 |  | % |  | 60 |  | % |  | 56 |  | % |
| Software maintenance |  |  | 15 |  |  |  | 15 |  |  |  | 16 |  |  |
| Hardware maintenance and other services |  |  | 24 |  |  |  | 25 |  |  |  | 28 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 29 |  |  |  | 29 |  |  |  | 29 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 8 |  |  |  | 9 |  |  |
| Gross profit |  |  | 64 |  |  |  | 63 |  |  |  | 61 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 29 |  |  |  | 30 |  |  |
| Research and development |  |  | 13 |  |  |  | 13 |  |  |  | 14 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |
| Gain on sale or derecognition of assets |  |  | (1 | ) |  |  | (4 | ) |  |  | — |  |  |
| Total operating expenses |  |  | 44 |  |  |  | 43 |  |  |  | 50 |  |  |
| Income from operations |  |  | 20 |  |  |  | 20 |  |  |  | 11 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |
| Income before income taxes |  |  | 21 |  |  |  | 20 |  |  |  | 11 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 18 |  |  |  | 3 |  |  |
| Net income |  |  | 19 |  | % |  | 2 |  | % |  | 9 |  | % |

[0001564590-19-022779:mdna:77]
Percentages may not add due to rounding

[0001564590-19-022779:mdna:78]
Discussion and Analysis of Results of Operations

[0001564590-19-022779:mdna:79]
Overview — Net revenues for fiscal 2019 were $6,146 million, an increase of $227 million, or 4% compared to fiscal 2018, reflecting higher product and software maintenance revenues, partially offset by slightly lower hardware maintenance and other services revenues. Net revenues for fiscal 2018 were $5,919 million, an increase of $428 million, or 8% compared to fiscal 2017, reflecting higher product revenues, partially offset by slightly lower hardware maintenance and other services revenues.

[0001564590-19-022779:mdna:80]
Gross profit as a percentage of net revenues for fiscal 2019 increased by one and a half percentage points compared to fiscal 2018, reflecting higher margins on product revenues and hardware maintenance and other services revenues. Gross profit margins on product revenues in fiscal 2019 increased two and a half percentage points compared to fiscal 2018, primarily due to higher average selling prices (ASPs) and revenue recognized during fiscal 2019 related to the software license components of several ELAs, partially offset by the unfavorable impact of foreign exchange rate fluctuations. Gross profit as a percentage of net revenues for fiscal 2018 increased by one and a half percentage points compared to fiscal 2017, reflecting higher margins on product revenues, and slightly higher margins on hardware maintenance and other services revenues.

[0001564590-19-022779:mdna:81]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2019 totaled $2,762 million, or 45% of net revenues, representing a decrease of two percentage points compared to fiscal 2018, primarily due to higher net revenues in the current year. Sales and marketing, research and development, and general and administrative expenses for fiscal 2018 totaled $2,769 million, or 47% of net revenues, representing a decrease of two and a half percentage points compared to fiscal 2017, primarily due to higher net revenues in fiscal 2018, coupled with relatively consistent average headcount in both fiscal years.

[0001564590-19-022779:mdna:82]
Net Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:83]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Net revenues |  |  | $ | 6,146 |  |  | $ | 5,919 |  |  |  | 4 | % |  | $ | 5,491 |  |  |  | 8 | % |

[0001564590-19-022779:mdna:84]
The increase in net revenues for fiscal 2019 compared to fiscal 2018 was primarily due to an increase of $230 million in product revenues. Product revenues as a percent of net revenues increased one and a half percentage points in fiscal 2019 compared to fiscal 2018.

[0001564590-19-022779:mdna:85]
The increase in net revenues for fiscal 2018 compared to fiscal 2017 was primarily due to an increase of $465 million in product revenues. Product revenues as a percent of net revenues increased four percentage points in fiscal 2018 compared to fiscal 2017.

[0001564590-19-022779:mdna:86]
Sales through our indirect channels represented 76%, 79% and 78% of net revenues in fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:mdna:87]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001564590-19-022779:mdna:88]
|  |  | Fiscal Year |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 23 | % |  |  | 22 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-19-022779:mdna:89]
Product Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:90]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Product revenues |  |  | $ | 3,755 |  |  | $ | 3,525 |  |  |  | 7 | % |  | $ | 3,060 |  |  |  | 15 | % |

[0001564590-19-022779:mdna:91]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, original equipment manufacturer (OEM) products and add-on hardware and software.

[0001564590-19-022779:mdna:92]
Product revenues from strategic solutions represented 72% of product revenues in fiscal 2019, compared to 70% in fiscal 2018. Product revenues from mature solutions represented 28% of product revenues in fiscal 2019, compared to 30% in fiscal 2018.

[0001564590-19-022779:mdna:93]
Total product revenues from strategic solutions totaled $2,709 million in fiscal 2019, reflecting a 10% increase from $2,468 million in fiscal 2018. This increase was primarily due to over $100 million of revenues from the software license component of several ELAs in fiscal 2019 which, under ASC 606, were recognized up-front. Comparable ELA revenues were immaterial in fiscal 2018. Revenues generated from the sale of optional add-on software unrelated to ELAs, and hyperconverged infrastructure solutions also increased in fiscal 2019, offset by a decrease in unit volume of Clustered ONTAP systems. Total product revenue from mature solutions totaled $1,046 million in fiscal 2019 reflecting a slight decrease from $1,057 million in fiscal 2018 due to our discontinuation of 7-mode systems in fiscal 2019, reflecting the movement of customers to our newer products, partially offset by an increase in add-on hardware, and related OS software revenues.

[0001564590-19-022779:mdna:94]
Total product revenues from strategic solutions totaled $2,468 million in fiscal 2018, reflecting a 23% increase from $2,000 million in fiscal 2017. This increase was primarily due to an increase in unit volume of Clustered ONTAP systems and an increase in ASP driven by sales of our All-Flash FAS products. Total product revenue from mature solutions totaled $1,057 million in fiscal 2018, reflecting a slight decrease from $1,060 million in fiscal 2017, primarily due to a decrease in unit volume of 7-mode systems and a decrease in OEM revenues, partially offset by an increase in add-on hardware, storage and related OS revenues. These fluctuations reflect our planned transition of our product offerings and the adoption by our customers of our newer all-flash and hybrid-cloud compatible products.

[0001564590-19-022779:mdna:95]
Software Maintenance Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:96]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Software maintenance revenues |  |  | $ | 946 |  |  | $ | 902 |  |  |  | 5 | % |  | $ | 905 |  |  |  | — | % |

[0001564590-19-022779:mdna:97]
Software maintenance revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes and patch releases, as well as internet and telephone access to technical support personnel located in our global support centers.

[0001564590-19-022779:mdna:98]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001564590-19-022779:mdna:99]
Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:100]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  |  | $ | 1,445 |  |  | $ | 1,492 |  |  |  | (3 | )% |  | $ | 1,526 |  |  |  | (2 | )% |

[0001564590-19-022779:mdna:101]
Hardware maintenance and other services revenues include hardware maintenance, professional services and educational and training services revenues.

[0001564590-19-022779:mdna:102]
Hardware maintenance contract revenues were $1,182 million, $1,214 million and $1,258 million in fiscal 2019, 2018 and 2017, respectively, reflecting a year over year decrease of 3% in both fiscal 2019 and fiscal 2018. These decreases were primarily attributable to a decline in ASP on contracts executed during those years, as well as lower contract renewal rates.

[0001564590-19-022779:mdna:103]
Professional services and educational and training services revenues were $263 million, $278 million and $268 million in fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:mdna:104]
Revenues by Geographic Area:

[0001564590-19-022779:mdna:105]
|  |  | Fiscal Year |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| United States, Canada and Latin America (Americas) |  |  | 56 | % |  |  | 54 | % |  |  | 55 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 32 | % |  |  | 32 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 14 | % |  |  | 13 | % |

[0001564590-19-022779:mdna:106]
Percentages may not add due to rounding

[0001564590-19-022779:mdna:107]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. During fiscal 2019, Americas revenues as a percentage of net revenues increased, reflecting higher product revenues, while EMEA revenues decreased slightly, primarily reflecting the unfavorable impact of foreign exchange rate fluctuations. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in fiscal 2018 and fiscal 2017.

[0001564590-19-022779:mdna:108]
Cost of Revenues

[0001564590-19-022779:mdna:109]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-19-022779:mdna:110]
Cost of Product Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:111]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 1,752 |  |  | $ | 1,738 |  |  |  | 1 | % |  | $ | 1,612 |  |  |  | 8 | % |

[0001564590-19-022779:mdna:112]
The changes in cost of product revenues consisted of the following (in percentage points of the total change):

[0001564590-19-022779:mdna:113]
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | — |  |  |  | 7 |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 1 |  |  |  | 8 |  |

[0001564590-19-022779:mdna:114]
38

[0001564590-19-022779:mdna:115]
Cost of product revenues represented 47%, 49% and 53% of product revenues for fiscal 2019, 2018 and 2017, respectively. Materials cost represented 90%, 91% and 91% of product costs for fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:mdna:116]
Materials costs decreased $5 million in fiscal 2019 compared to fiscal 2018, primarily due to a decline in the price of certain product components. The average unit materials costs of Clustered ONTAP systems decreased slightly in fiscal 2019 compared to fiscal 2018.

[0001564590-19-022779:mdna:117]
Margins on revenue recognized for strategic solutions were higher in fiscal 2019 compared to fiscal 2018 primarily due to the benefit of high margins realized on the software license components of several ELAs, and, to a lesser extent, higher ASPs. Margins for mature products also increased slightly in fiscal 2019. Foreign exchange rate fluctuations resulted in a slight unfavorable impact to margins in fiscal 2019.

[0001564590-19-022779:mdna:118]
Materials costs increased $108 million in fiscal 2018 compared to fiscal 2017, reflecting a 15% increase in materials costs related to strategic products, primarily due to higher unit volume of Clustered ONTAP systems. The average unit materials costs of Clustered ONTAP systems also increased slightly in fiscal 2018 compared to fiscal 2017.

[0001564590-19-022779:mdna:119]
An increase in ASP for strategic systems resulted in higher margins for strategic products in fiscal 2018 compared to the prior year. Margins in fiscal 2018 also benefitted from the favorable impact of foreign exchange rate fluctuations. Margins for mature products were relatively consistent in fiscal 2018 compared to the prior year.

[0001564590-19-022779:mdna:120]
Cost of Software Maintenance Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:121]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Cost of software maintenance revenues |  |  | $ | 35 |  |  | $ | 25 |  |  |  | 40 | % |  | $ | 28 |  |  |  | (11 | )% |

[0001564590-19-022779:mdna:122]
Cost of software maintenance revenues in dollars was relatively flat in each fiscal year presented and represented 4%, 3% and 3% of software maintenance revenues for fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:mdna:123]
Cost of Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-19-022779:mdna:124]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  |  | $ | 414 |  |  | $ | 447 |  |  |  | (7 | )% |  | $ | 487 |  |  |  | (8 | )% |

[0001564590-19-022779:mdna:125]
Cost of hardware maintenance and other services revenues decreased $33 million, or 7%, in fiscal 2019 compared to fiscal 2018 and decreased $40 million, or 8%, in fiscal 2018 compared to fiscal 2017, primarily due to the favorable impact of cost savings initiatives. Costs represented 29%, 30% and 32% of hardware maintenance and other services revenues for fiscal 2019, 2018 and 2017, respectively.

[0001564590-19-022779:mdna:126]
Operating Expenses

[0001564590-19-022779:mdna:127]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001564590-19-022779:mdna:128]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-19-022779:mdna:129]
Total compensation costs included in operating expenses decreased $15 million, or 1% during fiscal 2019 compared to fiscal 2018, primarily due to lower incentive compensation expenses reflecting lower operating performance against goals, and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations, partially offset by higher salaries and benefits expense, reflecting a slight increase in average headcount.

[0001564590-19-022779:mdna:130]
Total compensation costs included in operating expenses increased $21 million, or 1% during fiscal 2018 compared to fiscal 2017, primarily due to higher incentive compensation expense, reflecting stronger operating performance against goals, and higher salary expense, reflecting merit increases and the unfavorable impact of foreign exchange rate fluctuations. These increases were partially offset by lower stock-based compensation expense. Average headcount was relatively consistent in both fiscal years.

[0001564590-19-022779:mdna:131]
Sales and Marketing (in millions, except percentages):

[0001564590-19-022779:mdna:132]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 1,657 |  |  | $ | 1,706 |  |  |  | (3 | )% |  | $ | 1,651 |  |  |  | 3 | % |

[0001564590-19-022779:mdna:133]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following:

[0001564590-19-022779:mdna:134]
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | 1 |  |
| Commissions |  |  | — |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | (1 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | (3 | ) |  |  | 3 |  |

[0001564590-19-022779:mdna:135]
The decrease in compensation costs in fiscal 2019 reflects a slight reduction in average headcount and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. Facilities and IT support costs decreased during fiscal 2019 primarily due to cost containment efforts.

[0001564590-19-022779:mdna:136]
The increase in compensation costs in fiscal 2018 reflects higher average salaries due to merit increases and the unfavorable impact of foreign exchange rate fluctuations, partially offset by a slight reduction in average headcount. The increase in commissions expense was due to higher performance against sales goals.

[0001564590-19-022779:mdna:137]
Research and Development (in millions, except percentages):

[0001564590-19-022779:mdna:138]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 827 |  |  | $ | 783 |  |  |  | 6 | % |  | $ | 779 |  |  |  | 1 | % |

[0001564590-19-022779:mdna:139]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following:

[0001564590-19-022779:mdna:140]
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 3 |  |  |  | 1 |  |
| Development projects and outside services |  |  | 1 |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | (1 | ) |
| Other |  |  | — |  |  |  | — |  |
| Total change |  |  | 6 |  |  |  | 1 |  |

[0001564590-19-022779:mdna:141]
The increase in compensation costs for fiscal 2019 was attributable to an increase in average headcount of 7%, resulting in higher salaries and benefits expense, that was partially offset by lower incentive compensation expense and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. The average headcount increase reflects our investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities. Facilities and IT support costs increased in fiscal 2019 in connection with the increase in average headcount.

[0001564590-19-022779:mdna:142]
Development projects and outside services expense increased in each of fiscal 2019 and fiscal 2018 as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance existing products.

[0001564590-19-022779:mdna:143]
The increase in compensation costs for fiscal 2018 reflects higher incentive compensation expense than in fiscal 2017, partially offset by lower stock-based compensation expense.

[0001564590-19-022779:mdna:144]
40

[0001564590-19-022779:mdna:145]
General and Administrative (in millions, except percentages):

[0001564590-19-022779:mdna:146]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 278 |  |  | $ | 280 |  |  |  | (1 | )% |  | $ | 271 |  |  |  | 3 | % |

[0001564590-19-022779:mdna:147]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-19-022779:mdna:148]
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (3 | ) |  |  | (4 | ) |
| Professional and legal fees and outside services |  |  | 1 |  |  |  | 6 |  |
| Facilities and IT support costs |  |  | — |  |  |  | 2 |  |
| Other |  |  | 1 |  |  |  | (1 | ) |
| Total change |  |  | (1 | ) |  |  | 3 |  |

[0001564590-19-022779:mdna:149]
The decrease in compensation costs for fiscal 2019 was primarily attributable to lower incentive compensation expense. While average headcount increased in fiscal 2019, salaries and benefits expense remained relatively flat because a greater percentage of employees were located in lower cost geographies. The slight increase in professional and legal fees and outside services expense in fiscal 2019 was due to higher spending levels on projects and outside services.

[0001564590-19-022779:mdna:150]
The decrease in compensation costs for fiscal 2018 reflects lower salaries, benefits and stock-based compensation expenses due to an 8% decrease in average headcount, partially offset by higher incentive compensation expense. The increase in professional and legal fees and outside services expense in fiscal 2018 was primarily due to higher spending levels on projects and outside services, while the increase in facilities and IT support costs was primarily due to an increase in spending on IT projects.

[0001564590-19-022779:mdna:151]
Restructuring Charges (in millions, except percentages):

[0001564590-19-022779:mdna:152]
|  |  |  | Fiscal Year |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  | 2017 |  |  | % Change |
| Restructuring charges |  |  | $ | 35 |  |  | $ | — |  |  | NM |  | $ | 52 |  |  | NM |

[0001564590-19-022779:mdna:153]
In response to changes in market conditions and market demand for our products, in fiscal years 2019 and 2017, we initiated a number of business realignment plans designed to streamline our business, reduce our cost structure and focus our resources on key strategic opportunities, resulting in aggregate reductions of our global workforce of less than 3% in fiscal 2019, and approximately 6% in fiscal 2017, for which we recognized aggregate charges of $35 million and $52 million, respectively, consisting primarily of employee severance costs. See Note 13 – Restructuring Charges of the Notes to Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-19-022779:mdna:154]
Gain on Sale or Derecognition of Assets (in millions, except percentages):

[0001564590-19-022779:mdna:155]
|  |  |  | Fiscal Year |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  | 2017 |  |  | % Change |
| Gain on sale or derecognition of assets |  |  | $ | (73 | ) |  | $ | (218 | ) |  | NM |  | $ | (10 | ) |  | NM |

[0001564590-19-022779:mdna:156]
NM - Not Meaningful

[0001564590-19-022779:mdna:157]
41

[0001564590-19-022779:mdna:158]
In February 2019, we contributed cash and other assets with a total book value of $7 million to a newly formed joint venture with Lenovo in exchange for a non-controlling 49% equity interest in the new entity. The value of our equity interest was determined to be $80 million, resulting in a gain of $73 million.

[0001564590-19-022779:mdna:159]
In September 2017, we entered into an agreement to sell certain properties previously classified as assets held-for-sale for a total of $306 million, through two separate and independent closings. During fiscal 2018, the first closing occurred, and we consummated the sale of properties with a net book value of $66 million, for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-19-022779:mdna:160]
In fiscal 2018 and 2017, our continuing involvement with properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded non-cash sales of properties, extinguished the associated financing obligations and recognized gains of $76 million and $10 million, respectively.

[0001564590-19-022779:mdna:161]
Other Income, Net (in millions, except percentages)

[0001564590-19-022779:mdna:162]
The components of other income, net were as follows:

[0001564590-19-022779:mdna:163]
|  |  |  | Fiscal Year |  |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |  |
| Interest income |  |  | $ | 88 |  |  | $ | 79 |  |  |  | 11 | % |  | $ | 44 |  |  |  | 80 | % |
| Interest expense |  |  |  | (58 | ) |  |  | (62 | ) |  |  | (6 | )% |  |  | (52 | ) |  |  | 19 | % |
| Other income, net |  |  |  | 17 |  |  |  | 24 |  |  |  | (29 | )% |  |  | 8 |  |  | NM |  |
| Total |  |  | $ | 47 |  |  | $ | 41 |  |  | NM |  |  | $ | — |  |  | NM |  |

[0001564590-19-022779:mdna:164]
NM - Not Meaningful

[0001564590-19-022779:mdna:165]
Interest income increased during fiscal 2019 compared to fiscal 2018, primarily due to a shift in our investment portfolio to higher-yielding investments, partially offset by a decrease in the size of the portfolio. Interest income also increased during fiscal 2018 compared to fiscal 2017 due to a shift to higher-yielding investments, with the portfolio size being relatively consistent in each year.

[0001564590-19-022779:mdna:166]
Interest expense decreased during fiscal 2019 compared to fiscal 2018, primarily due to a reduction in the average amount of interest-bearing debt outstanding. Interest expense increased in fiscal 2018 compared to fiscal 2017 primarily as a result of our commercial paper program, which began in the third quarter of fiscal 2017, and the September 2017 issuance of $800 million aggregate principal amount of Senior Notes which have a higher weighted average interest rate than the $750 million aggregate principal amount of Senior Notes extinguished in November 2017.

[0001564590-19-022779:mdna:167]
The fluctuations in fiscal 2019 and 2018 compared to the respective prior years are primarily attributable to differences in net foreign exchange gains.

[0001564590-19-022779:mdna:168]
Provision for Income Taxes (in millions, except percentages):

[0001564590-19-022779:mdna:169]
|  |  |  | Fiscal Year |
|  |  |  | 2019 |  |  | 2018 |  |  | % Change |  |  | 2017 |  |  | % Change |
| Provision for income taxes |  |  | $ | 99 |  |  | $ | 1,083 |  |  |  | (91 | )% |  | $ | 140 |  |  | NM |

[0001564590-19-022779:mdna:170]
NM - Not Meaningful

[0001564590-19-022779:mdna:171]
Our effective tax rate for fiscal 2019 was 7.8% compared to an effective tax rate of 90.3% for fiscal 2018, and an effective tax rate of 22.5% for fiscal 2017. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate for fiscal 2019 was substantially lower than for the prior year primarily due to the fiscal 2018 impacts of U.S. tax reform and the effects of the resolution of certain income tax examinations during fiscal 2019.

[0001564590-19-022779:mdna:172]
Key components of the effective tax rate of 7.8% in fiscal 2019 included a benefit of $84 million, or 6.6 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 21%, a benefit of $48 million, or 3.8 percentage points, related to the effects on the resolution of certain income tax examinations, a benefit of $19 million, or 1.5 percentage points, attributable to stock-based compensation, and a benefit of $17 million, or 1.3 percentage points, from the generation of federal research credits.

[0001564590-19-022779:mdna:173]
Key components of the effective tax rate of 90.3% in fiscal 2018 included a one-time transition tax charge on accumulated foreign earnings of approximately $732 million, or 61.0 percentage points, a charge of $108 million, or 9.0 percentage points, related to the remeasurement of deferred tax assets and liabilities due to tax rate changes, offset by a benefit of $108 million, or 9.0 percentage

[0001564590-19-022779:mdna:174]
points, from foreign profits taxed at effective tax rates lower than our blended U.S. federal statutory rate of 30.5%, and a tax benefit of $23 million, or 1.9 percentage points, attributable to stock-based compensation.

[0001564590-19-022779:mdna:175]
Key components of the effective tax rate of 22.5% in fiscal 2017 included a benefit of $100 million, or 16.1 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%, and a tax charge of $16 million, or 2.6 percentage points, attributable to stock-based compensation.

[0001564590-19-022779:mdna:176]
During the fourth quarter of fiscal 2019, we recognized a discrete benefit of $48 million arising from the effective settlement of an Internal Revenue Service audit for fiscal 2012 and fiscal 2013. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-19-022779:mdna:177]
On December 22, 2017, the Tax Cuts and Jobs Act (TCJA) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. ASC 740, Income Taxes, requires companies to recognize the effect of the tax law changes in the period of enactment. However, the SEC staff issued Staff Accounting Bulletin 118, which allowed companies to record provisional amounts during a measurement period not to extend beyond one year from the TCJA enactment date.

[0001564590-19-022779:mdna:178]
As a result of the U.S. federal corporate income tax rate change, effective as of January 1, 2018, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. During fiscal 2018, we recorded $108 million of tax expense related to all tax rate changes. Upon finalization of our provisional estimates during the third quarter of fiscal 2019, we recorded tax expense of $6 million related to deferred tax assets for equity-based compensation awards to our executives.

[0001564590-19-022779:mdna:179]
The TCJA imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. In fiscal 2018, we recorded a $732 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. In the third quarter of fiscal 2019, we finalized our computation of the transition tax and recorded a reduction of $5 million to our provisional estimate.

[0001564590-19-022779:mdna:180]
As of April 26, 2019, we have completed the accounting for the tax impacts of the TCJA, however, we will continue to assess the impact of further guidance from federal and state tax authorities on our business and consolidated financial statements, and recognize any adjustments in the period in which they are determined.

[0001564590-19-022779:mdna:181]
Under the TCJA, the global minimum tax on intangible income (GMT) provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules, or (ii) account for GMT in a company’s measurement of deferred taxes. We have elected to recognize the GMT as a period cost and thus recorded $22 million of tax expense for federal and state impacts for fiscal 2019.

[0001564590-19-022779:mdna:182]
In October 2016, the FASB issued an ASU which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation.

[0001564590-19-022779:mdna:183]
During fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements and recorded a charge of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-19-022779:mdna:184]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key issues under these audits and are often subject to dispute and appeals.

[0001564590-19-022779:mdna:185]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. The preliminary ruling will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will then issue its final decision. While the timing and outcome of a final decision on this matter is uncertain, we believe it is more likely than not that our distributions were not subject to withholding tax and we intend to vigorously defend any withholding tax claims by the Danish Tax Authorities.

[0001564590-19-022779:mdna:186]
43

[0001564590-19-022779:mdna:187]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-19-022779:mdna:188]
Liquidity, Capital Resources and Cash Requirements

[0001564590-19-022779:mdna:189]
| (In millions, except percentages) |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,899 |  |  | $ | 5,391 |  |
| Principal amount of debt |  | $ | 1,799 |  |  | $ | 1,935 |  |

[0001564590-19-022779:mdna:190]
The following is a summary of our cash flow activities:

[0001564590-19-022779:mdna:191]
|  |  | Fiscal Year |  |
| (In millions) |  | 2019 |  |  | 2018 |  |
| Net cash provided by operating activities |  | $ | 1,341 |  |  | $ | 1,478 |  |
| Net cash provided by (used in) investing activities |  |  | 704 |  |  |  | (21 | ) |
| Net cash used in financing activities |  |  | (2,631 | ) |  |  | (986 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (30 | ) |  |  | 26 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (616 | ) |  | $ | 497 |  |

[0001564590-19-022779:mdna:192]
As of April 26, 2019, our cash, cash equivalents and short-term investments totaled $3.9 billion, reflecting a decrease of $1.5 billion from April 27, 2018. The decrease was primarily due to $2.1 billion paid for the repurchase of our common stock, $403 million used for the payment of dividends, $173 million in purchases of property and equipment, and $136 million used for the net repayment of commercial paper notes, partially offset by $1.3 billion of cash provided by operating activities. Working capital decreased by $1.7 billion to $1.7 billion as of April 26, 2019 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above, and the reclassification of $400 million principal amount of our senior notes to current liabilities.

[0001564590-19-022779:mdna:193]
Cash Conversion Cycle

[0001564590-19-022779:mdna:194]
The following table presents the components of our cash conversion cycle for the fourth quarter of each of the past three fiscal years:

[0001564590-19-022779:mdna:195]
|  |  | Three Months Ended |  |
| (In days) |  | April 26, 2019 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Days sales outstanding (1) |  |  | 70 |  |  |  | 58 |  |  |  | 45 |  |
| Days inventory outstanding (2) |  |  | 21 |  |  |  | 18 |  |  |  | 26 |  |
| Days payables outstanding (3) |  |  | (87 | ) |  |  | (90 | ) |  |  | (56 | ) |
| Cash conversion cycle (4) |  |  | 3 |  |  |  | (14 | ) |  |  | 15 |  |

[0001564590-19-022779:mdna:196]
Days may not add due to rounding

[0001564590-19-022779:mdna:197]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the fourth quarters presented above). The year over year increases in DSO in the fourth quarter of fiscal 2019 and fiscal 2018 were primarily due to less favorable shipping linearity and, in the case of fiscal 2019, one of our major distributors choosing not to take advantage of an early payment discount. |

[0001564590-19-022779:mdna:198]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. The increase in DIO in the fourth quarter of fiscal 2019 compared to the corresponding period of fiscal 2018 was primarily due to higher levels of finished goods on hand at the end of fiscal 2019. Compared to the corresponding period in fiscal 2017, the decrease in DIO in the fourth quarter of fiscal 2018 was due primarily to strong product sales towards the end of the fourth quarter of fiscal 2018. |

[0001564590-19-022779:mdna:199]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the fourth quarter of fiscal 2019 was relatively unchanged compared to the fourth quarter of fiscal 2018, while it increased compared to the corresponding period in fiscal 2017 was primarily the result of improved vendor payables management and extensions of payment terms with our suppliers. |

[0001564590-19-022779:mdna:200]
| (4) | The cash conversion cycle is the sum of DSO and DIO less DPO. Items which may cause the cash conversion cycle in a particular period to differ include, but are not limited to, changes in business mix, changes in payment terms (including extended payment terms from suppliers), the extent of shipment linearity, seasonal trends and the timing of revenue recognition and inventory purchases within the period. |

[0001564590-19-022779:mdna:201]
44

[0001564590-19-022779:mdna:202]
Cash Flows from Operating Activities

[0001564590-19-022779:mdna:203]
During fiscal 2019, we generated cash from operating activities of $1.3 billion, reflecting net income of $1.2 billion, adjusted by non-cash depreciation and amortization of $197 million, stock-based compensation of $158 million and a gain on derecognition of assets of $73 million.

[0001564590-19-022779:mdna:204]
Changes in assets and liabilities during fiscal 2019 included the following:

[0001564590-19-022779:mdna:205]
|  | • | Accounts receivable increased $185 million, reflecting higher DSO. |

[0001564590-19-022779:mdna:206]
|  | • | Deferred revenue and financed unearned services revenue increased $343 million, primarily due to an increase in deferred software and hardware maintenance contract revenue associated with a growing installed base. |

[0001564590-19-022779:mdna:207]
|  | • | Long-term taxes payable decreased $164 million, primarily due to transition taxes associated with U.S. tax reform. |

[0001564590-19-022779:mdna:208]
During fiscal 2018, we generated cash from operating activities of $1.5 billion, reflecting net income of $116 million, adjusted by non-cash depreciation and amortization of $198 million, stock-based compensation of $161 million, a deferred income tax provision of $270 million, and a gain on sale of properties of $218 million.

[0001564590-19-022779:mdna:209]
Changes in assets and liabilities during fiscal 2018 included the following:

[0001564590-19-022779:mdna:210]
|  | • | Accounts receivable increased $289 million, reflecting higher DSO. |

[0001564590-19-022779:mdna:211]
|  | • | Accounts payable increased $262 million, reflecting higher DPO. |

[0001564590-19-022779:mdna:212]
|  | • | Long-term taxes payable increased $714 million, primarily due to a one-time transition tax liability recorded as a result of the impact of U.S. tax reform, which will be paid over a period of eight years. |

[0001564590-19-022779:mdna:213]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-19-022779:mdna:214]
Cash Flows from Investing Activities

[0001564590-19-022779:mdna:215]
During fiscal 2019, we generated $876 million from maturities and sales of investments, net of purchases, and paid $173 million for capital expenditures.

[0001564590-19-022779:mdna:216]
During fiscal 2018, we used $10 million for the purchases of investments, net of maturities and sales, and paid $145 million for capital expenditures. Additionally, we paid $75 million to acquire two privately-held companies, and received proceeds of $210 million from the sale of properties.

[0001564590-19-022779:mdna:217]
Cash Flows from Financing Activities

[0001564590-19-022779:mdna:218]
During fiscal 2019, we used $2.1 billion for the repurchase of 29 million shares of our common stock, $403 million for the payment of dividends, and $136 million for the repayment of commercial paper notes, net.

[0001564590-19-022779:mdna:219]
During fiscal 2018, we used $750 million to redeem our Senior Notes due in December 2017, $115 million for the repayment of commercial paper notes, net, $794 million for the repurchase of 15 million shares of our common stock, $214 million for the payment of dividends, and generated $795 million in cash from the issuance of long-term debt.

[0001564590-19-022779:mdna:220]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies, and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-19-022779:mdna:221]
45

[0001564590-19-022779:mdna:222]
Liquidity

[0001564590-19-022779:mdna:223]
Our principal sources of liquidity as of April 26, 2019 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-19-022779:mdna:224]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0001564590-19-022779:mdna:225]
|  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Cash and cash equivalents |  | $ | 2,325 |  |  | $ | 2,941 |  |
| Short-term investments |  |  | 1,574 |  |  |  | 2,450 |  |
| Total |  | $ | 3,899 |  |  | $ | 5,391 |  |

[0001564590-19-022779:mdna:226]
As of April 26, 2019 and April 27, 2018, $3.7 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.2 billion and $0.9 billion, respectively, were available in the U.S. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-19-022779:mdna:227]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared.

[0001564590-19-022779:mdna:228]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 26, 2019.

[0001564590-19-022779:mdna:229]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-19-022779:mdna:230]
Senior Notes

[0001564590-19-022779:mdna:231]
The following table summarizes the principal amount of our Senior Notes as of April 26, 2019 (in millions):

[0001564590-19-022779:mdna:232]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-19-022779:mdna:233]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 10 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0001564590-19-022779:mdna:234]
Commercial Paper Program and Credit Facility

[0001564590-19-022779:mdna:235]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount

[0001564590-19-022779:mdna:236]
from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $249 million, a weighted-average interest rate of 2.73% and maturities ranging from 27 days to 38 days.

[0001564590-19-022779:mdna:237]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 26, 2019, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-19-022779:mdna:238]
Capital Expenditure Requirements

[0001564590-19-022779:mdna:239]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2020 to be between $150 million and $200 million.

[0001564590-19-022779:mdna:240]
Dividends and Stock Repurchase Program

[0001564590-19-022779:mdna:241]
On May 22, 2019, we declared a cash dividend of $0.48 per share of common stock, payable on July 24, 2019 to holders of record as of the close of business on July 5, 2019.

[0001564590-19-022779:mdna:242]
As of April 26, 2019, our Board of Directors had authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 26, 2019, we repurchased a total of 313 million shares of our common stock at an average price of $37.46 per share, for an aggregate purchase price of $11.7 billion. As of April 26, 2019, the remaining authorized amount for stock repurchases under this program was $1.9 billion.

[0001564590-19-022779:mdna:243]
The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001564590-19-022779:mdna:244]
47

[0001564590-19-022779:mdna:245]
Contractual Obligations

[0001564590-19-022779:mdna:246]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. The following table summarizes our contractual obligations at April 26, 2019 (in millions):

[0001564590-19-022779:mdna:247]
|  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2023 |  |  |  | 2024 |  |  | Thereafter |  |  | Total |  |
| Office space and equipment lease commitments |  | $ | 47 |  |  | $ | 38 |  |  | $ | 26 |  |  | $ | 14 |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 151 |  |
| Purchase commitments with contract manufacturers (1) |  |  | 449 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 449 |  |
| Construction related obligations |  |  | 3 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |
| Other purchase obligations (2) |  |  | 136 |  |  |  | 54 |  |  |  | 28 |  |  |  | 6 |  |  |  | 4 |  |  |  | 6 |  |  |  | 234 |  |
| Total off-balance sheet commitments |  |  | 635 |  |  |  | 93 |  |  |  | 55 |  |  |  | 20 |  |  |  | 14 |  |  |  | 22 |  |  |  | 839 |  |
| Commercial paper notes (3) |  |  | 249 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 249 |  |
| Long-term debt obligations (4) |  |  | 442 |  |  |  | 38 |  |  |  | 530 |  |  |  | 271 |  |  |  | 13 |  |  |  | 407 |  |  |  | 1,701 |  |
| Long-term financing arrangements |  |  | 5 |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |
| Uncertain tax positions (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 252 |  |
| Total contractual obligations |  | $ | 1,331 |  |  | $ | 134 |  |  | $ | 585 |  |  | $ | 291 |  |  | $ | 27 |  |  | $ | 429 |  |  | $ | 3,049 |  |

[0001564590-19-022779:mdna:248]
| (1) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. We record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts. As of April 26, 2019, such liability amounted to $16 million and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. |

[0001564590-19-022779:mdna:249]
| (2) | Other purchase obligations represent an estimate of all open purchase orders and contractual obligations associated with our ordinary course of business, excluding inventory commitments with contract manufacturers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be canceled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001564590-19-022779:mdna:250]
| (3) | Represents principal payments on our commercial paper notes. |

[0001564590-19-022779:mdna:251]
| (4) | Included in long-term debt are obligations related to our $1.6 billion principal amount of our Senior Notes, of which $400 million is due in September 2019, $500 million is due in June 2021, $250 million is due in December 2022 and $400 million is due in September 2024. Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations, are $151 million for fiscal 2020 through fiscal 2025. |

[0001564590-19-022779:mdna:252]
| (5) | As of April 26, 2019, our liability for uncertain tax positions was $252 million, including interest, penalties and certain income tax benefits, which due to the uncertainty of the timing of future payments, is presented in the total column on a separate line in this table. |

[0001564590-19-022779:mdna:253]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table.

[0001564590-19-022779:mdna:254]
Financing Guarantees

[0001564590-19-022779:mdna:255]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $87 million and $67 million of receivables during fiscal 2019 and 2018, respectively.

[0001564590-19-022779:mdna:256]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-19-022779:mdna:257]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 26, 2019 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-022779:mdna:258]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 26, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-19-022779:mdna:259]
Indemnification Agreements

[0001564590-19-022779:mdna:260]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.

[0001564590-19-022779:mdna:261]
Legal Contingencies

[0001564590-19-022779:mdna:262]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 18 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.
