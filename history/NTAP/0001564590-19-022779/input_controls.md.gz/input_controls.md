# NTAP 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001564590-19-022779:item_9a:1]
| Item 9A. | Controls and Procedures |

[0001564590-19-022779:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001564590-19-022779:item_9a:3]
The phrase “disclosure controls and procedures” refers to controls and procedures designed to ensure that information required to be disclosed in our reports filed or submitted under the Securities Exchange Act of 1934, as amended (the Exchange Act), such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the U.S. Securities and Exchange Commission (SEC). Disclosure controls and procedures are also designed to ensure that such information is accumulated and communicated to our management, including our Chief Executive Officer (CEO) and our Chief Financial Officer (CFO), as appropriate to allow timely decisions regarding required disclosure.

[0001564590-19-022779:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we carried out an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, as of April 26, 2019, the end of the fiscal period covered by this Annual Report on Form 10-K (the Evaluation Date). Based on this evaluation, our CEO and CFO concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information required to be disclosed in our SEC reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms and (ii) is accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosure.

[0001564590-19-022779:item_9a:5]
(b) Management’s Report on Internal Control Over Financial Reporting

[0001564590-19-022779:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Our internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-19-022779:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, our management concluded that, as of April 26, 2019, our internal control over financial reporting was effective at the reasonable assurance level based on those criteria.

[0001564590-19-022779:item_9a:8]
The effectiveness of our internal control over financial reporting as of April 26, 2019 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report, which is included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001564590-19-022779:item_9a:9]
(c) Changes in Internal Control Over Financial Reporting

[0001564590-19-022779:item_9a:10]
There has been no change in our internal control over financial reporting identified in connection with our evaluation required by paragraph (d) of rules 13a-15 and 15d-15 under the Exchange Act that occurred during the fourth quarter of fiscal 2019 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
