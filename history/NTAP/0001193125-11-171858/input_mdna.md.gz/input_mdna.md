# NTAP MD&A — 0001193125-11-171858


## mdna

[0001193125-11-171858:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-11-171858:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and
the related notes set forth under “Item 8. Financial Statements and Supplementary Data”. The following discussion also contains trend information and other forward looking statements that involve a number of risks and uncertainties.
The Risk Factors set forth in “Item 1. Business” are hereby incorporated into the discussion by reference.

[0001193125-11-171858:mdna:3]
Overview

[0001193125-11-171858:mdna:4]
Revenues for fiscal 2011 were $5.1 billion, up $1.2 billion, or 30%, from fiscal 2010. The improved revenue
performance in fiscal 2011 was predominantly the result of strong demand for our storage efficiency and data management solutions including the new products launched in November 2010. Additionally, net revenues for fiscal 2011 include a favorable
impact of $129.2 million from the adoption of new accounting standards related to revenue recognition. Revenues for fiscal 2010 were $3.9 billion, up $0.5 billion, or 15%, from fiscal 2009. Improved revenue performance in fiscal 2010 was
the result of improvements in product, software entitlements and maintenance (SEM) and service revenues. Revenues in fiscal 2009 were negatively impacted by a $128.7 million settlement with the General Services Administration (GSA). The dispute
related to our discounting practices and compliance with the price reduction provisions of GSA contracts between August 1997 and February 2005.

[0001193125-11-171858:mdna:5]
Gross profit as a percentage of net revenues increased during fiscal 2011 primarily as a result of higher product and service revenues at improved margins. The gross profit margin percentage increased
during fiscal 2010 due largely to reductions in product materials cost, partially offset by a decrease in the overall average selling prices of our products, as well as an increase in our SEM and services revenues mix relative to product revenues.
In addition, our gross profit margin percentage in fiscal 2009 was negatively impacted by the GSA settlement.

[0001193125-11-171858:mdna:6]
Operating
expenses, excluding restructuring and other charges and acquisition related (income) expense, net, for fiscal 2011 totaled $2.5 billion, up 21% from fiscal 2010. The increase is primarily due to a 17% increase in average headcount in fiscal 2011 and
higher levels of incentive compensation and commission expense due to higher revenues and operating profits. Salary and related expenses during fiscal 2011 were favorably impacted by having 52 weeks in fiscal 2011 compared to 53 weeks in fiscal
2010. During fiscal 2010, operating expenses, excluding restructuring and other charges and acquisition related (income) expense, net, totaled $2.1 billion, up 10% from fiscal 2009 and reflected the impact of an increase in incentive
compensation and commissions expense related to our stronger sales and operating profit performance, as well as having 53 weeks in fiscal 2010 compared to 52 weeks in fiscal 2009.

[0001193125-11-171858:mdna:7]
During fiscal 2010, we entered into a merger agreement with Data Domain, Inc., which was subsequently terminated on July 8, 2009. In
accordance with the agreement, we received a $57.0 million termination fee, which, when netted against $15.9 million of incremental third-party costs we incurred relating to the terminated merger transaction, resulted in net proceeds of
$41.1 million.

[0001193125-11-171858:mdna:8]
Subsequent Event

[0001193125-11-171858:mdna:9]
On May 6, 2011, we completed the acquisition of certain assets and liabilities related to the Engenio external storage systems business (ESG) of LSI Corporation (LSI). We paid LSI $480 million in
cash and assumed certain assets and liabilities related to ESG. This acquisition will enable us to further expand our OEM channel, and address emerging and fast-growing segments of the storage market such as video, including full-motion video
capture and digital video surveillance, as well as high-performance computing applications, such as genomics sequencing and scientific research.

[0001193125-11-171858:mdna:10]
The transaction is expected to materially impact our results of operations in fiscal 2012
and beyond. We expect fiscal 2012 ESG product revenues to consist primarily of revenues from sales to their existing OEMs, with new business developing slowly over the course of the year. The fiscal 2012 consolidated product gross margin percentage
is expected to decrease compared to fiscal 2011, reflecting the impact on our existing business of the lower gross margin ESG OEM revenues.

[0001193125-11-171858:mdna:11]
Critical Accounting Estimates and Policies

[0001193125-11-171858:mdna:12]
Our discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles
generally accepted in the United States of America. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of
assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our
estimates.

[0001193125-11-171858:mdna:13]
We believe that the following accounting policies are significantly affected by critical accounting estimates and
that they are both highly important to the portrayal of our financial condition and results and require difficult management judgments and assumptions about matters that are inherently uncertain. Note 2 of the accompanying consolidated
financial statements describes the significant accounting policies used in the preparation of the consolidated financial statements. Certain of these significant accounting policies are considered to be critical accounting policies.

[0001193125-11-171858:mdna:14]
We believe the accounting policies described below are those that most frequently require us to make estimates and judgments and
therefore are critical to the understanding of our results of operations.

[0001193125-11-171858:mdna:15]
Revenue Recognition, Reserves and Allowances

[0001193125-11-171858:mdna:16]
Revenue Recognition — We recognize revenue when:

[0001193125-11-171858:mdna:17]
|  | • |  | Persuasive evidence of an arrangement exists: It is our customary practice to have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers, or distributors. |

[0001193125-11-171858:mdna:18]
|  | • |  | Delivery has occurred: Our product is physically delivered to our customers, generally with standard transfer terms such as FOB origin. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. If undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement, delivery is not considered to have occurred. |

[0001193125-11-171858:mdna:19]
|  | • |  | The fee is fixed or determinable: Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001193125-11-171858:mdna:20]
|  | • |  | Collection is reasonably assured: If there is considerable doubt surrounding the credit worthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001193125-11-171858:mdna:21]
Our multiple element
arrangements include our systems and one or more of the following undelivered elements: SEM and premium hardware maintenance. Our SEM entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis,
bug fixes, and patch releases. Premium hardware maintenance services include contracts for technical support and minimum response times. Revenues

[0001193125-11-171858:mdna:22]
from SEM and premium hardware maintenance services are recognized ratably over the contractual term, generally from one to five years. We also offer extended service contracts (which extend our
standard parts warranty and may include premium hardware maintenance) at the end of the warranty term; revenues from these contracts are recognized ratably over the contract term. We also sell professional services either on a time and materials
basis or under fixed price standard projects; we recognize revenue for these services as they are performed. Revenue from hardware installation services is recognized in the period the services are delivered.

[0001193125-11-171858:mdna:23]
In October 2009, the FASB amended the accounting standards for revenue recognition to exclude tangible products containing software
components and non-software components that function together to deliver the tangible product’s essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards
for multiple deliverable revenue arrangements to:

[0001193125-11-171858:mdna:24]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

[0001193125-11-171858:mdna:25]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

[0001193125-11-171858:mdna:26]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

[0001193125-11-171858:mdna:27]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the
standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010.

[0001193125-11-171858:mdna:28]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software
components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001193125-11-171858:mdna:29]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate
on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the
industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or
return rights for the delivered elements.

[0001193125-11-171858:mdna:30]
For transactions entered into or materially modified after April 30, 2010, we
recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance
along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling
prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the new standards.

[0001193125-11-171858:mdna:31]
For
our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price.
For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement
consideration.

[0001193125-11-171858:mdna:32]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and
discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial
majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

[0001193125-11-171858:mdna:33]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on
competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with
similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our
products or services.

[0001193125-11-171858:mdna:34]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we
use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by
considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices
fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-11-171858:mdna:35]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

[0001193125-11-171858:mdna:36]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue
recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all
undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is SEM and/or service. Under the residual method, the fair value of the undelivered elements is deferred
and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements
occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

[0001193125-11-171858:mdna:37]
Net revenues and net income for the year ended April 29, 2011 were higher by $129.2 million and $53.0 million, respectively, as a
result of adoption of the new revenue recognition accounting standards. We are not able to reasonably estimate the effect of adopting these standards on future financial periods as the impact will vary based on the nature and volume of new or
materially modified sales transactions in any given period. In terms of the timing and pattern of revenue recognition, we expect that these new accounting standards will facilitate our efforts to optimize our offerings due to better alignment
between the economics of an arrangement and the related accounting. This may lead us to engage in new go-to-market practices in the future. In particular, we expect that the amended accounting standards will enable us to better integrate products
and services (for which we have not established VSOE) into existing offerings and solutions. As our go-to-market strategies evolve, we may modify our pricing practices in the future, which could result in changes in selling prices, including both
VSOE and BESP.

[0001193125-11-171858:mdna:38]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are
estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations to
determine the adequacy of our current and future reserve needs. If actual future returns and allowances differ from past experience, additional allowances may be required.

[0001193125-11-171858:mdna:39]
We also maintain a separate allowance for doubtful accounts for estimated losses based on
our assessment of the collectability of specific customer accounts and the aging of the accounts receivable. We analyze accounts receivable and historical bad debts, customer concentrations, customer solvency, current economic and geographic trends,
and changes in customer payment terms and practices when evaluating the adequacy of our current and future allowance. In circumstances where we are aware of a specific customer’s inability to meet its financial obligations to us, a specific
allowance for bad debt is estimated and recorded, which reduces the recognized receivable to the estimated amount we believe will ultimately be collected. We monitor and analyze the accuracy of our allowance for doubtful accounts estimate by
reviewing past collectability and adjusting it for future expectations to determine the adequacy of our current and future allowance. Our reserve levels have generally been sufficient to cover credit losses. Our allowance for doubtful accounts as of
April 29, 2011 was $0.5 million, compared to $1.6 million as of April 30, 2010. If the financial condition of our customers were to deteriorate, resulting in an impairment of their ability to make payments, additional allowances
may be required.

[0001193125-11-171858:mdna:40]
Inventory Valuation and Purchase Order Accruals

[0001193125-11-171858:mdna:41]
Inventories are stated at the lower of cost or market (which approximates actual cost on a first-in, first-out basis). We perform an
excess and obsolete analysis of our inventory based upon assumptions about future demand and market conditions. We adjust the inventory value based on estimated excess and obsolete inventories determined primarily by future demand forecasts.
Although we strive for accuracy in our forecasts of future product demand, any significant unanticipated changes in demand or technological developments could have a significant impact on the value of our inventory commitments and on our reported
results. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings may be required. If actual market conditions are more favorable, we may realize higher gross profits in the
period when the written-down inventory is sold. Historically, our inventory valuation adjustments have been sufficient to cover any excess and obsolete exposure and have not required material adjustments in subsequent periods.

[0001193125-11-171858:mdna:42]
In the normal course of business we make commitments to our third party contract manufacturers to manage lead times and meet product
forecasts, and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased commitments when we believe it is probable that the components will not be utilized
in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001193125-11-171858:mdna:43]
We are subject to a variety of federal, state, local, and foreign environmental regulations relating to the use, storage, discharge, and
disposal of hazardous chemicals used in the manufacture of our products, which may require design changes or recycling of products we manufacture. We will continue to monitor our compliance with these regulations, which may require us to incur
higher costs, and adversely impact our operating results.

[0001193125-11-171858:mdna:44]
Business Combinations

[0001193125-11-171858:mdna:45]
We allocate the purchase price of acquired companies to identifiable assets acquired and liabilities assumed at their acquisition date
fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. Significant management judgments and
assumptions are required in determining the fair value of acquired assets and liabilities, particularly acquired intangible assets which typically comprise acquired technology, trademarks and tradenames, customer contracts and relationships and
covenants not to compete.

[0001193125-11-171858:mdna:46]
The valuation of purchased intangible assets is principally based upon estimates of the future
performance and cash flows from the acquired business. If different assumptions are used, it could materially impact the purchase price allocation and our financial position and results of operations. Management’s estimates of fair value are
based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired
and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation.

[0001193125-11-171858:mdna:47]
Valuation of Goodwill and Intangibles

[0001193125-11-171858:mdna:48]
Purchased intangible assets are amortized over their useful lives unless these lives are determined to be indefinite. In-process research
and development is capitalized at fair value and classified as indefinite-lived assets until completion or abandonment and is subject to periodic review for impairment. Accordingly, the allocation of acquisition cost to identifiable intangible
assets has a significant impact on our future operating results. The allocation process requires extensive use of estimates and assumptions, including estimates of future cash flows expected to be generated by the acquired assets. Should conditions
be different than management’s assessment, material write-downs of the fair value of intangible assets may be required. We periodically review the estimated remaining useful lives of our intangible assets. A reduction in the estimate of
remaining useful life could result in accelerated amortization expense or a write-down in future periods. As such, any future write-downs of these assets would adversely affect our operating results.

[0001193125-11-171858:mdna:49]
We perform an annual review of the valuation of goodwill in the fourth quarter of each fiscal year, or more often if indicators of
impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. Evaluations of
possible impairment and, if applicable, adjustments to carrying values require us to estimate, among other factors, future cash flows, useful lives, and fair market values of our reporting units and assets. When we conduct our evaluation of
goodwill, the fair value of goodwill is assessed using valuation techniques that require significant management judgment. Should conditions be different from management’s last assessment, significant write-downs of goodwill may be required,
which would adversely affect our operating results. In fiscal 2011, we performed such evaluation and determined the fair value substantially exceeded the carrying value and therefore, found no impairment of goodwill.

[0001193125-11-171858:mdna:50]
Restructuring Reserves

[0001193125-11-171858:mdna:51]
We recognize a liability for restructuring costs when the liability is incurred. The restructuring accruals are based upon management estimates at the time they are recorded. These estimates can change
depending upon changes in facts and circumstances subsequent to the date the original liability was recorded. The main components of our restructuring charges are workforce reduction, intangibles and fixed assets write-offs and non-cancelable lease
costs related to excess facilities. Severance-related charges are accrued when it is determined that a liability has been incurred, which is generally when individuals have been notified of their termination dates and expected severance payments. We
record contract cancellation costs when contracts are terminated. The decision to eliminate excess facilities results in charges for lease termination fees and future commitments to pay lease charges, net of estimated future sublease income. We
recognize charges for elimination of excess facilities when we have vacated the premises. Intangible asset write-offs consist of impairment of acquired intangible assets related to our decision to cease the development and availability of specific
products. Fixed assets write-offs primarily consist of equipment, software and furniture associated with excess facilities being eliminated, and are based on an estimate of the amounts and timing of future cash flows related to the expected future
remaining use and ultimate sale or disposal of the equipment and furniture.

[0001193125-11-171858:mdna:52]
Our estimates involve a number of risks and
uncertainties, some of which are beyond our control, including future real estate market conditions and our ability to successfully enter into subleases or lease termination agreements with terms as favorable as those assumed when arriving at our
estimates. We regularly evaluate a number of factors to determine the appropriateness and reasonableness of our restructuring accruals, including the various assumptions noted above. If actual results differ significantly from our estimates, we may
be required to adjust our restructuring accruals in the future.

[0001193125-11-171858:mdna:53]
Product Warranties

[0001193125-11-171858:mdna:54]
Estimated future warranty costs are expensed as a cost of product revenues when revenue is recognized, based on estimates of the costs
that may be incurred under our warranty obligations including material, distribution and labor costs. Our accrued liability for estimated future warranty costs is included in other accrued

[0001193125-11-171858:mdna:55]
liabilities and other long-term obligations on the accompanying consolidated balance sheets. Factors that affect our warranty liability include the number of installed units, estimated material
costs, estimated distribution costs and estimated labor costs. We periodically assess the adequacy of our warranty accrual and adjust the amount as considered necessary.

[0001193125-11-171858:mdna:56]
Stock-Based Compensation

[0001193125-11-171858:mdna:57]
We account for stock-based compensation
using the Black-Scholes option pricing model to estimate the fair value of each option grant on the date of grant. Our option pricing model requires the input of highly subjective assumptions, including the expected stock price volatility, expected
term, and forfeiture rate. Any changes in these highly subjective assumptions significantly impact stock-based compensation expense.

[0001193125-11-171858:mdna:58]
Loss Contingencies

[0001193125-11-171858:mdna:59]
We are subject to the possibility of various
loss contingencies arising in the course of business. We consider the likelihood of the loss or impairment of an asset or the incurrence of a liability as well as our ability to reasonably estimate the amount of loss in determining loss
contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred or an asset has been impaired and the amount of loss can be reasonably estimated. We regularly evaluate current information available to
us to determine whether such accruals should be adjusted.

[0001193125-11-171858:mdna:60]
Fair Value Measurements and Impairments

[0001193125-11-171858:mdna:61]
All of our available-for-sale investments and nonmarketable securities are subject to periodic impairment review. Investments are
considered to be impaired when a decline in fair value is judged to be other-than-temporary. This determination requires significant judgment. For publicly traded investments, impairment is determined based upon the specific facts and circumstances
present at the time, including factors such as current economic and market conditions, the credit rating of the security’s issuer, the length of time an investment’s fair value has been below our carrying value, and our ability and intent
to hold investments to maturity or for a period of time sufficient to allow for any anticipated recovery in fair value. If an investment’s decline in fair value, caused by factors other than changes in interest rates, is deemed to be
other-than-temporary, we reduce its carrying value to its estimated fair value, as determined based on quoted market prices, liquidation values or other metrics. For investments in publicly held companies, we recognize an impairment charge when the
decline in the fair value of our investment is below its cost basis and is judged to be other-than-temporary. The ultimate value realized on these investments is subject to market price volatility until they are sold.

[0001193125-11-171858:mdna:62]
Pursuant to the accounting guidance for fair value measurement and its subsequent updates, fair value is defined as the price that would
be received to sell an asset or paid to transfer a liability (i.e., the “exit price”) in an orderly transaction between market participants at the measurement date. The accounting guidance establishes a hierarchy for inputs used in
measuring fair value that minimizes the use of unobservable inputs by requiring the use of observable market data when available. Observable inputs are inputs that market participants would use in pricing the asset or liability based on active
market data. Unobservable inputs are inputs that reflect the assumptions market participants would use in pricing the asset or liability based on the best information available in the circumstances.

[0001193125-11-171858:mdna:63]
The fair value hierarchy is broken down into the three input levels summarized below:

[0001193125-11-171858:mdna:64]
|  | • |  | Level 1 — Valuations are based on quoted prices in active markets for identical assets or liabilities, and readily accessible by us at the reporting date. Examples of assets and liabilities utilizing Level 1 inputs are certain money market funds, U.S. Treasuries and trading securities with quoted prices on active markets. |

[0001193125-11-171858:mdna:65]
|  | • |  | Level 2 — Valuations based on inputs other than the quoted prices in active markets that are observable either directly or indirectly in active markets. Examples of assets and liabilities utilizing Level 2 inputs are U.S. government agency bonds, corporate bonds, commercial paper, certificates of deposit and over-the-counter derivatives. |

[0001193125-11-171858:mdna:66]
|  | • |  | Level 3 — Valuations based on unobservable inputs in which there is little or no market data, which require us to develop our own assumptions. Examples of assets and liabilities utilizing Level 3 inputs are cost method investments, auction rate securities (ARS) and the Primary Fund. |

[0001193125-11-171858:mdna:67]
We measure our available-for-sale securities at fair value on a recurring basis. Available-for-sale securities include U.S. Treasury
securities, U.S. government agency bonds, corporate bonds, commercial paper, ARSs, money market funds and certificates of deposit. Where possible, we utilize quoted market prices to measure and such items are classified as Level 1 in the
hierarchy. When quoted market prices for identical assets are unavailable, varying valuation techniques are used. Such assets are classified as Level 2 or Level 3 in the hierarchy. We classify items in Level 2 if investments are
valued using observable inputs to quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. We classify items in Level 3 if investments are valued
using a pricing model, based on unobservable inputs in the market or that require us to develop our own assumptions. Our assessment of the significance of a particular input to the fair value measurement in its entirety requires judgment and
considers factors specific to the investment.

[0001193125-11-171858:mdna:68]
We are also exposed to market risk relating to our available-for-sale
investments due to uncertainties in the credit and capital markets. The fair value of our investments may change significantly due to events and conditions in the credit and capital markets. These securities/issuers could be subject to review for
possible downgrade. Any downgrade in these credit ratings may result in an additional decline in the estimated fair value of our investments. We monitor and evaluate the accounting for our investment portfolio on a quarterly basis for additional
other-than-temporary impairment charges.

[0001193125-11-171858:mdna:69]
We actively review current investment ratings, company specific events, and general
economic conditions in managing our investments and determining whether there is a significant decline in fair value that is other-than-temporary. As of April 29, 2011 and April 30, 2010, our short-term and long-term investments in
marketable securities have been classified as “available-for-sale” and are carried at fair value. Available-for-sale investments with original maturities of greater than three months at the date of purchases are classified as short-term
investments as these investments generally consist of marketable securities that are intended to be available to meet current cash requirements. Currently, all marketable securities held by us are classified as available-for-sale and our entire ARS
portfolio is classified as long-term investments.

[0001193125-11-171858:mdna:70]
Our ARS portfolio consists of securities with long-term nominal maturities
which, in accordance with investment policy guidelines, had credit ratings of AAA and Aaa at the time of purchase. During fiscal 2008, we reclassified all of our investments in ARS from short-term investments to long-term investments as we believed
our ability to liquidate these investments in the next twelve months was uncertain. Based on an analysis of the fair value and marketability of these investments, we recorded cumulative temporary impairment charges of approximately $4.5 million and
$3.3 million during fiscal 2011 and 2010, respectively, partially offset by $0.4 million and $0.7 million, respectively, in unrealized gains within other comprehensive income (loss). During fiscal 2009, we recorded cumulative temporary
impairment charges of approximately $7.0 million, partially offset by $0.3 million in unrealized gains within other comprehensive income (loss). In addition, during fiscal 2009, we recorded an other-than-temporary impairment charge of
$2.1 million due to a significant decline in the estimated fair values of certain of our ARS related to credit quality risk and rating downgrades.

[0001193125-11-171858:mdna:71]
The valuation models used to estimate the fair value of our ARS include numerous assumptions such as assessments of the underlying structure of each security, expected cash flows, discount rates, credit
ratings, workout periods, and overall capital market liquidity. These assumptions, assessments and the interpretations of relevant market data are subject to uncertainties, are difficult to predict and require significant judgment. The use of
different assumptions, or applying different judgments to inherently subjective matters and changes in future market conditions could result in significantly different estimates of fair value. There is no assurance as to when the market for auction
rate securities will stabilize. The fair value of our ARS could change significantly based on market conditions and continued uncertainties in the credit markets. If these uncertainties continue or if these

[0001193125-11-171858:mdna:72]
49

[0001193125-11-171858:mdna:73]
securities experience credit rating downgrades, we may incur additional temporary impairment related to our auction rate securities portfolio. We will continue to monitor the fair value of our
ARS and relevant market conditions and will record additional temporary or other-than-temporary impairments if future circumstances warrant such charges.

[0001193125-11-171858:mdna:74]
As a result of the bankruptcy filing of Lehman Brothers, which occurred during fiscal 2009, we recorded an other-than-temporary impairment charge of $11.8 million on our corporate bonds related to
investments in Lehman Brothers securities and approximately $9.3 million on our investments in the Primary Fund that held Lehman Brothers investments. During fiscal 2010, we sold our remaining holdings of Lehman Brothers bonds and the
Primary Fund made multiple distributions of its assets to its investors, and as of April 30, 2010, we recovered our recorded investment, with the exception of $0.2 million, for which we recognized an additional loss. As of April 30,
2010, we no longer had any direct or indirect investments related to Lehman Brothers and have recognized all related losses in our statements of operations.

[0001193125-11-171858:mdna:75]
During fiscal 2011, 2010 and 2009, recognized gains and losses on available-for-sale investments were not material. Management determines the appropriate classification of investments at the time of
purchase and reevaluates the classification at each reporting date. The fair value of our marketable securities, including those included in cash equivalents and long-term investments, was $4,043.6 million and $3,619.2 million as of
April 29, 2011 and April 30, 2010, respectively.

[0001193125-11-171858:mdna:76]
To determine the fair value of nonmarketable investments, we use
the most recent information available to us, including new financings or estimates of current fair value, as well as traditional valuation techniques. It is our policy to review the fair value of these investments on a regular basis to determine
whether the investments in these companies are other-than-temporarily impaired. In the case of privately-held companies, this evaluation is based on information that we request from these companies. If we believe the carrying value of an investment
is in excess of fair value, and this difference is other-than-temporary, it is our policy to write down the investment to fair value. The carrying value of our investments in privately-held companies was $1.3 million and $1.4 million as of
April 29, 2011 and April 30, 2010, respectively. During fiscal 2011 and 2010, we recorded $0.1 million of net impairment charges and $3.4 million of realized gains in our consolidated statements of operations, respectively, for our
investments in privately-held companies, and adjusted the carrying amount of those investments to fair value, as we deemed the decline in the value of these assets to be other-than-temporary.

[0001193125-11-171858:mdna:77]
Income Taxes

[0001193125-11-171858:mdna:78]
The determination of our tax provision is subject to judgments and estimates due to the complexity of the tax law that we are subject to in several tax jurisdictions. Earnings derived from our
international business are generally taxed at rates that are lower than U.S. rates, resulting in a lower effective tax rate than the U.S. statutory tax rate of 35.0%. The ability to maintain our current effective tax rate is contingent on
existing tax laws in both the United States and the respective countries in which our international subsidiaries are located. Future changes in domestic or international tax laws could affect the continued realization of the tax benefits we are
currently receiving. In addition, a decrease in the percentage of our total earnings from international business or a change in the mix of international business among particular tax jurisdictions could increase our overall effective tax rate.

[0001193125-11-171858:mdna:79]
We account for income taxes by recognizing deferred tax assets and liabilities for the effect of temporary differences
between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. We reduce deferred tax assets by a valuation allowance if it is more likely than not that some or all of the
deferred tax asset will not be realized. Tax attributes related to the exercise of employee stock options are not realized until they result in a reduction of taxes payable. We do not include unrealized stock option attributes as components of our
gross deferred tax assets and corresponding valuation allowance disclosures.

[0001193125-11-171858:mdna:80]
We have provided a valuation allowance of $45.5 million as of April 29, 2011, compared
to $28.3 million as of April 30, 2010 and $28.0 million as of April 24, 2009, on certain of our deferred tax assets. The change in valuation allowance in fiscal 2011 was primarily related to the realizability of state credit
carryforwards as a result of the expected application of the California single sales factor apportionment election. The change in valuation allowance in fiscal 2010 was primarily related to changes in blended state tax rates. The tax effected
amounts of gross unrealized net operating loss and business tax credit carryforwards are $414.2 million as of April 29, 2011.

[0001193125-11-171858:mdna:81]
We recognize tax liabilities for uncertain tax positions by applying a recognition threshold and measurement attribute for the financial statement recognition and measurement of a tax position taken or
expected to be taken in a tax return. We recognize the tax liability for uncertain income tax positions on income tax returns based on a two-step process. The first step is to determine whether it is more likely than not that each income tax
position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts
requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances,
changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a
related change in our tax provision during the period in which we make such determination.

[0001193125-11-171858:mdna:82]
New Accounting Standards

[0001193125-11-171858:mdna:83]
See Note 4 of the accompanying consolidated financial statements for a full description of new accounting pronouncements, including
the respective expected dates of adoption and effects on results of operations and financial condition.

[0001193125-11-171858:mdna:84]
51

[0001193125-11-171858:mdna:85]
Results of Operations

[0001193125-11-171858:mdna:86]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001193125-11-171858:mdna:87]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 65.7 | % |  |  | 60.6 | % |  |  | 63.2 | % |
| Software entitlements and maintenance |  |  | 14.1 |  |  |  | 17.3 |  |  |  | 18.2 |  |
| Service |  |  | 20.2 |  |  |  | 22.1 |  |  |  | 22.4 |  |
| GSA settlement |  |  | — |  |  |  | — |  |  |  | (3.8 | ) |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 26.2 |  |  |  | 24.8 |  |  |  | 29.6 |  |
| Cost of software entitlements and maintenance |  |  | 0.3 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Cost of service |  |  | 8.5 |  |  |  | 10.8 |  |  |  | 11.7 |  |
| Gross profit |  |  | 65.0 |  |  |  | 64.1 |  |  |  | 58.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31.2 |  |  |  | 32.9 |  |  |  | 34.8 |  |
| Research and development |  |  | 12.7 |  |  |  | 13.6 |  |  |  | 14.6 |  |
| General and administrative |  |  | 4.9 |  |  |  | 6.1 |  |  |  | 6.0 |  |
| Restructuring and other charges |  |  | — |  |  |  | 0.1 |  |  |  | 1.6 |  |
| Acquisition related (income) expense, net |  |  | 0.1 |  |  |  | (1.0 | ) |  |  | — |  |
| Total operating expenses |  |  | 48.9 |  |  |  | 51.7 |  |  |  | 57.0 |  |
| Income from operations |  |  | 16.1 |  |  |  | 12.4 |  |  |  | 1.4 |  |
| Other expense, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 0.8 |  |  |  | 0.9 |  |  |  | 1.7 |  |
| Interest expense |  |  | (1.5 | ) |  |  | (1.9 | ) |  |  | (1.9 | ) |
| Other income (expense), net |  |  | 0.1 |  |  |  | — |  |  |  | (1.0 | ) |
| Total other expense, net |  |  | (0.6 | ) |  |  | (1.0 | ) |  |  | (1.2 | ) |
| Income before income taxes |  |  | 15.5 |  |  |  | 11.4 |  |  |  | 0.2 |  |
| Provision for (benefit from) income taxes |  |  | 2.4 |  |  |  | 1.2 |  |  |  | (1.7 | ) |
| Net income |  |  | 13.1 | % |  |  | 10.2 | % |  |  | 1.9 | % |

[0001193125-11-171858:mdna:88]
Discussion and Analysis of Results of Operations

[0001193125-11-171858:mdna:89]
Net Revenues — Our net revenues for fiscal 2011, 2010 and 2009 were as follows (in millions, except percentages):

[0001193125-11-171858:mdna:90]
|  |  | Year Ended |  |
|  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Net revenues |  | $ | 5,122.6 |  |  | $ | 3,931.4 |  |  |  | 30 | % |  | $ | 3,406.4 |  |  |  | 15 | % |

[0001193125-11-171858:mdna:91]
Net revenues increased by
$1.2 billion, or 30%, in fiscal 2011 compared to fiscal 2010 and by $525.0 million, or 15%, in fiscal 2010 compared to fiscal 2009. The increase in our net revenues for fiscal 2011 was primarily due to an increase in product revenues, which
comprised 66% of net revenues in fiscal 2011 compared to 61% in fiscal 2010. Additionally, net revenues for fiscal 2011 include a favorable impact of $129.2 million from the adoption of new accounting standards related to revenue recognition. The
increase in net revenues in fiscal 2010 was also primarily related to an increase in product revenues. Net revenues for fiscal 2009 were negatively impacted by the $128.7 million GSA settlement.

[0001193125-11-171858:mdna:92]
Sales through our indirect channels represented 73%, 69% and 69% of net revenues for fiscal
2011, 2010 and 2009, respectively. The indirect channel mix for 2009 would have been 3% lower if not for the impact of the GSA settlement.

[0001193125-11-171858:mdna:93]
The following table sets forth sales to customers, who are distributors, who accounted for 10% or more of net revenues (in millions, except percentages):

[0001193125-11-171858:mdna:94]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | % of NetRevenues |  |  | April 30,2010 |  |  | % of NetRevenues |  |  | April 24,2009 |  |  | % of NetRevenues |  |
| Arrow Electronics, Inc. |  | $ | 903.0 |  |  |  | 18 | % |  | $ | 550.7 |  |  |  | 14 | % |  | $ | 360.3 |  |  |  | 11 | % |
| Avnet, Inc. |  |  | 639.0 |  |  |  | 12 | % |  |  | 444.0 |  |  |  | 11 | % |  |  | 356.4 |  |  |  | 10 | % |

[0001193125-11-171858:mdna:95]
Product Revenues (in
millions, except percentages):

[0001193125-11-171858:mdna:96]
|  |  | Year Ended |  |
|  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Product revenues |  | $ | 3,367.1 |  |  | $ | 2,381.1 |  |  |  | 41 | % |  | $ | 2,152.7 |  |  |  | 11 | % |

[0001193125-11-171858:mdna:97]
Product revenues increased
by $986.0 million, or 41%, in fiscal 2011 compared to fiscal 2010, and increased by $228.4 million, or 11%, in fiscal 2010 compared to fiscal 2009. Product revenues for fiscal 2011 include a 4% favorable impact from the adoption of new
accounting standards related to revenue recognition. Product revenues consist of configured systems, which are comprised of bundled hardware and software products, as well as add-on hardware and software and other products. Configured systems unit
volume increased by 46% in fiscal 2011 compared to fiscal 2010, with increases between 40% and 50% in large, medium-sized and smaller systems, and increased 19% in fiscal 2010 compared to fiscal 2009, with the largest increase in smaller systems.
Total configured system revenues increased by $690.3 million in fiscal 2011, compared to fiscal 2010, with the largest increase in medium-sized systems. Total configured system revenues increased by $139.9 million in fiscal 2010, compared to fiscal
2009, with the largest increase in medium-sized systems.

[0001193125-11-171858:mdna:98]
During fiscal 2011, large, medium-sized and smaller systems
generated approximately 22%, 57% and 21% of configured systems revenues, respectively, compared to approximately 23%, 56% and 21%, respectively in fiscal 2010 and approximately 24%, 55% and 21%, respectively in fiscal 2009. Overall average selling
prices (ASPs) decreased in fiscal 2011 compared to fiscal 2010 due primarily to lower ASPs per unit in large-sized systems as manufacturing cost reductions were passed along to customers as price reductions. ASPs declined in fiscal 2010 compared to
fiscal 2009 due primarily to a shift in mix towards smaller systems, as well as lower ASPs per unit in medium-sized and smaller systems.

[0001193125-11-171858:mdna:99]
In addition, our net add-on hardware, software and other product revenues accounted for a $295.7 million increase in fiscal 2011 compared to fiscal 2010, primarily due to customers increasing the capacity
and/or functionality of their storage systems. Our net add-on hardware, software and other product revenues accounted for an $88.5 million increase in fiscal 2010 compared to fiscal 2009, primarily due to customers increasing the capacity of their
storage systems.

[0001193125-11-171858:mdna:100]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets
that we serve. This wide variation in customer configurations can significantly impact revenues, cost of revenues, and gross profit performance. Price changes, foreign currency, unit volumes, customer mix and product configuration can also impact
revenues, cost of revenues and gross profit performance. Disks are a significant component of our storage systems. Industry disk pricing continues to fall every year, and we pass along those price decreases to our customers while working to maintain
relatively constant profit margins on our disk drives. As our sales price per terabyte continues to decline, improved system performance, increased capacity and software to manage this increased capacity have an offsetting impact on product
revenues.

[0001193125-11-171858:mdna:101]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-11-171858:mdna:102]
|  |  | Year Ended |  |
|  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 720.6 |  |  | $ | 679.8 |  |  |  | 6 | % |  | $ | 618.3 |  |  |  | 10 | % |

[0001193125-11-171858:mdna:103]
SEM revenues increased by
$40.8 million, or 6%, in fiscal 2011 compared to fiscal 2010 and increased $61.5 million, or 10%, in fiscal 2010 compared to fiscal 2009. These increases were the result of an increase in the aggregate contract value of the installed base under
SEM contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Adoption of new accounting standards related to revenue recognition did not have a significant impact on SEM revenues.

[0001193125-11-171858:mdna:104]
Service Revenues (in millions, except percentages):

[0001193125-11-171858:mdna:105]
|  |  | Year Ended |  |
|  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Service revenues |  | $ | 1,034.9 |  |  | $ | 870.5 |  |  |  | 19 | % |  | $ | 764.1 |  |  |  | 14 | % |

[0001193125-11-171858:mdna:106]
Service revenues include
hardware maintenance, professional services and educational and training services. Service revenues increased by $164.4 million, or 19%, in fiscal 2011, compared to fiscal 2010 and by $106.4 million, or 14%, in fiscal 2010, compared to fiscal
2009. Adoption of new accounting standards related to revenue recognition did not have a significant impact on service revenues.

[0001193125-11-171858:mdna:107]
Hardware maintenance contract revenues increased 23% in fiscal 2011 compared to fiscal 2010 and increased 20% in fiscal 2010 compared to fiscal 2009, as a result of an increase in the installed base under
service contracts. Professional services and educational and training services revenues increased 11% for fiscal 2011, compared to fiscal 2010 and increased 4% for fiscal 2010, compared to fiscal 2009.

[0001193125-11-171858:mdna:108]
GSA settlement (in millions, except percentages):

[0001193125-11-171858:mdna:109]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| GSA settlement |  | $ | — |  |  | $ | — |  |  |  | NM |  |  | $ | (128.7 | ) |  |  | (100 | )% |

[0001193125-11-171858:mdna:110]
NM — Not meaningful.

[0001193125-11-171858:mdna:111]
During fiscal 2009 we recorded $128.7 million as a reduction of revenues for the GSA settlement.

[0001193125-11-171858:mdna:112]
Revenues by Geographic Area (in millions, except percentages):

[0001193125-11-171858:mdna:113]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 2,899.0 |  |  | $ | 2,208.1 |  |  |  | 31 | % |  | $ | 1,805.2 |  |  |  | 22 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 1,719.1 |  |  |  | 1,329.1 |  |  |  | 29 | % |  |  | 1,213.3 |  |  |  | 10 | % |
| Asia Pacific and Japan (APAC) |  |  | 504.5 |  |  |  | 394.2 |  |  |  | 28 | % |  |  | 387.9 |  |  |  | 2 | % |
| Net revenues |  | $ | 5,122.6 |  |  | $ | 3,931.4 |  |  |  |  |  |  | $ | 3,406.4 |  |  |  |  |  |

[0001193125-11-171858:mdna:114]
Sales to the United States accounted for 89%, 89% and 90% of Americas’ revenues in fiscal
2011, 2010 and 2009, respectively. Revenues from the Americas geographic area increased $690.9 million in fiscal 2011 compared to fiscal 2010. Revenues from the Americas geographic area increased by $402.9 million in fiscal 2010

[0001193125-11-171858:mdna:115]
compared to fiscal 2009, due to an increase in gross revenues of $531.6 million and the negative impact in fiscal 2009 of the $128.7 million GSA settlement. Sales to Germany accounted
for 12%, 11% and 11% of net revenues in fiscal 2011, 2010 and 2009, respectively. No other single foreign country accounted for ten percent or more of net revenues in any of the years presented.

[0001193125-11-171858:mdna:116]
Cost of Revenues

[0001193125-11-171858:mdna:117]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping of our storage systems, amortization of purchased intangible
assets, inventory write-downs, and warranty costs; (2) cost of SEM, which includes the costs of providing SEM and third party royalty costs, and (3) cost of service revenues, which reflects costs associated with providing support
activities for hardware, global support partnership programs, professional services and educational and training services. Cost of revenues also reflect the adoption of the new accounting standards related to revenue recognition.

[0001193125-11-171858:mdna:118]
Our gross profit is impacted by a variety of factors including pricing and discount practices, product configuration, channel sales mix,
revenue mix and product material costs. Service gross profit is also typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of support service initiations and renewals, and incremental
investments in our customer support infrastructure. If our shipment volumes, product and services mix, average selling prices and pricing actions that impact our gross profit are adversely affected, whether by economic uncertainties or for other
reasons, our gross profit could decline.

[0001193125-11-171858:mdna:119]
Cost of Product Revenues (in millions, except percentages):

[0001193125-11-171858:mdna:120]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,342.0 |  |  | $ | 976.4 |  |  |  | 37 | % |  | $ | 1,007.6 |  |  |  | (3 | )% |

[0001193125-11-171858:mdna:121]
Cost of product revenues
increased by $365.6 million, or 37%, in fiscal 2011 compared to fiscal 2010 and decreased by $31.2 million, or 3%, in fiscal 2010 compared to fiscal 2009. The changes were comprised of the following elements (in percentage points of the total
change):

[0001193125-11-171858:mdna:122]
|  |  | Year EndedFiscal 2010 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2009 toFiscal 2010PercentageChangePoints |  |
| Materials costs |  |  | 34 |  |  |  | 1 |  |
| Excess and obsolete inventory |  |  | — |  |  |  | (2 | ) |
| Warranty |  |  | 1 |  |  |  | (1 | ) |
| Manufacturing overhead |  |  | 1 |  |  |  | — |  |
| Other |  |  | 1 |  |  |  | (1 | ) |
| Total change |  |  | 37 |  |  |  | (3 | ) |

[0001193125-11-171858:mdna:123]
In fiscal 2011, the increase in materials cost is primarily due to the 46% increase in configured systems
unit volume, and includes the impact from adoption of the new accounting standards related to revenue recognition. Average materials costs per unit in fiscal 2011 did not significantly change from fiscal 2010. Our fiscal 2011 cost of product
revenues includes:

[0001193125-11-171858:mdna:124]
|  | (i) | an increase of $222.7 million in material costs related to increased volumes in configured systems; |

[0001193125-11-171858:mdna:125]
|  | (ii) | an increase of $15.8 million in warranty expenses; and |

[0001193125-11-171858:mdna:126]
|  | (iii) | an increase of $127.1 million in costs of hardware add-ons and other product costs. |

[0001193125-11-171858:mdna:127]
In fiscal 2010, the decrease in materials cost reflects a decrease in unit costs in our
medium-sized and smaller systems, partially offset by an increase of in high-end systems unit cost. Average materials costs per unit were favorably impacted by lower average per unit materials costs in our medium-sized and smaller systems due to
favorable materials pricing in fiscal 2010, partially offset by an increase in average per unit materials costs in our high-end systems. Our fiscal 2010 cost of product revenues includes:

[0001193125-11-171858:mdna:128]
|  | (i) | a decrease of $9.9 million in material costs, despite an increase in total units shipped; |

[0001193125-11-171858:mdna:129]
|  | (ii) | a decrease of $11.3 million in warranty expenses; and |

[0001193125-11-171858:mdna:130]
|  | (iii) | a decrease of $8.6 million in inventory valuation charges. |

[0001193125-11-171858:mdna:131]
Cost of product revenues represented 40% of product revenue for 2011 compared to 41% for 2010, and 47% for 2009. The overall reduction of costs as a percentage of revenues for both fiscal 2011 and 2010
was the result of reductions in materials cost per unit outpacing sales price reductions.

[0001193125-11-171858:mdna:132]
Cost of Software Entitlements
and Maintenance Revenues (in millions, except percentages):

[0001193125-11-171858:mdna:133]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 15.7 |  |  | $ | 12.3 |  |  |  | 28 | % |  | $ | 9.2 |  |  |  | 34 | % |

[0001193125-11-171858:mdna:134]
Cost of SEM revenues
increased by $3.4 million, or 28% in fiscal 2011 compared to fiscal 2010 and increased $3.1 million, or 34%, in fiscal 2010 compared to fiscal 2009 primarily due to an increase in software related service support costs. Cost of SEM revenues
represented 2% of SEM revenues for each of fiscal 2011, 2010 and 2009, respectively.

[0001193125-11-171858:mdna:135]
Cost of Service Revenues (in
millions, except percentages):

[0001193125-11-171858:mdna:136]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Cost of service revenues |  | $ | 436.2 |  |  | $ | 423.5 |  |  |  | 3 | % |  | $ | 399.7 |  |  |  | 6 | % |

[0001193125-11-171858:mdna:137]
Cost of service revenues
increased by $12.7 million, or 3%, in fiscal 2011 compared to fiscal 2010 primarily due to an increase in service and support purchased from third parties, as well as an increase in logistics costs, and increased by $23.8 million, or 6%, in
fiscal 2010 compared to fiscal 2009 due to increased commissions and incentive compensation plan expenses, as well as an increase in service and support purchased from third parties. Costs represented 42%, 49% and 52%, respectively, of service
revenues for fiscal 2011, 2010 and 2009. The decrease in service cost of revenues as a percentage of service revenue in fiscal 2011 compared to fiscal 2010, and fiscal 2010 compared to fiscal 2009 was primarily due to improved productivity.

[0001193125-11-171858:mdna:138]
Operating Expenses

[0001193125-11-171858:mdna:139]
Sales and Marketing, Research and Development, and General and Administrative Expenses

[0001193125-11-171858:mdna:140]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries and related benefits, stock-based compensation costs and employee incentive
compensation plan costs. Compensation costs included in operating expenses increased approximately $202.3 million, or 18%, during fiscal 2011 compared to fiscal 2010, primarily due to:

[0001193125-11-171858:mdna:141]
(i) an increase in salaries, benefits and other compensation related costs due to an increase in average headcount, primarily in sales,
marketing and engineering functions, of $169.9 million;

[0001193125-11-171858:mdna:142]
(ii) an increase in incentive compensation expense reflecting stronger operating performance
and increased headcount of $16.7 million; and

[0001193125-11-171858:mdna:143]
(iii) an increase in stock based compensation of $15.7 million.

[0001193125-11-171858:mdna:144]
In addition, sales and marketing expenses reflected an increase in commissions expense of $30.2 million during fiscal 2011,
reflecting stronger sales performance compared to fiscal 2010.

[0001193125-11-171858:mdna:145]
Compensation costs included in operating expenses increased
approximately $108.6 million, or 11%, during fiscal 2010 compared to fiscal 2009, primarily due to:

[0001193125-11-171858:mdna:146]
(i) a $75.6 million
increase in employee incentive compensation due to stronger operating profit performance;

[0001193125-11-171858:mdna:147]
(ii) a $16.4 million
increase in stock based compensation; and

[0001193125-11-171858:mdna:148]
(iii) a $16.5 million increase in salaries, benefits and other
compensation related costs.

[0001193125-11-171858:mdna:149]
In addition, sales and marketing expenses reflected an increase in commissions expense of
$60.7 million during fiscal 2010, reflecting stronger sales performance compared to fiscal 2009.

[0001193125-11-171858:mdna:150]
Sales and Marketing
(in millions, except percentages) —

[0001193125-11-171858:mdna:151]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,597.0 |  |  | $ | 1,293.7 |  |  |  | 23 | % |  | $ | 1,186.1 |  |  |  | 9 | % |

[0001193125-11-171858:mdna:152]
Sales and marketing
expense consists primarily of compensation costs, commissions, outside services, allocated facilities and IT costs, advertising and marketing promotional expense, and travel and entertainment expense. In addition, during fiscal 2009, we recorded a
$9.4 million loss on impairment of a sales force automation tool. Sales and marketing expenses increased due to the following:

[0001193125-11-171858:mdna:153]
|  |  | Year EndedFiscal 2010 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2009 toFiscal 2010PercentageChangePoints |  |
| Salaries |  |  | 6 |  |  |  | — |  |
| Incentive plan compensation |  |  | 1 |  |  |  | 3 |  |
| Stock based compensation |  |  | 1 |  |  |  | 1 |  |
| Other compensation and benefit costs |  |  | 3 |  |  |  | 1 |  |
| Commissions |  |  | 2 |  |  |  | 5 |  |
| Outside services |  |  | 5 |  |  |  | — |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | (1 | ) |
| Travel and entertainment expense |  |  | 1 |  |  |  | (1 | ) |
| Facilities and IT support costs |  |  | 2 |  |  |  | 1 |  |
| Asset impairment |  |  | — |  |  |  | (1 | ) |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 23 |  |  |  | 9 |  |

[0001193125-11-171858:mdna:154]
The increase in salaries and related expenses in fiscal 2011 reflects an increase in average sales and
marketing headcount of 20%, compared to the prior year. Outside services increased to support sales and marketing initiatives.

[0001193125-11-171858:mdna:155]
Research and Development (in millions, except percentages) —

[0001193125-11-171858:mdna:156]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Research and development expenses |  | $ | 648.6 |  |  | $ | 535.7 |  |  |  | 21 | % |  | $ | 498.5 |  |  |  | 7 | % |

[0001193125-11-171858:mdna:157]
Research and development
expense consists primarily of compensation costs, allocated facilities and IT costs, depreciation and amortization, equipment and software related costs, prototypes, non-recurring engineering, or (NRE) charges and other outside services costs.
Research and development expenses increased due to the following:

[0001193125-11-171858:mdna:158]
|  |  | Year EndedFiscal 2010 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2009 toFiscal 2010PercentageChangePoints |  |
| Salaries |  |  | 8 |  |  |  | (1 | ) |
| Incentive plan compensation |  |  | 1 |  |  |  | 6 |  |
| Stock based compensation |  |  | 1 |  |  |  | — |  |
| Other compensation and benefit costs |  |  | 2 |  |  |  | — |  |
| Travel and entertainment expense |  |  | 1 |  |  |  | — |  |
| Facilities and IT support costs |  |  | 4 |  |  |  | 2 |  |
| NRE charges |  |  | (1 | ) |  |  | 1 |  |
| Outside services |  |  | 1 |  |  |  | — |  |
| Equipment and software related costs |  |  | 1 |  |  |  | — |  |
| Other |  |  | 3 |  |  |  | (1 | ) |
| Total change |  |  | 21 |  |  |  | 7 |  |

[0001193125-11-171858:mdna:159]
The fiscal 2011 increase in salaries and related expenses reflects a 28% increase in average engineering
headcount compared to fiscal 2010.

[0001193125-11-171858:mdna:160]
We believe that our future performance will depend in large part on our ability to
maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future
product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-11-171858:mdna:161]
General and Administrative (in millions, except percentages):

[0001193125-11-171858:mdna:162]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| General and administrative expenses |  | $ | 251.3 |  |  | $ | 238.8 |  |  |  | 5 | % |  | $ | 203.7 |  |  |  | 17 | % |

[0001193125-11-171858:mdna:163]
58

[0001193125-11-171858:mdna:164]
General and administrative expense consists primarily of compensation costs, professional
and corporate legal fees, outside services and allocated facilities and IT costs. General and administrative expenses increased due to the following:

[0001193125-11-171858:mdna:165]
|  |  | Year EndedFiscal 2010 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2009 toFiscal 2010PercentageChangePoints |  |
| Salaries |  |  | 3 |  |  |  | 1 |  |
| Incentive plan compensation |  |  | 1 |  |  |  | 8 |  |
| Stock based compensation |  |  | 1 |  |  |  | 4 |  |
| Other compensation and benefit costs |  |  | (1 | ) |  |  | 3 |  |
| Professional and corporate legal fees |  |  | (5 | ) |  |  | (1 | ) |
| Outside services |  |  | 3 |  |  |  | — |  |
| IT costs |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | 5 |  |  |  | 17 |  |

[0001193125-11-171858:mdna:166]
The fiscal 2011 increase in salaries and related expenses reflects a 10% increase in average general and
administrative headcount compared to fiscal 2010. The increase in outside services in fiscal 2011 reflects additional spending on contractors. Partially offsetting the increase in general and administrative expense was a decrease in legal fees due
to the resolution of the Sun Microsystems litigation in fiscal 2011.

[0001193125-11-171858:mdna:167]
Restructuring and Other Charges (in millions, except
percentages):

[0001193125-11-171858:mdna:168]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Restructuring and other charges |  | $ | 1.8 |  |  | $ | 2.5 |  |  |  | (28 | )% |  | $ | 54.4 |  |  |  | (95 | )% |

[0001193125-11-171858:mdna:169]
In the fourth quarter of
2011, we incurred severance-related restructuring charges of $2.4 million relating to the acquisition of Akorri Networks, Inc. (Akorri), that were partially offset by a reversal of $0.6 million related to our fiscal 2009 restructuring plans.

[0001193125-11-171858:mdna:170]
In fiscal 2010, we incurred $2.5 million related to both our fiscal 2009 restructuring plans and our fiscal 2002
restructuring plan.

[0001193125-11-171858:mdna:171]
In fiscal 2009, we announced our fiscal 2009 restructuring plans that resulted in restructuring charges
totaling $54.4 million.

[0001193125-11-171858:mdna:172]
Fiscal 2009 Restructuring Plans — In February 2009, we announced
our decision to execute a worldwide restructuring program, which included a reduction in workforce, the closing or downsizing of certain facilities, and the establishment of a plan to outsource certain internal activities. In December 2008, we
announced our decision to cease the development and availability of our SnapMirror® for Open Systems product,
which was originally acquired through our acquisition of Topio in fiscal 2007. As part of this decision, we also announced the closure of our engineering facility in Haifa, Israel. As of April 29, 2011, we had no further facilities-related
lease payment reserves related to these activities.

[0001193125-11-171858:mdna:173]
Fiscal 2002 Restructuring Plan — As of April 29,
2011, we have no material balances remaining in facility restructuring reserves established as part of a restructuring plan in fiscal 2002 related to future lease commitments on exited facilities, net of expected sublease income.

[0001193125-11-171858:mdna:174]
See Note 7 of the accompanying consolidated financial statements for more information.

[0001193125-11-171858:mdna:175]
Acquisition Related (Income) Expense, Net (in millions, except percentages):

[0001193125-11-171858:mdna:176]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Acquisition related (income) expense, net |  | $ | 5.7 |  |  | $ | (39.9 | ) |  |  | NM |  |  | $ | — |  |  |  | NM |  |

[0001193125-11-171858:mdna:177]
NM — Not meaningful.

[0001193125-11-171858:mdna:178]
During fiscal 2011, we incurred $5.7 million of costs including due diligence, legal and other one-time integration charges associated
with our acquisitions of Bycast Inc. (Bycast), Akorri and ESG.

[0001193125-11-171858:mdna:179]
On May 20, 2009, we announced that we had entered into a
merger agreement with Data Domain, Inc. (Data Domain) under which we would acquire Data Domain in a stock and cash transaction. On July 8, 2009, Data Domain’s Board of Directors terminated the merger agreement and pursuant to the terms of
the agreement, Data Domain paid us a $57.0 million termination fee. We incurred $15.9 million of incremental third-party costs relating to the terminated merger transaction during the same period, resulting in net proceeds of
$41.1 million recorded in the consolidated statements of operations during fiscal 2010. During fiscal 2010, we paid $1.2 million of acquisition related expenses related to the acquisition of Bycast.

[0001193125-11-171858:mdna:180]
See Notes 6 and 20 of the accompanying financial statements for more information.

[0001193125-11-171858:mdna:181]
Other Income and Expense

[0001193125-11-171858:mdna:182]
Interest Income (in millions, except percentages):

[0001193125-11-171858:mdna:183]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Interest income |  | $ | 39.9 |  |  | $ | 31.2 |  |  |  | 28 | % |  | $ | 57.6 |  |  |  | (46 | )% |

[0001193125-11-171858:mdna:184]
The increase in interest
income for fiscal 2011 compared to fiscal 2010 was primarily due to higher levels of cash equivalent and investment balances in fiscal 2011. The decrease in interest income for fiscal 2010 compared to fiscal 2009, was primarily due to lower market
yields on our cash and investment portfolio.

[0001193125-11-171858:mdna:185]
Interest Expense (in millions, except percentages):

[0001193125-11-171858:mdna:186]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Interest expense |  | $ | (75.9 | ) |  | $ | (74.1 | ) |  |  | 2 | % |  | $ | (63.4 | ) |  |  | 17 | % |

[0001193125-11-171858:mdna:187]
Interest expense was
relatively flat for fiscal 2011 compared to fiscal 2010. Interest expense increased $10.7 million for fiscal 2010 compared to fiscal 2009, primarily due to interest expense on our 1.75% Notes, issued on June 10, 2008, which were
outstanding for the full year ended April 30, 2010, but only for a partial period in the prior year.

[0001193125-11-171858:mdna:188]
During fiscal 2011,
2010 and 2009, we recognized incremental non-cash interest expense from the amortization of debt discount and issuance costs relating to our Notes of approximately $53.1 million, $50.8 million and $41.0 million, respectively. The coupon
interest expense related to the Notes was $22.1 million, $22.5 million and $19.4 million for fiscal 2011, 2010 and 2009, respectively.

[0001193125-11-171858:mdna:189]
Other Income (Expense), Net (in millions, except percentages):

[0001193125-11-171858:mdna:190]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Realized gain on investments, net |  | $ | 3.5 |  |  | $ | 3.9 |  |  |  | (10 | )% |  | $ | — |  |  |  | NM |  |
| Impairment of investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (29.5 | ) |  |  | (100 | )% |
| Other expenses, net |  |  | 2.3 |  |  |  | (2.4 | ) |  |  | NM |  |  |  | (3.6 | ) |  |  | (33 | )% |
| Other income (expense), net |  | $ | 5.8 |  |  | $ | 1.5 |  |  |  | 287 | % |  | $ | (33.1 | ) |  |  | NM |  |

[0001193125-11-171858:mdna:191]
NM — Not meaningful

[0001193125-11-171858:mdna:192]
Other income (expense), net in fiscal 2011 included $3.5 million of net gains on investments, consisting primarily of a $2.5 million
distribution from our investment in the Primary Fund and gains on investments in privately held companies. Other expenses, net included $3.0 million in other income, partially offset by $0.7 million in net losses on foreign currency transactions and
related hedging activities.

[0001193125-11-171858:mdna:193]
Other income (expense), net in fiscal 2010 included $3.9 million of net gains on
investments, consisting primarily of a gain on investments in privately held companies of $3.7 million and $1.0 million net gain on our investment in the Primary Fund and Lehman Brothers securities, offset by net losses on other
investments of $0.8 million. Other expenses included $5.3 million in net losses on foreign currency transactions and related hedging activities, partially offset by other income of $2.9 million.

[0001193125-11-171858:mdna:194]
Other income (expense), net in fiscal 2009 included a net impairment loss related to our investments in privately held companies of
$6.3 million, an other-than-temporary impairment charge on our available-for-sale investments related to direct and indirect investments in Lehman Brothers securities of $21.1 million, and an other-than-temporary decline in the value of
our ARS of $2.1 million. Other expenses included $5.0 in net exchange losses from foreign currency transactions and related hedging activities, partially offset by other income of $1.4 million.

[0001193125-11-171858:mdna:195]
Provision for (Benefit from) Income Taxes (in millions, except percentages):

[0001193125-11-171858:mdna:196]
|  |  | Year Ended |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | % Change |  |  | April 24, 2009 |  |  | % Change |  |
| Provision for (benefit from) income taxes |  | $ | 121.0 |  |  | $ | 46.6 |  |  |  | 160 | % |  | $ | (56.3 | ) |  |  | NM |  |

[0001193125-11-171858:mdna:197]
NM — Not meaningful.

[0001193125-11-171858:mdna:198]
Our effective tax rate for fiscal 2011 was 15.2%, compared to an effective tax rate of 10.4% for fiscal 2010, and an effective tax
benefit of 681.5% for fiscal 2009. Our effective tax rate reflects our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the
U.S. statutory tax rate. The effective tax rate for both fiscal 2011 and fiscal 2010 was favorably impacted by the geographic mix of profits. The tax benefit rate for fiscal 2009 reflected losses generated in the U.S. during that period
that were partially offset by profits generated in foreign tax jurisdictions where the tax rates were below the U.S. statutory rate.

[0001193125-11-171858:mdna:199]
The effective tax rate of 15.2% in fiscal 2011 included a benefit of $146.9 million, or 18.5 percentage points, related to foreign income tax rates that are lower than the U.S. federal
statutory rate of 35%, a benefit of $17.8 million, or 2.2 percentage points, related to research and development tax credits, a benefit of $1.3 million, or 0.2 percentage points, related to stock-based compensation and an IRS audit
settlement of $21.1 million, or 2.7 percentage points, partially offset by the unfavorable impact of $31.1 million, or 3.9 percentage points, related to state income taxes.

[0001193125-11-171858:mdna:200]
The effective tax rate of 10.4% in fiscal 2010 included a benefit of $105.3 million, or
23.5 percentage points, related to foreign income tax rates that are lower than the U.S. federal statutory rate of 35%, a benefit of $7.8 million, or 1.7 percentage points, related to research and development tax credits, a
benefit of $2.6 million, or 0.6 percentages points, related to stock-based compensation, partially offset by the unfavorable impact of $2.6 million, or 0.6 percentage points, related to state income taxes.

[0001193125-11-171858:mdna:201]
The effective tax benefit of 681.5% for fiscal 2009 included the benefit of $51.0 million related to foreign income tax rates that
are lower than the U.S. federal statutory rate of 35%, a benefit of $9.2 million related to research and development tax credits, a benefit of $7.9 million related to state income taxes, partially offset by the unfavorable impact of
$10.2 million related to stock-based compensation.

[0001193125-11-171858:mdna:202]
Liquidity and Capital Resources

[0001193125-11-171858:mdna:203]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and
capital resources. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to
maturity and by monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash
equivalents or investments from the values reported as of April 29, 2011.

[0001193125-11-171858:mdna:204]
Liquidity Sources, Cash Requirements

[0001193125-11-171858:mdna:205]
Our principal sources of liquidity as of April 29, 2011 consisted of approximately $5.2 billion in cash,
cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001193125-11-171858:mdna:206]
Cash, cash equivalents
and short-term investments consist of the following:

[0001193125-11-171858:mdna:207]
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |
| Cash and cash equivalents |  | $ | 2,757.3 |  |  | $ | 1,705.0 |  |
| Short-term investments |  |  | 2,417.4 |  |  |  | 2,019.0 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,174.7 |  |  | $ | 3,724.0 |  |

[0001193125-11-171858:mdna:208]
As of April 29, 2011, $3.0 billion of cash, cash equivalents and short-term investments were held in
the United States, while $2.2 billion were held in foreign countries. Most of the amounts held outside the United States may be repatriated to the United States but, under current law, would be subject to U.S. federal and state income taxes. As of
April 29, 2011, we have not provided for U.S. federal and state income taxes on approximately $872.1 million of undistributed earnings of our foreign subsidiaries, as such earnings are considered indefinitely reinvested outside the United
States. If we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income tax, reduced by the current amount of our U.S. federal and state net operating loss and tax credit carryforwards.
However, our intent is to keep these funds permanently reinvested outside of the U.S. and our current plans do not demonstrate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are to fund the $480 million
purchase price of our fiscal 2012 acquisition of certain assets related to ESG, meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary
technologies, and to service our debt and synthetic leases. Our contractual obligations as of April 29, 2011 are summarized below in the Contractual Obligations tables.

[0001193125-11-171858:mdna:209]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and
inventories, our ability to effectively integrate acquired products, businesses and technologies, including ESG and conversions of our Notes

[0001193125-11-171858:mdna:210]
by holders. Based on our current business outlook, we believe that our sources of cash will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases,
contractual obligations, commitments, interest payments on our Notes and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is
insufficient, we may be required to further curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be
able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-11-171858:mdna:211]
Our investment portfolio, including
auction rate securities has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize our market risk on our investment
portfolio. Based on our ability to access our cash and short-term investments, our expected operating cash flows, and our other potential sources of cash, we do not anticipate that the lack of liquidity of these investments will impact our ability
to fund working capital needs, capital expenditures, acquisitions or other cash requirements. We intend to and believe that we have the ability to hold these investments until the market recovers. If current market conditions deteriorate, we may be
required to record additional charges to earnings in future periods.

[0001193125-11-171858:mdna:212]
Capital Expenditure Requirements

[0001193125-11-171858:mdna:213]
Our capital expenditures were $222.7 million during fiscal 2011. We anticipate capital expenditures for fiscal 2012 to
be between $250.0 million and $300.0 million. We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through
existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes
in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing facilities and those being developed in Sunnyvale, California; Research Triangle Park,
North Carolina; and worldwide are adequate for our requirements over at least the next two years and that additional space will be available as needed.

[0001193125-11-171858:mdna:214]
Acquisition Related Requirements

[0001193125-11-171858:mdna:215]
On May 6, 2011, we completed
the acquisition of certain assets related to the ESG business. We paid LSI $480 million in cash and also assumed certain assets and liabilities related to ESG. As of April 29, 2011, we had incurred approximately $4.8 million in acquisition and
one-time integration related expenses for ESG which are included in acquisition related (income) expense, net, in our consolidated statements of operations. As part of our efforts to integrate ESG into our business, we expect to incur additional
one-time integration, restructuring and impairment charges. See Note 20 of the accompanying financial statements for more information.

[0001193125-11-171858:mdna:216]
Cash Flows

[0001193125-11-171858:mdna:217]
As of April 29, 2011, compared to April 30,
2010, our cash and cash equivalents and short-term and long-term investments increased by $1.5 billion to $5.2 billion. The increase was primarily a result of $1.3 billion of cash provided by operating activities and to a lesser extent
from issuances of common stock related to employee stock option exercises and purchases under the employee stock purchase plan of $196.5 million, net of tax benefit, partially offset by $74.9 million and $61.6 million net cash paid in connection
with the acquisitions of Bycast and Akorri, respectively and $222.7 million in capital expenditures. We derive our liquidity and capital resources primarily from our cash flow from operations and from working capital. Accounts receivable days sales
outstanding as of April 29, 2011 increased to 47 days, compared to 37 days as of April 30, 2010, as material supply constraints through the middle of the fourth quarter of fiscal 2011 contributed to a back-end loaded shipment
profile, which in turn, drove the increase in days sales outstanding. Working capital increased by $366.3 million to $3.0 billion as of April 29, 2011, compared to $2.6 billion as of April 30, 2010, primarily due

[0001193125-11-171858:mdna:218]
to an increase in cash, cash equivalents and short-term investments of $1.5 billion, partially offset by the reclassification of our $1.2 billion Notes to current liabilities as the
underlying contingent conversion threshold was exceeded at April 29, 2011.

[0001193125-11-171858:mdna:219]
Cash Flows from Operating Activities

[0001193125-11-171858:mdna:220]
During fiscal 2011 and 2010, we generated cash from operating activities of $1.3 billion and $975.0 million,
respectively. The primary sources of cash from operating activities in fiscal 2011 consisted of net income of $673.1 million, adjusted by non-cash stock-based compensation expense of $175.2 million and depreciation and amortization expense
of $165.6 million. Significant changes in assets and liabilities impacting operating cash flows in fiscal 2011 included an increase in accounts receivable of $262.7 million due to the backend loaded shipment profile during the fourth quarter of
fiscal year 2011, an increase in deferred revenue of $382.9 million primarily resulting from overall growth in shipments, and an increase in accrued compensation and other current liabilities of $118.8 million due to our increase in headcount.
The primary sources of cash from operating activities in fiscal 2010 consisted of net income of $400.4 million, adjusted by non-cash stock-based compensation expense of $159.8 million and depreciation and amortization expense of
$166.0 million. Significant changes in assets and liabilities impacting operating cash flows in fiscal 2010 included an increase in deferred revenue of $176.7 million and an increase in accrued compensation and other current liabilities of
$53.2 million.

[0001193125-11-171858:mdna:221]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a
number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits from stock-based compensation, and the timing and amount of
compensation and other payments.

[0001193125-11-171858:mdna:222]
Cash Flows from Investing Activities

[0001193125-11-171858:mdna:223]
Capital expenditures for fiscal 2011 were $222.7 million. We paid $418.5 million for net purchases and redemptions of our investments in
fiscal 2011. During fiscal 2011, we completed our acquisitions of Bycast and Akorri for total cash payments of $74.9 million and $61.6 million, respectively, net of cash acquired. Capital expenditures for fiscal 2010 were $135.6 million, which
included the purchase of fifteen acres of land in Bangalore, India for approximately $28.5 million. We paid $860.3 million for net purchases and redemptions of short-term investments in fiscal 2010.

[0001193125-11-171858:mdna:224]
Cash Flows from Financing Activities

[0001193125-11-171858:mdna:225]
We received $450.9 million from financing activities in fiscal 2011, which primarily consisted of $324.2 million of proceeds from employee equity award plans, net of shares withheld for taxes, and $127.7
million of excess tax benefit from stock-based compensation. We received $219.9 million from financing activities in fiscal 2010, which primarily consisted of $197.1 million of proceeds from employee equity award plans, net of shares withheld
for taxes and $14.2 million from the settlement of a Note hedge with Lehman Brothers.

[0001193125-11-171858:mdna:226]
Net proceeds from the issuance of
common stock related to employee participation in employee equity award programs have historically been a significant component of our liquidity. The extent to which our employees exercise stock options or participate in our ESPP program generally
increases or decreases based upon changes in the market price of our common stock. As a result, our cash flow resulting from the issuance of common stock in connection with these programs and related tax benefits will vary.

[0001193125-11-171858:mdna:227]
Stock Repurchase Program

[0001193125-11-171858:mdna:228]
Since the May 13, 2003 inception of our stock repurchase program through April 29, 2011, our Board of Directors has authorized the repurchase of up to $4.0 billion of common stock under such
stock repurchase program. At April 29, 2011, $1.1 billion remains available under these authorizations. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-11-171858:mdna:229]
Convertible Notes

[0001193125-11-171858:mdna:230]
As of April 29, 2011, we had $1.265 billion principal amount of 1.75% Convertible Senior Notes due 2013 (See Note 10
of the accompanying consolidated financial statements). The Notes will mature on June 1, 2013, unless earlier repurchased or converted. Based upon the closing price of our common stock for the prescribed measurement period in fiscal 2011, the
contingent conversion threshold of the Notes was exceeded as of April 29, 2011. Accordingly, the carrying value of the Notes was classified as a current liability at April 29, 2011. Since the Notes are convertible at the option of the
holder and the principal amount is required to be paid in cash, the difference between the principal amount and the carrying value of the Notes is reflected as convertible debt in mezzanine on our balance sheet as of April 29, 2011. The
determination of whether or not the Notes are convertible must continue to be performed on an ongoing basis. Consequently, the Notes may not be convertible in future quarters, and therefore may again be classified as long-term debt, if the
contingent conversion threshold is not met in such quarters. As of April 29, 2011, shares issued related to conversion of the Notes were minimal. Receipts of shares related to the Note hedge transactions were minimal and there was no cash
or shares delivered in relation to the warrant transactions as of April 29, 2011.

[0001193125-11-171858:mdna:231]
Contractual Obligations

[0001193125-11-171858:mdna:232]
The following summarizes our contractual obligations at April 29, 2011 and the effect such obligations are
expected to have on our liquidity and cash flows in future periods (in millions):

[0001193125-11-171858:mdna:233]
|  |  | 2012 |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 30.3 |  |  | $ | 26.4 |  |  | $ | 22.5 |  |  | $ | 20.9 |  |  | $ | 14.9 |  |  | $ | 11.7 |  |  | $ | 126.7 |  |
| Real estate lease payments(1) |  |  | 3.2 |  |  |  | 129.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 132.4 |  |
| Less: sublease income |  |  | (1.4 | ) |  |  | (1.4 | ) |  |  | (1.1 | ) |  |  | (1.1 | ) |  |  | (0.5 | ) |  |  | — |  |  |  | (5.5 | ) |
| Equipment operating lease payments |  |  | 21.5 |  |  |  | 13.2 |  |  |  | 6.5 |  |  |  | 0.6 |  |  |  | — |  |  |  | — |  |  |  | 41.8 |  |
| Purchase commitments with contract manufacturers(2) |  |  | 171.0 |  |  |  | 3.6 |  |  |  | 1.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | 176.0 |  |
| Capital expenditures |  |  | 32.1 |  |  |  | 4.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 36.1 |  |
| Other purchase obligations(3) |  |  | 171.7 |  |  |  | 62.5 |  |  |  | 18.7 |  |  |  | 13.9 |  |  |  | 3.2 |  |  |  | — |  |  |  | 270.0 |  |
| Total off balance-sheet commitments |  |  | 428.4 |  |  |  | 237.5 |  |  |  | 47.8 |  |  |  | 34.5 |  |  |  | 17.6 |  |  |  | 11.7 |  |  |  | 777.5 |  |
| 1.75% Convertible notes(4) |  |  | 1,287.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,287.1 |  |
| Long-term financing arrangements |  |  | 5.7 |  |  |  | 6.0 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11.9 |  |
| Uncertain tax positions(5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 104.2 |  |
| Total |  | $ | 1,721.2 |  |  | $ | 243.5 |  |  | $ | 48.0 |  |  | $ | 34.5 |  |  | $ | 17.6 |  |  | $ | 11.7 |  |  | $ | 2,180.7 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 4.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1.2 |  |  | $ | 5.3 |  |

[0001193125-11-171858:mdna:234]
Some of the amounts we include in this table are based on management’s estimates and assumptions about
these obligations, including their duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are necessarily subjective, our actual future
obligations may vary from those reflected in the table. We expect to fund our contractual obligations and other commitments in the table above through existing cash, cash equivalents, investments, and cash generated from operations or obtain
additional financing, if necessary.

[0001193125-11-171858:mdna:235]
| (1) | Included in real estate lease payments pursuant to four financing arrangements with BNP Paribas LLC (BNPPLC) are (i) lease commitments of $3.2 million in fiscal 2012; and $2.1 million in fiscal 2013, which are based on either the LIBOR rate at April 29, 2011 plus a spread or a fixed rate for terms of five years, and (ii) at the expiration or termination of the lease, a supplemental payment obligation equal to our minimum guarantee of $127.1 million in the event that we elect not to purchase or arrange for sale of the buildings. |

[0001193125-11-171858:mdna:236]
65

[0001193125-11-171858:mdna:237]
| (2) | Contract manufacturer commitments consist of obligations for on hand inventories and non-cancelable purchase orders with our contract manufacturer. We record a liability for firm, noncancelable, and nonreturnable purchase commitments for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. As of April 29, 2011, the liability for these purchase commitments in excess of future demand was approximately $4.5 million and is recorded in other current liabilities. |

[0001193125-11-171858:mdna:238]
| (3) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001193125-11-171858:mdna:239]
| (4) | Amount includes the $1.265 billion principal amount of 1.75% Notes due 2013 and the estimated fiscal 2012 interest payment for the Notes of $22.1 million. Based upon the closing price of our common stock for the prescribed measurement period during fiscal 2011, the contingent conversion threshold on the Notes was exceeded. As a result, the Notes are convertible at the option of the holder through June 30, 2011. Accordingly, since the terms of the Notes require the principal to be settled in cash, we reclassified from equity the portion of the Notes attributable to the conversion feature, which had not yet been accreted to its face value, and reclassified the Notes to current liabilities. For the holders to be able to continue to convert the Notes, our closing stock price must exceed $41.41 for 20 out of the last 30 trading days of each future calendar quarter. If this threshold is not met, the Notes will be reclassified to long-term debt. |

[0001193125-11-171858:mdna:240]
| (5) | As of April 29, 2011, our liability for uncertain tax positions was $104.2 million, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-11-171858:mdna:241]
As of April 29, 2011, we have four leasing
arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNPPLC which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in
Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease
commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of
the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third party for an amount equal to at
least 85% of the costs (residual guarantee), and be liable for any deficiency between the net proceeds received from the third party and such amounts; or (iii) pay BNPPLC supplemental payments for an amount equal to at least 85% of the costs
(residual guarantee), in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period. The following table summarizes the costs, the residual guarantee, the
applicable LIBOR plus spread or fixed rate at April 29, 2011 and the date we began to make payments for each of our leasing arrangements (in millions):

[0001193125-11-171858:mdna:242]
| Leasing Arrangements |  | Cost |  | ResidualGuarantee |  | LIBORPlusSpread orFixed Rate |  | LeaseCommencementDate |  | Term |
| 1 |  | $48.5 |  | $41.2 |  | 3.69% |  | January 2008 |  | 5 years |
| 2 |  | 80.0 |  | 68.0 |  | 0.79% |  | December 2007 |  | 5 years |
| 3 |  | 10.5 |  | 8.9 |  | 3.67% |  | December 2007 |  | 5 years |
| 4 |  | 10.6 |  | 9.0 |  | 3.69% |  | December 2007 |  | 5 years |

[0001193125-11-171858:mdna:243]
All leases require us to
maintain specified financial covenants with which we were in compliance as of April 29, 2011. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than three to
one and a minimum amount of Unencumbered Cash

[0001193125-11-171858:mdna:244]
and Short-Term Investments of $300 million. Our failure to comply with these financial covenants could result in a default under the leases which, subject to our right and ability to exercise our
purchase option, would give BNPPLC the right to, among other things, (i) terminate our possession of the leased property and require us to pay lease termination damages and other amounts as set forth in the lease agreements, or
(ii) exercise certain foreclosure remedies. If we were to exercise our purchase option, or be required to pay lease termination damages, these payments would significantly reduce our available liquidity, which could constrain our operating
flexibility.

[0001193125-11-171858:mdna:245]
As of April 29, 2011, we estimated that the fair value of the properties under synthetic lease was
$35.8 million less than their aggregate residual guarantees. We are accruing for this deficiency over the remaining terms of the respective leases. As of April 29, 2011, a deficiency reserve of $16.1 million was included in other long-term
liabilities.

[0001193125-11-171858:mdna:246]
We may from time to time terminate one or more of our leasing arrangements and repay amounts outstanding in
order to meet our operating or other objectives.

[0001193125-11-171858:mdna:247]
Legal Contingencies

[0001193125-11-171858:mdna:248]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as
of April 29, 2011, as the outcome of these legal matters is currently not determinable.

[0001193125-11-171858:mdna:249]
On October 13, 2010,
Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of
California, Santa Clara County. The lawsuit named 15 of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had
filed. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal
requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional
unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011, and the hearing on these motions is scheduled for July 15, 2011.

[0001193125-11-171858:mdna:250]
Off-Balance Sheet Arrangements

[0001193125-11-171858:mdna:251]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our
subsidiaries. As of April 29, 2011, our financial guarantees of $5.3 million that were not recorded on our balance sheet consisted of standby letters of credit related to workers’ compensation, a customs guarantee, a corporate credit
card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-11-171858:mdna:252]
We use derivative
instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency. The program is not designated for trading or
speculative purposes. Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related to firm commitments or nonmarketable investments. Our major foreign currency exchange exposures and related hedging programs are
described below:

[0001193125-11-171858:mdna:253]
|  | • |  | We utilize monthly foreign currency forward and options contracts to hedge exchange rate fluctuations related to certain foreign monetary assets and liabilities. |

[0001193125-11-171858:mdna:254]
|  | • |  | We use currency forward contracts to hedge exposures related to forecasted sales denominated in certain foreign currencies. These contracts are designated as cash flow hedges and in general closely match the underlying forecasted transactions in duration. |

[0001193125-11-171858:mdna:255]
As of April 29, 2011, our notional fair value of foreign exchange forward and foreign
currency option contracts totaled $592.4 million. We do not believe that these derivatives present significant credit risks, because of the short term maturity of the outstanding contracts at any point in time, the counterparties to the
derivatives consist of major financial institutions, and we manage the notional amount of contracts entered into with any one counterparty. Other than the risk associated with the financial condition of the counterparties, our maximum exposure
related to foreign currency forward and option contracts is limited to the premiums paid. See Note 12 of the accompanying consolidated financial statements for more information related to our hedging activities.

[0001193125-11-171858:mdna:256]
In the ordinary course of business, we enter into recourse lease financing arrangements with third-party leasing companies and from time
to time provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to the third-party funding companies in the event of nonpayment by end-user customers. See Note 18 of the accompanying
consolidated financial statements for more information related to these financing arrangements.

[0001193125-11-171858:mdna:257]
We enter into indemnification
agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third party due to various events, such as lawsuits arising from patent or copyright
infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.

[0001193125-11-171858:mdna:258]
We
have commitments related to four lease arrangements with BNPPLC for approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, California (as further described above under “Contractual Obligations”). Our
future minimum lease payments and residual guarantees under these real estate leases will amount to a total of $132.4 million as discussed above in “Contractual Obligations”.

[0001193125-11-171858:mdna:259]
We have evaluated our accounting for these leases as required by guidance on accounting for variable interest entities and have
determined the following:

[0001193125-11-171858:mdna:260]
|  | • |  | BNPPLC is a leasing company for BNP Paribas in the United States. BNPPLC is not a “special purpose entity” organized for the sole purpose of facilitating the leases to us. The obligation to absorb expected losses and receive expected residual returns rests with the parent, BNP Paribas. Therefore, we are not the primary beneficiary of BNPPLC as we do not absorb the majority of BNPPLC’s expected losses or expected residual returns; and |

[0001193125-11-171858:mdna:261]
|  | • |  | BNPPLC has represented in the related closing agreements that the fair value of the property leased to us by BNPPLC is less than half of the total of the fair values of all assets of BNPPLC, excluding any assets of BNPPLC held within a silo. Further, the property leased to NetApp is not held within a silo. The definition of “held within a silo” means that BNPPLC has obtained funds equal to or in excess of 95% of the fair value of the leased asset to acquire or maintain its investment in such asset through nonrecourse financing or other contractual arrangements, the effect of which is to leave such asset (or proceeds thereof) as the only significant asset of BNPPLC at risk for the repayment of such funds. |

[0001193125-11-171858:mdna:262]
Accordingly, under current
accounting guidance, we are not required to consolidate either the leasing entity or the specific assets that we lease under the BNPPLC lease.
