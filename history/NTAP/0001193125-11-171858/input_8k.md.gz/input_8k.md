# NTAP 8-K — 0001102624-11-000322 filed 2011-05-25

## item codes, every 8-K on or before 2011-06-23

- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2011-06-23

- none on or before 2011-06-23

## item 2.02 — earnings release, exhibit 99.1

[0001102624-11-000322:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-11-000322:8k_2_02:2]
exh99_1.htm

[0001102624-11-000322:8k_2_02:3]
Exhibit 99.1 PRESS RELEASE

[0001102624-11-000322:8k_2_02:4]
NETAPP ANNOUNCES RESULTS FOR FOURTH QUARTER AND FISCAL YEAR 2011

[0001102624-11-000322:8k_2_02:5]
Company Reports Q4 FY’11 Revenues of $1.428 Billion; Fiscal Year Revenues of $5.123 Billion

[0001102624-11-000322:8k_2_02:6]
Sunnyvale, Calif.—May 25, 2011—NetApp (NASDAQ: NTAP) today reported results for the fourth quarter and fiscal year 2011, which ended April 29, 2011. Revenues for the fourth quarter of fiscal year 2011 totaled $1.428 billion compared to revenues of $1.172 billion for the same period one year ago.

[0001102624-11-000322:8k_2_02:7]
For the fourth quarter of fiscal year 2011, GAAP net income was $160.6 million, or $0.40 per share1 compared to GAAP net income of $145.1 million, or $0.40 per share for the same period a year ago. Non-GAAP net income for the fourth quarter of fiscal year 2011 was $236.7 million, or $0.59 per share2, compared to non-GAAP net income of $183.1 million, or $0.50 per share for the same period a year ago.

[0001102624-11-000322:8k_2_02:8]
Revenues for fiscal year 2011 totaled $5.123 billion compared to revenues of $3.931 billion for fiscal year 2010. GAAP net income for fiscal year 2011 was $673.1 million, or $1.71 per share, compared to GAAP net income of $400.4 million, or $1.13 per share for fiscal year 2010. Non-GAAP net income for fiscal year 2011 totaled $865.7 million, or $2.20 per share, compared to non-GAAP net income of $533.0 million, or $1.51 per share for fiscal year 2010.

[0001102624-11-000322:8k_2_02:9]
“NetApp delivered 30% revenue growth, 38% growth in cash from operations and over $1B in non-GAAP operating profit during fiscal 2011. We achieved the largest market share gains in our history and closed a record number of million dollar deals, demonstrating our momentum in the market as enterprise customers increasingly choose NetApp as their vendor of choice for storage virtualization and cloud deployments,” said Tom Georgens, president and CEO. “Together with our partners we create unmatched IT efficiency and flexibility with innovative solutions that solve the biggest and hardest problems in accessing and protecting business-critical information.”

[0001102624-11-000322:8k_2_02:10]
In the fourth quarter of fiscal year 2011, NetApp adopted mandatory new accounting standards related to revenue recognition for transactions originating or materially modified in fiscal year 2011. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore the full year and previously reported quarterly results for fiscal 2011 have been adjusted to reflect the adoption of these new standards. An analysis of the impact of the new accounting standards can be found on page 3 of the Supplemental Commentary and the adjusted Statements of Operations for prior quarters can be found on page 14 of the Supplemental Commentary and on our website at investors.netapp.com.

[0001102624-11-000322:8k_2_02:11]
Outlook

[0001102624-11-000322:8k_2_02:12]
| ● | NetApp estimates revenue for the first quarter of fiscal year 2012 to be approximately $1.500 billion, plus or minus 3%, which equates to approximately 2% to 8% sequential revenue growth and approximately 26% to 34% year over year revenue growth. |

[0001102624-11-000322:8k_2_02:13]
| ● | NetApp estimates that first quarter fiscal year 2012 GAAP earnings per share will be approximately $0.31 to $0.36 per share. NetApp estimates that first quarter fiscal year 2012 non-GAAP earnings per share will be approximately $0.52 to $0.57 per share. |

[0001102624-11-000322:8k_2_02:14]
| ● | NetApp estimates that share count for the first quarter of fiscal year 2012 will increase to approximately 410 million shares, including an estimated 16 million shares from the company’s outstanding convertible notes3 and 9 million shares from outstanding warrants. Share count does not include the company’s outstanding note hedges that are expected to offset 80% of the dilution from the convertible notes at maturity or conversion. |

[0001102624-11-000322:8k_2_02:15]
| ● | The above guidance reflects the new accounting standards related to revenue recognition. |

[0001102624-11-000322:8k_2_02:16]
Business Highlights

[0001102624-11-000322:8k_2_02:17]
In its fourth quarter of fiscal year 2011, NetApp continued to demonstrate its commitment to providing customers and partners with the solutions and technologies that are foundational to their success. During the quarter, NetApp entered into a definitive agreement to purchase the Engenio external storage systems business from LSI Corporation to enable NetApp to expand its addressable market and generate greater revenue growth with a strategic storage platform intended to capitalize on new high-growth opportunities for big-bandwidth and high-performance applications. Additionally, NetApp continues to enable enterprises to make the transition to a flexible and shared IT infrastructure and once again received numerous awards honoring its product innovation, executive leadership, and culture. Highlights included the following:

[0001102624-11-000322:8k_2_02:18]
NetApp to Address Emerging, Fast-Growing Market Segments for Big-Bandwidth and High-Performance Applications

[0001102624-11-000322:8k_2_02:19]
| ● | The purchase of the Engenio external storage systems business provides NetApp with a storage platform that is complementary to its existing NetApp® Data ONTAP® platform and is targeted to address emerging customer needs around big-bandwidth and high-performance applications such as full-motion video and digital video surveillance. The purchase will help enable NetApp to capitalize on the expected growth within this emerging market and help it further diversify its channels to market through a proven, mature OEM business. |

[0001102624-11-000322:8k_2_02:20]
NetApp Enables Transition to a Shared IT Infrastructure

[0001102624-11-000322:8k_2_02:21]
| ● | NetApp helps Suncorp Group spark innovation on shared IT infrastructure. The Suncorp Group, a provider of diversified financial services and one of Australia’s largest companies, recently made a strategic bet on storage to fuel its growth and transformation as a company. With NetApp as its storage foundation, Suncorp migrated 80% of its entire IT environment to a shared infrastructure, creating a culture of innovation throughout the company and enabling it to scale rapidly. |

[0001102624-11-000322:8k_2_02:22]
| ● | NetApp enables leading service providers to deliver innovative cloud services. Expanding on its strategy to broaden and leverage its diverse pathways to reach customers, NetApp is collaborating with many of its leading service provider partners to deliver a wide range of innovative cloud services that help customers make the transition to a flexible and efficient shared IT infrastructure. These service providers are part of the industry’s first NetApp Partner Program for Service Providers, which helps partners increase their business and take advantage of the market shift to cloud services. |

[0001102624-11-000322:8k_2_02:23]
Milestones and Awards

[0001102624-11-000322:8k_2_02:24]
| ● | NetApp named one of the Best Places to Work around the globe. NetApp continued to gain recognition as a “best place to work,” ranking as the #2 best company to work for in Canada for a second consecutive year and #8 in Japan in the “Fewer than 250 Employees” category. Both honors are a testament to NetApp’s model company approach, strong culture, and talented employees. |

[0001102624-11-000322:8k_2_02:25]
| ● | NetApp gains impressive channel leadership recognition. NetApp was named a 2011 CRN Channel Champion in the Enterprise Network Storage category, amplifying the company’s focus on enabling its partners’ success. Additionally, Julie Parrish, senior vice president of Global Partner Sales; Todd Palmer, vice president of Americas Channels; and David Drahozal, director of Channel Sales for U.S. Public Sector, were named Channel Chiefs by Everything Channel’s CRN. |

[0001102624-11-000322:8k_2_02:26]
| ● | NetApp positioned in Leaders quadrant. Gartner, Inc. placed NetApp in the Leaders quadrant for midrange and high-end NAS solutions. Gartner asserted that vendors in the Leaders quadrant “have the highest scores in their ability to execute and completeness of vision.”4 |

[0001102624-11-000322:8k_2_02:27]
Webcast and Conference Call Information

[0001102624-11-000322:8k_2_02:28]
The NetApp fourth quarter and fiscal year 2011 results conference call will be broadcast live on the Internet at http://investors.netapp.com on Wednesday, May 25, 2011, at 2:00 p.m. Pacific time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4:00 p.m. Pacific time on our Web site.

[0001102624-11-000322:8k_2_02:29]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-11-000322:8k_2_02:30]
About NetApp

[0001102624-11-000322:8k_2_02:31]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-11-000322:8k_2_02:32]
NetApp, the NetApp logo, Go further, faster, and Data ONTAP are trademarks of NetApp, Inc. All other marks are the property of their respective owners and should be treated as such.

[0001102624-11-000322:8k_2_02:33]
| 1 | GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |
| 2 | Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation expenses, acquisition related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |
| 3 | 80% hedged on maturity or conversion of the convertible notes. |
| 4 | “Magic Quadrant for Midrange and High-End NAS Solutions” by Pushan Rinnen, Roger W. Cox, and Robert E. Passmore, Gartner, Inc. |

[0001102624-11-000322:8k_2_02:34]
NetApp Usage of Non-GAAP Financials

[0001102624-11-000322:8k_2_02:35]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation expenses, acquisition related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-11-000322:8k_2_02:36]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-11-000322:8k_2_02:37]
Adoption of New Accounting Standards

[0001102624-11-000322:8k_2_02:38]
In the fourth quarter of fiscal year 2011, NetApp adopted  Accounting Standards Update (“ASU”) No. 2009-13, and ASU No. 2009-14 related to revenue recognition for transactions originating or materially modified in fiscal year 2011. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore the full year and previously reported fiscal 2011 quarterly results have been adjusted to reflect the adoption of these new standards.

[0001102624-11-000322:8k_2_02:39]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,174.7 |  |  | $ | 3,724.0 |  |
| Accounts receivable, net |  |  | 742.6 |  |  |  | 471.5 |  |
| Inventories |  |  | 108.5 |  |  |  | 112.9 |  |
| Other current assets |  |  | 368.5 |  |  |  | 228.7 |  |
| Total current assets |  |  | 6,394.3 |  |  |  | 4,537.1 |  |
| Property and equipment, net |  |  | 911.6 |  |  |  | 804.4 |  |
| Goodwill and other intangible assets, net |  |  | 813.3 |  |  |  | 706.1 |  |
| Long-term investments and restricted cash |  |  | 69.2 |  |  |  | 72.8 |  |
| Other non-current assets |  |  | 310.4 |  |  |  | 374.0 |  |
|  |  | $ | 8,498.8 |  |  | $ | 6,494.4 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 232.8 |  |  | $ | 184.6 |  |
| Accrued compensation and other current liabilities |  |  | 763.0 |  |  |  | 591.3 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,150.4 |  |  |  | - |  |
| Short-term deferred revenue |  |  | 1,226.6 |  |  |  | 1,135.1 |  |
| Total current liabilities |  |  | 3,372.8 |  |  |  | 1,911.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 1,101.5 |  |
| Other long-term liabilities |  |  | 192.9 |  |  |  | 171.9 |  |
| Long-term deferred revenue |  |  | 1,088.3 |  |  |  | 779.5 |  |
|  |  |  | 4,654.0 |  |  |  | 3,963.9 |  |
| Stockholders' equity |  |  | 3,844.8 |  |  |  | 2,530.5 |  |
|  |  | $ | 8,498.8 |  |  | $ | 6,494.4 |  |
| (1) In the fourth quarter of fiscal year 2011, NetApp adopted new revenue recognition standards. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore, the full year and previously reported quarterly results for fiscal year 2011 have been adjusted to reflect the adoption of these new standards. |  |

[0001102624-11-000322:8k_2_02:40]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 960.5 |  |  | $ | 758.8 |  |  | $ | 3,367.1 |  |  | $ | 2,381.1 |  |
| Software entitlements and maintenance |  |  | 187.0 |  |  |  | 173.8 |  |  |  | 720.6 |  |  |  | 679.8 |  |
| Service |  |  | 280.8 |  |  |  | 239.2 |  |  |  | 1,034.9 |  |  |  | 870.5 |  |
| Net revenues |  |  | 1,428.3 |  |  |  | 1,171.8 |  |  |  | 5,122.6 |  |  |  | 3,931.4 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 379.1 |  |  |  | 310.9 |  |  |  | 1,342.0 |  |  |  | 976.4 |  |
| Cost of software entitlements and maintenance |  |  | 4.8 |  |  |  | 3.1 |  |  |  | 15.7 |  |  |  | 12.3 |  |
| Cost of service |  |  | 116.2 |  |  |  | 109.3 |  |  |  | 436.2 |  |  |  | 423.5 |  |
| Total cost of revenues |  |  | 500.1 |  |  |  | 423.3 |  |  |  | 1,793.9 |  |  |  | 1,412.2 |  |
| Gross profit |  |  | 928.2 |  |  |  | 748.5 |  |  |  | 3,328.7 |  |  |  | 2,519.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 462.6 |  |  |  | 366.7 |  |  |  | 1,597.0 |  |  |  | 1,293.7 |  |
| Research and development |  |  | 176.5 |  |  |  | 143.7 |  |  |  | 648.6 |  |  |  | 535.7 |  |
| General and administrative |  |  | 69.0 |  |  |  | 64.2 |  |  |  | 251.3 |  |  |  | 238.8 |  |
| Restructuring and other charges |  |  | 2.4 |  |  |  | (0.2 | ) |  |  | 1.8 |  |  |  | 2.5 |  |
| Acquisition related (income) expense, net |  |  | 4.8 |  |  |  | 1.2 |  |  |  | 5.7 |  |  |  | (39.9 | ) |
| Total operating expenses |  |  | 715.3 |  |  |  | 575.6 |  |  |  | 2,504.4 |  |  |  | 2,030.8 |  |
| Income from operations |  |  | 212.9 |  |  |  | 172.9 |  |  |  | 824.3 |  |  |  | 488.4 |  |
| Other expense, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.3 |  |  |  | 8.1 |  |  |  | 39.9 |  |  |  | 31.2 |  |
| Interest expense |  |  | (19.7 | ) |  |  | (18.8 | ) |  |  | (75.9 | ) |  |  | (74.1 | ) |
| Other income, net |  |  | 4.6 |  |  |  | 1.7 |  |  |  | 5.8 |  |  |  | 1.5 |  |
| Total other expense, net |  |  | (4.8 | ) |  |  | (9.0 | ) |  |  | (30.2 | ) |  |  | (41.4 | ) |
| Income before income taxes |  |  | 208.1 |  |  |  | 163.9 |  |  |  | 794.1 |  |  |  | 447.0 |  |
| Provision for income taxes |  |  | 47.5 |  |  |  | 18.8 |  |  |  | 121.0 |  |  |  | 46.6 |  |
| Net income |  | $ | 160.6 |  |  | $ | 145.1 |  |  | $ | 673.1 |  |  | $ | 400.4 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.42 |  |  | $ | 1.87 |  |  | $ | 1.18 |  |
| Diluted |  | $ | 0.40 |  |  | $ | 0.40 |  |  | $ | 1.71 |  |  | $ | 1.13 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 368.1 |  |  |  | 346.1 |  |  |  | 360.9 |  |  |  | 339.6 |  |
| Diluted |  |  | 403.6 |  |  |  | 364.5 |  |  |  | 393.7 |  |  |  | 353.2 |  |
| (1) In the fourth quarter of fiscal year 2011, NetApp adopted new revenue recognition standards. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore, the full year and previously reported quarterly results for fiscal year 2011 have been adjusted to reflect the adoption of these new standards. Our net revenues for the three months and year ended April 29, 2011 were higher by $48.2 million and $129.2 million, respectively, as a result of adoption of these new standards. |  |

[0001102624-11-000322:8k_2_02:41]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |
| Cash Flows from Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 160.6 |  |  | $ | 145.1 |  |  | $ | 673.1 |  |  | $ | 400.4 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 42.3 |  |  |  | 40.0 |  |  |  | 165.6 |  |  |  | 166.0 |  |
| Stock-based compensation |  |  | 48.2 |  |  |  | 37.8 |  |  |  | 175.2 |  |  |  | 159.8 |  |
| Accretion of discount and issue costs on notes |  |  | 13.9 |  |  |  | 13.1 |  |  |  | 53.1 |  |  |  | 50.8 |  |
| Unrealized losses on derivative activities |  |  | (2.5 | ) |  |  | - |  |  |  | 9.9 |  |  |  | - |  |
| Tax benefit from stock-based compensation |  |  | 53.6 |  |  |  | 1.8 |  |  |  | 128.5 |  |  |  | (0.9 | ) |
| Excess tax benefit from stock-based compensation |  |  | (64.4 | ) |  |  | (7.6 | ) |  |  | (127.7 | ) |  |  | (8.6 | ) |
| Other, net |  |  | 17.2 |  |  |  | 4.1 |  |  |  | (21.4 | ) |  |  | (1.6 | ) |
| Changes in assets and liabilities, net of acquisition of business: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (185.2 | ) |  |  | (13.4 | ) |  |  | (262.7 | ) |  |  | (21.3 | ) |
| Inventories |  |  | (14.4 | ) |  |  | (41.2 | ) |  |  | 4.4 |  |  |  | (52.1 | ) |
| Accounts payable |  |  | 41.0 |  |  |  | 43.1 |  |  |  | 38.7 |  |  |  | 42.7 |  |
| Accrued compensation and other current liabilities |  |  | 159.4 |  |  |  | 112.4 |  |  |  | 118.8 |  |  |  | 53.2 |  |
| Deferred revenue |  |  | 231.4 |  |  |  | 116.6 |  |  |  | 382.9 |  |  |  | 176.7 |  |
| Changes in other operating assets and liabilities, net |  |  | (42.3 | ) |  |  | 22.8 |  |  |  | 7.9 |  |  |  | 9.9 |  |
| Net cash provided by operating activities |  |  | 458.8 |  |  |  | 474.6 |  |  |  | 1,346.3 |  |  |  | 975.0 |  |
| Cash Flows from Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases and redemptions of investments, net |  |  | 417.0 |  |  |  | (768.9 | ) |  |  | (418.5 | ) |  |  | (860.3 | ) |
| Purchases of property and equipment |  |  | (72.9 | ) |  |  | (38.4 | ) |  |  | (222.7 | ) |  |  | (135.6 | ) |
| Acquisition of business, net of cash acquired |  |  | (61.6 | ) |  |  | - |  |  |  | (136.5 | ) |  |  | - |  |
| Other investing activities, net |  |  | (0.3 | ) |  |  | 4.1 |  |  |  | 0.5 |  |  |  | 8.2 |  |
| Net cash provided by (used in) investing activities |  |  | 282.2 |  |  |  | (803.2 | ) |  |  | (777.2 | ) |  |  | (987.7 | ) |
| Cash Flows from Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 12.2 |  |  |  | 40.4 |  |  |  | 324.2 |  |  |  | 197.1 |  |
| Excess tax benefit from stock-based compensation |  |  | 64.4 |  |  |  | 7.6 |  |  |  | 127.7 |  |  |  | 8.6 |  |
| Settlement of note hedge |  |  | - |  |  |  | 14.2 |  |  |  | - |  |  |  | 14.2 |  |
| Other financing activities |  |  | (1.4 | ) |  |  | - |  |  |  | (1.0 | ) |  |  | - |  |
| Net cash provided by financing activities |  |  | 75.2 |  |  |  | 62.2 |  |  |  | 450.9 |  |  |  | 219.9 |  |
| Effect of Exchange Rate Changes on Cash and Cash Equivalents |  |  | 21.7 |  |  |  | (4.4 | ) |  |  | 32.3 |  |  |  | 3.6 |  |
| Net Increase (Decrease) in Cash and Cash Equivalents |  |  | 837.9 |  |  |  | (270.8 | ) |  |  | 1,052.3 |  |  |  | 210.8 |  |
| Cash and Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,919.4 |  |  |  | 1,975.8 |  |  |  | 1,705.0 |  |  |  | 1,494.2 |  |
| End of period |  | $ | 2,757.3 |  |  | $ | 1,705.0 |  |  | $ | 2,757.3 |  |  | $ | 1,705.0 |  |
| (1) In the fourth quarter of fiscal year 2011, NetApp adopted new revenue recognition standards. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore, the full year and previously reported quarterly results for fiscal year 2011 have been adjusted to reflect the adoption of these new standards. |  |

[0001102624-11-000322:8k_2_02:42]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |  | April 29, 2011 (1) |  |  | April 30, 2010 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 160.6 |  |  | $ | 145.1 |  |  | $ | 673.1 |  |  | $ | 400.4 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 4.3 |  |  |  | 4.9 |  |  |  | 17.7 |  |  |  | 20.5 |  |
| Stock-based compensation expenses |  |  | 48.4 |  |  |  | 37.8 |  |  |  | 175.2 |  |  |  | 159.8 |  |
| Restructuring and other charges |  |  | 2.4 |  |  |  | (0.2 | ) |  |  | 1.8 |  |  |  | 2.5 |  |
| Acquisition related (income) expense, net |  |  | 4.8 |  |  |  | 1.2 |  |  |  | 5.7 |  |  |  | (39.9 | ) |
| Non-cash interest expense |  |  | 13.9 |  |  |  | 13.1 |  |  |  | 53.1 |  |  |  | 50.8 |  |
| Gain on investments |  |  | (0.9 | ) |  |  | (1.2 | ) |  |  | (3.4 | ) |  |  | (4.7 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 3.2 |  |  |  | (17.6 | ) |  |  | (57.5 | ) |  |  | (56.4 | ) |
| NON-GAAP NET INCOME |  | $ | 236.7 |  |  | $ | 183.1 |  |  | $ | 865.7 |  |  | $ | 533.0 |  |
| NET INCOME PER SHARE |  | $ | 0.398 |  |  | $ | 0.398 |  |  | $ | 1.710 |  |  | $ | 1.134 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.011 |  |  |  | 0.013 |  |  |  | 0.045 |  |  |  | 0.058 |  |
| Stock-based compensation expenses |  |  | 0.120 |  |  |  | 0.104 |  |  |  | 0.445 |  |  |  | 0.452 |  |
| Restructuring and other charges |  |  | 0.006 |  |  |  | (0.001 | ) |  |  | 0.005 |  |  |  | 0.007 |  |
| Acquisition related (income) expense, net |  |  | 0.012 |  |  |  | 0.003 |  |  |  | 0.014 |  |  |  | (0.113 | ) |
| Non-cash interest expense |  |  | 0.034 |  |  |  | 0.036 |  |  |  | 0.135 |  |  |  | 0.144 |  |
| Gain on investments |  |  | (0.002 | ) |  |  | (0.003 | ) |  |  | (0.009 | ) |  |  | (0.013 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.008 |  |  |  | (0.048 | ) |  |  | (0.146 | ) |  |  | (0.160 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.586 |  |  | $ | 0.502 |  |  | $ | 2.199 |  |  | $ | 1.509 |  |
| (1) In the fourth quarter of fiscal year 2011, NetApp adopted new revenue recognition standards. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore, the full year and previously reported quarterly results for fiscal year 2011 have been adjusted to reflect the adoption of these new standards. |  |

[0001102624-11-000322:8k_2_02:43]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended April 29, 2011 (1) |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation Expenses |  |  | Restructuring and Other Charges |  |  | Acquisition related (income) expense, net |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 3.1 |  |  | $ | 1.0 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 4.1 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.8 |  |
| Sales and marketing expense |  |  | 1.1 |  |  |  | 22.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 23.5 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 12.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.0 |  |
| General and administrative expense |  |  | - |  |  |  | 8.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 2.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 2.4 |  |
| Acquisition related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4.8 |  |  |  | - |  |  |  | - |  |  |  | 4.8 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.9 |  |  |  | - |  |  |  | 13.9 |  |
| Other income (expenses), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.9 | ) |  |  | (0.9 | ) |
| Effect on income before income taxes |  | $ | 4.3 |  |  | $ | 48.4 |  |  | $ | 2.4 |  |  | $ | 4.8 |  |  | $ | 13.9 |  |  | $ | (0.9 | ) |  | $ | 72.9 |  |
|  |  | Year Ended April 29, 2011 (1) |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation Expenses |  |  | Restructuring and Other Charges |  |  | Acquisition related (income) expense, net |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.3 |  |  | $ | 3.6 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 16.9 |  |
| Cost of service revenues |  |  | - |  |  |  | 14.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.4 |  |
| Sales and marketing expense |  |  | 4.3 |  |  |  | 81.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 85.8 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 44.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 44.6 |  |
| General and administrative expense |  |  | - |  |  |  | 31.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 31.2 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 1.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.8 |  |
| Acquisition related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5.7 |  |  |  | - |  |  |  | - |  |  |  | 5.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 53.1 |  |  |  | - |  |  |  | 53.1 |  |
| Other income (expenses), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (3.4 | ) |  |  | (3.4 | ) |
| Effect on income before income taxes |  | $ | 17.7 |  |  | $ | 175.2 |  |  | $ | 1.8 |  |  | $ | 5.7 |  |  | $ | 53.1 |  |  | $ | (3.4 | ) |  | $ | 250.1 |  |

[0001102624-11-000322:8k_2_02:44]
|  |  | Three Months Ended April 30, 2010 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation Expenses |  |  | Restructuring and Other Charges |  |  | Acquisition related (income) expense, net |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 4.1 |  |  | $ | 1.3 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 5.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.5 |  |
| Sales and marketing expense |  |  | 0.8 |  |  |  | 16.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 17.7 |  |
| Research and development expense |  |  | - |  |  |  | 9.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 9.0 |  |
| General and administrative expense |  |  | - |  |  |  | 7.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.1 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (0.2 | ) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.2 | ) |
| Acquisition related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.2 |  |  |  | - |  |  |  | - |  |  |  | 1.2 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.1 |  |  |  | - |  |  |  | 13.1 |  |
| Other income (expenses), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1.2 | ) |  |  | (1.2 | ) |
| Effect on income before income taxes |  | $ | 4.9 |  |  | $ | 37.8 |  |  | $ | (0.2 | ) |  | $ | 1.2 |  |  | $ | 13.1 |  |  | $ | (1.2 | ) |  | $ | 55.6 |  |
|  |  | Year Ended April 30, 2010 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation Expenses |  |  | Restructuring and Other Charges |  |  | Acquisition related (income) expense, net |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 17.1 |  |  | $ | 4.0 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 21.1 |  |
| Cost of service revenues |  |  | - |  |  |  | 14.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.3 |  |
| Sales and marketing expense |  |  | 3.4 |  |  |  | 73.7 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 77.1 |  |
| Research and development expense |  |  | - |  |  |  | 38.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 38.5 |  |
| General and administrative expense |  |  | - |  |  |  | 29.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 29.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 2.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 2.5 |  |
| Acquisition related income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (39.9 | ) |  |  | - |  |  |  | - |  |  |  | (39.9 | ) |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 50.8 |  |  |  | - |  |  |  | 50.8 |  |
| Other income (expenses), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (4.7 | ) |  |  | (4.7 | ) |
| Effect on income before income taxes |  | $ | 20.5 |  |  | $ | 159.8 |  |  | $ | 2.5 |  |  | $ | (39.9 | ) |  | $ | 50.8 |  |  | $ | (4.7 | ) |  | $ | 189.0 |  |
| (1) In the fourth quarter of fiscal year 2011, NetApp adopted new revenue recognition standards. We implemented these standards retrospectively to the beginning of fiscal year 2011; therefore, the full year and previously reported quarterly results for fiscal year 2011 have been adjusted to reflect the adoption of these new standards. |  |

[0001102624-11-000322:8k_2_02:45]
|  | NETAPP, INC. |  |
|  | RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |  |
|  | EXPRESSED AS EARNINGS PER SHARE |  |
|  | FIRST QUARTER 2012 |  |
|  | (Unaudited) |  |
|  | First Quarter |  |
|  | 2012 |  |
| Non-GAAP Guidance | $0.52 - $0.57 |  |
| Adjustments of Specific Items to |  |  |
| Net Income Per Share for the First |  |  |
| Quarter 2012: |  |  |
| Amortization of intangible assets | (0.04) |  |
| Stock based compensation expense | (0.13) |  |
| Acquisition-related expense | (0.04) |  |
| Restructuring & other charges | (0.02) |  |
| Non cash interest expense | (0.03) |  |
| Income tax effect | 0.05 |  |
| Total Adjustments | (0.21) |  |
| GAAP Guidance -Net Income Per Share | $0.31 - $0.36 |  |

[0001102624-11-000322:8k_2_02:46]
Press Contact:

[0001102624-11-000322:8k_2_02:47]
Ryan Lowry

[0001102624-11-000322:8k_2_02:48]
NetApp

[0001102624-11-000322:8k_2_02:49]
(408) 822-7544

[0001102624-11-000322:8k_2_02:50]
ryanl@netapp.com

[0001102624-11-000322:8k_2_02:51]
Investor Contacts:

[0001102624-11-000322:8k_2_02:52]
Shauna O'Boyle

[0001102624-11-000322:8k_2_02:53]
NetApp

[0001102624-11-000322:8k_2_02:54]
(408) 822-7655

[0001102624-11-000322:8k_2_02:55]
oboyle@netapp.com
