# NTAP note change history — 0001193125-10-274568 → 0001193125-11-056223


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-03-04):
[0001193125-11-056223:note_history:1]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of January 28, 2011 totaled $257.7 million.
  (was, 2010-12-06, similarity 0.9646):
[0001193125-10-274568:note_history:1]
Future annual minimum lease payments under all noncancelable facilities and equipment operating leases with an initial term in excess of one year as of October 29, 2010 totaled $254.3 million.

- changed (2011-03-04):
[0001193125-11-056223:note_history:2]
In the normal course of business we make commitments to our third party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $165 million in non-cancelable purchase commitments with our contract manufacturers as of January 28, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of January 28, 2011 and April 30, 2010, such liability amounted to $7.2 million and $3.8 million, respectively, and is included in other current liabilities in the consolidated balance sheets.
  (was, 2010-12-06, similarity 0.8684):
[0001193125-10-274568:note_history:2]
In the normal course of business we make commitments to our third party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components for which we believe it is probable that they will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $126.2 million in non-cancelable purchase commitments with our contract manufacturers as of October 29, 2010. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of October 29, 2010 and April 30, 2010, such liability amounted to $3.5 million and $3.8 million, respectively, and is included in other current liabilities in the consolidated balance sheets.

- changed (2011-03-04):
[0001193125-11-056223:note_history:3]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $33.4 million in capital purchase commitments and $317.1 million in other purchase commitments as of January 28, 2011.
  (was, 2010-12-06, similarity 0.9797):
[0001193125-10-274568:note_history:3]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $30.1 million in capital purchase commitments and $337.1 million in other purchase commitments as of October 29, 2010.

- changed (2011-03-04):
[0001193125-11-056223:note_history:4]
We provide customers a warranty on software of ninety days and a warranty on hardware of three years. The following table summarizes our warranty reserves (in millions):
  (was, 2010-12-06, similarity 0.9075):
[0001193125-10-274568:note_history:4]
We provide customers a warranty on software of ninety days and a warranty on hardware of three years. Following is an analysis of our warranty reserves (in millions):

- changed (2011-03-04):
[0001193125-11-056223:note_history:5]
|  |  | Nine Months Ended |  |
|  |  | January 28,2011 |  |  | January 29,2010 |  |
| Beginning balance |  | $ | 31.9 |  |  | $ | 42.3 |  |
| Expense accrued during the period |  |  | 20.9 |  |  |  | 12.9 |  |
| Warranty costs incurred |  |  | (17.1 | ) |  |  | (20.5 | ) |
| Ending balance |  | $ | 35.7 |  |  | $ | 34.7 |  |
  (was, 2010-12-06, similarity 0.6903):
[0001193125-10-274568:note_history:5]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29,2010 |  |  | October 30,2009 |  |  | October 29,2010 |  |  | October 30,2009 |  |
| Beginning balance |  | $ | 32.1 |  |  | $ | 40.3 |  |  | $ | 31.9 |  |  | $ | 42.3 |  |
| Expense accrued during the period |  |  | 7.0 |  |  |  | 2.3 |  |  |  | 12.9 |  |  |  | 7.6 |  |
| Warranty costs incurred |  |  | (5.6 | ) |  |  | (6.7 | ) |  |  | (11.3 | ) |  |  | (14.0 | ) |
| Ending balance |  | $ | 33.5 |  |  | $ | 35.9 |  |  | $ | 33.5 |  |  | $ | 35.9 |  |

- changed (2011-03-04):
[0001193125-11-056223:note_history:6]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of January 28, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $75.6 million, and the related deferred revenue and cost of revenues totaled approximately $76.8 million and $8.3 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.
  (was, 2010-12-06, similarity 0.9942):
[0001193125-10-274568:note_history:6]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of October 29, 2010, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $75.8 million; and the related deferred revenue and cost of revenues totaled approximately $78.7 million and $9.1 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- changed (2011-03-04):
[0001193125-11-056223:note_history:7]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of January 28, 2011, as the outcome of these legal matters is currently not determinable.
  (was, 2010-12-06, similarity 0.7198):
[0001193125-10-274568:note_history:7]
We are subject to various legal proceedings and claims which may arise in the normal course of business.No accrual has been recorded as of October 29, 2010, as the outcome of these legal matters is currently not determinable.

- added (2011-03-04):
[0001193125-11-056223:note_history:8]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named 15 current and former directors of the Company as defendants. On February 3, 2011, in response to motions to dismiss that we and the individual defendants filed, the plaintiff filed an amended complaint. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that the Company complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in the Company incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional unspecified damages. The Company and the individual defendants will file motions to dismiss the amended complaint in early March 2011.

- removed (2011-03-04):
[0001193125-10-274568:note_history:9]
On September 5, 2007, we filed a patent infringement lawsuit in the Eastern District of Texas seeking compensatory damages and a permanent injunction against Sun Microsystems (Sun). On October 25, 2007, Sun filed a counter claim against us in the Eastern District of Texas seeking compensatory damages and a permanent injunction. On October 29, 2007, Sun filed a second lawsuit against us in the Northern District of California asserting additional patents against us. The Texas court granted a joint motion to transfer the Texas lawsuit to the Northern District of California on November 26, 2007. On March 26, 2008, Sun filed a third lawsuit in federal court that extends the patent infringement charges to storage management technology we acquired in January 2008. In January 2010, Oracle Corporation acquired Sun. In September 2010, the lawsuits were dismissed without prejudice.

- removed (2011-03-04):
[0001193125-10-274568:note_history:10]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit names 15 current and former NetApp directors as defendants, alleging breach of fiduciary duty and wasting of corporate assets. The lawsuit alleges that the defendants failed to implement and oversee internal controls to ensure that we complied with legal requirements in its General Services Administration (GSA) contracting activities, and that this purported failure of oversight required us to incur significant costs in defending and settling a dispute with the United States of America regarding these past GSA contracting activities. The complaint seeks disgorgement of salaries and other compensation from the defendants and seeks additional unspecified damages. We and the defendants have filed demurrers seeking to have the lawsuit dismissed.


## ntap:UseOfEstimatesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-03-04):
[0001193125-11-056223:note_history:11]
Use of Estimates — The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ from those estimates.
  (was, 2010-12-06, similarity 0.9994):
[0001193125-10-274568:note_history:11]
Use of Estimates — The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-03-04):
[0001193125-11-056223:note_history:12]
There have been no significant changes in our significant accounting policies for the nine month period ended January 28, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 30, 2010.
  (was, 2010-12-06, similarity 0.9581):
[0001193125-10-274568:note_history:12]
There have been no significant changes in our significant accounting policies for the six month period ended October 29, 2010, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 30, 2010.

- changed (2011-03-04):
[0001193125-11-056223:note_history:13]
|  | (iii) | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method; and |
  (was, 2010-12-06, similarity 0.9965):
[0001193125-10-274568:note_history:13]
|  | (iii) | eliminate the use of the residual method and requires an entity to allocate revenue using the relative selling price method; and |

- changed (2011-03-04):
[0001193125-11-056223:note_history:14]
In addition, in October 2009, the FASB amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. The revised revenue recognition accounting standards are effective for revenue arrangements entered into or materially modified in fiscal years beginning on or after June 15, 2010 and shall be applied on a prospective basis. Earlier application is permitted. We are required to adopt this standard no later than the beginning of fiscal 2012, which begins on April 30, 2011. We are assessing the impact of the new accounting standards on our financial position and results of operations.
  (was, 2010-12-06, similarity 0.9905):
[0001193125-10-274568:note_history:14]
In addition, in October 2009, the FASB amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. The revised revenue recognition accounting standards are effective for revenue arrangements entered into or materially modified in fiscal years beginning on or after June 15, 2010 and shall be applied on a prospective basis. Earlier application is permitted. We are required to adopt this standard at the beginning of fiscal 2012, which begins on April 30, 2011. We are assessing the impact of the new accounting standards on our financial position and results of operations.

- changed (2011-03-04):
[0001193125-11-056223:note_history:15]
Use of Estimates — The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ from those estimates.
  (was, 2010-12-06, similarity 0.9994):
[0001193125-10-274568:note_history:15]
Use of Estimates — The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.

- removed (2011-03-04):
[0001193125-10-274568:note_history:16]
In July 2010, the FASB issued an accounting standard that is intended to improve the disclosures that an entity provides about the credit quality of its financing receivables and the related allowance for credit losses. As a result of these amendments, an entity is required to disaggregate by portfolio segment or class certain existing disclosures and provide certain new disclosures about its financing receivables and related allowance for credit losses. The disclosures as of the end of a reporting period are effective for interim and annual reporting periods ending on or after December 15, 2010. We do not expect the new standard to have a material impact on our financial statements.


## ntap:ContractualMaturitiesOfDebtInvestmentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-03-04):
[0001193125-11-056223:note_history:17]
| Debt Investment Maturities |  | Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 912.3 |  |  | $ | 914.8 |  |
| Due in one through five years |  |  | 1,961.8 |  |  |  | 1,966.4 |  |
| Due in five through ten years |  |  | 0.0 |  |  |  | 0.0 |  |
| Due after ten years* |  |  | 69.6 |  |  |  | 65.1 |  |
|  |  | $ | 2,943.7 |  |  | $ | 2,946.3 |  |
  (was, 2010-12-06, similarity 0.9983):
[0001193125-10-274568:note_history:17]
| Debt Investment Maturities |  | Cost |  |  | FairValue |  |
| Due in one year or less |  | $ | 1,131.7 |  |  | $ | 1,133.2 |  |
| Due in one through five years |  |  | 1,899.6 |  |  |  | 1,911.9 |  |
| Due in five through ten years |  |  | 0.0 |  |  |  | 0.0 |  |
| Due after ten years* |  |  | 70.2 |  |  |  | 66.2 |  |
|  |  | $ | 3,101.5 |  |  | $ | 3,111.3 |  |


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2011-03-04):
[0001193125-11-056223:note_history:18]
|  |  | January 28, 2011 |  |  | April 30, 2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 5.5 |  |  | $ | 0.0 |  |
| Non-current portion of other long-term financing arrangements |  |  | 7.4 |  |  |  | 0.0 |  |
|  |  | $ | 12.9 |  |  | $ | 0.0 |  |

- removed (2011-03-04):
[0001193125-10-274568:note_history:19]
|  |  | October 29, 2010 |  |  | April 30, 2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 4.1 |  |  | $ | 0.0 |  |
| Non-current portion of long-term financing arrangements |  |  | 6.5 |  |  |  | 0.0 |  |
|  |  | $ | 10.6 |  |  | $ | 0.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-03-04):
[0001193125-11-056223:note_history:20]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified in the indenture governing the Notes, based on an initial conversion rate of approximately 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes. For at least 20 trading days during the 30 consecutive trading days ended December 31, 2010, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the notes are convertible at the holder's option through March 31, 2011. Upon conversion of any Notes, we will deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock.
  (was, 2010-12-06, similarity 0.9919):
[0001193125-10-274568:note_history:20]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified in the indenture governing the Notes, based on an initial conversion rate of approximately 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes. For at least 20 trading days during the 30 consecutive trading days ended September 30, 2010, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the notes are convertible at the holder's option through December 31, 2010. Upon conversion of any Notes, we will deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock.

- added (2011-03-04):
[0001193125-11-056223:note_history:21]
As of January 28, 2011, we had not issued any shares related to the Notes. Based on the closing price of our common stock of $54.03 on January 28, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $911.6 million.

- changed (2011-03-04):
[0001193125-11-056223:note_history:22]
|  |  | January 28,2011 |  |  | April 30,2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (127.3 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,137.7 |  |  | $ | 1,101.5 |  |
  (was, 2010-12-06, similarity 0.9559):
[0001193125-10-274568:note_history:22]
|  |  | October 29, 2010 |  |  | April 30, 2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (139.6 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,125.4 |  |  | $ | 1,101.5 |  |

- changed (2011-03-04):
[0001193125-11-056223:note_history:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2011 |  |  | January 29, 2010 |  |  | January 28, 2011 |  |  | January 29, 2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.9 |  |
| Amortization of debt discount |  |  | 12.2 |  |  |  | 11.4 |  |  |  | 36.1 |  |  |  | 34.8 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 3.1 |  |  |  | 3.0 |  |
| Total interest expense recognized |  | $ | 18.8 |  |  | $ | 17.9 |  |  | $ | 55.7 |  |  | $ | 54.7 |  |
  (was, 2010-12-06, similarity 0.8568):
[0001193125-10-274568:note_history:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2010 |  |  | October 30, 2009 |  |  | October 29, 2010 |  |  | October 30, 2009 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.4 |  |
| Amortization of debt discount |  |  | 12.0 |  |  |  | 11.2 |  |  |  | 23.9 |  |  |  | 23.3 |  |
| Amortization of issuance costs |  |  | 1.0 |  |  |  | 1.0 |  |  |  | 2.0 |  |  |  | 2.0 |  |
| Total interest expense recognized |  | $ | 18.5 |  |  | $ | 17.7 |  |  | $ | 36.9 |  |  | $ | 36.7 |  |

- changed (2011-03-04):
[0001193125-11-056223:note_history:24]
The following table reflects the remaining debt discount and issuance cost as of January 28, 2011 (in millions):
  (was, 2010-12-06, similarity 0.9439):
[0001193125-10-274568:note_history:24]
The following table reflects the remaining debt discount and issuance cost as of October 29, 2010 (in millions):

- changed (2011-03-04):
[0001193125-11-056223:note_history:25]
|  | • |  | Note Hedges. As of January 28, 2011 and April 30, 2010, we have transactions with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |
  (was, 2010-12-06, similarity 0.8143):
[0001193125-10-274568:note_history:25]
|  | • |  | Note Hedges. As of October 29, 2010 and April 30, 2010, we have transactions with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. |

- changed (2011-03-04):
[0001193125-11-056223:note_history:26]
|  | • |  | Warrants. As of January 28, 2011 and April 30, 2010, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |
  (was, 2010-12-06, similarity 0.9853):
[0001193125-10-274568:note_history:26]
|  | • |  | Warrants. As of October 29, 2010 and April 30, 2010, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

- changed (2011-03-04):
[0001193125-11-056223:note_history:27]
As of January 28, 2011, we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.
  (was, 2010-12-06, similarity 0.9721):
[0001193125-10-274568:note_history:27]
As of October 29, 2010 we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

- added (2011-03-04):
[0001193125-11-056223:note_history:28]
As of January 28, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $2.3 billion, or 179% of the face value of the Notes, based upon quoted market information.

- added (2011-03-04):
[0001193125-11-056223:note_history:29]
|  |  | January 28, 2011 |  |  | April 30, 2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 5.5 |  |  | $ | 0.0 |  |
| Non-current portion of other long-term financing arrangements |  |  | 7.4 |  |  |  | 0.0 |  |
|  |  | $ | 12.9 |  |  | $ | 0.0 |  |

- removed (2011-03-04):
[0001193125-10-274568:note_history:30]
As of October 29, 2010, we had not issued any shares related to the Notes. Based on the closing price of our common stock of $53.25 on October 29, 2010, the if-converted value of our Notes exceeded their principal amount by approximately $850.0 million.

- removed (2011-03-04):
[0001193125-10-274568:note_history:31]
As of October 29, 2010, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $2.2 billion, or 174% of the face value of the Notes, based upon quoted market information.

- removed (2011-03-04):
[0001193125-10-274568:note_history:32]
|  |  | October 29, 2010 |  |  | April 30, 2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 4.1 |  |  | $ | 0.0 |  |
| Non-current portion of long-term financing arrangements |  |  | 6.5 |  |  |  | 0.0 |  |
|  |  | $ | 10.6 |  |  | $ | 0.0 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-03-04):
[0001193125-11-056223:note_history:33]
|  |  | January 28,2011 |  |  | April 30,2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (127.3 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,137.7 |  |  | $ | 1,101.5 |  |
  (was, 2010-12-06, similarity 0.9559):
[0001193125-10-274568:note_history:33]
|  |  | October 29, 2010 |  |  | April 30, 2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (139.6 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,125.4 |  |  | $ | 1,101.5 |  |


## us-gaap:ScheduleOfSubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2011-03-04):
[0001193125-11-056223:note_history:34]
16. Subsequent Event

- added (2011-03-04):
[0001193125-11-056223:note_history:35]
On January 31, 2011, we completed the acquisition of Akorri Networks, Inc., a privately held company headquartered in Massachusetts, for approximately $60 million in cash. Akorri is a provider of data center management software focused on performance and capacity analytics for virtualized, shared information technology infrastructures. As of January 28, 2011, we had incurred $0.6 million in related expenses which are included in acquisition related income, net, in our condensed consolidated statements of operations.
