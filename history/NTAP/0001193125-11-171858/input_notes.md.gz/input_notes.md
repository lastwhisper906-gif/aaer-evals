# NTAP notes — 0001193125-11-171858


## ntap:AccountsReceivableFromSignificantCustomersTextBlock

[0001193125-11-171858:notes:1]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Arrow Electronics, Inc. |  | $ | 101.4 |  |  | $ | 48.7 |  |
| Avnet, Inc. |  | $ | 107.5 |  |  | $ | 29.1 |  |


## ntap:AmortizationFiniteLivedIntangibleAssetsTextBlock

[0001193125-11-171858:notes:2]
|  |  | Year Ended |  |  | Statements of OperationsClassifications |  |
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |  | April 24, 2009 |  |  |
| Existing technology |  | $ | 13.3 |  |  | $ | 17.2 |  |  | $ | 25.0 |  |  |  | Cost of product revenues |  |
| Trademarks and tradenames |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 1.1 |  |  |  | Sales and marketing |  |
| Customer contracts/relationships |  |  | 3.0 |  |  |  | 2.4 |  |  |  | 3.3 |  |  |  | Sales and marketing |  |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | Sales and marketing/R&D |  |
|  |  | $ | 17.7 |  |  | $ | 20.6 |  |  | $ | 29.4 |  |  |  |  |  |


## ntap:AmountContributedUnder401KPlansTableTextBlock

[0001193125-11-171858:notes:3]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| 401(k) contributions |  | $ | 15.6 |  |  | $ | 9.2 |  |  | $ | 13.6 |  |


## ntap:AssetsByGeographicAreasTextBlock

[0001193125-11-171858:notes:4]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| United States |  | $ | 840.2 |  |  | $ | 735.0 |  |
| International |  |  | 71.4 |  |  |  | 69.4 |  |
| Total property and equipment |  | $ | 911.6 |  |  | $ | 804.4 |  |


## ntap:BalanceSheetDetailTextBlock

[0001193125-11-171858:notes:5]
8. Balance Sheet Detail

[0001193125-11-171858:notes:6]
Cash and cash equivalents (in millions):

[0001193125-11-171858:notes:7]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Cash |  | $ | 1,169.1 |  |  | $ | 187.8 |  |
| Cash equivalents |  |  | 1,588.2 |  |  |  | 1,517.2 |  |
|  |  | $ | 2,757.3 |  |  | $ | 1,705.0 |  |

[0001193125-11-171858:notes:8]
Inventories (in millions):

[0001193125-11-171858:notes:9]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Purchased components |  | $ | 7.5 |  |  | $ | 9.4 |  |
| Work-in-process |  |  | 0.1 |  |  |  | 0.2 |  |
| Finished goods |  |  | 100.9 |  |  |  | 103.3 |  |
|  |  | $ | 108.5 |  |  | $ | 112.9 |  |

[0001193125-11-171858:notes:10]
Other current assets (in millions):

[0001193125-11-171858:notes:11]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Net deferred tax assets |  | $ | 145.7 |  |  | $ | 69.6 |  |
| Prepaid expenses and other current assets |  |  | 188.4 |  |  |  | 157.0 |  |
| Short-term restricted cash |  |  | 5.3 |  |  |  | 2.1 |  |
|  |  | $ | 339.4 |  |  | $ | 228.7 |  |

[0001193125-11-171858:notes:12]
Property and equipment (in millions):

[0001193125-11-171858:notes:13]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Land |  | $ | 204.7 |  |  | $ | 204.7 |  |
| Buildings and building improvements |  |  | 406.2 |  |  |  | 394.8 |  |
| Leasehold improvements |  |  | 79.3 |  |  |  | 73.7 |  |
| Computers, production, engineering and other equipment |  |  | 475.5 |  |  |  | 392.0 |  |
| Software |  |  | 270.4 |  |  |  | 236.6 |  |
| Furniture and fixtures |  |  | 61.5 |  |  |  | 63.2 |  |
| Construction-in-progress |  |  | 91.9 |  |  |  | 37.0 |  |
|  |  |  | 1,589.5 |  |  |  | 1,402.0 |  |
| Accumulated depreciation and amortization |  |  | (677.9 | ) |  |  | (597.6 | ) |
|  |  | $ | 911.6 |  |  | $ | 804.4 |  |

[0001193125-11-171858:notes:14]
Depreciation and amortization expense related to property and equipment is summarized below:

[0001193125-11-171858:notes:15]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Depreciation and amortization expense |  | $ | 147.9 |  |  | $ | 145.4 |  |  | $ | 141.1 |  |

[0001193125-11-171858:notes:16]
Computer software represents capitalized internal-use software development costs. The net book value of computer software is as follows:

[0001193125-11-171858:notes:17]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Computer software |  | $ | 88.3 |  |  | $ | 76.0 |  |

[0001193125-11-171858:notes:18]
Amortization expense related to computer software is summarized below:

[0001193125-11-171858:notes:19]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Computer software amortization expense |  | $ | 37.9 |  |  | $ | 36.6 |  |  | $ | 32.6 |  |

[0001193125-11-171858:notes:20]
Long term investments and restricted cash (in millions):

[0001193125-11-171858:notes:21]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Auction rate securities |  | $ | 65.1 |  |  | $ | 69.0 |  |
| Nonmarketable securities |  |  | 1.3 |  |  |  | 1.4 |  |
| Restricted cash |  |  | 2.8 |  |  |  | 2.4 |  |
|  |  | $ | 69.2 |  |  | $ | 72.8 |  |

[0001193125-11-171858:notes:22]
Short-term and long-term deferred revenue (in millions):

[0001193125-11-171858:notes:23]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Product |  | $ | 106.2 |  |  | $ | 78.4 |  |
| Service |  |  | 2,208.7 |  |  |  | 1,836.2 |  |
| Total |  | $ | 2,314.9 |  |  | $ | 1,914.6 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,226.6 |  |  | $ | 1,135.1 |  |
| Long-term |  |  | 1,088.3 |  |  |  | 779.5 |  |
| Total |  | $ | 2,314.9 |  |  | $ | 1,914.6 |  |


## ntap:BusinessAcquisitionCostOfAcquiredEntityDescriptionOfPurchasePriceComponentsTextBlock

[0001193125-11-171858:notes:24]
| Cash |  | $ | 80.5 |  |
| Fair value of vested options assumed |  |  | 3.3 |  |
| Total initial purchase price |  | $ | 83.8 |  |


## ntap:CarryingValueOfShortTermFinancialInstrumentsPolicyTextBlock

[0001193125-11-171858:notes:25]
Financial Instruments — For certain financial instruments, including cash and cash equivalents, short-term investments, accounts receivable, accounts payable and other current liabilities, the carrying amounts approximate their fair value due to the relatively short maturity of these balances. The following methods were used to estimate the fair value of each class of financial instruments for which it is practicable to estimate that value:


## ntap:CashAndCashEquivalentsAndInvestmentsTableTextBlock

[0001193125-11-171858:notes:26]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| United States |  | $ | 3,037.5 |  |  | $ | 2,086.4 |  |
| International |  |  | 2,211.8 |  |  |  | 1,712.5 |  |
| Total cash, cash equivalents, restricted cash and investments |  | $ | 5,249.3 |  |  | $ | 3,798.9 |  |


## ntap:ContractualMaturitiesOfDebtInvestmentsTextBlock

[0001193125-11-171858:notes:27]
| Debt Investment Maturities |  | Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 814.6 |  |  | $ | 817.6 |  |
| Due in one through five years |  |  | 1,593.2 |  |  |  | 1,599.8 |  |
| Due in five through ten years |  |  | 0.0 |  |  |  | 0.0 |  |
| Due after ten years* |  |  | 69.2 |  |  |  | 65.1 |  |
|  |  | $ | 2,477.0 |  |  | $ | 2,482.5 |  |

[0001193125-11-171858:notes:28]
| * | Consists of auction rate securities which have contractual maturities of greater than 10 years. |


## ntap:CurrentAndNoncurrentNetDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-11-171858:notes:29]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |
| Current net deferred tax assets |  | $ | 145.7 |  |  | $ | 69.6 |  |
| Noncurrent net deferred tax assets |  |  | 208.0 |  |  |  | 263.4 |  |


## ntap:DebtDiscountAndIssuanceCostTextBlock

[0001193125-11-171858:notes:30]
| Remaining debt discount |  | $ | 114.6 |  |
| Remaining issuance costs |  |  | 9.9 |  |
| Remaining life of the Notes (years) |  |  | 2.1 |  |


## ntap:DisclosureOfShareBasedCompensationAdditionalInformationRelatedToStockOptionsTextBlock

[0001193125-11-171858:notes:31]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Weighted-average fair value per share granted |  | $ | 15.83 |  |  | $ | 9.74 |  |  | $ | 7.28 |  |
| Weighted-average fair value per share of options assumed in acquisition |  | $ | 21.15 |  |  |  | N/A |  |  |  | N/A |  |
| Intrinsic value of options exercised |  | $ | 325.3 |  |  | $ | 92.9 |  |  | $ | 30.3 |  |
| Proceeds received from the exercise of stock options |  | $ | 301.1 |  |  | $ | 165.1 |  |  | $ | 41.1 |  |
| Fair value of options vested |  | $ | 96.6 |  |  | $ | 165.6 |  |  | $ | 179.8 |  |


## ntap:EntityWideDisclosureOnSignificantCustomersTextBlock

[0001193125-11-171858:notes:32]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Arrow Electronics, Inc. |  | $ | 903.0 |  |  | $ | 550.7 |  |  | $ | 360.3 |  |
| Avnet, Inc. |  |  | 639.0 |  |  |  | 444.0 |  |  |  | 356.4 |  |


## ntap:FairValueOfFinancialInstrumentsPolicyTextBlock

[0001193125-11-171858:notes:33]
The accounting guidance provides a framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs, used in valuation techniques, are assigned a hierarchical level. The following are the hierarchical levels of inputs to measure fair value:

[0001193125-11-171858:notes:34]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001193125-11-171858:notes:35]
Level 2: Inputs reflect quoted prices for identical assets or liabilities in markets that are not active; quoted prices for similar assets or liabilities in active markets; inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001193125-11-171858:notes:36]
Level 3: Unobservable inputs reflecting our own assumptions incorporated in valuation techniques used to determine fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001193125-11-171858:notes:37]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and view an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty's non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001193125-11-171858:notes:38]
We classify investments within Level 1 if quoted prices are available in active markets. Level 1 investments generally include trading securities with quoted prices on active markets, and money market funds.

[0001193125-11-171858:notes:39]
We classify items in Level 2 if the investments are valued using observable inputs to quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. These investments include: corporate bonds, commercial paper, U.S. Treasuries, U.S. government agency bonds, municipal bonds, certificates of deposit, and foreign currency contracts. Investments are held by a custodian who obtains investment prices from a third party pricing provider that incorporates standard inputs in various asset price models. We corroborate the prices obtained from the pricing service against other independent sources and, as of April 29, 2011, have not found it necessary to make any adjustments to the prices obtained.


## ntap:FederalIncomeTaxNoteTableTextBlock

[0001193125-11-171858:notes:40]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Tax computed at federal statutory rate |  | $ | 277.9 |  |  | $ | 156.5 |  |  | $ | 2.9 |  |
| State income taxes, net of federal benefit |  |  | 31.1 |  |  |  | 2.6 |  |  |  | (7.9 | ) |
| Federal credits |  |  | (17.8 | ) |  |  | (7.8 | ) |  |  | (9.2 | ) |
| Stock-based compensation |  |  | (1.3 | ) |  |  | (2.6 | ) |  |  | 10.2 |  |
| Foreign earnings in lower tax jurisdiction |  |  | (146.9 | ) |  |  | (105.2 | ) |  |  | (51.0 | ) |
| IRS audit settlement |  |  | (21.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Other |  |  | (0.9 | ) |  |  | 3.1 |  |  |  | (1.3 | ) |
| Provision for (benefit from) income taxes |  | $ | 121.0 |  |  | $ | 46.6 |  |  | $ | (56.3 | ) |


## ntap:GrossUnrealizedLossesAndFairValuesOfInvestmentsTableTextBlock

[0001193125-11-171858:notes:41]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |
| Corporate bonds |  | $ | 516.1 |  |  | $ | (1.8 | ) |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 516.1 |  |  | $ | (1.8 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 59.7 |  |  |  | (3.3 | ) |  |  | 59.7 |  |  |  | (3.3 | ) |
| U.S. treasury and government debt securities |  |  | 165.3 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 165.3 |  |  |  | (0.1 | ) |
| Total |  | $ | 681.4 |  |  | $ | (1.9 | ) |  | $ | 59.7 |  |  | $ | (3.3 | ) |  | $ | 741.1 |  |  | $ | (5.2 | ) |

[0001193125-11-171858:notes:42]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |
| Corporate bonds |  | $ | 236.7 |  |  | $ | (0.6 | ) |  | $ | 1.1 |  |  | $ | 0.0 |  |  | $ | 237.8 |  |  | $ | (0.6 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 51.0 |  |  |  | (4.5 | ) |  |  | 51.0 |  |  |  | (4.5 | ) |
| U.S. treasury and government debt securities |  |  | 193.4 |  |  |  | (0.7 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 193.4 |  |  |  | (0.7 | ) |
| Total |  | $ | 430.1 |  |  | $ | (1.3 | ) |  | $ | 52.1 |  |  | $ | (4.5 | ) |  | $ | 482.2 |  |  | $ | (5.8 | ) |


## ntap:IncomeTaxBenefitsChargesAssociatedWithDispositionsFromEmployeeStockTransactionsTableTextBlock

[0001193125-11-171858:notes:43]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Income tax benefits (charges) |  | $ | 128.5 |  |  | $ | (0.9 | ) |  | $ | 45.4 |  |


## ntap:InterestCostIncurredTextBlock

[0001193125-11-171858:notes:44]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Contractual coupon interest expense |  | $ | 22.1 |  |  | $ | 22.5 |  |  | $ | 19.4 |  |
| Amortization of debt discount |  |  | 48.9 |  |  |  | 46.8 |  |  |  | 37.8 |  |
| Amortization of issuance costs |  |  | 4.2 |  |  |  | 4.0 |  |  |  | 3.2 |  |
| Total interest expense recognized |  | $ | 75.2 |  |  | $ | 73.3 |  |  | $ | 60.4 |  |


## ntap:InternationalSalesToSingleForeignCountriesTextBlock

[0001193125-11-171858:notes:45]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Germany |  | $ | 618.0 |  |  | $ | 441.1 |  |  | $ | 380.2 |  |


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock

[0001193125-11-171858:notes:46]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 5.5 |  |  | $ | 0.0 |  |
| Non-current portion of other long-term financing arrangements |  |  | 6.0 |  |  |  | 0.0 |  |
|  |  | $ | 11.5 |  |  | $ | 0.0 |  |


## ntap:MarketableSecuritiesAvailableForSaleSecuritiesPolicyTextBlock

[0001193125-11-171858:notes:47]
The unrealized losses on our available-for-sale investments in corporate bonds and U.S. treasury and government debt securities were caused by market value declines as a result of the recent economic environment, as well as fluctuations in market interest rates. Because the decline in market value is attributable to changes in market conditions and not credit quality, and because we neither intend to sell nor are likely to be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired at April 29, 2011.


## ntap:ResidualGuaranteesPolicyTextBlock

[0001193125-11-171858:notes:48]
Residual Guarantees — We record liabilities in other accrued liabilities for the fair value of residual guarantees relating to certain properties under our synthetic leases. In the event that the fair values of the properties, as determined by appraisals, are below the residual guarantees, we accrue for the deficiencies over the remaining term of the respective leases.


## ntap:RevenuesByGeographicRegionTextBlock

[0001193125-11-171858:notes:49]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Americas (United States, Canada and Latin America)* |  | $ | 2,899.0 |  |  | $ | 2,208.1 |  |  | $ | 1,805.2 |  |
| Europe, Middle East and Africa |  |  | 1,719.1 |  |  |  | 1,329.1 |  |  |  | 1,213.3 |  |
| Asia Pacific and Japan |  |  | 504.5 |  |  |  | 394.2 |  |  |  | 387.9 |  |
| Net revenues |  | $ | 5,122.6 |  |  | $ | 3,931.4 |  |  | $ | 3,406.4 |  |

[0001193125-11-171858:notes:50]
| * | Sales to the United States accounted for $2,593.2 million, $1,971.7 million and $1,622.3 million in fiscal 2011, 2010 and 2009, respectively. |


## ntap:ScheduleOfDepreciationAndAmortizationPropertyPlantTextBlock

[0001193125-11-171858:notes:51]
|  |  | Depreciation Life (years) |
| Buildings |  | 40 years |
| Building improvements |  | 10 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 3 years |
| Software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |


## ntap:ScheduleOfIncomeTaxEffectsAllocatedDirectlyToEquityEmployeeStockOptionsTextBlock

[0001193125-11-171858:notes:52]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Income tax benefits (charges) associated with employee stock transactions |  | $ | 128.5 |  |  | $ | (0.9 | ) |  | $ | 45.4 |  |


## ntap:ScheduleOfLeasingArrangementsTableTextBlock

[0001193125-11-171858:notes:53]
| Leasing Arrangements |  | Cost |  | ResidualGuarantee |  | LIBORPlusSpread orFixed Rate |  | LeaseCommencementDate |  | Term |
| 1 |  | $ 48.5 |  | $ 41.2 |  | 3.69% |  | January 2008 |  | 5 years |
| 2 |  | 80.0 |  | 68.0 |  | 0.79% |  | December 2007 |  | 5 years |
| 3 |  | 10.5 |  | 8.9 |  | 3.67% |  | December 2007 |  | 5 years |
| 4 |  | 10.6 |  | 9.0 |  | 3.69% |  | December 2007 |  | 5 years |


## ntap:ScheduleOfNotionalValueOfOutstandingCurrencyForwardContractsTextBlock

[0001193125-11-171858:notes:54]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 104.0 |  |  | $ | 81.0 |  |
| British Pound Sterling |  |  | 20.9 |  |  |  | 18.9 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 253.7 |  |  |  | 232.6 |  |
| British Pound Sterling |  |  | 70.8 |  |  |  | 57.0 |  |
| Canadian Dollar |  |  | 56.0 |  |  |  | 28.1 |  |
| Australian Dollar |  |  | 34.4 |  |  |  | 23.0 |  |
| Other |  |  | 52.6 |  |  |  | 43.6 |  |


## ntap:ScheduleOfTaxYearsSubjectToExaminationTableTextBlock

[0001193125-11-171858:notes:55]
| 2005 — 2010 |  | United States — federal income tax |
| 2003 — 2010 |  | United States — state and local income tax |
| 2005 — 2010 |  | Australia |
| 2004 — 2010 |  | Germany |
| 2002 — 2010 |  | India |
| 2003 — 2010 |  | Japan |
| 2009 — 2010 |  | The Netherlands |
| 2007 — 2010 |  | United Kingdom |
| 2006 — 2010 |  | Canada |


## ntap:ScheduleOfValuationAndQualifyingAccountsTableTextBlock

[0001193125-11-171858:notes:56]
| Description |  | Balance atBeginningof Period |  |  | AdditionsCharged(Credited) toCosts andExpenses |  |  | Reductionsand Write-offs |  |  | Balanceat End ofPeriod |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2011 |  | $ | 1.6 |  |  | $ | (0.8 | ) |  | $ | 0.3 |  |  | $ | 0.5 |  |
| 2010 |  | $ | 3.1 |  |  | $ | 0.0 |  |  | $ | 1.5 |  |  | $ | 1.6 |  |
| 2009 |  | $ | 2.4 |  |  | $ | 1.1 |  |  | $ | 0.4 |  |  | $ | 3.1 |  |


## ntap:SegmentGeographicAndSignificantCustomerInformationDisclosureTextBlock

[0001193125-11-171858:notes:57]
16. Segment, Geographic, and Significant Customer Information

[0001193125-11-171858:notes:58]
We operate in one reportable industry segment: the design, manufacturing, marketing, and technical support of high-performance networked storage solutions. Our company conducts business globally and is primarily managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from its internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management system because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001193125-11-171858:notes:59]
Summarized revenues by geographic region for fiscal 2011, 2010 and 2009, based on the our internal management system and as utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0001193125-11-171858:notes:60]
The majority of our assets, excluding cash, cash equivalents, restricted cash, investments and accounts receivable, as of April 29, 2011 and April 30, 2010 were attributable to our U.S. operations. The following table presents total cash, cash equivalents, restricted cash and investments held in the United States and outside of the United States in various foreign subsidiaries (in millions):

[0001193125-11-171858:notes:61]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001193125-11-171858:notes:62]
No more than ten percent of property and equipment was located in any single foreign country.

[0001193125-11-171858:notes:63]
International sales to single foreign countries which accounted for ten percent or more of net revenues were as follows (in millions):

[0001193125-11-171858:notes:64]
Sales to customers, who are distributors, which accounted for ten percent or more of net revenues were as follows (in millions):

[0001193125-11-171858:notes:65]
The following customers accounted for ten percent or more of net accounts receivable (in millions):


## ntap:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsMethodUsedTextBlock

[0001193125-11-171858:notes:66]
|  |  | Stock OptionsYear Ended |  |  | ESPPYear Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.5 |  |  |  | 4.0 |  |  |  | 1.2 |  |  |  | 1.3 |  |  |  | 1.3 |  |
| Risk-free interest rate |  |  | 2.01 | % |  |  | 2.27 | % |  |  | 2.11 | % |  |  | 0.37 | % |  |  | 0.39 | % |  |  | 1.16 | % |
| Volatility |  |  | 37 | % |  |  | 41 | % |  |  | 54 | % |  |  | 39 | % |  |  | 39 | % |  |  | 73 | % |


## ntap:ShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsOutstandingRollForwardTextBlock

[0001193125-11-171858:notes:67]
|  |  | Numbers ofShares |  |  | WeightedAverageGrant DateFair Value |  |
| Outstanding at April 25, 2008 |  |  | 4.6 |  |  | $ | 26.30 |  |
| RSUs granted |  |  | 2.2 |  |  |  | 17.16 |  |
| RSUs vested |  |  | (0.8 | ) |  |  | 28.81 |  |
| RSUs forfeitures and cancellations |  |  | (0.5 | ) |  |  | 25.48 |  |
| Outstanding at April 24, 2009 |  |  | 5.5 |  |  |  | 22.38 |  |
| RSUs granted |  |  | 3.1 |  |  |  | 29.32 |  |
| RSUs issued in the Stock Option Exchange |  |  | 3.2 |  |  |  | 21.73 |  |
| RSUs vested |  |  | (2.1 | ) |  |  | 24.64 |  |
| RSUs forfeitures and cancellations |  |  | (0.7 | ) |  |  | 23.39 |  |
| Outstanding at April 30, 2010 |  |  | 9.0 |  |  |  | 23.92 |  |
| RSUs granted |  |  | 4.7 |  |  |  | 49.13 |  |
| RSUs vested |  |  | (2.9 | ) |  |  | 22.52 |  |
| RSUs forfeitures and cancellations |  |  | (0.7 | ) |  |  | 27.57 |  |
| Outstanding at April 29, 2011 |  |  | 10.1 |  |  | $ | 35.79 |  |


## ntap:SharesWithheldForEmployeeTaxesTextBlock

[0001193125-11-171858:notes:68]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Shares withheld for taxes |  |  | 1.0 |  |  |  | 0.7 |  |  |  | 0.3 |  |
| Fair value of shares withheld |  | $ | 45.9 |  |  | $ | 20.8 |  |  | $ | 5.1 |  |


## ntap:StockBasedCompensationExpenseAssociatedWithEachTypeOfAwardTextBlock

[0001193125-11-171858:notes:69]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Employee stock options |  | $ | 53.7 |  |  | $ | 61.1 |  |  | $ | 80.5 |  |
| RSU's and restricted stock awards |  |  | 88.9 |  |  |  | 64.1 |  |  |  | 32.9 |  |
| ESPP |  |  | 32.6 |  |  |  | 34.3 |  |  |  | 27.4 |  |
| Change in amounts capitalized in inventory |  |  | 0.0 |  |  |  | 0.3 |  |  |  | 0.0 |  |
| Total stock-based compensation expense |  | $ | 175.2 |  |  | $ | 159.8 |  |  | $ | 140.8 |  |


## ntap:SupplementalCashFlowInformationRelatedTextBlock

[0001193125-11-171858:notes:70]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Noncash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition of property and equipment on account |  | $ | 39.3 |  |  | $ | 17.2 |  |  | $ | 13.2 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 12.6 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |
| Options assumed from acquired business |  | $ | 3.3 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |
| Taxes on settlement of note hedge |  | $ | 0.0 |  |  | $ | 32.1 |  |  | $ | 0.0 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 27.9 |  |  | $ | 22.8 |  |  | $ | 16.2 |  |
| Interest paid |  | $ | 22.7 |  |  | $ | 22.1 |  |  | $ | 12.7 |  |


## ntap:TaxesCollectedFromCustomersPolicyTextBlock

[0001193125-11-171858:notes:71]
Sales and Value Added Taxes — Taxes collected from customers and remitted to governmental authorities are presented on a net basis in the accompanying consolidated statements of operations.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-11-171858:notes:72]
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |
|  | Cost |  |  | Gross Unrealized |  |  | EstimatedFair Value |  |  | Cost |  |  | Gross Unrealized |  |  | EstimatedFair Value |  |
|  |  | Gains |  |  | Losses |  |  |  |  | Gains |  |  | Losses |  |  |
| Corporate bonds |  | $ | 1,643.2 |  |  | $ | 10.2 |  |  | $ | (0.6 | ) |  | $ | 1,652.8 |  |  | $ | 1,128.1 |  |  | $ | 3.4 |  |  | $ | (1.8 | ) |  | $ | 1,129.7 |  |
| Auction rate securities |  |  | 69.2 |  |  |  | 0.4 |  |  |  | (4.5 | ) |  |  | 65.1 |  |  |  | 71.6 |  |  |  | 0.7 |  |  |  | (3.3 | ) |  |  | 69.0 |  |
| U.S. treasury and government debt securities |  |  | 661.9 |  |  |  | 0.6 |  |  |  | (0.7 | ) |  |  | 661.8 |  |  |  | 816.9 |  |  |  | 2.1 |  |  |  | (0.1 | ) |  |  | 818.9 |  |
| Commercial paper |  |  | 5.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 5.0 |  |  |  | 215.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 215.9 |  |
| Municipal bonds |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |
| Certificates of deposit |  |  | 96.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 96.3 |  |  |  | 159.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 159.0 |  |
| Money market funds |  |  | 1,539.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,539.6 |  |  |  | 1,211.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,211.2 |  |
| Equity funds |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 20.2 |  |  |  | 12.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 12.6 |  |
| Investment in privately-held companies |  |  | 1.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.3 |  |  |  | 1.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.4 |  |
| Total debt and equity securities |  | $ | 4,038.2 |  |  | $ | 11.2 |  |  | $ | (5.8 | ) |  | $ | 4,043.6 |  |  | $ | 3,618.2 |  |  | $ | 6.2 |  |  | $ | (5.2 | ) |  | $ | 3,619.2 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-11-171858:notes:73]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Net revenues |  | $ | 5,823.8 |  |  | $ | 4,605.7 |  |
| Net income |  | $ | 606.8 |  |  | $ | 366.9 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-11-171858:notes:74]
6. Business Combinations

[0001193125-11-171858:notes:75]
Acquisition of Akorri Networks, Inc.

[0001193125-11-171858:notes:76]
On January 31, 2011, we completed the acquisition of Akorri Networks, Inc., (Akorri) a privately-held company headquartered in Massachusetts. Akorri is a provider of data center management software focused on performance and capacity analytics for virtualized, shared information technology infrastructures. The acquisition extends our offering by adding performance capacity analytics to provide customers greater visibility across the entire IT stack, resulting in further improvement in IT efficiency and flexibility through functions that help control, automate, and analyze their shared IT infrastructure.

[0001193125-11-171858:notes:77]
We acquired 100% of the outstanding shares of Akorri for a purchase price of $62.3 million in cash, of which $7.9 million was placed in an escrow account to secure Akorri's obligations under certain indemnity provisions. Subject to any claims for indemnity, the escrow funds will be released 18 months from the closing date of the acquisition. The results of operations of Akorri are included in our consolidated statements of operations beginning January 31, 2011, the closing date of the acquisition

[0001193125-11-171858:notes:78]
The purchase price was allocated to Akorri's net tangible and intangible assets based on various fair value estimates and analyses, including work performed by third-party valuation specialists (in millions):

[0001193125-11-171858:notes:79]
| Cash |  | $ | 0.7 |  |
| Other current assets |  |  | 0.8 |  |
| Other non-current assets |  |  | 7.3 |  |
| Deferred revenue |  |  | (1.2 | ) |
| Accounts payable and accrued liabilities |  |  | (0.5 | ) |
| Identified intangible assets |  |  | 22.0 |  |
| Deferred income taxes |  |  | 9.9 |  |
| Goodwill |  |  | 23.3 |  |
| Total initial purchase price |  | $ | 62.3 |  |

[0001193125-11-171858:notes:80]
Goodwill is not deductible for income tax purposes.

[0001193125-11-171858:notes:81]
Adjustments may be made to the allocation of the purchase price during the measurement period to reflect adjustments related to facts existing at the time of the acquisition. The identified intangible assets, which are amortized on a straight-line basis over their estimated useful lives, consisted of the following (in millions, except useful life):

[0001193125-11-171858:notes:82]
|  |  | FairValue |  |  | Useful Life(Years) |  |
| Developed technology |  | $ | 18.7 |  |  |  | 6 |  |
| Customer relationships |  |  | 2.3 |  |  |  | 3 |  |
| Trademarks and trade names |  |  | 0.6 |  |  |  | 4 |  |
| Covenant not to compete |  |  | 0.4 |  |  |  | 2 |  |
| Total identified intangible assets |  | $ | 22.0 |  |  |  |  |  |

[0001193125-11-171858:notes:83]
Pro forma results of operations have not been presented because the acquisition was not material to our results of operations.

[0001193125-11-171858:notes:84]
Certain terminated Akorri employees were provided with termination benefits including severance payouts of $2.4 million as a result of the acquisition. We have accounted for these costs as restructuring charges in our statements of operations.

[0001193125-11-171858:notes:85]
We incurred $0.6 million in acquisition related expenses for Akorri, which are included in acquisition related (income) expense, net, in our consolidated statements of operations for the fiscal year ended April 29, 2011.

[0001193125-11-171858:notes:86]
Bycast Acquisition

[0001193125-11-171858:notes:87]
On May 13, 2010, we completed our acquisition of Bycast Inc. (Bycast), a privately held company headquartered in Vancouver, Canada. Bycast develops and sells software designed to manage petabyte-scale, globally distributed repositories of images, video and records for enterprises and service providers. The acquisition extends our position in unified storage by adding an object-based storage software offering, which simplifies the task of large-scale storage and improves the ability to search and locate data objects.

[0001193125-11-171858:notes:88]
We acquired 100% of the outstanding shares of Bycast for a purchase price of $80.5 million in cash, of which $13.1 million was placed in an escrow account to secure Bycast's obligations under certain indemnity provisions. Subject to any claims for indemnity, the escrow funds will be released 18 months from the closing date of the acquisition. In addition, we assumed all of the then outstanding options to purchase Bycast common stock, and converted those into options to purchase approximately 0.2 million shares of our common stock. The results of operations of Bycast are included in our consolidated statements of operations beginning May 13, 2010, the closing date of the acquisition.

[0001193125-11-171858:notes:89]
The following table summarizes the purchase price (in millions):

[0001193125-11-171858:notes:90]
The fair value of the assumed options was determined using a Black-Scholes valuation model.

[0001193125-11-171858:notes:91]
The purchase price as shown in the table above was allocated to Bycast's net tangible and intangible assets based on various fair value estimates and analyses, including work performed by third-party valuation specialists (in millions):

[0001193125-11-171858:notes:92]
| Cash |  | $ | 5.7 |  |
| Tangible assets |  |  | 3.8 |  |
| Deferred revenue and other liabilities |  |  | (1.4 | ) |
| Identified intangible assets |  |  | 23.6 |  |
| Deferred income taxes |  |  | (3.9 | ) |
| Goodwill |  |  | 56.0 |  |
| Total initial purchase price |  | $ | 83.8 |  |

[0001193125-11-171858:notes:93]
The identified intangible assets, which are amortized on a straight-line basis over their estimated useful lives, consisted of the following (in millions, except useful life):

[0001193125-11-171858:notes:94]
|  |  | FairValue |  |  | Useful Life(Years) |  |
| Developed technology |  | $ | 18.0 |  |  |  | 5 |  |
| Customer relationships |  |  | 4.7 |  |  |  | 3 |  |
| Trademarks and trade names |  |  | 0.7 |  |  |  | 5 |  |
| Covenant not to compete |  |  | 0.2 |  |  |  | 2 |  |
| Total identified intangible assets |  | $ | 23.6 |  |  |  |  |  |

[0001193125-11-171858:notes:95]
We incurred $0.3 million and $1.2 million in acquisition related expenses for Bycast, which are included in acquisition related (income) expense, net, in our consolidated statements of operations for fiscal years ended April 29, 2011 and April 30, 2010, respectively.

[0001193125-11-171858:notes:96]
Termination of Proposed Merger with Data Domain, Inc.

[0001193125-11-171858:notes:97]
In July 2009, a proposed merger between us and Data Domain, Inc. (Data Domain) was terminated by Data Domain's Board of Directors and, pursuant to the terms of the agreement, Data Domain paid us a $57.0 million termination fee. We incurred $15.9 million of incremental third-party costs relating to the terminated merger transaction during the same period, resulting in a net amount of $41.1 million which is included in acquisition related (income) expense, net in our consolidated statements of operations for the fiscal year ended April 30, 2010.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-11-171858:notes:98]
Cash and Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at time of purchase to be cash equivalents. Cash equivalents consist primarily of money market funds, for which the carrying amounts are reasonable estimates of fair value. Cash equivalents are recognized at fair value.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-11-171858:notes:99]
5. Statements of Cash Flows

[0001193125-11-171858:notes:100]
Supplemental cash flows and noncash investing and financing activities are as follows (in millions):


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-11-171858:notes:101]
18. Commitments and Contingencies

[0001193125-11-171858:notes:102]
Operating Leases — We lease office space in several U.S. locations. Outside the United States, larger leased sites include sites in The Netherlands, Australia, Belgium, France, Germany, India, Japan, and the United Kingdom. We also lease equipment and vehicles.

[0001193125-11-171858:notes:103]
As of April 29, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNPPLC which require us to lease certain portions of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third party for an amount equal to at least 85% of the costs (residual guarantee), and be liable for any deficiency between the net proceeds received from the third party and such amounts; or (iii) pay BNPPLC supplemental payments for an amount equal to at least 85% of the costs (residual guarantee), in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period. The following table summarizes the costs, the residual guarantee, the applicable LIBOR plus spread or fixed rate at April 29, 2011 and the date we began to make payments for each of our leasing arrangements (in millions):

[0001193125-11-171858:notes:104]
These leases require us to maintain specified financial covenants with which we were in compliance as of April 29, 2011. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than three to one and a minimum amount of Unencumbered Cash and Short-Term Investments of $300 million.

[0001193125-11-171858:notes:105]
Future annual minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 29, 2011 are as follows (in millions):

[0001193125-11-171858:notes:106]
|  |  | 2012 |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | Thereafter |  |  | Total |  |
| Office operating lease payments |  | $ | 30.3 |  |  | $ | 26.4 |  |  | $ | 22.5 |  |  | $ | 20.9 |  |  | $ | 14.9 |  |  | $ | 11.7 |  |  | $ | 126.7 |  |
| Real estate lease payments |  |  | 3.2 |  |  |  | 129.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 132.4 |  |
| Equipment operating lease payments |  |  | 21.5 |  |  |  | 13.2 |  |  |  | 6.5 |  |  |  | 0.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 41.8 |  |
| Less: Sublease income |  |  | (1.4 | ) |  |  | (1.4 | ) |  |  | (1.1 | ) |  |  | (1.1 | ) |  |  | (0.5 | ) |  |  | 0.0 |  |  |  | (5.5 | ) |
| Total lease commitments |  | $ | 53.6 |  |  | $ | 167.4 |  |  | $ | 27.9 |  |  | $ | 20.4 |  |  | $ | 14.4 |  |  | $ | 11.7 |  |  | $ | 295.4 |  |

[0001193125-11-171858:notes:107]
Included in real estate lease payments pursuant to four financing arrangements with BNP Paribas Leasing Corporation (BNPPLC) are (i) lease commitments, which are based on the LIBOR rate at April 29, 2011 plus a spread or a fixed rate, for terms of five years; and (ii) included in the amount for fiscal year 2013 at the expiration or termination of the lease, a supplemental payment obligation equal to our minimum guarantee of $127.1 million in the event that we elect not to purchase or arrange for sale of the buildings.

[0001193125-11-171858:notes:108]
As of April 29, 2011, we estimated that the fair value of the properties under synthetic lease was $35.8 million less than their aggregate residual guarantees. We are accruing for this deficiency over the remaining terms of the respective leases. As of April 29, 2011, a deficiency reserve of $16.1 million was included in other long-term liabilities.

[0001193125-11-171858:notes:109]
Rent expense in fiscal 2011, 2010 and 2009 was as follows (in millions):

[0001193125-11-171858:notes:110]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Facilities rent expense |  | $ | 51.7 |  |  | $ | 43.2 |  |  | $ | 40.6 |  |
| Equipment rent expense |  |  | 23.1 |  |  |  | 23.4 |  |  |  | 25.3 |  |
|  |  | $ | 74.8 |  |  | $ | 66.6 |  |  | $ | 65.9 |  |
| Less: sublease income |  |  | (6.3 | ) |  |  | (12.5 | ) |  |  | (11.8 | ) |
| Net rent expense |  | $ | 68.5 |  |  | $ | 54.1 |  |  | $ | 54.1 |  |

[0001193125-11-171858:notes:111]
Purchase Orders and Other Commitments

[0001193125-11-171858:notes:112]
In the normal course of business we make commitments to our third party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $176.0 million in non-cancelable purchase commitments with our contract manufacturers as of April 29, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of April 29, 2011 and April 30, 2010, such liability amounted to $4.5 million and $3.8 million, respectively, and is included in other current liabilities in the consolidated balance sheets.

[0001193125-11-171858:notes:113]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $36.1 million in capital purchase commitments and $270.0 million in other purchase commitments as of April 29, 2011.

[0001193125-11-171858:notes:114]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 29, 2011, our financial guarantees of $5.3 million that were not recorded on our balance sheet consisted of standby letters of credit related to workers' compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and surety bonds.

[0001193125-11-171858:notes:115]
Product Warranties

[0001193125-11-171858:notes:116]
We provide customers a warranty on software of ninety days and a warranty on hardware of three years. The following table summarizes our warranty reserves (in millions):

[0001193125-11-171858:notes:117]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Beginning balance |  | $ | 31.9 |  |  | $ | 42.3 |  |
| Expense accrued during the period |  |  | 31.8 |  |  |  | 16.0 |  |
| Warranty costs incurred |  |  | (23.2 | ) |  |  | (26.4 | ) |
| Ending balance |  | $ | 40.5 |  |  | $ | 31.9 |  |

[0001193125-11-171858:notes:118]
Financing Guarantees

[0001193125-11-171858:notes:119]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of April 29, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $89.0 million, and the related deferred revenue and cost of revenues totaled approximately $87.7 million and $7.6 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001193125-11-171858:notes:120]
Indemnification Agreements

[0001193125-11-171858:notes:121]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another noninfringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 29, 2011 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001193125-11-171858:notes:122]
Legal Contingencies

[0001193125-11-171858:notes:123]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of April 29, 2011, as the outcome of these legal matters is currently not determinable.

[0001193125-11-171858:notes:124]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named 15 of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011, and the hearing on these motions is scheduled for July 15, 2011.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001193125-11-171858:notes:125]
17. Employee Benefits and Deferred Compensation

[0001193125-11-171858:notes:126]
Employee 401(k) Plans

[0001193125-11-171858:notes:127]
We have established a 401(k) tax-deferred savings plan. Employees meeting the eligibility requirements, as defined, may contribute specified percentages of their salaries. In 2011, 2010 and 2009, we matched 50% of the employee's contribution up to a total of 6% of the employee's annual salary, and the matched contributions are vested over 3 years. The amounts we contributed to this plan were as follows (in millions):

[0001193125-11-171858:notes:128]
Deferred Compensation Plans

[0001193125-11-171858:notes:129]
We have a non-qualified deferred compensation plan that allows a group of employees within the United States to contribute base salary and/or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The amounts of the marketable securities related to investments in debt and equity securities that are held in a rabbi trust under non-qualified deferred compensation plans and the related deferred compensation liability under this plan, which are recorded primarily in other long-term liabilities were as follows (in millions):

[0001193125-11-171858:notes:130]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Deferred compensation plan assets |  | $ | 20.2 |  |  | $ | 12.6 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 3.7 |  |  |  | 2.3 |  |
| Other long-term liabilities |  |  | 16.5 |  |  |  | 10.3 |  |

[0001193125-11-171858:notes:131]
Postretirement Health Care Plan

[0001193125-11-171858:notes:132]
We maintain a plan to provide postretirement health and welfare benefits to certain executives who meet certain age and service requirements. Coverage continues through the duration of the lifetime of the retiree or the retiree's spouse, whichever is longer. There is no funding requirement associated with the plan and none of the benefit obligation was funded as of April 29, 2011. Assumed health care cost trend rates have a significant effect on the amounts reported for the health care plan.

[0001193125-11-171858:notes:133]
The accumulated postretirement benefit obligation is summarized as follows and is classified in other long term liabilities in the accompanying consolidated balance sheets (in millions):

[0001193125-11-171858:notes:134]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| Accumulated postretirement benefit obligation |  | $ | 5.4 |  |  | $ | 4.8 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-11-171858:notes:135]
3. Concentration of Risk

[0001193125-11-171858:notes:136]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. government agency securities, and money market funds, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001193125-11-171858:notes:137]
Our long term investments, consisting primarily of auction rate securities, have been and will continue to be exposed to market risk due to uncertainties in the credit and capital markets.

[0001193125-11-171858:notes:138]
In entering into forward foreign exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001193125-11-171858:notes:139]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers' financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management's expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001193125-11-171858:notes:140]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we currently rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-11-171858:notes:141]
Principles of Consolidation — The consolidated financial statements include the Company and its wholly-owned subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001193125-11-171858:notes:142]
| 10. | Financing Arrangements |

[0001193125-11-171858:notes:143]
1.75% Convertible Senior Notes Due 2013

[0001193125-11-171858:notes:144]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per 1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes. We received net proceeds of $1,238.4 million, after deducting issuance costs of $26.6 million.

[0001193125-11-171858:notes:145]
The Notes are not redeemable by us prior to the maturity date. In the event of a fundamental change, holders of the Notes may require us to repurchase all or a portion of their Notes at a repurchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date.

[0001193125-11-171858:notes:146]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013 until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change (as defined in the indenture for the Notes) will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

[0001193125-11-171858:notes:147]
For at least 20 trading days during the 30 consecutive trading days ended March 31, 2011, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the Notes are convertible at the holder's option through June 30, 2011, and the carrying value of the Notes was classified as a current liability as of April 29, 2011. Since the Notes are convertible at the option of the holder and the principal amount is required to be paid in cash, the difference between the principal amount and the carrying value of the Notes is reflected as convertible debt in mezzanine on our Balance Sheet as of April 29, 2011. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may not be convertible in future quarters, and therefore may again be classified as long-term debt, if the contingent conversion thresholds are not met in such quarters.

[0001193125-11-171858:notes:148]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of April 29, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $52.11 on April 29, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $834.3 million.

[0001193125-11-171858:notes:149]
We separately account for the liability and equity components of the Notes. The initial debt component of the Notes was valued at $1,017.0 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 6.31%, with the equity component representing the residual amount of the proceeds of $248.0 million which was recorded as a debt discount. Issuance costs were allocated pro rata based on the relative initial carrying amounts of the debt and equity components. As a result, $5.2 million of the issuance costs were allocated to the equity component of the Notes, and $21.4 million of the issuance costs remained classified as long-term other assets. The debt discount and the issuance costs allocated to the debt component are amortized as additional interest expense over the term of the Notes using the effective interest method and an effective interest rate of 6.31% for all periods presented.

[0001193125-11-171858:notes:150]
The following table reflects the carrying value of our convertible debt as of April 29, 2011 and April 30, 2010 (in millions):

[0001193125-11-171858:notes:151]
|  |  | April 29,2011 |  |  | April 30,2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (114.6 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,150.4 |  |  | $ | 1,101.5 |  |

[0001193125-11-171858:notes:152]
The following table presents the amount of interest cost recognized relating to both the contractual interest coupon and the amortization of the discount and issuance costs (in millions):

[0001193125-11-171858:notes:153]
The following table reflects the remaining debt discount and issuance cost as of April 29, 2011 (in millions):

[0001193125-11-171858:notes:154]
Note Hedges and Warrants

[0001193125-11-171858:notes:155]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrants transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.

[0001193125-11-171858:notes:156]
| • |  | Note Hedges. As of April 29, 2011 and April 30, 2010, we have transactions with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

[0001193125-11-171858:notes:157]
| • |  | Warrants. As of April 29, 2011 and April 30, 2010, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

[0001193125-11-171858:notes:158]
As of April 29, 2011, we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

[0001193125-11-171858:notes:159]
As of April 29, 2011, receipts of shares related to the Note hedge transactions were minimal. Additionally, there was no cash or shares delivered in relation to the warrant transactions. We received proceeds of $163.1 million related to the sale of the warrants in fiscal year 2009, which has been classified as equity. In fiscal years 2009 and 2010 we did not receive any shares related to the Note hedge transactions or deliver cash or shares related to the warrant transactions.

[0001193125-11-171858:notes:160]
Lehman Brothers OTC Derivatives, Inc. (Lehman OTC) was the counterparty to 20% of our Note hedges. The bankruptcy filing by Lehman OTC on October 3, 2008 constituted an "event of default" under the hedge transaction. In April 2010, we terminated the hedge transaction with Lehman OTC in exchange for an unsecured bankruptcy claim, which we subsequently sold to a third party for $14.2 million. Because we have decided not to replace the hedge, we are subject to potential dilution on the 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of $31.85. The terms of the Notes, the rights of the holders of the Notes and other counterparties to Note hedges and warrants were not affected by the termination of this hedge.

[0001193125-11-171858:notes:161]
Fair Value of Note

[0001193125-11-171858:notes:162]
As of April 29, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $2,127.5 million, or 168% of the face value of the Notes, based upon quoted market information.

[0001193125-11-171858:notes:163]
Other Long-Term Financing Arrangements

[0001193125-11-171858:notes:164]
The following presents the amounts due under other long-term financing arrangements (in millions):


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-11-171858:notes:165]
12. Derivatives and Hedging Activities

[0001193125-11-171858:notes:166]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place a master netting arrangement to mitigate the credit risk of our counterparty and potentially to reduce our losses due to counterparty nonperformance. All contracts have a maturity of less than six months.

[0001193125-11-171858:notes:167]
Our major foreign currency exchange exposures and related hedging programs are described below:

[0001193125-11-171858:notes:168]
Balance Sheet. We utilize monthly foreign currency forward and options contracts to hedge exchange rate fluctuations related to certain foreign monetary assets and liabilities. These derivative instruments do not subject us to material balance sheet risk due to exchange rate movements because gains and losses on these derivatives are intended to offset gains and losses on the assets and liabilities being hedged and the net amount is included in earnings.

[0001193125-11-171858:notes:169]
Forecasted Transactions. We use currency forward contracts to hedge exposures related to forecasted sales denominated in certain foreign currencies. These contracts are designated as cash flow hedges and in general closely match the underlying forecasted transactions in duration. The contracts are carried on the balance sheet at fair value, and the effective portion of the contracts' gains and losses is recorded as AOCI until the forecasted transaction occurs. When the forecasted transaction occurs, we reclassify the related gain or loss on the cash flow hedge to revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur, the gain or loss on the related cash flow hedge is recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated currency forward contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss as well as changes in the fair value of the derivative's time value (which are excluded from the assessment of hedge effectiveness) is recognized in current period earnings.

[0001193125-11-171858:notes:170]
Over the next twelve months, it is expected that $2.3 million of derivative net losses recorded in AOCI as of April 29, 2011 will be reclassified into earnings as an adjustment to revenues. The maximum length of time over which forecasted foreign denominated revenues are hedged is six months.

[0001193125-11-171858:notes:171]
The notional value of our outstanding currency forward contracts that were entered into to hedge forecasted foreign denominated sales and our balance sheet monetary asset and liability exposures consisted of the following (in millions):

[0001193125-11-171858:notes:172]
As of April 29, 2011 and April 30, 2010, the fair value of our short-term foreign currency contracts was not material. Certain of these contracts are designed to hedge our exposure to foreign monetary assets and liabilities and are not accounted for as a hedging activity. Accordingly, changes in fair value of these instruments are recognized in earnings during the period of change. Net deferred gains and losses relating to changes in fair value of our foreign currency contracts that are accounted for as cash flow hedges were not material for any period presented. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. The amount of net losses recorded in AOCI as of April 29, 2011 was not material. Gain (loss) on derivative instruments was a loss of $20.6 million in fiscal 2011 and gains of $8.2 million and $20.9 million in fiscal years 2010 and 2009, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001193125-11-171858:notes:173]
Derivative Instruments — Derivatives that are not designated as hedges are adjusted to fair value through earnings. If the derivative is designated as a hedge, depending on the nature of the exposure being hedged, changes in fair value will either be offset against the change in fair value of the hedged items through earnings or recognized in AOCI until the hedged item is recognized in earnings. The ineffective portion of the hedge is recognized in earnings immediately.

[0001193125-11-171858:notes:174]
As a result of our significant international operations, we are subject to risks associated with fluctuating exchange rates. We use derivative financial instruments, principally currency forward contracts and currency options, to attempt to minimize the impact of exchange rate movements on our balance sheet and operating results. Factors that could have an impact on the effectiveness of our hedging program include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not always entirely eliminate, the impact of currency exchange movements. The maturities of these instruments are generally less than one year.

[0001193125-11-171858:notes:175]
Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related to firm commitments or nonmarketable investments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows with the exception of cash flows from the derivatives used to hedge the convertible Notes issued June 10, 2008. The cash flows related to the Note hedges are included under financing activities.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001193125-11-171858:notes:176]
|  |  | Numbersof Shares |  |  | WeightedAverageExercisePrice |  |  | WeightedAverageRemainingContractual Term(Years) |  |  | AggregateIntrinsicValue |  |
| Outstanding at April 25, 2008 |  |  | 65.6 |  |  | $ | 30.03 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 8.7 |  |  |  | 17.67 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (3.7 | ) |  |  | 11.20 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (4.5 | ) |  |  | 32.61 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 24, 2009 |  |  | 66.1 |  |  |  | 29.27 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 7.1 |  |  |  | 26.95 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (8.5 | ) |  |  | 19.33 |  |  |  |  |  |  |  |  |  |
| Options cancelled in the Exchange |  |  | (24.5 | ) |  |  | 39.05 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (5.0 | ) |  |  | 39.12 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 30, 2010 |  |  | 35.2 |  |  |  | 23.02 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 3.9 |  |  |  | 45.28 |  |  |  |  |  |  |  |  |  |
| Options assumed in acquisition |  |  | 0.2 |  |  |  | 16.56 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (13.8 | ) |  |  | 21.85 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (1.0 | ) |  |  | 34.43 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 29, 2011 |  |  | 24.5 |  |  | $ | 26.62 |  |  |  | 4.34 |  |  | $ | 626.5 |  |
| Options vested and expected to vest as of April 29, 2011 |  |  | 23.3 |  |  | $ | 26.25 |  |  |  | 4.27 |  |  | $ | 604.2 |  |
| Exercisable at April 29, 2011 |  |  | 13.9 |  |  | $ | 23.81 |  |  |  | 3.54 |  |  | $ | 394.5 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-11-171858:notes:177]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted average number of common shares outstanding, excluding common shares subject to repurchase for that period. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Dilutive potential common shares consist of incremental common shares subject to repurchase, common shares issuable upon exercise of stock options, restricted stock awards, ESPP shares, warrants, and assumed conversion of our Notes. Repurchased shares are held as treasury stock and our outstanding shares used to calculate earnings per share have been reduced by the weighted number of repurchased shares.


## us-gaap:EarningsPerShareTextBlock

[0001193125-11-171858:notes:178]
15. Net Income per Share

[0001193125-11-171858:notes:179]
The following is a calculation of basic and diluted net income per share for the periods presented (in millions):

[0001193125-11-171858:notes:180]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 673.1 |  |  | $ | 400.4 |  |  | $ | 64.6 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average common shares outstanding |  |  | 360.9 |  |  |  | 339.7 |  |  |  | 330.4 |  |
| Weighted average common shares outstanding subject to repurchase |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Shares used in basic computation |  |  | 360.9 |  |  |  | 339.6 |  |  |  | 330.3 |  |
| Weighted average common shares outstanding subject to repurchase |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 14.6 |  |  |  | 13.2 |  |  |  | 4.2 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 12.7 |  |  |  | 0.3 |  |  |  | 0.0 |  |
| Dilutive impact of warrants |  |  | 5.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Shares used in diluted computation |  |  | 393.7 |  |  |  | 353.2 |  |  |  | 334.6 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.87 |  |  | $ | 1.18 |  |  | $ | 0.20 |  |
| Diluted |  | $ | 1.71 |  |  | $ | 1.13 |  |  | $ | 0.19 |  |

[0001193125-11-171858:notes:181]
The following potential weighted average common shares have been excluded from the diluted net income per share calculations, as their effect would have been antidilutive (in millions):

[0001193125-11-171858:notes:182]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Options and RSUs |  |  | 2.6 |  |  |  | 19.3 |  |  |  | 61.1 |  |

[0001193125-11-171858:notes:183]
Dilutive shares outstanding for fiscal years 2010 and 2009 do not include any effect resulting from warrants and for fiscal 2009 do not include any effect resulting from assumed conversion of the Notes, as their impact would have been anti-dilutive. The Note hedges (as described in Note 10) are not included for purposes of, calculating earnings per share as their effect would be anti-dilutive. The Note hedges, if exercised upon conversion of the Notes, are expected to reduce approximately 80% of the dilutive effect of the Notes when our stock price is above $31.85 per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-11-171858:notes:184]
|  |  | Primary Fund |  |  | Auction RateSecurities |  |  | Private EquityFund |  |  | Privately-HeldCompanies |  |
| Balance at April 24, 2009 |  | $ | 51.6 |  |  | $ | 66.5 |  |  | $ | 2.0 |  |  | $ | 1.9 |  |
| Total unrealized gains included in other comprehensive income |  |  | 0.0 |  |  |  | 4.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Total realized gains (losses) included in earnings |  |  | (0.2 | ) |  |  | 0.0 |  |  |  | 0.8 |  |  |  | 2.6 |  |
| Purchases, sales and settlements, net |  |  | (51.4 | ) |  |  | (1.7 | ) |  |  | (1.4 | ) |  |  | (4.5 | ) |
| Balance at April 30, 2010 |  |  | 0.0 |  |  |  | 69.0 |  |  |  | 1.4 |  |  |  | 0.0 |  |
| Total unrealized losses included in other comprehensive income |  |  | 0.0 |  |  |  | (1.4 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Total realized losses included in earnings |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | 0.0 |  |
| Purchases, sales and settlements, net |  |  | 0.0 |  |  |  | (2.5 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Balance at April 29, 2011 |  | $ | 0.0 |  |  | $ | 65.1 |  |  | $ | 1.3 |  |  | $ | 0.0 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-11-171858:notes:185]
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,539.6 |  |  | $ | 1,539.6 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,417.4 |  |  |  | 5.0 |  |  |  | 2,412.4 |  |  |  | 0.0 |  |
| Other current assets |  |  | 4.1 |  |  |  | 3.7 |  |  |  | 0.4 |  |  |  | 0.0 |  |
| Long-term investments |  |  | 65.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 65.1 |  |
| Other non-current assets |  |  | 17.8 |  |  |  | 16.5 |  |  |  | 0.0 |  |  |  | 1.3 |  |
| Total |  | $ | 4,044.0 |  |  | $ | 1,564.8 |  |  | $ | 2,412.8 |  |  | $ | 66.4 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | (10.9 | ) |  | $ | 0.0 |  |  | $ | (10.9 | ) |  | $ | 0.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-11-171858:notes:186]
9. Financial Instruments and Fair Value

[0001193125-11-171858:notes:187]
We measure assets and liabilities at fair value based upon expected exit price, representing the amount that would be received on the sale of an asset or paid to transfer a liability, as the case may be, in an orderly transaction between market participants. As such, fair value is based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance provides a framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs, used in valuation techniques, are assigned a hierarchical level. The following are the hierarchical levels of inputs to measure fair value:

[0001193125-11-171858:notes:188]
Investments

[0001193125-11-171858:notes:189]
The following is a summary of investments at April 29, 2011 and April 30, 2010 (in millions):

[0001193125-11-171858:notes:190]
We record net unrealized gains or losses on available-for-sale securities that are determined to be temporary in other comprehensive income (loss). The following table shows the gross unrealized losses and fair values of our investments, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss position, at April 29, 2011 (in millions):

[0001193125-11-171858:notes:191]
The following table shows the gross unrealized losses and fair values of our investments, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss position, at April 30, 2010 (in millions):

[0001193125-11-171858:notes:192]
The following table presents the contractual maturities of our debt investments as of April 29, 2011 (in millions):

[0001193125-11-171858:notes:193]
Fair Value of Financial Instruments

[0001193125-11-171858:notes:194]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis as of April 29, 2011 (in millions):

[0001193125-11-171858:notes:195]
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,652.8 |  |  | $ | 0.0 |  |  | $ | 1,652.8 |  |  | $ | 0.0 |  |
| U.S. treasury and government debt securities |  |  | 661.8 |  |  |  | 5.0 |  |  |  | 656.8 |  |  |  | 0.0 |  |
| Municipal bonds |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 5.0 |  |  |  | 0.0 |  |  |  | 5.0 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 96.3 |  |  |  | 0.0 |  |  |  | 96.3 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,539.6 |  |  |  | 1,539.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 65.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 65.1 |  |
| Equity funds |  |  | 20.2 |  |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Investment in privately-held companies |  |  | 1.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.3 |  |
| Foreign currency contracts |  |  | 0.4 |  |  |  | 0.0 |  |  |  | 0.4 |  |  |  | 0.0 |  |
| Total |  | $ | 4,044.0 |  |  | $ | 1,564.8 |  |  | $ | 2,412.8 |  |  | $ | 66.4 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | (10.9 | ) |  | $ | 0.0 |  |  | $ | (10.9 | ) |  | $ | 0.0 |  |

[0001193125-11-171858:notes:196]
Reported as (in millions):

[0001193125-11-171858:notes:197]
Our foreign currency forward exchange contracts are also classified within Level 2. We determine the fair value of these instruments by considering the estimated amount we would pay or receive to terminate these agreements at the reporting date. We use observable inputs, including quoted prices in active markets for similar assets or liabilities. Our foreign currency derivative contracts are classified within Level 2 as the valuation inputs are based on quoted market prices of similar instruments in active markets.

[0001193125-11-171858:notes:198]
We classify items in Level 3 if the investments are valued using a pricing model or based on unobservable inputs in the market. These investments include auction rate securities and cost method investments. The table below provides a reconciliation of the beginning and ending balance of our Level 3 financial assets measured at fair value on a recurring basis using significant unobservable inputs as of April 29, 2011 (in millions).

[0001193125-11-171858:notes:199]
As of April 24, 2009, we held an investment in the Reserve Primary Fund (the Primary Fund), a money market fund which had suspended redemptions in September 2008 and was in the process of liquidating its portfolio of investments, with a recorded value of $51.6 million that had been previously written down from its par value of $60.9 million. During fiscal 2010, the Primary Fund made multiple distributions of its assets to its investors and we recognized an additional loss of $0.2 million in our income statement, and as of April 30, 2010, we had recovered $51.4 million of our recorded investment. Future distributions, if any, will be recognized as income upon receipt. During fiscal 2011 and 2010, we received $2.5 million and $1.0 million, respectively, in distributions from our investment in the Primary Fund.

[0001193125-11-171858:notes:200]
As of April 29, 2011 and April 30, 2010, we had auction rate securities (ARSs) with a par value of $71.3 million and $73.8 million, respectively, and an estimated fair value of $65.1 million and $69.0 million, respectively, which are classified as long-term investments. All of our ARSs are backed by pools of student loans guaranteed by the U.S. Department of Education. As of April 29, 2011, we recorded cumulative net temporary impairment charges of $4.1 million within AOCI. In addition, we recorded other-than-temporary impairment charges of $2.1 million in other income (expense), net, during fiscal 2009 based on an analysis of the fair value and marketability of these investments. We estimated the fair value for each individual ARS using an income (discounted cash flow) approach that incorporates both observable and unobservable inputs to discount the expected future cash flows. Key inputs into the discounted cash flow analysis include managements' expectation of when the principal amount will be recovered either through redemption at par, or some other refinancing event by the issuer; and marketability adjustments. Based on our ability to access our cash and other short-term investments, our expected operating cash flows, and our other sources of cash, we do not intend to sell these investments prior to recovery of value. We will continue to monitor our ARS investments in light of the current debt market environment and evaluate our accounting for these investments.

[0001193125-11-171858:notes:201]
As of April 29, 2011 and April 30, 2010, we held investments in a private equity fund of $1.3 million and $1.4 million, respectively. During fiscal 2011, we recorded a net other-than-temporary impairment charge of $0.1 million on the private equity fund. During fiscal 2010, we recorded realized gains of $0.8 million on this investment and $2.6 million on equity investments in privately held companies. During fiscal 2009, we recorded $6.3 million of other-than-temporary impairment charges on certain of the equity investments in privately held companies and adjusted their carrying amount to fair value, as we deemed the decline in the value of those assets to be other-than-temporary.

[0001193125-11-171858:notes:202]
Other Fair Value Disclosures

[0001193125-11-171858:notes:203]
The fair value of certain of our financial instruments that are not measured at fair value, including accounts receivable, accounts payable, accrued compensation, and other current liabilities, approximates the carrying amount because of their short maturities. The fair value of our Notes is disclosed in Note 10 of the accompanying consolidated financial statements and was determined using quoted market prices for those securities.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-11-171858:notes:204]
Foreign Currency Translation — For subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-11-171858:notes:205]
7. Goodwill and Purchased Intangible Assets

[0001193125-11-171858:notes:206]
Goodwill activity is summarized as follows (in millions):

[0001193125-11-171858:notes:207]
| April 24, 2009 |  | $ | 681.0 |  |
| Additions |  |  | 0.0 |  |
| April 30, 2010 |  |  | 681.0 |  |
| Additions |  |  | 79.3 |  |
| April 29, 2011 |  | $ | 760.3 |  |

[0001193125-11-171858:notes:208]
We conducted our annual goodwill impairment test in the three month period ended April 29, 2011. Based on this analysis, we determined that there was no impairment to goodwill. We will continue to monitor conditions and changes that could indicate that our recorded goodwill may be impaired.

[0001193125-11-171858:notes:209]
Identified intangible assets are summarized as follows (in millions):

[0001193125-11-171858:notes:210]
|  |  | April 29, 2011 |  |  | April 30, 2010 |  |
|  |  | GrossAssets |  |  | AccumulatedAmortization |  |  | NetAssets |  |  | GrossAssets |  |  | AccumulatedAmortization |  |  | NetAssets |  |
| Identified Intangible Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Existing technology |  | $ | 66.1 |  |  | $ | (23.2 | ) |  | $ | 42.9 |  |  | $ | 75.1 |  |  | $ | (55.5 | ) |  | $ | 19.6 |  |
| Trademarks and tradenames |  |  | 7.7 |  |  |  | (5.5 | ) |  |  | 2.2 |  |  |  | 6.4 |  |  |  | (4.3 | ) |  |  | 2.1 |  |
| Customer contracts/relationships |  |  | 12.0 |  |  |  | (4.6 | ) |  |  | 7.4 |  |  |  | 12.2 |  |  |  | (8.8 | ) |  |  | 3.4 |  |
| Covenants not to compete |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | 0.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Total identified intangible assets |  | $ | 86.4 |  |  | $ | (33.4 | ) |  | $ | 53.0 |  |  | $ | 93.7 |  |  | $ | (68.6 | ) |  | $ | 25.1 |  |

[0001193125-11-171858:notes:211]
During fiscal 2011, we retired $52.9 million of fully amortized intangible assets relating to prior acquisitions.

[0001193125-11-171858:notes:212]
Amortization expense for identified intangible assets is summarized below (in millions):

[0001193125-11-171858:notes:213]
In fiscal 2009, we ceased development and availability of our SnapMirror for Open Systems product, and as a result recorded impairment charges of $14.9 million attributable to identified intangible assets related to this product line.

[0001193125-11-171858:notes:214]
As of April 29, 2011, future amortization expense related to identifiable intangible assets is as follows (in millions):

[0001193125-11-171858:notes:215]
| Fiscal Year |  | Amount |  |
| 2012 |  | $ | 16.8 |  |
| 2013 |  |  | 14.4 |  |
| 2014 |  |  | 8.3 |  |
| 2015 |  |  | 7.5 |  |
| 2016 |  |  | 3.4 |  |
| Thereafter |  |  | 2.6 |  |
| Total |  | $ | 53.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-11-171858:notes:216]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Acquisition-related intangible assets are amortized on a straight-line basis over their economic lives of five years for patents, four to six years for existing technology, two to eight years for customer relationships, one to three years for covenants not to compete and two to seven years for trademarks and tradenames as we believe this method would most closely reflect the pattern in which the economic benefits of the assets will be consumed.

[0001193125-11-171858:notes:217]
Goodwill is measured and tested for impairment on an annual basis in the fourth quarter of our fiscal year or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. The performance of the test involves a two-step process. The first step requires comparing the fair value of the each of our reporting units to its net book value, including goodwill. We have three reporting units, the fair values of which are determined based on an allocation of our entity level market capitalization, as determined through quoted market prices. A potential impairment exists if the fair value of the reporting unit is lower than its net book value. The second step of the process is only performed if a potential impairment exists, and it involves determining the difference between the fair value of the reporting unit's net assets other than goodwill to the fair value of the reporting unit and if the difference is less than the net book value of goodwill, an impairment exists and is recorded. We have not been required to perform this second step of the process because the fair value of our reporting units have exceeded the net book value at every measurement date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001193125-11-171858:notes:218]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) discounted expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated net revenue and cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in a reduction in net income or an increase to net loss in the period when such determinations are made.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-11-171858:notes:219]
14. Income Taxes

[0001193125-11-171858:notes:220]
Income before income taxes is as follows (in millions):

[0001193125-11-171858:notes:221]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Domestic |  | $ | 307.6 |  |  | $ | 60.2 |  |  | $ | (250.9 | ) |
| Foreign |  |  | 486.5 |  |  |  | 386.8 |  |  |  | 259.2 |  |
| Total |  | $ | 794.1 |  |  | $ | 447.0 |  |  | $ | 8.3 |  |

[0001193125-11-171858:notes:222]
The provision for (benefit from) income taxes consists of the following (in millions):

[0001193125-11-171858:notes:223]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 113.0 |  |  | $ | 33.6 |  |  | $ | 16.2 |  |
| State |  |  | (1.3 | ) |  |  | 1.5 |  |  |  | 40.8 |  |
| Foreign |  |  | 35.6 |  |  |  | 22.8 |  |  |  | 11.2 |  |
| Total current |  |  | 147.3 |  |  |  | 57.9 |  |  |  | 68.2 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (27.5 | ) |  |  | (4.6 | ) |  |  | (78.7 | ) |
| State |  |  | 13.7 |  |  |  | (2.9 | ) |  |  | (52.0 | ) |
| Foreign |  |  | (12.5 | ) |  |  | (3.8 | ) |  |  | 6.2 |  |
| Total deferred |  |  | (26.3 | ) |  |  | (11.3 | ) |  |  | (124.5 | ) |
| Provision for (benefit from) income taxes |  | $ | 121.0 |  |  | $ | 46.6 |  |  | $ | (56.3 | ) |

[0001193125-11-171858:notes:224]
The provision (benefit) for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001193125-11-171858:notes:225]
The income tax benefits (charges) associated with dispositions from employee stock transactions were recognized as additional paid-in capital (in millions):

[0001193125-11-171858:notes:226]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001193125-11-171858:notes:227]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |
| Deferred Tax Assets: |  |  |  |  |  |  |  |  |
| Inventory reserves and capitalization |  | $ | 6.6 |  |  | $ | 5.1 |  |
| Reserves and accruals not currently deductible |  |  | 50.2 |  |  |  | 49.1 |  |
| Net operating loss and credit carryforwards |  |  | 120.3 |  |  |  | 75.3 |  |
| Stock-based compensation |  |  | 74.1 |  |  |  | 90.2 |  |
| Deferred revenue |  |  | 176.2 |  |  |  | 168.7 |  |
| Capitalized research and development expenditures |  |  | 3.3 |  |  |  | 6.6 |  |
| Investment losses |  |  | 0.0 |  |  |  | 2.4 |  |
| Conditional royalty |  |  | 13.6 |  |  |  | 13.6 |  |
| Other |  |  | 0.5 |  |  |  | 1.0 |  |
| Gross deferred tax assets |  |  | 444.8 |  |  |  | 412.0 |  |
| Valuation allowance |  |  | (45.5 | ) |  |  | (28.3 | ) |
| Total deferred tax assets |  |  | 399.3 |  |  |  | 383.7 |  |
| Deferred Tax Liabilities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 11.9 |  |  |  | 8.0 |  |
| Acquisition intangibles |  |  | 7.4 |  |  |  | 8.5 |  |
| Convertible notes |  |  | 28.2 |  |  |  | 35.2 |  |
| Other |  |  | (1.9 | ) |  |  | (1.0 | ) |
| Total deferred tax liabilities |  |  | 45.6 |  |  |  | 50.7 |  |
| Net deferred tax assets |  | $ | 353.7 |  |  | $ | 333.0 |  |

[0001193125-11-171858:notes:228]
Current and noncurrent net deferred tax assets for fiscal 2011 and 2010 are as follows (in millions):

[0001193125-11-171858:notes:229]
The valuation allowance increased by $17.2 million and $0.3 million in fiscal 2011 and 2010, respectively. The change in valuation allowance in fiscal 2011 was primarily related to the realizability of state credit carryforwards as a result of the expected application of the California single sales factor apportionment election. The change in valuation allowance in fiscal 2010 was primarily related to changes of blended state tax rates.

[0001193125-11-171858:notes:230]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001193125-11-171858:notes:231]
|  |  | Year Ended |  |
|  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Balance at beginning of period |  | $ | 134.5 |  |  | $ | 110.1 |  |  | $ | 97.8 |  |
| Additions based on tax positions related to the current year |  |  | 12.5 |  |  |  | 34.9 |  |  |  | 13.8 |  |
| Additions for tax positions of prior years |  |  | 26.3 |  |  |  | 3.7 |  |  |  | 0.7 |  |
| Decreases for tax positions of prior years |  |  | (40.0 | ) |  |  | (14.2 | ) |  |  | (2.2 | ) |
| Balance at end of period |  | $ | 133.3 |  |  | $ | 134.5 |  |  | $ | 110.1 |  |

[0001193125-11-171858:notes:232]
Of the $133.3 million of unrecognized tax benefits at April 29, 2011, $104.2 million has been recorded and included in other long-term liabilities, of which $92.7 million, if recognized, would affect our provision for income taxes.

[0001193125-11-171858:notes:233]
We recognize accrued interest and penalties related to unrecognized foreign tax benefits in the income tax provision. During the fiscal years ended 2005 through 2011, we recognized total accrued interest and penalties of approximately $1.0 million and have included this accrual in our liability for unrecognized tax benefits.

[0001193125-11-171858:notes:234]
During fiscal 2010, we recorded a $32.1 million charge to additional paid in capital related to the establishment of a $26.1 million tax liability to provide for the uncertainty relating to the tax treatment of the termination of the Lehman Brothers bond hedge, as well a $6.0 million deferred tax liability for related temporary tax return differences in the valuation of the convertible debt as a result of the transaction.

[0001193125-11-171858:notes:235]
We are subject to taxation in the United States, various states, and several foreign jurisdictions.

[0001193125-11-171858:notes:236]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001193125-11-171858:notes:237]
Tax Years Subject to Examination for Major Tax Jurisdictions at April 29, 2011

[0001193125-11-171858:notes:238]
In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal year 2000, in that we have net operating loss carryforwards from these years that could be subject to adjustment, if and when utilized.

[0001193125-11-171858:notes:239]
We are currently undergoing federal income tax audits in the United States and several foreign tax jurisdictions. The rights to some of our intellectual property (IP) are owned by certain of our foreign subsidiaries, and payments are made between U.S. and foreign tax jurisdictions relating to the use of this IP in a qualified cost sharing arrangement. In recent years, several other U.S. companies have had their foreign IP arrangements challenged as part of IRS examinations, which has resulted in material proposed assessments and/or litigation with respect to those companies.

[0001193125-11-171858:notes:240]
During fiscal year 2009, we received Notices of Proposed Adjustments from the IRS in connection with a federal income tax audit of our fiscal 2003 and 2004 tax returns. We filed a protest with the IRS in response to the Notices of Proposed Adjustments and subsequently received a rebuttal from the IRS examination team in response to our protest. In April 2011, we executed a closing agreement with the IRS Appeals Office to close this examination. The Notices of Proposed Adjustments in this audit focused primarily on issues relating to the timing and the amount of income recognized, deductions taken and on the level of cost allocations made to foreign operations during the audit years. The settlement of our 2003-2004 IRS examination resulted in additional liability of $10.8 million, which is almost entirely offset by net operating loss carryforwards. As a result of the examination settlement, we have reduced our reserve for uncertain tax positions and recognized a net benefit of $21.1 million.

[0001193125-11-171858:notes:241]
We do not include unrealized stock option attributes as components of our gross deferred tax assets and corresponding valuation allowance disclosures. The tax effected amounts of gross unrealized net operating loss and business tax credit carryforwards are $414.2 million as of April 29, 2011, which will result in additional paid in capital if and when realized as a reduction in taxes otherwise paid.

[0001193125-11-171858:notes:242]
As of April 29, 2011, the amount of accumulated unremitted earnings from our foreign subsidiaries is approximately $872.1 million.

[0001193125-11-171858:notes:243]
Network Appliance Systems India Pvt. Ltd., our Indian subsidiary, received a tax holiday from the Indian tax authorities attributed to its call center and research and development activities effective June 6, 2003. These activities qualify under the Software Technology Park of India (STPI) incentive for the development and manufacture of computer software and information technology enabled services. Under this tax holiday, net taxable income derived from call center and research and development activities is exempt from Indian taxation. The income tax holiday expired on March 31, 2011. Other tax and customs benefits remain available. Notwithstanding qualification for the income tax holiday, minimum alternate tax rules in India effective for us as of fiscal 2009 overrode the full tax exemption. For fiscal 2010, we were subject to a minimum alternate tax on this income in India at a rate of 16.99%. The minimum alternate tax paid is eligible for credit against regular tax paid in future years. The credits may be carried forward for ten years.

[0001193125-11-171858:notes:244]
In April 2010 our Dutch subsidiary received a favorable tax ruling from the Dutch tax authorities effective May 1, 2010 that replaces the previous Dutch tax ruling that expired on April 30, 2010. This ruling results in both a lower level of earnings subject to tax in the Netherlands and an extension of the expiration date to April 30, 2015.

[0001193125-11-171858:notes:245]
As of April 29, 2011, the federal, and state net operating loss carryforwards for income tax purposes were approximately $781.2 million and $352.9 million, respectively. The federal net operating loss carryforwards will begin to expire in fiscal 2022. State net operating losses of $26.4 million will expire in fiscal years 2012 through 2014; $11.3 million will expire in fiscal year 2015 while the remaining $315.2 million will expire in fiscal years 2016 through 2031.

[0001193125-11-171858:notes:246]
As of April 29, 2011, we had federal and state tax credit carryforwards of approximately $108.9 million and $93.3 million, respectively, available to offset future income tax liabilities. Federal tax credit carryforwards of $55.7 million will begin to expire in fiscal years 2016 through 2023, while the remaining $53.2 million will expire in fiscal years beginning 2024. State tax credits of $0.04 million will expire in fiscal years 2012 through 2014, while the remaining $93.3 million is available indefinitely to reduce cash taxes otherwise payable. As discussed above, most of the net operating loss and tax credit carryovers, if realized, will be recognized as additional paid in capital in that they are employee stock option tax attributes.

[0001193125-11-171858:notes:247]
On December 17, 2010, the Tax Relief Unemployment Insurance Reauthorization, and Job Creation Act of 2010 (the Act) was signed into law. Under the Act, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2009, and before January 1, 2012.

[0001193125-11-171858:notes:248]
During fiscal year 2010, the IRS commenced the examination of our fiscal 2005 through 2007 federal income tax returns, and, in addition, the California Franchise Tax Board began the examination of our fiscal 2007 and 2008 California income tax returns. These audits are currently in progress.

[0001193125-11-171858:notes:249]
If, upon the conclusion of these audits, the ultimate determination of taxes owed in the U.S. is for an amount in excess of the tax provision we have recorded in the applicable period or subsequently reserved for, our overall tax expense and effective tax rate could be adversely impacted in the period of adjustment.

[0001193125-11-171858:notes:250]
On September 17, 2010, the Danish tax authorities issued a decision concluding that distributions declared in 2005 and 2006 from the Company's Danish subsidiary, for which the Company has not paid or accrued any taxes, are subject to Danish at-source dividend withholding tax. The Company believes the assessment is without merit and has appealed this assessment decision with the Danish National Tax Tribunal.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-11-171858:notes:251]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001193125-11-171858:notes:252]
Determining the liability for uncertain tax positions requires us to make significant estimates and judgments as to whether, and the extent to which, additional taxes may be due based on potential tax audit issues in the U.S. and other tax jurisdictions throughout the world. Our estimates are based on the outcomes of previous audits, as well as the precedents set in cases in which others have taken similar tax positions to those taken by us. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related change in our tax provision during the period in which we make such a determination.

[0001193125-11-171858:notes:253]
The accounting guidance for income taxes prescribes a comprehensive model for how a company should recognize, measure, present, and disclose in its financial statements uncertain tax positions that we have taken or expect to take on a tax return (including a decision whether to file or not to file a return in a particular jurisdiction). We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. See note 14 for further discussion.


## us-gaap:InventoryPolicyTextBlock

[0001193125-11-171858:notes:254]
Inventories — Inventories are stated at the lower of cost or market, which approximates actual cost on a first-in, first out basis. We write down for excess and obsolete inventory based on the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-11-171858:notes:255]
Property and Equipment — Property and equipment are recorded at cost. Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001193125-11-171858:notes:256]
Construction in progress will be amortized over the estimated useful lives of the respective assets when they are ready for their intended use.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-11-171858:notes:257]
19. Selected Quarterly Financial Data

[0001193125-11-171858:notes:258]
Selected quarterly financial data for fiscal 2011 and 2010 was as follows (in millions, except per share amounts):

[0001193125-11-171858:notes:259]
|  |  | Year Ended April 29, 2011 |  |
|  |  | Q1 (1) |  |  | Q2 (1) |  |  | Q3 (1) |  |  | Q4 (2) |  |
| Net revenues |  | $ | 1,153.7 |  |  | $ | 1,251.0 |  |  | $ | 1,289.6 |  |  | $ | 1,428.3 |  |
| Gross profit |  |  | 737.8 |  |  |  | 816.5 |  |  |  | 846.2 |  |  |  | 928.2 |  |
| Income before income taxes |  |  | 171.0 |  |  |  | 202.3 |  |  |  | 212.7 |  |  |  | 208.1 |  |
| Net income |  |  | 150.7 |  |  |  | 175.4 |  |  |  | 186.4 |  |  |  | 160.6 |  |
| Net income per share, basic |  |  | 0.43 |  |  |  | 0.49 |  |  |  | 0.51 |  |  |  | 0.44 |  |
| Net income per share, diluted |  |  | 0.40 |  |  |  | 0.45 |  |  |  | 0.46 |  |  |  | 0.40 |  |

[0001193125-11-171858:notes:260]
|  |  | Year Ended April 30, 2010 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net revenues |  | $ | 838.0 |  |  | $ | 910.0 |  |  | $ | 1,011.7 |  |  | $ | 1,171.7 |  |
| Gross profit |  |  | 522.5 |  |  |  | 606.7 |  |  |  | 641.5 |  |  |  | 748.5 |  |
| Income before income taxes |  |  | 59.2 |  |  |  | 106.0 |  |  |  | 117.9 |  |  |  | 163.9 |  |
| Net income |  |  | 51.7 |  |  |  | 95.7 |  |  |  | 107.9 |  |  |  | 145.1 |  |
| Net income per share, basic |  |  | 0.15 |  |  |  | 0.28 |  |  |  | 0.32 |  |  |  | 0.42 |  |
| Net income per share, diluted |  |  | 0.15 |  |  |  | 0.27 |  |  |  | 0.30 |  |  |  | 0.40 |  |

[0001193125-11-171858:notes:261]
| (1) | The amounts previously reported in our Quarterly Reports on Form 10-Q for fiscal 2011 have been adjusted to reflect the retrospective adoption of new revenue recognition accounting standards, which is discussed more fully in Note 2. The impact from the adoption was as follows (in millions, except per share amounts): |

[0001193125-11-171858:notes:262]
|  |  | Year Ended April 29, 2011 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |
| Net revenues |  | $ | 15.9 |  |  | $ | 43.6 |  |  | $ | 21.5 |  |
| Gross profit |  |  | 13.4 |  |  |  | 15.4 |  |  |  | 22.4 |  |
| Income before income taxes |  |  | 13.4 |  |  |  | 15.4 |  |  |  | 22.4 |  |
| Net income |  |  | 8.9 |  |  |  | 10.8 |  |  |  | 13.9 |  |
| Net income per share, basic |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.04 |  |
| Net income per share, diluted |  |  | 0.02 |  |  |  | 0.03 |  |  |  | 0.04 |  |

[0001193125-11-171858:notes:263]
| (2) | As a result of the adoption of new revenue recognition accounting standards, fourth quarter fiscal 2011 net revenues and net income were higher by $48.2 million and $19.4 million, respectively |

[0001193125-11-171858:notes:264]
In the fourth quarter of fiscal 2011 we identified classification errors in previously issued interim condensed consolidated balance sheets as of October 29, 2010 and January 28, 2011, related to our 1.75% convertible senior notes due June 2013 (the "Notes") which had met the conversion threshold set forth in the Notes. See note 10 for the further discussion regarding the Notes. The Notes were previously reported as a long term liability of $1,125.4 million and $1,137.7 million as of October 29, 2010 and January 28, 2011, and should have been reflected as a current liability. In addition $139.6 million and $127.3 million as of October 29, 2010 and January 28, 2011, respectively, was recorded within additional paid-in-capital and should have been presented as temporary equity. Management has determined that the foregoing errors are not material to the previously issued interim condensed consolidated financial statements. The Company made these reclassifications in the consolidated balance sheet as of April 29, 2011, and will prospectively correct the classification errors in our interim condensed consolidated financial statements during fiscal 2012. The errors did not affect the previously reported results of operations or cash flows of the Company.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-11-171858:notes:265]
13. Restructuring and Other Charges

[0001193125-11-171858:notes:266]
Fiscal 2011 restructuring charges primarily related to charges taken as a result of the Akorri acquisition and adjustments to future lease commitments and employee severance costs associated with our fiscal 2009 restructuring plan.

[0001193125-11-171858:notes:267]
Activities related to the restructuring reserves for fiscal 2011, 2010 and 2009 were as follows (in millions):

[0001193125-11-171858:notes:268]
|  |  | Severance-RelatedCharges |  |  | Facilities |  |  | ContractCancellationCosts |  |  | Other |  |  | FixedAssetsWrite-off |  |  | IntangibleWrite-off |  |  | Total |  |
| Reserve balance at April 25, 2008 |  | $ | 0.0 |  |  | $ | 1.9 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 1.9 |  |
| Restructuring and other charges |  |  | 28.0 |  |  |  | 4.5 |  |  |  | 0.3 |  |  |  | 2.9 |  |  |  | 3.8 |  |  |  | 14.9 |  |  |  | 54.4 |  |
| Cash payments |  |  | (17.6 | ) |  |  | (1.0 | ) |  |  | (0.1 | ) |  |  | (1.8 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (20.5 | ) |
| Non-cash charges |  |  | 0.0 |  |  |  | 0.3 |  |  |  | 0.0 |  |  |  | 0.1 |  |  |  | (3.8 | ) |  |  | (14.9 | ) |  |  | (18.3 | ) |
| Foreign currency changes |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (0.3 | ) |
| Reserve balance at April 24, 2009 |  |  | 10.3 |  |  |  | 5.5 |  |  |  | 0.2 |  |  |  | 1.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.2 |  |
| Restructuring and other charges |  |  | 0.6 |  |  |  | 1.6 |  |  |  | (0.1 | ) |  |  | 0.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 2.5 |  |
| Cash payments |  |  | (11.1 | ) |  |  | (3.3 | ) |  |  | (0.1 | ) |  |  | (1.5 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (16.0 | ) |
| Foreign currency changes |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.4 |  |
| Reserve balance at April 30, 2010 |  |  | 0.0 |  |  |  | 4.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 4.1 |  |
| Restructuring and other charges |  |  | 2.4 |  |  |  | (0.6 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.8 |  |
| Cash payments |  |  | (2.4 | ) |  |  | (3.5 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (5.9 | ) |
| Foreign currency changes |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.1 |  |
| Reserve balance at April 29, 2011 |  | $ | 0.0 |  |  | $ | 0.1 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 0.1 |  |

[0001193125-11-171858:notes:269]
Akorri Acquisition Restructuring

[0001193125-11-171858:notes:270]
In the fourth quarter of 2011, we incurred restructuring charges relating to the acquisition of Akorri. Restructuring expenses of $2.4 million were accrued for and paid out for severance-related charges during this period. As of April 29, 2011 we had approximately $0.1 million relating to abandoned lease-related restructuring reserves resulting from this acquisition.

[0001193125-11-171858:notes:271]
Fiscal 2009 Restructuring Plans

[0001193125-11-171858:notes:272]
In February 2009, we announced our decision to execute a worldwide restructuring program, which included a reduction in workforce, the closing or downsizing of certain facilities, and the establishment of a plan to outsource certain internal activities. In December 2008, we announced our decision to cease the development and availability of our SnapMirror® for Open Systems product, which was originally acquired through our acquisition of Topio in fiscal 2007. As part of this decision, we also announced the closure of our engineering facility in Haifa, Israel. As of April 29, 2011, we had no further facilities-related lease payment reserves related to these activities.

[0001193125-11-171858:notes:273]
Fiscal 2002 Restructuring Plan

[0001193125-11-171858:notes:274]
As of April 29, 2011, we have no material balances remaining in facility restructuring reserves established as part of a restructuring plan in fiscal 2002 related to future lease commitments on exited facilities, net of expected sublease income.

[0001193125-11-171858:notes:275]
The total restructuring reserve balance of $0.1 million as of April 29, 2011 was included in other current liabilities.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-11-171858:notes:276]
Revenue Recognition — We recognize revenue when:

[0001193125-11-171858:notes:277]
|  | • |  | Persuasive evidence of an arrangement exists: It is our customary practice to have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers, or distributors. |

[0001193125-11-171858:notes:278]
|  | • |  | Delivery has occurred: Our product is physically delivered to our customers, generally with standard transfer terms such as FOB origin. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. If undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement, delivery is not considered to have occurred. |

[0001193125-11-171858:notes:279]
|  | • |  | The fee is fixed or determinable: Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001193125-11-171858:notes:280]
|  | • |  | Collection is reasonably assured: If there is considerable doubt surrounding the credit worthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001193125-11-171858:notes:281]
Our multiple element arrangements include our systems and one or more of the following undelivered elements: software entitlements and maintenance (SEM), premium hardware maintenance, and storage review services. Our SEM entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes, and patch releases. Premium hardware maintenance services include contracts for technical support and minimum response times. Revenues from SEM, premium hardware maintenance services and storage review services are recognized ratably over the contractual term, generally from one to five years. We also offer extended service contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the warranty term; revenues from these contracts are recognized ratably over the contract term. We also sell professional services either on a time and materials basis or under fixed price standard projects; we recognize revenue for these services as they are performed. Revenue from hardware installation services is recognized in the period the services are delivered.

[0001193125-11-171858:notes:282]
In October 2009, the FASB amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

[0001193125-11-171858:notes:283]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

[0001193125-11-171858:notes:284]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

[0001193125-11-171858:notes:285]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

[0001193125-11-171858:notes:286]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010.

[0001193125-11-171858:notes:287]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001193125-11-171858:notes:288]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or return rights for the delivered elements.

[0001193125-11-171858:notes:289]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

[0001193125-11-171858:notes:290]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

[0001193125-11-171858:notes:291]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

[0001193125-11-171858:notes:292]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

[0001193125-11-171858:notes:293]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-11-171858:notes:294]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

[0001193125-11-171858:notes:295]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is SEM and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

[0001193125-11-171858:notes:296]
Net revenues and net income for the year ended April 29, 2011 were higher by $129.2 million and $53.0 million, respectively, as a result of adoption of the new revenue recognition accounting standards. We are not able to reasonably estimate the effect of adopting these standards on future financial periods as the impact will vary based on the nature and volume of new or materially modified sales transactions in any given period. In terms of the timing and pattern of revenue recognition, we expect that these new accounting standards will facilitate our efforts to optimize our offerings due to better alignment between the economics of an arrangement and the related accounting. This may lead us to engage in new go-to-market practices in the future. In particular, we expect that the amended accounting standards will enable us to better integrate products and services (for which we have not established VSOE) into existing offerings and solutions. As our go-to-market strategies evolve, we may modify our pricing practices in the future, which could result in changes in selling prices, including both VSOE and BESP.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-11-171858:notes:297]
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Accumulated translation adjustments |  | $ | 11.6 |  |  | $ | 1.2 |  |  | $ | (0.3 | ) |
| Accumulated unrealized gain (loss) on available-for-sale investments |  |  | 3.4 |  |  |  | 0.9 |  |  |  | (4.4 | ) |
| Accumulated unrealized gain (loss) on derivatives qualifying as cash flow hedges |  |  | (2.2 | ) |  |  | 0.7 |  |  |  | (0.5 | ) |
| Total accumulated other comprehensive income (loss) |  | $ | 12.8 |  |  | $ | 2.8 |  |  | $ | (5.2 | ) |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-11-171858:notes:298]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Cost of product revenues |  | $ | 3.6 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |
| Cost of service revenues |  |  | 14.4 |  |  |  | 14.3 |  |  |  | 12.3 |  |
| Sales and marketing |  |  | 81.5 |  |  |  | 73.7 |  |  |  | 65.1 |  |
| Research and development |  |  | 44.5 |  |  |  | 38.5 |  |  |  | 37.9 |  |
| General and administrative |  |  | 31.2 |  |  |  | 29.3 |  |  |  | 22.2 |  |
| Total stock-based compensation expense |  | $ | 175.2 |  |  | $ | 159.8 |  |  | $ | 140.8 |  |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-11-171858:notes:299]
|  |  | Year Ended |  |
|  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 24,2009 |  |
| Weighted-average fair value per right granted |  | $ | 15.86 |  |  | $ | 8.86 |  |  | $ | 6.17 |  |
| Shares issued under the ESPP |  |  | 6.0 |  |  |  | 5.1 |  |  |  | 3.3 |  |
| Weighted average price of shares issued |  | $ | 11.50 |  |  | $ | 10.49 |  |  | $ | 14.96 |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001193125-11-171858:notes:300]
|  |  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices |  |  | NumberOutstandingat April 29,2011 |  |  | WeightedAverageRemainingContractual Life(In Years) |  |  | WeightedAverageExercisePrice |  |  | NumberExercisable |  |  | WeightedAverageExercisablePrice |  |
|  | $ 0.55 |  |  | $ | 12.17 |  |  |  | 0.9 |  |  |  | 2.38 |  |  | $ | 9.63 |  |  |  | 0.8 |  |  | $ | 9.40 |  |
|  | 12.25 |  |  |  | 13.56 |  |  |  | 2.9 |  |  |  | 4.57 |  |  |  | 13.50 |  |  |  | 1.2 |  |  |  | 13.48 |  |
|  | 13.63 |  |  |  | 20.52 |  |  |  | 2.5 |  |  |  | 2.29 |  |  |  | 17.05 |  |  |  | 2.3 |  |  |  | 17.06 |  |
|  | 20.61 |  |  |  | 20.86 |  |  |  | 2.5 |  |  |  | 4.73 |  |  |  | 20.71 |  |  |  | 1.1 |  |  |  | 20.73 |  |
|  | 20.92 |  |  |  | 22.93 |  |  |  | 2.5 |  |  |  | 3.59 |  |  |  | 22.10 |  |  |  | 1.8 |  |  |  | 22.10 |  |
|  | 22.94 |  |  |  | 24.72 |  |  |  | 2.6 |  |  |  | 4.33 |  |  |  | 24.01 |  |  |  | 1.5 |  |  |  | 23.89 |  |
|  | 24.98 |  |  |  | 31.73 |  |  |  | 2.5 |  |  |  | 3.93 |  |  |  | 29.15 |  |  |  | 2.3 |  |  |  | 29.20 |  |
|  | 31.89 |  |  |  | 33.54 |  |  |  | 3.3 |  |  |  | 4.77 |  |  |  | 33.22 |  |  |  | 1.5 |  |  |  | 32.89 |  |
|  | 33.77 |  |  |  | 39.83 |  |  |  | 2.5 |  |  |  | 5.18 |  |  |  | 37.26 |  |  |  | 1.2 |  |  |  | 37.27 |  |
|  | 40.30 |  |  |  | 58.99 |  |  |  | 2.3 |  |  |  | 6.41 |  |  |  | 50.43 |  |  |  | 0.2 |  |  |  | 46.34 |  |
|  | $ 0.55 |  |  | $ | 58.99 |  |  |  | 24.5 |  |  |  | 4.34 |  |  | $ | 26.62 |  |  |  | 13.9 |  |  | $ | 23.81 |  |


## us-gaap:ScheduleOfSubsequentEventsTextBlock

[0001193125-11-171858:notes:301]
20. Subsequent Event

[0001193125-11-171858:notes:302]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio external storage systems business (ESG) of LSI Corporation (LSI). We paid LSI $480 million in cash and also assumed certain assets and liabilities related to ESG. Over the next three years, LSI will pay us between $13.0 million and $14.5 million to service certain LSI customer warranties. This acquisition will enable us to address emerging and fast-growing market segments such as video, including full-motion video capture and digital video surveillance, as well as high performance computing applications, such as genomics sequencing and scientific research.

[0001193125-11-171858:notes:303]
We are in the process of completing a purchase price allocation for this acquisition. We currently expect between $250.0 million and $350.0 million of the purchase price to be allocated to identifiable intangible assets other than goodwill in the final purchase price allocation. A preliminary purchase price allocation is currently expected to be included in our consolidated financial statements for the quarter ending July 29, 2011.

[0001193125-11-171858:notes:304]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of ESG as if it were consummated on April 25, 2009. Due to differing fiscal year ends of NetApp and ESG, the unaudited pro forma condensed combined financial information is based on the historical results of NetApp for fiscal 2011 and fiscal 2010, respectively and the historical results of ESG for the twelve month periods ended April 3, 2011 and April 4, 2010, respectively. The unaudited pro forma condensed combined financial information is presented for informational purposes only and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 25, 2009 (the beginning of the earliest period presented) and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

[0001193125-11-171858:notes:305]
An adjustment of $2.5 million has been reflected in the unaudited pro forma condensed combined information to exclude acquisition related costs directly attributable to the acquisition because they will not have a continuing impact on the combined results.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-11-171858:notes:306]
SCHEDULE II

[0001193125-11-171858:notes:307]
NETAPP, INC.

[0001193125-11-171858:notes:308]
VALUATION AND QUALIFYING ACCOUNTS

[0001193125-11-171858:notes:309]
Years Ended April 29, 2011, April 30, 2010 and April 24, 2009

[0001193125-11-171858:notes:310]
(In millions)


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-11-171858:notes:311]
2. Significant Accounting Policies

[0001193125-11-171858:notes:312]
Fiscal Year — We operate on a 52-week or 53-week year ending on the last Friday in April. Fiscal 2011 and 2009 were 52-week fiscal years and fiscal 2010 was a 53-week fiscal year.

[0001193125-11-171858:notes:313]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.

[0001193125-11-171858:notes:314]
Short-Term Investments — Short-term investments consist of marketable debt or equity securities which are classified as available-for-sale and are recognized at fair value. The determination of fair value is further detailed in Note 9 of the accompanying consolidated financial statements. We regularly review our investment portfolio to identify and evaluate investments that have indications of possible impairment. Factors considered in determining whether a loss is other-than-temporary include: the length of time and extent to which the fair market value has been lower than the cost basis, the financial condition and near-term prospects of the investee, credit quality, likelihood of recovery, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in fair market value. We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001193125-11-171858:notes:315]
Unrealized gains and temporary losses, net of related taxes, are included with accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to results of operations. The amortization of premiums and discounts on the investments and realized gains and losses related to investments are included in results of operations. Other-than-temporary impairments on available-for-sale debt securities are determined to be either credit losses or losses due to other factors. Credit losses are recognized in our results of operations and other losses are included in AOCI.

[0001193125-11-171858:notes:316]
Fair Value Measurements and Impairments — All of our available-for-sale investments and nonmarketable equity securities are subject to a periodic impairment review. Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. This determination requires significant judgment.

[0001193125-11-171858:notes:317]
For publicly traded investments, impairment is determined based upon the specific facts and circumstances present at the time, including factors such as current economic and market conditions, the credit rating of the security's issuer, the length of time an investment's fair value has been below our carrying value, the extent to which fair value was below cost, and our ability and intent to hold investments for a period of time sufficient to allow for anticipated recovery in value. If an investment's decline in fair value, caused by factors other than changes in interest rates, is deemed to be other-than-temporary, we reduce its carrying value to its estimated fair value, as determined based on quoted market prices or liquidation values. Declines in value judged to be other-than-temporary, if any, are recorded in operations as incurred.

[0001193125-11-171858:notes:318]
For long-term investments, such as auction rate securities, impairment is determined based on fair value and marketability of these investments. The valuation models we used to estimate fair value included numerous assumptions such as assessments of the underlying structure of each security, expected cash flows, discount rates, credit ratings, workout periods, and overall capital market liquidity.

[0001193125-11-171858:notes:319]
For nonmarketable investments, impairment is based on the most recent information available to us, including new financings or estimates of current fair value, as well as through traditional valuation techniques. It is our policy to review the fair value of these investments on a regular basis to determine whether the investments in these companies are other-than-temporarily impaired. In the case of privately-held companies, this evaluation is based on information that we request from these companies. If we believe the carrying value of an investment is in excess of fair value, and this difference is other-than-temporary, it is our policy to write down the investment to fair value.

[0001193125-11-171858:notes:320]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001193125-11-171858:notes:321]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed for or obtained for internal-use and amortize them over the software's estimated useful life

[0001193125-11-171858:notes:322]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations

[0001193125-11-171858:notes:323]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Acquisition-related intangible assets are amortized on a straight-line basis over their economic lives of five years for patents, four to six years for existing technology, two to eight years for customer relationships, one to three years for covenants not to compete and two to seven years for trademarks and tradenames as we believe this method would most closely reflect the pattern in which the economic benefits of the assets will be consumed.

[0001193125-11-171858:notes:324]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations to determine the adequacy of our current and future reserve needs. If actual future returns and allowances differ from past experience, additional allowances may be required.

[0001193125-11-171858:notes:325]
Product Warranties — Estimated future warranty costs are expensed as a cost of product revenues when revenue is recognized, based on estimates of the costs that may be incurred under our warranty obligations including material, distribution and labor costs. Our accrued liability for estimated future warranty costs is included in other accrued liabilities and other long-term obligations on the accompanying consolidated balance sheets. Factors that affect our warranty liability include the number of installed units, estimated material costs, estimated distribution costs and estimated labor costs. We periodically assess the adequacy of our warranty accrual and adjust the amount as considered necessary.

[0001193125-11-171858:notes:326]
Stock-Based Compensation — We measure and recognize stock-based compensation expense for all stock-based awards, including employee stock options, restricted stock units and rights to purchase shares under our ESPP, based on their estimated fair value, and recognize the costs in our financial statements over the employees' requisite service period.

[0001193125-11-171858:notes:327]
The fair value of employee restricted stock units is equal to the market value of our common stock on the date the award is granted. Calculating the fair value of employee stock options and the rights to purchase shares under the ESPP requires estimates and significant judgment. The fair value of each option grant is estimated on the date of grant using the Black-Scholes option pricing model, and is not remeasured as a result of subsequent stock price fluctuations. Option-pricing models require the input of highly subjective assumptions, including the expected term of options, and the expected price volatility of the stock underlying such options. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on an implied volatility of call options and dealer quotes on call options, generally having a term of greater than twelve months. The risk-free interest rate is based upon United States Treasury bills with equivalent expected terms, and the expected dividend is based on our history and expected dividend payouts. Changes in the subjective assumptions required in the valuation models may significantly affect the estimated value of our stock-based awards and the related stock-based compensation expense. Likewise, the shortening of the contractual life of our options could change the estimated exercise behavior in a manner other than currently expected.

[0001193125-11-171858:notes:328]
In addition, we estimate the number of stock-based awards that will be forfeited due to employee turnover. Our forfeiture assumption is based primarily on historical experience. Changes in the estimated forfeiture rate can have a significant effect on reported stock-based compensation expense, as the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-11-171858:notes:329]
| 11. | Stockholders' Equity |

[0001193125-11-171858:notes:330]
Equity Incentive Programs

[0001193125-11-171858:notes:331]
Acquisition Plans — We have assumed stock incentive plans in connection with our acquisitions. The options granted under these plans generally vest at a rate of 25% on the first anniversary of the vesting commencement date and then ratably over the following 36 months. The restricted stock units generally vest at a rate of 50% on the first and second annual anniversaries of the vesting commencement date.

[0001193125-11-171858:notes:332]
The 1999 Plan — As amended through July 13, 2010, the 1999 Stock Option Plan ("the 1999 Plan") comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in Fair Market Value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of Common Stock directly; (iv) the Performance Share and Performance Unit Program (also known as restricted stock units or RSUs) under which eligible persons may be granted performance shares and performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved; and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service.

[0001193125-11-171858:notes:333]
Under the 1999 Plan, the Board of Directors may grant to employees, nonemployee directors, and consultants and other independent advisors options to purchase shares of our common stock during their period of service with us. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the 1999 Plan generally vest over a four-year period. Options granted prior to April 29, 2006, have a term of no more than 10 years after the date of grant and those granted after April 29, 2006 have a term of no more than seven years, subject to earlier termination upon the occurrence of certain events. The 1999 Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the 1999 Plan generally vest over a four-year period with 25% of the units vesting on each annual anniversary of the grant date. The 1999 Plan limits the number of shares issued under the Stock Issuance Program and the Performance Share and Performance Unit Program to 8.9 million shares plus 50% of the awards cancelled and returned to the 1999 Plan and 50% of the number of shares added to the 1999 Plan after the 2009 Annual Meeting. The 1999 Plan limits the value of performance units a participant may receive during any calendar year to $2.0 million. The 1999 Plan expires in August 2019.

[0001193125-11-171858:notes:334]
In fiscal 2011, the 1999 Plan was amended to increase the shares reserved for issuance under the plan by an additional 7.0 million. As of April 29, 2011, 14.1 million shares were available for grant under our equity incentive plans.

[0001193125-11-171858:notes:335]
Stock Options

[0001193125-11-171858:notes:336]
A summary of the combined activity under our stock option plans and agreements is as follows (in millions, except for per share information and term):

[0001193125-11-171858:notes:337]
The intrinsic value of stock options represents the difference between the exercise price of stock options and the market price of our stock on that day for all in-the-money options. Additional information related to our stock options is summarized below (in millions except per share information):

[0001193125-11-171858:notes:338]
There was $91.7 million of total unrecognized compensation expense as of April 29, 2011 related to options. The unrecognized compensation expense will be amortized on a straight-line basis over a weighted-average remaining period of 2.3 years.

[0001193125-11-171858:notes:339]
The following table summarizes information about stock options outstanding under all option plans as of April 29, 2011 (in millions, except for per share information and life):

[0001193125-11-171858:notes:340]
The following table summarizes activity related to our RSUs (in millions, except the fair value):

[0001193125-11-171858:notes:341]
RSUs are converted into common stock upon vesting. Upon the vesting of restricted stock, we primarily use the net share settlement approach, which withholds a portion of the shares to cover the applicable taxes and decreases the shares issued to the employee by a corresponding value. The number and the value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001193125-11-171858:notes:342]
As of April 29, 2011, there was $240.5 million of total unrecognized compensation expense related to RSUs. The unrecognized compensation expense will be amortized on a straight-line basis over a weighted-average remaining vesting period of 2.6 years.

[0001193125-11-171858:notes:343]
Stock Option Exchange

[0001193125-11-171858:notes:344]
In April 2009, our stockholders approved a stock option exchange program (the Exchange) pursuant to which eligible employees were able to exchange some or all of their outstanding options with an exercise price greater than or equal to $22.00 per share that were granted before June 20, 2008, whether vested or unvested, for new RSUs. In connection with the Exchange, we exchanged options to purchase 24.5 million shares of our common stock for total of 3.2 million RSUs. The fair value of the RSUs issued was measured as the total of the unrecognized compensation cost of the options surrendered and the incremental value of the RSUs issued, measured as the excess of the fair value of the RSUs over the fair value of the options tendered immediately before the exchange. The incremental cost of the RSUs was $5.8 million. The value of the RSUs, totaling $70.1 million, is being amortized over the weighted average vesting period of the RSUs of 3.5 years.

[0001193125-11-171858:notes:345]
Stock Issuance Program — Under the 1999 Stock Issuance Program, certain eligible persons may be issued shares of common stock directly. No restricted stock awards (RSAs) were issued to employees during fiscal 2011, 2010 and 2009. At April 29, 2011, 7.7 million shares were available for future issuances under this program.

[0001193125-11-171858:notes:346]
Employee Stock Purchase Plan — Under the Employee Stock Purchase Plan (ESPP), employees are entitled to purchase shares of our common stock at 85% of the fair market value at certain specified dates over a two-year period. In fiscal 2011, 2010 and 2009, the plan was amended to increase the share reserved by an additional 5.0 million, 6.7 million and 2.9 million shares of common stock, respectively. Of the 35.2 million shares authorized to be issued under this plan, 4.0 million shares were available for issuance at April 29, 2011. Additional information related to our purchase rights issued under the ESPP is summarized below (in millions, except per share information):

[0001193125-11-171858:notes:347]
Stock-Based Compensation Expense

[0001193125-11-171858:notes:348]
Stock-based compensation expenses included in the consolidated statements of operations for fiscal 2011, 2010 and 2009, respectively, are as follows (in millions):

[0001193125-11-171858:notes:349]
The following table summarizes stock-based compensation associated with each type of award (in millions):

[0001193125-11-171858:notes:350]
Total income tax benefits (charges) associated with employee stock transactions and recognized in stockholders' equity were as follows (in millions):

[0001193125-11-171858:notes:351]
Valuation Assumptions

[0001193125-11-171858:notes:352]
The fair value of each award is estimated on the date of grant using the Black-Scholes option pricing model, assuming no expected dividends and the following weighted average assumptions:

[0001193125-11-171858:notes:353]
Stock Repurchase Program

[0001193125-11-171858:notes:354]
Since the May 13, 2003 inception of our stock repurchase program through April 29, 2011, we have repurchased a total of 104.3 million shares of our common stock at an average price of $28.06 per share, for an aggregate purchase price of $2.9 billion. As of April 29, 2011, our Board of Directors had authorized the repurchase of up to $4.0 billion of common stock under this stock repurchase program, and $1.1 billion remains available under these authorizations. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-11-171858:notes:355]
During fiscal years 2011 and 2010, we did not repurchase any shares of our common stock under the stock repurchase program. During fiscal 2009, we repurchased 17.0 million shares of our common stock at an aggregate cost of $400.0 million, or a weighted average price of $23.58 per share. The repurchases were recorded as treasury stock and resulted in a reduction of stockholders' equity.

[0001193125-11-171858:notes:356]
Preferred Stock

[0001193125-11-171858:notes:357]
Our Board of Directors has the authority to issue up to 5.0 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders.

[0001193125-11-171858:notes:358]
Comprehensive Income (Loss)

[0001193125-11-171858:notes:359]
Comprehensive income (loss) consists of net income and other comprehensive income (OCI), which is a separate component of stockholders' equity and is disclosed within the consolidated statements of stockholders' equity and comprehensive income. OCI includes foreign currency translation adjustments, unrealized gains and losses on derivatives and unrealized gains and losses on our available-for-sale securities, which includes a cumulative temporary impairment charge of $4.5 million, $3.3 million and $7.0 million in fiscal 2011, 2010 and 2009, respectively, associated with our auction rate securities.

[0001193125-11-171858:notes:360]
The components of accumulated other comprehensive income (loss), net of related tax effects, at the end of each fiscal year, were as follows (in millions):
