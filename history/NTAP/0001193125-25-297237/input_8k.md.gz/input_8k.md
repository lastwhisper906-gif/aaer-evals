# NTAP 8-K — 0001193125-25-297164 filed 2025-11-25

## item codes, every 8-K on or before 2025-11-25

- 2025-11-25 0001193125-25-297164 — 2.02, 9.01
- 2025-09-15 0001193125-25-202408 — 5.02, 5.07, 9.01
- 2025-08-27 0000950170-25-111700 — 2.02, 9.01
- 2025-05-29 0000950170-25-078936 — 2.02, 5.02, 8.01, 9.01
- 2025-03-26 0000950170-25-045244 — 5.02, 7.01, 9.01
- 2025-03-17 0001193125-25-055656 — 1.01, 2.03, 8.01, 9.01
- 2025-03-05 0001193125-25-047187 — 1.01, 2.03, 9.01
- 2025-02-27 0000950170-25-029022 — 2.02, 9.01
- 2025-02-26 0001193125-25-036882 — 5.02, 9.01
- 2025-01-28 0001193125-25-014441 — 5.02, 9.01
- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2025-11-25

- none on or before 2025-11-25

## item 2.02 — earnings release, exhibit 99.1

[0001193125-25-297164:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0001193125-25-297164:8k_2_02:2]
EX-99.1

[0001193125-25-297164:8k_2_02:3]
Exhibit 99.1

[0001193125-25-297164:8k_2_02:4]
NetApp Reports Second Quarter of Fiscal Year 2026 Results

[0001193125-25-297164:8k_2_02:5]
Net revenues of $1.71 billion for the second quarter, an increase of 3% year-over-year;

[0001193125-25-297164:8k_2_02:6]
Second quarter GAAP net income per share1 of $1.51 and record non-GAAP net income per share1 of $2.05

[0001193125-25-297164:8k_2_02:7]
News Summary

[0001193125-25-297164:8k_2_02:8]
•
NetApp hosted its annual customer conference, NetApp INSIGHT™, unveiling significant innovation for data, AI, cyber resilience, and cloud, strengthening its enterprise-grade data platform to fuel AI data factories

[0001193125-25-297164:8k_2_02:9]
•
All-flash array revenue grew 9% year-over-year to $1.0 billion in the second quarter, for an annualized net revenue run rate2 of $4.1 billion

[0001193125-25-297164:8k_2_02:10]
•
Public Cloud revenue of $171 million in the second quarter was driven by first-party and marketplace storage services, which grew 32% year-over-year

[0001193125-25-297164:8k_2_02:11]
•
Billings3 of $1.65 billion in the second quarter grew 4% year-over-year, the eighth consecutive quarter of year-over-year growth

[0001193125-25-297164:8k_2_02:12]
•
Record second quarter GAAP operating profit of $399 million; record non-GAAP operating profit3 of $530 million

[0001193125-25-297164:8k_2_02:13]
•
Record second quarter GAAP operating margin of 23.4%; record non-GAAP operating margin3 of 31.1%

[0001193125-25-297164:8k_2_02:14]
•
Returned $353 million to stockholders through share repurchases and cash dividends

[0001193125-25-297164:8k_2_02:15]
SAN JOSE, Calif.—November 25, 2025—NetApp (NASDAQ: NTAP), the Intelligent Data Infrastructure company, today reported financial results for the second quarter of fiscal year 2026, which ended on October 24, 2025.

[0001193125-25-297164:8k_2_02:16]
“Through strong execution and operational discipline, we delivered an outstanding second quarter with revenue growth driven by strong demand for our AI solutions, first-party and marketplace cloud storage services, and all-flash offerings,” said George Kurian, Chief Executive Officer. “Our close alignment with customers' key data initiatives has positioned us to capitalize on our significant competitive advantages. We remain confident that our visionary approach to a data-driven future will enable us to outpace market growth and capture additional market share.”

[0001193125-25-297164:8k_2_02:17]
Second Quarter of Fiscal Year 2026 Financial Results

[0001193125-25-297164:8k_2_02:18]
(In millions, except earnings per share and percentages)

[0001193125-25-297164:8k_2_02:19]
| GAAP Results |
|  |  | Q2'FY26 |  | Q2'FY25 |  | % Change |
| Net revenues |  | $ 1,705 |  | $ 1,658 |  | 3% |
| Hybrid Cloud segment revenue |  | $ 1,534 |  | $ 1,490 |  | 3% |
| Public Cloud segment revenue |  | $ 171 |  | $ 168 |  | 2% |
| Gross profit |  | $ 1,227 |  | $ 1,177 |  | 4% |
| Net income |  | $ 305 |  | $ 299 |  | 2% |
| Earnings per share |  | $ 1.51 |  | $ 1.42 |  | 6% |
| Cash provided by operations |  | $ 127 |  | $ 105 |  | 21% |
| Non-GAAP Results |
|  |  | Q2'FY26 |  | Q2'FY25 |  | % Change |
| Billings |  | $ 1,646 |  | $ 1,586 |  | 4% |
| Net revenues |  | $ 1,705 |  | $ 1,658 |  | 3% |
| Hybrid Cloud segment revenue |  | $ 1,534 |  | $ 1,490 |  | 3% |
| Public Cloud segment revenue |  | $ 171 |  | $ 168 |  | 2% |
| Gross profit |  | $ 1,237 |  | $ 1,194 |  | 4% |
| Net income |  | $ 415 |  | $ 392 |  | 6% |
| Earnings per share |  | $ 2.05 |  | $ 1.87 |  | 10% |
| Full reconciliations between GAAP and non-GAAP measures are provided below. |  |  |

[0001193125-25-297164:8k_2_02:20]
Constant Currency4 — Q2 Fiscal Year 2026 versus Q2 Fiscal Year 2025

[0001193125-25-297164:8k_2_02:21]
•
In constant currency, year-over-year, net revenues increased by 2% and billings increased by 3%.

[0001193125-25-297164:8k_2_02:22]
•
The year-over-year fluctuations of GAAP and non-GAAP net income presented in the tables above each include a favorable impact of approximately $14 million from foreign currency exchange rate changes.

[0001193125-25-297164:8k_2_02:23]
•
The year-over-year fluctuations of GAAP and non-GAAP earnings per share presented in the tables above each include a favorable impact of approximately $0.07 from foreign currency exchange rate changes.

[0001193125-25-297164:8k_2_02:24]
Third Quarter of Fiscal Year 2026 Financial Outlook

[0001193125-25-297164:8k_2_02:25]
The Company provided the following financial guidance for the third quarter of fiscal year 2026:

[0001193125-25-297164:8k_2_02:26]
| Net revenues are expected to be in the range of: | $1.615 billion - $1.765 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 71.3% - 72.3% |  | 72.3% - 73.3% |
| Operating margins are expected to be in the range of: | 24.5% - 25.5% |  | 30.5% - 31.5% |
| Earnings per share is expected to be in the range of: | $1.52 - $1.62 |  | $2.01 - $2.11 |

[0001193125-25-297164:8k_2_02:27]
Full Fiscal Year 2026 Financial Outlook

[0001193125-25-297164:8k_2_02:28]
The Company provided the following financial guidance for the full fiscal year 2026:

[0001193125-25-297164:8k_2_02:29]
| Net revenues are expected to be in the range of: | $6.625 billion - $6.875 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 70.7% - 71.7% |  | 71.7% - 72.7% |
| Operating margins are expected to be in the range of: | 23.5% - 24.5% |  | 29.5% - 30.5% |
| Earnings per share is expected to be in the range of: | $5.82 - $6.12 |  | $7.75 - $8.05 |

[0001193125-25-297164:8k_2_02:30]
Dividend

[0001193125-25-297164:8k_2_02:31]
The next cash dividend of $0.52 per share is to be paid on January 21, 2026, to stockholders of record as of the close of business on January 2, 2026.

[0001193125-25-297164:8k_2_02:32]
Second Quarter of Fiscal Year 2026 Business Highlights

[0001193125-25-297164:8k_2_02:33]
Leading Product Innovation

[0001193125-25-297164:8k_2_02:34]
•
NetApp launched NetApp AFX, a unified, AI-ready enterprise data platform that decouples performance and capacity, enabling organizations to operationalize and scale Al workflows at enterprise-scale.

[0001193125-25-297164:8k_2_02:35]
•
NetApp unveiled NetApp AI Data Engine™, integrating NVIDIA accelerated computing to simplify, secure, and accelerate AI workloads across hybrid and multicloud environments with integrated data discovery, curation, guardrails, and vectorization for GenAI.

[0001193125-25-297164:8k_2_02:36]
•
NetApp introduced NetApp Keystone™ Storage-as-a-Service (STaaS) for Enterprise Al, a flexible, consumption-based Al infrastructure solution powered by NetApp AFX architecture.

[0001193125-25-297164:8k_2_02:37]
•
NetApp launched enhanced Ransomware Resilience capabilities, adding AI-powered data breach detection and isolated recovery environments to help enterprises proactively identify potential threats, prevent data exfiltration, and securely restore critical workloads.

[0001193125-25-297164:8k_2_02:38]
•
NetApp announced StorageGRID™ 12.0, a scalable, software-defined object storage solution that helps organizations manage growing volumes of unstructured data while enhancing AI initiatives, strengthening data security, and modernizing data infrastructure.

[0001193125-25-297164:8k_2_02:39]
•
NetApp released Trident™ 25.10, the latest version of its open-source Kubernetes storage orchestrator, introducing enhanced parallelism, automated volume failover, AI/ML workload integration with NetApp AFX, and customizable compute resources to boost scalability, performance, and resilience.

[0001193125-25-297164:8k_2_02:40]
•
NetApp announced an expanded version of the NetApp Shift Toolkit, adding support for Red Hat OpenShift Virtualization, Proxmox, and Oracle Linux VM, enabling bidirectional migration between VMware and Hyper-V, and giving customers increased flexibility.

[0001193125-25-297164:8k_2_02:41]
•
NetApp Backup and Recovery added support for Microsoft SQL Server, delivering scalable, application-consistent protection and extending NetApp SnapCenter™ capabilities as a service.

[0001193125-25-297164:8k_2_02:42]
•
NetApp announced updates to NetApp Cloud Volumes, including enhanced I/O performance, and robust security features like VNet encryption of data in transit.

[0001193125-25-297164:8k_2_02:43]
Customer and Partner Momentum

[0001193125-25-297164:8k_2_02:44]
•
NetApp and Google Cloud enhanced Google Cloud NetApp Volumes with block storage, Gemini Enterprise integration for AI applications, and FlexCache™ to unify on-premises and cloud data for seamless hybrid cloud access and simplified migration.

[0001193125-25-297164:8k_2_02:45]
•
Google Cloud NetApp Volumes announced support for block capabilities with Flex service level, offering unified storage via NAS (NFS/SMB) and SAN (iSCSI).

[0001193125-25-297164:8k_2_02:46]
•
Amazon FSx for NetApp ONTAP announced support for Amazon Elastic VMware Service, enabling secure, efficient migration of VMware workloads to AWS with integrated data management, disaster recovery, and ransomware protection.

[0001193125-25-297164:8k_2_02:47]
•
NetApp achieved AWS Competency Partner status, recognizing its proven technical expertise and customer success in delivering high-performance cloud storage and data management solutions on AWS.

[0001193125-25-297164:8k_2_02:48]
•
Azure NetApp Files announced enhanced capabilities, including single file restore from backup, availability of short-term clones to reduce costs by avoiding full copy storage and minimizing operational overhead, and flexible service levels to allow customers to provision capacity pools by independently selecting storage capacity and throughput.

[0001193125-25-297164:8k_2_02:49]
•
NetApp and Cisco announced a collaboration to integrate Cisco Nexus switches into NetApp AFX architecture, delivering AI-ready, enterprise-grade storage and networking for scalable, high-performance AI workloads.

[0001193125-25-297164:8k_2_02:50]
•
NetApp and Red Hat expanded their collaboration to enhance hybrid cloud flexibility, accelerate VM migration with the NetApp Shift Toolkit, and strengthen virtualization through Trident integration, helping customers run containerized and VM workloads efficiently across environments.

[0001193125-25-297164:8k_2_02:51]
•
NetApp, Equinix, Broadcom, and Kochasoft launched a managed service for SAP S/4HANA and legacy workloads on VMware Cloud Foundation, combining NetApp all-flash storage, Equinix secure infrastructure, and Broadcom private cloud technology to deliver resilient, high-performance, cost-efficient SAP environments.

[0001193125-25-297164:8k_2_02:52]
•
Aston Martin Aramco Formula One™ Team announced that it runs entirely on NetApp storage, leveraging AI-ready infrastructure to accelerate simulations, optimize strategies, and enable rapid, data-driven decision making on the track.

[0001193125-25-297164:8k_2_02:53]
Corporate News and Events

[0001193125-25-297164:8k_2_02:54]
•
NetApp announced a multiyear partnership with the 49ers Foundation to deliver hands-on data science education to Bay Area high school students through the 49ers EDU Data Analytics Lesson Series, teaching practical skills in data storage, cloud, and cybersecurity.

[0001193125-25-297164:8k_2_02:55]
•
NetApp released a global enterprise AI maturity study with IDC5, revealing that organizations investing in data readiness, protection, and scalable infrastructure realize the business impact from AI.

[0001193125-25-297164:8k_2_02:56]
Awards and Recognition

[0001193125-25-297164:8k_2_02:57]
•
NetApp was recognized as a Leader in the 2025 Gartner Magic Quadrant for Enterprise Storage Platforms for its strong Completeness of Vision and Ability to Execute, reflecting its innovation in Intelligent Data Infrastructure, AI integration, and cyber resilience.

[0001193125-25-297164:8k_2_02:58]
•
NetApp was recognized as a Leader and Fast Mover in the GigaOm Radar for Object Storage 2025 for its strong performance in key features, business criteria, and innovation, ranking among the top vendors for both feature depth and forward-looking development.

[0001193125-25-297164:8k_2_02:59]
•
NetApp was recognized as a Leader and Fast Mover in the GigaOm Radar for Globally Distributed File Systems 2025, ranking jointly second in overall business value for its mature hybrid cloud data fabric capabilities.

[0001193125-25-297164:8k_2_02:60]
•
NetApp received a five-star rating in Newsweek’s America’s Greenest Companies 2025, recognized for measurable sustainability performance in emissions reduction, water management, and waste minimization.

[0001193125-25-297164:8k_2_02:61]
•
CRN Asia named NetApp Highly Commended in the Infrastructure and Storage Vendor of the Year category at its inaugural Channel Awards Asia, recognizing the Company’s strong performance and success across the region.

[0001193125-25-297164:8k_2_02:62]
•
NetApp won PQC Solution of the Year in the 2025 Cybersecurity Breakthrough Awards.

[0001193125-25-297164:8k_2_02:63]
•
NetApp was awarded a Gold ranking by EcoVadis.

[0001193125-25-297164:8k_2_02:64]
•
NetApp won Gold in the 2025 Merit Awards Technology Program, recognizing innovation and leadership in cloud services.

[0001193125-25-297164:8k_2_02:65]
Webcast and Conference Call Information

[0001193125-25-297164:8k_2_02:66]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0001193125-25-297164:8k_2_02:67]
affecting our operations, products, services, the storage industry, or AI usage; material cybersecurity and other security breaches; the impact of supply chain disruptions on our business operations, financial performance and results of operations; changes and related uncertainty in U.S. government spending or policy; changes in overall technology spending by our customers; revenue seasonality; changes in laws or regulations, including those relating to privacy, data protection and information security; the timing of orders and their fulfilment; and our ability to manage our gross profit margins, including managing component costs. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the sections titled “Risk Factors” in our most recently filed annual report on Form 10-K and quarterly report on Form 10-Q. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0001193125-25-297164:8k_2_02:68]
###

[0001193125-25-297164:8k_2_02:69]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001193125-25-297164:8k_2_02:70]
Footnotes

[0001193125-25-297164:8k_2_02:71]
1GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001193125-25-297164:8k_2_02:72]
2All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0001193125-25-297164:8k_2_02:73]
3Refer to the “NetApp Usage of Non-GAAP Financial Information” section below for explanations of consolidated non-GAAP gross margins, non-GAAP operating profit, non-GAAP operating margins, non-GAAP net income, non-GAAP net income per share, free cash flow, and billings.

[0001193125-25-297164:8k_2_02:74]
4Refer to the “Constant Currency” section below for an explanation of constant currency growth rates and the impact of foreign currency exchange rate changes on year-over-year fluctuations, as provided for certain financial measures.

[0001193125-25-297164:8k_2_02:75]
5IDC InfoBrief, “Scaling Enterprise AI Responsibility: The Critical Role of Data Readiness and an Intelligent Data Infrastructure,” sponsored by NetApp, doc #US53841625, October 2025.

[0001193125-25-297164:8k_2_02:76]
NetApp Usage of Non-GAAP Financial Information

[0001193125-25-297164:8k_2_02:77]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP operating profit, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share.

[0001193125-25-297164:8k_2_02:78]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp’s management uses non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001193125-25-297164:8k_2_02:79]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP operating profit, non-GAAP operating margins, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our non-GAAP effective tax rate and non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. Non-GAAP net income per share is computed as non-GAAP net income divided by the diluted number of shares for the applicable period.

[0001193125-25-297164:8k_2_02:80]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001193125-25-297164:8k_2_02:81]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and

[0001193125-25-297164:8k_2_02:82]
investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0001193125-25-297164:8k_2_02:83]
Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001193125-25-297164:8k_2_02:84]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001193125-25-297164:8k_2_02:85]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001193125-25-297164:8k_2_02:86]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001193125-25-297164:8k_2_02:87]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001193125-25-297164:8k_2_02:88]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0001193125-25-297164:8k_2_02:89]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001193125-25-297164:8k_2_02:90]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001193125-25-297164:8k_2_02:91]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. This is inclusive of third-party advisory, legal and other costs that result directly from and are essential to a sale transaction and that would not have been incurred had the decision to sell not been made. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-25-297164:8k_2_02:92]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-25-297164:8k_2_02:93]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-25-297164:8k_2_02:94]
J. Income tax effects. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001193125-25-297164:8k_2_02:95]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the

[0001193125-25-297164:8k_2_02:96]
Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with GAAP. The non-GAAP financial measures are meant to supplement and be viewed in conjunction with GAAP financial measures. A detailed reconciliation of our non-GAAP to GAAP results can be found herein.

[0001193125-25-297164:8k_2_02:97]
Constant Currency

[0001193125-25-297164:8k_2_02:98]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes that the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0001193125-25-297164:8k_2_02:99]
About NetApp

[0001193125-25-297164:8k_2_02:100]
For more than three decades, NetApp has helped the world’s leading organizations navigate change – from the rise of enterprise storage to the intelligent era defined by data and AI. Today, NetApp is the Intelligent Data Infrastructure company, helping customers turn data into a catalyst for innovation, resilience, and growth.

[0001193125-25-297164:8k_2_02:101]
At the heart of that infrastructure is the NetApp data platform – the unified, enterprise-grade, intelligent foundation that connects, protects, and activates data across every cloud, workload, and environment. Built on the proven power of NetApp ONTAP™, our leading data management software and OS, and enhanced by automation through the AI Data Engine and AFX, it delivers observability, resilience, and intelligence at scale.

[0001193125-25-297164:8k_2_02:102]
Disaggregated by design, the NetApp data platform separates storage, services, and control so enterprises can modernize faster, scale efficiently, and innovate without lock-in. As the only enterprise storage platform natively embedded in the world’s largest clouds, it gives organizations the freedom to run any workload anywhere with consistent performance, governance, and protection.

[0001193125-25-297164:8k_2_02:103]
With NetApp, data is always ready – ready to defend against threats, ready to power AI, and ready to drive the next breakthrough. That’s why the world’s most forward-thinking enterprises trust NetApp to turn intelligence into advantage.

[0001193125-25-297164:8k_2_02:104]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0001193125-25-297164:8k_2_02:105]
NETAPP, INC.

[0001193125-25-297164:8k_2_02:106]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-25-297164:8k_2_02:107]
(In millions)

[0001193125-25-297164:8k_2_02:108]
(Unaudited)

[0001193125-25-297164:8k_2_02:109]
|  |  | October 24, 2025 |  |  | April 25, 2025 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,014 |  |  | $ | 3,846 |  |
| Accounts receivable |  |  | 988 |  |  |  | 1,246 |  |
| Inventories |  |  | 127 |  |  |  | 186 |  |
| Other current assets |  |  | 525 |  |  |  | 573 |  |
| Total current assets |  |  | 4,654 |  |  |  | 5,851 |  |
| Property and equipment, net |  |  | 568 |  |  |  | 563 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,762 |  |  |  | 2,766 |  |
| Other non-current assets |  |  | 1,646 |  |  |  | 1,643 |  |
| Total assets |  | $ | 9,630 |  |  | $ | 10,823 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 436 |  |  | $ | 511 |  |
| Accrued expenses |  |  | 890 |  |  |  | 1,122 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 750 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,144 |  |  |  | 2,279 |  |
| Total current liabilities |  |  | 3,470 |  |  |  | 4,662 |  |
| Long-term debt |  |  | 2,486 |  |  |  | 2,485 |  |
| Other long-term liabilities |  |  | 387 |  |  |  | 379 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,301 |  |  |  | 2,257 |  |
| Total liabilities |  |  | 8,644 |  |  |  | 9,783 |  |
| Stockholders' equity |  |  | 986 |  |  |  | 1,040 |  |
| Total liabilities and stockholders' equity |  | $ | 9,630 |  |  | $ | 10,823 |  |

[0001193125-25-297164:8k_2_02:110]
NETAPP, INC.

[0001193125-25-297164:8k_2_02:111]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-25-297164:8k_2_02:112]
(In millions, except per share amounts)

[0001193125-25-297164:8k_2_02:113]
(Unaudited)

[0001193125-25-297164:8k_2_02:114]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 788 |  |  | $ | 768 |  |  | $ | 1,442 |  |  | $ | 1,437 |  |  |
| Services |  |  | 917 |  |  |  | 890 |  |  |  | 1,822 |  |  |  | 1,762 |  |  |
| Net revenues |  |  | 1,705 |  |  |  | 1,658 |  |  |  | 3,264 |  |  |  | 3,199 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 321 |  |  |  | 307 |  |  |  | 623 |  |  |  | 576 |  |  |
| Cost of services |  |  | 157 |  |  |  | 174 |  |  |  | 316 |  |  |  | 348 |  |  |
| Total cost of revenues |  |  | 478 |  |  |  | 481 |  |  |  | 939 |  |  |  | 924 |  |  |
| Gross profit |  |  | 1,227 |  |  |  | 1,177 |  |  |  | 2,325 |  |  |  | 2,275 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 465 |  |  |  | 485 |  |  |  | 926 |  |  |  | 956 |  |  |
| Research and development |  |  | 251 |  |  |  | 257 |  |  |  | 493 |  |  |  | 509 |  |  |
| General and administrative |  |  | 89 |  |  |  | 77 |  |  |  | 173 |  |  |  | 152 |  |  |
| Restructuring charges |  |  | 23 |  |  |  | 12 |  |  |  | 25 |  |  |  | 29 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 2 |  |  |
| Total operating expenses |  |  | 828 |  |  |  | 832 |  |  |  | 1,617 |  |  |  | 1,648 |  |  |
| Income from operations |  |  | 399 |  |  |  | 345 |  |  |  | 708 |  |  |  | 627 |  |  |
| Other (expense) income, net |  |  | (6 | ) |  |  | 15 |  |  |  | (11 | ) |  |  | 32 |  |  |
| Income before income taxes |  |  | 393 |  |  |  | 360 |  |  |  | 697 |  |  |  | 659 |  |  |
| Provision for income taxes |  |  | 88 |  |  |  | 61 |  |  |  | 159 |  |  |  | 112 |  |  |
| Net income |  | $ | 305 |  |  | $ | 299 |  |  | $ | 538 |  |  | $ | 547 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.53 |  |  | $ | 1.47 |  |  | $ | 2.69 |  |  | $ | 2.67 |  |  |
| Diluted |  | $ | 1.51 |  |  | $ | 1.42 |  |  | $ | 2.66 |  |  | $ | 2.59 |  |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 199 |  |  |  | 204 |  |  |  | 200 |  |  |  | 205 |  |  |
| Diluted |  |  | 202 |  |  |  | 210 |  |  |  | 202 |  |  |  | 211 |  |  |

[0001193125-25-297164:8k_2_02:115]
NETAPP, INC.

[0001193125-25-297164:8k_2_02:116]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-25-297164:8k_2_02:117]
(In millions)

[0001193125-25-297164:8k_2_02:118]
(Unaudited)

[0001193125-25-297164:8k_2_02:119]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | October 24, 2025 |  |  | October 25, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 305 |  |  | $ | 299 |  |  | $ | 538 |  |  | $ | 547 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 52 |  |  |  | 63 |  |  |  | 103 |  |  |  | 126 |  |
| Non-cash operating lease cost |  |  | 10 |  |  |  | 11 |  |  |  | 21 |  |  |  | 21 |  |
| Stock-based compensation |  |  | 102 |  |  |  | 103 |  |  |  | 185 |  |  |  | 188 |  |
| Deferred income taxes |  |  | 10 |  |  |  | (52 | ) |  |  | 19 |  |  |  | (69 | ) |
| Other items, net |  |  | 29 |  |  |  | 54 |  |  |  | 75 |  |  |  | 35 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (205 | ) |  |  | (197 | ) |  |  | 261 |  |  |  | 138 |  |
| Inventories |  |  | 6 |  |  |  | (103 | ) |  |  | 60 |  |  |  | (132 | ) |
| Accounts payable |  |  | 34 |  |  |  | 113 |  |  |  | (73 | ) |  |  | 36 |  |
| Accrued expenses |  |  | (37 | ) |  |  | 137 |  |  |  | (277 | ) |  |  | (84 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (59 | ) |  |  | (72 | ) |  |  | (107 | ) |  |  | (164 | ) |
| Long-term taxes payable |  |  | 1 |  |  |  | (95 | ) |  |  | 3 |  |  |  | (91 | ) |
| Changes in other operating assets and liabilities, net |  |  | (121 | ) |  |  | (156 | ) |  |  | (8 | ) |  |  | (105 | ) |
| Net cash provided by operating activities |  |  | 127 |  |  |  | 105 |  |  |  | 800 |  |  |  | 446 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 298 |  |  |  | 607 |  |  |  | 155 |  |  |  | 597 |  |
| Purchases of property and equipment |  |  | (49 | ) |  |  | (45 | ) |  |  | (102 | ) |  |  | (86 | ) |
| Other investing activities, net |  |  | — |  |  |  | 2 |  |  |  | 15 |  |  |  | 2 |  |
| Net cash provided by investing activities |  |  | 249 |  |  |  | 564 |  |  |  | 68 |  |  |  | 513 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 54 |  |  |  | 55 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (30 | ) |  |  | (35 | ) |  |  | (87 | ) |  |  | (132 | ) |
| Repurchase of common stock |  |  | (250 | ) |  |  | (300 | ) |  |  | (550 | ) |  |  | (700 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | (400 | ) |  |  | (750 | ) |  |  | (400 | ) |
| Dividends paid |  |  | (103 | ) |  |  | (106 | ) |  |  | (207 | ) |  |  | (213 | ) |
| Other financing activities, net |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |
| Net cash used in financing activities |  |  | (383 | ) |  |  | (842 | ) |  |  | (1,540 | ) |  |  | (1,390 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (5 | ) |  |  | 1 |  |  |  | 2 |  |  |  | 9 |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (12 | ) |  |  | (172 | ) |  |  | (670 | ) |  |  | (422 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,091 |  |  |  | 1,659 |  |  |  | 2,749 |  |  |  | 1,909 |  |
| End of period |  | $ | 2,079 |  |  | $ | 1,487 |  |  | $ | 2,079 |  |  | $ | 1,487 |  |

[0001193125-25-297164:8k_2_02:120]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Product |  | $ | 788 |  |  |  | $ | 768 |  |
| Support |  |  | 647 |  |  |  |  | 635 |  |
| Professional and Other Services |  |  | 99 |  |  |  |  | 87 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,534 |  |  |  |  | 1,490 |  |
| Public Cloud Segment Net Revenues |  |  | 171 |  |  |  |  | 168 |  |
| Net Revenues |  | $ | 1,705 |  |  |  | $ | 1,658 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Product |  | $ | 469 |  |  |  | $ | 463 |  |
| Support |  |  | 596 |  |  |  |  | 584 |  |
| Professional and Other Services |  |  | 30 |  |  |  |  | 23 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,095 |  |  |  |  | 1,070 |  |
| Public Cloud Segment Gross Profit |  |  | 142 |  |  |  |  | 124 |  |
| Total Segments Gross Profit |  |  | 1,237 |  |  |  |  | 1,194 |  |
| Amortization of Intangible Assets |  |  | (3 | ) |  |  |  | (9 | ) |
| Stock-based Compensation |  |  | (7 | ) |  |  |  | (8 | ) |
| Unallocated Cost of Revenues |  |  | (10 | ) |  |  |  | (17 | ) |
| Gross Profit |  | $ | 1,227 |  |  |  | $ | 1,177 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Product |  |  | 59.5 | % |  |  |  | 60.3 | % |
| Support |  |  | 92.1 | % |  |  |  | 92.0 | % |
| Professional and Other Services |  |  | 30.3 | % |  |  |  | 26.4 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 71.4 | % |  |  |  | 71.8 | % |
| Public Cloud Segment Gross Margin |  |  | 83.0 | % |  |  |  | 73.8 | % |

[0001193125-25-297164:8k_2_02:121]
| Geographic Mix |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'26 |  |  |  | % of Q2 FY'25 |  |
|  |  | Revenue |  |  |  | Revenue |  |
| Americas |  |  | 51 | % |  |  |  | 52 | % |
| Americas Commercial |  |  | 39 | % |  |  |  | 38 | % |
| U.S. Public Sector* |  |  | 12 | % |  |  |  | 14 | % |
| EMEA |  |  | 33 | % |  |  |  | 33 | % |
| Asia Pacific |  |  | 16 | % |  |  |  | 15 | % |
| * U.S. Public Sector includes revenue from both 1) the U.S. federal government (“U.S. Fed”) and 2) U.S. state governments, local municipalities and education institutions (“U.S. SLED”). |  |

[0001193125-25-297164:8k_2_02:122]
| Pathways Mix |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'26 |  |  |  | % of Q2 FY'25 |  |
|  |  | Revenue |  |  |  | Revenue |  |
| Direct |  |  | 23 | % |  |  |  | 23 | % |
| Indirect |  |  | 77 | % |  |  |  | 77 | % |

[0001193125-25-297164:8k_2_02:123]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Non-GAAP Income from Operations |  | $ | 530 |  |  |  | $ | 475 |  |
| % of Net Revenues |  |  | 31.1 | % |  |  |  | 28.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 524 |  |  |  | $ | 493 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.8 | % |  |  |  | 20.5 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Non-GAAP Net Income |  | $ | 415 |  |  |  | $ | 392 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 202 |  |  |  |  | 210 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 2.05 |  |  |  | $ | 1.87 |  |

[0001193125-25-297164:8k_2_02:124]
| Select Balance Sheet Items |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,445 |  |  |  | $ | 4,100 |  |
| DSO (days) |  |  | 53 |  |  |  |  | 48 |  |
| DPO (days) |  |  | 83 |  |  |  |  | 105 |  |
| Inventory Turns |  |  | 15 |  |  |  |  | 6 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |

[0001193125-25-297164:8k_2_02:125]
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Net Cash Provided by Operating Activities |  | $ | 127 |  |  |  | $ | 105 |  |
| Purchases of Property and Equipment |  | $ | 49 |  |  |  | $ | 45 |  |
| Free Cash Flow |  | $ | 78 |  |  |  | $ | 60 |  |
| Free Cash Flow as % of Net Revenues |  |  | 4.6 | % |  |  |  | 3.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001193125-25-297164:8k_2_02:126]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| NET INCOME |  | $ | 305 |  |  |  | $ | 299 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 14 |  |
| Stock-based compensation |  |  | 102 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | 23 |  |  |  |  | 12 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| Income tax effects |  |  | (21 | ) |  |  |  | (40 | ) |
| NON-GAAP NET INCOME |  | $ | 415 |  |  |  | $ | 392 |  |
| COST OF REVENUES |  | $ | 478 |  |  |  | $ | 481 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (9 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  |  | (8 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 468 |  |  |  | $ | 464 |  |
| COST OF PRODUCT REVENUES |  | $ | 321 |  |  |  | $ | 307 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  |  | (2 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 319 |  |  |  | $ | 305 |  |
| COST OF SERVICES REVENUES |  | $ | 157 |  |  |  | $ | 174 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (9 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  |  | (6 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 149 |  |  |  | $ | 159 |  |
| GROSS PROFIT |  | $ | 1,227 |  |  |  | $ | 1,177 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 3 |  |  |  |  | 9 |  |
| Stock-based compensation |  |  | 7 |  |  |  |  | 8 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,237 |  |  |  | $ | 1,194 |  |

[0001193125-25-297164:8k_2_02:127]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| SALES AND MARKETING EXPENSES |  | $ | 465 |  |  |  | $ | 485 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (5 | ) |
| Stock-based compensation |  |  | (42 | ) |  |  |  | (43 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 420 |  |  |  | $ | 437 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 251 |  |  |  | $ | 257 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (34 | ) |  |  |  | (37 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 217 |  |  |  | $ | 220 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 89 |  |  |  | $ | 77 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (19 | ) |  |  |  | (15 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 70 |  |  |  | $ | 62 |  |
| RESTRUCTURING CHARGES |  | $ | 23 |  |  |  | $ | 12 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (23 | ) |  |  |  | (12 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | — |  |  |  | $ | 1 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | — |  |  |  |  | (1 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 828 |  |  |  | $ | 832 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (5 | ) |
| Stock-based compensation |  |  | (95 | ) |  |  |  | (95 | ) |
| Restructuring charges |  |  | (23 | ) |  |  |  | (12 | ) |
| Acquisition-related expense |  |  | — |  |  |  |  | (1 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 707 |  |  |  | $ | 719 |  |

[0001193125-25-297164:8k_2_02:128]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| INCOME FROM OPERATIONS |  | $ | 399 |  |  |  | $ | 345 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 14 |  |
| Stock-based compensation |  |  | 102 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | 23 |  |  |  |  | 12 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 530 |  |  |  | $ | 475 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | (6 | ) |  |  | $ | 15 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (6 | ) |  |  | $ | 18 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 393 |  |  |  | $ | 360 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 14 |  |
| Stock-based compensation |  |  | 102 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | 23 |  |  |  |  | 12 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 524 |  |  |  | $ | 493 |  |
| PROVISION FOR INCOME TAXES |  | $ | 88 |  |  |  | $ | 61 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Income tax effects |  |  | 21 |  |  |  |  | 40 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 109 |  |  |  | $ | 101 |  |
| NET INCOME PER SHARE |  | $ | 1.51 |  |  |  | $ | 1.42 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.03 |  |  |  |  | 0.07 |  |
| Stock-based compensation |  |  | 0.50 |  |  |  |  | 0.49 |  |
| Restructuring charges |  |  | 0.11 |  |  |  |  | 0.06 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 0.01 |  |
| Income tax effects |  |  | (0.10 | ) |  |  |  | (0.19 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 2.05 |  |  |  | $ | 1.87 |  |

[0001193125-25-297164:8k_2_02:129]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Gross margin-GAAP |  |  | 72.0 | % |  |  |  | 71.0 | % |
| Cost of revenues adjustments |  |  | 0.6 | % |  |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 72.6 | % |  |  |  | 72.0 | % |
| GAAP cost of revenues |  | $ | 478 |  |  |  | $ | 481 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (9 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  |  | (8 | ) |
| Non-GAAP cost of revenues |  | $ | 468 |  |  |  | $ | 464 |  |
| Net revenues |  | $ | 1,705 |  |  |  | $ | 1,658 |  |

[0001193125-25-297164:8k_2_02:130]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Product gross margin-GAAP |  |  | 59.3 | % |  |  |  | 60.0 | % |
| Cost of product revenues adjustments |  |  | 0.2 | % |  |  |  | 0.3 | % |
| Product gross margin-Non-GAAP |  |  | 59.5 | % |  |  |  | 60.3 | % |
| GAAP cost of product revenues |  | $ | 321 |  |  |  | $ | 307 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  |  | (2 | ) |
| Non-GAAP cost of product revenues |  | $ | 319 |  |  |  | $ | 305 |  |
| Product revenues |  | $ | 788 |  |  |  | $ | 768 |  |

[0001193125-25-297164:8k_2_02:131]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Services gross margin-GAAP |  |  | 82.9 | % |  |  |  | 80.4 | % |
| Cost of services revenues adjustments |  |  | 0.9 | % |  |  |  | 1.7 | % |
| Services gross margin-Non-GAAP |  |  | 83.8 | % |  |  |  | 82.1 | % |
| GAAP cost of services revenues |  | $ | 157 |  |  |  | $ | 174 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (9 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  |  | (6 | ) |
| Non-GAAP cost of services revenues |  | $ | 149 |  |  |  | $ | 159 |  |
| Services revenues |  | $ | 917 |  |  |  | $ | 890 |  |

[0001193125-25-297164:8k_2_02:132]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Operating margin-GAAP |  |  | 23.4 | % |  |  |  | 20.8 | % |
| Adjustments |  |  | 7.7 | % |  |  |  | 7.8 | % |
| Operating margin-Non-GAAP |  |  | 31.1 | % |  |  |  | 28.6 | % |
| GAAP income from operations |  | $ | 399 |  |  |  | $ | 345 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 14 |  |
| Stock-based compensation |  |  | 102 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | 23 |  |  |  |  | 12 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |
| Non-GAAP income from operations |  | $ | 530 |  |  |  | $ | 475 |  |
| Net revenues |  | $ | 1,705 |  |  |  | $ | 1,658 |  |

[0001193125-25-297164:8k_2_02:133]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| GAAP effective tax rate |  |  | 22.4 | % |  |  |  | 16.9 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Income tax effects |  |  | (1.6 | )% |  |  |  | 3.6 | % |
| Non-GAAP effective tax rate |  |  | 20.8 | % |  |  |  | 20.5 | % |

[0001193125-25-297164:8k_2_02:134]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Net cash provided by operating activities |  | $ | 127 |  |  |  | $ | 105 |  |
| Purchases of property and equipment |  |  | (49 | ) |  |  |  | (45 | ) |
| Free cash flow |  | $ | 78 |  |  |  | $ | 60 |  |

[0001193125-25-297164:8k_2_02:135]
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY26 |  |  |  | Q2'FY25 |  |
| Net revenues |  | $ | 1,705 |  |  |  | $ | 1,658 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (59 | ) |  |  |  | (72 | ) |
| Billings |  | $ | 1,646 |  |  |  | $ | 1,586 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |  |  |

[0001193125-25-297164:8k_2_02:136]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| THIRD QUARTER FISCAL 2026 |
|  |  | Third Quarter |
|  |  | Fiscal 2026 |
| Gross Margin - GAAP Guidance |  | 71.3% - 72.3% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | 72.3% - 73.3% |
|  |  | Third Quarter |
|  |  | Fiscal 2026 |
| Operating Margin - GAAP Guidance |  | 24.5% - 25.5% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Operating Margin - Non-GAAP Guidance |  | 30.5% - 31.5% |

[0001193125-25-297164:8k_2_02:137]
Some items may not add or recalculate due to rounding.

[0001193125-25-297164:8k_2_02:138]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2026 |
|  |  | Third Quarter |
|  |  | Fiscal 2026 |
| GAAP Guidance - Net Income Per Share |  | $1.52 - $1.62 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Third Quarter Fiscal 2026: |  |  |
| Amortization of intangible assets |  | $0.02 |
| Stock-based compensation expense |  | $0.51 |
| Income tax effects |  | ($0.04) |
| Total Adjustments |  | $0.49 |
| Non-GAAP Guidance - Net Income Per Share |  | $2.01 - $2.11 |

[0001193125-25-297164:8k_2_02:139]
Some items may not add or recalculate due to rounding.

[0001193125-25-297164:8k_2_02:140]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FISCAL 2026 |
|  |  | Fiscal 2026 |
| Gross Margin - GAAP Guidance |  | 70.7% - 71.7% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | 71.7% - 72.7% |
|  |  | Fiscal 2026 |
| Operating Margin - GAAP Guidance |  | 23.5% - 24.5% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Operating Margin - Non-GAAP Guidance |  | 29.5% - 30.5% |

[0001193125-25-297164:8k_2_02:141]
Some items may not add or recalculate due to rounding.

[0001193125-25-297164:8k_2_02:142]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2026 |
|  |  | Fiscal 2026 |
| GAAP Guidance - Net Income Per Share |  | $5.82 - $6.12 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2026: |  |  |
| Amortization of intangible assets |  | $0.11 |
| Stock-based compensation expense |  | $1.92 |
| Restructuring charges |  | $0.12 |
| Income tax effects |  | ($0.22) |
| Total Adjustments |  | $1.93 |
| Non-GAAP Guidance - Net Income Per Share |  | $7.75 - $8.05 |

[0001193125-25-297164:8k_2_02:143]
Some items may not add or recalculate due to rounding.

[0001193125-25-297164:8k_2_02:144]
Contacts:

[0001193125-25-297164:8k_2_02:145]
(Press)

[0001193125-25-297164:8k_2_02:146]
Kenya Hayes

[0001193125-25-297164:8k_2_02:147]
1 703 589 7595

[0001193125-25-297164:8k_2_02:148]
kenya.hayes@netapp.com

[0001193125-25-297164:8k_2_02:149]
(Investors)

[0001193125-25-297164:8k_2_02:150]
Kris Newton

[0001193125-25-297164:8k_2_02:151]
1 408 822 3312

[0001193125-25-297164:8k_2_02:152]
kris.newton@netapp.com
