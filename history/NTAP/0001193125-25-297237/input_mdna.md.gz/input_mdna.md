# NTAP MD&A — 0001193125-25-297237


## mdna

[0001193125-25-297237:mdna:1]
[same as prior period, unchanged from 0001193125-25-189700:mdna:1]

[0001193125-25-297237:mdna:2]
25

[0001193125-25-297237:mdna:3]
[same as prior period, unchanged from 0001193125-25-189700:mdna:2]

[0001193125-25-297237:mdna:4]
[same as prior period, unchanged from 0001193125-25-189700:mdna:3]

[0001193125-25-297237:mdna:5]
[same as prior period, unchanged from 0001193125-25-189700:mdna:4]

[0001193125-25-297237:mdna:6]
[same as prior period, unchanged from 0001193125-25-189700:mdna:5]

[0001193125-25-297237:mdna:7]
[same as prior period, unchanged from 0001193125-25-189700:mdna:6]

[0001193125-25-297237:mdna:8]
[same as prior period, unchanged from 0001193125-25-189700:mdna:7]

[0001193125-25-297237:mdna:9]
[same as prior period, unchanged from 0001193125-25-189700:mdna:8]

[0001193125-25-297237:mdna:10]
[same as prior period, unchanged from 0001193125-25-189700:mdna:9]

[0001193125-25-297237:mdna:11]
[same as prior period, unchanged from 0001193125-25-189700:mdna:10]

[0001193125-25-297237:mdna:12]
During the first six months of fiscal 2026, we repurchased 5.2 million shares of our common stock at an average price of $106.05 per share, for an aggregate purchase price of $550 million. We also declared aggregate cash dividends of $1.04 per share in that period, for which we paid $207 million.

[0001193125-25-297237:mdna:13]
Restructuring Events

[0001193125-25-297237:mdna:14]
In the first six months of fiscal 2026, we approved a restructuring plan to redirect resources to highest return activities and reduce costs. Aggregate charges recorded from restructuring plans during the second quarter and first six months of fiscal 2026 totaled $23 million and $25 million, respectively.

[0001193125-25-297237:mdna:15]
[same as prior period, unchanged from 0001193125-25-189700:mdna:14]

[0001193125-25-297237:mdna:16]
[same as prior period, unchanged from 0001193125-25-189700:mdna:15]

[0001193125-25-297237:mdna:17]
[same as prior period, unchanged from 0001193125-25-189700:mdna:16]

[0001193125-25-297237:mdna:18]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | October 24, 2025 |  |  | October 25, 2024 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 46 | % |  |  | 46 | % |  |  | 44 | % |  |  | 45 | % |
| Services |  |  | 54 |  |  |  | 54 |  |  |  | 56 |  |  |  | 55 |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 19 |  |  |  | 19 |  |  |  | 19 |  |  |  | 18 |  |
| Cost of services |  |  | 9 |  |  |  | 10 |  |  |  | 10 |  |  |  | 11 |  |
| Gross profit |  |  | 72 |  |  |  | 71 |  |  |  | 71 |  |  |  | 71 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 29 |  |  |  | 28 |  |  |  | 30 |  |
| Research and development |  |  | 15 |  |  |  | 16 |  |  |  | 15 |  |  |  | 16 |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |
| Restructuring charges |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total operating expenses |  |  | 49 |  |  |  | 50 |  |  |  | 50 |  |  |  | 52 |  |
| Income from operations |  |  | 23 |  |  |  | 21 |  |  |  | 22 |  |  |  | 20 |  |
| Other income, net |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Income before income taxes |  |  | 23 |  |  |  | 22 |  |  |  | 21 |  |  |  | 21 |  |
| Provision for income taxes |  |  | 5 |  |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |
| Net income |  |  | 18 | % |  |  | 18 | % |  |  | 16 | % |  |  | 17 | % |

[0001193125-25-297237:mdna:19]
[same as prior period, unchanged from 0001193125-25-189700:mdna:18]

[0001193125-25-297237:mdna:20]
[same as prior period, unchanged from 0001193125-25-189700:mdna:19]

[0001193125-25-297237:mdna:21]
[same as prior period, unchanged from 0001193125-25-189700:mdna:20]

[0001193125-25-297237:mdna:22]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Net revenues |  | $ | 1,705 |  |  | $ | 1,658 |  |  |  | 3 | % |  | $ | 3,264 |  |  | $ | 3,199 |  |  |  | 2 | % |

[0001193125-25-297237:mdna:23]
The increase in net revenues for the second quarter and first six months of fiscal 2026 compared to the corresponding periods of fiscal 2025 was due to an increase in both product and services revenues. Product revenues as a percentage of net revenues remained relatively flat in the second quarter of fiscal 2026 and decreased one percentage point during the first six months of fiscal 2026, as compared to the corresponding periods of fiscal 2025. Fluctuations in foreign currency exchange rates favorably impacted net revenues percentage growth by approximately one percentage point in the second quarter and first six months of fiscal 2026, compared to the corresponding periods of fiscal 2025.

[0001193125-25-297237:mdna:24]
[same as prior period, unchanged from 0001193125-25-189700:mdna:23]

[0001193125-25-297237:mdna:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Product revenues |  | $ | 788 |  |  | $ | 768 |  |  |  | 3 | % |  | $ | 1,442 |  |  | $ | 1,437 |  |  |  | — | % |

[0001193125-25-297237:mdna:26]
[same as prior period, unchanged from 0001193125-25-189700:mdna:25]

[0001193125-25-297237:mdna:27]
[same as prior period, unchanged from 0001193125-25-189700:mdna:26]

[0001193125-25-297237:mdna:28]
Total product revenues increased in the second quarter of fiscal 2026 compared to the corresponding period of the prior year primarily due to higher sales of all-flash array systems and the favorable impact from foreign exchange rate fluctuations.

[0001193125-25-297237:mdna:29]
27

[0001193125-25-297237:mdna:30]
[same as prior period, unchanged from 0001193125-25-189700:mdna:28]

[0001193125-25-297237:mdna:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Services revenues |  | $ | 917 |  |  | $ | 890 |  |  |  | 3 | % |  | $ | 1,822 |  |  | $ | 1,762 |  |  |  | 3 | % |
| Support |  |  | 647 |  |  |  | 635 |  |  |  | 2 | % |  |  | 1,294 |  |  |  | 1,266 |  |  |  | 2 | % |
| Professional and other services |  |  | 99 |  |  |  | 87 |  |  |  | 14 | % |  |  | 196 |  |  |  | 169 |  |  |  | 16 | % |
| Public cloud |  |  | 171 |  |  |  | 168 |  |  |  | 2 | % |  |  | 332 |  |  |  | 327 |  |  |  | 2 | % |

[0001193125-25-297237:mdna:32]
[same as prior period, unchanged from 0001193125-25-189700:mdna:30]

[0001193125-25-297237:mdna:33]
[same as prior period, unchanged from 0001193125-25-189700:mdna:31]

[0001193125-25-297237:mdna:34]
Support revenues increased marginally in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year, primarily due to the favorable impact from foreign exchange rate fluctuations.

[0001193125-25-297237:mdna:35]
Professional and other services revenues increased in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year primarily due to an increase in revenues from our Keystone storage-as-a-service offering.

[0001193125-25-297237:mdna:36]
[same as prior period, unchanged from 0001193125-25-189700:mdna:34]

[0001193125-25-297237:mdna:37]
[same as prior period, unchanged from 0001193125-25-189700:mdna:35]

[0001193125-25-297237:mdna:38]
Public Cloud revenues increased marginally in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year, due to higher customer demand, driven by NetApp’s diversified cloud offerings and overall growth in the cloud market, partially offset by the loss of revenue from our Spot by NetApp business which we sold in the fourth quarter of fiscal 2025.

[0001193125-25-297237:mdna:39]
[same as prior period, unchanged from 0001193125-25-189700:mdna:37]

[0001193125-25-297237:mdna:40]
[same as prior period, unchanged from 0001193125-25-189700:mdna:38]

[0001193125-25-297237:mdna:41]
[same as prior period, unchanged from 0001193125-25-189700:mdna:39]

[0001193125-25-297237:mdna:42]
[same as prior period, unchanged from 0001193125-25-189700:mdna:40]

[0001193125-25-297237:mdna:43]
[same as prior period, unchanged from 0001193125-25-189700:mdna:41]

[0001193125-25-297237:mdna:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Cost of product revenues |  | $ | 321 |  |  | $ | 307 |  |  |  | 5 | % |  | $ | 623 |  |  | $ | 576 |  |  |  | 8 | % |
| Hybrid Cloud |  |  | 319 |  |  |  | 305 |  |  |  | 5 | % |  |  | 620 |  |  |  | 573 |  |  |  | 8 | % |
| Unallocated |  |  | 2 |  |  |  | 2 |  |  |  | — | % |  |  | 3 |  |  |  | 3 |  |  |  | — | % |

[0001193125-25-297237:mdna:45]
[same as prior period, unchanged from 0001193125-25-189700:mdna:43]

[0001193125-25-297237:mdna:46]
Cost of Hybrid Cloud product revenues represented 40% and 43% of product revenues for the second quarter and first six months of fiscal 2026, respectively, compared to 40% for the corresponding periods of the prior year. Materials costs represented 91% and 90% of cost of Hybrid Cloud product revenues for the second quarter and first six months of fiscal 2026, respectively, compared to 89% for the corresponding periods of the prior year.

[0001193125-25-297237:mdna:47]
28

[0001193125-25-297237:mdna:48]
Materials costs increased by $18 million and $48 million in the second quarter and first six months of fiscal 2026, respectively, compared to the corresponding periods of the prior year.

[0001193125-25-297237:mdna:49]
Hybrid Cloud product gross margins decreased one percentage point in the second quarter and three percentage points in the first six months of fiscal 2026 compared to the corresponding periods of the prior year primarily due to higher component costs.

[0001193125-25-297237:mdna:50]
[same as prior period, unchanged from 0001193125-25-189700:mdna:47]

[0001193125-25-297237:mdna:51]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Cost of services revenues |  | $ | 157 |  |  | $ | 174 |  |  |  | (10 | )% |  | $ | 316 |  |  | $ | 348 |  |  |  | (9 | )% |
| Support |  |  | 51 |  |  |  | 51 |  |  |  | — | % |  |  | 101 |  |  |  | 101 |  |  |  | — | % |
| Professional and other services |  |  | 69 |  |  |  | 64 |  |  |  | 8 | % |  |  | 137 |  |  |  | 128 |  |  |  | 7 | % |
| Public cloud |  |  | 29 |  |  |  | 44 |  |  |  | (34 | )% |  |  | 61 |  |  |  | 90 |  |  |  | (32 | )% |
| Unallocated |  |  | 8 |  |  |  | 15 |  |  |  | (47 | )% |  |  | 17 |  |  |  | 29 |  |  |  | (41 | )% |

[0001193125-25-297237:mdna:52]
[same as prior period, unchanged from 0001193125-25-189700:mdna:49]

[0001193125-25-297237:mdna:53]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year. Cost of Hybrid Cloud services revenues represented 16% of Hybrid Cloud services revenues for both the second quarter and first six months of fiscal 2026 and the corresponding periods of the prior year.

[0001193125-25-297237:mdna:54]
Hybrid Cloud support gross margins were relatively flat in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year. Hybrid Cloud professional and other services gross margins increased by four percentage points in the second quarter of fiscal 2026 and six percentage points in the first six months of 2026 compared to the corresponding periods of the prior year due primarily to the mix of services provided.

[0001193125-25-297237:mdna:55]
[same as prior period, unchanged from 0001193125-25-189700:mdna:52]

[0001193125-25-297237:mdna:56]
Cost of Public Cloud revenues decreased and gross margins increased by nine percentage points in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year. The decrease in cost of Public Cloud revenues and improved gross margins was due to cost optimization that included a decrease in fixed assets depreciation, and the mix of offerings provided which was impacted by the sale of our Spot by NetApp business in the fourth quarter of fiscal 2025.

[0001193125-25-297237:mdna:57]
[same as prior period, unchanged from 0001193125-25-189700:mdna:54]

[0001193125-25-297237:mdna:58]
Unallocated cost of services revenues decreased in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year, due to lower intangible asset amortization expense from the derecognition of certain intangible assets as a result of the sale of our Spot by NetApp business during the fourth quarter of fiscal 2025.

[0001193125-25-297237:mdna:59]
[same as prior period, unchanged from 0001193125-25-189700:mdna:56]

[0001193125-25-297237:mdna:60]
[same as prior period, unchanged from 0001193125-25-189700:mdna:57]

[0001193125-25-297237:mdna:61]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2026 totaled $805 million, or 47% of net revenues, and $1,592 million, or 49% of net revenues, respectively, each reflecting a decrease of two percentage points compared to the corresponding periods of the prior year, primarily due to the increase in net revenues.

[0001193125-25-297237:mdna:62]
[same as prior period, unchanged from 0001193125-25-189700:mdna:59]

[0001193125-25-297237:mdna:63]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses in the second quarter and first six months of fiscal 2026 were relatively flat compared to the corresponding periods of the prior year.

[0001193125-25-297237:mdna:64]
[same as prior period, unchanged from 0001193125-25-189700:mdna:61]

[0001193125-25-297237:mdna:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 465 |  |  | $ | 485 |  |  |  | (4 | )% |  | $ | 926 |  |  | $ | 956 |  |  |  | (3 | )% |

[0001193125-25-297237:mdna:66]
29

[0001193125-25-297237:mdna:67]
[same as prior period, unchanged from 0001193125-25-189700:mdna:63]

[0001193125-25-297237:mdna:68]
The decrease in sales and marketing expenses in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year was primarily due to lower compensation costs and lower commissions expenses.

[0001193125-25-297237:mdna:69]
[same as prior period, unchanged from 0001193125-25-189700:mdna:65]

[0001193125-25-297237:mdna:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Research and development expenses |  | $ | 251 |  |  | $ | 257 |  |  |  | (2 | )% |  | $ | 493 |  |  | $ | 509 |  |  |  | (3 | )% |

[0001193125-25-297237:mdna:71]
[same as prior period, unchanged from 0001193125-25-189700:mdna:67]

[0001193125-25-297237:mdna:72]
Research and development expenses decreased in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year, primarily attributable to lower compensation costs and lower spend on engineering projects.

[0001193125-25-297237:mdna:73]
[same as prior period, unchanged from 0001193125-25-189700:mdna:69]

[0001193125-25-297237:mdna:74]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| General and administrative expenses |  | $ | 89 |  |  | $ | 77 |  |  |  | 16 | % |  | $ | 173 |  |  | $ | 152 |  |  |  | 14 | % |

[0001193125-25-297237:mdna:75]
[same as prior period, unchanged from 0001193125-25-189700:mdna:71]

[0001193125-25-297237:mdna:76]
General and administrative expenses increased in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year, primarily attributable to higher compensation costs and higher spend on professional services.

[0001193125-25-297237:mdna:77]
[same as prior period, unchanged from 0001193125-25-189700:mdna:73]

[0001193125-25-297237:mdna:78]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Restructuring charges |  | $ | 23 |  |  | $ | 12 |  |  |  | 92 | % |  | $ | 25 |  |  | $ | 29 |  |  |  | (14 | )% |

[0001193125-25-297237:mdna:79]
In the first six months of fiscal 2026, we incurred charges related to a restructuring plan previously approved by management in the fourth quarter of fiscal 2025, as well as a restructuring plan approved by management in the second quarter of fiscal 2026 to redirect resources to the highest return activities and reduce costs. The activities under these plans are expected to be substantially complete by the end of fiscal 2026.

[0001193125-25-297237:mdna:80]
In the first six months of fiscal 2025, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. The activities under these plans were substantially completed by the end of fiscal 2025.

[0001193125-25-297237:mdna:81]
[same as prior period, unchanged from 0001193125-25-189700:mdna:77]

[0001193125-25-297237:mdna:82]
[same as prior period, unchanged from 0001193125-25-189700:mdna:78]

[0001193125-25-297237:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Interest income |  | $ | 27 |  |  | $ | 27 |  |  |  | — | % |  | $ | 63 |  |  | $ | 63 |  |  |  | — | % |
| Interest expense |  |  | (26 | ) |  |  | (15 | ) |  |  | 73 | % |  |  | (55 | ) |  |  | (31 | ) |  |  | 77 | % |
| Other, net |  |  | (7 | ) |  |  | 3 |  |  | NM |  |  |  | (19 | ) |  |  | — |  |  | NM |  |
| Total |  | $ | (6 | ) |  | $ | 15 |  |  |  | (140 | )% |  | $ | (11 | ) |  | $ | 32 |  |  |  | (134 | )% |

[0001193125-25-297237:mdna:84]
[same as prior period, unchanged from 0001193125-25-189700:mdna:80]

[0001193125-25-297237:mdna:85]
[same as prior period, unchanged from 0001193125-25-189700:mdna:100]

[0001193125-25-297237:mdna:86]
Interest expense increased in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year due to a higher average outstanding aggregate principal amount of Senior Notes, with a higher average coupon rate.

[0001193125-25-297237:mdna:87]
The differences in Other, net in the second quarter and first six months of fiscal 2026 compared to the corresponding periods of the prior year are primarily due to fluctuations in foreign exchange gains and losses year-over-year.

[0001193125-25-297237:mdna:88]
[same as prior period, unchanged from 0001193125-25-189700:mdna:82]

[0001193125-25-297237:mdna:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |  | October 24, 2025 |  |  | October 25, 2024 |  |  | % Change |  |
| Provision for income taxes |  | $ | 88 |  |  | $ | 61 |  |  |  | 44 | % |  | $ | 159 |  |  | $ | 112 |  |  |  | 42 | % |
| Effective tax rate |  |  | 22.4 | % |  |  | 16.9 | % |  | NM |  |  |  | 22.8 | % |  |  | 17.0 | % |  | NM |  |

[0001193125-25-297237:mdna:90]
[same as prior period, unchanged from 0001193125-25-189700:mdna:84]

[0001193125-25-297237:mdna:91]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate which is offset by non-deductible stock-based compensation and state taxes. Our effective tax rate for the three and six months ended October 24, 2025 includes a decrease in discrete tax benefits related to stock-based compensation compared to the corresponding periods of the prior year.

[0001193125-25-297237:mdna:92]
As of October 24, 2025, we had $70 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $49 million of net unrecognized tax benefits would affect our provision for income taxes if recognized and have been recorded in other long-term liabilities.

[0001193125-25-297237:mdna:93]
[same as prior period, unchanged from 0001193125-25-189700:mdna:87]

[0001193125-25-297237:mdna:94]
| (In millions) |  | October 24, 2025 |  |  | April 25,2025 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,014 |  |  | $ | 3,846 |  |
| Principal amount of debt |  | $ | 2,500 |  |  | $ | 3,250 |  |

[0001193125-25-297237:mdna:95]
[same as prior period, unchanged from 0001193125-25-189700:mdna:89]

[0001193125-25-297237:mdna:96]
|  |  | Six Months Ended |  |
| (In millions) |  | October 24, 2025 |  |  | October 25, 2024 |  |
| Net cash provided by operating activities |  | $ | 800 |  |  | $ | 446 |  |
| Net cash provided by investing activities |  |  | 68 |  |  |  | 513 |  |
| Net cash used in financing activities |  |  | (1,540 | ) |  |  | (1,390 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 2 |  |  |  | 9 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (670 | ) |  | $ | (422 | ) |

[0001193125-25-297237:mdna:97]
[same as prior period, unchanged from 0001193125-25-189700:mdna:91]

[0001193125-25-297237:mdna:98]
As of October 24, 2025, our cash, cash equivalents and short-term investments were $3.0 billion, which represents a decrease of $832 million during the first six months of fiscal 2026. The decrease was primarily due to a $750 million principal repayment of our 1.875% Senior Notes due June 2025, $550 million used for the repurchase of our common stock, $207 million used for the payment of dividends, and $102 million used for purchases of property and equipment, partially offset by $800 million provided by operating activities. Our working capital was $1.2 billion as of October 24, 2025, relatively flat compared to April 25, 2025.

[0001193125-25-297237:mdna:99]
[same as prior period, unchanged from 0001193125-25-189700:mdna:93]

[0001193125-25-297237:mdna:100]
During the first six months of fiscal 2026, cash provided by operating activities reflected net income of $538 million which was increased for non-cash depreciation and amortization expense of $103 million and non-cash stock-based compensation expense of $185 million. During the first six months of fiscal 2025, cash provided by operating activities reflected net income of $547 million which was increased for non-cash depreciation and amortization expense of $126 million and non-cash stock-based compensation expense of $188 million.

[0001193125-25-297237:mdna:101]
Significant changes in assets and liabilities in the first six months of fiscal 2026 included the following:

[0001193125-25-297237:mdna:102]
•
Accounts receivable decreased by $261 million, reflecting lower billings in the first six months of fiscal 2026 compared to the last six months of fiscal 2025.

[0001193125-25-297237:mdna:103]
•
Accrued expenses decreased by $277 million, primarily due to employee compensation payments related to our fiscal 2025 incentive compensation plan accrual.

[0001193125-25-297237:mdna:104]
•
Deferred revenue and financed unearned services revenue decreased by $107 million, reflecting a decrease in deferred revenue for support contracts.

[0001193125-25-297237:mdna:105]
[same as prior period, unchanged from 0001193125-25-189700:mdna:99]

[0001193125-25-297237:mdna:106]
[same as prior period, unchanged from 0001193125-25-189700:mdna:101]

[0001193125-25-297237:mdna:107]
During the first six months of fiscal 2026, we generated $155 million from maturities and sales of investments, net of purchases, and paid $102 million for capital expenditures, as compared to the same period of fiscal 2025, in which we generated $597 million from maturities and sales of investments, net of purchases, and paid $86 million for capital expenditures.

[0001193125-25-297237:mdna:108]
[same as prior period, unchanged from 0001193125-25-189700:mdna:103]

[0001193125-25-297237:mdna:109]
During the first six months of fiscal 2026, we used $750 million for the principal repayment upon maturity of our 1.875% Senior Notes due in June 2025, $550 million for the repurchase of 5.2 million shares of common stock, and $207 million for the payment of dividends. During the first six months of fiscal 2025, we used $700 million for the repurchase of 5.8 million shares of common stock and $213 million for the payment of dividends.

[0001193125-25-297237:mdna:110]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months and thereafter for the foreseeable future. We may choose to periodically raise additional debt capital based on certain conditions, including the refinancing of upcoming maturities and/or for potential strategic acquisitions and investments. Our ability to obtain this, or any additional financing that we may pursue or need, will depend on, among other things, our business plans, operating performance and the condition of the capital markets at the time we seek financing. We may not be able to obtain such financing on terms acceptable to us or at all. In the event our liquidity is insufficient and we are unable to enter into new financing arrangements, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels. For further discussion of factors that could affect our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0001193125-25-297237:mdna:111]
[same as prior period, unchanged from 0001193125-25-189700:mdna:106]

[0001193125-25-297237:mdna:112]
Our principal sources of liquidity as of October 24, 2025 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001193125-25-297237:mdna:113]
[same as prior period, unchanged from 0001193125-25-189700:mdna:108]

[0001193125-25-297237:mdna:114]
|  |  | October 24, 2025 |  |  | April 25, 2025 |  |
| Cash and cash equivalents |  | $ | 2,072 |  |  | $ | 2,742 |  |
| Short-term investments |  |  | 942 |  |  |  | 1,104 |  |
| Total |  | $ | 3,014 |  |  | $ | 3,846 |  |

[0001193125-25-297237:mdna:115]
As of October 24, 2025 and April 25, 2025, $2.3 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $716 million and $1.3 billion, respectively, were available in the U.S.

[0001193125-25-297237:mdna:116]
[same as prior period, unchanged from 0001193125-25-189700:mdna:129]

[0001193125-25-297237:mdna:117]
[same as prior period, unchanged from 0001193125-25-189700:mdna:111]

[0001193125-25-297237:mdna:118]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counterparties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 24, 2025.

[0001193125-25-297237:mdna:119]
[same as prior period, unchanged from 0001193125-25-189700:mdna:114]

[0001193125-25-297237:mdna:120]
[same as prior period, unchanged from 0001193125-25-189700:mdna:115]

[0001193125-25-297237:mdna:121]
The following table summarizes the principal amount of our Senior Notes as of October 24, 2025 (in millions):

[0001193125-25-297237:mdna:122]
|  |  | Amount |  |
| 2.375% Senior Notes Due June 2027 |  | $ | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  |  | 625 |  |
| Total |  | $ | 2,500 |  |

[0001193125-25-297237:mdna:123]
[same as prior period, unchanged from 0001193125-25-189700:mdna:118]

[0001193125-25-297237:mdna:124]
On June 23, 2025, upon maturity, we repaid our 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-25-297237:mdna:125]
Commercial Paper Program and Credit Facility

[0001193125-25-297237:mdna:126]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of October 24, 2025.

[0001193125-25-297237:mdna:127]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 24, 2025, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001193125-25-297237:mdna:128]
[same as prior period, unchanged from 0001193125-25-189700:mdna:123]

[0001193125-25-297237:mdna:129]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2026 to be between $90 million and $140 million.

[0001193125-25-297237:mdna:130]
[same as prior period, unchanged from 0001193125-25-189700:mdna:125]

[0001193125-25-297237:mdna:131]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. A final transition tax payment of $179 million was paid during the second quarter of fiscal 2026.

[0001193125-25-297237:mdna:132]
[same as prior period, unchanged from 0001193125-25-189700:mdna:127]

[0001193125-25-297237:mdna:133]
On November 20, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on January 21, 2026, to holders of record as of the close of business on January 2, 2026.

[0001193125-25-297237:mdna:134]
In the first quarter of fiscal 2026, our Board of Directors authorized the repurchase of an additional $1.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. As of October 24, 2025, the remaining authorized amount for stock repurchases under this program was $902 million.

[0001193125-25-297237:mdna:135]
[same as prior period, unchanged from 0001193125-25-189700:mdna:131]

[0001193125-25-297237:mdna:136]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1.2 billion as of October 24, 2025.

[0001193125-25-297237:mdna:137]
[same as prior period, unchanged from 0001193125-25-189700:mdna:133]

[0001193125-25-297237:mdna:138]
We enter into financing and leasing contracts through the ordinary course of business. These arrangements and related financing guarantees are described in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1. There has been no material change in our financing guarantees as described in our 2025 Annual Report on Form 10-K.

[0001193125-25-297237:mdna:139]
Legal Contingencies

[0001193125-25-297237:mdna:140]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0001193125-25-297237:mdna:141]
[same as prior period, unchanged from 0001193125-25-189700:mdna:137]

[0001193125-25-297237:mdna:142]
[same as prior period, unchanged from 0001193125-25-189700:mdna:138]
