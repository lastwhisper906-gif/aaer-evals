# NTAP MD&A — 0001193125-14-239169


## mdna

[0001193125-14-239169:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-14-239169:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and
the accompanying notes set forth under “Item 8. Financial Statements and Supplementary Data”. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and
uncertainties. The Risk Factors set forth in “Item 1A. Risk Factors” are hereby incorporated into the discussion by reference.

[0001193125-14-239169:mdna:3]
Executive Overview

[0001193125-14-239169:mdna:4]
Our Company

[0001193125-14-239169:mdna:5]
We are a leading global provider of innovative storage and data management software, systems and services. Our storage solutions help customers create the flexible, efficient and highly available
information technology (IT) infrastructures they need to support their organizations.

[0001193125-14-239169:mdna:6]
Our unified
scale-out fabric-attached storage (FAS) platform is designed to meet the demanding requirements of shared infrastructures and cloud environments. Our E-Series high-performance storage area network platform is designed to meet demanding performance
and capacity requirements of dedicated workloads, while retaining simplicity and an optimized price to performance ratio. Our FAS storage platform uses the NetApp® DataONTAP® storage operating
system to deliver integrated data protection, comprehensive data management, and built-in efficiency software for virtualized, shared infrastructures, cloud computing, and mixed workload business applications. We offer hybrid and all-flash
configurations of both FAS and E-Series platforms. Effective in the fourth quarter of fiscal 2014, we have changed the way we group our FAS product platforms. We now describe our configured systems as (1) entry level products, which consists of
our FAS2000 systems, (2) mid-range products, which consists of our legacy FAS3000 systems and our new FAS8020 and FAS8040 systems, and (3) high-end products, which consists of our legacy 6000 systems and our new FAS8060 systems. This
change had no impact on previously reported amounts.

[0001193125-14-239169:mdna:7]
In addition to our products, we provide a variety of services including
hardware maintenance, and software entitlement and maintenance (SEM), professional services, global support solutions, and customer education and training to help customers most effectively manage their data.

[0001193125-14-239169:mdna:8]
We employ a multichannel distribution strategy, selling products and services to end users and service providers through a direct sales
force and through channel partners, including value-added resellers, system integrators, OEMs and distributors.

[0001193125-14-239169:mdna:9]
Financial Results and Key Performance Metrics Overview

[0001193125-14-239169:mdna:10]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except
per share amounts, percentages and days sales outstanding):

[0001193125-14-239169:mdna:11]
|  |  | Year Ended |  |
|  |  | April 25,2014 |  |  | April 26,2013 |  |  | April 27,2012 |  |
| Net revenues |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |  | $ | 6,233.2 |  |
| Gross profit |  | $ | 3,919.1 |  |  | $ | 3,761.1 |  |  | $ | 3,713.4 |  |
| Gross profit margin percentage |  |  | 62.0 | % |  |  | 59.4 | % |  |  | 59.6 | % |
| Income from operations |  | $ | 734.3 |  |  | $ | 607.8 |  |  | $ | 746.5 |  |
| Income from operations as a percentage of net revenues |  |  | 11.6 | % |  |  | 9.6 | % |  |  | 12.0 | % |
| Net income |  | $ | 637.5 |  |  | $ | 505.3 |  |  | $ | 605.4 |  |
| Diluted income per share |  | $ | 1.83 |  |  | $ | 1.37 |  |  | $ | 1.58 |  |
| Operating cash flows |  | $ | 1,349.6 |  |  | $ | 1,386.3 |  |  | $ | 1,462.6 |  |

[0001193125-14-239169:mdna:12]
|  |  | April 25,2014 |  |  | April 26,2013 |  |
| Deferred revenue |  | $ | 3,100.2 |  |  | $ | 3,009.5 |  |
| Days sales outstanding (DSO) |  |  | 47 |  |  |  | 42 |  |

[0001193125-14-239169:mdna:13]
|  | • |  | Net revenues: Our net revenues decreased slightly in fiscal 2014 compared to fiscal 2013. This was primarily due to a decrease in OEM product revenues of 26%, partially offset by increases in hardware maintenance contract revenue generated from a higher installed base of our hardware products under maintenance contracts. |

[0001193125-14-239169:mdna:14]
|  | • |  | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues increased in fiscal 2014 compared to fiscal 2013 primarily due to lower unit materials costs due to supply chain efficiencies and changes in our revenue mix. Additionally, gross profit was favorably impacted by lower OEM revenues and higher gross profit margins on add-on storage. |

[0001193125-14-239169:mdna:15]
|  | • |  | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues increased in fiscal 2014 compared to fiscal 2013 primarily due to an increase in gross margins and the favorable impact of cost containment initiatives. |

[0001193125-14-239169:mdna:16]
|  | • |  | Net Income and Diluted Income per Share: The 26% and 34% increases in net income and diluted income per share, respectively, in fiscal 2014 compared to fiscal 2013 reflects higher operating income in dollars and as a percentage of net revenues, partially offset by a 3% increase in our effective tax rate. In addition to these factors, diluted income per share was favorably impacted by a 5% decrease in the number of dilutive shares, primarily due to higher share repurchases in fiscal 2014. |

[0001193125-14-239169:mdna:17]
|  | • |  | Operating cash flows: Operating cash flows decreased 3% in fiscal 2014, reflecting an increase in net income that was more than offset by changes in our operating assets and liabilities. |

[0001193125-14-239169:mdna:18]
|  | • |  | Deferred revenue: Total deferred revenue increased $90.7 million, or 3%, in fiscal 2014 compared to fiscal 2013 primarily due to an increase in deferred SEM and service revenue related to service contract sales and renewals. |

[0001193125-14-239169:mdna:19]
|  | • |  | DSO: DSO increased in the fourth quarter of fiscal 2014 compared to the fourth quarter of fiscal 2013 primarily due to a higher percentage of the fourth quarter’s shipments that occurred in the last month of the fourth quarter (shipment linearity) of fiscal 2014 compared to the corresponding period in the prior year. |

[0001193125-14-239169:mdna:20]
Stock Repurchase Program and Dividend Activity

[0001193125-14-239169:mdna:21]
During fiscal 2014, we repurchased 47.3 million shares of our common stock at an average price of $39.78 per share, for an aggregate of $1.9 billion. We also declared cash dividends of $0.60 per
share of common stock in fiscal 2014, for which we paid an aggregate of $202.3 million.

[0001193125-14-239169:mdna:22]
Restructuring Plans

[0001193125-14-239169:mdna:23]
In March 2014 and May 2013, we initiated business realignment plans designed to focus our resources on key strategic
initiatives and streamline our business in light of the constrained IT spending environment, resulting in a reduction of our global workforce of approximately 11% in aggregate, for which we have recognized an aggregate of $88.3 million of employee
severance costs in fiscal 2014. We have completed all activities under the May 2013 plan, and expect to complete activities under the March 2014 plan in the first six months of fiscal 2015, with no significant additional charges.

[0001193125-14-239169:mdna:24]
Recent Activity

[0001193125-14-239169:mdna:25]
On June 5, 2014 we issued $500.0 million principal amount of 3.375% Senior Notes due on June 15, 2021. We intend to use the net proceeds from this offering for general corporate purposes,
including possible stock

[0001193125-14-239169:mdna:26]
repurchases, dividends, capital expenditures, working capital and potential acquisitions and strategic transactions. For further information on the terms of this debt issuance, see Note 18 of the
accompanying consolidated financial statements.

[0001193125-14-239169:mdna:27]
Critical Accounting Policies and Estimates

[0001193125-14-239169:mdna:28]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States
of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are
based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the
accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001193125-14-239169:mdna:29]
The summary of significant accounting policies is included in Note 1 to the consolidated financial statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be
made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the
financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001193125-14-239169:mdna:30]
Revenue Recognition, Reserves and Allowances

[0001193125-14-239169:mdna:31]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable and collection is reasonably assured. Revenue from the sale of hardware
systems and software components essential to the functionality of the hardware systems is recognized in accordance with general revenue recognition accounting guidance. Our product revenues also include revenues from the sale of non-essential
software products, which generally includes a perpetual license to our software. Non-essential software sales are subject to industry specific software revenue recognition accounting guidance. SEM and premium hardware maintenance services are
recognized ratably over their contractual terms, generally from one to five years.

[0001193125-14-239169:mdna:32]
For multiple element arrangements, we
allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. For our non-software deliverables, we allocate the arrangement
consideration based on the relative selling price of the deliverables using estimated selling price (ESP). For our software entitlements and support services, we generally use vendor-specific objective evidence of selling price (VSOE). When we are
unable to establish VSOE for our software entitlements and support services, we use ESP in our allocation of arrangement consideration.

[0001193125-14-239169:mdna:33]
The selling price for each element is based upon the following selling price hierarchy: VSOE if available, third party evidence (TPE) if VSOE is not available, or estimated selling price (ESP) if neither
VSOE nor TPE are available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products
with similar functionality cannot be obtained.

[0001193125-14-239169:mdna:34]
We record reductions to revenue for estimated sales returns at the time of
shipment. We also maintain a separate allowance for doubtful accounts for estimated losses based on our assessment of the collectability of specific customer accounts.

[0001193125-14-239169:mdna:35]
The following are the key estimates and assumptions and corresponding uncertainties for
recognizing revenue:

[0001193125-14-239169:mdna:36]
| Key Estimates and Assumptions |  | Key Uncertainties |
| We establish VSOE of selling price using the price charged for a deliverable when sold separately and generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE. Our revenue estimates and assumptions are based on our ability to assert and maintain VSOE. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer type and distribution channels. Our revenue estimates and assumptions are based on our ability to maintain consistent ESP. |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of service offerings and/or changes in customer segmentation may result in a lack of consistency required to establish and/or maintain VSOE or to maintain consistent ESP. Additionally, technological changes resulting in variability in product costs and gross margins may require changes to our ESP model. Changes in ESP may result in a different allocation of revenue to the deliverables in multiple-element arrangements. These factors, among others, may adversely impact the amount of revenue and gross margins we report in a particular period. |
| Sales returns are estimated based on historical sales returns, current trends and our expectations regarding future experience. Additionally, distributors and partners participate in various marketing and other programs, and we maintain estimated accruals and allowances for these programs based on contractual terms and historical experience. |  | If there is insufficient relevant historical data for determining our sales returns estimates, or if we experience changes in practices related to sales returns or changes in market or competitive conditions resulting in higher than expected return rates, or if actual credits received by our distributors and partners deviate significantly from our estimates, our revenues may be adversely impacted. |
| Our allowance for bad debt is based on an analysis of accounts receivable and historical bad debts, customer concentration, customer solvency, current economic and geographic trends, and changes in customer payment terms and practices. |  | Our reserves for bad debt have generally been sufficient to cover credit losses. However, if the financial condition of our customers were to deteriorate, resulting in an impairment of their ability to make payments, additional allowances may be required. |

[0001193125-14-239169:mdna:37]
39

[0001193125-14-239169:mdna:38]
Inventory Valuation and Purchase Order Accruals

[0001193125-14-239169:mdna:39]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or market, which approximates
actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates
and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001193125-14-239169:mdna:40]
| Key Estimates and Assumptions |  | Key Uncertainties |
| We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. |
|  |  | We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
| We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001193125-14-239169:mdna:41]
Goodwill and Purchased Intangible Assets

[0001193125-14-239169:mdna:42]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair
values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair
values of the assets acquired and liabilities assumed.

[0001193125-14-239169:mdna:43]
The carrying values of purchased intangible assets are reviewed
whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our
intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001193125-14-239169:mdna:44]
We review goodwill for impairment annually and whenever events or changes in circumstances
indicate the carrying value of an asset may not be recoverable. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill
impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2014, we performed a quantitative test at the reporting unit level and determined the fair value substantially exceeded the carrying value for each reporting
unit and, therefore, found no impairment of goodwill.

[0001193125-14-239169:mdna:45]
The following are the key estimates and assumptions and corresponding
uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001193125-14-239169:mdna:46]
| Key Estimates and Assumptions |  | Key Uncertainties |
| The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair value of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
| Evaluations of possible goodwill and purchased intangible assets impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. |
|  |  | Assumptions and estimates about future values of our goodwill and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001193125-14-239169:mdna:47]
Product Warranties

[0001193125-14-239169:mdna:48]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues when the related revenue is recognized. We assess the adequacy of our warranty accrual each quarter and
adjust the amount as considered necessary.

[0001193125-14-239169:mdna:49]
41

[0001193125-14-239169:mdna:50]
The following are the key estimates and assumptions and corresponding uncertainties for
product warranties:

[0001193125-14-239169:mdna:51]
| Key Estimates and Assumptions |  | Key Uncertainties |
| Estimated future software and hardware warranty costs are based on historical and projected warranty claim rates, product failure rates, historical and projected materials and logistics costs, distribution and labor costs and knowledge of specific product failures that are outside of our typical experience. We also evaluate our estimates to assess the adequacy of our warranty liability considering the size of the installed base of products subject to warranty protection and adjust the estimates as necessary. |  | Although we engage in product quality programs and processes, if we experience unexpected quality issues resulting in higher failure rates or experience increases in costs to remediate product failures, additional warranty costs may be incurred. Additionally, for new products our warranty liability is based on limited historical experience. If our projections differ from such limited experience, our warranty costs may increase, which could adversely impact our gross margins. |

[0001193125-14-239169:mdna:52]
Stock-Based Compensation

[0001193125-14-239169:mdna:53]
We recognize stock-based compensation expense for all share-based payment awards, net of an estimated forfeiture rate, on a straight-line
basis over the requisite service period.

[0001193125-14-239169:mdna:54]
The following are the key estimates and assumptions and corresponding uncertainties
for our stock-based compensation:

[0001193125-14-239169:mdna:55]
| Key Estimates and Assumptions |  | Key Uncertainties |
| The fair value of employee stock options and rights to purchase shares under our Employee Stock Purchase Plan (ESPP) is estimated using the Black-Scholes option-pricing model. The key assumptions used in estimating the fair value of such awards include the expected term of the awards, risk free interest rates and the expected stock price volatility over the expected term of the awards. |  | To the extent that market conditions or company specific events lead to higher stock price volatility or employee stock option exercise behavior differs from expectations, the estimated fair value and stock-based compensation expense may differ significantly in future periods, which could impact our operating results. |
| Stock-based compensation expense is based on awards ultimately expected to meet service vesting conditions and is impacted by the estimated forfeiture rate. |  | If we experience employee turnover different from our historical rates, our stock-based compensation expense may differ significantly from what we have recorded in the current period. |

[0001193125-14-239169:mdna:56]
Valuation of Investment Securities

[0001193125-14-239169:mdna:57]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses
related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is
subject to market price volatility until they are sold. Our investment portfolio includes Auction Rate Securities (ARSs), which we classify as long-term investments as there is no active market and we believe our ability to liquidate these
investments in the next twelve months is uncertain.

[0001193125-14-239169:mdna:58]
42

[0001193125-14-239169:mdna:59]
The following are the key estimates and assumptions and corresponding uncertainties for the
valuation of our investment securities:

[0001193125-14-239169:mdna:60]
| Key Estimates and Assumptions |  | Key Uncertainties |
| The estimated fair value of our debt securities, excluding ARSs, and the associated accounting for unrealized losses is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent a security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. If we determine that an investment has an other-than-temporary decline in fair value, we recognize the investment loss in earnings. |  | The fair value of our investments in debt securities, including ARSs, could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer, decreases in the marketability of the securities or changes in our ability and intent to continue to hold the securities. If the fair value of our investments decreases significantly and is determined to be other-than-temporary, we may incur impairment charges that could adversely affect our results of operations. |
| In estimating the fair value of our ARSs we consider the assessments of the underlying structure of each security, discounted expected cash flows, credit ratings, workout periods, trading activity for similar securities in the secondary market and overall capital market liquidity. |  |  |

[0001193125-14-239169:mdna:61]
Income Taxes

[0001193125-14-239169:mdna:62]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and
liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and
liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax
assets to the amount that is believed more likely than not to be realized.

[0001193125-14-239169:mdna:63]
43

[0001193125-14-239169:mdna:64]
The following are the key estimates and assumptions and corresponding uncertainties for our
income taxes:

[0001193125-14-239169:mdna:65]
| Key Estimates and Assumptions |  | Key Uncertainties |
| Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
| Deferred income taxes have not been provided on the undistributed earnings of foreign subsidiaries because these earnings have been indefinitely reinvested and there is no plan in the foreseeable future to initiate any action that would precipitate the payment of income taxes thereon. |  | We consider the following matters, among others, in evaluating our plans for indefinite reinvestment: the forecasts, budgets and financial requirements of the parent and subsidiaries for both the long and short term; the tax consequences of a decision to reinvest; and any U.S. and foreign government programs designed to influence remittances. If factors change, future income tax expense and payments may differ significantly from the current period and could materially adversely affect our results of operations. |
| The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | Our future profits could change resulting in a change to our determination as to the amount of deferred tax assets that can be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001193125-14-239169:mdna:66]
New Accounting Standards

[0001193125-14-239169:mdna:67]
See Note 3 of the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of
operations and financial condition.

[0001193125-14-239169:mdna:68]
Results of Operations

[0001193125-14-239169:mdna:69]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001193125-14-239169:mdna:70]
|  |  | Year Ended |  |
|  |  | April 25,2014 |  |  | April 26,2013 |  |  | April 27,2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 62.3 | % |  |  | 64.6 | % |  |  | 67.6 | % |
| Software entitlements and maintenance |  |  | 14.5 |  |  |  | 14.1 |  |  |  | 13.0 |  |
| Service |  |  | 23.2 |  |  |  | 21.3 |  |  |  | 19.4 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28.1 |  |  |  | 31.0 |  |  |  | 31.7 |  |
| Cost of software entitlements and maintenance |  |  | 0.5 |  |  |  | 0.4 |  |  |  | 0.4 |  |
| Cost of service |  |  | 9.4 |  |  |  | 9.2 |  |  |  | 8.3 |  |
| Gross profit |  |  | 62.0 |  |  |  | 59.4 |  |  |  | 59.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30.0 |  |  |  | 31.2 |  |  |  | 29.9 |  |
| Research and development |  |  | 14.5 |  |  |  | 14.3 |  |  |  | 13.3 |  |
| General and administrative |  |  | 4.5 |  |  |  | 4.3 |  |  |  | 4.2 |  |
| Restructuring and other charges |  |  | 1.4 |  |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 0.2 |  |
| Total operating expenses |  |  | 50.4 |  |  |  | 49.8 |  |  |  | 47.6 |  |
| Income from operations |  |  | 11.6 |  |  |  | 9.6 |  |  |  | 12.0 |  |
| Other income (expense), net |  |  | 0.1 |  |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Income before income taxes |  |  | 11.7 |  |  |  | 9.0 |  |  |  | 11.4 |  |
| Provision for income taxes |  |  | 1.6 |  |  |  | 1.0 |  |  |  | 1.7 |  |
| Net income |  |  | 10.1 | % |  |  | 8.0 | % |  |  | 9.7 | % |

[0001193125-14-239169:mdna:71]
Discussion and Analysis of Results of Operations

[0001193125-14-239169:mdna:72]
Overview — Net revenues for fiscal 2014 were $6,325.1 million, down $7.3 million, or less than 1%, compared to fiscal
2013, reflecting a decrease in product revenues, mostly offset by increases in hardware maintenance contract and SEM revenues.

[0001193125-14-239169:mdna:73]
Net revenues for fiscal 2013 were $6,332.4 million, up $99.2 million, or 2%, compared to fiscal 2012. The increase was due to
increases in hardware maintenance contract and SEM revenues.

[0001193125-14-239169:mdna:74]
Gross profit as a percentage of net revenues increased 2.6%
during fiscal 2014 compared to fiscal 2013, primarily due to lower unit materials costs due to supply chain efficiencies, partially offset by a lower average selling price (ASP) for total configured systems. Additionally, gross profit was favorably
impacted by lower OEM revenues and higher margins on service revenues.

[0001193125-14-239169:mdna:75]
Gross profit as a percentage of net revenues decreased
less than 1% during fiscal 2013 compared to fiscal 2012.

[0001193125-14-239169:mdna:76]
Sales and marketing, research and development, and general and
administrative expenses for fiscal 2014 totaled $3,096.5 million, down 1% as a percentage of net revenues compared to fiscal 2013, reflecting cost control programs implemented in fiscal 2014, partially offset by an increase in incentive compensation
due to higher achievement against plan.

[0001193125-14-239169:mdna:77]
Sales and marketing, research and development and general and administrative expenses for
fiscal 2013 totaled $3,151.6 million, up 7% compared to fiscal 2012. The increase was primarily due to increased compensation costs resulting from a 9% increase in average headcount during fiscal 2013 compared to fiscal 2012.

[0001193125-14-239169:mdna:78]
Net Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:79]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Net revenues |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |  |  | — |  |  | $ | 6,233.2 |  |  |  | 2 | % |

[0001193125-14-239169:mdna:80]
The slight decrease in net revenues for fiscal 2014 was due to a decrease of $148.4 million in product
revenues, offset by an aggregate increase in service and SEM revenues of $141.1 million. Product revenues comprised 62% of net revenues for fiscal 2014, compared to 65% of net revenues for fiscal 2013.

[0001193125-14-239169:mdna:81]
The increase in net revenues for fiscal 2013 was due to increases in service and SEM revenues of $216.6 million, partially offset by a
decrease in product revenues of $117.4 million. Product revenues comprised 65% of net revenues for fiscal 2013, compared to 68% of net revenues for fiscal 2012.

[0001193125-14-239169:mdna:82]
Sales through our indirect channels represented 82%, 81% and 78% of net revenues in fiscal 2014, 2013 and 2012, respectively. Included in indirect channel sales were $584.7 million, $787.2 million and
$889.5 million of OEM revenues for fiscal 2014, 2013 and 2012, respectively.

[0001193125-14-239169:mdna:83]
The following customers, each of which is a
distributor, accounted for 10% or more of net revenues:

[0001193125-14-239169:mdna:84]
|  |  | Year Ended |  |
|  |  | April 25,2014 |  |  | April 26,2013 |  |  | April 27,2012 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 19 | % |  |  | 17 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 15 | % |  |  | 12 | % |

[0001193125-14-239169:mdna:85]
Product Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:86]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Product revenues |  | $ | 3,943.9 |  |  | $ | 4,092.3 |  |  |  | (4 | )% |  | $ | 4,209.7 |  |  |  | (3 | )% |

[0001193125-14-239169:mdna:87]
Product revenues consist of configured systems, which include bundled hardware and software products, and
non-configured products, which consist primarily of add-on storage, OEM products and add-on hardware and software products. Please refer to the Executive Overview- Our Company section for a description of how, effective the fourth quarter of
fiscal 2014, we aggregate our FAS product platforms into entry-level, mid-range and high-end systems for reporting purposes.

[0001193125-14-239169:mdna:88]
Total configured system revenues of $2,287.3 million increased by $4.2 million in fiscal 2014 compared to fiscal 2013. Revenues from FAS
high-end systems and E-Series (which includes our all flash EF systems) increased, offset by decreases in FAS entry level and mid-range systems. Total configured systems unit volume increased 1.6% during fiscal 2014 compared to fiscal 2013,
primarily as a result of unit increases in the FAS high-end and mid-range systems and E-Series systems, partially offset by a decrease in unit volume of the FAS entry level systems, reflecting a shift in customer demand to our newer mid-range and
high-end products, lower sales to the U.S. public sector market, and higher demand for our E-Series systems. The average selling prices (ASP’s) decreased across all FAS system platforms in fiscal 2014 compared to fiscal 2013 due to higher

[0001193125-14-239169:mdna:89]
discounting and higher demand of newer lower priced products, while the ASP for E-Series increased due to higher ASPs on all-flash E-Series systems. Overall, ASPs of total configured systems
decreased 1% during fiscal 2014 due to higher discounting and product mix.

[0001193125-14-239169:mdna:90]
Non-configured product revenues of $1,656.6
million decreased $152.6 million, or 8%, during fiscal 2014 compared to fiscal 2013. This decrease was primarily due to lower revenues from non-configured OEM products, which declined 26%.

[0001193125-14-239169:mdna:91]
Total configured system revenues of $2,283.1 million increased by $63.4 million, or 3%, in fiscal 2013 compared to fiscal 2012, primarily
due to an increase in revenues from FAS entry-level and high-end systems, partially offset by a decrease in FAS mid-range systems. Total configured systems unit volume increased 9% during fiscal 2013 compared to fiscal 2012. Unit volume for both the
FAS entry-level and high-end systems increased, while unit volume of the FAS mid-range systems decreased, reflecting a shift in customer demand from certain older mid-range systems to certain entry level systems and increased demand for the high-end
systems. The ASP’s across all FAS configured systems increased due to increased capacity during fiscal 2013 compared to fiscal 2012. However, ASPs of total configured systems decreased during fiscal 2013, due to a shift in sales from higher
priced FAS mid-range systems to lower priced entry level systems.

[0001193125-14-239169:mdna:92]
Non-configured product revenues of $1,809.1 million
decreased $180.9 million, or 9%, during fiscal 2013 compared to fiscal 2012. This decrease was primarily due to lower revenues from non-configured OEM products, which declined 11%, and lower add-on storage revenues.

[0001193125-14-239169:mdna:93]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause
a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing changes, discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and
product materials costs can also impact revenues, cost of revenues and/or gross profits. Disks are a significant component of our storage systems. While our sales price per terabyte historically declines over time, improved system performance,
increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001193125-14-239169:mdna:94]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:95]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 914.8 |  |  | $ | 893.5 |  |  |  | 2 | % |  | $ | 812.2 |  |  |  | 10 | % |

[0001193125-14-239169:mdna:96]
SEM revenues are associated with contracts which entitle customers to receive unspecified product
upgrades and enhancements on a when-and-if-available basis, as well as bug fixes and patch releases.

[0001193125-14-239169:mdna:97]
The increases in SEM
revenues in each period were due to increases in the aggregate contract value of the installed base under SEM contracts, which is recognized as revenue ratably over the terms of the underlying contracts. In addition, in fiscal 2014, our SEM revenues
were favorably impacted by a change in our pricing strategy, effective in the fourth quarter of that period, such that we now charge for SEM services on the storage capacity sold in our configured systems and add-on storage products. We expect this
change to result in favorable trends in our SEM revenues as a percentage of total revenues in fiscal 2015.

[0001193125-14-239169:mdna:98]
Service
Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:99]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Service revenues |  | $ | 1,466.4 |  |  | $ | 1,346.6 |  |  |  | 9 | % |  | $ | 1,211.3 |  |  |  | 11 | % |

[0001193125-14-239169:mdna:100]
47

[0001193125-14-239169:mdna:101]
Service revenues include hardware maintenance, professional services and educational and
training services.

[0001193125-14-239169:mdna:102]
Hardware maintenance contract revenues represent 77%, 74% and 70%, of service revenues in fiscal 2014,
2013 and 2012, respectively. These revenues increased $137.8 million, or 14%, during fiscal 2014 compared to fiscal 2013, and increased $143.5 million, or 17%, during fiscal 2013 compared to fiscal 2012. The increases in each year are a result of
increases in the installed base and aggregate contract values under service contracts. Professional services and educational and training services comprised 23%, 26% and 30% of service revenues for fiscal 2014, 2013 and 2012, respectively.

[0001193125-14-239169:mdna:103]
Revenues by Geographic Area (in millions, except percentages):

[0001193125-14-239169:mdna:104]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 3,513.3 |  |  | $ | 3,552.5 |  |  |  | (1 | )% |  | $ | 3,529.7 |  |  |  | 1 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 1,954.6 |  |  |  | 1,928.8 |  |  |  | 1 | % |  |  | 1,936.5 |  |  |  | — | % |
| Asia Pacific (APAC) |  |  | 857.2 |  |  |  | 851.1 |  |  |  | 1 | % |  |  | 767.0 |  |  |  | 11 | % |
| Net revenues |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |  |  |  |  |  | $ | 6,233.2 |  |  |  |  |  |

[0001193125-14-239169:mdna:105]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. During fiscal
2014, Americas revenues were unfavorably impacted by a decrease in sales to the U.S. public sector market. During fiscal 2013, EMEA revenues were negatively impacted by the general macroeconomic conditions in the region.

[0001193125-14-239169:mdna:106]
Sales to customers inside the United States comprised 89%, 89% and 86% of Americas net revenues during fiscal 2014, 2013 and 2012,
respectively. Sales to Germany accounted for $632.6 million for fiscal 2012. No other foreign country accounted for 10% or more of our net revenues in an individual fiscal year.

[0001193125-14-239169:mdna:107]
Cost of Revenues

[0001193125-14-239169:mdna:108]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible
assets, inventory write-downs, and warranty costs, (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs and (3) cost of service revenues, which includes costs associated with providing support activities
for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001193125-14-239169:mdna:109]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency, product
configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of
support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our
gross profit could decline.

[0001193125-14-239169:mdna:110]
Cost of Product Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:111]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,777.1 |  |  | $ | 1,959.9 |  |  |  | (9 | )% |  | $ | 1,979.9 |  |  |  | (1 | )% |

[0001193125-14-239169:mdna:112]
48

[0001193125-14-239169:mdna:113]
The changes in cost of product revenues consisted of the following (in percentage points of
the total change):

[0001193125-14-239169:mdna:114]
|  |  | Fiscal 2014 toFiscal 2013PercentageChangePoints |  |  | Fiscal 2013 toFiscal 2012PercentageChangePoints |  |
| Materials cost |  |  | (7 | ) |  |  | (3 | ) |
| Excess and obsolete inventory |  |  | (1 | ) |  |  | 1 |  |
| Warranty |  |  | (1 | ) |  |  | 1 |  |
| Total change |  |  | (9 | ) |  |  | (1 | ) |

[0001193125-14-239169:mdna:115]
Cost of product revenues represented 45%, 48% and 47% of product revenues for fiscal 2014, 2013 and 2012,
respectively.

[0001193125-14-239169:mdna:116]
Materials cost represented 84%, 83% and 85% of product costs for fiscal 2014, 2013 and 2012, respectively.

[0001193125-14-239169:mdna:117]
Materials cost decreased $129.0 million in fiscal 2014 compared to fiscal 2013 due to an overall decrease in average unit
materials cost across all FAS platforms, reflecting increased supply chain efficiencies and favorable changes in product mix. Additionally, materials cost was favorably impacted by lower OEM product volume compared to fiscal 2013 and to lower
materials cost of add-on hardware and storage. This decrease was partially offset by a 1.6% unit volume increase in configured systems, resulting in higher gross margins on products compared to fiscal 2013. In addition, cost of product revenues in
fiscal 2014 was favorably impacted by a $24.6 million decrease in hardware-related warranty expense and a $14.1 million decrease in excess and obsolete inventory write-downs compared to fiscal 2013.

[0001193125-14-239169:mdna:118]
Materials cost decreased $58.9 million in fiscal 2013 compared to fiscal 2012 due to change in mix of configured systems towards lower
cost FAS entry level systems, lower drive costs and lower OEM product volume, resulting in an overall decrease in average unit materials cost. This decrease was partially offset by a 9% unit volume increase in configured systems. In addition, cost
of product revenues in fiscal 2013 reflected a $26.9 million increase in hardware-related warranty expense and an $11.7 million increase in inventory write-downs compared to fiscal 2012.

[0001193125-14-239169:mdna:119]
Cost of Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:120]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 30.7 |  |  | $ | 28.3 |  |  |  | 8 | % |  | $ | 23.9 |  |  |  | 18 | % |

[0001193125-14-239169:mdna:121]
Cost of SEM revenues increased primarily due to higher royalty costs in fiscal 2014 compared to fiscal
2013 and in fiscal 2013 compared to fiscal 2012. Cost of SEM revenues represented 3% of SEM revenues for fiscal 2014, 2013 and 2012.

[0001193125-14-239169:mdna:122]
Cost of Service Revenues (in millions, except percentages):

[0001193125-14-239169:mdna:123]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Cost of service revenues |  | $ | 598.2 |  |  | $ | 583.1 |  |  |  | 3 | % |  | $ | 516.0 |  |  |  | 13 | % |

[0001193125-14-239169:mdna:124]
Cost of service revenues increased in fiscal 2014 compared to 2013 primarily due to increases in spares
materials costs and a higher volume of service calls related to a higher service contract base, largely offset by

[0001193125-14-239169:mdna:125]
headcount related savings and lower per unit logistics and service delivery costs. Cost of service revenues increased in fiscal 2013 compared to 2012 primarily due to increases in service
contract fulfillment, logistics and service delivery costs. Costs represented 41%, 43% and 43% of service revenues for fiscal 2014, 2013 and 2012.

[0001193125-14-239169:mdna:126]
Operating Expenses

[0001193125-14-239169:mdna:127]
Sales and Marketing, Research and Development
and General and Administrative Expenses

[0001193125-14-239169:mdna:128]
Compensation costs comprise the largest component of operating expenses. Included
in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001193125-14-239169:mdna:129]
Total compensation costs included in operating expenses increased $28.2 million, or 2% during fiscal 2014 compared to fiscal 2013, primarily due to increases in incentive compensation reflecting stronger
operating performance against goals.

[0001193125-14-239169:mdna:130]
Total compensation costs included in operating expenses increased $111.1 million, or 7%
during fiscal 2013 compared to fiscal 2012, primarily due to an increase in salaries, benefits and other compensation-related costs due to an increase in average headcount.

[0001193125-14-239169:mdna:131]
Sales and Marketing (in millions, except percentages):

[0001193125-14-239169:mdna:132]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,898.2 |  |  | $ | 1,974.8 |  |  |  | (4 | )% |  | $ | 1,864.0 |  |  |  | 6 | % |

[0001193125-14-239169:mdna:133]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services,
allocated facilities and IT costs, advertising and marketing promotional expense and travel and entertainment expense. Sales and marketing expenses increased (decreased) due to the following:

[0001193125-14-239169:mdna:134]
|  |  | Fiscal 2014 toFiscal 2013PercentageChangePoints |  |  | Fiscal 2013 toFiscal 2012PercentageChangePoints |  |
| Compensation costs |  |  | — |  |  |  | 3 |  |
| Depreciation and amortization |  |  | (1 | ) |  |  | — |  |
| Facilities and IT support costs |  |  | 1 |  |  |  | 2 |  |
| Other |  |  | (4 | ) |  |  | 1 |  |
| Total change |  |  | (4 | ) |  |  | 6 |  |

[0001193125-14-239169:mdna:135]
Compensation costs during fiscal 2014 reflect higher incentive compensation that was more than offset by
lower stock-based compensation and salaries expense. Depreciation and amortization expense decreased during fiscal 2014 due to certain intangible assets becoming fully amortized during fiscal 2013. Facilities and IT support costs increased during
fiscal 2014 due to our increased investment in sales IT systems. The decrease in other sales and marketing expenses was primarily due to our fiscal 2014 cost containment programs.

[0001193125-14-239169:mdna:136]
The increase in compensation costs during fiscal 2013 is primarily due to higher salaries and stock-based compensation resulting from a
9% increase in average sales and marketing headcount compared to fiscal 2012. Facilities and IT support costs increased during fiscal 2013 due to our increased investment in sales IT systems.

[0001193125-14-239169:mdna:137]
Research and Development (in millions, except percentages):

[0001193125-14-239169:mdna:138]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Research and development expenses |  | $ | 917.3 |  |  | $ | 904.2 |  |  |  | 1 | % |  | $ | 828.2 |  |  |  | 9 | % |

[0001193125-14-239169:mdna:139]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT
costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Research and development expense increased (decreased) due to the following:

[0001193125-14-239169:mdna:140]
|  |  | Fiscal 2014 toFiscal 2013PercentageChangePoints |  |  | Fiscal 2013 toFiscal 2012PercentageChangePoints |  |
| Compensation costs |  |  | 2 |  |  |  | 6 |  |
| Depreciation |  |  | 1 |  |  |  | 2 |  |
| Development projects |  |  | (1 | ) |  |  | 1 |  |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | 1 |  |  |  | 9 |  |

[0001193125-14-239169:mdna:141]
The increase in compensation costs during fiscal 2014 is primarily due to higher incentive compensation.
Depreciation expense during fiscal 2014 increased due to higher levels of investment in engineering equipment. The decrease in development projects expense during fiscal 2014 reflects lower spending on materials and services associated with
engineering activities to develop new product lines and enhancements to existing products.

[0001193125-14-239169:mdna:142]
The increase in compensation costs
during fiscal 2013 is primarily due to higher salaries, stock-based compensation and incentive compensation resulting from an increase of 9% in average engineering headcount compared to fiscal 2012. Depreciation and amortization expense increased
during fiscal 2013 due to higher levels of investment in engineering equipment.

[0001193125-14-239169:mdna:143]
We believe that our future performance will
depend in large part on our ability to maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to
continue to spend on current and future product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-14-239169:mdna:144]
General and Administrative (in millions, except percentages):

[0001193125-14-239169:mdna:145]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| General and administrative expenses |  | $ | 281.0 |  |  | $ | 272.6 |  |  |  | 3 | % |  | $ | 264.9 |  |  |  | 3 | % |

[0001193125-14-239169:mdna:146]
General and administrative expenses consist primarily of compensation costs, professional
and corporate legal fees, outside services and allocated facilities and IT support costs. General and administrative expense increased (decreased) due to the following:

[0001193125-14-239169:mdna:147]
|  |  | Fiscal 2014 toFiscal 2013PercentageChangePoints |  |  | Fiscal 2013 toFiscal 2012PercentageChangePoints |  |
| Compensation costs |  |  | 5 |  |  |  | 3 |  |
| Professional and legal fees and outside services |  |  | 1 |  |  |  | (2 | ) |
| Bad debt expense |  |  | (2 | ) |  |  | 1 |  |
| Other |  |  | (1 | ) |  |  | 1 |  |
| Total change |  |  | 3 |  |  |  | 3 |  |

[0001193125-14-239169:mdna:148]
The increase in compensation costs in fiscal 2014 is primarily due to higher incentive compensation and
to a lesser extent higher stock-based compensation and salaries expense. The increase in professional and legal fees and outside services during fiscal 2014 reflects higher fees related to legal activities, partially offset by lower spending levels
on contractors and professional services. Bad debt expense in fiscal 2014 decreased $6.5 million compared to fiscal 2013.

[0001193125-14-239169:mdna:149]
The
increase in compensation costs in fiscal 2013 is primarily due to higher salaries resulting from an increase of 8% in average general and administrative headcount during fiscal 2013 compared to fiscal 2012. The decreases in outside services during
fiscal 2013 reflect lower spending on contractors and various operational projects, as well as the absence of Engenio integration activities in fiscal 2013 compared to fiscal 2012.

[0001193125-14-239169:mdna:150]
Acquisition-related Expense (in millions, except percentages):

[0001193125-14-239169:mdna:151]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Acquisition-related expense |  | $ | — |  |  | $ | 1.7 |  |  |  | (100 | )% |  | $ | 9.8 |  |  |  | (83 | )% |

[0001193125-14-239169:mdna:152]
During fiscal 2013, we incurred $1.7 million of acquisition costs, primarily related to severance costs
associated with the termination of certain acquiree company employees. During fiscal 2012, we incurred $9.8 million of due diligence, legal and integration charges associated with our acquisition of Engenio.

[0001193125-14-239169:mdna:153]
Restructuring and Other Charges:

[0001193125-14-239169:mdna:154]
In March 2014 and May 2013, we initiated business realignment plans designed to focus our resources on key strategic initiatives and streamline our business in light of the constrained IT spending
environment, resulting in a reduction of our global workforce of approximately 11% in aggregate, for which we have recognized an aggregate of $88.3 million of employee severance costs in fiscal 2014. We have completed all activities under the May
2013 plan, and expect to complete activities under the March 2014 plan in the first six months of fiscal 2015, with no significant additional charges.

[0001193125-14-239169:mdna:155]
Other Income, Net

[0001193125-14-239169:mdna:156]
Interest Income (in millions, except
percentages):

[0001193125-14-239169:mdna:157]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Interest income |  | $ | 34.9 |  |  | $ | 42.2 |  |  |  | (17 | )% |  | $ | 38.2 |  |  |  | 10 | % |

[0001193125-14-239169:mdna:158]
The decrease in interest income for fiscal 2014 compared to fiscal 2013 was primarily due to
a decrease in our investment portfolio as a result of the liquidation of some of our investments to repay our Convertible Notes and to pay for stock repurchases.

[0001193125-14-239169:mdna:159]
The increase in interest income for fiscal 2013 compared to fiscal 2012 was primarily due to increases in our investment portfolio, partially offset by lower yields.

[0001193125-14-239169:mdna:160]
Interest Expense (in millions, except percentages):

[0001193125-14-239169:mdna:161]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Interest expense |  | $ | (36.1 | ) |  | $ | (91.7 | ) |  |  | (61 | )% |  | $ | (74.7 | ) |  |  | 23 | % |

[0001193125-14-239169:mdna:162]
Interest expense, including the amortization of debt discount and issuance costs, is related to our
Senior Notes and Convertible Notes as summarized below:

[0001193125-14-239169:mdna:163]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Senior Notes |  | $ | 25.1 |  |  | $ | 9.4 |  |  | $ | — |  |
| Convertible Notes |  |  | 10.2 |  |  |  | 81.2 |  |  |  | 73.5 |  |
| Total |  | $ | 35.3 |  |  | $ | 90.6 |  |  | $ | 73.5 |  |

[0001193125-14-239169:mdna:164]
The increase in interest expense related to our Senior Notes in fiscal 2014 compared to fiscal 2013
reflects their issuance in December 2012. The decrease in interest expense related to our Convertible Notes in fiscal 2014 compared to fiscal 2013 reflects their maturity in June 2013.

[0001193125-14-239169:mdna:165]
The increase in interest expense related to our Convertible Notes in fiscal 2013 compared to fiscal 2012 reflects lower capitalized
interest and higher amortization of debt discount and issuance costs.

[0001193125-14-239169:mdna:166]
Other Income, Net (in millions, except percentages):

[0001193125-14-239169:mdna:167]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Other income, net |  | $ | 7.6 |  |  | $ | 8.3 |  |  |  | (8 | )% |  | $ | 2.4 |  |  |  | 246 | % |

[0001193125-14-239169:mdna:168]
The decrease in other income, net for fiscal 2014 compared to fiscal 2013 is primarily due to lower net
foreign exchange gains, partially offset by higher unrealized net gains on investments. The increase in other income, net for fiscal 2013 compared to fiscal 2012 is primarily due to net foreign exchange gains.

[0001193125-14-239169:mdna:169]
Provision for Income Taxes (in millions, except percentages):

[0001193125-14-239169:mdna:170]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | % Change |  |  | April 27, 2012 |  |  | % Change |  |
| Provision for income taxes |  | $ | 103.2 |  |  | $ | 61.3 |  |  |  | 68 | % |  | $ | 107.0 |  |  |  | (43 | )% |

[0001193125-14-239169:mdna:171]
Our effective tax rate for fiscal 2014 was 13.9% compared to an effective tax rate of 10.8% for fiscal
2013, and an effective tax rate of 15.0% for fiscal 2012. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign
jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for fiscal 2012 through fiscal 2014 were favorably impacted by the geographic mix of profits.

[0001193125-14-239169:mdna:172]
The effective tax rate of 13.9% in fiscal 2014 included a benefit of $163.3 million, or 22.0
percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $8.7 million, or 1.2 percentage points, related
to current year research and development credits, an expense of $9.8 million, or 1.3 percentage points, attributable to non-deductible stock-based compensation and an expense of $5.6 million, or 0.8 percentage points, related to state tax
provisions.

[0001193125-14-239169:mdna:173]
The effective tax rate of 10.8% in fiscal 2013 included a benefit of $144.4 million, or 25.5 percentage points,
from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $12.1 million, or 2.1 percentage points, related to current year
research and development credits, and an expense of $18.4 million, or 3.2 percentage points, attributable to non-deductible stock-based compensation.

[0001193125-14-239169:mdna:174]
The effective tax rate of 15.0% in fiscal 2012 included a benefit of $162.2 million, or 22.8 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate
of 35%. Other key components of our effective tax rate for the year included a benefit of $10.9 million, or 1.5 percentage points, related to research and development credits, an expense of $14.4 million, or 2.0 percentage points, attributable to
non-deductible stock-based compensation, an expense of $6.4 million, or 0.9 percentage points, for state tax expense and an expense of $7.3 million, or 1.0 percentage point, in connection with income tax audits.

[0001193125-14-239169:mdna:175]
On January 2, 2013, the American Taxpayer Relief Act of 2012 (the Act) was signed into law. Under the Act, the federal research
credit was retroactively extended for amounts paid or incurred after December 31, 2011, and before January 1, 2014. As a result of the extension, in fiscal 2013 we recorded a benefit of $12.1 million related to the fiscal 2013 research
credit and a benefit of $3.2 million related to prior year credits that we retroactively claimed. The federal research credit expired on December 31, 2013.

[0001193125-14-239169:mdna:176]
We are currently undergoing federal income tax audits in the United States and several foreign tax jurisdictions. Transfer pricing is a key issue under audit in various jurisdictions, and is often subject
to dispute. Our fiscal 2005 through 2007 income tax returns are currently under audit by the IRS. On May 19, 2014, we received a Revenue Agent’s Report (RAR) from the IRS field examination team for the audit period. The RAR is subject to
further review and approval by certain higher authorities within the IRS before submission to the Joint Committee of Taxation for final review and approval. We expect to close our fiscal 2005 through 2007 income tax audit within the next twelve
months. Our fiscal 2008 through fiscal 2010 income tax returns are currently under audit by the IRS. We are currently in the process of responding to inquiries from the IRS examination team. We expect the IRS examination team to finish the field
audit within the next twelve months. In January 2014, the California Franchise Tax Board temporarily closed the audit of our fiscal 2007 and 2008 income tax returns and will reopen the audit upon the conclusion of the applicable federal IRS audits.

[0001193125-14-239169:mdna:177]
Our open years in U.S. federal jurisdictions are fiscal 2005 and later years. In addition, we are effectively subject to
federal tax examination adjustments for tax years ended on or after fiscal year 2000, in that we have tax attribute carryforwards from these years that could be subject to adjustments, if and when utilized.

[0001193125-14-239169:mdna:178]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our
Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the
Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed the ruling to the Danish High Court in March 2012.

[0001193125-14-239169:mdna:179]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the
statute of limitations in various taxing jurisdictions, as further discussed in Note 13

[0001193125-14-239169:mdna:180]
of the accompanying consolidated financial statements. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude or statutes of limitations on
certain income tax examination periods will expire, or both. Given the uncertainties involved in all tax audits, we can only determine a range of estimated potential increase in underlying unrecognized tax benefits ranging from $23.5 million to
approximately $45.9 million.

[0001193125-14-239169:mdna:181]
Liquidity and Capital Resources

[0001193125-14-239169:mdna:182]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and capital resources. The principal objectives of our investment policy
are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors
closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 25,
2014.

[0001193125-14-239169:mdna:183]
Liquidity, Capital Resources and Cash Requirements

[0001193125-14-239169:mdna:184]
| ($ in Millions) |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Cash and cash equivalents and short-term investments |  | $ | 5,003.3 |  |  | $ | 6,952.6 |  |
| Current portion of principal amount of Convertible Notes |  |  | — |  |  |  | 1,264.9 |  |
| Principal amount of Senior Notes |  |  | 1,000.0 |  |  |  | 1,000.0 |  |
| Debt as a % of stockholders’ equity |  |  | 26 | % |  |  | 48 | % |

[0001193125-14-239169:mdna:185]
The following is a summary of our cash flow activities:

[0001193125-14-239169:mdna:186]
|  |  | Year Ended |  |
| (In Millions) |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Net cash provided by operating activities |  | $ | 1,349.6 |  |  | $ | 1,386.3 |  |
| Net cash provided by (used in) investing activities |  |  | 760.4 |  |  |  | (228.6 | ) |
| Net cash provided by (used in) financing activities |  |  | (3,104.0 | ) |  |  | 578.9 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 7.9 |  |  |  | (9.3 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (986.1 | ) |  | $ | 1,727.3 |  |

[0001193125-14-239169:mdna:187]
Cash Flows

[0001193125-14-239169:mdna:188]
As of April 25, 2014, our cash, cash equivalents and short-term investments decreased by $1.9 billion from April 26, 2013 to $5.0 billion. The decrease was primarily due to the
repayment of the principal amount of our Convertible Notes of $1.3 billion and $1.9 billion in cash paid for the repurchase of our common stock, partially offset by $1.3 billion of cash provided by operating activities. We derive our liquidity and
capital resources primarily from our operating cash flows and from working capital. Accounts receivable days sales outstanding as of April 25, 2014 were 47 days compared to 42 days as of April 26, 2013. Working capital decreased
by $0.8 billion to $3.8 billion as of April 25, 2014 as a result of a decrease of $1.9 billion in current assets, primarily due to the net decrease in cash, cash equivalents and short-term investments, partially offset by a decrease of
$1.1 billion in current liabilities, primarily due to the maturity of our Convertible Notes in the first quarter of fiscal 2014.

[0001193125-14-239169:mdna:189]
Cash Flows from Operating Activities

[0001193125-14-239169:mdna:190]
During fiscal 2014, we generated cash
from operating activities of $1.3 billion. The primary sources of cash from operating activities during fiscal 2014 consisted of net income of $637.5 million, adjusted by depreciation and amortization of $334.1 million and stock-based
compensation of $273.0 million.

[0001193125-14-239169:mdna:191]
Changes in assets and liabilities during fiscal 2014 included the following:

[0001193125-14-239169:mdna:192]
|  | • |  | Accounts receivable increased primarily due to the impact of more back-ended shipment linearity in the fourth quarter of fiscal 2014 compared to the corresponding period in the prior year. |

[0001193125-14-239169:mdna:193]
|  | • |  | Deferred revenue increased due to an increase in deferred SEM and service revenue. |

[0001193125-14-239169:mdna:194]
During fiscal 2013, we generated cash from operating activities of $1.4 billion. The primary sources of cash from operating
activities during fiscal 2013 consisted of net income of $505.3 million, adjusted by depreciation and amortization of $344.6 million and stock-based compensation of $276.6 million.

[0001193125-14-239169:mdna:195]
Changes in assets and liabilities during fiscal 2013 included the following:

[0001193125-14-239169:mdna:196]
|  | • |  | Deferred revenue increased due to an increase in deferred SEM and service revenues. |

[0001193125-14-239169:mdna:197]
|  | • |  | Accrued compensation and other current liabilities increased due to an increase in hardware-related warranty accruals and employee compensation plans. |

[0001193125-14-239169:mdna:198]
We expect that cash provided by operating activities may materially fluctuate in future periods as a
result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based compensation, and the
timing and amount of compensation and other payments.

[0001193125-14-239169:mdna:199]
Cash Flows from Investing Activities

[0001193125-14-239169:mdna:200]
During fiscal 2014, we generated $975.0 million from maturities and sales of investments, net of purchases, and paid $221.4 million for
capital expenditures.

[0001193125-14-239169:mdna:201]
During fiscal 2013, we generated $177.0 million from maturities and sales of investments, net of
purchases, completed business acquisitions for net cash payments of $106.5 million and paid $303.3 million for capital expenditures, including $69.6 million related to buildings and land associated with the buyout of our remaining synthetic leases.

[0001193125-14-239169:mdna:202]
Cash Flows from Financing Activities

[0001193125-14-239169:mdna:203]
During fiscal 2014, we used $1.3 billion for the principal repayment of our Convertible Notes and used $1.9 billion for the repurchase of 47.3 million shares of our common stock and the purchase of a
related forward contract.

[0001193125-14-239169:mdna:204]
During fiscal 2013, we generated $987.3 million, net, from the issuance of long-term debt, used
$590.0 million for the repurchase of 18.1 million shares of common stock and received an aggregate of $183.5 million of proceeds and excess tax benefits from employee equity award plans, net of shares withheld for taxes.

[0001193125-14-239169:mdna:205]
Liquidity

[0001193125-14-239169:mdna:206]
Our principal sources of liquidity as of April 25, 2014 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001193125-14-239169:mdna:207]
Cash, cash equivalents and short-term investments consist of the following (in millions):

[0001193125-14-239169:mdna:208]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Cash and cash equivalents |  | $ | 2,291.0 |  |  | $ | 3,277.1 |  |
| Short-term investments |  |  | 2,712.3 |  |  |  | 3,675.5 |  |
| Total |  | $ | 5,003.3 |  |  | $ | 6,952.6 |  |

[0001193125-14-239169:mdna:209]
As of April 25, 2014 and April 26, 2013, $4.3 billion and $3.6 billion,
respectively, of cash, cash equivalents and short-term investments was held by various foreign subsidiaries and was generally based in U.S. dollar-denominated holdings, while $0.7 billion and $3.4 billion, respectively, was available in the United
States. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings for
cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carry forwards. However, our intent is to keep these funds permanently reinvested
outside of the United States, and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities,
fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001193125-14-239169:mdna:210]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and
inventories, the timing and amount of stock repurchases and payment of cash dividends, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our
current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases,
cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event
our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows
at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-14-239169:mdna:211]
Our investment portfolio, including auction rate securities, has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current
economic and market events to minimize the market risk of our investment portfolio. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past
performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our
liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other
liquidity requirements associated with our operations. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties.

[0001193125-14-239169:mdna:212]
Senior Notes

[0001193125-14-239169:mdna:213]
The following table summarizes the principal amount of our
Senior Notes as of April 25, 2014 (in millions):

[0001193125-14-239169:mdna:214]
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |

[0001193125-14-239169:mdna:215]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms,
see Note 9 of the accompanying consolidated financial statements.

[0001193125-14-239169:mdna:216]
Credit Facility

[0001193125-14-239169:mdna:217]
Our credit facility, under which we may borrow up to $250.0 million, provides another potential source of liquidity. The credit facility
is an unsecured five-year revolving credit facility that terminates on December 21,

[0001193125-14-239169:mdna:218]
2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also,
subject to certain requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to certain conditions. As of April 25, 2014, no borrowings were outstanding
under the facility and we were in compliance with all covenants associated with the facility.

[0001193125-14-239169:mdna:219]
We also have an automatic shelf
registration statement on file with the SEC, pursuant to which, subsequent to year-end on June 5, 2014, we completed a debt offering and raised $494.7 million, net of discount and offering costs, through the issuance of long-term debt, as
further discussed in Note 18 to our consolidated financial statements. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001193125-14-239169:mdna:220]
Capital Expenditure Requirements

[0001193125-14-239169:mdna:221]
We expect to fund our capital
expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from
operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions
related to the financing of our facilities and equipment requirements. Our capital expenditures were $221.4 million during fiscal 2014. We anticipate capital expenditures for fiscal 2015 to be between $200.0 million and $250.0 million.

[0001193125-14-239169:mdna:222]
Dividends and Stock Repurchase Program

[0001193125-14-239169:mdna:223]
On May 21, 2014, we declared a cash dividend of $0.165 per share of common stock, payable on July 22, 2014 to holders of record as of the close of business on July 10, 2014.

[0001193125-14-239169:mdna:224]
Our Board of Directors has authorized the repurchase of up to $7.1 billion of our common stock under our stock repurchase program,
including an increase of $1.6 billion approved by our Board of Directors in May 2013. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate
by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 25, 2014, we repurchased a total of 184.3 million shares of our common stock
at an average price of $32.55 per share, for an aggregate purchase price of $6.0 billion. As of April 25, 2014, the remaining authorized amount for stock repurchases under this program was $1.1 billion with no termination date, which we plan to
complete by May 2015.

[0001193125-14-239169:mdna:225]
The timing and amount of stock repurchase transactions and future dividends will depend on market
conditions, corporate business and financial considerations and regulatory requirements.

[0001193125-14-239169:mdna:226]
Contractual Obligations

[0001193125-14-239169:mdna:227]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the
factors that impact our cash flows from operations discussed previously. The following table summarizes our contractual obligations at April 25, 2014 (in millions):

[0001193125-14-239169:mdna:228]
| Fiscal year |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | 2018 |  |  | 2019 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office space and equipment lease commitments |  | $ | 63.3 |  |  | $ | 51.5 |  |  | $ | 27.5 |  |  | $ | 14.8 |  |  | $ | 12.2 |  |  | $ | 33.9 |  |  | $ | 203.2 |  |
| Purchase commitments with contract manufacturers(1) |  |  | 258.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 258.4 |  |
| Capital expenditures |  |  | 30.2 |  |  |  | 0.3 |  |  |  | 0.3 |  |  |  | 0.3 |  |  |  | — |  |  |  | — |  |  |  | 31.1 |  |
| Other purchase obligations(2) |  |  | 107.0 |  |  |  | 48.3 |  |  |  | 16.7 |  |  |  | 2.1 |  |  |  | — |  |  |  | — |  |  |  | 174.1 |  |
| Total off-balance sheet commitments |  |  | 458.9 |  |  |  | 100.1 |  |  |  | 44.5 |  |  |  | 17.2 |  |  |  | 12.2 |  |  |  | 33.9 |  |  |  | 666.8 |  |
| Long-term debt obligations(3) |  |  | 23.1 |  |  |  | 23.1 |  |  |  | 23.1 |  |  |  | 773.2 |  |  |  | 8.1 |  |  |  | 282.5 |  |  |  | 1,133.1 |  |
| Long-term financing arrangements |  |  | 8.4 |  |  |  | 7.7 |  |  |  | 1.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 17.5 |  |
| Uncertain tax positions(4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 180.0 |  |
| Total |  | $ | 490.4 |  |  | $ | 130.9 |  |  | $ | 69.0 |  |  | $ | 790.4 |  |  | $ | 20.3 |  |  | $ | 316.4 |  |  | $ | 1,997.4 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 5.1 |  |  | $ | 3.0 |  |  | $ | 1.8 |  |  | $ | 1.6 |  |  | $ | 0.1 |  |  | $ | 1.0 |  |  | $ | 12.6 |  |

[0001193125-14-239169:mdna:229]
| (1) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. We recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to cost of product sales. As of April 25, 2014, such liability amounted to $11.5 million and is included in other current liabilities in our consolidated balance sheets. |

[0001193125-14-239169:mdna:230]
| (2) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001193125-14-239169:mdna:231]
| (3) | Included in long-term debt are obligations related to our $1.0 billion principal amount of our Senior Notes, of which $750.0 million is due in December 2017 and $250.0 million is due in December 2022. Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations are $133.1 million for fiscal 2015 through fiscal 2023. |

[0001193125-14-239169:mdna:232]
| (4) | As of April 25, 2014, our liability for uncertain tax positions was $180.0 million, including interest and penalties, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-14-239169:mdna:233]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by
management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table.

[0001193125-14-239169:mdna:234]
Legal Contingencies

[0001193125-14-239169:mdna:235]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 17 to our consolidated financial statements.

[0001193125-14-239169:mdna:236]
Off-Balance Sheet Arrangements

[0001193125-14-239169:mdna:237]
In the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As
of April 25, 2014, our financial guarantees of $12.6 million that were not recorded on our consolidated balance sheet consisted primarily of standby letters of credit and surety bonds.

[0001193125-14-239169:mdna:238]
In the ordinary course of business, some of our customers have entered into recourse and
non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse
basis to third-party financing companies. During the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user
customer default. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple
deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these
advance payments until the related refund rights expire and we perform the services. As of April 25, 2014, the maximum guaranteed payment contingencies under our financing arrangements totaled $205.8 million and the related deferred revenue
totaled $193.1 million.

[0001193125-14-239169:mdna:239]
We enter into indemnification agreements with third parties in the ordinary course of business.
Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered
off-balance sheet arrangements under accounting guidance.

[0001193125-14-239169:mdna:240]
60
