# NTAP notes — 0001193125-14-239169


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-14-239169:notes:1]
Property
 and equipment, net (in millions):

[0001193125-14-239169:notes:2]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Land |  | $ | 265.7 |  |  | $ | 265.5 |  |
| Buildings and building improvements |  |  | 541.7 |  |  |  | 534.8 |  |
| Leasehold improvements |  |  | 102.9 |  |  |  | 100.3 |  |
| Computer, production, engineering and other equipment |  |  | 753.8 |  |  |  | 714.0 |  |
| Software |  |  | 369.1 |  |  |  | 422.6 |  |
| Furniture and fixtures |  |  | 86.4 |  |  |  | 82.2 |  |
| Construction-in-progress |  |  | 72.9 |  |  |  | 19.9 |  |
|  |  |  | 2,192.5 |  |  |  | 2,139.3 |  |
| Accumulated depreciation and amortization |  |  | (1,083.7 | ) |  |  | (968.4 | ) |
| Property and equipment, net |  | $ | 1,108.8 |  |  | $ | 1,170.9 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-239169:notes:3]
As of
 April 25, 2014, future amortization expense related to
 purchased intangible assets is as follows (in millions):

[0001193125-14-239169:notes:4]
| Fiscal Year |  | Amount |  |
| 2015 |  | $ | 57.9 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 121.5 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-14-239169:notes:5]
The notional
 amount of our outstanding U.S. dollar equivalent foreign currency
 exchange forward contracts consisted of the following (in
 millions):

[0001193125-14-239169:notes:6]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 122.6 |  |  | $ | 108.4 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 155.5 |  |  |  | 158.2 |  |
| Forward contracts purchased |  |  | 389.9 |  |  |  | 358.4 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-14-239169:notes:7]
The following
 customers, each of which is a distributor, accounted for 10% or
 more of our net revenues:

[0001193125-14-239169:notes:8]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 19 | % |  |  | 17 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 15 | % |  |  | 12 | % |


## us-gaap:ScheduleOfAntidilutiveSecuritiesExcludedFromComputationOfEarningsPerShareTextBlock

[0001193125-14-239169:notes:9]
The following
 potential weighted-average shares of common stock have been
 excluded from the diluted net income per share calculations, as
 their effect would have been anti-dilutive (in
 millions):

[0001193125-14-239169:notes:10]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Employee equity award plans |  |  | 6.4 |  |  |  | 15.1 |  |  |  | 9.9 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-239169:notes:11]
The effect of
 derivative instruments not designated as hedging instruments
 recognized in other income, net on our consolidated statements of
 operations was as follows (in millions):

[0001193125-14-239169:notes:12]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
|  |  | Gain Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | 0.8 |  |  | $ | 6.5 |  |  | $ | 21.0 |  |


## us-gaap:ScheduleOfUnrealizedLossOnInvestmentsTableTextBlock

[0001193125-14-239169:notes:13]
The following
 tables show the gross unrealized losses and estimated fair values
 of our available-for-sale investments with gross unrealized losses
 and the length of time that individual securities have been in
 continuous unrealized loss positions (in millions):

[0001193125-14-239169:notes:14]
|  |  | April 25, 2014 |  |
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 233.1 |  |  | $ | (0.5 | ) |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 233.1 |  |  | $ | (0.5 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 36.0 |  |  |  | (0.9 | ) |  |  | 36.0 |  |  |  | (0.9 | ) |
| U.S. Treasury and government debt securities |  |  | 63.0 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 63.0 |  |  |  | (0.1 | ) |
| Total |  | $ | 296.1 |  |  | $ | (0.6 | ) |  | $ | 36.0 |  |  | $ | (0.9 | ) |  | $ | 332.1 |  |  | $ | (1.5 | ) |

[0001193125-14-239169:notes:15]
|  |  | April 26, 2013 |  |
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 698.1 |  |  | $ | (0.5 | ) |  | $ | 38.4 |  |  | $ | (0.1 | ) |  | $ | 736.5 |  |  | $ | (0.6 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 39.2 |  |  |  | (2.7 | ) |  |  | 39.2 |  |  |  | (2.7 | ) |
| Total |  | $ | 698.1 |  |  | $ | (0.5 | ) |  | $ | 77.6 |  |  | $ | (2.8 | ) |  | $ | 775.7 |  |  | $ | (3.3 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-239169:notes:16]
9. Financing
 Arrangements

[0001193125-14-239169:notes:17]
Long-term
 Debt

[0001193125-14-239169:notes:18]
The following
 table summarizes the carrying value of our long-term debt (in
 millions):

[0001193125-14-239169:notes:19]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes Due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (4.5 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.5 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.5 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

[0001193125-14-239169:notes:20]
N/A — Not
 Applicable

[0001193125-14-239169:notes:21]
Senior
 Notes

[0001193125-14-239169:notes:22]
Our Senior
 Notes, issued in December 2012, are unsecured, unsubordinated
 obligations, which pay interest semi-annually on June 15 and
 December 15 and rank equally in right of payment with any
 future senior unsecured indebtedness. Interest expense associated
 with the Senior Notes was $ 25.1 million and $9.4 million for
 the years ended April 25, 2014 and April 26, 2013,
 respectively.

[0001193125-14-239169:notes:23]
We may redeem
 the Senior Notes in whole or in part, at any time at our option at
 specified redemption prices. In addition, upon the occurrence of
 certain change of control triggering events, we may be required to
 repurchase the Senior Notes at 101% of their aggregate principal
 amount, plus accrued and unpaid interest to the date of repurchase.
 The Senior Notes also include covenants that limit our ability to
 incur debt secured by liens on assets or on shares of stock or
 indebtedness of our subsidiaries; to engage in sale and lease-back
 transactions; and to consolidate, merge or sell all or
 substantially all of our assets. As of April 25, 2014, we were
 in compliance with all covenants associated with the Senior
 Notes.

[0001193125-14-239169:notes:24]
1.75% Convertible Senior Notes due 2013

[0001193125-14-239169:notes:25]
On
 June 10, 2008, we issued $1,265.0 million aggregate
 principal amount of 1.75% Convertible Senior Notes (the Convertible
 Notes) with a maturity date of June 1, 2013. The Convertible
 Notes were unsecured, unsubordinated obligations of the Company and
 paid interest in cash semi-annually at a rate of 1.75% per
 annum. Upon maturity, the Convertible Notes were converted into
 shares of common stock at a conversion rate of 31.40 shares of
 common stock per $1,000 principal amount of the Convertible Notes
 (which represented the effective conversion price of $31.85 per
 share). Upon conversion in June 2013, the holders received cash for
 the principal amount of the Convertible Notes and an aggregate of
 4.9 million shares of common stock for the $178.9 million
 excess of the conversion value over the principal
 amount.

[0001193125-14-239169:notes:26]
We separately
 accounted for the liability and equity components of the
 Convertible Notes. The initial debt component of the Convertible
 Notes was valued at $1,017.0 million based on the contractual
 cash flows discounted at an appropriate comparable market
 non-convertible debt borrowing rate at the date of issuance of
 6.31%, with the equity component representing the residual amount
 of the proceeds of $248.0 million which was recorded as a debt
 discount. Issuance costs were allocated pro-rata based on the
 relative initial carrying amounts of the debt and equity
 components. As a result, $5.2 million of the issuance costs
 was allocated to the equity component of the Convertible Notes, and
 $21.4 million of the issuance costs remained classified as
 other non-current assets. The debt discount and the issuance costs
 allocated to the debt component were amortized as additional
 interest expense over the term of the Convertible Notes using the
 effective interest method.

[0001193125-14-239169:notes:27]
Convertible
 Note Hedges and Warrants

[0001193125-14-239169:notes:28]
Concurrent with
 the issuance of the Convertible Notes, we purchased Convertible
 Note hedges and sold warrants. The separate Convertible Note Hedge
 and warrant transactions were structured to reduce the potential
 future economic dilution associated with the conversion of the
 Convertible Notes.

[0001193125-14-239169:notes:29]
|  | • |  | Convertible Note Hedges: As of April 26, 2013, we had arrangements with counterparties to buy up to approximately 31.8 million shares of our common stock, at a price of $31.85 per share. In June 2013, concurrent with the repayment and conversion of the Convertible Notes, we exercised the Convertible Note hedges that were net settled for an aggregate of 3.9 million shares from the counterparties. No hedges were outstanding as of April 25, 2014. |

[0001193125-14-239169:notes:30]
|  | • |  | Warrants: As of April 26, 2013, we had outstanding warrants for certain counterparties to acquire 39.7 million shares of our common stock at an exercise price of $41.28 per share. The warrants were exercisable on a series of days commencing on September 3, 2013 and ending on October 28, 2013. The number of warrants and exercise price were adjusted in fiscal 2014 to reflect cash dividends declared during that period. During fiscal 2014, 31.9 million warrants were exercised at a weighted-average price of $43.09 and were net settled with 1.1 million shares of our common stock, equal to the difference between the market price on the date of exercise and the exercise price of the warrants on their respective exercise dates. No warrants were outstanding as of April 25, 2014. |

[0001193125-14-239169:notes:31]
Interest
 Expense on Convertible Notes

[0001193125-14-239169:notes:32]
The following
 table presents the amount of interest expense related to the
 Convertible Notes (in millions):

[0001193125-14-239169:notes:33]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 2.5 |  |  | $ | 22.0 |  |  | $ | 22.0 |  |
| Amortization of debt discount |  |  | 7.1 |  |  |  | 55.5 |  |  |  | 52.0 |  |
| Amortization of debt issuance costs |  |  | 0.6 |  |  |  | 4.8 |  |  |  | 4.5 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (1.1 | ) |  |  | (5.0 | ) |
| Total interest expense related to Convertible Notes |  | $ | 10.2 |  |  | $ | 81.2 |  |  | $ | 73.5 |  |

[0001193125-14-239169:notes:34]
Debt
 Maturities

[0001193125-14-239169:notes:35]
As of
 April 25, 2014, our aggregate future principal debt maturities
 are as follows (in millions):

[0001193125-14-239169:notes:36]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |

[0001193125-14-239169:notes:37]
Credit
 Facility

[0001193125-14-239169:notes:38]
In December
 2012, we entered into a credit agreement with a syndicated group of
 lenders that is scheduled to expire on December 21, 2017 and
 provides for an unsecured $250.0 million revolving credit facility
 that is comprised of revolving loans, Eurocurrency loans and/or
 swingline loans. The credit facility includes a $100.0 million
 foreign currency sub-facility, a $50.0 million letter of credit
 sub-facility and a $10.0 million swingline sub-facility available
 on same-day notice. Available borrowings under the credit facility
 are reduced by the amount of any outstanding borrowings on the
 sub-facilities. We may also, subject to certain requirements,
 request an increase in the facility up to an additional $100.0
 million and request two additional one-year extensions, subject to
 certain conditions. The proceeds from the facility may be used by
 us for general corporate purposes.

[0001193125-14-239169:notes:39]
Borrowings
 under the facility, except for swingline loans, accrue interest in
 arrears at an alternate base rate as defined in the credit
 agreement or, at our option, an adjusted London Interbank Offered
 Rate (LIBOR) plus in each case, a spread (based on our public debt
 ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline
 borrowings accrue interest at an alternate base rate. In addition,
 we are required to pay fees to maintain the credit facility,
 whether or not we have outstanding borrowings. The facility
 contains financial covenants requiring us to maintain a maximum
 leverage ratio of not more than 3.0:1.0 and a minimum interest
 coverage ratio of not less than 3.5:1.0. The facility contains
 customary affirmative and negative covenants, including covenants
 that limit our ability to incur debt secured by liens on assets or
 indebtedness of our subsidiaries and to consolidate, merge or sell
 all or substantially all of our assets. As of April 25, 2014,
 no borrowings were outstanding under the facility and we were in
 compliance with all covenants associated with the
 facility.

[0001193125-14-239169:notes:40]
Other
 Long-Term Financing Arrangements

[0001193125-14-239169:notes:41]
The following
 presents the amounts due under other long-term financing
 arrangements (in millions):

[0001193125-14-239169:notes:42]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Other long-term financing arrangements |  | $ | 13.1 |  |  | $ | 10.8 |  |
| Less: current portion |  |  | (6.6 | ) |  |  | (5.2 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 6.5 |  |  | $ | 5.6 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsGrantsInPeriodGrantDateIntrinsicValueTableTextBlock

[0001193125-14-239169:notes:43]
Additional
 information related to our stock options is summarized below (in
 millions):

[0001193125-14-239169:notes:44]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Intrinsic value of exercises |  | $ | 90.7 |  |  | $ | 46.1 |  |  | $ | 116.9 |  |
| Proceeds received from exercises |  | $ | 163.7 |  |  | $ | 56.5 |  |  | $ | 111.1 |  |
| Fair value of options vested |  | $ | 45.3 |  |  | $ | 55.9 |  |  | $ | 71.8 |  |


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001193125-14-239169:notes:45]
Future annual
 minimum lease payments under all non-cancelable operating leases
 with an initial term in excess of one year as of April 25,
 2014 are as follows (in millions):

[0001193125-14-239169:notes:46]
| Fiscal Year |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | 2018 |  |  | 2019 |  |  | Thereafter |  |  | Total |  |
| Lease commitments |  | $ | 63.3 |  |  | $ | 51.5 |  |  | $ | 27.5 |  |  | $ | 14.8 |  |  | $ | 12.2 |  |  | $ | 33.9 |  |  | $ | 203.2 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-14-239169:notes:47]
Revenue
 Recognition — We recognize revenue
 when:

[0001193125-14-239169:notes:48]
|  | • |  | Persuasive evidence of an arrangement exists. Customarily we have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001193125-14-239169:notes:49]
|  | • |  | Delivery has occurred. Our product is physically delivered to our customers. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. We do not recognize revenue if undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement. |

[0001193125-14-239169:notes:50]
|  | • |  | The fee is fixed or determinable. Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001193125-14-239169:notes:51]
|  | • |  | Collection is reasonably assured. If there is considerable doubt surrounding the creditworthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001193125-14-239169:notes:52]
The hardware
 systems and software components essential to the functionality of
 the hardware systems are considered non-software deliverables and
 therefore are not subject to industry-specific software revenue
 recognition guidance.

[0001193125-14-239169:notes:53]
Our product
 revenues also include revenues from the sale of non-essential
 software products. Non-essential software sales generally include a
 perpetual license to our software. Non-essential software sales are
 subject to the industry-specific software revenue recognition
 guidance.

[0001193125-14-239169:notes:54]
Our multiple
 element arrangements may include our systems, software entitlements
 and maintenance (SEM), premium hardware maintenance and services.
 SEM entitles our customers to receive unspecified product upgrades
 and enhancements on a when-and-if-available basis, and patch
 releases. Premium hardware maintenance services include contracts
 for technical support and minimum response times. Services include
 professional services and customer education and training services.
 Revenues from SEM and premium hardware maintenance services are
 recognized ratably over the contractual term, generally from one to
 five years. We also offer extended service contracts (which extend
 our standard parts warranty and may include premium hardware
 maintenance) at the end of the original warranty term; revenues
 from these contracts are recognized ratably over the extended
 contract term. We sell professional services either on a time and
 materials basis or under fixed price projects; we recognize revenue
 for these services as they are performed.

[0001193125-14-239169:notes:55]
For multiple
 element arrangements, we allocate revenue to the software
 deliverables and the non-software deliverables as a group based on
 the relative selling prices of all of the deliverables in the
 arrangement. The selling price for each element is based upon the
 following selling price hierarchy: VSOE if available, third party
 evidence (TPE) if VSOE is not available, or estimated selling price
 (ESP) if neither VSOE nor TPE are available. ESP is generally
 evidenced by a majority of historical transactions falling within a
 reasonable price range. We also consider multiple factors,
 including, but not limited to, cost of products, gross margin
 objectives, historical pricing practices, type of customer and
 distribution channels. For our non-software deliverables, we
 generally allocate the arrangement consideration based on the
 relative selling price of the deliverables using estimated selling
 price (ESP). For our software entitlements and support services, we
 generally use vendor-specific objective evidence of selling price
 (VSOE). When we are unable to establish VSOE for our software
 entitlements and support services, we use ESP in our allocation of
 arrangement consideration.

[0001193125-14-239169:notes:56]
VSOE is based
 upon the normal pricing and discounting practices for those
 services when sold separately. VSOE is generally evidenced by a
 substantial majority of historical stand-alone transactions falling
 within a reasonably narrow range. In addition, we consider major
 service type, customer type, and other variables in determining
 VSOE.

[0001193125-14-239169:notes:57]
When VSOE
 cannot be established, we attempt to establish the selling price of
 each element based on third party evidence of selling price (TPE).
 Generally, we are not able to determine TPE because our
 go-to-market strategy differs from that of our peers and our
 offerings contain a significant level of differentiation such that
 the comparable pricing of products with similar functionality
 cannot be obtained.

[0001193125-14-239169:notes:58]
We regularly
 review VSOE, TPE, and ESP and maintain internal controls over the
 establishment and updates of these estimates.

[0001193125-14-239169:notes:59]
For our
 software deliverables, we use the residual method to recognize
 revenue when an arrangement includes one or more elements to be
 delivered at a future date and VSOE of all undelivered elements
 exists. Typically, only SEM and/or service remain undelivered after
 the product is delivered. Under the residual method, the fair value
 of the undelivered elements is deferred and the remaining portion
 of the consideration is recognized as product revenues for
 delivered elements. If evidence of the fair value of one or more
 undelivered elements does not exist, all revenue is generally
 deferred until the earlier of when delivery of those elements
 occurs or when fair value can be established. In instances where
 the only undelivered element without fair value is SEM, the entire
 arrangement is recognized ratably over the maintenance
 period.

[0001193125-14-239169:notes:60]
We record
 reductions to revenue for estimated sales returns at the time of
 shipment. Sales returns are estimated based on historical sales
 returns, current trends, and our expectations regarding future
 experience. We monitor and analyze the accuracy of sales returns
 estimates by reviewing actual returns and adjust them for future
 expectations. Additionally, distributors and retail partners
 participate in various cooperative marketing and other programs,
 and we record estimated accruals and allowances for these programs.
 We accrue for these programs based on contractual terms and
 historical experience. Sales and value added taxes collected from
 customers and remitted to governmental authorities are presented on
 a net basis in the accompanying consolidated statements of
 operations.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0001193125-14-239169:notes:61]
The identified
 intangible assets as of the date of acquisition, which are
 amortized on a straight-line basis over their estimated useful
 lives, consisted of the following (in millions):

[0001193125-14-239169:notes:62]
|  |  | Estimated Fair Value |  |  | Useful Life (Years) |  |
| Developed technology |  | $ | 216.0 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 45.0 |  |  |  | 2 |  |
| Trademarks and trade names |  |  | 7.0 |  |  |  | 2 |  |
| Order backlog |  |  | 2.5 |  |  |  | 0 |  |
| Covenant not to compete |  |  | 1.6 |  |  |  | 3 |  |
| Total identified intangible assets |  | $ | 272.1 |  |  |  |  |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-14-239169:notes:63]
The following
 customers accounted for 10% or more of net accounts
 receivable:

[0001193125-14-239169:notes:64]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Arrow Electronics, Inc. |  |  | 14 | % |  |  | 16 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 14 | % |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-14-239169:notes:65]
SCHEDULE II

[0001193125-14-239169:notes:66]
NETAPP,
 INC.

[0001193125-14-239169:notes:67]
VALUATION
 AND QUALIFYING ACCOUNTS

[0001193125-14-239169:notes:68]
Years Ended
 April 25, 2014, April 26, 2013 and April 27,
 2012

[0001193125-14-239169:notes:69]
(In
 millions)

[0001193125-14-239169:notes:70]
| Description |  | Balance at Beginning of Period |  |  | Additions Charged (Credited) to Costs and Expenses |  |  | Reductions and Write-offs |  |  | Balance at End of Period |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2014 |  | $ | 4.2 |  |  | $ | (2.3 | ) |  | $ | 0.2 |  |  | $ | 1.7 |  |
| 2013 |  | $ | 0.4 |  |  | $ | 4.2 |  |  | $ | 0.4 |  |  | $ | 4.2 |  |
| 2012 |  | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-239169:notes:71]
Changes
 in
 accumulated other comprehensive income (AOCI) by component, net of
 tax, are summarized below (in millions):

[0001193125-14-239169:notes:72]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains on Derivative Instruments |  |  | Total |  |
| Balance as of April 27, 2012 |  | $ | 4.9 |  |  | $ | (4.4 | ) |  | $ | 4.9 |  |  | $ | (0.5 | ) |  | $ | 4.9 |  |
| Other comprehensive income (loss) (OCI) before reclassifications |  |  | (2.9 | ) |  |  | (1.3 | ) |  |  | 7.1 |  |  |  | 3.7 |  |  |  | 6.6 |  |
| Amounts reclassified from AOCI, net of tax |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (0.6 | ) |  |  | (2.2 | ) |  |  | (2.8 | ) |
| Net OCI |  |  | (2.9 | ) |  |  | (1.3 | ) |  |  | 6.5 |  |  |  | 1.5 |  |  |  | 3.8 |  |
| Balance as of April 26, 2013 |  |  | 2.0 |  |  |  | (5.7 | ) |  |  | 11.4 |  |  |  | 1.0 |  |  |  | 8.7 |  |
| Other comprehensive income (loss) (OCI) before reclassifications |  |  | 3.5 |  |  |  | 0.5 |  |  |  | (1.2 | ) |  |  | (3.5 | ) |  |  | (0.7 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | 0.0 |  |  |  | 0.4 |  |  |  | (1.3 | ) |  |  | 2.0 |  |  |  | 1.1 |  |
| Net OCI |  |  | 3.5 |  |  |  | 0.9 |  |  |  | (2.5 | ) |  |  | (1.5 | ) |  |  | 0.4 |  |
| Balance as of April 25, 2014 |  | $ | 5.5 |  |  | $ | (4.8 | ) |  | $ | 8.9 |  |  | $ | (0.5 | ) |  | $ | 9.1 |  |


## us-gaap:ScheduleOfDefinedBenefitPlansDisclosuresTextBlock

[0001193125-14-239169:notes:73]
The funded
 status of our postretirement health care and international
 termination and postretirement benefits was as follows (in
 millions):

[0001193125-14-239169:notes:74]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Fair value of plan assets |  | $ | 18.7 |  |  | $ | 17.3 |  |
| Benefit obligations |  |  | (45.7 | ) |  |  | (44.7 | ) |
| Unfunded obligations |  | $ | (27.0 | ) |  | $ | (27.4 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-239169:notes:75]
The following
 table summarizes activity related to our stock options (in
 millions, except for exercise price and contractual
 term):

[0001193125-14-239169:notes:76]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 29, 2011 |  |  | 24.5 |  |  | $ | 26.62 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.2 |  |  | $ | 50.65 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (5.2 | ) |  | $ | 21.54 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.9 | ) |  | $ | 37.23 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 27, 2012 |  |  | 20.6 |  |  | $ | 29.98 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.4 |  |  | $ | 28.87 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (3.0 | ) |  | $ | 18.37 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.8 | ) |  | $ | 40.11 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 26, 2013 |  |  | 19.2 |  |  | $ | 31.27 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.9 |  |  | $ | 38.26 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (6.3 | ) |  | $ | 25.83 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1.3 | ) |  | $ | 42.47 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 25, 2014 |  |  | 14.5 |  |  | $ | 34.10 |  |  |  | 3.49 |  |  | $ | 71.9 |  |
| Vested and expected to vest as of April 25, 2014 |  |  | 14.1 |  |  | $ | 34.01 |  |  |  | 3.42 |  |  |  | 71.4 |  |
| Exercisable as of April 25, 2014 |  |  | 10.5 |  |  | $ | 32.55 |  |  |  | 2.72 |  |  |  | 66.2 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001193125-14-239169:notes:77]
Impairment
 of Long-Lived Assets — We review the carrying values of
 long-lived assets whenever events and circumstances, such as
 reductions in demand, lower projections of profitability,
 significant changes in the manner of our use of acquired assets, or
 significant negative industry or economic trends, indicate that the
 net book value of an asset may not be recovered through expected
 future cash flows from its use and eventual disposition. If this
 review indicates that there is an impairment, the impaired asset is
 written down to its fair value, which is typically calculated
 using: (i) quoted market prices and/or (ii) expected
 future cash flows utilizing a discount rate. Our estimates
 regarding future anticipated net revenue and cash flows, the
 remaining economic life of the products and technologies, or both,
 may differ from those used to assess the recoverability of assets.
 In that event, impairment charges or shortened useful lives of
 certain long-lived assets may be required, resulting in charges to
 our consolidated statements of operations when such determinations
 are made.


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0001193125-14-239169:notes:78]
The following
 table summarizes activity related to this program (in millions,
 except per share information):

[0001193125-14-239169:notes:79]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Number of shares repurchased |  |  | 47.3 |  |  |  | 18.1 |  |  |  | 14.6 |  |
| Average price per share |  | $ | 39.78 |  |  | $ | 32.68 |  |  | $ | 40.97 |  |
| Aggregate purchase price |  | $ | 1,881.5 |  |  | $ | 590.0 |  |  | $ | 600.0 |  |
| Remaining authorization at end of period |  | $ | 1,124.8 |  |  | $ | 1,406.3 |  |  | $ | 496.3 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-239169:notes:80]
The following
 table summarizes our financial assets and liabilities measured at
 fair value on a recurring basis (in millions):

[0001193125-14-239169:notes:81]
|  |  | April 25, 2014 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,152.3 |  |  | $ | 0.0 |  |  | $ | 2,152.3 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 263.6 |  |  |  | 185.1 |  |  |  | 78.5 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 168.4 |  |  |  | 0.0 |  |  |  | 168.4 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 245.0 |  |  |  | 0.0 |  |  |  | 245.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 36.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 36.0 |  |
| Equity funds |  |  | 32.7 |  |  |  | 32.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 0.4 |  |  |  | 0.0 |  |  |  | 0.4 |  |  |  | 0.0 |  |
| Total |  | $ | 2,898.4 |  |  | $ | 217.8 |  |  | $ | 2,644.6 |  |  | $ | 36.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 1.9 |  |  | $ | 0.0 |  |  | $ | 1.9 |  |  | $ | 0.0 |  |

[0001193125-14-239169:notes:82]
|  |  | April 26, 2013 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 3,147.1 |  |  | $ | 0.0 |  |  | $ | 3,147.1 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 393.7 |  |  |  | 222.9 |  |  |  | 170.8 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 178.5 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 135.5 |  |  |  | 0.0 |  |  |  | 135.5 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,463.1 |  |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 42.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 42.0 |  |
| Equity funds |  |  | 28.3 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 1.2 |  |  |  | 0.0 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Total |  | $ | 5,389.4 |  |  | $ | 1,714.3 |  |  | $ | 3,633.1 |  |  | $ | 42.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 3.1 |  |  | $ | 0.0 |  |  | $ | 3.1 |  |  | $ | 0.0 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-239169:notes:83]
Inventories (in millions):

[0001193125-14-239169:notes:84]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Purchased components |  | $ | 17.6 |  |  | $ | 16.3 |  |
| Finished goods |  |  | 104.8 |  |  |  | 123.2 |  |
| Inventories |  | $ | 122.4 |  |  | $ | 139.5 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-14-239169:notes:85]
The following
 table presents the contractual maturities of our debt investments
 as of April 25, 2014 (in millions):

[0001193125-14-239169:notes:86]
|  |  | Amortized Cost |  |  | Estimated Fair Value |  |
| Due in one year or less |  | $ | 1,325.7 |  |  | $ | 1,328.4 |  |
| Due in one through five years |  |  | 1,493.4 |  |  |  | 1,500.9 |  |
| Due after ten years* |  |  | 36.9 |  |  |  | 36.0 |  |
|  |  | $ | 2,856.0 |  |  | $ | 2,865.3 |  |

[0001193125-14-239169:notes:87]
| * | Consists of ARSs which have contractual maturities of greater than 10 years. |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001193125-14-239169:notes:88]
Selected
 quarterly financial data is as follows (in millions, except per
 share amounts):

[0001193125-14-239169:notes:89]
|  |  | Quarter Ended |  |
|  |  | July 26, 2013 |  |  | October 25, 2013 |  |  | January 24, 2014 |  |  | April 25, 2014 |  |
| Net revenues |  | $ | 1,516.2 |  |  | $ | 1,549.9 |  |  | $ | 1,610.0 |  |  | $ | 1,649.0 |  |
| Total cost of revenues |  |  | 606.6 |  |  |  | 584.7 |  |  |  | 607.7 |  |  |  | 607.0 |  |
| Gross profit |  |  | 909.6 |  |  |  | 965.2 |  |  |  | 1,002.3 |  |  |  | 1,042.0 |  |
| Income before income taxes |  |  | 92.3 |  |  |  | 192.2 |  |  |  | 229.6 |  |  |  | 226.6 |  |
| Provision for income taxes |  |  | 10.7 |  |  |  | 25.4 |  |  |  | 37.5 |  |  |  | 29.6 |  |
| Net income |  | $ | 81.6 |  |  | $ | 166.8 |  |  | $ | 192.1 |  |  | $ | 197.0 |  |
| Net income per share, basic |  | $ | 0.23 |  |  | $ | 0.49 |  |  | $ | 0.57 |  |  | $ | 0.60 |  |
| Net income per share, diluted |  | $ | 0.23 |  |  | $ | 0.48 |  |  | $ | 0.55 |  |  | $ | 0.59 |  |

[0001193125-14-239169:notes:90]
|  |  | Quarter Ended |  |
|  |  | July 27, 2012 |  |  | October 26, 2012 |  |  | January 25, 2013 |  |  | April 26, 2013 |  |
| Net revenues |  | $ | 1,444.6 |  |  | $ | 1,541.2 |  |  | $ | 1,630.1 |  |  | $ | 1,716.5 |  |
| Total cost of revenues |  |  | 594.5 |  |  |  | 627.3 |  |  |  | 665.2 |  |  |  | 684.3 |  |
| Gross profit |  |  | 850.1 |  |  |  | 913.9 |  |  |  | 964.9 |  |  |  | 1,032.2 |  |
| Income before income taxes |  |  | 74.2 |  |  |  | 127.7 |  |  |  | 175.8 |  |  |  | 188.9 |  |
| Provision for income taxes |  |  | 10.4 |  |  |  | 18.1 |  |  |  | 17.7 |  |  |  | 15.1 |  |
| Net income |  | $ | 63.8 |  |  | $ | 109.6 |  |  | $ | 158.1 |  |  | $ | 173.8 |  |
| Net income per share, basic |  | $ | 0.17 |  |  | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 0.48 |  |
| Net income per share, diluted |  | $ | 0.17 |  |  | $ | 0.30 |  |  | $ | 0.43 |  |  | $ | 0.47 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-239169:notes:91]
11. Derivatives and
 Hedging Activities

[0001193125-14-239169:notes:92]
We use
 derivative instruments to manage exposures to foreign currency
 risk. Our primary objective in holding derivatives is to reduce the
 volatility of earnings and cash flows associated with changes in
 foreign currency exchange rates. The program is not designated for
 trading or speculative purposes. Our derivatives expose us to
 credit risk to the extent that the counterparties may be unable to
 meet the terms of the agreement. We seek to mitigate such risk by
 limiting our counterparties to major financial institutions. In
 addition, the potential risk of loss with any one counterparty
 resulting from this type of credit risk is monitored on an ongoing
 basis. We also have in place master netting arrangements to
 mitigate the credit risk of our counterparties and to potentially
 reduce our losses due to counterparty nonperformance. All contracts
 have a maturity of less than six months.

[0001193125-14-239169:notes:93]
Over the next 12
 months, we expect an immaterial amount of derivative losses
 recorded in AOCI as of April 25, 2014 will be reclassified
 into net revenues. The maximum length of time over which forecasted
 foreign currency denominated revenues are hedged is six
 months.

[0001193125-14-239169:notes:94]
We have master
 netting arrangements in place to mitigate the credit risk of our
 counterparties and to potentially reduce our losses due to
 counterparty nonperformance. We present our derivative instruments
 as net amounts in our consolidated balance sheets. The gross and
 net fair value amounts of such instruments were not material as of
 April 25, 2014 and April 26, 2013. We did not recognize
 any gains and losses in earnings due to hedge ineffectiveness for
 any period presented.

[0001193125-14-239169:notes:95]
The effect of
 derivative instruments designated as cash flow hedges recognized in
 net revenues on our consolidated statements of operations is
 presented in the consolidated statements of comprehensive income
 and Note 10.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-14-239169:notes:96]
Cash and
 cash equivalents (in millions):

[0001193125-14-239169:notes:97]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Cash |  | $ | 2,174.0 |  |  | $ | 1,634.7 |  |
| Cash equivalents |  |  | 117.0 |  |  |  | 1,642.4 |  |
| Cash and cash equivalents |  | $ | 2,291.0 |  |  | $ | 3,277.1 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-14-239169:notes:98]
The provision
 for income taxes consists of the following (in
 millions):

[0001193125-14-239169:notes:99]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 123.7 |  |  | $ | 85.3 |  |  | $ | 114.8 |  |
| State |  |  | 14.6 |  |  |  | 14.6 |  |  |  | 26.2 |  |
| Foreign |  |  | 40.9 |  |  |  | 38.0 |  |  |  | 26.9 |  |
| Total current |  |  | 179.2 |  |  |  | 137.9 |  |  |  | 167.9 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (64.8 | ) |  |  | (56.9 | ) |  |  | (61.5 | ) |
| State |  |  | (6.1 | ) |  |  | (17.8 | ) |  |  | (16.4 | ) |
| Foreign |  |  | (5.1 | ) |  |  | (1.9 | ) |  |  | 17.0 |  |
| Total deferred |  |  | (76.0 | ) |  |  | (76.6 | ) |  |  | (60.9 | ) |
| Provision for income taxes |  | $ | 103.2 |  |  | $ | 61.3 |  |  | $ | 107.0 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-14-239169:notes:100]
Income
 Taxes — Deferred income tax assets and liabilities
 are provided for temporary differences that will result in tax
 deductions or income in future periods, as well as the future
 benefit of tax credit carryforwards. A valuation allowance reduces
 tax assets to their estimated realizable value. Significant
 judgment is required in determining any valuation allowance
 recorded against deferred tax assets. In assessing the need for a
 valuation allowance, we consider all available evidence, including
 past operating results, estimates of future taxable income, and the
 feasibility of tax planning strategies. In the event that we change
 our determination as to the amount of deferred tax assets that can
 be realized, we adjust our valuation allowance with a corresponding
 impact to the provision for income taxes in the period in which
 such determination is made.

[0001193125-14-239169:notes:101]
The accounting
 guidance for income taxes prescribes a comprehensive model for how
 a company should recognize, measure, present, and disclose in its
 financial statements uncertain tax positions that we have taken or
 expect to take on a tax return (including a decision whether to
 file or not to file a return in a particular jurisdiction). We
 recognize the tax liability for uncertain income tax positions on
 the income tax return based on the two-step process prescribed in
 the interpretation. The first step is to determine whether it is
 more likely than not that each income tax position would be
 sustained upon audit. The second step is to estimate and measure
 the tax benefit as the amount that has a greater than 50%
 likelihood of being realized upon ultimate settlement with the tax
 authority. Estimating these amounts requires us to determine the
 probability of various possible outcomes. We evaluate these
 uncertain tax positions on a quarterly basis. The Company
 recognizes interest and penalties related to unrecognized tax
 benefits within the income tax expense line in the accompanying
 Consolidated Statement of Operations.

[0001193125-14-239169:notes:102]
Determining the
 liability for uncertain tax positions requires us to make
 significant estimates and judgments as to whether, and the extent
 to which, additional taxes may be due based on potential tax audit
 issues in the U.S. and other tax jurisdictions throughout the
 world. Our estimates are based on the outcomes of previous audits,
 as well as the precedents set in cases in which others have taken
 similar tax positions to those taken by us. If we later determine
 that our exposure is lower or that the liability is not sufficient
 to cover our revised expectations, we adjust the liability and
 effect a related change in our tax provision during the period in
 which we make such a determination.

[0001193125-14-239169:notes:103]
Tax attributes
 related to the exercise of employee stock options are not realized
 until they result in a reduction of taxes payable. We do not
 include unrealized stock option attributes as components of our
 gross deferred tax assets and corresponding valuation allowance
 disclosures.


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-14-239169:notes:104]
Other
 non-current assets (in millions):

[0001193125-14-239169:notes:105]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Auction rate securities |  | $ | 36.0 |  |  | $ | 42.0 |  |
| Deferred tax assets |  |  | 245.0 |  |  |  | 200.4 |  |
| Other assets |  |  | 248.5 |  |  |  | 242.2 |  |
| Other non-current assets |  | $ | 529.5 |  |  | $ | 484.6 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-239169:notes:106]
8. Financial Instruments and Fair Value
 Measurements

[0001193125-14-239169:notes:107]
The
 accounting guidance for fair value measurements provides a
 framework for measuring fair value on either a recurring or
 nonrecurring basis, whereby the inputs used in valuation techniques
 are assigned a hierarchical level. The following are the three
 levels of inputs to measure fair value:

[0001193125-14-239169:notes:108]
Level 1: Observable inputs that reflect quoted
 prices (unadjusted) for identical assets or liabilities in active
 markets.

[0001193125-14-239169:notes:109]
Level 2: Inputs that reflect quoted prices for
 identical assets or liabilities in less active markets; quoted
 prices for similar assets or liabilities in active markets;
 benchmark yields, reported trades, broker/dealer quotes, inputs
 other than quoted prices that are observable for the assets or
 liabilities; or inputs that are derived principally from or
 corroborated by observable market data by correlation or other
 means.

[0001193125-14-239169:notes:110]
Level 3: Unobservable inputs that reflect our
 own assumptions incorporated in valuation techniques used to
 measure fair value. These assumptions are required to be consistent
 with market participant assumptions that are reasonably
 available.

[0001193125-14-239169:notes:111]
We consider
 an active market to be one in which transactions for the asset or
 liability occur with sufficient frequency and volume to provide
 pricing information on an ongoing basis, and consider an inactive
 market to be one in which there are infrequent or few transactions
 for the asset or liability, the prices are not current, or price
 quotations vary substantially either over time or among market
 makers. Where appropriate, our own or the counterparty’s
 non-performance risk is considered in measuring the fair values of
 liabilities and assets, respectively.

[0001193125-14-239169:notes:112]
Investments

[0001193125-14-239169:notes:113]
The following
 is a summary of our investments (in millions):

[0001193125-14-239169:notes:114]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
|  |  | Cost or Amortized Cost |  |  | Gross Unrealized |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gross Unrealized |  |  | Estimated Fair Value |  |
|  |  |  | Gains |  |  | Losses |  |  |  |  | Gains |  |  | Losses |  |  |
| Corporate bonds |  | $ | 2,142.3 |  |  | $ | 10.5 |  |  | $ | (0.5 | ) |  | $ | 2,152.3 |  |  | $ | 3,132.8 |  |  | $ | 14.9 |  |  | $ | (0.6 | ) |  | $ | 3,147.1 |  |
| U.S. Treasury and government debt securities |  |  | 263.4 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 263.6 |  |  |  | 392.8 |  |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 393.7 |  |
| Commercial paper |  |  | 168.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 168.4 |  |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 178.5 |  |
| Certificates of deposit |  |  | 245.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 245.0 |  |  |  | 135.4 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 135.5 |  |
| Money market funds |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |
| Auction rate securities |  |  | 36.9 |  |  |  | 0.0 |  |  |  | (0.9 | ) |  |  | 36.0 |  |  |  | 44.2 |  |  |  | 0.5 |  |  |  | (2.7 | ) |  |  | 42.0 |  |
| Equity funds |  |  | 32.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 32.7 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 28.3 |  |
| Total debt and equity securities |  | $ | 2,888.7 |  |  | $ | 10.8 |  |  | $ | (1.5 | ) |  | $ | 2,898.0 |  |  | $ | 5,375.1 |  |  | $ | 16.4 |  |  | $ | (3.3 | ) |  | $ | 5,388.2 |  |

[0001193125-14-239169:notes:115]
As of
 April 25, 2014, the unrealized losses on our
 available-for-sale investments were caused by market value declines
 as a result of the economic environment, as well as fluctuations in
 market interest rates. Because the declines in market value are
 attributable to changes in market conditions and not credit
 quality, and because we have determined that (i) we do not
 have the intent to sell any of these investments and (ii) it
 is not more likely than not that we will be required to sell any of
 these investments before recovery of the entire amortized cost
 basis, we have determined that no other-than-temporary impairments
 were required to be recognized on these investments as of
 April 25, 2014.

[0001193125-14-239169:notes:116]
Actual
 maturities may differ from the contractual maturities because
 borrowers may have the right to call or prepay certain
 obligations.

[0001193125-14-239169:notes:117]
Fair
 Value of Financial Instruments

[0001193125-14-239169:notes:118]
The following
 table summarizes the balance sheet classifications of our financial
 assets and liabilities measured at fair value on a recurring basis
 (in millions):

[0001193125-14-239169:notes:119]
|  |  | April 25, 2014 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 117.0 |  |  | $ | 0.0 |  |  | $ | 117.0 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,712.3 |  |  |  | 185.1 |  |  |  | 2,527.2 |  |  |  | 0.0 |  |
| Other current assets |  |  | 6.8 |  |  |  | 6.4 |  |  |  | 0.4 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 62.3 |  |  |  | 26.3 |  |  |  | 0.0 |  |  |  | 36.0 |  |
| Total |  | $ | 2,898.4 |  |  | $ | 217.8 |  |  | $ | 2,644.6 |  |  | $ | 36.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 1.9 |  |  | $ | 0.0 |  |  | $ | 1.9 |  |  | $ | 0.0 |  |

[0001193125-14-239169:notes:120]
|  |  | April 26, 2013 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,642.4 |  |  | $ | 1,463.1 |  |  | $ | 179.3 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,675.5 |  |  |  | 222.9 |  |  |  | 3,452.6 |  |  |  | 0.0 |  |
| Other current assets |  |  | 2.8 |  |  |  | 1.6 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 68.7 |  |  |  | 26.7 |  |  |  | 0.0 |  |  |  | 42.0 |  |
| Total |  | $ | 5,389.4 |  |  | $ | 1,714.3 |  |  | $ | 3,633.1 |  |  | $ | 42.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 3.1 |  |  | $ | 0.0 |  |  | $ | 3.1 |  |  | $ | 0.0 |  |

[0001193125-14-239169:notes:121]
Level 2
 investments are held by a custodian who prices some of the
 investments using standard inputs in various asset price models or
 obtains investment prices from a third-party pricing provider that
 incorporates standard inputs in various asset price models. We
 review Level 2 inputs and fair value for reasonableness and the
 values may be further validated by comparison to multiple
 independent pricing sources. In addition, we review third-party
 pricing provider models, key inputs and assumptions and understand
 the pricing processes at our third-party providers in determining
 the overall reasonableness of the fair value of our Level 2
 financial instruments. As of April 25, 2014 and April 26,
 2013, we have not made any adjustments to the prices obtained from
 our third-party pricing providers.

[0001193125-14-239169:notes:122]
Quantitative
 information about our Level 3 fair value measurements is as follows
 (fair value in millions):

[0001193125-14-239169:notes:123]
|  |  | Estimated Fair Value as of April 25, 2014 |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $36.0 |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs. - 10.0 yrs. (8.2 yrs.) |
|  |  |  |  |  |  | Illiquidity premium |  | 1.1% - 2.8% (1.8%) |
|  |  |  |  |  |  | Coupon rate |  | 1.1% - 2.7% (1.8%) |
|  |  |  |  | Market comparable securities |  | Discount rate |  | 1.0% - 5.0% (2.4%) |

[0001193125-14-239169:notes:124]
|  |  | Estimated Fair Value as of April 26, 2013 |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $42.0 |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs. - 11.4 yrs. (8.6 yrs.) |
|  |  |  |  |  |  | Illiquidity premium |  | 1.6% - 2.8% (2.0%) |
|  |  |  |  |  |  | Coupon rate |  | 0.8% - 2.7% (1.5%) |
|  |  |  |  | Market comparable securities |  | Discount rate |  | 3.3% - 7.3% (6.3%) |

[0001193125-14-239169:notes:125]
All of our
 ARSs are classified as other non-current assets and are backed by
 pools of student loans guaranteed by the U.S. Department of
 Education. We estimate the fair value of each individual ARS using
 an income (discounted cash flow) and market approach that
 incorporate both observable and unobservable inputs. Key inputs
 into the discounted cash flow analysis include the time-to-economic
 maturity, illiquidity premium, (which factors in liquidity risk,
 market credit spread and other factors), and a coupon rate. The key
 input into the market approach is a discount rate. A significant
 increase (decrease) in the time-to-economic maturity, illiquidity
 premium, market credit spread and other factors, coupon rate or
 discount rate could result in a significantly lower (higher) fair
 value estimate. We review the fair value of our Level 3 financial
 instruments for overall reasonableness by reviewing service
 provider pricing methodologies, key inputs and assumptions and by
 understanding the processes used by our third-party service
 provider. We will continue to monitor our ARS investments in light
 of the asset-backed securities market environment and evaluate
 these investments for impairment and classification.

[0001193125-14-239169:notes:126]
The table
 below provides a reconciliation of the beginning and ending balance
 of our Level 3 ARSs measured at fair value on a recurring
 basis using significant unobservable inputs (in
 millions).

[0001193125-14-239169:notes:127]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Balance at beginning of period |  | $ | 42.0 |  |  | $ | 51.0 |  |  | $ | 65.1 |  |
| Total unrealized gains, net included in OCI |  |  | 1.3 |  |  |  | 0.5 |  |  |  | 0.9 |  |
| Total realized gains included in earnings |  |  | 0.7 |  |  |  | 1.1 |  |  |  | 0.7 |  |
| Sales |  |  | (8.0 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Settlements |  |  | 0.0 |  |  |  | (10.6 | ) |  |  | (15.7 | ) |
| Balance at end of period |  | $ | 36.0 |  |  | $ | 42.0 |  |  | $ | 51.0 |  |

[0001193125-14-239169:notes:128]
Fair
 Value of Debt

[0001193125-14-239169:notes:129]
As of
 April 25, 2014, the fair value of our 2.00% Senior Notes and
 3.25% Senior Notes (collectively referred to as Senior Notes) was
 approximately $1,000.0 million. The fair value of our debt was
 based on observable market prices in a less active market and
 discounted cash flow models that take into consideration variables
 such as credit-rating and interest rate changes. All of our debt
 obligations are categorized as Level 2 instruments.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-14-239169:notes:130]
1. Description of Business and Significant Accounting
 Policies

[0001193125-14-239169:notes:131]
Description of Business — NetApp, Inc. (we, us,
 or the Company) is a global provider of innovative storage and data
 management software, systems and services. Our storage solutions
 help customers create the flexible, efficient and highly available
 IT infrastructures they need to support their organizations. We are
 a storage and data management provider to enterprises of all sizes,
 service providers, governmental organizations and original
 equipment manufacturers.

[0001193125-14-239169:notes:132]
Fiscal
 Year —
 Our fiscal year is reported on a 52- or 53-week year ending on the
 last Friday in April. Fiscal 2014, 2013 and 2012 were each 52-week
 years.

[0001193125-14-239169:notes:133]
Principles
 of Consolidation — The consolidated
 financial statements include the Company and its subsidiaries.
 Intercompany accounts and transactions are eliminated in
 consolidation.

[0001193125-14-239169:notes:134]
Use of
 Estimates — The preparation of the
 consolidated financial statements in conformity with accounting
 principles generally accepted in the United States of America
 (GAAP) requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities and
 disclosure of contingent assets and liabilities at the date of the
 financial statements and the reported amounts of revenues and
 expenses during the reporting periods. Such estimates include, but
 are not limited to, revenue recognition, reserves and allowances;
 inventory valuation and purchase order accruals; valuation of
 goodwill and intangibles; restructuring reserves; product
 warranties; employee benefit accruals; stock-based compensation;
 loss contingencies; investment impairments; income taxes and fair
 value measurements. Actual results could differ materially from
 those estimates.

[0001193125-14-239169:notes:135]
Cash
 Equivalents — We consider all highly
 liquid debt investments with original maturities of three months or
 less at the time of purchase to be cash equivalents.

[0001193125-14-239169:notes:136]
Available-for-Sale Investments — We classify our
 investments in debt securities as available-for-sale investments.
 Debt securities primarily consist of corporate bonds, U.S.
 government securities, U.S. government agency securities,
 commercial paper, certificates of deposit and asset-backed
 securities. These available-for-sale investments are primarily held
 in the custody of a major financial institution. A specific
 identification method is used to determine the cost basis of debt
 securities sold. These investments are recorded in the Consolidated
 Balance Sheets at fair value.

[0001193125-14-239169:notes:137]
Unrealized
 gains and temporary losses, net of related taxes, are included in
 accumulated other comprehensive income (loss) (AOCI). Upon
 realization, those amounts are reclassified from AOCI to earnings.
 The amortization of premiums and discounts on the investments are
 included in our results of operations. Realized gains or losses on
 our available-for-sale investments are calculated based on the
 specific identification method.

[0001193125-14-239169:notes:138]
We classify
 our investments as current or noncurrent based on the nature of the
 investments and their availability for use in current
 operations.

[0001193125-14-239169:notes:139]
Other-than-Temporary Impairments on Investments — All of our
 available-for-sale investments are subject to periodic impairment
 review. When the fair value of a debt security is less than its
 amortized cost, it is deemed impaired, and we assess whether the
 impairment is other-than-temporary. An impairment is considered
 other-than-temporary if (i) we have the intent to sell the
 security, (ii) it is more likely than not that we will be
 required to sell the security before recovery of the entire
 amortized cost basis, or (iii) we do not expect to recover the
 entire amortized cost basis of the security. If impairment is
 considered other-than-temporary based on condition (i) or
 (ii) described above, the entire difference between the
 amortized cost and the fair value of the debt security is
 recognized in the results of operations. If an impairment is
 considered other-than-temporary based on condition (iii), described
 above, the amount representing credit losses (defined as the
 difference between the present value of the cash flows expected to
 be collected and the amortized cost basis of the debt security) is
 recognized in earnings, and the amount relating to all other
 factors is recognized in other comprehensive income
 (OCI).

[0001193125-14-239169:notes:140]
For our
 auction rate securities (ARSs), impairment is determined based on
 fair value and marketability of these investments. The valuation
 models used to estimate fair value include numerous assumptions
 such as assessments of the underlying structure of each security,
 expected cash flows, discount rates, trading activity in the
 secondary market for similar securities, credit ratings, workout
 periods, and overall capital market liquidity.

[0001193125-14-239169:notes:141]
Inventories — Inventories are stated
 at the lower of cost or market, which approximates actual cost on a
 first-in, first-out basis. We write down for excess and obsolete
 inventory based on the difference between the cost of inventory and
 the estimated net realizable value based upon assumptions about
 future demand forecasts and market conditions. At the point of a
 loss recognition, a new, lower cost basis for that inventory is
 established, and subsequent changes in facts or circumstances do
 not result in the restoration or increase in that newly established
 basis. In addition, we record a liability for firm, non-cancelable
 and unconditional purchase commitments with contract manufacturers
 and suppliers for quantities in excess of our future demand
 forecasts consistent with our valuation of excess and obsolete
 inventory.

[0001193125-14-239169:notes:142]
Property
 and Equipment — Property and equipment
 are recorded at cost. Depreciation and amortization is computed
 using the straight-line method, generally over the following
 periods:

[0001193125-14-239169:notes:143]
|  |  | Depreciation Life (years) |
| Buildings |  | 40 years |
| Building improvements |  | 10 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 3 years |
| Software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001193125-14-239169:notes:144]
Construction
 in progress will be depreciated over the estimated useful lives of
 the respective assets when they are ready for use. We capitalize
 interest on significant facility assets under construction and on
 significant software development projects.

[0001193125-14-239169:notes:145]
Software
 Development Costs — The costs for the
 development of new software products and substantial enhancements
 to existing software products are expensed as incurred until
 technological feasibility has been established, at which time any
 additional costs would be capitalized in accordance with the
 accounting guidance for software. Because our current process for
 developing software is essentially completed concurrently with the
 establishment of technological feasibility, which occurs upon the
 completion of a working model, no costs have been capitalized for
 any of the periods presented.

[0001193125-14-239169:notes:146]
Internal-Use Software Development Costs — We capitalize
 qualifying costs, which are incurred during the application
 development stage, for computer software developed or obtained for
 internal-use and amortize them over the software’s estimated
 useful life.

[0001193125-14-239169:notes:147]
Business
 Combinations — We recognize
 identifiable assets acquired and liabilities assumed at their
 acquisition date fair values. Goodwill as of the acquisition date
 is measured as the excess of consideration transferred over the net
 of the acquisition date fair values of the assets acquired and the
 liabilities assumed. While we use our best estimates and
 assumptions as a part of the purchase price allocation process to
 accurately value assets acquired and liabilities assumed at the
 acquisition date, our estimates are inherently uncertain and
 subject to refinement. As a result, during the measurement period,
 which may be up to one year from the acquisition date, we record
 adjustments to the assets acquired and liabilities assumed, with
 the corresponding offset to goodwill to the extent that we identify
 adjustments to the preliminary purchase price allocation. Upon the
 conclusion of the measurement period or final determination of the
 values of assets acquired or liabilities assumed, whichever comes
 first, any subsequent adjustments are recorded to our consolidated
 statements of operations.

[0001193125-14-239169:notes:148]
Goodwill
 and Purchased Intangible Assets — Goodwill is recorded when
 the consideration paid for an acquisition exceeds the fair value of
 net tangible and intangible assets acquired. Purchased intangible
 assets are amortized on a straight-line basis over their economic
 lives of three to six years for developed technology, two to eight
 years for customer contracts/relationships, two to three years for
 covenants not to compete and two to seven years for trademarks and
 trade names as we believe this method most closely reflects the
 pattern in which the economic benefits of the assets will be
 consumed.

[0001193125-14-239169:notes:149]
The carrying
 value of goodwill is tested for impairment on an annual basis in
 the fourth quarter of our fiscal year or more frequently if we
 believe indicators of impairment exist. Triggering events for
 impairment reviews may be indicators such as adverse industry or
 economic trends, restructuring actions, lower projections of
 profitability, or a sustained decline in our market capitalization.
 The performance of the test involves a two-step process. The first
 step requires comparing the fair value of each of our reporting
 units to its net book value, including goodwill. We have three
 reporting units, the fair values of which are determined based on
 an allocation of our entity level market capitalization, as
 determined through quoted market prices. A potential impairment
 exists if the fair value of the reporting unit is lower than its
 net book value. The second step of the process is only performed if
 a potential impairment exists, and it involves determining the
 difference between the fair value of the reporting unit’s net
 assets other than goodwill to the fair value of the reporting unit
 and if the difference is less than the net book value of goodwill,
 an impairment exists and is recorded. We have not been required to
 perform this second step of the process because the fair value of
 our reporting units have exceeded their net book value for fiscal
 2014, 2013 and 2012.

[0001193125-14-239169:notes:150]
Impairment
 of Long-Lived Assets — We review the carrying
 values of long-lived assets whenever events and circumstances, such
 as reductions in demand, lower projections of profitability,
 significant changes in the manner of our use of acquired assets, or
 significant negative industry or economic trends, indicate that the
 net book value of an asset may not be recovered through expected
 future cash flows from its use and eventual disposition. If this
 review indicates that there is an impairment, the impaired asset is
 written down to its fair value, which is typically calculated
 using: (i) quoted market prices and/or (ii) expected
 future cash flows utilizing a discount rate. Our estimates
 regarding future anticipated net revenue and cash flows, the
 remaining economic life of the products and technologies, or both,
 may differ from those used to assess the recoverability of assets.
 In that event, impairment charges or shortened useful lives of
 certain long-lived assets may be required, resulting in charges to
 our consolidated statements of operations when such determinations
 are made.

[0001193125-14-239169:notes:151]
Derivative
 Instruments — Our derivative
 instruments consist of foreign currency exchange contracts as
 described below:

[0001193125-14-239169:notes:152]
Balance
 Sheet Hedges — We utilize foreign currency
 exchange forward and option contracts to hedge against the
 short-term impact of foreign currency exchange rate fluctuations
 related to certain foreign-currency-denominated monetary assets and
 liabilities, primarily intercompany receivables and payables. These
 derivative instruments are not designated as hedging instruments
 and do not subject us to material balance sheet risk due to
 exchange rate movements because the gains and losses on these
 contracts are intended to offset the gains and losses in the
 underlying foreign currency denominated monetary assets and
 liabilities being hedged and the net amount is included in
 earnings.

[0001193125-14-239169:notes:153]
Cash Flow
 Hedges —
 We use foreign currency exchange forward contracts to hedge foreign
 currency exchange exposures related to forecasted sales
 transactions denominated in certain foreign currencies. These
 derivative instruments are designated and qualify as cash flow
 hedges and in general, closely match the underlying forecasted
 transactions in duration. The contracts are carried on the
 consolidated balance sheets at fair value, and the effective
 portion of the contracts’ gains and losses resulting from
 changes in fair value is recorded in AOCI until the forecasted
 transaction is recognized in the consolidated statements of
 operations. When the forecasted transactions occur, we reclassify
 the related gains or losses on the cash flow hedges into net
 revenues. If the underlying forecasted transactions do not occur,
 or it becomes probable that they will not occur, within the defined
 hedge period, the gains or losses on the related cash flow hedges
 are reclassified from AOCI and recognized immediately in earnings.
 We measure the effectiveness of hedges of forecasted transactions
 on a monthly basis by comparing the fair values of the designated
 foreign currency exchange forward purchase contracts with the fair
 values of the forecasted transactions. Any ineffective portion of
 the derivative hedging gain or loss, as well as changes in the fair
 value of the derivative’s time value (which are excluded from
 the assessment of hedge effectiveness), is recognized in
 earnings.

[0001193125-14-239169:notes:154]
Factors that
 could have an impact on the effectiveness of our hedging program
 include the accuracy of forecasts and the volatility of foreign
 currency markets. These programs reduce, but do not entirely
 eliminate, the impact of currency exchange movements. The
 maturities of these instruments are generally less than one year.
 Currently, we do not enter into any foreign exchange forward
 contracts to hedge exposures related to firm commitments or
 nonmarketable investments. Cash flows from our derivative programs
 are included under operating activities in the consolidated
 statements of cash flows.

[0001193125-14-239169:notes:155]
Product
 Warranties — Estimated future
 hardware and software warranty costs are recorded as a cost of
 product revenues when the related revenue is recognized, based on
 historical and projected warranty claim rates, historical and
 projected cost-per-claim and knowledge of specific product failures
 that are outside our typical experience. Factors that affect our
 warranty liability include the number of installed units subject to
 warranty protection, product failure rates, estimated material
 costs, estimated distribution costs and estimated labor costs. We
 assess the adequacy of our warranty accrual each quarter and adjust
 the amount as considered necessary.

[0001193125-14-239169:notes:156]
Foreign
 Currency Translation — For international
 subsidiaries whose functional currency is the local currency, gains
 and losses resulting from translation of these foreign currency
 financial statements into U.S. dollars are recorded in AOCI.
 For subsidiaries where the functional currency is the
 U.S. dollar, gains and losses resulting from the process of
 remeasuring foreign currency financial statements into
 U.S. dollars are included in other income (expense),
 net.

[0001193125-14-239169:notes:157]
Benefit
 Plans —
 We have a postretirement health care plan and various international
 defined benefit plans for certain of our employees. We record
 actuarial gains and losses within AOCI and amortize net gains or
 losses in excess of 10 percent of the greater of the market value
 of plan assets or the plans’ projected benefit obligation on
 a straight-line basis over the remaining estimated service life of
 plan participants. The measurement date for all defined benefit
 plans is our fiscal year end.

[0001193125-14-239169:notes:158]
Stock-Based Compensation — We measure and
 recognize stock-based compensation for all stock-based awards,
 including employee stock options, restricted stock units (RSUs) and
 rights to purchase shares under our employee stock purchase plan
 (ESPP), based on their estimated fair value, and recognize the
 costs in our financial statements using the single option
 straight-line approach over the requisite service period for the
 entire award.

[0001193125-14-239169:notes:159]
The fair
 value of employee RSUs is equal to the market value of our common
 stock on the grant date of the award, less (effective with our
 first dividend declaration in May 2013) the present value of
 expected dividends during the vesting period, discounted at a
 risk-free interest rate. Calculating the fair value of employee
 stock options and the rights to purchase shares under the ESPP
 requires estimates and significant judgment. The fair value of each
 award is estimated on the grant date using the Black-Scholes option
 pricing model, and is not remeasured as a result of subsequent
 stock price fluctuations. Option-pricing models require the input
 of highly subjective assumptions, including the expected term of
 awards and the stock price volatility of the underlying stock of
 such awards. Our expected term assumption is based primarily on
 historical exercise and post-vesting forfeiture experience.
 Effective fiscal 2013, our stock price volatility assumption is
 based on a combination of our historical and implied volatility,
 whereas prior to fiscal 2013, we solely used implied volatility.
 The change in volatility assumption methodology was based upon our
 assessment that blended volatility is more representative of our
 future stock price trends as it weighs in the longer term
 historical volatility with the near term future implied
 volatility.

[0001193125-14-239169:notes:160]
In addition,
 the Black-Scholes option pricing model requires risk-free interest
 rates and expected dividends. The risk-free interest rates are
 based upon United States Treasury bills with equivalent expected
 terms, and the expected dividends are based on our history and
 expected dividend payouts.

[0001193125-14-239169:notes:161]
We estimate
 the number of stock-based awards that will be forfeited due to
 employee turnover. Our forfeiture assumption is primarily based on
 historical experience.

[0001193125-14-239169:notes:162]
In the event
 of a modification of stock-based awards, if the requisite service
 period of the modified award is longer than the requisite service
 period of the original award and, both before and after the
 modification, it is probable that the awards will vest, we
 recognize the unrecognized compensation cost remaining from the
 original award plus the incremental compensation cost, if any, as a
 result of a modification in its entirety over the remaining portion
 of the requisite service period of the modified award.

[0001193125-14-239169:notes:163]
The
 accounting guidance for income taxes prescribes a comprehensive
 model for how a company should recognize, measure, present, and
 disclose in its financial statements uncertain tax positions that
 we have taken or expect to take on a tax return (including a
 decision whether to file or not to file a return in a particular
 jurisdiction). We recognize the tax liability for uncertain income
 tax positions on the income tax return based on the two-step
 process prescribed in the interpretation. The first step is to
 determine whether it is more likely than not that each income tax
 position would be sustained upon audit. The second step is to
 estimate and measure the tax benefit as the amount that has a
 greater than 50% likelihood of being realized upon ultimate
 settlement with the tax authority. Estimating these amounts
 requires us to determine the probability of various possible
 outcomes. We evaluate these uncertain tax positions on a quarterly
 basis. The Company recognizes interest and penalties related to
 unrecognized tax benefits within the income tax expense line in the
 accompanying Consolidated Statement of Operations.

[0001193125-14-239169:notes:164]
Determining
 the liability for uncertain tax positions requires us to make
 significant estimates and judgments as to whether, and the extent
 to which, additional taxes may be due based on potential tax audit
 issues in the U.S. and other tax jurisdictions throughout the
 world. Our estimates are based on the outcomes of previous audits,
 as well as the precedents set in cases in which others have taken
 similar tax positions to those taken by us. If we later determine
 that our exposure is lower or that the liability is not sufficient
 to cover our revised expectations, we adjust the liability and
 effect a related change in our tax provision during the period in
 which we make such a determination.

[0001193125-14-239169:notes:165]
Tax
 attributes related to the exercise of employee stock options are
 not realized until they result in a reduction of taxes payable. We
 do not include unrealized stock option attributes as components of
 our gross deferred tax assets and corresponding valuation allowance
 disclosures.

[0001193125-14-239169:notes:166]
Net Income
 per Share — Basic net income per
 share is computed by dividing income available to common
 stockholders by the weighted-average number of common shares
 outstanding. Diluted net income per share is computed giving effect
 to all dilutive potential shares that were outstanding during the
 period. Dilutive potential common shares consist of common shares
 issuable upon exercise of stock options, RSUs, ESPP shares,
 warrants and assumed conversion of our 1.75% Convertible Senior
 Notes due 2013 (the Convertible Notes). Repurchased shares that are
 held as treasury stock are excluded from the outstanding
 shares.

[0001193125-14-239169:notes:167]
Treasury
 Stock —
 We account for treasury stock under the cost method. If treasury
 stock is re-issued at a price higher than its cost, the difference
 is recorded as a component of additional paid-in capital on our
 consolidated balance sheets. If treasury stock is re-issued at a
 price lower than its cost, the difference is recorded as a
 component of additional paid-in-capital to the extent that there
 are gains to offset the losses. If there are no treasury stock
 gains in additional paid-in-capital, the losses upon re-issuance of
 treasury stock are recorded as a component of retained earnings on
 our consolidated balance sheets. Upon the retirement of treasury
 stock, we allocate the value of treasury shares between common
 stock, additional paid-in capital and retained earnings.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-14-239169:notes:168]
7. Balance Sheet
 Details

[0001193125-14-239169:notes:169]
Other
 current assets (in millions):

[0001193125-14-239169:notes:170]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Prepaid expenses and other current assets |  | $ | 219.4 |  |  | $ | 271.5 |  |
| Deferred tax assets |  |  | 270.3 |  |  |  | 253.7 |  |
| Other current assets |  | $ | 489.7 |  |  | $ | 525.2 |  |

[0001193125-14-239169:notes:171]
In fiscal 2013,
 we exercised our options under our three remaining synthetic
 leasing arrangements to terminate the leases and purchase the
 related facilities, including land and buildings, for $69.6
 million. The purchased facilities had an aggregate fair value of
 $88.4 million at the dates of the respective purchases. In fiscal
 2012, we exercised our option under one of our synthetic leasing
 arrangements to early terminate the lease and purchase the
 facilities, including land and buildings, for $80.0 million, which
 had a fair value of $44.3 million at the date of purchase. We had
 accounted for these leasing arrangements as operating leases. The
 difference between the estimated fair value of the facilities and
 their respective lease obligation had been accrued as additional
 rent expense in our consolidated statement of operations and as a
 residual value guarantee obligation in our consolidated balance
 sheets. The terminations did not result in a material impact to our
 operating results.

[0001193125-14-239169:notes:172]
The net book
 value of software, which includes capitalized internal-use software
 development costs, is summarized below (in millions):

[0001193125-14-239169:notes:173]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Computer software |  | $ | 103.5 |  |  | $ | 162.5 |  |

[0001193125-14-239169:notes:174]
Depreciation
 and amortization expense related to property and equipment, net is
 summarized below (in millions):

[0001193125-14-239169:notes:175]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Depreciation and amortization expense |  | $ | 275.0 |  |  | $ | 258.8 |  |  | $ | 204.1 |  |

[0001193125-14-239169:notes:176]
Included in
 depreciation and amortization expense above is amortization related
 to computer software, as summarized below (in millions):

[0001193125-14-239169:notes:177]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Computer software amortization expense |  | $ | 74.4 |  |  | $ | 76.7 |  |  | $ | 53.8 |  |

[0001193125-14-239169:notes:178]
Short-term and long-term deferred revenue (in
 millions):

[0001193125-14-239169:notes:179]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Product |  | $ | 23.4 |  |  | $ | 15.7 |  |
| SEM and service |  |  | 3,076.8 |  |  |  | 2,993.8 |  |
| Total |  | $ | 3,100.2 |  |  | $ | 3,009.5 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,653.8 |  |  | $ | 1,563.3 |  |
| Long-term |  |  | 1,446.4 |  |  |  | 1,446.2 |  |
| Total |  | $ | 3,100.2 |  |  | $ | 3,009.5 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-14-239169:notes:180]
2. Concentration of
 Risk

[0001193125-14-239169:notes:181]
Financial
 instruments that potentially subject us to concentrations of credit
 risk consist primarily of cash equivalents, investments, foreign
 exchange contracts and accounts receivable. Cash equivalents and
 short-term investments consist primarily of corporate bonds,
 U.S. Treasury and government debt securities and money market
 funds, all of which are considered high investment grade. Our
 policy is to limit the amount of credit exposure through
 diversification and investment in highly rated securities. We
 further mitigate concentrations of credit risk in our investments
 by limiting our investments in the debt securities of a single
 issuer and by diversifying risk across geographies and type of
 issuer.

[0001193125-14-239169:notes:182]
Our long term
 investments, consisting primarily of ARSs, have been and will
 continue to be exposed to market risk due to uncertainties in the
 credit and capital markets.

[0001193125-14-239169:notes:183]
In entering into
 forward foreign exchange contracts, we have assumed the risk that
 might arise from the possible inability of counterparties to meet
 the terms of their contracts. The counterparties to these contracts
 are major multinational commercial banks, and we do not expect any
 losses as a result of counterparty defaults.

[0001193125-14-239169:notes:184]
We sell our
 products primarily to large organizations in different industries
 and geographies. We do not require collateral or other security to
 support accounts receivable. In addition, we maintain an allowance
 for potential credit losses. To reduce credit risk, we perform
 ongoing credit evaluations on our customers’ financial
 condition. We establish an allowance for doubtful accounts based
 upon factors surrounding the credit risk of customers, historical
 trends and other information and, to date, such losses have been
 within management’s expectations. Concentrations of credit
 risk with respect to trade accounts receivable are limited due to
 the wide variety of customers who are dispersed across many
 geographic regions.

[0001193125-14-239169:notes:185]
There are no
 concentrations of business transacted with a particular market that
 would severely impact our business in the near term. However, we
 currently rely on a limited number of suppliers for certain key
 components and a few key contract manufacturers to manufacture most
 of our products; any disruption or termination of these
 arrangements could materially adversely affect our operating
 results.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-14-239169:notes:186]
A
 reconciliation of the beginning and ending amount of unrecognized
 tax benefits is as follows (in millions):

[0001193125-14-239169:notes:187]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Balance at beginning of period |  | $ | 189.6 |  |  | $ | 161.0 |  |  | $ | 133.3 |  |
| Additions based on tax positions related to the current year |  |  | 26.9 |  |  |  | 34.5 |  |  |  | 13.0 |  |
| Additions for tax positions of prior years |  |  | 23.8 |  |  |  | 1.0 |  |  |  | 22.1 |  |
| Decreases for tax positions of prior years |  |  | (4.4 | ) |  |  | (6.9 | ) |  |  | (7.4 | ) |
| Balance at end of period |  | $ | 235.9 |  |  | $ | 189.6 |  |  | $ | 161.0 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-14-239169:notes:188]
|  |  | ESPP |  |
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Volatility |  |  | 31 | % |  |  | 40 | % |  |  | 44 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 0.0 | % |
| Weighted-average fair value per right granted |  | $ | 10.83 |  |  | $ | 10.36 |  |  | $ | 12.87 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001193125-14-239169:notes:189]
Activities
 related to these plans for the year ended April 25, 2014 were
 as follows (in millions):

[0001193125-14-239169:notes:190]
|  |  | May 2013 Plan |  |  | March 2014 Plan |  |  | Total |  |
| Net charges |  | $ | 49.5 |  |  | $ | 38.8 |  |  | $ | 88.3 |  |
| Cash payments |  |  | (49.5 | ) |  |  | (12.3 | ) |  |  | (61.8 | ) |
| Balance as of April 25, 2014 |  | $ | 0.0 |  |  | $ | 26.5 |  |  | $ | 26.5 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-14-239169:notes:191]
19. Selected
 Quarterly Financial Data (Unaudited)


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-14-239169:notes:192]
4. Statements of
 Cash Flows

[0001193125-14-239169:notes:193]
Non-cash
 investing and financing activities and supplemental cash flow
 information are as follows (in millions):

[0001193125-14-239169:notes:194]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Reclassification of equity component of Convertible Notes |  | $ | 0.0 |  |  | $ | 62.6 |  |  | $ | 52.0 |  |
| Capital expenditures incurred but not paid |  | $ | 18.0 |  |  | $ | 20.2 |  |  | $ | 31.4 |  |
| Acquisition of software through long-term financing |  | $ | 11.4 |  |  | $ | 0.8 |  |  | $ | 3.6 |  |
| Vested options assumed in acquisition |  | $ | 0.0 |  |  | $ | 1.2 |  |  | $ | 0.0 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 58.1 |  |  | $ | 46.7 |  |  | $ | 48.2 |  |
| Interest paid, net of capitalized interest |  | $ | 35.2 |  |  | $ | 22.8 |  |  | $ | 21.4 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-14-239169:notes:195]
The following
 is a calculation of basic and diluted net income per share (in
 millions, except per share amounts):

[0001193125-14-239169:notes:196]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 637.5 |  |  | $ | 505.3 |  |  | $ | 605.4 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 340.3 |  |  |  | 361.5 |  |  |  | 363.9 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 6.9 |  |  |  | 5.4 |  |  |  | 8.8 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 0.5 |  |  |  | 1.1 |  |  |  | 9.4 |  |
| Dilutive impact of warrants |  |  | 0.2 |  |  |  | 0.0 |  |  |  | 2.2 |  |
| Shares used in diluted computation |  |  | 347.9 |  |  |  | 368.0 |  |  |  | 384.3 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.87 |  |  | $ | 1.40 |  |  | $ | 1.66 |  |
| Diluted |  | $ | 1.83 |  |  | $ | 1.37 |  |  | $ | 1.58 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-14-239169:notes:197]
12. Restructuring and
 Other Charges

[0001193125-14-239169:notes:198]
In May 2013, we
 initiated a business restructuring plan under which we realigned
 internal resources, resulting in a reduction of our global
 workforce of approximately 7%. Such activities have been completed
 as of April 25, 2014. In March 2014, we initiated a business
 realignment plan designed to focus our resources on key strategic
 initiatives and streamline our business in light of the constrained
 IT spending environment, resulting in a reduction of our global
 workforce of approximately 4%. We expect such activities to be
 substantially completed in the second quarter of fiscal 2015.
 Restructuring and other charges consisted primarily of employee
 severance-related costs.

[0001193125-14-239169:notes:199]
The liability
 for our restructuring plans as of April 25, 2014 is included
 in accrued compensation and related benefits in our consolidated
 balance sheets.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-14-239169:notes:200]
The following
 table presents cash, cash equivalents, restricted cash and
 investments held in the United States and internationally in
 various foreign subsidiaries (in millions):

[0001193125-14-239169:notes:201]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| United States |  | $ | 688.5 |  |  | $ | 3,419.3 |  |
| International |  |  | 4,360.9 |  |  |  | 3,586.8 |  |
| Total |  | $ | 5,049.4 |  |  | $ | 7,006.1 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-14-239169:notes:202]
The amounts reclassified
 out of AOCI are as follows (in millions):

[0001193125-14-239169:notes:203]
|  |  | Year Ended |  |  |  |  |
| OCI Components |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | Statements of Operations Location |  |
|  | Amounts Reclassified from AOCI |  |  |
| Recognized losses on defined benefit obligations |  | $ | 0.4 |  |  | $ | 0.0 |  |  | $ | 0.0 |  |  |  | Operating expenses |  |
| Realized losses (gains) on available-for-sale securities |  |  | (1.3 | ) |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | Other income, net |  |
| Realized losses (gains) on cash flow hedges |  |  | 2.0 |  |  |  | (2.2 | ) |  |  | (18.9 | ) |  |  | Net revenues |  |
| Total reclassifications |  | $ | 1.1 |  |  | $ | (2.8 | ) |  | $ | (19.4 | ) |  |  |  |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-14-239169:notes:204]
The following
 table presents property and equipment information for geographic
 areas based on the physical location of the assets (in
 millions):

[0001193125-14-239169:notes:205]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,021.4 |  |  | $ | 1,076.3 |  |
| International |  |  | 87.4 |  |  |  | 94.6 |  |
| Total |  | $ | 1,108.8 |  |  | $ | 1,170.9 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-14-239169:notes:206]
5. Business
 Combinations

[0001193125-14-239169:notes:207]
Fiscal
 2013 Acquisitions

[0001193125-14-239169:notes:208]
On
 February 11, 2013, we acquired all of the outstanding shares
 of ionGrid, a privately-held software company based in California,
 for $17.1 million in cash. This acquisition provides our customers
 with a secure, simple to use solution for accessing enterprise file
 shares from mobile devices. On November 14, 2012, we acquired
 all of the outstanding shares of CacheIQ, Inc., a privately-held
 storage solutions company based in Texas, for $91.0 million in cash
 and equity. This acquisition provides us with technology that
 extends our capabilities to support non-disruptive operations for
 enterprise data center environments. We will integrate this
 technology into our product offerings over time. Together we refer
 to these acquisitions as our fiscal 2013 acquisitions.

[0001193125-14-239169:notes:209]
Consideration
 related to our fiscal 2013 acquisitions consisted of the following
 (in millions):

[0001193125-14-239169:notes:210]
| Cash |  | $ | 106.9 |  |
| Equity |  |  | 1.2 |  |
| Total purchase price |  | $ | 108.1 |  |

[0001193125-14-239169:notes:211]
The purchase
 price was allocated to the respective net tangible and intangible
 assets of our fiscal 2013 acquisitions as of the dates of the
 acquisitions based on various fair value estimates and analyses,
 including work performed by third-party valuation
 specialists.

[0001193125-14-239169:notes:212]
The following
 are the fair value of assets acquired and liabilities assumed as of
 the respective closing dates (in millions):

[0001193125-14-239169:notes:213]
| Cash |  | $ | 0.4 |  |
| Other current assets |  |  | 6.0 |  |
| Finite-lived intangible assets |  |  | 30.3 |  |
| Goodwill |  |  | 82.9 |  |
| Other assets |  |  | 1.0 |  |
| Total assets acquired |  |  | 120.6 |  |
| Current liabilities |  |  | (0.5 | ) |
| Deferred income taxes |  |  | (12.0 | ) |
| Total purchase price |  | $ | 108.1 |  |

[0001193125-14-239169:notes:214]
The goodwill
 recorded from our fiscal 2013 acquisitions is comprised
 of expected synergies from combining their respective
 operations and that of the Company.

[0001193125-14-239169:notes:215]
None of the
 goodwill recognized upon acquisition of our fiscal 2013
 acquisitions is deductible for tax purposes. The finite-lived
 intangible assets acquired from our fiscal 2013 acquisitions
 consist of developed technology and are amortized on a
 straight-line basis over three to five year estimated useful
 lives.

[0001193125-14-239169:notes:216]
The results of
 operations of our fiscal 2013 acquisitions have been included in
 our consolidated statements of operations from their respective
 acquisition dates. Pro forma results of operations have not been
 presented because the acquisitions, individually and collectively,
 were not material to our results of operations.

[0001193125-14-239169:notes:217]
Fiscal
 2012 Acquisition

[0001193125-14-239169:notes:218]
On May 6,
 2011, we completed the acquisition of certain assets related to the
 Engenio external storage systems business (Engenio) of LSI
 Corporation (LSI). We paid LSI $480.0 million in cash and also
 assumed certain liabilities related to Engenio. During the three
 years following the acquisition, LSI will pay us a total of
 $13.0 million to service certain LSI customer warranties. This
 acquisition enables us to address growing customer requirements in
 the areas of high bandwidth and intensive analytics
 workloads.

[0001193125-14-239169:notes:219]
The purchase
 price was allocated to Engenio’s net tangible and intangible
 assets as of the date of acquisition based on various fair value
 estimates and analyses, including work performed by third-party
 valuation specialists.

[0001193125-14-239169:notes:220]
The following
 are the fair value of assets acquired and liabilities assumed as of
 the closing date (in millions):

[0001193125-14-239169:notes:221]
| Current assets |  | $ | 49.8 |  |
| Property and equipment |  |  | 33.3 |  |
| Finite-lived intangible assets |  |  | 272.1 |  |
| Goodwill |  |  | 143.7 |  |
| Other assets |  |  | 9.3 |  |
| Total assets acquired |  |  | 508.2 |  |
| Current liabilities |  |  | (20.9 | ) |
| Other liabilities |  |  | (7.3 | ) |
| Total purchase price |  | $ | 480.0 |  |

[0001193125-14-239169:notes:222]
As this was an
 asset acquisition, U.S. goodwill is deductible for income tax
 purposes. The goodwill is comprised of expected synergies in
 utilizing Engenio’s technology in our products and channels
 (and vice versa), reduction in future combined research and
 development expenses, and intangible assets, such as acquired
 workforce, that do not qualify for separate recognition.

[0001193125-14-239169:notes:223]
Our
 consolidated net revenues for fiscal 2012 included $665.9 million
 attributable to Engenio since the acquisition. Due to the
 integration of the combined businesses since the date of
 acquisition, it is impracticable to determine the earnings
 contributed by Engenio.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-14-239169:notes:224]
Goodwill
 activity is summarized as follows (in millions):

[0001193125-14-239169:notes:225]
| April 27, 2012 |  | $ | 905.2 |  |
| Additions |  |  | 82.9 |  |
| April 26, 2013 |  |  | 988.1 |  |
| Additions |  |  | 0.0 |  |
| April 25, 2014 |  | $ | 988.1 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-14-239169:notes:226]
The following
 table summarizes the activity related to product warranty
 liabilities for fiscal 2014 and 2013 (in millions):

[0001193125-14-239169:notes:227]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Balance at beginning of period |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 70.2 |  |  |  | 94.8 |  |
| Warranty costs incurred |  |  | (77.4 | ) |  |  | (60.7 | ) |
| Balance at end of period |  | $ | 110.0 |  |  | $ | 117.2 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-14-239169:notes:228]
16. Employee
 Benefits and Deferred Compensation

[0001193125-14-239169:notes:229]
Employee
 401(k) Plan

[0001193125-14-239169:notes:230]
We have
 established a 401(k) tax-deferred savings plan. Employees meeting
 the eligibility requirements, as defined, may contribute specified
 percentages of their salaries, but not more than the statutory
 limits. We match 100% of the first $1,000 of employee
 contributions, then 50% for additional contributions, up to a
 maximum match of $3,000 per employee. The matched contributions
 vest over 3 years. The amounts we contributed to this plan,
 net of forfeitures, were as follows (in millions):

[0001193125-14-239169:notes:231]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| 401(k) matching contributions |  | $ | 19.6 |  |  | $ | 19.9 |  |  | $ | 20.0 |  |

[0001193125-14-239169:notes:232]
Deferred
 Compensation Plan

[0001193125-14-239169:notes:233]
We have a
 non-qualified deferred compensation plan that allows a group of
 employees within the United States to contribute base salary and
 commissions or incentive compensation on a tax deferred basis in
 excess of the IRS limits imposed on 401(k) plans. The marketable
 securities related to these investments that are held in a rabbi
 trust under the non-qualified deferred compensation plan and the
 related deferred compensation plan liabilities under this plan were
 as follows (in millions):

[0001193125-14-239169:notes:234]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Deferred compensation plan assets |  | $ | 32.7 |  |  | $ | 28.3 |  |
| Deferred compensation plan liabilities reported as: |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 6.4 |  |  |  | 1.6 |  |
| Other long-term liabilities |  |  | 26.3 |  |  |  | 26.7 |  |

[0001193125-14-239169:notes:235]
Postretirement Health Care Plan

[0001193125-14-239169:notes:236]
We maintain a
 plan to provide postretirement health and welfare benefits to
 certain executives who meet certain age and service requirements.
 Coverage continues through the duration of the lifetime of the
 retiree or the retiree’s spouse, whichever is longer. There
 is no funding requirement associated with the plan and none of the
 benefit obligation was funded as of April 25, 2014. Assumed
 health care cost trend rates have a significant effect on the
 amounts reported for the health care plan.

[0001193125-14-239169:notes:237]
International Defined Benefit Plans

[0001193125-14-239169:notes:238]
We maintain
 various defined benefit plans to provide termination and
 postretirement benefits to certain eligible employees outside of
 the United States. We also provide disability benefits to certain
 eligible employees in the United States. Eligibility is determined
 based on the terms of our plans and local statutory requirements.
 Assumed discount rates and expected long-term returns on plan
 assets have significant effects on the amounts reported for the
 defined benefit plans.

[0001193125-14-239169:notes:239]
Funded
 Status

[0001193125-14-239169:notes:240]
Amounts
 recognized in the consolidated balance sheets were as follows (in
 millions):

[0001193125-14-239169:notes:241]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Other long-term liabilities |  | $ | 27.0 |  |  | $ | 27.4 |  |
| AOCI |  | $ | (4.8 | ) |  | $ | (5.7 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-239169:notes:242]
14. Net Income per
 Share

[0001193125-14-239169:notes:243]
Dilutive shares
 outstanding during fiscal 2013 do not include any effect resulting
 from warrants, as their impact would have been anti-dilutive. The
 Convertible Note hedges are not included in the calculation of
 earnings per share prior to their exercise as their effect would
 have been anti-dilutive.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-14-239169:notes:244]
10. Stockholders’ Equity

[0001193125-14-239169:notes:245]
Equity
 Incentive Programs

[0001193125-14-239169:notes:246]
The 1999
 Plan — As most recently amended on
 September 13, 2013, the 1999 Stock Option Plan (the Plan)
 comprises five separate equity incentive programs: (i) the
 Discretionary Option Grant Program under which options may be
 granted to eligible individuals at a fixed price per share;
 (ii) the Stock Appreciation Rights Program under which
 eligible persons may be granted stock appreciation rights that
 allow individuals to receive the appreciation in fair market value
 of the shares; (iii) the Stock Issuance Program under which
 eligible individuals may be issued shares of common stock directly;
 (iv) the Performance Share and Performance Unit Program (also
 known as RSUs) under which eligible persons may be granted
 performance shares or performance units which result in payment to
 the participant only if performance goals or other vesting criteria
 are achieved and (v) the Automatic Award Program under which
 nonemployee board members automatically receive equity grants at
 designated intervals over their period of board service. The Plan
 expires in August 2019.

[0001193125-14-239169:notes:247]
Under the
 Plan, the Board of Directors may grant to employees, nonemployee
 directors, consultants and independent advisors options to purchase
 shares of our common stock during their period of service. The
 exercise price for an incentive stock option and a nonstatutory
 option cannot be less than 100% of the fair market value of the
 common stock on the grant date. Options granted under the Plan
 generally vest over a four-year period. Options granted generally
 have a term of seven years after the grant date, subject to
 earlier termination upon the occurrence of certain events. The Plan
 prohibits the repricing of any outstanding stock option or stock
 appreciation right after it has been granted or to cancel any
 outstanding stock option or stock appreciation right and
 immediately replace it with a new stock option or stock
 appreciation right with a lower exercise price unless approved by
 stockholders. RSUs granted under the Plan generally vest over a
 four-year period with 25% vesting on each anniversary of the grant
 date. The Compensation Committee of the Board of Directors has the
 discretion to use different vesting schedules.

[0001193125-14-239169:notes:248]
Under the
 Plan, the number of shares reserved for issuance is reduced by two
 shares for every share subject to a full value award, which are
 specified to be grants that are in the form of performance shares
 and/or performance unit awards, stock, restricted stock, restricted
 stock units. The Plan limits (i) the number of shares that may
 be granted pursuant to awards under the Stock Issuance Program to a
 participant in any calendar year to 1 million,
 (ii) limits the initial value of performance units a
 participant may receive of not more than $5 million and
 (iii) limits the number of performance shares a participant
 may receive in a calendar year to 1 million.

[0001193125-14-239169:notes:249]
During fiscal
 2014, the shares reserved for issuance under the plan were
 increased by 10.0 million shares. As of April 25, 2014,
 17.8 million shares were available for grant under our equity
 incentive plans.

[0001193125-14-239169:notes:250]
Stock
 Options

[0001193125-14-239169:notes:251]
The aggregate
 intrinsic value represents the pre-tax difference between the
 exercise price of stock options and the quoted market price of our
 stock on that day for all in-the-money options.

[0001193125-14-239169:notes:252]
Restricted Stock Units

[0001193125-14-239169:notes:253]
The following
 table summarizes activity related to our RSUs (in millions, except
 for fair value):

[0001193125-14-239169:notes:254]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 29, 2011 |  |  | 10.1 |  |  | $ | 35.79 |  |
| Granted |  |  | 6.5 |  |  | $ | 47.17 |  |
| Vested |  |  | (3.7 | ) |  | $ | 30.35 |  |
| Forfeited |  |  | (0.9 | ) |  | $ | 40.91 |  |
| Outstanding as of April 27, 2012 |  |  | 12.0 |  |  | $ | 43.28 |  |
| Granted |  |  | 6.0 |  |  | $ | 29.94 |  |
| Vested |  |  | (4.0 | ) |  | $ | 39.83 |  |
| Forfeited |  |  | (1.2 | ) |  | $ | 40.95 |  |
| Outstanding as of April 26, 2013 |  |  | 12.8 |  |  | $ | 38.36 |  |
| Granted |  |  | 6.5 |  |  | $ | 38.61 |  |
| Vested |  |  | (4.5 | ) |  | $ | 38.48 |  |
| Forfeited |  |  | (1.6 | ) |  | $ | 39.08 |  |
| Outstanding as of April 25, 2014 |  |  | 13.2 |  |  | $ | 38.35 |  |

[0001193125-14-239169:notes:255]
RSUs are
 converted into common stock upon vesting. We primarily use the net
 share settlement approach upon vesting, where a portion of the
 shares are withheld as settlement of statutory employee withholding
 taxes, which decreases the shares issued to the employee by a
 corresponding value. The number and value of the shares netted for
 employee taxes are summarized in the table below (in
 millions):

[0001193125-14-239169:notes:256]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Shares withheld for taxes |  |  | 1.5 |  |  |  | 1.3 |  |  |  | 1.2 |  |
| Fair value of shares withheld |  | $ | 57.7 |  |  | $ | 40.9 |  |  | $ | 52.0 |  |

[0001193125-14-239169:notes:257]
Employee Stock Purchase Plan

[0001193125-14-239169:notes:258]
Eligible
 employees are offered shares through a 24-month offering period,
 which consists of four consecutive 6-month purchase
 periods. Employees may purchase a limited number of shares of
 the Company’s stock at a discount of up to 15% of the lesser
 of the market value at the beginning of the offering period or the
 end of each 6-month purchase period. On September 13, 2013,
 the ESPP was amended to increase the shares reserved for issuance
 by 5.0 million shares of common stock. As of April 25,
 2014, 7.4 million shares were available for issuance.
 Additional information related to the purchase rights issued under
 the ESPP is provided below (in millions):

[0001193125-14-239169:notes:259]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Shares issued under the ESPP |  |  | 3.8 |  |  |  | 3.8 |  |  |  | 2.6 |  |
| Proceeds from issuance of shares |  | $ | 95.5 |  |  | $ | 95.0 |  |  | $ | 89.6 |  |

[0001193125-14-239169:notes:260]
Stock-Based Compensation Expense

[0001193125-14-239169:notes:261]
Stock-based
 compensation expense is included in the consolidated statements of
 operations as follows (in millions):

[0001193125-14-239169:notes:262]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Cost of product revenues |  | $ | 5.6 |  |  | $ | 6.1 |  |  | $ | 5.4 |  |
| Cost of service revenues |  |  | 16.7 |  |  |  | 19.4 |  |  |  | 17.8 |  |
| Sales and marketing |  |  | 125.0 |  |  |  | 132.2 |  |  |  | 126.0 |  |
| Research and development |  |  | 87.7 |  |  |  | 84.1 |  |  |  | 74.1 |  |
| General and administrative |  |  | 38.0 |  |  |  | 34.8 |  |  |  | 34.3 |  |
| Total stock-based compensation expense |  | $ | 273.0 |  |  | $ | 276.6 |  |  | $ | 257.6 |  |

[0001193125-14-239169:notes:263]
As of
 April 25, 2014, total unrecognized compensation expense
 related to our equity awards was $385.6 million, which is expected
 to be recognized on a straight-line basis over a weighted-average
 remaining service period of 2.3 years.

[0001193125-14-239169:notes:264]
Total income
 tax benefit associated with employee stock transactions and
 recognized in stockholders’ equity were as follows (in
 millions):

[0001193125-14-239169:notes:265]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 40.5 |  |  | $ | 53.8 |  |  | $ | 107.5 |  |

[0001193125-14-239169:notes:266]
Valuation Assumptions

[0001193125-14-239169:notes:267]
The valuation
 of stock options and ESPP purchase rights and the underlying
 weighted-average assumptions are summarized as follows:

[0001193125-14-239169:notes:268]
|  |  | Stock Options |  |
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 1.1 | % |  |  | 0.6 | % |  |  | 1.5 | % |
| Volatility |  |  | 34 | % |  |  | 41 | % |  |  | 36 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 0.0 | % |
| Weighted-average fair value per share granted |  | $ | 9.85 |  |  | $ | 11.52 |  |  | $ | 16.70 |  |

[0001193125-14-239169:notes:269]
The
 weighted-average assumptions used to value RSUs are summarized as
 follows:

[0001193125-14-239169:notes:270]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Grant date fair value per share |  | $ | 38.61 |  |  | $ | 29.94 |  |  | $ | 47.17 |  |
| Expected dividend |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 0.0 | % |

[0001193125-14-239169:notes:271]
Stock
 Repurchase Program

[0001193125-14-239169:notes:272]
As of
 April 25, 2014, our Board of Directors has authorized the
 repurchase of up to $7.1 billion of our common stock, including an
 increase of $1.6 billion approved by our Board of Directors in
 fiscal 2014. Under this program, which we may suspend or
 discontinue at any time, we may purchase shares of our outstanding
 common stock through open market and privately negotiated
 transactions at prices deemed appropriate by our
 management.

[0001193125-14-239169:notes:273]
The aggregate
 purchase price of our stock repurchases for fiscal 2014 consisted
 of $750.0 million under an accelerated share repurchase agreement
 (ASR) and $1,131.5 million of open market purchases, for which
 collectively $0.1 million, $813.4 million and $1,068.0 million was
 allocated to common stock (par value), additional paid-in capital
 and retained earnings, respectively.

[0001193125-14-239169:notes:274]
During fiscal
 2014, we retired 104.3 million shares of common stock
 repurchased in prior years and previously reported as treasury
 stock, resulting in reductions of $0.1 million in common stock (par
 value), $614.0 million in additional paid-in capital and $2,313.3
 million in retained earnings.

[0001193125-14-239169:notes:275]
Since the
 May 13, 2003 inception of our stock repurchase program through
 April 25, 2014, we repurchased a total of 184.3 million
 shares of our common stock at an average price of $32.55 per share,
 for an aggregate purchase price of $6.0 billion.

[0001193125-14-239169:notes:276]
Accelerated Share Repurchase
 Agreements

[0001193125-14-239169:notes:277]
In fiscal
 2014 and 2012, we entered into collared ASRs with third parties
 under which we prepaid $750.0 million and $600 million,
 respectively, to purchase shares of our common stock. The aggregate
 number of shares ultimately purchased was determined based on the
 volume weighted-average share price of our common stock over a
 specified period of time. All such contracts have been settled,
 resulting in the repurchase of 19.2 million and
 14.6 million shares in fiscal 2014 and 2012, respectively, at
 an average price per share of $39.13 and $40.97, respectively. The
 value of the ASR forward contracts settled in fiscal 2014 and 2012
 was determined to be $13.9 million and $0.1 million, respectively,
 which has been recorded as additional paid-in capital.

[0001193125-14-239169:notes:278]
Preferred Stock

[0001193125-14-239169:notes:279]
Our Board of
 Directors has the authority to issue up to 5.0 million shares
 of preferred stock and to determine the price, rights, preferences,
 privileges, and restrictions, including voting rights, of those
 shares without any further vote or action by the
 stockholders.

[0001193125-14-239169:notes:280]
Dividends

[0001193125-14-239169:notes:281]
During fiscal
 2014, we paid cash dividends of $0.60 per share, or $202.3 million
 on our outstanding common stock, of which $50.4 million and $151.9
 million was allocated to additional paid-in capital and retained
 earnings, respectively. No dividends were declared or paid in
 fiscal 2013 and 2012.

[0001193125-14-239169:notes:282]
On
 May 21, 2014, we declared a cash dividend of $0.165 per share
 of common stock, payable on July 22, 2014 to holders of record
 as of the close of business on July 10, 2014. The timing and
 amount of future dividends will depend on market conditions,
 corporate business and financial considerations and regulatory
 requirements. All dividends declared have been determined by the
 Company to be legally authorized under the laws of the state in
 which we are incorporated.

[0001193125-14-239169:notes:283]
Accumulated Other Comprehensive Income

[0001193125-14-239169:notes:284]
Changes in
 accumulated other comprehensive income (AOCI) by component, net of
 tax, are summarized below (in millions):

[0001193125-14-239169:notes:285]
The amounts
 reclassified out of AOCI are as follows (in millions):


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-14-239169:notes:286]
The provision
 for income taxes differs from the amount computed by applying the
 statutory federal income tax rate as follows (in
 millions):

[0001193125-14-239169:notes:287]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Tax computed at federal statutory rate |  | $ | 259.2 |  |  | $ | 198.3 |  |  | $ | 249.4 |  |
| State income taxes, net of federal benefit |  |  | 5.6 |  |  |  | (2.0 | ) |  |  | 6.4 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (163.3 | ) |  |  | (144.4 | ) |  |  | (162.2 | ) |
| Stock-based compensation |  |  | 9.8 |  |  |  | 18.4 |  |  |  | 14.4 |  |
| Research and experimentation credits |  |  | (8.7 | ) |  |  | (12.1 | ) |  |  | (10.9 | ) |
| Resolution of income tax examinations |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 7.3 |  |
| Other |  |  | 0.6 |  |  |  | 3.0 |  |  |  | 2.6 |  |
| Provision for income taxes |  | $ | 103.2 |  |  | $ | 61.3 |  |  | $ | 107.0 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-14-239169:notes:288]
Purchased
 intangible assets, net are summarized below (in
 millions):

[0001193125-14-239169:notes:289]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 283.0 |  |  | $ | (162.6 | ) |  | $ | 120.4 |  |  | $ | 312.4 |  |  | $ | (134.9 | ) |  | $ | 177.5 |  |
| Customer contracts/relationships |  |  | 9.6 |  |  |  | (9.0 | ) |  |  | 0.6 |  |  |  | 54.7 |  |  |  | (53.1 | ) |  |  | 1.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.4 | ) |  |  | 0.5 |  |  |  | 9.9 |  |  |  | (8.9 | ) |  |  | 1.0 |  |
| Covenants not to compete |  |  | 1.6 |  |  |  | (1.6 | ) |  |  | 0.0 |  |  |  | 2.2 |  |  |  | (1.7 | ) |  |  | 0.5 |  |
| Total purchased intangible assets |  | $ | 297.1 |  |  | $ | (175.6 | ) |  | $ | 121.5 |  |  | $ | 379.2 |  |  | $ | (198.6 | ) |  | $ | 180.6 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-14-239169:notes:290]
Summarized
 revenues by geographic region based on information from our
 internal management system and utilized by our Chief Executive
 Officer, who is considered our Chief Operating Decision Maker, is
 as follows (in millions):

[0001193125-14-239169:notes:291]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Americas (United States, Canada and Latin America) |  | $ | 3,513.3 |  |  | $ | 3,552.5 |  |  | $ | 3,529.7 |  |
| Europe, Middle East and Africa |  |  | 1,954.6 |  |  |  | 1,928.8 |  |  |  | 1,936.5 |  |
| Asia Pacific |  |  | 857.2 |  |  |  | 851.1 |  |  |  | 767.0 |  |
| Net revenues |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |  | $ | 6,233.2 |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-14-239169:notes:292]
The components
 of our deferred tax assets and liabilities are as follows (in
 millions):

[0001193125-14-239169:notes:293]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 89.3 |  |  | $ | 83.5 |  |
| Acquired intangibles |  |  | 22.3 |  |  |  | 12.3 |  |
| Net operating loss and credit carryforwards |  |  | 87.6 |  |  |  | 76.5 |  |
| Stock-based compensation |  |  | 73.3 |  |  |  | 81.9 |  |
| Deferred revenue |  |  | 318.9 |  |  |  | 311.6 |  |
| Other |  |  | 19.8 |  |  |  | 20.7 |  |
| Gross deferred tax assets |  |  | 611.2 |  |  |  | 586.5 |  |
| Valuation allowance |  |  | (49.6 | ) |  |  | (39.8 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 561.6 |  |  |  | 546.7 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  |  | 3.9 |  |  |  | 7.7 |  |
| Acquired intangibles |  |  | 10.0 |  |  |  | 6.0 |  |
| Property and equipment |  |  | 30.8 |  |  |  | 71.5 |  |
| Convertible Notes |  |  | 0.0 |  |  |  | 4.4 |  |
| Other |  |  | 2.6 |  |  |  | 4.1 |  |
| Total deferred tax liabilities |  |  | 47.3 |  |  |  | 93.7 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 514.3 |  |  | $ | 453.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-239169:notes:294]
18. Subsequent
 Event

[0001193125-14-239169:notes:295]
On June 5,
 2014 we issued $500.0 million aggregate par value of 3.375% senior
 notes, with a maturity date of June 15, 2021 and received
 proceeds of approximately $494.7 million, net of discount and
 issuance costs, which will be used for general corporate purposes,
 including possible stock repurchases, dividends, capital
 expenditures, working capital and potential acquisitions and
 strategic transactions. The 3.375% senior notes are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with our Senior Notes. We may redeem the 3.375% Senior
 Notes in whole or in part, at any time at our option at specified
 redemption prices. In addition, upon the occurrence of certain
 change of control triggering events, we may be required to
 repurchase the 3.375% Senior Notes at 101% of their aggregate
 principal amount, plus accrued and unpaid interest to the date of
 repurchase.


## us-gaap:ScheduleOfGuaranteeObligationsTextBlock

[0001193125-14-239169:notes:296]
The following
 schedule of financing guarantees represents the total maximum
 potential future payments under financing arrangements with third
 parties, and the related deferred revenue (in millions):

[0001193125-14-239169:notes:297]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 205.8 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (193.1 | ) |  |  | (168.6 | ) |
| Net amount |  | $ | 12.7 |  |  | $ | 13.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-239169:notes:298]
13. Income
 Taxes

[0001193125-14-239169:notes:299]
Income before
 income taxes is as follows (in millions):

[0001193125-14-239169:notes:300]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Domestic |  | $ | 120.5 |  |  | $ | (63.8 | ) |  | $ | 211.9 |  |
| Foreign |  |  | 620.2 |  |  |  | 630.4 |  |  |  | 500.5 |  |
| Total |  | $ | 740.7 |  |  | $ | 566.6 |  |  | $ | 712.4 |  |

[0001193125-14-239169:notes:301]
Domestic income
 before taxes is lower than foreign income before taxes due to
 significant domestic expenses related to the amortization of
 intangibles, stock based compensation and convertible debt
 interest.

[0001193125-14-239169:notes:302]
Current and
 non-current net deferred tax assets are as follows (in
 millions):

[0001193125-14-239169:notes:303]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Current deferred tax assets, net |  | $ | 269.3 |  |  | $ | 252.7 |  |
| Non-current deferred tax assets, net |  |  | 245.0 |  |  |  | 200.3 |  |

[0001193125-14-239169:notes:304]
The valuation
 allowance increased by $9.8 million and $7.4 million in fiscal
 2014 and 2013, respectively. The increases are mainly attributable
 to corresponding changes in deferred tax assets, primarily foreign
 tax credit carryforwards in a foreign jurisdiction and state tax
 credit carryforwards in certain states.

[0001193125-14-239169:notes:305]
As of
 April 25, 2014, the federal and state net operating loss
 carryforwards were approximately $28.8 million and $108.4
 million, respectively, before applying tax rates for the respective
 jurisdictions. The federal and state tax credit carryforwards were
 approximately $120.0 million and $138.7 million,
 respectively. Certain acquired net operating loss and credit
 carryforwards are subject to an annual limitation under Internal
 Revenue Code Section 382, but are expected to be realized with
 the exception of those which have a valuation allowance. The
 federal and state net operating loss carryforwards and credits will
 expire in various years from fiscal 2015 through 2034. If realized,
 $127.5 million, tax effected, of net operating loss and tax credit
 carryovers will be recognized as additional paid-in
 capital.

[0001193125-14-239169:notes:306]
Of the
 $235.9 million of unrecognized tax benefits at April 25,
 2014, $175.9 million has been recorded in other long-term
 liabilities. Unrecognized tax benefits of $140.8 million, including
 penalties and interest, would affect our provision for income taxes
 if recognized.

[0001193125-14-239169:notes:307]
We recognize
 accrued interest and penalties related to unrecognized tax benefits
 in the income tax provision. During fiscal 2014, 2013 and 2012, we
 recognized accrued interest and penalties of approximately $2.2
 million, $1.2 million and $0.6 million, respectively in the
 consolidated statements of operations and $5.0 million and $2.8
 million, respectively, were recorded on the consolidated balance
 sheets as of April 25, 2014 and April 26,
 2013.

[0001193125-14-239169:notes:308]
The tax years
 that remain subject to examination for our major tax jurisdictions
 are shown below:

[0001193125-14-239169:notes:309]
Fiscal
 Years Subject to Examination for Major Tax Jurisdictions at
 April 25, 2014

[0001193125-14-239169:notes:310]
| 2005 — 2014 |  | United States — federal income tax |
| 2005 — 2014 |  | United States — state and local income tax |
| 2009 — 2014 |  | Australia |
| 2010 — 2014 |  | Germany |
| 2006 — 2014 |  | India |
| 2007 — 2014 |  | Japan |
| 2010 — 2014 |  | The Netherlands |
| 2009 — 2014 |  | United Kingdom |
| 2008 — 2014 |  | Canada |

[0001193125-14-239169:notes:311]
In addition, we
 are effectively subject to federal tax examination adjustments for
 tax years ended on or after fiscal 2000, in that we have net
 operating loss carryforwards from these years that could be subject
 to adjustment upon utilization. During fiscal 2014, 2013 and 2012,
 we recorded income tax expense of $0.0 million, $0.1 million and
 $7.3 million, respectively, in connection with income tax
 audits.

[0001193125-14-239169:notes:312]
We are
 currently undergoing federal income tax audits in the United States
 and several foreign tax jurisdictions. Transfer pricing
 calculations are key issues under audits in various jurisdictions,
 and are often subject to dispute and appeals. Our fiscal 2005
 through 2007 income tax returns are currently under audit by the
 IRS. On May 19, 2014, we received a Revenue Agent’s
 Report (RAR) from the IRS field examination team for the audit
 period. The RAR is subject to further review and approval by
 certain higher authorities within the IRS before submission to the
 Joint Committee of Taxation for final review and approval. We
 expect to close our fiscal 2005 through 2007 income tax audit
 within the next twelve months. Our fiscal 2008 through fiscal 2010
 income tax returns are currently under audit by the IRS. We are
 currently in the process of responding to inquiries from the IRS
 examination team. We expect the IRS examination team to finish the
 field audit within the next twelve months. In January 2014, the
 California Franchise Tax Board temporarily closed the audit of our
 fiscal 2007 and 2008 income tax returns and will reopen the audit
 upon the conclusion of the applicable federal IRS
 audits.

[0001193125-14-239169:notes:313]
On
 September 17, 2010, the Danish Tax Authorities issued a
 decision concluding that distributions declared in 2005 and 2006
 from our Danish subsidiary were subject to Danish at-source
 dividend withholding tax. We do not believe that our Danish
 subsidiary is liable for withholding tax and filed an appeal with
 the Danish Tax Tribunal to that effect. On December 19, 2011,
 the Danish Tax Tribunal issued a ruling that our Danish subsidiary
 was not liable for Danish withholding tax. The Danish tax
 examination agency appealed to the Danish High Court in March
 2012.

[0001193125-14-239169:notes:314]
We believe that
 within the next 12 months, it is reasonably possible that either
 certain audits will conclude or statutes of limitations on certain
 income tax examination periods will expire, or both. Given the
 uncertainties involved in all tax audits, we can only determine a
 range of estimated potential increase in underlying unrecognized
 tax benefits ranging from $23.5 million to approximately $45.9
 million.

[0001193125-14-239169:notes:315]
In April 2010,
 our Dutch subsidiary received a favorable tax ruling from the Dutch
 tax authorities, effective May 1, 2010, that replaces the
 previous Dutch tax ruling that expired on April 30, 2010. This
 ruling results in both a lower level of earnings subject to tax in
 the Netherlands and an extension of the expiration date to
 April 30, 2015.

[0001193125-14-239169:notes:316]
As of
 April 25, 2014, the amount of accumulated unremitted earnings
 from our foreign subsidiaries is approximately $3.0 billion. We
 have not provided U.S. income taxes and foreign withholding taxes
 on the undistributed earnings of foreign subsidiaries because we
 intend to permanently reinvest such earnings outside the U.S. If
 these foreign earnings were to be repatriated in the future, the
 related U.S. tax liability may be reduced by any foreign income
 taxes previously paid on these earnings as well as tax attributes
 carryforwards. We estimate the unrecognized deferred tax liability
 related to these earnings to be $895.9 million as of April 25,
 2014.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-14-239169:notes:317]
6. Goodwill and
 Purchased Intangible Assets, Net

[0001193125-14-239169:notes:318]
We conducted
 our annual goodwill impairment test during the three months ended
 April 25, 2014. Based on this analysis, we determined that
 there was no impairment to goodwill. We will continue to monitor
 our recorded goodwill for indicators of impairment.

[0001193125-14-239169:notes:319]
Amortization
 expense for purchased intangible assets is summarized below (in
 millions):

[0001193125-14-239169:notes:320]
|  |  | Year Ended |  |  | Statements of Operations Classifications |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |  |
| Developed technology |  | $ | 57.1 |  |  | $ | 55.9 |  |  | $ | 55.8 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 1.0 |  |  |  | 25.2 |  |  |  | 28.1 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.5 |  |  |  | 4.0 |  |  |  | 4.2 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.5 |  |  |  | 0.7 |  |  |  | 0.9 |  |  | Operating expenses |
|  |  | $ | 59.1 |  |  | $ | 85.8 |  |  | $ | 89.0 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-239169:notes:321]
15. Segment,
 Geographic, and Significant Customer Information

[0001193125-14-239169:notes:322]
We operate in
 one industry segment: the design, manufacturing, marketing, and
 technical support of high-performance networked storage solutions.
 We conduct business globally, and our sales and support activities
 are managed on a geographic basis. Our management reviews financial
 information presented on a consolidated basis, accompanied by
 disaggregated information it receives from its internal management
 system about revenues by geographic region, based on the location
 from which the customer relationship is managed, for purposes of
 allocating resources and evaluating financial performance. We do
 not allocate costs of revenues, research and development, sales and
 marketing, or general and administrative expenses to our geographic
 regions in this internal management reporting because management
 does not review operations or operating results, or make planning
 decisions, below the consolidated entity level.

[0001193125-14-239169:notes:323]
Americas
 revenues consist of sales to Americas commercial and U.S. public
 sector markets. Sales to customers inside the United States
 comprised $3,130.9 million, $3,152.7 million and $3,027.8 million
 of Americas net revenues during fiscal 2014, 2013 and 2012,
 respectively. Sales to Germany accounted for $632.6 million during
 fiscal 2012. No other foreign country accounted for 10% or more of
 our net revenues in an individual fiscal year.

[0001193125-14-239169:notes:324]
The majority of
 our assets, excluding cash, cash equivalents, restricted cash,
 investments and accounts receivable, were attributable to our
 domestic operations. The following table presents cash, cash
 equivalents, restricted cash and investments held in the United
 States and internationally in various foreign subsidiaries (in
 millions):

[0001193125-14-239169:notes:325]
With the
 exception of property and equipment, we do not identify or allocate
 our long-lived assets by geographic area. The following table
 presents property and equipment information for geographic areas
 based on the physical location of the assets (in
 millions):


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-239169:notes:326]
17. Commitments and
 Contingencies

[0001193125-14-239169:notes:327]
Operating
 Leases — We lease various equipment, vehicles and
 office space in the U.S. and internationally.

[0001193125-14-239169:notes:328]
Rent expense
 under all non-cancelable operating leases was $65.5 million, $64.9
 million and $88.2 million in fiscal 2014, 2013 and 2012,
 respectively.

[0001193125-14-239169:notes:329]
Purchase
 Orders and Other Commitments

[0001193125-14-239169:notes:330]
In the ordinary
 course of business, we make commitments to third-party contract
 manufacturers, to manage manufacturer lead times and meet product
 forecasts, and to other parties, to purchase various key components
 used in the manufacture of our products. We establish accruals for
 estimated losses on purchased components to the extent we believe
 it is probable that such components will not be utilized in future
 operations. To the extent that such forecasts are not achieved, our
 commitments and associated accruals may change. As of
 April 25, 2014, we had $258.4 million in non-cancelable
 purchase commitments with our contract manufacturers. In addition,
 we recorded a liability for firm, non-cancelable and unconditional
 purchase commitments with contract manufacturers for quantities in
 excess of our future demand forecasts through a charge to cost of
 product revenues. As of April 25, 2014 and April 26,
 2013, such liability amounted to $11.5 million and $9.5 million,
 respectively, and is included in other current liabilities in our
 consolidated balance sheets.

[0001193125-14-239169:notes:331]
In addition to
 commitments with contract manufacturers and component suppliers, we
 have open purchase orders and contractual obligations associated
 with our ordinary course of business for which we have not received
 goods or services. As of April 25, 2014, we had $31.1 million
 in capital purchase commitments and $174.1 million in other
 purchase commitments.

[0001193125-14-239169:notes:332]
During the
 ordinary course of business, we provide standby letters of credit
 or other guarantee instruments to third parties as required for
 certain transactions initiated either by us or our subsidiaries. As
 of April 25, 2014, our financial guarantees of
 $12.6 million that were not recorded on our consolidated
 balance sheets consisted primarily of standby letters of credit and
 surety bonds.

[0001193125-14-239169:notes:333]
Product
 Warranties

[0001193125-14-239169:notes:334]
We generally
 provide customers a warranty on software of ninety days and a
 warranty on hardware of three years. The following table summarizes
 the activity related to product warranty liabilities for fiscal
 2014 and 2013 (in millions):

[0001193125-14-239169:notes:335]
Product
 warranty liabilities were reported in our consolidated balance
 sheets as follows (in millions):

[0001193125-14-239169:notes:336]
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 73.0 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.0 |  |  |  | 35.6 |  |
| Total |  | $ | 110.0 |  |  | $ | 117.2 |  |

[0001193125-14-239169:notes:337]
Financing
 Guarantees

[0001193125-14-239169:notes:338]
Some of our
 customers have entered into recourse and non-recourse financing
 leasing arrangements using third-party financing companies, and in
 some situations, we enter into customer financing arrangements for
 our products and services that are contemporaneously sold on a
 recourse or non-recourse basis to third-party financing companies.
 Under the terms of recourse leases, which are generally three years
 or less, we remain liable for the aggregate unpaid remaining lease
 payments to the third-party leasing companies in the event of
 end-user customer default. These arrangements are generally
 collateralized by a security interest in the underlying assets.
 Under the terms of the non-recourse leases, we do not have any
 continuing obligations or liabilities to the third-party financing
 companies. Where we provide a guarantee for recourse leases, we
 defer revenues subject to the industry-specific software revenue
 recognition guidance, and recognize revenues for non-software
 deliverables in accordance with our multiple deliverable revenue
 arrangement policy. In connection with certain recourse financing
 arrangements, we receive advance payments associated with
 undelivered elements that are subject to customer refund rights. We
 defer revenue associated with these advance payments until the
 related refund rights expire and we perform the
 services.

[0001193125-14-239169:notes:339]
To date, we
 have not experienced material losses under our lease financing
 programs or other financing arrangements.

[0001193125-14-239169:notes:340]
Indemnification Agreements

[0001193125-14-239169:notes:341]
We enter into
 standard indemnification agreements in the ordinary course of
 business. Pursuant to these agreements, we agree to defend and
 indemnify other parties, primarily our customers or business
 partners or subcontractors, for damages and reasonable costs
 incurred in any suit or claim brought against them alleging that
 our products sold to them infringe any U.S. patent, copyright,
 trade secret, or similar right. If a product becomes the subject of
 an infringement claim, we may, at our option: (i) replace the
 product with another non-infringing product that provides
 substantially similar performance; (ii) modify the infringing
 product so that it no longer infringes but remains functionally
 equivalent; (iii) obtain the right for the customer to
 continue using the product at our expense and for the reseller to
 continue selling the product; (iv) take back the infringing
 product and refund to the customer the purchase price paid less
 depreciation amortized on a straight-line basis. We have not been
 required to make material payments pursuant to these provisions
 historically. We have not recorded any liability at April 25,
 2014 related to these guarantees since the maximum amount of
 potential future payments under such guarantees, indemnities and
 warranties is not determinable, other than as described
 above.

[0001193125-14-239169:notes:342]
Legal
 Contingencies

[0001193125-14-239169:notes:343]
When a loss is
 considered probable and reasonably estimable, we record a liability
 in the amount of our best estimate for the ultimate loss. However,
 the likelihood of a loss with respect to a particular contingency
 is often difficult to predict and determining a meaningful estimate
 of the loss or a range of loss may not be practicable based on the
 information available and the potential effect of future events and
 decisions by third parties that will determine the ultimate
 resolution of the contingency.

[0001193125-14-239169:notes:344]
We are subject
 to various legal proceedings and claims that arise in the normal
 course of business. No accrual has been recorded as of
 April 25, 2014 related to such matters as they are not
 probable and/or reasonably estimable.
