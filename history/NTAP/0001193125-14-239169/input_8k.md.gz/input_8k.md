# NTAP 8-K — 0001102624-14-000858 filed 2014-05-21

## item codes, every 8-K on or before 2014-06-17

- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2014-06-17

- none on or before 2014-06-17

## item 2.02 — earnings release, exhibit 99.1

[0001102624-14-000858:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-14-000858:8k_2_02:2]
exh99_1.htm

[0001102624-14-000858:8k_2_02:3]
Exhibit 99.1

[0001102624-14-000858:8k_2_02:4]
|  | Press Contact: | Investor Contact: |  |
|  | Jeremiah Glodoveza | Kris Newton |  |
|  | NetApp | NetApp |  |
|  | 408-822-4567 | 408-822-3312 |  |
|  | Jeremiah.Glodoveza@netapp.com | Kris.Newton@netapp.com |  |

[0001102624-14-000858:8k_2_02:5]
NETAPP REPORTS FOURTH QUARTER AND FISCAL YEAR 2014 RESULTS

[0001102624-14-000858:8k_2_02:6]
Achieves Fourth Quarter and Full Fiscal Year Non-GAAP Earnings per Share Growth of 22% Year over Year

[0001102624-14-000858:8k_2_02:7]
| · | Net revenues for Q4 of $1.649 billion; $6.325 billion for fiscal year 2014 |

[0001102624-14-000858:8k_2_02:8]
| · | Branded revenue for fiscal year 2014 grew 4% year over year |

[0001102624-14-000858:8k_2_02:9]
| · | Cash from operations for fiscal year 2014 of $1.350 billion; free cash flow 18% of revenue |

[0001102624-14-000858:8k_2_02:10]
Sunnyvale, CA—May 21, 2014—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2014, ended April 25, 2014.

[0001102624-14-000858:8k_2_02:11]
Fourth Quarter Financial Results

[0001102624-14-000858:8k_2_02:12]
Net revenues for the fourth quarter of fiscal year 2014 were $1.649 billion. GAAP net income for the fourth quarter of fiscal year 2014 was $197 million, or $0.59 per share,1 compared to GAAP net income of $174 million, or $0.47 per share, for the comparable period of the prior year. Non-GAAP net income for the fourth quarter of fiscal year 2014 was $284 million, or $0.84 per share,2 compared to non-GAAP net income of $253 million, or $0.69 per share, for the comparable period of the prior year.

[0001102624-14-000858:8k_2_02:13]
Fiscal Year 2014 Financial Results

[0001102624-14-000858:8k_2_02:14]
Net revenues for fiscal year 2014 were $6.325 billion. GAAP net income for fiscal year 2014 was $638 million, or $1.83 per share,1 compared to GAAP net income of $505 million, or $1.37 per share, for the comparable period of the prior year. Non-GAAP net income for fiscal year 2014 was $968 million, or $2.78 per share,2 compared to non-GAAP net income of $841 million, or $2.28 per share, for the comparable period of the prior year.

[0001102624-14-000858:8k_2_02:15]
Cash, Cash Equivalents, and Investments

[0001102624-14-000858:8k_2_02:16]
NetApp ended fiscal year 2014 with $5.003 billion of total cash, cash equivalents, and investments and generated $1.350 billion in cash from operations. During fiscal year 2014, the Company returned $2.084 billion to shareholders through share repurchases and cash dividends.

[0001102624-14-000858:8k_2_02:17]
The Company increased the next dividend to $0.165 per share to be paid on July 22, 2014 to shareholders of record as of the close of business on July 10, 2014.

[0001102624-14-000858:8k_2_02:18]
“NetApp saw market share gains and delivered a solid operational performance in fiscal year 2014, highlighted by margin expansion and strong cash generation,” said Tom Georgens, Chairman and CEO. “With solutions like clustered Data ONTAP, our broad flash portfolio and differentiated approach to the cloud, customers are solving the challenges of today, with innovative solutions that pave the way for the future.”

[0001102624-14-000858:8k_2_02:19]
Q1 Fiscal Year 2015 Outlook

[0001102624-14-000858:8k_2_02:20]
The Company provides the following financial guidance for the first quarter of fiscal year 2015:

[0001102624-14-000858:8k_2_02:21]
| · | Net revenues are expected to be in the range of $1.420 billion to $1.520 billion |

[0001102624-14-000858:8k_2_02:22]
| · | GAAP earnings per share is expected to be in the range of $0.32 to $0.37 per share |

[0001102624-14-000858:8k_2_02:23]
| · | Non-GAAP earnings per share is expected to be in the range of $0.53 to $0.58 per share |

[0001102624-14-000858:8k_2_02:24]
Business Highlights

[0001102624-14-000858:8k_2_02:25]
In its fourth quarter of fiscal year 2014, NetApp continued to help global enterprises achieve success with one of the industry’s broadest portfolios of flash-accelerated, cloud-integrated storage and data management solutions. Its industry-leading enterprise storage systems and software meet customer needs across a wide range of application workloads. Highlights include:

[0001102624-14-000858:8k_2_02:26]
|  | · | NetApp Introduces Unified Scale-Out Storage Systems for the Hybrid Cloud Era. The new FAS8000 series unified storage systems are NetApp’s most powerful and feature-rich scale-out storage systems with superior flexibility to simplify complex upgrades as IT needs change. |

[0001102624-14-000858:8k_2_02:27]
|  | · | NetApp Introduces FlexArray Virtualization Software. With new FlexArray virtualization software, NetApp® V-Series becomes a software option that can be licensed on the FAS8000 to virtualize and manage multivendor data storage platforms, paving the way for software-defined storage. |

[0001102624-14-000858:8k_2_02:28]
|  | · | NetApp Announces the Latest Release of Clustered Data ONTAP®. The latest release of the clustered Data ONTAP operating system, version 8.2.1, helps organizations seamlessly scale out operations and manage data consistently, without disruption across both private and public cloud environments. |

[0001102624-14-000858:8k_2_02:29]
|  | · | NetApp Teams with SAP to Set New Record for World's Largest Data Warehouse. SAP announced that it teamed with partners, including NetApp, to generate a world record for the largest data warehouse. The NetApp E5460 storage system was chosen for its ability to handle large data volumes, enormous throughput requirements, consistent high performance and availability demands, all at the same time. |

[0001102624-14-000858:8k_2_02:30]
|  | · | NetApp Again Honored as a Channel Champion. CRN’s 24th annual Channel Champions awards highlights vendor partners voted to be the best-of-the-best by the solutions providers for 2014. NetApp moved into the No. 2 position on this year's list in the Enterprise Network Storage category. |

[0001102624-14-000858:8k_2_02:31]
Webcast and Conference Call Information

[0001102624-14-000858:8k_2_02:32]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:00 p.m. Pacific Time today.

[0001102624-14-000858:8k_2_02:33]
Historical supplemental data tables, providing historical multi-period financial information, are also available on our Investor Relations website at investors.netapp.com.

[0001102624-14-000858:8k_2_02:34]
About NetApp

[0001102624-14-000858:8k_2_02:35]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-14-000858:8k_2_02:36]
8

[0001102624-14-000858:8k_2_02:37]
###

[0001102624-14-000858:8k_2_02:38]
NetApp, the NetApp logo, Go further, faster, and Data ONTAP are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-14-000858:8k_2_02:39]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-14-000858:8k_2_02:40]
2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-14-000858:8k_2_02:41]
9

[0001102624-14-000858:8k_2_02:42]
NetApp Usage of Non-GAAP Financials

[0001102624-14-000858:8k_2_02:43]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide both non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-14-000858:8k_2_02:44]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-14-000858:8k_2_02:45]
10

[0001102624-14-000858:8k_2_02:46]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,003.3 |  |  | $ | 6,952.6 |  |
| Accounts receivable, net |  |  | 855.9 |  |  |  | 800.9 |  |
| Inventories |  |  | 122.4 |  |  |  | 139.5 |  |
| Other current assets |  |  | 489.7 |  |  |  | 525.2 |  |
| Total current assets |  |  | 6,471.3 |  |  |  | 8,418.2 |  |
| Property and equipment, net |  |  | 1,108.8 |  |  |  | 1,170.9 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,109.6 |  |  |  | 1,168.7 |  |
| Other non-current assets |  |  | 529.5 |  |  |  | 484.6 |  |
| Total assets |  | $ | 9,219.2 |  |  | $ | 11,242.4 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 247.0 |  |  | $ | 259.7 |  |
| Accrued compensation and other current liabilities |  |  | 793.8 |  |  |  | 749.8 |  |
| Current portion of long-term debt |  |  | - |  |  |  | 1,257.8 |  |
| Short-term deferred revenue |  |  | 1,653.8 |  |  |  | 1,563.3 |  |
| Total current liabilities |  |  | 2,694.6 |  |  |  | 3,830.6 |  |
| Long-term debt |  |  | 995.5 |  |  |  | 994.6 |  |
| Other long-term liabilities |  |  | 296.2 |  |  |  | 253.5 |  |
| Long-term deferred revenue |  |  | 1,446.4 |  |  |  | 1,446.2 |  |
| Total liabilities |  |  | 5,432.7 |  |  |  | 6,524.9 |  |
| Stockholders' equity |  |  | 3,786.5 |  |  |  | 4,717.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,219.2 |  |  | $ | 11,242.4 |  |

[0001102624-14-000858:8k_2_02:47]
11

[0001102624-14-000858:8k_2_02:48]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,042.8 |  |  | $ | 1,137.8 |  |  | $ | 3,943.9 |  |  | $ | 4,092.3 |  |
| Software entitlements and maintenance |  |  | 227.5 |  |  |  | 227.0 |  |  |  | 914.8 |  |  |  | 893.5 |  |
| Service |  |  | 378.7 |  |  |  | 351.7 |  |  |  | 1,466.4 |  |  |  | 1,346.6 |  |
| Net revenues |  |  | 1,649.0 |  |  |  | 1,716.5 |  |  |  | 6,325.1 |  |  |  | 6,332.4 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 453.2 |  |  |  | 517.9 |  |  |  | 1,777.1 |  |  |  | 1,959.9 |  |
| Cost of software entitlements and maintenance |  |  | 8.0 |  |  |  | 7.4 |  |  |  | 30.7 |  |  |  | 28.3 |  |
| Cost of service |  |  | 145.8 |  |  |  | 159.0 |  |  |  | 598.2 |  |  |  | 583.1 |  |
| Total cost of revenues |  |  | 607.0 |  |  |  | 684.3 |  |  |  | 2,406.0 |  |  |  | 2,571.3 |  |
| Gross profit |  |  | 1,042.0 |  |  |  | 1,032.2 |  |  |  | 3,919.1 |  |  |  | 3,761.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 475.0 |  |  |  | 510.2 |  |  |  | 1,898.2 |  |  |  | 1,974.8 |  |
| Research and development |  |  | 230.7 |  |  |  | 243.4 |  |  |  | 917.3 |  |  |  | 904.2 |  |
| General and administrative |  |  | 73.7 |  |  |  | 74.2 |  |  |  | 281.0 |  |  |  | 272.6 |  |
| Restructuring and other charges |  |  | 38.8 |  |  |  | - |  |  |  | 88.3 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Total operating expenses |  |  | 818.2 |  |  |  | 827.8 |  |  |  | 3,184.8 |  |  |  | 3,153.3 |  |
| Income from operations |  |  | 223.8 |  |  |  | 204.4 |  |  |  | 734.3 |  |  |  | 607.8 |  |
| Other income/(expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.5 |  |  |  | 10.1 |  |  |  | 34.9 |  |  |  | 42.2 |  |
| Interest expense |  |  | (6.4 | ) |  |  | (28.0 | ) |  |  | (36.1 | ) |  |  | (91.7 | ) |
| Other income, net |  |  | 0.7 |  |  |  | 2.4 |  |  |  | 7.6 |  |  |  | 8.3 |  |
| Total other income/(expense), net |  |  | 2.8 |  |  |  | (15.5 | ) |  |  | 6.4 |  |  |  | (41.2 | ) |
| Income before income taxes |  |  | 226.6 |  |  |  | 188.9 |  |  |  | 740.7 |  |  |  | 566.6 |  |
| Provision for income taxes |  |  | 29.6 |  |  |  | 15.1 |  |  |  | 103.2 |  |  |  | 61.3 |  |
| Net income |  | $ | 197.0 |  |  | $ | 173.8 |  |  | $ | 637.5 |  |  | $ | 505.3 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.60 |  |  | $ | 0.48 |  |  | $ | 1.87 |  |  | $ | 1.40 |  |
| Diluted |  | $ | 0.59 |  |  | $ | 0.47 |  |  | $ | 1.83 |  |  | $ | 1.37 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 330.2 |  |  |  | 358.6 |  |  |  | 340.3 |  |  |  | 361.5 |  |
| Diluted |  |  | 336.4 |  |  |  | 368.2 |  |  |  | 347.9 |  |  |  | 368.0 |  |
| Cash dividends declared per share |  | $ | 0.15 |  |  | $ | - |  |  | $ | 0.60 |  |  | $ | - |  |

[0001102624-14-000858:8k_2_02:49]
12

[0001102624-14-000858:8k_2_02:50]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 197.0 |  |  | $ | 173.8 |  |  | $ | 637.5 |  |  | $ | 505.3 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 82.1 |  |  |  | 89.1 |  |  |  | 334.1 |  |  |  | 344.6 |  |
| Stock-based compensation |  |  | 67.2 |  |  |  | 65.1 |  |  |  | 273.0 |  |  |  | 276.6 |  |
| Accretion of discount and issuance costs on debt |  |  | 0.5 |  |  |  | 16.2 |  |  |  | 9.7 |  |  |  | 60.2 |  |
| Excess tax benefit from stock-based compensation |  |  | (19.1 | ) |  |  | (19.9 | ) |  |  | (52.5 | ) |  |  | (72.9 | ) |
| Other, net |  |  | (26.8 | ) |  |  | 2.3 |  |  |  | (58.4 | ) |  |  | (6.0 | ) |
| Changes in assets and liabilities, net of acquired businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (270.0 | ) |  |  | (170.0 | ) |  |  | (56.6 | ) |  |  | 23.1 |  |
| Inventories |  |  | (4.3 | ) |  |  | 33.4 |  |  |  | 17.0 |  |  |  | 22.0 |  |
| Accounts payable |  |  | 57.7 |  |  |  | 41.1 |  |  |  | (12.1 | ) |  |  | 25.1 |  |
| Accrued compensation and other current liabilities |  |  | 126.8 |  |  |  | 88.6 |  |  |  | 32.3 |  |  |  | 53.5 |  |
| Deferred revenue |  |  | 133.6 |  |  |  | 135.4 |  |  |  | 106.6 |  |  |  | 198.1 |  |
| Changes in other operating assets and liabilities, net |  |  | 24.8 |  |  |  | 0.5 |  |  |  | 119.0 |  |  |  | (43.3 | ) |
| Net cash provided by operating activities |  |  | 369.5 |  |  |  | 455.6 |  |  |  | 1,349.6 |  |  |  | 1,386.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 212.3 |  |  |  | (27.1 | ) |  |  | 975.0 |  |  |  | 177.0 |  |
| Purchases of property and equipment |  |  | (56.0 | ) |  |  | (63.6 | ) |  |  | (221.4 | ) |  |  | (303.3 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | - |  |  |  | (17.1 | ) |  |  | - |  |  |  | (106.5 | ) |
| Other investing activities, net |  |  | 4.2 |  |  |  | 1.2 |  |  |  | 6.8 |  |  |  | 4.2 |  |
| Net cash provided by (used in) investing activities |  |  | 160.5 |  |  |  | (106.6 | ) |  |  | 760.4 |  |  |  | (228.6 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 9.6 |  |  |  | 15.1 |  |  |  | 201.4 |  |  |  | 110.6 |  |
| Repurchase of common stock and forward contract |  |  | (374.5 | ) |  |  | (180.0 | ) |  |  | (1,881.5 | ) |  |  | (590.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 19.1 |  |  |  | 19.9 |  |  |  | 52.5 |  |  |  | 72.9 |  |
| Repayment of debt |  |  | - |  |  |  | - |  |  |  | (1,264.9 | ) |  |  | - |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 987.3 |  |
| Dividends paid |  |  | (49.2 | ) |  |  | - |  |  |  | (202.3 | ) |  |  | - |  |
| Other financing activities, net |  |  | (1.7 | ) |  |  | (1.2 | ) |  |  | (9.2 | ) |  |  | (1.9 | ) |
| Net cash provided by (used in) financing activities |  |  | (396.7 | ) |  |  | (146.2 | ) |  |  | (3,104.0 | ) |  |  | 578.9 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 5.0 |  |  |  | (7.4 | ) |  |  | 7.9 |  |  |  | (9.3 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 138.3 |  |  |  | 195.4 |  |  |  | (986.1 | ) |  |  | 1,727.3 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,152.7 |  |  |  | 3,081.7 |  |  |  | 3,277.1 |  |  |  | 1,549.8 |  |
| End of period |  | $ | 2,291.0 |  |  | $ | 3,277.1 |  |  | $ | 2,291.0 |  |  | $ | 3,277.1 |  |

[0001102624-14-000858:8k_2_02:51]
13

[0001102624-14-000858:8k_2_02:52]
| NETAPP, INC. |
| SUPPLEMENTAL DATA |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |
| (Unaudited) |

[0001102624-14-000858:8k_2_02:53]
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  | FY 2014 |  |  | FY 2013 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 1,042.8 |  |  | $ | 1,015.0 |  |  | $ | 1,137.8 |  |  | $ | 3,943.9 |  |  | $ | 4,092.3 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 227.5 |  |  |  | 227.0 |  |  |  | 227.0 |  |  |  | 914.8 |  |  |  | 893.5 |  |
| Service Revenue: |  |  | 378.7 |  |  |  | 368.0 |  |  |  | 351.7 |  |  |  | 1,466.4 |  |  |  | 1,346.6 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 293.7 |  |  |  | 285.9 |  |  |  | 262.9 |  |  |  | 1,129.6 |  |  |  | 991.8 |  |
| Professional & Other Services Revenue |  |  | 85.0 |  |  |  | 82.1 |  |  |  | 88.8 |  |  |  | 336.7 |  |  |  | 354.8 |  |
| Net Revenues |  | $ | 1,649.0 |  |  | $ | 1,610.0 |  |  | $ | 1,716.5 |  |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  | FY 2014 |  |  | FY 2013 |  |
| Branded Revenue |  | $ | 1,539.2 |  |  | $ | 1,452.7 |  |  | $ | 1,551.0 |  |  | $ | 5,740.4 |  |  | $ | 5,545.2 |  |
| OEM Revenue |  |  | 109.8 |  |  |  | 157.3 |  |  |  | 165.5 |  |  |  | 584.7 |  |  |  | 787.2 |  |
| Net Revenues |  | $ | 1,649.0 |  |  | $ | 1,610.0 |  |  | $ | 1,716.5 |  |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'14 Revenue |  |  | % of Q3 FY’14 Revenue |  |  | % of Q4 FY’13 Revenue |  |  | % of FY 2014 Revenue |  |  | % of FY 2013 Revenue |  |
| Americas* |  |  | 56 | % |  |  | 52 | % |  |  | 57 | % |  |  | 56 | % |  |  | 56 | % |
| Americas Commercial |  |  | 43 | % |  |  | 43 | % |  |  | 45 | % |  |  | 43 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 9 | % |  |  | 12 | % |  |  | 12 | % |  |  | 13 | % |
| EMEA |  |  | 31 | % |  |  | 34 | % |  |  | 30 | % |  |  | 31 | % |  |  | 30 | % |
| Asia Pacific |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |
| * Americas Commercial and USPS revenue for Q4 FY'13 is recast as a result of reporting certain healthcare revenue in Americas Commercial revenue that was previously included in U.S. Public Sector revenue. A reconciliation of this change is posted to our website at investors.netapp.com. |
| Pathways Mix |  |  |  |  |  |
|  |  | % of Q4 FY'14 Revenue |  |  | % of Q3 FY’14 Revenue |  |  | % of Q4 FY’13 Revenue |  |  | % of FY 2014 Revenue |  |  | % of FY 2013 Revenue |  |
| Direct |  |  | 17 | % |  |  | 17 | % |  |  | 19 | % |  |  | 18 | % |  |  | 19 | % |
| Indirect |  |  | 83 | % |  |  | 83 | % |  |  | 81 | % |  |  | 82 | % |  |  | 81 | % |
| Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. |
| Direct revenues are those sold through our direct sales force. Direct / Indirect revenue mix reflects order fulfillment and not reflective of who is responsible for the customer relationship. |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  | FY 2014 |  |  | FY 2013 |  |
| Non-GAAP Gross Margin |  |  | 64.4 | % |  |  | 63.5 | % |  |  | 61.3 | % |  |  | 63.2 | % |  |  | 60.7 | % |
| Product |  |  | 58.0 | % |  |  | 57.1 | % |  |  | 55.8 | % |  |  | 56.5 | % |  |  | 53.6 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 96.5 | % |  |  | 96.6 | % |  |  | 96.7 | % |  |  | 96.6 | % |  |  | 96.8 | % |
| Service |  |  | 62.7 | % |  |  | 60.8 | % |  |  | 56.2 | % |  |  | 60.5 | % |  |  | 58.2 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  | FY 2014 |  |  | FY 2013 |  |
| Non-GAAP Income from Operations |  | $ | 344.4 |  |  | $ | 313.3 |  |  | $ | 291.0 |  |  | $ | 1,154.7 |  |  | $ | 971.9 |  |
| % of Net Revenue |  |  | 20.9 | % |  |  | 19.5 | % |  |  | 17.0 | % |  |  | 18.3 | % |  |  | 15.3 | % |
| Non-GAAP Income before Income Taxes |  | $ | 347.2 |  |  | $ | 316.2 |  |  | $ | 291.7 |  |  | $ | 1,169.3 |  |  | $ | 990.2 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.1 | % |  |  | 17.6 | % |  |  | 13.4 | % |  |  | 17.2 | % |  |  | 15.1 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  | FY 2014 |  |  | FY 2013 |  |
| Non-GAAP Net Income |  | $ | 284.2 |  |  | $ | 260.6 |  |  | $ | 252.5 |  |  | $ | 968.2 |  |  | $ | 840.6 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 336.4 |  |  |  | 346.2 |  |  |  | 368.2 |  |  |  | 347.9 |  |  |  | 368.0 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.84 |  |  | $ | 0.75 |  |  | $ | 0.69 |  |  | $ | 2.78 |  |  | $ | 2.28 |  |
| Included in the diluted weighted average common shares outstanding are 3.2 million, 1.4 million and 1.1 million shares in Q4 FY'13, FY2014, FY2013, respectively, related to the impact of our convertible notes. The convertible notes matured in Q1 FY'14, and thus had no impact on any other period presented. |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue |  | $ | 3,100.2 |  |  | $ | 2,959.3 |  |  | $ | 3,009.5 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 47 |  |  |  | 33 |  |  |  | 42 |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 19 |  |  |  | 20 |  |  |  | 19 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable, net divided by net revenue, multiplied by the number of days in the quarter. |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY’14 |  |  | Q3 FY’14 |  |  | Q4 FY’13 |  |  | FY 2014 |  |  | FY 2013 |  |
| Net Cash Provided by Operating Activities |  | $ | 369.5 |  |  | $ | 331.8 |  |  | $ | 455.6 |  |  | $ | 1,349.6 |  |  | $ | 1,386.3 |  |
| Purchases of Property and Equipment |  | $ | 56.0 |  |  | $ | 57.9 |  |  | $ | 63.6 |  |  | $ | 221.4 |  |  | $ | 303.3 |  |
| Free Cash Flow |  | $ | 313.5 |  |  | $ | 273.9 |  |  | $ | 392.0 |  |  | $ | 1,128.2 |  |  | $ | 1,083.0 |  |
| Free Cash Flow as % of Total Revenue |  |  | 19.0 | % |  |  | 17.0 | % |  |  | 22.8 | % |  |  | 17.8 | % |  |  | 17.1 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |
| Some items may not add or recalculate due to rounding. |

[0001102624-14-000858:8k_2_02:54]
14

[0001102624-14-000858:8k_2_02:55]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| FINANCIAL STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | January 24, 2014 |  |  | April 26, 2013 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| NET INCOME |  | $ | 197.0 |  |  | $ | 192.1 |  |  | $ | 173.8 |  |  | $ | 637.5 |  |  | $ | 505.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.6 |  |  |  | 14.7 |  |  |  | 21.5 |  |  |  | 59.1 |  |  |  | 85.8 |  |
| Stock-based compensation |  |  | 67.2 |  |  |  | 71.9 |  |  |  | 65.1 |  |  |  | 273.0 |  |  |  | 276.6 |  |
| Restructuring and other charges |  |  | 38.8 |  |  |  | - |  |  |  | - |  |  |  | 88.3 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 16.2 |  |  |  | 8.2 |  |  |  | 60.2 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| Income tax effect of Non-GAAP adjustments |  |  | (33.4 | ) |  |  | (18.1 | ) |  |  | (24.1 | ) |  |  | (97.9 | ) |  |  | (88.3 | ) |
| NON-GAAP NET INCOME |  | $ | 284.2 |  |  | $ | 260.6 |  |  | $ | 252.5 |  |  | $ | 968.2 |  |  | $ | 840.6 |  |
| COST OF REVENUES |  | $ | 607.0 |  |  | $ | 607.7 |  |  | $ | 684.3 |  |  | $ | 2,406.0 |  |  | $ | 2,571.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.3 | ) |  |  | (14.2 | ) |  |  | (14.1 | ) |  |  | (57.1 | ) |  |  | (55.9 | ) |
| Stock-based compensation |  |  | (5.3 | ) |  |  | (6.1 | ) |  |  | (5.8 | ) |  |  | (22.3 | ) |  |  | (25.5 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 587.4 |  |  | $ | 587.4 |  |  | $ | 664.4 |  |  | $ | 2,326.6 |  |  | $ | 2,489.9 |  |
| COST OF PRODUCT REVENUES |  | $ | 453.2 |  |  | $ | 450.7 |  |  | $ | 517.9 |  |  | $ | 1,777.1 |  |  | $ | 1,959.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.7 | ) |  |  | (13.6 | ) |  |  | (13.5 | ) |  |  | (54.8 | ) |  |  | (55.3 | ) |
| Stock-based compensation |  |  | (1.4 | ) |  |  | (1.5 | ) |  |  | (1.4 | ) |  |  | (5.6 | ) |  |  | (6.1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 438.1 |  |  | $ | 435.6 |  |  | $ | 503.0 |  |  | $ | 1,716.7 |  |  | $ | 1,898.5 |  |
| COST OF SERVICE REVENUES |  | $ | 145.8 |  |  | $ | 149.3 |  |  | $ | 159.0 |  |  | $ | 598.2 |  |  | $ | 583.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (4.4 | ) |  |  | (2.3 | ) |  |  | (19.4 | ) |
| Stock-based compensation |  |  | (3.9 | ) |  |  | (4.6 | ) |  |  | (0.6 | ) |  |  | (16.7 | ) |  |  | (0.6 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 141.3 |  |  | $ | 144.1 |  |  | $ | 154.0 |  |  | $ | 579.2 |  |  | $ | 563.1 |  |
| GROSS PROFIT |  | $ | 1,042.0 |  |  | $ | 1,002.3 |  |  | $ | 1,032.2 |  |  | $ | 3,919.1 |  |  | $ | 3,761.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.3 |  |  |  | 14.2 |  |  |  | 14.1 |  |  |  | 57.1 |  |  |  | 55.9 |  |
| Stock-based compensation |  |  | 5.3 |  |  |  | 6.1 |  |  |  | 5.8 |  |  |  | 22.3 |  |  |  | 25.5 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,061.6 |  |  | $ | 1,022.6 |  |  | $ | 1,052.1 |  |  | $ | 3,998.5 |  |  | $ | 3,842.5 |  |
| SALES AND MARKETING EXPENSES |  | $ | 475.0 |  |  | $ | 475.9 |  |  | $ | 510.2 |  |  | $ | 1,898.2 |  |  | $ | 1,974.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.5 | ) |  |  | (7.4 | ) |  |  | (2.0 | ) |  |  | (29.8 | ) |
| Stock-based compensation |  |  | (30.4 | ) |  |  | (33.0 | ) |  |  | (30.4 | ) |  |  | (125.0 | ) |  |  | (132.2 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 444.3 |  |  | $ | 442.4 |  |  | $ | 472.4 |  |  | $ | 1,771.2 |  |  | $ | 1,812.8 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 230.7 |  |  | $ | 230.3 |  |  | $ | 243.4 |  |  | $ | 917.3 |  |  | $ | 904.2 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.1 | ) |
| Stock-based compensation |  |  | (21.1 | ) |  |  | (23.6 | ) |  |  | (20.3 | ) |  |  | (87.7 | ) |  |  | (84.1 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 209.6 |  |  | $ | 206.7 |  |  | $ | 223.1 |  |  | $ | 829.6 |  |  | $ | 820.0 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 73.7 |  |  | $ | 69.4 |  |  | $ | 74.2 |  |  | $ | 281.0 |  |  | $ | 272.6 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10.4 | ) |  |  | (9.2 | ) |  |  | (8.6 | ) |  |  | (38.0 | ) |  |  | (34.8 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 63.3 |  |  | $ | 60.2 |  |  | $ | 65.6 |  |  | $ | 243.0 |  |  | $ | 237.8 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | 38.8 |  |  | $ | - |  |  | $ | - |  |  | $ | 88.3 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (38.8 | ) |  |  | - |  |  |  | - |  |  |  | (88.3 | ) |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| ACQUISITION-RELATED EXPENSE |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 1.7 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1.7 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 818.2 |  |  | $ | 775.6 |  |  | $ | 827.8 |  |  | $ | 3,184.8 |  |  | $ | 3,153.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.5 | ) |  |  | (7.4 | ) |  |  | (2.0 | ) |  |  | (29.9 | ) |
| Stock-based compensation |  |  | (61.9 | ) |  |  | (65.8 | ) |  |  | (59.3 | ) |  |  | (250.7 | ) |  |  | (251.1 | ) |
| Restructuring and other charges |  |  | (38.8 | ) |  |  | - |  |  |  | - |  |  |  | (88.3 | ) |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1.7 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 717.2 |  |  | $ | 709.3 |  |  | $ | 761.1 |  |  | $ | 2,843.8 |  |  | $ | 2,870.6 |  |
| INCOME FROM OPERATIONS |  | $ | 223.8 |  |  | $ | 226.7 |  |  | $ | 204.4 |  |  | $ | 734.3 |  |  | $ | 607.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.6 |  |  |  | 14.7 |  |  |  | 21.5 |  |  |  | 59.1 |  |  |  | 85.8 |  |
| Stock-based compensation |  |  | 67.2 |  |  |  | 71.9 |  |  |  | 65.1 |  |  |  | 273.0 |  |  |  | 276.6 |  |
| Restructuring and other charges |  |  | 38.8 |  |  |  | - |  |  |  | - |  |  |  | 88.3 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 344.4 |  |  | $ | 313.3 |  |  | $ | 291.0 |  |  | $ | 1,154.7 |  |  | $ | 971.9 |  |
| TOTAL OTHER INCOME (EXPENSE), NET |  | $ | 2.8 |  |  | $ | 2.9 |  |  | $ | (15.5 | ) |  | $ | 6.4 |  |  | $ | (41.2 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 16.2 |  |  |  | 8.2 |  |  |  | 60.2 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| NON-GAAP TOTAL OTHER INCOME, NET |  | $ | 2.8 |  |  | $ | 2.9 |  |  | $ | 0.7 |  |  | $ | 14.6 |  |  | $ | 18.3 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 226.6 |  |  | $ | 229.6 |  |  | $ | 188.9 |  |  | $ | 740.7 |  |  | $ | 566.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.6 |  |  |  | 14.7 |  |  |  | 21.5 |  |  |  | 59.1 |  |  |  | 85.8 |  |
| Stock-based compensation |  |  | 67.2 |  |  |  | 71.9 |  |  |  | 65.1 |  |  |  | 273.0 |  |  |  | 276.6 |  |
| Restructuring and other charges |  |  | 38.8 |  |  |  | - |  |  |  | - |  |  |  | 88.3 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 16.2 |  |  |  | 8.2 |  |  |  | 60.2 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 347.2 |  |  | $ | 316.2 |  |  | $ | 291.7 |  |  | $ | 1,169.3 |  |  | $ | 990.2 |  |
| PROVISION FOR INCOME TAXES |  | $ | 29.6 |  |  | $ | 37.5 |  |  | $ | 15.1 |  |  | $ | 103.2 |  |  | $ | 61.3 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of Non-GAAP adjustments |  |  | 33.4 |  |  |  | 18.1 |  |  |  | 24.1 |  |  |  | 97.9 |  |  |  | 88.3 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 63.0 |  |  | $ | 55.6 |  |  | $ | 39.2 |  |  | $ | 201.1 |  |  | $ | 149.6 |  |
| NET INCOME PER SHARE |  | $ | 0.59 |  |  | $ | 0.55 |  |  | $ | 0.47 |  |  | $ | 1.83 |  |  | $ | 1.37 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.06 |  |  |  | 0.17 |  |  |  | 0.23 |  |
| Stock-based compensation |  |  | 0.20 |  |  |  | 0.21 |  |  |  | 0.18 |  |  |  | 0.79 |  |  |  | 0.75 |  |
| Restructuring and other charges |  |  | 0.11 |  |  |  | - |  |  |  | - |  |  |  | 0.25 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 0.04 |  |  |  | 0.02 |  |  |  | 0.16 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Income tax effect of Non-GAAP adjustments |  |  | (0.10 | ) |  |  | (0.05 | ) |  |  | (0.07 | ) |  |  | (0.28 | ) |  |  | (0.24 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.84 |  |  | $ | 0.75 |  |  | $ | 0.69 |  |  | $ | 2.78 |  |  | $ | 2.28 |  |
| Some items may not add or recalculate due to rounding. |  |  |

[0001102624-14-000858:8k_2_02:56]
15

[0001102624-14-000858:8k_2_02:57]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | FIRST QUARTER 2015 |
|  | (Unaudited) |
|  | First Quarter |
|  | 2015 |
| Non-GAAP Guidance - Net Income Per Share | $0.53 - $0.58 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the First |  |
| Quarter 2015: |  |
| Amortization of intangible assets | (0.04) |
| Stock-based compensation expense | (0.22) |
| Income tax effect | 0.05 |
| Total Adjustments | (0.21) |
| GAAP Guidance - Net Income Per Share | $0.32 - $0.37 |

[0001102624-14-000858:8k_2_02:58]
16
