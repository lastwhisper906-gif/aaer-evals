# NTAP note change history — 0001193125-13-454984 → 0001193125-14-069692


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-02-26):
[0001193125-14-069692:note_history:1]
As of January 24, 2014, future annual minimum lease
 payments under non-cancelable operating leases with an initial term
 in excess of one year totaled $216.1 million.
  (was, 2013-11-26, similarity 0.9613):
[0001193125-13-454984:note_history:1]
As of October 25, 2013, future annual minimum lease
 payments under non-cancelable operating leases with an initial term
 in excess of one year totaled $215.7 million.

- changed (2014-02-26):
[0001193125-14-069692:note_history:2]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of January 24, 2014, we had $240.2 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 January 24, 2014 and April 26, 2013, such liability
 amounted to $15.4 million and $9.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.
  (was, 2013-11-26, similarity 0.9825):
[0001193125-13-454984:note_history:2]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of October 25, 2013, we had $306.8 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product sales. As of
 October 25, 2013 and April 26, 2013, such liability
 amounted to $10.9 million and $9.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.

- changed (2014-02-26):
[0001193125-14-069692:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of
 January 24, 2014, we had $44.1 million in capital purchase
 commitments and $203.2 million in other purchase
 commitments.
  (was, 2013-11-26, similarity 0.7937):
[0001193125-13-454984:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course business for which
 we have not received goods or services. As of October 25,
 2013, we had $33.6 million in capital purchase commitments and
 $202.4 million in other purchase commitments.

- changed (2014-02-26):
[0001193125-14-069692:note_history:4]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Beginning balance |  | $ | 116.0 |  |  | $ | 111.8 |  |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 21.1 |  |  |  | 23.5 |  |  |  | 59.4 |  |  |  | 74.3 |  |
| Warranty costs incurred |  |  | (20.0 | ) |  |  | (18.5 | ) |  |  | (59.5 | ) |  |  | (40.6 | ) |
| Ending balance |  | $ | 117.1 |  |  | $ | 116.8 |  |  | $ | 117.1 |  |  | $ | 116.8 |  |
  (was, 2013-11-26, similarity 0.8473):
[0001193125-13-454984:note_history:4]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Beginning balance |  | $ | 119.8 |  |  | $ | 96.5 |  |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 14.3 |  |  |  | 27.1 |  |  |  | 38.3 |  |  |  | 50.8 |  |
| Warranty costs incurred |  |  | (18.1 | ) |  |  | (11.8 | ) |  |  | (39.5 | ) |  |  | (22.1 | ) |
| Ending balance |  | $ | 116.0 |  |  | $ | 111.8 |  |  | $ | 116.0 |  |  | $ | 111.8 |  |

- changed (2014-02-26):
[0001193125-14-069692:note_history:5]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 79.8 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.3 |  |  |  | 35.6 |  |
| Total |  | $ | 117.1 |  |  | $ | 117.2 |  |
  (was, 2013-11-26, similarity 0.9661):
[0001193125-13-454984:note_history:5]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 78.1 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.9 |  |  |  | 35.6 |  |
| Total |  | $ | 116.0 |  |  | $ | 117.2 |  |

- added (2014-02-26):
[0001193125-14-069692:note_history:6]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 218.0 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (203.8 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 14.2 |  |  | $ | 13.8 |  |

- changed (2014-02-26):
[0001193125-14-069692:note_history:7]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of January 24, 2014 related to such matters as
 they are not probable and/or reasonably estimable.
  (was, 2013-11-26, similarity 0.6652):
[0001193125-13-454984:note_history:7]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of October 25, 2013 related to such matters as
 they are not probable and/or reasonably estimable.

- removed (2014-02-26):
[0001193125-13-454984:note_history:8]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 215.6 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (199.0 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.6 |  |  | $ | 13.8 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-02-26):
[0001193125-14-069692:note_history:9]
There
 have been no significant changes in our significant accounting
 policies as of and for the nine months ended January 24, 2014,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 26,
 2013.
  (was, 2013-11-26, similarity 0.9587):
[0001193125-13-454984:note_history:9]
There
 have been no significant changes in our significant accounting
 policies as of and for the six months ended October 25, 2013,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 26,
 2013.

- removed (2014-02-26):
[0001193125-13-454984:note_history:10]
Recent Accounting Standards Not Yet Effective — In
 July 2013, the Financial Accounting Standards Board issued an
 accounting standard update providing presentation requirements for
 unrecognized tax benefit when a net operating loss carryforward, a
 similar tax loss, or a similar tax credit carryforward exists. This
 accounting standard update will be effective for us beginning in
 our first quarter of fiscal 2015 and is not expected to have a
 significant impact on our consolidated financial
 statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-26):
[0001193125-14-069692:note_history:11]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (4.8 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.2 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.2 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |
  (was, 2013-11-26, similarity 0.9895):
[0001193125-13-454984:note_history:11]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.0 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.0 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.0 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

- changed (2014-02-26):
[0001193125-14-069692:note_history:12]
Our Senior Notes, issued in December 2012, are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with any future senior unsecured indebtedness. Interest
 expense associated with the Senior Notes was $6.2 million and $18.7
 million for the three and nine months ended January 24, 2014,
 respectively, and was $3.1 million for each of the three and nine
 months ended January 25, 2013.
  (was, 2013-11-26, similarity 0.8433):
[0001193125-13-454984:note_history:12]
Our Senior Notes, issued in December 2012, are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with any future senior unsecured indebtedness. Interest
 expense associated with the Senior Notes was $6.2 million and $12.5
 million for the three and six months ended October 25, 2013,
 respectively.

- changed (2014-02-26):
[0001193125-14-069692:note_history:13]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of January 24,
 2014, we were in compliance with all covenants associated with the
 Senior Notes.
  (was, 2013-11-26, similarity 0.9896):
[0001193125-13-454984:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of October 25,
 2013, we were in compliance with all covenants associated with the
 Senior Notes.

- changed (2014-02-26):
[0001193125-14-069692:note_history:14]
• Warrants: As of April 26, 2013, we had outstanding
 warrants for certain counterparties to acquire 39.7 million
 shares of our common stock at an exercise price of $41.28 per
 share. The warrants were exercisable on a series of days commencing
 on September 3, 2013 and ending on October 28, 2013. The
 number of warrants and exercise price were adjusted in July 2013 to
 39.9 million and $41.12 per share, respectively, to reflect
 our July 2013 dividend. On October 17, 2013, the exercise
 price of the warrants then outstanding was further adjusted to
 $40.97 per share to reflect our October 2013 dividend. Through
 October 28, 2013, 31.9 million warrants were exercised
 and net settled with 1.1 million shares of our common stock
 equal to the difference between the market price on the date of
 exercise and the exercise price of the warrants on the respective
 exercise dates. No warrants were exercised during the three months
 ended January 24, 2014 as their exercise price exceeded the
 market value of our stock prior to their expiration during the
 quarter.
  (was, 2013-11-26, similarity 0.8549):
[0001193125-13-454984:note_history:14]
• Warrants: As of April 26, 2013, we had outstanding
 warrants for certain counterparties to acquire 39.7 million
 shares of our common stock at an exercise price of $41.28 per
 share. The warrants were exercisable on a series of days commencing
 on September 3, 2013 and ending on October 28, 2013. The
 number of warrants and exercise price were adjusted in July 2013 to
 39.9 million and $41.12 per share, respectively, to reflect
 our July 2013 dividend. On October 17, 2013, the exercise
 price of the warrants then outstanding was further adjusted to
 $40.97 per share to reflect our October 2013 dividend. Through
 October 25, 2013, 31.9 million warrants were exercised
 and net settled with 1.1 million shares of our common stock
 equal to the difference between the market price on the date of
 exercise and the exercise price of the warrants on the respective
 exercise dates. The remaining warrants had an exercise price
 greater than the market price and expired unexercised by
 October 28, 2013.

- changed (2014-02-26):
[0001193125-14-069692:note_history:15]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 2.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.9 |  |  |  | 7.1 |  |  |  | 41.0 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 0.6 |  |  |  | 3.6 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 20.6 |  |  | $ | 10.2 |  |  | $ | 60.0 |  |
  (was, 2013-11-26, similarity 0.8929):
[0001193125-13-454984:note_history:15]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 2.5 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 13.6 |  |  |  | 7.1 |  |  |  | 27.1 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 0.6 |  |  |  | 2.4 |  |
| Less capitalized interest |  |  | (0.6 | ) |  |  | 0.0 |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 19.7 |  |  | $ | 10.2 |  |  | $ | 39.4 |  |

- changed (2014-02-26):
[0001193125-14-069692:note_history:16]
No interest expense related to the Convertible Notes was
 recognized in the three months ended January 24, 2014 due to
 their maturity.
  (was, 2013-11-26, similarity 0.9531):
[0001193125-13-454984:note_history:16]
No interest expense related to the Convertible Notes was
 recognized in the three months ended October 25, 2013 due to
 their maturity.

- changed (2014-02-26):
[0001193125-14-069692:note_history:17]
As of January 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):
  (was, 2013-11-26, similarity 0.9362):
[0001193125-13-454984:note_history:17]
As of October 25, 2013, our aggregate future principal
 debt maturities are as follows (in millions):

- changed (2014-02-26):
[0001193125-14-069692:note_history:18]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of January 24, 2014, no borrowings were outstanding under
 the facility and we were in compliance with all covenants
 associated with the facility.
  (was, 2013-11-26, similarity 0.9939):
[0001193125-13-454984:note_history:18]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of October 25, 2013, no borrowings were outstanding under
 the facility and we were in compliance with all covenants
 associated with the facility.

- added (2014-02-26):
[0001193125-14-069692:note_history:19]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other long-term financing arrangements |  | $ | 14.8 |  |  | $ | 10.8 |  |
| Less: current portion |  |  | (6.9 | ) |  |  | (5.2 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 5.6 |  |

- removed (2014-02-26):
[0001193125-13-454984:note_history:20]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.1 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 9.5 |  |  |  | 5.6 |  |
| Total |  | $ | 16.6 |  |  | $ | 10.8 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-02-26):
[0001193125-14-069692:note_history:21]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other long-term financing arrangements |  | $ | 14.8 |  |  | $ | 10.8 |  |
| Less: current portion |  |  | (6.9 | ) |  |  | (5.2 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 5.6 |  |

- removed (2014-02-26):
[0001193125-13-454984:note_history:22]
Other Long-Term Financing Arrangements

- removed (2014-02-26):
[0001193125-13-454984:note_history:23]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.1 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 9.5 |  |  |  | 5.6 |  |
| Total |  | $ | 16.6 |  |  | $ | 10.8 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-26):
[0001193125-14-069692:note_history:24]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (4.8 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.2 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.2 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |
  (was, 2013-11-26, similarity 0.9895):
[0001193125-13-454984:note_history:24]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.0 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.0 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.0 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

- added (2014-02-26):
[0001193125-14-069692:note_history:25]
N/A - Not
 Applicable


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-02-26):
[0001193125-14-069692:note_history:26]
As of January 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):
  (was, 2013-11-26, similarity 0.9362):
[0001193125-13-454984:note_history:26]
As of October 25, 2013, our aggregate future principal
 debt maturities are as follows (in millions):
