# NTAP MD&A — 0001564590-17-002845


## mdna

[0001564590-17-002845:mdna:1]
[same as prior period, unchanged from 0001564590-16-029759:mdna:1]

[0001564590-17-002845:mdna:2]
[same as prior period, unchanged from 0001564590-16-029759:mdna:3]

[0001564590-17-002845:mdna:3]
[same as prior period, unchanged from 0001564590-16-029759:mdna:4]

[0001564590-17-002845:mdna:4]
[same as prior period, unchanged from 0001564590-16-029759:mdna:5]

[0001564590-17-002845:mdna:5]
[same as prior period, unchanged from 0001564590-16-029759:mdna:6]

[0001564590-17-002845:mdna:6]
[same as prior period, unchanged from 0001564590-16-029759:mdna:7]

[0001564590-17-002845:mdna:7]
[same as prior period, unchanged from 0001564590-16-029759:mdna:8]

[0001564590-17-002845:mdna:8]
[same as prior period, unchanged from 0001564590-16-029759:mdna:9]

[0001564590-17-002845:mdna:9]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,386 |  |  | $ | 4,038 |  |  | $ | 4,166 |  |
| Gross profit |  | $ | 851 |  |  | $ | 855 |  |  | $ | 2,477 |  |  | $ | 2,555 |  |
| Gross profit margin percentage |  |  | 61 | % |  |  | 62 | % |  |  | 61 | % |  |  | 61 | % |
| Income from operations |  | $ | 183 |  |  | $ | 165 |  |  | $ | 418 |  |  | $ | 284 |  |
| Income from operations as a percentage of net revenues |  |  | 13 | % |  |  | 12 | % |  |  | 10 | % |  |  | 7 | % |
| Net income |  | $ | 146 |  |  | $ | 153 |  |  | $ | 319 |  |  | $ | 237 |  |
| Diluted net income per share |  | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 1.13 |  |  | $ | 0.79 |  |
| Operating cash flows |  | $ | 235 |  |  | $ | 355 |  |  | $ | 621 |  |  | $ | 629 |  |

[0001564590-17-002845:mdna:10]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,234 |  |  | $ | 3,385 |  |
| Days sales outstanding (DSO) |  |  | 39 |  |  |  | 54 |  |

[0001564590-17-002845:mdna:11]
Key Events

[0001564590-17-002845:mdna:12]
Restructuring

[0001564590-17-002845:mdna:13]
During the third quarter of fiscal 2017, we announced a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we reduced our worldwide headcount by approximately 6% and incurred aggregate charges of approximately $52 million, primarily related to employee terminations. We expect to complete these actions in the fourth quarter of fiscal 2017 with no significant additional charges.

[0001564590-17-002845:mdna:14]
Commercial Paper Program

[0001564590-17-002845:mdna:15]
On December 12, 2016, we entered into a commercial paper program, under which we may issue unsecured commercial paper notes, with the aggregate face or principal amount of the notes outstanding at any time not to exceed $600 million. As of January 27, 2017, we had $392 million of commercial paper notes outstanding.

[0001564590-17-002845:mdna:16]
[same as prior period, unchanged from 0001564590-16-029759:mdna:15]

[0001564590-17-002845:mdna:17]
[same as prior period, unchanged from 0001564590-16-029759:mdna:16]

[0001564590-17-002845:mdna:18]
[same as prior period, unchanged from 0001564590-16-029759:mdna:18]

[0001564590-17-002845:mdna:19]
[same as prior period, unchanged from 0001564590-16-029759:mdna:19]

[0001564590-17-002845:mdna:20]
[same as prior period, unchanged from 0001564590-16-029759:mdna:20]

[0001564590-17-002845:mdna:21]
[same as prior period, unchanged from 0001564590-16-029759:mdna:21]

[0001564590-17-002845:mdna:22]
[same as prior period, unchanged from 0001564590-16-029759:mdna:22]

[0001564590-17-002845:mdna:23]
[same as prior period, unchanged from 0001564590-16-029759:mdna:23]

[0001564590-17-002845:mdna:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 56 |  | % |  | 54 |  | % |  | 53 |  | % |  | 54 |  | % |
| Software maintenance |  |  | 17 |  |  |  | 17 |  |  |  | 18 |  |  |  | 17 |  |  |
| Hardware maintenance and other services |  |  | 27 |  |  |  | 29 |  |  |  | 29 |  |  |  | 29 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 31 |  |  |  | 27 |  |  |  | 29 |  |  |  | 27 |  |  |
| Cost of software maintenance |  |  | - |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 8 |  |  |  | 10 |  |  |  | 9 |  |  |  | 11 |  |  |
| Gross profit |  |  | 61 |  |  |  | 62 |  |  |  | 61 |  |  |  | 61 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 30 |  |  |  | 30 |  |  |  | 33 |  |  |
| Research and development |  |  | 13 |  |  |  | 14 |  |  |  | 15 |  |  |  | 16 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 4 |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale of properties |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 48 |  |  |  | 50 |  |  |  | 51 |  |  |  | 55 |  |  |
| Income from operations |  |  | 13 |  |  |  | 12 |  |  |  | 10 |  |  |  | 7 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 13 |  |  |  | 12 |  |  |  | 10 |  |  |  | 7 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |
| Net income |  |  | 10 |  | % |  | 11 |  | % |  | 8 |  | % |  | 6 |  | % |

[0001564590-17-002845:mdna:25]
[same as prior period, unchanged from 0001564590-16-029759:mdna:25]

[0001564590-17-002845:mdna:26]
[same as prior period, unchanged from 0001564590-16-029759:mdna:26]

[0001564590-17-002845:mdna:27]
[same as prior period, unchanged from 0001564590-16-029759:mdna:27]

[0001564590-17-002845:mdna:28]
Net revenues for the third quarter and first nine months of fiscal 2017 were $1,404 million and $4,038 million, respectively, reflecting an increase of $18 million, or 1%, and a decrease of $128 million, or 3%, respectively, compared to the corresponding periods of the prior year. The increase in the third quarter of fiscal 2017 compared to the third quarter of fiscal 2016 was primarily due to higher product revenue, driven by the increase in revenues from strategic products more than offsetting the decrease in mature products. The increase in product revenues was partially offset by lower hardware maintenance and other services revenue. The decrease in the first nine months of fiscal 2017 compared to the first nine months of fiscal 2016 was primarily due to lower product revenue and lower hardware maintenance and other services revenue.

[0001564590-17-002845:mdna:29]
Gross profit as a percentage of net revenues decreased one percentage point for the third quarter of fiscal 2017 and was relatively flat for the first nine months of fiscal 2017 compared to the corresponding periods of the prior year, primarily due to lower gross margins on product revenues, but higher gross margins on software and hardware maintenance and other services revenues.

[0001564590-17-002845:mdna:30]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and first nine months of fiscal 2017 totaled $626 million, or 45% of net revenues and $2,017 million, or 50% of net revenues, respectively, compared to $688 million, or 50% of net revenues, and $2,241 million, or 54% of net revenues, respectively, for the corresponding periods of the prior year. The decreases in expenses were primarily due to decreases in average headcount as a result of our restructuring plans, as well as other cost reduction initiatives, partially offset by additional operating expenses related to the February 2016 acquisition of SolidFire, Inc.

[0001564590-17-002845:mdna:31]
[same as prior period, unchanged from 0001564590-16-029759:mdna:32]

[0001564590-17-002845:mdna:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,386 |  |  |  | 1 | % |  | $ | 4,038 |  |  | $ | 4,166 |  |  |  | (3 | )% |

[0001564590-17-002845:mdna:33]
Product revenues increased in the third quarter of fiscal 2017 compared to the corresponding period in the prior year, while hardware maintenance and other services revenues decreased and software maintenance revenues were relatively flat. Product revenues represented 56% of net revenues for the third quarter of fiscal 2017 compared to 54% for the corresponding period of the prior year. Software maintenance represented 17% of net revenues for each of the third quarter of fiscal 2017 and the corresponding period of the prior year. Hardware maintenance and other services revenues represented 27% of net revenues for the third quarter of fiscal 2017 compared to 29% for the corresponding period of the prior year.

[0001564590-17-002845:mdna:34]
Product revenues and hardware maintenance and other services revenues decreased in the first nine months of fiscal 2017 compared to the corresponding period in the prior year, while software maintenance revenues were relatively flat. Product revenues represented 53% of net revenues for the first nine months of fiscal 2017 compared to 54% for the corresponding periods of the prior year. Software maintenance represented 18% of net revenues for the first nine months of fiscal 2017 compared to 17% for the corresponding period of the prior year. Hardware maintenance and other services revenues represented 29% of net revenues for the first nine months of fiscal 2017 compared to 29% for the corresponding period of the prior year.

[0001564590-17-002845:mdna:35]
[same as prior period, unchanged from 0001564590-16-029759:mdna:36]

[0001564590-17-002845:mdna:36]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 21 | % |  |  | 21 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 20 | % |  |  | 19 | % |  |  | 20 | % |  |  | 19 | % |

[0001564590-17-002845:mdna:37]
[same as prior period, unchanged from 0001564590-16-029759:mdna:38]

[0001564590-17-002845:mdna:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Product revenues |  | $ | 784 |  |  | $ | 750 |  |  |  | 5 | % |  | $ | 2,154 |  |  | $ | 2,229 |  |  |  | (3 | )% |

[0001564590-17-002845:mdna:39]
[same as prior period, unchanged from 0001564590-16-029759:mdna:40]

[0001564590-17-002845:mdna:40]
Product revenues from strategic solutions represented 65% and 64% of product revenues in the third quarter and first nine months of fiscal 2017, respectively, compared to 56% and 54% in the third quarter and first nine months of the prior year. Product revenues from mature solutions represented 35% and 36% of product revenues, in the third quarter and first nine months of fiscal 2017, respectively, compared to 44% and 46% in the third quarter and first nine months of the prior year.

[0001564590-17-002845:mdna:41]
Total product revenues from strategic solutions totaled $512 million in the third quarter of fiscal 2017, reflecting a 22% increase from $419 million in the third quarter of fiscal 2016. This increase was primarily due to a 24% increase in unit volume of Clustered ONTAP systems, partially offset by a decrease in Average Selling Price (ASP) primarily due to higher discounting and promotional programs. Total product revenue from mature solutions totaled $272 million in the third quarter of fiscal 2017, reflecting an 18% decrease from $331 million in the third quarter of fiscal 2016. This decrease was primarily due to a 64% decrease in unit volume of 7-mode systems, as well as a decrease in ASP. In addition, add-on hardware storage and related OS revenues decreased 5% and OEM revenue decreased 2%. These fluctuations reflect the on-going trend of movement of customer demand from our older products to our newer products.

[0001564590-17-002845:mdna:42]
Total product revenues from strategic solutions totaled $1,375 million in the first nine months of fiscal 2017, reflecting a 14% increase from $1,201 million in the first nine months of fiscal 2016. This increase was primarily due to a 23% increase in unit volume of Clustered ONTAP systems, partially offset by a decrease in ASP reflecting higher discounting and promotional programs. Total product revenue from mature solutions totaled $779 million in the first nine months of fiscal 2017, reflecting a 24% decrease from $1,028 million in the first nine months of fiscal 2016. This decrease was primarily due to a 55% decrease in unit volume of 7-mode systems, as well as a decrease in ASP. In addition, add-on hardware, storage and related OS revenues decreased 14% and OEM revenue decreased 4%. These fluctuations are primarily due to the factors discussed above.

[0001564590-17-002845:mdna:43]
[same as prior period, unchanged from 0001564590-16-029759:mdna:44]

[0001564590-17-002845:mdna:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 240 |  |  | $ | 234 |  |  |  | 3 | % |  | $ | 723 |  |  | $ | 715 |  |  |  | 1 | % |

[0001564590-17-002845:mdna:45]
[same as prior period, unchanged from 0001564590-16-029759:mdna:46]

[0001564590-17-002845:mdna:46]
[same as prior period, unchanged from 0001564590-16-029759:mdna:47]

[0001564590-17-002845:mdna:47]
[same as prior period, unchanged from 0001564590-16-029759:mdna:48]

[0001564590-17-002845:mdna:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 380 |  |  | $ | 402 |  |  |  | (5 | )% |  | $ | 1,161 |  |  | $ | 1,222 |  |  |  | (5 | )% |

[0001564590-17-002845:mdna:49]
[same as prior period, unchanged from 0001564590-16-029759:mdna:50]

[0001564590-17-002845:mdna:50]
Hardware maintenance contract revenues were $313 million and $952 million for the third quarter and first nine months of fiscal 2017, respectively, compared to $326 million and $998 million for the corresponding periods of the prior year. The decreases in hardware maintenance contract revenues reflected lower average contract values, partially offset by a higher installed base under contract.

[0001564590-17-002845:mdna:51]
Professional services and educational and training services revenues were $67 million and $209 million for the third quarter and first nine months of fiscal 2017, respectively, compared to $76 million and $224 for the corresponding periods of the prior year.

[0001564590-17-002845:mdna:52]
[same as prior period, unchanged from 0001564590-16-029759:mdna:53]

[0001564590-17-002845:mdna:53]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| United States, Canada and Latin America (Americas) |  |  | 55 | % |  |  | 54 | % |  |  | 56 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 33 | % |  |  | 33 | % |  |  | 31 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |

[0001564590-17-002845:mdna:54]
[same as prior period, unchanged from 0001564590-16-029759:mdna:55]

[0001564590-17-002845:mdna:55]
[same as prior period, unchanged from 0001564590-16-029759:mdna:71]

[0001564590-17-002845:mdna:56]
Americas revenues consist of sales to Americas commercial and United States public sector (USPS) markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the third quarter and first nine months of fiscal 2017 compared to the third quarter and first nine months of fiscal 2016.

[0001564590-17-002845:mdna:57]
[same as prior period, unchanged from 0001564590-16-029759:mdna:57]

[0001564590-17-002845:mdna:58]
[same as prior period, unchanged from 0001564590-16-029759:mdna:58]

[0001564590-17-002845:mdna:59]
[same as prior period, unchanged from 0001564590-16-029759:mdna:59]

[0001564590-17-002845:mdna:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Cost of product revenues |  | $ | 435 |  |  | $ | 381 |  |  |  | 14 | % |  | $ | 1,170 |  |  | $ | 1,134 |  |  |  | 3 | % |

[0001564590-17-002845:mdna:61]
[same as prior period, unchanged from 0001564590-16-029759:mdna:61]

[0001564590-17-002845:mdna:62]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 15 |  |  |  | 9 |  |
| Warranty |  |  | — |  |  |  | (2 | ) |
| Excess and obsolete inventory |  |  | 2 |  |  |  | — |  |
| Amortization of purchased intangible assets |  |  | (1 | ) |  |  | (2 | ) |
| Other |  |  | (2 | ) |  |  | (2 | ) |
| Total change |  |  | 14 |  |  |  | 3 |  |

[0001564590-17-002845:mdna:63]
Cost of product revenues represented 55% and 54% of product revenues for the third quarter and first nine months of fiscal 2017, respectively, compared to 51% for each of the third quarter and first nine months of fiscal 2016.

[0001564590-17-002845:mdna:64]
Materials costs represented 90% of product costs for the third quarter of fiscal 2017 compared to 88% in the third quarter of fiscal 2016, and increased $58 million from the third quarter of fiscal 2016. Materials costs were impacted by a 42% increase in materials costs related to strategic products, primarily due to higher unit volume for configured Clustered ONTAP systems, partially offset by a 13% decrease in materials costs for mature products reflecting lower volume in 7-Mode systems. Average unit materials costs for both Clustered ONTAP and 7-mode systems decreased compared to the corresponding period in the prior year primarily due to changes in platform and configuration mix.

[0001564590-17-002845:mdna:65]
Materials costs represented 91% of product costs for the first nine months of fiscal 2017 compared to 84% in the first nine months of fiscal 2016, and increased $104 million from the first nine months of fiscal 2016. Materials costs were impacted by a 37% increase in materials costs related to strategic products, primarily due to an increase in volume for configured Clustered ONTAP systems, partially offset by an 18% decrease in materials costs for mature products reflecting a decrease in volume in 7-Mode systems. Average unit materials costs for both Clustered ONTAP and 7-mode systems decreased in the first nine months of fiscal 2017 compared to the corresponding period in the prior year for the same reasons described above.

[0001564590-17-002845:mdna:66]
The impact of the decreases in ASP were only partially offset by the decreases in unit materials costs, resulting in lower standard margins for both strategic and mature products in each of the third quarter and first nine months of fiscal 2017 compared to the corresponding periods in the prior year.

[0001564590-17-002845:mdna:67]
Cost of product revenues in the first nine months of fiscal 2017 reflected a decrease in warranty costs due to our product quality and cost reduction efforts. Charges for excess and obsolete inventories increased $7 million in the third quarter of fiscal 2017 as a result of our transition to new product platforms. The amortization of acquired intangibles in the third quarter and first nine months of fiscal 2017 decreased $5 million and $19 million, respectively, compared to the corresponding periods in the prior year due to the impact of certain acquired developed technology being fully amortized by the end of fiscal 2016, partially offset by the amortization of developed technology related to the SolidFire acquisition.

[0001564590-17-002845:mdna:68]
[same as prior period, unchanged from 0001564590-16-029759:mdna:85]

[0001564590-17-002845:mdna:69]
[same as prior period, unchanged from 0001564590-16-029759:mdna:68]

[0001564590-17-002845:mdna:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 7 |  |  | $ | 9 |  |  |  | (22 | )% |  | $ | 22 |  |  | $ | 28 |  |  |  | (21 | )% |

[0001564590-17-002845:mdna:71]
Cost of software maintenance revenues decreased in the third quarter and first nine months of fiscal 2017 compared to the third quarter and first nine months of fiscal 2016. Cost of software maintenance revenues represented 3% of software maintenance revenues for each of the third quarter and first nine months of fiscal 2017 compared to 4% of software maintenance revenues for each of the third quarter and first nine months of 2016.

[0001564590-17-002845:mdna:72]
[same as prior period, unchanged from 0001564590-16-029759:mdna:72]

[0001564590-17-002845:mdna:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 111 |  |  | $ | 141 |  |  |  | (21 | )% |  | $ | 369 |  |  | $ | 449 |  |  |  | (18 | )% |

[0001564590-17-002845:mdna:74]
Cost of hardware maintenance and other services revenues decreased $30 million and $80 million for the third quarter and first nine months of fiscal 2017, respectively, compared to the corresponding periods of the prior year, primarily due to the benefits of our cost reduction initiatives. Costs represented 29% and 32% of hardware and maintenance and other services revenues in the third quarter and first nine months of fiscal 2017, respectively, compared to 35% and 37% in the third quarter and first nine months of fiscal 2016, respectively.

[0001564590-17-002845:mdna:75]
[same as prior period, unchanged from 0001564590-16-029759:mdna:75]

[0001564590-17-002845:mdna:76]
[same as prior period, unchanged from 0001564590-16-029759:mdna:76]

[0001564590-17-002845:mdna:77]
[same as prior period, unchanged from 0001564590-16-029759:mdna:77]

[0001564590-17-002845:mdna:78]
Total compensation costs included in operating expenses decreased $35 million, or 9% and $124 million, or 10%, in the third quarter and first nine months of fiscal 2017, respectively, compared to the comparable periods in the prior year primarily due to lower salary and stock-based compensation expenses reflecting a 14% decrease in average headcount as a result of restructuring plans, partially offset by higher incentive compensation expense, reflecting stronger operating performance against goals.

[0001564590-17-002845:mdna:79]
[same as prior period, unchanged from 0001564590-16-029759:mdna:80]

[0001564590-17-002845:mdna:80]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 381 |  |  | $ | 418 |  |  |  | (9 | )% |  | $ | 1,228 |  |  | $ | 1,358 |  |  |  | (10 | )% |

[0001564590-17-002845:mdna:81]
[same as prior period, unchanged from 0001564590-16-029759:mdna:82]

[0001564590-17-002845:mdna:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (4 | ) |  |  | (5 | ) |
| Commissions |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (3 | ) |  |  | (3 | ) |
| Other |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | (9 | ) |  |  | (10 | ) |

[0001564590-17-002845:mdna:83]
Compensation costs for the third quarter and the first nine months of fiscal 2017 compared to the corresponding periods in the prior year were favorably impacted by lower salary and stock-based compensation expenses due to a 12% decrease in average headcount, but were unfavorably impacted by higher incentive compensation expense. Facilities and IT support costs for the third quarter and first nine months of fiscal 2017 compared to the corresponding periods of the prior year were favorably impacted by cost containment efforts.

[0001564590-17-002845:mdna:84]
[same as prior period, unchanged from 0001564590-16-029759:mdna:96]

[0001564590-17-002845:mdna:85]
[same as prior period, unchanged from 0001564590-16-029759:mdna:86]

[0001564590-17-002845:mdna:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Research and development expenses |  | $ | 181 |  |  | $ | 200 |  |  |  | (10 | )% |  | $ | 588 |  |  | $ | 660 |  |  |  | (11 | )% |

[0001564590-17-002845:mdna:87]
[same as prior period, unchanged from 0001564590-16-029759:mdna:88]

[0001564590-17-002845:mdna:88]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (8 | ) |  |  | (8 | ) |
| Development projects and outside services |  |  | — |  |  |  | (1 | ) |
| Other |  |  | (2 | ) |  |  | (2 | ) |
| Total change |  |  | (10 | ) |  |  | (11 | ) |

[0001564590-17-002845:mdna:89]
Compensation costs for the third quarter and first nine months of fiscal 2017 compared to the corresponding periods of the prior year were favorably impacted by lower salary and stock-based compensation expenses due to a 19% decrease in average headcount, but were unfavorably impacted by higher incentive compensation expense. Development projects and outside services for the first nine months of fiscal 2017 compared to the corresponding period of the prior year were favorably impacted by lower spending on materials and services associated with engineering activities to develop new product lines and enhancements to existing products due to the completion of certain key development projects.

[0001564590-17-002845:mdna:90]
[same as prior period, unchanged from 0001564590-16-029759:mdna:91]

[0001564590-17-002845:mdna:91]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| General and administrative expenses |  | $ | 64 |  |  | $ | 70 |  |  |  | (9 | )% |  | $ | 201 |  |  | $ | 223 |  |  |  | (10 | )% |

[0001564590-17-002845:mdna:92]
[same as prior period, unchanged from 0001564590-16-029759:mdna:93]

[0001564590-17-002845:mdna:93]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | (4 | ) |
| Professional and legal fees and outside services |  |  | (11 | ) |  |  | (5 | ) |
| Facilities and IT support costs |  |  | 4 |  |  |  | 1 |  |
| Other |  |  | — |  |  |  | (2 | ) |
| Total change |  |  | (9 | ) |  |  | (10 | ) |

[0001564590-17-002845:mdna:94]
Compensation costs for the third quarter and the first nine months of fiscal 2017 compared to the third quarter of fiscal 2016 were favorably impacted by lower salary and stock-based compensation expenses due to decreases of 13% and 9% in average headcount, respectively, but were unfavorably impacted by higher incentive compensation expense. Professional and legal fees and outside services expense for the third quarter and first nine months of fiscal 2017 compared to the corresponding periods of the prior year were favorably impacted by lower spending levels on consulting fees and projects. The increase in facilities and IT support costs for the third quarter and first nine months of fiscal 2017 compared to the corresponding periods of the prior year is primarily due to an increase in spending on IT projects.

[0001564590-17-002845:mdna:95]
Restructuring Charges (in millions, except percentages):

[0001564590-17-002845:mdna:96]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Restructuring charges |  | $ | 52 |  |  | $ | — |  |  | NM |  | $ | 52 |  |  |  | 28 |  |  |  | 86 | % |

[0001564590-17-002845:mdna:97]
NM – Not Meaningful

[0001564590-17-002845:mdna:98]
[same as prior period, unchanged from 0001564590-16-029759:mdna:113]

[0001564590-17-002845:mdna:99]
In November 2016, we announced a restructuring plan to streamline our core business and decrease operating expenses, which included a reduction in our worldwide headcount of approximately 6%. During fiscal 2016, management approved two restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, which included a restructuring plan announced in May 2015 under which we reduced our global workforce by approximately 3%. Restructuring charges related to these plans consisted primarily of employee severance-related costs. See Note 11 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-17-002845:mdna:100]
Acquisition-related Expense (in millions, except percentages):

[0001564590-17-002845:mdna:101]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  | % Change |  |
| Acquisition-related expense |  | $ | — |  |  | 2 |  |  | (100 | )% |  | $ | — |  |  | 2 |  |  | (100 | )% |

[0001564590-17-002845:mdna:102]
During the third quarter of fiscal 2016, we incurred $2 million of acquisition costs, primarily related to legal and consulting fees associated with our acquisition of SolidFire.

[0001564590-17-002845:mdna:103]
Gain on Sale of Properties (in millions, except percentages):

[0001564590-17-002845:mdna:104]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |
| Gain on sale of properties |  | $ | (10 | ) |  | $ | — |  |  | NM |  | $ | (10 | ) |  | $ | — |  |  | NM |

[0001564590-17-002845:mdna:105]
NM – Not Meaningful

[0001564590-17-002845:mdna:106]
During the third quarter of fiscal 2017, our continuing involvement with certain properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded a non-cash sale of properties, extinguished the associated financing obligation and recognized a gain of $10 million.

[0001564590-17-002845:mdna:107]
[same as prior period, unchanged from 0001564590-16-029759:mdna:100]

[0001564590-17-002845:mdna:108]
[same as prior period, unchanged from 0001564590-16-029759:mdna:101]

[0001564590-17-002845:mdna:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Interest income |  | $ | 10 |  |  | $ | 11 |  |  |  | (9 | )% |  | $ | 31 |  |  | $ | 35 |  |  |  | (11 | )% |
| Interest expense |  |  | (12 | ) |  |  | (11 | ) |  |  | 9 | % |  |  | (39 | ) |  |  | (34 | ) |  |  | 15 | % |
| Other income, net |  |  | 2 |  |  |  | (2 | ) |  | NM |  |  |  | 7 |  |  |  | — |  |  | NM |  |
| Total |  | $ | — |  |  | $ | (2 | ) |  |  | (100 | )% |  | $ | (1 | ) |  | $ | 1 |  |  | NM |  |

[0001564590-17-002845:mdna:110]
[same as prior period, unchanged from 0001564590-16-029759:mdna:103]

[0001564590-17-002845:mdna:111]
The decreases in interest income in the third quarter and first nine months of fiscal 2017 compared to the corresponding periods of the prior year were primarily due to a decrease in the size of our investment portfolio.

[0001564590-17-002845:mdna:112]
Interest expense is primarily related to our Senior Notes, and in the nine months ended January 27, 2017 to interest on the short-term note related to our acquisition of SolidFire.

[0001564590-17-002845:mdna:113]
[same as prior period, unchanged from 0001564590-16-029759:mdna:106]

[0001564590-17-002845:mdna:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | % Change |  |
| Provision for income taxes |  | $ | 37 |  |  | $ | 10 |  |  |  | 270 | % |  | $ | 98 |  |  | $ | 48 |  |  |  | 104 | % |

[0001564590-17-002845:mdna:115]
Our effective tax rate for the third quarter of fiscal 2017 was 20.2% compared to an effective tax rate of 6.1% for the third quarter of fiscal 2016. Our effective tax rate for the first nine months of fiscal 2017 was 23.5% compared to an effective tax rate of 16.8% for the first nine months of fiscal 2016. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business, with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for all periods presented were favorably impacted by the geographic mix of profits. Our effective tax rates increased for the three and nine months of fiscal 2017, compared to the corresponding periods in the prior year primarily as a result of differences in the respective periods’ income before taxes, as well as the impacts of discrete events described below.

[0001564590-17-002845:mdna:116]
[same as prior period, unchanged from 0001564590-16-029759:mdna:131]

[0001564590-17-002845:mdna:117]
In the first quarter of fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During the first nine months of fiscal 2017, we recorded a discrete charge of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-17-002845:mdna:118]
In June 2015, the IRS signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements and in October 2015 completed the examination of our fiscal 2008 to 2010 income tax returns. During the first nine months of fiscal 2016, we recorded discrete charges totaling $23 million attributable to the audit settlements and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-17-002845:mdna:119]
As of January 27, 2017, we had $215 million of gross unrecognized tax benefits, of which $147 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $157 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-002845:mdna:120]
[same as prior period, unchanged from 0001564590-16-029759:mdna:112]

[0001564590-17-002845:mdna:121]
[same as prior period, unchanged from 0001564590-16-029759:mdna:114]

[0001564590-17-002845:mdna:122]
| (In millions, except percentages) |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,639 |  |  | $ | 5,303 |  |
| Principal amount of debt |  | $ | 1,892 |  |  | $ | 2,350 |  |
| Debt as a percentage of stockholders' equity |  |  | 70 | % |  |  | 82 | % |

[0001564590-17-002845:mdna:123]
[same as prior period, unchanged from 0001564590-16-029759:mdna:116]

[0001564590-17-002845:mdna:124]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Net cash provided by operating activities |  | $ | 621 |  |  | $ | 629 |  |
| Net cash provided by (used in) investing activities |  |  | (133 | ) |  |  | 753 |  |
| Net cash used in financing activities |  |  | (1,128 | ) |  |  | (790 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (15 | ) |  |  | (19 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (655 | ) |  | $ | 573 |  |

[0001564590-17-002845:mdna:125]
[same as prior period, unchanged from 0001564590-16-029759:mdna:118]

[0001564590-17-002845:mdna:126]
As of January 27, 2017, our cash, cash equivalents and short-term investments were $4.6 billion, a decrease of $0.7 billion from April 29, 2016. The decrease was primarily due to $850 million used to repay our short-term loan, $576 million paid for the repurchase of our common stock and $157 million used for the payment of dividends, partially offset by $621 million of cash provided by operating activities and $392 million, net from the issuance of commercial paper notes. Accounts receivable DSO was 39 days for the third quarter of fiscal 2017 compared to 54 days for the fourth quarter of fiscal 2016 and 38 days for the third quarter of fiscal 2016, reflecting seasonal patterns of shipment linearity. Working capital decreased by $984 million to $1.8 billion as of January 27, 2017 compared to April 29, 2016 primarily due to a decrease in cash, cash equivalents and accounts receivable, the issuance of commercial paper notes and the reclassification of $750 million of the principal balance of our senior notes to current, partially offset by the repayment of our short-term loan.

[0001564590-17-002845:mdna:127]
[same as prior period, unchanged from 0001564590-16-029759:mdna:120]

[0001564590-17-002845:mdna:128]
During the first nine months of fiscal 2017, we generated cash from operating activities of $621 million, reflecting net income of $319 million, adjusted by non-cash depreciation and amortization of $173 million and stock-based compensation of $149 million, compared to $629 million of cash generated from operating activities during the first nine months of 2016.

[0001564590-17-002845:mdna:129]
Changes in assets and liabilities in the first nine months of fiscal 2017 included the following:

[0001564590-17-002845:mdna:130]
|  | • | Accounts receivable decreased $208 million, primarily due to lower seasonal invoicing levels in the third quarter of fiscal 2017 compared to the fourth quarter of fiscal 2016. |

[0001564590-17-002845:mdna:131]
|  | • | Accrued compensation decreased $64 million, primarily due to employee compensation payouts related to fiscal year 2016 commissions and incentive compensation plans, as well as payments of restructuring obligations. |

[0001564590-17-002845:mdna:132]
|  | • | Deferred revenue and financed unearned services revenue decreased $148 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting lower levels of maintenance contract renewal activities. |

[0001564590-17-002845:mdna:133]
[same as prior period, unchanged from 0001564590-16-029759:mdna:126]

[0001564590-17-002845:mdna:134]
[same as prior period, unchanged from 0001564590-16-029759:mdna:127]

[0001564590-17-002845:mdna:135]
During the first nine months of fiscal 2017, we generated $2 million from maturities and sales of investments, net of purchases, and paid $137 million for capital expenditures compared to $879 million and $125 million, respectively, during the first nine months of fiscal 2016.

[0001564590-17-002845:mdna:136]
[same as prior period, unchanged from 0001564590-16-029759:mdna:129]

[0001564590-17-002845:mdna:137]
During the first nine months of fiscal 2017, we used $850 million to repay our short-term loan, $576 million for the repurchase of 18 million shares of our common stock and $157 million for the payment of dividends, compared to $698 million used for the repurchase of common stock and $159 million for the payment of dividends during the first nine months of fiscal 2016. In the third quarter of fiscal 2017, we initiated a commercial paper program under which we had net borrowings of $392 million of commercial paper notes during the period.

[0001564590-17-002845:mdna:138]
[same as prior period, unchanged from 0001564590-16-029759:mdna:132]

[0001564590-17-002845:mdna:139]
[same as prior period, unchanged from 0001564590-16-029759:mdna:133]

[0001564590-17-002845:mdna:140]
Our principal sources of liquidity as of January 27, 2017 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-17-002845:mdna:141]
[same as prior period, unchanged from 0001564590-16-029759:mdna:135]

[0001564590-17-002845:mdna:142]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Cash and cash equivalents |  | $ | 2,213 |  |  | $ | 2,868 |  |
| Short-term investments |  |  | 2,426 |  |  |  | 2,435 |  |
| Total |  | $ | 4,639 |  |  | $ | 5,303 |  |

[0001564590-17-002845:mdna:143]
As of January 27, 2017 and April 29, 2016, $4.1 billion and $4.8 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.5 billion was available in the U.S. as of each of those dates. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds indefinitely reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-17-002845:mdna:144]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 27, 2017. Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and

[0001564590-17-002845:mdna:145]
[same as prior period, unchanged from 0001564590-16-029759:mdna:159]

[0001564590-17-002845:mdna:146]
capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties.

[0001564590-17-002845:mdna:147]
[same as prior period, unchanged from 0001564590-16-029759:mdna:145]

[0001564590-17-002845:mdna:148]
[same as prior period, unchanged from 0001564590-16-029759:mdna:140]

[0001564590-17-002845:mdna:149]
The following table summarizes the principal amount of our Senior Notes as of January 27, 2017 (in millions):

[0001564590-17-002845:mdna:150]
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-17-002845:mdna:151]
[same as prior period, unchanged from 0001564590-16-029759:mdna:144]

[0001564590-17-002845:mdna:152]
Commercial Paper Program and Credit Facility

[0001564590-17-002845:mdna:153]
In December 2016, we entered into a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $600 million. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes will be used for general corporate purposes. As of January 27, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $392 million, a weighted-average interest rate of 1.10% and maturities ranging from 20 days to 36 days.

[0001564590-17-002845:mdna:154]
In connection with the Program, we entered into a new senior unsecured credit agreement that expires on December 10, 2021, and we terminated our existing credit agreement that had been scheduled to expire on December 21, 2017. The new credit agreement provides a $600 million revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 27, 2017, no borrowings or letters of credit were outstanding under this facility and we were in compliance with all associated covenants.

[0001564590-17-002845:mdna:155]
[same as prior period, unchanged from 0001564590-16-029759:mdna:150]

[0001564590-17-002845:mdna:156]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2017 to be between $25 and $75 million.

[0001564590-17-002845:mdna:157]
[same as prior period, unchanged from 0001564590-16-029759:mdna:152]

[0001564590-17-002845:mdna:158]
On February 15, 2017, we declared a cash dividend of $0.19 per share of common stock, payable on April 26, 2017 to holders of record as of the close of business on April 7, 2017.

[0001564590-17-002845:mdna:159]
As of January 27, 2017, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 27, 2017, we repurchased a total of 266 million shares of our common stock at an average price of $32.74 per share, for an aggregate purchase price of $8.7 billion. As of January 27, 2017, the remaining authorized amount for stock repurchases under this program was $0.9 billion, with no termination date, which we plan to complete by May 2018.

[0001564590-17-002845:mdna:160]
[same as prior period, unchanged from 0001564590-16-029759:mdna:155]

[0001564590-17-002845:mdna:161]
[same as prior period, unchanged from 0001564590-16-029759:mdna:156]

[0001564590-17-002845:mdna:162]
[same as prior period, unchanged from 0001564590-16-029759:mdna:157]

[0001564590-17-002845:mdna:163]
As of January 27, 2017, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $227 million.

[0001564590-17-002845:mdna:164]
[same as prior period, unchanged from 0001564590-16-029759:mdna:160]

[0001564590-17-002845:mdna:165]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 27, 2017, we had $313 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-002845:mdna:166]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of January 27, 2017, we had $20 million in construction-related obligations and $220 million in other purchase obligations.

[0001564590-17-002845:mdna:167]
[same as prior period, unchanged from 0001564590-16-029759:mdna:163]

[0001564590-17-002845:mdna:168]
As of January 27, 2017, our liability for uncertain tax positions was $138 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-17-002845:mdna:169]
Sale-leaseback Transactions

[0001564590-17-002845:mdna:170]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. During the three months ended January 27, 2017, we terminated one of the leases, ending our continuing involvement with the related properties. As a result, we recorded a non-cash sale of properties having a net book value of $9 million, the extinguishment of $19 million of associated financing obligations, and a gain of $10 million. As of January 27, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.

[0001564590-17-002845:mdna:171]
[same as prior period, unchanged from 0001564590-16-029759:mdna:167]

[0001564590-17-002845:mdna:172]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $142 million and $153 million of receivables during the first nine months of fiscal 2017 and fiscal 2016, respectively.

[0001564590-17-002845:mdna:173]
[same as prior period, unchanged from 0001564590-16-029759:mdna:178]

[0001564590-17-002845:mdna:174]
[same as prior period, unchanged from 0001564590-16-029759:mdna:169]

[0001564590-17-002845:mdna:175]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 27, 2017 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-002845:mdna:176]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 27, 2017, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-17-002845:mdna:177]
[same as prior period, unchanged from 0001564590-16-029759:mdna:174]

[0001564590-17-002845:mdna:178]
[same as prior period, unchanged from 0001564590-16-029759:mdna:175]

[0001564590-17-002845:mdna:179]
Legal Contingencies

[0001564590-17-002845:mdna:180]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.
