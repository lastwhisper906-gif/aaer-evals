# NTAP 8-K — 0001564590-17-001635 filed 2017-02-15

## item codes, every 8-K on or before 2017-02-28

- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2017-02-28

- none on or before 2017-02-28

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-001635:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-17-001635:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-17-001635:8k_2_02:3]
Exhibit 99.1

[0001564590-17-001635:8k_2_02:4]
NETAPP REPORTS THIRD QUARTER FISCAL YEAR 2017 RESULTS

[0001564590-17-001635:8k_2_02:5]
Net Revenues of $1.40 Billion; Up 5% Quarter-over-Quarter and 1% Year-over-Year;

[0001564590-17-001635:8k_2_02:6]
GAAP EPS of $0.52 and Non-GAAP EPS of $0.82

[0001564590-17-001635:8k_2_02:7]
| • | All-flash array annualized net revenue run rate almost $1.40 billion, up 160% year-over-year. |

[0001564590-17-001635:8k_2_02:8]
| • | Nearly 300 petabytes of flash shipped. |

[0001564590-17-001635:8k_2_02:9]
| • | Clustered Data ONTAP™ managing 50% of installed base capacity. |

[0001564590-17-001635:8k_2_02:10]
| • | $336 million returned to shareholders in share repurchases and a cash dividend. |

[0001564590-17-001635:8k_2_02:11]
Sunnyvale, Calif.—February 15, 2017—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2017, ended January 27, 2017.

[0001564590-17-001635:8k_2_02:12]
Third Quarter Financial Results

[0001564590-17-001635:8k_2_02:13]
Net revenues for the third quarter of fiscal year 2017 were $1.40 billion. GAAP net income for the third quarter of fiscal year 2017 was $146 million, or $0.52 per share,1 compared to GAAP net income of $153 million, or $0.52 per share, for the comparable period of the prior year. Non-GAAP net income for the third quarter of fiscal year 2017 was $231 million, or $0.82 per share,2 compared to non-GAAP net income of $206 million, or $0.70 per share, for the comparable period of the prior year.

[0001564590-17-001635:8k_2_02:14]
Cash, Cash Equivalents and Investments

[0001564590-17-001635:8k_2_02:15]
NetApp ended the third quarter of fiscal year 2017 with $4.6 billion in total cash, cash equivalents and investments. During the third quarter of fiscal year 2017, the Company generated $235 million in cash from operations and returned $336 million to shareholders through share repurchases and a cash dividend.

[0001564590-17-001635:8k_2_02:16]
The Company announced the next cash dividend of $0.19 per share. The quarterly dividend will be paid on April 26, 2017 to shareholders of record as of the close of business on April 7, 2017.

[0001564590-17-001635:8k_2_02:17]
“Q3 marked another quarter of strong execution by NetApp,” said George Kurian, chief executive officer. “The transformation of NetApp is yielding solid results and has changed the trajectory of our business. With our industry-leading portfolio of solutions and Data Fabric strategy, NetApp is well positioned to lead in the next era of IT.”

[0001564590-17-001635:8k_2_02:18]
Q4 Fiscal Year 2017 Outlook

[0001564590-17-001635:8k_2_02:19]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2017:

[0001564590-17-001635:8k_2_02:20]
| • | Net revenues are expected to be in the range of $1.365 billion to $1.515 billion. |

[0001564590-17-001635:8k_2_02:21]
| • | GAAP earnings per share is expected to be in the range of $0.60 to $0.65 per share. |

[0001564590-17-001635:8k_2_02:22]
| • | Non-GAAP earnings per share is expected to be in the range of $0.79 to $0.84 per share. |

[0001564590-17-001635:8k_2_02:23]
Business Highlights

[0001564590-17-001635:8k_2_02:24]
| • | NetApp Expands Cloud Data Management and All-Flash Offerings |

[0001564590-17-001635:8k_2_02:25]
|  | - | NetApp Improves Control, Simplifies Movement of Data in the Hybrid Cloud. New Data Fabric solutions and services speed data access and visibility, enhance data protection and security, and help customers extract value from their data from anywhere in the hybrid cloud. |

[0001564590-17-001635:8k_2_02:26]
|  | - | NetApp Expands All-Flash Portfolio with New Entry-Level Array. The NetAppTM All Flash FAS (AFF) A200 expands the market opportunity for the world’s fastest and most efficient cloud-connected enterprise storage portfolio. The entry-level system delivers enterprise-grade flash performance at a very attractive price point and is ideal for midsize businesses that are making the move to all flash. |

[0001564590-17-001635:8k_2_02:27]
| • | Customers Team with NetApp to Accelerate Performance and Responsiveness |

[0001564590-17-001635:8k_2_02:28]
|  | - | Carrenza Supports Rapidly Evolving Customer Application and Infrastructure Demands with NetApp SolidFire. Global cloud service company Carrenza leverages NetApp SolidFireTM all-flash storage to enable customers to scale and accelerate business performance, increase infrastructure agility and responsiveness, and reduce storage maintenance time and administration effort. |

[0001564590-17-001635:8k_2_02:29]
|  | - | Cologne Broadcasting Center (CBC) Upgrades TV Production and Delivery Services with NetApp. A new production storage and disaster recovery infrastructure has improved |

[0001564590-17-001635:8k_2_02:30]
|  |  | CBC broadcast service offerings throughout Germany with solutions delivered by NetApp and partner Pixit Media. |

[0001564590-17-001635:8k_2_02:31]
|  | - | Wirestorm Delivers DevOps in the Cloud with NetApp ONTAP Cloud for Amazon Web Services (AWS). To accelerate and automate its DevOps process, Wirestorm deployed NetApp ONTAPTM Cloud. This Data Fabric solution delivers everything that the company needs for DevOps in the cloud—without a single physical array—enabling Wirestorm to use only laptops. The framework that it created with NetApp has enabled Wirestorm to automate so efficiently that it can implement an end-to-end solution all the way to AWS in less than a minute. |

[0001564590-17-001635:8k_2_02:32]
Webcast and Conference Call Information

[0001564590-17-001635:8k_2_02:33]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-17-001635:8k_2_02:34]
About NetApp

[0001564590-17-001635:8k_2_02:35]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store data. We help customers capitalize on the value of their data in the hybrid cloud through our Data Fabric strategy, data management expertise, portfolio and ecosystem. To learn more, visit www.netapp.com.

[0001564590-17-001635:8k_2_02:36]
seasonality and matters specific to our business, such as our ability to understand, and effectively respond to changes affecting our market environment, product, technologies and customer requirements, including the impact of the cloud, customer demand for and acceptance of our products and services, our ability to reduce our cost structure, streamline the business and improve efficiency, our ability to effectively integrate the SolidFire acquisition, and our ability to manage our gross profit margins. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the section titled “Risk Factors” in our most recently submitted Annual Report on Form 10-K. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0001564590-17-001635:8k_2_02:37]
###

[0001564590-17-001635:8k_2_02:38]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-17-001635:8k_2_02:39]
1 GAAP earnings per share is calculated using the diluted number of shares.

[0001564590-17-001635:8k_2_02:40]
2 Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related expenses, (d) restructuring and other charges, (e) asset impairments, (f) gains/losses on the sale of properties, and (g) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-17-001635:8k_2_02:41]
NetApp Usage of Non-GAAP Financial Information

[0001564590-17-001635:8k_2_02:42]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-17-001635:8k_2_02:43]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital expenditures. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-17-001635:8k_2_02:44]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001564590-17-001635:8k_2_02:45]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-17-001635:8k_2_02:46]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to

[0001564590-17-001635:8k_2_02:47]
exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-17-001635:8k_2_02:48]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-17-001635:8k_2_02:49]
C. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-17-001635:8k_2_02:50]
D. Restructuring and other charges. These charges include restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. These items are not ordinarily included in our annual operating plan and related budget due to the unpredictability of the timing and size of these events. We therefore exclude them in our assessment of operational performance.

[0001564590-17-001635:8k_2_02:51]
E. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-17-001635:8k_2_02:52]
F. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-17-001635:8k_2_02:53]
G. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation,

[0001564590-17-001635:8k_2_02:54]
authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-17-001635:8k_2_02:55]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-17-001635:8k_2_02:56]
NETAPP, INC.

[0001564590-17-001635:8k_2_02:57]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-001635:8k_2_02:58]
(In millions)

[0001564590-17-001635:8k_2_02:59]
(Unaudited)

[0001564590-17-001635:8k_2_02:60]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,639 |  |  | $ | 5,303 |  |
| Accounts receivable |  |  | 605 |  |  |  | 813 |  |
| Inventories |  |  | 125 |  |  |  | 98 |  |
| Other current assets |  |  | 277 |  |  |  | 234 |  |
| Total current assets |  |  | 5,646 |  |  |  | 6,448 |  |
| Property and equipment, net |  |  | 892 |  |  |  | 937 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,821 |  |  |  | 1,856 |  |
| Other non-current assets |  |  | 696 |  |  |  | 796 |  |
| Total assets |  | $ | 9,055 |  |  | $ | 10,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 258 |  |  | $ | 254 |  |
| Accrued expenses |  |  | 747 |  |  |  | 765 |  |
| Commercial paper notes |  |  | 392 |  |  |  | — |  |
| Short-term loan |  |  | — |  |  |  | 849 |  |
| Current portion of long-term debt |  |  | 748 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,699 |  |  |  | 1,794 |  |
| Total current liabilities |  |  | 3,844 |  |  |  | 3,662 |  |
| Long-term debt |  |  | 744 |  |  |  | 1,490 |  |
| Other long-term liabilities |  |  | 238 |  |  |  | 413 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,535 |  |  |  | 1,591 |  |
| Total liabilities |  |  | 6,361 |  |  |  | 7,156 |  |
| Stockholders' equity |  |  | 2,694 |  |  |  | 2,881 |  |
| Total liabilities and stockholders' equity |  | $ | 9,055 |  |  | $ | 10,037 |  |

[0001564590-17-001635:8k_2_02:61]
NETAPP, INC.

[0001564590-17-001635:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-001635:8k_2_02:63]
(In millions, except per share amounts)

[0001564590-17-001635:8k_2_02:64]
(Unaudited)

[0001564590-17-001635:8k_2_02:65]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 784 |  |  | $ | 750 |  |  | $ | 2,154 |  |  | $ | 2,229 |  |
| Software maintenance |  |  | 240 |  |  |  | 234 |  |  |  | 723 |  |  |  | 715 |  |
| Hardware maintenance and other services |  |  | 380 |  |  |  | 402 |  |  |  | 1,161 |  |  |  | 1,222 |  |
| Net revenues |  |  | 1,404 |  |  |  | 1,386 |  |  |  | 4,038 |  |  |  | 4,166 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 435 |  |  |  | 381 |  |  |  | 1,170 |  |  |  | 1,134 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | 9 |  |  |  | 22 |  |  |  | 28 |  |
| Cost of hardware maintenance and other services |  |  | 111 |  |  |  | 141 |  |  |  | 369 |  |  |  | 449 |  |
| Total cost of revenues |  |  | 553 |  |  |  | 531 |  |  |  | 1,561 |  |  |  | 1,611 |  |
| Gross profit |  |  | 851 |  |  |  | 855 |  |  |  | 2,477 |  |  |  | 2,555 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 381 |  |  |  | 418 |  |  |  | 1,228 |  |  |  | 1,358 |  |
| Research and development |  |  | 181 |  |  |  | 200 |  |  |  | 588 |  |  |  | 660 |  |
| General and administrative |  |  | 64 |  |  |  | 70 |  |  |  | 201 |  |  |  | 223 |  |
| Restructuring and other charges |  |  | 52 |  |  |  | — |  |  |  | 52 |  |  |  | 28 |  |
| Acquisition-related expense |  |  | — |  |  |  | 2 |  |  |  | — |  |  |  | 2 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |  |  | — |  |
| Total operating expenses |  |  | 668 |  |  |  | 690 |  |  |  | 2,059 |  |  |  | 2,271 |  |
| Income from operations |  |  | 183 |  |  |  | 165 |  |  |  | 418 |  |  |  | 284 |  |
| Other income (expense), net |  |  | — |  |  |  | (2 | ) |  |  | (1 | ) |  |  | 1 |  |
| Income before income taxes |  |  | 183 |  |  |  | 163 |  |  |  | 417 |  |  |  | 285 |  |
| Provision for income taxes |  |  | 37 |  |  |  | 10 |  |  |  | 98 |  |  |  | 48 |  |
| Net income |  | $ | 146 |  |  | $ | 153 |  |  | $ | 319 |  |  | $ | 237 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.53 |  |  | $ | 0.52 |  |  | $ | 1.15 |  |  | $ | 0.80 |  |
| Diluted |  | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 1.13 |  |  | $ | 0.79 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 274 |  |  |  | 293 |  |  |  | 277 |  |  |  | 297 |  |
| Diluted |  |  | 281 |  |  |  | 296 |  |  |  | 282 |  |  |  | 300 |  |
| Cash dividends declared per share |  | $ | 0.190 |  |  | $ | 0.180 |  |  | $ | 0.570 |  |  | $ | 0.540 |  |

[0001564590-17-001635:8k_2_02:66]
NETAPP, INC.

[0001564590-17-001635:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-001635:8k_2_02:68]
(In millions)

[0001564590-17-001635:8k_2_02:69]
(Unaudited)

[0001564590-17-001635:8k_2_02:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 146 |  |  | $ | 153 |  |  | $ | 319 |  |  | $ | 237 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 56 |  |  |  | 66 |  |  |  | 173 |  |  |  | 202 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 63 |  |  |  | 149 |  |  |  | 199 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |  |  | — |  |
| Other items, net |  |  | 52 |  |  |  | (22 | ) |  |  | 65 |  |  |  | (74 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (56 | ) |  |  | 1 |  |  |  | 208 |  |  |  | 190 |  |
| Inventories |  |  | (28 | ) |  |  | 23 |  |  |  | (27 | ) |  |  | 44 |  |
| Accounts payable |  |  | 26 |  |  |  | (53 | ) |  |  | 13 |  |  |  | (113 | ) |
| Accrued expenses |  |  | 17 |  |  |  | 10 |  |  |  | (121 | ) |  |  | (78 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 31 |  |  |  | 85 |  |  |  | (148 | ) |  |  | (52 | ) |
| Changes in other operating assets and liabilities, net |  |  | (45 | ) |  |  | 29 |  |  |  | — |  |  |  | 74 |  |
| Net cash provided by operating activities |  |  | 235 |  |  |  | 355 |  |  |  | 621 |  |  |  | 629 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (188 | ) |  |  | 91 |  |  |  | 2 |  |  |  | 879 |  |
| Purchases of property and equipment |  |  | (45 | ) |  |  | (41 | ) |  |  | (137 | ) |  |  | (125 | ) |
| Other investing activities, net |  |  | 3 |  |  |  | (1 | ) |  |  | 2 |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | (230 | ) |  |  | 49 |  |  |  | (133 | ) |  |  | 753 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock under employee stock award plans |  |  | 45 |  |  |  | 45 |  |  |  | 70 |  |  |  | 70 |  |
| Repurchase of common stock |  |  | (284 | ) |  |  | (85 | ) |  |  | (576 | ) |  |  | (698 | ) |
| Changes in commercial paper notes, net |  |  | 392 |  |  |  | — |  |  |  | 392 |  |  |  | — |  |
| Repayment of short-term loan |  |  | — |  |  |  | — |  |  |  | (850 | ) |  |  | — |  |
| Dividends paid |  |  | (52 | ) |  |  | (52 | ) |  |  | (157 | ) |  |  | (159 | ) |
| Other financing activities, net |  |  | (4 | ) |  |  | (4 | ) |  |  | (7 | ) |  |  | (3 | ) |
| Net cash provided by (used in) financing activities |  |  | 97 |  |  |  | (96 | ) |  |  | (1,128 | ) |  |  | (790 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2 | ) |  |  | (11 | ) |  |  | (15 | ) |  |  | (19 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 100 |  |  |  | 297 |  |  |  | (655 | ) |  |  | 573 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,113 |  |  |  | 2,198 |  |  |  | 2,868 |  |  |  | 1,922 |  |
| End of period |  | $ | 2,213 |  |  | $ | 2,495 |  |  | $ | 2,213 |  |  | $ | 2,495 |  |

[0001564590-17-001635:8k_2_02:71]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q3 FY'17 |  |  | Q2 FY'17 |  |  | Q3 FY'16 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1) |  | $ | 784 |  |  | $ | 710 |  |  | $ | 750 |  |
| Strategic |  | $ | 512 |  |  | $ | 452 |  |  | $ | 419 |  |
| Mature |  | $ | 272 |  |  | $ | 258 |  |  | $ | 331 |  |
| Software Maintenance |  | $ | 240 |  |  | $ | 242 |  |  | $ | 234 |  |
| Hardware Maintenance and Other Services: |  | $ | 380 |  |  | $ | 388 |  |  | $ | 402 |  |
| Hardware Maintenance Support Contracts |  | $ | 313 |  |  | $ | 316 |  |  | $ | 326 |  |
| Professional and Other Services |  | $ | 67 |  |  | $ | 72 |  |  | $ | 76 |  |
| Net Revenues |  | $ | 1,404 |  |  | $ | 1,340 |  |  | $ | 1,386 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'17 Revenue |  |  | % of Q2 FY'17 Revenue |  |  | % of Q3 FY'16 Revenue |  |
| Americas |  |  | 55 | % |  |  | 57 | % |  |  | 54 | % |
| Americas Commercial |  |  | 44 | % |  |  | 42 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 16 | % |  |  | 10 | % |
| EMEA |  |  | 33 | % |  |  | 30 | % |  |  | 33 | % |
| Asia Pacific |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'17 Revenue |  |  | % of Q2 FY'17 Revenue |  |  | % of Q3 FY'16 Revenue |  |
| Direct |  |  | 21 | % |  |  | 22 | % |  |  | 22 | % |
| Indirect |  |  | 79 | % |  |  | 78 | % |  |  | 78 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'17 |  |  | Q2 FY'17 |  |  | Q3 FY'16 |  |
| Non-GAAP Gross Margin |  |  | 61.5 | % |  |  | 62.7 | % |  |  | 63.1 | % |
| Product |  |  | 45.7 | % |  |  | 48.2 | % |  |  | 51.1 | % |
| Software Maintenance |  |  | 97.1 | % |  |  | 97.1 | % |  |  | 96.2 | % |
| Hardware Maintenance and Other Services |  |  | 71.6 | % |  |  | 67.8 | % |  |  | 66.2 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'17 |  |  | Q2 FY'17 |  |  | Q3 FY'16 |  |
| Non-GAAP Income from Operations |  | $ | 284 |  |  | $ | 204 |  |  | $ | 244 |  |
| % of Net Revenues |  |  | 20.2 | % |  |  | 15.2 | % |  |  | 17.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 284 |  |  | $ | 204 |  |  | $ | 242 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.6 | % |  |  | 17.3 | % |  |  | 14.9 | % |

[0001564590-17-001635:8k_2_02:72]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'17 |  |  | Q2 FY'17 |  |  | Q3 FY'16 |  |
| Non-GAAP Net Income |  | $ | 231 |  |  | $ | 169 |  |  | $ | 206 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 281 |  |  |  | 284 |  |  |  | 296 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.82 |  |  | $ | 0.60 |  |  | $ | 0.70 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'17 |  |  | Q2 FY'17 |  |  | Q3 FY'16 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,234 |  |  | $ | 3,201 |  |  | $ | 3,126 |  |
| DSO (days) |  |  | 39 |  |  |  | 37 |  |  |  | 38 |  |
| DIO (days) |  |  | 21 |  |  |  | 17 |  |  |  | 17 |  |
| DPO (days) |  |  | 42 |  |  |  | 45 |  |  |  | 30 |  |
| CCC (days) |  |  | 17 |  |  |  | 9 |  |  |  | 26 |  |
| Inventory Turns |  |  | 18 |  |  |  | 21 |  |  |  | 21 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'17 |  |  | Q2 FY'17 |  |  | Q3 FY'16 |  |
| Net Cash Provided by Operating Activities |  | $ | 235 |  |  | $ | 158 |  |  | $ | 355 |  |
| Purchases of Property and Equipment |  | $ | 45 |  |  | $ | 56 |  |  | $ | 41 |  |
| Free Cash Flow |  | $ | 190 |  |  | $ | 102 |  |  | $ | 314 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 13.5 | % |  |  | 7.6 | % |  |  | 22.7 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |
| (1) Sales of certain products which should have been reported as strategic products were improperly reported as mature product revenues. All periods presented have been recast to reflect the appropriate classification. |  |

[0001564590-17-001635:8k_2_02:73]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| NET INCOME |  | $ | 146 |  |  | $ | 109 |  |  | $ | 153 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 51 |  |  |  | 63 |  |
| Restructuring and other charges |  |  | 52 |  |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | — |  |
| Income tax effect of non-GAAP adjustments |  |  | (16 | ) |  |  | (2 | ) |  |  | (26 | ) |
| NON-GAAP NET INCOME |  | $ | 231 |  |  | $ | 169 |  |  | $ | 206 |  |
| COST OF REVENUES |  | $ | 553 |  |  | $ | 511 |  |  | $ | 531 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (7 | ) |  |  | (13 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (6 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 541 |  |  | $ | 500 |  |  | $ | 512 |  |
| COST OF PRODUCT REVENUES |  | $ | 435 |  |  | $ | 376 |  |  | $ | 381 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (7 | ) |  |  | (13 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 426 |  |  | $ | 368 |  |  | $ | 367 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 111 |  |  | $ | 128 |  |  | $ | 141 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (5 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 108 |  |  | $ | 125 |  |  | $ | 136 |  |
| GROSS PROFIT |  | $ | 851 |  |  | $ | 829 |  |  | $ | 855 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 7 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 4 |  |  |  | 6 |  |
| NON-GAAP GROSS PROFIT |  | $ | 863 |  |  | $ | 840 |  |  | $ | 874 |  |

[0001564590-17-001635:8k_2_02:74]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| SALES AND MARKETING EXPENSES |  | $ | 381 |  |  | $ | 418 |  |  | $ | 418 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (4 | ) |  |  | (1 | ) |
| Stock-based compensation |  |  | (20 | ) |  |  | (21 | ) |  |  | (27 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 356 |  |  | $ | 393 |  |  | $ | 390 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 181 |  |  | $ | 200 |  |  | $ | 200 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (14 | ) |  |  | (17 | ) |  |  | (20 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 167 |  |  | $ | 183 |  |  | $ | 180 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 64 |  |  | $ | 69 |  |  | $ | 70 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8 | ) |  |  | (9 | ) |  |  | (10 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 56 |  |  | $ | 60 |  |  | $ | 60 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | 52 |  |  | $ | — |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (52 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OF PROPERTIES |  | $ | (10 | ) |  | $ | — |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | 10 |  |  |  | — |  |  |  | — |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 668 |  |  | $ | 687 |  |  | $ | 690 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (4 | ) |  |  | (1 | ) |
| Stock-based compensation |  |  | (42 | ) |  |  | (47 | ) |  |  | (57 | ) |
| Restructuring and other charges |  |  | (52 | ) |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Gain on sale of properties |  |  | 10 |  |  |  | — |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 579 |  |  | $ | 636 |  |  | $ | 630 |  |

[0001564590-17-001635:8k_2_02:75]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| INCOME FROM OPERATIONS |  | $ | 183 |  |  | $ | 142 |  |  | $ | 165 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 51 |  |  |  | 63 |  |
| Restructuring and other charges |  |  | 52 |  |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 284 |  |  | $ | 204 |  |  | $ | 244 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 183 |  |  | $ | 142 |  |  | $ | 163 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 51 |  |  |  | 63 |  |
| Restructuring and other charges |  |  | 52 |  |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 284 |  |  | $ | 204 |  |  | $ | 242 |  |
| PROVISION FOR INCOME TAXES |  | $ | 37 |  |  | $ | 33 |  |  | $ | 10 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 16 |  |  |  | 2 |  |  |  | 26 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 53 |  |  | $ | 35 |  |  | $ | 36 |  |
| NET INCOME PER SHARE |  | $ | 0.52 |  |  | $ | 0.38 |  |  | $ | 0.52 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.04 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.16 |  |  |  | 0.18 |  |  |  | 0.21 |  |
| Restructuring and other charges |  |  | 0.19 |  |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Gain on sale of properties |  |  | (0.04 | ) |  |  | — |  |  |  | — |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.06 | ) |  |  | (0.01 | ) |  |  | (0.09 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.82 |  |  | $ | 0.60 |  |  | $ | 0.70 |  |

[0001564590-17-001635:8k_2_02:76]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| Gross margin-GAAP |  |  | 60.6 | % |  |  | 61.9 | % |  |  | 61.7 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.8 | % |  |  | 1.4 | % |
| Gross margin-Non-GAAP |  |  | 61.5 | % |  |  | 62.7 | % |  |  | 63.1 | % |
| GAAP cost of revenues |  | $ | 553 |  |  | $ | 511 |  |  | $ | 531 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (7 | ) |  |  | (13 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (6 | ) |
| Non-GAAP cost of revenues |  | $ | 541 |  |  | $ | 500 |  |  | $ | 512 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,340 |  |  | $ | 1,386 |  |

[0001564590-17-001635:8k_2_02:77]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| Product gross margin-GAAP |  |  | 44.5 | % |  |  | 47.0 | % |  |  | 49.2 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 1.9 | % |
| Product gross margin-Non-GAAP |  |  | 45.7 | % |  |  | 48.2 | % |  |  | 51.1 | % |
| GAAP cost of product revenues |  | $ | 435 |  |  | $ | 376 |  |  | $ | 381 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (7 | ) |  |  | (13 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 426 |  |  | $ | 368 |  |  | $ | 367 |  |
| Product revenues |  | $ | 784 |  |  | $ | 710 |  |  | $ | 750 |  |

[0001564590-17-001635:8k_2_02:78]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 70.8 | % |  |  | 67.0 | % |  |  | 64.9 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 1.2 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 71.6 | % |  |  | 67.8 | % |  |  | 66.2 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 111 |  |  | $ | 128 |  |  | $ | 141 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (5 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 108 |  |  | $ | 125 |  |  | $ | 136 |  |
| Hardware maintenance and other services revenues |  | $ | 380 |  |  | $ | 388 |  |  | $ | 402 |  |

[0001564590-17-001635:8k_2_02:79]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| GAAP effective tax rate |  |  | 20.2 | % |  |  | 23.2 | % |  |  | 6.1 | % |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (1.6 | )% |  |  | (5.9 | )% |  |  | 8.8 | % |
| Non-GAAP effective tax rate |  |  | 18.6 | % |  |  | 17.3 | % |  |  | 14.9 | % |

[0001564590-17-001635:8k_2_02:80]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY17 |  |  | Q2'FY17 |  |  | Q3'FY16 |  |
| Net cash provided by operating activities |  | $ | 235 |  |  | $ | 158 |  |  | $ | 355 |  |
| Purchases of property and equipment |  |  | (45 | ) |  |  | (56 | ) |  |  | (41 | ) |
| Free cash flow |  | $ | 190 |  |  | $ | 102 |  |  | $ | 314 |  |

[0001564590-17-001635:8k_2_02:81]
Some items may not add or recalculate due to rounding.

[0001564590-17-001635:8k_2_02:82]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FOURTH QUARTER FISCAL 2017 |  |
|  |  | Fourth Quarter |  |
|  |  | Fiscal 2017 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.79 - $0.84 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Fourth Quarter Fiscal 2017: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.16 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.02 |  |
| Total Adjustments |  |  | (0.19 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.60 - $0.65 |  |

[0001564590-17-001635:8k_2_02:83]
Press Contact:

[0001564590-17-001635:8k_2_02:84]
Judy Radlinsky

[0001564590-17-001635:8k_2_02:85]
NetApp

[0001564590-17-001635:8k_2_02:86]
1 408 822 6527

[0001564590-17-001635:8k_2_02:87]
judy.radlinsky@netapp.com

[0001564590-17-001635:8k_2_02:88]
Investor Contact:

[0001564590-17-001635:8k_2_02:89]
Kris Newton

[0001564590-17-001635:8k_2_02:90]
NetApp

[0001564590-17-001635:8k_2_02:91]
1 408 822 3312

[0001564590-17-001635:8k_2_02:92]
kris.newton@netapp.com
