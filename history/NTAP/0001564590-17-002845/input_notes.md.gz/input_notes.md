# NTAP notes — 0001564590-17-002845


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-17-002845:notes:1]
[same as prior period, unchanged from 0001564590-16-029759:notes:1]

[0001564590-17-002845:notes:2]
[same as prior period, unchanged from 0001564590-16-029759:notes:2]

[0001564590-17-002845:notes:3]
[same as prior period, unchanged from 0001564590-16-029759:notes:3]

[0001564590-17-002845:notes:4]
[same as prior period, unchanged from 0001564590-16-029759:notes:4]

[0001564590-17-002845:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 27, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-17-002845:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-17-002845:notes:7]
Accounting Change – In the first quarter of fiscal 2017, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

[0001564590-17-002845:notes:8]
[same as prior period, unchanged from 0001564590-16-029759:notes:8]

[0001564590-17-002845:notes:9]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $18 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the nine months ended January 27, 2017.

[0001564590-17-002845:notes:10]
[same as prior period, unchanged from 0001564590-16-029759:notes:10]

[0001564590-17-002845:notes:11]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 27, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-17-002845:notes:12]
[same as prior period, unchanged from 0001564590-16-029759:notes:12]

[0001564590-17-002845:notes:13]
Non-cash investing and financing activities and supplemental cash flow information are as follows (in millions):

[0001564590-17-002845:notes:14]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 13 |  |  | $ | 14 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | 19 |  |  | $ | — |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 90 |  |  | $ | 113 |  |
| Interest paid |  | $ | 43 |  |  | $ | 40 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-17-002845:notes:15]
[same as prior period, unchanged from 0001564590-16-029759:notes:15]

[0001564590-17-002845:notes:16]
[same as prior period, unchanged from 0001564590-16-029759:notes:16]

[0001564590-17-002845:notes:17]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 148 |  |  | $ | (36 | ) |  | $ | 112 |  |  | $ | 403 |  |  | $ | (289 | ) |  | $ | 114 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (15 | ) |  |  | 28 |  |  |  | 46 |  |  |  | (7 | ) |  |  | 39 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (4 | ) |  |  | 5 |  |  |  | 10 |  |  |  | (2 | ) |  |  | 8 |  |
| Total intangible assets subject to amortization |  |  | 200 |  |  |  | (55 | ) |  |  | 145 |  |  |  | 459 |  |  |  | (298 | ) |  |  | 161 |  |
| In-process research and development |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Total purchased intangible assets |  | $ | 200 |  |  | $ | (55 | ) |  | $ | 145 |  |  | $ | 478 |  |  | $ | (298 | ) |  | $ | 180 |  |

[0001564590-17-002845:notes:18]
As of January 27, 2017, the in-process research and development project related to the SolidFire acquisition had been completed, and the associated intangible asset was included in developed technology.

[0001564590-17-002845:notes:19]
[same as prior period, unchanged from 0001564590-16-029759:notes:19]

[0001564590-17-002845:notes:20]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statement of |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | Operations Classifications |
| Developed technology |  | $ | 8 |  |  | $ | 13 |  |  | $ | 21 |  |  | $ | 41 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 4 |  |  |  | 1 |  |  |  | 11 |  |  |  | 1 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 13 |  |  | $ | 14 |  |  | $ | 35 |  |  | $ | 42 |  |  |  |

[0001564590-17-002845:notes:21]
As of January 27, 2017, future amortization expense related to purchased intangible assets subject to amortization is as follows (in millions):

[0001564590-17-002845:notes:22]
| Fiscal Year |  | Amount |  |
| Remainder of 2017 |  | $ | 13 |  |
| 2018 |  |  | 49 |  |
| 2019 |  |  | 42 |  |
| 2020 |  |  | 26 |  |
| 2021 |  |  | 15 |  |
| Total |  | $ | 145 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-002845:notes:23]
[same as prior period, unchanged from 0001564590-16-029759:notes:23]

[0001564590-17-002845:notes:24]
[same as prior period, unchanged from 0001564590-16-029759:notes:24]

[0001564590-17-002845:notes:25]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Cash |  | $ | 1,989 |  |  | $ | 2,714 |  |
| Cash equivalents |  |  | 224 |  |  |  | 154 |  |
| Cash and cash equivalents |  | $ | 2,213 |  |  | $ | 2,868 |  |

[0001564590-17-002845:notes:26]
[same as prior period, unchanged from 0001564590-16-029759:notes:26]

[0001564590-17-002845:notes:27]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Purchased components |  | $ | 19 |  |  | $ | 10 |  |
| Finished goods |  |  | 106 |  |  |  | 88 |  |
| Inventories |  | $ | 125 |  |  | $ | 98 |  |

[0001564590-17-002845:notes:28]
[same as prior period, unchanged from 0001564590-16-029759:notes:28]

[0001564590-17-002845:notes:29]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Land |  | $ | 183 |  |  | $ | 215 |  |
| Buildings and improvements |  |  | 695 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 101 |  |  |  | 106 |  |
| Computer, production, engineering and other equipment |  |  | 756 |  |  |  | 751 |  |
| Computer software |  |  | 352 |  |  |  | 352 |  |
| Furniture and fixtures |  |  | 98 |  |  |  | 88 |  |
| Construction-in-progress |  |  | 11 |  |  |  | 74 |  |
|  |  |  | 2,196 |  |  |  | 2,191 |  |
| Accumulated depreciation and amortization |  |  | (1,304 | ) |  |  | (1,254 | ) |
| Property and equipment, net |  | $ | 892 |  |  | $ | 937 |  |

[0001564590-17-002845:notes:30]
As of January 27, 2017, we classified certain land previously reported as property and equipment as assets held-for-sale because we expect to sell it within the next twelve months. The book value of the land was $24 million as of January 27, 2017 and is included in other current assets in the condensed consolidated balance sheets.

[0001564590-17-002845:notes:31]
In addition, during the three months ended January 27, 2017, we recognized the sale of a portion of our properties that were subject to a sale-leaseback arrangement as further discussed in Note 8.

[0001564590-17-002845:notes:32]
[same as prior period, unchanged from 0001564590-16-029759:notes:30]

[0001564590-17-002845:notes:33]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Deferred tax assets |  | $ | 533 |  |  | $ | 621 |  |
| Other assets |  |  | 163 |  |  |  | 175 |  |
| Other non-current assets |  | $ | 696 |  |  | $ | 796 |  |

[0001564590-17-002845:notes:34]
[same as prior period, unchanged from 0001564590-16-029759:notes:32]

[0001564590-17-002845:notes:35]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Accrued compensation and benefits |  | $ | 307 |  |  | $ | 371 |  |
| Sale-leaseback financing obligations |  |  | 130 |  |  |  | — |  |
| Product warranty liability |  |  | 34 |  |  |  | 48 |  |
| Other current liabilities |  |  | 276 |  |  |  | 346 |  |
| Accrued expenses |  | $ | 747 |  |  | $ | 765 |  |

[0001564590-17-002845:notes:36]
[same as prior period, unchanged from 0001564590-16-029759:notes:34]

[0001564590-17-002845:notes:37]
[same as prior period, unchanged from 0001564590-16-029759:notes:35]

[0001564590-17-002845:notes:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Balance at beginning of period |  | $ | 54 |  |  | $ | 80 |  |  | $ | 70 |  |  | $ | 86 |  |
| Expense accrued during the period |  |  | 4 |  |  |  | 5 |  |  |  | 9 |  |  |  | 27 |  |
| Warranty costs incurred |  |  | (8 | ) |  |  | (12 | ) |  |  | (29 | ) |  |  | (40 | ) |
| Balance at end of period |  | $ | 50 |  |  | $ | 73 |  |  | $ | 50 |  |  | $ | 73 |  |

[0001564590-17-002845:notes:39]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Accrued expenses |  | $ | 34 |  |  | $ | 48 |  |
| Other long-term liabilities |  |  | 16 |  |  |  | 22 |  |
| Total warranty liabilities |  | $ | 50 |  |  | $ | 70 |  |

[0001564590-17-002845:notes:40]
[same as prior period, unchanged from 0001564590-16-029759:notes:38]

[0001564590-17-002845:notes:41]
[same as prior period, unchanged from 0001564590-16-029759:notes:39]

[0001564590-17-002845:notes:42]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Deferred product revenue |  | $ | 97 |  |  | $ | 68 |  |
| Deferred services revenue |  |  | 2,941 |  |  |  | 3,100 |  |
| Financed unearned services revenue |  |  | 196 |  |  |  | 217 |  |
| Total |  | $ | 3,234 |  |  | $ | 3,385 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,699 |  |  | $ | 1,794 |  |
| Long-term |  |  | 1,535 |  |  |  | 1,591 |  |
| Total |  | $ | 3,234 |  |  | $ | 3,385 |  |

[0001564590-17-002845:notes:43]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-17-002845:notes:44]
[same as prior period, unchanged from 0001564590-16-029759:notes:42]

[0001564590-17-002845:notes:45]
[same as prior period, unchanged from 0001564590-16-029759:notes:43]

[0001564590-17-002845:notes:46]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Interest income |  | $ | 10 |  |  | $ | 11 |  |  | $ | 31 |  |  | $ | 35 |  |
| Interest expense |  |  | (12 | ) |  |  | (11 | ) |  |  | (39 | ) |  |  | (34 | ) |
| Other income (expense), net |  |  | 2 |  |  |  | (2 | ) |  |  | 7 |  |  |  | — |  |
| Total other income (expense), net |  | $ | — |  |  | $ | (2 | ) |  | $ | (1 | ) |  | $ | 1 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-17-002845:notes:47]
[same as prior period, unchanged from 0001564590-16-029759:notes:45]

[0001564590-17-002845:notes:48]
[same as prior period, unchanged from 0001564590-16-029759:notes:46]

[0001564590-17-002845:notes:49]
[same as prior period, unchanged from 0001564590-16-029759:notes:47]

[0001564590-17-002845:notes:50]
[same as prior period, unchanged from 0001564590-16-029759:notes:48]

[0001564590-17-002845:notes:51]
[same as prior period, unchanged from 0001564590-16-029759:notes:49]

[0001564590-17-002845:notes:52]
[same as prior period, unchanged from 0001564590-16-029759:notes:50]

[0001564590-17-002845:notes:53]
[same as prior period, unchanged from 0001564590-16-029759:notes:51]

[0001564590-17-002845:notes:54]
[same as prior period, unchanged from 0001564590-16-029759:notes:52]

[0001564590-17-002845:notes:55]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,411 |  |  | $ | 2 |  |  | $ | (3 | ) |  | $ | 1,410 |  |  | $ | 1,370 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 1,374 |  |
| U.S. Treasury and government debt securities |  |  | 688 |  |  |  | — |  |  |  | (3 | ) |  |  | 685 |  |  |  | 878 |  |  |  | 2 |  |  |  | — |  |  |  | 880 |  |
| Foreign government debt securities |  |  | 27 |  |  |  | — |  |  |  | — |  |  |  | 27 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Commercial paper |  |  | 426 |  |  |  | — |  |  |  | — |  |  |  | 426 |  |  |  | 202 |  |  |  | — |  |  |  | — |  |  |  | 202 |  |
| Certificates of deposit |  |  | 102 |  |  |  | — |  |  |  | — |  |  |  | 102 |  |  |  | 98 |  |  |  | — |  |  |  | — |  |  |  | 98 |  |
| Mutual funds |  |  | 30 |  |  |  | — |  |  |  | — |  |  |  | 30 |  |  |  | 30 |  |  |  | — |  |  |  | — |  |  |  | 30 |  |
| Total debt and equity securities |  | $ | 2,684 |  |  | $ | 2 |  |  | $ | (6 | ) |  | $ | 2,680 |  |  | $ | 2,613 |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 2,619 |  |

[0001564590-17-002845:notes:56]
As of January 27, 2017, gross unrealized losses related to individual securities were not significant.

[0001564590-17-002845:notes:57]
The following table presents the contractual maturities of our debt investments as of January 27, 2017 (in millions):

[0001564590-17-002845:notes:58]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,281 |  |  | $ | 1,281 |  |
| Due after one year through five years |  |  | 1,363 |  |  |  | 1,359 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
| Due after ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 2,654 |  |  | $ | 2,650 |  |

[0001564590-17-002845:notes:59]
[same as prior period, unchanged from 0001564590-16-029759:notes:57]

[0001564590-17-002845:notes:60]
[same as prior period, unchanged from 0001564590-16-029759:notes:58]

[0001564590-17-002845:notes:61]
[same as prior period, unchanged from 0001564590-16-029759:notes:59]

[0001564590-17-002845:notes:62]
|  |  | January 27, 2017 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 1,989 |  |  | $ | 1,989 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,410 |  |  |  | — |  |  |  | 1,410 |  |
| U.S. Treasury and government debt securities |  |  | 685 |  |  |  | 270 |  |  |  | 415 |  |
| Foreign government debt securities |  |  | 27 |  |  |  | — |  |  |  | 27 |  |
| Commercial paper |  |  | 426 |  |  |  | — |  |  |  | 426 |  |
| Certificates of deposit |  |  | 102 |  |  |  | — |  |  |  | 102 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,639 |  |  | $ | 2,259 |  |  | $ | 2,380 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 23 |  |  | $ | 23 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001564590-17-002845:notes:63]
[same as prior period, unchanged from 0001564590-16-029759:notes:61]

[0001564590-17-002845:notes:64]
[same as prior period, unchanged from 0001564590-16-029759:notes:62]

[0001564590-17-002845:notes:65]
[same as prior period, unchanged from 0001564590-16-029759:notes:63]

[0001564590-17-002845:notes:66]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 27, 2017 and April 29, 2016, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-17-002845:notes:67]
Fair Value of Debt

[0001564590-17-002845:notes:68]
As of January 27, 2017 and April 29, 2016, the fair value of our long-term debt was approximately $1,511 million and $1,519 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-17-002845:notes:69]
8. Financing Arrangements

[0001564590-17-002845:notes:70]
Long-Term Debt

[0001564590-17-002845:notes:71]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-17-002845:notes:72]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total senior notes |  |  | 1,492 |  |  |  |  |  |  |  | 1,490 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (748 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 744 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |

[0001564590-17-002845:notes:73]
Senior Notes

[0001564590-17-002845:notes:74]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-17-002845:notes:75]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 27, 2017, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-17-002845:notes:76]
As of January 27, 2017, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-17-002845:notes:77]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-17-002845:notes:78]
Commercial Paper Program and Credit Facility

[0001564590-17-002845:notes:79]
In December 2016, we entered into a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $600 million. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes will be used for general corporate purposes. As of January 27, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $392 million, a weighted-average interest rate of 1.10% and maturities ranging from 20 days to 36 days.

[0001564590-17-002845:notes:80]
In connection with the Program, we entered into a new senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021, and we terminated our existing credit agreement that had been scheduled to expire on December 21, 2017. The new credit agreement provides a $600 million revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 27, 2017, no borrowings or letters of credit were outstanding under this facility, and we were in compliance with all associated covenants.

[0001564590-17-002845:notes:81]
Short-Term Loan

[0001564590-17-002845:notes:82]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of January 27, 2017, we have repaid the loan in full and have terminated the related loan agreement.

[0001564590-17-002845:notes:83]
Sale-leaseback Transactions

[0001564590-17-002845:notes:84]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. During the three months ended January 27, 2017, we terminated one of the leases, ending our continuing involvement with the related properties. As a result, we recorded a non-cash sale of properties having a net book value of $9 million, the extinguishment of $19 million of associated financing obligations, and a gain of $10 million. As of January 27, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-17-002845:notes:85]
[same as prior period, unchanged from 0001564590-16-029759:notes:83]

[0001564590-17-002845:notes:86]
[same as prior period, unchanged from 0001564590-16-029759:notes:84]

[0001564590-17-002845:notes:87]
As of January 27, 2017, we have outstanding certain equity incentive awards (awards), which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-17-002845:notes:88]
[same as prior period, unchanged from 0001564590-16-029759:notes:86]

[0001564590-17-002845:notes:89]
[same as prior period, unchanged from 0001564590-16-029759:notes:87]

[0001564590-17-002845:notes:90]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2 | ) |  | $ | 22.13 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 39.44 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 27, 2017 |  |  | 5 |  |  | $ | 35.01 |  |  |  | 3.42 |  |  | $ | 33 |  |
| Exercisable as of January 27, 2017 |  |  | 4 |  |  | $ | 40.19 |  |  |  | 2.50 |  |  | $ | 10 |  |

[0001564590-17-002845:notes:91]
[same as prior period, unchanged from 0001564590-16-029759:notes:89]

[0001564590-17-002845:notes:92]
[same as prior period, unchanged from 0001564590-16-029759:notes:90]

[0001564590-17-002845:notes:93]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Intrinsic value of exercises |  | $ | 18 |  |  | $ | 12 |  |
| Proceeds received from exercises |  | $ | 33 |  |  | $ | 24 |  |
| Fair value of options vested |  | $ | 12 |  |  | $ | 10 |  |

[0001564590-17-002845:notes:94]
[same as prior period, unchanged from 0001564590-16-029759:notes:92]

[0001564590-17-002845:notes:95]
In the nine months ended January 27, 2017, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of fiscal 2018 or 2019, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $15 million is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-17-002845:notes:96]
[same as prior period, unchanged from 0001564590-16-029759:notes:94]

[0001564590-17-002845:notes:97]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |
| Granted |  |  | 5 |  |  | $ | 24.42 |  |
| Vested |  |  | (5 | ) |  | $ | 32.69 |  |
| Forfeited |  |  | (2 | ) |  | $ | 32.01 |  |
| Outstanding as of January 27, 2017 |  |  | 11 |  |  | $ | 28.46 |  |

[0001564590-17-002845:notes:98]
[same as prior period, unchanged from 0001564590-16-029759:notes:96]

[0001564590-17-002845:notes:99]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 42 |  |  | $ | 47 |  |

[0001564590-17-002845:notes:100]
[same as prior period, unchanged from 0001564590-16-029759:notes:98]

[0001564590-17-002845:notes:101]
[same as prior period, unchanged from 0001564590-16-029759:notes:99]

[0001564590-17-002845:notes:102]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Shares issued under the ESPP |  |  | 4 |  |  |  | 3 |  |
| Proceeds from issuance of shares |  | $ | 80 |  |  | $ | 93 |  |

[0001564590-17-002845:notes:103]
[same as prior period, unchanged from 0001564590-16-029759:notes:101]

[0001564590-17-002845:notes:104]
[same as prior period, unchanged from 0001564590-16-029759:notes:102]

[0001564590-17-002845:notes:105]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 4 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 5 |  |  |  | 10 |  |  |  | 15 |  |
| Sales and marketing |  |  | 20 |  |  |  | 27 |  |  |  | 64 |  |  |  | 84 |  |
| Research and development |  |  | 14 |  |  |  | 20 |  |  |  | 46 |  |  |  | 64 |  |
| General and administrative |  |  | 8 |  |  |  | 10 |  |  |  | 26 |  |  |  | 32 |  |
| Total stock-based compensation expense |  | $ | 46 |  |  | $ | 63 |  |  | $ | 149 |  |  | $ | 199 |  |

[0001564590-17-002845:notes:106]
As of January 27, 2017, total unrecognized compensation expense related to our equity awards was $257 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.0 years.

[0001564590-17-002845:notes:107]
[same as prior period, unchanged from 0001564590-16-029759:notes:105]

[0001564590-17-002845:notes:108]
As of January 27, 2017, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-17-002845:notes:109]
The following table summarizes activity related to this program for the nine months ended January 27, 2017 (in millions, except per share amounts):

[0001564590-17-002845:notes:110]
| Number of shares repurchased |  |  | 18 |  |
| Average price per share |  | $ | 31.19 |  |
| Aggregate purchase price |  | $ | 576 |  |
| Remaining authorization at end of period |  | $ | 924 |  |

[0001564590-17-002845:notes:111]
The aggregate purchase price of our stock repurchases for the nine months ended January 27, 2017 consisted of $576 million of open market purchases, of which $305 million and $271 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-17-002845:notes:112]
Since the May 13, 2003 inception of our stock repurchase program through January 27, 2017, we repurchased a total of 266 million shares of our common stock at an average price of $32.74 per share, for an aggregate purchase price of $8.7 billion.

[0001564590-17-002845:notes:113]
[same as prior period, unchanged from 0001564590-16-029759:notes:111]

[0001564590-17-002845:notes:114]
[same as prior period, unchanged from 0001564590-16-029759:notes:112]

[0001564590-17-002845:notes:115]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Dividends per share declared |  | $ | 0.57 |  |  | $ | 0.54 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 88 |  |  | $ | 84 |  |
| Dividend payments allocated to retained earnings |  | $ | 69 |  |  | $ | 75 |  |

[0001564590-17-002845:notes:116]
On February 15, 2017, we declared a cash dividend of $0.19 per share of common stock, payable on April 26, 2017 to holders of record as of the close of business on April 7, 2017. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-17-002845:notes:117]
[same as prior period, unchanged from 0001564590-16-029759:notes:115]

[0001564590-17-002845:notes:118]
[same as prior period, unchanged from 0001564590-16-029759:notes:116]

[0001564590-17-002845:notes:119]
| Balance as of April 29, 2016 |  | $ | — |  |
| Cumulative-effect of new accounting principle |  |  | 21 |  |
| Net income |  |  | 319 |  |
| Repurchases of common stock |  |  | (271 | ) |
| Dividends |  |  | (69 | ) |
| Balance as of January 27, 2017 |  | $ | — |  |

[0001564590-17-002845:notes:120]
[same as prior period, unchanged from 0001564590-16-029759:notes:118]

[0001564590-17-002845:notes:121]
[same as prior period, unchanged from 0001564590-16-029759:notes:119]

[0001564590-17-002845:notes:122]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments (1) |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 29, 2016 |  | $ | (19 | ) |  | $ | (16 | ) |  | $ | 6 |  |  | $ | (2 | ) |  | $ | (31 | ) |
| OCI before reclassifications, net of tax |  |  | (14 | ) |  |  | 15 |  |  |  | (10 | ) |  |  | 8 |  |  |  | (1 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | (6 | ) |  |  | (5 | ) |
| Total OCI |  |  | (14 | ) |  |  | 16 |  |  |  | (10 | ) |  |  | 2 |  |  |  | (6 | ) |
| Balance as of January 27, 2017 |  | $ | (33 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (37 | ) |

[0001564590-17-002845:notes:123]
(1) See Note 15 – Employee Benefits for details of defined benefit obligation adjustments resulting from amendments made to our postretirement healthcare plan.

[0001564590-17-002845:notes:124]
[same as prior period, unchanged from 0001564590-16-029759:notes:121]

[0001564590-17-002845:notes:125]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  | Other income (expense), net |
| Realized gains on cash flow hedges |  |  | (5 | ) |  |  | (2 | ) |  |  | (6 | ) |  |  | — |  |  | Net revenues |
| Total reclassifications |  | $ | (5 | ) |  | $ | (2 | ) |  | $ | (5 | ) |  | $ | 1 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-002845:notes:126]
[same as prior period, unchanged from 0001564590-16-029759:notes:123]

[0001564590-17-002845:notes:127]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 27, 2017 and April 29, 2016. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-17-002845:notes:128]
[same as prior period, unchanged from 0001564590-16-029759:notes:125]

[0001564590-17-002845:notes:129]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 128 |  |  | $ | 99 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 166 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 377 |  |  | $ | 396 |  |

[0001564590-17-002845:notes:130]
[same as prior period, unchanged from 0001564590-16-029759:notes:127]

[0001564590-17-002845:notes:131]
[same as prior period, unchanged from 0001564590-16-029759:notes:128]

[0001564590-17-002845:notes:132]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
|  |  | Gain Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 2 |  |  | $ | 1 |  |  | $ | 8 |  |  | $ | (6 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-002845:notes:133]
11. Restructuring Charges

[0001564590-17-002845:notes:134]
During the three months ended January 27, 2017, we announced a restructuring plan (the November 2016 Plan) to streamline our core business and decrease operating expenses, which included a reduction in our global workforce of approximately 6%. We expect to complete the November 2016 Plan by the fourth quarter of fiscal 2017 with no significant additional charges.

[0001564590-17-002845:notes:135]
During fiscal 2016, management approved two restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities. These actions consisted of the May 2015 Plan and the March 2016 Plan, under which we reduced our global workforce by an aggregate of approximately 14%. These plans have been completed as of January 27, 2017.

[0001564590-17-002845:notes:136]
Restructuring charges related to each of these plans consisted primarily of employee severance-related costs.

[0001564590-17-002845:notes:137]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001564590-17-002845:notes:138]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
|  |  | November 2016 Plan |  |  | March 2016 Plan |  |  | Total |  |  | May 2015 Plan |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 45 |  |  | $ | 45 |  |  | $ | — |  |
| Net charges |  |  | 52 |  |  |  | — |  |  |  | 52 |  |  |  | 28 |  |
| Cash payments |  |  | (27 | ) |  |  | (45 | ) |  |  | (72 | ) |  |  | (28 | ) |
| Balance at end of period |  | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-002845:notes:139]
[same as prior period, unchanged from 0001564590-16-029759:notes:134]

[0001564590-17-002845:notes:140]
[same as prior period, unchanged from 0001564590-16-029759:notes:135]

[0001564590-17-002845:notes:141]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Effective tax rates |  |  | 23.5 | % |  |  | 16.8 | % |

[0001564590-17-002845:notes:142]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The differences in effective tax rates for the nine months ended January 27, 2017 and January 29, 2016 were primarily a result of differences in year-to-date profits before tax and the impacts of discrete events as described below.

[0001564590-17-002845:notes:143]
During the first quarter of fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During the nine months ended January 27, 2017, we recorded discrete charges of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense. See Note 1 – Description of Business and Significant Accounting Policies for more details regarding the adoption of this accounting standard.

[0001564590-17-002845:notes:144]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During the nine months ended January 29, 2016, we recorded discrete charges totaling $23 million, attributable to the audit settlements and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-17-002845:notes:145]
[same as prior period, unchanged from 0001564590-16-029759:notes:140]

[0001564590-17-002845:notes:146]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Balance at beginning of period |  | $ | 216 |  |  | $ | 272 |  |
| Additions based on tax positions related to the current year |  |  | 5 |  |  |  | 13 |  |
| Additions for tax positions of prior years |  |  | 6 |  |  |  | 21 |  |
| Decreases for tax positions of prior years |  |  | — |  |  |  | (38 | ) |
| Settlements |  |  | (12 | ) |  |  | (52 | ) |
| Balance at end of period |  | $ | 215 |  |  | $ | 216 |  |

[0001564590-17-002845:notes:147]
As of January 27, 2017, we had $215 million of gross unrecognized tax benefits, of which $147 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $157 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-002845:notes:148]
[same as prior period, unchanged from 0001564590-16-029759:notes:143]

[0001564590-17-002845:notes:149]
[same as prior period, unchanged from 0001564590-16-029759:notes:144]

[0001564590-17-002845:notes:150]
[same as prior period, unchanged from 0001564590-16-029759:notes:145]


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-002845:notes:151]
[same as prior period, unchanged from 0001564590-16-029759:notes:146]

[0001564590-17-002845:notes:152]
[same as prior period, unchanged from 0001564590-16-029759:notes:147]

[0001564590-17-002845:notes:153]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 146 |  |  | $ | 153 |  |  | $ | 319 |  |  | $ | 237 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 274 |  |  |  | 293 |  |  |  | 277 |  |  |  | 297 |  |
| Dilutive impact of employee equity award plans |  |  | 7 |  |  |  | 3 |  |  |  | 5 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 281 |  |  |  | 296 |  |  |  | 282 |  |  |  | 300 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.53 |  |  | $ | 0.52 |  |  | $ | 1.15 |  |  | $ | 0.80 |  |
| Diluted |  | $ | 0.52 |  |  | $ | 0.52 |  |  | $ | 1.13 |  |  | $ | 0.79 |  |

[0001564590-17-002845:notes:154]
In the three months ended January 27, 2017 and January 29, 2016, we have excluded from the diluted net income per share calculations 4 million and 11 million shares, respectively, and in the nine months ended January 27, 2017 and January 29, 2016, we have excluded 8 million and 13 million shares, respectively, of common stock potentially issuable under employee equity award plans as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-002845:notes:155]
[same as prior period, unchanged from 0001564590-16-029759:notes:150]

[0001564590-17-002845:notes:156]
[same as prior period, unchanged from 0001564590-16-029759:notes:151]

[0001564590-17-002845:notes:157]
[same as prior period, unchanged from 0001564590-16-029759:notes:152]

[0001564590-17-002845:notes:158]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| United States, Canada and Latin America (Americas) |  | $ | 767 |  |  | $ | 752 |  |  | $ | 2,271 |  |  | $ | 2,316 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 460 |  |  |  | 456 |  |  |  | 1,243 |  |  |  | 1,301 |  |
| Asia Pacific (APAC) |  |  | 177 |  |  |  | 178 |  |  |  | 524 |  |  |  | 549 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,386 |  |  | $ | 4,038 |  |  | $ | 4,166 |  |

[0001564590-17-002845:notes:159]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $684 million and $664 million during the three months ended January 27, 2017 and January 29, 2016, respectively, and were $2,047 million and $2,072 million during the nine months ended January 27, 2017 and January 29, 2016, respectively.

[0001564590-17-002845:notes:160]
[same as prior period, unchanged from 0001564590-16-029759:notes:155]

[0001564590-17-002845:notes:161]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 531 |  |  | $ | 513 |  |
| International |  |  | 4,108 |  |  |  | 4,790 |  |
| Total |  | $ | 4,639 |  |  | $ | 5,303 |  |

[0001564590-17-002845:notes:162]
[same as prior period, unchanged from 0001564590-16-029759:notes:157]

[0001564590-17-002845:notes:163]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 708 |  |  | $ | 797 |  |
| International |  |  | 184 |  |  |  | 140 |  |
| Total |  | $ | 892 |  |  | $ | 937 |  |

[0001564590-17-002845:notes:164]
[same as prior period, unchanged from 0001564590-16-029759:notes:159]

[0001564590-17-002845:notes:165]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2017 |  |  | January 29, 2016 |  |  | January 27, 2017 |  |  | January 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 21 | % |  |  | 21 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 20 | % |  |  | 19 | % |  |  | 20 | % |  |  | 19 | % |

[0001564590-17-002845:notes:166]
[same as prior period, unchanged from 0001564590-16-029759:notes:161]

[0001564590-17-002845:notes:167]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 12 | % |
| Avnet, Inc. |  | N/A |  |  |  | 15 | % |

[0001564590-17-002845:notes:168]
N/A - Not applicable


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-17-002845:notes:169]
15. Postretirement Health Care Plan

[0001564590-17-002845:notes:170]
Certain of our executive officers are eligible to participate in our Executive Retirement Medical Plan (the ERM Plan). The ERM Plan provides, upon retirement, medical benefits beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, years of service and position. The ERM Plan is unfunded as of April 29, 2016 and January 31, 2017, and there is no minimum funding requirement under the ERM Plan.

[0001564590-17-002845:notes:171]
In November 2016, we made certain amendments to the ERM Plan, which prior to amendment, provided group health insurance benefits to eligible retirees. Effective January 1, 2017, the amended ERM Plan provides each eligible retiree with a capped reimbursement of premiums for the period from January 1, 2017 through December 31, 2019. During the period from December 31, 2019 through December 31, 2021, participants in the ERM Plan will be eligible to receive a lump sum cash payment equal to two years of projected health care costs, or a prorated portion thereof, pursuant to the methodology set forth in the ERM Plan. Such payment will be made by us outside the ERM Plan as the ERM Plan is expected to terminate on December 31, 2019.

[0001564590-17-002845:notes:172]
These plan amendments resulted in a prior service credit adjustment, with the following impacts to our condensed consolidated financial statements in the three and nine months ended January 27, 2017 (in millions):

[0001564590-17-002845:notes:173]
| Decrease in other long-term liabilities |  | $ | 23 |  |
| Decrease in deferred tax assets |  | $ | 9 |  |
| Other comprehensive income, net of taxes |  | $ | 14 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-002845:notes:174]
16. Commitments and Contingencies

[0001564590-17-002845:notes:175]
Operating Leases

[0001564590-17-002845:notes:176]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $227 million as of January 27, 2017.

[0001564590-17-002845:notes:177]
Purchase Orders and Other Commitments

[0001564590-17-002845:notes:178]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 27, 2017, we had $313 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2017 and April 29, 2016, such liability amounted to $11 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-002845:notes:179]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 27, 2017, we had $20 million in construction related obligations and $220 million in other purchase obligations.

[0001564590-17-002845:notes:180]
Financing Guarantees

[0001564590-17-002845:notes:181]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $142 million and $153 million of receivables during the nine months ended January 27, 2017 and January 29, 2016, respectively.

[0001564590-17-002845:notes:182]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-17-002845:notes:183]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 27, 2017 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-002845:notes:184]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 27, 2017, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-17-002845:notes:185]
Legal Contingencies

[0001564590-17-002845:notes:186]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-17-002845:notes:187]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 27, 2017 related to such matters as they are not probable and/or reasonably estimable.
