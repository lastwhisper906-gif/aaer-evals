# NTAP note change history — 0001193125-13-084667 → 0001193125-13-352036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:1]
Operating Lease Commitments
  (was, 2013-02-28, similarity 0.7727):
[0001193125-13-084667:note_history:1]
Lease
Commitments

- changed (2013-08-29):
[0001193125-13-352036:note_history:2]
As of July 26, 2013, future annual minimum lease payments
 under non-cancelable operating leases with an initial term in
 excess of one year totaled $217.1 million.
  (was, 2013-02-28, similarity 0.6788):
[0001193125-13-084667:note_history:2]
As of January 25, 2013, future annual minimum lease
payments under all non-cancelable facilities and equipment
operating leases with an initial term in excess of one year totaled
$222.5 million. In the three months ended January 25, 2013, we
terminated all of our remaining synthetic lease
arrangements.

- changed (2013-08-29):
[0001193125-13-352036:note_history:3]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of July 26, 2013, we had $336.3 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product sales. As of
 July 26, 2013 and April 26, 2013, such liability amounted
 to $9.3 million and $9.5 million, respectively, and is included in
 other current liabilities in our condensed consolidated balance
 sheets.
  (was, 2013-02-28, similarity 0.9905):
[0001193125-13-084667:note_history:3]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. As of January 25, 2013, we had $282.4 million in
non-cancelable purchase commitments with our contract
manufacturers. In addition, we recorded a liability for firm,
non-cancelable and unconditional purchase commitments with contract
manufacturers for quantities in excess of our future demand
forecasts through a charge to cost of product sales. As of
January 25, 2013 and April 27, 2012, such liability
amounted to $8.1 million and $3.3 million, respectively, and is
included in other current liabilities in the condensed consolidated
balance sheets.

- changed (2013-08-29):
[0001193125-13-352036:note_history:4]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course business for which
 we have not received goods or services. As of July 26, 2013,
 we had $71.5 million in capital purchase commitments and $181.2
 million in other purchase commitments.
  (was, 2013-02-28, similarity 0.9898):
[0001193125-13-084667:note_history:4]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of January 25,
2013, we had $93.6 million in capital purchase commitments and
$182.3 million in other purchase commitments.

- added (2013-08-29):
[0001193125-13-352036:note_history:5]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Beginning balance |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 24.0 |  |  |  | 23.7 |  |
| Warranty costs incurred |  |  | (21.4 | ) |  |  | (10.3 | ) |
| Ending balance |  | $ | 119.8 |  |  | $ | 96.5 |  |

- added (2013-08-29):
[0001193125-13-352036:note_history:6]
Our warranty reserves were reported in our condensed
 consolidated balance sheets as follows (in millions):

- added (2013-08-29):
[0001193125-13-352036:note_history:7]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 81.8 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 38.0 |  |  |  | 35.6 |  |
| Total |  | $ | 119.8 |  |  | $ | 117.2 |  |

- changed (2013-08-29):
[0001193125-13-352036:note_history:8]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 nonrecourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.
  (was, 2013-02-28, similarity 0.8791):
[0001193125-13-084667:note_history:8]
Some of our customers have entered into recourse and
non-recourse financing leasing arrangements using third-party
financing companies, and in some situations, we enter into customer
financing arrangements for our products and services that are
contemporaneously sold on a recourse or non-recourse basis to
third-party financing companies. Under the terms of recourse
leases, which are generally three years or less, we remain liable
for the aggregate unpaid remaining lease payments to the
third-party leasing companies in the event of end-user customer
default. These arrangements are generally collateralized by a
security interest in the underlying assets. Under the terms of the
nonrecourse leases, we do not have any continuing obligations or
liabilities to the third-party financing companies. Where we
provide a guarantee for recourse leases, we defer revenues subject
to the industry-specific software revenue recognition guidance, and
recognize revenues for non-software deliverables in accordance with
our multiple deliverable revenue arrangement policy.

- added (2013-08-29):
[0001193125-13-352036:note_history:9]
The following schedule of financing guarantees represents the
 total maximum potential future payments under financing
 arrangements with third parties, and the related deferred revenue
 (in millions):

- added (2013-08-29):
[0001193125-13-352036:note_history:10]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 196.1 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (180.8 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 15.3 |  |  | $ | 13.8 |  |

- changed (2013-08-29):
[0001193125-13-352036:note_history:11]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of July 26, 2013 related to such matters as they
 are not probable and/or reasonably estimable.
  (was, 2013-02-28, similarity 0.8329):
[0001193125-13-084667:note_history:11]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of January 25, 2013 related to such
matters.

- removed (2013-08-29):
[0001193125-13-084667:note_history:12]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Beginning balance |  | $ | 111.8 |  |  | $ | 65.0 |  |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 23.5 |  |  |  | 14.1 |  |  |  | 74.3 |  |  |  | 41.5 |  |
| Warranty costs incurred |  |  | (18.5 | ) |  |  | (10.9 | ) |  |  | (40.6 | ) |  |  | (31.3 | ) |
| Ending balance |  | $ | 116.8 |  |  | $ | 68.2 |  |  | $ | 116.8 |  |  | $ | 68.2 |  |

- removed (2013-08-29):
[0001193125-13-084667:note_history:13]
The aggregate amount of financing guarantees representing the
total maximum potential future payments under financing
arrangements with third parties, and the related deferred revenue
are summarized as follows (in millions):

- removed (2013-08-29):
[0001193125-13-084667:note_history:14]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 180.9 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (164.4 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.5 |  |  | $ | 19.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:15]
Fiscal Year — Our fiscal year is reported on
 a 52- or 53-week year ending on the last Friday in April. The first
 quarters of fiscal 2014 and 2013 were each 13-week
 periods.
  (was, 2013-02-28, similarity 0.9477):
[0001193125-13-084667:note_history:15]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The
first, second and third quarters of fiscal 2013 and 2012 were each
13-week periods.

- changed (2013-08-29):
[0001193125-13-352036:note_history:16]
Basis of Presentation — The accompanying unaudited
 condensed consolidated financial statements have been prepared by
 the Company, and reflect all adjustments, consisting only of normal
 recurring adjustments, that are, in the opinion of management,
 necessary for the fair presentation of our financial position,
 results of operations, comprehensive income and cash flows for the
 interim periods presented. The statements have been prepared in
 accordance with accounting principles generally accepted in the
 United States of America (GAAP) for interim financial information
 and in accordance with the instructions to Form 10-Q and Rule 10-01
 of Regulation S-X. Accordingly, these statements do not include all
 information and footnotes required by GAAP for annual consolidated
 financial statements, and should be read in conjunction with our
 audited consolidated financial statements as of and for the fiscal
 year ended April 26, 2013 contained in our Annual Report on
 Form 10-K filed with the Securities and Exchange Commission on
 June 17, 2013. The results of operations for the three months
 ended July 26, 2013 are not necessarily indicative of the
 operating results to be expected for the full fiscal year or future
 operating periods.
  (was, 2013-02-28, similarity 0.9935):
[0001193125-13-084667:note_history:16]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments, that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, comprehensive income and cash flows for the
interim periods presented. The statements have been prepared in
accordance with accounting principles generally accepted in the
United States of America (GAAP) for interim financial information
and in accordance with the instructions to Form 10-Q and Rule 10-01
of Regulation S-X. Accordingly, these statements do not include all
information and footnotes required by GAAP for annual consolidated
financial statements, and should be read in conjunction with our
audited consolidated financial statements as of and for the fiscal
year ended April 27, 2012 contained in our Annual Report on
Form 10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three and
nine months ended January 25, 2013 are not necessarily
indicative of the operating results to be expected for the full
fiscal year or future operating periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:17]
There have been no significant changes in our significant
 accounting policies as of and for the three months ended
 July 26, 2013, as compared to the significant accounting
 policies described in our Annual Report on Form 10-K for the fiscal
 year ended April 26, 2013.
  (was, 2013-02-28, similarity 0.9724):
[0001193125-13-084667:note_history:17]
There have been no significant changes in our significant
accounting policies as of and for the nine months ended
January 25, 2013, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.

- added (2013-08-29):
[0001193125-13-352036:note_history:18]
In July 2013, the Financial Accounting Standards Board issued
 an accounting standard update providing presentation requirements
 for unrecognized tax benefit when a net operating loss
 carryforward, a similar tax loss, or a similar tax credit
 carryforward exists. This accounting standard update will be
 effective for us beginning in our first quarter of fiscal 2015 and
 is not expected to have a significant impact on our consolidated
 financial statements.

- changed (2013-08-29):
[0001193125-13-352036:note_history:19]
Use of Estimates — The preparation of the
 condensed consolidated financial statements in conformity with GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent assets and liabilities at the date of the financial
 statements and the reported amounts of revenues and expenses during
 the reporting periods. Such estimates include, but are not limited
 to, revenue recognition, reserves and allowances; inventory
 valuation and purchase order accruals; valuation of goodwill and
 intangibles; restructuring reserves; product warranties; employee
 benefit accruals; stock-based compensation; loss contingencies;
 investment impairments; income taxes and fair value measurements.
 Actual results could differ materially from those
 estimates.
  (was, 2013-02-28, similarity 0.9877):
[0001193125-13-084667:note_history:19]
The preparation of the condensed consolidated financial
statements in conformity with GAAP requires management to make
estimates and assumptions that affect the reported amounts of
assets and liabilities and disclosure of contingent assets and
liabilities at the date of the financial statements and the
reported amounts of revenues and expenses during the reporting
periods. Such estimates include, but are not limited to, revenue
recognition, reserves and allowances; inventory valuation and
purchase order accruals; valuation of goodwill and intangibles;
restructuring reserves; product warranties; employee benefit
accruals; stock-based compensation; loss contingencies; investment
impairments; income taxes, and fair value measurements. Actual
results could differ materially from those estimates.

- removed (2013-08-29):
[0001193125-13-084667:note_history:20]
In September 2011, the Financial Accounting Standards
Board (FASB) issued a revised accounting standard intended to
simplify how an entity tests goodwill for impairment. The revised
standard will allow an entity to first assess qualitative factors
to determine whether it is necessary to perform the two-step
quantitative goodwill impairment test. An entity will no longer be
required to calculate the fair value of a reporting unit unless it
determines, based on a qualitative assessment, that it is more
likely than not that its fair value is less than its carrying
amount. This guidance is effective for us beginning in our fourth
quarter of fiscal 2013. We do not expect this guidance to have a
material impact on our consolidated financial
statements.

- removed (2013-08-29):
[0001193125-13-084667:note_history:21]
In December 2011, the FASB issued new guidance that will
require us to disclose information about offsetting arrangements
associated with financial and derivative instruments to enable
users of our financial statements to understand the effect of those
arrangements on our financial position. This guidance is effective
for us beginning in our first quarter of fiscal 2014, at which time
we will include the applicable disclosures required by this
accounting standard update. Other than requiring additional
disclosures related to offsetting arrangements, we do not
anticipate material impacts on our financial statements upon
adoption.

- removed (2013-08-29):
[0001193125-13-084667:note_history:22]
Use of
Estimates


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:23]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.2 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total |  |  | 994.8 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.8 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |
  (was, 2013-02-28, similarity 0.8545):
[0001193125-13-084667:note_history:23]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 0.0 |  |  |  | N/A |  |
| 1.75% Convertible Notes Due 2013 |  |  | 1,264.9 |  |  |  | 6.31 | % |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 2,264.9 |  |  |  |  |  |  |  | 1,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (27.3 | ) |  |  |  |  |  |  | (62.6 | ) |  |  |  |  |
| Total |  |  | 2,237.6 |  |  |  |  |  |  |  | 1,202.3 |  |  |  |  |  |
| Less: Current portion |  |  | (1,243.3 | ) |  |  |  |  |  |  | (1,202.3 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.3 |  |  |  |  |  |  | $ | 0.0 |  |  |  |  |  |

- added (2013-08-29):
[0001193125-13-352036:note_history:24]
Senior Notes

- added (2013-08-29):
[0001193125-13-352036:note_history:25]
Our Senior Notes are unsecured, unsubordinated obligations,
 which pay interest semi-annually on June 15 and
 December 15 and rank equally in right of payment with any
 future senior unsecured indebtedness. Interest expense associated
 with the Senior Notes was $6.3 million for the three months ended
 July 26, 2013.

- changed (2013-08-29):
[0001193125-13-352036:note_history:26]
We may redeem the Senior Notes in whole or in part, at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of July 26, 2013,
 we were in compliance with all covenants associated with the Senior
 Notes.
  (was, 2013-02-28, similarity 0.9951):
[0001193125-13-084667:note_history:26]
We may redeem the Senior Notes in whole or in part, at any time
at our option at specified redemption prices. In addition, upon the
occurrence of certain change of control triggering events, we may
be required to repurchase the Senior Notes at 101% of their
aggregate principal amount, plus accrued and unpaid interest to the
date of repurchase. The Senior Notes also include covenants that
limit our ability to incur debt secured by liens on assets or on
shares of stock or indebtedness of our subsidiaries; to engage in
sale and lease-back transactions; and to consolidate, merge or sell
all or substantially all of our assets. As of January 25,
2013, we were in compliance with all covenants associated with the
Senior Notes.

- added (2013-08-29):
[0001193125-13-352036:note_history:27]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted based on a conversion rate of 31.40 shares of common
 stock per $1,000 principal amount of the Convertible Notes (which
 represented the effective conversion price of $31.85 per share).
 Upon conversion in June 2013, the holders received cash for the
 principal amount of the Convertible Notes and an aggregate of
 4.9 million shares of common stock for the $178.9 million
 excess of the conversion value over the principal
 amount.

- changed (2013-08-29):
[0001193125-13-352036:note_history:28]
We separately accounted for the liability and equity components
 of the Convertible Notes. The initial debt component of the
 Convertible Notes was valued at $1,017.0 million based on the
 contractual cash flows discounted at an appropriate comparable
 market non-convertible debt borrowing rate at the date of issuance
 of 6.31%, with the equity component representing the residual
 amount of the proceeds of $248.0 million which was recorded as
 a debt discount. Issuance costs were allocated pro-rata based on
 the relative initial carrying amounts of the debt and equity
 components. As a result, $5.2 million of the issuance costs
 was allocated to the equity component of the Convertible Notes, and
 $21.4 million of the issuance costs remained classified as
 other non-current assets. The debt discount and the issuance costs
 allocated to the debt component were amortized as additional
 interest expense over the term of the Convertible Notes using the
 effective interest method.
  (was, 2013-02-28, similarity 0.9974):
[0001193125-13-084667:note_history:28]
We separately account for the liability and equity components
of the Convertible Notes. The initial debt component of the
Convertible Notes was valued at $1,017.0 million based on the
contractual cash flows discounted at an appropriate comparable
market non-convertible debt borrowing rate at the date of issuance
of 6.31%, with the equity component representing the residual
amount of the proceeds of $248.0 million which was recorded as
a debt discount. Issuance costs were allocated pro-rata based on
the relative initial carrying amounts of the debt and equity
components. As a result, $5.2 million of the issuance costs
was allocated to the equity component of the Convertible Notes, and
$21.4 million of the issuance costs remained classified as
other non-current assets. The debt discount and the issuance costs
allocated to the debt component are amortized as additional
interest expense over the term of the Convertible Notes using the
effective interest method.

- changed (2013-08-29):
[0001193125-13-352036:note_history:29]
Concurrent with the issuance of the Convertible Notes, we
 purchased Convertible Note hedges and sold warrants. The separate
 Convertible Note hedge and warrant transactions were structured to
 reduce the potential future economic dilution associated with the
 conversion of the Convertible Notes.
  (was, 2013-02-28, similarity 0.9949):
[0001193125-13-084667:note_history:29]
Concurrent with the issuance of the Convertible Notes, we
purchased Convertible Note hedges and sold warrants. The separate
Convertible Note hedge and warrant transactions are structured to
reduce the potential future economic dilution associated with the
conversion of the Convertible Notes.

- added (2013-08-29):
[0001193125-13-352036:note_history:30]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges, for which we received an aggregate of 3.9 million
 shares from the counterparties.

- added (2013-08-29):
[0001193125-13-352036:note_history:31]
• Warrants: As of July 26, 2013, we had outstanding
 warrants for certain counterparties to acquire, subject to
 anti-dilution adjustments, 39.9 million shares of our common
 stock at an exercise price of $41.12 per share as adjusted to
 reflect our July 2013 dividend. Prior to the dividend, we had
 39.7 million outstanding warrants at an exercise price of
 $41.28 per share. The number of warrants and the exercise price are
 subject to additional adjustments for specified conditions,
 including future dividend declarations. The warrants are
 exercisable on a series of days commencing on September 3,
 2013 and ending on October 28, 2013. Upon exercise of the
 warrants, we have the option to deliver cash or shares of our
 common stock equal to the difference between the then market price
 and the strike price of the warrants.

- changed (2013-08-29):
[0001193125-13-352036:note_history:32]
Interest Expense on Convertible Notes
  (was, 2013-02-28, similarity 0.6038):
[0001193125-13-084667:note_history:32]
Interest
Expense

- changed (2013-08-29):
[0001193125-13-352036:note_history:33]
The following table presents the amount of interest expense
 related to the Convertible Notes (in millions):
  (was, 2013-02-28, similarity 0.9511):
[0001193125-13-084667:note_history:33]
The following table presents the amount of interest expense
recognized related to the Convertible Notes (in
millions):

- changed (2013-08-29):
[0001193125-13-352036:note_history:34]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 2.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 7.1 |  |  |  | 13.5 |  |
| Amortization of debt issuance costs |  |  | 0.6 |  |  |  | 1.2 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (0.5 | ) |
| Total interest expense related to Convertible Notes |  | $ | 10.2 |  |  | $ | 19.7 |  |
  (was, 2013-02-28, similarity 0.797):
[0001193125-13-084667:note_history:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.9 |  |  |  | 13.0 |  |  |  | 41.0 |  |  |  | 38.4 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 3.6 |  |  |  | 3.3 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (0.9 | ) |  |  | (1.1 | ) |  |  | (4.3 | ) |
| Total interest expense related to Convertible Notes |  | $ | 20.6 |  |  | $ | 18.7 |  |  | $ | 60.0 |  |  | $ | 53.9 |  |

- changed (2013-08-29):
[0001193125-13-352036:note_history:35]
As of July 26, 2013, our aggregate future principal debt
 maturities are as follows (in millions):
  (was, 2013-02-28, similarity 0.973):
[0001193125-13-084667:note_history:35]
As of January 25, 2013, our aggregate future principal
debt maturities are as follows (in millions):

- changed (2013-08-29):
[0001193125-13-352036:note_history:36]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |
  (was, 2013-02-28, similarity 0.7072):
[0001193125-13-084667:note_history:36]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 0.0 |  |
| 2014 |  |  | 1,264.9 |  |
| 2015 |  |  | 0.0 |  |
| 2016 |  |  | 0.0 |  |
| 2017 |  |  | 0.0 |  |
| Thereafter |  |  | 1,000.0 |  |
| Total |  | $ | 2,264.9 |  |

- changed (2013-08-29):
[0001193125-13-352036:note_history:37]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of July 26, 2013, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.
  (was, 2013-02-28, similarity 0.997):
[0001193125-13-084667:note_history:37]
Borrowings under the facility, except for swingline loans,
accrue interest in arrears at an alternate base rate as defined in
the credit agreement or, at our option, an adjusted London
Interbank Offered Rate (LIBOR) plus in each case, a spread (based
on our public debt ratings and the type of loan) ranging from 0.2%
to 1.2%. Swingline borrowings accrue interest at an alternate base
rate. In addition, we are required to pay fees to maintain the
credit facility, whether or not we have outstanding borrowings. The
facility terminates on December 21, 2017 if no extensions have
been requested and contains financial covenants requiring us to
maintain a maximum leverage ratio of not more than 3.0:1.0 and a
minimum interest coverage ratio of not less than 3.5:1.0. The
facility contains customary affirmative and negative covenants,
including covenants that limit our ability to incur debt secured by
liens on assets or indebtedness of our subsidiaries and to
consolidate, merge or sell all or substantially all of our assets.
As of January 25, 2013, no borrowings were outstanding under
the facility and we were in compliance with all covenants
associated with the facility.

- changed (2013-08-29):
[0001193125-13-352036:note_history:38]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 11.0 |  |  |  | 5.6 |  |
| Total |  | $ | 20.3 |  |  | $ | 10.8 |  |
  (was, 2013-02-28, similarity 0.9896):
[0001193125-13-084667:note_history:38]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.6 |  |  |  | 3.5 |  |
| Total |  | $ | 12.0 |  |  | $ | 12.6 |  |

- removed (2013-08-29):
[0001193125-13-084667:note_history:39]
2.00% Senior Notes due 2017 and 3.25% Senior Notes
due 2022

- removed (2013-08-29):
[0001193125-13-084667:note_history:40]
In December 2012, we issued $750.0 million principal amount of
2.00% Senior Notes due on December 15, 2017 and $250.0 million
principal amount of 3.25% Senior Notes due on December 15,
2022 (collectively referred to as the Senior Notes). The proceeds
received were net of debt discounts of $5.8 million and issuance
costs of $6.9 million, both of which are amortized as additional
interest expense over the respective terms of the Senior Notes
using the effective interest method. The Senior Notes are
unsecured, unsubordinated obligations, which pay interest
semi-annually on June 15 and December 15 and rank equally
in right of payment with our other existing and future senior
unsecured indebtedness, including the Convertible Notes. During the
three months ended January 25, 2013, interest expense
associated with the Senior Notes was $3.1 million. The proceeds
from the Senior Notes are available for general corporate purposes,
including repayment of certain indebtedness, capital expenditures,
possible stock repurchases, working capital and potential
acquisitions and strategic transactions.

- removed (2013-08-29):
[0001193125-13-084667:note_history:41]
On June 10, 2008, we issued $1,265.0 million
aggregate principal amount of 1.75% Convertible Senior Notes
due 2013 (the Convertible Notes). The Convertible Notes are
unsecured, unsubordinated obligations of the Company, which pay
interest in cash semi-annually at a rate of 1.75% per annum.
The Convertible Notes will mature on June 1, 2013 unless
earlier repurchased or converted in accordance with their terms
prior to such date. The Convertible Notes may be converted, under
the conditions specified below, based on an initial conversion rate
of 31.40 shares of common stock per $1,000 principal amount of
Convertible Notes (which represents an initial effective conversion
price of the Convertible Notes of $31.85 per share), subject to
adjustment as described in the indenture governing the Convertible
Notes.

- removed (2013-08-29):
[0001193125-13-084667:note_history:42]
The Convertible Notes are not redeemable by us prior to the
maturity date. In the event of a fundamental change (as defined in
the indenture for the Convertible Notes), holders of the
Convertible Notes may require us to repurchase all or a portion of
their Convertible Notes at a repurchase price equal to 100% of the
principal amount of the Convertible Notes plus accrued and unpaid
interest, if any, to, but excluding, the fundamental change
repurchase date.

- removed (2013-08-29):
[0001193125-13-084667:note_history:43]
The holders of the Convertible Notes may convert their
Convertible Notes until the close of business on the scheduled
trading day immediately preceding the maturity date if any of the
following conditions are met: (1) during the five business day
period after any five consecutive trading day period (the
measurement period) in which the trading price of the Convertible
Notes for each day in the measurement period was less than 98% of
an amount equal to (i) the last reported sale price of our
common stock multiplied by (ii) the conversion rate for the
Convertible Notes on each such day; (2) during any calendar
quarter (and only during such calendar quarter) if the last
reported sale price of our common stock for 20 or more trading days
in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the
Convertible Notes on the last trading day of such immediately
preceding calendar quarter; or (3) upon the occurrence of
specified corporate transactions set forth in the indenture for the
Convertible Notes. On or after March 1, 2013, until the
scheduled trading day immediately preceding the maturity date,
holders of the Convertible Notes may convert their Convertible
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Convertible Notes,
and shares of our common stock for any conversion value in excess
of the principal amount of the Convertible Notes, if any. Holders
of the Convertible Notes who convert their Convertible Notes in
connection with a fundamental change will, under certain
circumstances, be entitled to a make-whole premium in the form of
an increase in the conversion rate.

- removed (2013-08-29):
[0001193125-13-084667:note_history:44]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Convertible Notes for
at least 20 trading days during the 30 consecutive trading days
ended December 31, 2012, and accordingly, as of
January 25, 2013, the Convertible Notes were not convertible
at the option of the holders. Since the Convertible Notes were not
convertible, the difference between the principal amount and the
carrying value of the Convertible Notes was reflected as equity on
our condensed consolidated balance sheet as of January 25,
2013.

- removed (2013-08-29):
[0001193125-13-084667:note_history:45]
The Convertible Notes become unconditionally convertible at the
option of the holders on March 1, 2013. At such time, the
difference between the principal amount and the carrying value of
the Convertible Notes will be reflected as convertible debt in
mezzanine on our condensed consolidated balance sheet.

- removed (2013-08-29):
[0001193125-13-084667:note_history:46]
Upon conversion of the Convertible Notes, we deliver cash up to
the principal amount of the Convertible Notes and, with respect to
any excess conversion value greater than the principal amount of
the Convertible Notes, shares of our common stock. As of
January 25, 2013, shares issued related to the Convertible
Notes were minimal. Based on the closing price of our common stock
of $36.15 on January 25, 2013, the if-converted value of our
Convertible Notes exceeded their principal amount by approximately
$170.9 million.

- removed (2013-08-29):
[0001193125-13-084667:note_history:47]
• Convertible Note Hedges: As of January 25, 2013
and April 27, 2012, we had arrangements with counterparties to
buy up to approximately 31.8 million shares of our common
stock, subject to anti-dilution adjustments, at a price of $31.85
per share, subject to adjustment. The Convertible Note hedge
transactions will expire at the earlier of (1) the last day on
which any Convertible Notes remain outstanding or (2) the
scheduled trading day immediately preceding the maturity date of
the Convertible Notes. Upon exercise of the Convertible Note
hedges, we have the option to receive cash or shares of our common
stock equal to the difference between the then market price and the
strike price of the Convertible Note hedges.

- removed (2013-08-29):
[0001193125-13-084667:note_history:48]
• Warrants: As of January 25, 2013 and
April 27, 2012, we had outstanding warrants for others to
acquire, subject to anti-dilution adjustments, 39.7 million
shares of our common stock at an exercise price of $41.28 per
share, subject to adjustment, on a series of days commencing on
September 3, 2013. Upon exercise of the warrants, we have the
option to deliver cash or shares of our common stock equal to the
difference between the then market price and the strike price of
the warrants.

- removed (2013-08-29):
[0001193125-13-084667:note_history:49]
As of January 25, 2013, we were subject to potential
dilution on the approximately 20% unhedged portion of our
Convertible Notes upon conversion, if on the date of conversion,
the per-share market price of our common stock exceeds the
conversion price of $31.85.

- removed (2013-08-29):
[0001193125-13-084667:note_history:50]
As of January 25, 2013, we received a minimal number of
shares related to the Convertible Note hedge transactions and no
cash or shares were delivered related to the warrant
transactions.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:51]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 11.0 |  |  |  | 5.6 |  |
| Total |  | $ | 20.3 |  |  | $ | 10.8 |  |
  (was, 2013-02-28, similarity 0.9896):
[0001193125-13-084667:note_history:51]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.6 |  |  |  | 3.5 |  |
| Total |  | $ | 12.0 |  |  | $ | 12.6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:52]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.2 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total |  |  | 994.8 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.8 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |
  (was, 2013-02-28, similarity 0.8545):
[0001193125-13-084667:note_history:52]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 0.0 |  |  |  | N/A |  |
| 1.75% Convertible Notes Due 2013 |  |  | 1,264.9 |  |  |  | 6.31 | % |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 2,264.9 |  |  |  |  |  |  |  | 1,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (27.3 | ) |  |  |  |  |  |  | (62.6 | ) |  |  |  |  |
| Total |  |  | 2,237.6 |  |  |  |  |  |  |  | 1,202.3 |  |  |  |  |  |
| Less: Current portion |  |  | (1,243.3 | ) |  |  |  |  |  |  | (1,202.3 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.3 |  |  |  |  |  |  | $ | 0.0 |  |  |  |  |  |

- removed (2013-08-29):
[0001193125-13-084667:note_history:53]
N/A - Not
Applicable


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-08-29):
[0001193125-13-352036:note_history:54]
As of July 26, 2013, our aggregate future principal debt
 maturities are as follows (in millions):
  (was, 2013-02-28, similarity 0.973):
[0001193125-13-084667:note_history:54]
As of
January 25, 2013, our aggregate future principal debt
maturities are as follows (in millions):

- changed (2013-08-29):
[0001193125-13-352036:note_history:55]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |
  (was, 2013-02-28, similarity 0.7072):
[0001193125-13-084667:note_history:55]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 0.0 |  |
| 2014 |  |  | 1,264.9 |  |
| 2015 |  |  | 0.0 |  |
| 2016 |  |  | 0.0 |  |
| 2017 |  |  | 0.0 |  |
| Thereafter |  |  | 1,000.0 |  |
| Total |  | $ | 2,264.9 |  |
