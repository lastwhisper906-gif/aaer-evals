# NTAP notes — 0001193125-13-352036


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-13-352036:notes:1]
Information related to the purchase rights issued under the
 ESPP is provided below (in millions, except per right
 information):

[0001193125-13-352036:notes:2]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Weighted-average fair value per right granted |  | $ | 10.53 |  |  | $ | 10.25 |  |
| Shares issued under the ESPP |  |  | 2.0 |  |  |  | 1.9 |  |
| Proceeds from issuance of shares |  | $ | 49.9 |  |  | $ | 48.2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-13-352036:notes:3]
11.  Restructuring and Other
 Charges

[0001193125-13-352036:notes:4]
In May 2013, we initiated a business restructuring plan under
 which we realigned internal resources, resulting in a reduction of
 our global workforce of approximately 7%. Restructuring and other
 charges during the three months ended July 26, 2013 consisted
 primarily of employee severance-related costs.

[0001193125-13-352036:notes:5]
Activities related to this plan for the three months ended
 July 26, 2013 were as follows (in millions):

[0001193125-13-352036:notes:6]
|  |  | Total |  |
| Gross charges |  | $ | 48.4 |  |
| Cash payments |  |  | (24.6 | ) |
| Balance as of July 26, 2013 |  | $ | 23.8 |  |

[0001193125-13-352036:notes:7]
The reserve balance as of July 26, 2013 is included in
 accrued compensation and related benefits in our condensed
 consolidated balance sheet.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-13-352036:notes:8]
4.  Statements
 of Cash Flows

[0001193125-13-352036:notes:9]
Non-cash investing and financing activities and supplemental
 cash flow information are as follows (in millions):

[0001193125-13-352036:notes:10]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of Convertible Notes |  | $ | 0.0 |  |  | $ | 62.6 |  |
| Acquisition of property and equipment outstanding in accounts payable |  | $ | 17.7 |  |  | $ | 27.4 |  |
| Acquisition of software through long-term financing |  | $ | 10.6 |  |  | $ | 0.0 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 19.1 |  |  | $ | 16.2 |  |
| Interest paid, net of capitalized interest |  | $ | 23.0 |  |  | $ | 11.2 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-352036:notes:11]
The following is a calculation of basic and diluted net income
 per share (in millions):

[0001193125-13-352036:notes:12]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 81.6 |  |  | $ | 63.8 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 350.9 |  |  |  | 366.1 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 6.9 |  |  |  | 4.9 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 2.1 |  |  |  | 0.2 |  |
| Shares used in diluted computation |  |  | 359.9 |  |  |  | 371.2 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | 0.17 |  |
| Diluted |  | $ | 0.23 |  |  | $ | 0.17 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-13-352036:notes:13]
9.  Stockholders’ Equity

[0001193125-13-352036:notes:14]
Stock Options

[0001193125-13-352036:notes:15]
The following table summarizes activity related to our stock
 options (in millions, except for exercise price and contractual
 term):

[0001193125-13-352036:notes:16]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 26, 2013 |  |  | 19.2 |  |  | $ | 31.27 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.4 |  |  |  | 37.63 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2.3 | ) |  |  | 25.17 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.2 | ) |  |  | 44.39 |  |  |  |  |  |  |  |  |  |
| Outstanding as of July 26, 2013 |  |  | 19.1 |  |  |  | 32.67 |  |  |  | 3.73 |  |  | $ | 199.4 |  |
| Vested and expected to vest as of July 26, 2013 |  |  | 18.4 |  |  |  | 32.50 |  |  |  | 3.63 |  |  |  | 195.6 |  |
| Exercisable as of July 26, 2013 |  |  | 13.1 |  |  |  | 30.16 |  |  |  | 2.78 |  |  |  | 166.8 |  |

[0001193125-13-352036:notes:17]
The aggregate intrinsic value represents the pre-tax difference
 between the exercise price of stock options and the quoted market
 price of our stock on that day for all in-the-money
 options.

[0001193125-13-352036:notes:18]
Additional information related to our stock options is
 summarized below (in millions, except per share
 information):

[0001193125-13-352036:notes:19]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Weighted-average fair value per share granted |  | $ | 9.78 |  |  | $ | 10.71 |  |
| Intrinsic value of exercises |  | $ | 27.4 |  |  | $ | 5.4 |  |
| Proceeds received from exercises |  | $ | 56.8 |  |  | $ | 6.7 |  |
| Fair value of options vested |  | $ | 12.0 |  |  | $ | 14.4 |  |

[0001193125-13-352036:notes:20]
[same as prior period, unchanged from 0001193125-13-084667:notes:15]

[0001193125-13-352036:notes:21]
The following table summarizes activity related to our
 restricted stock units (RSUs) (in millions, except for fair
 value):

[0001193125-13-352036:notes:22]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 26, 2013 |  |  | 12.8 |  |  | $ | 38.36 |  |
| Granted |  |  | 4.6 |  |  |  | 38.16 |  |
| Vested |  |  | (2.7 | ) |  |  | 36.55 |  |
| Forfeited |  |  | (0.6 | ) |  |  | 39.93 |  |
| Outstanding as of July 26, 2013 |  |  | 14.1 |  |  |  | 38.57 |  |

[0001193125-13-352036:notes:23]
RSUs are converted into common stock upon vesting. We primarily
 use the net share settlement approach upon vesting, where a portion
 of the shares are withheld as settlement of statutory employee
 withholding taxes, which decreases the shares issued to the
 employee by a corresponding value. The number and value of the
 shares netted for employee taxes are summarized in the table below
 (in millions):

[0001193125-13-352036:notes:24]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Shares withheld for taxes |  |  | 0.9 |  |  |  | 0.7 |  |
| Fair value of shares withheld |  | $ | 35.3 |  |  | $ | 19.8 |  |

[0001193125-13-352036:notes:25]
Employee Stock Purchase Plan

[0001193125-13-352036:notes:26]
Under the Employee Stock Purchase Plan (ESPP), employees who
 elect to participate are granted options that include a purchase
 price adjustment provision under which the employees may purchase
 common stock at a 15% discount from the market value of the common
 stock at certain specified dates within a two-year offering period.
 Information related to the purchase rights issued under the ESPP is
 provided below (in millions, except per right
 information):

[0001193125-13-352036:notes:27]
[same as prior period, unchanged from 0001193125-13-084667:notes:24]

[0001193125-13-352036:notes:28]
Stock-based compensation expense consists primarily of expenses
 for stock options, RSUs and ESPP and is included in the condensed
 consolidated statements of operations as follows (in
 millions):

[0001193125-13-352036:notes:29]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Cost of product revenues |  | $ | 1.3 |  |  | $ | 1.8 |  |
| Cost of service revenues |  |  | 4.0 |  |  |  | 5.6 |  |
| Sales and marketing |  |  | 30.5 |  |  |  | 39.0 |  |
| Research and development |  |  | 21.4 |  |  |  | 23.7 |  |
| General and administrative |  |  | 9.1 |  |  |  | 9.1 |  |
| Total stock-based compensation expense |  | $ | 66.3 |  |  | $ | 79.2 |  |

[0001193125-13-352036:notes:30]
As of July 26, 2013, total unrecognized compensation
 expense related to our equity awards was $525.4 million, which is
 expected to be recognized on a straight-line basis over a
 weighted-average remaining service period of
 2.7 years.

[0001193125-13-352036:notes:31]
Total income tax charges associated with employee stock
 transactions and recognized in stockholders’ equity were as
 follows (in millions):

[0001193125-13-352036:notes:32]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Income tax charges associated with employee stock transactions |  | $ | 8.0 |  |  | $ | 8.8 |  |

[0001193125-13-352036:notes:33]
Valuation Assumptions

[0001193125-13-352036:notes:34]
The fair value of each award is estimated on the grant date
 using the Black-Scholes option pricing model and the following
 weighted-average assumptions:

[0001193125-13-352036:notes:35]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 1.0 | % |  |  | 0.6 | % |
| Volatility |  |  | 34 | % |  |  | 41 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |
|  |  | ESPP |  |
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |
| Volatility |  |  | 32 | % |  |  | 38 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |

[0001193125-13-352036:notes:36]
The weighted-average assumptions used to value RSUs are
 summarized as follows:

[0001193125-13-352036:notes:37]
|  |  | RSUs |  |
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Grant date fair value per share |  | $ | 38.16 |  |  | $ | 29.03 |  |
| Expected dividend |  |  | 1.6 | % |  |  | 0.0 | % |

[0001193125-13-352036:notes:38]
Prior to the initial declaration of a quarterly cash dividend
 on May 21, 2013, the fair value of RSUs was measured based on
 the grant date share price, as we did not historically pay cash
 dividends on our common stock. For awards granted on or subsequent
 to May 21, 2013, the fair value of RSUs was measured based on the
 grant date share price, less the present value of expected
 dividends during the vesting period, discounted at a risk-free
 interest rate.

[0001193125-13-352036:notes:39]
Stock Repurchase Program

[0001193125-13-352036:notes:40]
As of July 26, 2013, our Board of Directors has authorized
 the repurchase of up to $7.1 billion of our common stock. Under
 this program, which may be suspended or discontinued at any time,
 we may purchase shares of our outstanding common stock through open
 market and privately negotiated transactions at prices deemed
 appropriate by our management.

[0001193125-13-352036:notes:41]
The following table summarizes activity related to this program
 for the three months ended July 26, 2013 (in millions, except
 per share information):

[0001193125-13-352036:notes:42]
| Number of shares purchased |  |  | 21.7 |  |
| Average price per share |  | $ | 39.20 |  |
| Aggregate purchase price |  | $ | 849.5 |  |
| Remaining authorization at end of period |  | $ | 2,156.8 |  |

[0001193125-13-352036:notes:43]
The aggregate purchase price of our share repurchases for the
 three months ended July 26, 2013 consisted of $750.0 million
 under an accelerated share repurchase agreement (ASR) and $99.5
 million repurchased on the open market, for which collectively
 $235.8 million and $613.7 million was allocated to additional
 paid-in capital and retained earnings, respectively.

[0001193125-13-352036:notes:44]
Accelerated Share Repurchase Agreement

[0001193125-13-352036:notes:45]
On June 5, 2013, we entered into a collared ASR with a
 counterparty under which we prepaid $750.0 million to purchase
 shares of our common stock. The aggregate number of shares
 ultimately purchased was determined based on the volume
 weighted-average share price of our common stock over a specified
 period of time. The contract was settled in July 2013. The total
 number of shares repurchased under this ASR was 19.2 million
 shares, at an average price per share of $39.13. The value of the
 ASR forward contract was determined to be $13.9 million, which has
 been recorded as additional paid-in capital.

[0001193125-13-352036:notes:46]
Dividends

[0001193125-13-352036:notes:47]
On May 21, 2013, we declared a cash dividend of $0.15 per
 common share, for which we paid an aggregate of $51.4 million on
 July 23, 2013. No dividends were declared or paid during the
 three months ended July 27, 2012. On August 14, 2013, we
 declared a cash dividend of $0.15 per share of common stock,
 payable on October 25, 2013 to holders of record as of the
 close of business on October 21, 2013. The timing and amount
 of future dividends will depend on market conditions, corporate
 business and financial considerations and regulatory
 requirements.

[0001193125-13-352036:notes:48]
Retained Earnings

[0001193125-13-352036:notes:49]
A reconciliation of retained earnings for the three months
 ended July 26, 2013 is as follows (in millions):

[0001193125-13-352036:notes:50]
|  |  | Retained Earnings |  |
| Balance as of April 26, 2013 |  | $ | 2,896.8 |  |
| Net income |  |  | 81.6 |  |
| Repurchases of common stock |  |  | (613.7 | ) |
| Dividends |  |  | (51.4 | ) |
| Balance as of July 26, 2013 |  | $ | 2,313.3 |  |

[0001193125-13-352036:notes:51]
Accumulated comprehensive income (loss) and other
 comprehensive income

[0001193125-13-352036:notes:52]
Changes in accumulated other comprehensive income (AOCI) by
 component, net of tax, are summarized below (in
 millions):

[0001193125-13-352036:notes:53]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 26, 2013 |  | $ | 2.0 |  |  | $ | (5.7 | ) |  | $ | 11.4 |  |  | $ | 1.0 |  |  | $ | 8.7 |  |
| Other comprehensive income (loss) (OCI) before reclassifications |  |  | (1.2 | ) |  |  | 0.1 |  |  |  | (7.4 | ) |  |  | (0.4 | ) |  |  | (8.9 | ) |
| Amounts reclassified from AOCI |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | (1.0 | ) |  |  | (1.1 | ) |
| Net OCI |  |  | (1.2 | ) |  |  | 0.1 |  |  |  | (7.5 | ) |  |  | (1.4 | ) |  |  | (10.0 | ) |
| Balance as of July 26, 2013 |  | $ | 0.8 |  |  | $ | (5.6 | ) |  | $ | 3.9 |  |  | $ | (0.4 | ) |  | $ | (1.3 | ) |

[0001193125-13-352036:notes:54]
The amounts reclassified out of AOCI are as follows (in
 millions):

[0001193125-13-352036:notes:55]
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |  |  |  |
| OCI Components |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |  |
| Realized gains on available-for-sale securities |  | $ | (0.1 | ) |  | $ | (0.1 | ) |  |  | Other income, net |  |
| Realized gains on cash flow hedges |  |  | (1.0 | ) |  |  | (4.5 | ) |  |  | Net revenues |  |
| Total reclassifications |  | $ | (1.1 | ) |  | $ | (4.6 | ) |  |  |  |  |


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-13-352036:notes:56]
The following table presents cash, cash equivalents, restricted
 cash and investments held in the United States and internationally
 in various foreign subsidiaries (in millions):

[0001193125-13-352036:notes:57]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,368.5 |  |  | $ | 3,419.3 |  |
| International |  |  | 3,768.6 |  |  |  | 3,586.8 |  |
| Total |  | $ | 5,137.1 |  |  | $ | 7,006.1 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-13-352036:notes:58]
The following is a summary of our investments (in
 millions):

[0001193125-13-352036:notes:59]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,836.7 |  |  | $ | 9.1 |  |  | $ | (3.0 | ) |  | $ | 2,842.8 |  |  | $ | 3,132.8 |  |  | $ | 14.9 |  |  | $ | (0.6 | ) |  | $ | 3,147.1 |  |
| U.S. Treasury and government debt securities |  |  | 329.0 |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 329.3 |  |  |  | 392.8 |  |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 393.7 |  |
| Commercial paper |  |  | 125.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 125.9 |  |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 178.5 |  |
| Certificates of deposit |  |  | 135.0 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 135.1 |  |  |  | 135.4 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 135.5 |  |
| Money market funds |  |  | 323.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 323.2 |  |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |
| Auction rate securities |  |  | 44.2 |  |  |  | 0.5 |  |  |  | (2.5 | ) |  |  | 42.2 |  |  |  | 44.2 |  |  |  | 0.5 |  |  |  | (2.7 | ) |  |  | 42.0 |  |
| Equity funds |  |  | 29.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 29.9 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 28.3 |  |
| Total debt and equity securities |  | $ | 3,823.9 |  |  | $ | 10.1 |  |  | $ | (5.6 | ) |  | $ | 3,828.4 |  |  | $ | 5,375.1 |  |  | $ | 16.4 |  |  | $ | (3.3 | ) |  | $ | 5,388.2 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-13-352036:notes:60]
The following table presents property and equipment information
 for geographic areas based on the physical location of the assets
 (in millions):

[0001193125-13-352036:notes:61]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,071.0 |  |  | $ | 1,076.3 |  |
| International |  |  | 92.4 |  |  |  | 94.6 |  |
| Total |  | $ | 1,163.4 |  |  | $ | 1,170.9 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-352036:notes:62]
13.  Net
 Income per Share

[0001193125-13-352036:notes:63]
The following potential weighted-average shares of common stock
 have been excluded from the diluted net income per share
 calculations, as their effect would have been anti-dilutive (in
 millions):

[0001193125-13-352036:notes:64]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Employee equity award plans |  |  | 6.6 |  |  |  | 17.7 |  |

[0001193125-13-352036:notes:65]
Dilutive shares do not include any effect resulting from
 warrants as their impact would have been anti-dilutive for all
 periods reported above.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-13-352036:notes:66]
Cash and cash equivalents (in
 millions):

[0001193125-13-352036:notes:67]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Cash |  | $ | 1,327.7 |  |  | $ | 1,634.7 |  |
| Cash equivalents |  |  | 469.1 |  |  |  | 1,642.4 |  |
| Cash and cash equivalents |  | $ | 1,796.8 |  |  | $ | 3,277.1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-13-352036:notes:68]
7.  Financial
 Instruments and Fair Value Measurements

[0001193125-13-352036:notes:69]
The accounting guidance for fair value measurements provides a
 framework for measuring fair value on either a recurring or
 nonrecurring basis whereby the inputs used in our valuation
 techniques are assigned a hierarchical level. The following are the
 three levels of inputs to measure fair value:

[0001193125-13-352036:notes:70]
Level 1: Observable inputs that reflect quoted prices
 (unadjusted) for identical assets or liabilities in active
 markets.

[0001193125-13-352036:notes:71]
Level 2: Inputs that reflect quoted prices for identical
 assets or liabilities in less active markets; quoted prices for
 similar assets or liabilities in active markets; benchmark yields,
 reported trades, broker/dealer quotes, inputs other than quoted
 prices that are observable for the assets or liabilities; or inputs
 that are derived principally from or corroborated by observable
 market data by correlation or other means.

[0001193125-13-352036:notes:72]
Level 3: Unobservable inputs that reflect our own
 assumptions incorporated in valuation techniques used to measure
 fair value. These assumptions are required to be consistent with
 market participant assumptions that are reasonably
 available.

[0001193125-13-352036:notes:73]
We consider an active market to be one in which transactions
 for the asset or liability occur with sufficient frequency and
 volume to provide pricing information on an ongoing basis, and
 consider an inactive market to be one in which there are infrequent
 or few transactions for the asset or liability, the prices are not
 current, or price quotations vary substantially either over time or
 among market makers. Where appropriate, our own or the
 counterparty’s non-performance risk is considered in
 measuring the fair values of liabilities and assets,
 respectively.

[0001193125-13-352036:notes:74]
[same as prior period, unchanged from 0001193125-13-084667:notes:73]

[0001193125-13-352036:notes:75]
The unrealized losses on our available-for-sale investments
 were caused by market value declines as a result of the economic
 environment, as well as fluctuations in market interest rates.
 Because the declines in market value are attributable to changes in
 market conditions and not credit quality, and because we have
 currently concluded that we neither intend to sell nor is it more
 likely than not that we will be required to sell these investments
 prior to a recovery of par value, we do not consider these
 investments to be other-than temporarily impaired as of
 July 26, 2013.

[0001193125-13-352036:notes:76]
The following table presents the contractual maturities of our
 debt investments as of July 26, 2013 (in millions):

[0001193125-13-352036:notes:77]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,240.6 |  |  | $ | 1,242.2 |  |
| Due in one through five years |  |  | 2,040.1 |  |  |  | 2,045.0 |  |
| Due after ten years* |  |  | 44.2 |  |  |  | 42.2 |  |
|  |  | $ | 3,324.9 |  |  | $ | 3,329.4 |  |

[0001193125-13-352036:notes:78]
| * | Consists of auction rate securities (ARS) which have contractual maturities of greater than 10 years. |

[0001193125-13-352036:notes:79]
Fair Value of Financial Instruments

[0001193125-13-352036:notes:80]
The following table summarizes our financial assets and
 liabilities measured at fair value on a recurring basis as of
 July 26, 2013 (in millions):

[0001193125-13-352036:notes:81]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,842.8 |  |  | $ | 0.0 |  |  | $ | 2,842.8 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 329.3 |  |  |  | 207.2 |  |  |  | 122.1 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 125.9 |  |  |  | 0.0 |  |  |  | 125.9 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 135.1 |  |  |  | 0.0 |  |  |  | 135.1 |  |  |  | 0.0 |  |
| Money market funds |  |  | 323.2 |  |  |  | 323.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 42.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 42.2 |  |
| Equity funds |  |  | 29.9 |  |  |  | 29.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 0.0 |  |
| Total |  | $ | 3,829.9 |  |  | $ | 560.3 |  |  | $ | 3,227.4 |  |  | $ | 42.2 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 2.2 |  |  | $ | 0.0 |  |  | $ | 2.2 |  |  | $ | 0.0 |  |

[0001193125-13-352036:notes:82]
The following table summarizes the balance sheet
 classifications of our financial assets and liabilities measured at
 fair value on a recurring basis as of July 26, 2013 (in
 millions):

[0001193125-13-352036:notes:83]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 469.1 |  |  | $ | 323.2 |  |  | $ | 145.9 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,287.2 |  |  |  | 207.2 |  |  |  | 3,080.0 |  |  |  | 0.0 |  |
| Other current assets |  |  | 3.8 |  |  |  | 2.3 |  |  |  | 1.5 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 69.8 |  |  |  | 27.6 |  |  |  | 0.0 |  |  |  | 42.2 |  |
| Total |  | $ | 3,829.9 |  |  | $ | 560.3 |  |  | $ | 3,227.4 |  |  | $ | 42.2 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 2.2 |  |  | $ | 0.0 |  |  | $ | 2.2 |  |  | $ | 0.0 |  |

[0001193125-13-352036:notes:84]
Level 2 investments are held by a custodian who prices some of
 the investments using standard inputs in various asset price models
 or obtains investment prices from a third-party pricing provider
 that incorporates standard inputs in various asset price models. We
 review Level 2 inputs and fair value for reasonableness and the
 values may be further validated by comparison to multiple
 independent pricing sources. In addition, we review third-party
 pricing provider models, key inputs and assumptions and understand
 the pricing processes at our third-party providers in determining
 the overall reasonableness of the fair value of our Level 2
 financial instruments. As of July 26, 2013, we have not made
 any adjustments to the prices obtained from our third-party pricing
 providers.

[0001193125-13-352036:notes:85]
Quantitative information about our Level 3 fair value
 measurements is as follows (fair value in millions):

[0001193125-13-352036:notes:86]
|  |  | Fair Value as of July 26, 2013 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARS |  | $ | 42.2 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs – 11.2 yrs (8.3 yrs) |
|  |  |  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.7% - 2.9% (2.3%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.1% - 2.7% (1.5%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 3.7% - 5.7% (4.9%) |

[0001193125-13-352036:notes:87]
All of our ARS are classified as other non-current assets and
 are backed by pools of student loans guaranteed by the U.S.
 Department of Education. We estimate the fair value of each
 individual ARS using an income (discounted cash flow) and market
 approach that incorporate both observable and unobservable inputs.
 Key inputs into the discounted cash flow analysis include the
 time-to-economic maturity, liquidity risk premium, market credit
 spread and other factors and a coupon rate. The key input into the
 market approach is a discount rate. A significant increase
 (decrease) in the time-to-economic maturity, liquidity risk
 premium, market credit spread and other factors, coupon rate or
 discount rate could result in a significantly lower (higher) fair
 value estimate. We review the fair value of our Level 3 financial
 instruments for overall reasonableness by reviewing service
 provider pricing methodologies, key inputs and assumptions and by
 understanding the processes used by our third-party service
 provider. We will continue to monitor our ARS investments in light
 of the debt market environment and evaluate these investments for
 impairment and classification.

[0001193125-13-352036:notes:88]
The table below provides a reconciliation of the beginning and
 ending balance of our Level 3 ARS measured at fair value on a
 recurring basis using significant unobservable inputs (in
 millions):

[0001193125-13-352036:notes:89]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Balance at beginning of period |  | $ | 42.0 |  |  | $ | 51.0 |  |
| Total unrealized gains, net included in other comprehensive income (loss) |  |  | 0.2 |  |  |  | 0.3 |  |
| Settlements |  |  | 0.0 |  |  |  | (5.0 | ) |
| Balance at end of period |  | $ | 42.2 |  |  | $ | 46.3 |  |

[0001193125-13-352036:notes:90]
Fair Value of Debt

[0001193125-13-352036:notes:91]
As of July 26, 2013, the fair value of our 2.00% Senior
 Notes and 3.25% Senior Notes (collectively referred to as Senior
 Notes) was approximately $997.3 million. The fair value of our debt
 was based on observable market prices in a less active market and
 discounted cash flow models that take into consideration variables
 such as credit-rating and interest rate changes. All of our debt
 obligations are categorized as Level 2 instruments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-13-352036:notes:92]
6.  Balance Sheet Details

[0001193125-13-352036:notes:93]
Inventories (in millions):

[0001193125-13-352036:notes:94]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Purchased components |  | $ | 13.6 |  |  | $ | 16.3 |  |
| Finished goods |  |  | 102.9 |  |  |  | 123.2 |  |
| Inventories |  | $ | 116.5 |  |  | $ | 139.5 |  |

[0001193125-13-352036:notes:95]
Other current assets (in millions):

[0001193125-13-352036:notes:96]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Prepaid expenses and other current assets |  | $ | 212.6 |  |  | $ | 262.6 |  |
| Short-term restricted cash |  |  | 8.3 |  |  |  | 8.9 |  |
| Deferred tax assets |  |  | 246.9 |  |  |  | 253.7 |  |
| Other current assets |  | $ | 467.8 |  |  | $ | 525.2 |  |

[0001193125-13-352036:notes:97]
Property and equipment, net (in
 millions):

[0001193125-13-352036:notes:98]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Land and land improvements |  | $ | 265.7 |  |  | $ | 265.5 |  |
| Buildings and building improvements |  |  | 540.5 |  |  |  | 534.8 |  |
| Leasehold improvements |  |  | 101.0 |  |  |  | 100.3 |  |
| Computer, production, engineering and other equipment |  |  | 725.1 |  |  |  | 714.0 |  |
| Software |  |  | 432.8 |  |  |  | 422.6 |  |
| Furniture and fixtures |  |  | 83.7 |  |  |  | 82.2 |  |
| Construction-in-progress |  |  | 23.2 |  |  |  | 19.9 |  |
|  |  |  | 2,172.0 |  |  |  | 2,139.3 |  |
| Accumulated depreciation and amortization |  |  | (1,008.6 | ) |  |  | (968.4 | ) |
| Property and equipment, net |  | $ | 1,163.4 |  |  | $ | 1,170.9 |  |

[0001193125-13-352036:notes:99]
Software includes capitalized internal-use software development
 costs with a net book value as follows (in millions):

[0001193125-13-352036:notes:100]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Computer software |  | $ | 158.4 |  |  | $ | 162.5 |  |

[0001193125-13-352036:notes:101]
Other non-current assets (in
 millions):

[0001193125-13-352036:notes:102]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Auction rate securities |  | $ | 42.2 |  |  | $ | 42.0 |  |
| Deferred tax assets |  |  | 209.4 |  |  |  | 200.4 |  |
| Other assets |  |  | 247.5 |  |  |  | 242.2 |  |
| Other non-current assets |  | $ | 499.1 |  |  | $ | 484.6 |  |

[0001193125-13-352036:notes:103]
Short-term and long-term deferred revenue (in
 millions):

[0001193125-13-352036:notes:104]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Product |  | $ | 24.4 |  |  | $ | 15.7 |  |
| Software entitlements and maintenance and service |  |  | 2,916.9 |  |  |  | 2,993.8 |  |
| Total |  | $ | 2,941.3 |  |  | $ | 3,009.5 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,529.1 |  |  | $ | 1,563.3 |  |
| Long-term |  |  | 1,412.2 |  |  |  | 1,446.2 |  |
| Total |  | $ | 2,941.3 |  |  | $ | 3,009.5 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-13-352036:notes:105]
The following customers accounted for 10% or more of net
 accounts receivable:

[0001193125-13-352036:notes:106]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Arrow Electronics, Inc. |  |  | 13 | % |  |  | 16 | % |
| Avnet, Inc. |  |  | 11 | % |  |  | 14 | % |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-13-352036:notes:107]
5.  Purchased
 Intangible Assets, Net

[0001193125-13-352036:notes:108]
Purchased intangible assets, net are summarized below (in
 millions):

[0001193125-13-352036:notes:109]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 283.0 |  |  | $ | (119.8 | ) |  | $ | 163.2 |  |  | $ | 312.4 |  |  | $ | (134.9 | ) |  | $ | 177.5 |  |
| Customer contracts/relationships |  |  | 9.6 |  |  |  | (8.4 | ) |  |  | 1.2 |  |  |  | 54.7 |  |  |  | (53.1 | ) |  |  | 1.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.0 | ) |  |  | 0.9 |  |  |  | 9.9 |  |  |  | (8.9 | ) |  |  | 1.0 |  |
| Covenants not to compete |  |  | 1.6 |  |  |  | (1.2 | ) |  |  | 0.4 |  |  |  | 2.2 |  |  |  | (1.7 | ) |  |  | 0.5 |  |
| Total purchased intangible assets |  | $ | 297.1 |  |  | $ | (131.4 | ) |  | $ | 165.7 |  |  | $ | 379.2 |  |  | $ | (198.6 | ) |  | $ | 180.6 |  |

[0001193125-13-352036:notes:110]
Amortization expense for purchased intangible assets is
 summarized below (in millions):

[0001193125-13-352036:notes:111]
|  |  | Three Months Ended |  |  | Statements of Operations |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |  | Classifications |
| Developed technology |  | $ | 14.3 |  |  | $ | 13.9 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.4 |  |  |  | 6.3 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.1 |  |  |  | 1.0 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.1 |  |  |  | 0.2 |  |  | Operating expenses |
|  |  | $ | 14.9 |  |  | $ | 21.4 |  |  |  |

[0001193125-13-352036:notes:112]
As of July 26, 2013, future amortization expense related
 to purchased intangible assets is as follows (in
 millions):

[0001193125-13-352036:notes:113]
| Fiscal Year |  | Amount |  |
| Remainder of 2014 |  | $ | 44.3 |  |
| 2015 |  |  | 57.8 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 165.7 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-13-352036:notes:114]
Summarized revenues by geographic region based on information
 from our internal management system and utilized by our Chief
 Executive Officer, who is considered our Chief Operating Decision
 Maker, is as follows (in millions):

[0001193125-13-352036:notes:115]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Americas (United States, Canada and Latin America) |  | $ | 858.5 |  |  | $ | 801.1 |  |
| Europe, Middle East and Africa |  |  | 448.0 |  |  |  | 439.3 |  |
| Asia Pacific |  |  | 209.7 |  |  |  | 204.2 |  |
| Net revenues |  | $ | 1,516.2 |  |  | $ | 1,444.6 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-13-352036:notes:116]
The notional amount of our outstanding U.S. dollar equivalent
 foreign currency exchange forward contracts consisted of the
 following (in millions):

[0001193125-13-352036:notes:117]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 134.9 |  |  | $ | 108.4 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 143.8 |  |  |  | 158.2 |  |
| Forward contracts purchased |  |  | 272.8 |  |  |  | 358.4 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-13-352036:notes:118]
The following customers, each of which is a distributor,
 accounted for 10% or more of our net revenues:

[0001193125-13-352036:notes:119]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012(1) |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 17 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 14 | % |

[0001193125-13-352036:notes:120]
| (1) | Net revenues for Arrow Electronics, Inc. for the three months ended July 27, 2012 have been corrected from 16% previously disclosed to 17%. |


## us-gaap:ScheduleOfGuaranteeObligationsTextBlock

[0001193125-13-352036:notes:121]
The following schedule of financing guarantees represents the
 total maximum potential future payments under financing
 arrangements with third parties, and the related deferred revenue
 (in millions):

[0001193125-13-352036:notes:122]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 196.1 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (180.8 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 15.3 |  |  | $ | 13.8 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-13-352036:notes:123]
The following table summarizes our warranty reserves (in
 millions):

[0001193125-13-352036:notes:124]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Beginning balance |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 24.0 |  |  |  | 23.7 |  |
| Warranty costs incurred |  |  | (21.4 | ) |  |  | (10.3 | ) |
| Ending balance |  | $ | 119.8 |  |  | $ | 96.5 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-13-352036:notes:125]
The effect of derivative instruments not designated as hedging
 instruments recognized in other income, net on our condensed
 consolidated statements of operations was as follows (in
 millions):

[0001193125-13-352036:notes:126]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
|  |  | Gain Recognized into Income |  |
| Foreign currency exchange forward contracts |  | $ | 0.2 |  |  | $ | 15.9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-352036:notes:127]
12.  Income
 Taxes

[0001193125-13-352036:notes:128]
Our effective tax rates for the periods presented were as
 follows:

[0001193125-13-352036:notes:129]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Effective tax rates |  |  | 11.6 | % |  |  | 14.0 | % |

[0001193125-13-352036:notes:130]
Our effective tax rates reflect the impact of a significant
 amount of our earnings being taxed in foreign jurisdictions at
 rates below the U.S. statutory tax rate.

[0001193125-13-352036:notes:131]
As of July 26, 2013, we had $194.3 million of unrecognized
 tax benefits, of which $138.4 million has been recorded in other
 long-term liabilities. Unrecognized tax benefits of $124.1 million,
 including penalties and interest, would affect our provision for
 income taxes if recognized. During the three months ended
 July 26, 2013, there was a gross increase in our unrecognized
 tax benefits of $7.2 million for tax positions related to the
 current year, and a gross increase of $1.0 million and gross
 decrease, including settlements and statute lapses, of $3.5 million
 for tax positions related to prior years.

[0001193125-13-352036:notes:132]
Our fiscal 2005 through 2007 income tax returns are currently
 under audit by the IRS. In September 2012, we reached a tentative
 agreement with the IRS field examination team on certain transfer
 pricing matters under appeals, and in July 2013, we received a
 revised Revenue Agent’s Report (RAR) from the IRS. We are
 currently in the process of preparing for the review of the revised
 RAR by certain higher authorities within the IRS and the Joint
 Committee on Taxation. In February 2012, the IRS commenced an
 examination of our fiscal 2008 through fiscal 2010 income tax
 returns. Our open years in U.S. federal jurisdictions are fiscal
 2005 and later years. In addition, we are effectively subject to
 federal tax examination adjustments for tax years ended on or after
 fiscal year 2000, in that we have tax attribute carryforwards from
 these years that could be subject to adjustments, if and when
 utilized. We are also currently under audit by the California
 Franchise Tax Board for our fiscal 2007 and 2008 income tax
 returns.

[0001193125-13-352036:notes:133]
On September 17, 2010, the Danish Tax Authorities issued a
 decision concluding that distributions declared in 2005 and 2006
 from our Danish subsidiary were subject to Danish at-source
 dividend withholding tax. We do not believe that our Danish
 subsidiary is liable for withholding tax and filed an appeal with
 the Danish Tax Tribunal to that effect. On December 19, 2011,
 the Danish Tax Tribunal issued a ruling that our Danish subsidiary
 was not liable for Danish withholding tax. The Danish tax
 examination agency appealed to the Danish High Court in March
 2012.

[0001193125-13-352036:notes:134]
We are in various stages of the examination and appeals process
 in connection with tax audits worldwide, and it is difficult to
 determine when these examinations will be settled. It is reasonably
 possible that over the next twelve-month period, we may experience
 an increase or decrease in unrecognized tax benefits. It is not
 possible to determine either the magnitude or the range of any
 increase or decrease at this time.

[0001193125-13-352036:notes:135]
In April 2010, our Dutch subsidiary received a favorable tax
 ruling from the Dutch tax authorities effective May 1, 2010
 that replaces the previous Dutch tax ruling that expired on
 April 30, 2010. This ruling results in both a lower level of
 earnings subject to tax in the Netherlands and an extension of the
 expiration date to April 30, 2015.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-13-352036:notes:136]
As of July 26, 2013, our aggregate future principal debt
 maturities are as follows (in millions):

[0001193125-13-352036:notes:137]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-13-352036:notes:138]
8.  Financing
 Arrangements

[0001193125-13-352036:notes:139]
Long-term Debt

[0001193125-13-352036:notes:140]
The following table summarizes the carrying value of our
 long-term debt (in millions):

[0001193125-13-352036:notes:141]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.2 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total |  |  | 994.8 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.8 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

[0001193125-13-352036:notes:142]
N/A - Not
 Applicable

[0001193125-13-352036:notes:143]
Senior Notes

[0001193125-13-352036:notes:144]
Our Senior Notes are unsecured, unsubordinated obligations,
 which pay interest semi-annually on June 15 and
 December 15 and rank equally in right of payment with any
 future senior unsecured indebtedness. Interest expense associated
 with the Senior Notes was $6.3 million for the three months ended
 July 26, 2013.

[0001193125-13-352036:notes:145]
We may redeem the Senior Notes in whole or in part, at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of July 26, 2013,
 we were in compliance with all covenants associated with the Senior
 Notes.

[0001193125-13-352036:notes:146]
1.75% Convertible Senior Notes due 2013

[0001193125-13-352036:notes:147]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted based on a conversion rate of 31.40 shares of common
 stock per $1,000 principal amount of the Convertible Notes (which
 represented the effective conversion price of $31.85 per share).
 Upon conversion in June 2013, the holders received cash for the
 principal amount of the Convertible Notes and an aggregate of
 4.9 million shares of common stock for the $178.9 million
 excess of the conversion value over the principal
 amount.

[0001193125-13-352036:notes:148]
We separately accounted for the liability and equity components
 of the Convertible Notes. The initial debt component of the
 Convertible Notes was valued at $1,017.0 million based on the
 contractual cash flows discounted at an appropriate comparable
 market non-convertible debt borrowing rate at the date of issuance
 of 6.31%, with the equity component representing the residual
 amount of the proceeds of $248.0 million which was recorded as
 a debt discount. Issuance costs were allocated pro-rata based on
 the relative initial carrying amounts of the debt and equity
 components. As a result, $5.2 million of the issuance costs
 was allocated to the equity component of the Convertible Notes, and
 $21.4 million of the issuance costs remained classified as
 other non-current assets. The debt discount and the issuance costs
 allocated to the debt component were amortized as additional
 interest expense over the term of the Convertible Notes using the
 effective interest method.

[0001193125-13-352036:notes:149]
Convertible Note Hedges and Warrants

[0001193125-13-352036:notes:150]
Concurrent with the issuance of the Convertible Notes, we
 purchased Convertible Note hedges and sold warrants. The separate
 Convertible Note hedge and warrant transactions were structured to
 reduce the potential future economic dilution associated with the
 conversion of the Convertible Notes.

[0001193125-13-352036:notes:151]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges, for which we received an aggregate of 3.9 million
 shares from the counterparties.

[0001193125-13-352036:notes:152]
• Warrants: As of July 26, 2013, we had outstanding
 warrants for certain counterparties to acquire, subject to
 anti-dilution adjustments, 39.9 million shares of our common
 stock at an exercise price of $41.12 per share as adjusted to
 reflect our July 2013 dividend. Prior to the dividend, we had
 39.7 million outstanding warrants at an exercise price of
 $41.28 per share. The number of warrants and the exercise price are
 subject to additional adjustments for specified conditions,
 including future dividend declarations. The warrants are
 exercisable on a series of days commencing on September 3,
 2013 and ending on October 28, 2013. Upon exercise of the
 warrants, we have the option to deliver cash or shares of our
 common stock equal to the difference between the then market price
 and the strike price of the warrants.

[0001193125-13-352036:notes:153]
Interest Expense on Convertible Notes

[0001193125-13-352036:notes:154]
The following table presents the amount of interest expense
 related to the Convertible Notes (in millions):

[0001193125-13-352036:notes:155]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 2.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 7.1 |  |  |  | 13.5 |  |
| Amortization of debt issuance costs |  |  | 0.6 |  |  |  | 1.2 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (0.5 | ) |
| Total interest expense related to Convertible Notes |  | $ | 10.2 |  |  | $ | 19.7 |  |

[0001193125-13-352036:notes:156]
Debt Maturities

[0001193125-13-352036:notes:157]
Credit Facility

[0001193125-13-352036:notes:158]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that provides for an unsecured $250.0
 million five-year revolving credit facility that is comprised of
 revolving loans, Eurocurrency loans and/or swingline loans. The
 credit facility includes a $100.0 million foreign currency
 sub-facility, a $50.0 million letter of credit sub-facility and a
 $10.0 million swingline sub-facility available on same-day notice.
 Available borrowings under the credit facility are reduced by the
 amount of any outstanding borrowings on the sub-facilities. We may
 also, subject to certain requirements, request an increase in the
 facility up to an additional $100.0 million and request two
 additional one-year extensions, subject to certain conditions. The
 proceeds from the facility may be used by us for general corporate
 purposes.

[0001193125-13-352036:notes:159]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of July 26, 2013, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.

[0001193125-13-352036:notes:160]
Other Long-Term Financing Arrangements

[0001193125-13-352036:notes:161]
The following presents the amounts due under other long-term
 financing arrangements (in millions):

[0001193125-13-352036:notes:162]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 11.0 |  |  |  | 5.6 |  |
| Total |  | $ | 20.3 |  |  | $ | 10.8 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-352036:notes:163]
15.  Commitments and Contingencies

[0001193125-13-352036:notes:164]
Operating Lease Commitments

[0001193125-13-352036:notes:165]
As of July 26, 2013, future annual minimum lease payments
 under non-cancelable operating leases with an initial term in
 excess of one year totaled $217.1 million.

[0001193125-13-352036:notes:166]
Purchase Orders and Other Commitments

[0001193125-13-352036:notes:167]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of July 26, 2013, we had $336.3 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product sales. As of
 July 26, 2013 and April 26, 2013, such liability amounted
 to $9.3 million and $9.5 million, respectively, and is included in
 other current liabilities in our condensed consolidated balance
 sheets.

[0001193125-13-352036:notes:168]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course business for which
 we have not received goods or services. As of July 26, 2013,
 we had $71.5 million in capital purchase commitments and $181.2
 million in other purchase commitments.

[0001193125-13-352036:notes:169]
Product Warranties

[0001193125-13-352036:notes:170]
We provide customers a warranty on software of ninety days to
 five years and a warranty on hardware of one to five years. The
 following table summarizes our warranty reserves (in
 millions):

[0001193125-13-352036:notes:171]
Our warranty reserves were reported in our condensed
 consolidated balance sheets as follows (in millions):

[0001193125-13-352036:notes:172]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 81.8 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 38.0 |  |  |  | 35.6 |  |
| Total |  | $ | 119.8 |  |  | $ | 117.2 |  |

[0001193125-13-352036:notes:173]
Financing Guarantees

[0001193125-13-352036:notes:174]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 nonrecourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.

[0001193125-13-352036:notes:175]
To date, we have not experienced material losses under our
 lease financing programs or other financing
 arrangements.

[0001193125-13-352036:notes:176]
Legal Contingencies

[0001193125-13-352036:notes:177]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.

[0001193125-13-352036:notes:178]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of July 26, 2013 related to such matters as they
 are not probable and/or reasonably estimable.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-352036:notes:179]
14.  Segment,
 Geographic, and Significant Customer Information

[0001193125-13-352036:notes:180]
We operate in one industry segment: the design, manufacturing,
 marketing, and technical support of high-performance networked
 storage solutions. We conduct business globally, and our sales and
 support activities are managed on a geographic basis. Our
 management reviews financial information presented on a
 consolidated basis, accompanied by disaggregated information it
 receives from its internal management system about revenues by
 geographic region, based on the location from which the customer
 relationship is managed, for purposes of allocating resources and
 evaluating financial performance. We do not allocate costs of
 revenues, research and development, sales and marketing, or general
 and administrative expenses to our geographic regions using this
 internal management system because management does not review
 operations or operating results, or make planning decisions, below
 the consolidated entity level.

[0001193125-13-352036:notes:181]
Americas revenues consist of Americas commercial and U.S.
 public sector revenues. Sales to customers inside the United States
 comprised $772.8 million and $711.4 million of Americas net
 revenues during the three months ended July 26, 2013 and
 July 27, 2012, respectively. Sales to Germany were $146.7
 million, or 10% of net revenues, for the three months ended
 July 27, 2012. During the three months ended July 26,
 2013, sales to Germany were less than 10% of our net revenues. No
 other foreign country accounted for 10% or more of our net revenues
 for any period presented.

[0001193125-13-352036:notes:182]
The majority of our assets, excluding cash, cash equivalents,
 restricted cash, investments and accounts receivable, were
 attributable to our domestic operations. The following table
 presents cash, cash equivalents, restricted cash and investments
 held in the United States and internationally in various foreign
 subsidiaries (in millions):

[0001193125-13-352036:notes:183]
With the exception of property and equipment, we do not
 identify or allocate our long-lived assets by geographic area. The
 following table presents property and equipment information for
 geographic areas based on the physical location of the assets (in
 millions):


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-352036:notes:184]
10.  Derivatives and Hedging
 Activities

[0001193125-13-352036:notes:185]
We use derivative instruments to manage exposures to foreign
 currency risk. All contracts have a maturity of less than six
 months. The notional amount of our outstanding U.S. dollar
 equivalent foreign currency exchange forward contracts consisted of
 the following (in millions):

[0001193125-13-352036:notes:186]
We have in place master netting arrangements to mitigate the
 credit risk of our counterparties and to potentially reduce our
 losses due to counterparty nonperformance. We present our
 derivative instruments as net amounts in our condensed consolidated
 balance sheets. The gross and net fair value amounts of such
 instruments were not material as of July 26, 2013 and
 April 26, 2013. We did not recognize any gains and losses in
 earnings due to hedge ineffectiveness for any period
 presented.

[0001193125-13-352036:notes:187]
The effect of derivative instruments designated as cash flow
 hedges recognized in net revenues on our condensed consolidated
 statements of operations is presented in the condensed consolidated
 statements of comprehensive income and Note 9.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-13-352036:notes:188]
[same as prior period, unchanged from 0001193125-13-084667:notes:204]

[0001193125-13-352036:notes:189]
There have been no significant changes in our significant
 accounting policies as of and for the three months ended
 July 26, 2013, as compared to the significant accounting
 policies described in our Annual Report on Form 10-K for the fiscal
 year ended April 26, 2013.

[0001193125-13-352036:notes:190]
Recent Accounting Standards Not Yet Effective

[0001193125-13-352036:notes:191]
In July 2013, the Financial Accounting Standards Board issued
 an accounting standard update providing presentation requirements
 for unrecognized tax benefit when a net operating loss
 carryforward, a similar tax loss, or a similar tax credit
 carryforward exists. This accounting standard update will be
 effective for us beginning in our first quarter of fiscal 2015 and
 is not expected to have a significant impact on our consolidated
 financial statements.

[0001193125-13-352036:notes:192]
Use of Estimates — The preparation of the
 condensed consolidated financial statements in conformity with GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent assets and liabilities at the date of the financial
 statements and the reported amounts of revenues and expenses during
 the reporting periods. Such estimates include, but are not limited
 to, revenue recognition, reserves and allowances; inventory
 valuation and purchase order accruals; valuation of goodwill and
 intangibles; restructuring reserves; product warranties; employee
 benefit accruals; stock-based compensation; loss contingencies;
 investment impairments; income taxes and fair value measurements.
 Actual results could differ materially from those
 estimates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-13-352036:notes:193]
2.  Condensed
 Consolidated Financial Statements

[0001193125-13-352036:notes:194]
Fiscal Year — Our fiscal year is reported on
 a 52- or 53-week year ending on the last Friday in April. The first
 quarters of fiscal 2014 and 2013 were each 13-week
 periods.

[0001193125-13-352036:notes:195]
Basis of Presentation — The accompanying unaudited
 condensed consolidated financial statements have been prepared by
 the Company, and reflect all adjustments, consisting only of normal
 recurring adjustments, that are, in the opinion of management,
 necessary for the fair presentation of our financial position,
 results of operations, comprehensive income and cash flows for the
 interim periods presented. The statements have been prepared in
 accordance with accounting principles generally accepted in the
 United States of America (GAAP) for interim financial information
 and in accordance with the instructions to Form 10-Q and Rule 10-01
 of Regulation S-X. Accordingly, these statements do not include all
 information and footnotes required by GAAP for annual consolidated
 financial statements, and should be read in conjunction with our
 audited consolidated financial statements as of and for the fiscal
 year ended April 26, 2013 contained in our Annual Report on
 Form 10-K filed with the Securities and Exchange Commission on
 June 17, 2013. The results of operations for the three months
 ended July 26, 2013 are not necessarily indicative of the
 operating results to be expected for the full fiscal year or future
 operating periods.
