# NTAP 8-K — 0001102624-13-000997 filed 2013-08-14

## item codes, every 8-K on or before 2013-08-29

- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2013-08-29

- none on or before 2013-08-29

## item 2.02 — earnings release, exhibit 99.1

[0001102624-13-000997:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-13-000997:8k_2_02:2]
exh99_1.htm

[0001102624-13-000997:8k_2_02:3]
Exhibit No. 99.1

[0001102624-13-000997:8k_2_02:4]
| Press Contact: | Investor Contact: |
| Ryan Lowry | Kris Newton |
| NetApp | NetApp |
| (408) 822-7544 | (408) 822-3312 |
| ryanl@netapp.com | kris.newton@netapp.com |

[0001102624-13-000997:8k_2_02:5]
NETAPP REPORTS FISCAL YEAR 2014 FIRST QUARTER RESULTS

[0001102624-13-000997:8k_2_02:6]
Achieves Strongest Branded Revenue Growth in 7 Quarters, Up 9% Year-Over-Year

[0001102624-13-000997:8k_2_02:7]
| · | Revenues of $1.516 billion, up 5% year-over-year |

[0001102624-13-000997:8k_2_02:8]
| · | Non-GAAP EPS of $0.53, up 26% year-over-year |

[0001102624-13-000997:8k_2_02:9]
| · | Cash from Operations of $286 million, up 25% year-over-year |

[0001102624-13-000997:8k_2_02:10]
| · | $900 million returned to shareholders in share repurchases and cash dividends |

[0001102624-13-000997:8k_2_02:11]
Sunnyvale, Calif.—August 14, 2013—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2014 ended July 26, 2013.

[0001102624-13-000997:8k_2_02:12]
First Quarter Financial Results

[0001102624-13-000997:8k_2_02:13]
Total revenues for the first quarter of fiscal year 2014 were $1.516 billion, an increase of 5% from the comparable period of the prior year. GAAP net income for the first quarter of fiscal year 2014 was $82 million, or $0.23 per share,1 compared to GAAP net income of $64 million, or $0.17 per share, for the comparable period of the prior year. Non-GAAP net income for the first quarter of fiscal year 2014 was $192 million, or $0.53 per share,2 compared to non-GAAP net income of $156 million, or $0.42 per share, for the first quarter of fiscal 2013.

[0001102624-13-000997:8k_2_02:14]
Cash, Cash Equivalents and Investments

[0001102624-13-000997:8k_2_02:15]
NetApp ended the first quarter of 2014 with $5.084 billion of total cash, cash equivalents and investments and during the quarter generated approximately $286 million in cash from operations. The company returned $900 million to shareholders during the quarter through share repurchases and a cash dividend. The next dividend in the amount of $0.15 per share will be paid on October 25, 2013 to shareholders of record as of the close of business on October 21, 2013.

[0001102624-13-000997:8k_2_02:16]
“NetApp delivered solid results and innovation with the latest release to our clustered Data ONTAP® operating system,” said Tom Georgens, president and CEO. “Despite an uneven macro environment, our branded business was strong, with 9% year-over-year growth. This is evidence of the tremendous value we are delivering to customers today and their confidence in our long-term strategy to enable them to navigate the future.”

[0001102624-13-000997:8k_2_02:17]
6

[0001102624-13-000997:8k_2_02:18]
Q2 Fiscal Year 2014 Outlook

[0001102624-13-000997:8k_2_02:19]
The Company provided the following financial guidance for the second quarter of fiscal year 2014:

[0001102624-13-000997:8k_2_02:20]
| ● | Total revenue is expected to be in the range of $1.560 billion to $1.660 billion |

[0001102624-13-000997:8k_2_02:21]
| ● | GAAP earnings per share is expected to be in the range of $0.41 to $0.46 per share |

[0001102624-13-000997:8k_2_02:22]
| ● | Non-GAAP earnings per share is expected to be in the range of $0.60 to $0.65 per share |

[0001102624-13-000997:8k_2_02:23]
| ● | Diluted shares3 outstanding of approximately 351 million shares |

[0001102624-13-000997:8k_2_02:24]
Business Highlights

[0001102624-13-000997:8k_2_02:25]
In its first quarter of fiscal year 2014, NetApp delivered technology innovation focused on helping customers capitalize on cloud and mobility trends, while also strengthening its strategic relationships with industry-leading partners. Highlights include:

[0001102624-13-000997:8k_2_02:26]
| · | NetApp Introduces Data ONTAP 8.2. New enhancements to clustered Data ONTAP 8.2 provide organizations and cloud service providers the capability to rapidly and cost effectively deliver new services and capacity with maximum application uptime. Clustered Data ONTAP delivers native multi-tenant, policy-based storage services via programmable APIs and application integrations that are core tenants of a software-defined storage environment. |

[0001102624-13-000997:8k_2_02:27]
| · | NetApp Connect Delivers Mobile Access with Enterprise Level Data Protection. By keeping all data securely behind the corporate firewall, NetApp Connect offers mobile access to corporate data while maintaining the tight security and control that enterprise IT requires for keeping its data and business protected. |

[0001102624-13-000997:8k_2_02:28]
| · | NetApp and Cisco Expand the FlexPod® Platform. In a continuing effort to make data center infrastructures more responsive to applications’ dynamic needs, Cisco and NetApp broadened the FlexPod portfolio with a new offering called FlexPod Select and introduced new validated designs across the entire suite. FlexPod Select components include NetApp E-Series and FAS storage systems. |

[0001102624-13-000997:8k_2_02:29]
| · | NetApp Teams up with Microsoft to Accelerate Cloud Deployments. NetApp will invest $15 million in new ecosystem sales collaboration and continued technology integration with Microsoft to accelerate the adoption of enterprise cloud deployments. |

[0001102624-13-000997:8k_2_02:30]
| · | Clustered Data ONTAP integrates with Citrix Technologies. New solution integrations from NetApp and Citrix combine the benefits of clustered Data ONTAP with Citrix technologies for desktop and application virtualization, mobile collaboration, and cloud services. |

[0001102624-13-000997:8k_2_02:31]
| · | Microsoft’s Server Platform Partner of the Year. NetApp was named Microsoft’s Server Platform Partner of the Year for innovative storage solutions that enable nondisruptive operations and deliver optimal operational efficiency for virtualized environments and file services. |

[0001102624-13-000997:8k_2_02:32]
7

[0001102624-13-000997:8k_2_02:33]
Editor’s Note

[0001102624-13-000997:8k_2_02:34]
| · | Financial information previously found in the Supplemental Commentary document will now be included in the accompanying Supplemental Data tables of the quarterly financial press release. |

[0001102624-13-000997:8k_2_02:35]
| · | In addition, historical supplemental data tables, providing historical multi-period financial information, will be available on our investor relations website at investors.netapp.com. |

[0001102624-13-000997:8k_2_02:36]
Webcast and Conference Call Information

[0001102624-13-000997:8k_2_02:37]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and any other information related to the call will be posted on the Investor Relations website. An audio replay will also be available after 4:30 p.m. Pacific Time today on the website.

[0001102624-13-000997:8k_2_02:38]
About NetApp

[0001102624-13-000997:8k_2_02:39]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-13-000997:8k_2_02:40]
###

[0001102624-13-000997:8k_2_02:41]
NetApp, the NetApp logo, Go further, faster, Data ONTAP and FlexPod are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-13-000997:8k_2_02:42]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-13-000997:8k_2_02:43]
2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-13-000997:8k_2_02:44]
3Dilutive share count includes the estimated impact of our warrants, calculated based upon our average stock price of $41.56 for the first 10 trading days of our second quarter. Please refer to the table on our investor relations website which shows the impact on diluted share count for a range of stock prices.

[0001102624-13-000997:8k_2_02:45]
8

[0001102624-13-000997:8k_2_02:46]
NetApp Usage of Non-GAAP Financials

[0001102624-13-000997:8k_2_02:47]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-13-000997:8k_2_02:48]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-13-000997:8k_2_02:49]
9

[0001102624-13-000997:8k_2_02:50]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,084.0 |  |  | $ | 6,952.6 |  |
| Accounts receivable, net |  |  | 533.3 |  |  |  | 800.9 |  |
| Inventories |  |  | 116.5 |  |  |  | 139.5 |  |
| Other current assets |  |  | 467.8 |  |  |  | 525.2 |  |
| Total current assets |  |  | 6,201.6 |  |  |  | 8,418.2 |  |
| Property and equipment, net |  |  | 1,163.4 |  |  |  | 1,170.9 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,153.8 |  |  |  | 1,168.7 |  |
| Other non-current assets |  |  | 499.1 |  |  |  | 484.6 |  |
| Total assets |  | $ | 9,017.9 |  |  | $ | 11,242.4 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 218.7 |  |  | $ | 259.7 |  |
| Accrued compensation and other current liabilities |  |  | 582.3 |  |  |  | 749.8 |  |
| Current portion of long-term debt |  |  | - |  |  |  | 1,257.8 |  |
| Short-term deferred revenue |  |  | 1,529.1 |  |  |  | 1,563.3 |  |
| Total current liabilities |  |  | 2,330.1 |  |  |  | 3,830.6 |  |
| Long-term debt |  |  | 994.8 |  |  |  | 994.6 |  |
| Other long-term liabilities |  |  | 262.8 |  |  |  | 253.5 |  |
| Long-term deferred revenue |  |  | 1,412.2 |  |  |  | 1,446.2 |  |
| Total liabilities |  |  | 4,999.9 |  |  |  | 6,524.9 |  |
| Stockholders' equity |  |  | 4,018.0 |  |  |  | 4,717.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,017.9 |  |  | $ | 11,242.4 |  |

[0001102624-13-000997:8k_2_02:51]
10

[0001102624-13-000997:8k_2_02:52]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Revenues: |  |  |  |  |  |  |
| Product |  | $ | 930.8 |  |  | $ | 898.0 |  |
| Software entitlements and maintenance |  |  | 228.5 |  |  |  | 218.5 |  |
| Service |  |  | 356.9 |  |  |  | 328.1 |  |
| Net revenues |  |  | 1,516.2 |  |  |  | 1,444.6 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 449.9 |  |  |  | 452.2 |  |
| Cost of software entitlements and maintenance |  |  | 7.5 |  |  |  | 6.6 |  |
| Cost of service |  |  | 149.2 |  |  |  | 135.7 |  |
| Total cost of revenues |  |  | 606.6 |  |  |  | 594.5 |  |
| Gross profit |  |  | 909.6 |  |  |  | 850.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 467.8 |  |  |  | 482.9 |  |
| Research and development |  |  | 228.1 |  |  |  | 221.4 |  |
| General and administrative |  |  | 68.4 |  |  |  | 65.6 |  |
| Restructuring and other charges |  |  | 48.4 |  |  |  | - |  |
| Total operating expenses |  |  | 812.7 |  |  |  | 769.9 |  |
| Income from operations |  |  | 96.9 |  |  |  | 80.2 |  |
| Other expense, net: |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.0 |  |  |  | 10.8 |  |
| Interest expense |  |  | (16.5 | ) |  |  | (19.9 | ) |
| Other income, net |  |  | 1.9 |  |  |  | 3.1 |  |
| Total other expense, net |  |  | (4.6 | ) |  |  | (6.0 | ) |
| Income before income taxes |  |  | 92.3 |  |  |  | 74.2 |  |
| Provision for income taxes |  |  | 10.7 |  |  |  | 10.4 |  |
| Net income |  | $ | 81.6 |  |  | $ | 63.8 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | 0.17 |  |
| Diluted |  | $ | 0.23 |  |  | $ | 0.17 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 350.9 |  |  |  | 366.1 |  |
| Diluted |  |  | 359.9 |  |  |  | 371.2 |  |
| Cash dividends declared per share |  | $ | 0.15 |  |  | $ | - |  |

[0001102624-13-000997:8k_2_02:53]
11

[0001102624-13-000997:8k_2_02:54]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 81.6 |  |  | $ | 63.8 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 85.9 |  |  |  | 82.4 |  |
| Stock-based compensation |  |  | 66.3 |  |  |  | 79.2 |  |
| Accretion of discount and issuance costs on debt |  |  | 8.2 |  |  |  | 14.3 |  |
| Excess tax benefit from stock-based compensation |  |  | (0.1 | ) |  |  | (4.9 | ) |
| Other, net |  |  | (35.4 | ) |  |  | (32.8 | ) |
| Changes in assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 265.2 |  |  |  | 244.2 |  |
| Inventories |  |  | 22.9 |  |  |  | (42.2 | ) |
| Accounts payable |  |  | (37.9 | ) |  |  | 41.9 |  |
| Accrued compensation and other current liabilities |  |  | (175.4 | ) |  |  | (146.7 | ) |
| Deferred revenue |  |  | (54.3 | ) |  |  | (47.0 | ) |
| Changes in other operating assets and liabilities, net |  |  | 58.8 |  |  |  | (23.0 | ) |
| Net cash provided by operating activities |  |  | 285.8 |  |  |  | 229.2 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 390.0 |  |  |  | (66.1 | ) |
| Purchases of property and equipment |  |  | (65.3 | ) |  |  | (61.9 | ) |
| Other investing activities, net |  |  | 1.2 |  |  |  | 1.3 |  |
| Net cash provided by (used in) investing activities |  |  | 325.9 |  |  |  | (126.7 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 71.5 |  |  |  | 35.0 |  |
| Repurchase of common stock |  |  | (849.5 | ) |  |  | (150.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 0.1 |  |  |  | 4.9 |  |
| Repayment of debt |  |  | (1,264.9 | ) |  |  | - |  |
| Dividends paid |  |  | (51.4 | ) |  |  | - |  |
| Other financing activities, net |  |  | 9.5 |  |  |  | (2.0 | ) |
| Net cash used in financing activities |  |  | (2,084.7 | ) |  |  | (112.1 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7.3 | ) |  |  | (10.8 | ) |
| Net decrease in cash and cash equivalents |  |  | (1,480.3 | ) |  |  | (20.4 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,277.1 |  |  |  | 1,549.8 |  |
| End of period |  | $ | 1,796.8 |  |  | $ | 1,529.4 |  |

[0001102624-13-000997:8k_2_02:55]
12

[0001102624-13-000997:8k_2_02:56]
| NETAPP, INC. |
| SUPPLEMENTAL DATA |
| (In millions except percentages, DSO and Inventory Turns) |
| (Unaudited) |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 930.8 |  |  | $ | 1,137.8 |  |  | $ | 898.0 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 228.5 |  |  |  | 227.0 |  |  |  | 218.5 |  |
| Service Revenue: |  |  | 356.9 |  |  |  | 351.7 |  |  |  | 328.1 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 273.6 |  |  |  | 262.9 |  |  |  | 234.2 |  |
| Professional & Other Services Revenue |  |  | 83.2 |  |  |  | 88.8 |  |  |  | 93.9 |  |
| Net Revenue |  | $ | 1,516.2 |  |  | $ | 1,716.5 |  |  | $ | 1,444.6 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Branded Revenue |  | $ | 1,349.7 |  |  | $ | 1,551.0 |  |  | $ | 1,235.7 |  |
| OEM Revenue |  |  | 166.5 |  |  |  | 165.5 |  |  |  | 208.9 |  |
| Net Revenue |  | $ | 1,516.2 |  |  | $ | 1,716.5 |  |  | $ | 1,444.6 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY’14 Revenue |  |  | % of Q4 FY’13 Revenue |  |  | % of Q1 FY’13 Revenue |  |
| Americas* |  |  | 57 | % |  |  | 57 | % |  |  | 55 | % |
| Americas Commercial |  |  | 44 | % |  |  | 46 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 11 | % |  |  | 12 | % |
| EMEA |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |
| * Historical Americas Commercial and USPS revenue is recast as a result of reporting certain healthcare revenue in Americas Commercial revenue that was previously included |
| in U.S. Public Sector revenue. A reconciliation of this change is posted to our website at investors.netapp.com. |
| Pathways Mix |
|  |  | % of Q1 FY’14 Revenue |  |  | % of Q4 FY’13 Revenue |  |  | % of Q1 FY’13 Revenue |  |
| Direct |  |  | 20 | % |  |  | 19 | % |  |  | 22 | % |
| Indirect |  |  | 80 | % |  |  | 81 | % |  |  | 78 | % |
| Indirect revenues include those sold through value-added resellers, system integrators, OEM's and distributors. |  |  |  |  |  |  |  |  |  |  |  |  |
| Direct revenues are those sold through our direct sales force. The Direct / Indirect revenue mix reflects order fulfillment, not who owns the customer relationship. |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Non-GAAP Gross Margin |  |  | 61.3 | % |  |  | 61.3 | % |  |  | 60.3 | % |
| Product |  |  | 53.3 | % |  |  | 55.8 | % |  |  | 51.4 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 96.7 | % |  |  | 96.7 | % |  |  | 97.0 | % |
| Service |  |  | 59.5 | % |  |  | 56.2 | % |  |  | 60.3 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Non-GAAP Income from Operations |  | $ | 226.5 |  |  | $ | 291.0 |  |  | $ | 180.8 |  |
| % of Net Revenue |  |  | 14.9 | % |  |  | 17.0 | % |  |  | 12.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 230.1 |  |  | $ | 291.7 |  |  | $ | 189.1 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.6 | % |  |  | 13.4 | % |  |  | 17.3 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Non-GAAP Net Income |  | $ | 191.9 |  |  | $ | 252.5 |  |  | $ | 156.4 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 359.9 |  |  |  | 368.2 |  |  |  | 371.2 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.53 |  |  | $ | 0.69 |  |  | $ | 0.42 |  |
| Included in the dilutied weighted average common shares outstanding are 2.6 million, 3.2 million and 0.2 million shares in Q1 FY’14, Q4 FY’13 and Q1 FY’13 respectively, related to the impact of our convertible notes. |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Deferred Revenue |  | $ | 2,941.3 |  |  | $ | 3,009.5 |  |  | $ | 2,767.5 |  |
| DSO (days) |  |  | 32 |  |  |  | 42 |  |  |  | 37 |  |
| Inventory Turns |  |  | 20 |  |  |  | 19 |  |  |  | 11 |  |
| Days sales outstanding are defined as accounts receivable net divided by net revenue, multiplied by the number of days in the quarter. |  |
| Inventory turns are defined as annualized non-GAAP cost of revenues divided by net inventories. |  |  |  |  |  |  |  |  |  |  |  |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’14 |  |  | Q4 FY’13 |  |  | Q1 FY’13 |  |
| Net Cash Provided by Operating Activities |  | $ | 285.8 |  |  | $ | 455.6 |  |  | $ | 229.2 |  |
| Purchases of Property and Equipment |  | $ | 65.3 |  |  | $ | 63.6 |  |  | $ | 61.9 |  |
| Free Cash Flow |  | $ | 220.5 |  |  | $ | 392.0 |  |  | $ | 167.3 |  |
| Free Cash Flow as % of Total Revenue |  |  | 14.5 | % |  |  | 22.8 | % |  |  | 11.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |
| Some items may not add or recalculate due to rounding |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-13-000997:8k_2_02:57]
13

[0001102624-13-000997:8k_2_02:58]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| FINANCIAL STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |  | July 27, 2012 |  |
| NET INCOME |  | $ | 81.6 |  |  | $ | 173.8 |  |  | $ | 63.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.9 |  |  |  | 21.5 |  |  |  | 21.4 |  |
| Stock-based compensation |  |  | 66.3 |  |  |  | 65.1 |  |  |  | 79.2 |  |
| Restructuring and other charges |  |  | 48.4 |  |  |  | - |  |  |  | - |  |
| Non-cash interest expense |  |  | 8.2 |  |  |  | 16.2 |  |  |  | 14.3 |  |
| Income tax effect of non-GAAP adjustments |  |  | (27.5 | ) |  |  | (24.1 | ) |  |  | (22.3 | ) |
| NON-GAAP NET INCOME |  | $ | 191.9 |  |  | $ | 252.5 |  |  | $ | 156.4 |  |
| COST OF REVENUES |  | $ | 606.6 |  |  | $ | 684.3 |  |  | $ | 594.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.3 | ) |  |  | (14.1 | ) |  |  | (14.0 | ) |
| Stock-based compensation |  |  | (5.3 | ) |  |  | (5.8 | ) |  |  | (7.4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 587.0 |  |  | $ | 664.4 |  |  | $ | 573.1 |  |
| COST OF PRODUCT REVENUES |  | $ | 449.9 |  |  | $ | 517.9 |  |  | $ | 452.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.7 | ) |  |  | (13.5 | ) |  |  | (14.0 | ) |
| Stock-based compensation |  |  | (1.3 | ) |  |  | (1.4 | ) |  |  | (1.8 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 434.9 |  |  | $ | 503.0 |  |  | $ | 436.4 |  |
| COST OF SERVICE REVENUES |  | $ | 149.2 |  |  | $ | 159.0 |  |  | $ | 135.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | - |  |
| Stock-based compensation |  |  | (4.0 | ) |  |  | (4.4 | ) |  |  | (5.6 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 144.6 |  |  | $ | 154.0 |  |  | $ | 130.1 |  |
| GROSS PROFIT |  | $ | 909.6 |  |  | $ | 1,032.2 |  |  | $ | 850.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.3 |  |  |  | 14.1 |  |  |  | 14.0 |  |
| Stock-based compensation |  |  | 5.3 |  |  |  | 5.8 |  |  |  | 7.4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 929.2 |  |  | $ | 1,052.1 |  |  | $ | 871.5 |  |
| SALES AND MARKETING EXPENSES |  | $ | 467.8 |  |  | $ | 510.2 |  |  | $ | 482.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (7.4 | ) |  |  | (7.4 | ) |
| Stock-based compensation |  |  | (30.5 | ) |  |  | (30.4 | ) |  |  | (39.0 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 436.7 |  |  | $ | 472.4 |  |  | $ | 436.5 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 228.1 |  |  | $ | 243.4 |  |  | $ | 221.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (21.4 | ) |  |  | (20.3 | ) |  |  | (23.7 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 206.7 |  |  | $ | 223.1 |  |  | $ | 197.7 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 68.4 |  |  | $ | 74.2 |  |  | $ | 65.6 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9.1 | ) |  |  | (8.6 | ) |  |  | (9.1 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 59.3 |  |  | $ | 65.6 |  |  | $ | 56.5 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | 48.4 |  |  | $ | - |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (48.4 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 812.7 |  |  | $ | 827.8 |  |  | $ | 769.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (7.4 | ) |  |  | (7.4 | ) |
| Stock-based compensation |  |  | (61.0 | ) |  |  | (59.3 | ) |  |  | (71.8 | ) |
| Restructuring and other charges |  |  | (48.4 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 702.7 |  |  | $ | 761.1 |  |  | $ | 690.7 |  |
| INCOME FROM OPERATIONS |  | $ | 96.9 |  |  | $ | 204.4 |  |  | $ | 80.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.9 |  |  |  | 21.5 |  |  |  | 21.4 |  |
| Stock-based compensation |  |  | 66.3 |  |  |  | 65.1 |  |  |  | 79.2 |  |
| Restructuring and other charges |  |  | 48.4 |  |  |  | - |  |  |  | - |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 226.5 |  |  | $ | 291.0 |  |  | $ | 180.8 |  |
| TOTAL OTHER EXPENSE, NET |  | $ | (4.6 | ) |  | $ | (15.5 | ) |  | $ | (6.0 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-cash interest expense |  |  | 8.2 |  |  |  | 16.2 |  |  |  | 14.3 |  |
| NON-GAAP TOTAL OTHER INCOME, NET |  | $ | 3.6 |  |  | $ | 0.7 |  |  | $ | 8.3 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 92.3 |  |  | $ | 188.9 |  |  | $ | 74.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.9 |  |  |  | 21.5 |  |  |  | 21.4 |  |
| Stock-based compensation |  |  | 66.3 |  |  |  | 65.1 |  |  |  | 79.2 |  |
| Restructuring and other charges |  |  | 48.4 |  |  |  | - |  |  |  | - |  |
| Non-cash interest expense |  |  | 8.2 |  |  |  | 16.2 |  |  |  | 14.3 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 230.1 |  |  | $ | 291.7 |  |  | $ | 189.1 |  |
| PROVISION FOR INCOME TAXES |  | $ | 10.7 |  |  | $ | 15.1 |  |  | $ | 10.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 27.5 |  |  |  | 24.1 |  |  |  | 22.3 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 38.2 |  |  | $ | 39.2 |  |  | $ | 32.7 |  |
| NET INCOME PER SHARE |  | $ | 0.227 |  |  | $ | 0.472 |  |  | $ | 0.172 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.041 |  |  |  | 0.058 |  |  |  | 0.058 |  |
| Stock-based compensation |  |  | 0.184 |  |  |  | 0.177 |  |  |  | 0.213 |  |
| Restructuring and other charges |  |  | 0.134 |  |  |  | - |  |  |  | - |  |
| Non-cash interest expense |  |  | 0.023 |  |  |  | 0.044 |  |  |  | 0.038 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.076 | ) |  |  | (0.065 | ) |  |  | (0.060 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.533 |  |  | $ | 0.686 |  |  | $ | 0.421 |  |

[0001102624-13-000997:8k_2_02:59]
14

[0001102624-13-000997:8k_2_02:60]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | SECOND QUARTER 2014 |
|  | (Unaudited) |
|  | Second Quarter |
|  | 2014 |
| Non-GAAP Guidance - Net Income Per Share | $0.60 - $0.65 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Second |  |
| Quarter 2014: |  |
| Amortization of intangible assets | (0.04) |
| Stock-based compensation expense | (0.20) |
| Income tax effect | 0.05 |
| Total Adjustments | (0.19) |
| GAAP Guidance - Net Income Per Share | $0.41 - $0.46 |

[0001102624-13-000997:8k_2_02:61]
15
