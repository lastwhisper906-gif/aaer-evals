# NTAP notes — 0001564590-21-033645


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-21-033645:notes:1]
The information called for by Part III of this Form 10-K is hereby incorporated by reference from the definitive Proxy Statement for our annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after April 30, 2021.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-21-033645:notes:2]
1. Description of Business and Significant Accounting Policies

[0001564590-21-033645:notes:3]
Description of Business — NetApp, Inc. (we, us, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-21-033645:notes:4]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2021, ending on April 30, 2021 is a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2020, which ended on April 24, 2020, and fiscal year 2019, which ended on April 26, 2019 were both 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-21-033645:notes:5]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-21-033645:notes:6]
Accounting Changes

[0001564590-21-033645:notes:7]
In June 2016, the FASB issued an accounting standards update on the measurement of credit losses on financial instruments. The standard introduces a new model for measuring and recognizing credit losses on financial instruments, requiring financial assets measured at amortized cost basis to be presented at the net amount expected to be collected. It also requires that credit losses be recorded through an allowance for credit losses. On April 25, 2020, we adopted the standard with no material impact to our consolidated financial statements.

[0001564590-21-033645:notes:8]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, including impacts from the COVID-19 pandemic, the anticipated effects of which have been incorporated, as applicable, into management’s estimates as of and for the year ended April 30, 2021.

[0001564590-21-033645:notes:9]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-21-033645:notes:10]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit. These investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-21-033645:notes:11]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses are calculated based on the specific identification method.

[0001564590-21-033645:notes:12]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-21-033645:notes:13]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected

[0001564590-21-033645:notes:14]
and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-21-033645:notes:15]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value. Net realizable value is estimated using management’s best estimate of forecasts for future demand and expectations regarding market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-21-033645:notes:16]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-21-033645:notes:17]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-21-033645:notes:18]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-21-033645:notes:19]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-21-033645:notes:20]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-21-033645:notes:21]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-21-033645:notes:22]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of income.

[0001564590-21-033645:notes:23]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are generally amortized on a straight-line basis over their economic lives of three to five years for developed technology, two to five years for customer contracts/relationships, two to three years for covenants not to compete and two to five years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001564590-21-033645:notes:24]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have a single reporting unit. The performance of the quantitative impairment test requires comparing the fair value of our reporting unit to its carrying amount, including goodwill. The fair value of our reporting unit is based on our entity level market capitalization, as determined through quoted market prices. An impairment exists if the fair value of our reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the

[0001564590-21-033645:notes:25]
carrying amount of our reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of goodwill. The fair value of our reporting unit has substantially exceeded its carrying amount in all periods presented.

[0001564590-21-033645:notes:26]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of income when such determinations are made.

[0001564590-21-033645:notes:27]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0001564590-21-033645:notes:28]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001564590-21-033645:notes:29]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of income. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions.

[0001564590-21-033645:notes:30]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001564590-21-033645:notes:31]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0001564590-21-033645:notes:32]
|  | • | Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria: |

[0001564590-21-033645:notes:33]
|  | - | It is enforceable |

[0001564590-21-033645:notes:34]
|  | - | It defines each party’s rights |

[0001564590-21-033645:notes:35]
|  | - | It identifies the payment terms |

[0001564590-21-033645:notes:36]
|  | - | It has commercial substance, and |

[0001564590-21-033645:notes:37]
|  | - | We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay |

[0001564590-21-033645:notes:38]
|  | • | Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct. |

[0001564590-21-033645:notes:39]
|  | • | Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer. |

[0001564590-21-033645:notes:40]
|  | • | Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation. |

[0001564590-21-033645:notes:41]
|  | • | Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time. |

[0001564590-21-033645:notes:42]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0001564590-21-033645:notes:43]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0001564590-21-033645:notes:44]
Our contracts with customers may include hardware systems, software licenses, software support, hardware support and other services. Software support contracts entitle our customers to receive unspecified upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware support services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0001564590-21-033645:notes:45]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract.

[0001564590-21-033645:notes:46]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. A configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware support, software support, and different types of professional services are each separate performance obligations.

[0001564590-21-033645:notes:47]
In certain instances, we enter into enterprise license agreements (ELAs) with our customers which transfer to them the right to deploy an unlimited or capped number of OS or optional add-on software licenses and obligate us to provide software support through the ELA term. In general, we treat the software license component and software support component of ELAs as separate performance obligations.

[0001564590-21-033645:notes:48]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell professional services either on a time and materials basis or under fixed price projects.

[0001564590-21-033645:notes:49]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0001564590-21-033645:notes:50]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0001564590-21-033645:notes:51]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward completion of the performance obligation. Our stand-ready services, including both hardware and software support, are transferred ratably over the period of the contract. For other services such as our fixed professional services contracts, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0001564590-21-033645:notes:52]
Deferred Commissions — We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of income.

[0001564590-21-033645:notes:53]
Leases — We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our consolidated balance sheets, operating lease right-of-use (ROU) assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0001564590-21-033645:notes:54]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0001564590-21-033645:notes:55]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0001564590-21-033645:notes:56]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For international subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other (expense) income, net.

[0001564590-21-033645:notes:57]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-21-033645:notes:58]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-21-033645:notes:59]
The fair value of employee time-based RSUs, and PBRSUs that include a performance condition, is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0001564590-21-033645:notes:60]
The fair value of time-based RSUs, and PBRSUs that include a market condition, is not remeasured as a result of subsequent stock price fluctuations. When there is a change in management’s estimate of expected achievement relative to the performance target for PBRSUs that include a performance condition, such as our achievement against a cumulative Adjusted Operating Income target, the change in estimate results in the recognition of a cumulative adjustment of stock-based compensation expense.

[0001564590-21-033645:notes:61]
Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-21-033645:notes:62]
We account for forfeitures of stock-based awards as they occur.

[0001564590-21-033645:notes:63]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001564590-21-033645:notes:64]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the provision for income taxes line on the accompanying consolidated statements of income.

[0001564590-21-033645:notes:65]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to the weighted-average number of dilutive potential shares that were outstanding during the period using the treasury stock method. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0001564590-21-033645:notes:66]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-21-033645:notes:67]
2. Recent Accounting Pronouncements

[0001564590-21-033645:notes:68]
Although there are several new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results or disclosures.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-21-033645:notes:69]
3. Concentration of Risk

[0001564590-21-033645:notes:70]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer. The COVID-19 pandemic has led to an increase in market volatility and liquidity challenges for certain companies. However, it has not currently resulted in a material increase in the credit risk associated with our financial instruments.

[0001564590-21-033645:notes:71]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-21-033645:notes:72]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information, including the expected impact of macroeconomic disruptions such as the COVID-19 pandemic, and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-21-033645:notes:73]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption, including as a result of the COVID-19 pandemic, or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-033645:notes:74]
4. Business Combinations

[0001564590-21-033645:notes:75]
Fiscal 2021 Acquisitions

[0001564590-21-033645:notes:76]
Cloud Jumper Corporation Acquisition

[0001564590-21-033645:notes:77]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation (Cloud Jumper), a provider of virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for $34 million in cash.

[0001564590-21-033645:notes:78]
The acquisition date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0001564590-21-033645:notes:79]
|  |  | Amount |  |
| Developed technology |  | $ | 16 |  |
| Customer contracts/relationships |  |  | 6 |  |
| Goodwill |  |  | 12 |  |
| Other assets |  |  | 1 |  |
| Total assets acquired |  |  | 35 |  |
| Liabilities assumed |  |  | (1 | ) |
| Total purchase price |  | $ | 34 |  |

[0001564590-21-033645:notes:80]
Spot, Inc. Acquisition

[0001564590-21-033645:notes:81]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. (Spot), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash. The acquisition of Spot will allow us to establish an application driven infrastructure for the continuous optimization of both compute and storage, which we believe will facilitate customers deploying more applications to the cloud.

[0001564590-21-033645:notes:82]
|  |  | Amount |  |
| Cash |  | $ | 24 |  |
| Intangible assets |  |  | 84 |  |
| Goodwill |  |  | 249 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 363 |  |
| Liabilities assumed |  |  | (23 | ) |
| Total purchase price |  | $ | 340 |  |

[0001564590-21-033645:notes:83]
The components of the Spot intangible assets acquired were as follows (in millions, except useful life):

[0001564590-21-033645:notes:84]
|  |  |  |  |  |  | Estimated useful life |  |
|  |  | Amount |  |  | (years) |  |
| Developed technology |  | $ | 53 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 28 |  |  |  | 5 |  |
| Trade name |  |  | 3 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 84 |  |  |  |  |  |

[0001564590-21-033645:notes:85]
The acquired assets and assumed liabilities of Spot and Cloud Jumper were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing Spot and Cloud Jumper sales channels and product development resources, and utilize their existing workforces. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with both of these acquisitions. The goodwill is not deductible for income tax purposes.

[0001564590-21-033645:notes:86]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions would not have been material to our consolidated results of operations for each of the fiscal years ended April 30, 2021 and April 24, 2020.

[0001564590-21-033645:notes:87]
Fiscal 2020 Acquisitions

[0001564590-21-033645:notes:88]
Talon Storage Solutions, Inc. Acquisition

[0001564590-21-033645:notes:89]
On March 6, 2020, we acquired all the outstanding shares of privately-held Talon Storage Solutions, Inc., a provider of next generation software-defined storage solutions, for $23 million in cash.

[0001564590-21-033645:notes:90]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 6 |  |
| Customer contracts/relationships |  |  | 4 |  |
| Other assets |  |  | 4 |  |
| Goodwill |  |  | 13 |  |
| Total assets acquired |  |  | 29 |  |
| Liabilities assumed |  |  | (6 | ) |
| Total purchase price |  | $ | 23 |  |

[0001564590-21-033645:notes:91]
Cognigo Research Ltd. Acquisition

[0001564590-21-033645:notes:92]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for $53 million in cash.

[0001564590-21-033645:notes:93]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 26 |  |
| Goodwill |  |  | 30 |  |
| Total assets acquired |  |  | 58 |  |
| Liabilities assumed |  |  | (5 | ) |
| Total purchase price |  | $ | 53 |  |

[0001564590-21-033645:notes:94]
Fiscal 2019 Acquisition

[0001564590-21-033645:notes:95]
On September 17, 2018, we acquired all of the outstanding shares of a privately-held software company for $3 million in cash. Substantially all of the purchase price was recorded to goodwill.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-21-033645:notes:96]
5. Goodwill and Purchased Intangible Assets, Net

[0001564590-21-033645:notes:97]
Goodwill activity is summarized as follows (in millions):

[0001564590-21-033645:notes:98]
|  |  | Amount |  |
| Balance as of April 26, 2019 |  | $ | 1,735 |  |
| Additions |  |  | 43 |  |
| Balance as of April 24, 2020 |  |  | 1,778 |  |
| Additions |  |  | 261 |  |
| Balance as of April 30, 2021 |  | $ | 2,039 |  |

[0001564590-21-033645:notes:99]
We derecognized goodwill during fiscal 2019 in connection with our contribution of a group of assets to a newly formed joint venture with Lenovo in exchange for a non-controlling ownership interest in the new entity. Refer to Note 6 – Supplemental Financial Information for additional details.

[0001564590-21-033645:notes:100]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-21-033645:notes:101]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 215 |  |  | $ | (147 | ) |  | $ | 68 |  |  | $ | 192 |  |  | $ | (152 | ) |  | $ | 40 |  |
| Customer contracts/relationships |  |  | 38 |  |  |  | (8 | ) |  |  | 30 |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total purchased intangible assets |  | $ | 256 |  |  | $ | (155 | ) |  | $ | 101 |  |  | $ | 196 |  |  | $ | (152 | ) |  | $ | 44 |  |

[0001564590-21-033645:notes:102]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-21-033645:notes:103]
|  |  | Year Ended |  |  | Statements of |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | Income Classifications |
| Developed technology |  | $ | 41 |  |  | $ | 39 |  |  | $ | 36 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 8 |  |  |  | — |  |  |  | 10 |  |  | Operating expenses |
| Total |  | $ | 49 |  |  | $ | 39 |  |  | $ | 46 |  |  |  |

[0001564590-21-033645:notes:104]
As of April 30, 2021, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-21-033645:notes:105]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | 36 |  |
| 2023 |  | 29 |  |
| 2024 |  | 17 |  |
| 2025 |  | 16 |  |
| 2026 |  | 3 |  |
| Total |  | $ | 101 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-033645:notes:106]
6. Supplemental Financial Information

[0001564590-21-033645:notes:107]
Cash and cash equivalents (in millions):

[0001564590-21-033645:notes:108]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statements of cash flows:

[0001564590-21-033645:notes:109]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Cash and cash equivalents |  | $ | 4,529 |  |  | $ | 2,658 |  |
| Restricted cash |  |  | 6 |  |  |  | 8 |  |
| Cash, cash equivalents and restricted cash |  | $ | 4,535 |  |  | $ | 2,666 |  |

[0001564590-21-033645:notes:110]
Inventories (in millions):

[0001564590-21-033645:notes:111]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Purchased components |  | $ | 22 |  |  | $ | 28 |  |
| Finished goods |  |  | 92 |  |  |  | 117 |  |
| Inventories |  | $ | 114 |  |  | $ | 145 |  |

[0001564590-21-033645:notes:112]
Property and equipment, net (in millions):

[0001564590-21-033645:notes:113]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Land |  | $ | 46 |  |  | $ | 103 |  |
| Buildings and improvements |  |  | 356 |  |  |  | 597 |  |
| Leasehold improvements |  |  | 83 |  |  |  | 89 |  |
| Computer, production, engineering and other equipment |  |  | 869 |  |  |  | 802 |  |
| Computer software |  |  | 305 |  |  |  | 359 |  |
| Furniture and fixtures |  |  | 93 |  |  |  | 106 |  |
| Construction-in-progress |  |  | 46 |  |  |  | 32 |  |
|  |  |  | 1,798 |  |  |  | 2,088 |  |
| Accumulated depreciation and amortization |  |  | (1,273 | ) |  |  | (1,361 | ) |
| Property and equipment, net |  | $ | 525 |  |  | $ | 727 |  |

[0001564590-21-033645:notes:114]
In April 2021, we announced the sale of our corporate headquarters located in Sunnyvale, California, consisting primarily of land, buildings and improvements, for cash proceeds of $365 million. The assets sold had a net book value totaling $210 million. To facilitate an orderly transition to a new location, we executed short-term lease agreements with the buyer to lease back these properties. The agreed lease payments were below market rates and as a result we recognized an asset of $7 million for the difference between the fair value of the leases and the agreed lease payments. The cash proceeds, less direct selling costs, plus the fair value of the below-market leases, resulted in a net gain on the sale of these properties of $156 million.

[0001564590-21-033645:notes:115]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California through two separate and independent closings. The first closing occurred in fiscal 2018. On August 26, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-21-033645:notes:116]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-21-033645:notes:117]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Depreciation and amortization expense |  | $ | 158 |  |  | $ | 154 |  |  | $ | 150 |  |

[0001564590-21-033645:notes:118]
Other non-current assets (in millions):

[0001564590-21-033645:notes:119]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Deferred tax assets |  | $ | 219 |  |  | $ | 220 |  |
| Operating lease ROU assets |  |  | 114 |  |  |  | 137 |  |
| Other assets |  |  | 361 |  |  |  | 342 |  |
| Other non-current assets |  | $ | 694 |  |  | $ | 699 |  |

[0001564590-21-033645:notes:120]
During fiscal 2019, we formed a joint venture with Lenovo (Beijing) Information Technology Ltd. (“Lenovo”) in China and, in February 2019, contributed assets to the newly formed entity, Lenovo NetApp Technology Limited (“LNTL”), in exchange for a non-controlling 49% equity interest. The group of assets we contributed and derecognized met the definition of a business and included cash, fixed assets, customer relationships and an allocation of goodwill, with an aggregate book value of $7 million. The fair value of our equity interest in LNTL of $80 million, based on discounted cash flows, resulted in a non-cash gain of $73 million. We accounted for our ownership interest as an equity method investment and have presented it in other non-current assets on our consolidated balance sheets. The book value of our investment as of April 30, 2021 and April 24, 2020 was $71 million and $67 million, respectively. The book value as of April 24, 2020 reflected a $10 million other-than-temporary impairment charge recorded to other (expense) income, net in the fourth quarter of fiscal 2020 attributable to a decline in growth rate projections for LNTL, in part due to the COVID-19 pandemic.

[0001564590-21-033645:notes:121]
LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. It will also endeavor to localize our products and services, and to develop new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001564590-21-033645:notes:122]
Accrued expenses (in millions):

[0001564590-21-033645:notes:123]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Accrued compensation and benefits |  | $ | 505 |  |  | $ | 322 |  |
| Product warranty liabilities |  |  | 21 |  |  |  | 26 |  |
| Operating lease liabilities |  |  | 49 |  |  |  | 51 |  |
| Other current liabilities |  |  | 395 |  |  |  | 375 |  |
| Accrued expenses |  | $ | 970 |  |  | $ | 774 |  |

[0001564590-21-033645:notes:124]
Product warranty liabilities:

[0001564590-21-033645:notes:125]
Equipment and software systems sales include a standard product warranty. Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience.

[0001564590-21-033645:notes:126]
The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-21-033645:notes:127]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Balance at beginning of period |  | $ | 41 |  |  | $ | 40 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 13 |  |  |  | 26 |  |  |  | 22 |  |
| Warranty costs incurred |  |  | (22 | ) |  |  | (25 | ) |  |  | (22 | ) |
| Balance at end of period |  | $ | 32 |  |  | $ | 41 |  |  | $ | 40 |  |

[0001564590-21-033645:notes:128]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Accrued expenses |  | $ | 21 |  |  | $ | 26 |  |
| Other long-term liabilities |  |  | 11 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 32 |  |  | $ | 41 |  |

[0001564590-21-033645:notes:129]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-21-033645:notes:130]
Other long-term liabilities (in millions):

[0001564590-21-033645:notes:131]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Liability for uncertain tax positions |  | $ | 127 |  |  | $ | 136 |  |
| Income taxes payable |  |  | 351 |  |  |  | 399 |  |
| Product warranty liabilities |  |  | 11 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 71 |  |  |  | 93 |  |
| Other liabilities |  |  | 90 |  |  |  | 71 |  |
| Other long-term liabilities |  | $ | 650 |  |  | $ | 714 |  |

[0001564590-21-033645:notes:132]
Other (expense) income, net (in millions):

[0001564590-21-033645:notes:133]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Interest income |  | $ | 9 |  |  | $ | 48 |  |  | $ | 88 |  |
| Interest expense |  |  | (74 | ) |  |  | (55 | ) |  |  | (58 | ) |
| Other income, net |  |  | (4 | ) |  |  | 6 |  |  |  | 17 |  |
| Other (expense) income, net |  | $ | (69 | ) |  | $ | (1 | ) |  | $ | 47 |  |

[0001564590-21-033645:notes:134]
Statements of cash flows additional information (in millions):

[0001564590-21-033645:notes:135]
Supplemental cash flow information related to our operating leases is included in Note 10 – Leases. Non-cash investing and other supplemental cash flow information are presented below:

[0001564590-21-033645:notes:136]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 15 |  |  | $ | 15 |  |  | $ | 9 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 338 |  |  | $ | 276 |  |  | $ | 205 |  |
| Interest paid |  | $ | 57 |  |  | $ | 50 |  |  | $ | 53 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-033645:notes:137]
7. Revenue

[0001564590-21-033645:notes:138]
Disaggregation of revenue

[0001564590-21-033645:notes:139]
Product revenues include the sale of our hardware and software solutions across our entire product set, including All-Flash FAS, SolidFire, EF-series, Hybrid FAS, E-series, NetApp HCI, and StorageGrid. In addition to the sale of our products and solutions, we provide a variety of services to our customers, including software support, hardware support and other services including professional services, and customer education and training. Revenues generated by our Public Cloud Services (formerly referred to as Cloud Data Services) offerings, are included in software support revenues.

[0001564590-21-033645:notes:140]
The following table depicts the disaggregation of revenue by our products and services (in millions):

[0001564590-21-033645:notes:141]
|  | Year Ended |  |
|  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Product revenues | $ | 2,991 |  |  | $ | 2,995 |  |  | $ | 3,755 |  |
| Software support revenues |  | 1,281 |  |  |  | 1,034 |  |  |  | 946 |  |
| Hardware support and other services revenues |  | 1,472 |  |  |  | 1,383 |  |  |  | 1,445 |  |
| Hardware support contracts |  | 1,195 |  |  |  | 1,142 |  |  |  | 1,182 |  |
| Professional and other services |  | 277 |  |  |  | 241 |  |  |  | 263 |  |
| Net revenues | $ | 5,744 |  |  | $ | 5,412 |  |  | $ | 6,146 |  |

[0001564590-21-033645:notes:142]
Revenues by geographic region are presented in Note 16 – Segment, Geographic, and Significant Customer Information.

[0001564590-21-033645:notes:143]
Deferred revenue and financed unearned services revenue:

[0001564590-21-033645:notes:144]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our consolidated balance sheets (in millions):

[0001564590-21-033645:notes:145]
|  | April 30, 2021 |  |  | April 20, 2020 |  |
| Deferred product revenue | $ | 59 |  |  | $ | 75 |  |
| Deferred services revenue |  | 3,873 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  | 71 |  |  |  | 56 |  |
| Total | $ | 4,003 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |
| Short-term | $ | 2,062 |  |  | $ | 1,894 |  |
| Long-term |  | 1,941 |  |  |  | 1,804 |  |
| Total | $ | 4,003 |  |  | $ | 3,698 |  |

[0001564590-21-033645:notes:146]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 18 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-21-033645:notes:147]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

[0001564590-21-033645:notes:148]
|  | Year Ended |  |
|  | April 30, 2021 |  |  | April 20, 2020 |  |
| Balance at beginning of period | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  | 3,191 |  |  |  | 2,513 |  |
| Revenue recognized during the period |  | (2,886 | ) |  |  | (2,483 | ) |
| Balance at end of period | $ | 4,003 |  |  | $ | 3,698 |  |

[0001564590-21-033645:notes:149]
During the years ended April 30, 2021 and April 24, 2020, we recognized $1,894 million and $1,822 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-21-033645:notes:150]
As of April 30, 2021, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $4,003 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 52% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-21-033645:notes:151]
Deferred commissions

[0001564590-21-033645:notes:152]
The following tables summarize the activity related to deferred commissions and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-21-033645:notes:153]
|  | Year Ended |  |
|  | April 30, 2021 |  |  | April 24, 2020 |  |
| Balance at beginning of period | $ | 156 |  |  | $ | 172 |  |
| Additions |  | 142 |  |  |  | 79 |  |
| Expense recognized during the period |  | (101 | ) |  |  | (95 | ) |
| Balance at end of period | $ | 197 |  |  | $ | 156 |  |

[0001564590-21-033645:notes:154]
|  | April 30, 2021 |  |  | April 24, 2020 |  |
| Other current assets | $ | 86 |  |  | $ | 67 |  |
| Other non-current assets |  | 111 |  |  |  | 89 |  |
| Total deferred commissions | $ | 197 |  |  | $ | 156 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-033645:notes:155]
8. Financial Instruments and Fair Value Measurements

[0001564590-21-033645:notes:156]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-21-033645:notes:157]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-21-033645:notes:158]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-21-033645:notes:159]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-21-033645:notes:160]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-21-033645:notes:161]
Investments

[0001564590-21-033645:notes:162]
The following is a summary of our investments at their cost or amortized cost for the years ended April 30, 2021 and April 24, 2020 (in millions):

[0001564590-21-033645:notes:163]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Corporate bonds |  | $ | 58 |  |  | $ | 155 |  |
| U.S. Treasury and government debt securities |  |  | 8 |  |  |  | 68 |  |
| Certificates of deposit |  |  | 61 |  |  |  | 158 |  |
| Mutual funds |  |  | 40 |  |  |  | 33 |  |
| Total debt and equity securities |  | $ | 167 |  |  | $ | 414 |  |

[0001564590-21-033645:notes:164]
The fair value of our investments approximates their cost or amortized cost for both periods presented.

[0001564590-21-033645:notes:165]
During fiscal 2020, we sold approximately $1.0 billion of corporate bonds held by foreign subsidiaries and recognized a gain on sale of $14 million, which is presented in other (expense) income, net on our consolidated statement of income.

[0001564590-21-033645:notes:166]
The following table presents the contractual maturities of our debt investments as of April 30, 2021 (in millions):

[0001564590-21-033645:notes:167]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 102 |  |  | $ | 102 |  |
| Due after one year through five years |  |  | 20 |  |  |  | 21 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 127 |  |  | $ | 128 |  |

[0001564590-21-033645:notes:168]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-21-033645:notes:169]
Fair Value of Financial Instruments

[0001564590-21-033645:notes:170]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-21-033645:notes:171]
|  |  | April 30, 2021 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,468 |  |  | $ | 4,468 |  |  | $ | — |  |
| Corporate bonds |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| U.S. Treasury and government debt securities |  |  | 8 |  |  |  | 4 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 61 |  |  |  | — |  |  |  | 61 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,596 |  |  | $ | 4,472 |  |  | $ | 124 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-21-033645:notes:172]
|  |  | April 24, 2020 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,500 |  |  | $ | 2,500 |  |  | $ | — |  |
| Corporate bonds |  |  | 156 |  |  |  | — |  |  |  | 156 |  |
| U.S. Treasury and government debt securities |  |  | 68 |  |  |  | 44 |  |  |  | 24 |  |
| Certificates of deposit |  |  | 158 |  |  |  | — |  |  |  | 158 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,882 |  |  | $ | 2,544 |  |  | $ | 338 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 27 |  |  | $ | 27 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001564590-21-033645:notes:173]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-21-033645:notes:174]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-21-033645:notes:175]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-21-033645:notes:176]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 30, 2021 and April 24, 2020, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-21-033645:notes:177]
Fair Value of Debt

[0001564590-21-033645:notes:178]
As of April 30, 2021 and April 24, 2020, the fair value of our long-term debt was approximately $2,736 million and $1,176 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-033645:notes:179]
9. Financing Arrangements

[0001564590-21-033645:notes:180]
Long-Term Debt

[0001564590-21-033645:notes:181]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-21-033645:notes:182]
|  |  | Effective Interest Rate |  |  | April 30, 2021 |  |  | April 24, 2020 |  |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (18 | ) |  |  | (4 | ) |  |
| Total senior notes |  |  |  |  |  | $ | 2,632 |  |  | $ | 1,146 |  |  |

[0001564590-21-033645:notes:183]
Senior Notes

[0001564590-21-033645:notes:184]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December.

[0001564590-21-033645:notes:185]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December. .

[0001564590-21-033645:notes:186]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness

[0001564590-21-033645:notes:187]
On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million during the first quarter of fiscal year 2021, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other (expense) income, net in our consolidated statement of income for the year ended April 30, 2021.

[0001564590-21-033645:notes:188]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 30, 2021, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-21-033645:notes:189]
As of April 30, 2021, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-21-033645:notes:190]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0001564590-21-033645:notes:191]
Commercial Paper Program and Credit Facility

[0001564590-21-033645:notes:192]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of April 30, 2021, we had commercial paper notes outstanding with an aggregate principal amount of $523 million, a weighted-average interest rate of 2.01%, and maturities primarily less than three months as of April 24, 2020. During fiscal year 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months. During fiscal 2020, we received proceeds of $111 million from the issuance, and made repayments of $10 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0001564590-21-033645:notes:193]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 30, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-21-033645:notes:194]
10. Leases

[0001564590-21-033645:notes:195]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of April 30, 2021, have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of April 30, 2021, have remaining lease terms of up to 4 years. As of April 30, 2021, our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-21-033645:notes:196]
In June 2020, we entered into a build-to-suit lease agreement for an office building with future undiscounted payments of approximately $67 million. Because the Company does not control the underlying asset during the construction period, the Company is not considered the owner of the asset under construction for accounting purposes. The lease will commence upon completion of the construction of the office building which is expected to be in the third quarter of fiscal 2022. The initial term of the lease is twenty years with options to renew the lease during the lease term. A ROU asset and related lease liability will be measured and recognized in our financial statements in the period the lease commences.

[0001564590-21-033645:notes:197]
In April 2021, we entered into a lease for our new corporate headquarters located in San Jose, California, which is comprised of approximately three hundred thousand square feet of office space and requires future minimum undiscounted payments of approximately $180 million over the initial 11-year lease term. The lease agreement also provides us two successive renewal options, each for five years. A ROU asset and related lease liability will be measured and recognized in our financial statements upon lease commencement in the first quarter of fiscal 2022.

[0001564590-21-033645:notes:198]
The components of lease cost related to our operating leases were as follows (in millions):

[0001564590-21-033645:notes:199]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Operating lease cost |  | $ | 55 |  |  | $ | 55 |  |
| Variable lease cost |  |  | 11 |  |  |  | 16 |  |
| Total lease cost |  | $ | 66 |  |  | $ | 71 |  |

[0001564590-21-033645:notes:200]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0001564590-21-033645:notes:201]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0001564590-21-033645:notes:202]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 57 |  |  | $ | 56 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 31 |  |  | $ | 41 |  |

[0001564590-21-033645:notes:203]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0001564590-21-033645:notes:204]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Other non-current assets |  | $ | 114 |  |  | $ | 137 |  |
| Total operating lease ROU assets |  | $ | 114 |  |  | $ | 137 |  |
| Accrued expenses |  | $ | 49 |  |  | $ | 51 |  |
| Other long-term liabilities |  |  | 71 |  |  |  | 93 |  |
| Total operating lease liabilities |  | $ | 120 |  |  | $ | 144 |  |
| Weighted Average Remaining Lease Term |  | 3.4 years |  |  | 3.9 years |  |
| Weighted Average Discount Rate |  |  | 2.9 | % |  |  | 2.7 | % |

[0001564590-21-033645:notes:205]
Future minimum operating lease payments as of April 30, 2021, which exclude the undiscounted payments for the aforementioned build-to-suit and corporate headquarters leases to commence in fiscal 2022, are as follows (in millions):

[0001564590-21-033645:notes:206]
| Fiscal Year |  |  |  | Operating Leases |  |
| 2022 |  |  |  | $ | 52 |  |
| 2023 |  |  |  |  | 34 |  |
| 2024 |  |  |  |  | 21 |  |
| 2025 |  |  |  |  | 10 |  |
| 2026 |  |  |  |  | 8 |  |
| Thereafter |  |  |  |  | 4 |  |
| Total lease payments |  |  |  |  | 129 |  |
| Less: Interest |  |  |  |  | (9 | ) |
| Total |  |  |  | $ | 120 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-21-033645:notes:207]
11. Stockholders’ Equity

[0001564590-21-033645:notes:208]
Equity Incentive Programs

[0001564590-21-033645:notes:209]
The 1999 Plan — As most recently amended on September 12, 2019, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program

[0001564590-21-033645:notes:210]
under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. In August 2019, the Plan was extended for a 10-year term.

[0001564590-21-033645:notes:211]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001564590-21-033645:notes:212]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock or restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-21-033645:notes:213]
As of April 30, 2021, 18 million shares were available for grant under the Plan.

[0001564590-21-033645:notes:214]
Stock Options

[0001564590-21-033645:notes:215]
Less than 1 million stock options were outstanding as of April 30, 2021 and April 24, 2020.

[0001564590-21-033645:notes:216]
Additional information related to our stock options is summarized below (in millions):

[0001564590-21-033645:notes:217]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Intrinsic value of exercises |  | $ | 11 |  |  | $ | 5 |  |  | $ | 31 |  |
| Proceeds received from exercises |  | $ | 8 |  |  | $ | 4 |  |  | $ | 25 |  |
| Fair value of options vested |  | $ | 5 |  |  | $ | 1 |  |  | $ | 2 |  |

[0001564590-21-033645:notes:218]
Restricted Stock Units

[0001564590-21-033645:notes:219]
In fiscal 2021, 2020 and 2019, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate one, two or three year performance period, which began on the date specified in the grant agreement and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For most of the PBRSUs granted in fiscal 2021 and half of the PBRSUs granted in fiscal 2020 and 2019, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted in fiscal 2020 and 2019, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three-year periods from fiscal 2020 through 2022 and fiscal 2019 through 2021, respectively. The fair values of these AOI PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in fiscal 2021, 2020 and 2019 was $27 million, $18 million and $24 million, respectively, and these amounts are being recognized to expense over the shorter of the remaining applicable performance or service periods.

[0001564590-21-033645:notes:220]
As of April 30, 2021, April 24, 2020 and April 26, 2019, there were approximately 1 million PBRSUs outstanding.

[0001564590-21-033645:notes:221]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-21-033645:notes:222]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |
| Granted |  |  | 3 |  |  | $ | 63.40 |  |
| Vested |  |  | (3 | ) |  | $ | 32.02 |  |
| Forfeited |  |  | (1 | ) |  | $ | 36.61 |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |
| Granted |  |  | 4 |  |  | $ | 51.39 |  |
| Vested |  |  | (4 | ) |  | $ | 38.87 |  |
| Forfeited |  |  | (1 | ) |  | $ | 48.30 |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |
| Granted |  |  | 6 |  |  | $ | 42.46 |  |
| Vested |  |  | (3 | ) |  | $ | 44.74 |  |
| Forfeited |  |  | (1 | ) |  | $ | 51.20 |  |
| Outstanding as of April 30, 2021 |  |  | 9 |  |  | $ | 47.75 |  |

[0001564590-21-033645:notes:223]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-21-033645:notes:224]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 42 |  |  | $ | 79 |  |  | $ | 96 |  |

[0001564590-21-033645:notes:225]
Employee Stock Purchase Plan

[0001564590-21-033645:notes:226]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 12, 2019, the ESPP was amended to increase the shares reserved for issuance by 2 million shares of common stock. As of April 30, 2021, 5 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-21-033645:notes:227]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |  |  | 3 |  |
| Proceeds from issuance of shares |  | $ | 90 |  |  | $ | 98 |  |  | $ | 96 |  |

[0001564590-21-033645:notes:228]
Stock-Based Compensation Expense

[0001564590-21-033645:notes:229]
Stock-based compensation expense is included in the consolidated statements of income as follows (in millions):

[0001564590-21-033645:notes:230]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Cost of product revenues |  | $ | 4 |  |  | $ | 3 |  |  | $ | 4 |  |
| Cost of hardware support and other services revenues |  |  | 10 |  |  |  | 10 |  |  |  | 10 |  |
| Sales and marketing |  |  | 92 |  |  |  | 66 |  |  |  | 67 |  |
| Research and development |  |  | 64 |  |  |  | 53 |  |  |  | 48 |  |
| General and administrative |  |  | 27 |  |  |  | 21 |  |  |  | 29 |  |
| Total stock-based compensation expense |  | $ | 197 |  |  | $ | 153 |  |  | $ | 158 |  |
| Income tax benefit for stock-based compensation |  | $ | 17 |  |  | $ | 15 |  |  | $ | 15 |  |

[0001564590-21-033645:notes:231]
As of April 30, 2021, total unrecognized compensation expense related to our equity awards was $333 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001564590-21-033645:notes:232]
Valuation Assumptions

[0001564590-21-033645:notes:233]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-21-033645:notes:234]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 1.7 | % |  |  | 2.6 | % |
| Expected dividend yield |  |  | 4.4 | % |  |  | 2.9 | % |  |  | 2.4 | % |
| Weighted-average fair value per share granted |  | $ | 42.46 |  |  | $ | 51.39 |  |  | $ | 63.40 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 2.0 | % |  |  | 2.6 | % |
| Expected volatility |  |  | 47 | % |  |  | 33 | % |  |  | 31 | % |
| Expected dividend yield |  |  | 4.4 | % |  |  | 3.1 | % |  |  | 2.4 | % |
| Weighted-average fair value per right granted |  | $ | 10.08 |  |  | $ | 10.15 |  |  | $ | 18.07 |  |

[0001564590-21-033645:notes:235]
Stock Repurchase Program

[0001564590-21-033645:notes:236]
As of April 30, 2021, our Board of Directors had authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program, and on May 28, 2021 authorized an additional $500 million. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. In March 2020, we suspended our repurchases under the program due to the economic impact of the COVID-19 pandemic. We reinitiated our stock repurchase program during the third quarter of fiscal year 2021.

[0001564590-21-033645:notes:237]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0001564590-21-033645:notes:238]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Number of shares repurchased |  |  | 2 |  |  |  | 25 |  |  |  | 29 |  |
| Average price per share |  | $ | 67.61 |  |  | $ | 56.34 |  |  | $ | 72.87 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 3 |  |  | $ | 625 |  |  | $ | 1,002 |  |
| Stock repurchases allocated to retained earnings |  | $ | 122 |  |  | $ | 786 |  |  | $ | 1,109 |  |
| Remaining authorization at end of period |  | $ | 352 |  |  | $ | 477 |  |  | $ | 1,889 |  |

[0001564590-21-033645:notes:239]
Since the May 13, 2003 inception of our stock repurchase program through April 30, 2021, we repurchased a total of 340 million shares of our common stock at an average price of $39.02 per share, for an aggregate purchase price of $13.3 billion.

[0001564590-21-033645:notes:240]
Preferred Stock

[0001564590-21-033645:notes:241]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-21-033645:notes:242]
Dividends

[0001564590-21-033645:notes:243]
The following is a summary of our fiscal 2021, 2020 and 2019 activities related to dividends on our common stock (in millions, except per share amounts).

[0001564590-21-033645:notes:244]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Dividends per share declared |  | $ | 1.92 |  |  | $ | 1.92 |  |  | $ | 1.60 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 30 |  |  | $ | 400 |  |  | $ | 403 |  |
| Dividend payments allocated to retained earnings |  | $ | 397 |  |  | $ | 39 |  |  | $ | - |  |

[0001564590-21-033645:notes:245]
On May 28, 2021, we declared a cash dividend of $0.50 per share of common stock, payable on July 28, 2021 to shareholders of record as of the close of business on July 9, 2021. The timing and amount of future dividends will depend on market conditions,

[0001564590-21-033645:notes:246]
corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-21-033645:notes:247]
Accumulated Other Comprehensive Income (Loss)

[0001564590-21-033645:notes:248]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0001564590-21-033645:notes:249]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 27, 2018 |  | $ | (27 | ) |  | $ | — |  |  | $ | (43 | ) |  | $ | — |  |  | $ | (70 | ) |
| OCI before reclassifications, net of tax |  |  | (7 | ) |  |  | (2 | ) |  |  | 36 |  |  |  | 2 |  |  |  | 29 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |
| Total OCI |  |  | (7 | ) |  |  | (3 | ) |  |  | 36 |  |  |  | 1 |  |  |  | 27 |  |
| Balance as of April 26, 2019 |  |  | (34 | ) |  |  | (3 | ) |  |  | (7 | ) |  |  | 1 |  |  |  | (43 | ) |
| OCI before reclassifications, net of tax |  |  | (8 | ) |  |  | 3 |  |  |  | 22 |  |  |  | 5 |  |  |  | 22 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | (14 | ) |  |  | (6 | ) |  |  | (21 | ) |
| Total OCI |  |  | (8 | ) |  |  | 2 |  |  |  | 8 |  |  |  | (1 | ) |  |  | 1 |  |
| Balance as of April 24, 2020 |  |  | (42 | ) |  |  | (1 | ) |  |  | 1 |  |  |  | — |  |  |  | (42 | ) |
| OCI before reclassifications, net of tax |  |  | 15 |  |  |  | (3 | ) |  |  | — |  |  |  | (11 | ) |  |  | 1 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |  |  | 11 |  |
| Total OCI |  |  | 15 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 12 |  |
| Balance as of April 30, 2021 |  | $ | (27 | ) |  | $ | (4 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (30 | ) |

[0001564590-21-033645:notes:250]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-21-033645:notes:251]
|  |  | Year Ended |  |  | Statements of Income |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | Classification |
| Recognized gains on defined benefit obligations |  | $ | — |  |  | $ | (2 | ) |  | $ | (2 | ) |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | (14 | ) |  |  | — |  |  | Other (expense) income, net |
| Realized losses (gains) on cash flow hedges |  |  | 11 |  |  |  | (6 | ) |  |  | (1 | ) |  | Net revenues |
| Total reclassifications |  | $ | 11 |  |  | $ | (22 | ) |  | $ | (3 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-033645:notes:252]
12. Derivatives and Hedging Activities

[0001564590-21-033645:notes:253]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 30, 2021 or April 24, 2020. All contracts have a maturity of less than 12 months.

[0001564590-21-033645:notes:254]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-21-033645:notes:255]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 167 |  |  | $ | 124 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 497 |  |  | $ | 254 |  |
| Forward contracts purchased |  | $ | 117 |  |  | $ | 108 |  |

[0001564590-21-033645:notes:256]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 11 – Stockholders’ Equity.

[0001564590-21-033645:notes:257]
The effect of derivative instruments not designated as hedging instruments recognized in other (expense) income, net on our consolidated statements of income was as follows (in millions):

[0001564590-21-033645:notes:258]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Gain Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 20 |  |  | $ | — |  |  | $ | 15 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-033645:notes:259]
13. Restructuring Charges

[0001564590-21-033645:notes:260]
In the second quarter of fiscal year 2021, we committed to a restructuring plan (the August 2020 Plan) to optimize our business and fund our biggest opportunities. In connection with the plan, we reduced our global workforce by approximately 5%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-21-033645:notes:261]
In the first quarter of fiscal year 2021, we executed a restructuring plan (the May 2020 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce by less than 1%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-21-033645:notes:262]
Management has previously approved several restructuring actions, including the May 2019 Plan, April 2019 Plan, May 2018 Plan and November 2016 Plan, under which we reduced our global workforce by approximately 2%, approximately 1%, less than 2%, and 6%, respectively. Charges related to these restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under the May 2019 Plan were complete as of the end of fiscal 2020, and substantially all activities under the April 2019 Plan were complete as of the end of fiscal 2020. Substantially all activities under the November 2016 Plan and the May 2018 Plan were complete as of the end of fiscal 2018 and 2019, respectively.

[0001564590-21-033645:notes:263]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001564590-21-033645:notes:264]
|  |  | Total |  |
| Balance as of April 27, 2018 |  | $ | 6 |  |
| Net charges |  |  | 35 |  |
| Cash payments |  |  | (22 | ) |
| Balance as of April 26, 2019 |  |  | 19 |  |
| Net charges |  |  | 21 |  |
| Cash payments |  |  | (35 | ) |
| Other |  |  | (4 | ) |
| Balance as of April 24, 2020 |  |  | 1 |  |
| Net charges |  |  | 42 |  |
| Cash payments |  |  | (42 | ) |
| Balance as of April 30, 2021 |  | $ | 1 |  |

[0001564590-21-033645:notes:265]
Upon adoption of the new lease accounting standard in the first quarter of fiscal 2020, the remaining lease-related liabilities associated with the November 2016 Plan were recognized as a reduction to the lease right-of-use asset recorded at transition.

[0001564590-21-033645:notes:266]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-033645:notes:267]
14. Income Taxes

[0001564590-21-033645:notes:268]
Income before income taxes is as follows (in millions):

[0001564590-21-033645:notes:269]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Domestic |  | $ | 433 |  |  | $ | 379 |  |  | $ | 678 |  |
| Foreign |  |  | 529 |  |  |  | 565 |  |  |  | 590 |  |
| Total |  | $ | 962 |  |  | $ | 944 |  |  | $ | 1,268 |  |

[0001564590-21-033645:notes:270]
The provision for income taxes consists of the following (in millions):

[0001564590-21-033645:notes:271]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 82 |  |  | $ | 83 |  |  | $ | 26 |  |
| State |  |  | 22 |  |  |  | 9 |  |  |  | 27 |  |
| Foreign |  |  | 134 |  |  |  | 50 |  |  |  | 49 |  |
| Total current |  |  | 238 |  |  |  | 142 |  |  |  | 102 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 6 |  |  |  | (26 | ) |  |  | 35 |  |
| State |  |  | 2 |  |  |  | (6 | ) |  |  | (6 | ) |
| Foreign |  |  | (14 | ) |  |  | 15 |  |  |  | (32 | ) |
| Total deferred |  |  | (6 | ) |  |  | (17 | ) |  |  | (3 | ) |
| Provision for income taxes |  | $ | 232 |  |  | $ | 125 |  |  | $ | 99 |  |

[0001564590-21-033645:notes:272]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-21-033645:notes:273]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Tax computed at federal statutory rate |  | $ | 202 |  |  | $ | 198 |  |  | $ | 266 |  |
| State income taxes, net of federal benefit |  |  | 23 |  |  |  | 10 |  |  |  | 16 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (26 | ) |  |  | (40 | ) |  |  | (84 | ) |
| Stock-based compensation |  |  | 6 |  |  |  | (4 | ) |  |  | (19 | ) |
| Research and development credits |  |  | (13 | ) |  |  | (16 | ) |  |  | (17 | ) |
| Global minimum tax on intangible income |  |  | 19 |  |  |  | 32 |  |  |  | 22 |  |
| Transition tax and related reserves |  |  | 1 |  |  |  | 15 |  |  |  | (5 | ) |
| Tax charge from integration of acquired companies |  |  | 35 |  |  |  | — |  |  |  | — |  |
| Resolution of income tax matters (1) |  |  | (6 | ) |  |  | (61 | ) |  |  | (48 | ) |
| Non-taxable gain on joint venture formation |  |  | — |  |  |  | — |  |  |  | (14 | ) |
| Domestic production activities deduction |  |  | — |  |  |  | — |  |  |  | (13 | ) |
| Other |  |  | (9 | ) |  |  | (9 | ) |  |  | (5 | ) |
| Provision for income taxes |  | $ | 232 |  |  | $ | 125 |  |  | $ | 99 |  |

[0001564590-21-033645:notes:274]
|  | (1) | During fiscal 2021, we recognized a tax benefit related to the lapse of statutes of limitations for certain issues on our fiscal 2016 and 2017 federal income tax returns. During fiscal 2020, we recognized a tax benefit related to the lapse of statutes of limitations on our fiscal 2014 and 2015 federal income tax returns. During fiscal 2019, the Internal Revenue Service completed the examination of our fiscal 2012 to fiscal 2013 federal income tax returns, and we recognized a tax benefit attributable to the effective settlement and the release of related tax reserves. |

[0001564590-21-033645:notes:275]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-21-033645:notes:276]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 65 |  |  | $ | 72 |  |
| Net operating loss and credit carryforwards |  |  | 115 |  |  |  | 113 |  |
| Stock-based compensation |  |  | 18 |  |  |  | 15 |  |
| Deferred revenue |  |  | 226 |  |  |  | 242 |  |
| Other |  |  | 20 |  |  |  | 14 |  |
| Gross deferred tax assets |  |  | 444 |  |  |  | 456 |  |
| Valuation allowance |  |  | (107 | ) |  |  | (104 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 337 |  |  |  | 352 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 51 |  |  |  | 49 |  |
| Acquired intangibles |  |  | 28 |  |  |  | 40 |  |
| Property and equipment |  |  | 31 |  |  |  | 33 |  |
| Other |  |  | 24 |  |  |  | 20 |  |
| Total deferred tax liabilities |  |  | 134 |  |  |  | 142 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 203 |  |  | $ | 210 |  |

[0001564590-21-033645:notes:277]
The valuation allowance increased by $3 million in fiscal 2021. The increase is mainly attributable to corresponding changes in deferred tax assets, primarily certain state tax credit carryforwards.

[0001564590-21-033645:notes:278]
As of April 30, 2021, we have federal net operating loss and tax credit carryforwards of approximately $6 million and $1 million, respectively. In addition, we have gross state net operating loss and tax credit carryforwards of $23 million and $130 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $1 million of foreign net operating losses, and $28 million of foreign tax credit carryforwards where the majority is generated by our Dutch subsidiary which are fully offset by a valuation allowance. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal, state, and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2022 through 2035. The federal NOLs, California research credit and Dutch foreign tax credit carryforwards do not expire.

[0001564590-21-033645:notes:279]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-21-033645:notes:280]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Balance at beginning of period |  | $ | 211 |  |  | $ | 296 |  |  | $ | 348 |  |
| Additions based on tax positions related to the current year |  |  | 7 |  |  |  | 5 |  |  |  | 11 |  |
| Additions for tax positions of prior years |  |  | 11 |  |  |  | 1 |  |  |  | 26 |  |
| Decreases for tax positions of prior years |  |  | — |  |  |  | (10 | ) |  |  | (35 | ) |
| Settlements |  |  | (8 | ) |  |  | (81 | ) |  |  | (54 | ) |
| Balance at end of period |  | $ | 221 |  |  | $ | 211 |  |  | $ | 296 |  |

[0001564590-21-033645:notes:281]
As of April 30, 2021, we had $221 million of gross unrecognized tax benefits, of which $127 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $126 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-21-033645:notes:282]
We recognized expense for increases to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of approximately $1 million in fiscal 2021, a benefit of $8 million in fiscal 2020 and a benefit of $4 million in fiscal 2019. Accrued interest and penalties of $11 million and $10 million were recorded in the consolidated balance sheets as of April 30, 2021 and April 24, 2020, respectively.

[0001564590-21-033645:notes:283]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-21-033645:notes:284]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 30, 2021

[0001564590-21-033645:notes:285]
| 2016 — 2021 |  | United States — federal income tax |
| 2012 — 2021 |  | United States — state and local income tax |
| 2014 — 2021 |  | Australia |
| 2015 — 2021 |  | Germany |
| 2007 — 2021 |  | India |
| 2014 — 2021 |  | Japan |
| 2017 — 2021 |  | The Netherlands |
| 2016 — 2021 |  | United Kingdom |
| 2016 — 2021 |  | Canada |

[0001564590-21-033645:notes:286]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals. We are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-21-033645:notes:287]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. On May 3, 2021, the DHC reached a decision resulting in NetApp prevailing on the predominate distribution made in 2005. The smaller distribution made in 2006 was ruled in favor of the Danish Tax Authorities. On May 28, 2021, the Danish Tax Authorities appealed the DHC decision to the Danish Supreme Court. We believe it is more likely than not that our distributions were not subject to withholding tax and we will continue to support our position in the appeals process with the Danish Supreme Court.

[0001564590-21-033645:notes:288]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-21-033645:notes:289]
As of April 30, 2021, we continue to record a deferred tax liability related to state taxes on unremitted earnings of certain foreign entities. We estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-033645:notes:290]
15. Net Income per Share

[0001564590-21-033645:notes:291]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-21-033645:notes:292]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 730 |  |  | $ | 819 |  |  | $ | 1,169 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 222 |  |  |  | 230 |  |  |  | 254 |  |
| Dilutive impact of employee equity award plans |  |  | 4 |  |  |  | 3 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 226 |  |  |  | 233 |  |  |  | 259 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.29 |  |  | $ | 3.56 |  |  | $ | 4.60 |  |
| Diluted |  | $ | 3.23 |  |  | $ | 3.52 |  |  | $ | 4.51 |  |

[0001564590-21-033645:notes:293]
Four million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for each of fiscal 2021 and 2020, while one million potential shares were excluded from the calculations for fiscal 2019, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-033645:notes:294]
16. Segment, Geographic, and Significant Customer Information

[0001564590-21-033645:notes:295]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-21-033645:notes:296]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-21-033645:notes:297]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,097 |  |  | $ | 2,863 |  |  | $ | 3,425 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,775 |  |  |  | 1,742 |  |  |  | 1,847 |  |
| Asia Pacific (APAC) |  |  | 872 |  |  |  | 807 |  |  |  | 874 |  |
| Net revenues |  | $ | 5,744 |  |  | $ | 5,412 |  |  | $ | 6,146 |  |

[0001564590-21-033645:notes:298]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $2,784 million, $2,584 million and $3,116 million during fiscal 2021, 2020 and 2019, respectively.

[0001564590-21-033645:notes:299]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-21-033645:notes:300]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 2,098 |  |  | $ | 385 |  |
| International |  |  | 2,498 |  |  |  | 2,497 |  |
| Total |  | $ | 4,596 |  |  | $ | 2,882 |  |

[0001564590-21-033645:notes:301]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-21-033645:notes:302]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 340 |  |  | $ | 540 |  |
| International |  |  | 185 |  |  |  | 187 |  |
| Total |  | $ | 525 |  |  | $ | 727 |  |

[0001564590-21-033645:notes:303]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-21-033645:notes:304]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 21 | % |  |  | 20 | % |

[0001564590-21-033645:notes:305]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-21-033645:notes:306]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 13 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 19 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-21-033645:notes:307]
17. Employee Benefits and Deferred Compensation

[0001564590-21-033645:notes:308]
Employee 401(k) Plan

[0001564590-21-033645:notes:309]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-21-033645:notes:310]
|  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| 401(k) matching contributions |  | $ | 29 |  |  | $ | 29 |  |  | $ | 29 |  |

[0001564590-21-033645:notes:311]
Deferred Compensation Plan

[0001564590-21-033645:notes:312]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-21-033645:notes:313]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Deferred compensation plan assets |  | $ | 40 |  |  | $ | 33 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 8 |  |  | $ | 6 |  |
| Other long-term liabilities |  | $ | 32 |  |  | $ | 27 |  |

[0001564590-21-033645:notes:314]
Postretirement Health Care Plan

[0001564590-21-033645:notes:315]
Certain of our executive officers were eligible to participate in our Executive Retirement Medical Plan (the ERM Plan). Prior to its termination in fiscal 2020, the ERM Plan provided, upon retirement, medical benefits beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, years of service and position. The ERM Plan was unfunded and there was no minimum funding requirement.

[0001564590-21-033645:notes:316]
In November 2016, we made certain amendments to the ERM Plan, which prior to amendment, provided group health insurance benefits to eligible retirees. Effective January 1, 2017, the amended ERM Plan provided each eligible retiree with a capped reimbursement of premiums for the period from January 1, 2017 through December 31, 2019. During the period from December 31, 2019 through December 31, 2021, participants in the ERM Plan are eligible to receive a lump sum cash payment equal to two years of projected health care costs, or a prorated portion thereof, pursuant to the methodology set forth in the ERM Plan. Such payments were, or will be, made by us outside the ERM Plan as the ERM Plan was terminated on December 31, 2019.

[0001564590-21-033645:notes:317]
Other Defined Benefit Plans

[0001564590-21-033645:notes:318]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0001564590-21-033645:notes:319]
Funded Status

[0001564590-21-033645:notes:320]
The funded status of our defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0001564590-21-033645:notes:321]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Fair value of plan assets |  | $ | 38 |  |  | $ | 32 |  |
| Benefit obligations |  |  | (72 | ) |  |  | (59 | ) |
| Unfunded obligations |  | $ | (34 | ) |  | $ | (27 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-033645:notes:322]
18. Commitments and Contingencies

[0001564590-21-033645:notes:323]
Purchase Orders and Other Commitments

[0001564590-21-033645:notes:324]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 30, 2021, we had $576 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 30, 2021 and April 24, 2020, such liability amounted to $15 million and $6 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-21-033645:notes:325]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 30, 2021, we had $224 million in other purchase obligations.

[0001564590-21-033645:notes:326]
Of the total $800 million in purchase commitments, $584 million is due in fiscal 2022, with the remainder due thereafter.

[0001564590-21-033645:notes:327]
Financing Guarantees

[0001564590-21-033645:notes:328]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $102 million, $59 million and $87 million of receivables during fiscal 2021, 2020 and 2019, respectively.

[0001564590-21-033645:notes:329]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-21-033645:notes:330]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of April 30, 2021 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-21-033645:notes:331]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-21-033645:notes:332]
Legal Contingencies

[0001564590-21-033645:notes:333]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-21-033645:notes:334]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. NetApp’s Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp. On March 26, 2021, Plaintiffs filed a notice of appeal. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-21-033645:notes:335]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-21-033645:notes:336]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of April 30, 2021 related to such matters.
