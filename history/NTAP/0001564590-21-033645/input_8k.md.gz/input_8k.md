# NTAP 8-K — 0001564590-21-031393 filed 2021-06-02

## item codes, every 8-K on or before 2021-06-21

- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2021-06-21

- none on or before 2021-06-21

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-031393:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-21-031393:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-21-031393:8k_2_02:3]
Exhibit 99.1

[0001564590-21-031393:8k_2_02:4]
NetApp reports fourth quarter and fiscal year 2021 results

[0001564590-21-031393:8k_2_02:5]
Net revenues for the fourth quarter grew 11% year-over-year to $1.56 billion

[0001564590-21-031393:8k_2_02:6]
| • | NetApp™ public cloud services annualized revenue run rate (ARR)1 increased 171% year-over-year to $301 million |  |

[0001564590-21-031393:8k_2_02:7]
| • | All-flash array annualized net revenue run rate2 increased 11% year-over-year to $2.9 billion |  |

[0001564590-21-031393:8k_2_02:8]
| • | Billings3 increased 12% year-over-year to $1.74 billion in the fourth quarter |  |

[0001564590-21-031393:8k_2_02:9]
| • | $559 million in cash provided by operations in the fourth quarter; $521 million in free cash flow3, an all-time high for the Company |  |

[0001564590-21-031393:8k_2_02:10]
Sunnyvale, Calif.—June 2, 2021—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2021, which ended on April 30, 2021.

[0001564590-21-031393:8k_2_02:11]
“We delivered fourth quarter results above expectations, capping off a solid year of growth. Our momentum underscores our value to customers in a hybrid, multi-cloud world. We are gaining share in key storage markets and our public cloud services are at a scale where they are positively impacting total company billings and revenue growth,” said George Kurian, chief executive officer. “Our focused execution last year has set us up well for FY22. I am excited about the year ahead and confident in our ability to grow revenue while delivering operating leverage as we support our customers on their cloud and digital transformation journeys.”

[0001564590-21-031393:8k_2_02:12]
Fourth quarter of fiscal year 2021 financial results

[0001564590-21-031393:8k_2_02:13]
| • | Net revenues: $1.56 billion, compared to $1.40 billion in the fourth quarter of fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:14]
| • | Net income: GAAP net income of $334 million, compared to $196 million in the fourth quarter of fiscal year 2020; non-GAAP net income4 of $268 million, compared to $265 million in the fourth quarter of fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:15]
| • | Earnings per share: GAAP net income per share5 of $1.46, compared to $0.88 in the fourth quarter of fiscal year 2020; non-GAAP net income per share of $1.17, compared to $1.19 in the fourth quarter of fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:16]
| • | Cash, cash equivalents and investments: $4.60 billion at the end of the fourth quarter of fiscal year 2021 |  |

[0001564590-21-031393:8k_2_02:17]
| • | Cash provided by operations: $559 million, compared to $383 million in the fourth quarter of fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:18]
| • | Share repurchase and dividends: Returned $181 million to shareholders through share repurchases and cash dividends |  |

[0001564590-21-031393:8k_2_02:19]
Fiscal year 2021 financial results

[0001564590-21-031393:8k_2_02:20]
| • | Net revenues: $5.74 billion, compared to $5.41 billion in fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:21]
| • | Net income: GAAP net income of $730 million, compared to $819 million in fiscal year 2020; non-GAAP net income of $917 million, compared to $944 million in fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:22]
| • | Earnings per share: GAAP net income per share of $3.23, compared to $3.52 in fiscal year 2020; non-GAAP net income per share of $4.06, compared to $4.05 in fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:23]
| • | Cash provided by operations: $1.33 billion compared to $1.06 billion in fiscal year 2020 |  |

[0001564590-21-031393:8k_2_02:24]
| • | Share repurchase and dividends: Returned $552 million to shareholders through share repurchases and cash dividends |  |

[0001564590-21-031393:8k_2_02:25]
First quarter fiscal year 2022 financial outlook

[0001564590-21-031393:8k_2_02:26]
The Company provided the following financial guidance for the first quarter of fiscal year 2022:

[0001564590-21-031393:8k_2_02:27]
| Net revenues are expected to be in the range of: | $1.37 billion to $1.47 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.69 - $0.77 | $0.89 - $0.97 |

[0001564590-21-031393:8k_2_02:28]
Full fiscal year 2022 financial outlook

[0001564590-21-031393:8k_2_02:29]
The Company provided the following financial guidance for the full fiscal year 2022:

[0001564590-21-031393:8k_2_02:30]
| Net revenues are expected to grow in the range of: | 6% to 7% |
| Public cloud ARR is expected to exit the fiscal year in the range of: | $425 million to $500 million |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | 66% - 67% | 67% - 68% |
| Operating margins are expected to be: | 16% - 17% | 21% - 22% |
| Effective tax rate is expected to be: | ~20% | ~19% |
| Earnings per share is expected to be in the range of: | $3.48 - $3.68 | $4.45 - $4.65 |

[0001564590-21-031393:8k_2_02:31]
Dividend

[0001564590-21-031393:8k_2_02:32]
The Company will increase the first quarter fiscal year 2022 dividend by 4% to $0.50 per share. The quarterly dividend will be paid on July 28, 2021, to shareholders of record as of the close of business on July 9, 2021.

[0001564590-21-031393:8k_2_02:33]
Share repurchase program

[0001564590-21-031393:8k_2_02:34]
The Company authorized an additional $500 million for the repurchase of shares of its common stock under its existing share repurchase program.

[0001564590-21-031393:8k_2_02:35]
Fourth quarter fiscal year 2021 business highlights

[0001564590-21-031393:8k_2_02:36]
Delivering industry-leading products

[0001564590-21-031393:8k_2_02:37]
| • | NetApp announced the general availability of NetApp Astra™, a fully managed application-aware data management service built for Kubernetes workloads. |

[0001564590-21-031393:8k_2_02:38]
| • | NetApp announced Spot Wave by NetApp. In addition, Spot Ocean by NetApp now supports Azure Kubernetes Service. Together, these products provide customers with leading solutions for simple, scalable, and efficient infrastructure for cloud-native applications. |

[0001564590-21-031393:8k_2_02:39]
| • | NetApp introduced the Data Science Toolkit to simplify the performance of various data science tasks with NetApp storage. |

[0001564590-21-031393:8k_2_02:40]
| • | NetApp now supports BeeGFS for Kubernetes, providing infrastructure options for AI initiatives that offer customers a new cloud-native era. The Company also introduced NetApp EF-Series integration with nVIDIA DGX A100 systems, NetApp EF600 all-flash arrays, and the BeeGFS parallel file system with state-of-the-art InfiniBand networking. |

[0001564590-21-031393:8k_2_02:41]
| • | NetApp announced a FlexPod™ Cisco Validated Design (CVD), that enables customers and partners to confidently deploy a FlexPod solution with Citrix Virtual Apps and Desktops. |

[0001564590-21-031393:8k_2_02:42]
NetApp partnering for innovation

[0001564590-21-031393:8k_2_02:43]
| • | NetApp and NVIDIA announced a new integrated solution based on the field-proven NetApp ONTAP™ AI reference architecture. |

[0001564590-21-031393:8k_2_02:44]
| • | Cisco and NetApp celebrated the 10-year anniversary of FlexPod and announced the next decade of collaboration with the tech preview of NetApp ONTAP integration with Cisco Intersight. |

[0001564590-21-031393:8k_2_02:45]
| • | Ducati Corse announced that its NetApp sponsorship would continue for a fourth straight year. The sponsorship plays a critical role in helping the Ducati Corse division fully exploit data’s potential in the racing world. |

[0001564590-21-031393:8k_2_02:46]
| • | NetApp and Aston Martin Cognizant Formula One Team announced a partnership, unlocking the very best of cloud by outfitting the team with world-class data and cloud services. |

[0001564590-21-031393:8k_2_02:47]
Leadership matters—driving inclusion at NetApp

[0001564590-21-031393:8k_2_02:48]
NetApp announced that Carrie Palin, former senior vice president and chief marketing officer of Splunk, has joined as a member of the Board of Directors.

[0001564590-21-031393:8k_2_02:49]
Webcast and conference call information

[0001564590-21-031393:8k_2_02:50]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-21-031393:8k_2_02:51]
###

[0001564590-21-031393:8k_2_02:52]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001564590-21-031393:8k_2_02:53]
Footnotes

[0001564590-21-031393:8k_2_02:54]
1Public cloud services annualized revenue run rate (ARR) is calculated as the annualized value of all public cloud services customer commitments as of the last day of the quarter, with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0001564590-21-031393:8k_2_02:55]
2All Flash Array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0001564590-21-031393:8k_2_02:56]
3Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings and free cash flow.

[0001564590-21-031393:8k_2_02:57]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, (j) COVID-19 charges and (k) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-21-031393:8k_2_02:58]
5GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-21-031393:8k_2_02:59]
NetApp usage of non-GAAP financial information

[0001564590-21-031393:8k_2_02:60]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0001564590-21-031393:8k_2_02:61]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0001564590-21-031393:8k_2_02:62]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-21-031393:8k_2_02:63]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0001564590-21-031393:8k_2_02:64]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it represents the amounts under purchase orders received by us during a given period that have been billed.

[0001564590-21-031393:8k_2_02:65]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-21-031393:8k_2_02:66]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-21-031393:8k_2_02:67]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-21-031393:8k_2_02:68]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-21-031393:8k_2_02:69]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-21-031393:8k_2_02:70]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-21-031393:8k_2_02:71]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-21-031393:8k_2_02:72]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-21-031393:8k_2_02:73]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-031393:8k_2_02:74]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-031393:8k_2_02:75]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-031393:8k_2_02:76]
J. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-031393:8k_2_02:77]
K. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior

[0001564590-21-031393:8k_2_02:78]
fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-21-031393:8k_2_02:79]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-21-031393:8k_2_02:80]
About NetApp

[0001564590-21-031393:8k_2_02:81]
NetApp is a global cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The Company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0001564590-21-031393:8k_2_02:82]
NETAPP, INC.

[0001564590-21-031393:8k_2_02:83]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-031393:8k_2_02:84]
(In millions)

[0001564590-21-031393:8k_2_02:85]
(Unaudited)

[0001564590-21-031393:8k_2_02:86]
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,596 |  |  | $ | 2,882 |  |
| Accounts receivable |  |  | 945 |  |  |  | 973 |  |
| Inventories |  |  | 114 |  |  |  | 145 |  |
| Other current assets |  |  | 346 |  |  |  | 274 |  |
| Total current assets |  |  | 6,001 |  |  |  | 4,274 |  |
| Property and equipment, net |  |  | 525 |  |  |  | 727 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,140 |  |  |  | 1,822 |  |
| Other non-current assets |  |  | 694 |  |  |  | 699 |  |
| Total assets |  | $ | 9,360 |  |  | $ | 7,522 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 420 |  |  | $ | 426 |  |
| Accrued expenses |  |  | 970 |  |  |  | 774 |  |
| Commercial paper notes |  |  | — |  |  |  | 522 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,062 |  |  |  | 1,894 |  |
| Total current liabilities |  |  | 3,452 |  |  |  | 3,616 |  |
| Long-term debt |  |  | 2,632 |  |  |  | 1,146 |  |
| Other long-term liabilities |  |  | 650 |  |  |  | 714 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,941 |  |  |  | 1,804 |  |
| Total liabilities |  |  | 8,675 |  |  |  | 7,280 |  |
| Stockholders' equity |  |  | 685 |  |  |  | 242 |  |
| Total liabilities and stockholders' equity |  | $ | 9,360 |  |  | $ | 7,522 |  |

[0001564590-21-031393:8k_2_02:87]
NETAPP, INC.

[0001564590-21-031393:8k_2_02:88]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-031393:8k_2_02:89]
(In millions, except per share amounts)

[0001564590-21-031393:8k_2_02:90]
(Unaudited)

[0001564590-21-031393:8k_2_02:91]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 840 |  |  | $ | 793 |  |  | $ | 2,991 |  |  | $ | 2,995 |  |
| Software support |  |  | 343 |  |  |  | 267 |  |  |  | 1,281 |  |  |  | 1,034 |  |
| Hardware support and other services |  |  | 372 |  |  |  | 341 |  |  |  | 1,472 |  |  |  | 1,383 |  |
| Net revenues |  |  | 1,555 |  |  |  | 1,401 |  |  |  | 5,744 |  |  |  | 5,412 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 387 |  |  |  | 355 |  |  |  | 1,432 |  |  |  | 1,368 |  |
| Cost of software support |  |  | 28 |  |  |  | 15 |  |  |  | 95 |  |  |  | 48 |  |
| Cost of hardware support and other services |  |  | 105 |  |  |  | 90 |  |  |  | 402 |  |  |  | 373 |  |
| Total cost of revenues |  |  | 520 |  |  |  | 460 |  |  |  | 1,929 |  |  |  | 1,789 |  |
| Gross profit |  |  | 1,035 |  |  |  | 941 |  |  |  | 3,815 |  |  |  | 3,623 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 447 |  |  |  | 389 |  |  |  | 1,744 |  |  |  | 1,585 |  |
| Research and development |  |  | 221 |  |  |  | 212 |  |  |  | 881 |  |  |  | 847 |  |
| General and administrative |  |  | 66 |  |  |  | 63 |  |  |  | 257 |  |  |  | 263 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |  |  | (38 | ) |
| Total operating expenses |  |  | 580 |  |  |  | 664 |  |  |  | 2,784 |  |  |  | 2,678 |  |
| Income from operations |  |  | 455 |  |  |  | 277 |  |  |  | 1,031 |  |  |  | 945 |  |
| Other expense, net |  |  | (19 | ) |  |  | (27 | ) |  |  | (69 | ) |  |  | (1 | ) |
| Income before income taxes |  |  | 436 |  |  |  | 250 |  |  |  | 962 |  |  |  | 944 |  |
| Provision for income taxes |  |  | 102 |  |  |  | 54 |  |  |  | 232 |  |  |  | 125 |  |
| Net income |  | $ | 334 |  |  | $ | 196 |  |  | $ | 730 |  |  | $ | 819 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.50 |  |  | $ | 0.89 |  |  | $ | 3.29 |  |  | $ | 3.56 |  |
| Diluted |  | $ | 1.46 |  |  | $ | 0.88 |  |  | $ | 3.23 |  |  | $ | 3.52 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 222 |  |  |  | 220 |  |  |  | 222 |  |  |  | 230 |  |
| Diluted |  |  | 229 |  |  |  | 222 |  |  |  | 226 |  |  |  | 233 |  |

[0001564590-21-031393:8k_2_02:92]
NETAPP, INC.

[0001564590-21-031393:8k_2_02:93]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-031393:8k_2_02:94]
(In millions)

[0001564590-21-031393:8k_2_02:95]
(Unaudited)

[0001564590-21-031393:8k_2_02:96]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 334 |  |  | $ | 196 |  |  | $ | 730 |  |  | $ | 819 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48 |  |  |  | 47 |  |  |  | 207 |  |  |  | 193 |  |
| Non-cash operating lease cost |  |  | 14 |  |  |  | 12 |  |  |  | 52 |  |  |  | 51 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 35 |  |  |  | 197 |  |  |  | 153 |  |
| Deferred income taxes |  |  | (5 | ) |  |  | 6 |  |  |  | (6 | ) |  |  | (17 | ) |
| Gain on sale or derecognition of assets |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |  |  | (38 | ) |
| Other items, net |  |  | (11 | ) |  |  | 17 |  |  |  | 24 |  |  |  | 1 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (146 | ) |  |  | (156 | ) |  |  | 62 |  |  |  | 238 |  |
| Inventories |  |  | (8 | ) |  |  | (32 | ) |  |  | 31 |  |  |  | (14 | ) |
| Accounts payable |  |  | 81 |  |  |  | 41 |  |  |  | (11 | ) |  |  | (117 | ) |
| Accrued expenses |  |  | 195 |  |  |  | 96 |  |  |  | 134 |  |  |  | (177 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 183 |  |  |  | 147 |  |  |  | 193 |  |  |  | 54 |  |
| Long-term taxes payable |  |  | (6 | ) |  |  | (30 | ) |  |  | (57 | ) |  |  | (163 | ) |
| Changes in other operating assets and liabilities, net |  |  | (12 | ) |  |  | 4 |  |  |  | (67 | ) |  |  | 77 |  |
| Net cash provided by operating activities |  |  | 559 |  |  |  | 383 |  |  |  | 1,333 |  |  |  | 1,060 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 20 |  |  |  | 82 |  |  |  | 160 |  |  |  | 1,370 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (24 | ) |  |  | (162 | ) |  |  | (124 | ) |
| Proceeds from sale of properties |  |  | 365 |  |  |  | — |  |  |  | 371 |  |  |  | 96 |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (17 | ) |  |  | (350 | ) |  |  | (73 | ) |
| Other investing activities, net |  |  | (6 | ) |  |  | 1 |  |  |  | 2 |  |  |  | — |  |
| Net cash provided by investing activities |  |  | 341 |  |  |  | 42 |  |  |  | 21 |  |  |  | 1,269 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 6 |  |  |  | — |  |  |  | 98 |  |  |  | 102 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (4 | ) |  |  | (2 | ) |  |  | (42 | ) |  |  | (79 | ) |
| Repurchase of common stock |  |  | (75 | ) |  |  | (161 | ) |  |  | (125 | ) |  |  | (1,411 | ) |
| (Repayments of) proceeds from commercial paper notes, original maturities of three months or less, net |  |  | — |  |  |  | (261 | ) |  |  | (420 | ) |  |  | 172 |  |
| Issuances of debt, net of issuance costs |  |  | — |  |  |  | 101 |  |  |  | 2,057 |  |  |  | 111 |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | (10 | ) |  |  | (689 | ) |  |  | (410 | ) |
| Dividends paid |  |  | (106 | ) |  |  | (105 | ) |  |  | (427 | ) |  |  | (439 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | (2 | ) |  |  | (8 | ) |  |  | (6 | ) |
| Net cash (used in) provided by financing activities |  |  | (180 | ) |  |  | (440 | ) |  |  | 444 |  |  |  | (1,960 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 1 |  |  |  | (30 | ) |  |  | 71 |  |  |  | (34 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 721 |  |  |  | (45 | ) |  |  | 1,869 |  |  |  | 335 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,814 |  |  |  | 2,711 |  |  |  | 2,666 |  |  |  | 2,331 |  |
| End of period |  | $ | 4,535 |  |  | $ | 2,666 |  |  | $ | 4,535 |  |  | $ | 2,666 |  |

[0001564590-21-031393:8k_2_02:97]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  | FY2021 |  |  | FY2020 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 840 |  |  |  |  | $ | 775 |  |  |  |  | $ | 793 |  |  |  |  | $ | 2,991 |  |  | $ | 2,995 |  |
| Hardware |  | $ | 360 |  |  |  |  | $ | 347 |  |  |  |  | $ | 386 |  |  |  |  | $ | 1,355 |  |  | $ | 1,541 |  |
| Software |  | $ | 480 |  |  |  |  | $ | 428 |  |  |  |  | $ | 407 |  |  |  |  | $ | 1,636 |  |  | $ | 1,454 |  |
| Software Support |  | $ | 343 |  |  |  |  | $ | 334 |  |  |  |  | $ | 267 |  |  |  |  | $ | 1,281 |  |  | $ | 1,034 |  |
| Hardware Support & Other Services |  | $ | 372 |  |  |  |  | $ | 361 |  |  |  |  | $ | 341 |  |  |  |  | $ | 1,472 |  |  | $ | 1,383 |  |
| Hardware Support Contracts |  | $ | 299 |  |  |  |  | $ | 293 |  |  |  |  | $ | 279 |  |  |  |  | $ | 1,195 |  |  | $ | 1,142 |  |
| Professional and Other Services |  | $ | 73 |  |  |  |  | $ | 68 |  |  |  |  | $ | 62 |  |  |  |  | $ | 277 |  |  | $ | 241 |  |
| Net Revenues |  | $ | 1,555 |  |  |  |  | $ | 1,470 |  |  |  |  | $ | 1,401 |  |  |  |  | $ | 5,744 |  |  | $ | 5,412 |  |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 840 |  |  |  |  | $ | 775 |  |  |  |  | $ | 793 |  |  |  |  | $ | 2,991 |  |  | $ | 2,995 |  |
| Software* |  | $ | 480 |  |  |  |  | $ | 428 |  |  |  |  | $ | 407 |  |  |  |  | $ | 1,636 |  |  | $ | 1,454 |  |
| Hardware* |  | $ | 360 |  |  |  |  | $ | 347 |  |  |  |  | $ | 386 |  |  |  |  | $ | 1,355 |  |  | $ | 1,541 |  |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components to display the significance of software included in total product revenues. |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  | FY2021 |  |  | FY2020 |  |
| Software and recurring support and cloud revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product - Software |  | $ | 480 |  |  |  |  | $ | 428 |  |  |  |  | $ | 407 |  |  |  |  | $ | 1,636 |  |  | $ | 1,454 |  |
| Software Support |  | $ | 343 |  |  |  |  | $ | 334 |  |  |  |  | $ | 267 |  |  |  |  | $ | 1,281 |  |  | $ | 1,034 |  |
| Hardware Support Contracts |  | $ | 299 |  |  |  |  | $ | 293 |  |  |  |  | $ | 279 |  |  |  |  | $ | 1,195 |  |  | $ | 1,142 |  |
| Software and recurring support and cloud revenue* |  | $ | 1,122 |  |  |  |  | $ | 1,055 |  |  |  |  | $ | 953 |  |  |  |  | $ | 4,112 |  |  | $ | 3,630 |  |
| Software and recurring support and cloud revenue as a percentage of net revenues |  |  | 72 | % |  |  |  | 72 | % |  |  |  | 68 | % |  |  |  |  | 72 | % |  |  | 67 | % |
| Cloud revenue is included in software support revenues |  |
| *Software and recurring support and cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'21 |  |  |  |  | % of Q3 FY'21 |  |  |  |  | % of Q4 FY'20 |  |  |  |  | % of FY 2021 |  |  | % of FY 2020 |  |
|  |  | Revenue |  |  |  |  | Revenue |  |  |  |  | Revenue |  |  |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 53 | % |  |  |  |  | 53 | % |  |  |  |  | 54 | % |  |  |  |  | 54 | % |  |  | 53 | % |
| Americas Commercial |  |  | 44 | % |  |  |  |  | 43 | % |  |  |  |  | 43 | % |  |  |  |  | 43 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 9 | % |  |  |  |  | 10 | % |  |  |  |  | 11 | % |  |  |  |  | 11 | % |  |  | 12 | % |
| EMEA |  |  | 32 | % |  |  |  |  | 32 | % |  |  |  |  | 32 | % |  |  |  |  | 31 | % |  |  | 32 | % |
| Asia Pacific |  |  | 15 | % |  |  |  |  | 15 | % |  |  |  |  | 14 | % |  |  |  |  | 15 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'21 |  |  |  |  | % of Q3 FY'21 |  |  |  |  | % of Q4 FY'20 |  |  |  |  | % of FY 2021 |  |  | % of FY 2020 |  |
|  |  | Revenue |  |  |  |  | Revenue |  |  |  |  | Revenue |  |  |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 23 | % |  |  |  |  | 24 | % |  |  |  |  | 23 | % |  |  |  |  | 23 | % |  |  | 21 | % |
| Indirect |  |  | 77 | % |  |  |  |  | 76 | % |  |  |  |  | 77 | % |  |  |  |  | 77 | % |  |  | 79 | % |

[0001564590-21-031393:8k_2_02:98]
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  | FY2021 |  |  | FY2020 |  |
| Non-GAAP Gross Margin |  |  | 67.3 | % |  |  |  |  | 67.3 | % |  |  |  |  | 68.0 | % |  |  |  |  | 67.4 | % |  |  | 67.9 | % |
| Product |  |  | 54.3 | % |  |  |  |  | 53.4 | % |  |  |  |  | 56.4 | % |  |  |  |  | 53.1 | % |  |  | 55.7 | % |
| Software Support |  |  | 93.3 | % |  |  |  |  | 93.1 | % |  |  |  |  | 94.4 | % |  |  |  |  | 93.8 | % |  |  | 95.4 | % |
| Hardware Support & Other Services |  |  | 72.6 | % |  |  |  |  | 73.4 | % |  |  |  |  | 74.5 | % |  |  |  |  | 73.4 | % |  |  | 73.8 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  | FY2021 |  |  | FY2020 |  |
| Non-GAAP Income from Operations |  | $ | 358 |  |  |  |  | $ | 322 |  |  |  |  | $ | 324 |  |  |  |  | $ | 1,184 |  |  | $ | 1,123 |  |
| % of Net Revenues |  |  | 23.0 | % |  |  |  |  | 21.9 | % |  |  |  |  | 23.1 | % |  |  |  |  | 20.6 | % |  |  | 20.8 | % |
| Non-GAAP Income before Income Taxes |  | $ | 339 |  |  |  |  | $ | 311 |  |  |  |  | $ | 307 |  |  |  |  | $ | 1,123 |  |  | $ | 1,132 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.9 | % |  |  |  |  | 19.6 | % |  |  |  |  | 13.7 | % |  |  |  |  | 18.3 | % |  |  | 16.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  | FY2021 |  |  | FY2020 |  |
| Non-GAAP Net Income |  | $ | 268 |  |  |  |  | $ | 250 |  |  |  |  | $ | 265 |  |  |  |  | $ | 917 |  |  | $ | 944 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 229 |  |  |  |  |  | 227 |  |  |  |  |  | 222 |  |  |  |  |  | 226 |  |  |  | 233 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.17 |  |  |  |  | $ | 1.10 |  |  |  |  | $ | 1.19 |  |  |  |  | $ | 4.06 |  |  | $ | 4.05 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,003 |  |  |  |  | $ | 3,828 |  |  |  |  | $ | 3,698 |  |  |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 55 |  |  |  |  |  | 49 |  |  |  |  |  | 63 |  |  |  |  |  |  |  |  |  |  |  |
| DPO (days) |  |  | 74 |  |  |  |  |  | 62 |  |  |  |  |  | 84 |  |  |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 18 |  |  |  |  |  | 19 |  |  |  |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY21 |  |  |  |  | Q3'FY21 |  |  |  |  | Q4'FY20 |  |  |  |  | FY2021 |  |  | FY2020 |  |
| Net Cash Provided by Operating Activities |  | $ | 559 |  |  |  |  | $ | 373 |  |  |  |  | $ | 383 |  |  |  |  | $ | 1,333 |  |  | $ | 1,060 |  |
| Purchases of Property and Equipment |  | $ | 38 |  |  |  |  | $ | 32 |  |  |  |  | $ | 24 |  |  |  |  | $ | 162 |  |  | $ | 124 |  |
| Free Cash Flow |  | $ | 521 |  |  |  |  | $ | 341 |  |  |  |  | $ | 359 |  |  |  |  | $ | 1,171 |  |  | $ | 936 |  |
| Free Cash Flow as % of Net Revenues |  |  | 33.5 | % |  |  |  |  | 23.2 | % |  |  |  |  | 25.6 | % |  |  |  |  | 20.4 | % |  |  | 17.3 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0001564590-21-031393:8k_2_02:99]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| NET INCOME |  | $ | 334 |  |  | $ | 182 |  |  | $ | 196 |  |  | $ | 730 |  |  | $ | 819 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 15 |  |  |  | 9 |  |  |  | 49 |  |  |  | 39 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 46 |  |  |  | 35 |  |  |  | 197 |  |  |  | 153 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | — |  |  |  | 10 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| COVID-19 charges |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (156 | ) |  |  | — |  |  |  | — |  |  |  | (156 | ) |  |  | (38 | ) |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Income tax effects |  |  | 18 |  |  |  | (13 | ) |  |  | 12 |  |  |  | (20 | ) |  |  | (13 | ) |
| Income tax expenses from integration of acquired companies |  |  | 13 |  |  |  | 17 |  |  |  | — |  |  |  | 46 |  |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (50 | ) |
| NON-GAAP NET INCOME |  | $ | 268 |  |  | $ | 250 |  |  | $ | 265 |  |  | $ | 917 |  |  | $ | 944 |  |
| COST OF REVENUES |  | $ | 520 |  |  | $ | 495 |  |  | $ | 460 |  |  | $ | 1,929 |  |  | $ | 1,789 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (12 | ) |  |  | (9 | ) |  |  | (41 | ) |  |  | (39 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (14 | ) |  |  | (13 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 509 |  |  | $ | 480 |  |  | $ | 448 |  |  | $ | 1,874 |  |  | $ | 1,737 |  |
| COST OF PRODUCT REVENUES |  | $ | 387 |  |  | $ | 369 |  |  | $ | 355 |  |  | $ | 1,432 |  |  | $ | 1,368 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (7 | ) |  |  | (9 | ) |  |  | (26 | ) |  |  | (39 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |  |  | (4 | ) |  |  | (3 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 384 |  |  | $ | 361 |  |  | $ | 346 |  |  | $ | 1,402 |  |  | $ | 1,326 |  |
| COST OF SOFTWARE SUPPORT REVENUES |  | $ | 28 |  |  | $ | 28 |  |  | $ | 15 |  |  | $ | 95 |  |  | $ | 48 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |  |  | (15 | ) |  |  | — |  |
| NON-GAAP COST OF SOFTWARE SUPPORT REVENUES |  | $ | 23 |  |  | $ | 23 |  |  | $ | 15 |  |  | $ | 80 |  |  | $ | 48 |  |
| COST OF HARDWARE SUPPORT AND OTHER SERVICES REVENUES |  | $ | 105 |  |  | $ | 98 |  |  | $ | 90 |  |  | $ | 402 |  |  | $ | 373 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (10 | ) |
| NON-GAAP COST OF HARDWARE SUPPORT AND OTHER SERVICES REVENUES |  | $ | 102 |  |  | $ | 96 |  |  | $ | 87 |  |  | $ | 392 |  |  | $ | 363 |  |
| GROSS PROFIT |  | $ | 1,035 |  |  | $ | 975 |  |  | $ | 941 |  |  | $ | 3,815 |  |  | $ | 3,623 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 7 |  |  |  | 12 |  |  |  | 9 |  |  |  | 41 |  |  |  | 39 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |  |  | 14 |  |  |  | 13 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,046 |  |  | $ | 990 |  |  | $ | 953 |  |  | $ | 3,870 |  |  | $ | 3,675 |  |

[0001564590-21-031393:8k_2_02:100]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| SALES AND MARKETING EXPENSES |  | $ | 447 |  |  | $ | 436 |  |  | $ | 389 |  |  | $ | 1,744 |  |  | $ | 1,585 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (3 | ) |  |  | — |  |  |  | (8 | ) |  |  | — |  |
| Stock-based compensation |  |  | (22 | ) |  |  | (21 | ) |  |  | (16 | ) |  |  | (92 | ) |  |  | (66 | ) |
| COVID-19 charges |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | — |  |  |  | (3 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 423 |  |  | $ | 412 |  |  | $ | 370 |  |  | $ | 1,644 |  |  | $ | 1,516 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 221 |  |  | $ | 215 |  |  | $ | 212 |  |  | $ | 881 |  |  | $ | 847 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (15 | ) |  |  | (12 | ) |  |  | (64 | ) |  |  | (53 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 206 |  |  | $ | 200 |  |  | $ | 200 |  |  | $ | 817 |  |  | $ | 794 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 66 |  |  | $ | 63 |  |  | $ | 63 |  |  | $ | 257 |  |  | $ | 263 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (4 | ) |  |  | (27 | ) |  |  | (21 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 59 |  |  | $ | 56 |  |  | $ | 59 |  |  | $ | 225 |  |  | $ | 242 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 42 |  |  | $ | 21 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (42 | ) |  |  | (21 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | (156 | ) |  | $ | — |  |  | $ | — |  |  | $ | (156 | ) |  | $ | (38 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | 156 |  |  |  | — |  |  |  | — |  |  |  | 156 |  |  |  | 38 |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (2 | ) |  |  | (3 | ) |  |  | — |  |  |  | (16 | ) |  |  | — |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 580 |  |  | $ | 717 |  |  | $ | 664 |  |  | $ | 2,784 |  |  | $ | 2,678 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (3 | ) |  |  | — |  |  |  | (8 | ) |  |  | — |  |
| Stock-based compensation |  |  | (44 | ) |  |  | (43 | ) |  |  | (32 | ) |  |  | (183 | ) |  |  | (140 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| COVID-19 charges |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | — |  |  |  | (3 | ) |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (42 | ) |  |  | (21 | ) |
| Acquisition-related expense |  |  | (2 | ) |  |  | (3 | ) |  |  | — |  |  |  | (16 | ) |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | 156 |  |  |  | — |  |  |  | — |  |  |  | 156 |  |  |  | 38 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 688 |  |  | $ | 668 |  |  | $ | 629 |  |  | $ | 2,686 |  |  | $ | 2,552 |  |

[0001564590-21-031393:8k_2_02:101]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| INCOME FROM OPERATIONS |  | $ | 455 |  |  | $ | 258 |  |  | $ | 277 |  |  | $ | 1,031 |  |  | $ | 945 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 15 |  |  |  | 9 |  |  |  | 49 |  |  |  | 39 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 46 |  |  |  | 35 |  |  |  | 197 |  |  |  | 153 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| COVID-19 charges |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (156 | ) |  |  | — |  |  |  | — |  |  |  | (156 | ) |  |  | (38 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 358 |  |  | $ | 322 |  |  | $ | 324 |  |  | $ | 1,184 |  |  | $ | 1,123 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | (19 | ) |  | $ | (11 | ) |  | $ | (27 | ) |  | $ | (69 | ) |  | $ | (1 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | — |  |  |  | 10 |  |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (19 | ) |  | $ | (11 | ) |  | $ | (17 | ) |  | $ | (61 | ) |  | $ | 9 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 436 |  |  | $ | 247 |  |  | $ | 250 |  |  | $ | 962 |  |  | $ | 944 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 15 |  |  |  | 9 |  |  |  | 49 |  |  |  | 39 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 46 |  |  |  | 35 |  |  |  | 197 |  |  |  | 153 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | — |  |  |  | 10 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| COVID-19 charges |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (156 | ) |  |  | — |  |  |  | — |  |  |  | (156 | ) |  |  | (38 | ) |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 339 |  |  | $ | 311 |  |  | $ | 307 |  |  | $ | 1,123 |  |  | $ | 1,132 |  |
| PROVISION FOR INCOME TAXES |  | $ | 102 |  |  | $ | 65 |  |  | $ | 54 |  |  | $ | 232 |  |  | $ | 125 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (18 | ) |  |  | 13 |  |  |  | (12 | ) |  |  | 20 |  |  |  | 13 |  |
| Income tax expenses from integration of acquired companies |  |  | (13 | ) |  |  | (17 | ) |  |  | — |  |  |  | (46 | ) |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 50 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 71 |  |  | $ | 61 |  |  | $ | 42 |  |  | $ | 206 |  |  | $ | 188 |  |
| NET INCOME PER SHARE |  | $ | 1.46 |  |  | $ | 0.80 |  |  | $ | 0.88 |  |  | $ | 3.23 |  |  | $ | 3.52 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.07 |  |  |  | 0.04 |  |  |  | 0.22 |  |  |  | 0.17 |  |
| Stock-based compensation |  |  | 0.21 |  |  |  | 0.20 |  |  |  | 0.16 |  |  |  | 0.87 |  |  |  | 0.66 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 0.05 |  |  |  | — |  |  |  | 0.04 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| COVID-19 charges |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.19 |  |  |  | 0.09 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.07 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (0.68 | ) |  |  | — |  |  |  | — |  |  |  | (0.69 | ) |  |  | (0.16 | ) |
| Debt extinguishment costs |  | — |  |  | — |  |  |  | — |  |  |  | 0.06 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  | — |  |  |  | (0.03 | ) |  |  | — |  |

[0001564590-21-031393:8k_2_02:102]
| Income tax effects |  |  | 0.08 |  |  |  | (0.06 | ) |  |  | 0.05 |  |  |  | (0.09 | ) |  |  | (0.06 | ) |
| Income tax expenses from integration of acquired companies |  |  | 0.06 |  |  |  | 0.07 |  |  |  | — |  |  |  | 0.20 |  |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.21 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.17 |  |  | $ | 1.10 |  |  | $ | 1.19 |  |  | $ | 4.06 |  |  | $ | 4.05 |  |

[0001564590-21-031393:8k_2_02:103]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| Gross margin-GAAP |  |  | 66.6 | % |  |  | 66.3 | % |  |  | 67.2 | % |  |  | 66.4 | % |  |  | 66.9 | % |
| Cost of revenues adjustments |  |  | 0.7 | % |  |  | 1.0 | % |  |  | 0.9 | % |  |  | 1.0 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 67.3 | % |  |  | 67.3 | % |  |  | 68.0 | % |  |  | 67.4 | % |  |  | 67.9 | % |
| GAAP cost of revenues |  | $ | 520 |  |  | $ | 495 |  |  | $ | 460 |  |  | $ | 1,929 |  |  | $ | 1,789 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (12 | ) |  |  | (9 | ) |  |  | (41 | ) |  |  | (39 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (14 | ) |  |  | (13 | ) |
| Non-GAAP cost of revenues |  | $ | 509 |  |  | $ | 480 |  |  | $ | 448 |  |  | $ | 1,874 |  |  | $ | 1,737 |  |
| Net revenues |  | $ | 1,555 |  |  | $ | 1,470 |  |  | $ | 1,401 |  |  | $ | 5,744 |  |  | $ | 5,412 |  |

[0001564590-21-031393:8k_2_02:104]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| Product gross margin-GAAP |  |  | 53.9 | % |  |  | 52.4 | % |  |  | 55.2 | % |  |  | 52.1 | % |  |  | 54.3 | % |
| Cost of product revenues adjustments |  |  | 0.4 | % |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.0 | % |  |  | 1.4 | % |
| Product gross margin-Non-GAAP |  |  | 54.3 | % |  |  | 53.4 | % |  |  | 56.4 | % |  |  | 53.1 | % |  |  | 55.7 | % |
| GAAP cost of product revenues |  | $ | 387 |  |  | $ | 369 |  |  | $ | 355 |  |  | $ | 1,432 |  |  | $ | 1,368 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (7 | ) |  |  | (9 | ) |  |  | (26 | ) |  |  | (39 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |  |  | (4 | ) |  |  | (3 | ) |
| Non-GAAP cost of product revenues |  | $ | 384 |  |  | $ | 361 |  |  | $ | 346 |  |  | $ | 1,402 |  |  | $ | 1,326 |  |
| Product revenues |  | $ | 840 |  |  | $ | 775 |  |  | $ | 793 |  |  | $ | 2,991 |  |  | $ | 2,995 |  |

[0001564590-21-031393:8k_2_02:105]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SOFTWARE SUPPORT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| Software support gross margin-GAAP |  |  | 91.8 | % |  |  | 91.6 | % |  |  | 94.4 | % |  |  | 92.6 | % |  |  | 95.4 | % |
| Cost of software support revenues adjustment |  |  | 1.5 | % |  |  | 1.5 | % |  |  | — | % |  |  | 1.2 | % |  |  | — | % |
| Software support gross margin-Non-GAAP |  |  | 93.3 | % |  |  | 93.1 | % |  |  | 94.4 | % |  |  | 93.8 | % |  |  | 95.4 | % |
| GAAP cost of software support revenues |  | $ | 28 |  |  | $ | 28 |  |  | $ | 15 |  |  | $ | 95 |  |  | $ | 48 |  |
| Cost of software support revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |  |  | (15 | ) |  |  | — |  |
| Non-GAAP cost of software support revenues |  | $ | 23 |  |  | $ | 23 |  |  | $ | 15 |  |  | $ | 80 |  |  | $ | 48 |  |
| Software support revenues |  | $ | 343 |  |  | $ | 334 |  |  | $ | 267 |  |  | $ | 1,281 |  |  | $ | 1,034 |  |

[0001564590-21-031393:8k_2_02:106]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE SUPPORT AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| Hardware support and other services gross margin-GAAP |  |  | 71.8 | % |  |  | 72.9 | % |  |  | 73.6 | % |  |  | 72.7 | % |  |  | 73.0 | % |
| Cost of hardware support and other services revenues adjustment |  |  | 0.8 | % |  |  | 0.6 | % |  |  | 0.9 | % |  |  | 0.7 | % |  |  | 0.7 | % |
| Hardware support and other services gross margin-Non-GAAP |  |  | 72.6 | % |  |  | 73.4 | % |  |  | 74.5 | % |  |  | 73.4 | % |  |  | 73.8 | % |
| GAAP cost of hardware support and other services revenues |  | $ | 105 |  |  | $ | 98 |  |  | $ | 90 |  |  | $ | 402 |  |  | $ | 373 |  |
| Cost of hardware support and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (10 | ) |
| Non-GAAP cost of hardware support and other services revenues |  | $ | 102 |  |  | $ | 96 |  |  | $ | 87 |  |  | $ | 392 |  |  | $ | 363 |  |
| Hardware support and other services revenues |  | $ | 372 |  |  | $ | 361 |  |  | $ | 341 |  |  | $ | 1,472 |  |  | $ | 1,383 |  |

[0001564590-21-031393:8k_2_02:107]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| GAAP effective tax rate |  |  | 23.4 | % |  |  | 26.3 | % |  |  | 21.6 | % |  |  | 24.1 | % |  |  | 13.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 0.5 | % |  |  | 0.2 | % |  |  | (7.9 | )% |  |  | (1.0 | )% |  |  | (1.1 | )% |
| Income tax expenses from integration of acquired companies |  |  | (3.0 | )% |  |  | (6.9 | )% |  |  | — | % |  |  | (4.8 | )% |  |  | — | % |
| Resolution of income tax matters |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | 4.4 | % |
| Non-GAAP effective tax rate |  |  | 20.9 | % |  |  | 19.6 | % |  |  | 13.7 | % |  |  | 18.3 | % |  |  | 16.6 | % |

[0001564590-21-031393:8k_2_02:108]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| Net cash provided by operating activities |  | $ | 559 |  |  | $ | 373 |  |  | $ | 383 |  |  | $ | 1,333 |  |  | $ | 1,060 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (32 | ) |  |  | (24 | ) |  |  | (162 | ) |  |  | (124 | ) |
| Free cash flow |  | $ | 521 |  |  | $ | 341 |  |  | $ | 359 |  |  | $ | 1,171 |  |  | $ | 936 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY21 |  |  | Q3'FY21 |  |  | Q4'FY20 |  |  | FY2021 |  |  | FY2020 |  |
| Net revenues |  | $ | 1,555 |  |  | $ | 1,470 |  |  | $ | 1,401 |  |  | $ | 5,744 |  |  | $ | 5,412 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 183 |  |  |  | 128 |  |  |  | 147 |  |  |  | 193 |  |  |  | 54 |  |
| Billings |  | $ | 1,738 |  |  | $ | 1,598 |  |  | $ | 1,548 |  |  | $ | 5,937 |  |  | $ | 5,466 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0001564590-21-031393:8k_2_02:109]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FIRST QUARTER FISCAL 2022 |
|  |  | First Quarter |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $0.89 - $0.97 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the First Quarter Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.04) |
| Stock-based compensation expense |  | ($0.20) |
| Income tax effects |  | $0.04 |
| Total Adjustments |  | ($0.20) |
| GAAP Guidance - Net Income Per Share |  | $0.69 - $0.77 |

[0001564590-21-031393:8k_2_02:110]
Some items may not add or recalculate due to rounding.

[0001564590-21-031393:8k_2_02:111]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| FISCAL 2022 |  |
| (Unaudited) |  |
|  |  | GROSS MARGIN |  |
| Gross Margin - Non-GAAP Guidance |  | 67% - 68% |  |
| Adjustment: |  |  |  |  |
| Cost of revenues adjustments |  | (1)% |  |
| Gross Margin - GAAP Guidance |  | 66% - 67% |  |
|  |  | OPERATING MARGIN |  |
| Operating Margin - Non-GAAP Guidance |  | 21% - 22% |  |
| Adjustments: |  |  |  |  |
| Amortization of intangible assets |  | (1)% |  |
| Stock-based compensation expense |  | (4)% |  |
| Operating Margin - GAAP Guidance |  | 16% - 17% |  |
|  |  | EFFECTIVE TAX RATE |  |
| Effective Tax Rate - Non-GAAP Guidance |  | ~ 19% |  |
| Adjustment: |  |  |  |  |
| Income tax effects |  | 1% |  |
| Effective Tax Rate - GAAP Guidance |  | ~ 20% |  |

[0001564590-21-031393:8k_2_02:112]
Some items may not add or recalculate due to rounding.

[0001564590-21-031393:8k_2_02:113]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2022 |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $4.45 - $4.65 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.16) |
| Stock-based compensation expense |  | ($0.98) |
| Income tax effects |  | $0.17 |
| Total Adjustments |  | ($0.97) |
| GAAP Guidance - Net Income Per Share |  | $3.48 - $3.68 |

[0001564590-21-031393:8k_2_02:114]
Some items may not add or recalculate due to rounding.

[0001564590-21-031393:8k_2_02:115]
Contacts:

[0001564590-21-031393:8k_2_02:116]
(Press)

[0001564590-21-031393:8k_2_02:117]
Chris Drago

[0001564590-21-031393:8k_2_02:118]
1 831 900 888

[0001564590-21-031393:8k_2_02:119]
chris.drago@netapp.com

[0001564590-21-031393:8k_2_02:120]
(Investors)

[0001564590-21-031393:8k_2_02:121]
Lance Berger

[0001564590-21-031393:8k_2_02:122]
1 408 822 6628

[0001564590-21-031393:8k_2_02:123]
lance.berger@netapp.com

## item 5.02 — body, verbatim

[0001564590-21-031393:8k_body:1]
Item 5.02.     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-21-031393:8k_body:2]
(b)

[0001564590-21-031393:8k_body:3]
On June 2, 2021, Brad Anderson, Executive Vice President, Hybrid Cloud Group of the Company, informed the Company of his intent to retire from the Company, effective as of the end of fiscal year 2022 on April 29, 2022.
