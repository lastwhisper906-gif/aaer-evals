# NVDA notes — 0001045810-22-000036


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001045810-22-000036:notes:1]
Portions of the registrant's Proxy Statement for its 2022 Annual Meeting of Shareholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated by reference into Part III, Items 10-14 of this Annual Report on Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-22-000036:notes:2]
Organization and Summary of Significant Accounting Policies
Our Company

[0001045810-22-000036:notes:3]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-22-000036:notes:4]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-22-000036:notes:5]
On July 19, 2021, we executed a four-for-one stock split of our common stock. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the Stock Split.

[0001045810-22-000036:notes:6]
Fiscal Year

[0001045810-22-000036:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2022 and 2020 were both 52-week years. Fiscal year 2021 was a 53-week year.

[0001045810-22-000036:notes:8]
Reclassifications

[0001045810-22-000036:notes:9]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-22-000036:notes:10]
Principles of Consolidation

[0001045810-22-000036:notes:11]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-22-000036:notes:12]
Use of Estimates

[0001045810-22-000036:notes:13]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-22-000036:notes:14]
Revenue Recognition

[0001045810-22-000036:notes:15]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, software licensing, and cloud services. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract (where revenue is allocated on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation); and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-22-000036:notes:16]
Product Sales Revenue

[0001045810-22-000036:notes:17]
Revenue from product sales is recognized upon transfer of control of products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Certain products are sold with support or an extended warranty for the incorporated system, hardware, and/or software. Support and extended warranty revenue are recognized ratably over the service period, or as services are performed. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-22-000036:notes:18]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-22-000036:notes:19]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-22-000036:notes:20]
License and Development Arrangements

[0001045810-22-000036:notes:21]
Our license and development arrangements with customers typically require significant customization of our IP components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-22-000036:notes:22]
Software Licensing

[0001045810-22-000036:notes:23]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with the right to receive, on a when-and-if available basis, future unspecified software updates and upgrades. Revenue from software licenses is recognized up front when the software is made available to the customer. Software support revenue is recognized ratably over the service period, or as services are performed.

[0001045810-22-000036:notes:24]
Cloud Services

[0001045810-22-000036:notes:25]
Cloud services, which allow customers to use hosted software over the contract period without taking possession of the software, are provided on a subscription basis or a combination of subscription plus usage. Revenue related to subscription-based cloud services is recognized ratably over the contract period. Revenue related to cloud services based on usage is recognized as usage occurs.

[0001045810-22-000036:notes:26]
Product Warranties

[0001045810-22-000036:notes:27]
We generally offer a limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-22-000036:notes:28]
Stock-based Compensation

[0001045810-22-000036:notes:29]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, we estimate forfeitures at least annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates.

[0001045810-22-000036:notes:30]
Litigation, Investigation and Settlement Costs

[0001045810-22-000036:notes:31]
We currently, are, and will likely continue to be subject to claims, litigation, and other actions, including potential regulatory proceedings, involving patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, commercial disputes, goods and services offered by us and by third parties, and other matters. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial

[0001045810-22-000036:notes:32]
settlement payments or judgements. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-22-000036:notes:33]
Foreign Currency Remeasurement

[0001045810-22-000036:notes:34]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at exchange rates in effect during each period, except for those expenses related to non-monetary balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in earnings in our Consolidated Statements of Income and to date have not been significant.

[0001045810-22-000036:notes:35]
Income Taxes

[0001045810-22-000036:notes:36]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-22-000036:notes:37]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-22-000036:notes:38]
As of January 30, 2022, we had a valuation allowance of $907 million related to state and certain other deferred tax assets that management determined are not likely to be realized due to jurisdictional projections of future taxable income, tax attributes usage limitation by certain jurisdictions, and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as an income tax benefit during the period.

[0001045810-22-000036:notes:39]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-22-000036:notes:40]
Net Income Per Share

[0001045810-22-000036:notes:41]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of equity awards outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive.

[0001045810-22-000036:notes:42]
Cash and Cash Equivalents and Marketable Securities

[0001045810-22-000036:notes:43]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. Marketable securities consist of highly liquid debt investments with maturities of greater than three months when purchased. We currently classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0001045810-22-000036:notes:44]
We classify our cash equivalents and marketable securities related to debt securities at the date of acquisition as available-for-sale. These available-for-sale debt securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of

[0001045810-22-000036:notes:45]
tax. The fair value of interest-bearing debt securities includes accrued interest. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income (expense), net, section of our Consolidated Statements of Income.

[0001045810-22-000036:notes:46]
All of our available-for-sale debt investments are subject to a periodic impairment review. If the estimated fair value of available-for-sale debt securities is less than its amortized cost basis, we determine if the difference, if any, is caused by expected credit losses and write-down the amortized cost basis of the securities if it is more likely than not we will be required or we intend to sell the securities before recovery of its amortized cost basis. Allowances for credit losses and write-downs are recognized in the other income (expense), net section of our Consolidated Statements of Income.

[0001045810-22-000036:notes:47]
Fair Value of Financial Instruments

[0001045810-22-000036:notes:48]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 30, 2022 and January 31, 2021. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains or losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains or losses are recognized in earnings in the periods of change together with the offsetting losses or gains on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings. For derivative instruments not designated for hedge accounting, changes in fair value are recognized in earnings.

[0001045810-22-000036:notes:49]
Concentration of Credit Risk

[0001045810-22-000036:notes:50]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio duration. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-22-000036:notes:51]
Inventories

[0001045810-22-000036:notes:52]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory. Most of our inventory provisions relate to excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up. We record a liability for noncancelable purchase commitments with suppliers for quantities in excess of our future demand forecasts consistent with our valuation of obsolete or excess inventory.

[0001045810-22-000036:notes:53]
Property and Equipment

[0001045810-22-000036:notes:54]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization of assets recorded under finance leases. Leasehold improvements and assets recorded under finance leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.

[0001045810-22-000036:notes:55]
Leases

[0001045810-22-000036:notes:56]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

[0001045810-22-000036:notes:57]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0001045810-22-000036:notes:58]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

[0001045810-22-000036:notes:59]
Goodwill

[0001045810-22-000036:notes:60]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist. For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-22-000036:notes:61]
Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting units.

[0001045810-22-000036:notes:62]
Our quantitative impairment test considers both the income approach and the market approach to estimate a reporting unit’s fair value. The income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-22-000036:notes:63]
Intangible Assets and Other Long-Lived Assets

[0001045810-22-000036:notes:64]
Intangible assets primarily represent acquired intangible assets including developed technology, in-process research and development, or IPR&D, and customer relationships, as well as rights acquired under technology licenses, patents, and acquired IP. We currently amortize our intangible assets with finite lives over periods ranging from one to twenty years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method. We initially capitalize the fair value of IPR&D as an intangible asset with an indefinite life. When IPR&D projects are completed, we reclassify the IPR&D as an amortizable purchased intangible asset and amortize over the asset’s estimated useful life.

[0001045810-22-000036:notes:65]
Long-lived assets, such as property and equipment and intangible assets subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets or asset groups to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.

[0001045810-22-000036:notes:66]
Business Combination

[0001045810-22-000036:notes:67]
We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, including IPR&D, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used

[0001045810-22-000036:notes:68]
to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our Consolidated Statements of Income.

[0001045810-22-000036:notes:69]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

[0001045810-22-000036:notes:70]
Investment in Non-Affiliated Entities

[0001045810-22-000036:notes:71]
Non-marketable equity investments in privately-held companies are recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. These investments are valued using observable and unobservable inputs or data in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. The estimated fair value is based on quantitative and qualitative factors including subsequent financing activities by the investee.

[0001045810-22-000036:notes:72]
Marketable equity investments in publicly-held companies are recorded at fair value with the related unrealized and realized gains and losses recognized in other income (expense), net.

[0001045810-22-000036:notes:73]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-22-000036:notes:74]
Recently Adopted Accounting Pronouncement

[0001045810-22-000036:notes:75]
In October 2021, the Financial Accounting Standards Board issued a new accounting standard to require that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers. We early adopted this accounting standard in the third quarter of fiscal year 2022 and the impact was immaterial.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-22-000036:notes:76]
Business Combination
Termination of the Arm Share Purchase Agreement

[0001045810-22-000036:notes:77]
On February 8, 2022, NVIDIA and SoftBank announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We intend to record in operating expenses a $1.36 billion charge in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing in September 2020.

[0001045810-22-000036:notes:78]
Acquisition of Mellanox Technologies, Ltd.

[0001045810-22-000036:notes:79]
In April 2020, we completed the acquisition of all outstanding shares of Mellanox for a total purchase consideration of $7.13 billion. Mellanox is a supplier of high-performance interconnect products for computing, storage and communications applications. We acquired Mellanox to optimize data center workloads to scale across the entire computing, networking, and storage stack.

[0001045810-22-000036:notes:80]
Purchase Price Allocation

[0001045810-22-000036:notes:81]
The aggregate purchase consideration has been allocated as follows (in millions):

[0001045810-22-000036:notes:82]
| Purchase Price |  |  |
| Cash paid for outstanding Mellanox ordinary shares (1) |  | $ | 7,033 |  |
| Cash for Mellanox equity awards (2) |  | 16 |  |
| Total cash consideration |  | 7,049 |  |
| Fair value of Mellanox equity awards assumed by NVIDIA (3) |  | 85 |  |
| Total purchase consideration |  | $ | 7,134 |  |
| Allocation |  |  |
| Cash and cash equivalents |  | $ | 115 |  |
| Marketable securities |  | 699 |  |
| Accounts receivable, net |  | 216 |  |
| Inventories |  | 320 |  |
| Prepaid expenses and other assets |  | 179 |  |
| Property and equipment, net |  | 144 |  |
| Goodwill |  | 3,431 |  |
| Intangible assets |  | 2,970 |  |
| Accounts payable |  | (136) |  |
| Accrued and other current liabilities |  | (236) |  |
| Income tax liability |  | (191) |  |
| Deferred income tax liability |  | (258) |  |
| Other long-term liabilities |  | (119) |  |
|  |  | $ | 7,134 |  |

[0001045810-22-000036:notes:83]
(1)    Represents the cash consideration of $125.00 per share paid to Mellanox shareholders for approximately 56 million shares of outstanding Mellanox ordinary shares.

[0001045810-22-000036:notes:84]
(2)    Represents the cash consideration for the settlement of approximately 249 thousand Mellanox stock options held by employees and non-employee directors of Mellanox.

[0001045810-22-000036:notes:85]
(3)    Represents the fair value of Mellanox’s stock-based compensation awards attributable to pre-combination services.

[0001045810-22-000036:notes:86]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on the estimated fair values.

[0001045810-22-000036:notes:87]
The goodwill is primarily attributable to the planned growth in the combined business of NVIDIA and Mellanox. Goodwill is not amortized to earnings, but instead is reviewed for impairment at least annually, absent any interim indicators of impairment. Goodwill recognized in the acquisition is not expected to be deductible for foreign tax purposes. Goodwill arising from the Mellanox acquisition has been allocated to the Compute and Networking segment. Refer to Note 17 – Segment Information for further details on segments.

[0001045810-22-000036:notes:88]
The operating results of Mellanox have been included in our consolidated financial statements for fiscal year 2021 since the acquisition date of April 27, 2020. Revenue attributable to Mellanox was approximately 10% for fiscal year 2021. There is not a practical way to determine net income attributable to Mellanox due to integration. Acquisition-related costs attributable to Mellanox of $28 million were included in selling, general and administrative expense for fiscal year 2021.

[0001045810-22-000036:notes:89]
Intangible Assets

[0001045810-22-000036:notes:90]
The estimated fair value and useful life of the acquired intangible assets at the time of the acquisition are as follows:

[0001045810-22-000036:notes:91]
|  | Fair Value |  | Useful Lives |
|  | (In millions) |  |  |
| Developed technology (1) | $ | 1,640 |  |  | 5 years |
| Customer relationships (2) | 440 |  |  | 3 years |
| Order backlog (3) | 190 |  |  | Based on actual shipments |
| Trade names (4) | 70 |  |  | 5 years |
| Total identified finite-lived intangible assets | 2,340 |  |  |  |
| IPR&D (5) | 630 |  |  | N/A |
| Total identified intangible assets | $ | 2,970 |  |  |  |

[0001045810-22-000036:notes:92]
(1)    The fair value of developed technology was identified using the Multi-Period Excess Earnings Method.

[0001045810-22-000036:notes:93]
(2)    Customer relationships represent the fair value of the existing relationships using the With and Without Method.

[0001045810-22-000036:notes:94]
(3)    Order backlog represents primarily the fair value of purchase arrangements with customers using the Multi-Period Excess Earnings Method. The intangible asset was fully amortized as of January 31, 2021.

[0001045810-22-000036:notes:95]
(4)    Trade names primarily relate to Mellanox trade names and fair value was determined by applying the Relief-from-Royalty Method under the income approach.

[0001045810-22-000036:notes:96]
(5)    The fair value of IPR&D was determined using the Multi-Period Excess Earnings Method.

[0001045810-22-000036:notes:97]
The fair value of the finite-lived intangible assets will be amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received to cost of revenue and operating expenses.

[0001045810-22-000036:notes:98]
Mellanox has an IPR&D project associated with the next generation interconnect product that had not yet reached technological feasibility as of the acquisition date. Accordingly, we recorded an indefinite-lived intangible asset of $630 million for the fair value of this project, which was initially not amortized. Instead, the project is tested for impairment annually and whenever events or changes in circumstances indicate that the project may be impaired or may have reached technological feasibility. Once and if the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life.

[0001045810-22-000036:notes:99]
Supplemental Unaudited Pro Forma Information

[0001045810-22-000036:notes:100]
The following unaudited pro forma financial information summarizes the combined results of operations for NVIDIA and Mellanox as if the companies were combined as of the beginning of fiscal year 2020:

[0001045810-22-000036:notes:101]
|  | Pro Forma |
|  | Year Ended |
|  | January 31, 2021 |  | January 26, 2020 |  |  |
|  | (In millions) |
| Revenue | $ | 17,104 |  |  | $ | 12,250 |  |  |  |
| Net income | $ | 4,757 |  |  | $ | 2,114 |  |  |  |

[0001045810-22-000036:notes:102]
The unaudited pro forma information includes adjustments related to amortization of acquired intangible assets, adjustments to stock-based compensation expense, fair value of acquired inventory, and transaction costs. The unaudited pro forma information presented above is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2020 or of the results of our future operations of the combined businesses.

[0001045810-22-000036:notes:103]
The pro forma results reflect the inventory step-up expense of $161 million in the fiscal year 2020 and were excluded from the pro forma results for fiscal year 2021. There were no other material nonrecurring adjustments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-22-000036:notes:104]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2023 and 2035.

[0001045810-22-000036:notes:105]
Future minimum lease payments under our non-cancelable operating leases as of January 30, 2022, are as follows:

[0001045810-22-000036:notes:106]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 | $ | 176 |  |
| 2024 | 162 |  |
| 2025 | 136 |  |
| 2026 | 124 |  |
| 2027 | 114 |  |
| 2028 and thereafter | 288 |  |
| Total | 1,000 |  |
| Less imputed interest | 115 |  |
| Present value of net future minimum lease payments | 885 |  |
| Less short-term operating lease liabilities | 144 |  |
| Long-term operating lease liabilities | $ | 741 |  |

[0001045810-22-000036:notes:107]
In addition to our existing operating lease obligations, we have operating leases that are expected to commence within fiscal year 2023 with lease terms of 7 years for $169 million.

[0001045810-22-000036:notes:108]
Operating lease expense for fiscal years 2022, 2021, and 2020 was $168 million, $145 million, $114 million, respectively. Short-term and variable lease expenses for fiscal years 2022, 2021, and 2020 were not significant.

[0001045810-22-000036:notes:109]
Other information related to leases was as follows:

[0001045810-22-000036:notes:110]
|  | Year Ended |
|  | January 30, 2022 |  | January 31, 2021 |  | January 26, 2020 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 154 |  |  | $ | 141 |  |  | $ | 103 |  |
| Operating lease assets obtained in exchange for lease obligations (1) | $ | 266 |  |  | $ | 200 |  |  | $ | 238 |  |

[0001045810-22-000036:notes:111]
(1)    Fiscal year 2021 includes $80 million of operating lease assets addition due to Mellanox.

[0001045810-22-000036:notes:112]
As of January 30, 2022, our operating leases had a weighted average remaining lease term of 7.1 years and a weighted average discount rate of 2.51%. As of January 31, 2021, our operating leases had a weighted average remaining lease term of 7.6 years and a weighted average discount rate of 2.87%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-22-000036:notes:113]
Stock-Based CompensationOur stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our ESPP.
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts allocated to inventory, as follows:

[0001045810-22-000036:notes:114]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Cost of revenue | $ | 141 |  |  | $ | 88 |  |  | $ | 39 |  |
| Research and development | 1,298 |  |  | 860 |  |  | 540 |  |
| Sales, general and administrative | 565 |  |  | 449 |  |  | 265 |  |
| Total | $ | 2,004 |  |  | $ | 1,397 |  |  | $ | 844 |  |

[0001045810-22-000036:notes:115]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2022, 2021, and 2020.

[0001045810-22-000036:notes:116]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-22-000036:notes:117]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 18 |  |  | 36 |  |  | 28 |  |
| Estimated total grant-date fair value | $ | 3,492 |  |  | $ | 2,764 |  |  | $ | 1,282 |  |
| Weighted average grant-date fair value per share | $ | 190.69 |  |  | $ | 76.81 |  |  | $ | 46.12 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 5 |  |  | 4 |  |  | 4 |  |
| Weighted average price per share | $ | 56.36 |  |  | $ | 34.80 |  |  | $ | 37.19 |  |
| Weighted average grant-date fair value per share | $ | 23.24 |  |  | $ | 16.91 |  |  | $ | 16.22 |  |

[0001045810-22-000036:notes:118]
As of January 30, 2022, there was $4.87 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.4 years for RSUs, PSUs, and market-based PSUs, and 0.9 years for ESPP.

[0001045810-22-000036:notes:119]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-22-000036:notes:120]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.1-2.0 |  | 0.1-2.0 |  | 0.1-2.0 |
| Risk-free interest rate | —%-0.5% |  | 0.1%-1.6% |  | 1.5%-2.6% |
| Volatility | 20%-58% |  | 26%-89% |  | 30%-82% |
| Dividend yield | 0.1% |  | 0.1%-0.3% |  | 0.3%-0.4% |

[0001045810-22-000036:notes:121]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-22-000036:notes:122]
Additionally, for RSU, PSU, and market-based PSU awards, we estimate forfeitures semi-annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-22-000036:notes:123]
Equity Incentive Program

[0001045810-22-000036:notes:124]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans. In addition, in connection with our acquisitions of various companies, we have assumed certain stock-based awards granted under their stock incentive plans and converted them into our RSUs.

[0001045810-22-000036:notes:125]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-22-000036:notes:126]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, as most recently amended and restated, or the 2007 Plan.

[0001045810-22-000036:notes:127]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock units, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. As of January 30, 2022, up to 50 million shares of our common stock could be issued pursuant to stock awards granted under the 2007 Plan, of which 6 million shares were issuable upon the exercise of outstanding stock options. All options are fully vested, the last of which will expire by December 2023 if not exercised. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 30, 2022, there were 131 million shares available for future grants.

[0001045810-22-000036:notes:128]
Subject to certain exceptions, RSUs granted to employees either vest (A) over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25% vesting quarterly thereafter, or (B) over a three-year period, subject to continued service, with 40% vesting on a pre-determined date that is close to the anniversary of the date of grant and 7.5% vesting quarterly thereafter. PSUs vest over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25% vesting quarterly thereafter. Market-based PSUs vest 100% on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-22-000036:notes:129]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-22-000036:notes:130]
In 2012, our shareholders approved the NVIDIA Corporation 2012 Employee Stock Purchase Plan, as most recently amended and restated, or the 2012 Plan.

[0001045810-22-000036:notes:131]
Employees who participate in the 2012 Plan may have up to 15% of their earnings withheld to purchase shares of common stock. The Board may decrease this percentage at its discretion. Each offering period is approximately 24 months, which is generally divided into four purchase periods of six months. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period or the fair market value of the common stock on each purchase date within the offering. As of January 30, 2022, we had 233 million shares reserved for future issuance under the 2012 Plan.

[0001045810-22-000036:notes:132]
Equity Award Activity

[0001045810-22-000036:notes:133]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-22-000036:notes:134]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
|  | (In millions, except per share data) |
| Balances, January 31, 2021 | 59 |  |  | $ | 66.17 |  |
| Granted | 18 |  |  | $ | 190.69 |  |
| Vested restricted stock | (29) |  |  | $ | 66.67 |  |
| Canceled and forfeited | (2) |  |  | $ | 86.47 |  |
| Balances, January 30, 2022 | 46 |  |  | $ | 114.19 |  |
| Vested and expected to vest after January 30, 2022 | 46 |  |  | $ | 113.84 |  |

[0001045810-22-000036:notes:135]
As of January 30, 2022 and January 31, 2021, there were 131 million and 148 million shares, respectively, of common stock available for future grants under our equity incentive plans.

[0001045810-22-000036:notes:136]
As of January 30, 2022, the total intrinsic value of options currently exercisable and outstanding was $1.38 billion, with an average exercise price of $3.55 per share and an average remaining term of 1.1 years. The total intrinsic value of options exercised was $741 million, $521 million, and $84 million for fiscal years 2022, 2021, and 2020, respectively. Upon the exercise of an option, we issue new shares of stock.

[0001045810-22-000036:notes:137]
The total fair value of RSUs and PSUs, as of their respective vesting dates, during the years ended January 30, 2022, January 31, 2021, and January 26, 2020, was $5.56 billion, $2.67 billion, and $1.45 billion, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-22-000036:notes:138]
Net Income Per Share
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-22-000036:notes:139]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 9,752 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 2,496 |  |  | 2,467 |  |  | 2,439 |  |
| Dilutive impact of outstanding equity awards | 39 |  |  | 43 |  |  | 33 |  |
| Diluted weighted average shares | 2,535 |  |  | 2,510 |  |  | 2,472 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 3.91 |  |  | $ | 1.76 |  |  | $ | 1.15 |  |
| Diluted (2) | $ | 3.85 |  |  | $ | 1.73 |  |  | $ | 1.13 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 21 |  |  | 12 |  |  | 44 |  |

[0001045810-22-000036:notes:140]
(1)    Calculated as net income divided by basic weighted average shares.

[0001045810-22-000036:notes:141]
(2)    Calculated as net income divided by diluted weighted average shares.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-22-000036:notes:142]
GoodwillAs of January 30, 2022, the total carrying amount of goodwill was $4.35 billion, consisting of goodwill balances allocated to our Graphics and Compute & Networking reporting units of $361 million and $3.99 billion, respectively. As of January 31, 2021, the total carrying amount of goodwill was $4.19 billion, consisting of goodwill balances allocated to our Graphics and Compute & Networking reporting units of $347 million and $3.85 billion, respectively. Goodwill increased by $156 million in fiscal year 2022 from acquisitions. We assigned $143 million of the increase in goodwill to our Compute & Networking segment and assigned $13 million of the increase to our Graphics segment. During the fourth quarters of fiscal years 2022, 2021, and 2020, we completed our annual impairment tests and concluded that goodwill was not impaired in any of these years.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-22-000036:notes:143]
Amortizable Intangible Assets
The components of our amortizable intangible assets are as follows:

[0001045810-22-000036:notes:144]
|  | January 30, 2022 |  | January 31, 2021 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,418 |  |  | $ | (1,304) |  |  | $ | 2,114 |  |  | $ | 3,280 |  |  | $ | (774) |  |  | $ | 2,506 |  |
| Patents and licensed technology | 717 |  |  | (492) |  |  | 225 |  |  | 706 |  |  | (475) |  |  | 231 |  |
| Total intangible assets | $ | 4,135 |  |  | $ | (1,796) |  |  | $ | 2,339 |  |  | $ | 3,986 |  |  | $ | (1,249) |  |  | $ | 2,737 |  |

[0001045810-22-000036:notes:145]
(1)    As of January 30, 2022, acquisition-related intangible assets include the fair value of a Mellanox in-process research and development project of $630 million, which has not yet commenced amortization.

[0001045810-22-000036:notes:146]
Amortization expense associated with intangible assets for fiscal years 2022, 2021, and 2020 was $563 million, $612 million, and $25 million, respectively. Future amortization expense related to the net carrying amount of intangible assets, excluding in-process research and development, as of January 30, 2022 is estimated to be $585 million in fiscal year 2023, $461 million in fiscal year 2024, $405 million in fiscal year 2025, $121 million in fiscal year 2026, $16 million in fiscal year 2027, and $121 million in fiscal year 2028 and thereafter.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-22-000036:notes:147]
Cash Equivalents and Marketable SecuritiesOur cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities. 
The following is a summary of cash equivalents and marketable securities as of January 30, 2022 and January 31, 2021:

[0001045810-22-000036:notes:148]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

[0001045810-22-000036:notes:149]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

[0001045810-22-000036:notes:150]
The following table provides the breakdown of unrealized losses as of January 30, 2022, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-22-000036:notes:151]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Corporate debt securities | $ | 2,445 |  |  | $ | (3) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,464 |  |  | $ | (3) |  |
| Debt securities issued by the United States Treasury | 5,292 |  |  | (14) |  |  | — |  |  | — |  |  | 5,292 |  |  | (14) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

[0001045810-22-000036:notes:152]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-22-000036:notes:153]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of January 30, 2022 and January 31, 2021 are shown below by contractual maturity.

[0001045810-22-000036:notes:154]
|  | January 30, 2022 |  | January 31, 2021 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 16,346 |  |  | $ | 16,343 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 4,584 |  |  | 4,570 |  |  | 566 |  |  | 568 |  |
| Total | $ | 20,930 |  |  | $ | 20,913 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-22-000036:notes:155]
The following is a summary of cash equivalents and marketable securities as of January 30, 2022 and January 31, 2021:


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-22-000036:notes:156]
Fair Value of Financial Assets and LiabilitiesThe fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-22-000036:notes:157]
|  |  | Fair Value at |
|  | Pricing Category |  | January 30, 2022 |  | January 31, 2021 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 316 |  |  | $ | 313 |  |
| Corporate debt securities | Level 2 |  | $ | 9,974 |  |  | $ | 4,444 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 7,300 |  |  | $ | 2,846 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 1,612 |  |  | $ | 2,976 |  |
| Certificates of deposit | Level 2 |  | $ | 1,561 |  |  | $ | 705 |  |
| Foreign government bonds | Level 2 |  | $ | 150 |  |  | $ | 67 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities (1) | Level 1 |  | $ | 58 |  |  | $ | — |  |
| Privately-held equity securities | Level 3 |  | $ | 208 |  |  | $ | 144 |  |
| Liabilities (2) |  |  |  |  |  |
| 2.20% Notes Due 2021 | Level 2 |  | $ | — |  |  | $ | 1,011 |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,236 |  |  | $ | — |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,224 |  |  | $ | — |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 1,055 |  |  | $ | 1,124 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,200 |  |  | $ | — |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,542 |  |  | $ | 1,654 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,200 |  |  | $ | — |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 1,066 |  |  | $ | 1,152 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 2,147 |  |  | $ | 2,308 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 551 |  |  | $ | 602 |  |

[0001045810-22-000036:notes:158]
(1)    Unrealized gains of $48 million from an investment in a publicly-traded equity security were recorded in other income (expense), net, in fiscal year 2022.

[0001045810-22-000036:notes:159]
(2)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-22-000036:notes:160]
Balance Sheet Components
Certain balance sheet components are as follows:

[0001045810-22-000036:notes:161]
|  | January 30,2022 |  | January 31,2021 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 791 |  |  | $ | 632 |  |
| Work in-process | 692 |  |  | 457 |  |
| Finished goods | 1,122 |  |  | 737 |  |
| Total inventories | $ | 2,605 |  |  | $ | 1,826 |  |

[0001045810-22-000036:notes:162]
|  | January 30,2022 |  | January 31,2021 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Buildings, leasehold improvements, and furniture | 874 |  |  | 796 |  |  | (B) |
| Equipment, compute hardware, and software | 2,852 |  |  | 1,985 |  |  | 3-5 |
| Construction in process | 737 |  |  | 558 |  |  | (C) |
| Total property and equipment, gross | 4,681 |  |  | 3,557 |  |  |  |
| Accumulated depreciation and amortization | (1,903) |  |  | (1,408) |  |  |  |
| Total property and equipment, net | $ | 2,778 |  |  | $ | 2,149 |  |  |  |

[0001045810-22-000036:notes:163]
(A)Land is a non-depreciable asset.

[0001045810-22-000036:notes:164]
(B)The estimated useful lives of our buildings are up to thirty years. Leasehold improvements and finance leases are amortized based on the lesser of either the asset’s estimated useful life or the expected lease term.

[0001045810-22-000036:notes:165]
(C)Construction in process represents assets that are not available for their intended use as of the balance sheet date.

[0001045810-22-000036:notes:166]
Depreciation expense for fiscal years 2022, 2021, and 2020 was $611 million, $486 million, and $355 million, respectively.

[0001045810-22-000036:notes:167]
Accumulated amortization of leasehold improvements and finance leases was $265 million and $223 million as of January 30, 2022 and January 31, 2021, respectively.

[0001045810-22-000036:notes:168]
Property, equipment and intangible assets acquired by assuming related liabilities during fiscal years 2022, 2021, and 2020 were $258 million, $157 million, and $212 million, respectively.

[0001045810-22-000036:notes:169]
|  | January 30,2022 |  | January 31,2021 |
| Other assets: | (In millions) |
| Prepaid supply agreements | $ | 1,747 |  |  | $ | — |  |
| Advanced consideration for acquisition (1) | 1,357 |  |  | 1,357 |  |
| Prepaid royalties | 409 |  |  | 440 |  |
| Investment in non-affiliated entities | 266 |  |  | 144 |  |
| Other | 62 |  |  | 203 |  |
| Total other assets | $ | 3,841 |  |  | $ | 2,144 |  |

[0001045810-22-000036:notes:170]
(1)Refer to Note 2 - Business Combination for further details on the Arm acquisition.

[0001045810-22-000036:notes:171]
|  | January 30,2022 |  | January 31,2021 |
|  | (In millions) |
| Accrued and Other Current Liabilities: |  |  |  |
| Customer program accruals | $ | 1,000 |  |  | $ | 630 |  |
| Accrued payroll and related expenses | 409 |  |  | 297 |  |
| Deferred revenue (1) | 300 |  |  | 288 |  |
| Excess inventory purchase obligations | 196 |  |  | 52 |  |
| Other | 647 |  |  | 510 |  |
| Total accrued and other current liabilities | $ | 2,552 |  |  | $ | 1,777 |  |

[0001045810-22-000036:notes:172]
(1)Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements, support for hardware and software, and cloud services.

[0001045810-22-000036:notes:173]
|  | January 30,2022 |  | January 31,2021 |
|  | (In millions) |
| Other Long-Term Liabilities: |  |  |  |
| Income tax payable (1) | $ | 980 |  |  | $ | 836 |  |
| Deferred income tax | 245 |  |  | 241 |  |
| Deferred revenue (2) | 202 |  |  | 163 |  |
| Other | 126 |  |  | 135 |  |
| Total other long-term liabilities | $ | 1,553 |  |  | $ | 1,375 |  |

[0001045810-22-000036:notes:174]
(1)As of January 30, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, long-term portion of the unrecognized tax benefits of $670 million, and related interest and penalties of $59 million.

[0001045810-22-000036:notes:175]
(2)Deferred revenue primarily includes deferrals related to support for hardware and software.

[0001045810-22-000036:notes:176]
Deferred Revenue

[0001045810-22-000036:notes:177]
The following table shows the changes in deferred revenue during fiscal years 2022 and 2021.

[0001045810-22-000036:notes:178]
|  | January 30,2022 |  | January 31,2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 451 |  |  | $ | 201 |  |
| Deferred revenue added during the period | 821 |  |  | 536 |  |
| Addition due to business combinations | 8 |  |  | 75 |  |
| Revenue recognized during the period | (778) |  |  | (361) |  |
| Balance at end of period | $ | 502 |  |  | $ | 451 |  |

[0001045810-22-000036:notes:179]
Revenue related to remaining performance obligations represents the contracted license and development arrangements and support for hardware and software. This includes deferred revenue currently recorded and amounts that will be invoiced in future periods. As of January 30, 2022, $624 million of revenue related to performance obligations had not been recognized, of which we expect to recognize approximately 49% over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-22-000036:notes:180]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of January 30, 2022 and January 31, 2021.

[0001045810-22-000036:notes:181]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-22-000036:notes:182]
The table below presents the notional value of our foreign currency forward contracts outstanding as of January 30, 2022 and January 31, 2021:

[0001045810-22-000036:notes:183]
|  | January 30,2022 |  | January 31,2021 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,023 |  |  | $ | 840 |  |
| Non-designated hedges | $ | 408 |  |  | $ | 441 |  |

[0001045810-22-000036:notes:184]
As of January 30, 2022, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.
During fiscal years 2022 and 2021, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-22-000036:notes:185]
Debt
Long-Term Debt

[0001045810-22-000036:notes:186]
In June 2021, March 2020, and September 2016, we issued a total of $5.00 billion, $5.00 billion, and $2.00 billion aggregate principal of senior notes, respectively. The net proceeds from these offerings were $4.98 billion, $4.97 billion, and $1.98 billion, respectively, after deducting debt discount and issuance costs.

[0001045810-22-000036:notes:187]
On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021.

[0001045810-22-000036:notes:188]
All of our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-22-000036:notes:189]
The carrying value of the Notes, the calendar year of maturity, and the associated interest rates were as follows:

[0001045810-22-000036:notes:190]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | January 30,2022 |  | January 31,2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | — |  | 2.38% |  | $ | — |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.4 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.4 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 4.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.4 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.2 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.4 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.2 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.2 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.2 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (54) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 10,946 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,946 |  |  | $ | 5,964 |  |

[0001045810-22-000036:notes:191]
As of January 30, 2022, we were in compliance with the required covenants under the Notes.

[0001045810-22-000036:notes:192]
Commercial Paper

[0001045810-22-000036:notes:193]
We have a $575 million commercial paper program to support general corporate purposes. As of January 30, 2022, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-22-000036:notes:194]
Commitments and Contingencies
Purchase Obligations

[0001045810-22-000036:notes:195]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-22-000036:notes:196]
We have entered into several long-term supply agreements, under which we have made advance payments and have $1.58 billion remaining unpaid. As of January 30, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.00 billion, inclusive of the $1.58 billion, and other purchase obligations totaling $1.30 billion.

[0001045810-22-000036:notes:197]
Total future unconditional purchase commitments as of January 30, 2022, are as follows:

[0001045810-22-000036:notes:198]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 | $ | 9,302 |  |
| 2024 | 765 |  |
| 2025 | 201 |  |
| 2026 | 28 |  |
| Total | $ | 10,296 |  |

[0001045810-22-000036:notes:199]
In March 2022, we entered into a supply agreement with payments of $670 million to be paid over nine years.

[0001045810-22-000036:notes:200]
Accrual for Product Warranty Liabilities

[0001045810-22-000036:notes:201]
The estimated amount of product warranty liabilities was $46 million and $22 million as of January 30, 2022 and January 31, 2021, respectively.

[0001045810-22-000036:notes:202]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included IP indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability for such indemnifications.

[0001045810-22-000036:notes:203]
Litigation

[0001045810-22-000036:notes:204]
Securities Class Action and Derivative Lawsuits

[0001045810-22-000036:notes:205]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument is scheduled for May 10, 2022.

[0001045810-22-000036:notes:206]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-22-000036:notes:207]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-22-000036:notes:208]
Accounting for Loss Contingencies

[0001045810-22-000036:notes:209]
As of January 30, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-22-000036:notes:210]
Income Taxes
The income tax expense (benefit) applicable to income before income taxes consists of the following:

[0001045810-22-000036:notes:211]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 482 |  |  | $ | 197 |  |  | $ | 65 |  |
| State | 42 |  |  | 1 |  |  | 4 |  |
| Foreign | 71 |  |  | 161 |  |  | 87 |  |
| Total current | 595 |  |  | 359 |  |  | 156 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | (420) |  |  | (246) |  |  | 2 |  |
| Foreign | 14 |  |  | (36) |  |  | 16 |  |
| Total deferred | (406) |  |  | (282) |  |  | 18 |  |
| Income tax expense | $ | 189 |  |  | $ | 77 |  |  | $ | 174 |  |

[0001045810-22-000036:notes:212]
Income before income tax consists of the following:

[0001045810-22-000036:notes:213]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Domestic (1) | $ | 8,446 |  |  | $ | 1,437 |  |  | $ | 620 |  |
| Foreign | 1,495 |  |  | 2,972 |  |  | 2,350 |  |
| Income before income tax | $ | 9,941 |  |  | $ | 4,409 |  |  | $ | 2,970 |  |

[0001045810-22-000036:notes:214]
(1)Fiscal year 2022 domestic income before income tax increased as compared to fiscal years 2021 and 2020 due to the Domestication in the second quarter of fiscal year 2022.

[0001045810-22-000036:notes:215]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21% to income before income taxes as follows:

[0001045810-22-000036:notes:216]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 2,088 |  |  | $ | 926 |  |  | $ | 624 |  |
| Expense (benefit) resulting from: |  |  |  |  |  |
| State income taxes, net of federal tax effect | 42 |  |  | 10 |  |  | 12 |  |
| Foreign-derived intangible income | (520) |  |  | — |  |  | — |  |
| Foreign tax rate differential | (497) |  |  | (561) |  |  | (301) |  |
| Stock-based compensation | (337) |  |  | (136) |  |  | (60) |  |
| U.S. federal R&D tax credit | (289) |  |  | (173) |  |  | (110) |  |
| IP domestication | (244) |  |  | — |  |  | — |  |
| Other | (54) |  |  | 11 |  |  | 9 |  |
| Income tax expense | $ | 189 |  |  | $ | 77 |  |  | $ | 174 |  |

[0001045810-22-000036:notes:217]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-22-000036:notes:218]
|  | January 30,2022 |  | January 31,2021 |
|  | (In millions) |
| Deferred tax assets: |  |
| Research and other tax credit carryforwards | $ | 798 |  |  | $ | 650 |  |
| Property, equipment and intangible assets | 530 |  |  | 32 |  |
| GILTI deferred tax assets | 378 |  |  | 709 |  |
| Accruals and reserves, not currently deductible for tax purposes | 258 |  |  | 59 |  |
| Operating lease liabilities | 125 |  |  | 120 |  |
| Net operating loss carryforwards | 118 |  |  | 100 |  |
| Stock-based compensation | 86 |  |  | 36 |  |
| Other deferred tax assets | 22 |  |  | — |  |
| Gross deferred tax assets | 2,315 |  |  | 1,706 |  |
| Less valuation allowance | (907) |  |  | (728) |  |
| Total deferred tax assets | 1,408 |  |  | 978 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (169) |  |  | (191) |  |
| Unremitted earnings of foreign subsidiaries | (150) |  |  | (111) |  |
| Operating lease assets | (113) |  |  | (111) |  |
| Gross deferred tax liabilities | (432) |  |  | (413) |  |
| Net deferred tax asset (1) | $ | 976 |  |  | $ | 565 |  |

[0001045810-22-000036:notes:219]
(1)  Net deferred tax asset includes long-term deferred tax assets of $1.22 billion and $806 million and long-term deferred tax liabilities of $245 million and $241 million for fiscal years 2022 and 2021, respectively. Long-term deferred tax liabilities are included in other long-term liabilities on our Consolidated Balance Sheets.

[0001045810-22-000036:notes:220]
We recognized income tax expense of $189 million, $77 million, and $174 million for fiscal years 2022, 2021, and 2020 respectively. Our annual effective tax rate was 1.9%, 1.7%, and 5.9% for fiscal years 2022, 2021, and 2020, respectively. The increase in our effective tax rate in fiscal year 2022 as compared to fiscal year 2021 was primarily due to an

[0001045810-22-000036:notes:221]
increase in the amount of earnings subject to U.S. tax, and a decreased impact of tax benefits from the U.S. federal research tax credit, partially offset by the benefit of the foreign-derived intangible income deduction and the discrete benefit of the Domestication. The decrease in our effective tax rate in fiscal year 2021 as compared to fiscal year 2020 was primarily due to a decrease in the proportional amount of earnings subject to United States tax and an increase of tax benefits from stock-based compensation.

[0001045810-22-000036:notes:222]
On June 28, 2021, we simplified our corporate structure by repatriating the economic rights of certain non-U.S. IP to the United States via domestication of a foreign subsidiary, or the Domestication. The Domestication more closely aligns our corporate structure to our operating structure in accordance with the Organization for Economic Cooperation and Development’s Base Erosion and Profit Shifting conclusions and changes to U.S. and European tax laws. The impact of the Domestication, which is regarded as a change in tax status, resulted in a discrete benefit primarily from re-valuing certain deferred tax assets, net of deferred tax liabilities, of $244 million in fiscal year 2022.

[0001045810-22-000036:notes:223]
Our effective tax rate for fiscal year 2022 was lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, income earned in jurisdictions, including the British Virgin Islands and Israel, that are subject to taxes lower than the U.S. federal statutory tax rate, excess tax benefits related to stock-based compensation, recognition of U.S. federal research tax credits and the one-time benefits of the Domestication.

[0001045810-22-000036:notes:224]
Our effective tax rates for fiscal years 2021 and 2020 were lower than the U.S. federal statutory rate of 21% due primarily to income earned in jurisdictions, including the British Virgin Islands, Israel and Hong Kong, where the tax rate was lower than the U.S. federal statutory tax rate, recognition of U.S. federal research tax credits, and excess tax benefits related to stock-based compensation.

[0001045810-22-000036:notes:225]
During the second quarter of fiscal year 2021, we completed the acquisition of Mellanox. As a result of the acquisition, we recorded $256 million of net deferred tax liabilities primarily on the excess of book basis over the tax basis of the acquired intangible assets and undistributed earnings in certain foreign subsidiaries. We also recorded $153 million of long-term tax liabilities related to tax basis differences in Mellanox.

[0001045810-22-000036:notes:226]
As of January 30, 2022, we intend to indefinitely reinvest approximately $1.05 billion and $232 million of cumulative undistributed earnings held by certain subsidiaries in Israel and the United Kingdom, respectively. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to these investments as the determination of such amount is not practicable.

[0001045810-22-000036:notes:227]
As of January 30, 2022 and January 31, 2021, we had a valuation allowance of $907 million and $728 million, respectively, related to state and certain other deferred tax assets that management determined not likely to be realized due, in part, to jurisdictional projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-22-000036:notes:228]
As of January 30, 2022, we had federal, state and foreign net operating loss carryforwards of $397 million, $345 million and $341 million, respectively. The federal and state carryforwards will begin to expire in fiscal year 2023. The foreign net operating loss carryforwards of $341 million may be carried forward indefinitely. As of January 30, 2022, we had federal research tax credit carryforwards of $102 million that will begin to expire in fiscal year 2042. We have state research tax credit carryforwards of $1.24 billion, of which $1.18 billion is attributable to the State of California and may be carried over indefinitely, and $55 million is attributable to various other states and will begin to expire in fiscal year 2023. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, state, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-22-000036:notes:229]
As of January 30, 2022, we had $1.01 billion of gross unrecognized tax benefits, of which $808 million would affect our effective tax rate if recognized. However, $181 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $808 million of net unrecognized tax benefits as of January 30, 2022 consisted of $670 million recorded in non-current income taxes payable and $138 million reflected as a net reduction to the deferred tax assets.

[0001045810-22-000036:notes:230]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-22-000036:notes:231]
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Balance at beginning of period | $ | 776 |  |  | $ | 583 |  |  | $ | 477 |  |
| Increases in tax positions for current year | 246 |  |  | 158 |  |  | 104 |  |
| Increases in tax positions for prior years (1) | 14 |  |  | 60 |  |  | 7 |  |
| Decreases in tax positions for prior years | (4) |  |  | (11) |  |  | — |  |
| Settlements | (8) |  |  | (5) |  |  | — |  |
| Lapse in statute of limitations | (11) |  |  | (9) |  |  | (5) |  |
| Balance at end of period | $ | 1,013 |  |  | $ | 776 |  |  | $ | 583 |  |

[0001045810-22-000036:notes:232]
(1)  The fiscal year 2021 balance represents prior year gross unrecognized tax benefits recorded as a result of the Mellanox acquisition.

[0001045810-22-000036:notes:233]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable, if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-22-000036:notes:234]
We include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 30, 2022, January 31, 2021, and January 26, 2020, we had accrued $59 million, $44 million, and $31 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 30, 2022, unrecognized tax benefits of $670 million and the related interest and penalties of $59 million are included in non-current income taxes payable.

[0001045810-22-000036:notes:235]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 30, 2022, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-22-000036:notes:236]
We are subject to taxation by taxing authorities both in the United States and other countries. As of January 30, 2022, the significant tax jurisdictions that may be subject to examination include China, Germany, Hong Kong, India, Israel, Taiwan, United Kingdom, and the United States for fiscal years 2005 through 2021. As of January 30, 2022, the significant tax jurisdictions for which we are currently under examination include Germany, India, Israel, and the United States for fiscal years 2005 through 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-22-000036:notes:237]
Shareholders’ Equity
Capital Return Program

[0001045810-22-000036:notes:238]
Beginning August 2004, our Board of Directors authorized us to repurchase our stock.

[0001045810-22-000036:notes:239]
Through January 30, 2022, we have repurchased an aggregate of 1.04 billion shares under our share repurchase program for a total cost of $7.08 billion. As of January 30, 2022, we have a remaining authorization, subject to certain specifications, to repurchase shares of our common stock up to $7.24 billion through December 2022. From January 31, 2022 through March 17, 2022, we repurchased 7.7 million shares of our common stock for $1.75 billion.

[0001045810-22-000036:notes:240]
During fiscal years 2022, 2021, and 2020, we paid $399 million, $395 million, and $390 million in cash dividends to our shareholders, respectively.

[0001045810-22-000036:notes:241]
During the fourth quarter of fiscal year 2022, our Board of Directors approved the retirement of our existing 349 million treasury shares. These shares assumed the status of authorized and unissued shares upon retirement. The excess of repurchase price over par value was allocated between additional paid-in capital and retained earnings, resulting in a reduction in additional paid-in capital by $20 million and retained earnings by $12.0 billion. Any future repurchased shares will assume the status of authorized and unissued shares.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-22-000036:notes:242]
Employee Retirement PlansWe provide tax-qualified defined contribution plans to eligible employees in the U.S. and certain other countries. Our contribution expense for fiscal years 2022, 2021, and 2020 was $168 million, $120 million, and $76 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-22-000036:notes:243]
Segment Information 
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance.

[0001045810-22-000036:notes:244]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; vGPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse software for building 3D designs and virtual worlds.

[0001045810-22-000036:notes:245]
Our Compute & Networking segment includes Data Center platforms and systems for AI, HPC, and accelerated computing; Mellanox networking and interconnect solutions; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; CMP; Jetson for robotics and other embedded platforms; and NVIDIA AI Enterprise and other software.

[0001045810-22-000036:notes:246]
Operating results by segment include costs or expenses that are directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

[0001045810-22-000036:notes:247]
The “All Other” category includes the expenses that our CODM does not assign to either Graphics or Compute & Networking for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, IP-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-22-000036:notes:248]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-22-000036:notes:249]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 30, 2022: |  |  |  |  |  |  |  |
| Revenue | $ | 15,868 |  |  | $ | 11,046 |  |  | $ | — |  |  | $ | 26,914 |  |
| Operating income (loss) | $ | 8,492 |  |  | $ | 4,598 |  |  | $ | (3,049) |  |  | $ | 10,041 |  |
| Year Ended January 31, 2021: |  |  |  |  |  |  |  |
| Revenue | $ | 9,834 |  |  | $ | 6,841 |  |  | $ | — |  |  | $ | 16,675 |  |
| Operating income (loss) | $ | 4,612 |  |  | $ | 2,548 |  |  | $ | (2,628) |  |  | $ | 4,532 |  |
| Year Ended January 26, 2020: |  |  |  |  |  |  |  |
| Revenue | $ | 7,639 |  |  | $ | 3,279 |  |  | $ | — |  |  | $ | 10,918 |  |
| Operating income (loss) | $ | 3,267 |  |  | $ | 751 |  |  | $ | (1,172) |  |  | $ | 2,846 |  |

[0001045810-22-000036:notes:250]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |
| Stock-based compensation expense | $ | (2,004) |  |  | $ | (1,397) |  |  | $ | (844) |  |
| Acquisition-related intangible asset amortization, inventory step-up charge, and other costs | (636) |  |  | (836) |  |  | (31) |  |
| Unallocated cost of revenue and operating expenses | (399) |  |  | (357) |  |  | (283) |  |
| IP-related costs | (10) |  |  | (38) |  |  | (14) |  |
| Total | $ | (3,049) |  |  | $ | (2,628) |  |  | $ | (1,172) |  |

[0001045810-22-000036:notes:251]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-22-000036:notes:252]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
| Revenue: | (In millions) |
| Taiwan | $ | 8,544 |  |  | $ | 4,531 |  |  | $ | 3,025 |  |
| China (including Hong Kong) | 7,111 |  |  | 3,886 |  |  | 2,731 |  |
| United States | 4,349 |  |  | 3,214 |  |  | 886 |  |
| Other countries | 6,910 |  |  | 5,044 |  |  | 4,276 |  |
| Total revenue | $ | 26,914 |  |  | $ | 16,675 |  |  | $ | 10,918 |  |

[0001045810-22-000036:notes:253]
No customer represented 10% or more of total revenue for fiscal years 2022 and 2021. One customer represented 11% of our total revenue for fiscal year 2020 and was attributable primarily to the Graphics segment.

[0001045810-22-000036:notes:254]
Two customers represented 22% of our accounts receivable balance as of January 30, 2022. One customer represented 16% of our accounts receivable balance as of January 31, 2021.

[0001045810-22-000036:notes:255]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-22-000036:notes:256]
|  | Year Ended |
|  | January 30,2022 |  | January 31,2021 |  | January 26,2020 |
| Revenue: | (In millions) |
| Gaming | $ | 12,462 |  |  | $ | 7,759 |  |  | $ | 5,518 |  |
| Data Center | 10,613 |  |  | 6,696 |  |  | 2,983 |  |
| Professional Visualization | 2,111 |  |  | 1,053 |  |  | 1,212 |  |
| Automotive | 566 |  |  | 536 |  |  | 700 |  |
| OEM & Other | 1,162 |  |  | 631 |  |  | 505 |  |
| Total revenue | $ | 26,914 |  |  | $ | 16,675 |  |  | $ | 10,918 |  |

[0001045810-22-000036:notes:257]
The following table presents summarized information for long-lived assets by country. Long-lived assets consist of property and equipment and exclude other assets, operating lease assets, goodwill, and intangible assets.

[0001045810-22-000036:notes:258]
|  | January 30,2022 |  | January 31,2021 |
| Long-lived assets: | (In millions) |
| United States | $ | 2,023 |  |  | $ | 1,643 |  |
| Taiwan | 379 |  |  | 183 |  |
| Israel | 185 |  |  | 147 |  |
| Other countries | 191 |  |  | 176 |  |
| Total long-lived assets | $ | 2,778 |  |  | $ | 2,149 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-22-000036:notes:259]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-22-000036:notes:260]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2022 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 17 |  |  | $ | 19 |  | (2) | $ | (23) |  | (4) | $ | 13 |  |
| Deferred tax valuation allowance |  | $ | 728 |  |  | $ | 179 |  | (3) | $ | — |  |  | $ | 907 |  |
| Fiscal year 2021 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | 2 |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 30 |  | (2) | $ | (22) |  | (4) | $ | 17 |  |
| Deferred tax valuation allowance |  | $ | 621 |  |  | $ | 107 |  | (3) | $ | — |  |  | $ | 728 |  |
| Fiscal year 2020 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 8 |  |  | $ | 18 |  | (2) | $ | (17) |  | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 562 |  |  | $ | 59 |  | (3) | $ | — |  |  | $ | 621 |  |

[0001045810-22-000036:notes:261]
(1)Additions represent either expense or acquired balances and deductions represent write-offs.

[0001045810-22-000036:notes:262]
(2)Additions represent estimated product returns charged as a reduction to revenue or an acquired balance.

[0001045810-22-000036:notes:263]
(3)Additional valuation allowance on deferred tax assets not likely to be realized. Refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-22-000036:notes:264]
(4)Represents sales returns.
