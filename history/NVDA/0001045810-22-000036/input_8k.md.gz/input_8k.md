# NVDA 8-K — 0001045810-22-000008 filed 2022-02-16

## item codes, every 8-K on or before 2022-03-18

- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2022-03-18

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-22-000008:8k_2_02:1]
EX-99.1
2
q4fy22pr.htm
Q4FY22 PRESS RELEASE

[0001045810-22-000008:8k_2_02:2]
Document

[0001045810-22-000008:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-22-000008:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2022

[0001045810-22-000008:8k_2_02:5]
•Record quarterly revenue of $7.64 billion, up 53 percent from a year earlier

[0001045810-22-000008:8k_2_02:6]
•Record fiscal-year revenue of $26.91 billion, up 61 percent

[0001045810-22-000008:8k_2_02:7]
•Record quarterly and fiscal-year revenue for Gaming, Data Center and Professional Visualization

[0001045810-22-000008:8k_2_02:8]
SANTA CLARA, Calif.-Feb. 16, 2022- NVIDIA (NASDAQ: NVDA) today reported record revenue for the fourth quarter ended January 30, 2022, of $7.64 billion, up 53 percent from a year ago and up 8 percent from the previous quarter. Gaming, Data Center and Professional Visualization market platforms each achieved record revenue for the quarter and year.

[0001045810-22-000008:8k_2_02:9]
GAAP earnings per diluted share for the quarter were a record $1.18, up 103 percent from a year ago and up 22 percent from the previous quarter. Non-GAAP earnings per diluted share were $1.32, up 69 percent from a year ago and up 13 percent from the previous quarter.

[0001045810-22-000008:8k_2_02:10]
For fiscal 2022, revenue was a record $26.91 billion, up 61 percent from $16.68 billion a year ago. GAAP earnings per diluted share were a record $3.85, up 123 percent from $1.73 a year ago. Non-GAAP earnings per diluted share were $4.44, up 78 percent from $2.50 a year ago.

[0001045810-22-000008:8k_2_02:11]
“We are seeing exceptional demand for NVIDIA computing platforms,” said Jensen Huang, founder and CEO of NVIDIA. “NVIDIA is propelling advances in AI, digital biology, climate sciences, gaming, creative design, autonomous vehicles and robotics – some of today's most impactful fields.

[0001045810-22-000008:8k_2_02:12]
“We are entering the new year with strong momentum across our businesses and excellent traction with our new software business models with NVIDIA AI, NVIDIA Omniverse and NVIDIA DRIVE. GTC is coming. We will announce many new products, applications and partners for NVIDIA computing,” he said.

[0001045810-22-000008:8k_2_02:13]
NVIDIA paid quarterly cash dividends of $100 million in the fourth quarter and $399 million in fiscal 2022. It will pay its next quarterly cash dividend of $0.04 per share on March 24, 2022, to all shareholders of record on March 3, 2022.

[0001045810-22-000008:8k_2_02:14]
Q4 Fiscal 2022 Summary

[0001045810-22-000008:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q4 FY22 | Q3 FY22 | Q4 FY21 | Q/Q | Y/Y |
| Revenue | $7,643 | $7,103 | $5,003 | Up 8% | Up 53% |
| Gross margin | 65.4 | % | 65.2 | % | 63.1 | % | Up 20 bps | Up 230 bps |
| Operating expenses | $2,029 | $1,960 | $1,650 | Up 4% | Up 23% |
| Operating income | $2,970 | $2,671 | $1,507 | Up 11% | Up 97% |
| Net income | $3,003 | $2,464 | $1,457 | Up 22% | Up 106% |
| Diluted earnings per share* | $1.18 | $0.97 | $0.58 | Up 22% | Up 103% |

[0001045810-22-000008:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q4 FY22 | Q3 FY22 | Q4 FY21 | Q/Q | Y/Y |
| Revenue | $7,643 | $7,103 | $5,003 | Up 8% | Up 53% |
| Gross margin | 67.0 | % | 67.0 | % | 65.5 | % | -- | Up 150 bps |
| Operating expenses | $1,447 | $1,375 | $1,187 | Up 5% | Up 22% |
| Operating income | $3,677 | $3,386 | $2,089 | Up 9% | Up 76% |
| Net income | $3,350 | $2,973 | $1,957 | Up 13% | Up 71% |
| Diluted earnings per share* | $1.32 | $1.17 | $0.78 | Up 13% | Up 69% |

[0001045810-22-000008:8k_2_02:17]
*All per share amounts presented herein have been adjusted to reflect the four-for-one stock split, which was effective July 2021.

[0001045810-22-000008:8k_2_02:18]
Fiscal 2022 Summary

[0001045810-22-000008:8k_2_02:19]
| GAAP |
| ($ in millions, except earnings per share) | FY22 | FY21 | Y/Y |
| Revenue | $26,914 | $16,675 | Up 61% |
| Gross margin | 64.9 | % | 62.3 | % | Up 260 bps |
| Operating expenses | $7,434 | $5,864 | Up 27% |
| Operating income | $10,041 | $4,532 | Up 122% |
| Net income | $9,752 | $4,332 | Up 125% |
| Diluted earnings per share* | $3.85 | $1.73 | Up 123% |

[0001045810-22-000008:8k_2_02:20]
| Non-GAAP |
| ($ in millions, except earnings per share) | FY22 | FY21 | Y/Y |
| Revenue | $26,914 | $16,675 | Up 61% |
| Gross margin | 66.8 | % | 65.6 | % | Up 120 bps |
| Operating expenses | $5,279 | $4,144 | Up 27% |
| Operating income | $12,690 | $6,803 | Up 87% |
| Net income | $11,259 | $6,277 | Up 79% |
| Diluted earnings per share* | $4.44 | $2.50 | Up 78% |

[0001045810-22-000008:8k_2_02:21]
*All per share amounts presented herein have been adjusted to reflect the four-for-one stock split, which was effective July 2021.

[0001045810-22-000008:8k_2_02:22]
Termination of the Arm Share Purchase Agreement

[0001045810-22-000008:8k_2_02:23]
On February 8, 2022, NVIDIA and SoftBank Group Corp. (SoftBank) announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the consummation of the transaction. NVIDIA intends to record in operating expenses a $1.36 billion charge (the Arm Write-off) in the first quarter of fiscal 2023 reflecting the write-off of the prepayment provided at signing in September 2020.

[0001045810-22-000008:8k_2_02:24]
Outlook

[0001045810-22-000008:8k_2_02:25]
NVIDIA’s outlook for the first quarter of fiscal 2023 is as follows:

[0001045810-22-000008:8k_2_02:26]
•Revenue is expected to be $8.10 billion, plus or minus 2 percent.

[0001045810-22-000008:8k_2_02:27]
•GAAP and non-GAAP gross margins are expected to be 65.2 percent and 67.0 percent, respectively, plus or minus 50 basis points.

[0001045810-22-000008:8k_2_02:28]
•GAAP operating expenses are expected to be $3.55 billion, including the Arm Write-off of $1.36 billion. Non-GAAP operating expenses are expected to be $1.60 billion.

[0001045810-22-000008:8k_2_02:29]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $55 million, excluding gains and losses from non-affiliated investments.

[0001045810-22-000008:8k_2_02:30]
•GAAP and non-GAAP tax rates are expected to be 11 percent and 13 percent, respectively, plus or minus 1 percent, excluding any discrete items.

[0001045810-22-000008:8k_2_02:31]
Highlights

[0001045810-22-000008:8k_2_02:32]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-22-000008:8k_2_02:33]
Gaming

[0001045810-22-000008:8k_2_02:34]
•Fourth-quarter revenue was a record $3.42 billion, up 37 percent from a year ago and up 6 percent from the previous quarter. Fiscal-year revenue rose 61 percent to a record $12.46 billion.

[0001045810-22-000008:8k_2_02:35]
•Launched the GeForce RTX® 3050 desktop GPU, bringing RTX and the performance and efficiency of NVIDIA Ampere architecture to more gamers, starting at $249 MSRP.

[0001045810-22-000008:8k_2_02:36]
•Launched GeForce RTX 3080 Ti and RTX 3070 Ti laptop GPUs, delivering new levels of performance to laptops for gamers and creators.

[0001045810-22-000008:8k_2_02:37]
•Announced over 160 gaming and Studio GeForce®-based laptop designs by leading manufacturers.

[0001045810-22-000008:8k_2_02:38]
•Announced over 30 new RTX games and titles shipped in the quarter -- including COD: Vanguard, Horizon Zero Dawn, God of War, Icarus and Rainbow Six Extraction.

[0001045810-22-000008:8k_2_02:39]
•Integrated NVIDIA Reflex technology for low-latency gaming in more AAA games – including Call of Duty: Vanguard, God of War and Rainbow Six Extraction.

[0001045810-22-000008:8k_2_02:40]
•Added over 65 games to the GeForce NOW library, bringing the total to over 1,200, and announced collaborations with AT&T and Samsung to offer GeForce Now to their customers.

[0001045810-22-000008:8k_2_02:41]
Data Center

[0001045810-22-000008:8k_2_02:42]
•Fourth-quarter revenue was a record $3.26 billion, up 71 percent from a year ago and up 11 percent from the previous quarter. Fiscal-year revenue rose 58 percent to a record $10.61 billion.

[0001045810-22-000008:8k_2_02:43]
•Announced that Meta is building its AI Research SuperCluster with NVIDIA® DGX™ A100 systems.

[0001045810-22-000008:8k_2_02:44]
•Extended its AI leadership, as NVIDIA and partners, including Microsoft Azure, set records across eight popular workloads in the latest MLPerf training results.

[0001045810-22-000008:8k_2_02:45]
•Announced the general release of NVIDIA AI Enterprise 1.1, with updates including production support for containerized AI with NVIDIA software on VMware vSphere with Tanzu.

[0001045810-22-000008:8k_2_02:46]
•Open-sourced NVIDIA FLARE, an SDK enabling healthcare, manufacturing and financial services groups to collaborate on generalizable AI models that harness federated learning where data is sparse, confidential or lacks diversity.

[0001045810-22-000008:8k_2_02:47]
•A team of Stanford researchers set a world record for fastest DNA sequencing of a human genome, using NVIDIA Clara™, Google DeepVariant and Oxford Nanopore Technologies sequencing.

[0001045810-22-000008:8k_2_02:48]
Professional Visualization

[0001045810-22-000008:8k_2_02:49]
•Fourth-quarter revenue was a record $643 million, up 109 percent from a year ago and up 11 percent from the previous quarter. Fiscal-year revenue rose 100 percent to a record $2.11 billion.

[0001045810-22-000008:8k_2_02:50]
•Launched NVIDIA Omniverse™ for Creators, making it available at no cost to millions of individual creators.

[0001045810-22-000008:8k_2_02:51]
•Launched Omniverse Universal Scene Description connector for Blender, the world’s most popular open-source 3D creative application.

[0001045810-22-000008:8k_2_02:52]
•University of Illinois at Urbana-Champaign researchers built what is believed to be the longest, most complex 3D cell simulation using NVIDIA GPU-accelerated software.

[0001045810-22-000008:8k_2_02:53]
Automotive and Robotics

[0001045810-22-000008:8k_2_02:54]
•Fourth-quarter Automotive revenue was $125 million, down 14 percent from a year ago and down 7 percent from the previous quarter. Fiscal-year revenue rose 6 percent to $566 million.

[0001045810-22-000008:8k_2_02:55]
•Formed a multi-year partnership with Jaguar Land Rover to jointly develop and deliver next-generation automated driving systems, plus AI-enabled services and experiences.

[0001045810-22-000008:8k_2_02:56]
•Announced that NIO’s ET5 sedan, Xpeng’s G9 SUV and Pony.ai’s robotaxi fleet are using NVIDIA DRIVE Orin™.

[0001045810-22-000008:8k_2_02:57]
•Announced that Desay, Flex, Quanta, Valeo and ZF are using the NVIDIA DRIVE Hyperion™ platform to manufacture safe and secure AV systems for vehicle makers.

[0001045810-22-000008:8k_2_02:58]
•Launched the Isaac Autonomous Mobile Robot platform for building and deploying robotics applications.

[0001045810-22-000008:8k_2_02:59]
CFO Commentary

[0001045810-22-000008:8k_2_02:60]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-22-000008:8k_2_02:61]
Conference Call and Webcast Information

[0001045810-22-000008:8k_2_02:62]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2022 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2023.

[0001045810-22-000008:8k_2_02:63]
Non-GAAP Measures

[0001045810-22-000008:8k_2_02:64]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, IP-related costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable, domestication tax benefit, and foreign tax benefit. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-22-000008:8k_2_02:65]
About NVIDIA

[0001045810-22-000008:8k_2_02:66]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market and has redefined modern computer graphics, high performance computing and artificial intelligence. The company’s pioneering work in accelerated computing and AI is reshaping trillion-dollar industries, such as transportation,

[0001045810-22-000008:8k_2_02:67]
healthcare and manufacturing, and fueling the growth of many others. More information at https://nvidianews.nvidia.com/.

[0001045810-22-000008:8k_2_02:68]
###

[0001045810-22-000008:8k_2_02:69]
For further information, contact:

[0001045810-22-000008:8k_2_02:70]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-22-000008:8k_2_02:71]
Certain statements in this press release including, but not limited to, statements as to: the benefits, performance, impact, and abilities of our products and technologies, including NVIDIA AI, NVIDIA Omniverse, NVIDIA DRIVE, the GeForce RTX 3050 desktop GPU, GeForce RTX 3080 Ti and RTX 3070 Ti laptop GPUs, Studio GeForce, NVIDIA Reflex, GeForce NOW, NVIDIA DGX A100 systems, NVIDIA AI Enterprise 1.1, NVIDIA FLARE, NVIDIA Clara, NVIDIA Omniverse for Creators, Omniverse Universal Scene Description, NVIDIA GPU-accelerated software, NVIDIA DRIVE Orin, NVIDIA DRIVE Hyperion, and the Isaac Autonomous Mobile Robot platform; the momentum across our businesses; NVIDIA propelling advances in AI, digital biology, climate sciences, gaming, creative design, autonomous vehicles and robotics; our upcoming developer conference at GTC; our plans to announce many new products, applications, and partners for NVIDIA computing at GTC; our collaborations with AT&T and Samsung and our partnership with Jaguar Land Rover; NVIDIA’s next quarterly cash dividend; our intention to record a charge in connection with the termination of the Share Purchase Agreement related to Arm Limited; NVIDIA’s financial outlook for the first quarter of fiscal 2023; and NVIDIA’s expected tax rates for the first quarter of fiscal 2023 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-22-000008:8k_2_02:72]
© 2022 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, NVIDIA Clara, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Orin, NVIDIA Isaac and NVIDIA Omniverse trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000008:8k_2_02:73]
NVIDIA CORPORATION

[0001045810-22-000008:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-22-000008:8k_2_02:75]
(In millions, except per share data)

[0001045810-22-000008:8k_2_02:76]
(Unaudited)

[0001045810-22-000008:8k_2_02:77]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 30, |  | January 31, |  | January 30, |  | January 31, |
|  |  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue | $ | 7,643 |  |  | $ | 5,003 |  |  | $ | 26,914 |  |  | $ | 16,675 |  |
| Cost of revenue | 2,644 |  |  | 1,846 |  |  | 9,439 |  |  | 6,279 |  |
| Gross profit | 4,999 |  |  | 3,157 |  |  | 17,475 |  |  | 10,396 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,466 |  |  | 1,147 |  |  | 5,268 |  |  | 3,924 |  |
|  | Sales, general and administrative | 563 |  |  | 503 |  |  | 2,166 |  |  | 1,940 |  |
|  |  | Total operating expenses | 2,029 |  |  | 1,650 |  |  | 7,434 |  |  | 5,864 |  |
| Income from operations | 2,970 |  |  | 1,507 |  |  | 10,041 |  |  | 4,532 |  |
|  | Interest income | 9 |  |  | 6 |  |  | 29 |  |  | 57 |  |
|  | Interest expense | (61) |  |  | (53) |  |  | (236) |  |  | (184) |  |
|  | Other, net | (53) |  |  | 10 |  |  | 107 |  |  | 4 |  |
|  |  | Other income (expense), net | (105) |  |  | (37) |  |  | (100) |  |  | (123) |  |
| Income before income tax | 2,865 |  |  | 1,470 |  |  | 9,941 |  |  | 4,409 |  |
| Income tax expense (benefit) | (138) |  |  | 13 |  |  | 189 |  |  | 77 |  |
| Net income | $ | 3,003 |  |  | $ | 1,457 |  |  | $ | 9,752 |  |  | $ | 4,332 |  |
| Net income per share (A): |  |  |  |  |  |  |  |
|  | Basic | $ | 1.20 |  |  | $ | 0.59 |  |  | $ | 3.91 |  |  | $ | 1.76 |  |
|  | Diluted | $ | 1.18 |  |  | $ | 0.58 |  |  | $ | 3.85 |  |  | $ | 1.73 |  |
| Weighted average shares used in per share computation (A): |  |  |  |  |  |  |  |
|  | Basic | 2,504 |  |  | 2,478 |  |  | 2,496 |  |  | 2,467 |  |
|  | Diluted | 2,545 |  |  | 2,524 |  |  | 2,535 |  |  | 2,510 |  |

[0001045810-22-000008:8k_2_02:78]
(A) Reflects a four-for-one stock split on July 19, 2021.

[0001045810-22-000008:8k_2_02:79]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | January 30, |  | January 31, |
|  |  |  |  | 2022 |  | 2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 21,208 |  |  | $ | 11,561 |  |
|  | Accounts receivable, net |  | 4,650 |  |  | 2,429 |  |
|  | Inventories |  | 2,605 |  |  | 1,826 |  |
|  | Prepaid expenses and other current assets |  | 366 |  |  | 239 |  |
|  |  | Total current assets |  | 28,829 |  |  | 16,055 |  |
| Property and equipment, net |  | 2,778 |  |  | 2,149 |  |
| Operating lease assets |  | 829 |  |  | 707 |  |
| Goodwill |  | 4,349 |  |  | 4,193 |  |
| Intangible assets, net |  | 2,339 |  |  | 2,737 |  |
| Deferred income tax assets |  | 1,222 |  |  | 806 |  |
| Other assets |  | 3,841 |  |  | 2,144 |  |
|  |  | Total assets |  | $ | 44,187 |  |  | $ | 28,791 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,783 |  |  | $ | 1,149 |  |
|  | Accrued and other current liabilities |  | 2,552 |  |  | 1,777 |  |
|  | Short-term debt |  | — |  |  | 999 |  |
|  |  | Total current liabilities |  | 4,335 |  |  | 3,925 |  |
| Long-term debt |  | 10,946 |  |  | 5,964 |  |
| Long-term operating lease liabilities |  | 741 |  |  | 634 |  |
| Other long-term liabilities |  | 1,553 |  |  | 1,375 |  |
|  |  | Total liabilities |  | 17,575 |  |  | 11,898 |  |
| Shareholders' equity |  | 26,612 |  |  | 16,893 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 44,187 |  |  | $ | 28,791 |  |

[0001045810-22-000008:8k_2_02:80]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 30, |  | January 31, |  | January 30, |  | January 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 3,003 |  |  | $ | 1,457 |  |  | $ | 9,752 |  |  | $ | 4,332 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 551 |  |  | 417 |  |  | 2,004 |  |  | 1,397 |  |
| Depreciation and amortization | 309 |  |  | 287 |  |  | 1,174 |  |  | 1,098 |  |
| Deferred income taxes | (225) |  |  | (164) |  |  | (406) |  |  | (282) |  |
| (Gains) losses on investments in non affiliates, net | 53 |  |  | (9) |  |  | (100) |  |  | — |  |
| Other | 21 |  |  | (8) |  |  | 47 |  |  | (20) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (692) |  |  | 117 |  |  | (2,215) |  |  | (550) |  |
| Inventories | (374) |  |  | (334) |  |  | (774) |  |  | (524) |  |
| Prepaid expenses and other assets | (158) |  |  | 15 |  |  | (1,715) |  |  | (394) |  |
| Accounts payable | 183 |  |  | 23 |  |  | 568 |  |  | 312 |  |
| Accrued and other current liabilities | 423 |  |  | 178 |  |  | 581 |  |  | 290 |  |
| Other long-term liabilities | (61) |  |  | 88 |  |  | 192 |  |  | 163 |  |
| Net cash provided by operating activities | 3,033 |  |  | 2,067 |  |  | 9,108 |  |  | 5,822 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 7,417 |  |  | 3,627 |  |  | 15,197 |  |  | 8,792 |  |
| Proceeds from sales of marketable securities | 107 |  |  | 25 |  |  | 1,023 |  |  | 527 |  |
| Purchases of marketable securities | (8,767) |  |  | (6,468) |  |  | (24,787) |  |  | (19,308) |  |
| Purchases related to property and equipment and intangible assets | (273) |  |  | (283) |  |  | (976) |  |  | (1,128) |  |
| Acquisitions, net of cash acquired | (60) |  |  | — |  |  | (263) |  |  | (8,524) |  |
| Investments and other, net | (11) |  |  | (30) |  |  | (24) |  |  | (34) |  |
| Net cash used in investing activities | (1,587) |  |  | (3,129) |  |  | (9,830) |  |  | (19,675) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 4 |  |  | 4 |  |  | 281 |  |  | 194 |  |
| Payments related to tax on restricted stock units | (622) |  |  | (225) |  |  | (1,904) |  |  | (942) |  |
| Dividends paid | (100) |  |  | (99) |  |  | (399) |  |  | (395) |  |
| Principal payments on property and equipment | (21) |  |  | (17) |  |  | (83) |  |  | (17) |  |
| Other | (5) |  |  | (2) |  |  | (7) |  |  | (4) |  |
| Issuance of debt, net of issuance costs | — |  |  | (3) |  |  | 4,977 |  |  | 4,968 |  |
| Repayment of debt | — |  |  | — |  |  | (1,000) |  |  | — |  |
| Net cash provided by (used in) financing activities | (744) |  |  | (342) |  |  | 1,865 |  |  | 3,804 |  |
| Change in cash and cash equivalents | 702 |  |  | (1,404) |  |  | 1,143 |  |  | (10,049) |  |
| Cash and cash equivalents at beginning of period | 1,288 |  |  | 2,251 |  |  | 847 |  |  | 10,896 |  |
| Cash and cash equivalents at end of period | $ | 1,990 |  |  | $ | 847 |  |  | $ | 1,990 |  |  | $ | 847 |  |

[0001045810-22-000008:8k_2_02:81]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 30, |  | October 31, |  | January 31, |  | January 30, |  | January 31, |
|  |  |  | 2022 |  | 2021 |  | 2021 |  | 2022 |  | 2021 |
| GAAP gross profit |  | $ | 4,999 |  |  | $ | 4,631 |  |  | $ | 3,157 |  |  | $ | 17,475 |  |  | $ | 10,396 |  |
| GAAP gross margin |  | 65.4 | % |  | 65.2 | % |  | 63.1 | % |  | 64.9 | % |  | 62.3 | % |
|  | Acquisition-related and other costs (A) |  | 86 |  |  | 86 |  |  | 92 |  |  | 344 |  |  | 425 |  |
|  | Stock-based compensation expense (B) |  | 39 |  |  | 44 |  |  | 26 |  |  | 141 |  |  | 88 |  |
|  | IP-related costs |  | — |  |  | — |  |  | 1 |  |  | 9 |  |  | 38 |  |
| Non-GAAP gross profit |  | $ | 5,124 |  |  | $ | 4,761 |  |  | $ | 3,276 |  |  | $ | 17,969 |  |  | $ | 10,947 |  |
| Non-GAAP gross margin |  | 67.0 | % |  | 67.0 | % |  | 65.5 | % |  | 66.8 | % |  | 65.6 | % |
| GAAP operating expenses |  | $ | 2,029 |  |  | $ | 1,960 |  |  | $ | 1,650 |  |  | $ | 7,434 |  |  | $ | 5,864 |  |
|  | Stock-based compensation expense (B) |  | (512) |  |  | (515) |  |  | (391) |  |  | (1,863) |  |  | (1,309) |  |
|  | Acquisition-related and other costs (A) |  | (70) |  |  | (70) |  |  | (72) |  |  | (292) |  |  | (411) |  |
| Non-GAAP operating expenses |  | $ | 1,447 |  |  | $ | 1,375 |  |  | $ | 1,187 |  |  | $ | 5,279 |  |  | $ | 4,144 |  |
| GAAP income from operations |  | $ | 2,970 |  |  | $ | 2,671 |  |  | $ | 1,507 |  |  | $ | 10,041 |  |  | $ | 4,532 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 707 |  |  | 715 |  |  | 582 |  |  | 2,649 |  |  | 2,271 |  |
| Non-GAAP income from operations |  | $ | 3,677 |  |  | $ | 3,386 |  |  | $ | 2,089 |  |  | $ | 12,690 |  |  | $ | 6,803 |  |
| GAAP other income (expense), net |  | $ | (105) |  |  | $ | (33) |  |  | $ | (37) |  |  | $ | (100) |  |  | $ | (123) |  |
|  | (Gains) losses from non-affiliated investments |  | 53 |  |  | (20) |  |  | (9) |  |  | (99) |  |  | — |  |
|  | Interest expense related to amortization of debt discount |  | — |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Non-GAAP other income (expense), net |  | $ | (52) |  |  | $ | (52) |  |  | $ | (45) |  |  | $ | (196) |  |  | $ | (120) |  |
| GAAP net income |  | $ | 3,003 |  |  | $ | 2,464 |  |  | $ | 1,457 |  |  | $ | 9,752 |  |  | $ | 4,332 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 760 |  |  | 696 |  |  | 574 |  |  | 2,553 |  |  | 2,274 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (330) |  |  | (187) |  |  | (74) |  |  | (712) |  |  | (329) |  |
|  | Domestication tax adjustments |  | 7 |  |  | — |  |  | — |  |  | (244) |  |  | — |  |
|  | Foreign tax benefit |  | $ | (90) |  |  | $ | — |  |  | $ | — |  |  | $ | (90) |  |  | $ | — |  |
| Non-GAAP net income |  | $ | 3,350 |  |  | $ | 2,973 |  |  | $ | 1,957 |  |  | $ | 11,259 |  |  | $ | 6,277 |  |

[0001045810-22-000008:8k_2_02:82]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 30, |  | October 31, |  | January 31, |  | January 30, |  | January 31, |
|  |  |  | 2022 |  | 2021 |  | 2021 |  | 2022 |  | 2021 |
| Diluted net income per share (D) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 1.18 |  |  | $ | 0.97 |  |  | $ | 0.58 |  |  | $ | 3.85 |  |  | $ | 1.73 |  |
|  | Non-GAAP |  | $ | 1.32 |  |  | $ | 1.17 |  |  | $ | 0.78 |  |  | $ | 4.44 |  |  | $ | 2.50 |  |
| Weighted average shares used in diluted net income per share computation (D) |  | 2,545 |  |  | 2,538 |  |  | 2,524 |  |  | 2,535 |  |  | 2,510 |  |
| GAAP net cash provided by operating activities |  | $ | 3,033 |  |  | $ | 1,519 |  |  | $ | 2,067 |  |  | $ | 9,108 |  |  | $ | 5,822 |  |
|  | Purchases related to property and equipment and intangible assets |  | (273) |  |  | (221) |  |  | (283) |  |  | (976) |  |  | (1,128) |  |
|  | Principal payments on property and equipment |  | (21) |  |  | (22) |  |  | (17) |  |  | (83) |  |  | (17) |  |
| Free cash flow |  | $ | 2,739 |  |  | $ | 1,276 |  |  | $ | 1,767 |  |  | $ | 8,049 |  |  | $ | 4,677 |  |

[0001045810-22-000008:8k_2_02:83]
| (A) Acquisition-related and other costs primarily include amortization of intangible assets, inventory step-up, transaction costs, and certain compensation charges presented as follows: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 30, |  | October 31, |  | January 31, |  | January 30, |  | January 31, |
|  |  |  | 2022 |  | 2021 |  | 2021 |  | 2022 |  | 2021 |
|  | Cost of revenue |  | $ | 86 |  |  | $ | 86 |  |  | $ | 92 |  |  | $ | 344 |  |  | $ | 425 |  |
|  | Research and development |  | $ | 9 |  |  | $ | 7 |  |  | $ | 2 |  |  | $ | 19 |  |  | $ | 9 |  |
|  | Sales, general and administrative |  | $ | 61 |  |  | $ | 63 |  |  | $ | 70 |  |  | $ | 273 |  |  | $ | 402 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 30, |  | October 31, |  | January 31, |  | January 30, |  | January 31, |
|  |  |  | 2022 |  | 2021 |  | 2021 |  | 2022 |  | 2021 |
|  | Cost of revenue |  | $ | 39 |  |  | $ | 44 |  |  | $ | 26 |  |  | $ | 141 |  |  | $ | 88 |  |
|  | Research and development |  | $ | 362 |  |  | $ | 363 |  |  | $ | 266 |  |  | $ | 1,298 |  |  | $ | 860 |  |
|  | Sales, general and administrative |  | $ | 150 |  |  | $ | 152 |  |  | $ | 125 |  |  | $ | 565 |  |  | $ | 449 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (D) Reflects a four-for-one stock split on July 19, 2021. |

[0001045810-22-000008:8k_2_02:84]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2023 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 65.2 | % |
|  | Impact of stock-based compensation expense and acquisition-related costs | 1.8 | % |
| Non-GAAP gross margin |  | 67.0 | % |
| GAAP operating expenses |  | $ | 3,550 |  |
|  | Arm write-off cost |  | (1,357) |  |
|  | Stock-based compensation expense and acquisition-related costs | (593) |  |
| Non-GAAP operating expenses |  | $ | 1,600 |  |
