# NVDA note change history — 0001045810-21-000131 → 0001045810-21-000163


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-11-22):
[0001045810-21-000163:note_history:1]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

- added (2021-11-22):
[0001045810-21-000163:note_history:2]
We recently entered into several long-term supply agreements, under which we have made advance payments and have $1.79 billion remaining unpaid. As of October 31, 2021, we had outstanding inventory purchase and long-term supply obligations totaling $6.90 billion, inclusive of the $1.79 billion, and other purchase obligations totaling $935 million.

- added (2021-11-22):
[0001045810-21-000163:note_history:3]
Total future unconditional purchase commitments as of October 31, 2021, are as follows:

- added (2021-11-22):
[0001045810-21-000163:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 (excluding first nine months of fiscal year 2022) | $ | 2,944 |  |
| 2023 | 4,637 |  |
| 2024 | 172 |  |
| 2025 | 52 |  |
| 2026 | 28 |  |
| Total | $ | 7,833 |  |

- changed (2021-11-22):
[0001045810-21-000163:note_history:5]
The estimated amount of product warranty liabilities was $32 million and $22 million as of October 31, 2021 and January 31, 2021, respectively, and the activities were not significant.
  (was, 2021-08-20, similarity 0.6207):
[0001045810-21-000131:note_history:5]
The estimated amount of product warranty liabilities was $31 million and $22 million as of August 1, 2021 and January 31, 2021, respectively, and the activities related to the warranty liabilities were not significant.

- added (2021-11-22):
[0001045810-21-000163:note_history:6]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-

- changed (2021-11-22):
[0001045810-21-000163:note_history:7]
cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2021-08-20, similarity 0.6779):
[0001045810-21-000131:note_history:7]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of

- changed (2021-11-22):
[0001045810-21-000163:note_history:8]
As of October 31, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2021-08-20, similarity 0.9901):
[0001045810-21-000131:note_history:8]
As of August 1, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2021-11-22):
[0001045810-21-000131:note_history:9]
As of August 1, 2021, we had outstanding inventory purchase and long-term supply commitment obligations totaling $4.79 billion, of which $4.59 billion is expected to occur over the next 12 months and the remaining balance over 36 months. Other purchase obligations totaling $565 million are primarily expected to occur over the next 18 months.

- removed (2021-11-22):
[0001045810-21-000131:note_history:10]
cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-22):
[0001045810-21-000163:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The third quarters of fiscal years 2022 and 2021 were both 13-week quarters.
  (was, 2021-08-20, similarity 0.7458):
[0001045810-21-000131:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The second quarters of fiscal years 2022 and 2021 were both 13-week quarters.

- added (2021-11-22):
[0001045810-21-000163:note_history:12]
Adoption of New and Recently Issued Accounting Pronouncement

- added (2021-11-22):
[0001045810-21-000163:note_history:13]
Recently Adopted Accounting Pronouncement

- added (2021-11-22):
[0001045810-21-000163:note_history:14]
In October 2021, the Financial Accounting Standards Board issued a new accounting standard to require that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers. We early adopted this accounting standard in the third quarter of fiscal year 2022 and the impact was immaterial.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-11-22):
[0001045810-21-000163:note_history:15]
In June 2021, we issued $1.25 billion of the 0.309% Notes Due 2023, $1.25 billion of the 0.584% Notes Due 2024, $1.25 billion of the 1.55% Notes Due 2028, and $1.25 billion of the 2.00% Notes Due 2031, or collectively, the June 2021 Notes. Interest on the 0.584% Notes Due 2024 is payable on June 14 and December 14 of each year, beginning on

- added (2021-11-22):
[0001045810-21-000163:note_history:16]
December 14, 2021. Interest on all other series of the June 2021 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2021. We may redeem the June 2021 Notes for cash prior to maturity. However, no make-whole premium will be paid for redemptions of the Notes Due 2023 on or after June 15, 2022, the Notes Due 2024 on or after June 14, 2023, the Notes Due 2028 on or after April 15, 2028, or the Notes Due 2031 on or after March 15, 2031. The net proceeds from the June 2021 Notes were $4.98 billion, after deducting debt discount and issuance costs.

- added (2021-11-22):
[0001045810-21-000163:note_history:17]
On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021. Interest on the $1.00 billion of the 3.20% Notes Due 2026, or September 2016 Notes, is payable on March 16 and September 16 of each year.

- added (2021-11-22):
[0001045810-21-000163:note_history:18]
The September 2016 Notes, the March 2020 Notes, and the June 2021 Notes, or collectively, the Notes, are our unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

- changed (2021-11-22):
[0001045810-21-000163:note_history:19]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 31, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | — |  | 2.38% |  | $ | — |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.6 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.6 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 4.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.6 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.6 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (56) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 10,944 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,944 |  |  | $ | 5,964 |  |
  (was, 2021-08-20, similarity 0.7548):
[0001045810-21-000131:note_history:19]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | August 1, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.9 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.9 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 5.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.9 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.9 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (57) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 11,943 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,943 |  |  | $ | 5,964 |  |

- changed (2021-11-22):
[0001045810-21-000163:note_history:20]
As of October 31, 2021, we were in compliance with the required covenants under the Notes.
  (was, 2021-08-20, similarity 0.9341):
[0001045810-21-000131:note_history:20]
As of August 1, 2021, we were in compliance with the required covenants under the Notes.

- added (2021-11-22):
[0001045810-21-000163:note_history:21]
Commercial Paper

- changed (2021-11-22):
[0001045810-21-000163:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of October 31, 2021, we had not issued any commercial paper.
  (was, 2021-08-20, similarity 0.9611):
[0001045810-21-000131:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of August 1, 2021, we had not issued any commercial paper.

- removed (2021-11-22):
[0001045810-21-000131:note_history:23]
In June 2021, we issued $1.25 billion of the 0.309% Notes Due 2023, $1.25 billion of the 0.584% Notes Due 2024, $1.25 billion of the 1.55% Notes Due 2028, and $1.25 billion of the 2.00% Notes Due 2031, or collectively, the June 2021 Notes. Interest on the 0.584% Notes Due 2024 is payable on June 14 and December 14 of each year, beginning on December 14, 2021. Interest on all other series of the June 2021 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2021. We may redeem the June 2021 Notes for cash prior to maturity, upon at least 10 but no more than 60 days prior notice, at redemption prices that include accrued and unpaid interest and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2023 on or after June 15, 2022, the Notes Due 2024 on or after June 14, 2023, the Notes Due 2028 on or after April 15, 2028, or the Notes Due 2031 on or after March 15, 2031.  The net proceeds from the June 2021 Notes were $4.98 billion, after deducting debt discount and issuance costs.

- removed (2021-11-22):
[0001045810-21-000131:note_history:24]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021.

- removed (2021-11-22):
[0001045810-21-000131:note_history:25]
The September 2016 Notes, the March 2020 Notes, and the June 2021 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

- removed (2021-11-22):
[0001045810-21-000131:note_history:26]
Credit Facilities

- removed (2021-11-22):
[0001045810-21-000131:note_history:27]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of August 1, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-22):
[0001045810-21-000163:note_history:28]
The following is a summary of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021:
  (was, 2021-08-20, similarity 0.9484):
[0001045810-21-000131:note_history:28]
The following is a summary of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021:

- changed (2021-11-22):
[0001045810-21-000163:note_history:29]
|  | October 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,179 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 9,180 |  |  | $ | 135 |  |  | $ | 9,045 |  |
| Debt securities issued by the United States Treasury | 4,887 |  |  | — |  |  | (2) |  |  | 4,885 |  |  | 195 |  |  | 4,690 |  |
| Debt securities issued by United States government agencies | 2,861 |  |  | — |  |  | — |  |  | 2,861 |  |  | 307 |  |  | 2,554 |  |
| Certificates of deposit | 1,512 |  |  | — |  |  | — |  |  | 1,512 |  |  | 32 |  |  | 1,480 |  |
| Money market funds | 360 |  |  | — |  |  | — |  |  | 360 |  |  | 360 |  |  | — |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,040 |  |  | $ | 2 |  |  | $ | (3) |  |  | $ | 19,039 |  |  | $ | 1,029 |  |  | $ | 18,010 |  |
  (was, 2021-08-20, similarity 0.8111):
[0001045810-21-000131:note_history:29]
|  | August 1, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,610 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 8,611 |  |  | $ | 1,825 |  |  | $ | 6,786 |  |
| Debt securities issued by the United States Treasury | 5,079 |  |  | 1 |  |  | — |  |  | 5,080 |  |  | 1,311 |  |  | 3,769 |  |
| Debt securities issued by United States government agencies | 2,371 |  |  | 1 |  |  | — |  |  | 2,372 |  |  | 60 |  |  | 2,312 |  |
| Money market funds | 2,097 |  |  | — |  |  | — |  |  | 2,097 |  |  | 2,097 |  |  | — |  |
| Certificates of deposit | 962 |  |  | — |  |  | — |  |  | 962 |  |  | 44 |  |  | 918 |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,360 |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | 19,363 |  |  | $ | 5,337 |  |  | $ | 14,026 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-22):
[0001045810-21-000163:note_history:30]
The following is a summary of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021:
  (was, 2021-08-20, similarity 0.9484):
[0001045810-21-000131:note_history:30]
The following is a summary of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021:

- changed (2021-11-22):
[0001045810-21-000163:note_history:31]
|  | October 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,179 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 9,180 |  |  | $ | 135 |  |  | $ | 9,045 |  |
| Debt securities issued by the United States Treasury | 4,887 |  |  | — |  |  | (2) |  |  | 4,885 |  |  | 195 |  |  | 4,690 |  |
| Debt securities issued by United States government agencies | 2,861 |  |  | — |  |  | — |  |  | 2,861 |  |  | 307 |  |  | 2,554 |  |
| Certificates of deposit | 1,512 |  |  | — |  |  | — |  |  | 1,512 |  |  | 32 |  |  | 1,480 |  |
| Money market funds | 360 |  |  | — |  |  | — |  |  | 360 |  |  | 360 |  |  | — |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,040 |  |  | $ | 2 |  |  | $ | (3) |  |  | $ | 19,039 |  |  | $ | 1,029 |  |  | $ | 18,010 |  |
  (was, 2021-08-20, similarity 0.8111):
[0001045810-21-000131:note_history:31]
|  | August 1, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,610 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 8,611 |  |  | $ | 1,825 |  |  | $ | 6,786 |  |
| Debt securities issued by the United States Treasury | 5,079 |  |  | 1 |  |  | — |  |  | 5,080 |  |  | 1,311 |  |  | 3,769 |  |
| Debt securities issued by United States government agencies | 2,371 |  |  | 1 |  |  | — |  |  | 2,372 |  |  | 60 |  |  | 2,312 |  |
| Money market funds | 2,097 |  |  | — |  |  | — |  |  | 2,097 |  |  | 2,097 |  |  | — |  |
| Certificates of deposit | 962 |  |  | — |  |  | — |  |  | 962 |  |  | 44 |  |  | 918 |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,360 |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | 19,363 |  |  | $ | 5,337 |  |  | $ | 14,026 |  |

- changed (2021-11-22):
[0001045810-21-000163:note_history:32]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021 are shown below by contractual maturity.
  (was, 2021-08-20, similarity 0.9664):
[0001045810-21-000131:note_history:32]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021 are shown below by contractual maturity.

- added (2021-11-22):
[0001045810-21-000163:note_history:33]
|  | October 31, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,243 |  |  | $ | 16,244 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 2,797 |  |  | 2,795 |  |  | 566 |  |  | 568 |  |
| Total | $ | 19,040 |  |  | $ | 19,039 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |

- removed (2021-11-22):
[0001045810-21-000131:note_history:34]
|  | August 1, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,390 |  |  | $ | 17,391 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 1,970 |  |  | 1,972 |  |  | 566 |  |  | 568 |  |
| Total | $ | 19,360 |  |  | $ | 19,363 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-22):
[0001045810-21-000163:note_history:35]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 31, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | — |  | 2.38% |  | $ | — |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.6 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.6 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 4.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.6 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.6 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (56) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 10,944 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,944 |  |  | $ | 5,964 |  |
  (was, 2021-08-20, similarity 0.7548):
[0001045810-21-000131:note_history:35]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | August 1, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.9 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.9 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 5.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.9 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.9 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (57) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 11,943 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,943 |  |  | $ | 5,964 |  |
