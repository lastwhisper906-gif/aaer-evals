# NVDA 8-K — 0001045810-24-000262 filed 2024-08-28

## item codes, every 8-K on or before 2024-08-28

- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2024-08-28

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-24-000262:8k_2_02:1]
EX-99.1
2
q2fy25pr.htm
Q2FY25 PRESS RELEASE

[0001045810-24-000262:8k_2_02:2]
Document

[0001045810-24-000262:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-24-000262:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2025

[0001045810-24-000262:8k_2_02:5]
•Record quarterly revenue of $30.0 billion, up 15% from Q1 and up 122% from a year ago

[0001045810-24-000262:8k_2_02:6]
•Record quarterly Data Center revenue of $26.3 billion, up 16% from Q1 and up 154% from a year ago

[0001045810-24-000262:8k_2_02:7]
SANTA CLARA, Calif.—Aug. 28, 2024―NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 28, 2024, of $30.0 billion, up 15% from the previous quarter and up 122% from a year ago.

[0001045810-24-000262:8k_2_02:8]
For the quarter, GAAP earnings per diluted share was $0.67, up 12% from the previous quarter and up 168% from a year ago. Non-GAAP earnings per diluted share was $0.68, up 11% from the previous quarter and up 152% from a year ago.

[0001045810-24-000262:8k_2_02:9]
“Hopper demand remains strong, and the anticipation for Blackwell is incredible,” said Jensen Huang, founder and CEO of NVIDIA. “NVIDIA achieved record revenues as global data centers are in full throttle to modernize the entire computing stack with accelerated computing and generative AI.”

[0001045810-24-000262:8k_2_02:10]
“Blackwell samples are shipping to our partners and customers. Spectrum-X Ethernet for AI and NVIDIA AI Enterprise software are two new product categories achieving significant scale, demonstrating that NVIDIA is a full-stack and data center-scale platform. Across the entire stack and ecosystem, we are helping frontier model makers to consumer internet services, and now enterprises. Generative AI will revolutionize every industry.”

[0001045810-24-000262:8k_2_02:11]
During the first half of fiscal 2025, NVIDIA returned $15.4 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the second quarter, the company had $7.5 billion remaining under its share repurchase authorization. On August 26, 2024, the Board of Directors approved an additional $50.0 billion in share repurchase authorization, without expiration.

[0001045810-24-000262:8k_2_02:12]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on October 3, 2024, to all shareholders of record on September 12, 2024.

[0001045810-24-000262:8k_2_02:13]
On June 7, 2024, NVIDIA completed a ten-for-one forward stock split. All share and per-share amounts presented have been retroactively adjusted to reflect the stock split.

[0001045810-24-000262:8k_2_02:14]
Q2 Fiscal 2025 Summary

[0001045810-24-000262:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY25 | Q1 FY25 | Q2 FY24 | Q/Q | Y/Y |
| Revenue | $30,040 | $26,044 | $13,507 | Up 15% | Up 122% |
| Gross margin | 75.1 | % | 78.4 | % | 70.1 | % | Down 3.3 pts | Up 5.0 pts |
| Operating expenses | $3,932 | $3,497 | $2,662 | Up 12% | Up 48% |
| Operating income | $18,642 | $16,909 | $6,800 | Up 10% | Up 174% |
| Net income | $16,599 | $14,881 | $6,188 | Up 12% | Up 168% |
| Diluted earnings per share | $0.67 | $0.60 | $0.25 | Up 12% | Up 168% |

[0001045810-24-000262:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY25 | Q1 FY25 | Q2 FY24 | Q/Q | Y/Y |
| Revenue | $30,040 | $26,044 | $13,507 | Up 15% | Up 122% |
| Gross margin | 75.7 | % | 78.9 | % | 71.2 | % | Down 3.2 pts | Up 4.5 pts |
| Operating expenses | $2,792 | $2,501 | $1,838 | Up 12% | Up 52% |
| Operating income | $19,937 | $18,059 | $7,776 | Up 10% | Up 156% |
| Net income | $16,952 | $15,238 | $6,740 | Up 11% | Up 152% |
| Diluted earnings per share | $0.68 | $0.61 | $0.27 | Up 11% | Up 152% |

[0001045810-24-000262:8k_2_02:17]
Outlook

[0001045810-24-000262:8k_2_02:18]
NVIDIA’s outlook for the third quarter of fiscal 2025 is as follows:

[0001045810-24-000262:8k_2_02:19]
•Revenue is expected to be $32.5 billion, plus or minus 2%.

[0001045810-24-000262:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 74.4% and 75.0%, respectively, plus or minus 50 basis points. For the full year, gross margins are expected to be in the mid-70% range.

[0001045810-24-000262:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $4.3 billion and $3.0 billion, respectively.  Full-year operating expenses are expected to grow in the mid- to upper-40% range.

[0001045810-24-000262:8k_2_02:22]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $350 million, excluding gains and losses from non-affiliated investments and publicly-held equity securities.

[0001045810-24-000262:8k_2_02:23]
•GAAP and non-GAAP tax rates are expected to be 17%, plus or minus 1%, excluding any discrete items.

[0001045810-24-000262:8k_2_02:24]
Highlights

[0001045810-24-000262:8k_2_02:25]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-24-000262:8k_2_02:26]
Data Center

[0001045810-24-000262:8k_2_02:27]
•Second-quarter revenue was a record $26.3 billion, up 16% from the previous quarter and up 154% from a year ago.

[0001045810-24-000262:8k_2_02:28]
•Announced that the combination of NVIDIA H200 Tensor Core and NVIDIA Blackwell architecture B200 Tensor Core processors swept the latest industry-standard MLPerf benchmark results for inference.

[0001045810-24-000262:8k_2_02:29]
•Revealed that H200 GPU-powered systems are now available on CoreWeave, the first cloud service provider to announce general availability.

[0001045810-24-000262:8k_2_02:30]
•Unveiled an array of Blackwell systems featuring NVIDIA Grace™ CPUs, networking and infrastructure from top manufacturers such as GIGABYTE, QCT and Wiwynn.

[0001045810-24-000262:8k_2_02:31]
•Reported broad adoption of the NVIDIA Spectrum-X™ Ethernet networking platform by cloud service providers, GPU cloud providers and enterprises, as well as partners incorporating it into their offerings.

[0001045810-24-000262:8k_2_02:32]
•Released NVIDIA NIM™ for broad availability to developers globally and announced more than 150 companies are integrating microservices into their platforms to speed generative AI application development.

[0001045810-24-000262:8k_2_02:33]
•Unveiled an inference service with Hugging Face powered by NIM microservices on NVIDIA DGX™ Cloud to enable developers to deploy popular large language models.

[0001045810-24-000262:8k_2_02:34]
•Introduced an NVIDIA AI Foundry service and NIM inference microservices to accelerate generative AI for the world’s enterprises with the Llama 3.1 collection of models.

[0001045810-24-000262:8k_2_02:35]
•Announced Japan advanced its sovereign AI capabilities with its ABCI 3.0 supercomputer, integrating H200 GPUs and NVIDIA Quantum-2 InfiniBand networking.

[0001045810-24-000262:8k_2_02:36]
•Accelerated quantum computing efforts at national supercomputing centers around the world with the open-source NVIDIA CUDA-Q™ platform.

[0001045810-24-000262:8k_2_02:37]
Gaming and AI PC

[0001045810-24-000262:8k_2_02:38]
•Second-quarter Gaming revenue was $2.9 billion, up 9% from the previous quarter and up 16% from a year ago.

[0001045810-24-000262:8k_2_02:39]
•Announced NVIDIA ACE, a suite of generative AI technologies that bring digital humans to life, now includes NVIDIA Nemotron-4 4B, a small language model for on-device inference, and is available in early access for RTX AI PCs.

[0001045810-24-000262:8k_2_02:40]
•Introduced Project G-Assist, a technology preview demonstrating the power of AI agents to assist gamers and creators in real time.

[0001045810-24-000262:8k_2_02:41]
•Announced new NVIDIA GeForce RTX and DLSS titles, including Indiana Jones and the Great Circle, Dune: Awakening and Dragon Age: The Veilguard, bringing the total number of RTX games and apps to over 600.

[0001045810-24-000262:8k_2_02:42]
•Surpassed 2,000 games on GeForce NOW, expanded the service into Japan and announced launches of Black Myth: Wukong and Star Wars Outlaws.

[0001045810-24-000262:8k_2_02:43]
Professional Visualization

[0001045810-24-000262:8k_2_02:44]
•Second-quarter revenue was $454 million, up 6% from the previous quarter and up 20% from a year ago.

[0001045810-24-000262:8k_2_02:45]
•Introduced generative AI models and NIM microservices for OpenUSD to accelerate workflows and the development of industrial digital twins and robotics.

[0001045810-24-000262:8k_2_02:46]
•Announced major Taiwanese electronics makers are creating more autonomous factories with a new reference workflow that combines NVIDIA Metropolis vision AI, NVIDIA Omniverse™ simulation and NVIDIA Isaac™ AI robot development.

[0001045810-24-000262:8k_2_02:47]
Automotive and Robotics

[0001045810-24-000262:8k_2_02:48]
•Second-quarter Automotive revenue was $346 million, up 5% from the previous quarter and up 37% from a year ago.

[0001045810-24-000262:8k_2_02:49]
•Unveiled the world’s leaders in robot development, including BYD Electronics, Siemens and Teradyne Robotics, are adopting the Isaac robotics platform for R&D and production.

[0001045810-24-000262:8k_2_02:50]
•Announced Omniverse Cloud Sensor RTX™ microservices to enable physically accurate sensor simulation to speed development of autonomous machines.

[0001045810-24-000262:8k_2_02:51]
•Won the Autonomous Grand Challenge at the Computer Vision and Pattern Recognition conference in the category of End-to-End Driving at Scale for advances in building physical, generative AI applications for autonomous vehicle development.

[0001045810-24-000262:8k_2_02:52]
CFO Commentary

[0001045810-24-000262:8k_2_02:53]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-24-000262:8k_2_02:54]
Conference Call and Webcast Information

[0001045810-24-000262:8k_2_02:55]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2025 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2025.

[0001045810-24-000262:8k_2_02:56]
Non-GAAP Measures

[0001045810-24-000262:8k_2_02:57]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains from non-affiliated investments and publicly-held equity securities, net, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-24-000262:8k_2_02:58]
About NVIDIA

[0001045810-24-000262:8k_2_02:59]
NVIDIA (NASDAQ: NVDA) is the world leader in accelerated computing.

[0001045810-24-000262:8k_2_02:60]
###

[0001045810-24-000262:8k_2_02:61]
For further information, contact:

[0001045810-24-000262:8k_2_02:62]
| Stewart Stecker |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sstecker@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-24-000262:8k_2_02:63]
Certain statements in this press release including, but not limited to, statements as to:  the strong demand for Hopper and the incredible anticipation for Blackwell; global data centers in full throttle to modernize the entire computing stack with accelerated computing and generative AI; the timing of Blackwell samples shipping to partners and customers; Spectrum-X Ethernet for AI and NVIDIA AI Enterprise software achieving significant scale; NVIDIA helping frontier model makers, consumer internet services, and enterprises; generative AI revolutionizing every industry; the benefits and performance of NVIDIA’s products and services, including NVIDIA H200, NVIDIA Blackwell and B200, NVIDIA Spectrum-X, NVIDIA NIM, NVIDIA DGX Cloud, NVIDIA AI Foundry service, NVIDIA Quantum-2 InfiniBand, NVIDIA CUDA-Q, NVIDIA ACE, NVIDIA Nemotron-4 4B, Project G-Assist, RTX AI Toolkit, NVIDIA Metropolis, NVIDIA Omniverse, NVIDIA Isaac and Omniverse Cloud Sensor RTX; NVIDIA’s next quarterly cash dividend; NVIDIA’s expected full-year gross margins and operating expenses; and NVIDIA’s financial outlook and expected tax rates for the third quarter of fiscal 2025 are forward-looking statements that

[0001045810-24-000262:8k_2_02:64]
are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; and unexpected loss of performance of our products or technologies when integrated into systems, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-24-000262:8k_2_02:65]
© 2024 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce RTX, NVIDIA CUDA-Q, NVIDIA DGX, NVIDIA Grace, NVIDIA Isaac, NVIDIA NIM, NVIDIA Omniverse, NVIDIA RTX, NVIDIA Spectrum-X and Omniverse Cloud Sensor RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-24-000262:8k_2_02:66]
NVIDIA CORPORATION

[0001045810-24-000262:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-24-000262:8k_2_02:68]
(In millions, except per share data)

[0001045810-24-000262:8k_2_02:69]
(Unaudited)

[0001045810-24-000262:8k_2_02:70]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | July 30, |  | July 28, |  | July 30, |
|  |  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue | $ | 30,040 |  |  | $ | 13,507 |  |  | $ | 56,084 |  |  | $ | 20,699 |  |
| Cost of revenue | 7,466 |  |  | 4,045 |  |  | 13,105 |  |  | 6,589 |  |
| Gross profit | 22,574 |  |  | 9,462 |  |  | 42,979 |  |  | 14,110 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 3,090 |  |  | 2,040 |  |  | 5,810 |  |  | 3,916 |  |
|  | Sales, general and administrative | 842 |  |  | 622 |  |  | 1,618 |  |  | 1,253 |  |
|  |  | Total operating expenses | 3,932 |  |  | 2,662 |  |  | 7,428 |  |  | 5,169 |  |
| Operating income | 18,642 |  |  | 6,800 |  |  | 35,551 |  |  | 8,941 |  |
|  | Interest income | 444 |  |  | 187 |  |  | 803 |  |  | 338 |  |
|  | Interest expense | (61) |  |  | (65) |  |  | (125) |  |  | (131) |  |
|  | Other, net | 189 |  |  | 59 |  |  | 264 |  |  | 42 |  |
|  |  | Other income (expense), net | 572 |  |  | 181 |  |  | 942 |  |  | 249 |  |
| Income before income tax | 19,214 |  |  | 6,981 |  |  | 36,493 |  |  | 9,190 |  |
| Income tax expense | 2,615 |  |  | 793 |  |  | 5,013 |  |  | 958 |  |
| Net income | $ | 16,599 |  |  | $ | 6,188 |  |  | $ | 31,480 |  |  | $ | 8,232 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.68 |  |  | $ | 0.25 |  |  | $ | 1.28 |  |  | $ | 0.33 |  |
|  | Diluted | $ | 0.67 |  |  | $ | 0.25 |  |  | $ | 1.27 |  |  | $ | 0.33 |  |
| Weighted average shares used in per share computation: |
|  | Basic | 24,578 |  |  | 24,729 |  |  | 24,599 |  |  | 24,716 |  |
|  | Diluted | 24,848 |  |  | 24,994 |  |  | 24,869 |  |  | 24,948 |  |

[0001045810-24-000262:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | July 28, |  | January 28, |
|  |  |  |  | 2024 |  | 2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 34,800 |  |  | $ | 25,984 |  |
|  | Accounts receivable, net |  | 14,132 |  |  | 9,999 |  |
|  | Inventories |  | 6,675 |  |  | 5,282 |  |
|  | Prepaid expenses and other current assets |  | 4,026 |  |  | 3,080 |  |
|  |  | Total current assets |  | 59,633 |  |  | 44,345 |  |
| Property and equipment, net |  | 4,885 |  |  | 3,914 |  |
| Operating lease assets |  | 1,556 |  |  | 1,346 |  |
| Goodwill |  | 4,622 |  |  | 4,430 |  |
| Intangible assets, net |  | 952 |  |  | 1,112 |  |
| Deferred income tax assets |  | 9,578 |  |  | 6,081 |  |
| Other assets |  | 4,001 |  |  | 4,500 |  |
|  |  | Total assets |  | $ | 85,227 |  |  | $ | 65,728 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 3,680 |  |  | $ | 2,699 |  |
|  | Accrued and other current liabilities |  | 10,289 |  |  | 6,682 |  |
|  | Short-term debt |  | — |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 13,969 |  |  | 10,631 |  |
| Long-term debt |  | 8,461 |  |  | 8,459 |  |
| Long-term operating lease liabilities |  | 1,304 |  |  | 1,119 |  |
| Other long-term liabilities |  | 3,336 |  |  | 2,541 |  |
|  |  | Total liabilities |  | 27,070 |  |  | 22,750 |  |
| Shareholders' equity |  | 58,157 |  |  | 42,978 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 85,227 |  |  | $ | 65,728 |  |

[0001045810-24-000262:8k_2_02:72]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, |  | July 30, |  | July 28, |  | July 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 16,599 |  |  | $ | 6,188 |  |  | $ | 31,480 |  |  | $ | 8,232 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,154 |  |  | 842 |  |  | 2,164 |  |  | 1,576 |  |
| Depreciation and amortization | 433 |  |  | 365 |  |  | 843 |  |  | 749 |  |
| Gains on investments in non-affiliated entities and publicly-held equity securities, net | (193) |  |  | (60) |  |  | (264) |  |  | (45) |  |
| Deferred income taxes | (1,699) |  |  | (746) |  |  | (3,276) |  |  | (1,881) |  |
| Other | (144) |  |  | (69) |  |  | (288) |  |  | (102) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (1,767) |  |  | (2,986) |  |  | (4,133) |  |  | (3,239) |  |
| Inventories | (803) |  |  | 296 |  |  | (1,380) |  |  | 861 |  |
| Prepaid expenses and other assets | 714 |  |  | (376) |  |  | (12) |  |  | (592) |  |
| Accounts payable | 823 |  |  | 777 |  |  | 801 |  |  | 789 |  |
| Accrued and other current liabilities | (888) |  |  | 1,986 |  |  | 3,314 |  |  | 2,675 |  |
| Other long-term liabilities | 260 |  |  | 131 |  |  | 584 |  |  | 236 |  |
| Net cash provided by operating activities | 14,489 |  |  | 6,348 |  |  | 29,833 |  |  | 9,259 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 4,094 |  |  | 2,598 |  |  | 8,098 |  |  | 5,111 |  |
| Proceeds from sales of marketable securities | 15 |  |  | — |  |  | 164 |  |  | — |  |
| Purchases of marketable securities | (5,744) |  |  | (2,542) |  |  | (15,047) |  |  | (5,343) |  |
| Purchase related to property and equipment and intangible assets | (977) |  |  | (289) |  |  | (1,346) |  |  | (537) |  |
| Acquisitions, net of cash acquired | (279) |  |  | — |  |  | (317) |  |  | (83) |  |
| Purchases of investments in non-affiliated entities | (344) |  |  | (235) |  |  | (534) |  |  | (456) |  |
| Proceeds from sales of investments in non-affiliated entities | 50 |  |  | — |  |  | 105 |  |  | — |  |
| Other | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Net cash used in investing activities | (3,185) |  |  | (447) |  |  | (8,877) |  |  | (1,287) |  |

[0001045810-24-000262:8k_2_02:73]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, |  | July 30, |  | July 28, |  | July 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | — |  |  | 1 |  |  | 285 |  |  | 247 |  |
| Payments related to repurchases of common stock | (7,158) |  |  | (3,067) |  |  | (14,898) |  |  | (3,067) |  |
| Repayment of debt | (1,250) |  |  | (1,250) |  |  | (1,250) |  |  | (1,250) |  |
| Payments related to tax on restricted stock units | (1,637) |  |  | (672) |  |  | (3,389) |  |  | (1,179) |  |
| Dividends paid | (246) |  |  | (99) |  |  | (344) |  |  | (199) |  |
| Principal payments on property and equipment and intangible assets | (29) |  |  | (11) |  |  | (69) |  |  | (31) |  |
| Net cash used in financing activities | (10,320) |  |  | (5,098) |  |  | (19,665) |  |  | (5,479) |  |
| Change in cash, cash equivalents, and restricted cash | 984 |  |  | 803 |  |  | 1,291 |  |  | 2,493 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 7,587 |  |  | 5,079 |  |  | 7,280 |  |  | 3,389 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 8,571 |  |  | $ | 5,882 |  |  | $ | 8,571 |  |  | $ | 5,882 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheet: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 8,563 |  |  | $ | 5,783 |  |  | $ | 8,563 |  |  | $ | 5,783 |  |
| Restricted cash, included in prepaid expenses and other current assets | 8 |  |  | 99 |  |  | 8 |  |  | 99 |  |
| Total cash, cash equivalents, and restricted cash | $ | 8,571 |  |  | $ | 5,882 |  |  | $ | 8,571 |  |  | $ | 5,882 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 7,208 |  |  | $ | 227 |  |  | $ | 7,449 |  |  | $ | 328 |  |

[0001045810-24-000262:8k_2_02:74]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 30, |  | July 28, |  | July 30, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| GAAP gross profit |  | $ | 22,574 |  |  | $ | 20,406 |  |  | $ | 9,462 |  |  | $ | 42,979 |  |  | $ | 14,110 |  |
| GAAP gross margin |  | 75.1 | % |  | 78.4 | % |  | 70.1 | % |  | 76.6 | % |  | 68.2 | % |
|  | Acquisition-related and other costs (A) |  | 118 |  |  | 119 |  |  | 119 |  |  | 238 |  |  | 239 |  |
|  | Stock-based compensation expense (B) |  | 40 |  |  | 36 |  |  | 31 |  |  | 75 |  |  | 58 |  |
|  | Other (C) |  | (3) |  |  | (1) |  |  | 2 |  |  | (4) |  |  | 10 |  |
| Non-GAAP gross profit |  | $ | 22,729 |  |  | $ | 20,560 |  |  | $ | 9,614 |  |  | $ | 43,288 |  |  | $ | 14,417 |  |
| Non-GAAP gross margin |  | 75.7 | % |  | 78.9 | % |  | 71.2 | % |  | 77.2 | % |  | 69.7 | % |
| GAAP operating expenses |  | $ | 3,932 |  |  | $ | 3,497 |  |  | $ | 2,662 |  |  | $ | 7,428 |  |  | $ | 5,169 |  |
|  | Stock-based compensation expense (B) |  | (1,114) |  |  | (975) |  |  | (811) |  |  | (2,089) |  |  | (1,518) |  |
|  | Acquisition-related and other costs (A) |  | (26) |  |  | (21) |  |  | (18) |  |  | (48) |  |  | (72) |  |
|  | Other (C) |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 10 |  |
| Non-GAAP operating expenses |  | $ | 2,792 |  |  | $ | 2,501 |  |  | $ | 1,838 |  |  | $ | 5,291 |  |  | $ | 3,589 |  |
| GAAP operating income |  | $ | 18,642 |  |  | $ | 16,909 |  |  | $ | 6,800 |  |  | $ | 35,551 |  |  | $ | 8,941 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,295 |  |  | 1,150 |  |  | 976 |  |  | 2,446 |  |  | 1,887 |  |
| Non-GAAP operating income |  | $ | 19,937 |  |  | $ | 18,059 |  |  | $ | 7,776 |  |  | $ | 37,997 |  |  | $ | 10,828 |  |
| GAAP other income (expense), net |  | $ | 572 |  |  | $ | 370 |  |  | $ | 181 |  |  | $ | 942 |  |  | $ | 249 |  |
|  | Gains from non-affiliated investments and publicly-held equity securities, net |  | (193) |  |  | (69) |  |  | (62) |  |  | (264) |  |  | (46) |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Non-GAAP other income (expense), net |  | $ | 380 |  |  | $ | 302 |  |  | $ | 120 |  |  | $ | 680 |  |  | $ | 205 |  |
| GAAP net income |  | $ | 16,599 |  |  | $ | 14,881 |  |  | $ | 6,188 |  |  | $ | 31,480 |  |  | $ | 8,232 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 1,103 |  |  | 1,082 |  |  | 915 |  |  | 2,184 |  |  | 1,843 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (750) |  |  | (725) |  |  | (363) |  |  | (1,475) |  |  | (622) |  |
| Non-GAAP net income |  | $ | 16,952 |  |  | $ | 15,238 |  |  | $ | 6,740 |  |  | $ | 32,189 |  |  | $ | 9,453 |  |

[0001045810-24-000262:8k_2_02:75]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 30, |  | July 28, |  | July 30, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.67 |  |  | $ | 0.60 |  |  | $ | 0.25 |  |  | $ | 1.27 |  |  | $ | 0.33 |  |
|  | Non-GAAP |  | $ | 0.68 |  |  | $ | 0.61 |  |  | $ | 0.27 |  |  | $ | 1.29 |  |  | $ | 0.38 |  |
| Weighted average shares used in diluted net income per share computation |  | 24,848 |  |  | 24,890 |  |  | 24,994 |  |  | 24,869 |  |  | 24,948 |  |
| GAAP net cash provided by operating activities |  | $ | 14,489 |  |  | $ | 15,345 |  |  | $ | 6,348 |  |  | $ | 29,833 |  |  | $ | 9,259 |  |
|  | Purchases related to property and equipment and intangible assets |  | (977) |  |  | (369) |  |  | (289) |  |  | (1,346) |  |  | (537) |  |
|  | Principal payments on property and equipment and intangible assets |  | (29) |  |  | (40) |  |  | (11) |  |  | (69) |  |  | (31) |  |
| Free cash flow |  | $ | 13,483 |  |  | $ | 14,936 |  |  | $ | 6,048 |  |  | $ | 28,418 |  |  | $ | 8,691 |  |

[0001045810-24-000262:8k_2_02:76]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 30, |  | July 28, |  | July 30, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Cost of revenue |  | $ | 118 |  |  | $ | 119 |  |  | $ | 119 |  |  | $ | 238 |  |  | $ | 239 |  |
|  | Research and development |  | $ | 17 |  |  | $ | 12 |  |  | $ | 12 |  |  | $ | 30 |  |  | $ | 24 |  |
|  | Sales, general and administrative |  | $ | 9 |  |  | $ | 8 |  |  | $ | 6 |  |  | $ | 18 |  |  | $ | 48 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 30, |  | July 28, |  | July 30, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Cost of revenue |  | $ | 40 |  |  | $ | 36 |  |  | $ | 31 |  |  | $ | 75 |  |  | $ | 58 |  |
|  | Research and development |  | $ | 832 |  |  | $ | 727 |  |  | $ | 600 |  |  | $ | 1,559 |  |  | $ | 1,124 |  |
|  | Sales, general and administrative |  | $ | 282 |  |  | $ | 248 |  |  | $ | 211 |  |  | $ | 530 |  |  | $ | 394 |  |
| (C) Other consists of IP-related costs and assets held for sale related adjustments. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-24-000262:8k_2_02:77]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2025 |
|  |  |  | Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 74.4 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.6 | % |
| Non-GAAP gross margin |  | 75.0 | % |
| GAAP operating expenses |  | $ | 4,250 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,250) |  |
| Non-GAAP operating expenses |  | $ | 3,000 |  |
