# NVDA note change history — 0001045810-24-000124 → 0001045810-24-000264


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2024-08-28):
[0001045810-24-000264:note_history:1]
As of July 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $27.8 billion, an increase from the prior year due to commitments for Hopper and Blackwell capacity and components. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $12.0 billion, including $9.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

- changed (2024-08-28):
[0001045810-24-000264:note_history:2]
Total future purchase commitments as of July 28, 2024 are as follows:
  (was, 2024-05-29, similarity 0.9457):
[0001045810-24-000124:note_history:2]
Total future purchase commitments as of April 28, 2024 are as follows:

- added (2024-08-28):
[0001045810-24-000264:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first half of fiscal year 2025) | $ | 21,934 |  |
| 2026 | 10,671 |  |
| 2027 | 2,778 |  |
| 2028 | 2,436 |  |
| 2029 | 1,543 |  |
| 2030 and thereafter | 419 |  |
| Total | $ | 39,781 |  |

- changed (2024-08-28):
[0001045810-24-000264:note_history:4]
The estimated amount of product warranty liabilities was $741 million and $306 million as of July 28, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:
  (was, 2024-05-29, similarity 0.9791):
[0001045810-24-000124:note_history:4]
The estimated amount of product warranty liabilities was $532 million and $306 million as of April 28, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:

- changed (2024-08-28):
[0001045810-24-000264:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 532 |  |  | $ | 77 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 237 |  |  | 42 |  |  | 471 |  |  | 55 |  |
| Utilization | (28) |  |  | (4) |  |  | (36) |  |  | (22) |  |
| Balance at end of period | $ | 741 |  |  | $ | 115 |  |  | $ | 741 |  |  | $ | 115 |  |
  (was, 2024-05-29, similarity 0.7443):
[0001045810-24-000124:note_history:5]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 306 |  |  | $ | 82 |  |  |  |  |  |
| Additions | 234 |  |  | 13 |  |  |  |  |  |
| Utilization | (8) |  |  | (18) |  |  |  |  |  |
| Balance at end of period | $ | 532 |  |  | $ | 77 |  |  |  |  |  |

- changed (2024-08-28):
[0001045810-24-000264:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. Four amicus briefs were filed in support of NVIDIA's petition. Oral arguments are scheduled for November 13, 2024.
  (was, 2024-05-29, similarity 0.9458):
[0001045810-24-000124:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. Four amicus briefs in support of NVIDIA’s petition were filed on April 5, 2024.

- added (2024-08-28):
[0001045810-24-000264:note_history:7]
As of July 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2024-08-28):
[0001045810-24-000124:note_history:8]
As of April 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $18.8 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. These changes may result in costs incurred through the date of cancellation. Other non-inventory purchase obligations were $10.6 billion, including $8.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

- removed (2024-08-28):
[0001045810-24-000124:note_history:9]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first quarter of fiscal year 2025) | $ | 19,306 |  |
| 2026 | 3,438 |  |
| 2027 | 2,573 |  |
| 2028 | 2,222 |  |
| 2029 | 1,585 |  |
| 2030 and thereafter | 249 |  |
| Total | $ | 29,373 |  |

- removed (2024-08-28):
[0001045810-24-000124:note_history:10]
In addition to the purchase commitments included in the table above, at the end of the first quarter of fiscal year 2025, we had commitments of approximately $1.2 billion to complete business combinations, subject to closing conditions, and acquire land and buildings.

- removed (2024-08-28):
[0001045810-24-000124:note_history:11]
As of April 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-28):
[0001045810-24-000264:note_history:12]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2024 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair presentation of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024.
  (was, 2024-05-29, similarity 0.9908):
[0001045810-24-000124:note_history:12]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2024 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024.

- added (2024-08-28):
[0001045810-24-000264:note_history:13]
In May 2024, we announced a ten-for-one stock split, or the Stock Split, of our issued common stock, which was effected through the filing of an amendment to the Company's Restated Certificate of Incorporation, or the Amendment, with the Secretary of the State of Delaware. In June 2024, the Company filed the Amendment to effect the Stock Split and proportionately increased the number of shares of the Company’s authorized common stock from 8.0 billion to 80.0 billion. Shareholders of record at the close of market on June 6, 2024 received nine additional shares of common stock, distributed after the close of market on June 7, 2024. All share, equity award and per share amounts presented herein have been retrospectively adjusted to reflect the Stock Split.

- changed (2024-08-28):
[0001045810-24-000264:note_history:14]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The second quarters of fiscal years 2025 and 2024 were both 13-week quarters.
  (was, 2024-05-29, similarity 0.9759):
[0001045810-24-000124:note_history:14]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The first quarters of fiscal years 2025 and 2024 were both 13-week quarters.

- changed (2024-08-28):
[0001045810-24-000264:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, other contingencies, property, plant, and equipment, revenue recognition, and stock-based compensation. These estimates are based on historical facts and other assumptions that we believe are reasonable.
  (was, 2024-05-29, similarity 0.7267):
[0001045810-24-000124:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories and product purchase commitments, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- added (2024-08-28):
[0001045810-24-000264:note_history:16]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of significant expenses in operating segments. We expect to adopt this standard in our annual reporting starting with fiscal year 2025. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- changed (2024-08-28):
[0001045810-24-000264:note_history:17]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.
  (was, 2024-05-29, similarity 0.7798):
[0001045810-24-000124:note_history:17]
In December 2023, the FASB issued a new accounting standard which provides for new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- removed (2024-08-28):
[0001045810-24-000124:note_history:18]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard to provide for additional disclosures about significant expenses in operating segments. The standard is effective for our annual reporting starting with fiscal year 2025 and for interim period reporting starting in fiscal year 2026 retrospectively. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-08-28):
[0001045810-24-000264:note_history:19]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,461 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,461 |  |  | $ | 8,459 |  |

- added (2024-08-28):
[0001045810-24-000264:note_history:20]
(1) We repaid the 0.584% Notes Due 2024 in the second quarter of fiscal year 2025.

- changed (2024-08-28):
[0001045810-24-000264:note_history:21]
As of July 28, 2024, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2024-05-29, similarity 0.9237):
[0001045810-24-000124:note_history:21]
As of April 28, 2024, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2024-08-28):
[0001045810-24-000264:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2024, we had no commercial paper outstanding.
  (was, 2024-05-29, similarity 0.9749):
[0001045810-24-000124:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2024, we had no commercial paper outstanding.

- removed (2024-08-28):
[0001045810-24-000124:note_history:23]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 |  | 0.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 9,710 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,460 |  |  | $ | 8,459 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-28):
[0001045810-24-000264:note_history:24]
|  | Jul 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,051 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | 14,083 |  |  | $ | 2,132 |  |  | $ | 11,951 |  |
| Corporate debt securities | 11,994 |  |  | 37 |  |  | (7) |  |  | 12,024 |  |  | 682 |  |  | 11,342 |  |
| Money market funds | 5,252 |  |  | — |  |  | — |  |  | 5,252 |  |  | 5,252 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,461 |  |  | 7 |  |  | (2) |  |  | 2,466 |  |  | 50 |  |  | 2,416 |  |
| Certificates of deposit | 141 |  |  | — |  |  | — |  |  | 141 |  |  | 32 |  |  | 109 |  |
| Total marketable securities with fair value adjustments recorded in other comprehensive income | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 33,966 |  |  | $ | 8,148 |  |  | $ | 25,818 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | $ | 419 |  |  | $ | — |  |  | $ | 419 |  |
| Total | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 34,385 |  |  | $ | 8,148 |  |  | $ | 26,237 |  |
  (was, 2024-05-29, similarity 0.6898):
[0001045810-24-000124:note_history:24]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

- added (2024-08-28):
[0001045810-24-000264:note_history:25]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. In the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

- changed (2024-08-28):
[0001045810-24-000264:note_history:26]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total marketable securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |
  (was, 2024-05-29, similarity 0.9176):
[0001045810-24-000124:note_history:26]
|  | Apr 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 11,397 |  |  | $ | 3 |  |  | $ | (43) |  |  | $ | 11,357 |  |  | $ | 733 |  |  | $ | 10,624 |  |
| Debt securities issued by the U.S. Treasury | 11,314 |  |  | — |  |  | (62) |  |  | 11,252 |  |  | 886 |  |  | 10,366 |  |
| Money market funds | 5,374 |  |  | — |  |  | — |  |  | 5,374 |  |  | 5,374 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,826 |  |  | — |  |  | (7) |  |  | 2,819 |  |  | 189 |  |  | 2,630 |  |
| Certificates of deposit | 286 |  |  | — |  |  | — |  |  | 286 |  |  | 69 |  |  | 217 |  |
| Foreign government bonds | 14 |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 31,211 |  |  | $ | 3 |  |  | $ | (112) |  |  | $ | 31,102 |  |  | $ | 7,251 |  |  | $ | 23,851 |  |

- changed (2024-08-28):
[0001045810-24-000264:note_history:27]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.
  (was, 2024-05-29, similarity 0.9028):
[0001045810-24-000124:note_history:27]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

- added (2024-08-28):
[0001045810-24-000264:note_history:28]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,535 |  |  | $ | 15,532 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 18,364 |  |  | 18,434 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 33,899 |  |  | $ | 33,966 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |

- removed (2024-08-28):
[0001045810-24-000124:note_history:29]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,811 |  |  | $ | 16,800 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 14,400 |  |  | 14,302 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 31,211 |  |  | $ | 31,102 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-28):
[0001045810-24-000264:note_history:30]
Cash Equivalents and Marketable Securities 
The following is a summary of cash equivalents and marketable securities:
  (was, 2024-05-29, similarity 0.7725):
[0001045810-24-000124:note_history:30]
The following is a summary of cash equivalents and marketable securities:

- changed (2024-08-28):
[0001045810-24-000264:note_history:31]
|  | Jul 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,051 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | 14,083 |  |  | $ | 2,132 |  |  | $ | 11,951 |  |
| Corporate debt securities | 11,994 |  |  | 37 |  |  | (7) |  |  | 12,024 |  |  | 682 |  |  | 11,342 |  |
| Money market funds | 5,252 |  |  | — |  |  | — |  |  | 5,252 |  |  | 5,252 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,461 |  |  | 7 |  |  | (2) |  |  | 2,466 |  |  | 50 |  |  | 2,416 |  |
| Certificates of deposit | 141 |  |  | — |  |  | — |  |  | 141 |  |  | 32 |  |  | 109 |  |
| Total marketable securities with fair value adjustments recorded in other comprehensive income | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 33,966 |  |  | $ | 8,148 |  |  | $ | 25,818 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | $ | 419 |  |  | $ | — |  |  | $ | 419 |  |
| Total | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 34,385 |  |  | $ | 8,148 |  |  | $ | 26,237 |  |
  (was, 2024-05-29, similarity 0.6898):
[0001045810-24-000124:note_history:31]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

- added (2024-08-28):
[0001045810-24-000264:note_history:32]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. In the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

- added (2024-08-28):
[0001045810-24-000264:note_history:33]
For the second quarter and first half of fiscal year 2025, net unrealized gains on investments in publicly-held equity securities were $132 million and $181 million, respectively. For the second quarter and first half of fiscal year 2024, net unrealized gains on investments in publicly-held equity securities were not significant.

- changed (2024-08-28):
[0001045810-24-000264:note_history:34]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total marketable securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |
  (was, 2024-05-29, similarity 0.9176):
[0001045810-24-000124:note_history:34]
|  | Apr 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 11,397 |  |  | $ | 3 |  |  | $ | (43) |  |  | $ | 11,357 |  |  | $ | 733 |  |  | $ | 10,624 |  |
| Debt securities issued by the U.S. Treasury | 11,314 |  |  | — |  |  | (62) |  |  | 11,252 |  |  | 886 |  |  | 10,366 |  |
| Money market funds | 5,374 |  |  | — |  |  | — |  |  | 5,374 |  |  | 5,374 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,826 |  |  | — |  |  | (7) |  |  | 2,819 |  |  | 189 |  |  | 2,630 |  |
| Certificates of deposit | 286 |  |  | — |  |  | — |  |  | 286 |  |  | 69 |  |  | 217 |  |
| Foreign government bonds | 14 |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 31,211 |  |  | $ | 3 |  |  | $ | (112) |  |  | $ | 31,102 |  |  | $ | 7,251 |  |  | $ | 23,851 |  |

- changed (2024-08-28):
[0001045810-24-000264:note_history:35]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:
  (was, 2024-05-29, similarity 0.9867):
[0001045810-24-000124:note_history:35]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- changed (2024-08-28):
[0001045810-24-000264:note_history:36]
|  | Jul 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by U.S. government agencies | $ | 4,031 |  |  | $ | (8) |  |  | $ | 857 |  |  | $ | (2) |  |  | $ | 4,888 |  |  | $ | (10) |  |
| Corporate debt securities | 3,170 |  |  | (5) |  |  | 396 |  |  | (2) |  |  | 3,566 |  |  | (7) |  |
| Debt securities issued by the U.S. Treasury | 1,210 |  |  | (1) |  |  | 117 |  |  | (1) |  |  | 1,327 |  |  | (2) |  |
| Total | $ | 8,411 |  |  | $ | (14) |  |  | $ | 1,370 |  |  | $ | (5) |  |  | $ | 9,781 |  |  | $ | (19) |  |
  (was, 2024-05-29, similarity 0.7318):
[0001045810-24-000124:note_history:36]
|  | Apr 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 9,720 |  |  | $ | (60) |  |  | $ | 756 |  |  | $ | (2) |  |  | $ | 10,476 |  |  | $ | (62) |  |
| Corporate debt securities | 6,943 |  |  | (42) |  |  | 188 |  |  | (1) |  |  | 7,131 |  |  | (43) |  |
| Debt securities issued by U.S. government agencies | 2,391 |  |  | (7) |  |  | — |  |  | — |  |  | 2,391 |  |  | (7) |  |
| Total | $ | 19,054 |  |  | $ | (109) |  |  | $ | 944 |  |  | $ | (3) |  |  | $ | 19,998 |  |  | $ | (112) |  |

- changed (2024-08-28):
[0001045810-24-000264:note_history:37]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.
  (was, 2024-05-29, similarity 0.7285):
[0001045810-24-000124:note_history:37]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

- changed (2024-08-28):
[0001045810-24-000264:note_history:38]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.
  (was, 2024-05-29, similarity 0.9028):
[0001045810-24-000124:note_history:38]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

- added (2024-08-28):
[0001045810-24-000264:note_history:39]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,535 |  |  | $ | 15,532 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 18,364 |  |  | 18,434 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 33,899 |  |  | $ | 33,966 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |

- removed (2024-08-28):
[0001045810-24-000124:note_history:40]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to publicly held debt securities are classified as “available-for-sale” debt securities.

- removed (2024-08-28):
[0001045810-24-000124:note_history:41]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,811 |  |  | $ | 16,800 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 14,400 |  |  | 14,302 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 31,211 |  |  | $ | 31,102 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-08-28):
[0001045810-24-000264:note_history:42]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,461 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,461 |  |  | $ | 8,459 |  |

- added (2024-08-28):
[0001045810-24-000264:note_history:43]
(1) We repaid the 0.584% Notes Due 2024 in the second quarter of fiscal year 2025.

- removed (2024-08-28):
[0001045810-24-000124:note_history:44]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 |  | 0.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 9,710 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,460 |  |  | $ | 8,459 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-08-28):
[0001045810-24-000124:note_history:45]
Subsequent Events
On May 22, 2024, we announced a ten-for-one forward stock split, or the Stock Split, of our issued common stock to be effected through the filing of an amendment to our Restated Certificate of Incorporation, or the Amendment, with the Secretary of the State of Delaware. The Amendment will result in a proportionate increase in the number of shares of authorized common stock. As a result of the Stock Split, each record holder of common stock as of the close of market on June 6, 2024 will receive nine additional shares of common stock, to be distributed after the close of market on June 7, 2024. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the Stock Split as if it had been effective for all periods presented:

- removed (2024-08-28):
[0001045810-24-000124:note_history:46]
|  | Pro Forma (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 14,881 |  |  | $ | 2,043 |  |  | $ | 29,760 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,620 |  |  | 24,700 |  |  | 24,690 |  |  | 24,870 |  |  | 24,960 |  |
| Dilutive impact of outstanding equity awards | 270 |  |  | 200 |  |  | 250 |  |  | 200 |  |  | 390 |  |
| Diluted weighted average shares | 24,890 |  |  | 24,900 |  |  | 24,940 |  |  | 25,070 |  |  | 25,350 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.60 |  |  | $ | 0.08 |  |  | $ | 1.21 |  |  | $ | 0.18 |  |  | $ | 0.39 |  |
| Diluted (2) | $ | 0.60 |  |  | $ | 0.08 |  |  | $ | 1.19 |  |  | $ | 0.17 |  |  | $ | 0.38 |  |

- removed (2024-08-28):
[0001045810-24-000124:note_history:47]
(1)       Calculated as net income divided by basic weighted average shares.

- removed (2024-08-28):
[0001045810-24-000124:note_history:48]
(2)       Calculated as net income divided by diluted weighted average shares.

- removed (2024-08-28):
[0001045810-24-000124:note_history:49]
On May 22, 2024, we also announced an increase in our quarterly cash dividend by 150% from $0.04 per share to $0.10 per share of common stock. The increased dividend is equivalent to $0.01 per share on a post-Stock Split basis and will be paid on June 28, 2024, to all shareholders of record on June 11, 2024.
