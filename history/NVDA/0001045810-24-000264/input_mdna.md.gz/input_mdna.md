# NVDA MD&A — 0001045810-24-000264


## mdna

[0001045810-24-000264:mdna:1]
[same as prior period, unchanged from 0001045810-24-000124:mdna:1]

[0001045810-24-000264:mdna:2]
[same as prior period, unchanged from 0001045810-24-000124:mdna:2]

[0001045810-24-000264:mdna:3]
[same as prior period, unchanged from 0001045810-24-000124:mdna:3]

[0001045810-24-000264:mdna:4]
[same as prior period, unchanged from 0001045810-24-000124:mdna:4]

[0001045810-24-000264:mdna:5]
[same as prior period, unchanged from 0001045810-24-000124:mdna:5]

[0001045810-24-000264:mdna:6]
[same as prior period, unchanged from 0001045810-24-000124:mdna:6]

[0001045810-24-000264:mdna:7]
[same as prior period, unchanged from 0001045810-24-000124:mdna:7]

[0001045810-24-000264:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, and 3D internet applications. Our two operating segments are "Compute & Networking" and "Graphics," as described in Note 14 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001045810-24-000264:mdna:9]
[same as prior period, unchanged from 0001045810-24-000124:mdna:9]

[0001045810-24-000264:mdna:10]
[same as prior period, unchanged from 0001045810-24-000124:mdna:10]

[0001045810-24-000264:mdna:11]
Demand and Supply

[0001045810-24-000264:mdna:12]
Revenue growth in the second quarter of fiscal year 2025 was driven by data center compute platforms and networking for accelerated computing and AI solutions. Hopper architecture demand is strong, and shipments are expected to increase in the second half of fiscal 2025. We shipped customer samples of our Blackwell architecture in the second quarter. We executed a change to the Blackwell GPU mask to improve production yield. Blackwell production ramp is scheduled to begin in the fourth quarter and continue into fiscal year 2026. In the fourth quarter of fiscal year 2025, we expect to ship several billion dollars in Blackwell revenue.

[0001045810-24-000264:mdna:13]
Demand estimates for our new products, applications, and services can be incorrect and create volatility in our revenue or supply levels. We may not be able to generate significant revenue from them. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for Data Center, the long-term trajectory is unknown.

[0001045810-24-000264:mdna:14]
We continue to increase our supply and capacity purchases with existing and new suppliers to support our demand projections. With these additions, we have also entered and may continue to enter into prepaid manufacturing and capacity agreements to supply both current and future products. The increased purchase volumes and integration of new suppliers and contract manufacturers into our supply chain may create more complexity in managing multiple suppliers with variations in production planning, execution and logistics. Our expanding product portfolio and varying component compatibility and quality may lead to increased inventory levels. We have incurred and may in the future incur inventory

[0001045810-24-000264:mdna:15]
provisions or impairments if our inventory or supply or capacity commitments exceed demand for our products or demand declines.

[0001045810-24-000264:mdna:16]
Product Transitions and New Product Introductions

[0001045810-24-000264:mdna:17]
Product transitions are complex and we often ship both new and prior architecture products simultaneously as our channel partners prepare to ship and support new products. We may be in various stages of transitioning the architectures of our Data Center, Gaming, Professional Visualization and Automotive products. The computing industry is experiencing a broader and faster launch cadence of accelerated computing platforms to meet a growing and diverse set of AI opportunities. We have introduced a new cadence of our Data Center architectures where we seek to complete a new GPU computing architecture each year and we are providing a greater variety of Data Center offerings. The increased frequency of these transitions and the larger number of products and product configurations may magnify the challenges associated with managing our supply and demand which may create volatility in our revenue. The increased frequency and complexity of newly introduced products could result in quality or production issues that could increase inventory provisions, warranty, or other costs or result in product delays. We incur significant engineering development resources for new products, and changes to our product roadmap may impact our ability to develop other products or adequately manage our supply chain cost. Customers may delay purchasing existing products as we increase the frequency of new products or may not be able to adopt our new products as fast as forecasted, both impacting the timing of our revenue and supply chain cost. While we have managed prior product transitions and have sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and may cause us to incur additional costs. For example, we executed a change to the Blackwell GPU mask to improve production yield. Our gross margins in the second quarter of fiscal year 2025 were negatively impacted by inventory provisions for low-yielding Blackwell material and they may continue to be impacted in the future.

[0001045810-24-000264:mdna:18]
[same as prior period, unchanged from 0001045810-24-000124:mdna:17]

[0001045810-24-000264:mdna:19]
[same as prior period, unchanged from 0001045810-24-000124:mdna:18]

[0001045810-24-000264:mdna:20]
[same as prior period, unchanged from 0001045810-24-000124:mdna:19]

[0001045810-24-000264:mdna:21]
In October 2023, the USG announced new and updated licensing requirements that became effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products. We have not received licenses to ship these restricted products to China. Additionally, partners and customers have experienced delays in receiving licenses or have not received a license to ship these restricted products.

[0001045810-24-000264:mdna:22]
We expanded our Data Center product portfolio to offer new solutions, including those for which the USG does not require a license or advance notice before each shipment. We ramped new products designed specifically for China that do not require an export control license. Our Data Center revenue in China grew sequentially in the second quarter of fiscal year 2025 and is a significant contributor to our Data Center revenue. As a percentage of total Data Center revenue, it remains below levels seen prior to the imposition of export controls in October 2023. To the extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer but have no assurance that the USG will grant such a license, or that the USG will act on the license application in a timely manner or at all.

[0001045810-24-000264:mdna:23]
[same as prior period, unchanged from 0001045810-24-000124:mdna:22]

[0001045810-24-000264:mdna:24]
[same as prior period, unchanged from 0001045810-24-000124:mdna:23]

[0001045810-24-000264:mdna:25]
[same as prior period, unchanged from 0001045810-24-000124:mdna:24]

[0001045810-24-000264:mdna:26]
Macroeconomic factors, including inflation, interest rate changes, capital market volatility, global supply chain constraints and global economic and geopolitical developments, may have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors can also impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Our product and solution pricing generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-24-000264:mdna:27]
Israel and Regional Conflicts

[0001045810-24-000264:mdna:28]
We are monitoring the impact of the geopolitical conflict in and around Israel on our operations, including the health and safety of our approximately 4,000 employees in the region who primarily support the research and development, operations, and sales and marketing of our networking products. Our global supply chain for our networking products has not experienced any significant impact. A substantial number of our employees in the region have been called-up for active military duty in Israel. Some employees in Israel have been on active military duty for an extended period and may continue to be absent, which may cause disruption to our product development or operations. We have not experienced significant impact or expense to our business; however, if the conflict is further extended, it could impact future product development, operations, and revenue or create other uncertainty for our business.

[0001045810-24-000264:mdna:29]
Second Quarter of Fiscal Year 2025 Summary

[0001045810-24-000264:mdna:30]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Jul 28, 2024 |  | Apr 28, 2024 |  | Jul 30, 2023 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 30,040 |  |  | $ | 26,044 |  |  | $ | 13,507 |  |  | 15 | % |  | 122 | % |
| Gross margin | 75.1 | % |  | 78.4 | % |  | 70.1 | % |  | (3.3) pts |  | 5.0 pts |
| Operating expenses | $ | 3,932 |  |  | $ | 3,497 |  |  | $ | 2,662 |  |  | 12 | % |  | 48 | % |
| Operating income | $ | 18,642 |  |  | $ | 16,909 |  |  | $ | 6,800 |  |  | 10 | % |  | 174 | % |
| Net income | $ | 16,599 |  |  | $ | 14,881 |  |  | $ | 6,188 |  |  | 12 | % |  | 168 | % |
| Net income per diluted share | $ | 0.67 |  |  | $ | 0.60 |  |  | $ | 0.25 |  |  | 12 | % |  | 168 | % |

[0001045810-24-000264:mdna:31]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

[0001045810-24-000264:mdna:32]
Revenue was $30.0 billion, up 122% from a year ago and up 15% sequentially.

[0001045810-24-000264:mdna:33]
Data Center revenue was up 154% from a year ago and up 16% sequentially. The strong sequential and year-on-year growth was driven by demand for our Hopper GPU computing platform for training and inferencing of large language models, recommendation engines, and generative AI applications. Sequential growth was driven by consumer internet and enterprise companies. Cloud service providers represented roughly 45% of our Data Center revenue, and more than 50% stemmed from consumer internet and enterprise companies. Strong year-on-year growth was driven by all customer types from both compute and networking revenue. Customers continue to accelerate their Hopper architecture purchases while gearing up to adopt Blackwell. Data Center compute revenue was $22.6 billion, up 162% from a year ago and up 17% sequentially. Networking revenue was $3.7 billion, up 114% from a year ago driven by InfiniBand and Ethernet for AI revenue, which includes Spectrum-X end-to-end ethernet platform. Networking revenue sequentially was up 16% and includes a doubling of Ethernet for AI revenue.

[0001045810-24-000264:mdna:34]
We shipped customer samples of our Blackwell architecture in the second quarter. We executed a change to the Blackwell GPU mask to improve production yield. Blackwell production ramp is scheduled to begin in the fourth quarter and continue into fiscal year 2026. In the fourth quarter of fiscal year 2025, we expect to ship several billion dollars in Blackwell revenue. Hopper demand is strong, and shipments are expected to increase in the second half of fiscal year 2025.

[0001045810-24-000264:mdna:35]
Gaming revenue was up 16% from a year ago and up 9% sequentially. These increases reflect higher sales of our GeForce RTX 40 Series GPUs and game console SOCs. We had solid demand in the second quarter for our gaming GPUs as part of the back-to-school season.

[0001045810-24-000264:mdna:36]
Professional Visualization revenue was up 20% from a year ago and up 6% sequentially. These increases were driven by the continued ramp of RTX GPU workstations based on our Ada architecture.

[0001045810-24-000264:mdna:37]
Automotive revenue was up 37% from a year ago and up 5% sequentially. These increases were driven by AI Cockpit solutions and self-driving platforms.

[0001045810-24-000264:mdna:38]
Gross margin increased from a year ago on strong Data Center revenue growth primarily driven by our Hopper GPU computing platform. Sequentially, gross margin decreased primarily driven by inventory provisions for low-yielding Blackwell material and a higher mix of new products within Data Center.

[0001045810-24-000264:mdna:39]
Operating expenses were up 48% from a year ago and up 12% sequentially, largely driven by compensation and benefits, reflecting growth in employees and compensation.

[0001045810-24-000264:mdna:40]
[same as prior period, unchanged from 0001045810-24-000124:mdna:39]

[0001045810-24-000264:mdna:41]
Data Center revenue for the second quarter of fiscal year 2025 was $26.3 billion, up 16% from the previous quarter and up 154% from a year ago. We unveiled an array of NVIDIA Blackwell-powered systems featuring NVIDIA Grace CPUs, networking and infrastructure from top manufacturers. We announced broad adoption of the NVIDIA Spectrum-X Ethernet networking platform by cloud service providers, GPU cloud providers and enterprises, as well as partners incorporating it into their offerings. We released NVIDIA Inference Microservices, or NIM, for broad availability to developers globally and unveiled that more than 150 companies are integrating NIM into their platforms to speed generative AI application development. We introduced an NVIDIA AI Foundry service and NIM inference microservices to accelerate generative AI for the world’s enterprises with the Llama 3.1 collection of models. We announced that the combination of NVIDIA H200 and NVIDIA Blackwell architecture B200 processors swept the latest industry-standard MLPerf results for inference. We also unveiled an array of Blackwell systems featuring NVIDIA Grace CPUs, networking and infrastructure. Over the trailing four quarters, we estimate that inference drove over 40% of our Data Center revenue.

[0001045810-24-000264:mdna:42]
Gaming revenue for the second quarter of fiscal year 2025 was $2.9 billion, up 9% from the previous quarter and up 16% from a year ago. We announced NVIDIA ACE generative AI microservices are in early access for RTX AI PCs. We announced new RTX and DLSS titles bringing the total number of RTX games and apps to over 600. We surpassed 2,000 games on GeForce NOW and expanded the service into Japan.

[0001045810-24-000264:mdna:43]
Professional Visualization revenue for the second quarter of fiscal year 2025 was $454 million, up 6% from the previous quarter and up 20% from a year ago. We introduced generative AI models and NIM microservices for OpenUSD; and announced major Taiwanese electronics makers are creating more autonomous factories with a new reference workflow that combines NVIDIA Metropolis vision AI, NVIDIA Omniverse simulation and NVIDIA Isaac AI robot development.

[0001045810-24-000264:mdna:44]
Automotive revenue for the second quarter of fiscal year 2025 was $346 million, up 5% from the previous quarter and up 37% from a year ago. At the Computer Vision and Pattern Recognition conference, NVIDIA won the Autonomous Grand Challenge in the ‘End-to-End Driving at Scale’ category, highlighting the importance of generative AI in building applications for physical AI deployments in autonomous vehicle development.

[0001045810-24-000264:mdna:45]
[same as prior period, unchanged from 0001045810-24-000124:mdna:44]

[0001045810-24-000264:mdna:46]
[same as prior period, unchanged from 0001045810-24-000124:mdna:45]

[0001045810-24-000264:mdna:47]
[same as prior period, unchanged from 0001045810-24-000124:mdna:46]

[0001045810-24-000264:mdna:48]
[same as prior period, unchanged from 0001045810-24-000124:mdna:47]

[0001045810-24-000264:mdna:49]
[same as prior period, unchanged from 0001045810-24-000124:mdna:48]

[0001045810-24-000264:mdna:50]
[same as prior period, unchanged from 0001045810-24-000124:mdna:49]

[0001045810-24-000264:mdna:51]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 24.9 |  |  | 29.9 |  |  | 23.4 |  |  | 31.8 |  |
| Gross profit | 75.1 |  |  | 70.1 |  |  | 76.6 |  |  | 68.2 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 10.3 |  |  | 15.1 |  |  | 10.4 |  |  | 18.9 |  |
| Sales, general and administrative | 2.8 |  |  | 4.7 |  |  | 2.9 |  |  | 6.1 |  |
| Total operating expenses | 13.1 |  |  | 19.8 |  |  | 13.3 |  |  | 25.0 |  |
| Operating income | 62.0 |  |  | 50.3 |  |  | 63.3 |  |  | 43.2 |  |
| Interest income | 1.5 |  |  | 1.4 |  |  | 1.4 |  |  | 1.6 |  |
| Interest expense | (0.2) |  |  | (0.5) |  |  | (0.2) |  |  | (0.6) |  |
| Other, net | 0.6 |  |  | 0.4 |  |  | 0.5 |  |  | 0.2 |  |
| Other income (expense), net | 1.9 |  |  | 1.3 |  |  | 1.7 |  |  | 1.2 |  |
| Income before income tax | 63.9 |  |  | 51.6 |  |  | 65.0 |  |  | 44.4 |  |
| Income tax expense | 8.7 |  |  | 5.9 |  |  | 8.9 |  |  | 4.6 |  |
| Net income | 55.2 | % |  | 45.7 | % |  | 56.1 | % |  | 39.8 | % |

[0001045810-24-000264:mdna:52]
[same as prior period, unchanged from 0001045810-24-000124:mdna:51]

[0001045810-24-000264:mdna:53]
[same as prior period, unchanged from 0001045810-24-000124:mdna:52]

[0001045810-24-000264:mdna:54]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | %Change |  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 26,446 |  |  | $ | 10,402 |  |  | $ | 16,044 |  |  | 154 | % |  | $ | 49,121 |  |  | $ | 14,862 |  |  | $ | 34,259 |  |  | 231 | % |
| Graphics | 3,594 |  |  | 3,105 |  |  | 489 |  |  | 16 | % |  | 6,963 |  |  | 5,837 |  |  | 1,126 |  |  | 19 | % |
| Total | $ | 30,040 |  |  | $ | 13,507 |  |  | $ | 16,533 |  |  | 122 | % |  | $ | 56,084 |  |  | $ | 20,699 |  |  | $ | 35,385 |  |  | 171 | % |

[0001045810-24-000264:mdna:55]
[same as prior period, unchanged from 0001045810-24-000124:mdna:54]

[0001045810-24-000264:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | %Change |  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 18,848 |  |  | $ | 6,728 |  |  | $ | 12,120 |  |  | 180 | % |  | $ | 35,896 |  |  | $ | 8,887 |  |  | $ | 27,009 |  |  | 304 | % |
| Graphics | 1,369 |  |  | 1,211 |  |  | 158 |  |  | 13 | % |  | $ | 2,609 |  |  | 2,258 |  |  | 351 |  |  | 16 | % |
| All Other | (1,575) |  |  | (1,139) |  |  | (436) |  |  | 38 | % |  | $ | (2,954) |  |  | (2,204) |  |  | (750) |  |  | 34 | % |
| Total | $ | 18,642 |  |  | $ | 6,800 |  |  | $ | 11,842 |  |  | 174 | % |  | $ | 35,551 |  |  | $ | 8,941 |  |  | $ | 26,610 |  |  | 298 | % |

[0001045810-24-000264:mdna:57]
Compute & Networking revenue – The increase in the second quarter and first half of fiscal year 2025 compared to the second quarter and first half of fiscal year 2024 was due to strength in Data Center computing and networking for accelerated computing and AI solutions. Revenue from GPU computing grew 166% year-on-year and 257% compared to the first half of fiscal year 2024, was driven by demand for our Hopper GPU architecture computing platform for training and inferencing of large language models, recommendation engines, and generative AI applications. Networking was also up 114% year-on-year and 159% compared to the first half of last year driven by both InfiniBand and Ethernet for AI revenue.

[0001045810-24-000264:mdna:58]
28

[0001045810-24-000264:mdna:59]
Graphics revenue – The increase in the second quarter and first half of fiscal year 2025 compared to the second quarter and first half of fiscal year 2024 was led by higher sales of our GeForce RTX 40 Series GPUs.

[0001045810-24-000264:mdna:60]
Reportable segment operating income – The increase in the second quarter and first half of fiscal year 2025 compared to the second quarter and first half of fiscal year 2024 in Compute & Networking and Graphics operating income was driven by higher revenue.

[0001045810-24-000264:mdna:61]
All Other operating loss – The increase in the second quarter and first half of fiscal year 2025 compared to the second quarter and first half of fiscal year 2024 was due to an increase in stock-based compensation expense reflecting employee growth and compensation increases.

[0001045810-24-000264:mdna:62]
[same as prior period, unchanged from 0001045810-24-000124:mdna:60]

[0001045810-24-000264:mdna:63]
Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to end customers, such as enterprises and gamers in a different location. Revenue from sales to customers outside of the United States accounted for 57% and 53% of total revenue for the second quarter and first half of fiscal year 2025, respectively, and 55% and 59% of total revenue for the second quarter and first half of fiscal year 2024, respectively.

[0001045810-24-000264:mdna:64]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, ODMs, OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. We also have indirect customers, who purchase products through our direct customers; indirect customers include cloud service providers, consumer internet companies, enterprises, and public sector entities.

[0001045810-24-000264:mdna:65]
Sales to direct customers which represented 10% or more of total revenue, all of which were primarily attributable to the Compute & Networking segment, are presented in the following table:

[0001045810-24-000264:mdna:66]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 28, 2024 |
| Customer A | 14 | % |  | 14 | % |
| Customer B | 11 | % |  | * |
| Customer C | 11 | % |  | * |
| Customer D | 10 | % |  | 10 | % |
| Customer E | * |  | 10 | % |

[0001045810-24-000264:mdna:67]
* Less than 10% of total revenue

[0001045810-24-000264:mdna:68]
For the second quarter of fiscal year 2025, two indirect customers which primarily purchase our products through system integrators and distributors, including through Customer B and Customer E, are estimated to each represent 10% or more of total revenue attributable to the Compute & Networking segment.

[0001045810-24-000264:mdna:69]
For the first half of fiscal year 2025, an indirect customer which primarily purchases our products from system integrators and distributors, including from Customer E, is estimated to represent 10% or more of total revenue, attributable to the Compute & Networking segment.

[0001045810-24-000264:mdna:70]
Indirect customer revenue is an estimation based upon multiple factors including customer purchase order information, product specifications, internal sales data and other sources. Actual indirect customer revenue may differ from our estimates.

[0001045810-24-000264:mdna:71]
We have experienced periods where we receive a significant amount of our revenue from a limited number of customers, and this trend may continue.

[0001045810-24-000264:mdna:72]
[same as prior period, unchanged from 0001045810-24-000124:mdna:66]

[0001045810-24-000264:mdna:73]
[same as prior period, unchanged from 0001045810-24-000124:mdna:67]

[0001045810-24-000264:mdna:74]
Our overall gross margin increased to 75.1% and 76.6% for the second quarter and first half of fiscal year 2025, respectively, from 70.1% and 68.2% for the second quarter and first half of fiscal year 2024, respectively. The increases in the second quarter and first half of fiscal year 2025 compared to the second quarter and first half of fiscal year 2024 were primarily due to strong Data Center revenue growth of 154% and 234% for the second quarter and first half of 2025, respectively.

[0001045810-24-000264:mdna:75]
Provisions for inventory and excess inventory purchase obligations totaled $908 million and $1.3 billion for the second quarter and first half of fiscal year 2025, respectively, and were primarily due to low-yielding Blackwell material. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $85 million and $199 million for the second quarter and first half of fiscal year 2025, respectively. The net effect on our

[0001045810-24-000264:mdna:76]
[same as prior period, unchanged from 0001045810-24-000124:mdna:100]

[0001045810-24-000264:mdna:77]
gross margin was an unfavorable impact of 2.7% and 2.0% in the second quarter and first half of fiscal year 2025, respectively.

[0001045810-24-000264:mdna:78]
Provisions for inventory and excess inventory purchase obligations totaled $576 million and $709 million for the second quarter and first half of fiscal year 2024, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $84 million and $134 million for the second quarter and first half of fiscal year 2024, respectively. The net effect on our gross margin was an unfavorable impact of 3.6% and 2.8% in the second quarter and first half of fiscal year 2024, respectively.

[0001045810-24-000264:mdna:79]
We expect our Data Center mix to continue to shift to new products in the second half of fiscal year 2025. For fiscal year 2025, we expect gross margins to be in the mid-70% range.

[0001045810-24-000264:mdna:80]
[same as prior period, unchanged from 0001045810-24-000124:mdna:71]

[0001045810-24-000264:mdna:81]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | %Change |  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 3,090 |  |  | $ | 2,040 |  |  | $ | 1,050 |  |  | 51 | % |  | $ | 5,810 |  |  | $ | 3,916 |  |  | $ | 1,894 |  |  | 48 | % |
| % of net revenue | 10.3 | % |  | 15.1 | % |  |  |  |  |  | 10.4 | % |  | 18.9 | % |  |  |  |  |
| Sales, general and administrative expenses | 842 |  |  | 622 |  |  | 220 |  |  | 35 | % |  | 1,618 |  |  | 1,253 |  |  | 365 |  |  | 29 | % |
| % of net revenue | 2.8 | % |  | 4.7 | % |  |  |  |  |  | 2.9 | % |  | 6.1 | % |  |  |  |  |
| Total operating expenses | $ | 3,932 |  |  | $ | 2,662 |  |  | $ | 1,270 |  |  | 48 | % |  | $ | 7,428 |  |  | $ | 5,169 |  |  | $ | 2,259 |  |  | 44 | % |
| % of net revenue | 13.1 | % |  | 19.8 | % |  |  |  |  |  | 13.3 | % |  | 25.0 | % |  |  |  |  |

[0001045810-24-000264:mdna:82]
The increases in research and development expenses for the second quarter and first half of fiscal year 2025 were driven by 35% and 34% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, and 118% and 117% increase in compute and infrastructure investments, respectively.

[0001045810-24-000264:mdna:83]
The increases in sales, general and administrative expenses for the second quarter and first half of fiscal year 2025 was primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-24-000264:mdna:84]
For fiscal year 2025, we expect operating expenses to grow in the mid to upper 40% range as we work on developing our next generation of products.

[0001045810-24-000264:mdna:85]
[same as prior period, unchanged from 0001045810-24-000124:mdna:76]

[0001045810-24-000264:mdna:86]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |  | Jul 28, 2024 |  | Jul 30, 2023 |  | $Change |
|  | ($ in millions) |
| Interest income | $ | 444 |  |  | $ | 187 |  |  | $ | 257 |  |  | $ | 803 |  |  | $ | 338 |  |  | $ | 465 |  |
| Interest expense | (61) |  |  | (65) |  |  | 4 |  |  | (125) |  |  | (131) |  |  | 6 |  |
| Other, net | 189 |  |  | 59 |  |  | 130 |  |  | 264 |  |  | 42 |  |  | 222 |  |
| Other income (expense), net | $ | 572 |  |  | $ | 181 |  |  | $ | 391 |  |  | $ | 942 |  |  | $ | 249 |  |  | $ | 693 |  |

[0001045810-24-000264:mdna:87]
The increases in interest income for the second quarter and first half of fiscal year 2025 was due to higher cash, cash equivalents, and publicly-held debt security balances.

[0001045810-24-000264:mdna:88]
[same as prior period, unchanged from 0001045810-24-000124:mdna:79]

[0001045810-24-000264:mdna:89]
Other, net consists of realized or unrealized gains and losses from investments in privately-held equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other, net, compared to the second quarter and first half of fiscal year 2024 was primarily driven by an increase in fair value of our privately-held and publicly-held equity securities. Refer to Note 6 and 7 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding our investments in privately-held and publicly-held equity securities.

[0001045810-24-000264:mdna:90]
[same as prior period, unchanged from 0001045810-24-000124:mdna:81]

[0001045810-24-000264:mdna:91]
We recognized income tax expense of $2.6 billion and $5.0 billion for the second quarter and first half of fiscal year 2025, respectively, and $793 million and $958 million for the second quarter and first half of fiscal year 2024, respectively. Income tax expense as a percentage of income before income tax was 13.6% and 13.7% for the second quarter and first half of fiscal year 2025, respectively, and 11.4% and 10.4% for the second quarter and first half of fiscal year 2024, respectively.

[0001045810-24-000264:mdna:92]
The effective tax rate increased primarily due to a lower percentage of tax benefits from the foreign-derived intangible income deduction relative to the increase in income before income tax.

[0001045810-24-000264:mdna:93]
Given our current and anticipated future earnings, we believe that we may release the valuation allowance associated with certain state deferred tax assets in the near term, which would decrease our income tax expense for the period the release is recorded. The timing and amount of the valuation allowance release could vary based on our assessment of all available evidence.

[0001045810-24-000264:mdna:94]
[same as prior period, unchanged from 0001045810-24-000124:mdna:84]

[0001045810-24-000264:mdna:95]
[same as prior period, unchanged from 0001045810-24-000124:mdna:85]

[0001045810-24-000264:mdna:96]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | (In millions) |
| Cash and cash equivalents | $ | 8,563 |  |  | $ | 7,280 |  |
| Marketable securities | 26,237 |  |  | 18,704 |  |
| Cash, cash equivalents and marketable securities | $ | 34,800 |  |  | $ | 25,984 |  |

[0001045810-24-000264:mdna:97]
|  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 29,833 |  |  | $ | 9,259 |  |
| Net cash used in investing activities | $ | (8,877) |  |  | $ | (1,287) |  |
| Net cash used in financing activities | $ | (19,665) |  |  | $ | (5,479) |  |

[0001045810-24-000264:mdna:98]
Our investment policy requires the purchase of high-rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-24-000264:mdna:99]
Cash provided by operating activities increased in the first half of fiscal year 2025 compared to the first half of fiscal year 2024 due to growth in revenue, partially offset by higher tax payments. Our accounts receivable balance at the end of the first half of fiscal year 2025 reflects the strong revenue growth, partially offset by $2.8 billion from customer payments received prior to the invoice due date.

[0001045810-24-000264:mdna:100]
Cash used in investing activities increased in the first half of fiscal year 2025 compared to the first half of fiscal year 2024, primarily driven by net purchases of marketable securities, and acquisition of land and buildings.

[0001045810-24-000264:mdna:101]
Cash used in financing activities increased in the first half of fiscal year 2025 compared to the first half of fiscal year 2024, mainly due to higher share repurchases and higher tax payments related to RSUs.

[0001045810-24-000264:mdna:102]
[same as prior period, unchanged from 0001045810-24-000124:mdna:92]

[0001045810-24-000264:mdna:103]
Our primary sources of liquidity include cash, cash equivalents, and marketable securities, and the cash generated by our operations. As of July 28, 2024, we had $34.8 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations and share repurchases. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-24-000264:mdna:104]
Our marketable securities consist of publicly-held equity securities, debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. Our corporate debt securities are publicly traded. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-24-000264:mdna:105]
Except for approximately $1.4 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. as of July 28, 2024 are available for use in the U.S. without incurring additional U.S. federal income taxes.

[0001045810-24-000264:mdna:106]
Payment from customers, per our standard payment terms, is generally due shortly after delivery of products, availability of software licenses or commencement of services.

[0001045810-24-000264:mdna:107]
[same as prior period, unchanged from 0001045810-24-000124:mdna:96]

[0001045810-24-000264:mdna:108]
During the second quarter and first half of fiscal year 2025, we paid $246 million and $344 million, respectively, in quarterly cash dividends.

[0001045810-24-000264:mdna:109]
[same as prior period, unchanged from 0001045810-24-000124:mdna:98]

[0001045810-24-000264:mdna:110]
On June 7, 2024, we increased our quarterly cash dividend to $0.01 per share on a post-Stock Split basis to all shareholders of record on June 11, 2024. Our quarterly cash dividend was paid on June 28, 2024.

[0001045810-24-000264:mdna:111]
During the second quarter and first half of fiscal year 2025, we repurchased 62.8 million and 162.1 million shares of our common stock for $7.0 billion and $15.1 billion, respectively. As of July 28, 2024, we were authorized, subject to certain specifications, to repurchase up to $7.5 billion of our common stock. On August 26, 2024, our Board of Directors approved an additional $50.0 billion to our share repurchase authorization, without expiration. As of August 26, 2024, a total of $53.9 billion was available for repurchase. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities. We plan to continue share repurchases this fiscal year.

[0001045810-24-000264:mdna:112]
From April 29, 2024 through August 26, 2024, we repurchased 31.5 million shares for $3.6 billion pursuant to a Rule 10b5-1 trading plan.

[0001045810-24-000264:mdna:113]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for the second quarter and first half of fiscal year 2025.

[0001045810-24-000264:mdna:114]
[same as prior period, unchanged from 0001045810-24-000124:mdna:105]

[0001045810-24-000264:mdna:115]
Our aggregate debt maturities as of July 28, 2024, by year payable, are as follows:

[0001045810-24-000264:mdna:116]
|  |  | Jul 28, 2024 |
|  |  | (In millions) |
| Due in one year |  | $ | — |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 2,750 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (39) |  |
| Net carrying amount |  | 8,461 |  |
| Less short-term portion |  | — |  |
| Total long-term portion |  | $ | 8,461 |  |

[0001045810-24-000264:mdna:117]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2024, no commercial paper was outstanding.

[0001045810-24-000264:mdna:118]
[same as prior period, unchanged from 0001045810-24-000124:mdna:109]

[0001045810-24-000264:mdna:119]
[same as prior period, unchanged from 0001045810-24-000124:mdna:110]

[0001045810-24-000264:mdna:120]
Unrecognized tax benefits were $1.7 billion, which includes related interest and penalties of $186 million recorded in non-current income tax payable as of July 28, 2024. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of

[0001045810-24-000264:mdna:121]
the effective settlement of such tax positions. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-24-000264:mdna:122]
[same as prior period, unchanged from 0001045810-24-000124:mdna:112]

[0001045810-24-000264:mdna:123]
[same as prior period, unchanged from 0001045810-24-000124:mdna:113]

[0001045810-24-000264:mdna:124]
[same as prior period, unchanged from 0001045810-24-000124:mdna:114]

[0001045810-24-000264:mdna:125]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-24-000264:mdna:126]
There has been no adoption of any new and recently issued accounting pronouncements.
