# NVDA 10-Q controls and the auditor's report


## item_4_controls

[0001045810-24-000264:item_4_controls:1]
Item 4. Controls and Procedures

[0001045810-24-000264:item_4_controls:2]
Controls and Procedures

[0001045810-24-000264:item_4_controls:3]
Disclosure Controls and Procedures

[0001045810-24-000264:item_4_controls:4]
Based on their evaluation as of July 28, 2024, our management, including our Chief Executive Officer and Chief Financial Officer, has concluded that our disclosure controls and procedures (as defined in Exchange Act Rule 13a-15(e) and 15d-15(e)) were effective to provide reasonable assurance that the information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC rules and forms, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosures.

[0001045810-24-000264:item_4_controls:5]
Changes in Internal Control Over Financial Reporting

[0001045810-24-000264:item_4_controls:6]
There were no changes that occurred during the second quarter of fiscal year 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. In fiscal year 2022, we began an upgrade of our enterprise resource planning, or ERP, system, which will update much of our existing core financial systems. The ERP system is designed to accurately maintain our financial records used to report operating results. The upgrade will occur in phases. We will continue to evaluate each quarter whether there are changes that materially affect our internal control over financial reporting.

[0001045810-24-000264:item_4_controls:7]
Inherent Limitations on Effectiveness of Controls

[0001045810-24-000264:item_4_controls:8]
Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.

[0001045810-24-000264:item_4_controls:9]
33
