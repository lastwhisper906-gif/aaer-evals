# NVDA notes — 0001045810-24-000264


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-24-000264:notes:1]
[same as prior period, unchanged from 0001045810-24-000124:notes:1]

[0001045810-24-000264:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2024 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair presentation of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024.

[0001045810-24-000264:notes:3]
In May 2024, we announced a ten-for-one stock split, or the Stock Split, of our issued common stock, which was effected through the filing of an amendment to the Company's Restated Certificate of Incorporation, or the Amendment, with the Secretary of the State of Delaware. In June 2024, the Company filed the Amendment to effect the Stock Split and proportionately increased the number of shares of the Company’s authorized common stock from 8.0 billion to 80.0 billion. Shareholders of record at the close of market on June 6, 2024 received nine additional shares of common stock, distributed after the close of market on June 7, 2024. All share, equity award and per share amounts presented herein have been retrospectively adjusted to reflect the Stock Split.

[0001045810-24-000264:notes:4]
[same as prior period, unchanged from 0001045810-24-000124:notes:3]

[0001045810-24-000264:notes:5]
[same as prior period, unchanged from 0001045810-24-000124:notes:4]

[0001045810-24-000264:notes:6]
[same as prior period, unchanged from 0001045810-24-000124:notes:5]

[0001045810-24-000264:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The second quarters of fiscal years 2025 and 2024 were both 13-week quarters.

[0001045810-24-000264:notes:8]
[same as prior period, unchanged from 0001045810-24-000124:notes:7]

[0001045810-24-000264:notes:9]
[same as prior period, unchanged from 0001045810-24-000124:notes:8]

[0001045810-24-000264:notes:10]
[same as prior period, unchanged from 0001045810-24-000124:notes:9]

[0001045810-24-000264:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, other contingencies, property, plant, and equipment, revenue recognition, and stock-based compensation. These estimates are based on historical facts and other assumptions that we believe are reasonable.

[0001045810-24-000264:notes:12]
Recently Issued Accounting Pronouncements

[0001045810-24-000264:notes:13]
[same as prior period, unchanged from 0001045810-24-000124:notes:12]

[0001045810-24-000264:notes:14]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of significant expenses in operating segments. We expect to adopt this standard in our annual reporting starting with fiscal year 2025. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

[0001045810-24-000264:notes:15]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-24-000264:notes:16]
[same as prior period, unchanged from 0001045810-24-000124:notes:15]

[0001045810-24-000264:notes:17]
Future minimum lease payments under our non-cancelable operating leases as of July 28, 2024 were as follows:

[0001045810-24-000264:notes:18]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first half of fiscal year 2025) | $ | 144 |  |
| 2026 | 316 |  |
| 2027 | 299 |  |
| 2028 | 280 |  |
| 2029 | 247 |  |
| 2030 and thereafter | 486 |  |
| Total | 1,772 |  |
| Less imputed interest | 218 |  |
| Present value of net future minimum lease payments | 1,554 |  |
| Less short-term operating lease liabilities | 250 |  |
| Long-term operating lease liabilities | $ | 1,304 |  |

[0001045810-24-000264:notes:19]
In addition, operating leases of $1.0 billion, primarily for our data centers, are expected to commence during fiscal year 2025 with lease terms of 2 to 10.5 years.

[0001045810-24-000264:notes:20]
Operating lease expenses were $84 million and $67 million for the second quarter of fiscal years 2025 and 2024, respectively, and $164 million and $126 million for the first half of fiscal years 2025 and 2024, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal years 2025 and 2024 were not significant.

[0001045810-24-000264:notes:21]
[same as prior period, unchanged from 0001045810-24-000124:notes:20]

[0001045810-24-000264:notes:22]
|  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 146 |  |  | $ | 135 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 405 |  |  | $ | 299 |  |

[0001045810-24-000264:notes:23]
As of July 28, 2024, our operating leases had a weighted average remaining lease term of 6.4 years and a weighted average discount rate of 4.03%. As of January 28, 2024, our operating leases had a weighted average remaining lease term of 6.1 years and a weighted average discount rate of 3.76%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-24-000264:notes:24]
Stock-Based Compensation
Stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and employee stock purchase plan, or ESPP.

[0001045810-24-000264:notes:25]
Condensed Consolidated Statements of Income include stock-based compensation expense, net of amounts capitalized into inventory and subsequently recognized to cost of revenue, as follows:

[0001045810-24-000264:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Cost of revenue | $ | 40 |  |  | $ | 31 |  |  | $ | 75 |  |  | $ | 58 |  |
| Research and development | 832 |  |  | 600 |  |  | 1,559 |  |  | 1,124 |  |
| Sales, general and administrative | 282 |  |  | 211 |  |  | 530 |  |  | 394 |  |
| Total | $ | 1,154 |  |  | $ | 842 |  |  | $ | 2,164 |  |  | $ | 1,576 |  |

[0001045810-24-000264:notes:27]
[same as prior period, unchanged from 0001045810-24-000124:notes:26]

[0001045810-24-000264:notes:28]
[same as prior period, unchanged from 0001045810-24-000124:notes:27]

[0001045810-24-000264:notes:29]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, Jan 28, 2024 | 367 |  |  | $ | 24.59 |  |  |  |  |  |
| Granted | 79 |  |  | $ | 82.68 |  |  |  |  |  |
| Vested | (93) |  |  | $ | 19.23 |  |  |  |  |  |
| Canceled and forfeited | (5) |  |  | $ | 28.82 |  |  |  |  |  |
| Balances, Jul 28, 2024 | 348 |  |  | $ | 39.16 |  |  |  |  |  |

[0001045810-24-000264:notes:30]
As of July 28, 2024, aggregate unearned stock-based compensation expense was $12.8 billion, which is expected to be recognized over a weighted average period of 2.5 years for RSUs, PSUs, and market-based PSUs, and 0.8 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-24-000264:notes:31]
[same as prior period, unchanged from 0001045810-24-000124:notes:30]

[0001045810-24-000264:notes:32]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 16,599 |  |  | $ | 6,188 |  |  | $ | 31,480 |  |  | $ | 8,232 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,578 |  |  | 24,729 |  |  | 24,599 |  |  | 24,716 |  |
| Dilutive impact of outstanding equity awards | 270 |  |  | 265 |  |  | 270 |  |  | 232 |  |
| Diluted weighted average shares | 24,848 |  |  | 24,994 |  |  | 24,869 |  |  | 24,948 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.68 |  |  | $ | 0.25 |  |  | $ | 1.28 |  |  | $ | 0.33 |  |
| Diluted (2) | $ | 0.67 |  |  | $ | 0.25 |  |  | $ | 1.27 |  |  | $ | 0.33 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 5 |  |  | 104 |  |  | 68 |  |  | 136 |  |

[0001045810-24-000264:notes:33]
[same as prior period, unchanged from 0001045810-24-000124:notes:32]

[0001045810-24-000264:notes:34]
[same as prior period, unchanged from 0001045810-24-000124:notes:33]

[0001045810-24-000264:notes:35]
Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. The anti-dilutive effect of equity awards outstanding is not included in the computation of diluted net income per share.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-24-000264:notes:36]
Income Taxes
Income tax expense was $2.6 billion and $5.0 billion for the second quarter and first half of fiscal year 2025, respectively, and $793 million and $958 million for the second quarter and first half of fiscal year 2024, respectively. The income tax expense as a percentage of income before income tax for the second quarter and first half of fiscal year 2025 was 13.6% and 13.7%, respectively, and 11.4% and 10.4% for the second quarter and first half of fiscal year 2024, respectively.

[0001045810-24-000264:notes:37]
The effective tax rate increased primarily due to a lower percentage of tax benefits from the foreign-derived intangible income deduction relative to the increase in income before income tax.

[0001045810-24-000264:notes:38]
Effective tax rates for the first half of fiscal years 2025 and 2024 were lower than the U.S. federal statutory rate of 21% due to tax benefits from stock-based compensation, the foreign-derived intangible income deduction, income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit.

[0001045810-24-000264:notes:39]
Given our current and anticipated future earnings, we believe that we may release the valuation allowance associated with certain state deferred tax assets in the near term, which would decrease our income tax expense for the period the release is recorded. The timing and amount of the valuation allowance release could vary based on our assessment of all available evidence.

[0001045810-24-000264:notes:40]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 28, 2024, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-24-000264:notes:41]
Cash Equivalents and Marketable Securities 
The following is a summary of cash equivalents and marketable securities:

[0001045810-24-000264:notes:42]
|  | Jul 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,051 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | 14,083 |  |  | $ | 2,132 |  |  | $ | 11,951 |  |
| Corporate debt securities | 11,994 |  |  | 37 |  |  | (7) |  |  | 12,024 |  |  | 682 |  |  | 11,342 |  |
| Money market funds | 5,252 |  |  | — |  |  | — |  |  | 5,252 |  |  | 5,252 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,461 |  |  | 7 |  |  | (2) |  |  | 2,466 |  |  | 50 |  |  | 2,416 |  |
| Certificates of deposit | 141 |  |  | — |  |  | — |  |  | 141 |  |  | 32 |  |  | 109 |  |
| Total marketable securities with fair value adjustments recorded in other comprehensive income | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 33,966 |  |  | $ | 8,148 |  |  | $ | 25,818 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | $ | 419 |  |  | $ | — |  |  | $ | 419 |  |
| Total | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 34,385 |  |  | $ | 8,148 |  |  | $ | 26,237 |  |

[0001045810-24-000264:notes:43]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. In the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

[0001045810-24-000264:notes:44]
For the second quarter and first half of fiscal year 2025, net unrealized gains on investments in publicly-held equity securities were $132 million and $181 million, respectively. For the second quarter and first half of fiscal year 2024, net unrealized gains on investments in publicly-held equity securities were not significant.

[0001045810-24-000264:notes:45]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total marketable securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

[0001045810-24-000264:notes:46]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-24-000264:notes:47]
|  | Jul 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by U.S. government agencies | $ | 4,031 |  |  | $ | (8) |  |  | $ | 857 |  |  | $ | (2) |  |  | $ | 4,888 |  |  | $ | (10) |  |
| Corporate debt securities | 3,170 |  |  | (5) |  |  | 396 |  |  | (2) |  |  | 3,566 |  |  | (7) |  |
| Debt securities issued by the U.S. Treasury | 1,210 |  |  | (1) |  |  | 117 |  |  | (1) |  |  | 1,327 |  |  | (2) |  |
| Total | $ | 8,411 |  |  | $ | (14) |  |  | $ | 1,370 |  |  | $ | (5) |  |  | $ | 9,781 |  |  | $ | (19) |  |

[0001045810-24-000264:notes:48]
|  | Jan 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 3,343 |  |  | $ | (5) |  |  | $ | 1,078 |  |  | $ | (5) |  |  | $ | 4,421 |  |  | $ | (10) |  |
| Corporate debt securities | 1,306 |  |  | (3) |  |  | 618 |  |  | (2) |  |  | 1,924 |  |  | (5) |  |
| Debt securities issued by U.S. government agencies | 670 |  |  | (1) |  |  | — |  |  | — |  |  | 670 |  |  | (1) |  |
| Total | $ | 5,319 |  |  | $ | (9) |  |  | $ | 1,696 |  |  | $ | (7) |  |  | $ | 7,015 |  |  | $ | (16) |  |

[0001045810-24-000264:notes:49]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-24-000264:notes:50]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-24-000264:notes:51]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,535 |  |  | $ | 15,532 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 18,364 |  |  | 18,434 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 33,899 |  |  | $ | 33,966 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-24-000264:notes:52]
The following is a summary of cash equivalents and marketable securities:


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-24-000264:notes:53]
Fair Value of Financial Assets and Liabilities and Investments in Non-Affiliated Entities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis.

[0001045810-24-000264:notes:54]
|  | Pricing Category |  | Fair Value at |
|  |  | Jul 28, 2024 |  | Jan 28, 2024 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 5,252 |  |  | $ | 3,031 |  |
| Publicly-held equity securities | Level 1 |  | $ | 419 |  |  | $ | — |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 14,083 |  |  | $ | 9,524 |  |
| Corporate debt securities | Level 2 |  | $ | 12,024 |  |  | $ | 10,152 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,466 |  |  | $ | 2,333 |  |
| Certificates of deposit | Level 2 |  | $ | 141 |  |  | $ | 510 |  |
| Foreign government bonds | Level 2 |  | $ | — |  |  | $ | 174 |  |
| Other assets (Investments in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities | Level 1 |  | $ | — |  |  | $ | 225 |  |
| Liabilities (1) |  |  |  |  |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | — |  |  | $ | 1,228 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 973 |  |  | $ | 970 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,126 |  |  | $ | 1,115 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,380 |  |  | $ | 1,367 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,068 |  |  | $ | 1,057 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 839 |  |  | $ | 851 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,559 |  |  | $ | 1,604 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 386 |  |  | $ | 403 |  |

[0001045810-24-000264:notes:55]
[same as prior period, unchanged from 0001045810-24-000124:notes:55]

[0001045810-24-000264:notes:56]
[same as prior period, unchanged from 0001045810-24-000124:notes:56]

[0001045810-24-000264:notes:57]
Our investments in non-affiliated entities include non-marketable equity securities, which are primarily investments in privately held companies. In the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

[0001045810-24-000264:notes:58]
Our non-marketable equity securities are recorded in long-term other assets on our Condensed Consolidated Balance Sheets and valued under the measurement alternative. Gains and losses on these investments, realized and unrealized, are recognized in Other income and expense, net on our Condensed Consolidated Statements of Income.

[0001045810-24-000264:notes:59]
Adjustments to the carrying value of our non-marketable equity securities during the second quarter and first half of fiscal years 2025 and 2024 were as follows:

[0001045810-24-000264:notes:60]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,463 |  |  | $ | 496 |  |  | $ | 1,321 |  |  | $ | 288 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 294 |  |  | 181 |  |  | 421 |  |  | 402 |  |
| Unrealized gains | 77 |  |  | — |  |  | 92 |  |  | — |  |
| Impairments and unrealized losses | (15) |  |  | (1) |  |  | (15) |  |  | (14) |  |
| Balance at end of period | $ | 1,819 |  |  | $ | 676 |  |  | $ | 1,819 |  |  | $ | 676 |  |

[0001045810-24-000264:notes:61]
Non-marketable equity securities had cumulative gross unrealized gains of $362 million and cumulative gross losses and impairments of $60 million as of July 28, 2024.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-24-000264:notes:62]
[same as prior period, unchanged from 0001045810-24-000124:notes:64]

[0001045810-24-000264:notes:63]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 2,752 |  |  | $ | (1,976) |  |  | $ | 776 |  |  | $ | 2,642 |  |  | $ | (1,720) |  |  | $ | 922 |  |
| Patents and licensed technology | 442 |  |  | (266) |  |  | 176 |  |  | 449 |  |  | (259) |  |  | 190 |  |
| Total intangible assets | $ | 3,194 |  |  | $ | (2,242) |  |  | $ | 952 |  |  | $ | 3,091 |  |  | $ | (1,979) |  |  | $ | 1,112 |  |

[0001045810-24-000264:notes:64]
For the second quarter and first half of fiscal year 2025, amortization expense associated with intangible assets was $146 million and $289 million, respectively. For the second quarter and first half of fiscal year 2024, amortization expense was $146 million and $327 million, respectively.

[0001045810-24-000264:notes:65]
The following table outlines the estimated amortization expense related to the net carrying amount of intangible assets as of July 28, 2024:

[0001045810-24-000264:notes:66]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first half of fiscal year 2025) | $ | 295 |  |
| 2026 | 304 |  |
| 2027 | 192 |  |
| 2028 | 51 |  |
| 2029 | 9 |  |
| 2030 and thereafter | 101 |  |
| Total | $ | 952 |  |

[0001045810-24-000264:notes:67]
In the first half of fiscal year 2025, goodwill increased by $192 million from business combinations assigned to our Compute & Networking reporting unit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-24-000264:notes:68]
Balance Sheet Components 
Three customers accounted for 23%, 15%, and 11% of our accounts receivable balance as of July 28, 2024. Two customers accounted for 24% and 11% of our accounts receivable balance as of January 28, 2024.

[0001045810-24-000264:notes:69]
[same as prior period, unchanged from 0001045810-24-000124:notes:71]

[0001045810-24-000264:notes:70]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
| Inventories: | (In millions) |
| Raw materials | $ | 1,895 |  |  | $ | 1,719 |  |
| Work in process | 2,111 |  |  | 1,505 |  |
| Finished goods | 2,669 |  |  | 2,058 |  |
| Total inventories (1) | $ | 6,675 |  |  | $ | 5,282 |  |

[0001045810-24-000264:notes:71]
(1)    During the second quarter of fiscal years 2025 and 2024, we recorded an inventory provision of $345 million and $343 million, respectively and during the first half of fiscal years 2025 and 2024, we recorded an inventory provision of $555 million and $448 million, respectively, in cost of revenue.

[0001045810-24-000264:notes:72]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
| Other Assets (Long Term): | (In millions) |
| Investments in non-affiliated entities | $ | 1,819 |  |  | $ | 1,546 |  |
| Prepaid supply and capacity agreements (1) | 1,313 |  |  | 2,458 |  |
| Prepaid royalties | 352 |  |  | 364 |  |
| Prepaid tax | 331 |  |  | 2 |  |
| Other | 186 |  |  | 130 |  |
| Total other assets | $ | 4,001 |  |  | $ | 4,500 |  |

[0001045810-24-000264:notes:73]
(1)    As of July 28, 2024 and January 28, 2024, there were $3.3 billion and $2.5 billion of short-term prepaid supply and capacity agreements included in short term Prepaid expenses and other current assets, respectively.

[0001045810-24-000264:notes:74]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 3,584 |  |  | $ | 2,081 |  |
| Excess inventory purchase obligations (1) | 2,051 |  |  | 1,655 |  |
| Taxes payable | 1,173 |  |  | 296 |  |
| Deferred revenue (2) | 948 |  |  | 764 |  |
| Accrued payroll and related expenses | 941 |  |  | 675 |  |
| Product warranty and return provisions | 868 |  |  | 415 |  |
| Operating leases | 250 |  |  | 228 |  |
| Licenses and royalties | 154 |  |  | 182 |  |
| Unsettled share repurchases | 130 |  |  | 187 |  |
| Other | 190 |  |  | 199 |  |
| Total accrued and other current liabilities | $ | 10,289 |  |  | $ | 6,682 |  |

[0001045810-24-000264:notes:75]
(1)    During the second quarter of fiscal years 2025 and 2024, we recorded $563 million and $232 million, respectively and during the first half of fiscal years 2025 and 2024, we recorded $746 million and $261 million, respectively, in cost of revenue.

[0001045810-24-000264:notes:76]
(2)    Deferred revenue includes customer advances and unearned revenue related to hardware support, software support, cloud services, and license and development arrangements. The balance as of July 28, 2024 and January 28, 2024 included $340 million and $233 million of customer advances, respectively.

[0001045810-24-000264:notes:77]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,670 |  |  | $ | 1,361 |  |
| Deferred revenue (2) | 773 |  |  | 573 |  |
| Deferred income tax | 697 |  |  | 462 |  |
| Other | 196 |  |  | 145 |  |
| Total other long-term liabilities | $ | 3,336 |  |  | $ | 2,541 |  |

[0001045810-24-000264:notes:78]
[same as prior period, unchanged from 0001045810-24-000124:notes:81]

[0001045810-24-000264:notes:79]
(2)    Deferred revenue includes unearned revenue related to hardware support and software support.

[0001045810-24-000264:notes:80]
[same as prior period, unchanged from 0001045810-24-000124:notes:83]

[0001045810-24-000264:notes:81]
The following table shows the changes in short and long term deferred revenue during the first half of fiscal years 2025 and 2024:

[0001045810-24-000264:notes:82]
|  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,337 |  |  | $ | 572 |  |
| Deferred revenue additions | 1,478 |  |  | 713 |  |
| Revenue recognized | (1,094) |  |  | (556) |  |
| Balance at end of period | $ | 1,721 |  |  | $ | 729 |  |

[0001045810-24-000264:notes:83]
We recognized revenue of $323 million and $199 million for the first half of fiscal years 2025 and 2024 respectively, that were included in the prior year end deferred revenue balances.

[0001045810-24-000264:notes:84]
For revenue contracts with a length greater than one year, $1.3 billion is included in deferred revenue and $123 million has not yet been billed nor recognized as revenue as of July 28, 2024. Approximately 37% of this combined amount will be recognized as revenue over the next twelve months.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-24-000264:notes:85]
Derivative Financial Instruments
We entered into foreign currency forward contracts mitigating the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur.

[0001045810-24-000264:notes:86]
We also entered into foreign currency forward contracts mitigating the impact of foreign currency movements on monetary assets and liabilities. The change in fair value of these non-designated contracts was recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which was also recorded in other income or expense.

[0001045810-24-000264:notes:87]
[same as prior period, unchanged from 0001045810-24-000124:notes:90]

[0001045810-24-000264:notes:88]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,278 |  |  | $ | 1,168 |  |
| Non-designated hedges | $ | 894 |  |  | $ | 597 |  |

[0001045810-24-000264:notes:89]
The unrealized gains and losses or fair value of our foreign currency contracts were not significant as of July 28, 2024 and January 28, 2024.

[0001045810-24-000264:notes:90]
As of July 28, 2024, all designated foreign currency contracts mature within 18 months and the expected realized gains and losses were not significant.

[0001045810-24-000264:notes:91]
During the first half of fiscal years 2025 and 2024, the impact of derivative financial instruments designated for cash flow hedges was not significant and the instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-24-000264:notes:92]
Debt
Long-Term Debt

[0001045810-24-000264:notes:93]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,461 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,461 |  |  | $ | 8,459 |  |

[0001045810-24-000264:notes:94]
(1) We repaid the 0.584% Notes Due 2024 in the second quarter of fiscal year 2025.

[0001045810-24-000264:notes:95]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes are calendar year.

[0001045810-24-000264:notes:96]
As of July 28, 2024, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-24-000264:notes:97]
Commercial Paper

[0001045810-24-000264:notes:98]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2024, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-24-000264:notes:99]
Commitments and Contingencies
Purchase Obligations

[0001045810-24-000264:notes:100]
Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-24-000264:notes:101]
As of July 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $27.8 billion, an increase from the prior year due to commitments for Hopper and Blackwell capacity and components. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $12.0 billion, including $9.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

[0001045810-24-000264:notes:102]
Total future purchase commitments as of July 28, 2024 are as follows:

[0001045810-24-000264:notes:103]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first half of fiscal year 2025) | $ | 21,934 |  |
| 2026 | 10,671 |  |
| 2027 | 2,778 |  |
| 2028 | 2,436 |  |
| 2029 | 1,543 |  |
| 2030 and thereafter | 419 |  |
| Total | $ | 39,781 |  |

[0001045810-24-000264:notes:104]
Accrual for Product Warranty Liabilities

[0001045810-24-000264:notes:105]
The estimated amount of product warranty liabilities was $741 million and $306 million as of July 28, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-24-000264:notes:106]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 532 |  |  | $ | 77 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 237 |  |  | 42 |  |  | 471 |  |  | 55 |  |
| Utilization | (28) |  |  | (4) |  |  | (36) |  |  | (22) |  |
| Balance at end of period | $ | 741 |  |  | $ | 115 |  |  | $ | 741 |  |  | $ | 115 |  |

[0001045810-24-000264:notes:107]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-24-000264:notes:108]
Litigation

[0001045810-24-000264:notes:109]
Securities Class Action and Derivative Lawsuits

[0001045810-24-000264:notes:110]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. Four amicus briefs were filed in support of NVIDIA's petition. Oral arguments are scheduled for November 13, 2024.

[0001045810-24-000264:notes:111]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The stay remains in place. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-24-000264:notes:112]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-24-000264:notes:113]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-24-000264:notes:114]
Accounting for Loss Contingencies

[0001045810-24-000264:notes:115]
As of July 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-24-000264:notes:116]
[same as prior period, unchanged from 0001045810-24-000124:notes:119]

[0001045810-24-000264:notes:117]
During the second quarter and first half of fiscal year 2025, we repurchased 62.8 million and 162.1 million shares of our common stock for $7.0 billion and $15.1 billion, respectively. During the second quarter and first half of fiscal year 2024, we repurchased 75.5 million shares of our common stock for $3.3 billion. As of July 28, 2024, we were authorized, subject to certain specifications, to repurchase up to $7.5 billion of our common stock. On August 26, 2024, our Board of Directors approved an additional $50.0 billion to our share repurchase authorization, without expiration. As of August 26, 2024, a total of $53.9 billion was available for repurchase. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-24-000264:notes:118]
From July 29, 2024 through August 26, 2024, we repurchased 31.5 million shares for $3.6 billion pursuant to a Rule 10b5-1 trading plan.

[0001045810-24-000264:notes:119]
On June 7, 2024, we increased our quarterly cash dividend to $0.01 per share on a post-Stock Split basis to all shareholders of record on June 11, 2024. Our quarterly cash dividend was paid on June 28, 2024.

[0001045810-24-000264:notes:120]
During the second quarter and first half of fiscal year 2025, we paid $246 million and $344 million in cash dividends, respectively. During the second quarter and first half of fiscal year 2024, we paid $99 million and $199 million in cash dividends to our shareholders, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-24-000264:notes:121]
[same as prior period, unchanged from 0001045810-24-000124:notes:123]

[0001045810-24-000264:notes:122]
The Compute & Networking segment includes our Data Center accelerated computing platforms and artificial intelligence, or AI, solutions and software; networking; automotive platforms and autonomous and electric vehicle solutions; Jetson for robotics and other embedded platforms; and DGX Cloud computing services.

[0001045810-24-000264:notes:123]
[same as prior period, unchanged from 0001045810-24-000124:notes:125]

[0001045810-24-000264:notes:124]
[same as prior period, unchanged from 0001045810-24-000124:notes:126]

[0001045810-24-000264:notes:125]
[same as prior period, unchanged from 0001045810-24-000124:notes:127]

[0001045810-24-000264:notes:126]
[same as prior period, unchanged from 0001045810-24-000124:notes:128]

[0001045810-24-000264:notes:127]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended Jul 28, 2024 |  |  |  |  |  |  |  |
| Revenue | $ | 26,446 |  |  | $ | 3,594 |  |  | $ | — |  |  | $ | 30,040 |  |
| Operating income (loss) | $ | 18,848 |  |  | $ | 1,369 |  |  | $ | (1,575) |  |  | $ | 18,642 |  |
| Three Months Ended Jul 30, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 10,402 |  |  | $ | 3,105 |  |  | $ | — |  |  | $ | 13,507 |  |
| Operating income (loss) | $ | 6,728 |  |  | $ | 1,211 |  |  | $ | (1,139) |  |  | $ | 6,800 |  |
| Six Months Ended Jul 28, 2024 |  |  |  |  |  |  |  |
| Revenue | $ | 49,121 |  |  | $ | 6,963 |  |  | $ | — |  |  | $ | 56,084 |  |
| Operating income (loss) | $ | 35,896 |  |  | $ | 2,609 |  |  | $ | (2,954) |  |  | $ | 35,551 |  |
| Six Months Ended Jul 30, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 14,862 |  |  | $ | 5,837 |  |  | $ | — |  |  | $ | 20,699 |  |
| Operating income (loss) | $ | 8,887 |  |  | $ | 2,258 |  |  | $ | (2,204) |  |  | $ | 8,941 |  |

[0001045810-24-000264:notes:128]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (1,154) |  |  | $ | (842) |  |  | $ | (2,164) |  |  | $ | (1,576) |  |
| Unallocated cost of revenue and operating expenses | (280) |  |  | (163) |  |  | (508) |  |  | (317) |  |
| Acquisition-related and other costs | (144) |  |  | (137) |  |  | (286) |  |  | (311) |  |
| Other | 3 |  |  | 3 |  |  | 4 |  |  | — |  |
| Total | $ | (1,575) |  |  | $ | (1,139) |  |  | $ | (2,954) |  |  | $ | (2,204) |  |

[0001045810-24-000264:notes:129]
Revenue by geographic areas is based upon the billing location of the customer. The end customer and shipping location may be different from our customer’s billing location. For example, most shipments associated with Singapore revenue were to locations other than Singapore and shipments to Singapore were insignificant. Revenue by geographic areas was as follows:

[0001045810-24-000264:notes:130]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 13,022 |  |  | $ | 6,043 |  |  | $ | 26,518 |  |  | $ | 8,428 |  |
| Taiwan | 5,740 |  |  | 2,839 |  |  | 10,113 |  |  | 4,635 |  |
| Singapore | 5,622 |  |  | 1,042 |  |  | 9,659 |  |  | 1,804 |  |
| China (including Hong Kong) | 3,667 |  |  | 2,740 |  |  | 6,158 |  |  | 4,330 |  |
| Other countries | 1,989 |  |  | 843 |  |  | 3,636 |  |  | 1,502 |  |
| Total revenue | $ | 30,040 |  |  | $ | 13,507 |  |  | $ | 56,084 |  |  | $ | 20,699 |  |

[0001045810-24-000264:notes:131]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, original device manufacturers, or ODMs, original equipment manufacturers, or OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. We also have indirect customers, who purchase products through our direct customers; indirect customers include cloud service providers, consumer internet companies, enterprises, and public sector entities.

[0001045810-24-000264:notes:132]
Sales to direct customers which represented 10% or more of total revenue, all of which were primarily attributable to the Compute & Networking segment, are presented in the following table:

[0001045810-24-000264:notes:133]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 28, 2024 |
| Customer A | 14 | % |  | 14 | % |
| Customer B | 11 | % |  | * |
| Customer C | 11 | % |  | * |
| Customer D | 10 | % |  | 10 | % |
| Customer E | * |  | 10 | % |

[0001045810-24-000264:notes:134]
* Less than 10% of total revenue

[0001045810-24-000264:notes:135]
One customer represented approximately 17% and 13% of total revenue for the second quarter and first half of fiscal year 2024, respectively, and was attributable to the Compute & Networking segment.

[0001045810-24-000264:notes:136]
The following table summarizes revenue by specialized markets:

[0001045810-24-000264:notes:137]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 26,272 |  |  | $ | 10,323 |  |  | $ | 48,835 |  |  | $ | 14,607 |  |
| Compute | 22,604 |  |  | 8,612 |  |  | 41,996 |  |  | 11,969 |  |
| Networking | 3,668 |  |  | 1,711 |  |  | 6,839 |  |  | 2,638 |  |
| Gaming | 2,880 |  |  | 2,486 |  |  | 5,527 |  |  | 4,726 |  |
| Professional Visualization | 454 |  |  | 379 |  |  | 881 |  |  | 674 |  |
| Automotive | 346 |  |  | 253 |  |  | 675 |  |  | 549 |  |
| OEM and Other | 88 |  |  | 66 |  |  | 166 |  |  | 143 |  |
| Total revenue | $ | 30,040 |  |  | $ | 13,507 |  |  | $ | 56,084 |  |  | $ | 20,699 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-24-000264:notes:138]
On July 22, 2024, Ajay K. Puri, Executive Vice President, Worldwide Field Operations, terminated a Rule 10b5-1 trading arrangement adopted on April 12, 2024 for the sale of up to 1,008,320 shares of our common stock on a post-split basis through July 11, 2025. 100,110 shares were sold under the plan prior to termination.
