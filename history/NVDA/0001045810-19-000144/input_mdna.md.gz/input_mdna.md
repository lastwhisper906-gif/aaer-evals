# NVDA MD&A — 0001045810-19-000144


## mdna

[0001045810-19-000144:mdna:1]
[same as prior period, unchanged from 0001045810-19-000079:mdna:1]

[0001045810-19-000144:mdna:2]
[same as prior period, unchanged from 0001045810-19-000079:mdna:2]

[0001045810-19-000144:mdna:3]
[same as prior period, unchanged from 0001045810-19-000079:mdna:3]

[0001045810-19-000144:mdna:4]
NVIDIA, the NVIDIA logo, CUDA, CUDA-X AI, GeForce, GeForce GTX, GeForce RTX, GeForce RTX SUPER, NVIDIA DGX, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA DRIVE Constellation, NVIDIA GRID, NVIDIA Omniverse, NVIDIA RTX, NVIDIA Turing, Quadro, Quadro RTX, Tegra and Tesla are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000144:mdna:5]
[same as prior period, unchanged from 0001045810-19-000079:mdna:5]

[0001045810-19-000144:mdna:6]
[same as prior period, unchanged from 0001045810-19-000079:mdna:6]

[0001045810-19-000144:mdna:7]
[same as prior period, unchanged from 0001045810-19-000079:mdna:7]

[0001045810-19-000144:mdna:8]
[same as prior period, unchanged from 0001045810-19-000079:mdna:8]

[0001045810-19-000144:mdna:9]
Our two reportable segments - GPU and Tegra Processor - are based on a single underlying architecture. From our proprietary processors, we have designed, created, and marketed platforms that address four large markets where our expertise is critical: Gaming, Professional Visualization, Data Center, and Automotive.

[0001045810-19-000144:mdna:10]
[same as prior period, unchanged from 0001045810-19-000079:mdna:10]

[0001045810-19-000144:mdna:11]
[same as prior period, unchanged from 0001045810-19-000079:mdna:11]

[0001045810-19-000144:mdna:12]
[same as prior period, unchanged from 0001045810-19-000079:mdna:12]

[0001045810-19-000144:mdna:13]
Second Quarter of Fiscal Year 2020 Summary

[0001045810-19-000144:mdna:14]
|  | Three Months Ended |  |  |  |  |
|  | July 28, 2019 |  | April 28, 2019 |  | July 29, 2018 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 2,579 |  |  | $ | 2,220 |  |  | $ | 3,123 |  |  | 16 | % |  | (17 | )% |
| Gross margin | 59.8 | % |  | 58.4 | % |  | 63.3 | % |  | 140 bps |  |  | (350) bps |  |
| Operating expenses | $ | 970 |  |  | $ | 938 |  |  | $ | 818 |  |  | 3 | % |  | 19 | % |
| Income from operations | $ | 571 |  |  | $ | 358 |  |  | $ | 1,157 |  |  | 59 | % |  | (51 | )% |
| Net income | $ | 552 |  |  | $ | 394 |  |  | $ | 1,101 |  |  | 40 | % |  | (50 | )% |
| Net income per diluted share | $ | 0.90 |  |  | $ | 0.64 |  |  | $ | 1.76 |  |  | 41 | % |  | (49 | )% |

[0001045810-19-000144:mdna:15]
Revenue for the second quarter of fiscal year 2020 decreased 17% year over year and increased 16% sequentially.

[0001045810-19-000144:mdna:16]
GPU business revenue was $2.10 billion, down 21% from a year earlier and up 4% sequentially.

[0001045810-19-000144:mdna:17]
Tegra Processor business revenue - which includes Automotive, SOC modules for gaming platforms, and embedded edge AI platforms - was $475 million, up 2% from a year ago and up 140% sequentially.

[0001045810-19-000144:mdna:18]
From a market-platforms perspective, Gaming revenue was $1.31 billion, down 27% from a year ago and up 24% sequentially. The year-on-year decrease reflects a decline in shipments of gaming desktop GPUs and SOC modules for gaming platforms, partially offset by growth in gaming notebook GPUs. The sequential increase reflects growth from SOC modules for gaming platforms, gaming notebook GPUs, and GeForce RTX SUPER gaming GPUs.

[0001045810-19-000144:mdna:19]
Professional Visualization revenue was $291 million, up 4% from a year earlier and up 9% sequentially. The year-on-year and sequential growth reflects strength across mobile workstation products.

[0001045810-19-000144:mdna:20]
Data Center revenue was $655 million, down 14% from a year ago and up 3% sequentially. The year-on-year decline reflects lower hyperscale revenue. The sequential increase was due to enterprise revenue growth driven by expanding AI workloads.

[0001045810-19-000144:mdna:21]
Automotive revenue of $209 million was up 30% from a year earlier and up 26% sequentially. The year-on-year and sequential growth was primarily driven by a development services agreement in the second quarter of fiscal year 2020. The growth in revenue also reflected AI cockpit solutions and other autonomous vehicle development agreements.

[0001045810-19-000144:mdna:22]
OEM and Other revenue was $111 million, down 4% from a year ago and up 12% sequentially. The sequential increase was primarily due to growth in shipments of embedded edge AI products.

[0001045810-19-000144:mdna:23]
Gross margin for the second quarter of fiscal year 2020 was 59.8%, down 350 basis points from a year earlier and up 140 basis points sequentially. The year-on-year decrease reflects lower Gaming and Data Center margins, driven primarily by product costs. The sequential increase reflects automotive development services, a favorable mix in Gaming, and lower component costs.

[0001045810-19-000144:mdna:24]
Operating expenses for the second quarter of fiscal year 2020 were $970 million, up 19% from a year earlier and up 3% sequentially, reflecting primarily employee additions and increases in employee compensation and other related costs, including infrastructure costs.

[0001045810-19-000144:mdna:25]
Income from operations for the second quarter of fiscal year 2020 was $571 million, down 51% from a year earlier and up 59% sequentially. Net income and net income per diluted share for the second quarter of fiscal year 2020 were $552 million and $0.90, respectively, down 50% and 49%, respectively, from a year earlier, and up 40% and 41%, respectively, sequentially. The year-on-year decrease reflects lower revenue and gross margin, and higher operating expenses. The sequential increase reflects higher revenue and gross margin.

[0001045810-19-000144:mdna:26]
We previously communicated our intent to return $3.00 billion to shareholders by the end of fiscal year 2020, including $700 million in share repurchases made during the fourth quarter of fiscal year 2019. In the first half of fiscal year 2020, we returned $195 million in quarterly cash dividends. We intend to return the remaining $2.11 billion through a combination of share repurchases and cash dividends. We do not expect to repurchase shares prior to the close of the acquisition of Mellanox Technologies, Ltd., or Mellanox, and therefore the intended repurchases may extend into fiscal year 2021.

[0001045810-19-000144:mdna:27]
23

[0001045810-19-000144:mdna:28]
Cash, cash equivalents and marketable securities were $8.47 billion as of July 28, 2019, compared with $7.42 billion as of January 27, 2019. The increase was primarily related to growth in operating cash flow.

[0001045810-19-000144:mdna:29]
On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. The closing of the merger is subject to approval by regulatory agencies. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million. We have received regulatory approval in the United States and Mexico and are engaged with regulators in Europe and China. In June 2019, Mellanox shareholders approved the merger.

[0001045810-19-000144:mdna:30]
[same as prior period, unchanged from 0001045810-19-000079:mdna:30]

[0001045810-19-000144:mdna:31]
During the second quarter of fiscal year 2020, in our Gaming platform, we introduced GeForce RTX 2060 SUPER, GeForce RTX 2070 SUPER and GeForce RTX 2080 SUPER to our GeForce GPU lineup; accelerated the momentum of ray-tracing games by supporting newly announced blockbuster titles; introduced new RTX Studio laptops powered by GeForce RTX and Quadro RTX GPUs for online and studio-based creatives and prosumers; and announced OEMs will be launching additional gaming laptops incorporating NVIDIA GeForce Turing GPUs.

[0001045810-19-000144:mdna:32]
In our Professional Visualization platform, we rolled out a full range of Turing architecture-based Quadro GPUs for mobile workstations, also incorporating ray tracing for product design, architecture, effects and scientific visualization.

[0001045810-19-000144:mdna:33]
In our Data Center platform, we announced NVIDIA's DGX SuperPOD, which provides the AI infrastructure for our autonomous-vehicle development program; set eight records in AI training performance in the latest MLPerf benchmarking tests; and announced support for Arm CPUs, providing a new path to build highly energy-efficient, AI-enabled exascale supercomputers.

[0001045810-19-000144:mdna:34]
During the first quarter of fiscal year 2020, in our Gaming platform, we introduced the GeForce GTX 1660 Ti, GTX 1660 and GTX 1650 gaming GPUs with improved performance and efficiency for today’s most popular games; announced a number of gaming laptop models based on Turing GPUs from top makers; and announced that real-time ray tracing is now integrated into Unreal Engine and Unity commercial game engines.

[0001045810-19-000144:mdna:35]
In our Professional Visualization platform, we announced expanded adoption of NVIDIA RTX ray-tracing technology by top 3D application providers and unveiled the NVIDIA Omniverse open-collaboration platform to simplify creative workflows for content creation.

[0001045810-19-000144:mdna:36]
In our Data Center platform, we introduced the NVIDIA CUDA-X AI platform for accelerating data science; announced availability of NVIDIA T4 Tensor Core GPUs from leading OEMs and Amazon Web Services; partnered with global system builders to create powerful data-science workstations integrating NVIDIA Quadro RTX GPUs and NVIDIA CUDA-X AI; and launched beta access to NVIDIA Quadro Virtual Workstation software in the Alibaba Cloud Marketplace.

[0001045810-19-000144:mdna:37]
[same as prior period, unchanged from 0001045810-19-000079:mdna:34]

[0001045810-19-000144:mdna:38]
During the second quarter of fiscal year 2020, in our Automotive platform, Volvo Group announced that it is using the NVIDIA DRIVE end-to-end autonomous driving platform to train networks in the data center, test them in simulation, and deploy them in self-driving vehicles, targeting freight transport, refuse and recycling collection, public transport, construction, mining, forestry and more.

[0001045810-19-000144:mdna:39]
During the first quarter of fiscal year 2020, in our Automotive platform, we announced that we are partnering with Toyota Research Institute-Advanced Development to develop, train and validate self-driving vehicles; unveiled the NVIDIA DRIVE AP2X automated driving solution, encompassing DRIVE AutoPilot software, DRIVE AGX and DRIVE validation tools; introduced NVIDIA DRIVE AV Safety Force Field to enable safe, comfortable driving experiences; and announced availability of the NVIDIA DRIVE Constellation autonomous vehicle simulation platform.

[0001045810-19-000144:mdna:40]
[same as prior period, unchanged from 0001045810-19-000079:mdna:36]

[0001045810-19-000144:mdna:41]
[same as prior period, unchanged from 0001045810-19-000079:mdna:37]

[0001045810-19-000144:mdna:42]
[same as prior period, unchanged from 0001045810-19-000079:mdna:38]

[0001045810-19-000144:mdna:43]
[same as prior period, unchanged from 0001045810-19-000079:mdna:39]

[0001045810-19-000144:mdna:44]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, 2019 |  | July 29, 2018 |  | July 28, 2019 |  | July 29, 2018 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 40.2 |  |  | 36.7 |  |  | 40.9 |  |  | 36.1 |  |
| Gross profit | 59.8 |  |  | 63.3 |  |  | 59.1 |  |  | 63.9 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Research and development | 27.3 |  |  | 18.6 |  |  | 28.7 |  |  | 17.8 |  |
| Sales, general and administrative | 10.3 |  |  | 7.7 |  |  | 11.0 |  |  | 7.4 |  |
| Total operating expenses | 37.6 |  |  | 26.3 |  |  | 39.7 |  |  | 25.2 |  |
| Income from operations | 22.2 |  |  | 37.0 |  |  | 19.4 |  |  | 38.7 |  |
| Interest income | 1.8 |  |  | 1.0 |  |  | 1.9 |  |  | 0.9 |  |
| Interest expense | (0.5 | ) |  | (0.4 | ) |  | (0.6 | ) |  | (0.5 | ) |
| Other, net | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Total other income (expense) | 1.3 |  |  | 0.8 |  |  | 1.3 |  |  | 0.6 |  |
| Income before income tax | 23.5 |  |  | 37.8 |  |  | 20.7 |  |  | 39.3 |  |
| Income tax expense | 2.1 |  |  | 2.5 |  |  | 1.0 |  |  | 2.3 |  |
| Net income | 21.4 | % |  | 35.3 | % |  | 19.7 | % |  | 37.0 | % |

[0001045810-19-000144:mdna:45]
[same as prior period, unchanged from 0001045810-19-000079:mdna:41]

[0001045810-19-000144:mdna:46]
[same as prior period, unchanged from 0001045810-19-000079:mdna:42]

[0001045810-19-000144:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, 2019 |  | July 29, 2018 |  | $Change |  | %Change |  | July 28, 2019 |  | July 29, 2018 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,104 |  |  | $ | 2,656 |  |  | $ | (552 | ) |  | (21 | )% |  | $ | 4,126 |  |  | $ | 5,421 |  |  | $ | (1,295 | ) |  | (24 | )% |
| Tegra Processor | 475 |  |  | 467 |  |  | 8 |  |  | 2 | % |  | 673 |  |  | 909 |  |  | (236 | ) |  | (26 | )% |
| Total | $ | 2,579 |  |  | $ | 3,123 |  |  | $ | (544 | ) |  | (17 | )% |  | $ | 4,799 |  |  | $ | 6,330 |  |  | $ | (1,531 | ) |  | (24 | )% |

[0001045810-19-000144:mdna:48]
GPU Business. GPU business revenue decreased by 21% in the second quarter of fiscal year 2020 compared to the second quarter of fiscal year 2019, which reflects declines in gaming GPU and Data Center revenue. GeForce GPU product sales for gaming decreased 29%, reflecting a decline in shipments of gaming desktop GPUs partially offset by revenue growth in gaming notebook GPUs. Data Center revenue, including Tesla, GRID and DGX, decreased 14%, primarily reflecting a decline in hyperscale revenue partially offset by enterprise revenue growth, driven by expanding AI workloads. Revenue from Quadro GPUs for professional visualization increased 4%, primarily reflecting strength across mobile workstation products. Our PC OEM revenue decreased by 4%, primarily driven by the absence of cryptocurrency mining processor sales.

[0001045810-19-000144:mdna:49]
GPU business revenue decreased by 24% in the first half of fiscal year 2020 compared to the first half of fiscal year 2019, which reflects declines in gaming GPU and Data Center revenue. GeForce GPU product sales for gaming decreased 29%, reflecting a decline in shipments of gaming desktop GPUs partially offset by growth in gaming notebook GPUs. Data Center revenue, including Tesla, GRID and DGX, decreased 12%, primarily reflecting a decline in hyperscale revenue partially offset by enterprise revenue growth driven by expanding AI workloads. Revenue from Quadro GPUs for professional visualization increased 5% due primarily reflecting strength across mobile workstation products. Our PC OEM revenue decreased by 58% primarily driven by the absence of cryptocurrency mining processor sales.

[0001045810-19-000144:mdna:50]
Tegra Processor Business. Tegra Processor business revenue increased by 2% for the second quarter of fiscal year 2020 compared to the second quarter of fiscal year 2019. This was driven by an increase of 30% in Automotive revenue primarily

[0001045810-19-000144:mdna:51]
driven by a development services agreement in the second quarter of fiscal year 2020. The growth in Automotive revenue also reflected AI cockpit solutions and other autonomous vehicle development agreements. The increase in Automotive revenue was partially offset by a decline in revenue from SOC modules for gaming platforms.

[0001045810-19-000144:mdna:52]
Tegra Processor business revenue decreased by 26% for the first half of fiscal year 2020 compared to the first half of fiscal year 2019. This was driven by a decline in revenue from SOC modules for gaming platforms, which was partially offset by an increase of 23% in Automotive revenue. Growth in Automotive revenue primarily reflects a development services agreement in the second quarter of fiscal year 2020, AI cockpit solutions, and other autonomous vehicle development agreements.

[0001045810-19-000144:mdna:53]
[same as prior period, unchanged from 0001045810-19-000079:mdna:46]

[0001045810-19-000144:mdna:54]
Revenue from sales to customers outside of the United States accounted for 93% of total revenue for the second quarter and first half of fiscal year 2020. Revenue from sales to customers outside of the United States accounted for 87% of total revenue for the second quarter and first half of fiscal year 2019. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-19-000144:mdna:55]
One customer represented approximately 11% of our total revenue for the second quarter and the first half of fiscal year 2020, and was attributable primarily to the GPU business. No customer represented 10% or more of total revenue for the second quarter and first half of fiscal year 2019.

[0001045810-19-000144:mdna:56]
[same as prior period, unchanged from 0001045810-19-000079:mdna:49]

[0001045810-19-000144:mdna:57]
Our overall gross margin decreased to 59.8% for the second quarter of fiscal year 2020 from 63.3% for the second quarter of fiscal year 2019. Our overall gross margin decreased to 59.1% for the first half of fiscal year 2020 from 63.9% for the first half of fiscal year 2019. These decreases reflect lower Gaming and Data Center margins, driven primarily by product costs.

[0001045810-19-000144:mdna:58]
Inventory provisions totaled $28 million and $21 million for the second quarter of fiscal years 2020 and 2019, respectively. Sales of inventory that was previously written-off or written-down totaled $19 million and $12 million for the second quarter of fiscal years 2020 and 2019, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.4% and 0.3% for the second quarter of fiscal years 2020 and 2019, respectively.

[0001045810-19-000144:mdna:59]
Inventory provisions totaled $72 million and $54 million for the first half of fiscal years 2020 and 2019, respectively. Sales of inventory that was previously written-off or written-down totaled $31 million and $16 million for the first half of fiscal years 2020 and 2019, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.9% and 0.6% for the first half of fiscal years 2020 and 2019, respectively.

[0001045810-19-000144:mdna:60]
[same as prior period, unchanged from 0001045810-19-000079:mdna:52]

[0001045810-19-000144:mdna:61]
GPU Business. The gross margin of our GPU business decreased during the second quarter and first half of fiscal year 2020 compared to the second quarter and first half of fiscal year 2019, primarily reflecting lower gaming GPU and data center margins driven by product costs.

[0001045810-19-000144:mdna:62]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the second quarter of fiscal year 2020 compared to the second quarter of fiscal year 2019, primarily driven by automotive development services. The gross margin of our Tegra Processor business decreased during the first half of fiscal year 2020 compared to the first half of fiscal year 2019, primarily due to mix shifts.

[0001045810-19-000144:mdna:63]
[same as prior period, unchanged from 0001045810-19-000079:mdna:55]

[0001045810-19-000144:mdna:64]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, 2019 |  | July 29, 2018 |  | $Change |  | %Change |  | July 28, 2019 |  | July 29, 2018 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| Research and development expenses | $ | 704 |  |  | $ | 581 |  |  | $ | 123 |  |  | 21 | % |  | $ | 1,379 |  |  | $ | 1,124 |  |  | $ | 255 |  |  | 23 | % |
| % of net revenue | 27 | % |  | 19 | % |  |  |  |  |  | 29 | % |  | 18 | % |  |  |  |  |
| Sales, general and administrative expenses | 266 |  |  | 237 |  |  | 29 |  |  | 12 | % |  | 529 |  |  | 467 |  |  | 62 |  |  | 13 | % |
| % of net revenue | 10 | % |  | 8 | % |  |  |  |  |  | 11 | % |  | 7 | % |  |  |  |  |
| Total operating expenses | $ | 970 |  |  | $ | 818 |  |  | $ | 152 |  |  | 19 | % |  | $ | 1,908 |  |  | $ | 1,591 |  |  | $ | 317 |  |  | 20 | % |

[0001045810-19-000144:mdna:65]
[same as prior period, unchanged from 0001045810-19-000079:mdna:57]

[0001045810-19-000144:mdna:66]
Research and development expenses increased by 21% and 23% during the second quarter and first half of fiscal year 2020, compared to the second quarter and first half of fiscal year 2019, respectively, driven primarily by employee additions, increases in employee compensation and other related costs, including infrastructure costs and stock-based compensation expense.

[0001045810-19-000144:mdna:67]
[same as prior period, unchanged from 0001045810-19-000079:mdna:59]

[0001045810-19-000144:mdna:68]
Sales, general and administrative expenses increased by 12% during the second quarter of fiscal year 2020, compared to the second quarter of fiscal year 2019, driven primarily by employee additions, increases in employee compensation and other related costs, including stock-based compensation expense and infrastructure costs.

[0001045810-19-000144:mdna:69]
Sales, general and administrative expenses increased by 13% during the first half of fiscal year 2020, compared to the first half of fiscal year 2019, driven primarily by costs related to our plans to acquire Mellanox, costs related to employee additions, and increases in employee compensation and other related costs, including stock-based compensation expense and infrastructure costs.

[0001045810-19-000144:mdna:70]
[same as prior period, unchanged from 0001045810-19-000079:mdna:61]

[0001045810-19-000144:mdna:71]
[same as prior period, unchanged from 0001045810-19-000079:mdna:62]

[0001045810-19-000144:mdna:72]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $47 million and $32 million during the second quarter of fiscal years 2020 and 2019, respectively, and $92 million and $57 million during the first half of fiscal years 2020 and 2019, respectively. The increase in interest income was primarily due to higher average invested balances, higher rates from our floating rate securities, and the purchase of new securities.

[0001045810-19-000144:mdna:73]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016. Interest expense was $13 million and $14 million during the second quarters of fiscal years 2020 and 2019, respectively, and $27 million and $29 million during the first half of fiscal years 2020 and 2019, respectively.

[0001045810-19-000144:mdna:74]
[same as prior period, unchanged from 0001045810-19-000079:mdna:65]

[0001045810-19-000144:mdna:75]
Other, net, consists primarily of realized or unrealized gains and losses from non-affiliated investments, and the impact of changes in foreign currency rates. Other, net, was not significant during the second quarter or the first half of fiscal years 2020 and 2019.

[0001045810-19-000144:mdna:76]
[same as prior period, unchanged from 0001045810-19-000079:mdna:67]

[0001045810-19-000144:mdna:77]
We recognized an income tax expense of $54 million and $48 million for the second quarter and first half of fiscal year 2020, respectively, and $79 million and $146 million for the second quarter and first half of fiscal year 2019, respectively. The effective tax rate for the second quarter and first half of fiscal year 2020 was 8.8% and 4.9% respectively, and 6.7% and 5.9% for the second quarter and first half of fiscal year 2019, respectively.

[0001045810-19-000144:mdna:78]
27

[0001045810-19-000144:mdna:79]
The increase in our effective tax rate for the second quarter of fiscal year 2020 as compared to the second quarter of fiscal year 2019 was primarily due to an increase in the amount of earnings subject to United States tax, and a decrease of tax benefits from stock-based compensation, partially offset by an increase in the impact of tax benefits from the U.S. federal research tax credit. The decrease in our effective tax rate for the first half of fiscal year 2020 as compared to the first half of fiscal year 2019 was primarily due to an increase in the impact of tax benefits from the U.S. federal research tax credit and stock-based compensation.

[0001045810-19-000144:mdna:80]
[same as prior period, unchanged from 0001045810-19-000079:mdna:70]

[0001045810-19-000144:mdna:81]
[same as prior period, unchanged from 0001045810-19-000079:mdna:71]

[0001045810-19-000144:mdna:82]
|  | July 28, 2019 |  | January 27, 2019 |
|  | (In millions) |
| Cash and cash equivalents | $ | 7,105 |  |  | $ | 782 |  |
| Marketable securities | 1,370 |  |  | 6,640 |  |
| Cash, cash equivalents and marketable securities | $ | 8,475 |  |  | $ | 7,422 |  |

[0001045810-19-000144:mdna:83]
|  | Six Months Ended |
|  | July 28, 2019 |  | July 29, 2018 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,656 |  |  | $ | 2,358 |  |
| Net cash provided by (used in) investing activities | $ | 5,040 |  |  | $ | (4,356 | ) |
| Net cash used in financing activities | $ | (373 | ) |  | $ | (1,286 | ) |

[0001045810-19-000144:mdna:84]
As of July 28, 2019, we had $8.47 billion in cash, cash equivalents and marketable securities, an increase of $1.05 billion from the end of fiscal year 2019. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain limits on our portfolio duration.

[0001045810-19-000144:mdna:85]
Cash provided by operating activities decreased in the first half of fiscal year 2020 compared to the first half of fiscal year 2019, due to lower net income, partially offset by changes in working capital.

[0001045810-19-000144:mdna:86]
Cash provided by investing activities increased in the first half of fiscal year 2020 compared to the first half of fiscal year 2019, due to lower purchases of marketable securities and higher maturities and sales of marketable securities.

[0001045810-19-000144:mdna:87]
Cash used in financing activities decreased in the first half of fiscal year 2020 compared to the first half of fiscal year 2019, due to lower share repurchases and lower tax payments related to employee stock plans.

[0001045810-19-000144:mdna:88]
[same as prior period, unchanged from 0001045810-19-000079:mdna:78]

[0001045810-19-000144:mdna:89]
[same as prior period, unchanged from 0001045810-19-000079:mdna:79]

[0001045810-19-000144:mdna:90]
As a result of the Tax Cuts and Jobs Act, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of July 28, 2019 are available for use in the United States without incurring additional U.S. federal income taxes.

[0001045810-19-000144:mdna:91]
[same as prior period, unchanged from 0001045810-19-000079:mdna:81]

[0001045810-19-000144:mdna:92]
We previously communicated our intent to return $3.00 billion to shareholders by the end of fiscal year 2020, including $700 million in share repurchases made during the fourth quarter of fiscal year 2019. In the first half of fiscal year 2020, we returned $195 million in quarterly cash dividends. We intend to return the remaining $2.11 billion through a combination of share repurchases and cash dividends. We do not expect to repurchase shares prior to the close of the acquisition of Mellanox, and therefore the intended repurchases may extend into fiscal year 2021. As of July 28, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000144:mdna:93]
[same as prior period, unchanged from 0001045810-19-000079:mdna:83]

[0001045810-19-000144:mdna:94]
[same as prior period, unchanged from 0001045810-19-000079:mdna:84]

[0001045810-19-000144:mdna:95]
[same as prior period, unchanged from 0001045810-19-000079:mdna:85]

[0001045810-19-000144:mdna:96]
Revolving Credit Facility

[0001045810-19-000144:mdna:97]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 28, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000144:mdna:98]
[same as prior period, unchanged from 0001045810-19-000079:mdna:88]

[0001045810-19-000144:mdna:99]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2019, we had not issued any commercial paper.

[0001045810-19-000144:mdna:100]
[same as prior period, unchanged from 0001045810-19-000079:mdna:90]

[0001045810-19-000144:mdna:101]
In fiscal year 2019, we began construction on a 750 thousand square foot building on our Santa Clara campus, which is currently targeted for completion in fiscal year 2022. We believe that our existing cash and cash equivalents, marketable securities, anticipated cash flows from operations, and our available revolving credit facility or commercial paper program mentioned above will be sufficient to meet our operating requirements for at least the next twelve months.

[0001045810-19-000144:mdna:102]
[same as prior period, unchanged from 0001045810-19-000079:mdna:92]

[0001045810-19-000144:mdna:103]
As of July 28, 2019, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-19-000144:mdna:104]
[same as prior period, unchanged from 0001045810-19-000079:mdna:94]

[0001045810-19-000144:mdna:105]
[same as prior period, unchanged from 0001045810-19-000079:mdna:95]

[0001045810-19-000144:mdna:106]
[same as prior period, unchanged from 0001045810-19-000079:mdna:96]

[0001045810-19-000144:mdna:107]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000144:mdna:108]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
