# NVDA notes — 0001045810-19-000144


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-19-000144:notes:1]
Summary of Significant Accounting Policies
Basis of Presentation

[0001045810-19-000144:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 27, 2019 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.

[0001045810-19-000144:notes:3]
[same as prior period, unchanged from 0001045810-19-000079:notes:146]

[0001045810-19-000144:notes:4]
[same as prior period, unchanged from 0001045810-19-000079:notes:147]

[0001045810-19-000144:notes:5]
Leases

[0001045810-19-000144:notes:6]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

[0001045810-19-000144:notes:7]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0001045810-19-000144:notes:8]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

[0001045810-19-000144:notes:9]
[same as prior period, unchanged from 0001045810-19-000079:notes:148]

[0001045810-19-000144:notes:10]
[same as prior period, unchanged from 0001045810-19-000079:notes:149]

[0001045810-19-000144:notes:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The second quarters of fiscal years 2020 and 2019 were both 13-week quarters.

[0001045810-19-000144:notes:12]
[same as prior period, unchanged from 0001045810-19-000079:notes:151]

[0001045810-19-000144:notes:13]
[same as prior period, unchanged from 0001045810-19-000079:notes:152]

[0001045810-19-000144:notes:14]
Principles of Consolidation

[0001045810-19-000144:notes:15]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-19-000144:notes:16]
[same as prior period, unchanged from 0001045810-19-000079:notes:153]

[0001045810-19-000144:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and

[0001045810-19-000144:notes:18]
other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-19-000144:notes:19]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000144:notes:20]
Recently Adopted Accounting Pronouncement

[0001045810-19-000144:notes:21]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases under which lease assets and liabilities are recognized on the balance sheet. We adopted this guidance on January 28, 2019 using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet. Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-19-000144:notes:22]
Recent Accounting Pronouncement Not Yet Adopted

[0001045810-19-000144:notes:23]
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. The standard will be effective for us beginning in the first quarter of fiscal year 2021, with early adoption permitted. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-19-000144:notes:24]
Merger Agreement with Mellanox Technologies, Ltd.
On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox Technologies Ltd., or Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. The closing of the merger is subject to approval by regulatory agencies. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million. We have received regulatory approval in the United States and Mexico and are engaged with regulators in Europe and China. In June 2019, Mellanox shareholders approved the merger.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-19-000144:notes:25]
New Lease Accounting Standard
Method and Impact of Adoption

[0001045810-19-000144:notes:26]
[same as prior period, unchanged from 0001045810-19-000079:notes:118]

[0001045810-19-000144:notes:27]
[same as prior period, unchanged from 0001045810-19-000079:notes:119]

[0001045810-19-000144:notes:28]
[same as prior period, unchanged from 0001045810-19-000079:notes:120]

[0001045810-19-000144:notes:29]
Our lease obligations consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2020 and 2035.

[0001045810-19-000144:notes:30]
Future minimum lease payments under our non-cancelable operating leases as of July 28, 2019, are as follows:

[0001045810-19-000144:notes:31]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2020 (excluding first half of fiscal year 2020) | $ | 55 |  |
| 2021 | 109 |  |
| 2022 | 100 |  |
| 2023 | 81 |  |
| 2024 | 57 |  |
| 2025 and thereafter | 281 |  |
| Total | 683 |  |
| Less imputed interest | 116 |  |
| Present value of net future minimum lease payments | 567 |  |
| Less short-term operating lease liabilities | 84 |  |
| Long-term operating lease liabilities | $ | 483 |  |

[0001045810-19-000144:notes:32]
[same as prior period, unchanged from 0001045810-19-000079:notes:122]

[0001045810-19-000144:notes:33]
[same as prior period, unchanged from 0001045810-19-000079:notes:123]

[0001045810-19-000144:notes:34]
Operating lease expense for the second quarter and first half of fiscal year 2020 was $28 million and $55 million, respectively. Operating lease expense for the second quarter and first half of fiscal year 2019 was $20 million and $36 million, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal year 2020 were not significant.

[0001045810-19-000144:notes:35]
Other information related to leases was as follows:

[0001045810-19-000144:notes:36]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, 2019 |  | July 28, 2019 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 26 |  |  | $ | 50 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 21 |  |  | $ | 108 |  |

[0001045810-19-000144:notes:37]
As of July 28, 2019, our operating leases had a weighted average remaining lease term of 8.7 years and a weighted average discount rate of 3.70%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-19-000144:notes:38]
Stock-Based Compensation
Our stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-19-000144:notes:39]
[same as prior period, unchanged from 0001045810-19-000079:notes:79]

[0001045810-19-000144:notes:40]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, 2019 |  | July 29, 2018 |  | July 28, 2019 |  | July 29, 2018 |
|  | (In millions) |
| Cost of revenue | $ | 8 |  |  | $ | 8 |  |  | $ | 12 |  |  | $ | 16 |  |
| Research and development | 145 |  |  | 76 |  |  | 259 |  |  | 150 |  |
| Sales, general and administrative | 71 |  |  | 48 |  |  | 130 |  |  | 96 |  |
| Total | $ | 224 |  |  | $ | 132 |  |  | $ | 401 |  |  | $ | 262 |  |

[0001045810-19-000144:notes:41]
[same as prior period, unchanged from 0001045810-19-000079:notes:81]

[0001045810-19-000144:notes:42]
[same as prior period, unchanged from 0001045810-19-000079:notes:82]

[0001045810-19-000144:notes:43]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balances, January 27, 2019 | 16 |  |  | $ | 129.92 |  |
| Granted (1) (2) | 6 |  |  | $ | 183.33 |  |
| Vested restricted stock | (4 | ) |  | $ | 67.51 |  |
| Canceled and forfeited | (1 | ) |  | $ | 189.95 |  |
| Balances, July 28, 2019 | 17 |  |  | $ | 161.37 |  |

[0001045810-19-000144:notes:44]
[same as prior period, unchanged from 0001045810-19-000079:notes:84]

[0001045810-19-000144:notes:45]
[same as prior period, unchanged from 0001045810-19-000079:notes:85]

[0001045810-19-000144:notes:46]
As of July 28, 2019, there was $2.06 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.5 years for RSUs, PSUs, and market-based PSUs, and 1.1 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-19-000144:notes:47]
Net Income Per Share
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-19-000144:notes:48]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, |  | July 29, |  | July 28, |  | July 29, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 552 |  |  | $ | 1,101 |  |  | $ | 947 |  |  | $ | 2,345 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 609 |  |  | 607 |  |  | 608 |  |  | 607 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards | 7 |  |  | 18 |  |  | 8 |  |  | 19 |  |
| 1.00% Convertible Senior Notes | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Diluted weighted average shares | 616 |  |  | 626 |  |  | 616 |  |  | 627 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.91 |  |  | $ | 1.81 |  |  | $ | 1.56 |  |  | $ | 3.86 |  |
| Diluted (2) | $ | 0.90 |  |  | $ | 1.76 |  |  | $ | 1.54 |  |  | $ | 3.74 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 11 |  |  | — |  |  | 12 |  |  | 1 |  |

[0001045810-19-000144:notes:49]
[same as prior period, unchanged from 0001045810-19-000079:notes:91]

[0001045810-19-000144:notes:50]
(2)

[0001045810-19-000144:notes:51]
Calculated as net income divided by diluted weighted average shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-19-000144:notes:52]
Income Taxes
We recognized an income tax expense of $54 million and $48 million for the second quarter and first half of fiscal year 2020, respectively, and $79 million and $146 million for the second quarter and first half of fiscal year 2019, respectively. The effective tax rate for the second quarter and first half of fiscal year 2020 was 8.8% and 4.9%, respectively, and 6.7% and 5.9% for the second quarter and first half of fiscal year 2019, respectively.

[0001045810-19-000144:notes:53]
The increase in our effective tax rate for the second quarter of fiscal year 2020 as compared to the second quarter of fiscal year 2019 was primarily due to an increase in the amount of earnings subject to United States tax, and a decrease of tax benefits from stock-based compensation, partially offset by an increase in the impact of tax benefits from the U.S. federal research tax credit. The decrease in our effective tax rate for the first half of fiscal year 2020 as compared to the first half of fiscal year 2019 was primarily due to an increase in the impact of tax benefits from the U.S. federal research tax credit and stock-based compensation.

[0001045810-19-000144:notes:54]
Our effective tax rates for the first half of fiscal years 2020 and 2019 were 4.9% and 5.9%, respectively, and were lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-19-000144:notes:55]
For the first half of fiscal year 2020, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 27, 2019.

[0001045810-19-000144:notes:56]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise

[0001045810-19-000144:notes:57]
resolved with the respective tax authorities. As of July 28, 2019, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-19-000144:notes:58]
Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-19-000144:notes:59]
The following is a summary of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019:

[0001045810-19-000144:notes:60]
|  | July 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 2,868 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,868 |  |  | $ | 2,868 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 2,161 |  |  | — |  |  | — |  |  | 2,161 |  |  | 1,833 |  |  | 328 |  |
| Corporate debt securities | 2,103 |  |  | 1 |  |  | — |  |  | 2,104 |  |  | 1,282 |  |  | 822 |  |
| Debt securities of United States government agencies | 1,120 |  |  | — |  |  | — |  |  | 1,120 |  |  | 995 |  |  | 125 |  |
| Foreign government debt securities | 45 |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Asset-backed securities | 44 |  |  | — |  |  | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Certificates of deposit | 24 |  |  | — |  |  | — |  |  | 24 |  |  | 24 |  |  | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 6 |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total | $ | 8,371 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 8,372 |  |  | $ | 7,002 |  |  | $ | 1,370 |  |

[0001045810-19-000144:notes:61]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government debt securities | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

[0001045810-19-000144:notes:62]
For the second quarter and first half of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.

[0001045810-19-000144:notes:63]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019 are shown below by contractual maturity.

[0001045810-19-000144:notes:64]
|  | July 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 8,255 |  |  | $ | 8,255 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 112 |  |  | 113 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 4 |  |  | 4 |  |  | 22 |  |  | 22 |  |
| Total | $ | 8,371 |  |  | $ | 8,372 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-19-000144:notes:65]
Fair Value of Financial Assets and Liabilities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-19-000144:notes:66]
|  |  | Fair Value at |
|  | Pricing Category |  | July 28, 2019 |  | January 27, 2019 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Money market funds | Level 1 |  | $ | 2,868 |  |  | $ | 483 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 2,161 |  |  | $ | 1,492 |  |
| Corporate debt securities | Level 2 |  | $ | 2,104 |  |  | $ | 2,620 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,120 |  |  | $ | 2,280 |  |
| Foreign government debt securities | Level 2 |  | $ | 45 |  |  | $ | 209 |  |
| Asset-backed securities | Level 2 |  | $ | 44 |  |  | $ | 151 |  |
| Certificates of deposit | Level 2 |  | $ | 24 |  |  | $ | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 6 |  |  | $ | 89 |  |
| Liabilities |  |  |  |  |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 999 |  |  | $ | 978 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 1,022 |  |  | $ | 961 |  |

[0001045810-19-000144:notes:67]
(1)

[0001045810-19-000144:notes:68]
These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-19-000144:notes:69]
Amortizable Intangible Assets
The components of our amortizable intangible assets are as follows:

[0001045810-19-000144:notes:70]
|  | July 28, 2019 |  | January 27, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (190 | ) |  | $ | 5 |  |  | $ | 195 |  |  | $ | (188 | ) |  | $ | 7 |  |
| Patents and licensed technology | 508 |  |  | (464 | ) |  | 44 |  |  | 491 |  |  | (453 | ) |  | 38 |  |
| Total intangible assets | $ | 703 |  |  | $ | (654 | ) |  | $ | 49 |  |  | $ | 686 |  |  | $ | (641 | ) |  | $ | 45 |  |

[0001045810-19-000144:notes:71]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during the first half of fiscal year 2020. Amortization expense associated with intangible assets was $6 million and $13 million for the second quarter and first half of fiscal year 2020, respectively, and $6 million and $17 million for the second quarter and first half of fiscal year 2019, respectively. Future amortization expense related to the net carrying amount of intangible assets as of July 28, 2019 is estimated to be $12 million for the remainder of fiscal year 2020, $16 million in fiscal year 2021, $9 million in fiscal year 2022, $7 million in fiscal year 2023, and $5 million in fiscal year 2024.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-19-000144:notes:72]
Balance Sheet Components 
Certain balance sheet components are as follows:

[0001045810-19-000144:notes:73]
|  | July 28, |  | January 27, |
|  | 2019 |  | 2019 |
| Inventories: | (In millions) |
| Raw materials | $ | 362 |  |  | $ | 613 |  |
| Work in-process | 203 |  |  | 238 |  |
| Finished goods | 639 |  |  | 724 |  |
| Total inventories | $ | 1,204 |  |  | $ | 1,575 |  |

[0001045810-19-000144:notes:74]
|  | July 28, |  | January 27, |
|  | 2019 |  | 2019 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 312 |  |  | $ | 302 |  |
| Accrued payroll and related expenses | 183 |  |  | 186 |  |
| Deferred revenue (1) | 127 |  |  | 92 |  |
| Operating lease liabilities | 84 |  |  | — |  |
| Taxes payable | 37 |  |  | 91 |  |
| Licenses payable | 21 |  |  | 12 |  |
| Coupon interest on debt obligations | 20 |  |  | 20 |  |
| Other | 96 |  |  | 115 |  |
| Total accrued and other current liabilities | $ | 880 |  |  | $ | 818 |  |

[0001045810-19-000144:notes:75]
[same as prior period, unchanged from 0001045810-19-000079:notes:5]

[0001045810-19-000144:notes:76]
|  | July 28, |  | January 27, |
|  | 2019 |  | 2019 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 501 |  |  | $ | 513 |  |
| Deferred revenue (2) | 54 |  |  | 46 |  |
| Licenses payable | 26 |  |  | 1 |  |
| Deferred income tax liability | 23 |  |  | 19 |  |
| Employee benefits liability | 22 |  |  | 20 |  |
| Deferred rent | — |  |  | 21 |  |
| Other | 24 |  |  | 13 |  |
| Total other long-term liabilities | $ | 650 |  |  | $ | 633 |  |

[0001045810-19-000144:notes:77]
| (1) | As of July 28, 2019, represents the long-term portion of the one-time transition tax payable of $317 million, as well as unrecognized tax benefits of $159 million and related interest and penalties of $25 million. |

[0001045810-19-000144:notes:78]
[same as prior period, unchanged from 0001045810-19-000079:notes:9]

[0001045810-19-000144:notes:79]
[same as prior period, unchanged from 0001045810-19-000079:notes:10]

[0001045810-19-000144:notes:80]
The following table shows the changes in deferred revenue during the first half of fiscal years 2020 and 2019.

[0001045810-19-000144:notes:81]
|  | July 28, |  | July 29, |
|  | 2019 |  | 2018 |
|  | (In millions) |
| Balance at beginning of period | $ | 138 |  |  | $ | 63 |  |
| Deferred revenue added during the period | 161 |  |  | 194 |  |
| Revenue recognized during the period | (118 | ) |  | (153 | ) |
| Balance at end of period | $ | 181 |  |  | $ | 104 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-19-000144:notes:82]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of July 28, 2019 and January 27, 2019.

[0001045810-19-000144:notes:83]
[same as prior period, unchanged from 0001045810-19-000079:notes:72]

[0001045810-19-000144:notes:84]
The table below presents the notional value of our foreign currency forward contracts outstanding as of July 28, 2019 and January 27, 2019:

[0001045810-19-000144:notes:85]
|  | July 28, 2019 |  | January 27, 2019 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 420 |  |  | $ | 408 |  |
| Not designated for hedge accounting | $ | 269 |  |  | $ | 241 |  |

[0001045810-19-000144:notes:86]
As of July 28, 2019, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-19-000144:notes:87]
During the second quarter and first half of fiscal years 2020 and 2019, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-19-000144:notes:88]
Debt
Long-Term Debt

[0001045810-19-000144:notes:89]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-19-000144:notes:90]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-19-000144:notes:91]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-19-000144:notes:92]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-19-000144:notes:93]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (11 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,989 |  |  | $ | 1,988 |  |

[0001045810-19-000144:notes:94]
Revolving Credit Facility

[0001045810-19-000144:notes:95]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 28, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000144:notes:96]
Commercial Paper

[0001045810-19-000144:notes:97]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2019, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-19-000144:notes:98]
Commitments and Contingencies
Inventory Purchase Obligations

[0001045810-19-000144:notes:99]
As of July 28, 2019, we had outstanding inventory purchase obligations totaling $757 million.

[0001045810-19-000144:notes:100]
Capital Purchase Obligations

[0001045810-19-000144:notes:101]
As of July 28, 2019, we had outstanding capital purchase obligations totaling $133 million.

[0001045810-19-000144:notes:102]
Performance Obligations

[0001045810-19-000144:notes:103]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of July 28, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $418 million, of which we expect to recognize approximately 48% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-19-000144:notes:104]
Accrual for Product Warranty Liabilities

[0001045810-19-000144:notes:105]
The estimated amount of product returns and warranty liabilities was $17 million and $18 million as of July 28, 2019 and January 27, 2019, respectively.

[0001045810-19-000144:notes:106]
In connection with certain agreements that we have entered in the past, we have provided indemnification to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-19-000144:notes:107]
Litigation

[0001045810-19-000144:notes:108]
Securities Class Action and Derivative Lawsuits

[0001045810-19-000144:notes:109]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

[0001045810-19-000144:notes:110]
On January 18, 2019, a shareholder, purporting to act on the behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-19-000144:notes:111]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-19-000144:notes:112]
Litigation Related to Mellanox Merger

[0001045810-19-000144:notes:113]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Securities Exchange Act of 1934 and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but to date, NVIDIA has not been named as a defendant in any of these other lawsuits.

[0001045810-19-000144:notes:114]
Accounting for Loss Contingencies

[0001045810-19-000144:notes:115]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of July 28, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-19-000144:notes:116]
Shareholders’ Equity 
Capital Return Program

[0001045810-19-000144:notes:117]
[same as prior period, unchanged from 0001045810-19-000079:notes:157]

[0001045810-19-000144:notes:118]
During the second quarter and first half of fiscal year 2020, we paid $97 million and $195 million, respectively, in cash dividends to our shareholders.

[0001045810-19-000144:notes:119]
Through July 28, 2019, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of July 28, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000144:notes:120]
[same as prior period, unchanged from 0001045810-19-000079:notes:160]

[0001045810-19-000144:notes:121]
As of July 28, 2019 and January 27, 2019, there were no shares of preferred stock outstanding.

[0001045810-19-000144:notes:122]
[same as prior period, unchanged from 0001045810-19-000079:notes:162]

[0001045810-19-000144:notes:123]
[same as prior period, unchanged from 0001045810-19-000079:notes:163]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-19-000144:notes:124]
Segment Information
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-19-000144:notes:125]
[same as prior period, unchanged from 0001045810-19-000079:notes:137]

[0001045810-19-000144:notes:126]
[same as prior period, unchanged from 0001045810-19-000079:notes:138]

[0001045810-19-000144:notes:127]
Under the single unifying architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating

[0001045810-19-000144:notes:128]
expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-19-000144:notes:129]
The “All Other” category presented below represents the expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, contributions, restructuring and other charges, product warranty charge, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-19-000144:notes:130]
[same as prior period, unchanged from 0001045810-19-000079:notes:141]

[0001045810-19-000144:notes:131]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 28, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 2,104 |  |  | $ | 475 |  |  | $ | — |  |  | $ | 2,579 |  |
| Depreciation and amortization expense | $ | 76 |  |  | $ | 12 |  |  | $ | 4 |  |  | $ | 92 |  |
| Operating income (loss) | $ | 746 |  |  | $ | 122 |  |  | $ | (297 | ) |  | $ | 571 |  |
| Three Months Ended July 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,656 |  |  | $ | 467 |  |  | $ | — |  |  | $ | 3,123 |  |
| Depreciation and amortization expense | $ | 43 |  |  | $ | 12 |  |  | $ | 3 |  |  | $ | 58 |  |
| Operating income (loss) | $ | 1,259 |  |  | $ | 97 |  |  | $ | (199 | ) |  | $ | 1,157 |  |
| Six Months Ended July 28, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 4,126 |  |  | $ | 673 |  |  | $ | — |  |  | $ | 4,799 |  |
| Depreciation and amortization expense | $ | 152 |  |  | $ | 24 |  |  | $ | 7 |  |  | $ | 183 |  |
| Operating income (loss) | $ | 1,415 |  |  | $ | 78 |  |  | $ | (564 | ) |  | $ | 929 |  |
| Six Months Ended July 29, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 5,421 |  |  | $ | 909 |  |  | $ | — |  |  | $ | 6,330 |  |
| Depreciation and amortization expense | $ | 83 |  |  | $ | 22 |  |  | $ | 11 |  |  | $ | 116 |  |
| Operating income (loss) | $ | 2,653 |  |  | $ | 194 |  |  | $ | (395 | ) |  | $ | 2,452 |  |

[0001045810-19-000144:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, 2019 |  | July 29, 2018 |  | July 28, 2019 |  | July 29, 2018 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (224 | ) |  | $ | (132 | ) |  | $ | (401 | ) |  | $ | (262 | ) |
| Unallocated cost of revenue and operating expenses | (66 | ) |  | (65 | ) |  | (135 | ) |  | (129 | ) |
| Acquisition-related and other costs | (5 | ) |  | (2 | ) |  | (15 | ) |  | (4 | ) |
| Legal settlement costs | (2 | ) |  | — |  |  | (13 | ) |  | — |  |
| Total | $ | (297 | ) |  | $ | (199 | ) |  | $ | (564 | ) |  | $ | (395 | ) |

[0001045810-19-000144:notes:133]
[same as prior period, unchanged from 0001045810-19-000079:notes:142]

[0001045810-19-000144:notes:134]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, |  | July 29, |  | July 28, |  | July 29, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Other Asia Pacific | $ | 756 |  |  | $ | 676 |  |  | $ | 1,178 |  |  | $ | 1,259 |  |
| Taiwan | 635 |  |  | 843 |  |  | 1,333 |  |  | 1,810 |  |
| China (including Hong Kong) | 583 |  |  | 760 |  |  | 1,136 |  |  | 1,514 |  |
| Europe | 288 |  |  | 234 |  |  | 537 |  |  | 469 |  |
| United States | 188 |  |  | 413 |  |  | 353 |  |  | 847 |  |
| Other countries | 129 |  |  | 197 |  |  | 262 |  |  | 431 |  |
| Total revenue | $ | 2,579 |  |  | $ | 3,123 |  |  | $ | 4,799 |  |  | $ | 6,330 |  |

[0001045810-19-000144:notes:135]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-19-000144:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | July 28, |  | July 29, |  | July 28, |  | July 29, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,313 |  |  | $ | 1,805 |  |  | $ | 2,368 |  |  | $ | 3,528 |  |
| Professional Visualization | 291 |  |  | 281 |  |  | 557 |  |  | 532 |  |
| Data Center | 655 |  |  | 760 |  |  | 1,289 |  |  | 1,461 |  |
| Automotive | 209 |  |  | 161 |  |  | 375 |  |  | 306 |  |
| OEM and Other | 111 |  |  | 116 |  |  | 210 |  |  | 503 |  |
| Total revenue | $ | 2,579 |  |  | $ | 3,123 |  |  | $ | 4,799 |  |  | $ | 6,330 |  |

[0001045810-19-000144:notes:137]
One customer represented approximately 11% of our total revenue for the second quarter and the first half of fiscal year 2020, and was attributable primarily to the GPU business. No customer represented 10% or more of total revenue for the second quarter and first half of fiscal year 2019.

[0001045810-19-000144:notes:138]
One customer represented approximately 20% of our accounts receivable balance as of July 28, 2019, and one customer represented approximately 19% of our accounts receivable balance as of January 27, 2019.
