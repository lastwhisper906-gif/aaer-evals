# NVDA 8-K — 0001045810-19-000140 filed 2019-08-15

## item codes, every 8-K on or before 2019-08-15

- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2019-08-15

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-19-000140:8k_2_02:1]
EX-99.1
2
q2fy20pr.htm
Q2FY20 PRESS RELEASE

[0001045810-19-000140:8k_2_02:2]
Exhibit

[0001045810-19-000140:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-19-000140:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2020

[0001045810-19-000140:8k_2_02:5]
SANTA CLARA, Calif.-Aug. 15, 2019-NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 28, 2019, of $2.58 billion compared with $3.12 billion a year earlier and $2.22 billion in the previous quarter.

[0001045810-19-000140:8k_2_02:6]
GAAP earnings per diluted share for the quarter were $0.90, compared with $1.76 a year ago and $0.64 in the previous quarter. Non-GAAP earnings per diluted share were $1.24 compared with $1.94 a year earlier and $0.88 in the previous quarter.

[0001045810-19-000140:8k_2_02:7]
“We achieved sequential growth across our platforms,” said Jensen Huang, founder and CEO of NVIDIA. “Real-time ray tracing is the most important graphics innovation in a decade. Adoption has reached a tipping point, with NVIDIA RTX leading the way.

[0001045810-19-000140:8k_2_02:8]
“NVIDIA accelerated computing momentum continues to build as the industry races to enable the next frontier in artificial intelligence, conversational AI, as well as autonomous systems like self-driving vehicles and delivery robots,” he said.

[0001045810-19-000140:8k_2_02:9]
NVIDIA will pay its next quarterly cash dividend of $0.16 per share on September 20, 2019, to all shareholders of record on August 29, 2019. The first priority of the company’s cash balance is the purchase of Mellanox Technologies, Ltd. The company will return to repurchasing its stock after the close of the Mellanox acquisition. The regulatory approval process for this acquisition is progressing as expected, and NVIDIA continues to work toward closing the deal by the end of this calendar year.

[0001045810-19-000140:8k_2_02:10]
Q2 Fiscal 2020 Summary

[0001045810-19-000140:8k_2_02:11]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY20 | Q1 FY20 | Q2 FY19 | Q/Q | Y/Y |
| Revenue | $2,579 | $2,220 | $3,123 | Up 16% | Down 17% |
| Gross margin | 59.8 | % | 58.4 | % | 63.3 | % | Up 140 bps | Down 350 bps |
| Operating expenses | $970 | $938 | $818 | Up 3% | Up 19% |
| Operating income | $571 | $358 | $1,157 | Up 59% | Down 51% |
| Net income | $552 | $394 | $1,101 | Up 40% | Down 50% |
| Diluted earnings per share | $0.90 | $0.64 | $1.76 | Up 41% | Down 49% |

[0001045810-19-000140:8k_2_02:12]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY20 | Q1 FY20 | Q2 FY19 | Q/Q | Y/Y |
| Revenue | $2,579 | $2,220 | $3,123 | Up 16% | Down 17% |
| Gross margin | 60.1 | % | 59.0 | % | 63.5 | % | Up 110 bps | Down 340 bps |
| Operating expenses | $749 | $753 | $692 | Down 1% | Up 8% |
| Operating income | $802 | $557 | $1,290 | Up 44% | Down 38% |
| Net income | $762 | $543 | $1,210 | Up 40% | Down 37% |
| Diluted earnings per share | $1.24 | $0.88 | $1.94 | Up 41% | Down 36% |

[0001045810-19-000140:8k_2_02:13]
NVIDIA’s outlook for the third quarter of fiscal 2020 is as follows:

[0001045810-19-000140:8k_2_02:14]
| • | Revenue is expected to be $2.90 billion, plus or minus 2 percent. |

[0001045810-19-000140:8k_2_02:15]
| • | GAAP and non-GAAP gross margins are expected to be 62.0 percent and 62.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-19-000140:8k_2_02:16]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $980 million and $765 million, respectively. |

[0001045810-19-000140:8k_2_02:17]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $25 million. |

[0001045810-19-000140:8k_2_02:18]
| • | GAAP and non-GAAP tax rates are both expected to be 10 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-19-000140:8k_2_02:19]
Highlights

[0001045810-19-000140:8k_2_02:20]
Since the end of the first quarter of fiscal 2020, NVIDIA has achieved progress in these areas:

[0001045810-19-000140:8k_2_02:21]
Data Center

[0001045810-19-000140:8k_2_02:22]
| • | Announced breakthroughs in language understanding that allow organizations to enable real-time conversational AI, with record-setting performance in running training and inference on the BERT AI language model. |

[0001045810-19-000140:8k_2_02:23]
| • | Announced that NVIDIA’s DGX SuperPOD™ - which provides the AI infrastructure for the company’s autonomous-vehicle development program - was ranked the world’s 22nd fastest supercomputer and that its reference architecture is available commercially through partners. |

[0001045810-19-000140:8k_2_02:24]
| • | Set eight records in AI training performance in the latest MLPerf benchmarking tests. |

[0001045810-19-000140:8k_2_02:25]
| • | Announced support for Arm CPUs, providing a new path to build highly energy-efficient, AI-enabled exascale supercomputers. |

[0001045810-19-000140:8k_2_02:26]
Gaming

[0001045810-19-000140:8k_2_02:27]
| • | Supercharged its GPU lineup with GeForce® RTX 2060 SUPER™, GeForce RTX 2070 SUPER and GeForce RTX 2080 SUPER, delivering best-in-class gaming performance and real-time ray tracing. |

[0001045810-19-000140:8k_2_02:28]
| • | Announced that new blockbuster titles including Call of Duty: Modern Warfare, Cyberpunk 2077, Watch Dogs: Legion, and Wolfenstein: Youngblood will feature ray tracing, propelling the momentum of RTX technology. |

[0001045810-19-000140:8k_2_02:29]
| • | Unveiled the new NVIDIA Studio® platform for the world’s tens of millions of online and studio-based creatives, with the introduction of 27 new RTX Studio laptops powered by GeForce RTX™ and Quadro RTX™ GPUs. |

[0001045810-19-000140:8k_2_02:30]
| • | Announced the launch of 25 more gaming laptops by major makers fueled by NVIDIA Turing™ GPUs, bringing the total number of Turing laptops to more than 100. |

[0001045810-19-000140:8k_2_02:31]
Professional Visualization

[0001045810-19-000140:8k_2_02:32]
| • | Announced that in its first full year, NVIDIA RTX™ ray tracing has emerged as the new industry standard in product design, architecture, effects and scientific visualization, with the support of more than 40 key applications, including eight introduced at SIGGRAPH. |

[0001045810-19-000140:8k_2_02:33]
| • | Rolled out a full range of Turing architecture-based Quadro® GPUs for mobile workstations with global system providers. |

[0001045810-19-000140:8k_2_02:34]
Automotive

[0001045810-19-000140:8k_2_02:35]
| • | Volvo Group announced that it is using the NVIDIA DRIVE™ end-to-end autonomous driving platform to train networks in the data center, test them in simulation and deploy them in self-driving vehicles, targeting freight transport, refuse and recycling collection, public transport, construction, mining, forestry and more. |

[0001045810-19-000140:8k_2_02:36]
CFO Commentary

[0001045810-19-000140:8k_2_02:37]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-19-000140:8k_2_02:38]
Conference Call and Webcast Information

[0001045810-19-000140:8k_2_02:39]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2020 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2020.

[0001045810-19-000140:8k_2_02:40]
Non-GAAP Measures

[0001045810-19-000140:8k_2_02:41]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related and other costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchase of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-19-000140:8k_2_02:42]
About NVIDIA

[0001045810-19-000140:8k_2_02:43]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-19-000140:8k_2_02:44]
###

[0001045810-19-000140:8k_2_02:45]
For further information, contact:

[0001045810-19-000140:8k_2_02:46]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-19-000140:8k_2_02:47]
Certain statements in this press release including, but not limited to, statements as to: real-time ray tracing being the most important graphics innovation in a decade; adoption of ray tracing reaching a tipping point with RTX leading the way; NVIDIA accelerated computing momentum continuing to build as the industry races to enable the next frontier of artificial intelligence and autonomous systems; NVIDIA’s intended capital return; NVIDIA’s next quarterly cash dividend; the priority of NVIDIA’s cash balance being the purchase of Mellanox; NVIDIA returning to repurchasing its stock after the close of the Mellanox acquisition; the regulatory approval process for the Mellanox acquisition progressing and NVIDIA continuing to work toward closing the deal by the end of this calendar year; NVIDIA’s financial outlook for the third quarter of fiscal 2020; NVIDIA’s expected tax rates for the third quarter of fiscal 2020; NVIDIA’s expectation to generate variability from excess tax benefits or deficiencies; NVIDIA’s support for Arm CPUs providing a path to build exascale supercomputers; breakthroughs in language understanding enabling real-time conversational AI and its performance; NVIDIA DGX SuperPOD’s availability; new games featuring ray tracing and it propelling the momentum of RTX technology; the launch of laptops by major makers; the benefits, impact and performance of our technologies, including the RTX SUPER GPU lines, NVIDIA Studio platform and NVIDIA RTX ray tracing; NVIDIA RTX ray tracing emerging as the new industry standard and supporting more than 40 key applications; and Volvo Group’s uses of NVIDIA DRIVE are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-19-000140:8k_2_02:48]
© 2019 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce RTX, GeForce RTX SUPER, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA RTX, NVIDIA Turing, Quadro and Quadro RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000140:8k_2_02:49]
NVIDIA CORPORATION

[0001045810-19-000140:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-19-000140:8k_2_02:51]
(In millions, except per share data)

[0001045810-19-000140:8k_2_02:52]
(Unaudited)

[0001045810-19-000140:8k_2_02:53]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | July 29, |  | July 28, |  | July 29, |
|  |  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue | $ | 2,579 |  |  | $ | 3,123 |  |  | $ | 4,799 |  |  | $ | 6,330 |  |
| Cost of revenue | 1,038 |  |  | 1,148 |  |  | 1,962 |  |  | 2,287 |  |
| Gross profit | 1,541 |  |  | 1,975 |  |  | 2,837 |  |  | 4,043 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 704 |  |  | 581 |  |  | 1,379 |  |  | 1,124 |  |
|  | Sales, general and administrative | 266 |  |  | 237 |  |  | 529 |  |  | 467 |  |
|  |  | Total operating expenses | 970 |  |  | 818 |  |  | 1,908 |  |  | 1,591 |  |
| Income from operations | 571 |  |  | 1,157 |  |  | 929 |  |  | 2,452 |  |
|  | Interest income | 47 |  |  | 32 |  |  | 92 |  |  | 57 |  |
|  | Interest expense | (13 | ) |  | (14 | ) |  | (27 | ) |  | (29 | ) |
|  | Other, net | 1 |  |  | 5 |  |  | 1 |  |  | 11 |  |
|  |  | Total other income (expense) | 35 |  |  | 23 |  |  | 66 |  |  | 39 |  |
| Income before income tax | 606 |  |  | 1,180 |  |  | 995 |  |  | 2,491 |  |
| Income tax expense | 54 |  |  | 79 |  |  | 48 |  |  | 146 |  |
| Net income | $ | 552 |  |  | $ | 1,101 |  |  | $ | 947 |  |  | $ | 2,345 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.91 |  |  | $ | 1.81 |  |  | $ | 1.56 |  |  | $ | 3.86 |  |
|  | Diluted | $ | 0.90 |  |  | $ | 1.76 |  |  | $ | 1.54 |  |  | $ | 3.74 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 609 |  |  | 607 |  |  | 608 |  |  | 607 |  |
|  | Diluted | 616 |  |  | 626 |  |  | 616 |  |  | 627 |  |

[0001045810-19-000140:8k_2_02:54]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | July 28, |  | January 27, |
|  |  |  |  | 2019 |  | 2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 8,475 |  |  | $ | 7,422 |  |
|  | Accounts receivable, net |  | 1,561 |  |  | 1,424 |  |
|  | Inventories |  | 1,204 |  |  | 1,575 |  |
|  | Prepaid expenses and other current assets |  | 151 |  |  | 136 |  |
|  |  | Total current assets |  | 11,391 |  |  | 10,557 |  |
| Property and equipment, net |  | 1,484 |  |  | 1,404 |  |
| Operating lease assets |  | 535 |  |  | — |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 49 |  |  | 45 |  |
| Deferred income tax assets |  | 588 |  |  | 560 |  |
| Other assets |  | 110 |  |  | 108 |  |
|  |  | Total assets |  | $ | 14,775 |  |  | $ | 13,292 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 437 |  |  | $ | 511 |  |
|  | Accrued and other current liabilities |  | 880 |  |  | 818 |  |
|  |  | Total current liabilities |  | 1,317 |  |  | 1,329 |  |
| Long-term debt |  | 1,989 |  |  | 1,988 |  |
| Long-term operating lease liabilities |  | 483 |  |  | — |  |
| Other long-term liabilities |  | 650 |  |  | 633 |  |
|  |  | Total liabilities |  | 4,439 |  |  | 3,950 |  |
| Shareholders' equity |  | 10,336 |  |  | 9,342 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 14,775 |  |  | $ | 13,292 |  |

[0001045810-19-000140:8k_2_02:55]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 29, |  | July 28, |  | July 29, |
|  |  |  | 2019 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 1,541 |  |  | $ | 1,296 |  |  | $ | 1,975 |  |  | $ | 2,837 |  |  | $ | 4,043 |  |
| GAAP gross margin |  | 59.8 | % |  | 58.4 | % |  | 63.3 | % |  | 59.1 | % |  | 63.9 | % |
|  | Stock-based compensation expense (A) |  | 8 |  |  | 4 |  |  | 8 |  |  | 12 |  |  | 16 |  |
|  | Legal settlement costs |  | 2 |  |  | 10 |  |  | — |  |  | 11 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 1,551 |  |  | $ | 1,310 |  |  | $ | 1,983 |  |  | $ | 2,860 |  |  | $ | 4,059 |  |
| Non-GAAP gross margin |  | 60.1 | % |  | 59.0 | % |  | 63.5 | % |  | 59.6 | % |  | 64.1 | % |
| GAAP operating expenses |  | $ | 970 |  |  | $ | 938 |  |  | $ | 818 |  |  | $ | 1,908 |  |  | $ | 1,591 |  |
|  | Stock-based compensation expense (A) |  | (216 | ) |  | (174 | ) |  | (124 | ) |  | (389 | ) |  | (246 | ) |
|  | Acquisition-related and other costs |  | (5 | ) |  | (10 | ) |  | (2 | ) |  | (15 | ) |  | (4 | ) |
|  | Legal settlement costs |  | — |  |  | (1 | ) |  | — |  |  | (2 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 749 |  |  | $ | 753 |  |  | $ | 692 |  |  | $ | 1,502 |  |  | $ | 1,341 |  |
| GAAP income from operations |  | $ | 571 |  |  | $ | 358 |  |  | $ | 1,157 |  |  | $ | 929 |  |  | $ | 2,452 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 231 |  |  | 199 |  |  | 133 |  |  | 429 |  |  | 266 |  |
| Non-GAAP income from operations |  | $ | 802 |  |  | $ | 557 |  |  | $ | 1,290 |  |  | $ | 1,358 |  |  | $ | 2,718 |  |
| GAAP other income (expense) |  | $ | 35 |  |  | $ | 31 |  |  | $ | 23 |  |  | $ | 66 |  |  | $ | 39 |  |
|  | Gains from non-affiliated investments |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (8 | ) |
|  | Interest expense related to amortization of debt discount |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Non-GAAP other income (expense) |  | $ | 35 |  |  | $ | 31 |  |  | $ | 21 |  |  | $ | 67 |  |  | $ | 32 |  |
| GAAP net income |  | $ | 552 |  |  | $ | 394 |  |  | $ | 1,101 |  |  | $ | 947 |  |  | $ | 2,345 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 231 |  |  | 199 |  |  | 131 |  |  | 430 |  |  | 259 |  |
|  | Income tax impact of non-GAAP adjustments (B) |  | (21 | ) |  | (50 | ) |  | (22 | ) |  | (72 | ) |  | (109 | ) |
| Non-GAAP net income |  | $ | 762 |  |  | $ | 543 |  |  | $ | 1,210 |  |  | $ | 1,305 |  |  | $ | 2,495 |  |

[0001045810-19-000140:8k_2_02:56]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 29, |  | July 28, |  | July 29, |
|  |  |  | 2019 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.90 |  |  | $ | 0.64 |  |  | $ | 1.76 |  |  | $ | 1.54 |  |  | $ | 3.74 |  |
|  | Non-GAAP |  | $ | 1.24 |  |  | $ | 0.88 |  |  | $ | 1.94 |  |  | $ | 2.12 |  |  | $ | 3.99 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | 616 |  |  | 616 |  |  | 626 |  |  | 616 |  |  | 627 |  |
|  | Anti-dilution impact from note hedge |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
|  | Non-GAAP |  | 616 |  |  | 616 |  |  | 625 |  |  | 616 |  |  | 626 |  |
| GAAP net cash provided by operating activities |  | $ | 936 |  |  | $ | 720 |  |  | $ | 913 |  |  | $ | 1,656 |  |  | $ | 2,358 |  |
|  | Purchase of property and equipment and intangible assets |  | (113 | ) |  | (128 | ) |  | (128 | ) |  | (241 | ) |  | (247 | ) |
| Free cash flow |  | $ | 823 |  |  | $ | 592 |  |  | $ | 785 |  |  | $ | 1,415 |  |  | $ | 2,111 |  |

[0001045810-19-000140:8k_2_02:57]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 28, |  | April 28, |  | July 29, |  | July 28, |  | July 29, |
|  |  |  | 2019 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Cost of revenue |  | $ | 8 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 12 |  |  | $ | 16 |  |
|  | Research and development |  | $ | 145 |  |  | $ | 114 |  |  | $ | 76 |  |  | $ | 259 |  |  | $ | 150 |  |
|  | Sales, general and administrative |  | $ | 71 |  |  | $ | 60 |  |  | $ | 48 |  |  | $ | 130 |  |  | $ | 96 |  |
| (B) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-19-000140:8k_2_02:58]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2020 Outlook |
| GAAP gross margin |  | 62.0 | % |
|  | Impact of stock-based compensation expense |  | 0.5 | % |
| Non-GAAP gross margin |  | 62.5 | % |
|  |  |  | Q3 FY2020 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 980 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (215 | ) |
| Non-GAAP operating expenses |  | $ | 765 |  |
