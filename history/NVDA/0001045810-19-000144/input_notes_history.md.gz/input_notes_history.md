# NVDA note change history — 0001045810-19-000079 → 0001045810-19-000144


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-15):
[0001045810-19-000144:note_history:1]
Commitments and Contingencies
Inventory Purchase Obligations
  (was, 2019-05-16, similarity 0.6667):
[0001045810-19-000079:note_history:1]
Inventory Purchase Obligations

- changed (2019-08-15):
[0001045810-19-000144:note_history:2]
As of July 28, 2019, we had outstanding inventory purchase obligations totaling $757 million.
  (was, 2019-05-16, similarity 0.9591):
[0001045810-19-000079:note_history:2]
As of April 28, 2019, we had outstanding inventory purchase obligations totaling $782 million.

- changed (2019-08-15):
[0001045810-19-000144:note_history:3]
As of July 28, 2019, we had outstanding capital purchase obligations totaling $133 million.
  (was, 2019-05-16, similarity 0.9581):
[0001045810-19-000079:note_history:3]
As of April 28, 2019, we had outstanding capital purchase obligations totaling $194 million.

- changed (2019-08-15):
[0001045810-19-000144:note_history:4]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of July 28, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $418 million, of which we expect to recognize approximately 48% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.
  (was, 2019-05-16, similarity 0.9917):
[0001045810-19-000079:note_history:4]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of April 28, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $294 million, of which we expect to recognize approximately 57% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

- changed (2019-08-15):
[0001045810-19-000144:note_history:5]
The estimated amount of product returns and warranty liabilities was $17 million and $18 million as of July 28, 2019 and January 27, 2019, respectively.
  (was, 2019-05-16, similarity 0.8392):
[0001045810-19-000079:note_history:5]
The estimated amount of product returns and warranty liabilities was $18 million as of both April 28, 2019 and January 27, 2019.

- added (2019-08-15):
[0001045810-19-000144:note_history:6]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

- changed (2019-08-15):
[0001045810-19-000144:note_history:7]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.
  (was, 2019-05-16, similarity 0.965):
[0001045810-19-000079:note_history:7]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming us and/or our officers and directors as defendants.

- added (2019-08-15):
[0001045810-19-000144:note_history:8]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of July 28, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.

- removed (2019-08-15):
[0001045810-19-000079:note_history:9]
Commitments and Contingencies

- removed (2019-08-15):
[0001045810-19-000079:note_history:10]
Polaris Innovations Limited

- removed (2019-08-15):
[0001045810-19-000079:note_history:11]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States and Germany.

- removed (2019-08-15):
[0001045810-19-000079:note_history:12]
NVIDIA and Polaris entered into an agreement effective April 3, 2019 that settled the litigation between the parties, which had an immaterial impact on our financial results. The agreement includes a license to NVIDIA for certain patents owned by Polaris, as well as options for NVIDIA to renew the license through the life of the patents.

- removed (2019-08-15):
[0001045810-19-000079:note_history:13]
ZiiLabs 1 Patents Lawsuit

- removed (2019-08-15):
[0001045810-19-000079:note_history:14]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA had infringed and was continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint sought unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 1 Patents.

- removed (2019-08-15):
[0001045810-19-000079:note_history:15]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the U.S. International Trade Commission, or USITC, investigation over the ZiiLabs 2 patents.

- removed (2019-08-15):
[0001045810-19-000079:note_history:16]
On February 1, 2019, NVIDIA entered into an agreement in which it received a license to the ZiiLabs patents and a dismissal of the ZiiLabs 1 and 2 Patent Lawsuits, which had an immaterial impact on our financial results. The ZiiLabs 1 and 2 district court cases were dismissed pursuant to a stipulation of dismissal filed on February 8, 2019. The Administrative Law Judge issued an Initial Determination on February 12, 2019, granting the motion to terminate the USITC investigation addressing the ZiiLabs 2 patents.

- removed (2019-08-15):
[0001045810-19-000079:note_history:17]
ZiiLabs 2 Patents Lawsuits

- removed (2019-08-15):
[0001045810-19-000079:note_history:18]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also sought unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 2 Patents.

- removed (2019-08-15):
[0001045810-19-000079:note_history:19]
On December 29, 2017, ZiiLabs filed a request with the USITC to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleged that the unlawful importation resulted from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

- removed (2019-08-15):
[0001045810-19-000079:note_history:20]
On February 1, 2019, NVIDIA entered into an agreement in which it received a license to the ZiiLabs patents and a dismissal of the ZiiLabs 1 and 2 Patent Lawsuits, which had an immaterial impact on our financial results. The ZiiLabs 1 and 2 district court cases were dismissed pursuant to a stipulation of dismissal filed on February 8, 2019. The Administrative Law Judge issued an Initial Determination on February 12, 2019, granting the motion to terminate the USITC investigation addressing the ZiiLabs 2 patents.

- removed (2019-08-15):
[0001045810-19-000079:note_history:21]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. The complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between August 10, 2017 and November 15, 2018. The plaintiff also alleges that the NVIDIA officers who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiff seeks class certification, an award of unspecified compensatory damages, an award of equitable/injunctive or other further relief as the Court may deem just and proper. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief.  On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiff and lead counsel.

- removed (2019-08-15):
[0001045810-19-000079:note_history:22]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of April 28, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-15):
[0001045810-19-000144:note_history:23]
Summary of Significant Accounting Policies
Basis of Presentation
  (was, 2019-05-16, similarity 0.7925):
[0001045810-19-000079:note_history:23]
Summary of Significant Accounting Policies

- changed (2019-08-15):
[0001045810-19-000144:note_history:24]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The second quarters of fiscal years 2020 and 2019 were both 13-week quarters.
  (was, 2019-05-16, similarity 0.9759):
[0001045810-19-000079:note_history:24]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The first quarters of fiscal years 2020 and 2019 were both 13-week quarters.

- changed (2019-08-15):
[0001045810-19-000144:note_history:25]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and
  (was, 2019-05-16, similarity 0.9179):
[0001045810-19-000079:note_history:25]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- added (2019-08-15):
[0001045810-19-000144:note_history:26]
other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- removed (2019-08-15):
[0001045810-19-000079:note_history:27]
Basis of Presentation


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-15):
[0001045810-19-000144:note_history:28]
Debt
Long-Term Debt
  (was, 2019-05-16, similarity 0.8485):
[0001045810-19-000079:note_history:28]
Long-Term Debt

- changed (2019-08-15):
[0001045810-19-000144:note_history:29]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.
  (was, 2019-05-16, similarity 0.9812):
[0001045810-19-000079:note_history:29]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

- changed (2019-08-15):
[0001045810-19-000144:note_history:30]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (11 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,989 |  |  | $ | 1,988 |  |
  (was, 2019-05-16, similarity 0.9904):
[0001045810-19-000079:note_history:30]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (12 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,988 |  |  | $ | 1,988 |  |

- changed (2019-08-15):
[0001045810-19-000144:note_history:31]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 28, 2019, we had not borrowed any amounts under this agreement.
  (was, 2019-05-16, similarity 0.8627):
[0001045810-19-000079:note_history:31]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 28, 2019, we had not borrowed any amounts under this agreement.

- changed (2019-08-15):
[0001045810-19-000144:note_history:32]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2019, we had not issued any commercial paper.
  (was, 2019-05-16, similarity 0.9749):
[0001045810-19-000079:note_history:32]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2019, we had not issued any commercial paper.

- removed (2019-08-15):
[0001045810-19-000079:note_history:33]
Debt


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-15):
[0001045810-19-000144:note_history:34]
The following is a summary of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019:
  (was, 2019-05-16, similarity 0.9665):
[0001045810-19-000079:note_history:34]
The following is a summary of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019:

- added (2019-08-15):
[0001045810-19-000144:note_history:35]
|  | July 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 2,868 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,868 |  |  | $ | 2,868 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 2,161 |  |  | — |  |  | — |  |  | 2,161 |  |  | 1,833 |  |  | 328 |  |
| Corporate debt securities | 2,103 |  |  | 1 |  |  | — |  |  | 2,104 |  |  | 1,282 |  |  | 822 |  |
| Debt securities of United States government agencies | 1,120 |  |  | — |  |  | — |  |  | 1,120 |  |  | 995 |  |  | 125 |  |
| Foreign government debt securities | 45 |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Asset-backed securities | 44 |  |  | — |  |  | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Certificates of deposit | 24 |  |  | — |  |  | — |  |  | 24 |  |  | 24 |  |  | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 6 |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total | $ | 8,371 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 8,372 |  |  | $ | 7,002 |  |  | $ | 1,370 |  |

- changed (2019-08-15):
[0001045810-19-000144:note_history:36]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government debt securities | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |
  (was, 2019-05-16, similarity 0.9916):
[0001045810-19-000079:note_history:36]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

- changed (2019-08-15):
[0001045810-19-000144:note_history:37]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019 are shown below by contractual maturity.
  (was, 2019-05-16, similarity 0.9783):
[0001045810-19-000079:note_history:37]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019 are shown below by contractual maturity.

- changed (2019-08-15):
[0001045810-19-000144:note_history:38]
|  | July 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 8,255 |  |  | $ | 8,255 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 112 |  |  | 113 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 4 |  |  | 4 |  |  | 22 |  |  | 22 |  |
| Total | $ | 8,371 |  |  | $ | 8,372 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |
  (was, 2019-05-16, similarity 0.9903):
[0001045810-19-000079:note_history:38]
|  | April 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,773 |  |  | $ | 5,770 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 1,896 |  |  | 1,898 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 23 |  |  | 23 |  |  | 22 |  |  | 22 |  |
| Total | $ | 7,692 |  |  | $ | 7,691 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |

- removed (2019-08-15):
[0001045810-19-000079:note_history:39]
|  | April 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,899 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 2,899 |  |  | $ | 1,048 |  |  | $ | 1,851 |  |
| Debt securities of United States government agencies | 1,882 |  |  | — |  |  | (1 | ) |  | 1,881 |  |  | — |  |  | 1,881 |  |
| Debt securities issued by the United States Treasury | 1,833 |  |  | — |  |  | — |  |  | 1,833 |  |  | 932 |  |  | 901 |  |
| Money market funds | 681 |  |  | — |  |  | — |  |  | 681 |  |  | 681 |  |  | — |  |
| Foreign government bonds | 183 |  |  | — |  |  | — |  |  | 183 |  |  | — |  |  | 183 |  |
| Asset-backed securities | 133 |  |  | — |  |  | (1 | ) |  | 132 |  |  | — |  |  | 132 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 81 |  |  | 1 |  |  | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total | $ | 7,692 |  |  | $ | 3 |  |  | $ | (4 | ) |  | $ | 7,691 |  |  | $ | 2,661 |  |  | $ | 5,030 |  |

- removed (2019-08-15):
[0001045810-19-000079:note_history:40]
The following table provides the breakdown of unrealized losses as of April 28, 2019, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- removed (2019-08-15):
[0001045810-19-000079:note_history:41]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,429 |  |  | $ | — |  |  | $ | 306 |  |  | $ | (1 | ) |  | $ | 1,735 |  |  | $ | (1 | ) |
| Corporate debt securities | 330 |  |  | (1 | ) |  | 453 |  |  | (1 | ) |  | 783 |  |  | (2 | ) |
| Asset-backed securities | — |  |  | — |  |  | 132 |  |  | (1 | ) |  | 132 |  |  | (1 | ) |
| Total | $ | 1,759 |  |  | $ | (1 | ) |  | $ | 891 |  |  | $ | (3 | ) |  | $ | 2,650 |  |  | $ | (4 | ) |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-15):
[0001045810-19-000144:note_history:42]
Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.
  (was, 2019-05-16, similarity 0.9027):
[0001045810-19-000079:note_history:42]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

- changed (2019-08-15):
[0001045810-19-000144:note_history:43]
The following is a summary of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019:
  (was, 2019-05-16, similarity 0.9665):
[0001045810-19-000079:note_history:43]
The following is a summary of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019:

- added (2019-08-15):
[0001045810-19-000144:note_history:44]
|  | July 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 2,868 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,868 |  |  | $ | 2,868 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 2,161 |  |  | — |  |  | — |  |  | 2,161 |  |  | 1,833 |  |  | 328 |  |
| Corporate debt securities | 2,103 |  |  | 1 |  |  | — |  |  | 2,104 |  |  | 1,282 |  |  | 822 |  |
| Debt securities of United States government agencies | 1,120 |  |  | — |  |  | — |  |  | 1,120 |  |  | 995 |  |  | 125 |  |
| Foreign government debt securities | 45 |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Asset-backed securities | 44 |  |  | — |  |  | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Certificates of deposit | 24 |  |  | — |  |  | — |  |  | 24 |  |  | 24 |  |  | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 6 |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total | $ | 8,371 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 8,372 |  |  | $ | 7,002 |  |  | $ | 1,370 |  |

- changed (2019-08-15):
[0001045810-19-000144:note_history:45]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government debt securities | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |
  (was, 2019-05-16, similarity 0.9916):
[0001045810-19-000079:note_history:45]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

- added (2019-08-15):
[0001045810-19-000144:note_history:46]
For the second quarter and first half of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.

- changed (2019-08-15):
[0001045810-19-000144:note_history:47]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019 are shown below by contractual maturity.
  (was, 2019-05-16, similarity 0.9783):
[0001045810-19-000079:note_history:47]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019 are shown below by contractual maturity.

- changed (2019-08-15):
[0001045810-19-000144:note_history:48]
|  | July 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 8,255 |  |  | $ | 8,255 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 112 |  |  | 113 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 4 |  |  | 4 |  |  | 22 |  |  | 22 |  |
| Total | $ | 8,371 |  |  | $ | 8,372 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |
  (was, 2019-05-16, similarity 0.9903):
[0001045810-19-000079:note_history:48]
|  | April 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,773 |  |  | $ | 5,770 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 1,896 |  |  | 1,898 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 23 |  |  | 23 |  |  | 22 |  |  | 22 |  |
| Total | $ | 7,692 |  |  | $ | 7,691 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |

- removed (2019-08-15):
[0001045810-19-000079:note_history:49]
Marketable Securities

- removed (2019-08-15):
[0001045810-19-000079:note_history:50]
|  | April 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,899 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 2,899 |  |  | $ | 1,048 |  |  | $ | 1,851 |  |
| Debt securities of United States government agencies | 1,882 |  |  | — |  |  | (1 | ) |  | 1,881 |  |  | — |  |  | 1,881 |  |
| Debt securities issued by the United States Treasury | 1,833 |  |  | — |  |  | — |  |  | 1,833 |  |  | 932 |  |  | 901 |  |
| Money market funds | 681 |  |  | — |  |  | — |  |  | 681 |  |  | 681 |  |  | — |  |
| Foreign government bonds | 183 |  |  | — |  |  | — |  |  | 183 |  |  | — |  |  | 183 |  |
| Asset-backed securities | 133 |  |  | — |  |  | (1 | ) |  | 132 |  |  | — |  |  | 132 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 81 |  |  | 1 |  |  | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total | $ | 7,692 |  |  | $ | 3 |  |  | $ | (4 | ) |  | $ | 7,691 |  |  | $ | 2,661 |  |  | $ | 5,030 |  |

- removed (2019-08-15):
[0001045810-19-000079:note_history:51]
The following table provides the breakdown of unrealized losses as of April 28, 2019, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- removed (2019-08-15):
[0001045810-19-000079:note_history:52]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,429 |  |  | $ | — |  |  | $ | 306 |  |  | $ | (1 | ) |  | $ | 1,735 |  |  | $ | (1 | ) |
| Corporate debt securities | 330 |  |  | (1 | ) |  | 453 |  |  | (1 | ) |  | 783 |  |  | (2 | ) |
| Asset-backed securities | — |  |  | — |  |  | 132 |  |  | (1 | ) |  | 132 |  |  | (1 | ) |
| Total | $ | 1,759 |  |  | $ | (1 | ) |  | $ | 891 |  |  | $ | (3 | ) |  | $ | 2,650 |  |  | $ | (4 | ) |

- removed (2019-08-15):
[0001045810-19-000079:note_history:53]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For the first quarter of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-15):
[0001045810-19-000144:note_history:54]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (11 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,989 |  |  | $ | 1,988 |  |
  (was, 2019-05-16, similarity 0.9904):
[0001045810-19-000079:note_history:54]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (12 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,988 |  |  | $ | 1,988 |  |
