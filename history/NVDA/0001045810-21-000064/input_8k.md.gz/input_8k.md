# NVDA 8-K — 0001045810-21-000063 filed 2021-05-26

## item codes, every 8-K on or before 2021-05-26

- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2021-05-26

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-21-000063:8k_2_02:1]
EX-99.1
2
q1fy22pr.htm
Q1FY22 PRESS RELEASE

[0001045810-21-000063:8k_2_02:2]
Document

[0001045810-21-000063:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-21-000063:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2022

[0001045810-21-000063:8k_2_02:5]
•Record revenue of $5.66 billion, up 84 percent from a year earlier

[0001045810-21-000063:8k_2_02:6]
•Record Gaming revenue of $2.76 billion, up 106 percent from a year earlier

[0001045810-21-000063:8k_2_02:7]
•Record Data Center revenue of $2.05 billion, up 79 percent from a year earlier

[0001045810-21-000063:8k_2_02:8]
SANTA CLARA, Calif.-May 26, 2021- NVIDIA (NASDAQ: NVDA) today reported record revenue for the first quarter ended May 2, 2021, of $5.66 billion, up 84 percent from a year earlier and up 13 percent from the previous quarter, with record revenue from the company’s Gaming, Data Center and Professional Visualization platforms.

[0001045810-21-000063:8k_2_02:9]
GAAP earnings per diluted share for the quarter were a record $3.03, up 106 percent from a year ago and up 31 percent from the previous quarter. Non-GAAP earnings per diluted share were $3.66, up 103 percent from a year earlier and up 18 percent from the previous quarter.

[0001045810-21-000063:8k_2_02:10]
“We had a fantastic quarter, with strong demand for our products driving record revenue,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-21-000063:8k_2_02:11]
“Our Data Center business continues to expand, as the world’s industries take up NVIDIA AI to process computer vision, conversational AI, natural language understanding and recommender systems. NVIDIA RTX has reinvented computer graphics and is driving upgrades across the gaming and design markets. Our partners are launching the largest-ever wave of NVIDIA-powered laptops. Across industries, the adoption of NVIDIA computing platforms is accelerating.

[0001045810-21-000063:8k_2_02:12]
“Mellanox, one year in, has exceeded our expectations and transformed NVIDIA into a data-center-scale computing company. We continue to make headway with our planned acquisition of Arm, which will accelerate innovation and growth for the Arm ecosystem. From gaming, cloud computing, AI, robotics, self-driving cars, to genomics and computational biology, NVIDIA continues to do impactful work to invent a better future,” he said.

[0001045810-21-000063:8k_2_02:13]
NVIDIA paid quarterly cash dividends of $99 million in the first quarter. It will pay its next quarterly cash dividend of $0.16 per share on July 1, 2021, to all shareholders of record on June 10, 2021.

[0001045810-21-000063:8k_2_02:14]
On May 21, 2021, the company’s board of directors declared a four-for-one split of NVIDIA’s common stock payable in the form of a stock dividend, with the additional shares expected to be distributed on July 19, 2021. The stock dividend is conditioned on obtaining stockholder approval at the company’s 2021 Annual Meeting of Stockholders on June 3, 2021, to increase the number of authorized shares of common stock from 2 billion to 4 billion.

[0001045810-21-000063:8k_2_02:15]
Q1 Fiscal 2022 Summary

[0001045810-21-000063:8k_2_02:16]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY22 | Q4 FY21 | Q1 FY21 | Q/Q | Y/Y |
| Revenue | $5,661 | $5,003 | $3,080 | Up 13% | Up 84% |
| Gross margin | 64.1 | % | 63.1 | % | 65.1 | % | Up 100 bps | Down 100 bps |
| Operating expenses | $1,673 | $1,650 | $1,028 | Up 1% | Up 63% |
| Operating income | $1,956 | $1,507 | $976 | Up 30% | Up 100% |
| Net income | $1,912 | $1,457 | $917 | Up 31% | Up 109% |
| Diluted earnings per share | $3.03 | $2.31 | $1.47 | Up 31% | Up 106% |

[0001045810-21-000063:8k_2_02:17]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY22 | Q4 FY21 | Q1 FY21 | Q/Q | Y/Y |
| Revenue | $5,661 | $5,003 | $3,080 | Up 13% | Up 84% |
| Gross margin | 66.2 | % | 65.5 | % | 65.8 | % | Up 70 bps | Up 40 bps |
| Operating expenses | $1,189 | $1,187 | $821 | -- | Up 45% |
| Operating income | $2,557 | $2,089 | $1,205 | Up 22% | Up 112% |
| Net income | $2,313 | $1,957 | $1,120 | Up 18% | Up 107% |
| Diluted earnings per share | $3.66 | $3.10 | $1.80 | Up 18% | Up 103% |

[0001045810-21-000063:8k_2_02:18]
NVIDIA’s outlook for the second quarter of fiscal 2022 is as follows:

[0001045810-21-000063:8k_2_02:19]
•Revenue is expected to be $6.30 billion, plus or minus 2 percent.

[0001045810-21-000063:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 64.6 percent and 66.5 percent, respectively, plus or minus 50 basis points.

[0001045810-21-000063:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $1.76 billion and $1.26 billion, respectively.

[0001045810-21-000063:8k_2_02:22]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $50 million.

[0001045810-21-000063:8k_2_02:23]
•GAAP and non-GAAP tax rates are both expected to be 10 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter-by-quarter basis.

[0001045810-21-000063:8k_2_02:24]
Highlights

[0001045810-21-000063:8k_2_02:25]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-21-000063:8k_2_02:26]
Gaming

[0001045810-21-000063:8k_2_02:27]
•First-quarter revenue was a record $2.76 billion, up 106 percent from a year earlier and up 11 percent from the previous quarter.

[0001045810-21-000063:8k_2_02:28]
•Broadened the wave of laptops powered by NVIDIA’s second-generation RTX graphics with the launch of GeForce RTXTM 3060 Laptop GPU systems starting at $999, and the announcement of GeForce® 3050 Ti and 3050 Laptop GPU systems starting at $799 and aimed at gamers and creators.

[0001045810-21-000063:8k_2_02:29]
•Accelerated RTX momentum with now over 60 games, including Call of Duty Modern Warfare, Crysis Remastered and Outriders.

[0001045810-21-000063:8k_2_02:30]
•Took steps to improve gamers’ access to GeForce GPUs by reducing the Ethereum hash rate on newly manufactured RTX 3080, 3070 and 3060 Ti graphics cards -- which carry a “Lite Hash Rate,” or “LHR,” identifier -- in addition to previous steps to lower the RTX 3060’s hash rate.

[0001045810-21-000063:8k_2_02:31]
•Announced that NVIDIA DLSS is available now in Unreal Engine 4 and soon in the Unity game engine.

[0001045810-21-000063:8k_2_02:32]
•Announced that NVIDIA Reflex, which reduces system latency, is now incorporated into Call of Duty Warzone, Overwatch and Rainbow Six: Siege.

[0001045810-21-000063:8k_2_02:33]
•Announced that GeForce NOWTM, now in its second year, has over 10 million members in more than 70 countries and is approaching 1,000 games in its library.

[0001045810-21-000063:8k_2_02:34]
Data Center

[0001045810-21-000063:8k_2_02:35]
•First-quarter revenue was a record $2.05 billion, up 79 percent from a year earlier and up 8 percent from the previous quarter.

[0001045810-21-000063:8k_2_02:36]
•Hosted its largest-ever GPU Technology Conference, virtually, with more than 200,000 registrations from 195 countries, and an opening keynote with over 14 million views.

[0001045810-21-000063:8k_2_02:37]
•Unveiled NVIDIA GraceTM, its first Arm-based data center CPU, designed for giant-scale AI and high performance computing, which will deliver 10x the performance of today’s fastest servers and power the world’s most powerful AI-capable supercomputer at the Swiss National Supercomputing Centre.

[0001045810-21-000063:8k_2_02:38]
•Collaborated with Amazon Web Services to deploy NVIDIA GPU inferencing through GPU-accelerated, AWS Graviton2-based Amazon EC2 instances, enabling GPU-accelerated games to run natively on AWS and allowing greater performance for Arm-based workloads.

[0001045810-21-000063:8k_2_02:39]
•Unveiled the NVIDIA® BlueField-3® DPU, the first data processing unit built for AI and accelerated computing, with support from VMware, Splunk, NetApp, Cloudflare and others.

[0001045810-21-000063:8k_2_02:40]
•Announced the new NVIDIA DGX SuperPODTM, the first cloud-native, multi-tenant supercomputer, with customers in conversational AI, drug discovery, autonomous vehicles and more.

[0001045810-21-000063:8k_2_02:41]
•Announced that its AI inference platform, expanded with NVIDIA A30 and A10 GPUs for mainstream servers, set records across every category in the latest release of the MLPerf benchmark for AI performance across a range of workloads.

[0001045810-21-000063:8k_2_02:42]
•Announced the NVIDIA AI Enterprise software suite for VMware vSphere, enabling scale-out, multi-node performance and compatibility for a range of applications and data science.

[0001045810-21-000063:8k_2_02:43]
•Introduced the NVIDIA Morpheus AI application framework to enable cybersecurity providers to instantly detect cyber breaches using AI and NVIDIA BlueField DPUs.

[0001045810-21-000063:8k_2_02:44]
•Announced availability of NVIDIA Jarvis, a framework for interactive conversational AI, and NVIDIA MaxineTM, a framework for real-time video-based experiences.

[0001045810-21-000063:8k_2_02:45]
•Unveiled NVIDIA TAO, a framework for accelerating the creation of enterprise AI applications.

[0001045810-21-000063:8k_2_02:46]
•Expanded its work supporting drug development and discovery with NVIDIA Clara Discovery, announcing a partnership with Schrödinger to support the pharmaceutical industry with AI software to speed drug-discovery workflows.

[0001045810-21-000063:8k_2_02:47]
Professional Visualization

[0001045810-21-000063:8k_2_02:48]
•First-quarter revenue was a record $372 million, up 21 percent both from a year earlier and the previous quarter.

[0001045810-21-000063:8k_2_02:49]
•Launched NVIDIA OmniverseTM Enterprise software for real-time 3D design and collaboration, with BMW Group, Foster + Partners and WPP as early customers.

[0001045810-21-000063:8k_2_02:50]
•Unveiled NVIDIA RTXTM GPUs for next-gen laptop and desktop workstations, including the NVIDIA RTX A4000 and A5000 for desktops and the A2000, A3000, A4000 and A5000 for laptops.

[0001045810-21-000063:8k_2_02:51]
•Revealed GANverse3D, an AI model for creating 3D object models from standard 2D images.

[0001045810-21-000063:8k_2_02:52]
Automotive

[0001045810-21-000063:8k_2_02:53]
•First-quarter revenue was $154 million, down 1 percent from a year earlier and up 6 percent from the previous quarter.

[0001045810-21-000063:8k_2_02:54]
•Unveiled NVIDIA DRIVE AtlanTM, an AI-enabled processor for autonomous vehicles with 1,000 TOPS and data-center-grade security, targeting automakers’ 2025 vehicles.

[0001045810-21-000063:8k_2_02:55]
•Announced NVIDIA DRIVE HyperionTM 8, the latest generation of a fully operational, open platform that reduces the time and cost to outfit vehicles with AI and surround sensors.

[0001045810-21-000063:8k_2_02:56]
•Announced that NVIDIA DRIVETM will be powering intelligent new energy vehicles from SAIC R Auto, IM Motors, Faraday Future and VinFast, starting in 2022.

[0001045810-21-000063:8k_2_02:57]
•Revealed that Cruise is the latest robotaxi company selecting NVIDIA DRIVE, following announcements by Amazon Zoox, DiDi, Oxbotica, Pony.ai and AutoX.

[0001045810-21-000063:8k_2_02:58]
•Announced that Volvo Cars will use NVIDIA DRIVE OrinTM to power the autonomous driving computer in its next-generation cars, beginning with the XC90, to be revealed in 2022.

[0001045810-21-000063:8k_2_02:59]
•Announced that the NVIDIA DRIVE platform powers MBUX Hyperscreen, the AI cockpit in Mercedes-Benz’s new EQS sedan.

[0001045810-21-000063:8k_2_02:60]
•Announced that TuSimple and Navistar will build self-driving trucks powered by the NVIDIA DRIVE AGXTM platform, and the self-driving truck company Plus will use NVIDIA DRIVE Orin for its upcoming autonomous vehicle platform.

[0001045810-21-000063:8k_2_02:61]
CFO Commentary

[0001045810-21-000063:8k_2_02:62]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-21-000063:8k_2_02:63]
Conference Call and Webcast Information

[0001045810-21-000063:8k_2_02:64]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2022.

[0001045810-21-000063:8k_2_02:65]
Non-GAAP Measures

[0001045810-21-000063:8k_2_02:66]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, IP-related costs, gains and losses from non-affiliated investments, mark to market adjustments of our publicly traded equity securities, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation

[0001045810-21-000063:8k_2_02:67]
or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-21-000063:8k_2_02:68]
About NVIDIA

[0001045810-21-000063:8k_2_02:69]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market and has redefined modern computer graphics, high performance computing and artificial intelligence. The company’s pioneering work in accelerated computing and AI is reshaping trillion-dollar industries, such as transportation, healthcare and manufacturing, and fueling the growth of many others. More information at https://nvidianews.nvidia.com/.

[0001045810-21-000063:8k_2_02:70]
###

[0001045810-21-000063:8k_2_02:71]
For further information, contact:

[0001045810-21-000063:8k_2_02:72]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-21-000063:8k_2_02:73]
Certain statements in this press release including, but not limited to, statements as to: NVIDIA’s next quarterly cash dividend; the expected timing of our stock split; our stock split being conditioned on stockholder approval of our charter amendment; our data center business continuing to expand; the world’s industries taking up AI to process computer vision, conversational AI, natural language understanding, and recommender systems; NVIDIA RTX reinventing computer graphics and driving upgrades across the gaming and design markets; improving gamers’ access to GeForce GPUs by reducing the Ethereum hash rate on certain RTX graphics cards; our partners launching the largest-ever wave of NVIDIA-powered laptops; the acceleration of the adoption of NVIDIA computing platforms; NVIDIA’s financial outlook for the second quarter of fiscal 2022; NVIDIA’s expected tax rates for the second quarter of fiscal 2022; NVIDIA’s expectation to generate variability from excess tax benefits or deficiencies; expanding our footprint across the data center; our progress on the Arm acquisition, when it is expected to close and it creating new opportunities for the entire ecosystem; the benefits, performance and abilities of our products and technologies, including NVIDIA Grace, NVIDIA Clara Discovery and NVIDIA GeForce RTX 30 Series GPUs; the release and availability of certain of our products and technologies, including the NVIDIA BlueField-3 DPU, the DGX SuperPOD, a new class of NVIDIA-Certified Systems, NVIDIA AI Enterprise, the NVIDIA Morpheus AI application framework, the NVIDIA Jarvis framework, NVIDIA Maxine, NVIDIA TAO, NVIDIA Omniverse Enterprise and GANverse3D; collaborations with third parties, including Amazon and Schrödinger; our GPU series expansion; expanding our RTX 30 Series GPUs and their features; the games using NVIDIA Reflex and NVIDIA DLSS technology; GeForce NOW’s availability and the number of members that can access it; NVIDIA DRIVE powering a range of next-generation cars and self-driving trucks; expanding the NVIDIA DRIVE ecosystem; NVIDIA powering the Mercedes-Benz AI cockpit and the cars and timing for its debut; and NVIDIA’s pioneering work in accelerated computing and its impacts are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-21-000063:8k_2_02:74]
© 2021 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA DRIVE AGX, NVIDIA DRIVE Atlan, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Orin, NVIDIA Grace, NVIDIA Omniverse, NVIDIA RTX, BlueField, GeForce, GeForce NOW, GeForce RTX and Maxine are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000063:8k_2_02:75]
NVIDIA CORPORATION

[0001045810-21-000063:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-21-000063:8k_2_02:77]
(In millions, except per share data)

[0001045810-21-000063:8k_2_02:78]
(Unaudited)

[0001045810-21-000063:8k_2_02:79]
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 2, |  | April 26, |  |  |  |  |
|  |  |  | 2021 |  | 2020 |  |  |  |  |
| Revenue | $ | 5,661 |  |  | $ | 3,080 |  |  |  |  |  |
| Cost of revenue | 2,032 |  |  | 1,076 |  |  |  |  |  |
| Gross profit | 3,629 |  |  | 2,004 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,153 |  |  | 735 |  |  |  |  |  |
|  | Sales, general and administrative | 520 |  |  | 293 |  |  |  |  |  |
|  |  | Total operating expenses | 1,673 |  |  | 1,028 |  |  |  |  |  |
| Income from operations | 1,956 |  |  | 976 |  |  |  |  |  |
|  | Interest income | 6 |  |  | 31 |  |  |  |  |  |
|  | Interest expense | (53) |  |  | (25) |  |  |  |  |  |
|  | Other, net | 135 |  |  | (1) |  |  |  |  |  |
|  |  | Other income (expense), net | 88 |  |  | 5 |  |  |  |  |  |
| Income before income tax | 2,044 |  |  | 981 |  |  |  |  |  |
| Income tax expense | 132 |  |  | 64 |  |  |  |  |  |
| Net income | $ | 1,912 |  |  | $ | 917 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 3.08 |  |  | $ | 1.49 |  |  |  |  |  |
|  | Diluted | $ | 3.03 |  |  | $ | 1.47 |  |  |  |  |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 621 |  |  | 614 |  |  |  |  |  |
|  | Diluted | 632 |  |  | 622 |  |  |  |  |  |

[0001045810-21-000063:8k_2_02:80]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | May 2, |  | January 31, |
|  |  |  |  | 2021 |  | 2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 12,667 |  |  | $ | 11,561 |  |
|  | Accounts receivable, net |  | 3,024 |  |  | 2,429 |  |
|  | Inventories |  | 1,992 |  |  | 1,826 |  |
|  | Prepaid expenses and other current assets |  | 444 |  |  | 239 |  |
|  |  | Total current assets |  | 18,127 |  |  | 16,055 |  |
| Property and equipment, net |  | 2,268 |  |  | 2,149 |  |
| Operating lease assets |  | 727 |  |  | 707 |  |
| Goodwill |  | 4,193 |  |  | 4,193 |  |
| Intangible assets, net |  | 2,613 |  |  | 2,737 |  |
| Deferred income tax assets |  | 778 |  |  | 806 |  |
| Other assets |  | 2,090 |  |  | 2,144 |  |
|  |  | Total assets |  | $ | 30,796 |  |  | $ | 28,791 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,218 |  |  | $ | 1,201 |  |
|  | Accrued and other current liabilities |  | 1,787 |  |  | 1,725 |  |
|  | Short-term debt |  | 999 |  |  | 999 |  |
|  |  | Total current liabilities |  | 4,004 |  |  | 3,925 |  |
| Long-term debt |  | 5,964 |  |  | 5,964 |  |
| Long-term operating lease liabilities |  | 640 |  |  | 634 |  |
| Other long-term liabilities |  | 1,414 |  |  | 1,375 |  |
|  |  | Total liabilities |  | 12,022 |  |  | 11,898 |  |
| Shareholders' equity |  | 18,774 |  |  | 16,893 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 30,796 |  |  | $ | 28,791 |  |

[0001045810-21-000063:8k_2_02:81]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | May 2, |  | April 26, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,912 |  |  | $ | 917 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 429 |  |  | 224 |  |  |  |  |  |
| Depreciation and amortization | 281 |  |  | 107 |  |  |  |  |  |
| Deferred income taxes | 24 |  |  | 16 |  |  |  |  |  |
| (Gains) losses on investments in non affiliates, net | (133) |  |  | 3 |  |  |  |  |  |
| Other | (3) |  |  | 1 |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (595) |  |  | (249) |  |  |  |  |  |
| Inventories | (159) |  |  | (151) |  |  |  |  |  |
| Prepaid expenses and other assets | 2 |  |  | (8) |  |  |  |  |  |
| Accounts payable | 70 |  |  | 71 |  |  |  |  |  |
| Accrued and other current liabilities | (1) |  |  | (32) |  |  |  |  |  |
| Other long-term liabilities | 47 |  |  | 10 |  |  |  |  |  |
| Net cash provided by operating activities | 1,874 |  |  | 909 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 3,140 |  |  | — |  |  |  |  |  |
| Proceeds from sales of marketable securities | 358 |  |  | 1 |  |  |  |  |  |
| Purchases of marketable securities | (4,470) |  |  | (861) |  |  |  |  |  |
| Purchases related to property and equipment and intangible assets | (298) |  |  | (155) |  |  |  |  |  |
| Investments and other, net | (2) |  |  | (6) |  |  |  |  |  |
| Acquisitions, net of cash acquired | — |  |  | (34) |  |  |  |  |  |
| Net cash used in investing activities | (1,272) |  |  | (1,055) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 126 |  |  | 88 |  |  |  |  |  |
| Payments related to tax on restricted stock units | (477) |  |  | (222) |  |  |  |  |  |
| Dividends paid | (99) |  |  | (98) |  |  |  |  |  |
| Principal payments on property and equipment | (19) |  |  | — |  |  |  |  |  |
| Other | (2) |  |  | (3) |  |  |  |  |  |
| Issuance of debt, net of issuance costs | — |  |  | 4,979 |  |  |  |  |  |
| Net cash provided by (used in) financing activities | (471) |  |  | 4,744 |  |  |  |  |  |
| Change in cash and cash equivalents | 131 |  |  | 4,598 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 847 |  |  | 10,896 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 978 |  |  | $ | 15,494 |  |  |  |  |  |

[0001045810-21-000063:8k_2_02:82]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 2, |  | January 31, |  | April 26, |  |  |  |  |
|  |  |  | 2021 |  | 2021 |  | 2020 |  |  |  |  |
| GAAP gross profit |  | $ | 3,629 |  |  | $ | 3,157 |  |  | $ | 2,004 |  |  |  |  |  |
| GAAP gross margin |  | 64.1 | % |  | 63.1 | % |  | 65.1 | % |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | 87 |  |  | 92 |  |  | 1 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | 25 |  |  | 26 |  |  | 21 |  |  |  |  |  |
|  | IP-related costs |  | 5 |  |  | 1 |  |  | — |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 3,746 |  |  | $ | 3,276 |  |  | $ | 2,026 |  |  |  |  |  |
| Non-GAAP gross margin |  | 66.2 | % |  | 65.5 | % |  | 65.8 | % |  |  |  |  |
| GAAP operating expenses |  | $ | 1,673 |  |  | $ | 1,650 |  |  | $ | 1,028 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | (404) |  |  | (391) |  |  | (203) |  |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | (80) |  |  | (72) |  |  | (4) |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 1,189 |  |  | $ | 1,187 |  |  | $ | 821 |  |  |  |  |  |
| GAAP income from operations |  | $ | 1,956 |  |  | $ | 1,507 |  |  | $ | 976 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 601 |  |  | 582 |  |  | 229 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 2,557 |  |  | $ | 2,089 |  |  | $ | 1,205 |  |  |  |  |  |
| GAAP other income (expense), net |  | $ | 88 |  |  | $ | (37) |  |  | $ | 5 |  |  |  |  |  |
|  | (Gains) losses from non-affiliated investments |  | (134) |  |  | (9) |  |  | 3 |  |  |  |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  |  |  |  |
| Non-GAAP other income (expense), net |  | $ | (45) |  |  | $ | (45) |  |  | $ | 9 |  |  |  |  |  |
| GAAP net income |  | $ | 1,912 |  |  | $ | 1,457 |  |  | $ | 917 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 468 |  |  | 574 |  |  | 232 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (67) |  |  | (74) |  |  | (29) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 2,313 |  |  | $ | 1,957 |  |  | $ | 1,120 |  |  |  |  |  |

[0001045810-21-000063:8k_2_02:83]
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 2, |  | January 31, |  | April 26, |  |  |  |  |
|  |  |  | 2021 |  | 2021 |  | 2020 |  |  |  |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 3.03 |  |  | $ | 2.31 |  |  | $ | 1.47 |  |  |  |  |  |
|  | Non-GAAP |  | $ | 3.66 |  |  | $ | 3.10 |  |  | $ | 1.80 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation |  | 632 |  |  | 631 |  |  | 622 |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 1,874 |  |  | $ | 2,067 |  |  | $ | 909 |  |  |  |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (298) |  |  | (283) |  |  | (155) |  |  |  |  |  |
|  | Principal payments on property and equipment |  | (19) |  |  | (17) |  |  | — |  |  |  |  |  |
| Free cash flow |  | $ | 1,557 |  |  | $ | 1,767 |  |  | $ | 754 |  |  |  |  |  |

[0001045810-21-000063:8k_2_02:84]
| (A) Acquisition-related and other costs primarily include amortization of intangible assets, transaction costs, and certain compensation charges presented as follows: |  |  |  |  |
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 2, |  | January 31, |  | April 26, |  |  |  |  |
|  |  |  | 2021 |  | 2021 |  | 2020 |  |  |  |  |
|  | Cost of revenue |  | $ | 87 |  |  | $ | 92 |  |  | $ | 1 |  |  |  |  |  |
|  | Research and development |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 79 |  |  | $ | 70 |  |  | $ | 2 |  |  |  |  |  |
| (B) Stock-based compensation consists of the following: |  |  |  |  |
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 2, |  | January 31, |  | April 26, |  |  |  |  |
|  |  |  | 2021 |  | 2021 |  | 2020 |  |  |  |  |
|  | Cost of revenue |  | $ | 25 |  |  | $ | 26 |  |  | $ | 21 |  |  |  |  |  |
|  | Research and development |  | $ | 276 |  |  | $ | 266 |  |  | $ | 134 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 128 |  |  | $ | 125 |  |  | $ | 69 |  |  |  |  |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |  |  |  |

[0001045810-21-000063:8k_2_02:85]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2022 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 64.6 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 1.9 | % |
| Non-GAAP gross margin |  | 66.5 | % |
| GAAP operating expenses |  | $ | 1,760 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (500) |  |
| Non-GAAP operating expenses |  | $ | 1,260 |  |
