# NVDA MD&A — 0001045810-21-000064


## mdna

[0001045810-21-000064:mdna:1]
[same as prior period, unchanged from 0001045810-20-000189:mdna:1]

[0001045810-21-000064:mdna:2]
[same as prior period, unchanged from 0001045810-20-000189:mdna:2]

[0001045810-21-000064:mdna:3]
[same as prior period, unchanged from 0001045810-20-000189:mdna:3]

[0001045810-21-000064:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, Maxine, Mellanox, NVIDIA DRIVE, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Orin, NVIDIA Grace, NVIDIA GRID, NVIDIA Jetson, NVIDIA Omniverse, NVIDIA RTX, Quadro and Quadro RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000064:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 31, 2021 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-21-000064:mdna:6]
[same as prior period, unchanged from 0001045810-20-000189:mdna:7]

[0001045810-21-000064:mdna:7]
[same as prior period, unchanged from 0001045810-20-000189:mdna:8]

[0001045810-21-000064:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, or AV, robotics, and augmented and virtual reality, or AR and VR.

[0001045810-21-000064:mdna:9]
Our two operating segments are "Graphics" and "Compute & Networking," as described in Note 15 of the Notes to Condensed Consolidated Financial Statements.

[0001045810-21-000064:mdna:10]
[same as prior period, unchanged from 0001045810-20-000189:mdna:14]

[0001045810-21-000064:mdna:11]
[same as prior period, unchanged from 0001045810-20-000189:mdna:15]

[0001045810-21-000064:mdna:12]
[same as prior period, unchanged from 0001045810-20-000189:mdna:16]

[0001045810-21-000064:mdna:13]
On September 13, 2020, we entered into a Purchase Agreement with Arm and SoftBank for us to acquire, from SoftBank, all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid the Signing Consideration and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 44.3 million shares of our common

[0001045810-21-000064:mdna:14]
stock, which had an aggregate value of $21.5 billion as of the date of the Purchase Agreement. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial performance targets are achieved, Softbank can elect to receive either up to an additional $5 billion in cash or up to an additional 10.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and the expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. We are engaged with regulators in the United States, the United Kingdom, the European Union, China and other jurisdictions. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The Signing Consideration was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. We believe the closing of the acquisition will likely occur in the first quarter of calendar year 2022.

[0001045810-21-000064:mdna:15]
Demand

[0001045810-21-000064:mdna:16]
Demand for our products is based on many factors, including our product introductions and transitions, competitor announcements, and competing technologies, all of which can impact the timing and amount of our revenue. For example, our GPUs for gaming are capable of digital currency mining. Demand and use of GPUs for cryptocurrency has fluctuated in the past and is likely to continue to change quickly. Volatility in the cryptocurrency market, including changes in the prices of cryptocurrencies, can impact demand for our products and our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the pending Ethereum 2.0 standard may also create increased aftermarket resales of our GPUs and may reduce demand for our new GPUs. During the first quarter of fiscal year 2022, we believe Gaming benefited from cryptocurrency mining demand, although it is hard to determine to what extent. Additionally, consumer behavior during the COVID-19 pandemic, such as increased demand for our Gaming, Data Center and notebook workstation products, has made it more difficult for us to estimate future demand, and these challenges may be more pronounced or volatile in the future on both a global and regional basis if and when the effects of the pandemic subside. In estimating demand and evaluating trends, we make multiple assumptions, any of which may prove to be incorrect.

[0001045810-21-000064:mdna:17]
Supply

[0001045810-21-000064:mdna:18]
Our products are manufactured based on estimates of customers’ future demand and our manufacturing lead times are very long. We sell many of our products through a channel model, and our channel customers sell to retailers, distributors, and/or end customers. As a result, the decisions made by our channel partners, retailers, and distributors in response to changing market conditions and the changing demand for our products could impact our financial results. To have shorter shipment lead times and quicker delivery schedules for our customers, we may build inventory for anticipated periods of growth which do not occur, may build inventory anticipating demand that does not materialize, or may build inventory to serve what we believe is pent-up demand. We expect to remain supply-constrained into the second half of the fiscal year, primarily in gaming. We may need to place non-cancellable inventory orders significantly in advance of our normal lead times, pay premiums or provide deposits to secure normal and incremental future supply.

[0001045810-21-000064:mdna:19]
[same as prior period, unchanged from 0001045810-20-000189:mdna:18]

[0001045810-21-000064:mdna:20]
The worldwide COVID-19 pandemic has caused governments and businesses to take unprecedented measures including restrictions on travel, temporary business closures, quarantines and shelter-in-place orders. It has significantly impacted global economic activity and caused volatility and disruption in global financial markets. Some regions are easing COVID-19 related restrictions; however, most of our employees continue to work remotely and we continue to temporarily prohibit most business travel.

[0001045810-21-000064:mdna:21]
The COVID-19 pandemic continues to evolve and affect our business and financial results. Our Gaming and Data Center market platforms have benefited from stronger demand as people continue to work, learn, and play from home. In Professional Visualization, notebook workstations continue to benefit from work-from-home trends and desktop workstations have started to recover as employees return onsite in certain markets. As our own offices begin to reopen, we expect to incur incremental expenses as we resume onsite services and related in-office costs.

[0001045810-21-000064:mdna:22]
As the COVID-19 pandemic continues, the timing and overall demand from customers and the availability of supply chain, logistical services and component supply may have a material net negative impact on our business and financial results. Refer to Part II, Item 1A of this Quarterly Report on Form 10-Q for additional information under the heading “Risk Factors.”

[0001045810-21-000064:mdna:23]
24

[0001045810-21-000064:mdna:24]
We believe our existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy our working capital needs, capital asset purchases, dividends, debt repayments and other liquidity requirements associated with our existing operations.

[0001045810-21-000064:mdna:25]
First Quarter of Fiscal Year 2022 Summary

[0001045810-21-000064:mdna:26]
|  | Three Months Ended |  |  |  |  |
|  | May 2, 2021 |  | January 31, 2021 |  | April 26, 2020 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 5,661 |  |  | $ | 5,003 |  |  | $ | 3,080 |  |  | 13 | % |  | 84 | % |
| Gross margin | 64.1 | % |  | 63.1 | % |  | 65.1 | % |  | 100 bps |  | (100) bps |
| Operating expenses | $ | 1,673 |  |  | $ | 1,650 |  |  | $ | 1,028 |  |  | 1 | % |  | 63 | % |
| Income from operations | $ | 1,956 |  |  | $ | 1,507 |  |  | $ | 976 |  |  | 30 | % |  | 100 | % |
| Net income | $ | 1,912 |  |  | $ | 1,457 |  |  | $ | 917 |  |  | 31 | % |  | 109 | % |
| Net income per diluted share | $ | 3.03 |  |  | $ | 2.31 |  |  | $ | 1.47 |  |  | 31 | % |  | 106 | % |

[0001045810-21-000064:mdna:27]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Gaming, Data Center, Professional Visualization, and Automotive.

[0001045810-21-000064:mdna:28]
Revenue for the first quarter of fiscal year 2022 was $5.66 billion, up 84% from a year earlier. Revenue was up 13% sequentially with growth in all market platforms.

[0001045810-21-000064:mdna:29]
Gaming revenue was up 106% from a year ago and up 11% sequentially, reflecting higher sales in GeForce GPUs, as well as in game-console SOCs. We continued to benefit from strong sales of our GeForce RTX 30 Series based on the NVIDIA Ampere architecture. We believe Gaming also benefited from cryptocurrency mining demand, although it is hard to determine to what extent.

[0001045810-21-000064:mdna:30]
Data Center revenue was up 79% from a year ago and up 8% sequentially. The year-on-year revenue growth was driven primarily by the Mellanox acquisition and the ramp of NVIDIA Ampere GPU architecture products into vertical industries and hyperscale customers. Sequentially, growth in Data Center came from both compute and networking products, primarily driven by hyperscale customers.

[0001045810-21-000064:mdna:31]
Professional Visualization revenue was up 21% from both a year earlier and sequentially. The year-on-year increase was driven by sales of notebook workstation GPUs. The sequential growth reflects sales of GPUs for both desktop and notebook workstations.

[0001045810-21-000064:mdna:32]
Automotive revenue was down 1% from a year earlier and up 6% sequentially.

[0001045810-21-000064:mdna:33]
OEM and Other revenue was up 137% from a year ago and up 114% sequentially, primarily reflecting the addition of CMP, which generated revenue of $155 million.

[0001045810-21-000064:mdna:34]
Gross margin was down 100 basis points from a year earlier due to amortization of intangible assets related to the Mellanox acquisition and a shift in the mix of Data Center products, partially offset by a lower contribution from Automotive products. Gross margin was up 100 basis points sequentially due to a more favorable mix within Data Center and the addition of CMP products.

[0001045810-21-000064:mdna:35]
Operating expenses were up 63% from a year earlier, which did not include Mellanox, and up 1% sequentially. In addition to Mellanox, the year-on-year increase was primarily driven by compensation-related costs, including employee growth and infrastructure costs. Sequential costs were relatively flat, with increased expenses from growth in employees offset by the additional week in the fourth quarter of fiscal year 2021.

[0001045810-21-000064:mdna:36]
Income from operations was $1.96 billion, up 100% from a year earlier and up 30% sequentially. Net income was $1.91 billion. Net income per diluted share was $3.03, up 106% from a year earlier and up 31% sequentially.

[0001045810-21-000064:mdna:37]
Cash, cash equivalents and marketable securities at the end of the first quarter were $12.67 billion, down from $16.35 billion a year earlier and up from $11.56 billion in the prior quarter. The year-on-year decrease primarily reflects payment for Mellanox acquisition, while the sequential increase primarily reflects growth in operating income.

[0001045810-21-000064:mdna:38]
We paid $99 million in quarterly cash dividends in the first quarter.

[0001045810-21-000064:mdna:39]
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock payable in the form of a stock dividend, with the additional shares expected to be distributed on July 19, 2021. The stock dividend is conditioned on obtaining stockholder approval at our 2021 Annual Meeting of Stockholders on June 3, 2021 to increase the number of authorized shares of common stock from 2 billion to 4 billion.

[0001045810-21-000064:mdna:40]
[same as prior period, unchanged from 0001045810-20-000189:mdna:39]

[0001045810-21-000064:mdna:41]
During the first quarter of fiscal year 2022, in our Gaming platform, we launched GeForce RTX 3060 laptop GPU systems; announced GeForce 3050 Ti and 3050 laptop GPUs; accelerated RTX momentum with now over 60 games; announced plans to integrate NVIDIA DLSS into the Unity game engine; announced that NVIDIA Reflex is incorporated in more games; and announced that GeForce NOW has over 10 million members.

[0001045810-21-000064:mdna:42]
In our Data Center platform, we launched new NVIDIA A30 and A10 GPUs for mainstream AI, data analytics and graphics; debuted a new class of NVIDIA-Certified Systems with leading server OEMs; announced the NVIDIA AI Enterprise software suite; hosted our largest-ever GPU Technology Conference, where we unveiled NVIDIA Grace, our first Arm-based data center CPU; introduced the NVIDIA Morpheus AI and NVIDIA TAO application frameworks; and announced the availability of NVIDIA Jarvis and NVIDIA Maxine.

[0001045810-21-000064:mdna:43]
In our Professional Visualization platform, we unveiled NVIDIA RTX GPUs for next-generation notebook and desktop workstations; and launched NVIDIA Omniverse Enterprise.

[0001045810-21-000064:mdna:44]
In our Automotive platform, we announced that the NVIDIA DRIVE platform powers MBUX Hyperscreen, the AI cockpit in Mercedes-Benz’s new EQS sedan, and that Volvo Cars will use NVIDIA DRIVE Orin to power the autonomous driving computer in its next-generation cars, beginning with the XC90 in 2022; announced that NVIDIA DRIVE will be powering intelligent new energy vehicles from R-Auto, IM Motors, Faraday Future and VinFast, and robotaxis including Cruise and Amazon Zoox; announced NVIDIA DRIVE Hyperion 8; and unveiled the NVIDIA DRIVE Atlan next-generation SOC.

[0001045810-21-000064:mdna:45]
[same as prior period, unchanged from 0001045810-20-000189:mdna:45]

[0001045810-21-000064:mdna:46]
[same as prior period, unchanged from 0001045810-20-000189:mdna:46]

[0001045810-21-000064:mdna:47]
[same as prior period, unchanged from 0001045810-20-000189:mdna:53]

[0001045810-21-000064:mdna:48]
[same as prior period, unchanged from 0001045810-20-000189:mdna:54]

[0001045810-21-000064:mdna:49]
|  | Three Months Ended |  |  |
|  | May 2,2021 |  | April 26,2020 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 35.9 |  |  | 34.9 |  |  |  |  |  |
| Gross profit | 64.1 |  |  | 65.1 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 20.4 |  |  | 23.9 |  |  |  |  |  |
| Sales, general and administrative | 9.2 |  |  | 9.5 |  |  |  |  |  |
| Total operating expenses | 29.6 |  |  | 33.4 |  |  |  |  |  |
| Income from operations | 34.5 |  |  | 31.7 |  |  |  |  |  |
| Interest income | 0.1 |  |  | 1.0 |  |  |  |  |  |
| Interest expense | (0.9) |  |  | (0.8) |  |  |  |  |  |
| Other, net | 2.4 |  |  | — |  |  |  |  |  |
| Other income (expense), net | 1.6 |  |  | 0.2 |  |  |  |  |  |
| Income before income tax | 36.1 |  |  | 31.9 |  |  |  |  |  |
| Income tax expense | 2.3 |  |  | 2.1 |  |  |  |  |  |
| Net income | 33.8 | % |  | 29.8 | % |  |  |  |  |

[0001045810-21-000064:mdna:50]
[same as prior period, unchanged from 0001045810-20-000189:mdna:56]

[0001045810-21-000064:mdna:51]
[same as prior period, unchanged from 0001045810-20-000189:mdna:57]

[0001045810-21-000064:mdna:52]
|  | Three Months Ended |  |  |
|  | May 2,2021 |  | April 26,2020 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Graphics | $ | 3,451 |  |  | $ | 1,906 |  |  | $ | 1,545 |  |  | 81 | % |  |  |  |  |  |  |  |  |
| Compute & Networking | 2,210 |  |  | 1,174 |  |  | 1,036 |  |  | 88 | % |  |  |  |  |  |  |  |  |
| Total | $ | 5,661 |  |  | $ | 3,080 |  |  | $ | 2,581 |  |  | 84 | % |  |  |  |  |  |  |  |  |

[0001045810-21-000064:mdna:53]
Graphics - Graphics segment revenue increased 81% in the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, reflecting growth in GeForce GPUs which benefited from continued strong sales of our GeForce RTX 30 Series based on the NVIDIA Ampere architecture. Additionally, revenue increased from higher sales of Quadro/NVIDIA RTX workstations and game console SOCs. We believe this segment also benefited from cryptocurrency mining demand, although it is hard to determine to what extent.

[0001045810-21-000064:mdna:54]
Compute & Networking - Compute & Networking segment revenue increased 88% for the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, reflecting the addition of Mellanox, which we acquired on April 27, 2020.  Revenue also increased due to the ramp of NVIDIA Ampere GPU architecture products into vertical industries and hyperscale customers and the addition of CMP revenue.

[0001045810-21-000064:mdna:55]
[same as prior period, unchanged from 0001045810-20-000189:mdna:61]

[0001045810-21-000064:mdna:56]
Revenue from sales to customers outside of the United States accounted for 86% and 84% of total revenue for the first quarter of fiscal years 2022 and 2021, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-21-000064:mdna:57]
No customer represented 10% or more of total revenue for the first quarter of fiscal years 2022 or 2021.

[0001045810-21-000064:mdna:58]
[same as prior period, unchanged from 0001045810-20-000189:mdna:64]

[0001045810-21-000064:mdna:59]
Our overall gross margin decreased to 64.1% for the first quarter of fiscal year 2022 from 65.1% for the first quarter of fiscal year 2021, reflecting amortization of intangible assets related to the Mellanox acquisition and a shift in the mix of Data Center products, partially offset by a lower contribution from Automotive products.

[0001045810-21-000064:mdna:60]
Inventory provisions totaled $58 million and $36 million for the first quarter of fiscal years 2022 and 2021, respectively. Sales of inventory that was previously written-off or -down totaled $21 million and $39 million for the first quarter of fiscal years 2022 and 2021, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.6% and a favorable impact of 0.1% in the first quarter of fiscal years 2022 and 2021, respectively.

[0001045810-21-000064:mdna:61]
[same as prior period, unchanged from 0001045810-20-000189:mdna:68]

[0001045810-21-000064:mdna:62]
Graphics - The gross margin of our Graphics segment increased during the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, primarily due to reduced contribution from lower margin products.

[0001045810-21-000064:mdna:63]
Compute & Networking - The gross margin of our Compute & Networking segment decreased during the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, primarily due to a shift in the mix of Data Center products, partially offset by a lower contribution from Automotive solutions.

[0001045810-21-000064:mdna:64]
[same as prior period, unchanged from 0001045810-20-000189:mdna:71]

[0001045810-21-000064:mdna:65]
|  | Three Months Ended |  |  |
|  | May 2,2021 |  | April 26,2020 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Research and development expenses | $ | 1,153 |  |  | $ | 735 |  |  | $ | 418 |  |  | 57 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 20 | % |  | 24 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales, general and administrative expenses | 520 |  |  | 293 |  |  | 227 |  |  | 77 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 9 | % |  | 10 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 1,673 |  |  | $ | 1,028 |  |  | $ | 645 |  |  | 63 | % |  |  |  |  |  |  |  |  |

[0001045810-21-000064:mdna:66]
[same as prior period, unchanged from 0001045810-20-000189:mdna:73]

[0001045810-21-000064:mdna:67]
Research and development expenses increased by 57% during the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, driven primarily by the acquisition of Mellanox. The increase also reflects the impact of employee additions and higher employee compensation, including stock-based compensation and infrastructure costs.

[0001045810-21-000064:mdna:68]
[same as prior period, unchanged from 0001045810-20-000189:mdna:75]

[0001045810-21-000064:mdna:69]
Sales, general and administrative expenses increased by 77% during the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, driven primarily by the Mellanox acquisition. The increase also reflects the impact of employee additions and higher employee compensation, including stock-based compensation, and costs related to the pending acquisition of Arm.

[0001045810-21-000064:mdna:70]
[same as prior period, unchanged from 0001045810-20-000189:mdna:77]

[0001045810-21-000064:mdna:71]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $6 million and $31 million during the first quarter of fiscal years 2022 and 2021, respectively. The decrease in interest income was primarily due to lower interest earned on our investments.

[0001045810-21-000064:mdna:72]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our September 2016 Notes and March 2020 Notes. Interest expense was $53 million and $25 million during the first quarter of fiscal years 2022 and 2021, respectively.

[0001045810-21-000064:mdna:73]
Other, net, consists primarily of realized or unrealized gains and losses from non-affiliated investments, mark to market adjustment of our publicly-traded equity security investment and the impact of changes in foreign currency rates. Other, net, was an income of $135 million during the first quarter of fiscal year 2022 and not significant during the first quarter

[0001045810-21-000064:mdna:74]
of fiscal year 2021. The increase was primarily due to a $124 million unrealized gain from an equity investment in a company that commenced public trading. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-21-000064:mdna:75]
[same as prior period, unchanged from 0001045810-20-000189:mdna:80]

[0001045810-21-000064:mdna:76]
We recognized an income tax expense of $132 million and $64 million for the first quarter of fiscal years 2022 and 2021, respectively. The income tax expense as a percentage of income before income tax was 6.5% and 6.6% for the first quarter of fiscal years 2022 and 2021, respectively.

[0001045810-21-000064:mdna:77]
The slight decrease in our effective tax rate for the first quarter of fiscal year 2022 as compared to the first quarter of fiscal year 2021 was primarily due to a change in the jurisdiction of earnings, partially offset by a decrease in the impact of tax benefits from the U.S. federal research tax credit.

[0001045810-21-000064:mdna:78]
[same as prior period, unchanged from 0001045810-20-000189:mdna:83]

[0001045810-21-000064:mdna:79]
[same as prior period, unchanged from 0001045810-20-000189:mdna:84]

[0001045810-21-000064:mdna:80]
|  | May 2, 2021 |  | January 31, 2021 |
|  | (In millions) |
| Cash and cash equivalents | $ | 978 |  |  | $ | 847 |  |
| Marketable securities | 11,689 |  |  | 10,714 |  |
| Cash, cash equivalents and marketable securities | $ | 12,667 |  |  | $ | 11,561 |  |

[0001045810-21-000064:mdna:81]
|  | Three Months Ended |
|  | May 2, 2021 |  | April 26, 2020 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,874 |  |  | $ | 909 |  |
| Net cash used in investing activities | $ | (1,272) |  |  | $ | (1,055) |  |
| Net cash provided by (used in) financing activities | $ | (471) |  |  | $ | 4,744 |  |

[0001045810-21-000064:mdna:82]
As of May 2, 2021, we had $12.67 billion in cash, cash equivalents and marketable securities, an increase of $1.11 billion from the end of fiscal year 2021. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-21-000064:mdna:83]
Cash provided by operating activities increased in the first quarter of fiscal year 2022 compared to the first quarter of fiscal year 2021, due to higher net income and non-cash adjustments, partially offset by changes in working capital. Changes in working capital include increases in outstanding trade receivables due to higher revenue and corresponding shipment linearity.

[0001045810-21-000064:mdna:84]
Cash used in investing activities increased in the first quarter of fiscal year 2022 compared to cash used in the first quarter of fiscal year 2021, which primarily reflects higher purchases of marketable securities, and higher purchases of property and equipment and intangible assets, offset by higher sales and maturities of marketable securities.

[0001045810-21-000064:mdna:85]
Cash used in financing activities increased in the first quarter of fiscal year 2022 compared to cash provided in the first quarter of fiscal year 2021, which primarily reflects the debt issued in the first quarter of fiscal year 2021 and higher payments related to tax on restricted stock units.

[0001045810-21-000064:mdna:86]
[same as prior period, unchanged from 0001045810-20-000189:mdna:92]

[0001045810-21-000064:mdna:87]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of May 2, 2021, we had $12.67 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of certificates of deposits and debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next 12 months, including our proposed acquisition of Arm. We continuously evaluate our liquidity and

[0001045810-21-000064:mdna:88]
capital resources, including our access to external capital, to ensure we can adequately and efficiently finance our capital requirements beyond 12 months.

[0001045810-21-000064:mdna:89]
We have approximately $1.5 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S. Other than that, substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of May 2, 2021 are available for use in the U.S. without incurring additional U.S. federal income taxes.

[0001045810-21-000064:mdna:90]
[same as prior period, unchanged from 0001045810-20-000189:mdna:97]

[0001045810-21-000064:mdna:91]
In the first quarter of fiscal year 2022, we paid $99 million in quarterly cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to the continuing determination by our Board of Directors that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-21-000064:mdna:92]
As of May 2, 2021, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022. We did not repurchase any shares during the first quarter of fiscal year 2022.

[0001045810-21-000064:mdna:93]
[same as prior period, unchanged from 0001045810-20-000189:mdna:100]

[0001045810-21-000064:mdna:94]
We have outstanding $1.50 billion of Notes Due 2030, $1.00 billion of Notes Due 2040, $2.00 billion of Notes Due 2050, and $500 million of Notes due 2060, or collectively, the March 2020 Notes.

[0001045810-21-000064:mdna:95]
We have outstanding $1.00 billion of Notes due 2021 and $1.00 billion of Notes due 2026, or collectively, the September 2016 Notes.

[0001045810-21-000064:mdna:96]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of May 2, 2021, we had not borrowed any amounts under this agreement. The Credit Agreement expires October 2021.

[0001045810-21-000064:mdna:97]
We have a $575 million commercial paper program to support general corporate purposes. As of May 2, 2021, we had not issued any commercial paper.

[0001045810-21-000064:mdna:98]
[same as prior period, unchanged from 0001045810-20-000189:mdna:107]

[0001045810-21-000064:mdna:99]
There were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021 for a description of our contractual obligations. For a description of our operating lease obligations, long-term debt, and purchase obligations, refer to Note 3, Note 12, and Note 13 of the Notes to Condensed Consolidated Financial Statements, respectively.

[0001045810-21-000064:mdna:100]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-21-000064:mdna:101]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
