# NVDA notes — 0001045810-21-000064


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-21-000064:notes:1]
[same as prior period, unchanged from 0001045810-20-000189:notes:1]

[0001045810-21-000064:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 31, 2021 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021.

[0001045810-21-000064:notes:3]
[same as prior period, unchanged from 0001045810-20-000189:notes:4]

[0001045810-21-000064:notes:4]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021.

[0001045810-21-000064:notes:5]
[same as prior period, unchanged from 0001045810-20-000189:notes:12]

[0001045810-21-000064:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The first quarters of fiscal years 2022 and 2021 were both 13-week quarters.

[0001045810-21-000064:notes:7]
[same as prior period, unchanged from 0001045810-20-000189:notes:14]

[0001045810-21-000064:notes:8]
[same as prior period, unchanged from 0001045810-20-000189:notes:15]

[0001045810-21-000064:notes:9]
[same as prior period, unchanged from 0001045810-20-000189:notes:16]

[0001045810-21-000064:notes:10]
[same as prior period, unchanged from 0001045810-20-000189:notes:17]

[0001045810-21-000064:notes:11]
[same as prior period, unchanged from 0001045810-20-000189:notes:18]

[0001045810-21-000064:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-21-000064:notes:13]
[same as prior period, unchanged from 0001045810-20-000189:notes:23]

[0001045810-21-000064:notes:14]
On September 13, 2020, we entered into a Share Purchase Agreement, or the Purchase Agreement, with Arm Limited, or Arm, and SoftBank Group Capital Limited and SVF Holdco (UK) Limited, or together, SoftBank, for us to acquire, from SoftBank, all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid $2 billion in cash at signing, or the Signing Consideration, and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 44.3 million shares of our common stock, which had an aggregate value of $21.5 billion as of the date of the Purchase Agreement. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial targets are achieved, SoftBank can elect to receive either up to an additional $5 billion in cash or up to an additional 10.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion

[0001045810-21-000064:notes:15]
paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and the expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. We are engaged with regulators in the United States, the United Kingdom, the European Union, China and other jurisdictions. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The Signing Consideration was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. We believe the closing of the acquisition will likely occur in the first quarter of calendar year 2022.

[0001045810-21-000064:notes:16]
[same as prior period, unchanged from 0001045810-20-000189:notes:25]

[0001045810-21-000064:notes:17]
[same as prior period, unchanged from 0001045810-20-000189:notes:26]

[0001045810-21-000064:notes:18]
[same as prior period, unchanged from 0001045810-20-000189:notes:47]

[0001045810-21-000064:notes:19]
[same as prior period, unchanged from 0001045810-20-000189:notes:48]

[0001045810-21-000064:notes:20]
|  | Pro Forma |
|  | Three Months Ended |  |  |
|  | April 26, 2020 |  |  |  |  |
|  | (In millions) |
| Revenue | $ | 3,509 |  |  |  |  |  |
| Net income | $ | 918 |  |  |  |  |  |

[0001045810-21-000064:notes:21]
The unaudited pro forma information includes adjustments related to amortization of acquired intangible assets, adjustments to stock-based compensation expense, fair value of acquired inventory, and transaction costs. The unaudited pro forma information presented above is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition occurred at the beginning of fiscal year 2020 or of the results of our future operations of the combined businesses.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-21-000064:notes:22]
LeasesOur lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2022 and 2035.
Future minimum lease payments under our non-cancelable operating leases as of May 2, 2021, are as follows:

[0001045810-21-000064:notes:23]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 (excluding first quarter of fiscal year 2022) | $ | 106 |  |
| 2023 | 144 |  |
| 2024 | 123 |  |
| 2025 | 102 |  |
| 2026 | 94 |  |
| 2027 and thereafter | 306 |  |
| Total | 875 |  |
| Less imputed interest | 100 |  |
| Present value of net future minimum lease payments | 775 |  |
| Less short-term operating lease liabilities | 135 |  |
| Long-term operating lease liabilities | $ | 640 |  |

[0001045810-21-000064:notes:24]
Operating lease expenses were $39 million and $31 million for the first quarter of fiscal years 2022 and 2021, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2022 and 2021 were not significant.

[0001045810-21-000064:notes:25]
[same as prior period, unchanged from 0001045810-20-000189:notes:56]

[0001045810-21-000064:notes:26]
|  | Three Months Ended |
|  | May 2, 2021 |  | April 26, 2020 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 39 |  |  | $ | 31 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 54 |  |  | $ | 3 |  |

[0001045810-21-000064:notes:27]
As of May 2, 2021, our operating leases had a weighted average remaining lease term of 7.5 years and a weighted average discount rate of 2.77%. As of January 31, 2021, our operating leases had a weighted average remaining lease term of 7.6 years and a weighted average discount rate of 2.87%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-21-000064:notes:28]
[same as prior period, unchanged from 0001045810-20-000189:notes:60]

[0001045810-21-000064:notes:29]
[same as prior period, unchanged from 0001045810-20-000189:notes:61]

[0001045810-21-000064:notes:30]
|  | Three Months Ended |  |  |
|  | May 2,2021 |  | April 26,2020 |  |  |  |  |
|  | (In millions) |
| Cost of revenue | $ | 25 |  |  | $ | 21 |  |  |  |  |  |
| Research and development | 276 |  |  | 134 |  |  |  |  |  |
| Sales, general and administrative | 128 |  |  | 69 |  |  |  |  |  |
| Total | $ | 429 |  |  | $ | 224 |  |  |  |  |  |

[0001045810-21-000064:notes:31]
[same as prior period, unchanged from 0001045810-20-000189:notes:63]

[0001045810-21-000064:notes:32]
[same as prior period, unchanged from 0001045810-20-000189:notes:64]

[0001045810-21-000064:notes:33]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 31, 2021 | 15 |  |  | $ | 264.69 |  |  |  |  |  |
| Granted | 1 |  |  | $ | 535.82 |  |  |  |  |  |
| Vested restricted stock | (4) |  |  | $ | 252.22 |  |  |  |  |  |
| Balances, May 2, 2021 | 12 |  |  | $ | 279.79 |  |  |  |  |  |

[0001045810-21-000064:notes:34]
As of May 2, 2021, there was $3.32 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.4 years for RSUs, PSUs, and market-based PSUs, and 1.1 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-21-000064:notes:35]
[same as prior period, unchanged from 0001045810-20-000189:notes:67]

[0001045810-21-000064:notes:36]
|  | Three Months Ended |  |  |
|  | May 2, |  | April 26, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 1,912 |  |  | $ | 917 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 621 |  |  | 614 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 11 |  |  | 8 |  |  |  |  |  |
| Diluted weighted average shares | 632 |  |  | 622 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 3.08 |  |  | $ | 1.49 |  |  |  |  |  |
| Diluted (2) | $ | 3.03 |  |  | $ | 1.47 |  |  |  |  |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 1 |  |  | 1 |  |  |  |  |  |

[0001045810-21-000064:notes:37]
[same as prior period, unchanged from 0001045810-20-000189:notes:69]

[0001045810-21-000064:notes:38]
[same as prior period, unchanged from 0001045810-20-000189:notes:70]


## us-gaap:ScheduleOfWeightedAverageNumberOfSharesTableTextBlock

[0001045810-21-000064:notes:39]
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-21-000064:notes:40]
(2)    Calculated as net income divided by diluted weighted average shares.
The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the four-for-one stock split as if it had been effective for all periods presented:

[0001045810-21-000064:notes:41]
|  |  |  | Pro Forma (Unaudited) |  |  |  |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |  |  |
|  |  |  |  |  | May 2, |  | April 26, |  | January 31, |  | January 26, |  | January 27, |  |  |  |  |
|  |  |  |  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2019 |  |  |  |  |
|  |  |  |  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  |  |  |  | $ | 1,912 |  |  | $ | 917 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |  | $ | 4,141 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares |  |  |  |  | 2,484 |  |  | 2,456 |  |  | 2,468 |  |  | 2,436 |  |  | 2,432 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards |  |  |  |  | 44 |  |  | 32 |  |  | 44 |  |  | 36 |  |  | 68 |  |  |  |  |  |
| Diluted weighted average shares |  |  |  |  | 2,528 |  |  | 2,488 |  |  | 2,512 |  |  | 2,472 |  |  | 2,500 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic (1) |  |  |  |  | $ | 0.77 |  |  | $ | 0.37 |  |  | $ | 1.76 |  |  | $ | 1.15 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted (2) |  |  |  |  | $ | 0.76 |  |  | $ | 0.37 |  |  | $ | 1.72 |  |  | $ | 1.13 |  |  | $ | 1.66 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-21-000064:notes:42]
Income Taxes
We recognized an income tax expense of $132 million and $64 million for the first quarter of fiscal years 2022 and 2021, respectively. The income tax expense as a percentage of income before income tax was 6.5% and 6.6% for the first quarter of fiscal years 2022 and 2021, respectively.

[0001045810-21-000064:notes:43]
The slight decrease in our effective tax rate for the first quarter of fiscal year 2022 as compared to the first quarter of fiscal year 2021 was primarily due to a change in the jurisdiction of earnings, partially offset by a decrease in the impact of tax benefits from the U.S. federal research tax credit.

[0001045810-21-000064:notes:44]
Our effective tax rates for the first quarter of fiscal years 2022 and 2021 were lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit, and tax benefits related to stock-based compensation.

[0001045810-21-000064:notes:45]
As of May 2, 2021, we intend to indefinitely reinvest approximately $1.3 billion of cumulative undistributed earnings held by Mellanox non-U.S. subsidiaries. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in Mellanox non-U.S. subsidiaries as the determination of such amount is not practicable.

[0001045810-21-000064:notes:46]
For the first quarter of fiscal year 2022, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 31, 2021.
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of May 2, 2021, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-21-000064:notes:47]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-21-000064:notes:48]
The following is a summary of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021:

[0001045810-21-000064:notes:49]
|  | May 2, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,240 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 5,242 |  |  | $ | 323 |  |  | $ | 4,919 |  |
| Debt securities issued by United States government agencies | 3,045 |  |  | 1 |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Debt securities issued by the United States Treasury | 2,820 |  |  | 1 |  |  | — |  |  | 2,821 |  |  | — |  |  | 2,821 |  |
| Certificates of deposit | 884 |  |  | — |  |  | — |  |  | 884 |  |  | 48 |  |  | 836 |  |
| Money market funds | 319 |  |  | — |  |  | — |  |  | 319 |  |  | 319 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 12,375 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12,379 |  |  | $ | 690 |  |  | $ | 11,689 |  |

[0001045810-21-000064:notes:50]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

[0001045810-21-000064:notes:51]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-21-000064:notes:52]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021 are shown below by contractual maturity.

[0001045810-21-000064:notes:53]
|  | May 2, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,499 |  |  | $ | 11,502 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 876 |  |  | 877 |  |  | 566 |  |  | 568 |  |
| Total | $ | 12,375 |  |  | $ | 12,379 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-21-000064:notes:54]
Fair Value of Financial Assets and Liabilities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-21-000064:notes:55]
|  |  | Fair Value at |
|  | Pricing Category |  | May 2, 2021 |  | January 31, 2021 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 319 |  |  | $ | 313 |  |
| Corporate debt securities | Level 2 |  | $ | 5,242 |  |  | $ | 4,444 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 3,046 |  |  | $ | 2,976 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 2,821 |  |  | $ | 2,846 |  |
| Certificates of deposit | Level 2 |  | $ | 884 |  |  | $ | 705 |  |
| Foreign government bonds | Level 2 |  | $ | 67 |  |  | $ | 67 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |
| Publicly-held equity security (1) | Level 1 |  | $ | 133 |  |  | $ | — |  |
| Other assets: |  |  |  |  |  |
| Investment in non-affiliated entities (2) | Level 3 |  | $ | 146 |  |  | $ | 144 |  |
| Liabilities |  |  |  |  |  |
| 2.20% Notes Due 2021 (3) | Level 2 |  | $ | 1,006 |  |  | $ | 1,011 |  |
| 3.20% Notes Due 2026 (3) | Level 2 |  | $ | 1,101 |  |  | $ | 1,124 |  |
| 2.85% Notes Due 2030 (3) | Level 2 |  | $ | 1,592 |  |  | $ | 1,654 |  |
| 3.50% Notes Due 2040 (3) | Level 2 |  | $ | 1,095 |  |  | $ | 1,152 |  |
| 3.50% Notes Due 2050 (3) | Level 2 |  | $ | 2,158 |  |  | $ | 2,308 |  |
| 3.70% Notes Due 2060 (3) | Level 2 |  | $ | 552 |  |  | $ | 602 |  |

[0001045810-21-000064:notes:56]
(1)    The balance as of May 2, 2021 includes an investment that was reclassified from privately-held equity securities following the commencement of public market trading of the issuer in the first quarter of fiscal year 2022. As of May 2, 2021, the investment is subject to short-term selling restrictions. Due to the public market trading of the issuer, an unrealized gain on the investment of $124 million was recorded in other income (expense), net in the first quarter of fiscal year 2022. The net cumulative unrealized gain on the investment was $130 million as of May 2, 2021.

[0001045810-21-000064:notes:57]
(2)    Investment in private non-affiliated entities is recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of May 2, 2021 has not been significant.
(3)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for additional information


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-21-000064:notes:58]
(2)    Investment in private non-affiliated entities is recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of May 2, 2021 has not been significant.
(3)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-21-000064:notes:59]
Amortizable Intangible Assets and Goodwill
The components of our amortizable intangible assets are as follows:

[0001045810-21-000064:notes:60]
|  | May 2, 2021 |  | January 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,280 |  |  | $ | (904) |  |  | $ | 2,376 |  |  | $ | 3,280 |  |  | $ | (774) |  |  | $ | 2,506 |  |
| Patents and licensed technology | 719 |  |  | (482) |  |  | 237 |  |  | 706 |  |  | (475) |  |  | 231 |  |
| Total intangible assets | $ | 3,999 |  |  | $ | (1,386) |  |  | $ | 2,613 |  |  | $ | 3,986 |  |  | $ | (1,249) |  |  | $ | 2,737 |  |

[0001045810-21-000064:notes:61]
(1)    As of May 2, 2021, acquisition-related intangible assets include the fair value of a Mellanox in-process research and development, or IPR&D, project of $630 million, which has not yet commenced amortization. Once the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life.

[0001045810-21-000064:notes:62]
Amortization expense associated with intangible assets was $137 million and $7 million for the first quarter of fiscal years 2022 and 2021, respectively. Future amortization expense related to the net carrying amount of intangible assets, excluding IPR&D, as of May 2, 2021 is estimated to be $412 million for the remainder of fiscal year 2022, $546 million in fiscal year 2023, $424 million in fiscal year 2024, $370 million in fiscal year 2025, $99 million in fiscal year 2026, and $132 million in fiscal year 2027 and thereafter.
There were no changes to the carrying amount of goodwill during the first quarter of fiscal year 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-21-000064:notes:63]
Balance Sheet Components 
Certain balance sheet components are as follows:

[0001045810-21-000064:notes:64]
|  | May 2, |  | January 31, |
|  | 2021 |  | 2021 |
| Inventories: | (In millions) |
| Raw materials | $ | 734 |  |  | $ | 632 |  |
| Work in-process | 504 |  |  | 457 |  |
| Finished goods | 754 |  |  | 737 |  |
| Total inventories | $ | 1,992 |  |  | $ | 1,826 |  |

[0001045810-21-000064:notes:65]
|  | May 2, |  | January 31, |
|  | 2021 |  | 2021 |
| Prepaid expenses and other current assets: | (In millions) |
| Prepaid expenses | $ | 179 |  |  | $ | 142 |  |
| Publicly-held equity security (1) | 133 |  |  | — |  |
| Other | 132 |  |  | 97 |  |
| Total prepaid expenses and other current assets | $ | 444 |  |  | $ | 239 |  |

[0001045810-21-000064:notes:66]
|  | May 2, |  | January 31, |
|  | 2021 |  | 2021 |
| Other assets: | (In millions) |
| Advanced consideration for acquisition | $ | 1,357 |  |  | $ | 1,357 |  |
| Prepaid royalties | 428 |  |  | 440 |  |
| Investment in non-affiliated entities | 146 |  |  | 144 |  |
| Deposits | 123 |  |  | 136 |  |
| Other | 36 |  |  | 67 |  |
| Total other assets | $ | 2,090 |  |  | $ | 2,144 |  |

[0001045810-21-000064:notes:67]
|  | May 2, |  | January 31, |
|  | 2021 |  | 2021 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 700 |  |  | $ | 630 |  |
| Deferred revenue (1) | 333 |  |  | 288 |  |
| Accrued payroll and related expenses | 265 |  |  | 297 |  |
| Operating leases | 135 |  |  | 121 |  |
| Licenses and royalties | 96 |  |  | 128 |  |
| Taxes payable | 96 |  |  | 61 |  |
| Product warranty and return provisions | 45 |  |  | 39 |  |
| Professional service fees | 33 |  |  | 26 |  |
| Coupon interest on debt obligations | 19 |  |  | 74 |  |
| Other | 65 |  |  | 61 |  |
| Total accrued and other current liabilities | $ | 1,787 |  |  | $ | 1,725 |  |

[0001045810-21-000064:notes:68]
(1)    Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and post-contract customer support, or PCS.

[0001045810-21-000064:notes:69]
|  | May 2, |  | January 31, |
|  | 2021 |  | 2021 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 864 |  |  | $ | 836 |  |
| Deferred income tax | 234 |  |  | 241 |  |
| Deferred revenue (2) | 173 |  |  | 163 |  |
| Licenses payable | 59 |  |  | 56 |  |
| Employee benefits | 34 |  |  | 33 |  |
| Other | 50 |  |  | 46 |  |
| Total other long-term liabilities | $ | 1,414 |  |  | $ | 1,375 |  |

[0001045810-21-000064:notes:70]
(1)    As of May 2, 2021, income tax payable represents the long-term portion of the one-time transition tax payable of $284 million, unrecognized tax benefits of $374 million, related interest and penalties of $48 million, and other foreign long-term tax payable of $158 million.

[0001045810-21-000064:notes:71]
(2)    Deferred revenue primarily includes deferrals related to PCS.

[0001045810-21-000064:notes:72]
Deferred Revenue

[0001045810-21-000064:notes:73]
The following table shows the changes in deferred revenue during the first quarter of fiscal years 2022 and 2021:

[0001045810-21-000064:notes:74]
|  | May 2, |  | April 26, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Balance at beginning of period | $ | 451 |  |  | $ | 201 |  |
| Deferred revenue added during the period | 178 |  |  | 110 |  |
| Revenue recognized during the period | (123) |  |  | (70) |  |
| Balance at end of period | $ | 506 |  |  | $ | 241 |  |

[0001045810-21-000064:notes:75]
Revenue related to remaining performance obligations represents the remaining contracted license, development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of May 2, 2021, the amount of our remaining performance obligations that has not been recognized as revenue was $680 million, of which we expect to recognize approximately 48% as revenue over the next 12 months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-21-000064:notes:76]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of May 2, 2021 and January 31, 2021.

[0001045810-21-000064:notes:77]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than the U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-21-000064:notes:78]
The table below presents the notional value of our foreign currency forward contracts outstanding as of May 2, 2021 and January 31, 2021:

[0001045810-21-000064:notes:79]
|  | May 2,2021 |  | January 31,2021 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 888 |  |  | $ | 840 |  |
| Not designated for hedge accounting | $ | 402 |  |  | $ | 441 |  |

[0001045810-21-000064:notes:80]
As of May 2, 2021, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next 12 months was not significant.

[0001045810-21-000064:notes:81]
During the first quarter of fiscal years 2022 and 2021, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-21-000064:notes:82]
Debt
Long-Term Debt

[0001045810-21-000064:notes:83]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year.

[0001045810-21-000064:notes:84]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year.

[0001045810-21-000064:notes:85]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-21-000064:notes:86]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-21-000064:notes:87]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 2, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 8.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 3.50% Notes Due 2040 |  | 18.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (37) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 6,963 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 5,964 |  |  | $ | 5,964 |  |

[0001045810-21-000064:notes:88]
As of May 2, 2021, we were in compliance with the required covenants under the Notes.

[0001045810-21-000064:notes:89]
Credit Facilities

[0001045810-21-000064:notes:90]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of May 2, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.

[0001045810-21-000064:notes:91]
We have a $575 million commercial paper program to support general corporate purposes. As of May 2, 2021, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-21-000064:notes:92]
Commitments and Contingencies
Purchase Obligations

[0001045810-21-000064:notes:93]
As of May 2, 2021, we had outstanding inventory purchase obligations totaling $3.46 billion which are expected to occur over the next 12 months, and other purchase obligations totaling $396 million, which are primarily expected to occur over the next 18 months.

[0001045810-21-000064:notes:94]
Accrual for Product Warranty Liabilities

[0001045810-21-000064:notes:95]
The estimated amount of product warranty liabilities was $30 million and $22 million as of May 2, 2021 and January 31, 2021, respectively, and the activities related to the warranty liabilities were not significant.

[0001045810-21-000064:notes:96]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-21-000064:notes:97]
Litigation

[0001045810-21-000064:notes:98]
Securities Class Action and Derivative Lawsuits

[0001045810-21-000064:notes:99]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed a notice of appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.

[0001045810-21-000064:notes:100]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-21-000064:notes:101]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-21-000064:notes:102]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-21-000064:notes:103]
Accounting for Loss Contingencies

[0001045810-21-000064:notes:104]
As of May 2, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-21-000064:notes:105]
[same as prior period, unchanged from 0001045810-20-000189:notes:137]

[0001045810-21-000064:notes:106]
[same as prior period, unchanged from 0001045810-20-000189:notes:138]

[0001045810-21-000064:notes:107]
Through May 2, 2021, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of May 2, 2021, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-21-000064:notes:108]
During the first quarter of fiscal year 2022, we paid $99 million in cash dividends to our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-21-000064:notes:109]
Segment Information
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. Our two operating segments are "Graphics" and "Compute & Networking." Our operating segments are equivalent to our reportable segments.

[0001045810-21-000064:notes:110]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise design; GRID software for cloud-based visual and virtual computing; and automotive platforms for infotainment systems.

[0001045810-21-000064:notes:111]
Our Compute & Networking segment includes Data Center platforms and systems for artificial intelligence, or AI, high performance computing, or HPC, and accelerated computing; Mellanox networking and interconnect solutions; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; cryptocurrency mining processors, or CMP; and Jetson for robotics and other embedded platforms.

[0001045810-21-000064:notes:112]
[same as prior period, unchanged from 0001045810-20-000189:notes:143]

[0001045810-21-000064:notes:113]
The “All Other” category includes the expenses that our CODM does not assign to either Graphics or Compute & Networking for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, IP-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-21-000064:notes:114]
[same as prior period, unchanged from 0001045810-20-000189:notes:145]

[0001045810-21-000064:notes:115]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended May 2, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 3,451 |  |  | $ | 2,210 |  |  | $ | — |  |  | $ | 5,661 |  |
| Operating income (loss) | $ | 1,786 |  |  | $ | 861 |  |  | $ | (691) |  |  | $ | 1,956 |  |
| Three Months Ended April 26, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 1,906 |  |  | $ | 1,174 |  |  | $ | — |  |  | $ | 3,080 |  |
| Operating income (loss) | $ | 836 |  |  | $ | 451 |  |  | $ | (311) |  |  | $ | 976 |  |

[0001045810-21-000064:notes:116]
|  | Three Months Ended |  |  |
|  | May 2,2021 |  | April 26,2020 |  |  |  |  |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (429) |  |  | $ | (224) |  |  |  |  |  |
| Acquisition-related and other costs | (167) |  |  | (5) |  |  |  |  |  |
| Unallocated cost of revenue and operating expenses | (90) |  |  | (82) |  |  |  |  |  |
| IP-related costs | (5) |  |  | — |  |  |  |  |  |
| Total | $ | (691) |  |  | $ | (311) |  |  |  |  |  |

[0001045810-21-000064:notes:117]
[same as prior period, unchanged from 0001045810-20-000189:notes:148]

[0001045810-21-000064:notes:118]
|  | Three Months Ended |  |  |
|  | May 2, |  | April 26, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 1,784 |  |  | $ | 813 |  |  |  |  |  |
| China (including Hong Kong) | 1,391 |  |  | 758 |  |  |  |  |  |
| Other Asia Pacific | 1,001 |  |  | 607 |  |  |  |  |  |
| United States | 768 |  |  | 497 |  |  |  |  |  |
| Europe | 381 |  |  | 254 |  |  |  |  |  |
| Other countries | 336 |  |  | 151 |  |  |  |  |  |
| Total revenue | $ | 5,661 |  |  | $ | 3,080 |  |  |  |  |  |

[0001045810-21-000064:notes:119]
[same as prior period, unchanged from 0001045810-20-000189:notes:150]

[0001045810-21-000064:notes:120]
|  | Three Months Ended |  |  |
|  | May 2, |  | April 26, |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 2,760 |  |  | $ | 1,339 |  |  |  |  |  |
| Data Center | 2,048 |  |  | 1,141 |  |  |  |  |  |
| Professional Visualization | 372 |  |  | 307 |  |  |  |  |  |
| Automotive | 154 |  |  | 155 |  |  |  |  |  |
| OEM and Other | 327 |  |  | 138 |  |  |  |  |  |
| Total revenue | $ | 5,661 |  |  | $ | 3,080 |  |  |  |  |  |

[0001045810-21-000064:notes:121]
No customer represented 10% or more of total revenue for the first quarter of fiscal years 2022 or 2021.
One customer represented 13% and 16% of our accounts receivable balance as of May 2, 2021 and January 31, 2021, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001045810-21-000064:notes:122]
Subsequent Event
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock in the form of a stock dividend, conditioned on obtaining stockholder approval at our 2021 Annual Meeting of Stockholders to be held on June 3, 2021, of an amendment to our Amended and Restated Certificate of Incorporation to increase the number of authorized shares of common stock from 2 billion to 4 billion. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the four-for-one stock split as if it had been effective for all periods presented:
