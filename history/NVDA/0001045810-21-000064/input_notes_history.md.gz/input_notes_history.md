# NVDA note change history — 0001045810-20-000189 → 0001045810-21-000064


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-26):
[0001045810-21-000064:note_history:1]
As of May 2, 2021, we had outstanding inventory purchase obligations totaling $3.46 billion which are expected to occur over the next 12 months, and other purchase obligations totaling $396 million, which are primarily expected to occur over the next 18 months.
  (was, 2020-11-18, similarity 0.6804):
[0001045810-20-000189:note_history:1]
As of October 25, 2020, we had outstanding inventory purchase obligations totaling $2.57 billion and other purchase obligations totaling $398 million.

- changed (2021-05-26):
[0001045810-21-000064:note_history:2]
The estimated amount of product warranty liabilities was $30 million and $22 million as of May 2, 2021 and January 31, 2021, respectively, and the activities related to the warranty liabilities were not significant.
  (was, 2020-11-18, similarity 0.9479):
[0001045810-20-000189:note_history:2]
The estimated amount of product returns and warranty liabilities was $19 million and $15 million as of October 25, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.

- added (2021-05-26):
[0001045810-21-000064:note_history:3]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed a notice of appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.

- changed (2021-05-26):
[0001045810-21-000064:note_history:4]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.
  (was, 2020-11-18, similarity 0.965):
[0001045810-20-000189:note_history:4]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

- changed (2021-05-26):
[0001045810-21-000064:note_history:5]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2020-11-18, similarity 0.967):
[0001045810-20-000189:note_history:5]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action.  The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2021-05-26):
[0001045810-21-000064:note_history:6]
As of May 2, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2021-05-26):
[0001045810-20-000189:note_history:7]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020.  The amended complaint asserts that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act.  Plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper.  On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the individual defendants.  As of September 14, 2020, the motion was fully briefed but the Court has not yet issued a decision.

- removed (2021-05-26):
[0001045810-20-000189:note_history:8]
As of October 25, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-26):
[0001045810-21-000064:note_history:9]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 31, 2021 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021.
  (was, 2020-11-18, similarity 0.9996):
[0001045810-20-000189:note_history:9]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 26, 2020 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

- changed (2021-05-26):
[0001045810-21-000064:note_history:10]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021.
  (was, 2020-11-18, similarity 0.8496):
[0001045810-20-000189:note_history:10]
Except for the accounting policies for business combination and investment in non-affiliated entities, there have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

- changed (2021-05-26):
[0001045810-21-000064:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The first quarters of fiscal years 2022 and 2021 were both 13-week quarters.
  (was, 2020-11-18, similarity 0.969):
[0001045810-20-000189:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The third quarters of fiscal years 2021 and 2020 were both 13-week quarters.

- changed (2021-05-26):
[0001045810-21-000064:note_history:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2020-11-18, similarity 0.9715):
[0001045810-20-000189:note_history:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19 on our critical and significant accounting estimates. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- removed (2021-05-26):
[0001045810-20-000189:note_history:13]
The unaudited condensed consolidated financial statements in this report include the financial results of Mellanox Technologies Ltd., or Mellanox, prospectively from April 27, 2020. For additional details, refer to Note 2 - Business Combination.

- removed (2021-05-26):
[0001045810-20-000189:note_history:14]
Business Combination

- removed (2021-05-26):
[0001045810-20-000189:note_history:15]
We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, including in-process research and development, or IPR&D, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our condensed consolidated statements of income.

- removed (2021-05-26):
[0001045810-20-000189:note_history:16]
We initially capitalize the fair value of IPR&D as an intangible asset with an indefinite life. We assess for impairment thereafter. When IPR&D projects are completed, we reclassify the IPR&D as an amortizable purchased intangible asset and amortize over the asset’s estimated useful life.

- removed (2021-05-26):
[0001045810-20-000189:note_history:17]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

- removed (2021-05-26):
[0001045810-20-000189:note_history:18]
Investment in Non-Affiliated Entities

- removed (2021-05-26):
[0001045810-20-000189:note_history:19]
Non-marketable equity investments in privately-held companies are recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. These investments are valued using observable and unobservable inputs or data in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. The estimated fair value is based on quantitative and qualitative factors including subsequent financing activities by the investee.

- removed (2021-05-26):
[0001045810-20-000189:note_history:20]
Adoption of New and Recently Issued Accounting Pronouncements

- removed (2021-05-26):
[0001045810-20-000189:note_history:21]
Recently Adopted Accounting Pronouncement

- removed (2021-05-26):
[0001045810-20-000189:note_history:22]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. We adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-05-26):
[0001045810-21-000064:note_history:23]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year.

- changed (2021-05-26):
[0001045810-21-000064:note_history:24]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year.
  (was, 2020-11-18, similarity 0.6748):
[0001045810-20-000189:note_history:24]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-

- changed (2021-05-26):
[0001045810-21-000064:note_history:25]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 2, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 8.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 3.50% Notes Due 2040 |  | 18.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (37) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 6,963 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 5,964 |  |  | $ | 5,964 |  |
  (was, 2020-11-18, similarity 0.6645):
[0001045810-20-000189:note_history:25]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 25, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.4 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.4 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.5 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.5 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,961 |  |  | $ | 1,991 |  |

- changed (2021-05-26):
[0001045810-21-000064:note_history:26]
As of May 2, 2021, we were in compliance with the required covenants under the Notes.
  (was, 2020-11-18, similarity 0.939):
[0001045810-20-000189:note_history:26]
As of October 25, 2020, we were in compliance with the required covenants under the Notes.

- changed (2021-05-26):
[0001045810-21-000064:note_history:27]
Credit Facilities
  (was, 2020-11-18, similarity 0.6667):
[0001045810-20-000189:note_history:27]
Revolving Credit Facility

- changed (2021-05-26):
[0001045810-21-000064:note_history:28]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of May 2, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.
  (was, 2020-11-18, similarity 0.8286):
[0001045810-20-000189:note_history:28]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 25, 2020, we had not borrowed any amounts and were in compliance with the required covenants under this agreement.

- changed (2021-05-26):
[0001045810-21-000064:note_history:29]
We have a $575 million commercial paper program to support general corporate purposes. As of May 2, 2021, we had not issued any commercial paper.
  (was, 2020-11-18, similarity 0.9643):
[0001045810-20-000189:note_history:29]
We have a $575 million commercial paper program to support general corporate purposes. As of October 25, 2020, we had not issued any commercial paper.

- removed (2021-05-26):
[0001045810-20-000189:note_history:30]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and issuance costs.

- removed (2021-05-26):
[0001045810-20-000189:note_history:31]
whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

- removed (2021-05-26):
[0001045810-20-000189:note_history:32]
Commercial Paper


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-26):
[0001045810-21-000064:note_history:33]
The following is a summary of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021:
  (was, 2020-11-18, similarity 0.9524):
[0001045810-20-000189:note_history:33]
The following is a summary of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020:

- added (2021-05-26):
[0001045810-21-000064:note_history:34]
|  | May 2, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,240 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 5,242 |  |  | $ | 323 |  |  | $ | 4,919 |  |
| Debt securities issued by United States government agencies | 3,045 |  |  | 1 |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Debt securities issued by the United States Treasury | 2,820 |  |  | 1 |  |  | — |  |  | 2,821 |  |  | — |  |  | 2,821 |  |
| Certificates of deposit | 884 |  |  | — |  |  | — |  |  | 884 |  |  | 48 |  |  | 836 |  |
| Money market funds | 319 |  |  | — |  |  | — |  |  | 319 |  |  | 319 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 12,375 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12,379 |  |  | $ | 690 |  |  | $ | 11,689 |  |

- added (2021-05-26):
[0001045810-21-000064:note_history:35]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

- removed (2021-05-26):
[0001045810-20-000189:note_history:36]
|  | October 25, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 3,881 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,881 |  |  | $ | 1,116 |  |  | $ | 2,765 |  |
| Corporate debt securities | 3,139 |  |  | 2 |  |  | — |  |  | 3,141 |  |  | 427 |  |  | 2,714 |  |
| Debt securities issued by United States government agencies | 1,571 |  |  | 1 |  |  | — |  |  | 1,572 |  |  | — |  |  | 1,572 |  |
| Certificates of deposit | 797 |  |  | — |  |  | — |  |  | 797 |  |  | 29 |  |  | 768 |  |
| Money market funds | 388 |  |  | — |  |  | — |  |  | 388 |  |  | 388 |  |  | — |  |
| Foreign government bonds | 117 |  |  | — |  |  | — |  |  | 117 |  |  | 48 |  |  | 69 |  |
| Total | $ | 9,893 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 9,896 |  |  | $ | 2,008 |  |  | $ | 7,888 |  |

- removed (2021-05-26):
[0001045810-20-000189:note_history:37]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-26):
[0001045810-21-000064:note_history:38]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.
  (was, 2020-11-18, similarity 0.7672):
[0001045810-20-000189:note_history:38]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities, except for money market funds and certificates of deposits, are classified as “available-for-sale” debt securities.

- changed (2021-05-26):
[0001045810-21-000064:note_history:39]
The following is a summary of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021:
  (was, 2020-11-18, similarity 0.9524):
[0001045810-20-000189:note_history:39]
The following is a summary of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020:

- added (2021-05-26):
[0001045810-21-000064:note_history:40]
|  | May 2, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,240 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 5,242 |  |  | $ | 323 |  |  | $ | 4,919 |  |
| Debt securities issued by United States government agencies | 3,045 |  |  | 1 |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Debt securities issued by the United States Treasury | 2,820 |  |  | 1 |  |  | — |  |  | 2,821 |  |  | — |  |  | 2,821 |  |
| Certificates of deposit | 884 |  |  | — |  |  | — |  |  | 884 |  |  | 48 |  |  | 836 |  |
| Money market funds | 319 |  |  | — |  |  | — |  |  | 319 |  |  | 319 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 12,375 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12,379 |  |  | $ | 690 |  |  | $ | 11,689 |  |

- added (2021-05-26):
[0001045810-21-000064:note_history:41]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

- changed (2021-05-26):
[0001045810-21-000064:note_history:42]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021 are shown below by contractual maturity.
  (was, 2020-11-18, similarity 0.9691):
[0001045810-20-000189:note_history:42]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020 are shown below by contractual maturity.

- added (2021-05-26):
[0001045810-21-000064:note_history:43]
|  | May 2, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,499 |  |  | $ | 11,502 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 876 |  |  | 877 |  |  | 566 |  |  | 568 |  |
| Total | $ | 12,375 |  |  | $ | 12,379 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |

- removed (2021-05-26):
[0001045810-20-000189:note_history:44]
|  | October 25, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 3,881 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,881 |  |  | $ | 1,116 |  |  | $ | 2,765 |  |
| Corporate debt securities | 3,139 |  |  | 2 |  |  | — |  |  | 3,141 |  |  | 427 |  |  | 2,714 |  |
| Debt securities issued by United States government agencies | 1,571 |  |  | 1 |  |  | — |  |  | 1,572 |  |  | — |  |  | 1,572 |  |
| Certificates of deposit | 797 |  |  | — |  |  | — |  |  | 797 |  |  | 29 |  |  | 768 |  |
| Money market funds | 388 |  |  | — |  |  | — |  |  | 388 |  |  | 388 |  |  | — |  |
| Foreign government bonds | 117 |  |  | — |  |  | — |  |  | 117 |  |  | 48 |  |  | 69 |  |
| Total | $ | 9,893 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 9,896 |  |  | $ | 2,008 |  |  | $ | 7,888 |  |

- removed (2021-05-26):
[0001045810-20-000189:note_history:45]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- removed (2021-05-26):
[0001045810-20-000189:note_history:46]
|  | October 25, 2020 |  | January 26, 2020 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 9,329 |  |  | $ | 9,330 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 564 |  |  | 566 |  |  | — |  |  | — |  |
| Total | $ | 9,893 |  |  | $ | 9,896 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-26):
[0001045810-21-000064:note_history:47]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 2, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 8.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 3.50% Notes Due 2040 |  | 18.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (37) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 6,963 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 5,964 |  |  | $ | 5,964 |  |
  (was, 2020-11-18, similarity 0.6645):
[0001045810-20-000189:note_history:47]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 25, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.4 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.4 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.5 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.5 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,961 |  |  | $ | 1,991 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-05-26):
[0001045810-21-000064:note_history:48]
Subsequent Event
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock in the form of a stock dividend, conditioned on obtaining stockholder approval at our 2021 Annual Meeting of Stockholders to be held on June 3, 2021, of an amendment to our Amended and Restated Certificate of Incorporation to increase the number of authorized shares of common stock from 2 billion to 4 billion. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the four-for-one stock split as if it had been effective for all periods presented:

- added (2021-05-26):
[0001045810-21-000064:note_history:49]
|  |  |  | Pro Forma (Unaudited) |  |  |  |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |  |  |
|  |  |  |  |  | May 2, |  | April 26, |  | January 31, |  | January 26, |  | January 27, |  |  |  |  |
|  |  |  |  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2019 |  |  |  |  |
|  |  |  |  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  |  |  |  | $ | 1,912 |  |  | $ | 917 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |  | $ | 4,141 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares |  |  |  |  | 2,484 |  |  | 2,456 |  |  | 2,468 |  |  | 2,436 |  |  | 2,432 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards |  |  |  |  | 44 |  |  | 32 |  |  | 44 |  |  | 36 |  |  | 68 |  |  |  |  |  |
| Diluted weighted average shares |  |  |  |  | 2,528 |  |  | 2,488 |  |  | 2,512 |  |  | 2,472 |  |  | 2,500 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic (1) |  |  |  |  | $ | 0.77 |  |  | $ | 0.37 |  |  | $ | 1.76 |  |  | $ | 1.15 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted (2) |  |  |  |  | $ | 0.76 |  |  | $ | 0.37 |  |  | $ | 1.72 |  |  | $ | 1.13 |  |  | $ | 1.66 |  |  |  |  |  |

- added (2021-05-26):
[0001045810-21-000064:note_history:50]
(1)    Calculated as net income divided by basic weighted average shares.

- added (2021-05-26):
[0001045810-21-000064:note_history:51]
(2)    Calculated as net income divided by diluted weighted average shares.
