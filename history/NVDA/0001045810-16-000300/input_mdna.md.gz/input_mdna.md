# NVDA MD&A — 0001045810-16-000300


## mdna

[0001045810-16-000300:mdna:1]
[same as prior period, unchanged from 0001045810-16-000275:mdna:1]

[0001045810-16-000300:mdna:2]
[same as prior period, unchanged from 0001045810-16-000275:mdna:2]

[0001045810-16-000300:mdna:3]
[same as prior period, unchanged from 0001045810-16-000275:mdna:3]

[0001045810-16-000300:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, Ansel, GeForce NOW, Icera, Iray, NVIDIA DGX-1, NVIDIA DRIVE, NVIDIA DesignWorks, NVIDIA GRID, NVIDIA SHIELD, NVIDIA VRWorks, and Pascal are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-16-000300:mdna:5]
[same as prior period, unchanged from 0001045810-16-000275:mdna:5]

[0001045810-16-000300:mdna:6]
[same as prior period, unchanged from 0001045810-16-000275:mdna:6]

[0001045810-16-000300:mdna:7]
[same as prior period, unchanged from 0001045810-16-000275:mdna:7]

[0001045810-16-000300:mdna:8]
[same as prior period, unchanged from 0001045810-16-000275:mdna:8]

[0001045810-16-000300:mdna:9]
[same as prior period, unchanged from 0001045810-16-000275:mdna:9]

[0001045810-16-000300:mdna:10]
[same as prior period, unchanged from 0001045810-16-000275:mdna:10]

[0001045810-16-000300:mdna:11]
[same as prior period, unchanged from 0001045810-16-000275:mdna:11]

[0001045810-16-000300:mdna:12]
25

[0001045810-16-000300:mdna:13]
[same as prior period, unchanged from 0001045810-16-000275:mdna:12]

[0001045810-16-000300:mdna:14]
Second Quarter of Fiscal Year 2017 Summary

[0001045810-16-000300:mdna:15]
|  | Three Months Ended |  |  |  |  |
|  | July 31, 2016 |  | May 1, 2016 |  | July 26, 2015 |  | Q/Q |  | Y/Y |
|  | (In millions, except per share data) |
| Revenue | $ | 1,428 |  |  | $ | 1,305 |  |  | $ | 1,153 |  |  | 9 | % |  | 24 | % |
| Gross margin | 57.9 | % |  | 57.5 | % |  | 55.0 | % |  | 40 bps |  |  | 290 bps |  |
| Operating expenses | $ | 509 |  |  | $ | 506 |  |  | $ | 558 |  |  | 1 | % |  | (9 | )% |
| Income from operations | $ | 317 |  |  | $ | 245 |  |  | $ | 76 |  |  | 29 | % |  | 317 | % |
| Net income | $ | 253 |  |  | $ | 196 |  |  | $ | 26 |  |  | 29 | % |  | 873 | % |
| Net income per diluted share | $ | 0.40 |  |  | $ | 0.33 |  |  | $ | 0.05 |  |  | 21 | % |  | 700 | % |

[0001045810-16-000300:mdna:16]
Revenue increased 24% in the second quarter of fiscal year 2017 to $1.43 billion. Growth was driven by GPUs for gaming, datacenter and professional visualization, as well as by Tegra automotive systems. GPU business revenue was $1.2 billion, up 25% from a year earlier and up 11% sequentially, reflecting strength in GeForce gaming GPU, datacenter, and professional visualization revenue. Tegra Processor business revenue of $166 million was up 30% year on year and up 4% sequentially, reflecting growth in Tegra automotive systems.

[0001045810-16-000300:mdna:17]
Gaming platform revenue for the second quarter of fiscal year 2017 was $781 million, up 18% from a year ago, driven by Pascal gaming GPU sales across all regions. Datacenter revenue, including Tesla and NVIDIA GRID, was $151 million, up 110% from a year earlier and up 6% sequentially, amid strong demand for GPU acceleration related to deep learning. Professional visualization revenue from Quadro was $214 million, up 22% year over year and up 13% sequentially. Automotive revenue from infotainment modules and product development contracts was $119 million, up 68% from a year earlier and up 5% sequentially.

[0001045810-16-000300:mdna:18]
Gross margin for the second quarter of fiscal year 2017 was 57.9%, reflecting the strength of our GeForce gaming GPUs, our platform approach, and demand for deep learning.

[0001045810-16-000300:mdna:19]
Operating expenses for the second quarter of fiscal year 2017 were $509 million, down 9% from a year earlier and up 1% sequentially. The year over year decrease was driven primarily by $89 million in restructuring and other charges we recorded in the second quarter of fiscal year 2016 associated with the wind-down of our Icera operations. The sequential increase reflects headcount related costs from hiring for our growth initiatives and marketing expenses associated with the introduction of our new Pascal family of GPUs.

[0001045810-16-000300:mdna:20]
Income from operations for the second quarter of fiscal year 2017 was $317 million, up 317% from $76 million a year ago. Net income and net income per diluted share for the second quarter of fiscal year 2017 was $253 million and $0.40, respectively, increases of 873% and 700%, respectively. These year over year increases were primarily a result of revenue growing at a faster rate than operating expenses, gross margin improvements, and the $89 million in restructuring and other charges recorded in the year ago quarter.

[0001045810-16-000300:mdna:21]
During the first half of fiscal year 2017, we paid $509 million for share repurchases and $124 million in cash dividends.

[0001045810-16-000300:mdna:22]
Cash, cash equivalents and marketable securities were $4.88 billion as of July 31, 2016, compared with $4.75 billion at the end of the prior quarter, as operating cash flow was partially offset by the quarterly cash dividend.

[0001045810-16-000300:mdna:23]
[same as prior period, unchanged from 0001045810-16-000275:mdna:22]

[0001045810-16-000300:mdna:24]
During the second quarter of fiscal year 2017, we began shipping our Pascal architecture with  a set of gaming GPUs: NVIDIA GeForce GTX 1080, 1070, 1060, and TITAN X, and released our first game, NVIDIA VR Funhouse. For our datacenter platform, we introduced the Tesla M10 for virtualizing enterprise applications, introduced Tesla P100 GPU accelerators, delivering substantial performance and value compared with CPU-based systems, and unveiled our Inception Program, which provides access to NVIDIA technology and expertise to support the growth of startups in deep learning and data science. For our professional virtualization platform, we unveiled Quadro P6000 to power advanced workstations, enabling designers to complete complex designs and refreshed NVIDIA DesignWorks and NVIDIA VRWorks with new updates and software development kits.

[0001045810-16-000300:mdna:25]
26

[0001045810-16-000300:mdna:26]
[same as prior period, unchanged from 0001045810-16-000275:mdna:23]

[0001045810-16-000300:mdna:27]
[same as prior period, unchanged from 0001045810-16-000275:mdna:24]

[0001045810-16-000300:mdna:28]
During the second quarter of fiscal year 2017, we initiated collaborative research in advanced self-driving technology with New York University’s pioneering deep learning team.

[0001045810-16-000300:mdna:29]
[same as prior period, unchanged from 0001045810-16-000275:mdna:25]

[0001045810-16-000300:mdna:30]
[same as prior period, unchanged from 0001045810-16-000275:mdna:26]

[0001045810-16-000300:mdna:31]
[same as prior period, unchanged from 0001045810-16-000275:mdna:27]

[0001045810-16-000300:mdna:32]
[same as prior period, unchanged from 0001045810-16-000275:mdna:28]

[0001045810-16-000300:mdna:33]
[same as prior period, unchanged from 0001045810-16-000275:mdna:29]

[0001045810-16-000300:mdna:34]
[same as prior period, unchanged from 0001045810-16-000275:mdna:30]

[0001045810-16-000300:mdna:35]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, restructuring and other charges, contributions, product warranty charge, legal settlement costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-16-000300:mdna:36]
[same as prior period, unchanged from 0001045810-16-000275:mdna:32]

[0001045810-16-000300:mdna:37]
[same as prior period, unchanged from 0001045810-16-000275:mdna:33]

[0001045810-16-000300:mdna:38]
[same as prior period, unchanged from 0001045810-16-000275:mdna:34]

[0001045810-16-000300:mdna:39]
[same as prior period, unchanged from 0001045810-16-000275:mdna:35]

[0001045810-16-000300:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |  | July 31, 2016 |  | July 26, 2015 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 42.1 |  |  | 45.0 |  |  | 42.3 |  |  | 44.2 |  |
| Gross profit | 57.9 |  |  | 55.0 |  |  | 57.7 |  |  | 55.8 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 24.5 |  |  | 27.8 |  |  | 25.5 |  |  | 28.6 |  |
| Sales, general and administrative | 11.0 |  |  | 12.9 |  |  | 11.6 |  |  | 12.5 |  |
| Restructuring and other charges | 0.1 |  |  | 7.7 |  |  | 0.1 |  |  | 3.9 |  |
| Total operating expenses | 35.6 |  |  | 48.4 |  |  | 37.2 |  |  | 45.0 |  |
| Income from operations | 22.2 |  |  | 6.7 |  |  | 20.5 |  |  | 10.8 |  |
| Interest income | 0.8 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |
| Interest expense | (0.8 | ) |  | (1.0 | ) |  | (0.8 | ) |  | (1.0 | ) |
| Other income (expense), net | — |  |  | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Income before income tax expense | 22.2 |  |  | 6.4 |  |  | 20.4 |  |  | 10.5 |  |
| Income tax expense | 4.5 |  |  | 4.0 |  |  | 4.0 |  |  | 3.6 |  |
| Net income | 17.7 | % |  | 2.4 | % |  | 16.4 | % |  | 6.9 | % |

[0001045810-16-000300:mdna:41]
[same as prior period, unchanged from 0001045810-16-000275:mdna:37]

[0001045810-16-000300:mdna:42]
NVIDIA’s products and services are built for three computing platforms - PC, Datacenter/Cloud, and Mobile. For the first half of fiscal years 2017 and 2016, approximately 72% and 75% of our revenue, respectively, was associated with the PC computing platform, of which GPUs for the gaming and professional visualization markets comprised approximately 91% and 87%, respectively, while PC OEM represented approximately 9% and 13%, respectively.

[0001045810-16-000300:mdna:43]
[same as prior period, unchanged from 0001045810-16-000275:mdna:39]

[0001045810-16-000300:mdna:44]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |  | $Change |  | %Change |  | July 31, 2016 |  | July 26, 2015 |  | $Change |  | %Change |
|  | (In millions) |
| GPU | $ | 1,196 |  |  | $ | 959 |  |  | $ | 237 |  |  | 25 | % |  | $ | 2,275 |  |  | $ | 1,899 |  |  | $ | 376 |  |  | 20 | % |
| Tegra Processor | 166 |  |  | 128 |  |  | 38 |  |  | 30 | % |  | 326 |  |  | 273 |  |  | 53 |  |  | 19 | % |
| All Other | 66 |  |  | 66 |  |  | — |  |  | — | % |  | 132 |  |  | 132 |  |  | — |  |  | — | % |
| Total | $ | 1,428 |  |  | $ | 1,153 |  |  | $ | 275 |  |  | 24 | % |  | $ | 2,733 |  |  | $ | 2,304 |  |  | $ | 429 |  |  | 19 | % |

[0001045810-16-000300:mdna:45]
GPU Business. GPU business revenue increased by 25% for the second quarter of fiscal year 2017 compared to the second quarter of fiscal year 2016. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased 20%, reflecting a combination of continued strength in PC gaming and strong demand for our new Pascal-based GPU products. Datacenter revenue, including Tesla and NVIDIA GRID, increased 110%, reflecting strong demand for GPU acceleration related to deep learning. Revenue from Quadro GPUs for professional visualization increased 22% due primarily to higher sales in both desktop and mobile workstation products year over year. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-16-000300:mdna:46]
[same as prior period, unchanged from 0001045810-16-000275:mdna:41]

[0001045810-16-000300:mdna:47]
GPU business revenue increased by 20% in the first half of fiscal year 2017 compared to the first half of fiscal year 2016. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased  21%, reflecting a combination of continued strength in PC gaming and strong demand for our new Pascal-based GPU products. Datacenter revenue, including Tesla and NVIDIA GRID, increased 84%, reflecting strong demand for GPU acceleration related to deep learning. Revenue from Quadro GPUs for professional visualization increased 13% due primarily to higher sales in the both desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-16-000300:mdna:48]
Tegra Processor Business. Tegra Processor business revenue increased by 30% for the second quarter of fiscal year 2017 compared to the second quarter of fiscal year 2016. This was driven by an increase of 68% in sales of Tegra products serving automotive systems, partially offset by a decline in development services compared to last year.

[0001045810-16-000300:mdna:49]
Tegra Processor business revenue increased by 19% in the first half of fiscal year 2017 compared to the first half of fiscal year 2016. This was driven by an increase of 57% in sales of Tegra products serving automotive systems, partially offset by a decline in development services compared to last year.

[0001045810-16-000300:mdna:50]
All Other. We recognized $66 million in revenue during the second quarter of both fiscal years 2017 and 2016 and $132 million in revenue during the first half of both fiscal years 2017 and 2016, from the patent cross licensing arrangement with Intel.

[0001045810-16-000300:mdna:51]
[same as prior period, unchanged from 0001045810-16-000275:mdna:45]

[0001045810-16-000300:mdna:52]
Revenue from sales to customers outside of the United States and Other Americas accounted for 78% of total revenue for both the second quarter and the first half of fiscal year 2017. Revenue from sales to customers outside of the United States and Other Americas accounted for 80% of total revenue for the second quarter of fiscal year 2016 and 77% of total revenue for the first half of fiscal year 2016. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-16-000300:mdna:53]
[same as prior period, unchanged from 0001045810-16-000275:mdna:47]

[0001045810-16-000300:mdna:54]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |  | July 31, 2016 |  | July 26, 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Customer A | 10 | % |  | 13 | % |  | 11 | % |  | 11 | % |
| Customer B | 8 | % |  | 10 | % |  | 8 | % |  | 10 | % |

[0001045810-16-000300:mdna:55]
[same as prior period, unchanged from 0001045810-16-000275:mdna:49]

[0001045810-16-000300:mdna:56]
[same as prior period, unchanged from 0001045810-16-000275:mdna:50]

[0001045810-16-000300:mdna:57]
Our overall gross margin was 57.9% and 55.0% for the second quarter of fiscal years 2017 and 2016, respectively, and 57.7% and 55.8% for the first half of fiscal year 2017 and 2016, respectively. These increases were driven primarily by product mix in our GPU business, partially offset by lower gross margins in our Tegra business.

[0001045810-16-000300:mdna:58]
Charges to cost of sales for inventory provisions totaled $5 million and $18 million for the second quarter of fiscal years 2017 and 2016, respectively, unfavorably impacting our gross margin by 0.3% and 1.5%, respectively. Sales of inventory that was previously written-off or written-down totaled $12 million and $10 million for the second quarter of fiscal years 2017 and 2016, respectively, favorably impacting our gross margin by 0.9% for both years. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.5% favorable impact for the second quarter of fiscal year 2017 and a 0.6% unfavorable impact for the second quarter of fiscal year 2016.

[0001045810-16-000300:mdna:59]
[same as prior period, unchanged from 0001045810-16-000275:mdna:56]

[0001045810-16-000300:mdna:60]
Charges to cost of sales for inventory provisions totaled $27 million and $31 million for the first half of fiscal years 2017 and 2016, respectively, unfavorably impacting our gross margin by 1.0% and 1.4%, respectively. Sales of inventory that was previously written-off or written-down totaled $20 million and $19 million for the first half of fiscal years 2017 and 2016, respectively, favorably impacting our gross margin by 0.7% and 0.8%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.3% unfavorable impact for the first half of fiscal year 2017 and a 0.6% unfavorable impact for the first half of fiscal year 2016.

[0001045810-16-000300:mdna:61]
[same as prior period, unchanged from 0001045810-16-000275:mdna:53]

[0001045810-16-000300:mdna:62]
GPU Business. The gross margin of our GPU business increased during the second quarter and first half of fiscal year 2017 compared to the second quarter and first half of fiscal year 2016. GPU margins increased primarily due to strong demand for Tesla products for deep learning and high performance computing and Quadro products for professional visualization.

[0001045810-16-000300:mdna:63]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the second quarter and first half of fiscal year 2017 compared to the second quarter and first half of fiscal year 2016. The increase in Tegra margins was primarily due to the warranty charge we recorded in the prior year associated with the SHIELD tablet product recall.

[0001045810-16-000300:mdna:64]
[same as prior period, unchanged from 0001045810-16-000275:mdna:57]

[0001045810-16-000300:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |  | $Change |  | %Change |  | July 31, 2016 |  | July 26, 2015 |  | $Change |  | %Change |
|  | (In millions) |
| Research and development expenses | $ | 350 |  |  | $ | 320 |  |  | $ | 30 |  |  | 9 | % |  | $ | 697 |  |  | $ | 658 |  |  | $ | 39 |  |  | 6 | % |
| Sales, general and administrative expenses | 157 |  |  | 149 |  |  | 8 |  |  | 5 | % |  | 316 |  |  | 289 |  |  | 27 |  |  | 9 | % |
| Restructuring and other charges | 2 |  |  | 89 |  |  | (87 | ) |  | (98 | )% |  | 3 |  |  | 89 |  |  | (86 | ) |  | (97 | )% |
| Total operating expenses | $ | 509 |  |  | $ | 558 |  |  | $ | (49 | ) |  | (9 | )% |  | $ | 1,016 |  |  | $ | 1,036 |  |  | $ | (20 | ) |  | (2 | )% |
| Research and development expenses as a percentage of net revenue | 25 | % |  | 28 | % |  |  |  |  |  |  |  | 26 | % |  | 29 | % |  |  |  |  |
| Sales, general and administrative expenses as a percentage of net revenue | 11 | % |  | 13 | % |  |  |  |  |  |  |  | 12 | % |  | 13 | % |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | — | % |  | 8 | % |  |  |  |  |  | — | % |  | 4 | % |  |  |  |  |

[0001045810-16-000300:mdna:66]
[same as prior period, unchanged from 0001045810-16-000275:mdna:59]

[0001045810-16-000300:mdna:67]
Research and development expenses increased by 9% during the second quarter of fiscal year 2017 compared to the second quarter of fiscal year 2016. Compensation and benefits increased by $26 million primarily driven by employee additions and compensation increases.

[0001045810-16-000300:mdna:68]
Research and development expenses increased by 6% during the first half of fiscal year 2017 compared to the first half of fiscal year 2016. Compensation and benefits increased by $30 million primarily driven by employee additions and compensation increases. Engineering and development expenses increased by $4 million associated with our newest platform architecture, Pascal.

[0001045810-16-000300:mdna:69]
[same as prior period, unchanged from 0001045810-16-000275:mdna:61]

[0001045810-16-000300:mdna:70]
Sales, general and administrative expenses increased by 5% during the second quarter of fiscal year 2017 compared to the second quarter of fiscal year 2016. Compensation and benefits increased by $24 million primarily driven by employee additions and compensation increases. Marketing expense increased by $5 million mainly due to the introduction of our new Pascal family of GPUs. Offsetting these increases was a decrease in outside professional fees of $24 million resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-16-000300:mdna:71]
30

[0001045810-16-000300:mdna:72]
Sales, general and administrative expenses increased by 9% during the first half of fiscal year 2017 compared to the first half of fiscal year 2016. Compensation and benefits increased by $37 million primarily driven by employee additions and compensation increases. Marketing expense increased by $6 million mainly due to the introduction of our new Pascal family of GPUs. Offsetting these increases was a decrease in outside professional fees of $27 million resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-16-000300:mdna:73]
[same as prior period, unchanged from 0001045810-16-000275:mdna:63]

[0001045810-16-000300:mdna:74]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera operations. Our operating expenses for the three and six months ended July 31, 2016 included $2 million and $3 million, respectively, of restructuring and other charges. Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-16-000300:mdna:75]
[same as prior period, unchanged from 0001045810-16-000275:mdna:65]

[0001045810-16-000300:mdna:76]
[same as prior period, unchanged from 0001045810-16-000275:mdna:66]

[0001045810-16-000300:mdna:77]
Interest income was $12 million and $9 million during the second quarter of fiscal years 2017 and 2016, respectively, and $23 million and $18 million during the first half of fiscal years 2017 and 2016, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-16-000300:mdna:78]
Interest expense was $12 million during the second quarter of fiscal years 2017 and 2016 and $23 million and $22 million during the first half of fiscal years 2017 and 2016, respectively, consisting primarily of coupon interest and debt discount amortization related to the convertible notes we issued in December 2013.

[0001045810-16-000300:mdna:79]
Other Income (Expense), Net

[0001045810-16-000300:mdna:80]
Other income (expense), net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, and the impact of changes in foreign currency rates. Other income (expense), net, was not significant during the second quarter or the first half of either fiscal year 2017 or fiscal year 2016.

[0001045810-16-000300:mdna:81]
[same as prior period, unchanged from 0001045810-16-000275:mdna:72]

[0001045810-16-000300:mdna:82]
We recognized income tax expense of $64 million and $109 million for the second quarter and first half of fiscal year 2017, respectively, and $46 million and $84 million for the second quarter and first half of fiscal year 2016, respectively. Our effective tax rate was 20.3% and 19.6% for the second quarter and first half of fiscal year 2017, respectively, and 64.0% and 34.3% for the second quarter and first half of fiscal year 2016, respectively.

[0001045810-16-000300:mdna:83]
The decrease in our effective tax rate in the second quarter and first half of fiscal year 2017 compared to the same periods in the prior fiscal year was primarily due to the absence of tax-related restructuring charges recorded in the second quarter of fiscal year 2016, the favorable benefit of the U.S. federal research tax credit, which was permanently re-enacted in December 2015, and lower permanent tax differences related to stock-based compensation, partly offset by an increase in the amount of earnings subject to U.S. tax.

[0001045810-16-000300:mdna:84]
Our effective tax rate for the first half of fiscal year 2017 of 19.6% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit and discrete events that occurred in the first half of fiscal year 2017 primarily attributable to tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-16-000300:mdna:85]
[same as prior period, unchanged from 0001045810-16-000275:mdna:76]

[0001045810-16-000300:mdna:86]
[same as prior period, unchanged from 0001045810-16-000275:mdna:77]

[0001045810-16-000300:mdna:87]
|  | July 31, 2016 |  | January 31, 2016 |
|  | (In millions) |
| Cash and cash equivalents | $ | 426 |  |  | $ | 596 |  |
| Marketable securities | 4,453 |  |  | 4,441 |  |
| Cash, cash equivalents and marketable securities | $ | 4,879 |  |  | $ | 5,037 |  |

[0001045810-16-000300:mdna:88]
|  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 493 |  |  | $ | 409 |  |
| Net cash provided by (used in) investing activities | $ | (93 | ) |  | $ | 12 |  |
| Net cash used in financing activities | $ | (570 | ) |  | $ | (483 | ) |

[0001045810-16-000300:mdna:89]
As of July 31, 2016, we had $4.88 billion in cash, cash equivalents and marketable securities, a decrease of $158 million from the end of fiscal year 2016. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions. Our portfolio managers are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-16-000300:mdna:90]
Cash provided by operating activities increased in the first half of fiscal year 2017 compared to the first half of fiscal year 2016, primarily due to higher net income resulting from revenue growing at a faster rate than operating expenses and gross margin improvements.

[0001045810-16-000300:mdna:91]
Cash was used by investing activities in the first half of fiscal year 2017, primarily due to higher purchases of marketable securities and property and equipment and intangible assets than proceeds from sales and maturities of marketable securities. Cash was provided in investing activities in the first half of fiscal year 2016, primarily due to higher proceeds from sales and maturities of marketable securities.

[0001045810-16-000300:mdna:92]
Cash used in financing activities increased in the first half of fiscal year 2017 compared to the first half of fiscal year 2016. The increase was primarily due to the higher amount of share repurchases and dividend payments in the first half of fiscal year 2017 compared to the first half of fiscal year 2016.

[0001045810-16-000300:mdna:93]
[same as prior period, unchanged from 0001045810-16-000275:mdna:84]

[0001045810-16-000300:mdna:94]
Our primary source of liquidity is cash generated by our operations. Our investment portfolio consists principally of cash and cash equivalents, corporate debt securities, debt securities of United States government agencies, debt securities issued by United States Treasury, asset-backed securities, mortgage-backed securities issued by United States government-sponsored enterprises, foreign government bonds and money market funds. These investments are denominated in United States dollars. As of July 31, 2016, we did not have any investments in auction-rate preferred securities.

[0001045810-16-000300:mdna:95]
[same as prior period, unchanged from 0001045810-16-000275:mdna:86]

[0001045810-16-000300:mdna:96]
As of July 31, 2016 and January 31, 2016, we had $4.88 billion and $5.04 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of July 31, 2016, we were in compliance with our investment policy. As of July 31, 2016, our investments in government agencies and government-sponsored enterprises represented 45% of our total investment portfolio, while the financial sector accounted for 26% of our total investment portfolio.  All of our investments are in A/A3 or better rated securities.

[0001045810-16-000300:mdna:97]
Our cash balances are held in numerous locations throughout the world, including substantial amounts held outside of the United States. Most of the amounts held outside the United States may be repatriated to the United States. However, if we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal income tax at a rate of 35% less utilization of any net operating loss carryforwards, and further offset by any applicable research and foreign tax credits, plus any state income taxes on such income. Repatriation of some foreign balances may be restricted by local laws.

[0001045810-16-000300:mdna:98]
Dividend payments and any share repurchases must be made from cash held in the United States. In the second quarter and first half of fiscal year 2017, we made total cash dividend payments of $62 million and $124 million, respectively, and repurchased $9 million and $509 million of our common stock, respectively, utilizing a significant amount of our U.S. cash balance previously taxed as of July 31, 2016.

[0001045810-16-000300:mdna:99]
[same as prior period, unchanged from 0001045810-16-000275:mdna:90]

[0001045810-16-000300:mdna:100]
On December 2, 2013, we issued $1.50 billion of 1.00% Convertible Senior Notes, or the Notes, due in 2018 and concurrently entered into separate note hedge and warrant transactions. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were convertible during the second quarter of fiscal year 2017 and are currently convertible at the holders’ option in the third quarter of fiscal year 2017. During the second quarter of fiscal year 2017, we had received conversion notices for an aggregate of $229 million in principal amount of the Notes plus an additional notice subsequent to July 31, 2016 for $200 million in principal amount of the Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2017.

[0001045810-16-000300:mdna:101]
Given the current price of our common stock, we expect to receive additional notices of early conversion, which could require us to use a substantial amount of our cash in the United States to settle. If our cash balances in the United States are insufficient to cover such settlements and we do not obtain additional financing, we may be required to repatriate foreign earnings, which could result in additional tax liabilities. Please refer to Note 11 of the Notes to the Condensed Consolidated Financial Statements for further discussion.

[0001045810-16-000300:mdna:102]
[same as prior period, unchanged from 0001045810-16-000275:mdna:92]

[0001045810-16-000300:mdna:103]
In March 2016, we entered into an accelerated share repurchase, or ASR, agreement with an investment bank, under which we made an upfront payment of $500 million to purchase shares of our common stock and received an initial delivery of 12 million shares. The shares delivered resulted in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share. The ASR agreement was settled in July 2016 with a cash payment of $9 million to the investment bank. As a result, a total of 12 million shares were repurchased under the ASR transaction for $509 million, or an average price of $42.06 per share.

[0001045810-16-000300:mdna:104]
During the second quarter and first half of fiscal year 2017, we also paid $62 million and $124 million, respectively, in cash dividends to our shareholders, equivalent to $0.1150 per share. As a result, we returned $71 million and $633 million to shareholders during the second quarter and first half of fiscal year 2017, respectively, in the form of share repurchases and dividend payments.

[0001045810-16-000300:mdna:105]
We intend to return approximately $1.00 billion to our shareholders in fiscal year 2017 through a combination of share repurchases and cash dividends. We also declared on August 11, 2016 that we would pay our next quarterly cash dividend of $0.1150 per share on September 16, 2016, to all shareholders of record on August 25, 2016.

[0001045810-16-000300:mdna:106]
[same as prior period, unchanged from 0001045810-16-000275:mdna:96]

[0001045810-16-000300:mdna:107]
[same as prior period, unchanged from 0001045810-16-000275:mdna:97]

[0001045810-16-000300:mdna:108]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating requirements for at least the next twelve months. However, since substantial amounts of our cash are held outside of the United States, and the repayment of the principal amount of Notes, dividend payments and any share repurchases must be made from cash held in the United States, we may need to raise additional debt or equity financing or repatriate foreign earnings within this time frame. Repatriation of foreign earnings could result in additional tax liabilities related to such repatriated amount. We are continuously evaluating options for efficiently funding repayment of the principal amount of the Notes, early conversions of the Notes, dividend payments, share repurchases, ongoing operations and capital expenditures. We may engage in transactions for such purposes, including the issuance or incurrence of secured and unsecured debt and the refinancing and restructuring of existing debt. We also may require additional capital for other purposes not presently contemplated.

[0001045810-16-000300:mdna:109]
[same as prior period, unchanged from 0001045810-16-000275:mdna:99]

[0001045810-16-000300:mdna:110]
[same as prior period, unchanged from 0001045810-16-000275:mdna:100]

[0001045810-16-000300:mdna:111]
[same as prior period, unchanged from 0001045810-16-000275:mdna:101]

[0001045810-16-000300:mdna:112]
As of July 31, 2016, we had outstanding inventory purchase obligations totaling $826 million. Except as described above with respect to the Notes, there were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 31, 2016.

[0001045810-16-000300:mdna:113]
[same as prior period, unchanged from 0001045810-16-000275:mdna:103]

[0001045810-16-000300:mdna:114]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-16-000300:mdna:115]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
