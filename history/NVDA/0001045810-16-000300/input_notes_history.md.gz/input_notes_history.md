# NVDA note change history — 0001045810-16-000275 → 0001045810-16-000300


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-08-23):
[0001045810-16-000300:note_history:1]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941. On June 16, 2016, the ITC granted the joint motion and terminated the ITC investigation. The parties have also moved to dismiss all pending inter partes reviews. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party. On June 28, 2016, NVIDIA and Samsung executed a settlement agreement based on the April 28, 2016 memorandum of understanding.
  (was, 2016-05-25, similarity 0.8639):
[0001045810-16-000275:note_history:1]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941; the motion has not yet been granted. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party.

- changed (2016-08-23):
[0001045810-16-000300:note_history:2]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. On June 1, 2016, the ITC issued a Notice determining not to review the Administrative Law Judge’s determination, thereby finalizing termination of the investigation as to NVIDIA. Pursuant to the license agreement, $10 million was recorded as a charge to cost of revenue during the three months ended May 1, 2016.
  (was, 2016-05-25, similarity 0.7303):
[0001045810-16-000275:note_history:2]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. The Initial Determination is expected to become the Final Determination of the ITC on or before June 9, 2016. Pursuant to the license agreement, we paid Advanced Silicon Technologies $16 million during the three months ended May 1, 2016, of which $6 million was recorded as a patent-related intangible asset and $10 million was recorded as a charge to cost of revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-23):
[0001045810-16-000300:note_history:3]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The second quarter of fiscal years 2017 and 2016 were both 13-week quarters.
  (was, 2016-05-25, similarity 0.7446):
[0001045810-16-000275:note_history:3]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The first quarter of fiscal years 2017 and 2016 were both 13-week quarters.

- added (2016-08-23):
[0001045810-16-000300:note_history:4]
Reclassifications

- added (2016-08-23):
[0001045810-16-000300:note_history:5]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

- changed (2016-08-23):
[0001045810-16-000300:note_history:6]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting, including income taxes at settlement, classifications in the statement of cash flows, forfeitures and net settlements, and will be effective in our first quarter of fiscal year 2018. Early adoption is permitted in any annual or interim period. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements and whether or not to adopt it early. We expect that the adoption of this accounting guidance will result in increased volatility of our effective tax rate, and changes in certain tax-related balance sheet line items and statement of cash flows classifications.
  (was, 2016-05-25, similarity 0.8045):
[0001045810-16-000275:note_history:6]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting, including income taxes at settlement, classifications in the statement of cash flows, forfeitures and net settlements, and will be effective in our first quarter of fiscal year 2018. Early adoption is permitted in any annual or interim period. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements.

- changed (2016-08-23):
[0001045810-16-000300:note_history:7]
In February 2016, FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.
  (was, 2016-05-25, similarity 0.7777):
[0001045810-16-000275:note_history:7]
In February 2016, FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements, however, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-23):
[0001045810-16-000300:note_history:8]
The following table presents the carrying value of the Notes:
  (was, 2016-05-25, similarity 0.76):
[0001045810-16-000275:note_history:8]
The following table presents the carrying amounts of the liability and equity components:

- changed (2016-08-23):
[0001045810-16-000300:note_history:9]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (72 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,428 |  |  | $ | 1,413 |  |
  (was, 2016-05-25, similarity 0.651):
[0001045810-16-000275:note_history:9]
|  |  | May 1, |  | January 31, |
|  |  | 2016 |  | 2016 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 39 |  |  | $ | 39 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (79 | ) |  | (87 | ) |
| Net carrying amount |  | $ | 1,421 |  |  | $ | 1,413 |  |

- changed (2016-08-23):
[0001045810-16-000300:note_history:10]
(1) As of July 31, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.3 years.
  (was, 2016-05-25, similarity 0.9772):
[0001045810-16-000275:note_history:10]
(1) As of May 1, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.6 years.

- added (2016-08-23):
[0001045810-16-000300:note_history:11]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- removed (2016-08-23):
[0001045810-16-000275:note_history:12]
|  |  | Three Months Ended |
|  |  | May 1, |  | April 26, |
|  |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 8 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 12 |  |  | $ | 11 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-23):
[0001045810-16-000300:note_history:13]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of July 31, 2016, the conversion rate has been adjusted to 49.7818 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.0877 per share of common stock) for dividend increases made to that date.
  (was, 2016-05-25, similarity 0.9971):
[0001045810-16-000275:note_history:13]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of May 1, 2016, the conversion rate has been adjusted to 49.7481 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.1013 per share of common stock) for dividend increases made to that date.

- changed (2016-08-23):
[0001045810-16-000300:note_history:14]
The following table presents the carrying value of the Notes:
  (was, 2016-05-25, similarity 0.76):
[0001045810-16-000275:note_history:14]
The following table presents the carrying amounts of the liability and equity components:

- changed (2016-08-23):
[0001045810-16-000300:note_history:15]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (72 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,428 |  |  | $ | 1,413 |  |
  (was, 2016-05-25, similarity 0.651):
[0001045810-16-000275:note_history:15]
|  |  | May 1, |  | January 31, |
|  |  | 2016 |  | 2016 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 39 |  |  | $ | 39 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (79 | ) |  | (87 | ) |
| Net carrying amount |  | $ | 1,421 |  |  | $ | 1,413 |  |

- changed (2016-08-23):
[0001045810-16-000300:note_history:16]
(1) As of July 31, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.3 years.
  (was, 2016-05-25, similarity 0.9772):
[0001045810-16-000275:note_history:16]
(1) As of May 1, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.6 years.

- added (2016-08-23):
[0001045810-16-000300:note_history:17]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- changed (2016-08-23):
[0001045810-16-000300:note_history:18]
The Notes first became convertible as of February 1, 2016. As of July 31, 2016, the Notes continued to be convertible at the holders’ option through October 30, 2016 as the price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended July 31, 2016. As such, the $1.43 billion carrying value of the Notes continued to be classified as a current liability and the $72 million difference between the principal amount and the carrying value of the Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.
  (was, 2016-05-25, similarity 0.6984):
[0001045810-16-000275:note_history:18]
As of May 1, 2016, the Notes continued to be convertible at the holders’ option for the period beginning on May 2, 2016 and ending on July 31, 2016. As such, the $1.42 billion carrying value of the Notes as of May 1, 2016 continued to be classified as a current liability and the $79 million difference between the principal amount and the carrying value of the Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

- changed (2016-08-23):
[0001045810-16-000300:note_history:19]
Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the closing price of our common stock on July 29, 2016 (the last trading day of the second quarter of fiscal year 2017) of $57.10, the if-converted value of our Notes exceeded their principal amount by approximately $2.76 billion.
  (was, 2016-05-25, similarity 0.8112):
[0001045810-16-000275:note_history:19]
Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the closing price of our common stock on April 29, 2016 (the last trading day of the first quarter of fiscal year 2017) of $35.53, the if-converted value of our Notes exceeded their principal amount by approximately $1.15 billion. As of May 1, 2016, we had received conversion notices for a total of $0.2 million aggregate principal amount of the Notes, for which conversion is expected to be completed in the second quarter of fiscal year 2017. As of May 1, 2016, no conversions had taken place.

- added (2016-08-23):
[0001045810-16-000300:note_history:20]
During the three months ended July 31, 2016, an aggregate of $0.2 million in principal amount of the Notes was converted at the holders’ option, and we paid cash of $0.2 million and issued 5,446 shares of our common stock with respect to the conversion obligation in excess of the principal amount. We recognized an insignificant loss on extinguishment related to the conversions of the Notes for the three months ended July 31, 2016. As of July 31, 2016, the remaining aggregate principal amount of the Notes outstanding was $1,499.8 million. As of July 31, 2016, we had received conversion notices for an aggregate of $229 million in principal amount of the Notes plus an additional notice subsequent to July 31, 2016 for $200 million in principal amount of the Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2017.

- changed (2016-08-23):
[0001045810-16-000300:note_history:21]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through July 31, 2016, the strike price of the Note Hedges has been adjusted to $20.0877 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion. Through July 31, 2016, we had received 5,446 shares of our common stock from the exercise of a portion of the Note Hedges related to the conversion of an aggregate of $0.2 million in principal amount of the Notes.
  (was, 2016-05-25, similarity 0.8361):
[0001045810-16-000275:note_history:21]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through May 1, 2016, the strike price of the Note Hedges has been adjusted to $20.1013 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion.

- changed (2016-08-23):
[0001045810-16-000300:note_history:22]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of July 31, 2016, the strike price was adjusted to $27.0411 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 75 million shares of our common stock. As of July 31, 2016, the warrants had not been exercised and remained outstanding. The value of the warrants was initially recorded in equity and continues to be classified as equity.
  (was, 2016-05-25, similarity 0.8822):
[0001045810-16-000275:note_history:22]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of May 1, 2016, the strike price was adjusted to $27.0594 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 74 million shares of our common stock.

- removed (2016-08-23):
[0001045810-16-000275:note_history:23]
|  |  | Three Months Ended |
|  |  | May 1, |  | April 26, |
|  |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 8 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 12 |  |  | $ | 11 |  |

- removed (2016-08-23):
[0001045810-16-000275:note_history:24]
The price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended January 31, 2016. Therefore, as of January 31, 2016, the conversion threshold had been met and the Notes became convertible at the holders’ option beginning on February 1, 2016 and ending on May 1, 2016. As such, the $1.41 billion carrying value of the Notes as of January 31, 2016 was classified as a current liability and the $87 million difference between the principal amount and the carrying value of the Notes was reclassified from shareholders' equity to convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet as of January 31, 2016.
