# NVDA notes — 0001045810-16-000300


## nvda:BalanceSheetComponentsTextBlock

[0001045810-16-000300:notes:1]
[same as prior period, unchanged from 0001045810-16-000275:notes:1]

[0001045810-16-000300:notes:2]
[same as prior period, unchanged from 0001045810-16-000275:notes:2]

[0001045810-16-000300:notes:3]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
| Inventories: | (In millions) |
| Raw materials | $ | 133 |  |  | $ | 105 |  |
| Work in-process | 143 |  |  | 103 |  |
| Finished goods | 245 |  |  | 210 |  |
| Total inventories | $ | 521 |  |  | $ | 418 |  |

[0001045810-16-000300:notes:4]
As of July 31, 2016, we had outstanding inventory purchase obligations totaling $826 million.

[0001045810-16-000300:notes:5]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
| Accrued and Other Current Liabilities: | (In millions) |
| Deferred revenue | $ | 251 |  |  | $ | 322 |  |
| Customer related liabilities (1) | 144 |  |  | 160 |  |
| Accrued payroll and related expenses | 90 |  |  | 79 |  |
| Accrued restructuring and other charges (2) | 15 |  |  | 23 |  |
| Professional service fees | 14 |  |  | 23 |  |
| Warranty accrual (3) | 8 |  |  | 11 |  |
| Income taxes payable | 6 |  |  | 2 |  |
| Contributions payable | 4 |  |  | 3 |  |
| Coupon interest on Notes | 3 |  |  | 3 |  |
| Other | 21 |  |  | 16 |  |
| Total accrued and other current liabilities | $ | 556 |  |  | $ | 642 |  |

[0001045810-16-000300:notes:6]
[same as prior period, unchanged from 0001045810-16-000275:notes:6]

[0001045810-16-000300:notes:7]
[same as prior period, unchanged from 0001045810-16-000275:notes:7]

[0001045810-16-000300:notes:8]
[same as prior period, unchanged from 0001045810-16-000275:notes:8]

[0001045810-16-000300:notes:9]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 372 |  |  | $ | 301 |  |
| Income taxes payable | 80 |  |  | 78 |  |
| Contributions payable | 14 |  |  | 13 |  |
| Interest rate swap (1) | 12 |  |  | 7 |  |
| Deferred revenue (2) | 1 |  |  | 44 |  |
| Other | 15 |  |  | 10 |  |
| Total other long-term liabilities | $ | 494 |  |  | $ | 453 |  |

[0001045810-16-000300:notes:10]
[same as prior period, unchanged from 0001045810-16-000275:notes:10]

[0001045810-16-000300:notes:11]
[same as prior period, unchanged from 0001045810-16-000275:notes:11]


## nvda:ScheduleofAccountReceivablefromMajorCustomersTableTextBlock

[0001045810-16-000300:notes:12]
|  |  | July 31, |  | January 31, |
|  |  | 2016 |  | 2016 |
| Accounts Receivable: |  |  |  |  |
| Customer B |  | 18 | % |  | 21 | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-16-000300:notes:13]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 781 |  |  | $ | 660 |  |  | $ | 1,468 |  |  | $ | 1,247 |  |
| Professional Visualization | 214 |  |  | 176 |  |  | 403 |  |  | 357 |  |
| Datacenter | 151 |  |  | 72 |  |  | 294 |  |  | 160 |  |
| Automotive | 119 |  |  | 71 |  |  | 232 |  |  | 148 |  |
| OEM & IP | 163 |  |  | 174 |  |  | 336 |  |  | 392 |  |
| Total revenue | $ | 1,428 |  |  | $ | 1,153 |  |  | $ | 2,733 |  |  | $ | 2,304 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-16-000300:notes:14]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 392 |  |  | $ | 381 |  |
| Estimated weighted average amortization period | (In years) |
| Stock options | 0.8 |  |  | 1.1 |  |
| RSUs, PSUs and market-based PSUs | 2.6 |  |  | 2.7 |  |
| ESPP | 0.6 |  |  | 0.7 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-16-000300:notes:15]
|  | July 31, 2016 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,972 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 1,976 |  |
| Debt securities of United States government agencies | 1,046 |  |  | 2 |  |  | — |  |  | 1,048 |  |
| Debt securities issued by United States Treasury | 809 |  |  | 3 |  |  | — |  |  | 812 |  |
| Asset-backed securities | 369 |  |  | 1 |  |  | — |  |  | 370 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 175 |  |  | 3 |  |  | (1 | ) |  | 177 |  |
| Foreign government bonds | 80 |  |  | — |  |  | — |  |  | 80 |  |
| Money market funds | 47 |  |  | — |  |  | — |  |  | 47 |  |
| Total | $ | 4,498 |  |  | $ | 14 |  |  | $ | (2 | ) |  | $ | 4,510 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 57 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 4,453 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,510 |  |

[0001045810-16-000300:notes:16]
[same as prior period, unchanged from 0001045810-16-000275:notes:16]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-16-000300:notes:17]
[same as prior period, unchanged from 0001045810-16-000275:notes:17]

[0001045810-16-000300:notes:18]
[same as prior period, unchanged from 0001045810-16-000275:notes:18]

[0001045810-16-000300:notes:19]
[same as prior period, unchanged from 0001045810-16-000275:notes:19]

[0001045810-16-000300:notes:20]
[same as prior period, unchanged from 0001045810-16-000275:notes:20]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-16-000300:notes:21]
Commitments and Contingencies

[0001045810-16-000300:notes:22]
Operating Lease Financing Arrangement

[0001045810-16-000300:notes:23]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-16-000300:notes:24]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-16-000300:notes:25]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-16-000300:notes:26]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-16-000300:notes:27]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-16-000300:notes:28]
Patent Infringement Cases

[0001045810-16-000300:notes:29]
In September 2014, NVIDIA filed complaints against Qualcomm, Inc. and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing. In November 2014, Samsung filed complaints against NVIDIA in the ITC and the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed certain patents.

[0001045810-16-000300:notes:30]
NVIDIA and Samsung, and NVIDIA and Qualcomm, also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office.

[0001045810-16-000300:notes:31]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941. On June 16, 2016, the ITC granted the joint motion and terminated the ITC investigation. The parties have also moved to dismiss all pending inter partes reviews. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party. On June 28, 2016, NVIDIA and Samsung executed a settlement agreement based on the April 28, 2016 memorandum of understanding.

[0001045810-16-000300:notes:32]
NVIDIA’s dismissals on May 11, 2016 and May 12, 2016 also terminated its claims against Qualcomm.

[0001045810-16-000300:notes:33]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. On June 1, 2016, the ITC issued a Notice determining not to review the Administrative Law Judge’s determination, thereby finalizing termination of the investigation as to NVIDIA. Pursuant to the license agreement, $10 million was recorded as a charge to cost of revenue during the three months ended May 1, 2016.

[0001045810-16-000300:notes:34]
Accounting for Loss Contingencies

[0001045810-16-000300:notes:35]
We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-16-000300:notes:36]
[same as prior period, unchanged from 0001045810-16-000275:notes:36]

[0001045810-16-000300:notes:37]
[same as prior period, unchanged from 0001045810-16-000275:notes:37]


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-16-000300:notes:38]
The following table presents the carrying value of the Notes:

[0001045810-16-000300:notes:39]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (72 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,428 |  |  | $ | 1,413 |  |

[0001045810-16-000300:notes:40]
(1) As of July 31, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.3 years.

[0001045810-16-000300:notes:41]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-16-000300:notes:42]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-16-000300:notes:43]
Convertible Debt

[0001045810-16-000300:notes:44]
1.00 % Convertible Senior Notes Due 2018

[0001045810-16-000300:notes:45]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of July 31, 2016, the conversion rate has been adjusted to 49.7818 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.0877 per share of common stock) for dividend increases made to that date.

[0001045810-16-000300:notes:46]
We separately accounted for the liability and equity components of the Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-16-000300:notes:47]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-16-000300:notes:48]
Holders may convert all or any portion of their Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Notes regardless of the foregoing conditions.

[0001045810-16-000300:notes:49]
The Notes first became convertible as of February 1, 2016. As of July 31, 2016, the Notes continued to be convertible at the holders’ option through October 30, 2016 as the price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended July 31, 2016. As such, the $1.43 billion carrying value of the Notes continued to be classified as a current liability and the $72 million difference between the principal amount and the carrying value of the Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

[0001045810-16-000300:notes:50]
Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the closing price of our common stock on July 29, 2016 (the last trading day of the second quarter of fiscal year 2017) of $57.10, the if-converted value of our Notes exceeded their principal amount by approximately $2.76 billion.

[0001045810-16-000300:notes:51]
During the three months ended July 31, 2016, an aggregate of $0.2 million in principal amount of the Notes was converted at the holders’ option, and we paid cash of $0.2 million and issued 5,446 shares of our common stock with respect to the conversion obligation in excess of the principal amount. We recognized an insignificant loss on extinguishment related to the conversions of the Notes for the three months ended July 31, 2016. As of July 31, 2016, the remaining aggregate principal amount of the Notes outstanding was $1,499.8 million. As of July 31, 2016, we had received conversion notices for an aggregate of $229 million in principal amount of the Notes plus an additional notice subsequent to July 31, 2016 for $200 million in principal amount of the Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2017.

[0001045810-16-000300:notes:52]
Note Hedges and Warrants

[0001045810-16-000300:notes:53]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through July 31, 2016, the strike price of the Note Hedges has been adjusted to $20.0877 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion. Through July 31, 2016, we had received 5,446 shares of our common stock from the exercise of a portion of the Note Hedges related to the conversion of an aggregate of $0.2 million in principal amount of the Notes.

[0001045810-16-000300:notes:54]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of July 31, 2016, the strike price was adjusted to $27.0411 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 75 million shares of our common stock. As of July 31, 2016, the warrants had not been exercised and remained outstanding. The value of the warrants was initially recorded in equity and continues to be classified as equity.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-16-000300:notes:55]
[same as prior period, unchanged from 0001045810-16-000275:notes:55]

[0001045810-16-000300:notes:56]
In August 2015 we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building that entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments. This interest rate swap is designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are recorded in accumulated other comprehensive income (loss) and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur.

[0001045810-16-000300:notes:57]
During the three and six months ended July 31, 2016, we entered into foreign currency forward contracts with a total U.S. dollar equivalent notional value of $61 million and $96 million, respectively, to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income (loss) and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts as of July 31, 2016 was not significant.

[0001045810-16-000300:notes:58]
During the three months ended July 31, 2016, we also entered into a foreign currency forward contract to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than our reporting currency. This foreign currency forward contract had a total U.S. dollar equivalent notional value of $13 million and was not designated for hedge accounting treatment. Therefore, the change in fair value of this contract is recorded as a component of other income (expense), net, and offsets the change in fair value of the foreign currency denominated monetary assets and liabilities, which is also recorded in other income (expense), net.

[0001045810-16-000300:notes:59]
[same as prior period, unchanged from 0001045810-16-000275:notes:58]

[0001045810-16-000300:notes:60]
As of July 31, 2016, the maturities of the designated foreign currency forward contracts were three months or less.

[0001045810-16-000300:notes:61]
We formally assess, both at inception and on an ongoing basis, whether derivative financial instruments designated for hedge accounting treatment are highly effective. For the three and six months ended July 31, 2016, all derivative financial instruments designated for hedge accounting treatment were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-16-000300:notes:62]
During the three and six months ended July 31, 2016, we recognized unrealized losses on derivative financial instruments designated for hedge accounting treatment of $3 million and $4 million, respectively, net of tax, in other comprehensive income.

[0001045810-16-000300:notes:63]
We expect to realize all of the amounts deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months. However, we do not expect to reclassify any amount from accumulated other comprehensive income (loss) into earnings related to the interest rate swap as the underlying operating lease financing payments for our new headquarters building will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-16-000300:notes:64]
[same as prior period, unchanged from 0001045810-16-000275:notes:63]

[0001045810-16-000300:notes:65]
[same as prior period, unchanged from 0001045810-16-000275:notes:64]

[0001045810-16-000300:notes:66]
[same as prior period, unchanged from 0001045810-16-000275:notes:65]

[0001045810-16-000300:notes:67]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |  | July 31, 2016 |  | July 26, 2015 |
|  | (In millions) |
| Cost of revenue | $ | 4 |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 6 |  |
| Research and development | 30 |  |  | 27 |  |  | 59 |  |  | 54 |  |
| Sales, general and administrative | 24 |  |  | 17 |  |  | 44 |  |  | 33 |  |
| Total | $ | 58 |  |  | $ | 47 |  |  | $ | 111 |  |  | $ | 93 |  |

[0001045810-16-000300:notes:68]
[same as prior period, unchanged from 0001045810-16-000275:notes:67]

[0001045810-16-000300:notes:69]
[same as prior period, unchanged from 0001045810-16-000275:notes:68]

[0001045810-16-000300:notes:70]
|  | RSUs, PSUs and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted Average Exercise Price Per Share |
|  | (In millions, except per share data) |
| Balances, January 31, 2016 | 26 |  |  | $ | 19.12 |  |  | 13 |  |  | $ | 14.49 |  |
| Granted (1) (2) | 4 |  |  | $ | 33.80 |  |  | — |  |  | $ | — |  |
| Exercised | — |  |  | $ | — |  |  | (3 | ) |  | $ | 14.26 |  |
| Vested restricted stock | (4 | ) |  | $ | 16.68 |  |  | — |  |  | $ | — |  |
| Canceled and forfeited | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balances, July 31, 2016 | 26 |  |  | $ | 21.89 |  |  | 10 |  |  | $ | 14.57 |  |

[0001045810-16-000300:notes:71]
| (1) | Includes PSUs that will be issued and eligible to vest if the corporate financial performance maximum target level for fiscal year 2017 is achieved. Depending on the actual level of achievement of the corporate performance target at the end of fiscal year 2017, the PSUs issued could range from 0 to 2 million shares. |

[0001045810-16-000300:notes:72]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs issued could range from 0 to 0.3 million shares. |

[0001045810-16-000300:notes:73]
Of the total fair value of equity awards granted during the three and six months ended July 31, 2016, the stock-based compensation expense related to equity awards that are not expected to vest was $5 million and $17 million, respectively. Of the total fair value of equity awards granted during the three and six months ended July 26, 2015, the stock-based compensation expense related to equity awards that are not expected to vest was $2 million and $8 million, respectively.

[0001045810-16-000300:notes:74]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of July 31, 2016 and January 31, 2016:


## us-gaap:EarningsPerShareTextBlock

[0001045810-16-000300:notes:75]
[same as prior period, unchanged from 0001045810-16-000275:notes:74]

[0001045810-16-000300:notes:76]
[same as prior period, unchanged from 0001045810-16-000275:notes:75]

[0001045810-16-000300:notes:77]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 253 |  |  | $ | 26 |  |  | $ | 449 |  |  | $ | 160 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 534 |  |  | 541 |  |  | 536 |  |  | 545 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards outstanding | 23 |  |  | 11 |  |  | 20 |  |  | 13 |  |
| 1% Convertible Senior Notes | 43 |  |  | 4 |  |  | 37 |  |  | 5 |  |
| Warrants issued with the Notes | 31 |  |  | — |  |  | 24 |  |  | — |  |
| Diluted weighted average shares | 631 |  |  | 556 |  |  | 617 |  |  | 563 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.47 |  |  | $ | 0.05 |  |  | $ | 0.84 |  |  | $ | 0.29 |  |
| Diluted (2) | $ | 0.40 |  |  | $ | 0.05 |  |  | $ | 0.73 |  |  | $ | 0.28 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | — |  |  | 1 |  |  | 4 |  |  | 4 |  |

[0001045810-16-000300:notes:78]
[same as prior period, unchanged from 0001045810-16-000275:notes:77]

[0001045810-16-000300:notes:79]
[same as prior period, unchanged from 0001045810-16-000275:notes:78]

[0001045810-16-000300:notes:80]
The 1.00% Convertible Senior Notes, or the Notes, are included in the calculation of diluted net income per share. The Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0877 per share. The Warrants outstanding are included in the calculation of diluted net income per share. The Warrants have a dilutive impact on net income per share if our average stock price for the quarter exceeds the adjusted strike price of $27.0411 per share. For the three and six months ended July 31, 2016, our average stock price was $46.57 and $39.69, respectively, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Notes and the Warrants to have a dilutive impact for these periods.

[0001045810-16-000300:notes:81]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transactions, or the Note Hedges, that we entered into concurrently with the issuance of the Notes, as its effect would be anti-dilutive. In the event of conversion of the Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Notes. Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Notes.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-16-000300:notes:82]
|  |  | Fair Value at |
|  | Pricing Category |  | July 31, 2016 |  | January 31, 2016 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Corporate debt securities (1) | Level 2 |  | $ | 1,976 |  |  | $ | 1,901 |  |
| Debt securities of United States government agencies (2) | Level 2 |  | $ | 1,048 |  |  | $ | 1,170 |  |
| Debt securities issued by United States Treasury (3) | Level 2 |  | $ | 812 |  |  | $ | 801 |  |
| Asset-backed securities (3) | Level 2 |  | $ | 370 |  |  | $ | 435 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises (3) | Level 2 |  | $ | 177 |  |  | $ | 231 |  |
| Foreign government bonds (3) | Level 2 |  | $ | 80 |  |  | $ | 92 |  |
| Money market funds (4) | Level 1 |  | $ | 47 |  |  | $ | 43 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (5) | Level 2 |  | $ | 4,239 |  |  | $ | 2,273 |  |
| Other noncurrent liability: |  |  |  |  |  |
| Interest rate swap (6) | Level 2 |  | $ | 12 |  |  | $ | 7 |  |

[0001045810-16-000300:notes:83]
| (1) | Included $5 million and $51 million in cash equivalents as of July 31, 2016 and January 31, 2016, respectively, and $1.97 billion and $1.85 billion in marketable securities as of July 31, 2016 and January 31, 2016, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000300:notes:84]
| (2) | Included $5 million and $90 million in cash equivalents as of July 31, 2016 and January 31, 2016, respectively, and $1.04 billion and $1.08 billion in marketable securities as of July 31, 2016 and January 31, 2016, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000300:notes:85]
| (3) | Reported in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000300:notes:86]
| (4) | Reported in cash equivalents on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000300:notes:87]
| (5) | The Notes are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount, and are not marked to fair value each period. See Note 11 of these Notes to Condensed Consolidated Financial Statements for additional information on the Notes. |

[0001045810-16-000300:notes:88]
| (6) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-16-000300:notes:89]
[same as prior period, unchanged from 0001045810-16-000275:notes:88]

[0001045810-16-000300:notes:90]
We measure our cash equivalents, marketable securities, and interest rate swap at fair value using quoted market prices of identical assets or similar assets from active markets. We review the fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 assets or liabilities for the three months ended July 31, 2016, and we did not have any investments or liabilities classified as Level 3 as of July 31, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-16-000300:notes:91]
[same as prior period, unchanged from 0001045810-16-000275:notes:90]

[0001045810-16-000300:notes:92]
We recognized income tax expense of $64 million and $109 million for the three and six months ended July 31, 2016, respectively, and $46 million and $84 million for the three and six months ended July 26, 2015, respectively. Our effective tax rate was 20.3% and 19.6% for the three and six months ended July 31, 2016, respectively, and 64.0% and 34.3% for the three and six months ended July 26, 2015, respectively.

[0001045810-16-000300:notes:93]
The decrease in our effective tax rate in the three and six months ended July 31, 2016 compared to the same periods in the prior fiscal year was primarily due to the absence of tax-related restructuring charges recorded in the three months ended July 26, 2015, the favorable benefit of the U.S. federal research tax credit, which was permanently re-enacted in December 2015, and lower permanent tax differences related to stock-based compensation, partly offset by an increase in the amount of earnings subject to U.S. tax.

[0001045810-16-000300:notes:94]
Our effective tax rate for the six months ended July 31, 2016 of 19.6% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit and discrete events that occurred during the six months ended July 31, 2016 primarily attributable to tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-16-000300:notes:95]
During the three months ended July 31, 2016, we reduced certain unrecognized tax benefits related to various U.S. state income tax positions by $48 million as the state of California settled its review of our fiscal years 2011 and 2012. As a result, we recognized a $13 million state tax benefit, net of the agreed settlement, in the form of a deferred tax asset that is subject to a full valuation allowance. For the six months ended July 31, 2016, there have been no other significant changes to our tax years that remain subject to review by major tax jurisdictions. Further, there have been no other significant changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 31, 2016, other than the closure of our aforementioned state income tax position and the recognition of tax benefits upon the expiration of statutes of limitations in certain non-U.S. jurisdictions in the six months ended July 31, 2016.

[0001045810-16-000300:notes:96]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 31, 2016, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-16-000300:notes:97]
[same as prior period, unchanged from 0001045810-16-000275:notes:96]

[0001045810-16-000300:notes:98]
[same as prior period, unchanged from 0001045810-16-000275:notes:97]

[0001045810-16-000300:notes:99]
|  | July 31, 2016 |  | January 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (160 | ) |  | $ | 33 |  |  | $ | 193 |  |  | $ | (152 | ) |  | $ | 41 |  |
| Patents and licensed technology | 469 |  |  | (364 | ) |  | 105 |  |  | 462 |  |  | (337 | ) |  | 125 |  |
| Total intangible assets | $ | 662 |  |  | $ | (524 | ) |  | $ | 138 |  |  | $ | 655 |  |  | $ | (489 | ) |  | $ | 166 |  |

[0001045810-16-000300:notes:100]
Amortization expense associated with intangible assets was $18 million and $35 million for the three and six months ended July 31, 2016, respectively, and $19 million and $38 million for the three and six months ended July 26, 2015, respectively. Future amortization expense related to the net carrying amount of intangible assets as of July 31, 2016 is estimated to be $34 million for the remainder of fiscal year 2017, $54 million in fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $7 million in fiscal year 2021 and a total of $1 million in fiscal year 2022 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-16-000300:notes:101]
|  | July 31, 2016 |  | January 31, 2016 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 1,846 |  |  | $ | 1,847 |  |  | $ | 1,619 |  |  | $ | 1,619 |  |
| Due in 1 - 5 years | 2,591 |  |  | 2,601 |  |  | 3,019 |  |  | 3,020 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 61 |  |  | 62 |  |  | 34 |  |  | 34 |  |
| Total | $ | 4,498 |  |  | $ | 4,510 |  |  | $ | 4,672 |  |  | $ | 4,673 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-16-000300:notes:102]
[same as prior period, unchanged from 0001045810-16-000275:notes:101]

[0001045810-16-000300:notes:103]
[same as prior period, unchanged from 0001045810-16-000275:notes:102]

[0001045810-16-000300:notes:104]
We performed an impairment review of our investment portfolio as of July 31, 2016. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of July 31, 2016.

[0001045810-16-000300:notes:105]
The following is a summary of cash equivalents and marketable securities as of July 31, 2016 and January 31, 2016:

[0001045810-16-000300:notes:106]
The following table provides the breakdown of the investments with unrealized losses as of July 31, 2016:

[0001045810-16-000300:notes:107]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 263 |  |  | $ | 1 |  |  | $ | 98 |  |  | $ | — |  |  | $ | 361 |  |  | $ | 1 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 54 |  |  | 1 |  |  | 31 |  |  | — |  |  | 85 |  |  | 1 |  |
|  | $ | 317 |  |  | $ | 2 |  |  | $ | 129 |  |  | $ | — |  |  | $ | 446 |  |  | $ | 2 |  |

[0001045810-16-000300:notes:108]
The gross unrealized losses as of July 31, 2016 related to fixed income securities due to changes in interest rates and are temporary in nature. We have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-16-000300:notes:109]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of July 31, 2016 and January 31, 2016 and are shown below by contractual maturity:

[0001045810-16-000300:notes:110]
Net realized losses were not significant for the three and six months ended July 31, 2016 and for the three months ended July 26, 2015. Net realized gains were $3 million for the six months ended July 26, 2015.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-16-000300:notes:111]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-16-000300:notes:112]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting, including income taxes at settlement, classifications in the statement of cash flows, forfeitures and net settlements, and will be effective in our first quarter of fiscal year 2018. Early adoption is permitted in any annual or interim period. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements and whether or not to adopt it early. We expect that the adoption of this accounting guidance will result in increased volatility of our effective tax rate, and changes in certain tax-related balance sheet line items and statement of cash flows classifications.

[0001045810-16-000300:notes:113]
In February 2016, FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.

[0001045810-16-000300:notes:114]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). In March, April and May 2016, the FASB issued additional updates to the new revenue standard relating to reporting revenue on a gross versus net basis, identifying performance obligations and licensing arrangements, and narrow-scope improvements and practical expedients, respectively. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-16-000300:notes:115]
[same as prior period, unchanged from 0001045810-16-000275:notes:114]

[0001045810-16-000300:notes:116]
[same as prior period, unchanged from 0001045810-16-000275:notes:115]

[0001045810-16-000300:notes:117]
[same as prior period, unchanged from 0001045810-16-000275:notes:116]

[0001045810-16-000300:notes:118]
[same as prior period, unchanged from 0001045810-16-000275:notes:117]

[0001045810-16-000300:notes:119]
On July 31, 2015, we announced a voluntary recall and replacement of our SHIELD 8-inch tablets that were sold between July 2014 and July 2015. We have determined that the battery in these tablets can overheat, posing a fire hazard. The recall does not affect any other NVIDIA products. During the twelve months ended January 31, 2016, we recorded a $26 million charge against cost of revenue to cover anticipated customer warranty, repair, return, replacement and other associated costs.

[0001045810-16-000300:notes:120]
The estimated product returns and estimated product warranty liabilities as of, and for the six months and twelve months ended July 31, 2016 and January 31, 2016, respectively, were as follows:

[0001045810-16-000300:notes:121]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| Balance at beginning of period | $ | 11 |  |  | $ | 8 |  |
| Additions | 1 |  |  | 27 |  |
| Deductions | (4 | ) |  | (24 | ) |
| Balance at end of period | $ | 8 |  |  | $ | 11 |  |

[0001045810-16-000300:notes:122]
[same as prior period, unchanged from 0001045810-16-000275:notes:120]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-16-000300:notes:123]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | July 26, 2015 |  | July 31, 2016 |  | July 26, 2015 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Unallocated revenue | $ | 66 |  |  | $ | 66 |  |  | $ | 132 |  |  | $ | 132 |  |
| Stock-based compensation expense | (58 | ) |  | (47 | ) |  | (111 | ) |  | (93 | ) |
| Unallocated cost of revenue and operating expenses | (49 | ) |  | (67 | ) |  | (104 | ) |  | (124 | ) |
| Acquisition-related costs | (4 | ) |  | (4 | ) |  | (8 | ) |  | (13 | ) |
| Restructuring and other charges | (2 | ) |  | (89 | ) |  | (3 | ) |  | (89 | ) |
| Contributions | (1 | ) |  | — |  |  | (4 | ) |  | — |  |
| Product warranty charge | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Legal settlement costs | — |  |  | — |  |  | (16 | ) |  | — |  |
| Total | $ | (48 | ) |  | $ | (156 | ) |  | $ | (114 | ) |  | $ | (202 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-16-000300:notes:124]
[same as prior period, unchanged from 0001045810-16-000275:notes:122]

[0001045810-16-000300:notes:125]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera operations. Our operating expenses for the three and six months ended July 31, 2016 included $2 million and $3 million, respectively, of restructuring and other charges.

[0001045810-16-000300:notes:126]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Condensed Consolidated Balance Sheets as of July 31, 2016 (in millions):

[0001045810-16-000300:notes:127]
| Balance as of January 31, 2016 | $ | 23 |  |
| Restructuring and other charges | 3 |  |
| Cash payments | (12 | ) |
| Non-cash adjustments | 1 |  |
| Balance as of July 31, 2016 | $ | 15 |  |

[0001045810-16-000300:notes:128]
The majority of the remaining balance of $15 million as of July 31, 2016 is expected to be paid during fiscal year 2017.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-16-000300:notes:129]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 505 |  |  | $ | 445 |  |  | $ | 949 |  |  | $ | 832 |  |
| China | 256 |  |  | 181 |  |  | 504 |  |  | 354 |  |
| United States | 206 |  |  | 138 |  |  | 400 |  |  | 318 |  |
| Other Asia Pacific | 191 |  |  | 185 |  |  | 351 |  |  | 373 |  |
| Europe | 167 |  |  | 106 |  |  | 323 |  |  | 225 |  |
| Other Americas | 103 |  |  | 98 |  |  | 206 |  |  | 202 |  |
| Total revenue | $ | 1,428 |  |  | $ | 1,153 |  |  | $ | 2,733 |  |  | $ | 2,304 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001045810-16-000300:notes:130]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Customer A | 10 | % |  | 13 | % |  | 11 | % |  | 11 | % |
| Customer B | 8 | % |  | 10 | % |  | 8 | % |  | 10 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-16-000300:notes:131]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 31, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 1,196 |  |  | $ | 166 |  |  | $ | 66 |  |  | $ | 1,428 |  |
| Depreciation and amortization expense | $ | 29 |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 47 |  |
| Operating income (loss) | $ | 379 |  |  | $ | (14 | ) |  | $ | (48 | ) |  | $ | 317 |  |
| Three Months Ended July 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 959 |  |  | $ | 128 |  |  | $ | 66 |  |  | $ | 1,153 |  |
| Depreciation and amortization expense | $ | 27 |  |  | $ | 11 |  |  | $ | 11 |  |  | $ | 49 |  |
| Operating income (loss) | $ | 273 |  |  | $ | (41 | ) |  | $ | (156 | ) |  | $ | 76 |  |
| Six Months Ended July 31, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 2,275 |  |  | $ | 326 |  |  | $ | 132 |  |  | $ | 2,733 |  |
| Depreciation and amortization expense | $ | 57 |  |  | $ | 14 |  |  | $ | 21 |  |  | $ | 92 |  |
| Operating income (loss) | $ | 727 |  |  | $ | (52 | ) |  | $ | (114 | ) |  | $ | 561 |  |
| Six Months Ended July 26, 2015 |  |  |  |  |  |  |  |
| Revenue | $ | 1,899 |  |  | $ | 273 |  |  | $ | 132 |  |  | $ | 2,304 |  |
| Depreciation and amortization expense | $ | 55 |  |  | $ | 26 |  |  | $ | 22 |  |  | $ | 103 |  |
| Operating income (loss) | $ | 551 |  |  | $ | (99 | ) |  | $ | (202 | ) |  | $ | 250 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-16-000300:notes:132]
[same as prior period, unchanged from 0001045810-16-000275:notes:130]

[0001045810-16-000300:notes:133]
[same as prior period, unchanged from 0001045810-16-000275:notes:131]

[0001045810-16-000300:notes:134]
[same as prior period, unchanged from 0001045810-16-000275:notes:132]

[0001045810-16-000300:notes:135]
[same as prior period, unchanged from 0001045810-16-000275:notes:133]

[0001045810-16-000300:notes:136]
[same as prior period, unchanged from 0001045810-16-000275:notes:134]

[0001045810-16-000300:notes:137]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, restructuring and other charges, contributions, product warranty charge, legal settlement costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-16-000300:notes:138]
[same as prior period, unchanged from 0001045810-16-000275:notes:136]

[0001045810-16-000300:notes:139]
[same as prior period, unchanged from 0001045810-16-000275:notes:137]

[0001045810-16-000300:notes:140]
[same as prior period, unchanged from 0001045810-16-000275:notes:138]

[0001045810-16-000300:notes:141]
[same as prior period, unchanged from 0001045810-16-000275:notes:139]

[0001045810-16-000300:notes:142]
Revenue from both customers was attributable to the GPU business.

[0001045810-16-000300:notes:143]
[same as prior period, unchanged from 0001045810-16-000275:notes:141]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-16-000300:notes:144]
[same as prior period, unchanged from 0001045810-16-000275:notes:142]

[0001045810-16-000300:notes:145]
[same as prior period, unchanged from 0001045810-16-000275:notes:143]

[0001045810-16-000300:notes:146]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The second quarter of fiscal years 2017 and 2016 were both 13-week quarters.

[0001045810-16-000300:notes:147]
Reclassifications

[0001045810-16-000300:notes:148]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-16-000300:notes:149]
[same as prior period, unchanged from 0001045810-16-000275:notes:145]

[0001045810-16-000300:notes:150]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-16-000300:notes:151]
[same as prior period, unchanged from 0001045810-16-000275:notes:147]

[0001045810-16-000300:notes:152]
[same as prior period, unchanged from 0001045810-16-000275:notes:148]

[0001045810-16-000300:notes:153]
[same as prior period, unchanged from 0001045810-16-000275:notes:149]

[0001045810-16-000300:notes:154]
In March 2016, we entered into an accelerated share repurchase, or ASR, agreement with an investment bank, under which we made an upfront payment of $500 million to purchase shares of our common stock and received an initial delivery of 12 million shares. The shares delivered resulted in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share. The ASR agreement was settled in July 2016 with a cash payment of $9 million to the investment bank. As a result, a total of 12 million shares were repurchased under the ASR transaction for $509 million, or an average price of $42.06 per share.

[0001045810-16-000300:notes:155]
During the three and six months ended July 31, 2016, we also paid $62 million and $124 million, respectively, in cash dividends to our shareholders, equivalent to $0.1150 per share. As a result, we returned $71 million and $633 million to shareholders during the three and six months ended July 31, 2016, respectively, in the form of share repurchases and dividend payments.

[0001045810-16-000300:notes:156]
Through July 31, 2016, we have repurchased an aggregate of 243 million shares under our share repurchase program for a total cost of $4.36 billion. All shares delivered from these repurchases have been placed into treasury stock. As of July 31, 2016, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $0.96 billion.

[0001045810-16-000300:notes:157]
We intend to return approximately $1.00 billion to our shareholders in fiscal year 2017 through a combination of share repurchases and cash dividends. We also declared on August 11, 2016 that we would pay our next quarterly cash dividend of $0.1150 per share on September 16, 2016, to all shareholders of record on August 25, 2016.

[0001045810-16-000300:notes:158]
[same as prior period, unchanged from 0001045810-16-000275:notes:155]

[0001045810-16-000300:notes:159]
As of July 31, 2016 and January 31, 2016, there were no shares of preferred stock outstanding.

[0001045810-16-000300:notes:160]
[same as prior period, unchanged from 0001045810-16-000275:notes:157]

[0001045810-16-000300:notes:161]
[same as prior period, unchanged from 0001045810-16-000275:notes:158]
