# NVDA 8-K — 0001045810-16-000292 filed 2016-08-11

## item codes, every 8-K on or before 2016-08-23

- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2016-08-23

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-16-000292:8k_2_02:1]
EX-99.1
2
q2fy17pr.htm
Q2FY17 PRESS RELEASE

[0001045810-16-000292:8k_2_02:2]
Exhibit

[0001045810-16-000292:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-16-000292:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2017

[0001045810-16-000292:8k_2_02:5]
| • | Record revenue of $1.43 billion, up 24 percent from a year ago - growth across all platforms |

[0001045810-16-000292:8k_2_02:6]
| • | GAAP EPS of $0.40. Non-GAAP EPS of $0.53, up 56 percent from a year ago |

[0001045810-16-000292:8k_2_02:7]
| • | Strong launch of Pascal-based GPUs, growing demand for deep learning |

[0001045810-16-000292:8k_2_02:8]
SANTA CLARA, Calif. - Aug. 11, 2016 - NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 31, 2016, of $1.43 billion, up 24 percent from $1.15 billion a year earlier, and up 9 percent from $1.30 billion in the previous quarter.

[0001045810-16-000292:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.40, compared with $0.05 a year ago and up 21 percent from $0.33 in the previous quarter. Non-GAAP earnings per diluted share were $0.53, up 56 percent from $0.34 a year earlier and up 15 percent from $0.46 in the previous quarter.

[0001045810-16-000292:8k_2_02:10]
“Strong demand for our new Pascal-generation GPUs and surging interest in deep learning drove record results,” said Jen-Hsun Huang, co-founder and chief executive officer, NVIDIA. “Our strategy to focus on creating the future where graphics, computer vision and artificial intelligence converge is fueling growth across our specialized platforms - Gaming, Pro Visualization, Datacenter and Automotive."

[0001045810-16-000292:8k_2_02:11]
“We are more excited than ever about the impact of deep learning and AI, which will touch every industry and market. We have made significant investments over the past five years to evolve our entire GPU computing stack for deep learning. Now, we are well positioned to partner with researchers and developers all over the world to democratize this powerful technology and invent its future,” he said.

[0001045810-16-000292:8k_2_02:12]
Capital Return

[0001045810-16-000292:8k_2_02:13]
During the first half of fiscal 2017, NVIDIA paid $509 million in share repurchases and $124 million in cash dividends.

[0001045810-16-000292:8k_2_02:14]
NVIDIA will pay its next quarterly cash dividend of $0.115 per share on September 16, 2016, to all shareholders of record on August 25, 2016.

[0001045810-16-000292:8k_2_02:15]
Q2 FY2017 Summary

[0001045810-16-000292:8k_2_02:16]
| GAAP |
| ($ in millions except earnings per share) | Q2 FY17 | Q1 FY17 | Q2 FY16 | Q/Q | Y/Y |
| Revenue | $1,428 | $1,305 | $1,153 | Up 9% | Up 24% |
| Gross margin | 57.9% | 57.5% | 55.0% | Up 40 bps | Up 290 bps |
| Operating expenses | $509 | $506 | $558 | Up 1% | Down 9% |
| Operating income | $317 | $245 | $76 | Up 29% | Up 317% |
| Net income | $253 | $196 | $26 | Up 29% | Up 873% |
| Diluted earnings per share | $0.40 | $0.33 | $0.05 | Up 21% | Up 700% |

[0001045810-16-000292:8k_2_02:17]
| Non-GAAP |
| ($ in millions except earnings per share) | Q2 FY17 | Q1 FY17 | Q2 FY16 | Q/Q | Y/Y |
| Revenue | $1,428 | $1,305 | $1,153 | Up 9% | Up 24% |
| Gross margin | 58.1% | 58.6% | 56.6% | Down 50 bps | Up 150 bps |
| Operating expenses | $448 | $443 | $421 | Up 1% | Up 6% |
| Operating income | $382 | $322 | $231 | Up 19% | Up 65% |
| Net income | $313 | $263 | $190 | Up 19% | Up 65% |
| Diluted earnings per share | $0.53 | $0.46 | $0.34 | Up 15% | Up 56% |

[0001045810-16-000292:8k_2_02:18]
NVIDIA’s outlook for the third quarter of fiscal 2017 is as follows:

[0001045810-16-000292:8k_2_02:19]
| • | Revenue is expected to be $1.68 billion, plus or minus two percent. |

[0001045810-16-000292:8k_2_02:20]
| • | GAAP and non-GAAP gross margins are expected to be 57.8 percent and 58.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-16-000292:8k_2_02:21]
| • | GAAP operating expenses are expected to be approximately $530 million. Non-GAAP operating expenses are expected to be approximately $465 million. |

[0001045810-16-000292:8k_2_02:22]
| • | GAAP and non-GAAP tax rates for the third quarter of fiscal 2017 are both expected to be 21 percent, plus or minus one percent. |

[0001045810-16-000292:8k_2_02:23]
| • | Capital expenditures are expected to be approximately $35 million to $45 million. |

[0001045810-16-000292:8k_2_02:24]
Second Quarter Fiscal 2017 Highlights

[0001045810-16-000292:8k_2_02:25]
During the second quarter, NVIDIA achieved progress in each of its four major platforms:

[0001045810-16-000292:8k_2_02:26]
Gaming:

[0001045810-16-000292:8k_2_02:27]
| • | Introduced the first four members of its Pascal™ family of gaming GPUs: NVIDIA® GeForce® GTX 1080 and 1070, which have set records for speed and power efficiency; GTX 1060, which delivers immersive VR at strong value; and TITAN X, the most powerful consumer GPU ever built. |

[0001045810-16-000292:8k_2_02:28]
| • | Released its first game, NVIDIA VR Funhouse, which uses enhanced graphics, interactive audio and simulated physics to bring a new level of immersion to VR. |

[0001045810-16-000292:8k_2_02:29]
| • | Released NVIDIA Ansel, an in-game 360° capture tool, which enables gamers to take and share screenshots of their favorite in-game moments. |

[0001045810-16-000292:8k_2_02:30]
Professional Visualization:

[0001045810-16-000292:8k_2_02:31]
| • | Unveiled Quadro® P6000 to power the most advanced workstations, enabling designers to manipulate complex designs up to twice as fast as before. |

[0001045810-16-000292:8k_2_02:32]
| • | Introduced in partnership with SMI an innovative rendering technique that uses eye tracking to enable developers to create more immersive VR environments. |

[0001045810-16-000292:8k_2_02:33]
| • | Refreshed NVIDIA DesignWorks™ and NVIDIA VRWorks™ with new SDKs and updates that bring developers enhanced capabilities for interactive ray tracing, 360° video stitching and streaming and physically based materials. |

[0001045810-16-000292:8k_2_02:34]
Datacenter:

[0001045810-16-000292:8k_2_02:35]
| • | Opened the path to virtualizing all enterprise applications with Tesla® M10, providing the industry’s highest user density. |

[0001045810-16-000292:8k_2_02:36]
| • | Introduced Tesla P100 GPU accelerator for PCI Express-based servers, delivering substantial performance and value compared with CPU-based systems. |

[0001045810-16-000292:8k_2_02:37]
| • | Unveiled its Inception Program which provides access to NVIDIA technology and expertise to support the growth of startups driving breakthroughs in deep learning and data science. |

[0001045810-16-000292:8k_2_02:38]
Automotive:

[0001045810-16-000292:8k_2_02:39]
| • | Initiated collaborative research in advanced self-driving technology with New York University’s pioneering deep learning team. |

[0001045810-16-000292:8k_2_02:40]
CFO Commentary

[0001045810-16-000292:8k_2_02:41]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-16-000292:8k_2_02:42]
Conference Call and Webcast Information

[0001045810-16-000292:8k_2_02:43]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2017 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 47401500. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its third quarter of fiscal 2017.

[0001045810-16-000292:8k_2_02:44]
Non-GAAP Measures

[0001045810-16-000292:8k_2_02:45]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, legal settlement costs, product warranty charge, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-16-000292:8k_2_02:46]
Keep Current on NVIDIA

[0001045810-16-000292:8k_2_02:47]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-16-000292:8k_2_02:48]
About NVIDIA

[0001045810-16-000292:8k_2_02:49]
NVIDIA (NASDAQ: NVDA) is a computer technology company that has pioneered GPU-accelerated computing. It targets the world’s most demanding users - gamers, designers and scientists - with products, services and software that power amazing experiences in virtual reality, artificial intelligence, professional visualization and autonomous cars. More information at http://nvidianews.nvidia.com/.

[0001045810-16-000292:8k_2_02:50]
###

[0001045810-16-000292:8k_2_02:51]
For further information, contact:

[0001045810-16-000292:8k_2_02:52]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-16-000292:8k_2_02:53]
Certain statements in this press release including, but not limited to statements as to: surging interest in deep learning; the company’s strategy fueling growth across the company’s specialized platforms; deep learning and AI touching every industry and market; the company’s next quarterly cash dividend; the company’s financial outlook for the third quarter of fiscal 2017; the company’s tax rates for the third quarter of fiscal 2017; and the impact and benefits of Pascal GPUs, NVIDIA VR Funhouse, NVIDIA Ansel, Quadro P6000, NVIDIA DesignWorks, NVIDIA VRWorks, Tesla M10, and Tesla P100 GPU accelerator are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended May 1, 2016. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-16-000292:8k_2_02:54]
© 2016 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Quadro, Tesla, NVIDIA DesignWorks, NVIDIA VRWorks, and Pascal are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-16-000292:8k_2_02:55]
NVIDIA CORPORATION

[0001045810-16-000292:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-16-000292:8k_2_02:57]
(In millions, except per share data)

[0001045810-16-000292:8k_2_02:58]
(Unaudited)

[0001045810-16-000292:8k_2_02:59]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue | $ | 1,428 |  |  | $ | 1,153 |  |  | $ | 2,733 |  |  | $ | 2,304 |  |
| Cost of revenue | 602 |  |  | 519 |  |  | 1,156 |  |  | 1,018 |  |
| Gross profit | 826 |  |  | 634 |  |  | 1,577 |  |  | 1,286 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 350 |  |  | 320 |  |  | 697 |  |  | 658 |  |
| Sales, general and administrative | 157 |  |  | 149 |  |  | 316 |  |  | 289 |  |
| Restructuring and other charges | 2 |  |  | 89 |  |  | 3 |  |  | 89 |  |
| Total operating expenses | 509 |  |  | 558 |  |  | 1,016 |  |  | 1,036 |  |
| Income from operations | 317 |  |  | 76 |  |  | 561 |  |  | 250 |  |
| Interest income | 12 |  |  | 9 |  |  | 23 |  |  | 18 |  |
| Interest expense | (12 | ) |  | (12 | ) |  | (23 | ) |  | (22 | ) |
| Other income (expense), net | — |  |  | (1 | ) |  | (3 | ) |  | (2 | ) |
| Income before income tax expense | 317 |  |  | 72 |  |  | 558 |  |  | 244 |  |
| Income tax expense | 64 |  |  | 46 |  |  | 109 |  |  | 84 |  |
| Net income | $ | 253 |  |  | $ | 26 |  |  | $ | 449 |  |  | $ | 160 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.47 |  |  | $ | 0.05 |  |  | $ | 0.84 |  |  | $ | 0.29 |  |
| Diluted | $ | 0.40 |  |  | $ | 0.05 |  |  | $ | 0.73 |  |  | $ | 0.28 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 534 |  |  | 541 |  |  | 536 |  |  | 545 |  |
| Diluted | 631 |  |  | 556 |  |  | 617 |  |  | 563 |  |

[0001045810-16-000292:8k_2_02:60]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | July 31, |  | January 31, |
|  |  |  | 2016 |  | 2016 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,879 |  |  | $ | 5,037 |  |
|  | Accounts receivable, net |  | 644 |  |  | 505 |  |
|  | Inventories |  | 521 |  |  | 418 |  |
|  | Prepaid expenses and other current assets |  | 112 |  |  | 93 |  |
|  | Total current assets |  | 6,156 |  |  | 6,053 |  |
| Property and equipment, net |  | 485 |  |  | 466 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 138 |  |  | 166 |  |
| Other assets |  | 64 |  |  | 67 |  |
|  | Total assets |  | $ | 7,461 |  |  | $ | 7,370 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 423 |  |  | $ | 296 |  |
|  | Accrued and other current liabilities |  | 556 |  |  | 642 |  |
|  | Convertible short-term debt |  | 1,428 |  |  | 1,413 |  |
|  | Total current liabilities |  | 2,407 |  |  | 2,351 |  |
| Other long-term liabilities |  | 494 |  |  | 453 |  |
| Capital lease obligations, long-term |  | 8 |  |  | 10 |  |
|  | Total liabilities |  | 2,909 |  |  | 2,814 |  |
| Convertible debt conversion obligation |  | 72 |  |  | 87 |  |
| Shareholders' equity |  | 4,480 |  |  | 4,469 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 7,461 |  |  | $ | 7,370 |  |

[0001045810-16-000292:8k_2_02:61]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | May 1, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP gross profit |  | $ | 826 |  |  | $ | 751 |  |  | $ | 634 |  |  | $ | 1,577 |  |  | $ | 1,286 |  |
| GAAP gross margin |  | 57.9 | % |  | 57.5 | % |  | 55.0 | % |  | 57.7 | % |  | 55.8 | % |
| Stock-based compensation expense (A) |  | 4 |  |  | 4 |  |  | 3 |  |  | 8 |  |  | 6 |  |
| Legal settlement costs (B) |  | — |  |  | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Product warranty charge (C) |  | — |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Non-GAAP gross profit |  | $ | 830 |  |  | $ | 765 |  |  | $ | 652 |  |  | $ | 1,595 |  |  | $ | 1,307 |  |
| Non-GAAP gross margin |  | 58.1 | % |  | 58.6 | % |  | 56.6 | % |  | 58.4 | % |  | 56.7 | % |
| GAAP operating expenses |  | $ | 509 |  |  | $ | 506 |  |  | $ | 558 |  |  | $ | 1,016 |  |  | $ | 1,036 |  |
| Stock-based compensation expense (A) |  | (54 | ) |  | (49 | ) |  | (44 | ) |  | (104 | ) |  | (87 | ) |
| Legal settlement costs (B) |  | — |  |  | (6 | ) |  | — |  |  | (6 | ) |  | — |  |
| Acquisition-related costs (D) |  | (4 | ) |  | (4 | ) |  | (4 | ) |  | (8 | ) |  | (13 | ) |
| Contributions |  | (1 | ) |  | (3 | ) |  | — |  |  | (4 | ) |  | — |  |
| Restructuring and other charges |  | (2 | ) |  | (1 | ) |  | (89 | ) |  | (3 | ) |  | (89 | ) |
| Non-GAAP operating expenses |  | $ | 448 |  |  | $ | 443 |  |  | $ | 421 |  |  | $ | 891 |  |  | $ | 847 |  |
| GAAP income from operations |  | $ | 317 |  |  | $ | 245 |  |  | $ | 76 |  |  | $ | 561 |  |  | $ | 250 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 65 |  |  | 77 |  |  | 155 |  |  | 143 |  |  | 211 |  |
| Non-GAAP income from operations |  | $ | 382 |  |  | $ | 322 |  |  | $ | 231 |  |  | $ | 704 |  |  | $ | 461 |  |
| GAAP other income (expense), net |  | $ | — |  |  | $ | (4 | ) |  | $ | (4 | ) |  | $ | (3 | ) |  | $ | (6 | ) |
| Gains from non-affiliated investments |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | 7 |  |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Non-GAAP other income (expense), net |  | $ | 7 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 8 |  |
| GAAP net income |  | $ | 253 |  |  | $ | 196 |  |  | $ | 26 |  |  | $ | 449 |  |  | $ | 160 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 72 |  |  | 81 |  |  | 162 |  |  | 154 |  |  | 225 |  |
| Income tax impact of non-GAAP adjustments |  | (12 | ) |  | (14 | ) |  | 2 |  |  | (27 | ) |  | (8 | ) |
| Non-GAAP net income |  | $ | 313 |  |  | $ | 263 |  |  | $ | 190 |  |  | $ | 576 |  |  | $ | 377 |  |

[0001045810-16-000292:8k_2_02:62]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | May 1, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.40 |  |  | $ | 0.33 |  |  | $ | 0.05 |  |  | $ | 0.73 |  |  | $ | 0.28 |  |
| Non-GAAP |  | $ | 0.53 |  |  | $ | 0.46 |  |  | $ | 0.34 |  |  | $ | 0.99 |  |  | $ | 0.68 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 631 |  |  | 597 |  |  | 556 |  |  | 617 |  |  | 563 |  |
| Anti-dilution impact from note hedge (E) |  | (43 | ) |  | (29 | ) |  | (4 | ) |  | (37 | ) |  | (5 | ) |
| Non-GAAP |  | 588 |  |  | 568 |  |  | 552 |  |  | 580 |  |  | 558 |  |
| GAAP net cash provided by operating activities |  | $ | 184 |  |  | $ | 309 |  |  | $ | 163 |  |  | $ | 493 |  |  | $ | 409 |  |
| Purchase of property and equipment and intangible assets |  | (33 | ) |  | (55 | ) |  | (24 | ) |  | (88 | ) |  | (54 | ) |
| Free cash flow |  | $ | 151 |  |  | $ | 254 |  |  | $ | 139 |  |  | $ | 405 |  |  | $ | 355 |  |

[0001045810-16-000292:8k_2_02:63]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | May 1, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenue |  | $ | 4 |  |  | $ | 4 |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 6 |  |
| Research and development |  | $ | 30 |  |  | $ | 29 |  |  | $ | 27 |  |  | $ | 59 |  |  | $ | 54 |  |
| Sales, general and administrative |  | $ | 24 |  |  | $ | 20 |  |  | $ | 17 |  |  | $ | 44 |  |  | $ | 33 |  |
| (B) Legal settlement with Advanced Silicon Technologies LLC and other settlement related costs. |
| (C) Represents warranty charge associated with a product recall. |
| (D) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (E) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under U.S. GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-16-000292:8k_2_02:64]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2017 Outlook |
| GAAP gross margin |  | 57.8 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 58.0 | % |
|  |  |  | Q3 FY2017 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 530 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (65 | ) |
| Non-GAAP operating expenses |  | $ | 465 |  |
