# NVDA 10-Q controls and the auditor's report


## item_4_controls

[0001045810-16-000300:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001045810-16-000300:item_4_controls:2]
Controls and Procedures

[0001045810-16-000300:item_4_controls:3]
Disclosure Controls and Procedures

[0001045810-16-000300:item_4_controls:4]
Based on their evaluation as of July 31, 2016, our management, including our Chief Executive Officer and Chief Financial Officer, has concluded that our disclosure controls and procedures (as defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended) were effective to provide reasonable assurance.

[0001045810-16-000300:item_4_controls:5]
Changes in Internal Control Over Financial Reporting

[0001045810-16-000300:item_4_controls:6]
There were no changes in our internal control over financial reporting during the second quarter of fiscal year 2017 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001045810-16-000300:item_4_controls:7]
Inherent Limitations on Effectiveness of Controls

[0001045810-16-000300:item_4_controls:8]
Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.

[0001045810-16-000300:item_4_controls:9]
35
