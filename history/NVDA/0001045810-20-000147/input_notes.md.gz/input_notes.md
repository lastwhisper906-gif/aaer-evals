# NVDA notes — 0001045810-20-000147


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-20-000147:notes:1]
[same as prior period, unchanged from 0001045810-20-000065:notes:1]

[0001045810-20-000147:notes:2]
[same as prior period, unchanged from 0001045810-20-000065:notes:2]

[0001045810-20-000147:notes:3]
The unaudited condensed consolidated financial statements in this report include the financial results of Mellanox Technologies Ltd., or Mellanox, prospectively from April 27, 2020. For additional details, refer to Note 2 - Business Combination.

[0001045810-20-000147:notes:4]
[same as prior period, unchanged from 0001045810-20-000065:notes:3]

[0001045810-20-000147:notes:5]
Except for the accounting policies for business combination and investment in non-affiliated entities, there have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

[0001045810-20-000147:notes:6]
Business Combination

[0001045810-20-000147:notes:7]
We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, including in-process research and development, or IPR&D, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our condensed consolidated statements of income.

[0001045810-20-000147:notes:8]
We initially capitalize the fair value of IPR&D as an intangible asset with an indefinite life. We assess for impairment thereafter. When IPR&D projects are completed, we reclassify the IPR&D as an amortizable purchased intangible asset and amortize over the asset’s estimated useful life.

[0001045810-20-000147:notes:9]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

[0001045810-20-000147:notes:10]
Investment in Non-Affiliated Entities

[0001045810-20-000147:notes:11]
Non-marketable equity investments in privately-held companies are recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. These investments are valued using observable and unobservable inputs or data in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. The estimated fair value is based on quantitative and qualitative factors including subsequent financing activities by the investee.

[0001045810-20-000147:notes:12]
[same as prior period, unchanged from 0001045810-20-000065:notes:5]

[0001045810-20-000147:notes:13]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The second quarters of fiscal years 2021 and 2020 were both 13-week quarters.

[0001045810-20-000147:notes:14]
[same as prior period, unchanged from 0001045810-20-000065:notes:7]

[0001045810-20-000147:notes:15]
[same as prior period, unchanged from 0001045810-20-000065:notes:8]

[0001045810-20-000147:notes:16]
[same as prior period, unchanged from 0001045810-20-000065:notes:9]

[0001045810-20-000147:notes:17]
[same as prior period, unchanged from 0001045810-20-000065:notes:10]

[0001045810-20-000147:notes:18]
[same as prior period, unchanged from 0001045810-20-000065:notes:11]

[0001045810-20-000147:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19 on our critical and significant accounting estimates. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-20-000147:notes:20]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000147:notes:21]
Recently Adopted Accounting Pronouncement

[0001045810-20-000147:notes:22]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. We adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to our consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-20-000147:notes:23]
Business CombinationOn April 27, 2020, we completed the acquisition of all outstanding shares of Mellanox for a total purchase consideration of $7.13 billion. Mellanox is a supplier of high-performance interconnect products for computing, storage and communications applications. We acquired Mellanox to optimize data center workloads to scale across the entire computing, networking, and storage stack.
Preliminary Purchase Price Allocation

[0001045810-20-000147:notes:24]
The aggregate purchase consideration has been preliminarily allocated as follows (in millions):

[0001045810-20-000147:notes:25]
| Purchase Price |  |  |
| Cash paid for outstanding Mellanox ordinary shares (1) |  | $ | 7,033 |  |
| Cash for Mellanox equity awards (2) |  | 16 |  |
| Total cash consideration |  | 7,049 |  |
| Fair value of Mellanox equity awards assumed by NVIDIA (3) |  | 85 |  |
| Total purchase consideration |  | $ | 7,134 |  |
| Allocation |  |  |
| Cash and cash equivalents |  | $ | 115 |  |
| Marketable securities |  | 699 |  |
| Accounts receivable, net |  | 216 |  |
| Inventories |  | 320 |  |
| Prepaid expenses and other assets |  | 179 |  |
| Property and equipment, net |  | 144 |  |
| Goodwill |  | 3,431 |  |
| Intangible assets |  | 2,970 |  |
| Accounts payable |  | (136) |  |
| Accrued and other current liabilities |  | (236) |  |
| Income tax liability |  | (191) |  |
| Deferred income tax liability |  | (258) |  |
| Other long-term liabilities |  | (119) |  |
|  |  | $ | 7,134 |  |

[0001045810-20-000147:notes:26]
(1) Represents the cash consideration of $125.00 per share paid to Mellanox shareholders for approximately 56 million shares of outstanding Mellanox ordinary shares.

[0001045810-20-000147:notes:27]
(2) Represents the cash consideration for the settlement of approximately 249 thousand Mellanox stock options held by employees and non-employee directors of Mellanox.

[0001045810-20-000147:notes:28]
(3) Represents the fair value of Mellanox’s stock-based compensation awards attributable to pre-combination services.

[0001045810-20-000147:notes:29]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on the preliminary estimates of their estimated fair values, which were determined using generally accepted valuation techniques based on estimates and assumptions made by management at the time of the acquisition and are subject to change during the measurement period which is not expected to exceed one year. The primary tasks that are required to be completed include validation of business level forecasts, jurisdictional forecasts, customer attrition rates, contingent liabilities assessments and any related tax impacts from the acquisition. Any adjustments to our preliminary purchase price allocation identified during the measurement period will be recognized in the period in which the adjustments are determined.

[0001045810-20-000147:notes:30]
The goodwill is primarily attributable to the planned growth in the combined business of NVIDIA and Mellanox. Goodwill is not amortized to earnings, but instead is reviewed for impairment at least annually, absent any interim indicators of impairment. Goodwill recognized in the acquisition is not expected to be deductible for foreign tax purposes. Goodwill arising from the Mellanox acquisition has been allocated to the Compute and Networking segment. Refer to Note 15 – Segment Information for further details on segments.

[0001045810-20-000147:notes:31]
The operating results of Mellanox have been included in our condensed consolidated financial statements for the second quarter of fiscal year 2021 from the acquisition date. Revenue attributable to Mellanox was approximately 14% of consolidated revenue. There is not a practical way to determine net income attributable to Mellanox due to integration.

[0001045810-20-000147:notes:32]
Acquisition-related costs of $26 million were included in selling, general and administrative expense for the first half of fiscal year 2021.

[0001045810-20-000147:notes:33]
Intangible Assets

[0001045810-20-000147:notes:34]
The estimated fair value and weighted average useful life of the acquired intangible assets are as follows:

[0001045810-20-000147:notes:35]
|  | Fair Value |  | Weighted Average Useful Lives |
|  | (In millions) |  |  |
| Developed technology (1) | $ | 1,640 |  |  | 5 years |
| Customer relationships (2) | 440 |  |  | 3 years |
| Order backlog (3) | 190 |  |  | Based on actual shipments |
| Trade names (4) | 70 |  |  | 5 years |
| Total identified finite-lived intangible assets | 2,340 |  |  |  |
| IPR&D (5) | 630 |  |  | N/A |
| Total identified intangible assets | $ | 2,970 |  |  |  |

[0001045810-20-000147:notes:36]
(1) The fair value of developed technology was identified using the Multi-Period Excess Earning Method.

[0001045810-20-000147:notes:37]
(2) Customer relationships represent the fair value of the existing relationships using the With and Without Method.

[0001045810-20-000147:notes:38]
(3) Order backlog represents primarily the fair value of purchase arrangements with customers using the Multi-Period Excess Earning Method.

[0001045810-20-000147:notes:39]
(4) Trade names primarily relate to Mellanox trade names and fair value was determined by applying the Relief-from-Royalty Method under the income approach.

[0001045810-20-000147:notes:40]
(5) The fair value of IPR&D was determined using the Multi-Period Excess Earning Method.

[0001045810-20-000147:notes:41]
The fair value of the finite-lived intangible assets will be amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received to cost of revenue and operating expenses.

[0001045810-20-000147:notes:42]
Mellanox had an IPR&D project associated with the next generation interconnect product that had not yet reached technological feasibility as of the acquisition date. Accordingly, we recorded an indefinite-lived intangible asset of $630 million for the fair value of this project, which will initially not be amortized. Instead, the project will be tested for impairment whenever events or changes in circumstances indicate that the project may be impaired or may have reached technological feasibility. Once the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life.

[0001045810-20-000147:notes:43]
Supplemental Unaudited Pro Forma Information

[0001045810-20-000147:notes:44]
The following unaudited pro forma financial information summarizes the combined results of operations for NVIDIA and Mellanox as if the companies were combined as of the beginning of fiscal year 2020:

[0001045810-20-000147:notes:45]
|  | Pro Forma |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26,2020 |  | July 28,2019 |  | July 26,2020 |  | July 28,2019 |
|  | (In millions) |  |  |  |  |  |  |
| Revenue | $ | 3,866 |  |  | $ | 2,889 |  |  | $ | 7,375 |  |  | $ | 5,415 |  |
| Net income | $ | 964 |  |  | $ | 411 |  |  | $ | 1,883 |  |  | $ | 404 |  |

[0001045810-20-000147:notes:46]
The unaudited pro forma information includes adjustments related to amortization of acquired intangible assets, adjustments to stock-based compensation expense, fair value of acquired inventory, and transaction costs. The unaudited pro forma information presented above is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2020 or of the results of our future operations of the combined businesses.

[0001045810-20-000147:notes:47]
The pro forma results reflect the inventory step-up expense of $161 million in the first half of fiscal year 2020 and were excluded from the pro forma results for the second quarter and first half of fiscal year 2021. There were no other material nonrecurring adjustments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-20-000147:notes:48]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2021 and 2035.

[0001045810-20-000147:notes:49]
Future minimum lease payments under our non-cancelable operating leases as of July 26, 2020, are as follows:

[0001045810-20-000147:notes:50]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2021 (excluding first half of fiscal year 2021) | $ | 74 |  |
| 2022 | 139 |  |
| 2023 | 119 |  |
| 2024 | 99 |  |
| 2025 | 80 |  |
| 2026 and thereafter | 344 |  |
| Total | 855 |  |
| Less imputed interest | 120 |  |
| Present value of net future minimum lease payments | 735 |  |
| Less short-term operating lease liabilities | 124 |  |
| Long-term operating lease liabilities | $ | 611 |  |

[0001045810-20-000147:notes:51]
Operating lease expense was $35 million and $28 million for the second quarter of fiscal years 2021 and 2020, respectively, and $67 million and $55 million for the first half of fiscal years 2021 and 2020, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal years 2021 and 2020 were not significant.

[0001045810-20-000147:notes:52]
[same as prior period, unchanged from 0001045810-20-000065:notes:21]

[0001045810-20-000147:notes:53]
|  | Six Months Ended |  |  |
|  | July 26, 2020 |  | July 28, 2019 |
|  | (In millions) |  |  |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 66 |  |  | $ | 50 |  |
| Operating lease assets obtained in exchange for lease obligations (1) | $ | 138 |  |  | $ | 108 |  |

[0001045810-20-000147:notes:54]
(1) The first half of fiscal year 2021 includes $80 million of operating lease assets addition due to a business combination.

[0001045810-20-000147:notes:55]
As of July 26, 2020, our operating leases had a weighted average remaining lease term of 8.0 years and a weighted average discount rate of 3.08%. As of January 26, 2020, our operating leases had a weighted average remaining lease term of 8.3 years and a weighted average discount rate of 3.45%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-20-000147:notes:56]
[same as prior period, unchanged from 0001045810-20-000065:notes:24]

[0001045810-20-000147:notes:57]
[same as prior period, unchanged from 0001045810-20-000065:notes:25]

[0001045810-20-000147:notes:58]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26,2020 |  | July 28,2019 |  | July 26,2020 |  | July 28,2019 |
|  | (In millions) |  |  |  |  |  |  |
| Cost of revenue | $ | 14 |  |  | $ | 8 |  |  | $ | 35 |  |  | $ | 12 |  |
| Research and development | 228 |  |  | 145 |  |  | 362 |  |  | 259 |  |
| Sales, general and administrative | 132 |  |  | 71 |  |  | 201 |  |  | 130 |  |
| Total | $ | 374 |  |  | $ | 224 |  |  | $ | 598 |  |  | $ | 401 |  |

[0001045810-20-000147:notes:59]
[same as prior period, unchanged from 0001045810-20-000065:notes:27]

[0001045810-20-000147:notes:60]
[same as prior period, unchanged from 0001045810-20-000065:notes:28]

[0001045810-20-000147:notes:61]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |  |  |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |  |  |  |  |  |  |
| Balances, January 26, 2020 | 14 |  |  | $ | 176.72 |  |  |  |  |  |
| Granted | 8 |  |  | $ | 291.89 |  |  |  |  |  |
| Vested restricted stock | (5) |  |  | $ | 149.90 |  |  |  |  |  |
| Balances, July 26, 2020 | 17 |  |  | $ | 239.22 |  |  |  |  |  |

[0001045810-20-000147:notes:62]
As of July 26, 2020, there was $3.60 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.8 years for RSUs, PSUs, and market-based PSUs, and 0.9 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-20-000147:notes:63]
[same as prior period, unchanged from 0001045810-20-000065:notes:31]

[0001045810-20-000147:notes:64]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26, |  | July 28, |  | July 26, |  | July 28, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In millions, except per share data) |  |  |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 622 |  |  | $ | 552 |  |  | $ | 1,539 |  |  | $ | 947 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 616 |  |  | 609 |  |  | 615 |  |  | 608 |  |
| Dilutive impact of outstanding equity awards | 10 |  |  | 7 |  |  | 9 |  |  | 8 |  |
| Diluted weighted average shares | 626 |  |  | 616 |  |  | 624 |  |  | 616 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.01 |  |  | $ | 0.91 |  |  | $ | 2.50 |  |  | $ | 1.56 |  |
| Diluted (2) | $ | 0.99 |  |  | $ | 0.90 |  |  | $ | 2.47 |  |  | $ | 1.54 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | — |  |  | 11 |  |  | 6 |  |  | 12 |  |

[0001045810-20-000147:notes:65]
[same as prior period, unchanged from 0001045810-20-000065:notes:33]

[0001045810-20-000147:notes:66]
[same as prior period, unchanged from 0001045810-20-000065:notes:34]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-20-000147:notes:67]
Income Taxes
We recognized an income tax benefit of $13 million and an income tax expense of $52 million for the second quarter and first half of fiscal year 2021, respectively, and an income tax expense of $54 million and $48 million for the second quarter and first half of fiscal year 2020, respectively. The income tax benefit as a percentage of income before income tax was 2.0% for the second quarter of fiscal year 2021. The income tax expense as a percentage of income before income tax was 3.3% for the first half of fiscal year 2021, and 8.8% and 4.9% for the second quarter and first half of fiscal year 2020, respectively.

[0001045810-20-000147:notes:68]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2021 as compared to the same periods of fiscal year 2020 was primarily due to a decrease in the proportional amount of earnings subject to United States tax and an increase of tax benefits from stock-based compensation and the U.S. federal research tax credit.

[0001045810-20-000147:notes:69]
Our effective tax rates for the first half of fiscal years 2021 and 2020 were lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-20-000147:notes:70]
During the second quarter of fiscal year 2021, we completed the acquisition of Mellanox. As a result of the acquisition, we recorded $256 million of net deferred tax liabilities primarily on the excess of book basis over the tax basis of the acquired intangible assets and undistributed earnings in certain foreign subsidiaries. We also recorded $153 million of long-term tax liabilities related to tax basis differences in Mellanox. The net deferred tax liabilities and long-term tax liabilities are based upon certain assumptions underlying our purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes and long-term tax liabilities may be required.

[0001045810-20-000147:notes:71]
As of July 26, 2020, we intend to indefinitely reinvest approximately $675 million of cumulative undistributed earnings held by Mellanox non-U.S. subsidiaries. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in Mellanox non-U.S. subsidiaries as the determination of such amount is not practicable.
For the first half of fiscal year 2021, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. In the second quarter of fiscal year 2021, we assumed $59 million of unrecognized tax benefits and $4 million of related interest through the Mellanox acquisition. Other than these amounts, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 26, 2020.While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.  As of July 26, 2020, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-20-000147:notes:72]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-20-000147:notes:73]
The following is a summary of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020:

[0001045810-20-000147:notes:74]
|  | July 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 3,494 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3,497 |  |  | $ | 515 |  |  | $ | 2,982 |  |
| Debt securities issued by United States government agencies | 2,101 |  |  | 1 |  |  | — |  |  | 2,102 |  |  | 50 |  |  | 2,052 |  |
| Money market funds | 2,053 |  |  | — |  |  | — |  |  | 2,053 |  |  | 2,053 |  |  | — |  |
| Debt securities issued by the United States Treasury | 1,956 |  |  | — |  |  | — |  |  | 1,956 |  |  | — |  |  | 1,956 |  |
| Certificates of deposit | 893 |  |  | — |  |  | — |  |  | 893 |  |  | 342 |  |  | 551 |  |
| Foreign government bonds | 256 |  |  | — |  |  | — |  |  | 256 |  |  | 90 |  |  | 166 |  |
| Total | $ | 10,753 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 10,757 |  |  | $ | 3,050 |  |  | $ | 7,707 |  |

[0001045810-20-000147:notes:75]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

[0001045810-20-000147:notes:76]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-20-000147:notes:77]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020 are shown below by contractual maturity.

[0001045810-20-000147:notes:78]
|  | July 26, 2020 |  |  |  | January 26, 2020 |  |  |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |  |  |  |  |  |  |
| Less than one year | $ | 10,027 |  |  | $ | 10,028 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 726 |  |  | 729 |  |  | — |  |  | — |  |
| Total | $ | 10,753 |  |  | $ | 10,757 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-20-000147:notes:79]
[same as prior period, unchanged from 0001045810-20-000065:notes:45]

[0001045810-20-000147:notes:80]
|  |  |  | Fair Value at |  |  |
|  | Pricing Category |  | July 26, 2020 |  | January 26, 2020 |
|  |  |  | (In millions) |  |  |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 2,053 |  |  | $ | 7,507 |  |
| Corporate debt securities | Level 2 |  | $ | 3,497 |  |  | $ | 592 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 2,102 |  |  | $ | 1,096 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 1,956 |  |  | $ | 1,358 |  |
| Certificates of deposit | Level 2 |  | $ | 893 |  |  | $ | 27 |  |
| Foreign government bonds | Level 2 |  | $ | 256 |  |  | $ | 200 |  |
| Other asset: |  |  |  |  |  |
| Investment in non-affiliated entities (1) | Level 3 |  | $ | 110 |  |  | $ | 77 |  |
| Liabilities |  |  |  |  |  |
| Other non-current liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (2) | Level 2 |  | $ | 1,019 |  |  | $ | 1,006 |  |
| 3.20% Notes Due 2026 (2) | Level 2 |  | $ | 1,139 |  |  | $ | 1,065 |  |
| 2.85% Notes Due 2030 (2) | Level 2 |  | $ | 1,684 |  |  | $ | — |  |
| 3.50% Notes Due 2040 (2) | Level 2 |  | $ | 1,211 |  |  | $ | — |  |
| 3.50% Notes Due 2050 (2) | Level 2 |  | $ | 2,432 |  |  | $ | — |  |
| 3.70% Notes Due 2060 (2) | Level 2 |  | $ | 637 |  |  | $ | — |  |

[0001045810-20-000147:notes:81]
(1)    Investment in non-affiliated entities is privately held and recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of July 26, 2020 has not been significant.
(2) These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance   costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-20-000147:notes:82]
(1)    Investment in non-affiliated entities is privately held and recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of July 26, 2020 has not been significant.

[0001045810-20-000147:notes:83]
(2) These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance   costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-20-000147:notes:84]
[same as prior period, unchanged from 0001045810-20-000065:notes:48]

[0001045810-20-000147:notes:85]
|  | July 26, 2020 |  |  |  |  |  | January 26, 2020 |  |  |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related intangible assets (1) | $ | 3,287 |  |  | $ | (474) |  |  | $ | 2,813 |  |  | $ | 195 |  |  | $ | (192) |  |  | $ | 3 |  |
| Patents and licensed technology | 524 |  |  | (483) |  |  | 41 |  |  | 520 |  |  | (474) |  |  | 46 |  |
| Total intangible assets | $ | 3,811 |  |  | $ | (957) |  |  | $ | 2,854 |  |  | $ | 715 |  |  | $ | (666) |  |  | $ | 49 |  |

[0001045810-20-000147:notes:86]
(1)  As of July 26, 2020, acquisition-related intangible assets include the fair value of a Mellanox IPR&D project of $630 million, which initially will not be amortized. Once the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for further details.

[0001045810-20-000147:notes:87]
Amortization expense associated with intangible assets was $284 million and $291 million for the second quarter and first half of fiscal year 2021, respectively, and $6 million and $13 million for the second quarter and first half of fiscal year 2020, respectively. Future amortization expense related to the net carrying amount of intangible assets as of July 26, 2020 is estimated to be $316 million for the remainder of fiscal year 2021, $532 million in fiscal year 2022, $529 million in fiscal year 2023, $407 million in fiscal year 2024, $354 million in fiscal year 2025, and $716 million in fiscal year 2026 and thereafter. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for further details on acquisition-related intangible assets.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-20-000147:notes:88]
[same as prior period, unchanged from 0001045810-20-000065:notes:51]

[0001045810-20-000147:notes:89]
|  | July 26, |  | January 26, |
|  | 2020 |  | 2020 |
| Inventories: | (In millions) |  |  |
| Raw materials | $ | 320 |  |  | $ | 249 |  |
| Work in-process | 516 |  |  | 265 |  |
| Finished goods | 565 |  |  | 465 |  |
| Total inventories | $ | 1,401 |  |  | $ | 979 |  |

[0001045810-20-000147:notes:90]
|  | July 26, |  | January 26, |
|  | 2020 |  | 2020 |
| Accrued and Other Current Liabilities: | (In millions) |  |  |
| Customer program accruals | $ | 506 |  |  | $ | 462 |  |
| Accrued payroll and related expenses | 322 |  |  | 185 |  |
| Deferred revenue (1) | 222 |  |  | 141 |  |
| Operating leases | 124 |  |  | 91 |  |
| Licenses and royalties | 101 |  |  | 66 |  |
| Coupon interest on debt obligations | 74 |  |  | 20 |  |
| Taxes payable | 52 |  |  | 61 |  |
| Product warranty and return provisions | 31 |  |  | 24 |  |
| Professional service fee | 20 |  |  | 18 |  |
| Other | 65 |  |  | 29 |  |
| Total accrued and other current liabilities | $ | 1,517 |  |  | $ | 1,097 |  |

[0001045810-20-000147:notes:91]
[same as prior period, unchanged from 0001045810-20-000065:notes:54]

[0001045810-20-000147:notes:92]
|  | July 26, |  | January 26, |
|  | 2020 |  | 2020 |
| Other Long-Term Liabilities: | (In millions) |  |  |
| Income tax payable (1) | $ | 721 |  |  | $ | 528 |  |
| Deferred income tax (2) | 274 |  |  | 29 |  |
| Deferred revenue (3) | 120 |  |  | 60 |  |
| Licenses payable | 89 |  |  | 110 |  |
| Employee benefits | 38 |  |  | 22 |  |
| Other | 43 |  |  | 26 |  |
| Total other long-term liabilities | $ | 1,285 |  |  | $ | 775 |  |

[0001045810-20-000147:notes:93]
(1) As of July 26, 2020, income tax payable represents the long-term portion of the one-time transition tax payable of $284 million, unrecognized tax benefits of $245 million, related interest and penalties of $41 million, and other foreign long-term tax payable of $151 million.

[0001045810-20-000147:notes:94]
(2) Deferred income tax primarily relates to acquired intangible assets.

[0001045810-20-000147:notes:95]
(3) Deferred revenue primarily includes deferrals related to PCS.

[0001045810-20-000147:notes:96]
[same as prior period, unchanged from 0001045810-20-000065:notes:58]

[0001045810-20-000147:notes:97]
The following table shows the changes in deferred revenue during the first half of fiscal years 2021 and 2020:

[0001045810-20-000147:notes:98]
|  | July 26, |  | July 28, |
|  | 2020 |  | 2019 |
|  | (In millions) |  |  |
| Balance at beginning of period | $ | 201 |  |  | $ | 138 |  |
| Deferred revenue added during the period | 213 |  |  | 161 |  |
| Addition due to business combinations | 75 |  |  | — |  |
| Revenue recognized during the period | (147) |  |  | (118) |  |
| Balance at end of period | $ | 342 |  |  | $ | 181 |  |

[0001045810-20-000147:notes:99]
Revenue related to remaining performance obligations represents the remaining contracted license, development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of July 26, 2020, the amount of our remaining performance obligations that has not been recognized as revenue was $670 million, of which we expect to recognize approximately 40% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-20-000147:notes:100]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of July 26, 2020 and January 26, 2020.

[0001045810-20-000147:notes:101]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than the U.S. dollar, including intercompany hedging instruments, or intercompany derivatives, with wholly-owned subsidiaries in order to hedge certain forecasted expenses denominated in currencies other than the U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-20-000147:notes:102]
The table below presents the notional value of our foreign currency forward contracts outstanding as of July 26, 2020 and January 26, 2020:

[0001045810-20-000147:notes:103]
|  | July 26,2020 |  | January 26,2020 |
|  | (In millions) |  |  |
| Designated as cash flow hedges | $ | 575 |  |  | $ | 428 |  |
| Not designated for hedge accounting | $ | 373 |  |  | $ | 287 |  |

[0001045810-20-000147:notes:104]
As of July 26, 2020, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-20-000147:notes:105]
During the first half of fiscal years 2021 and 2020, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-20-000147:notes:106]
Debt
Long-Term Debt

[0001045810-20-000147:notes:107]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and estimated issuance costs.

[0001045810-20-000147:notes:108]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-20-000147:notes:109]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-20-000147:notes:110]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-20-000147:notes:111]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.7 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.7 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.7 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.7 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,960 |  |  | $ | 1,991 |  |

[0001045810-20-000147:notes:112]
As of July 26, 2020, we were in compliance with the required covenants under the Notes.

[0001045810-20-000147:notes:113]
Revolving Credit Facility

[0001045810-20-000147:notes:114]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 26, 2020, we had not borrowed any amounts and were in compliance with the required covenants under this agreement.

[0001045810-20-000147:notes:115]
Commercial Paper

[0001045810-20-000147:notes:116]
We have a $575 million commercial paper program to support general corporate purposes. As of July 26, 2020, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-20-000147:notes:117]
Commitments and Contingencies
Purchase Obligations

[0001045810-20-000147:notes:118]
As of July 26, 2020, we had outstanding inventory purchase obligations totaling $2.04 billion and other purchase obligations totaling $310 million.

[0001045810-20-000147:notes:119]
Accrual for Product Warranty Liabilities

[0001045810-20-000147:notes:120]
The estimated amount of product returns and warranty liabilities was $19 million and $15 million as of July 26, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.

[0001045810-20-000147:notes:121]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-20-000147:notes:122]
Litigation

[0001045810-20-000147:notes:123]
Securities Class Action and Derivative Lawsuits

[0001045810-20-000147:notes:124]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants. On March 16, 2020, the Court issued an order dismissing the consolidated class action complaint with leave to amend.  The plaintiffs filed an amended complaint on May 13, 2020.  On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

[0001045810-20-000147:notes:125]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The Court approved the parties’ stipulation to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-20-000147:notes:126]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the Court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-20-000147:notes:127]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-20-000147:notes:128]
Accounting for Loss Contingencies

[0001045810-20-000147:notes:129]
As of July 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-20-000147:notes:130]
[same as prior period, unchanged from 0001045810-20-000065:notes:94]

[0001045810-20-000147:notes:131]
[same as prior period, unchanged from 0001045810-20-000065:notes:95]

[0001045810-20-000147:notes:132]
Through July 26, 2020, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of July 26, 2020, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-20-000147:notes:133]
During the second quarter and first half of fiscal year 2021, we paid $99 million and $197 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-20-000147:notes:134]
Segment Information
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. In the prior fiscal year, we had reported two operating segments: GPU and Tegra Processor. During the first quarter of fiscal year 2021, we changed our operating segments to be consistent with the revised manner in which our CODM reviews our financial performance and allocates resources. The two new operating segments are "Graphics" and "Compute & Networking". Comparative periods presented reflect this change. Our operating segments are equivalent to our reportable segments.

[0001045810-20-000147:notes:135]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro GPUs for enterprise design; GRID software for cloud-based visual and virtual computing; and automotive platforms for infotainment systems. Our Compute & Networking segment includes Data Center platforms and systems for artificial intelligence, or AI, high performance computing, or HPC, and accelerated computing; Mellanox networking and interconnect solutions; DRIVE for autonomous vehicles; and Jetson for robotics and other embedded platforms.

[0001045810-20-000147:notes:136]
[same as prior period, unchanged from 0001045810-20-000065:notes:100]

[0001045810-20-000147:notes:137]
[same as prior period, unchanged from 0001045810-20-000065:notes:101]

[0001045810-20-000147:notes:138]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the

[0001045810-20-000147:notes:139]
same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-20-000147:notes:140]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |  |  |  |  |  |  |
| Three Months Ended July 26, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 2,085 |  |  | $ | 1,781 |  |  | $ | — |  |  | $ | 3,866 |  |
| Operating income (loss) | $ | 911 |  |  | $ | 691 |  |  | $ | (951) |  |  | $ | 651 |  |
| Three Months Ended July 28, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 1,803 |  |  | $ | 776 |  |  | $ | — |  |  | $ | 2,579 |  |
| Operating income (loss) | $ | 707 |  |  | $ | 164 |  |  | $ | (300) |  |  | $ | 571 |  |
| Six Months Ended July 26, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 3,991 |  |  | $ | 2,955 |  |  | $ | — |  |  | $ | 6,946 |  |
| Operating income (loss) | $ | 1,747 |  |  | $ | 1,142 |  |  | $ | (1,262) |  |  | $ | 1,627 |  |
| Six Months Ended July 28, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 3,329 |  |  | $ | 1,470 |  |  | $ | — |  |  | $ | 4,799 |  |
| Operating income (loss) | $ | 1,239 |  |  | $ | 259 |  |  | $ | (569) |  |  | $ | 929 |  |

[0001045810-20-000147:notes:141]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26,2020 |  | July 28,2019 |  | July 26,2020 |  | July 28,2019 |
|  | (In millions) |  |  |  |  |  |  |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Acquisition-related and other costs | $ | (474) |  |  | $ | (5) |  |  | $ | (479) |  |  | $ | (15) |  |
| Stock-based compensation expense | (374) |  |  | (224) |  |  | (598) |  |  | (401) |  |
| Unallocated cost of revenue and operating expenses | (86) |  |  | (69) |  |  | (168) |  |  | (140) |  |
| Legal settlement costs | (17) |  |  | (2) |  |  | (17) |  |  | (13) |  |
| Total | $ | (951) |  |  | $ | (300) |  |  | $ | (1,262) |  |  | $ | (569) |  |

[0001045810-20-000147:notes:142]
[same as prior period, unchanged from 0001045810-20-000065:notes:105]

[0001045810-20-000147:notes:143]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26, |  | July 28, |  | July 26, |  | July 28, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In millions) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 954 |  |  | $ | 635 |  |  | $ | 1,766 |  |  | $ | 1,333 |  |
| United States | 944 |  |  | 188 |  |  | 1,441 |  |  | 353 |  |
| China (including Hong Kong) | 855 |  |  | 583 |  |  | 1,614 |  |  | 1,136 |  |
| Other Asia Pacific | 698 |  |  | 756 |  |  | 1,305 |  |  | 1,178 |  |
| Europe | 240 |  |  | 288 |  |  | 494 |  |  | 537 |  |
| Other countries | 175 |  |  | 129 |  |  | 326 |  |  | 262 |  |
| Total revenue | $ | 3,866 |  |  | $ | 2,579 |  |  | $ | 6,946 |  |  | $ | 4,799 |  |

[0001045810-20-000147:notes:144]
[same as prior period, unchanged from 0001045810-20-000065:notes:107]

[0001045810-20-000147:notes:145]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26, |  | July 28, |  | July 26, |  | July 28, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In millions) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,654 |  |  | $ | 1,313 |  |  | $ | 2,993 |  |  | $ | 2,368 |  |
| Professional Visualization | 203 |  |  | 291 |  |  | 510 |  |  | 557 |  |
| Data Center | 1,752 |  |  | 655 |  |  | 2,893 |  |  | 1,289 |  |
| Automotive | 111 |  |  | 209 |  |  | 266 |  |  | 375 |  |
| OEM and Other | 146 |  |  | 111 |  |  | 284 |  |  | 210 |  |
| Total revenue | $ | 3,866 |  |  | $ | 2,579 |  |  | $ | 6,946 |  |  | $ | 4,799 |  |

[0001045810-20-000147:notes:146]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal year 2021. One customer represented 11% of our total revenue for the second quarter and first half of fiscal year 2020, and was attributable primarily to the Graphics segment.

[0001045810-20-000147:notes:147]
One customer represented 14% and 21% of our accounts receivable balance as of July 26, 2020 and January 26, 2020, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-20-000147:notes:148]
Goodwill During the first quarter of fiscal year 2021, we changed our operating segments to Graphics and Compute & Networking, as discussed in Note 15 of these Notes to Condensed Consolidated Financial Statements. As a result, our reporting units also changed, and we reassigned the goodwill balance to the new reporting units based on their relative fair values. We determined there was no goodwill impairment immediately prior to the reorganization. As of July 26, 2020, the total carrying amount of goodwill was $4.19 billion and the amount of goodwill allocated to our Graphics and Compute & Networking reporting units was $347 million and $3.85 billion, respectively. In the second quarter and first half of fiscal year 2021, goodwill increased by $3.56 billion and $3.57 billion, respectively. The increase in goodwill in the second quarter of fiscal year 2021 was due to goodwill of $3.43 billion arising from the Mellanox acquisition, and goodwill of $133 million from other acquisition activity, both of which were allocated to the Compute & Networking reporting unit.
