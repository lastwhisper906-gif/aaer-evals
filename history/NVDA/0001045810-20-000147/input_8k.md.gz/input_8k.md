# NVDA 8-K — 0001045810-20-000145 filed 2020-08-19

## item codes, every 8-K on or before 2020-08-19

- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2020-08-19

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-20-000145:8k_2_02:1]
EX-99.1
2
q2fy21pr.htm
Q2FY21 PRESS RELEASE

[0001045810-20-000145:8k_2_02:2]
Document

[0001045810-20-000145:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-20-000145:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2021

[0001045810-20-000145:8k_2_02:5]
•Record revenue of $3.87 billion, up 50 percent from a year earlier

[0001045810-20-000145:8k_2_02:6]
•Record Data Center revenue of $1.75 billion, up 167 percent from a year earlier

[0001045810-20-000145:8k_2_02:7]
•Mellanox growth accelerated in its first quarter as part of NVIDIA, contributed 14 percent of revenue

[0001045810-20-000145:8k_2_02:8]
SANTA CLARA, Calif.-Aug. 19, 2020- NVIDIA (NASDAQ: NVDA) today reported record revenue for the second quarter ended July 26, 2020, of $3.87 billion, up 50 percent from $2.58 billion a year earlier, and up 26 percent from $3.08 billion in the previous quarter.

[0001045810-20-000145:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.99, up 10 percent from $0.90 a year ago, and down 33 percent from $1.47 in the previous quarter. Non-GAAP earnings per diluted share were $2.18, up 76 percent from $1.24 a year earlier, and up 21 percent from $1.80 in the previous quarter.

[0001045810-20-000145:8k_2_02:10]
NVIDIA closed its acquisition of Mellanox Technologies Ltd. on April 27, 2020.

[0001045810-20-000145:8k_2_02:11]
“Adoption of NVIDIA computing is accelerating, driving record revenue and exceptional growth,” said Jensen Huang, founder and CEO of NVIDIA. “Growth in GeForce gaming accelerated as gamers increasingly immerse themselves in realistic virtual worlds created by NVIDIA RTX ray tracing and AI.

[0001045810-20-000145:8k_2_02:12]
“Our new Ampere GPU architecture is sprinting out of the blocks, with the world’s top cloud service providers and server makers moving quickly to offer NVIDIA accelerated computing. Mellanox grew sharply, driven by the need for high-speed networking in cloud data centers to scale-out AI services. And Mercedes-Benz’s partnership with NVIDIA to power its next-generation fleet of luxury cars -- from the computer to the AI software, and from the cloud to the car -- is transformative.

[0001045810-20-000145:8k_2_02:13]
“Despite the pandemic’s impact on our professional visualization and automotive platforms, we are well positioned to grow, as gaming, AI, cloud computing and autonomous machines drive the next industrial revolution around the world,” he said.

[0001045810-20-000145:8k_2_02:14]
NVIDIA paid $99 million in quarterly cash dividends in the second quarter. It will pay its next quarterly cash dividend of $0.16 per share on September 24, 2020, to all shareholders of record on September 2, 2020.

[0001045810-20-000145:8k_2_02:15]
Q2 Fiscal 2021 Summary

[0001045810-20-000145:8k_2_02:16]
| GAAP |  |  |  |  |  |
| ($ in millions, except earnings per share) | Q2 FY21 | Q1 FY21 | Q2 FY20 | Q/Q | Y/Y |
| Revenue | $3,866 | $3,080 | $2,579 | Up 26% | Up 50% |
| Gross margin | 58.8 | % | 65.1 | % | 59.8 | % | Down 630 bps | Down 100 bps |
| Operating expenses | $1,624 | $1,028 | $970 | Up 58% | Up 67% |
| Operating income | $651 | $976 | $571 | Down 33% | Up 14% |
| Net income | $622 | $917 | $552 | Down 32% | Up 13% |
| Diluted earnings per share | $0.99 | $1.47 | $0.90 | Down 33% | Up 10% |

[0001045810-20-000145:8k_2_02:17]
| Non-GAAP |  |  |  |  |  |
| ($ in millions, except earnings per share) | Q2 FY21 | Q1 FY21 | Q2 FY20 | Q/Q | Y/Y |
| Revenue | $3,866 | $3,080 | $2,579 | Up 26% | Up 50% |
| Gross margin | 66.0 | % | 65.8 | % | 60.1 | % | Up 20 bps | Up 590 bps |
| Operating expenses | $1,035 | $821 | $749 | Up 26% | Up 38% |
| Operating income | $1,516 | $1,205 | $802 | Up 26% | Up 89% |
| Net income | $1,366 | $1,120 | $762 | Up 22% | Up 79% |
| Diluted earnings per share | $2.18 | $1.80 | $1.24 | Up 21% | Up 76% |

[0001045810-20-000145:8k_2_02:18]
NVIDIA’s outlook for the third quarter of fiscal 2021 is as follows:

[0001045810-20-000145:8k_2_02:19]
•Revenue is expected to be $4.40 billion, plus or minus 2 percent.

[0001045810-20-000145:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 62.5 percent and 65.5 percent, respectively, plus or minus 50 basis points.

[0001045810-20-000145:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $1.54 billion and $1.09 billion, respectively.

[0001045810-20-000145:8k_2_02:22]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $55 million.

[0001045810-20-000145:8k_2_02:23]
•GAAP and non-GAAP tax rates are both expected to be 8 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis.

[0001045810-20-000145:8k_2_02:24]
Highlights

[0001045810-20-000145:8k_2_02:25]
Since its previous earnings report, NVIDIA has achieved progress in these areas:

[0001045810-20-000145:8k_2_02:26]
Data Center

[0001045810-20-000145:8k_2_02:27]
•Second-quarter revenue, which included Mellanox, was $1.75 billion, up 54 percent from the previous quarter and up 167 percent from a year earlier.

[0001045810-20-000145:8k_2_02:28]
•Announced, together with the world’s leading server makers, more than 50 NVIDIA® A100-powered systems to tackle the most complex challenges in AI, data science and scientific computing.

[0001045810-20-000145:8k_2_02:29]
•Powered eight of the top 10, and two-thirds of the total systems, on the latest TOP500 list of the world’s fastest supercomputers. This includes NVIDIA Selene, an NVIDIA DGX SuperPOD™ system, which ranked No. 7 on the list and was No. 2 on the Green500 list.

[0001045810-20-000145:8k_2_02:30]
•Set 16 AI performance records on the latest MLPerf benchmarks, eight on a per-chip basis based on the A100 Tensor Core GPU and eight “at scale” using the DGX A100 SuperPOD system.

[0001045810-20-000145:8k_2_02:31]
•Made the NVIDIA A100 Tensor Core GPU available on Google Cloud just over a month after its introduction.

[0001045810-20-000145:8k_2_02:32]
•Provided CUDA GPU-acceleration for Apache Spark, the world’s most popular data analytics application, through the general availability release of Spark 3.0.

[0001045810-20-000145:8k_2_02:33]
•Unveiled the NVIDIA Mellanox® UFM Cyber-AI Platform, which minimizes downtime in supercomputing data centers by detecting security threats and operational issues and predicting network failures.

[0001045810-20-000145:8k_2_02:34]
Gaming

[0001045810-20-000145:8k_2_02:35]
•Second-quarter revenue was $1.65 billion, up 24 percent from the previous quarter and up 26 percent from a year earlier.

[0001045810-20-000145:8k_2_02:36]
•Ramped 100+ new GeForce laptops to deliver outstanding performance to students, creators and gamers across a range of price points.

[0001045810-20-000145:8k_2_02:37]
•Announced a range of games now supporting NVIDIA RTX ray tracing and DLSS AI super resolution, including, Justice, Cyberpunk 2077 and Death Stranding. Introduced new worlds for Minecraft with RTX.

[0001045810-20-000145:8k_2_02:38]
•Expanded GeForce NOW™ to Chromebooks, enabling millions of users to play games in the cloud.

[0001045810-20-000145:8k_2_02:39]
•Announced that Square Enix is adding its extensive catalog to GeForce NOW, including franchises such as Deus Ex and Just Cause, plus Shadow of the Tomb Raider, which returned with RTX On.

[0001045810-20-000145:8k_2_02:40]
Professional Visualization

[0001045810-20-000145:8k_2_02:41]
•Second-quarter revenue was $203 million, down 34 percent from the previous quarter and down 30 percent from a year earlier.

[0001045810-20-000145:8k_2_02:42]
•Launched with Acer, Dell, Lenovo and Microsoft new mobile workstations for professional creators, based on NVIDIA Quadro® graphics. Powered new AI features in the latest releases of Substance Alchemist and Blender, improving material creation and incorporating AI denoising.

[0001045810-20-000145:8k_2_02:43]
•Announced that NVIDIA RTX™ has been implemented in the latest application releases from Foundry, Chaos Group and Redshift by Maxon, giving creators access to faster ray tracing and accelerated performance.

[0001045810-20-000145:8k_2_02:44]
•Released NVIDIA Quadro View™, the latest application in the NVIDIA Quadro Experience platform, which aids in streamlining workflows with a suite of desktop management tools.

[0001045810-20-000145:8k_2_02:45]
Automotive

[0001045810-20-000145:8k_2_02:46]
•Second-quarter revenue was $111 million, down 28 percent from the previous quarter and down 47 percent from a year earlier.

[0001045810-20-000145:8k_2_02:47]
•Announced with Mercedes-Benz that the carmaker is integrating into every vehicle in its lineup, beginning in 2024, a new software-defined vehicle architecture that is perpetually upgradeable and built on the NVIDIA DRIVE AV autonomous driving software and NVIDIA AGX Orin™ AV computer.

[0001045810-20-000145:8k_2_02:48]
CFO Commentary

[0001045810-20-000145:8k_2_02:49]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-20-000145:8k_2_02:50]
Conference Call and Webcast Information

[0001045810-20-000145:8k_2_02:51]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2021 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2021.

[0001045810-20-000145:8k_2_02:52]
Non-GAAP Measures

[0001045810-20-000145:8k_2_02:53]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-

[0001045810-20-000145:8k_2_02:54]
GAAP income from operations, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, legal settlement costs, losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchase of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-20-000145:8k_2_02:55]
About NVIDIA

[0001045810-20-000145:8k_2_02:56]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI ― the next era of computing ― with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-20-000145:8k_2_02:57]
###

[0001045810-20-000145:8k_2_02:58]
For further information, contact:

[0001045810-20-000145:8k_2_02:59]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-20-000145:8k_2_02:60]
Certain statements in this press release including, but not limited to, statements as to: the adoption of computing accelerating and it driving revenue and growth; growth in gaming and NVIDIA Networking; Ampere sprinting out of the blocks; top cloud service providers and server makers moving to offer NVIDIA accelerated computing; our partnership with Mercedes-Benz powering the next generation of luxury cars and being transformative; the pandemic’s impact; our position for growth; gaming, AI, cloud computing and autonomous machines driving the next industrial revolution; NVIDIA’s capital return program; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the third quarter of fiscal 2021; NVIDIA’s expected tax rates for the third quarter of fiscal 2021; NVIDIA’s expectation to generate variability from excess tax benefits or deficiencies; the benefits, abilities and impact of our products and technologies, including our Ampere GPU architecture, Spark 3.0, GeForce, NVIDIA Quadro and Quadro View; the supercomputers our products power; setting AI performance records; NVIDIA Mellanox UFM Cyber-AI Platform minimizing downtime in supercomputing data centers; the games supporting NVIDIA features; Square Enix adding its catalog to GeForce NOW and their features; powering AI features in Substance Alchemist and Blender and the improvements in AI denoising; NVIDIA RTX being added to applications and giving creators access to faster ray tracing and accelerated performance; and starting in 2024, Mercedes-Benz integrating into every vehicle in its lineup a software-defined architecture based on NVIDIA technology, are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-20-000145:8k_2_02:61]
© 2020 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, Quadro, DRIVE AGX Orin, GeForce NOW, Mellanox, NVIDIA A100, NVIDIA AGX, NVIDIA DGX A100, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA RAPIDS, NVIDIA RTX and Quadro View are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-20-000145:8k_2_02:62]
NVIDIA CORPORATION

[0001045810-20-000145:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-20-000145:8k_2_02:64]
(In millions, except per share data)

[0001045810-20-000145:8k_2_02:65]
(Unaudited)

[0001045810-20-000145:8k_2_02:66]
|  |  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  |  |  | July 26, |  | July 28, |  | July 26, |  | July 28, |
|  |  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue |  |  | $ | 3,866 |  |  | $ | 2,579 |  |  | $ | 6,946 |  |  | $ | 4,799 |  |
| Cost of revenue |  |  | 1,591 |  |  | 1,038 |  |  | 2,667 |  |  | 1,962 |  |
| Gross profit |  |  | 2,275 |  |  | 1,541 |  |  | 4,279 |  |  | 2,837 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |
|  | Research and development |  | 997 |  |  | 704 |  |  | 1,732 |  |  | 1,379 |  |
|  | Sales, general and administrative |  | 627 |  |  | 266 |  |  | 920 |  |  | 529 |  |
|  |  | Total operating expenses | 1,624 |  |  | 970 |  |  | 2,652 |  |  | 1,908 |  |
| Income from operations |  |  | 651 |  |  | 571 |  |  | 1,627 |  |  | 929 |  |
|  | Interest income |  | 13 |  |  | 47 |  |  | 44 |  |  | 92 |  |
|  | Interest expense |  | (54) |  |  | (13) |  |  | (78) |  |  | (27) |  |
|  | Other, net |  | (1) |  |  | 1 |  |  | (2) |  |  | 1 |  |
|  |  | Other income (expense), net | (42) |  |  | 35 |  |  | (36) |  |  | 66 |  |
| Income before income tax |  |  | 609 |  |  | 606 |  |  | 1,591 |  |  | 995 |  |
| Income tax expense (benefit) |  |  | (13) |  |  | 54 |  |  | 52 |  |  | 48 |  |
| Net income |  |  | $ | 622 |  |  | $ | 552 |  |  | $ | 1,539 |  |  | $ | 947 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
|  | Basic |  | $ | 1.01 |  |  | $ | 0.91 |  |  | $ | 2.50 |  |  | $ | 1.56 |  |
|  | Diluted |  | $ | 0.99 |  |  | $ | 0.90 |  |  | $ | 2.47 |  |  | $ | 1.54 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |  |  |
|  | Basic |  | 616 |  |  | 609 |  |  | 615 |  |  | 608 |  |
|  | Diluted |  | 626 |  |  | 616 |  |  | 624 |  |  | 616 |  |

[0001045810-20-000145:8k_2_02:67]
| NVIDIA CORPORATION |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |  |  |  |
| (In millions) |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |
|  |  |  |  | July 26, |  | January 26, |
|  |  |  |  | 2020 |  | 2020 |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  |  | $ | 10,981 |  |  | $ | 10,897 |  |
|  | Accounts receivable, net |  |  | 2,084 |  |  | 1,657 |  |
|  | Inventories |  |  | 1,401 |  |  | 979 |  |
|  | Prepaid expenses and other current assets |  |  | 215 |  |  | 157 |  |
|  |  | Total current assets |  | 14,681 |  |  | 13,690 |  |
| Property and equipment, net |  |  |  | 1,964 |  |  | 1,674 |  |
| Operating lease assets |  |  |  | 701 |  |  | 618 |  |
| Goodwill |  |  |  | 4,193 |  |  | 618 |  |
| Intangible assets, net |  |  |  | 2,854 |  |  | 49 |  |
| Deferred income tax assets |  |  |  | 630 |  |  | 548 |  |
| Other assets |  |  |  | 157 |  |  | 118 |  |
|  |  | Total assets |  | $ | 25,180 |  |  | $ | 17,315 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
|  | Accounts payable |  |  | $ | 893 |  |  | $ | 687 |  |
|  | Accrued and other current liabilities |  |  | 1,517 |  |  | 1,097 |  |
|  |  | Total current liabilities |  | 2,410 |  |  | 1,784 |  |
| Long-term debt |  |  |  | 6,960 |  |  | 1,991 |  |
| Long-term operating lease liabilities |  |  |  | 611 |  |  | 561 |  |
| Other long-term liabilities |  |  |  | 1,285 |  |  | 775 |  |
|  |  | Total liabilities |  | 11,266 |  |  | 5,111 |  |
| Shareholders' equity |  |  |  | 13,914 |  |  | 12,204 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 25,180 |  |  | $ | 17,315 |  |

[0001045810-20-000145:8k_2_02:68]
| NVIDIA CORPORATION |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |  |  |  |  |
| (In millions) |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26, |  | July 28, |  | July 26, |  | July 28, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 622 |  |  | $ | 552 |  |  | $ | 1,539 |  |  | $ | 947 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 404 |  |  | 92 |  |  | 511 |  |  | 183 |  |
| Stock-based compensation expense | 374 |  |  | 223 |  |  | 598 |  |  | 401 |  |
| Deferred income taxes | (80) |  |  | 15 |  |  | (64) |  |  | (27) |  |
| Other | (8) |  |  | 4 |  |  | (5) |  |  | 1 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | 44 |  |  | (319) |  |  | (205) |  |  | (137) |  |
| Inventories | 54 |  |  | 225 |  |  | (97) |  |  | 378 |  |
| Prepaid expenses and other assets | 42 |  |  | 31 |  |  | 34 |  |  | 36 |  |
| Accounts payable | (8) |  |  | 78 |  |  | 63 |  |  | (45) |  |
| Accrued and other current liabilities | 112 |  |  | 49 |  |  | 81 |  |  | (79) |  |
| Other long-term liabilities | 10 |  |  | (14) |  |  | 21 |  |  | (2) |  |
| Net cash provided by operating activities | 1,566 |  |  | 936 |  |  | 2,476 |  |  | 1,656 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 1,032 |  |  | 1,372 |  |  | 1,032 |  |  | 3,592 |  |
| Proceeds from sales of marketable securities | 258 |  |  | 3,126 |  |  | 259 |  |  | 3,152 |  |
| Purchases of marketable securities | (7,425) |  |  | (840) |  |  | (8,286) |  |  | (1,461) |  |
| Acquisition of businesses, net of cash acquired | (7,137) |  |  | — |  |  | (7,171) |  |  | — |  |
| Purchases of property and equipment and intangible assets | (217) |  |  | (113) |  |  | (372) |  |  | (241) |  |
| Investments and other, net | — |  |  | (2) |  |  | (7) |  |  | (2) |  |
| Net cash provided by (used in) investing activities | (13,489) |  |  | 3,543 |  |  | (14,545) |  |  | 5,040 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 6 |  |  | 1 |  |  | 94 |  |  | 83 |  |
| Payments related to tax on restricted stock units | (196) |  |  | (50) |  |  | (418) |  |  | (261) |  |
| Dividends paid | (99) |  |  | (97) |  |  | (197) |  |  | (195) |  |
| Issuance of debt, net of issuance costs | (8) |  |  | — |  |  | 4,971 |  |  | — |  |
| Other | — |  |  | — |  |  | (3) |  |  | — |  |
| Net cash provided by (used in) financing activities | (297) |  |  | (146) |  |  | 4,447 |  |  | (373) |  |
| Change in cash and cash equivalents | (12,220) |  |  | 4,333 |  |  | (7,622) |  |  | 6,323 |  |
| Cash and cash equivalents at beginning of period | 15,494 |  |  | 2,772 |  |  | 10,896 |  |  | 782 |  |
| Cash and cash equivalents at end of period | $ | 3,274 |  |  | $ | 7,105 |  |  | $ | 3,274 |  |  | $ | 7,105 |  |

[0001045810-20-000145:8k_2_02:69]
|  | NVIDIA CORPORATION |  |  |  |  |  |  |  |  |  |  |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |  |  |  |  |  |  |  |  |  |  |
|  | (In millions, except per share data) |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |
|  |  |  | July 26, |  | April 26, |  | July 28, |  | July 26, |  | July 28, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP gross profit |  |  | $ | 2,275 |  |  | $ | 2,004 |  |  | $ | 1,541 |  |  | $ | 4,279 |  |  | $ | 2,837 |  |
| GAAP gross margin |  |  | 58.8 | % |  | 65.1 | % |  | 59.8 | % |  | 61.6 | % |  | 59.1 | % |
|  | Stock-based compensation expense (A) |  | 14 |  |  | 21 |  |  | 8 |  |  | 35 |  |  | 12 |  |
|  | Acquisition-related and other costs (B) |  | 245 |  |  | 1 |  |  | — |  |  | 246 |  |  | — |  |
|  | Legal settlement costs |  | 17 |  |  | — |  |  | 2 |  |  | 17 |  |  | 11 |  |
| Non-GAAP gross profit |  |  | $ | 2,551 |  |  | $ | 2,026 |  |  | $ | 1,551 |  |  | $ | 4,577 |  |  | $ | 2,860 |  |
| Non-GAAP gross margin |  |  | 66.0 | % |  | 65.8 | % |  | 60.1 | % |  | 65.9 | % |  | 59.6 | % |
| GAAP operating expenses |  |  | $ | 1,624 |  |  | $ | 1,028 |  |  | $ | 970 |  |  | $ | 2,652 |  |  | $ | 1,908 |  |
|  | Stock-based compensation expense (A) |  | (360) |  |  | (203) |  |  | (216) |  |  | (563) |  |  | (389) |  |
|  | Acquisition-related and other costs (B) |  | (229) |  |  | (4) |  |  | (5) |  |  | (233) |  |  | (15) |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | (2) |  |
| Non-GAAP operating expenses |  |  | $ | 1,035 |  |  | $ | 821 |  |  | $ | 749 |  |  | $ | 1,856 |  |  | $ | 1,502 |  |
| GAAP income from operations |  |  | $ | 651 |  |  | $ | 976 |  |  | $ | 571 |  |  | $ | 1,627 |  |  | $ | 929 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 865 |  |  | 229 |  |  | 231 |  |  | 1,094 |  |  | 429 |  |
| Non-GAAP income from operations |  |  | $ | 1,516 |  |  | $ | 1,205 |  |  | $ | 802 |  |  | $ | 2,721 |  |  | $ | 1,358 |  |
| GAAP other income (expense), net |  |  | $ | (42) |  |  | $ | 5 |  |  | $ | 35 |  |  | $ | (36) |  |  | $ | 66 |  |
|  | Losses from non-affiliated investments |  | 2 |  |  | 3 |  |  | — |  |  | 5 |  |  | — |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Non-GAAP other income (expense), net |  |  | $ | (39) |  |  | $ | 9 |  |  | $ | 35 |  |  | $ | (30) |  |  | $ | 67 |  |
| GAAP net income |  |  | $ | 622 |  |  | $ | 917 |  |  | $ | 552 |  |  | $ | 1,539 |  |  | $ | 947 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 868 |  |  | 232 |  |  | 231 |  |  | 1,100 |  |  | 430 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (124) |  |  | (29) |  |  | (21) |  |  | (153) |  |  | (72) |  |
| Non-GAAP net income |  |  | $ | 1,366 |  |  | $ | 1,120 |  |  | $ | 762 |  |  | $ | 2,486 |  |  | $ | 1,305 |  |

[0001045810-20-000145:8k_2_02:70]
|  |  |  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |
|  |  |  | July 26, |  | April 26, |  | July 28, |  | July 26, |  | July 28, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.99 |  |  | $ | 1.47 |  |  | $ | 0.90 |  |  | $ | 2.47 |  |  | $ | 1.54 |  |
|  | Non-GAAP |  | $ | 2.18 |  |  | $ | 1.80 |  |  | $ | 1.24 |  |  | $ | 3.98 |  |  | $ | 2.12 |  |
| Weighted average shares used in diluted net income per share computation |  |  | 626 |  |  | 622 |  |  | 616 |  |  | 624 |  | 616 |
| GAAP net cash provided by operating activities |  |  | $ | 1,566 |  |  | $ | 909 |  |  | $ | 936 |  |  | $ | 2,476 |  |  | $ | 1,656 |  |
|  | Purchase of property and equipment and intangible assets |  | (217) |  |  | (155) |  |  | (113) |  |  | (372) |  |  | (241) |  |
| Free cash flow |  |  | $ | 1,349 |  |  | $ | 754 |  |  | $ | 823 |  |  | $ | 2,104 |  |  | $ | 1,415 |  |

[0001045810-20-000145:8k_2_02:71]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |
|  |  |  | July 26, |  | April 26, |  | July 28, |  | July 26, |  | July 28, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | Cost of revenue |  | $ | 14 |  |  | $ | 21 |  |  | $ | 8 |  |  | $ | 35 |  |  | $ | 12 |  |
|  | Research and development |  | $ | 228 |  |  | $ | 134 |  |  | $ | 145 |  |  | $ | 362 |  |  | $ | 259 |  |
|  | Sales, general and administrative |  | $ | 132 |  |  | $ | 69 |  |  | $ | 71 |  |  | $ | 201 |  |  | $ | 130 |  |
| (B) Acquisition-related and other costs primarily include amortization of intangible assets, inventory step-up, transaction costs, and certain compensation charges. |  |  |  |  |  |  |  |  |  |  |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |  |  |  |  |  |  |  |  |  |  |

[0001045810-20-000145:8k_2_02:72]
| NVIDIA CORPORATION |  |  |  |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |  |  |  |
|  |  |  | Q3 FY2021 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  |  | 62.5 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs |  | 3.0 | % |
| Non-GAAP gross margin |  |  | 65.5 | % |
| GAAP operating expenses |  |  | $ | 1,535 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (445) |  |
| Non-GAAP operating expenses |  |  | $ | 1,090 |  |
