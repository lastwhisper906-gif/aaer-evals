# NVDA MD&A — 0001045810-20-000147


## mdna

[0001045810-20-000147:mdna:1]
[same as prior period, unchanged from 0001045810-20-000065:mdna:1]

[0001045810-20-000147:mdna:2]
[same as prior period, unchanged from 0001045810-20-000065:mdna:2]

[0001045810-20-000147:mdna:3]
[same as prior period, unchanged from 0001045810-20-000065:mdna:3]

[0001045810-20-000147:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, DRIVE AGX Orin, GeForce NOW, GeForce RTX SUPER, NVIDIA A100, NVIDIA CUDA, NVIDIA DGX A100, NVIDIA DRIVE, NVIDIA GRID, NVIDIA Jarvis, NVIDIA Merlin, NVIDIA RTX, Mellanox, Quadro, Quadro RTX, Quadro View and Tegra are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-20-000147:mdna:5]
[same as prior period, unchanged from 0001045810-20-000065:mdna:5]

[0001045810-20-000147:mdna:6]
[same as prior period, unchanged from 0001045810-20-000065:mdna:6]

[0001045810-20-000147:mdna:7]
[same as prior period, unchanged from 0001045810-20-000065:mdna:7]

[0001045810-20-000147:mdna:8]
[same as prior period, unchanged from 0001045810-20-000065:mdna:8]

[0001045810-20-000147:mdna:9]
[same as prior period, unchanged from 0001045810-20-000065:mdna:9]

[0001045810-20-000147:mdna:10]
[same as prior period, unchanged from 0001045810-20-000065:mdna:10]

[0001045810-20-000147:mdna:11]
Our Compute & Networking segment includes Data Center platforms and systems for AI, HPC, and accelerated computing; Mellanox networking and interconnect solutions; DRIVE for autonomous vehicles; and Jetson for robotics and other embedded platforms.

[0001045810-20-000147:mdna:12]
All prior period comparisons presented reflect our new reportable segments. Our market platforms – Gaming, Professional Visualization, Data Center, Automotive, OEM and Other – remain unchanged.

[0001045810-20-000147:mdna:13]
[same as prior period, unchanged from 0001045810-20-000065:mdna:13]

[0001045810-20-000147:mdna:14]
27

[0001045810-20-000147:mdna:15]
[same as prior period, unchanged from 0001045810-20-000065:mdna:15]

[0001045810-20-000147:mdna:16]
[same as prior period, unchanged from 0001045810-20-000065:mdna:16]

[0001045810-20-000147:mdna:17]
The coronavirus identified in late calendar year 2019 (COVID-19) continues to be a worldwide pandemic. Government authorities around the world have implemented measures to try to contain the disease, such as travel bans and restrictions, quarantines, shelter-in-place orders and shutdowns. Since March 2020, most of our employees have been working remotely and we have temporarily prohibited most business travel.

[0001045810-20-000147:mdna:18]
Our employees and partners are performing above and beyond to keep our supply chain functioning normally. Many industries we serve are adversely impacted, including higher education research, energy, manufacturing, automotive, architecture, engineering, and media. Each industry is recovering, albeit at different rates. Professional Visualization revenue was negatively affected as corporate customers delayed spending on workstations. Automotive production is well below pre-COVID-19 levels.

[0001045810-20-000147:mdna:19]
The full extent and duration of COVID-19 is uncertain. As the COVID-19 pandemic continues, the timing and overall demand from customers and the availability of supply chain, logistical services and component supply may have a material net negative impact on our business and financial results. Refer to Part II, Item 1A of this Quarterly Report on Form 10-Q for additional information under the heading “Risk Factors”.

[0001045810-20-000147:mdna:20]
The Company believes its existing balances of cash, cash equivalents and marketable securities, along with commercial paper and other short-term liquidity arrangements, will be sufficient to satisfy its working capital needs, capital asset purchases, dividends, debt repayments and other liquidity requirements associated with its existing operations.

[0001045810-20-000147:mdna:21]
Second Quarter of Fiscal Year 2021 Summary

[0001045810-20-000147:mdna:22]
|  | Three Months Ended |  |  |  |  |  |  |  |  |
|  | July 26, 2020 |  | April 26, 2020 |  | July 28, 2019 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |  |  |  |  |
| Revenue | $ | 3,866 |  |  | $ | 3,080 |  |  | $ | 2,579 |  |  | 26 | % |  | 50 | % |
| Gross margin | 58.8 | % |  | 65.1 | % |  | 59.8 | % |  | (630) bps |  | (100) bps |
| Operating expenses | $ | 1,624 |  |  | $ | 1,028 |  |  | $ | 970 |  |  | 58 | % |  | 67 | % |
| Income from operations | $ | 651 |  |  | $ | 976 |  |  | $ | 571 |  |  | (33) | % |  | 14 | % |
| Net income | $ | 622 |  |  | $ | 917 |  |  | $ | 552 |  |  | (32) | % |  | 13 | % |
| Net income per diluted share | $ | 0.99 |  |  | $ | 1.47 |  |  | $ | 0.90 |  |  | (33) | % |  | 10 | % |

[0001045810-20-000147:mdna:23]
Revenue for the second quarter of fiscal year 2021 was $3.87 billion, up 50% from a year earlier and up 26% sequentially. Results for the second quarter include the acquisition of Mellanox on April 27, 2020, the first day of the quarter. Mellanox contributed approximately 14% of total company revenue.

[0001045810-20-000147:mdna:24]
Graphics segment revenue for the second quarter was $2.09 billion, up 16% from a year earlier and up 9% sequentially.

[0001045810-20-000147:mdna:25]
Compute & Networking segment revenue, which includes Mellanox, was $1.78 billion, up 130% from a year ago and up 52% sequentially.

[0001045810-20-000147:mdna:26]
From a market-platform perspective, Gaming revenue was $1.65 billion, up 26% from a year ago and up 24% sequentially. The year-on-year increase reflects higher sales of gaming GPUs. The sequential increase reflects higher sales from gaming GPUs and game console SOCs.

[0001045810-20-000147:mdna:27]
Professional Visualization revenue was $203 million, down 30% from a year earlier and down 34% sequentially.

[0001045810-20-000147:mdna:28]
Data Center revenue, which includes Mellanox, was $1.75 billion, up 167% from a year ago and up 54% sequentially. Mellanox contributed approximately 14% of total company revenue and just over 30% of Data Center revenue for the second quarter. In addition to Mellanox, the year-on-year and sequential increases were driven by the ramp of Ampere GPU architecture products.

[0001045810-20-000147:mdna:29]
Automotive revenue was $111 million, down 47% from a year earlier and down 28% sequentially.

[0001045810-20-000147:mdna:30]
OEM and Other revenue was $146 million, up 32% from a year ago and up 6% sequentially, primarily due to higher demand for entry-level laptop GPUs.

[0001045810-20-000147:mdna:31]
Gross margin for the second quarter of fiscal year 2021 was 58.8%, down 100 basis points from a year earlier and down 630 basis points sequentially, reflecting charges related to the Mellanox acquisition. These include a non-recurring inventory step-up expense of $161 million and intangible asset amortization of $84 million that is expected to be recurring.

[0001045810-20-000147:mdna:32]
Operating expenses for the second quarter of fiscal year 2021 were $1.62 billion, up 67% from a year earlier and up 58% sequentially, primarily driven by our Mellanox acquisition, as well as hiring additional employees.

[0001045810-20-000147:mdna:33]
Income from operations for the second quarter of fiscal year 2021 was $651 million, up 14% from a year earlier and down 33% sequentially. Net income for the second quarter of fiscal year 2021 was $622 million. Net income per diluted share for the second quarter of fiscal year 2021 was $0.99, up 10% from a year earlier and down 33% sequentially.

[0001045810-20-000147:mdna:34]
Cash, cash equivalents and marketable securities at the end of the second quarter were $10.98 billion, up from $8.47 billion a year earlier and down from $16.35 billion in the prior quarter. The year-on-year increase primarily reflects the issuance of the $5 billion of notes in March 2020, offset by acquisitions. The sequential decrease reflects the Mellanox acquisition during the second quarter.

[0001045810-20-000147:mdna:35]
We paid $99 million in quarterly cash dividends in the second quarter.

[0001045810-20-000147:mdna:36]
[same as prior period, unchanged from 0001045810-20-000065:mdna:37]

[0001045810-20-000147:mdna:37]
During the second quarter of fiscal year 2021, in our Gaming platform, we ramped 100+ new GeForce laptops across a range of price points; announced a range of games now supporting NVIDIA RTX ray tracing and DLSS AI super resolution; expanded GeForce NOW to Chromebooks; and announced that Square Enix is adding its catalog to GeForce NOW.

[0001045810-20-000147:mdna:38]
In our Professional Visualization platform, we launched with Acer, Dell, Lenovo and Microsoft new mobile workstations for professional creators, based on NVIDIA Quadro graphics; powered new AI features in the latest releases of Substance Alchemist and Blender; announced that NVIDIA RTX has been implemented in the latest application releases from Foundry, Chaos Group and Redshift by Maxon; and released NVIDIA Quadro View.

[0001045810-20-000147:mdna:39]
In our Data Center platform, we announced more than 50 NVIDIA A100-powered systems; powered eight of the 10, and two-thirds of the total systems, on the latest TOP500 list of the world’s fastest supercomputers; set 16 AI performance records on the latest MLPerf benchmarks; made the NVIDIA A100 Tensor Core GPU available on Google Cloud; provided CUDA GPU-acceleration for Apache Spark; and unveiled the NVIDIA Mellanox UFM Cyber-AI Platform.

[0001045810-20-000147:mdna:40]
In our Automotive platform, we announced with Mercedes-Benz that the carmaker is integrating into every vehicle in its lineup, beginning in 2024, a new software-defined vehicle architecture built on the NVIDIA DRIVE AV autonomous driving software and AGX Orin AV computer.

[0001045810-20-000147:mdna:41]
[same as prior period, unchanged from 0001045810-20-000065:mdna:38]

[0001045810-20-000147:mdna:42]
[same as prior period, unchanged from 0001045810-20-000065:mdna:39]

[0001045810-20-000147:mdna:43]
[same as prior period, unchanged from 0001045810-20-000065:mdna:40]

[0001045810-20-000147:mdna:44]
[same as prior period, unchanged from 0001045810-20-000065:mdna:41]

[0001045810-20-000147:mdna:45]
[same as prior period, unchanged from 0001045810-20-000065:mdna:42]

[0001045810-20-000147:mdna:46]
Critical Accounting Policies and Estimates

[0001045810-20-000147:mdna:47]
Management’s discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments

[0001045810-20-000147:mdna:48]
29

[0001045810-20-000147:mdna:49]
that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Our management has discussed the development and selection of these critical accounting policies and estimates with the Audit Committee of our Board of Directors. The Audit Committee has reviewed our disclosures relating to our critical accounting policies and estimates in this Quarterly Report on Form 10-Q. Due to the Mellanox acquisition, we added the following critical accounting policy:

[0001045810-20-000147:mdna:50]
Business Combinations

[0001045810-20-000147:mdna:51]
The application of acquisition accounting to a business acquisition requires that we identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the purchase price are based upon preliminary estimates and assumptions and subject to revision when we receive final information, including appraisals and other analysis. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. We will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0001045810-20-000147:mdna:52]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. We recognize the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, order backlog and trade name acquired in a business combination and IPR&D. We generally assess the estimated fair values of acquired intangibles using a combination of valuation techniques. To estimate fair value, we are required to make certain estimates and assumptions, including future economic and market conditions, revenue growth, technology migration curve, and risk-adjusted discount rates. Our estimates require significant judgment and are based on historical data, various internal estimates, and external sources. Our assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0001045810-20-000147:mdna:53]
There have been no other material changes in our critical accounting policies and estimates since our Annual Report on Form 10-K for the fiscal year ended January 26, 2020. Refer to Note 1 “Basis of Presentation” to the condensed consolidated financial statements for additional details. In addition, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended January 26, 2020 for a more complete discussion of our critical accounting policies and estimates.

[0001045810-20-000147:mdna:54]
30

[0001045810-20-000147:mdna:55]
[same as prior period, unchanged from 0001045810-20-000065:mdna:44]

[0001045810-20-000147:mdna:56]
[same as prior period, unchanged from 0001045810-20-000065:mdna:45]

[0001045810-20-000147:mdna:57]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 26,2020 |  | July 28,2019 |  | July 26,2020 |  | July 28,2019 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 41.2 |  |  | 40.2 |  |  | 38.4 |  |  | 40.9 |  |
| Gross profit | 58.8 |  |  | 59.8 |  |  | 61.6 |  |  | 59.1 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 25.8 |  |  | 27.3 |  |  | 24.9 |  |  | 28.7 |  |
| Sales, general and administrative | 16.2 |  |  | 10.3 |  |  | 13.3 |  |  | 11.0 |  |
| Total operating expenses | 42.0 |  |  | 37.6 |  |  | 38.2 |  |  | 39.7 |  |
| Income from operations | 16.8 |  |  | 22.2 |  |  | 23.4 |  |  | 19.4 |  |
| Interest income | 0.3 |  |  | 1.8 |  |  | 0.6 |  |  | 1.9 |  |
| Interest expense | (1.4) |  |  | (0.5) |  |  | (1.1) |  |  | (0.6) |  |
| Other income (expense), net | (1.1) |  |  | 1.3 |  |  | (0.5) |  |  | 1.3 |  |
| Income before income tax | 15.7 |  |  | 23.5 |  |  | 22.9 |  |  | 20.7 |  |
| Income tax expense (benefit) | (0.3) |  |  | 2.1 |  |  | 0.7 |  |  | 1.0 |  |
| Net income | 16.0 | % |  | 21.4 | % |  | 22.2 | % |  | 19.7 | % |

[0001045810-20-000147:mdna:58]
[same as prior period, unchanged from 0001045810-20-000065:mdna:47]

[0001045810-20-000147:mdna:59]
[same as prior period, unchanged from 0001045810-20-000065:mdna:48]

[0001045810-20-000147:mdna:60]
|  | Three Months Ended |  |  |  |  |  |  |  | Six Months Ended |  |  |  |  |  |  |
|  | July 26,2020 |  | July 28,2019 |  | $Change |  | %Change |  | July 26,2020 |  | July 28,2019 |  | $Change |  | %Change |
|  | ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Graphics | $ | 2,085 |  |  | $ | 1,803 |  |  | $ | 282 |  |  | 16 | % |  | $ | 3,991 |  |  | $ | 3,329 |  |  | $ | 662 |  |  | 20 | % |
| Compute & Networking | 1,781 |  |  | 776 |  |  | 1,005 |  |  | 130 | % |  | 2,955 |  |  | 1,470 |  |  | 1,485 |  |  | 101 | % |
| Total | $ | 3,866 |  |  | $ | 2,579 |  |  | $ | 1,287 |  |  | 50 | % |  | $ | 6,946 |  |  | $ | 4,799 |  |  | $ | 2,147 |  |  | 45 | % |

[0001045810-20-000147:mdna:61]
Graphics - Graphics segment revenue increased 16% in the second quarter of fiscal year 2021 compared to the second quarter of fiscal year 2020, which reflects growth in GeForce GPUs for gaming, partially offset by lower sales of Quadro workstations and game console SOCs.

[0001045810-20-000147:mdna:62]
Graphics segment revenue increased 20% in the first half of fiscal year 2021 compared to the first half of fiscal year 2020, which reflects growth in GeForce GPUs for gaming, game console SOCs, and Quadro workstations.

[0001045810-20-000147:mdna:63]
Compute & Networking - Compute & Networking segment revenue for the second quarter of fiscal year 2021 compared to the second quarter of fiscal year 2020 increased by 130% and revenue for the first half of fiscal year 2021 compared to the first half of fiscal year 2020 increased by 101%. These increases reflect the addition of Mellanox acquired on April 27, 2020 and the ramp of Ampere GPU architecture products, partially offset by lower autonomous driving development agreement revenue.

[0001045810-20-000147:mdna:64]
[same as prior period, unchanged from 0001045810-20-000065:mdna:52]

[0001045810-20-000147:mdna:65]
Revenue from sales to customers outside of the United States accounted for 76% and 79% of total revenue for the second quarter and first half of fiscal year 2021, respectively, and 93% of total revenue for the second quarter and first

[0001045810-20-000147:mdna:66]
half of fiscal year 2020. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-20-000147:mdna:67]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal year 2021. One customer represented 11% of our total revenue for the second quarter and the first half of fiscal year 2020 and was attributable primarily to the Graphics segment.

[0001045810-20-000147:mdna:68]
[same as prior period, unchanged from 0001045810-20-000065:mdna:56]

[0001045810-20-000147:mdna:69]
Our overall gross margin decreased to 58.8% for the second quarter of fiscal year 2021 from 59.8% for the second quarter of fiscal year 2020, reflecting Mellanox acquisition-related costs including a non-recurring inventory step-up charge of $161 million and ongoing intangible asset amortization of $84 million, partially offset by an increase due to a shift in product mix. Our overall gross margin increased to 61.6% for the first half of fiscal year 2021 from 59.1% for the first half of fiscal year 2020, primarily driven by a shift in product mix, partially offset by Mellanox acquisition-related costs including a non-recurring inventory step-up charge of $161 million and ongoing intangible asset amortization of $85 million.

[0001045810-20-000147:mdna:70]
Inventory provisions totaled $45 million and $28 million for the second quarter of fiscal years 2021 and 2020, respectively. Sales of inventory that was previously written-off or -down totaled $49 million and $19 million for the second quarter of fiscal years 2021 and 2020, respectively. As a result, the overall net effect on our gross margin was insignificant in the second quarter of fiscal year 2021, and an unfavorable impact of 0.4% in the second quarter of fiscal year 2020.

[0001045810-20-000147:mdna:71]
Inventory provisions totaled $81 million and $72 million for the first half of fiscal years 2021 and 2020, respectively. Sales of inventory that was previously written-off or -down totaled $88 million and $31 million for the first half of fiscal years 2021 and 2020, respectively. As a result, the overall net effect on our gross margin was insignificant in the first half of fiscal year 2021 and an unfavorable impact of 0.9% for the first half of fiscal year 2020.

[0001045810-20-000147:mdna:72]
[same as prior period, unchanged from 0001045810-20-000065:mdna:59]

[0001045810-20-000147:mdna:73]
Graphics - The gross margin of our Graphics segment increased during the second quarter and first half of fiscal year 2021 compared to the second quarter and first half of fiscal year 2020, primarily driven by a shift in product mix.

[0001045810-20-000147:mdna:74]
Compute & Networking - The gross margin of our Compute & Networking segment decreased during the second quarter and first half of fiscal year 2021 compared to the second quarter and first half of fiscal year 2020, primarily driven by Mellanox acquisition-related costs, partially offset by higher data center sales.

[0001045810-20-000147:mdna:75]
[same as prior period, unchanged from 0001045810-20-000065:mdna:62]

[0001045810-20-000147:mdna:76]
|  | Three Months Ended |  |  |  |  |  |  |  | Six Months Ended |  |  |  |  |  |  |
|  | July 26,2020 |  | July 28,2019 |  | $Change |  | %Change |  | July 26,2020 |  | July 28,2019 |  | $Change |  | %Change |
|  | ($ in millions) |  |  |  |  |  |  |  | ($ in millions) |  |  |  |  |  |  |
| Research and development expenses | $ | 997 |  |  | $ | 704 |  |  | $ | 293 |  |  | 42 | % |  | $ | 1,732 |  |  | $ | 1,379 |  |  | $ | 353 |  |  | 26 | % |
| % of net revenue | 26 | % |  | 27 | % |  |  |  |  |  | 25 | % |  | 29 | % |  |  |  |  |
| Sales, general and administrative expenses | 627 |  |  | 266 |  |  | 361 |  |  | 136 | % |  | 920 |  |  | 529 |  |  | 391 |  |  | 74 | % |
| % of net revenue | 16 | % |  | 10 | % |  |  |  |  |  | 13 | % |  | 11 | % |  |  |  |  |
| Total operating expenses | $ | 1,624 |  |  | $ | 970 |  |  | $ | 654 |  |  | 67 | % |  | $ | 2,652 |  |  | $ | 1,908 |  |  | $ | 744 |  |  | 39 | % |

[0001045810-20-000147:mdna:77]
[same as prior period, unchanged from 0001045810-20-000065:mdna:64]

[0001045810-20-000147:mdna:78]
Research and development expenses increased by 42% and 26% during the second quarter and first half of fiscal year 2021, compared to the second quarter and first half of fiscal year 2020, respectively, primarily driven by expenses and

[0001045810-20-000147:mdna:79]
stock-based compensation related to the Mellanox acquisition. In addition to Mellanox, increases reflect employee compensation and related costs, including stock-based compensation and infrastructure costs.

[0001045810-20-000147:mdna:80]
[same as prior period, unchanged from 0001045810-20-000065:mdna:66]

[0001045810-20-000147:mdna:81]
Sales, general and administrative expenses increased by 136% and 74% during the second quarter and first half of fiscal year 2021, compared to the second quarter of fiscal year 2020, respectively, primarily driven by Mellanox acquisition-related expenses. In addition to Mellanox, increases reflect employee compensation and related costs, including stock-based compensation and infrastructure costs.

[0001045810-20-000147:mdna:82]
Other Income (Expense), Net

[0001045810-20-000147:mdna:83]
[same as prior period, unchanged from 0001045810-20-000065:mdna:69]

[0001045810-20-000147:mdna:84]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $13 million and $47 million during the second quarter of fiscal years 2021 and 2020, respectively, and $44 million and $92 million during the first half of fiscal years 2021 and 2020, respectively. The decrease in interest income was primarily due to lower interest earned on our investments.

[0001045810-20-000147:mdna:85]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our September 2016 Notes and March 2020 Notes. Interest expense was $54 million and $13 million during the second quarter of fiscal years 2021 and 2020, respectively, and $78 million and $27 million during the first half of fiscal years 2021 and 2020, respectively.

[0001045810-20-000147:mdna:86]
[same as prior period, unchanged from 0001045810-20-000065:mdna:72]

[0001045810-20-000147:mdna:87]
We recognized an income tax benefit of $13 million and an income tax expense of $52 million for the second quarter and first half of fiscal year 2021, respectively, and an income tax expense of $54 million and $48 million for the second quarter and first half of fiscal year 2020, respectively. The income tax benefit as a percentage of income before income tax was 2.0% for the second quarter of fiscal year 2021. The income tax expense as a percentage of income before income tax was 3.3% for the first half of fiscal year 2021, and 8.8% and 4.9% for the second quarter and first half of fiscal year 2020, respectively.

[0001045810-20-000147:mdna:88]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2021 as compared to the same periods of fiscal year 2020 was primarily due to a decrease in the proportional amount of earnings subject to U.S. tax and an increase of tax benefits from stock-based compensation and the U.S. federal research tax credit.

[0001045810-20-000147:mdna:89]
[same as prior period, unchanged from 0001045810-20-000065:mdna:76]

[0001045810-20-000147:mdna:90]
[same as prior period, unchanged from 0001045810-20-000065:mdna:77]

[0001045810-20-000147:mdna:91]
|  | July 26, 2020 |  | January 26, 2020 |
|  | (In millions) |  |  |
| Cash and cash equivalents | $ | 3,274 |  |  | $ | 10,896 |  |
| Marketable securities | 7,707 |  |  | 1 |  |
| Cash, cash equivalents and marketable securities | $ | 10,981 |  |  | $ | 10,897 |  |

[0001045810-20-000147:mdna:92]
|  | Six Months Ended |  |  |
|  | July 26, 2020 |  | July 28, 2019 |
|  | (In millions) |  |  |
| Net cash provided by operating activities | $ | 2,476 |  |  | $ | 1,656 |  |
| Net cash provided by (used in) investing activities | $ | (14,545) |  |  | $ | 5,040 |  |
| Net cash provided by (used in) financing activities | $ | 4,447 |  |  | $ | (373) |  |

[0001045810-20-000147:mdna:93]
As of July 26, 2020, we had $10.98 billion in cash, cash equivalents and marketable securities, a decrease of $84 million from the end of fiscal year 2020. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-20-000147:mdna:94]
Cash provided by operating activities increased in the first half of fiscal year 2021 compared to the first half of fiscal year 2020, due to higher net income, partially offset by changes in working capital. Change in working capital was driven by an increase in inventory offset by inventory step-up expense from the Mellanox acquisition and changes in operating liabilities.

[0001045810-20-000147:mdna:95]
Cash used in investing activities increased in the first half of fiscal year 2021 compared to cash provided in the first half of fiscal year 2020, primarily reflects cash used for the acquisition of Mellanox, higher purchases of marketable securities, and lower maturities and sales of marketable securities.

[0001045810-20-000147:mdna:96]
Cash provided by financing activities increased in the first half of fiscal year 2021 compared to cash used in the first half of fiscal year 2020, primarily reflects the debt issued in the first quarter of fiscal year 2021.

[0001045810-20-000147:mdna:97]
[same as prior period, unchanged from 0001045810-20-000065:mdna:84]

[0001045810-20-000147:mdna:98]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of July 26, 2020, we had $10.98 billion in cash, cash equivalents and marketable securities. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and certificates of deposits. These marketable securities are denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information.  We believe that we have sufficient liquidity to meet our operating requirements and capital expenditures for at least the next twelve months.

[0001045810-20-000147:mdna:99]
We have approximately $857 million of cash, cash equivalents, and marketable securities that we have not accrued any related foreign or state taxes if we repatriate these amounts to the United States. Other than that, as a result of the Tax Cuts and Jobs Act, or TCJA, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of July 26, 2020 are available for use in the United States without incurring additional U.S. federal income taxes.

[0001045810-20-000147:mdna:100]
[same as prior period, unchanged from 0001045810-20-000065:mdna:87]

[0001045810-20-000147:mdna:101]
In the first half of fiscal year 2021, we paid $197 million in quarterly cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-20-000147:mdna:102]
As of July 26, 2020, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022. We did not repurchase any shares during the first half of fiscal year 2021.

[0001045810-20-000147:mdna:103]
[same as prior period, unchanged from 0001045810-20-000065:mdna:91]

[0001045810-20-000147:mdna:104]
[same as prior period, unchanged from 0001045810-20-000065:mdna:92]

[0001045810-20-000147:mdna:105]
[same as prior period, unchanged from 0001045810-20-000065:mdna:93]

[0001045810-20-000147:mdna:106]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 26, 2020, we had not borrowed any amounts under this agreement.

[0001045810-20-000147:mdna:107]
We have a $575 million commercial paper program to support general corporate purposes. As of July 26, 2020, we had not issued any commercial paper.

[0001045810-20-000147:mdna:108]
[same as prior period, unchanged from 0001045810-20-000065:mdna:96]

[0001045810-20-000147:mdna:109]
As of July 26, 2020, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-20-000147:mdna:110]
[same as prior period, unchanged from 0001045810-20-000065:mdna:98]

[0001045810-20-000147:mdna:111]
There are $153 million of long-term tax liabilities related to tax basis differences in Mellanox and unrecognized tax benefits of $286 million, which includes related interest and penalties of $41 million recorded in non-current income tax payable as of July 26, 2020. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-20-000147:mdna:112]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020 for a description of our contractual obligations. For a description of our long-term debt, purchase obligations, and operating lease obligations, refer to Note 12, Note 13, and Note 3 of the Notes to Condensed Consolidated Financial Statements, respectively.

[0001045810-20-000147:mdna:113]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000147:mdna:114]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
