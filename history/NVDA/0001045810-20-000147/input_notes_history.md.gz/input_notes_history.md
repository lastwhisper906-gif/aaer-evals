# NVDA note change history — 0001045810-20-000065 → 0001045810-20-000147


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-19):
[0001045810-20-000147:note_history:1]
As of July 26, 2020, we had outstanding inventory purchase obligations totaling $2.04 billion and other purchase obligations totaling $310 million.
  (was, 2020-05-21, similarity 0.9744):
[0001045810-20-000065:note_history:1]
As of April 26, 2020, we had outstanding inventory purchase obligations totaling $1.76 billion and other purchase obligations totaling $287 million.

- changed (2020-08-19):
[0001045810-20-000147:note_history:2]
The estimated amount of product returns and warranty liabilities was $19 million and $15 million as of July 26, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.
  (was, 2020-05-21, similarity 0.9376):
[0001045810-20-000065:note_history:2]
The estimated amount of product returns and warranty liabilities was $16 million and $15 million as of April 26, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.

- changed (2020-08-19):
[0001045810-20-000147:note_history:3]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants. On March 16, 2020, the Court issued an order dismissing the consolidated class action complaint with leave to amend.  The plaintiffs filed an amended complaint on May 13, 2020.  On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.
  (was, 2020-05-21, similarity 0.9568):
[0001045810-20-000065:note_history:3]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants. On March 16, 2020, the Court issued an order dismissing the consolidated class action complaint with leave to amend.  The plaintiffs filed an amended complaint on May 13, 2020.

- changed (2020-08-19):
[0001045810-20-000147:note_history:4]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The Court approved the parties’ stipulation to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.
  (was, 2020-05-21, similarity 0.9431):
[0001045810-20-000065:note_history:4]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The Court approved the parties’ stipulation to stay the

- changed (2020-08-19):
[0001045810-20-000147:note_history:5]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the Court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.
  (was, 2020-05-21, similarity 0.9101):
[0001045810-20-000065:note_history:5]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the Court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of the motion to dismiss filed by NVIDIA in the In Re NVIDIA Corporation Securities Litigation.

- added (2020-08-19):
[0001045810-20-000147:note_history:6]
As of July 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2020-08-19):
[0001045810-20-000065:note_history:7]
In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

- removed (2020-08-19):
[0001045810-20-000065:note_history:8]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of April 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-08-19):
[0001045810-20-000147:note_history:9]
The unaudited condensed consolidated financial statements in this report include the financial results of Mellanox Technologies Ltd., or Mellanox, prospectively from April 27, 2020. For additional details, refer to Note 2 - Business Combination.

- changed (2020-08-19):
[0001045810-20-000147:note_history:10]
Except for the accounting policies for business combination and investment in non-affiliated entities, there have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.
  (was, 2020-05-21, similarity 0.6163):
[0001045810-20-000065:note_history:10]
There have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

- added (2020-08-19):
[0001045810-20-000147:note_history:11]
Business Combination

- added (2020-08-19):
[0001045810-20-000147:note_history:12]
We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, including in-process research and development, or IPR&D, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our condensed consolidated statements of income.

- added (2020-08-19):
[0001045810-20-000147:note_history:13]
We initially capitalize the fair value of IPR&D as an intangible asset with an indefinite life. We assess for impairment thereafter. When IPR&D projects are completed, we reclassify the IPR&D as an amortizable purchased intangible asset and amortize over the asset’s estimated useful life.

- added (2020-08-19):
[0001045810-20-000147:note_history:14]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

- added (2020-08-19):
[0001045810-20-000147:note_history:15]
Investment in Non-Affiliated Entities

- added (2020-08-19):
[0001045810-20-000147:note_history:16]
Non-marketable equity investments in privately-held companies are recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. These investments are valued using observable and unobservable inputs or data in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. The estimated fair value is based on quantitative and qualitative factors including subsequent financing activities by the investee.

- changed (2020-08-19):
[0001045810-20-000147:note_history:17]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The second quarters of fiscal years 2021 and 2020 were both 13-week quarters.
  (was, 2020-05-21, similarity 0.7399):
[0001045810-20-000065:note_history:17]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The first quarters of fiscal years 2021 and 2020 were both 13-week quarters.

- changed (2020-08-19):
[0001045810-20-000147:note_history:18]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. We adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to our consolidated financial statements.
  (was, 2020-05-21, similarity 0.7887):
[0001045810-20-000065:note_history:18]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. The Company adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to the Company's consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-19):
[0001045810-20-000147:note_history:19]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.7 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.7 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.7 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.7 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,960 |  |  | $ | 1,991 |  |
  (was, 2020-05-21, similarity 0.9937):
[0001045810-20-000065:note_history:19]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.9 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.9 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 30.0 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 40.0 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (41) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,959 |  |  | $ | 1,991 |  |

- added (2020-08-19):
[0001045810-20-000147:note_history:20]
As of July 26, 2020, we were in compliance with the required covenants under the Notes.

- changed (2020-08-19):
[0001045810-20-000147:note_history:21]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 26, 2020, we had not borrowed any amounts and were in compliance with the required covenants under this agreement.
  (was, 2020-05-21, similarity 0.7608):
[0001045810-20-000065:note_history:21]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 26, 2020, we had not borrowed any amounts under this agreement.

- changed (2020-08-19):
[0001045810-20-000147:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of July 26, 2020, we had not issued any commercial paper.
  (was, 2020-05-21, similarity 0.9749):
[0001045810-20-000065:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of April 26, 2020, we had not issued any commercial paper.

- removed (2020-08-19):
[0001045810-20-000065:note_history:23]
The Notes require the Company to comply with certain covenants for which the Company was in compliance as of April 26, 2020.

- removed (2020-08-19):
[0001045810-20-000065:note_history:24]
The Credit Agreement governing the revolving credit facility requires the Company to comply with a leverage ratio covenant. As of April 26, 2020, the Company was in compliance with this financial covenant.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-19):
[0001045810-20-000147:note_history:25]
The following is a summary of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020:
  (was, 2020-05-21, similarity 0.9665):
[0001045810-20-000065:note_history:25]
The following is a summary of cash equivalents and marketable securities as of April 26, 2020 and January 26, 2020:

- added (2020-08-19):
[0001045810-20-000147:note_history:26]
|  | July 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 3,494 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3,497 |  |  | $ | 515 |  |  | $ | 2,982 |  |
| Debt securities issued by United States government agencies | 2,101 |  |  | 1 |  |  | — |  |  | 2,102 |  |  | 50 |  |  | 2,052 |  |
| Money market funds | 2,053 |  |  | — |  |  | — |  |  | 2,053 |  |  | 2,053 |  |  | — |  |
| Debt securities issued by the United States Treasury | 1,956 |  |  | — |  |  | — |  |  | 1,956 |  |  | — |  |  | 1,956 |  |
| Certificates of deposit | 893 |  |  | — |  |  | — |  |  | 893 |  |  | 342 |  |  | 551 |  |
| Foreign government bonds | 256 |  |  | — |  |  | — |  |  | 256 |  |  | 90 |  |  | 166 |  |
| Total | $ | 10,753 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 10,757 |  |  | $ | 3,050 |  |  | $ | 7,707 |  |

- changed (2020-08-19):
[0001045810-20-000147:note_history:27]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |
  (was, 2020-05-21, similarity 0.9989):
[0001045810-20-000065:note_history:27]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  |  |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- removed (2020-08-19):
[0001045810-20-000065:note_history:28]
|  | April 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 11,128 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,128 |  |  | $ | 11,128 |  |  | $ | — |  |
| Corporate debt securities | 3,238 |  |  | — |  |  | — |  |  | 3,238 |  |  | 2,951 |  |  | 287 |  |
| Foreign government bonds | 870 |  |  | — |  |  | — |  |  | 870 |  |  | 870 |  |  | — |  |
| Certificates of deposit | 582 |  |  | — |  |  | — |  |  | 582 |  |  | 222 |  |  | 360 |  |
| Debt securities issued by United States government agencies | 381 |  |  | — |  |  | — |  |  | 381 |  |  | 168 |  |  | 213 |  |
| Total | $ | 16,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 16,199 |  |  | $ | 15,339 |  |  | $ | 860 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-19):
[0001045810-20-000147:note_history:29]
The following is a summary of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020:
  (was, 2020-05-21, similarity 0.9665):
[0001045810-20-000065:note_history:29]
The following is a summary of cash equivalents and marketable securities as of April 26, 2020 and January 26, 2020:

- added (2020-08-19):
[0001045810-20-000147:note_history:30]
|  | July 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 3,494 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3,497 |  |  | $ | 515 |  |  | $ | 2,982 |  |
| Debt securities issued by United States government agencies | 2,101 |  |  | 1 |  |  | — |  |  | 2,102 |  |  | 50 |  |  | 2,052 |  |
| Money market funds | 2,053 |  |  | — |  |  | — |  |  | 2,053 |  |  | 2,053 |  |  | — |  |
| Debt securities issued by the United States Treasury | 1,956 |  |  | — |  |  | — |  |  | 1,956 |  |  | — |  |  | 1,956 |  |
| Certificates of deposit | 893 |  |  | — |  |  | — |  |  | 893 |  |  | 342 |  |  | 551 |  |
| Foreign government bonds | 256 |  |  | — |  |  | — |  |  | 256 |  |  | 90 |  |  | 166 |  |
| Total | $ | 10,753 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 10,757 |  |  | $ | 3,050 |  |  | $ | 7,707 |  |

- changed (2020-08-19):
[0001045810-20-000147:note_history:31]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |
  (was, 2020-05-21, similarity 0.9989):
[0001045810-20-000065:note_history:31]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  |  |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- added (2020-08-19):
[0001045810-20-000147:note_history:32]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

- added (2020-08-19):
[0001045810-20-000147:note_history:33]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020 are shown below by contractual maturity.

- added (2020-08-19):
[0001045810-20-000147:note_history:34]
|  | July 26, 2020 |  |  |  | January 26, 2020 |  |  |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |  |  |  |  |  |  |
| Less than one year | $ | 10,027 |  |  | $ | 10,028 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 726 |  |  | 729 |  |  | — |  |  | — |  |
| Total | $ | 10,753 |  |  | $ | 10,757 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |

- removed (2020-08-19):
[0001045810-20-000065:note_history:35]
|  | April 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 11,128 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,128 |  |  | $ | 11,128 |  |  | $ | — |  |
| Corporate debt securities | 3,238 |  |  | — |  |  | — |  |  | 3,238 |  |  | 2,951 |  |  | 287 |  |
| Foreign government bonds | 870 |  |  | — |  |  | — |  |  | 870 |  |  | 870 |  |  | — |  |
| Certificates of deposit | 582 |  |  | — |  |  | — |  |  | 582 |  |  | 222 |  |  | 360 |  |
| Debt securities issued by United States government agencies | 381 |  |  | — |  |  | — |  |  | 381 |  |  | 168 |  |  | 213 |  |
| Total | $ | 16,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 16,199 |  |  | $ | 15,339 |  |  | $ | 860 |  |

- removed (2020-08-19):
[0001045810-20-000065:note_history:36]
The amortized cost and estimated fair value of cash equivalents and marketable securities of $16.20 billion and $10.78 billion as of April 26, 2020 and January 26, 2020, respectively, are all related to contracts with maturities of less than one year. Unrealized gains and losses were not significant for all periods presented. For the first quarter of fiscal years 2021 and 2020, net realized gains were not significant.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-19):
[0001045810-20-000147:note_history:37]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.7 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.7 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.7 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.7 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,960 |  |  | $ | 1,991 |  |
  (was, 2020-05-21, similarity 0.9937):
[0001045810-20-000065:note_history:37]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.9 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.9 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 30.0 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 40.0 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (41) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,959 |  |  | $ | 1,991 |  |
