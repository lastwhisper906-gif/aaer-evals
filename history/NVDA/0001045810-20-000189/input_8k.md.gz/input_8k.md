# NVDA 8-K — 0001045810-20-000187 filed 2020-11-18

## item codes, every 8-K on or before 2020-11-18

- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2020-11-18

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-20-000187:8k_2_02:1]
EX-99.1
2
q3fy21pr.htm
Q3FY21 PRESS RELEASE

[0001045810-20-000187:8k_2_02:2]
Document

[0001045810-20-000187:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-20-000187:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2021

[0001045810-20-000187:8k_2_02:5]
•Record revenue of $4.73 billion, up 57 percent from a year earlier

[0001045810-20-000187:8k_2_02:6]
•Record Gaming revenue of $2.27 billion, up 37 percent from a year earlier

[0001045810-20-000187:8k_2_02:7]
•Record Data Center revenue of $1.90 billion, up 162 percent from a year earlier

[0001045810-20-000187:8k_2_02:8]
SANTA CLARA, Calif.-Nov. 18, 2020- NVIDIA (NASDAQ: NVDA) today reported record revenue for the third quarter ended October 25, 2020, of $4.73 billion, up 57 percent from $3.01 billion a year earlier, and up 22 percent from $3.87 billion in the previous quarter.

[0001045810-20-000187:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $2.12, up 46 percent from $1.45 a year ago, and up 114 percent from $0.99 in the previous quarter. Non-GAAP earnings per diluted share were $2.91, up 63 percent from $1.78 a year earlier, and up 33 percent from $2.18 in the previous quarter.

[0001045810-20-000187:8k_2_02:10]
“NVIDIA is firing on all cylinders, achieving record revenues in Gaming, Data Center, and overall,” said Jensen Huang, founder and CEO of NVIDIA. “The new NVIDIA GeForce RTX GPU provides our largest-ever generational leap and demand is overwhelming. NVIDIA RTX has made ray tracing the new standard in gaming.

[0001045810-20-000187:8k_2_02:11]
“We are continuing to raise the bar with NVIDIA AI. Our A100 compute platform is ramping fast, with the top cloud companies deploying it globally. We swept the industry AI inference benchmark, and our customers are moving some of the world’s most popular AI services into production, powered by NVIDIA technology.

[0001045810-20-000187:8k_2_02:12]
“We announced the NVIDIA DPU programmable data center processor, and the planned acquisition of Arm, creator of the world’s most popular CPU. We are positioning NVIDIA for the age of AI, when computing will extend from the cloud to trillions of devices.”

[0001045810-20-000187:8k_2_02:13]
NVIDIA paid $99 million in quarterly cash dividends in the third quarter. It will pay its next quarterly cash dividend of $0.16 per share on December 29, 2020, to all shareholders of record on December 4, 2020.

[0001045810-20-000187:8k_2_02:14]
Q3 Fiscal 2021 Summary

[0001045810-20-000187:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY21 | Q2 FY21 | Q3 FY20 | Q/Q | Y/Y |
| Revenue | $4,726 | $3,866 | $3,014 | Up 22% | Up 57% |
| Gross margin | 62.6 | % | 58.8 | % | 63.6 | % | Up 380 bps | Down 100 bps |
| Operating expenses | $1,562 | $1,624 | $989 | Down 4% | Up 58% |
| Operating income | $1,398 | $651 | $927 | Up 115% | Up 51% |
| Net income | $1,336 | $622 | $899 | Up 115% | Up 49% |
| Diluted earnings per share | $2.12 | $0.99 | $1.45 | Up 114% | Up 46% |

[0001045810-20-000187:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY21 | Q2 FY21 | Q3 FY20 | Q/Q | Y/Y |
| Revenue | $4,726 | $3,866 | $3,014 | Up 22% | Up 57% |
| Gross margin | 65.5 | % | 66.0 | % | 64.1 | % | Down 50 bps | Up 140 bps |
| Operating expenses | $1,101 | $1,035 | $774 | Up 6% | Up 42% |
| Operating income | $1,993 | $1,516 | $1,156 | Up 31% | Up 72% |
| Net income | $1,834 | $1,366 | $1,103 | Up 34% | Up 66% |
| Diluted earnings per share | $2.91 | $2.18 | $1.78 | Up 33% | Up 63% |

[0001045810-20-000187:8k_2_02:17]
NVIDIA’s outlook for the fourth quarter of fiscal 2021 is as follows:

[0001045810-20-000187:8k_2_02:18]
•Revenue is expected to be $4.80 billion, plus or minus 2 percent.

[0001045810-20-000187:8k_2_02:19]
•GAAP and non-GAAP gross margins are expected to be 62.8 percent and 65.5 percent, respectively, plus or minus 50 basis points.

[0001045810-20-000187:8k_2_02:20]
•GAAP and non-GAAP operating expenses are expected to be approximately $1.64 billion and $1.18 billion, respectively.

[0001045810-20-000187:8k_2_02:21]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $55 million.

[0001045810-20-000187:8k_2_02:22]
•GAAP and non-GAAP tax rates are both expected to be 8 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter-by-quarter basis.

[0001045810-20-000187:8k_2_02:23]
Highlights

[0001045810-20-000187:8k_2_02:24]
During the third quarter, NVIDIA announced a definitive agreement to acquire Arm Limited from SoftBank Capital Limited and SVF Holdco (UK) Limited in a transaction valued at $40 billion. The transaction will combine NVIDIA’s leading AI computing platform with Arm’s vast ecosystem to create the premier computing company for the age of AI. The transaction -- which is expected to be immediately accretive to NVIDIA’s non-GAAP gross margin and non-GAAP earnings per share -- is expected to close in the first quarter of calendar 2022.

[0001045810-20-000187:8k_2_02:25]
NVIDIA also announced plans to build a world-class AI lab in Cambridge, England -- including a powerful AI supercomputer based on NVIDIA and Arm technology -- and provide research fellowships and partnerships with local institutions and AI training courses. Separately, it plans to build Cambridge-1, the U.K.’s most powerful AI supercomputer, based on an NVIDIA DGX SuperPOD™ system and designed for AI research in healthcare and drug discovery.

[0001045810-20-000187:8k_2_02:26]
NVIDIA also achieved progress since its previous earnings announcement in these areas:

[0001045810-20-000187:8k_2_02:27]
Data Center

[0001045810-20-000187:8k_2_02:28]
•Third-quarter revenue was a record $1.90 billion, up 8 percent from the previous quarter and up 162 percent from a year earlier.

[0001045810-20-000187:8k_2_02:29]
•Shared news that Amazon Web Services and Oracle Cloud Infrastructure announced general availability of cloud computing instances based on the NVIDIA A100™ GPU, following Google Cloud Platform and Microsoft Azure.

[0001045810-20-000187:8k_2_02:30]
•Announced the NVIDIA DGX SuperPOD Solution for Enterprise -- the world’s first turnkey AI infrastructure -- which is expected to be installed by yearend in Korea, the U.K., India and Sweden.

[0001045810-20-000187:8k_2_02:31]
•Announced that five supercomputers backed by EuroHPC -- including “Leonardo,” the world’s fastest AI supercomputer built by the Italian inter-university consortium CINECA -- will use NVIDIA’s data center accelerators or networking.

[0001045810-20-000187:8k_2_02:32]
•Introduced the NVIDIA BlueField-2 DPU (data processing unit) -- supported by NVIDIA DOCA™, a novel data-center-infrastructure-on-a-chip architecture -- to bring breakthrough networking, storage and security performance to every data center.

[0001045810-20-000187:8k_2_02:33]
•Announced a broad partnership with VMware to create an end-to-end enterprise platform for AI and a new architecture for data center, cloud and edge using NVIDIA DPUs, benefiting 300,000-plus VMware customers.

[0001045810-20-000187:8k_2_02:34]
•Unveiled NVIDIA Maxine™, an AI video-streaming platform that enhances streaming quality and offers such AI-powered features as gaze correction, super-resolution, noise cancellation and face relighting.

[0001045810-20-000187:8k_2_02:35]
•Introduced the NVIDIA RTX™ A6000 and NVIDIA A40™ GPUs, built on the NVIDIA Ampere architecture and featuring new RT Cores, Tensor Cores and CUDA® cores.

[0001045810-20-000187:8k_2_02:36]
•Extended its lead on MLPerf performance benchmarks for inference, winning every test across all six application areas for data center and edge computing systems.

[0001045810-20-000187:8k_2_02:37]
•Announced a partnership with GSK to integrate computing platforms for imaging, genomics and AI into the drug and vaccine discovery process.

[0001045810-20-000187:8k_2_02:38]
•Introduced at SC20, three powerful advances in AI technology: the NVIDIA® A100 80GB GPU, powering the NVIDIA HGX™ AI supercomputing platform with twice the memory of its predecessor; the NVIDIA DGX Station™ A100, the world’s only petascale workgroup server, for machine learning and data science workloads; and the next generation of NVIDIA® Mellanox® InfiniBand, for the fastest networking performance.

[0001045810-20-000187:8k_2_02:39]
Gaming

[0001045810-20-000187:8k_2_02:40]
•Third-quarter revenue was a record $2.27 billion, up 37 percent from the previous quarter and up 37 percent from a year earlier.

[0001045810-20-000187:8k_2_02:41]
•Unveiled the GeForce RTX® 30 Series GPUs, powered by the NVIDIA Ampere architecture and the second generation of RTX, with up to 2x the performance of the previous Turing-based generation.

[0001045810-20-000187:8k_2_02:42]
•Announced that Fortnite – the world’s most popular video game – will support NVIDIA RTX real-time ray tracing and DLSS AI super-resolution, joining more than two dozen other titles including Cyberpunk 2077, Call of Duty: Black Ops, and Watch Dogs: Legion.

[0001045810-20-000187:8k_2_02:43]
•Introduced NVIDIA Reflex™, a suite of technologies that improves reaction time in games by reducing system latency, which is available in Fortnite, Valorant, Call of Duty: Warzone and Apex Legends among other titles.

[0001045810-20-000187:8k_2_02:44]
•Unveiled NVIDIA Broadcast™, a plugin that enhances microphone, speaker and webcam quality with RTX-accelerated AI effects.

[0001045810-20-000187:8k_2_02:45]
Professional Visualization

[0001045810-20-000187:8k_2_02:46]
•Third-quarter revenue was $236 million, up 16 percent from the previous quarter and down 27 percent from a year earlier.

[0001045810-20-000187:8k_2_02:47]
•Brought to open beta NVIDIA Omniverse™, the world’s first NVIDIA RTX-based 3D simulation and collaboration platform.

[0001045810-20-000187:8k_2_02:48]
•Announced NVIDIA Omniverse Machinima™, enabling creators with video game assets animated by NVIDIA AI technologies.

[0001045810-20-000187:8k_2_02:49]
•Collaborated with Adobe to bring GPU-accelerated neural filters to Adobe Photoshop AI-powered tools.

[0001045810-20-000187:8k_2_02:50]
Automotive

[0001045810-20-000187:8k_2_02:51]
•Third-quarter revenue was $125 million, up 13 percent from the previous quarter and down 23 percent from a year earlier.

[0001045810-20-000187:8k_2_02:52]
•Announced with Mercedes-Benz that NVIDIA is powering the next-generation MBUX AI cockpit system, to be featured first in the new S-class sedan, with such features as an augmented reality heads-up display, AI voice assistant and interactive graphics.

[0001045810-20-000187:8k_2_02:53]
•Announced with Hyundai Motor Group that the Korean automaker’s entire lineup of Hyundai, Kia and Genesis models will come standard with NVIDIA DRIVE™ in-vehicle infotainment systems, starting in 2022.

[0001045810-20-000187:8k_2_02:54]
•Announced that China’s Li Auto will develop its next generation of electric vehicles using NVIDIA DRIVE AGX Orin™, a software-defined platform for autonomous vehicles.

[0001045810-20-000187:8k_2_02:55]
CFO Commentary

[0001045810-20-000187:8k_2_02:56]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-20-000187:8k_2_02:57]
Conference Call and Webcast Information

[0001045810-20-000187:8k_2_02:58]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2021 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal year 2021.

[0001045810-20-000187:8k_2_02:59]
Non-GAAP Measures

[0001045810-20-000187:8k_2_02:60]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, legal settlement costs, losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases related to property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-20-000187:8k_2_02:61]
About NVIDIA

[0001045810-20-000187:8k_2_02:62]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI ― the next era of computing ― with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at https://nvidianews.nvidia.com/.

[0001045810-20-000187:8k_2_02:63]
###

[0001045810-20-000187:8k_2_02:64]
For further information, contact:

[0001045810-20-000187:8k_2_02:65]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-20-000187:8k_2_02:66]
Certain statements in this press release including, but not limited to, statements as to:  NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the fourth quarter of fiscal 2021; NVIDIA’s expected tax rates for the fourth quarter of fiscal 2021; NVIDIA’s expectation to generate variability from excess tax benefits or deficiencies; the benefits of the Arm acquisition, including the combination creating the world’s premier computing company; the expectation that the Arm transaction will be immediately accretive; when the Arm transaction is expected to close; NVIDIA’s plan to build an AI lab in Cambridge and provide fellowships, partnerships and AI training; NVIDIA’s plan to build the Cambridge-1 supercomputer; the benefits, performance, abilities and impact of our products and technologies, including the BlueField DPUs,  NVIDIA Maxine, GeForce RTX 30 Series GPUs, NVIDIA Omniverse Machinima, NVIDIA A100 80GB GPU, NVIDIA DGX Station A100, NVIDIA Ampere architecture and NVIDIA Mellanox InfiniBand; our partnership with VMware creating a platform and architecture for data center and benefiting VMware customers; the expected locations and timing for installation of the NVIDIA DGX SuperPOD Solution for Enterprise; our partnership with GSK; the plan for CINECA to use NVIDIA technology to build Leonardo and the other supercomputers being built planning to use NVIDIA technology; the games supporting real-time ray tracing and AI-powered NVIDIA DLSS; the abilities of NVIDIA Reflex and its availability; the partnership with Mercedes-Benz to power the new MBUX AI cockpit system; NVIDIA DRIVE coming standard in Hyundai Motor Group’s lineup of cars and the timing for the launch; Li Auto developing its next-generation vehicles using NVIDIA DRIVE AGX Orin; NVIDIA firing on all cylinders; NVIDIA GeForce RTX GPUs providing the largest ever generational leap and demand being overwhelming; raising the bar with NVIDIA AI; our A100 compute platform ramping and deploying globally; our customers moving AI services into production; the acquisition of Arm; and NVIDIA’s positioning for the age of AI, when computing will extend from the cloud to trillions of devices are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-20-000187:8k_2_02:67]
© 2020 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, CUDA, GeForce RTX,  Mellanox, NVIDIA A40, NVIDIA AGX, NVIDIA A100, NVIDIA Broadcast, NVIDIA DGX A100, NVIDIA DGX Station, NVIDIA DGX SuperPOD, NVIDIA DOCA, NVIDIA DRIVE, NVIDIA DRIVE AGX Orin,  NVIDIA HGX, NVIDIA Maxine, NVIDIA Omniverse, NVIDIA Omniverse Machinima, NVIDIA Reflex, and NVIDIA RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-20-000187:8k_2_02:68]
NVIDIA CORPORATION

[0001045810-20-000187:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-20-000187:8k_2_02:70]
(In millions, except per share data)

[0001045810-20-000187:8k_2_02:71]
(Unaudited)

[0001045810-20-000187:8k_2_02:72]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 25, |  | October 27, |  | October 25, |  | October 27, |
|  |  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue | $ | 4,726 |  |  | $ | 3,014 |  |  | $ | 11,672 |  |  | $ | 7,813 |  |
| Cost of revenue | 1,766 |  |  | 1,098 |  |  | 4,432 |  |  | 3,060 |  |
| Gross profit | 2,960 |  |  | 1,916 |  |  | 7,240 |  |  | 4,753 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,047 |  |  | 712 |  |  | 2,778 |  |  | 2,091 |  |
|  | Sales, general and administrative | 515 |  |  | 277 |  |  | 1,437 |  |  | 806 |  |
|  |  | Total operating expenses | 1,562 |  |  | 989 |  |  | 4,215 |  |  | 2,897 |  |
| Income from operations | 1,398 |  |  | 927 |  |  | 3,025 |  |  | 1,856 |  |
|  | Interest income | 7 |  |  | 45 |  |  | 50 |  |  | 137 |  |
|  | Interest expense | (53) |  |  | (13) |  |  | (131) |  |  | (39) |  |
|  | Other, net | (4) |  |  | — |  |  | (5) |  |  | — |  |
|  |  | Other income (expense), net | (50) |  |  | 32 |  |  | (86) |  |  | 98 |  |
| Income before income tax | 1,348 |  |  | 959 |  |  | 2,939 |  |  | 1,954 |  |
| Income tax expense | 12 |  |  | 60 |  |  | 64 |  |  | 109 |  |
| Net income | $ | 1,336 |  |  | $ | 899 |  |  | $ | 2,875 |  |  | $ | 1,845 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 2.16 |  |  | $ | 1.47 |  |  | $ | 4.67 |  |  | $ | 3.03 |  |
|  | Diluted | $ | 2.12 |  |  | $ | 1.45 |  |  | $ | 4.59 |  |  | $ | 2.99 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 618 |  |  | 610 |  |  | 616 |  |  | 609 |  |
|  | Diluted | 630 |  |  | 618 |  |  | 626 |  |  | 617 |  |

[0001045810-20-000187:8k_2_02:73]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | October 25, |  | January 26, |
|  |  |  |  | 2020 |  | 2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 10,139 |  |  | $ | 10,897 |  |
|  | Accounts receivable, net |  | 2,546 |  |  | 1,657 |  |
|  | Inventories |  | 1,495 |  |  | 979 |  |
|  | Prepaid expenses and other current assets |  | 213 |  |  | 157 |  |
|  |  | Total current assets |  | 14,393 |  |  | 13,690 |  |
| Property and equipment, net |  | 2,059 |  |  | 1,674 |  |
| Operating lease assets |  | 681 |  |  | 618 |  |
| Goodwill |  | 4,193 |  |  | 618 |  |
| Intangible assets, net |  | 2,861 |  |  | 49 |  |
| Deferred income tax assets |  | 666 |  |  | 548 |  |
| Other assets |  | 2,028 |  |  | 118 |  |
|  |  | Total assets |  | $ | 26,881 |  |  | $ | 17,315 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,097 |  |  | $ | 687 |  |
|  | Accrued and other current liabilities |  | 1,574 |  |  | 1,097 |  |
|  | Short-term debt |  | 998 |  |  | — |  |
|  |  | Total current liabilities |  | 3,669 |  |  | 1,784 |  |
| Long-term debt |  | 5,963 |  |  | 1,991 |  |
| Long-term operating lease liabilities |  | 604 |  |  | 561 |  |
| Other long-term liabilities |  | 1,311 |  |  | 775 |  |
|  |  | Total liabilities |  | 11,547 |  |  | 5,111 |  |
| Shareholders' equity |  | 15,334 |  |  | 12,204 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 26,881 |  |  | $ | 17,315 |  |

[0001045810-20-000187:8k_2_02:74]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 27, |  | October 25, |  | October 27, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,336 |  |  | $ | 899 |  |  | $ | 2,875 |  |  | $ | 1,845 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 299 |  |  | 92 |  |  | 810 |  |  | 275 |  |
| Stock-based compensation expense | 383 |  |  | 223 |  |  | 981 |  |  | 624 |  |
| Deferred income taxes | (53) |  |  | 22 |  |  | (117) |  |  | (5) |  |
| Other | 2 |  |  | 3 |  |  | (2) |  |  | 5 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (463) |  |  | 106 |  |  | (667) |  |  | (32) |  |
| Inventories | (93) |  |  | 152 |  |  | (190) |  |  | 531 |  |
| Prepaid expenses and other assets | (443) |  |  | 19 |  |  | (409) |  |  | 55 |  |
| Accounts payable | 225 |  |  | 135 |  |  | 289 |  |  | 91 |  |
| Accrued and other current liabilities | 31 |  |  | (23) |  |  | 111 |  |  | (103) |  |
| Other long-term liabilities | 55 |  |  | 12 |  |  | 74 |  |  | 10 |  |
| Net cash provided by operating activities | 1,279 |  |  | 1,640 |  |  | 3,755 |  |  | 3,296 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 4,133 |  |  | 1,153 |  |  | 5,165 |  |  | 4,744 |  |
| Proceeds from sales of marketable securities | 243 |  |  | 211 |  |  | 502 |  |  | 3,363 |  |
| Purchases of marketable securities | (4,554) |  |  | — |  |  | (12,840) |  |  | (1,461) |  |
| Acquisitions, net of cash acquired | (1,353) |  |  | — |  |  | (8,524) |  |  | — |  |
| Purchases related to property and equipment and intangible assets | (473) |  |  | (104) |  |  | (845) |  |  | (344) |  |
| Investments and other, net | 3 |  |  | (3) |  |  | (4) |  |  | (6) |  |
| Net cash provided by (used in) investing activities | (2,001) |  |  | 1,257 |  |  | (16,546) |  |  | 6,296 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 96 |  |  | 63 |  |  | 190 |  |  | 146 |  |
| Payments related to tax on restricted stock units | (298) |  |  | (203) |  |  | (716) |  |  | (463) |  |
| Dividends paid | (99) |  |  | (97) |  |  | (296) |  |  | (292) |  |
| Issuance of debt, net of issuance costs | — |  |  | — |  |  | 4,971 |  |  | — |  |
| Other | — |  |  | — |  |  | (3) |  |  | — |  |
| Net cash provided by (used in) financing activities | (301) |  |  | (237) |  |  | 4,146 |  |  | (609) |  |
| Change in cash and cash equivalents | (1,023) |  |  | 2,660 |  |  | (8,645) |  |  | 8,983 |  |
| Cash and cash equivalents at beginning of period | 3,274 |  |  | 7,105 |  |  | 10,896 |  |  | 782 |  |
| Cash and cash equivalents at end of period | $ | 2,251 |  |  | $ | 9,765 |  |  | $ | 2,251 |  |  | $ | 9,765 |  |

[0001045810-20-000187:8k_2_02:75]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 25, |  | July 26, |  | October 27, |  | October 25, |  | October 27, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP gross profit |  | $ | 2,960 |  |  | $ | 2,275 |  |  | $ | 1,916 |  |  | $ | 7,240 |  |  | $ | 4,753 |  |
| GAAP gross margin |  | 62.6 | % |  | 58.8 | % |  | 63.6 | % |  | 62.0 | % |  | 60.8 | % |
|  | Acquisition-related and other costs (B) |  | 86 |  |  | 245 |  |  | — |  |  | 331 |  |  | — |  |
|  | Stock-based compensation expense (A) |  | 28 |  |  | 14 |  |  | 15 |  |  | 62 |  |  | 27 |  |
|  | Legal settlement costs |  | 21 |  |  | 17 |  |  | — |  |  | 38 |  |  | 11 |  |
| Non-GAAP gross profit |  | $ | 3,095 |  |  | $ | 2,551 |  |  | $ | 1,931 |  |  | $ | 7,671 |  |  | $ | 4,791 |  |
| Non-GAAP gross margin |  | 65.5 | % |  | 66.0 | % |  | 64.1 | % |  | 65.7 | % |  | 61.3 | % |
| GAAP operating expenses |  | $ | 1,562 |  |  | $ | 1,624 |  |  | $ | 989 |  |  | $ | 4,215 |  |  | $ | 2,897 |  |
|  | Stock-based compensation expense (A) |  | (355) |  |  | (360) |  |  | (208) |  |  | (919) |  |  | (597) |  |
|  | Acquisition-related and other costs (B) |  | (106) |  |  | (229) |  |  | (7) |  |  | (338) |  |  | (22) |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | (2) |  |
| Non-GAAP operating expenses |  | $ | 1,101 |  |  | $ | 1,035 |  |  | $ | 774 |  |  | $ | 2,958 |  |  | $ | 2,276 |  |
| GAAP income from operations |  | $ | 1,398 |  |  | $ | 651 |  |  | $ | 927 |  |  | $ | 3,025 |  |  | $ | 1,856 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 595 |  |  | 865 |  |  | 229 |  |  | 1,689 |  |  | 659 |  |
| Non-GAAP income from operations |  | $ | 1,993 |  |  | $ | 1,516 |  |  | $ | 1,156 |  |  | $ | 4,714 |  |  | $ | 2,515 |  |
| GAAP other income (expense), net |  | $ | (50) |  |  | $ | (42) |  |  | $ | 32 |  |  | $ | (86) |  |  | $ | 98 |  |
|  | Losses from non-affiliated investments |  | 4 |  |  | 2 |  |  | — |  |  | 9 |  |  | 1 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Non-GAAP other income (expense), net |  | $ | (45) |  |  | $ | (39) |  |  | $ | 33 |  |  | $ | (76) |  |  | $ | 100 |  |
| GAAP net income |  | $ | 1,336 |  |  | $ | 622 |  |  | $ | 899 |  |  | $ | 2,875 |  |  | $ | 1,845 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 600 |  |  | 868 |  |  | 230 |  |  | 1,699 |  |  | 660 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (102) |  |  | (124) |  |  | (26) |  |  | (255) |  |  | (97) |  |
| Non-GAAP net income |  | $ | 1,834 |  |  | $ | 1,366 |  |  | $ | 1,103 |  |  | $ | 4,319 |  |  | $ | 2,408 |  |

[0001045810-20-000187:8k_2_02:76]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 25, |  | July 26, |  | October 27, |  | October 25, |  | October 27, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 2.12 |  |  | $ | 0.99 |  |  | $ | 1.45 |  |  | $ | 4.59 |  |  | $ | 2.99 |  |
|  | Non-GAAP |  | $ | 2.91 |  |  | $ | 2.18 |  |  | $ | 1.78 |  |  | $ | 6.90 |  |  | $ | 3.90 |  |
| Weighted average shares used in diluted net income per share computation |  | 630 |  |  | 626 |  |  | 618 |  |  | 626 |  | 617 |
| GAAP net cash provided by operating activities |  | $ | 1,279 |  |  | $ | 1,566 |  |  | $ | 1,640 |  |  | $ | 3,755 |  |  | $ | 3,296 |  |
|  | Purchases related to property and equipment and intangible assets |  | (473) |  |  | (217) |  |  | (104) |  |  | (845) |  |  | (344) |  |
| Free cash flow |  | $ | 806 |  |  | $ | 1,349 |  |  | $ | 1,536 |  |  | $ | 2,910 |  |  | $ | 2,952 |  |

[0001045810-20-000187:8k_2_02:77]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 25, |  | July 26, |  | October 27, |  | October 25, |  | October 27, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | Cost of revenue |  | $ | 28 |  |  | $ | 14 |  |  | $ | 15 |  |  | $ | 62 |  |  | $ | 27 |  |
|  | Research and development |  | $ | 232 |  |  | $ | 228 |  |  | $ | 141 |  |  | $ | 594 |  |  | $ | 400 |  |
|  | Sales, general and administrative |  | $ | 123 |  |  | $ | 132 |  |  | $ | 67 |  |  | $ | 325 |  |  | $ | 197 |  |
| (B) Acquisition-related and other costs primarily include amortization of intangible assets, inventory step-up, transaction costs, and certain compensation charges presented as follows: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 25, |  | July 26, |  | October 27, |  | October 25, |  | October 27, |
|  |  |  | 2020 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | Cost of revenue |  | $ | 86 |  |  | $ | 245 |  |  | $ | — |  |  | $ | 331 |  |  | $ | — |  |
|  | Research and development |  | $ | 2 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 7 |  |  | $ | 4 |  |
|  | Sales, general and administrative |  | $ | 104 |  |  | $ | 226 |  |  | $ | 6 |  |  | $ | 331 |  |  | $ | 18 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-20-000187:8k_2_02:78]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2021 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 62.8 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 2.7 | % |
| Non-GAAP gross margin |  | 65.5 | % |
| GAAP operating expenses |  | $ | 1,640 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (460) |  |
| Non-GAAP operating expenses |  | $ | 1,180 |  |
