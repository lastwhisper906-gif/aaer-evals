# NVDA notes — 0001045810-20-000189


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-20-000189:notes:1]
[same as prior period, unchanged from 0001045810-20-000147:notes:1]

[0001045810-20-000189:notes:2]
[same as prior period, unchanged from 0001045810-20-000147:notes:2]

[0001045810-20-000189:notes:3]
[same as prior period, unchanged from 0001045810-20-000147:notes:3]

[0001045810-20-000189:notes:4]
[same as prior period, unchanged from 0001045810-20-000147:notes:4]

[0001045810-20-000189:notes:5]
[same as prior period, unchanged from 0001045810-20-000147:notes:5]

[0001045810-20-000189:notes:6]
[same as prior period, unchanged from 0001045810-20-000147:notes:6]

[0001045810-20-000189:notes:7]
[same as prior period, unchanged from 0001045810-20-000147:notes:7]

[0001045810-20-000189:notes:8]
[same as prior period, unchanged from 0001045810-20-000147:notes:8]

[0001045810-20-000189:notes:9]
[same as prior period, unchanged from 0001045810-20-000147:notes:9]

[0001045810-20-000189:notes:10]
[same as prior period, unchanged from 0001045810-20-000147:notes:10]

[0001045810-20-000189:notes:11]
[same as prior period, unchanged from 0001045810-20-000147:notes:11]

[0001045810-20-000189:notes:12]
[same as prior period, unchanged from 0001045810-20-000147:notes:12]

[0001045810-20-000189:notes:13]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The third quarters of fiscal years 2021 and 2020 were both 13-week quarters.

[0001045810-20-000189:notes:14]
[same as prior period, unchanged from 0001045810-20-000147:notes:14]

[0001045810-20-000189:notes:15]
[same as prior period, unchanged from 0001045810-20-000147:notes:15]

[0001045810-20-000189:notes:16]
[same as prior period, unchanged from 0001045810-20-000147:notes:16]

[0001045810-20-000189:notes:17]
[same as prior period, unchanged from 0001045810-20-000147:notes:17]

[0001045810-20-000189:notes:18]
[same as prior period, unchanged from 0001045810-20-000147:notes:18]

[0001045810-20-000189:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19 on our critical and significant accounting estimates. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-20-000189:notes:20]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000189:notes:21]
Recently Adopted Accounting Pronouncement

[0001045810-20-000189:notes:22]
[same as prior period, unchanged from 0001045810-20-000147:notes:22]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-20-000189:notes:23]
Business Combination
Pending Acquisition of Arm Limited

[0001045810-20-000189:notes:24]
On September 13, 2020, we entered into a Share Purchase Agreement, or the Purchase Agreement, with Arm Limited, or Arm, and SoftBank Group Capital Limited and SVF Holdco (UK) Limited, or together, SoftBank, for us to acquire, from SoftBank, all of the allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid $2 billion in cash at signing, or the Signing Consideration, and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 44.3 million shares of our common stock with an aggregate value of $21.5 billion. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial targets are achieved, SoftBank can elect to receive either up to $5 billion in cash or up to 10.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The $2 billion payment upon signing was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. We believe the closing of the acquisition will likely occur in the first quarter of calendar year 2022.

[0001045810-20-000189:notes:25]
Acquisition of Mellanox Technologies, Ltd.

[0001045810-20-000189:notes:26]
On April 27, 2020, we completed the acquisition of all outstanding shares of Mellanox for a total purchase consideration of $7.13 billion. Mellanox is a supplier of high-performance interconnect products for computing, storage and communications applications. We acquired Mellanox to optimize data center workloads to scale across the entire computing, networking, and storage stack.

[0001045810-20-000189:notes:27]
Preliminary Purchase Price Allocation

[0001045810-20-000189:notes:28]
[same as prior period, unchanged from 0001045810-20-000147:notes:24]

[0001045810-20-000189:notes:29]
[same as prior period, unchanged from 0001045810-20-000147:notes:25]

[0001045810-20-000189:notes:30]
(1)    Represents the cash consideration of $125.00 per share paid to Mellanox shareholders for approximately 56 million shares of outstanding Mellanox ordinary shares.

[0001045810-20-000189:notes:31]
(2)    Represents the cash consideration for the settlement of approximately 249 thousand Mellanox stock options held by employees and non-employee directors of Mellanox.

[0001045810-20-000189:notes:32]
(3)    Represents the fair value of Mellanox’s stock-based compensation awards attributable to pre-combination services.

[0001045810-20-000189:notes:33]
[same as prior period, unchanged from 0001045810-20-000147:notes:29]

[0001045810-20-000189:notes:34]
The goodwill is primarily attributable to the planned growth in the combined business of NVIDIA and Mellanox. Goodwill is not amortized to earnings, but instead is reviewed for impairment at least annually, absent any interim indicators of impairment. Goodwill recognized in the acquisition is not expected to be deductible for foreign tax purposes. Goodwill

[0001045810-20-000189:notes:35]
arising from the Mellanox acquisition has been allocated to the Compute and Networking segment. Refer to Note 15 – Segment Information for further details on segments.

[0001045810-20-000189:notes:36]
The operating results of Mellanox have been included in our condensed consolidated financial statements for the third quarter and first nine months of fiscal year 2021 since the acquisition date of April 27, 2020. Revenue attributable to Mellanox was approximately 13% and 10% of consolidated revenue for the third quarter and first nine months of fiscal year 2021, respectively. There is not a practical way to determine net income attributable to Mellanox due to integration. Acquisition-related costs attributable to Mellanox of $27 million were included in selling, general and administrative expense for the first nine months of fiscal year 2021.

[0001045810-20-000189:notes:37]
[same as prior period, unchanged from 0001045810-20-000147:notes:33]

[0001045810-20-000189:notes:38]
[same as prior period, unchanged from 0001045810-20-000147:notes:34]

[0001045810-20-000189:notes:39]
[same as prior period, unchanged from 0001045810-20-000147:notes:35]

[0001045810-20-000189:notes:40]
(1)    The fair value of developed technology was identified using the Multi-Period Excess Earning Method.

[0001045810-20-000189:notes:41]
(2)    Customer relationships represent the fair value of the existing relationships using the With and Without Method.

[0001045810-20-000189:notes:42]
(3)    Order backlog represents primarily the fair value of purchase arrangements with customers using the Multi-Period Excess Earning Method.

[0001045810-20-000189:notes:43]
(4)    Trade names primarily relate to Mellanox trade names and fair value was determined by applying the Relief-from-Royalty Method under the income approach.

[0001045810-20-000189:notes:44]
(5)    The fair value of IPR&D was determined using the Multi-Period Excess Earning Method.

[0001045810-20-000189:notes:45]
[same as prior period, unchanged from 0001045810-20-000147:notes:41]

[0001045810-20-000189:notes:46]
[same as prior period, unchanged from 0001045810-20-000147:notes:42]

[0001045810-20-000189:notes:47]
[same as prior period, unchanged from 0001045810-20-000147:notes:43]

[0001045810-20-000189:notes:48]
[same as prior period, unchanged from 0001045810-20-000147:notes:44]

[0001045810-20-000189:notes:49]
|  | Pro Forma |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25,2020 |  | October 27,2019 |  | October 25,2020 |  | October 27,2019 |
|  | (In millions) |
| Revenue | $ | 4,726 |  |  | $ | 3,350 |  |  | $ | 12,101 |  |  | $ | 8,765 |  |
| Net income | $ | 1,388 |  |  | $ | 786 |  |  | $ | 3,267 |  |  | $ | 1,190 |  |

[0001045810-20-000189:notes:50]
[same as prior period, unchanged from 0001045810-20-000147:notes:46]

[0001045810-20-000189:notes:51]
The pro forma results reflect the inventory step-up expense of $161 million in the first nine months of fiscal year 2020 and were excluded from the pro forma results for the first nine months of fiscal year 2021. There were no other material nonrecurring adjustments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-20-000189:notes:52]
[same as prior period, unchanged from 0001045810-20-000147:notes:48]

[0001045810-20-000189:notes:53]
Future minimum lease payments under our non-cancelable operating leases as of October 25, 2020, are as follows:

[0001045810-20-000189:notes:54]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2021 (excluding first nine months of fiscal year 2021) | $ | 38 |  |
| 2022 | 143 |  |
| 2023 | 122 |  |
| 2024 | 102 |  |
| 2025 | 83 |  |
| 2026 and thereafter | 347 |  |
| Total | 835 |  |
| Less imputed interest | 115 |  |
| Present value of net future minimum lease payments | 720 |  |
| Less short-term operating lease liabilities | 116 |  |
| Long-term operating lease liabilities | $ | 604 |  |

[0001045810-20-000189:notes:55]
Operating lease expense was $37 million and $28 million for the third quarter of fiscal years 2021 and 2020, respectively, and $104 million and $83 million for the first nine months of fiscal years 2021 and 2020, respectively. Short-term and variable lease expenses for the third quarter and first nine months of fiscal years 2021 and 2020 were not significant.

[0001045810-20-000189:notes:56]
[same as prior period, unchanged from 0001045810-20-000147:notes:52]

[0001045810-20-000189:notes:57]
|  | Nine Months Ended |
|  | October 25, 2020 |  | October 27, 2019 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 103 |  |  | $ | 78 |  |
| Operating lease assets obtained in exchange for lease obligations (1) | $ | 147 |  |  | $ | 122 |  |

[0001045810-20-000189:notes:58]
(1)    The first nine months of fiscal year 2021 includes $80 million of operating lease assets addition due to a business combination.

[0001045810-20-000189:notes:59]
As of October 25, 2020, our operating leases had a weighted average remaining lease term of 7.8 years and a weighted average discount rate of 3.06%. As of January 26, 2020, our operating leases had a weighted average remaining lease term of 8.3 years and a weighted average discount rate of 3.45%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-20-000189:notes:60]
[same as prior period, unchanged from 0001045810-20-000147:notes:56]

[0001045810-20-000189:notes:61]
[same as prior period, unchanged from 0001045810-20-000147:notes:57]

[0001045810-20-000189:notes:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25,2020 |  | October 27,2019 |  | October 25,2020 |  | October 27,2019 |
|  | (In millions) |
| Cost of revenue | $ | 28 |  |  | $ | 15 |  |  | $ | 62 |  |  | $ | 27 |  |
| Research and development | 232 |  |  | 141 |  |  | 594 |  |  | 400 |  |
| Sales, general and administrative | 123 |  |  | 67 |  |  | 325 |  |  | 197 |  |
| Total | $ | 383 |  |  | $ | 223 |  |  | $ | 981 |  |  | $ | 624 |  |

[0001045810-20-000189:notes:63]
[same as prior period, unchanged from 0001045810-20-000147:notes:59]

[0001045810-20-000189:notes:64]
[same as prior period, unchanged from 0001045810-20-000147:notes:60]

[0001045810-20-000189:notes:65]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 26, 2020 | 14 |  |  | $ | 176.72 |  |  |  |  |  |
| Granted | 8 |  |  | $ | 300.75 |  |  |  |  |  |
| Vested restricted stock | (6) |  |  | $ | 152.46 |  |  |  |  |  |
| Balances, October 25, 2020 | 16 |  |  | $ | 253.81 |  |  |  |  |  |

[0001045810-20-000189:notes:66]
As of October 25, 2020, there was $3.42 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.7 years for RSUs, PSUs, and market-based PSUs, and 0.9 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-20-000189:notes:67]
[same as prior period, unchanged from 0001045810-20-000147:notes:63]

[0001045810-20-000189:notes:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 27, |  | October 25, |  | October 27, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 1,336 |  |  | $ | 899 |  |  | $ | 2,875 |  |  | $ | 1,845 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 618 |  |  | 610 |  |  | 616 |  |  | 609 |  |
| Dilutive impact of outstanding equity awards | 12 |  |  | 8 |  |  | 10 |  |  | 8 |  |
| Diluted weighted average shares | 630 |  |  | 618 |  |  | 626 |  |  | 617 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 2.16 |  |  | $ | 1.47 |  |  | $ | 4.67 |  |  | $ | 3.03 |  |
| Diluted (2) | $ | 2.12 |  |  | $ | 1.45 |  |  | $ | 4.59 |  |  | $ | 2.99 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | — |  |  | 5 |  |  | 8 |  |  | 11 |  |

[0001045810-20-000189:notes:69]
(1)    Calculated as net income divided by basic weighted average shares.

[0001045810-20-000189:notes:70]
(2)    Calculated as net income divided by diluted weighted average shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-20-000189:notes:71]
Income Taxes
We recognized an income tax expense of $12 million and $64 million for the third quarter and first nine months of fiscal year 2021, respectively, and $60 million and $109 million for the third quarter and first nine months of fiscal year 2020, respectively. The income tax expense as a percentage of income before income tax was 0.9% and 2.2% for the third quarter and first nine months of fiscal year 2021, respectively, and 6.3% and 5.6% for the third quarter and first nine months of fiscal year 2020, respectively.

[0001045810-20-000189:notes:72]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2021 as compared to the same periods of fiscal year 2020 was primarily due to a decrease in the proportional amount of earnings subject to United States tax and an increase of tax benefits from stock-based compensation.

[0001045810-20-000189:notes:73]
Our effective tax rates for the first nine months of fiscal years 2021 and 2020 were lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit, and tax benefits related to stock-based compensation.

[0001045810-20-000189:notes:74]
During the second quarter of fiscal year 2021, we completed the acquisition of Mellanox. As a result of the acquisition, we recorded $256 million of net deferred tax liabilities primarily on the excess of book basis over the tax basis of the acquired intangible assets and undistributed earnings in certain foreign subsidiaries. We also recorded $153 million of long-term tax liabilities related to tax basis differences in Mellanox. The net deferred tax liabilities and long-term tax liabilities are based upon certain assumptions underlying our purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes and long-term tax liabilities may be required. As a result of the acquisition, we intend to indefinitely reinvest approximately $675 million of cumulative undistributed earnings held by Mellanox non-U.S. subsidiaries. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in Mellanox non-U.S. subsidiaries as the determination of such amount is not practicable.

[0001045810-20-000189:notes:75]
For the first nine months of fiscal year 2021, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. In the second quarter of fiscal year 2021, we assumed $59 million of unrecognized tax 
benefits and $4 million of related interest through the Mellanox acquisition. Other than these amounts, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 26, 2020.While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.  As of October 25, 2020, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-20-000189:notes:76]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities, except for money market funds and certificates of deposits, are classified as “available-for-sale” debt securities.

[0001045810-20-000189:notes:77]
The following is a summary of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020:

[0001045810-20-000189:notes:78]
|  | October 25, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 3,881 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,881 |  |  | $ | 1,116 |  |  | $ | 2,765 |  |
| Corporate debt securities | 3,139 |  |  | 2 |  |  | — |  |  | 3,141 |  |  | 427 |  |  | 2,714 |  |
| Debt securities issued by United States government agencies | 1,571 |  |  | 1 |  |  | — |  |  | 1,572 |  |  | — |  |  | 1,572 |  |
| Certificates of deposit | 797 |  |  | — |  |  | — |  |  | 797 |  |  | 29 |  |  | 768 |  |
| Money market funds | 388 |  |  | — |  |  | — |  |  | 388 |  |  | 388 |  |  | — |  |
| Foreign government bonds | 117 |  |  | — |  |  | — |  |  | 117 |  |  | 48 |  |  | 69 |  |
| Total | $ | 9,893 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 9,896 |  |  | $ | 2,008 |  |  | $ | 7,888 |  |

[0001045810-20-000189:notes:79]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

[0001045810-20-000189:notes:80]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-20-000189:notes:81]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020 are shown below by contractual maturity.

[0001045810-20-000189:notes:82]
|  | October 25, 2020 |  | January 26, 2020 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 9,329 |  |  | $ | 9,330 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 564 |  |  | 566 |  |  | — |  |  | — |  |
| Total | $ | 9,893 |  |  | $ | 9,896 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-20-000189:notes:83]
[same as prior period, unchanged from 0001045810-20-000147:notes:79]

[0001045810-20-000189:notes:84]
|  |  | Fair Value at |
|  | Pricing Category |  | October 25, 2020 |  | January 26, 2020 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 388 |  |  | $ | 7,507 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 3,881 |  |  | $ | 1,358 |  |
| Corporate debt securities | Level 2 |  | $ | 3,141 |  |  | $ | 592 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 1,572 |  |  | $ | 1,096 |  |
| Certificates of deposit | Level 2 |  | $ | 797 |  |  | $ | 27 |  |
| Foreign government bonds | Level 2 |  | $ | 117 |  |  | $ | 200 |  |
| Asset-backed securities | Level 2 |  | $ | — |  |  | $ | 1 |  |
| Other asset: |  |  |  |  |  |
| Investment in non-affiliated entities (1) | Level 3 |  | $ | 106 |  |  | $ | 77 |  |
| Liabilities |  |  |  |  |  |
| Other non-current liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (2) | Level 2 |  | $ | 1,016 |  |  | $ | 1,006 |  |
| 3.20% Notes Due 2026 (2) | Level 2 |  | $ | 1,127 |  |  | $ | 1,065 |  |
| 2.85% Notes Due 2030 (2) | Level 2 |  | $ | 1,676 |  |  | $ | — |  |
| 3.50% Notes Due 2040 (2) | Level 2 |  | $ | 1,163 |  |  | $ | — |  |
| 3.50% Notes Due 2050 (2) | Level 2 |  | $ | 2,311 |  |  | $ | — |  |
| 3.70% Notes Due 2060 (2) | Level 2 |  | $ | 594 |  |  | $ | — |  |

[0001045810-20-000189:notes:85]
(1)       Investment in non-affiliated entities is privately held and recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of October 25, 2020 has not been significant.
(2)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance   costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-20-000189:notes:86]
(1)       Investment in non-affiliated entities is privately held and recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of October 25, 2020 has not been significant.

[0001045810-20-000189:notes:87]
(2)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance   costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-20-000189:notes:88]
[same as prior period, unchanged from 0001045810-20-000147:notes:84]

[0001045810-20-000189:notes:89]
|  | October 25, 2020 |  | January 26, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,287 |  |  | $ | (642) |  |  | $ | 2,645 |  |  | $ | 195 |  |  | $ | (192) |  |  | $ | 3 |  |
| Patents and licensed technology | 705 |  |  | (489) |  |  | 216 |  |  | 520 |  |  | (474) |  |  | 46 |  |
| Total intangible assets | $ | 3,992 |  |  | $ | (1,131) |  |  | $ | 2,861 |  |  | $ | 715 |  |  | $ | (666) |  |  | $ | 49 |  |

[0001045810-20-000189:notes:90]
(1)     As of October 25, 2020, acquisition-related intangible assets include the fair value of a Mellanox IPR&D project of $630 million, which has not been amortized. Once the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for further details.

[0001045810-20-000189:notes:91]
Amortization expense associated with intangible assets was $174 million and $465 million for the third quarter and first nine months of fiscal year 2021, respectively, and $6 million and $19 million for the third quarter and first nine months of fiscal year 2020, respectively. Future amortization expense related to the net carrying amount of intangible assets as of October 25, 2020 is estimated to be $146 million for the remainder of fiscal year 2021, $542 million in fiscal year 2022, $539 million in fiscal year 2023, $418 million in fiscal year 2024, $364 million in fiscal year 2025, and $852 million in fiscal year 2026 and thereafter. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for further details on intangible assets.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-20-000189:notes:92]
[same as prior period, unchanged from 0001045810-20-000147:notes:88]

[0001045810-20-000189:notes:93]
|  | October 25, |  | January 26, |
|  | 2020 |  | 2020 |
| Inventories: | (In millions) |
| Raw materials | $ | 455 |  |  | $ | 249 |  |
| Work in-process | 380 |  |  | 265 |  |
| Finished goods | 660 |  |  | 465 |  |
| Total inventories | $ | 1,495 |  |  | $ | 979 |  |

[0001045810-20-000189:notes:94]
|  | October 25, |  | January 26, |
|  | 2020 |  | 2020 |
| Other assets: | (In millions) |
| Advanced consideration for acquisition (1) | $ | 1,357 |  |  | $ | — |  |
| Prepaid royalties (1) | 446 |  |  | 1 |  |
| Investment in non-affiliated entities | 106 |  |  | 77 |  |
| Other | 119 |  |  | 40 |  |
| Total other assets | $ | 2,028 |  |  | $ | 118 |  |

[0001045810-20-000189:notes:95]
(1)    Advanced consideration for acquisition and long-term prepaid royalties are related to the pending acquisition of Arm. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for further details.

[0001045810-20-000189:notes:96]
|  | October 25, |  | January 26, |
|  | 2020 |  | 2020 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 609 |  |  | $ | 462 |  |
| Accrued payroll and related expenses | 277 |  |  | 185 |  |
| Deferred revenue (1) | 235 |  |  | 141 |  |
| Licenses and royalties | 124 |  |  | 66 |  |
| Operating leases | 116 |  |  | 91 |  |
| Taxes payable | 70 |  |  | 61 |  |
| Product warranty and return provisions | 33 |  |  | 24 |  |
| Professional service fee | 28 |  |  | 18 |  |
| Coupon interest on debt obligations | 19 |  |  | 20 |  |
| Other | 63 |  |  | 29 |  |
| Total accrued and other current liabilities | $ | 1,574 |  |  | $ | 1,097 |  |

[0001045810-20-000189:notes:97]
(1)    Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and post contract customer support, or PCS.

[0001045810-20-000189:notes:98]
|  | October 25, |  | January 26, |
|  | 2020 |  | 2020 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 747 |  |  | $ | 528 |  |
| Deferred income tax (2) | 258 |  |  | 29 |  |
| Deferred revenue (3) | 147 |  |  | 60 |  |
| Licenses payable | 71 |  |  | 110 |  |
| Employee benefits | 40 |  |  | 22 |  |
| Other | 48 |  |  | 26 |  |
| Total other long-term liabilities | $ | 1,311 |  |  | $ | 775 |  |

[0001045810-20-000189:notes:99]
(1)    As of October 25, 2020, income tax payable represents the long-term portion of the one-time transition tax payable of $284 million, unrecognized tax benefits of $264 million, related interest and penalties of $46 million, and other foreign long-term tax payable of $153 million.

[0001045810-20-000189:notes:100]
(2)    Deferred income tax primarily relates to acquired intangible assets.

[0001045810-20-000189:notes:101]
(3)    Deferred revenue primarily includes deferrals related to PCS.

[0001045810-20-000189:notes:102]
[same as prior period, unchanged from 0001045810-20-000147:notes:96]

[0001045810-20-000189:notes:103]
The following table shows the changes in deferred revenue during the first nine months of fiscal years 2021 and 2020:

[0001045810-20-000189:notes:104]
|  | October 25, |  | October 27, |
|  | 2020 |  | 2019 |
|  | (In millions) |
| Balance at beginning of period | $ | 201 |  |  | $ | 138 |  |
| Deferred revenue added during the period | 361 |  |  | 237 |  |
| Addition due to business combinations | 75 |  |  | — |  |
| Revenue recognized during the period | (255) |  |  | (199) |  |
| Balance at end of period | $ | 382 |  |  | $ | 176 |  |

[0001045810-20-000189:notes:105]
Revenue related to remaining performance obligations represents the remaining contracted license, development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of October 25, 2020, the amount of our remaining performance obligations that has not been recognized as revenue was $679 million, of which we expect to recognize approximately 41% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-20-000189:notes:106]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of October 25, 2020 and January 26, 2020.

[0001045810-20-000189:notes:107]
[same as prior period, unchanged from 0001045810-20-000147:notes:101]

[0001045810-20-000189:notes:108]
The table below presents the notional value of our foreign currency forward contracts outstanding as of October 25, 2020 and January 26, 2020:

[0001045810-20-000189:notes:109]
|  | October 25,2020 |  | January 26,2020 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 744 |  |  | $ | 428 |  |
| Not designated for hedge accounting | $ | 352 |  |  | $ | 287 |  |

[0001045810-20-000189:notes:110]
As of October 25, 2020, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-20-000189:notes:111]
During the first nine months of fiscal years 2021 and 2020, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-20-000189:notes:112]
Debt
Long-Term Debt

[0001045810-20-000189:notes:113]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and issuance costs.

[0001045810-20-000189:notes:114]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-

[0001045810-20-000189:notes:115]
whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-20-000189:notes:116]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-20-000189:notes:117]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-20-000189:notes:118]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 25, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.4 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.4 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.5 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.5 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,961 |  |  | $ | 1,991 |  |

[0001045810-20-000189:notes:119]
As of October 25, 2020, we were in compliance with the required covenants under the Notes.

[0001045810-20-000189:notes:120]
Revolving Credit Facility

[0001045810-20-000189:notes:121]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 25, 2020, we had not borrowed any amounts and were in compliance with the required covenants under this agreement.

[0001045810-20-000189:notes:122]
Commercial Paper

[0001045810-20-000189:notes:123]
We have a $575 million commercial paper program to support general corporate purposes. As of October 25, 2020, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-20-000189:notes:124]
Commitments and Contingencies
Purchase Obligations

[0001045810-20-000189:notes:125]
As of October 25, 2020, we had outstanding inventory purchase obligations totaling $2.57 billion and other purchase obligations totaling $398 million.

[0001045810-20-000189:notes:126]
Accrual for Product Warranty Liabilities

[0001045810-20-000189:notes:127]
The estimated amount of product returns and warranty liabilities was $19 million and $15 million as of October 25, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.

[0001045810-20-000189:notes:128]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-20-000189:notes:129]
Litigation

[0001045810-20-000189:notes:130]
Securities Class Action and Derivative Lawsuits

[0001045810-20-000189:notes:131]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020.  The amended complaint asserts that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act.  Plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper.  On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the individual defendants.  As of September 14, 2020, the motion was fully briefed but the Court has not yet issued a decision.

[0001045810-20-000189:notes:132]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-20-000189:notes:133]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action.  The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-20-000189:notes:134]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-20-000189:notes:135]
Accounting for Loss Contingencies

[0001045810-20-000189:notes:136]
As of October 25, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-20-000189:notes:137]
[same as prior period, unchanged from 0001045810-20-000147:notes:130]

[0001045810-20-000189:notes:138]
[same as prior period, unchanged from 0001045810-20-000147:notes:131]

[0001045810-20-000189:notes:139]
Through October 25, 2020, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of October 25, 2020, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-20-000189:notes:140]
During the third quarter and first nine months of fiscal year 2021, we paid $99 million and $296 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-20-000189:notes:141]
[same as prior period, unchanged from 0001045810-20-000147:notes:134]

[0001045810-20-000189:notes:142]
[same as prior period, unchanged from 0001045810-20-000147:notes:135]

[0001045810-20-000189:notes:143]
[same as prior period, unchanged from 0001045810-20-000147:notes:136]

[0001045810-20-000189:notes:144]
[same as prior period, unchanged from 0001045810-20-000147:notes:137]

[0001045810-20-000189:notes:145]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-20-000189:notes:146]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 25, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 2,787 |  |  | $ | 1,939 |  |  | $ | — |  |  | $ | 4,726 |  |
| Operating income (loss) | $ | 1,345 |  |  | $ | 738 |  |  | $ | (685) |  |  | $ | 1,398 |  |
| Three Months Ended October 27, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 2,226 |  |  | $ | 788 |  |  | $ | — |  |  | $ | 3,014 |  |
| Operating income (loss) | $ | 1,068 |  |  | $ | 158 |  |  | $ | (299) |  |  | $ | 927 |  |
| Nine Months Ended October 25, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 6,778 |  |  | $ | 4,894 |  |  | $ | — |  |  | $ | 11,672 |  |
| Operating income (loss) | $ | 3,092 |  |  | $ | 1,880 |  |  | $ | (1,947) |  |  | $ | 3,025 |  |
| Nine Months Ended October 27, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 5,555 |  |  | $ | 2,258 |  |  | $ | — |  |  | $ | 7,813 |  |
| Operating income (loss) | $ | 2,307 |  |  | $ | 418 |  |  | $ | (869) |  |  | $ | 1,856 |  |

[0001045810-20-000189:notes:147]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25,2020 |  | October 27,2019 |  | October 25,2020 |  | October 27,2019 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (383) |  |  | $ | (223) |  |  | $ | (981) |  |  | $ | (624) |  |
| Acquisition-related and other costs | (192) |  |  | (7) |  |  | (669) |  |  | (22) |  |
| Unallocated cost of revenue and operating expenses | (89) |  |  | (69) |  |  | (259) |  |  | (210) |  |
| Legal settlement costs | (21) |  |  | — |  |  | (38) |  |  | (13) |  |
| Total | $ | (685) |  |  | $ | (299) |  |  | $ | (1,947) |  |  | $ | (869) |  |

[0001045810-20-000189:notes:148]
[same as prior period, unchanged from 0001045810-20-000147:notes:142]

[0001045810-20-000189:notes:149]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 27, |  | October 25, |  | October 27, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 1,296 |  |  | $ | 838 |  |  | $ | 3,062 |  |  | $ | 2,171 |  |
| China (including Hong Kong) | 1,113 |  |  | 758 |  |  | 2,727 |  |  | 1,894 |  |
| Other Asia Pacific | 955 |  |  | 805 |  |  | 2,260 |  |  | 1,983 |  |
| United States | 890 |  |  | 236 |  |  | 2,331 |  |  | 589 |  |
| Europe | 247 |  |  | 216 |  |  | 741 |  |  | 753 |  |
| Other countries | 225 |  |  | 161 |  |  | 551 |  |  | 423 |  |
| Total revenue | $ | 4,726 |  |  | $ | 3,014 |  |  | $ | 11,672 |  |  | $ | 7,813 |  |

[0001045810-20-000189:notes:150]
[same as prior period, unchanged from 0001045810-20-000147:notes:144]

[0001045810-20-000189:notes:151]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 27, |  | October 25, |  | October 27, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 2,271 |  |  | $ | 1,659 |  |  | $ | 5,264 |  |  | $ | 4,027 |  |
| Professional Visualization | 236 |  |  | 324 |  |  | 746 |  |  | 881 |  |
| Data Center | 1,900 |  |  | 726 |  |  | 4,793 |  |  | 2,015 |  |
| Automotive | 125 |  |  | 162 |  |  | 391 |  |  | 537 |  |
| OEM and Other | 194 |  |  | 143 |  |  | 478 |  |  | 353 |  |
| Total revenue | $ | 4,726 |  |  | $ | 3,014 |  |  | $ | 11,672 |  |  | $ | 7,813 |  |

[0001045810-20-000189:notes:152]
No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal year 2021. One customer represented 10% and 11% of our total revenue for the third quarter and first nine months of fiscal year 2020, respectively, and was attributable primarily to the Graphics segment.

[0001045810-20-000189:notes:153]
One customer represented 13% and 21% of our accounts receivable balance as of October 25, 2020 and January 26, 2020, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-20-000189:notes:154]
Goodwill During the first quarter of fiscal year 2021, we changed our operating segments to Graphics and Compute & Networking, as discussed in Note 15 of these Notes to Condensed Consolidated Financial Statements. As a result, our reporting units also changed, and we reassigned the goodwill balance to the new reporting units based on their relative fair values. We determined there was no goodwill impairment immediately prior to the reorganization. As of October 25, 2020, the total carrying amount of goodwill was $4.19 billion and the amount of goodwill allocated to our Graphics and Compute & Networking reporting units was $347 million and $3.85 billion, respectively. In the first nine months of fiscal year 2021, goodwill increased by $3.57 billion. The increase in goodwill in the first nine months of fiscal year 2021 was due to goodwill of $3.43 billion arising from the Mellanox acquisition, and goodwill of $133 million from other acquisition activity, both of which were allocated to the Compute & Networking reporting unit.
