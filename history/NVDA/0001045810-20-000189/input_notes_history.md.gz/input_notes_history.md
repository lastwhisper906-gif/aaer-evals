# NVDA note change history — 0001045810-20-000147 → 0001045810-20-000189


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-18):
[0001045810-20-000189:note_history:1]
As of October 25, 2020, we had outstanding inventory purchase obligations totaling $2.57 billion and other purchase obligations totaling $398 million.
  (was, 2020-08-19, similarity 0.96):
[0001045810-20-000147:note_history:1]
As of July 26, 2020, we had outstanding inventory purchase obligations totaling $2.04 billion and other purchase obligations totaling $310 million.

- changed (2020-11-18):
[0001045810-20-000189:note_history:2]
The estimated amount of product returns and warranty liabilities was $19 million and $15 million as of October 25, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.
  (was, 2020-08-19, similarity 0.6023):
[0001045810-20-000147:note_history:2]
The estimated amount of product returns and warranty liabilities was $19 million and $15 million as of July 26, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.

- added (2020-11-18):
[0001045810-20-000189:note_history:3]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020.  The amended complaint asserts that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act.  Plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper.  On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the individual defendants.  As of September 14, 2020, the motion was fully briefed but the Court has not yet issued a decision.

- added (2020-11-18):
[0001045810-20-000189:note_history:4]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

- changed (2020-11-18):
[0001045810-20-000189:note_history:5]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action.  The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2020-08-19, similarity 0.6738):
[0001045810-20-000147:note_history:5]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the Court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

- changed (2020-11-18):
[0001045810-20-000189:note_history:6]
As of October 25, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2020-08-19, similarity 0.9916):
[0001045810-20-000147:note_history:6]
As of July 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2020-11-18):
[0001045810-20-000147:note_history:7]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants. On March 16, 2020, the Court issued an order dismissing the consolidated class action complaint with leave to amend.  The plaintiffs filed an amended complaint on May 13, 2020.  On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

- removed (2020-11-18):
[0001045810-20-000147:note_history:8]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The Court approved the parties’ stipulation to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-18):
[0001045810-20-000189:note_history:9]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The third quarters of fiscal years 2021 and 2020 were both 13-week quarters.
  (was, 2020-08-19, similarity 0.7446):
[0001045810-20-000147:note_history:9]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The second quarters of fiscal years 2021 and 2020 were both 13-week quarters.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-18):
[0001045810-20-000189:note_history:10]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and issuance costs.
  (was, 2020-08-19, similarity 0.994):
[0001045810-20-000147:note_history:10]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and estimated issuance costs.

- changed (2020-11-18):
[0001045810-20-000189:note_history:11]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-
  (was, 2020-08-19, similarity 0.7728):
[0001045810-20-000147:note_history:11]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

- added (2020-11-18):
[0001045810-20-000189:note_history:12]
whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

- changed (2020-11-18):
[0001045810-20-000189:note_history:13]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 25, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.4 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.4 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.5 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.5 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,961 |  |  | $ | 1,991 |  |
  (was, 2020-08-19, similarity 0.9865):
[0001045810-20-000147:note_history:13]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.7 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.7 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.7 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.7 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,960 |  |  | $ | 1,991 |  |

- changed (2020-11-18):
[0001045810-20-000189:note_history:14]
As of October 25, 2020, we were in compliance with the required covenants under the Notes.
  (was, 2020-08-19, similarity 0.9333):
[0001045810-20-000147:note_history:14]
As of July 26, 2020, we were in compliance with the required covenants under the Notes.

- changed (2020-11-18):
[0001045810-20-000189:note_history:15]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 25, 2020, we had not borrowed any amounts and were in compliance with the required covenants under this agreement.
  (was, 2020-08-19, similarity 0.9236):
[0001045810-20-000147:note_history:15]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 26, 2020, we had not borrowed any amounts and were in compliance with the required covenants under this agreement.

- changed (2020-11-18):
[0001045810-20-000189:note_history:16]
We have a $575 million commercial paper program to support general corporate purposes. As of October 25, 2020, we had not issued any commercial paper.
  (was, 2020-08-19, similarity 0.9609):
[0001045810-20-000147:note_history:16]
We have a $575 million commercial paper program to support general corporate purposes. As of July 26, 2020, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-18):
[0001045810-20-000189:note_history:17]
The following is a summary of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020:
  (was, 2020-08-19, similarity 0.9479):
[0001045810-20-000147:note_history:17]
The following is a summary of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020:

- added (2020-11-18):
[0001045810-20-000189:note_history:18]
|  | October 25, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 3,881 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,881 |  |  | $ | 1,116 |  |  | $ | 2,765 |  |
| Corporate debt securities | 3,139 |  |  | 2 |  |  | — |  |  | 3,141 |  |  | 427 |  |  | 2,714 |  |
| Debt securities issued by United States government agencies | 1,571 |  |  | 1 |  |  | — |  |  | 1,572 |  |  | — |  |  | 1,572 |  |
| Certificates of deposit | 797 |  |  | — |  |  | — |  |  | 797 |  |  | 29 |  |  | 768 |  |
| Money market funds | 388 |  |  | — |  |  | — |  |  | 388 |  |  | 388 |  |  | — |  |
| Foreign government bonds | 117 |  |  | — |  |  | — |  |  | 117 |  |  | 48 |  |  | 69 |  |
| Total | $ | 9,893 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 9,896 |  |  | $ | 2,008 |  |  | $ | 7,888 |  |

- changed (2020-11-18):
[0001045810-20-000189:note_history:19]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |
  (was, 2020-08-19, similarity 0.9712):
[0001045810-20-000147:note_history:19]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- removed (2020-11-18):
[0001045810-20-000147:note_history:20]
|  | July 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 3,494 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3,497 |  |  | $ | 515 |  |  | $ | 2,982 |  |
| Debt securities issued by United States government agencies | 2,101 |  |  | 1 |  |  | — |  |  | 2,102 |  |  | 50 |  |  | 2,052 |  |
| Money market funds | 2,053 |  |  | — |  |  | — |  |  | 2,053 |  |  | 2,053 |  |  | — |  |
| Debt securities issued by the United States Treasury | 1,956 |  |  | — |  |  | — |  |  | 1,956 |  |  | — |  |  | 1,956 |  |
| Certificates of deposit | 893 |  |  | — |  |  | — |  |  | 893 |  |  | 342 |  |  | 551 |  |
| Foreign government bonds | 256 |  |  | — |  |  | — |  |  | 256 |  |  | 90 |  |  | 166 |  |
| Total | $ | 10,753 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 10,757 |  |  | $ | 3,050 |  |  | $ | 7,707 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-18):
[0001045810-20-000189:note_history:21]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities, except for money market funds and certificates of deposits, are classified as “available-for-sale” debt securities.
  (was, 2020-08-19, similarity 0.8262):
[0001045810-20-000147:note_history:21]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

- changed (2020-11-18):
[0001045810-20-000189:note_history:22]
The following is a summary of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020:
  (was, 2020-08-19, similarity 0.9479):
[0001045810-20-000147:note_history:22]
The following is a summary of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020:

- added (2020-11-18):
[0001045810-20-000189:note_history:23]
|  | October 25, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 3,881 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,881 |  |  | $ | 1,116 |  |  | $ | 2,765 |  |
| Corporate debt securities | 3,139 |  |  | 2 |  |  | — |  |  | 3,141 |  |  | 427 |  |  | 2,714 |  |
| Debt securities issued by United States government agencies | 1,571 |  |  | 1 |  |  | — |  |  | 1,572 |  |  | — |  |  | 1,572 |  |
| Certificates of deposit | 797 |  |  | — |  |  | — |  |  | 797 |  |  | 29 |  |  | 768 |  |
| Money market funds | 388 |  |  | — |  |  | — |  |  | 388 |  |  | 388 |  |  | — |  |
| Foreign government bonds | 117 |  |  | — |  |  | — |  |  | 117 |  |  | 48 |  |  | 69 |  |
| Total | $ | 9,893 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 9,896 |  |  | $ | 2,008 |  |  | $ | 7,888 |  |

- changed (2020-11-18):
[0001045810-20-000189:note_history:24]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |
  (was, 2020-08-19, similarity 0.9712):
[0001045810-20-000147:note_history:24]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- changed (2020-11-18):
[0001045810-20-000189:note_history:25]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 25, 2020 and January 26, 2020 are shown below by contractual maturity.
  (was, 2020-08-19, similarity 0.9662):
[0001045810-20-000147:note_history:25]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 26, 2020 and January 26, 2020 are shown below by contractual maturity.

- added (2020-11-18):
[0001045810-20-000189:note_history:26]
|  | October 25, 2020 |  | January 26, 2020 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 9,329 |  |  | $ | 9,330 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 564 |  |  | 566 |  |  | — |  |  | — |  |
| Total | $ | 9,893 |  |  | $ | 9,896 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |

- removed (2020-11-18):
[0001045810-20-000147:note_history:27]
|  | July 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 3,494 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3,497 |  |  | $ | 515 |  |  | $ | 2,982 |  |
| Debt securities issued by United States government agencies | 2,101 |  |  | 1 |  |  | — |  |  | 2,102 |  |  | 50 |  |  | 2,052 |  |
| Money market funds | 2,053 |  |  | — |  |  | — |  |  | 2,053 |  |  | 2,053 |  |  | — |  |
| Debt securities issued by the United States Treasury | 1,956 |  |  | — |  |  | — |  |  | 1,956 |  |  | — |  |  | 1,956 |  |
| Certificates of deposit | 893 |  |  | — |  |  | — |  |  | 893 |  |  | 342 |  |  | 551 |  |
| Foreign government bonds | 256 |  |  | — |  |  | — |  |  | 256 |  |  | 90 |  |  | 166 |  |
| Total | $ | 10,753 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 10,757 |  |  | $ | 3,050 |  |  | $ | 7,707 |  |

- removed (2020-11-18):
[0001045810-20-000147:note_history:28]
|  | July 26, 2020 |  |  |  | January 26, 2020 |  |  |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |  |  |  |  |  |  |
| Less than one year | $ | 10,027 |  |  | $ | 10,028 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 726 |  |  | 729 |  |  | — |  |  | — |  |
| Total | $ | 10,753 |  |  | $ | 10,757 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-18):
[0001045810-20-000189:note_history:29]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 25, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.4 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.4 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.5 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.5 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,961 |  |  | $ | 1,991 |  |
  (was, 2020-08-19, similarity 0.9865):
[0001045810-20-000147:note_history:29]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.7 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.7 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.7 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.7 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,960 |  |  | $ | 1,991 |  |
