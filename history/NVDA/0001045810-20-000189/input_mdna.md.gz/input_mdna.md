# NVDA MD&A — 0001045810-20-000189


## mdna

[0001045810-20-000189:mdna:1]
[same as prior period, unchanged from 0001045810-20-000147:mdna:1]

[0001045810-20-000189:mdna:2]
[same as prior period, unchanged from 0001045810-20-000147:mdna:2]

[0001045810-20-000189:mdna:3]
[same as prior period, unchanged from 0001045810-20-000147:mdna:3]

[0001045810-20-000189:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, DRIVE AGX Orin, GeForce NOW, GeForce RTX SUPER, NVIDIA A100, NVIDIA Broadcast, NVIDIA CloudXR, NVIDIA CUDA, NVIDIA DLSS, NVIDIA DGX A100, NVIDIA DGX SuperPOD, NVIDIA DRIVE,  NVIDIA EGX, NVIDIA GRID, NVIDIA Jarvis, NVIDIA Jetson, NVIDIA Maxine, NVIDIA Merlin, NVIDIA Omniverse, NVIDIA Omniverse Machinima, NVIDIA Reflex, NVIDIA RTX, Mellanox, Quadro, Quadro RTX, Quadro View and Tegra are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-20-000189:mdna:5]
[same as prior period, unchanged from 0001045810-20-000147:mdna:5]

[0001045810-20-000189:mdna:6]
25

[0001045810-20-000189:mdna:7]
[same as prior period, unchanged from 0001045810-20-000147:mdna:6]

[0001045810-20-000189:mdna:8]
[same as prior period, unchanged from 0001045810-20-000147:mdna:7]

[0001045810-20-000189:mdna:9]
[same as prior period, unchanged from 0001045810-20-000147:mdna:8]

[0001045810-20-000189:mdna:10]
[same as prior period, unchanged from 0001045810-20-000147:mdna:9]

[0001045810-20-000189:mdna:11]
[same as prior period, unchanged from 0001045810-20-000147:mdna:10]

[0001045810-20-000189:mdna:12]
[same as prior period, unchanged from 0001045810-20-000147:mdna:11]

[0001045810-20-000189:mdna:13]
[same as prior period, unchanged from 0001045810-20-000147:mdna:12]

[0001045810-20-000189:mdna:14]
[same as prior period, unchanged from 0001045810-20-000147:mdna:13]

[0001045810-20-000189:mdna:15]
[same as prior period, unchanged from 0001045810-20-000147:mdna:15]

[0001045810-20-000189:mdna:16]
Pending Acquisition of Arm Limited

[0001045810-20-000189:mdna:17]
On September 13, 2020, we entered into a Purchase Agreement with Arm and SoftBank for us to acquire, from SoftBank, all of the allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid $2 billion in Signing Consideration and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 44.3 million shares of our common stock with an aggregate value of $21.5 billion. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial performance targets are achieved, Softbank can elect to receive either up to $5 billion in cash or up to 10.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The $2 billion payment upon signing was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. We believe the closing of the acquisition will likely occur in the first quarter of calendar year 2022.

[0001045810-20-000189:mdna:18]
[same as prior period, unchanged from 0001045810-20-000147:mdna:16]

[0001045810-20-000189:mdna:19]
The worldwide COVID-19 pandemic is prompting governments and businesses to take unprecedented measures including restrictions on travel, temporary business closures, quarantines and shelter-in-place orders. It has significantly impacted global economic activity and caused volatility and disruption in global financial markets. Since March 2020, most of our employees have been working remotely and we have temporarily prohibited most business travel.

[0001045810-20-000189:mdna:20]
Our Gaming and Data Center market platforms have benefited from stronger demand as people continue to work, learn, and play from home. In Professional Visualization, stronger demand for mobile workstations due to work from home trends was partially offset by lower demand for desktop workstations. In Automotive, customers' production volumes have largely returned to pre-COVID levels. In our supply chain, stronger demand globally has limited the availability of capacity and components.

[0001045810-20-000189:mdna:21]
As the COVID-19 pandemic continues, the timing and overall demand from customers and the availability of supply chain, logistical services and component supply may have a material net negative impact on our business and financial results. Refer to Part II, Item 1A of this Quarterly Report on Form 10-Q for additional information under the heading “Risk Factors”.

[0001045810-20-000189:mdna:22]
[same as prior period, unchanged from 0001045810-20-000147:mdna:20]

[0001045810-20-000189:mdna:23]
Third Quarter of Fiscal Year 2021 Summary

[0001045810-20-000189:mdna:24]
|  | Three Months Ended |  |  |  |  |
|  | October 25, 2020 |  | July 26, 2020 |  | October 27, 2019 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 4,726 |  |  | $ | 3,866 |  |  | $ | 3,014 |  |  | 22 | % |  | 57 | % |
| Gross margin | 62.6 | % |  | 58.8 | % |  | 63.6 | % |  | 380 bps |  | (100) bps |
| Operating expenses | $ | 1,562 |  |  | $ | 1,624 |  |  | $ | 989 |  |  | (4) | % |  | 58 | % |
| Income from operations | $ | 1,398 |  |  | $ | 651 |  |  | $ | 927 |  |  | 115 | % |  | 51 | % |
| Net income | $ | 1,336 |  |  | $ | 622 |  |  | $ | 899 |  |  | 115 | % |  | 49 | % |
| Net income per diluted share | $ | 2.12 |  |  | $ | 0.99 |  |  | $ | 1.45 |  |  | 114 | % |  | 46 | % |

[0001045810-20-000189:mdna:25]
[same as prior period, unchanged from 0001045810-20-000147:mdna:14]

[0001045810-20-000189:mdna:26]
Revenue for the third quarter of fiscal year 2021 was $4.73 billion, up 57% from a year earlier and up 22% sequentially.

[0001045810-20-000189:mdna:27]
Graphics segment revenue was $2.79 billion, up 25% from a year earlier and up 34% sequentially.

[0001045810-20-000189:mdna:28]
Compute & Networking segment revenue was $1.94 billion, up 146% from a year ago and up 9% sequentially.

[0001045810-20-000189:mdna:29]
From a market-platform perspective, Gaming revenue was $2.27 billion, up 37% both from a year ago and sequentially. The increases reflect higher sales across desktop and notebook gaming GPUs, and game console SOCs. Desktop gaming sales benefited from the launch of our GeForce RTX 30 Series based on the NVIDIA Ampere architecture.

[0001045810-20-000189:mdna:30]
Professional Visualization revenue was $236 million, down 27% from a year earlier and up 16% sequentially. The year-on-year decline was influenced by COVID-19, with reduced demand for desktop workstations. The sequential increase reflects a sharp rebound in mobile workstations due to work from home trends.

[0001045810-20-000189:mdna:31]
Data Center revenue was $1.90 billion, up 162% from a year ago and up 8% sequentially. Our recent acquisition of Mellanox contributed 13% of total company revenue and approximately a third of Data Center revenue. In addition to Mellanox, the year-on-year and sequential increases were driven by the ramp of NVIDIA Ampere architecture products.

[0001045810-20-000189:mdna:32]
Automotive revenue was $125 million, down 23% from a year earlier and up 13% sequentially. The year-on-year decrease reflects a decline in revenue from legacy infotainment modules and autonomous driving development agreements. The sequential increase reflects higher sales of AI cockpit solutions.

[0001045810-20-000189:mdna:33]
OEM and Other revenue was $194 million, up 36% from a year ago and up 33% sequentially, primarily due to higher volume of entry-level laptop GPUs.

[0001045810-20-000189:mdna:34]
Gross margin was 62.6% in the third quarter, down 100 basis points from a year earlier and up 380 basis points sequentially. The year-on-year decline reflects charges related to the Mellanox acquisition and lower margins in Gaming, partially offset by a shift in product mix with higher Data Center and lower Automotive sales. The sequential increase was primarily driven by the absence of a non-recurring inventory step-up expense related to the Mellanox acquisition in the prior quarter.

[0001045810-20-000189:mdna:35]
Operating expenses were $1.56 billion, up 58% from a year earlier and down 4% sequentially. The year-on-year increase was primarily driven by compensation-related costs, the Mellanox acquisition, infrastructure costs, and employee growth. The sequential decrease was due to a reduction in acquisition-related costs.

[0001045810-20-000189:mdna:36]
Income from operations was $1.40 billion, up 51% from a year earlier and up 115% sequentially. Net income was $1.34 billion. Net income per diluted share was $2.12, up 46% from a year earlier and up 114% sequentially.

[0001045810-20-000189:mdna:37]
Cash, cash equivalents and marketable securities at the end of the third quarter were $10.14 billion, up from $9.77 billion a year earlier and down from $10.98 billion in the prior quarter. The year-on-year increase primarily reflects the issuance of the $5 billion of notes in March 2020 and cash flow generation, partially offset by acquisitions. The sequential decrease primarily reflects the $2 billion payment under the Purchase Agreement to acquire Arm.

[0001045810-20-000189:mdna:38]
We paid $99 million in quarterly cash dividends in the third quarter.

[0001045810-20-000189:mdna:39]
[same as prior period, unchanged from 0001045810-20-000147:mdna:36]

[0001045810-20-000189:mdna:40]
During the third quarter of fiscal year 2021, in our Gaming platform, we unveiled GeForce RTX 30 Series GPUs; announced that Fortnite will support NVIDA RTX real-time ray tracing and DLSS AI super-resolution; introduced NVIDIA Reflex; and unveiled NVIDIA Broadcast.

[0001045810-20-000189:mdna:41]
In our Professional Visualization platform, we brought to open beta NVIDIA Omniverse; announced NVIDIA Omniverse Machinima; and collaborated with Adobe to bring GPU-accelerated neural filters to Adobe Photoshop AI-powered tools.

[0001045810-20-000189:mdna:42]
In our Data Center platform, we shared news that Amazon Web Services and Oracle Cloud Infrastructure announced general availability of cloud computing instances based on the NVIDIA A100 GPU; announced the NVIDIA DGX SuperPOD Solution for Enterprise; announced that five supercomputers backed by EuroHPC will use NVIDIA’s data center accelerators or networking; introduced the new family of NVIDIA BlueField-2 DPUs (data processing units); announced a broad partnership with VMware to create an end-to-end enterprise platform for AI and a new architecture for data center, cloud and edge; unveiled NVIDIA Maxine; introduced the NVIDIA RTX A6000 and NVIDIA A40 GPUs; extended our lead on MLPerf performance benchmarks for inference; announced a partnership with GSK to integrate computing

[0001045810-20-000189:mdna:43]
platforms for imaging, genomics and AI into the drug and vaccine discovery process; and introduced NVIDIA A100 80GB GPU, NVIDIA DGX Station A100, and NVIDIA Mellanox InfiniBand.

[0001045810-20-000189:mdna:44]
In our Automotive platform, we announced with Mercedes-Benz that NVIDIA is powering the next-generation MBUX AI cockpit system; announced with Hyundai Motor Group that the Korean automaker’s entire lineup of Hyundai, Kia and Genesis models will come standard with NVIDIA DRIVE in-vehicle infotainment systems, starting in 2022; and announced that China’s Li Auto will develop its next-generation of electric vehicles using NVIDIA DRIVE AGX Orin, a software-defined platform for autonomous vehicles.

[0001045810-20-000189:mdna:45]
[same as prior period, unchanged from 0001045810-20-000147:mdna:44]

[0001045810-20-000189:mdna:46]
[same as prior period, unchanged from 0001045810-20-000147:mdna:45]

[0001045810-20-000189:mdna:47]
[same as prior period, unchanged from 0001045810-20-000147:mdna:46]

[0001045810-20-000189:mdna:48]
Management’s discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. Our management has discussed the development and selection of these critical accounting policies and estimates with the Audit Committee of our Board of Directors. The Audit Committee has reviewed our disclosures relating to our critical accounting policies and estimates in this Quarterly Report on Form 10-Q. Due to the Mellanox acquisition, we added the following critical accounting policy:

[0001045810-20-000189:mdna:49]
[same as prior period, unchanged from 0001045810-20-000147:mdna:50]

[0001045810-20-000189:mdna:50]
[same as prior period, unchanged from 0001045810-20-000147:mdna:51]

[0001045810-20-000189:mdna:51]
[same as prior period, unchanged from 0001045810-20-000147:mdna:52]

[0001045810-20-000189:mdna:52]
[same as prior period, unchanged from 0001045810-20-000147:mdna:53]

[0001045810-20-000189:mdna:53]
[same as prior period, unchanged from 0001045810-20-000147:mdna:55]

[0001045810-20-000189:mdna:54]
[same as prior period, unchanged from 0001045810-20-000147:mdna:56]

[0001045810-20-000189:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25,2020 |  | October 27,2019 |  | October 25,2020 |  | October 27,2019 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 37.4 |  |  | 36.4 |  |  | 38.0 |  |  | 39.2 |  |
| Gross profit | 62.6 |  |  | 63.6 |  |  | 62.0 |  |  | 60.8 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 22.2 |  |  | 23.6 |  |  | 23.8 |  |  | 26.8 |  |
| Sales, general and administrative | 10.9 |  |  | 9.2 |  |  | 12.3 |  |  | 10.3 |  |
| Total operating expenses | 33.1 |  |  | 32.8 |  |  | 36.1 |  |  | 37.1 |  |
| Income from operations | 29.5 |  |  | 30.8 |  |  | 25.9 |  |  | 23.7 |  |
| Interest income | 0.1 |  |  | 1.5 |  |  | 0.4 |  |  | 1.8 |  |
| Interest expense | (1.1) |  |  | (0.4) |  |  | (1.1) |  |  | (0.5) |  |
| Other, net | (0.1) |  |  | — |  |  | — |  |  | — |  |
| Other income (expense), net | (1.1) |  |  | 1.1 |  |  | (0.7) |  |  | 1.3 |  |
| Income before income tax | 28.4 |  |  | 31.9 |  |  | 25.2 |  |  | 25.0 |  |
| Income tax expense | 0.3 |  |  | 2.0 |  |  | 0.5 |  |  | 1.4 |  |
| Net income | 28.1 | % |  | 29.9 | % |  | 24.7 | % |  | 23.6 | % |

[0001045810-20-000189:mdna:56]
[same as prior period, unchanged from 0001045810-20-000147:mdna:58]

[0001045810-20-000189:mdna:57]
[same as prior period, unchanged from 0001045810-20-000147:mdna:59]

[0001045810-20-000189:mdna:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25,2020 |  | October 27,2019 |  | $Change |  | %Change |  | October 25,2020 |  | October 27,2019 |  | $Change |  | %Change |
|  | ($ in millions) |
| Graphics | $ | 2,787 |  |  | $ | 2,226 |  |  | $ | 561 |  |  | 25 | % |  | $ | 6,778 |  |  | $ | 5,555 |  |  | $ | 1,223 |  |  | 22 | % |
| Compute & Networking | 1,939 |  |  | 788 |  |  | 1,151 |  |  | 146 | % |  | 4,894 |  |  | 2,258 |  |  | 2,636 |  |  | 117 | % |
| Total | $ | 4,726 |  |  | $ | 3,014 |  |  | $ | 1,712 |  |  | 57 | % |  | $ | 11,672 |  |  | $ | 7,813 |  |  | $ | 3,859 |  |  | 49 | % |

[0001045810-20-000189:mdna:59]
Graphics - Graphics segment revenue for the third quarter of fiscal year 2021 compared to the third quarter of fiscal year 2020 increased by 25% and revenue for the first nine months of fiscal year 2021 compared to the first nine months of fiscal year 2020 increased by 22%. These increases reflect growth in GeForce GPUs and game console SOCs, partially offset by lower sales of Quadro workstations.

[0001045810-20-000189:mdna:60]
Compute & Networking - Compute & Networking segment revenue for the third quarter of fiscal year 2021 compared to the third quarter of fiscal year 2020 increased by 146% and revenue for the first nine months of fiscal year 2021 compared to the first nine months of fiscal year 2020 increased by 117%. These increases reflect the addition of Mellanox acquired on April 27, 2020 and the continued ramp of NVIDIA Ampere GPU architecture systems and new products, partially offset by lower autonomous driving development agreement revenue.

[0001045810-20-000189:mdna:61]
[same as prior period, unchanged from 0001045810-20-000147:mdna:64]

[0001045810-20-000189:mdna:62]
Revenue from sales to customers outside of the United States accounted for 81% and 80% of total revenue for the third quarter and first nine months of fiscal year 2021, respectively, and 92% of total revenue for the third quarter and first nine months of fiscal year 2020. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-20-000189:mdna:63]
No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal year 2021. One customer represented 10% and 11% of our total revenue for the third quarter and first nine months of fiscal year 2020, respectively, and was attributable primarily to the Graphics segment.

[0001045810-20-000189:mdna:64]
[same as prior period, unchanged from 0001045810-20-000147:mdna:68]

[0001045810-20-000189:mdna:65]
Our overall gross margin decreased to 62.6% for the third quarter of fiscal year 2021 from 63.6% for the third quarter of fiscal year 2020, reflecting charges related to the Mellanox acquisition and lower margins in Gaming, partially offset by a shift in product mix with higher Data Center and lower Automotive sales. Our overall gross margin increased to 62.0% for the first nine months of fiscal year 2021 from 60.8% for the first nine months of fiscal year 2020, primarily driven by Mellanox products, lower Automotive sales and lower product costs within Compute & Networking, partially offset by Mellanox acquisition-related costs including a non-recurring inventory step-up charge of $161 million and ongoing intangible asset amortization of $171 million.

[0001045810-20-000189:mdna:66]
Inventory provisions totaled $15 million and $42 million for the third quarter of fiscal years 2021 and 2020, respectively. Sales of inventory that was previously written-off or -down totaled $29 million and $78 million for the third quarter of fiscal years 2021 and 2020, respectively. As a result, the overall net effect on our gross margin was a favorable impact of 0.3% and 1.2% in the third quarter of fiscal years 2021 and 2020, respectively.

[0001045810-20-000189:mdna:67]
Inventory provisions totaled $96 million and $114 million for the first nine months of fiscal years 2021 and 2020, respectively. Sales of inventory that was previously written-off or -down totaled $116 million and $109 million for the first nine months of fiscal years 2021 and 2020, respectively. As a result, the overall net effect on our gross margin was a favorable impact of 0.2% in the first nine months of fiscal year 2021 and an unfavorable impact of 0.1% for the first nine months of fiscal year 2020.

[0001045810-20-000189:mdna:68]
[same as prior period, unchanged from 0001045810-20-000147:mdna:72]

[0001045810-20-000189:mdna:69]
Graphics - The gross margin of our Graphics segment decreased during the third quarter of fiscal year 2021 compared to the third quarter of fiscal year 2020, primarily driven by a shift in product mix and higher product costs. The gross margin of our Graphics segment increased during the first nine months of fiscal year 2021 compared to the first nine months of fiscal year 2020, primarily driven by lower legacy infotainment sales and product mix within Quadro.

[0001045810-20-000189:mdna:70]
Compute & Networking - The gross margin of our Compute & Networking segment increased during the third quarter and first nine months of fiscal year 2021 compared to the third quarter and first nine months of fiscal year 2020, primarily driven by Mellanox products and lower product costs.

[0001045810-20-000189:mdna:71]
[same as prior period, unchanged from 0001045810-20-000147:mdna:75]

[0001045810-20-000189:mdna:72]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25,2020 |  | October 27,2019 |  | $Change |  | %Change |  | October 25,2020 |  | October 27,2019 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 1,047 |  |  | $ | 712 |  |  | $ | 335 |  |  | 47 | % |  | $ | 2,778 |  |  | $ | 2,091 |  |  | $ | 687 |  |  | 33 | % |
| % of net revenue | 22 | % |  | 24 | % |  |  |  |  |  | 24 | % |  | 27 | % |  |  |  |  |
| Sales, general and administrative expenses | 515 |  |  | 277 |  |  | 238 |  |  | 86 | % |  | 1,437 |  |  | 806 |  |  | 631 |  |  | 78 | % |
| % of net revenue | 11 | % |  | 9 | % |  |  |  |  |  | 12 | % |  | 10 | % |  |  |  |  |
| Total operating expenses | $ | 1,562 |  |  | $ | 989 |  |  | $ | 573 |  |  | 58 | % |  | $ | 4,215 |  |  | $ | 2,897 |  |  | $ | 1,318 |  |  | 45 | % |

[0001045810-20-000189:mdna:73]
[same as prior period, unchanged from 0001045810-20-000147:mdna:77]

[0001045810-20-000189:mdna:74]
Research and development expenses increased by 47% and 33% during the third quarter and first nine months of fiscal year 2021, compared to the third quarter and first nine months of fiscal year 2020, respectively, primarily driven by expenses related to the Mellanox acquisition. In addition to Mellanox, increases reflect employee compensation and related costs, including stock-based compensation, and infrastructure costs.

[0001045810-20-000189:mdna:75]
[same as prior period, unchanged from 0001045810-20-000147:mdna:80]

[0001045810-20-000189:mdna:76]
Sales, general and administrative expenses increased by 86% and 78% during the third quarter and first nine months of fiscal year 2021, compared to the third quarter of fiscal year 2020, respectively, primarily driven by Mellanox acquisition-related expenses. In addition to Mellanox, increases reflect employee compensation and related costs, including stock-based compensation.

[0001045810-20-000189:mdna:77]
[same as prior period, unchanged from 0001045810-20-000147:mdna:82]

[0001045810-20-000189:mdna:78]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $7 million and $45 million during the third quarter of fiscal years 2021 and 2020, respectively, and $50 million and $137 million during the first nine months of fiscal years 2021 and 2020, respectively. The decrease in interest income was primarily due to lower interest earned on our investments.

[0001045810-20-000189:mdna:79]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our September 2016 Notes and March 2020 Notes. Interest expense was $53 million and $13 million during the third quarter of fiscal years 2021 and 2020, respectively, and $131 million and $39 million during the first nine months of fiscal years 2021 and 2020, respectively.

[0001045810-20-000189:mdna:80]
[same as prior period, unchanged from 0001045810-20-000147:mdna:86]

[0001045810-20-000189:mdna:81]
We recognized an income tax expense of $12 million and $64 million for the third quarter and first nine months of fiscal year 2021, respectively, and $60 million and $109 million for the third quarter and first nine months of fiscal year 2020, respectively. The income tax expense as a percentage of income before income tax was 0.9% and 2.2% for the third quarter and first nine months of fiscal year 2021, respectively, and 6.3% and 5.6% for the third quarter and first nine months of fiscal year 2020, respectively.

[0001045810-20-000189:mdna:82]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2021 as compared to the same periods of fiscal year 2020 was primarily due to a decrease in the proportional amount of earnings subject to United States tax and an increase of tax benefits from stock-based compensation.

[0001045810-20-000189:mdna:83]
[same as prior period, unchanged from 0001045810-20-000147:mdna:89]

[0001045810-20-000189:mdna:84]
[same as prior period, unchanged from 0001045810-20-000147:mdna:90]

[0001045810-20-000189:mdna:85]
|  | October 25, 2020 |  | January 26, 2020 |
|  | (In millions) |
| Cash and cash equivalents | $ | 2,251 |  |  | $ | 10,896 |  |
| Marketable securities | 7,888 |  |  | 1 |  |
| Cash, cash equivalents and marketable securities | $ | 10,139 |  |  | $ | 10,897 |  |

[0001045810-20-000189:mdna:86]
|  | Nine Months Ended |
|  | October 25, 2020 |  | October 27, 2019 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 3,755 |  |  | $ | 3,296 |  |
| Net cash provided by (used in) investing activities | $ | (16,546) |  |  | $ | 6,296 |  |
| Net cash provided by (used in) financing activities | $ | 4,146 |  |  | $ | (609) |  |

[0001045810-20-000189:mdna:87]
As of October 25, 2020, we had $10.14 billion in cash, cash equivalents and marketable securities, a decrease of $758 million from the end of fiscal year 2020. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-20-000189:mdna:88]
In the third quarter of fiscal year 2021, we paid $2 billion as part of the proposed acquisition of Arm, which was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion. The cash flow allocation of the payment resulted in $1.36 billion advanced consideration included in acquisitions, net of cash acquired, $0.17 billion for the intellectual property license included in purchases related to property and equipment and intangible assets and $0.47 billion prepayment of royalties included in changes in prepaid expenses and other assets.

[0001045810-20-000189:mdna:89]
Cash provided by operating activities increased in the first nine months of fiscal year 2021 compared to the first nine months of fiscal year 2020, due to higher net income, partially offset by changes in working capital. Changes in working capital include increases in outstanding trade receivables, purchases of inventory, and a prepayment of royalties to Arm.

[0001045810-20-000189:mdna:90]
Cash used in investing activities increased in the first nine months of fiscal year 2021 compared to cash provided in the first nine months of fiscal year 2020, which primarily reflects cash used for the acquisition of Mellanox and the advanced consideration for the proposed acquisition of Arm, higher purchases of marketable securities, higher maturities of marketable securities, higher purchases of property and equipment and intangible assets, and lower sales of marketable securities.

[0001045810-20-000189:mdna:91]
Cash provided by financing activities increased in the first nine months of fiscal year 2021 compared to cash used in the first nine months of fiscal year 2020, which primarily reflects the debt issued in the first quarter of fiscal year 2021 and payments related to tax on restricted stock units.

[0001045810-20-000189:mdna:92]
[same as prior period, unchanged from 0001045810-20-000147:mdna:97]

[0001045810-20-000189:mdna:93]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of October 25, 2020, we had $10.14 billion in cash, cash equivalents and marketable securities. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, and certificates of deposits. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements and capital expenditures for at least the next twelve months.

[0001045810-20-000189:mdna:94]
We have approximately $1.2 billion of cash, cash equivalents, and marketable securities that we have not accrued any related foreign or state taxes if we repatriate these amounts to the United States. Other than that, as a result of the Tax Cuts and Jobs Act, or TCJA, substantially all of our cash, cash equivalents and marketable securities held outside of the

[0001045810-20-000189:mdna:95]
33

[0001045810-20-000189:mdna:96]
United States as of October 25, 2020 are available for use in the United States without incurring additional U.S. federal income taxes.

[0001045810-20-000189:mdna:97]
[same as prior period, unchanged from 0001045810-20-000147:mdna:100]

[0001045810-20-000189:mdna:98]
In the first nine months of fiscal year 2021, we paid $296 million in quarterly cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-20-000189:mdna:99]
As of October 25, 2020, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022. We did not repurchase any shares during the first nine months of fiscal year 2021.

[0001045810-20-000189:mdna:100]
[same as prior period, unchanged from 0001045810-20-000147:mdna:103]

[0001045810-20-000189:mdna:101]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discounts and issuance costs.

[0001045810-20-000189:mdna:102]
[same as prior period, unchanged from 0001045810-20-000147:mdna:105]

[0001045810-20-000189:mdna:103]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 25, 2020, we had not borrowed any amounts under this agreement.

[0001045810-20-000189:mdna:104]
We have a $575 million commercial paper program to support general corporate purposes. As of October 25, 2020, we had not issued any commercial paper.

[0001045810-20-000189:mdna:105]
[same as prior period, unchanged from 0001045810-20-000147:mdna:108]

[0001045810-20-000189:mdna:106]
As of October 25, 2020, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-20-000189:mdna:107]
[same as prior period, unchanged from 0001045810-20-000147:mdna:110]

[0001045810-20-000189:mdna:108]
There are $155 million of long-term tax liabilities related to tax basis differences in Mellanox and unrecognized tax benefits of $310 million, which includes related interest and penalties of $46 million recorded in non-current income tax payable as of October 25, 2020. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-20-000189:mdna:109]
[same as prior period, unchanged from 0001045810-20-000147:mdna:112]

[0001045810-20-000189:mdna:110]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000189:mdna:111]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
