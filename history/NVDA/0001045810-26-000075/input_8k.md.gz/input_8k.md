# NVDA 8-K — 0001045810-26-000073 filed 2026-08-26

## item codes, every 8-K on or before 2026-08-26

- 2026-08-26 0001045810-26-000073 — 2.02, 9.01
- 2026-08-17 0001045810-26-000069 — 1.01, 2.03, 7.01
- 2026-07-02 0001045810-26-000060 — 5.02
- 2026-06-30 0001045810-26-000056 — 5.07
- 2026-06-18 0001193125-26-275783 — 8.01, 9.01
- 2026-05-20 0001045810-26-000051 — 2.02, 9.01
- 2026-05-08 0001045810-26-000028 — 5.02
- 2026-04-27 0001045810-26-000026 — 5.02
- 2026-03-06 0001045810-26-000024 — 5.02, 9.01
- 2026-02-25 0001045810-26-000019 — 2.02, 9.01
- 2026-01-23 0001045810-26-000003 — 5.02
- 2025-11-19 0001045810-25-000228 — 2.02, 9.01
- 2025-08-27 0001045810-25-000207 — 2.02, 9.01
- 2025-08-05 0001045810-25-000197 — 5.02
- 2025-07-01 0001045810-25-000179 — 5.07
- 2025-05-28 0001045810-25-000115 — 2.02, 9.01
- 2025-04-15 0001045810-25-000082 — 8.01
- 2025-03-07 0001045810-25-000039 — 5.02
- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2026-08-26

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-26-000073:8k_2_02:1]
EX-99.1
2
q2fy27pr.htm
EX-99.1

[0001045810-26-000073:8k_2_02:2]
Document

[0001045810-26-000073:8k_2_02:3]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2027

[0001045810-26-000073:8k_2_02:4]
•Revenue of $96.2 billion, up 106% from a year ago

[0001045810-26-000073:8k_2_02:5]
•Data Center revenue of $89.0 billion, up 117% from a year ago

[0001045810-26-000073:8k_2_02:6]
SANTA CLARA, Calif.—Aug. 26, 2026―NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 26, 2026, of $96.2 billion, up 18% from the previous quarter and up 106% from a year ago. For the quarter, GAAP and non-GAAP gross margins were both 75.0%. GAAP and non-GAAP earnings per diluted share were $2.46 and $2.22, respectively.

[0001045810-26-000073:8k_2_02:7]
“AI has reached its inflection point. It’s doing useful work. Its tokens are productive and profitable. Now, compute is revenue,” said Jensen Huang, founder and CEO of NVIDIA. “And demand is accelerating. This time last year, one lab alone was driving the buildout; today, we have a golden age of new AI labs and startups, multiple frontier labs scaling in parallel, a thriving open-model ecosystem and physical AI coming online — with strong momentum across the U.S. and around the world. The AI infrastructure buildout is at full steam. Vera Rubin, now in full production, was built to power exactly this moment.”

[0001045810-26-000073:8k_2_02:8]
During the second quarter of fiscal 2027, NVIDIA returned approximately $26.0 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the second quarter, the company had approximately $99.0 billion remaining under its share repurchase authorization.

[0001045810-26-000073:8k_2_02:9]
NVIDIA will pay its next quarterly cash dividend of $0.25 per share on October 1, 2026, to all shareholders of record on September 10, 2026.

[0001045810-26-000073:8k_2_02:10]
Q2 Fiscal 2027 Summary

[0001045810-26-000073:8k_2_02:11]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY27 | Q1 FY27 | Q2 FY26 | Q/Q | Y/Y |
| Revenue | $96,221 | $81,615 | $46,743 | 18 | % | 106 | % |
| Gross margin | 75.0 | % | 74.9 | % | 72.4 | % | 0.1 pts | 2.6 pts |
| Operating expenses | $8,408 | $7,621 | $5,413 | 10 | % | 55 | % |
| Operating income | $63,734 | $53,536 | $28,440 | 19 | % | 124 | % |
| Net income | $59,688 | $58,321 | $26,422 | 2 | % | 126 | % |
| Diluted earnings per share | $2.46 | $2.39 | $1.08 | 3 | % | 128 | % |

[0001045810-26-000073:8k_2_02:12]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY27 | Q1 FY27 | Q2 FY26 | Q/Q | Y/Y |
| Revenue | $96,221 | $81,615 | $46,743 | 18 | % | 106 | % |
| Gross margin | 75.0 | % | 75.0 | % | 72.5 | % | — | 2.5 pts |
| Operating expenses | $8,232 | $7,449 | $5,361 | 11 | % | 54 | % |
| Operating income | $63,956 | $53,783 | $28,541 | 19 | % | 124 | % |
| Net income | $53,954 | $45,548 | $24,763 | 18 | % | 118 | % |
| Diluted earnings per share | $2.22 | $1.87 | $1.01 | 19 | % | 120 | % |

[0001045810-26-000073:8k_2_02:13]
Outlook

[0001045810-26-000073:8k_2_02:14]
NVIDIA’s outlook for the third quarter of fiscal 2027 is as follows:

[0001045810-26-000073:8k_2_02:15]
•Revenue is expected to be $108.0 billion, plus or minus 2%. NVIDIA is not assuming any Data Center compute revenue from China in its outlook.

[0001045810-26-000073:8k_2_02:16]
•GAAP and non-GAAP gross margins are expected to be 74.0%, plus or minus 50 basis points.

[0001045810-26-000073:8k_2_02:17]
•GAAP and non-GAAP operating expenses are expected to be approximately $9.2 billion and $9.0 billion, respectively.

[0001045810-26-000073:8k_2_02:18]
For the full year fiscal 2027, NVIDIA expects GAAP and non-GAAP tax rates to be between 16.0% and 18.0%, excluding any discrete items and material changes to NVIDIA’s tax environment.

[0001045810-26-000073:8k_2_02:19]
Highlights

[0001045810-26-000073:8k_2_02:20]
Data Center

[0001045810-26-000073:8k_2_02:21]
•Second-quarter revenue was $89.0 billion, up 18% from the previous quarter and up 117% from a year ago.

[0001045810-26-000073:8k_2_02:22]
•Announced the NVIDIA Vera Rubin platform is ramping into full production with racks running at partners including CoreWeave, Google Cloud, Microsoft Azure, Oracle Cloud Infrastructure and Nebius.

[0001045810-26-000073:8k_2_02:23]
•Revealed that NVIDIA Spectrum™-6 switch systems — supporting both pluggable and co-packaged optics as part of the NVIDIA Vera Rubin platform — are arriving across the world’s gigascale AI factories.

[0001045810-26-000073:8k_2_02:24]
•Unveiled NVIDIA Vera, the first CPU built for AI agents, with broad adoption planned across the world’s leading technology providers.

[0001045810-26-000073:8k_2_02:25]
•Announced that NVIDIA Groq 3 LPX, the interactive AI inference accelerator, is now in full production.

[0001045810-26-000073:8k_2_02:26]
•Introduced new security innovations for NVIDIA Vera BlueField™-4 STX, delivering agentic AI storage processing with in-silicon security for AI factories.

[0001045810-26-000073:8k_2_02:27]
•Launched the NVIDIA DSX™ platform, providing infrastructure builders a complete playbook to design, build and operate AI factories at scale.

[0001045810-26-000073:8k_2_02:28]
•Announced strategic partnerships to establish independent compute financing platforms with Apollo, BlackRock, Blackstone, Brookfield, Goldman Sachs and KKR to mobilize over $500 billion of third-party capital for the buildout of AI infrastructure over time, subject to definitive agreements.

[0001045810-26-000073:8k_2_02:29]
•Announced that SpaceXAI will deploy NVIDIA Vera CPUs to accelerate its next generation of agentic AI applications.

[0001045810-26-000073:8k_2_02:30]
•Secured land, power and shell capacity through a partnership with SB Energy at the PORTS-Pike Technology Campus in Ohio to host NVIDIA compute.

[0001045810-26-000073:8k_2_02:31]
•Revealed that NVIDIA Blackwell led across every category in the MLPerf Training 6.0 benchmarks and in AgentPerf, the industry’s first agentic AI infrastructure benchmark.

[0001045810-26-000073:8k_2_02:32]
•Announced new software, open source models and partnerships with the world’s leading software platform providers to build autonomous AI agents for industries and enterprises;

[0001045810-26-000073:8k_2_02:33]
expanded NVIDIA Agent Toolkit with NVIDIA PhysicsNeMo and new and updated NVIDIA CUDA-X™ libraries.

[0001045810-26-000073:8k_2_02:34]
•Launched NVIDIA BioNeMo™ Agent Toolkit, which provides domain-specific tools and skills for the agentic life sciences era.

[0001045810-26-000073:8k_2_02:35]
•Formed the Open Secure AI Alliance with industry leaders to advance AI safety and security.

[0001045810-26-000073:8k_2_02:36]
•Revealed that NVIDIA GPUs with Confidential Computing are now used for confidential inference in Apple’s Private Cloud Compute.

[0001045810-26-000073:8k_2_02:37]
•Expanded Korea’s AI factory ecosystem through strategic partnerships with SK Telecom, NAVER and Brookfield to build sovereign AI infrastructure at gigawatt scale on the NVIDIA DSX platform, as part of a broader NVIDIA-powered national AI push across Korea’s industries and research institutions.

[0001045810-26-000073:8k_2_02:38]
•Announced a multiyear technology partnership with SK hynix to advance next-generation memory for the global AI factory buildout.

[0001045810-26-000073:8k_2_02:39]
•Partnered with the Japan government and industrial leaders to launch the world’s first national AI infrastructure; revealed that Japan’s leading enterprises, startups and research institutions are building industry-specialized AI models with NVIDIA Nemotron™ open models.

[0001045810-26-000073:8k_2_02:40]
•Announced that the NVIDIA Vera Rubin platform delivers world-class supercomputers for science; announced a record 35 new NVIDIA AI HPC supercomputers in development across Europe.

[0001045810-26-000073:8k_2_02:41]
Edge Computing

[0001045810-26-000073:8k_2_02:42]
•Second-quarter Edge Computing revenue was $7.2 billion, up 13% from the previous quarter and up 27% from a year ago.

[0001045810-26-000073:8k_2_02:43]
•Partnered with Microsoft to reinvent the Windows PC with NVIDIA RTX Spark™ — a 1-petaflop superchip with the full CUDA™ and NVIDIA RTX™ ecosystem.

[0001045810-26-000073:8k_2_02:44]
•Announced NVIDIA DGX Station™ for Windows, the world’s most powerful deskside AI supercomputer for developing and running agents on Windows.

[0001045810-26-000073:8k_2_02:45]
•Launched a local AI initiative with optimizations for top open models — DeepSeek v4 Flash, Diffusion Gemma, Nemotron 3.5 Lightning and Qwen 3.8 — and agent harnesses Hermes Agent and OpenClaw across RTX and DGX platforms.

[0001045810-26-000073:8k_2_02:46]
•Expanded the NVIDIA DRIVE Hyperion™ robotaxi-ready platform ecosystem, including strategic collaborations with Foxconn, VinFast, Uber and HUMAIN.

[0001045810-26-000073:8k_2_02:47]
•Introduced NVIDIA Alpamayo 2 Super, the frontier open reasoning model for safe robotaxi and autonomous vehicle development, for commercial use.

[0001045810-26-000073:8k_2_02:48]
•Launched NVIDIA Cosmos™ 3, the world’s first fully open frontier omnimodel for physical AI.

[0001045810-26-000073:8k_2_02:49]
•Announced the NVIDIA Isaac™ GR00T Reference Humanoid Robot, the first open humanoid robot reference design built on NVIDIA Jetson Thor™ and the NVIDIA Isaac GR00T open development platform.

[0001045810-26-000073:8k_2_02:50]
•Announced NVIDIA Halos for Robotics, the industry’s first full-stack safety system for physical AI, unifying AI compute and safety in a single comprehensive platform.

[0001045810-26-000073:8k_2_02:51]
•Released a major collection of open source agent tools and skills for physical AI, enabling developers to turn complex robotics, autonomous vehicle and vision AI workflows into agent-executable tasks.

[0001045810-26-000073:8k_2_02:52]
CFO Commentary

[0001045810-26-000073:8k_2_02:53]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-26-000073:8k_2_02:54]
Conference Call and Webcast Information

[0001045810-26-000073:8k_2_02:55]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2027 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2027.

[0001045810-26-000073:8k_2_02:56]
Non-GAAP Measures

[0001045810-26-000073:8k_2_02:57]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition-related and other costs, other, gains/losses from equity securities, net, certain other income and expense, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures no longer exclude stock-based compensation expense. The historical non-GAAP financial information presented has been updated to include stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the users’ overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-26-000073:8k_2_02:58]
About NVIDIA

[0001045810-26-000073:8k_2_02:59]
NVIDIA (NASDAQ: NVDA) is the world leader in AI and accelerated computing.

[0001045810-26-000073:8k_2_02:60]
###

[0001045810-26-000073:8k_2_02:61]
For further information, contact:

[0001045810-26-000073:8k_2_02:62]
| Toshiya Hari |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| IR@nvidia.com |  | press@nvidia.com |

[0001045810-26-000073:8k_2_02:63]
Certain statements in this press release including, but not limited to, statements as to: the buildout of AI factories; expectations with respect to growth, performance and benefits of NVIDIA’s products, services and technologies, including Blackwell and Vera Rubin, and related trends and drivers; expectations with respect to supply and demand for NVIDIA’s products, services and technologies, including Blackwell and Vera Rubin, and related matters including inventory, production and distribution; expectations with respect to NVIDIA’s third party arrangements, including with its collaborators and

[0001045810-26-000073:8k_2_02:64]
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, BlueField, Cosmos, Nemotron, NVIDIA Isaac, BioNeMo, CUDA-X, NVIDIA DRIVE Hyperion, NVIDIA Spectrum, NVIDIA DSX, NVIDIA RTX, RTX Spark, DGX Station, and Jetson Thor are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-26-000073:8k_2_02:65]
NVIDIA CORPORATION

[0001045810-26-000073:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-26-000073:8k_2_02:67]
(In millions, except per share data)

[0001045810-26-000073:8k_2_02:68]
(Unaudited)

[0001045810-26-000073:8k_2_02:69]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue | $ | 96,221 |  |  | $ | 46,743 |  |  | $ | 177,837 |  |  | $ | 90,805 |  |
| Cost of revenue | 24,079 |  |  | 12,890 |  |  | 44,538 |  |  | 30,284 |  |
| Gross profit | 72,142 |  |  | 33,853 |  |  | 133,299 |  |  | 60,521 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 7,054 |  |  | 4,291 |  |  | 13,375 |  |  | 8,280 |  |
|  | Sales, general and administrative | 1,354 |  |  | 1,122 |  |  | 2,654 |  |  | 2,163 |  |
|  |  | Total operating expenses | 8,408 |  |  | 5,413 |  |  | 16,029 |  |  | 10,443 |  |
| Operating income | 63,734 |  |  | 28,440 |  |  | 117,270 |  |  | 50,078 |  |
| Other income, net | 7,773 |  |  | 2,766 |  |  | 24,140 |  |  | 3,039 |  |
| Income before income tax | 71,507 |  |  | 31,206 |  |  | 141,410 |  |  | 53,117 |  |
| Income tax expense | 11,819 |  |  | 4,784 |  |  | 23,400 |  |  | 7,920 |  |
| Net income | $ | 59,688 |  |  | $ | 26,422 |  |  | $ | 118,010 |  |  | $ | 45,197 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 2.47 |  |  | $ | 1.08 |  |  | $ | 4.87 |  |  | $ | 1.85 |  |
|  | Diluted | $ | 2.46 |  |  | $ | 1.08 |  |  | $ | 4.85 |  |  | $ | 1.84 |  |
| Weighted average shares used in per share computation: |
|  | Basic | 24,190 |  |  | 24,366 |  |  | 24,238 |  |  | 24,404 |  |
|  | Diluted | 24,285 |  |  | 24,532 |  |  | 24,338 |  |  | 24,571 |  |

[0001045810-26-000073:8k_2_02:70]
| NVIDIA CORPORATION |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  |  | July 26, |  | January 25, |  |
|  |  |  | 2026 |  | 2026 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 22,443 |  |  | $ | 10,605 |  |  |
|  | Marketable debt securities | 34,143 |  |  | 39,065 |  |  |
|  | Marketable equity securities | 42,783 |  |  | 12,886 |  |  |
|  | Accounts receivable, net | 63,059 |  |  | 38,466 |  |  |
|  | Inventories | 31,575 |  |  | 21,403 |  |  |
|  | Prepaid expenses and other current assets | 3,409 |  |  | 3,180 |  |  |
|  |  | Total current assets | 197,412 |  |  | 125,605 |  |  |
| Property and equipment, net | 14,285 |  |  | 10,383 |  |  |
| Operating lease assets | 5,390 |  |  | 2,867 |  |  |
| Goodwill | 21,125 |  |  | 20,832 |  |  |
| Intangible assets, net | 2,998 |  |  | 3,306 |  |  |
| Deferred income tax assets | 12,159 |  |  | 13,258 |  |  |
| Non-marketable securities | 51,157 |  |  | 22,251 |  |  |
| Other assets | 15,746 |  |  | 8,301 |  |  |
|  |  | Total assets | $ | 320,272 |  |  | $ | 206,803 |  |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable | $ | 15,059 |  |  | $ | 9,812 |  |  |
|  | Accrued and other current liabilities | 26,960 |  |  | 21,352 |  |  |
|  | Short-term debt | 1,000 |  |  | 999 |  |  |
|  |  | Total current liabilities | 43,019 |  |  | 32,163 |  |  |
| Long-term debt | 32,366 |  |  | 7,469 |  |  |
| Long-term operating lease liabilities | 4,985 |  |  | 2,572 |  |  |
| Other long-term liabilities | 10,918 |  |  | 7,306 |  |  |
|  |  | Total liabilities | 91,288 |  |  | 49,510 |  |  |
| Shareholders' equity | 228,984 |  |  | 157,293 |  |  |
|  |  | Total liabilities and shareholders' equity | $ | 320,272 |  |  | $ | 206,803 |  |  |

[0001045810-26-000073:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 59,688 |  |  | $ | 26,422 |  |  | $ | 118,010 |  |  | $ | 45,197 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 2,027 |  |  | 1,624 |  |  | 3,954 |  |  | 3,099 |  |
| Depreciation and amortization | 1,127 |  |  | 668 |  |  | 2,124 |  |  | 1,280 |  |
| Deferred income taxes | (602) |  |  | 18 |  |  | 982 |  |  | (2,160) |  |
| Gains from equity securities, net | (7,771) |  |  | (2,247) |  |  | (23,707) |  |  | (2,073) |  |
| Other | 315 |  |  | (100) |  |  | 222 |  |  | (196) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (22,346) |  |  | (5,675) |  |  | (24,590) |  |  | (4,743) |  |
| Inventories | (5,784) |  |  | (3,622) |  |  | (10,204) |  |  | (4,880) |  |
| Prepaid expenses and other assets | (5,497) |  |  | 387 |  |  | (6,480) |  |  | 946 |  |
| Accounts payable | 1,915 |  |  | 1,314 |  |  | 4,125 |  |  | 2,255 |  |
| Accrued and other current liabilities | 252 |  |  | (4,053) |  |  | 8,015 |  |  | 3,075 |  |
| Other long-term liabilities | 753 |  |  | 629 |  |  | 1,970 |  |  | 979 |  |
| Net cash provided by operating activities | 24,077 |  |  | 15,365 |  |  | 74,421 |  |  | 42,779 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from sales and maturities of debt securities | 24,592 |  |  | 3,150 |  |  | 26,563 |  |  | 6,739 |  |
| Proceeds from sales of equity securities | 7,215 |  |  | 70 |  |  | 7,241 |  |  | 70 |  |
| Purchases of equity securities | (15,822) |  |  | (346) |  |  | (42,404) |  |  | (1,245) |  |
| Purchases of debt securities | (21,777) |  |  | (7,812) |  |  | (21,777) |  |  | (14,108) |  |
| Purchases related to property and equipment and intangible assets | (2,677) |  |  | (1,894) |  |  | (4,434) |  |  | (3,122) |  |
| Acquisitions, net of cash acquired | (211) |  |  | (294) |  |  | (298) |  |  | (677) |  |
| Other | (15) |  |  | — |  |  | (15) |  |  | — |  |
| Net cash used in investing activities | (8,695) |  |  | (7,126) |  |  | (35,124) |  |  | (12,343) |  |

[0001045810-26-000073:8k_2_02:72]
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to issuance of debt, net of costs | 24,896 |  |  | — |  |  | 24,896 |  |  | — |  |
| Proceeds related to employee stock plans | — |  |  | — |  |  | 515 |  |  | 370 |  |
| Payments related to repurchases of common stock | (19,732) |  |  | (9,721) |  |  | (39,044) |  |  | (23,815) |  |
| Dividends paid | (6,047) |  |  | (244) |  |  | (6,290) |  |  | (488) |  |
| Payments related to employee stock plan taxes | (2,402) |  |  | (1,848) |  |  | (4,531) |  |  | (3,380) |  |
| Groq, Inc. | (2,944) |  |  | — |  |  | (2,944) |  |  | — |  |
| Principal payments on property and equipment and intangible assets | (59) |  |  | (21) |  |  | (92) |  |  | (73) |  |
| Other | 112 |  |  | — |  |  | 31 |  |  | — |  |
| Net cash used in financing activities | (6,176) |  |  | (11,834) |  |  | (27,459) |  |  | (27,386) |  |
| Change in cash and cash equivalents | 9,206 |  |  | (3,595) |  |  | 11,838 |  |  | 3,050 |  |
| Cash and cash equivalents at beginning of period | 13,237 |  |  | 15,234 |  |  | 10,605 |  |  | 8,589 |  |
| Cash and cash equivalents at end of period | $ | 22,443 |  |  | $ | 11,639 |  |  | $ | 22,443 |  |  | $ | 11,639 |  |

[0001045810-26-000073:8k_2_02:73]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | ($ In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 26, |  | April 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  |  | 2026 |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| GAAP cost of revenue |  | $ | 24,079 |  |  | $ | 20,458 |  |  | $ | 12,890 |  |  | $ | 44,538 |  |  | $ | 30,284 |  |
| GAAP gross profit |  | $ | 72,142 |  |  | $ | 61,157 |  |  | $ | 33,853 |  |  | $ | 133,299 |  |  | $ | 60,521 |  |
| GAAP gross margin |  | 75.0 | % |  | 74.9 | % |  | 72.4 | % |  | 75.0 | % |  | 66.6 | % |
|  | Acquisition-related and other costs (A) |  | 46 |  |  | 47 |  |  | 49 |  |  | 93 |  |  | 170 |  |
|  | Other |  | — |  |  | 28 |  |  | — |  |  | 28 |  |  | 4 |  |
| Non-GAAP cost of revenue |  | $ | 24,033 |  |  | $ | 20,383 |  |  | $ | 12,841 |  |  | $ | 44,417 |  |  | $ | 30,110 |  |
| Non-GAAP gross profit |  | $ | 72,188 |  |  | $ | 61,232 |  |  | $ | 33,902 |  |  | $ | 133,420 |  |  | $ | 60,695 |  |
| Non-GAAP gross margin* |  | 75.0 | % |  | 75.0 | % |  | 72.5 | % |  | 75.0 | % |  | 66.8 | % |
| GAAP operating expenses |  | $ | 8,408 |  |  | $ | 7,621 |  |  | $ | 5,413 |  |  | $ | 16,029 |  |  | $ | 10,443 |  |
|  | Acquisition-related and other costs (A) |  | (176) |  |  | (172) |  |  | (37) |  |  | (348) |  |  | (74) |  |
|  | Other |  | — |  |  | — |  |  | (15) |  |  | — |  |  | (15) |  |
| Non-GAAP operating expenses |  | $ | 8,232 |  |  | $ | 7,449 |  |  | $ | 5,361 |  |  | $ | 15,681 |  |  | $ | 10,354 |  |
| GAAP operating income |  | $ | 63,734 |  |  | $ | 53,536 |  |  | $ | 28,440 |  |  | $ | 117,270 |  |  | $ | 50,078 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 222 |  |  | 247 |  |  | 101 |  |  | 469 |  |  | 263 |  |
| Non-GAAP operating income* |  | $ | 63,956 |  |  | $ | 53,783 |  |  | $ | 28,541 |  |  | $ | 117,739 |  |  | $ | 50,341 |  |
| GAAP other income, net |  | $ | 7,773 |  |  | $ | 16,367 |  |  | $ | 2,766 |  |  | $ | 24,140 |  |  | $ | 3,039 |  |
|  | Gains from equity securities, net |  | (7,771) |  |  | (15,936) |  |  | (2,247) |  |  | (23,707) |  |  | (2,073) |  |
|  | Other (B) |  | 298 |  |  | 26 |  |  | 1 |  |  | 323 |  |  | 2 |  |
| Non-GAAP other income, net |  | $ | 300 |  |  | $ | 457 |  |  | $ | 520 |  |  | $ | 756 |  |  | $ | 968 |  |
| GAAP net income |  | $ | 59,688 |  |  | $ | 58,321 |  |  | $ | 26,422 |  |  | $ | 118,010 |  |  | $ | 45,197 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | (7,251) |  |  | (15,663) |  |  | (2,145) |  |  | (22,915) |  |  | (1,808) |  |
|  | Income tax impact of non-GAAP adjustments |  | 1,517 |  |  | 2,890 |  |  | 438 |  |  | 4,407 |  |  | 418 |  |
|  | Tax expense from OBBBA** |  | — |  |  | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Non-GAAP net income* |  | $ | 53,954 |  |  | $ | 45,548 |  |  | $ | 24,763 |  |  | $ | 99,502 |  |  | $ | 43,855 |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 2.46 |  |  | $ | 2.39 |  |  | $ | 1.08 |  |  | $ | 4.85 |  |  | $ | 1.84 |  |
|  | Non-GAAP* |  | $ | 2.22 |  |  | $ | 1.87 |  |  | $ | 1.01 |  |  | $ | 4.09 |  |  | $ | 1.78 |  |
| Weighted average shares used in diluted net income per share computation |  | 24,285 |  |  | 24,391 |  |  | 24,532 |  |  | 24,338 |  |  | 24,571 |  |

[0001045810-26-000073:8k_2_02:74]
| GAAP net cash provided by operating activities |  | $ | 24,077 |  |  | $ | 50,344 |  |  | $ | 15,365 |  |  | $ | 74,421 |  |  | $ | 42,779 |  |
|  | Purchases related to property and equipment and intangible assets |  | (2,677) |  |  | (1,757) |  |  | (1,894) |  |  | (4,434) |  |  | (3,122) |  |
|  | Principal payments on property and equipment and intangible assets |  | (59) |  |  | (33) |  |  | (21) |  |  | (92) |  |  | (73) |  |
| Free cash flow |  | $ | 21,341 |  |  | $ | 48,554 |  |  | $ | 13,450 |  |  | $ | 69,895 |  |  | $ | 39,584 |  |
| *Includes H20 charges/(releases), net, which were $4.5 billion and none for the first quarter, and ($180 million) and insignificant for the second quarter, of fiscal years 2026 and 2027, respectively. |
| **Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act). |

[0001045810-26-000073:8k_2_02:75]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |  |
|  |  |  | Three Months Ended |  | Six Months Ended |  |
|  |  |  | July 26, |  | April 26, |  | July 27, |  | July 26, |  | July 27, |  |
|  |  |  | 2026 |  | 2026 |  | 2025 |  | 2026 |  | 2025 |  |
|  | Cost of revenue |  | $ | 46 |  |  | $ | 47 |  |  | $ | 49 |  |  | $ | 93 |  |  | $ | 170 |  |  |
|  | Research and development |  | $ | 170 |  |  | $ | 167 |  |  | $ | 29 |  |  | $ | 337 |  |  | $ | 57 |  |  |
|  | Sales, general and administrative |  | $ | 6 |  |  | $ | 5 |  |  | $ | 8 |  |  | $ | 11 |  |  | $ | 17 |  |  |
| (B) Comprised of net (gains)/losses on equity derivatives, interest expense related to acquisition consideration discount to be paid in the future, share of net (earnings)/losses related to equity method investments, and dividend income on equity securities. |  |

[0001045810-26-000073:8k_2_02:76]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2027 Outlook |
|  |  |  | ($ in billions) |
| GAAP gross margin |  | 74.0 | % |
|  | Impact of acquisition-related costs and other costs |  | — |  |
| Non-GAAP gross margin |  | 74.0 | % |
| GAAP operating expenses |  | $ | 9.2 |  |
|  | Acquisition-related costs and other costs |  | (0.2) |  |
| Non-GAAP operating expenses |  | $ | 9.0 |  |
