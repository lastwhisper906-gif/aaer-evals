# NVDA notes — 0001045810-26-000075


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-26-000075:notes:1]
[same as prior period, unchanged from 0001045810-26-000052:notes:1]

[0001045810-26-000075:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2026, consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair presentation of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026.

[0001045810-26-000075:notes:3]
[same as prior period, unchanged from 0001045810-26-000052:notes:3]

[0001045810-26-000075:notes:4]
[same as prior period, unchanged from 0001045810-26-000052:notes:4]

[0001045810-26-000075:notes:5]
[same as prior period, unchanged from 0001045810-26-000052:notes:5]

[0001045810-26-000075:notes:6]
[same as prior period, unchanged from 0001045810-26-000052:notes:6]

[0001045810-26-000075:notes:7]
Fiscal year 2027 is a 53-week year, and fiscal year 2026 was a 52-week year, both ending on the last Sunday in January. The second quarters of fiscal years 2027 and 2026 were both 13-week quarters. The fourth quarter of fiscal year 2027 will be a 14-week quarter.

[0001045810-26-000075:notes:8]
[same as prior period, unchanged from 0001045810-26-000052:notes:8]

[0001045810-26-000075:notes:9]
[same as prior period, unchanged from 0001045810-26-000052:notes:9]

[0001045810-26-000075:notes:10]
[same as prior period, unchanged from 0001045810-26-000052:notes:10]

[0001045810-26-000075:notes:11]
[same as prior period, unchanged from 0001045810-26-000052:notes:11]

[0001045810-26-000075:notes:12]
Recently Issued Accounting Pronouncements

[0001045810-26-000075:notes:13]
[same as prior period, unchanged from 0001045810-26-000052:notes:13]

[0001045810-26-000075:notes:14]
In November 2024, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-26-000075:notes:15]
[same as prior period, unchanged from 0001045810-26-000052:notes:15]

[0001045810-26-000075:notes:16]
[same as prior period, unchanged from 0001045810-26-000052:notes:16]

[0001045810-26-000075:notes:17]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Cost of revenue | $ | 71 |  |  | $ | 58 |  |  | $ | 139 |  |  | $ | 123 |  |
| Research and development | 1,551 |  |  | 1,191 |  |  | 3,010 |  |  | 2,254 |  |
| Sales, general and administrative | 405 |  |  | 375 |  |  | 805 |  |  | 722 |  |
| Total | $ | 2,027 |  |  | $ | 1,624 |  |  | $ | 3,954 |  |  | $ | 3,099 |  |

[0001045810-26-000075:notes:18]
[same as prior period, unchanged from 0001045810-26-000052:notes:18]

[0001045810-26-000075:notes:19]
[same as prior period, unchanged from 0001045810-26-000052:notes:19]

[0001045810-26-000075:notes:20]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balance as of Jan 25, 2026 | 189 |  |  | $ | 81.51 |  |
| Granted | 49 |  |  | $ | 183.74 |  |
| Vested | (63) |  |  | $ | 54.60 |  |
| Canceled and forfeited | (7) |  |  | $ | 102.16 |  |
| Balance as of Jul 26, 2026 | 168 |  |  | $ | 120.41 |  |

[0001045810-26-000075:notes:21]
As of July 26, 2026, aggregate unearned stock-based compensation expense was $19.4 billion, which is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and 0.9 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-26-000075:notes:22]
Net Income Per Share
The following are the basic and diluted net income per share computations for the periods presented:

[0001045810-26-000075:notes:23]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 59,688 |  |  | $ | 26,422 |  |  | $ | 118,010 |  |  | $ | 45,197 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,190 |  |  | 24,366 |  |  | 24,238 |  |  | 24,404 |  |
| Dilutive impact of outstanding equity awards | 95 |  |  | 166 |  |  | 100 |  |  | 167 |  |
| Diluted weighted average shares | 24,285 |  |  | 24,532 |  |  | 24,338 |  |  | 24,571 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 2.47 |  |  | $ | 1.08 |  |  | $ | 4.87 |  |  | $ | 1.85 |  |
| Diluted (2) | $ | 2.46 |  |  | $ | 1.08 |  |  | $ | 4.85 |  |  | $ | 1.84 |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 7 |  |  | 3 |  |  | 52 |  |  | 60 |  |

[0001045810-26-000075:notes:24]
[same as prior period, unchanged from 0001045810-26-000052:notes:24]

[0001045810-26-000075:notes:25]
[same as prior period, unchanged from 0001045810-26-000052:notes:25]

[0001045810-26-000075:notes:26]
[same as prior period, unchanged from 0001045810-26-000052:notes:26]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-26-000075:notes:27]
Intangible Assets and Goodwill
The components of our intangible assets are as follows:

[0001045810-26-000075:notes:28]
|  | Jul 26, 2026 |  | Jan 25, 2026 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 5,737 |  |  | $ | (2,974) |  |  | $ | 2,763 |  |  | $ | 5,656 |  |  | $ | (2,580) |  |  | $ | 3,076 |  |
| Patents and licensed technology | 557 |  |  | (322) |  |  | 235 |  |  | 528 |  |  | (298) |  |  | 230 |  |
| Total intangible assets | $ | 6,294 |  |  | $ | (3,296) |  |  | $ | 2,998 |  |  | $ | 6,184 |  |  | $ | (2,878) |  |  | $ | 3,306 |  |

[0001045810-26-000075:notes:29]
Amortization expense associated with intangible assets was $237 million and $84 million for the second quarter, and $470 million and $243 million for the first half, of fiscal years 2027 and 2026, respectively.

[0001045810-26-000075:notes:30]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of July 26, 2026:

[0001045810-26-000075:notes:31]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2027 (the second half of fiscal year 2027) | $ | 482 |  |
| 2028 | 795 |  |
| 2029 | 642 |  |
| 2030 | 528 |  |
| 2031 | 468 |  |
| 2032 and thereafter | 83 |  |
| Total | $ | 2,998 |  |

[0001045810-26-000075:notes:32]
In the first half of fiscal year 2027, goodwill increased by $293 million, which was allocated to our Compute & Networking reporting unit.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-26-000075:notes:33]
Cash Equivalents and Marketable Securities
Cash equivalents and marketable securities including debt and equity securities are measured at fair value using quoted prices in active markets for identical assets (Level 1) or for similar assets or use of other observable inputs (Level 2).

[0001045810-26-000075:notes:34]
The following is a summary of cash equivalents and marketable securities:

[0001045810-26-000075:notes:35]
|  | Jul 26, 2026 |
|  | Pricing Category |  | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 45,367 |  |  | $ | 8 |  |  | $ | (54) |  |  | $ | 45,321 |  |  | $ | 12,318 |  |  | $ | 33,003 |  |  | $ | — |  |  | $ | — |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | 1,541 |  |  | — |  |  | (2) |  |  | 1,539 |  |  | 399 |  |  | 1,140 |  |  | — |  |  | — |  |
| Money market funds | Level 1 |  | 8,633 |  |  | — |  |  | — |  |  | 8,633 |  |  | 8,633 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  |  | 36,934 |  |  | — |  |  | — |  |  | 31,977 |  |  | 4,957 |  |
| Publicly-held equity securities (1) (3) | Level 2 |  |  |  |  |  |  |  | 10,806 |  |  | — |  |  | — |  |  | 10,806 |  |  | — |  |
| Total |  |  | $ | 55,541 |  |  | $ | 8 |  |  | $ | (56) |  |  | $ | 103,233 |  |  | $ | 21,350 |  |  | $ | 34,143 |  |  | $ | 42,783 |  |  | $ | 4,957 |  |

[0001045810-26-000075:notes:36]
(1)    Included $36.9 billion of investments that are subject to short-term lock-up restrictions on the ability to sell.

[0001045810-26-000075:notes:37]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $5.0 billion as of July 26, 2026, was included in Other assets.

[0001045810-26-000075:notes:38]
(3)    Included investments in unregistered warrants and preferred stock convertible to common stock in public companies.

[0001045810-26-000075:notes:39]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $1.5 billion and $12.5 billion for the second quarter and first half of fiscal year 2027, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were $1.9 billion and $1.7 billion for the second quarter and first half of fiscal year 2026, respectively.

[0001045810-26-000075:notes:40]
|  | Jan 25, 2026 |
|  | Pricing Category |  | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 21,635 |  |  | $ | 77 |  |  | $ | (3) |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 |  | 15,410 |  |  | 92 |  |  | (3) |  |  | 15,499 |  |  | 345 |  |  | 15,154 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | 2,157 |  |  | 4 |  |  | — |  |  | 2,161 |  |  | — |  |  | 2,161 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 |  | 110 |  |  | — |  |  | — |  |  | 110 |  |  | 110 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 |  | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 |  | 7,830 |  |  | — |  |  | — |  |  | 7,830 |  |  | 7,830 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  |  | 17,726 |  |  | — |  |  | — |  |  | 12,886 |  |  | 4,840 |  |
| Total |  |  | $ | 47,182 |  |  | $ | 174 |  |  | $ | (6) |  |  | $ | 65,076 |  |  | $ | 8,285 |  |  | $ | 39,065 |  |  | $ | 12,886 |  |  | $ | 4,840 |  |

[0001045810-26-000075:notes:41]
(1)    Included $10.5 billion of investments that are subject to short-term lock-up restrictions on the ability to sell.

[0001045810-26-000075:notes:42]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $4.8 billion as of January 25, 2026, was included in Other assets.

[0001045810-26-000075:notes:43]
As of July 26, 2026, and January 25, 2026, debt securities of $42.0 billion and $13.1 billion, respectively, in a continuous loss position had been so for less than 12 months, and the related unrealized losses were not significant.

[0001045810-26-000075:notes:44]
As of July 26, 2026, the estimated fair values of debt securities included in cash equivalents and marketable debt securities were $46.9 billion, consisting of $41.0 billion due in less than one year and $5.9 billion due in one to five years.
Non-marketable Securities
Non-marketable Equity Securities

[0001045810-26-000075:notes:45]
Our non-marketable equity securities are primarily in privately-held companies carried at cost less impairment, and adjusted for observable price changes. We value investments using observable comparable transactions and other inputs including volatility, expected time to liquidity, the risk-free rate, and security-specific rights and obligations.

[0001045810-26-000075:notes:46]
Adjustments to the carrying value of privately-held securities:

[0001045810-26-000075:notes:47]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Balance at beginning of period | $ | 42,336 |  |  | $ | 3,240 |  |  | $ | 22,251 |  |  | $ | 3,387 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 13,106 |  |  | 299 |  |  | 31,005 |  |  | 948 |  |
| Unrealized gains (1) | 4,900 |  |  | 267 |  |  | 7,504 |  |  | 330 |  |
| Reclassification (2) | (12,323) |  |  | (5) |  |  | (12,712) |  |  | (848) |  |
| Impairments and unrealized losses (1) | (121) |  |  | (2) |  |  | (150) |  |  | (18) |  |
| Balance at end of period | $ | 47,898 |  |  | $ | 3,799 |  |  | $ | 47,898 |  |  | $ | 3,799 |  |

[0001045810-26-000075:notes:48]
(1)    Unrealized gains, losses, and impairments are recognized in Other income, net, in the Condensed Consolidated Statements of Income.

[0001045810-26-000075:notes:49]
(2)    Included reclassifications primarily related to marketable securities following public market trading.

[0001045810-26-000075:notes:50]
Non-marketable equity securities had cumulative gross unrealized gains of $9.1 billion and $661 million, and cumulative gross unrealized losses and impairments of $250 million and $93 million as of July 26, 2026, and July 27, 2025, respectively.

[0001045810-26-000075:notes:51]
Equity Method Investments

[0001045810-26-000075:notes:52]
We had $3.3 billion of investments in infrastructure financiers accounted for using the equity method as of July 26, 2026. Those equity method investments deemed to be variable interest entities, or VIEs, had a maximum loss exposure, including carrying values and future committed amounts, of $4.7 billion as of July 26, 2026. We have determined we are not the primary beneficiary of our VIE investments and, therefore, do not consolidate the VIEs in our consolidated financial statements. Income from equity method investments is recognized in Other income, net, and was not significant for the second quarter and first half of fiscal year 2027.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001045810-26-000075:notes:53]
Supplemental Financial Statement Information
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, or AIBs, distributors, original design manufacturers, or ODMs, original equipment manufacturers, or OEMs, cloud service providers, or CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. Five direct customers accounted for 22%, 14%, 13%, 11%, and 10% of our accounts receivable balance as of July 26, 2026. Three direct customers accounted for 25%, 18%, and 13% of our accounts receivable balance as of January 25, 2026.

[0001045810-26-000075:notes:54]
Payment from customers is generally due shortly after delivery of our products. In certain cases, for investment-grade customer purchases, we have and may in the future provide longer payment terms ranging from 90 days up to one year to assist customers with large data center builds depending on size.

[0001045810-26-000075:notes:55]
Certain balance sheet components were as follows:

[0001045810-26-000075:notes:56]
|  | Jul 26, 2026 |  | Jan 25, 2026 |
| Inventories: | (In millions) |
| Raw materials | $ | 11,341 |  |  | $ | 3,807 |  |
| Work in process | 13,377 |  |  | 8,822 |  |
| Finished goods | 6,857 |  |  | 8,774 |  |
| Total inventories (1) | $ | 31,575 |  |  | $ | 21,403 |  |

[0001045810-26-000075:notes:57]
(1)    We recognized inventory provisions of $784 million and $886 million for the second quarter, and $1.6 billion and $3.2 billion for the first half, of fiscal years 2027 and 2026, respectively, in Cost of revenue.

[0001045810-26-000075:notes:58]
Property and Equipment:

[0001045810-26-000075:notes:59]
Property, equipment, and intangible assets acquired but not paid for in the first half of fiscal years 2027 and 2026 were $1.2 billion and $1.1 billion, respectively.

[0001045810-26-000075:notes:60]
|  | Jul 26, 2026 |  | Jan 25, 2026 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 7,391 |  |  | $ | 5,318 |  |
| Taxes payable | 5,206 |  |  | 2,669 |  |
| Deferred revenue (1) | 4,616 |  |  | 1,379 |  |
| Product warranty | 2,938 |  |  | 2,807 |  |
| Excess inventory purchase obligations (2) | 2,138 |  |  | 2,739 |  |
| Accrued payroll and related expenses | 1,206 |  |  | 1,146 |  |
| Accrued purchase consideration (3) | 986 |  |  | 3,921 |  |
| Other | 2,479 |  |  | 1,373 |  |
| Total accrued and other current liabilities | $ | 26,960 |  |  | $ | 21,352 |  |

[0001045810-26-000075:notes:61]
(1)    Included customer advances and unearned revenue primarily related to hardware and software support, and license and development arrangements. The balance as of July 26, 2026, and January 25, 2026, included $2.8 billion and $160 million of customer advances, respectively.

[0001045810-26-000075:notes:62]
(2)    We recognized $201 million and $137 million for the second quarter, and $501 million and $3.1 billion for the first half, of fiscal years 2027 and 2026, respectively, in Cost of revenue.

[0001045810-26-000075:notes:63]
(3)    Related to the Groq, Inc. non-exclusive license agreement.

[0001045810-26-000075:notes:64]
|  | Jul 26, 2026 |  | Jan 25, 2026 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 5,602 |  |  | $ | 3,958 |  |
| Deferred revenue (2) | 1,796 |  |  | 1,193 |  |
| Deferred income tax | 1,619 |  |  | 1,774 |  |
| Other | 1,901 |  |  | 381 |  |
| Total other long-term liabilities | $ | 10,918 |  |  | $ | 7,306 |  |

[0001045810-26-000075:notes:65]
(1)    Primarily comprised of unrecognized tax benefits and related interest and penalties.

[0001045810-26-000075:notes:66]
(2)    Included unearned revenue related to hardware and software support.

[0001045810-26-000075:notes:67]
Deferred Revenue

[0001045810-26-000075:notes:68]
The following table shows the changes in short- and long-term deferred revenue during the first half of fiscal years 2027 and 2026:

[0001045810-26-000075:notes:69]
|  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,572 |  |  | $ | 1,813 |  |
| Deferred revenue additions (1) | 17,709 |  |  | 8,275 |  |
| Revenue recognized (2) | (13,869) |  |  | (8,053) |  |
| Balance at end of period | $ | 6,412 |  |  | $ | 2,035 |  |

[0001045810-26-000075:notes:70]
(1)    Included $15.6 billion and $7.5 billion of customer advances for the first half of fiscal years 2027 and 2026, respectively.

[0001045810-26-000075:notes:71]
(2)    Included $13.0 billion and $7.5 billion related to customer advances for the first half of fiscal years 2027 and 2026, respectively.

[0001045810-26-000075:notes:72]
We recognized revenue of $758 million and $479 million in the first half of fiscal years 2027 and 2026, respectively, that was included in the prior year-end deferred revenue balance.

[0001045810-26-000075:notes:73]
As of July 26, 2026, revenue related to remaining performance obligations from contracts greater than one year in length was $3.2 billion, which included $3.0 billion from deferred revenue and $244 million that has not yet been billed or recognized as revenue. Approximately 39% of revenue from contracts greater than one year in length will be recognized over the next twelve months.

[0001045810-26-000075:notes:74]
Other Income, Net

[0001045810-26-000075:notes:75]
Other income, net, consisted of the following:

[0001045810-26-000075:notes:76]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Interest income | $ | 496 |  |  | $ | 592 |  |  | $ | 1,037 |  |  | $ | 1,108 |  |
| Interest expense | (227) |  |  | (62) |  |  | (329) |  |  | (124) |  |
| Gains from equity securities, net | 7,771 |  |  | 2,247 |  |  | 23,707 |  |  | 2,073 |  |
| Other | (267) |  |  | (11) |  |  | (275) |  |  | (18) |  |
| Other income, net | $ | 7,773 |  |  | $ | 2,766 |  |  | $ | 24,140 |  |  | $ | 3,039 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-26-000075:notes:77]
[same as prior period, unchanged from 0001045810-26-000052:notes:80]

[0001045810-26-000075:notes:78]
We primarily utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These foreign currency forward contracts for operating expenses are designated as accounting hedges. Gains or losses on the contracts are recognized in Accumulated other comprehensive income or loss and reclassified to Operating expenses when the related operating expenses are recognized in earnings. During the first half of fiscal years 2027 and 2026, the impact of foreign currency forward contracts designated as accounting hedges on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.

[0001045810-26-000075:notes:79]
We also entered into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities. For our foreign currency contracts for assets and liabilities, the change in fair value of these non-designated contracts offsets the change in fair value of the hedged foreign currency-denominated monetary assets and liabilities, and is recognized in Other income, net. The fair values of our foreign currency contracts were not significant as of July 26, 2026, and January 25, 2026.

[0001045810-26-000075:notes:80]
As of July 26, 2026, all foreign currency contracts mature within 18 months.

[0001045810-26-000075:notes:81]
The gains and losses of our foreign currency contracts were not significant for the second quarter and first half of fiscal years 2027 and 2026.

[0001045810-26-000075:notes:82]
Land, Power, and Shell Guarantees for AI Clouds

[0001045810-26-000075:notes:83]
We entered into land, power, and shell guarantees for select AI cloud partners’ data center lease obligations in the event of their default. The guarantees are classified as credit derivatives, the fair values of which were not significant, with changes in fair values recognized in Other income, net.

[0001045810-26-000075:notes:84]
Public Company Warrants
In the second quarter of fiscal year 2027, we received warrants to purchase shares of publicly-traded common stock with terms of three to five years. These warrants are classified as equity derivatives, initially recognized within Other assets, with the corresponding benefit substantially deferred. Subsequent valuation changes are recognized in Other income, net. As of July 26, 2026, the fair values of the equity derivatives, a Level 3 measurement, were $824 million
Derivative Financial Instrument Notional Values

[0001045810-26-000075:notes:85]
The table below presents the notional values of our derivatives outstanding:

[0001045810-26-000075:notes:86]
|  | Jul 26, 2026 |  | Jan 25, 2026 |
|  | (In millions) |
| Foreign currency contracts designated as accounting hedges | $ | 2,162 |  |  | $ | 1,765 |  |
| Not designated as accounting hedges: |  |  |  |
| Foreign currency contracts | $ | 2,252 |  |  | $ | 2,332 |  |
| Land, power, and shell guarantees for AI clouds (1) | $ | 3,529 |  |  | $ | 3,530 |  |
| Public company warrants | $ | 4,800 |  |  | $ | — |  |
| Equity forward contract | $ | 1,000 |  |  | $ | — |  |

[0001045810-26-000075:notes:87]
(1)    The maximum gross exposure under all agreements is reduced as the partners make payments to the lessors over terms ranging from five to seven years. The partners have placed $712 million in escrow to partially mitigate our potential exposure, which is not reflected in the notional value.


## us-gaap:DebtDisclosureTextBlock

[0001045810-26-000075:notes:88]
Debt

[0001045810-26-000075:notes:89]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  |  |
|  |  |  |  | Jul 26, 2026 |  | Jan 25, 2026 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.1 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.25% Notes Due 2028 |  | 1.9 |  | 4.39% |  | 3,500 |  |  | — |  |
| 1.55% Notes Due 2028 |  | 1.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 4.35% Notes Due 2029 |  | 2.9 |  | 4.45% |  | 3,500 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 3.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 4.50% Notes Due 2031 |  | 4.9 |  | 4.60% |  | 4,000 |  |  | — |  |
| 2.00% Notes Due 2031 |  | 4.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 4.75% Notes Due 2033 |  | 6.9 |  | 4.82% |  | 3,500 |  |  | — |  |
| 4.95% Notes Due 2036 |  | 9.9 |  | 5.01% |  | 4,000 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 13.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 5.55% Notes Due 2046 |  | 19.9 |  | 5.61% |  | 3,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 23.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 5.625% Notes Due 2056 |  | 29.9 |  | 5.66% |  | 3,500 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 33.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (134) |  |  | (32) |  |
| Net carrying amount |  |  |  |  |  | $ | 33,366 |  |  | $ | 8,468 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 32,366 |  |  | $ | 7,469 |  |

[0001045810-26-000075:notes:90]
In June 2026, we issued an aggregate of $25.0 billion of senior unsecured notes across seven tranches for general corporate purposes.

[0001045810-26-000075:notes:91]
As of July 26, 2026, and January 25, 2026, the estimated fair value of debt was $31.4 billion and $7.5 billion, respectively. The estimated fair values are based on Level 2 inputs.

[0001045810-26-000075:notes:92]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity dates of the notes are stated by calendar year.

[0001045810-26-000075:notes:93]
As of July 26, 2026, we complied with the required covenants under the outstanding notes.

[0001045810-26-000075:notes:94]
As of July 26, 2026, our commercial paper program had a capacity of $25.0 billion, with no amounts outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-26-000075:notes:95]
Commitments and Contingencies
Commitments

[0001045810-26-000075:notes:96]
We entered into strategic commitments across our supply, infrastructure, and partner ecosystems to capitalize on future growth opportunities and support our business.

[0001045810-26-000075:notes:97]
Future commitments by fiscal year as of July 26, 2026, were as follows:

[0001045810-26-000075:notes:98]
|  | Remainder of 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 |  | 2032 and thereafter |  | Total |
|  | (In billions) |
| Supply and capacity | $ | 92 |  |  | $ | 87 |  |  | $ | 88 |  |  | $ | 6 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 279 |  |
| Cloud service agreements | 3 |  |  | 8 |  |  | 7 |  |  | 6 |  |  | 4 |  |  | 1 |  |  | 29 |  |
| Data center leases not commenced | — |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |  | 20 |  |  | 25 |  |
| Equity investments | 18 |  |  | 3 |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |  | 25 |  |
| Capital expenditures | 7 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Total | $ | 120 |  |  | $ | 100 |  |  | $ | 98 |  |  | $ | 16 |  |  | $ | 10 |  |  | $ | 22 |  |  | $ | 366 |  |

[0001045810-26-000075:notes:99]
Supply and capacity – We have partnered with our extensive network to secure the necessary supply and critical components needed to meet demand for the next several years, increasing supply commitments from $119 billion last quarter to $279 billion as of July 26, 2026. These supply commitments are for our data center infrastructure systems, primarily memory and manufacturing facilities, to produce our products for long-term demand across current and future product architectures. We enter into agreements with our suppliers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements may be cancelable, rescheduled, or adjustable for our business needs prior to placing firm orders. Changes to these agreements may result in additional costs.

[0001045810-26-000075:notes:100]
Cloud service agreements – These commitments provide the cloud infrastructure to support our research and development of our open models, such as NVIDIA Nemotron, Cosmos, and GR00T, and our autonomous vehicle software.

[0001045810-26-000075:notes:101]
Data center leases not commenced – These leases will be primarily used for engineering, product design, and testing of our compute chips, networking products, and systems. They are expected to begin between the third quarter of fiscal year 2027 and fiscal year 2033 and have terms up to twenty years. Many of the expected lease start dates are subject to and dependent on timing of facility construction completion. Refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for additional information on our leases that have commenced and are recognized in our financial statements.

[0001045810-26-000075:notes:102]
Equity investments – We committed to make certain equity investments in AI model makers, infrastructure financiers, and other private companies, subject to certain contingencies.

[0001045810-26-000075:notes:103]
Capital expenditures – Our capital expenditures primarily include obligations for data center equipment and infrastructure used for engineering and manufacturing operations.

[0001045810-26-000075:notes:104]
Additional Commitments and Guarantees

[0001045810-26-000075:notes:105]
Securing land, power, and shell for data centers is a critical phase in the AI infrastructure buildout. We have entered into arrangements to assist select customers with securing the land, power, shell, and data center capacity needed to support their growth. These strategic commitments and guarantees may impact our financial results and are dependent on the performance of our customers and partners.

[0001045810-26-000075:notes:106]
Additional Commitments

[0001045810-26-000075:notes:107]
|  | Remainder of 2027 |  | 2028 |  | 2029 |  | 2030 |  | 2031 |  | 2032 and thereafter |  | Total |
|  | (In billions) |
| AI cloud agreements | $ | — |  |  | $ | 6 |  |  | $ | 8 |  |  | $ | 7 |  |  | $ | 6 |  |  | $ | 9 |  |  | $ | 36 |  |
| Data center leases not commenced for third party | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 17 |  |  | 20 |  |
| Total | $ | — |  |  | $ | 6 |  |  | $ | 9 |  |  | $ | 8 |  |  | $ | 7 |  |  | $ | 26 |  |  | $ | 56 |  |

[0001045810-26-000075:notes:108]
AI cloud agreements – We have partnered with leading AI clouds to enable broader access to our AI infrastructure to serve AI startups, model builders, enterprises, research organizations and sovereign customers. Under these agreements, AI clouds procure our data center infrastructure products and we commit to cloud service agreements, which the AI clouds can unilaterally stop providing to us and sell to third-party customers at more advantageous rates. Our commitments

[0001045810-26-000075:notes:109]
decrease as capacity is used by third-party customers or by us for our research and development efforts. If certain criteria are met, we will participate in revenue share generated by the AI clouds from third-party customers.

[0001045810-26-000075:notes:110]
Data center leases not commenced for third party – We have entered into data center leases with terms of approximately fifteen years that are expected to commence between fiscal year 2028 and fiscal year 2029. The expected lease start dates are subject to and dependent on timing of construction completion. We expect to reassign these data center leases to third parties. Refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for additional information on our leases.

[0001045810-26-000075:notes:111]
Guarantees

[0001045810-26-000075:notes:112]
Land, power, and shell guarantees for AI clouds – We entered into land, power, and shell guarantees for select AI cloud partners’ data center lease obligations in the event of their default. The maximum gross exposure under all agreements is $3.5 billion. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information on our derivatives.

[0001045810-26-000075:notes:113]
SB Energy Corp. guarantees – In August 2026, we entered into guarantees, capped at a total of $105 billion, to provide credit support on a land, power, and shell buildout with affiliates of SB Energy Corp. (SB Energy) on behalf of a customer, an affiliate of OpenAI Group PBC (OpenAI), related to leases for approximately 4.25 gigawatts of IT load in the aggregate at SB Energy’s PORTS Technology Campus in Pike County, Ohio. Each guarantee generally becomes effective upon commencement of the applicable lease, with corresponding guarantee amounts increasing, as each of the nine phases of data center construction is completed, the first of which is expected in fiscal year 2029. Our payment obligations under the guarantees are triggered upon certain tenant defaults and the amount is expected to decrease over the course of each phase’s 20-year lease term. Our guarantees are limited to defined portions of lease and power payments and not the full cost of the site or all of the tenant’s obligations. The guarantees terminate upon certain events, including OpenAI achieving a satisfactory credit rating or after each respective lease term has completed. In exchange for the guarantees, the site will exclusively host NVIDIA AI infrastructure, subject to limited exceptions. We also hold an option, exercisable in our sole discretion, to provide additional credit support in phases for approximately 3.8 additional gigawatts as the site scales.

[0001045810-26-000075:notes:114]
The following table summarizes the maximum gross exposure related to our guarantees, including the SB Energy Corp. guarantees signed in August 2026 (in billions):

[0001045810-26-000075:notes:115]
| Land, power, and shell guarantees for AI clouds | $ | 3.5 |  |
| SB Energy Corp. guarantees | 105.0 |  |
| Total | $ | 108.5 |  |

[0001045810-26-000075:notes:116]
Accrual for Product Warranty Liabilities

[0001045810-26-000075:notes:117]
The estimated product returns and product warranty activity consisted of the following:

[0001045810-26-000075:notes:118]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,948 |  |  | $ | 2,080 |  |  | $ | 2,807 |  |  | $ | 1,290 |  |
| Additions | 391 |  |  | 220 |  |  | 720 |  |  | 1,090 |  |
| Utilization | (401) |  |  | (156) |  |  | (589) |  |  | (236) |  |
| Balance at end of period | $ | 2,938 |  |  | $ | 2,144 |  |  | $ | 2,938 |  |  | $ | 2,144 |  |

[0001045810-26-000075:notes:119]
For the second quarter and first half of fiscal years 2027 and 2026, the additions in product warranty liabilities primarily related to our Compute & Networking segment.

[0001045810-26-000075:notes:120]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recognized any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-26-000075:notes:121]
Litigation

[0001045810-26-000075:notes:122]
Securities Class Action and Derivative Lawsuits

[0001045810-26-000075:notes:123]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings. On March 25, 2026, the district court granted plaintiffs’ motion for class certification and certified a class of investors consisting of all persons or entities who purchased or otherwise acquired NVIDIA common stock between August 10, 2017, and November 15, 2018, inclusive, excluding certain persons and entities, such as NVIDIA’s officers and directors, and members of their immediate families, among others.

[0001045810-26-000075:notes:124]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-26-000075:notes:125]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties’ stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-26-000075:notes:126]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. On August 11, 2025, the court granted the parties’ stipulation to voluntarily dismiss with prejudice plaintiff City of Westland Police and Fire Retirement System. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-26-000075:notes:127]
Accounting for Loss Contingencies

[0001045810-26-000075:notes:128]
As of July 26, 2026, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-26-000075:notes:129]
Income Taxes
Income tax expense was $11.8 billion and $4.8 billion for the second quarter, and $23.4 billion and $7.9 billion for the first half, of fiscal years 2027 and 2026, respectively. Income tax as a percentage of income before income tax was 16.5% and 15.3% for the second quarter, and 16.5% and 14.9% for the first half, of fiscal years 2027 and 2026, respectively.

[0001045810-26-000075:notes:130]
The effective tax rate increased primarily due to a lower percentage of tax benefits from stock-based compensation, foreign-derived deduction eligible income, and the U.S. federal research tax credit relative to the increase in income before income tax.

[0001045810-26-000075:notes:131]
Our effective tax rates for the first half of fiscal years 2027 and 2026 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from foreign-derived deduction eligible income, income earned in jurisdictions that were subject to taxes at rates lower than the U.S. federal statutory tax rate, stock-based compensation, and the U.S. federal research tax credit.

[0001045810-26-000075:notes:132]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state, and foreign tax-related matters to be recognized in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.

[0001045810-26-000075:notes:133]
[same as prior period, unchanged from 0001045810-26-000052:notes:117]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-26-000075:notes:134]
[same as prior period, unchanged from 0001045810-26-000052:notes:118]

[0001045810-26-000075:notes:135]
We repurchased 94 million and 67 million shares of our common stock for $19.7 billion and $9.7 billion during the second quarter of fiscal years 2027 and 2026, respectively, and 203 million and 193 million shares of our common stock for $39.8 billion and $24.2 billion during the first half of fiscal years 2027 and 2026, respectively.

[0001045810-26-000075:notes:136]
On May 18, 2026, our Board of Directors approved an additional $80.0 billion in share repurchase authorization, without expiration. As of July 26, 2026, we were authorized, subject to certain specifications, to repurchase up to $99.3 billion of our common stock.

[0001045810-26-000075:notes:137]
We paid cash dividends to our shareholders of $6.0 billion and $244 million during the second quarter, and $6.3 billion and $488 million during the first half, of fiscal years 2027 and 2026, respectively. On May 18, 2026, we increased our quarterly cash dividend from $0.01 per share to $0.25 per share.

[0001045810-26-000075:notes:138]
The payment of future cash dividends is subject to our Board of Directors’ continuing determination that the declaration of dividends is in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-26-000075:notes:139]
[same as prior period, unchanged from 0001045810-26-000052:notes:122]

[0001045810-26-000075:notes:140]
[same as prior period, unchanged from 0001045810-26-000052:notes:123]

[0001045810-26-000075:notes:141]
[same as prior period, unchanged from 0001045810-26-000052:notes:124]

[0001045810-26-000075:notes:142]
[same as prior period, unchanged from 0001045810-26-000052:notes:125]

[0001045810-26-000075:notes:143]
[same as prior period, unchanged from 0001045810-26-000052:notes:126]

[0001045810-26-000075:notes:144]
|  | Compute & Networking |  | Graphics |  | Total |
|  | (In millions) |
| Three Months Ended Jul 26, 2026 |  |  |  |  |  |
| Revenue | $ | 88,299 |  |  | $ | 7,922 |  |  | $ | 96,221 |  |
| Other segment items (1) | 25,603 |  |  | 4,023 |  |  | 29,626 |  |
| Operating income | $ | 62,696 |  |  | $ | 3,899 |  |  | $ | 66,595 |  |
| Three Months Ended Jul 27, 2025 |  |  |  |  |  |
| Revenue | $ | 41,331 |  |  | $ | 5,412 |  |  | $ | 46,743 |  |
| Other segment items (1) | 12,968 |  |  | 3,170 |  |  | 16,138 |  |
| Operating income | $ | 28,363 |  |  | $ | 2,242 |  |  | $ | 30,605 |  |
| Six Months Ended Jul 26, 2026 |  |  |  |  |  |
| Revenue | $ | 162,850 |  |  | $ | 14,987 |  |  | $ | 177,837 |  |
| Other segment items (1) | 46,819 |  |  | 8,147 |  |  | 54,966 |  |
| Operating income | $ | 116,031 |  |  | $ | 6,840 |  |  | $ | 122,871 |  |
| Six Months Ended Jul 27, 2025 |  |  |  |  |  |
| Revenue | $ | 80,920 |  |  | $ | 9,885 |  |  | $ | 90,805 |  |
| Other segment items (1) | 30,503 |  |  | 6,003 |  |  | 36,506 |  |
| Operating income | $ | 50,417 |  |  | $ | 3,882 |  |  | $ | 54,299 |  |

[0001045810-26-000075:notes:145]
[same as prior period, unchanged from 0001045810-26-000052:notes:128]

[0001045810-26-000075:notes:146]
Depreciation and amortization expense attributable to our Compute & Networking segment was $642 million and $383 million for the second quarter, and $1.2 billion and $684 million for the first half, of fiscal years 2027 and 2026, respectively. Depreciation and amortization expense attributable to our Graphics segment was $204 million and $148 million for the second quarter, and $399 million and $252 million for the first half, of fiscal years 2027 and 2026, respectively. Acquisition-related intangible amortization expense is not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance.

[0001045810-26-000075:notes:147]
Reconciliation of segment operating income to consolidated income before income tax for the second quarter and first half of fiscal years 2027 and 2026 was as follows:

[0001045810-26-000075:notes:148]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Segment operating income | $ | 66,595 |  |  | $ | 30,605 |  |  | $ | 122,871 |  |  | $ | 54,299 |  |
| Stock-based compensation expense | (2,027) |  |  | (1,624) |  |  | (3,954) |  |  | (3,099) |  |
| Unallocated operating expenses | (612) |  |  | (440) |  |  | (1,178) |  |  | (859) |  |
| Acquisition-related and other costs | (222) |  |  | (101) |  |  | (469) |  |  | (263) |  |
| Other income, net | 7,773 |  |  | 2,766 |  |  | 24,140 |  |  | 3,039 |  |
| Consolidated income before income tax | $ | 71,507 |  |  | $ | 31,206 |  |  | $ | 141,410 |  |  | $ | 53,117 |  |

[0001045810-26-000075:notes:149]
Revenue by geographic region is designated based on the location of the headquarters of direct customers. The end customer and shipping location may be different from our direct customers’ headquarters location.

[0001045810-26-000075:notes:150]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Geographic Revenue based upon Customer Headquarters Location: |  |  |  |  |  |  |  |
| United States | $ | 60,074 |  |  | $ | 32,897 |  |  | $ | 123,843 |  |  | $ | 58,582 |  |
| Taiwan | 26,985 |  |  | 8,902 |  |  | 38,991 |  |  | 16,550 |  |
| China (including Hong Kong) | 7,880 |  |  | 3,985 |  |  | 12,430 |  |  | 13,644 |  |
| Other | 1,282 |  |  | 959 |  |  | 2,573 |  |  | 2,029 |  |
| Total revenue | $ | 96,221 |  |  | $ | 46,743 |  |  | $ | 177,837 |  |  | $ | 90,805 |  |

[0001045810-26-000075:notes:151]
Revenue from sales to customers headquartered outside of the United States accounted for 38% and 30% of total revenue for the second quarter and first half of fiscal year 2027, respectively, and 30% and 35% of total revenue for the second quarter and first half of fiscal year 2026, respectively.

[0001045810-26-000075:notes:152]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, AI clouds, AI model makers, enterprises, and public sector entities. Our revenue is concentrated among a limited number of direct and indirect customers and this trend may continue.

[0001045810-26-000075:notes:153]
For the second quarter of fiscal year 2027, one direct customer represented 16% of total revenue, which was primarily attributable to the Compute & Networking segment. For the first half of fiscal year 2027, three direct customers represented 16%, 15%, and 13% of total revenue, all of which was primarily attributable to the Compute & Networking segment.

[0001045810-26-000075:notes:154]
For the second quarter of fiscal year 2026, two direct customers represented 23% and 16% of total revenue, all of which was primarily attributable to the Compute & Networking segment. For the first half of fiscal year 2026, two direct customers represented 20% and 15% of total revenue, all of which was primarily attributable to the Compute & Networking segment.

[0001045810-26-000075:notes:155]
In the first quarter of fiscal year 2027, we changed our presentation of revenue by market platform, and the comparable periods were recast. During the second quarter of fiscal year 2027, we reclassified a company from AI Clouds, Industrial, & Enterprise (ACIE) to Hyperscale due to a change in their business model and recast the prior period revenue associated with this company.

[0001045810-26-000075:notes:156]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Revenue by Market Platform |  |  |  |  |  |  |  |
| Data Center | $ | 89,023 |  |  | $ | 41,096 |  |  | $ | 164,269 |  |  | $ | 80,208 |  |
| Hyperscale | 48,710 |  |  | 24,168 |  |  | 91,761 |  |  | 46,428 |  |
| AI Clouds, Industrial, & Enterprise | 40,313 |  |  | 16,928 |  |  | 72,508 |  |  | 33,780 |  |
| Edge Computing | 7,198 |  |  | 5,647 |  |  | 13,568 |  |  | 10,597 |  |
| Total revenue | $ | 96,221 |  |  | $ | 46,743 |  |  | $ | 177,837 |  |  | $ | 90,805 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-26-000075:notes:157]
[same as prior period, unchanged from 0001045810-26-000052:notes:139]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-26-000075:notes:158]
[same as prior period, unchanged from 0001045810-26-000052:notes:140]

[0001045810-26-000075:notes:159]
Future minimum lease obligations under our non-cancelable lease agreements as of July 26, 2026, were as follows:

[0001045810-26-000075:notes:160]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2027 (the second half of fiscal year 2027) | $ | 354 |  |
| 2028 | 718 |  |
| 2029 | 715 |  |
| 2030 | 648 |  |
| 2031 | 586 |  |
| 2032 and thereafter | 4,186 |  |
| Total | 7,207 |  |
| Less imputed interest | 1,713 |  |
| Present value of net future minimum lease payments | 5,494 |  |
| Less short-term operating lease liabilities | 509 |  |
| Long-term operating lease liabilities | $ | 4,985 |  |

[0001045810-26-000075:notes:161]
As of July 26, 2026, our operating leases have a weighted average remaining lease term of 10.9 years and a weighted average discount rate of 4.69%. As of January 25, 2026, our operating leases had a weighted average remaining lease term of 8.8 years and a weighted average discount rate of 4.38%.

[0001045810-26-000075:notes:162]
Operating lease costs were $208 million and $109 million for the second quarter, and $379 million and $210 million for the first half, of fiscal years 2027 and 2026, respectively. Short-term, variable, and finance lease costs for the second quarter and first half of fiscal years 2027 and 2026 were not significant.

[0001045810-26-000075:notes:163]
[same as prior period, unchanged from 0001045810-26-000052:notes:145]

[0001045810-26-000075:notes:164]
|  | Six Months Ended |
|  | Jul 26, 2026 |  | Jul 27, 2025 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 353 |  |  | $ | 200 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 2,792 |  |  | $ | 458 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-26-000075:notes:165]
| Name |  | Title of Director or Officer |  | Action |  | Date |  | Total Shares of Common Stock to be Sold |  | Expiration Date |
| Aarti Shah |  | Director |  | Adoption |  | 5/22/2026 |  | 6,500 |  | 5/29/2027 |
| Timothy S. Teter |  | Executive Vice President, General Counsel and Secretary |  | Adoption |  | 5/22/2026 |  | 547,942 and any future equity awards* |  | 12/13/2027 |
| Colette M. Kress |  | Executive Vice President and Chief Financial Officer |  | Adoption |  | 6/16/2026 |  | 375,439** |  | 12/14/2027 |

[0001045810-26-000075:notes:166]
* Includes 367,942 shares from future vests of equity awards, assuming the maximum number of shares issuable under performance-based equity awards where performance is yet to be certified, as well as shares from vests of any future equity grants awarded during the term of the plan. The actual number of shares to be sold will be net of shares withheld by the Company for taxes.
** Represents shares from future vests of equity awards, assuming the maximum number of shares issuable under performance-based equity awards where performance is yet to be certified. The actual number of shares to be sold will be net of shares withheld by the Company for taxes.
