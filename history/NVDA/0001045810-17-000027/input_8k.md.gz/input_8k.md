# NVDA 8-K — 0001045810-17-000016 filed 2017-02-09

## item codes, every 8-K on or before 2017-03-01

- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2017-03-01

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-17-000016:8k_2_02:1]
EX-99.1
2
q4fy17pr.htm
Q4FY17 PRESS RELEASE

[0001045810-17-000016:8k_2_02:2]
Exhibit

[0001045810-17-000016:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-17-000016:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2017

[0001045810-17-000016:8k_2_02:5]
| • | Record quarterly revenue of $2.17 billion, up 55 percent from a year ago |

[0001045810-17-000016:8k_2_02:6]
| • | Record full-year revenue of $6.91 billion, up 38 percent from a year ago |

[0001045810-17-000016:8k_2_02:7]
| • | Record quarterly GAAP gross margin at 60.0 percent, non-GAAP gross margin at 60.2 percent |

[0001045810-17-000016:8k_2_02:8]
| • | GPU computing platform continues to power gains across full product line |

[0001045810-17-000016:8k_2_02:9]
SANTA CLARA, Calif.-Feb. 9, 2017-NVIDIA (NASDAQ: NVDA) today reported revenue for the fourth quarter ended January 29, 2017, of $2.17 billion, up 55 percent from $1.40 billion a year earlier, and up 8 percent from $2.00 billion in the previous quarter.

[0001045810-17-000016:8k_2_02:10]
GAAP earnings per diluted share for the quarter were $0.99, up 183 percent from $0.35 a year ago and up 19 percent from $0.83 in the previous quarter. Non-GAAP earnings per diluted share were $1.13, up 117 percent from $0.52 a year earlier and up 20 percent from $0.94 in the previous quarter.

[0001045810-17-000016:8k_2_02:11]
For fiscal 2017, revenue reached a record $6.91 billion, up 38 percent from $5.01 billion a year earlier. GAAP earnings per diluted share were $2.57, up 138 percent from $1.08 a year earlier. Non-GAAP earnings per diluted share were $3.06, up 83 percent from $1.67 a year earlier.

[0001045810-17-000016:8k_2_02:12]
“We had a great finish to a record year, with continued strong growth across all our businesses,” said Jen-Hsun Huang, founder and chief executive officer of NVIDIA. “Our GPU computing platform is enjoying rapid adoption in artificial intelligence, cloud computing, gaming, and autonomous vehicles.‎

[0001045810-17-000016:8k_2_02:13]
“Deep learning on NVIDIA GPUs, a breakthrough approach to AI, is helping to tackle challenges such as self-driving cars, early cancer detection and weather prediction. We can now see that ‎GPU-based deep learning will revolutionize major industries, from consumer internet and transportation to health care and manufacturing. The era of AI is upon us,” he said.

[0001045810-17-000016:8k_2_02:14]
Capital Return

[0001045810-17-000016:8k_2_02:15]
During fiscal 2017, NVIDIA paid $739 million in share repurchases and $261 million in cash dividends. As a result, the company returned an aggregate of $1.00 billion to shareholders in fiscal 2017.

[0001045810-17-000016:8k_2_02:16]
For fiscal 2018, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-17-000016:8k_2_02:17]
NVIDIA will pay its next quarterly cash dividend of $0.14 per share on March 17, 2017, to all shareholders of record on February 24, 2017.

[0001045810-17-000016:8k_2_02:18]
Q4 Fiscal 2017 Summary

[0001045810-17-000016:8k_2_02:19]
| GAAP |
| ($ in millions except earnings per share) | Q4 FY17 | Q3 FY17 | Q4 FY16 | Q/Q | Y/Y |
| Revenue | $2,173 | $2,004 | $1,401 | up 8% | up 55% |
| Gross margin | 60.0 | % | 59.0 | % | 56.5 | % | up 100 bps | up 350 bps |
| Operating expenses | $570 | $544 | $539 | up 5% | up 6% |
| Operating income | $733 | $639 | $252 | up 15% | up 191% |
| Net income | $655 | $542 | $207 | up 21% | up 216% |
| Diluted earnings per share | $0.99 | $0.83 | $0.35 | up 19% | up 183% |

[0001045810-17-000016:8k_2_02:20]
| Non-GAAP |
| ($ in millions except earnings per share) | Q4 FY17 | Q3 FY17 | Q4 FY16 | Q/Q | Y/Y |
| Revenue | $2,173 | $2,004 | $1,401 | up 8% | up 55% |
| Gross margin | 60.2 | % | 59.2 | % | 57.2 | % | up 100 bps | up 300 bps |
| Operating expenses | $498 | $478 | $445 | up 4% | up 12% |
| Operating income | $809 | $708 | $356 | up 14% | up 127% |
| Net income | $704 | $570 | $297 | up 24% | up 137% |
| Diluted earnings per share | $1.13 | $0.94 | $0.52 | up 20% | up 117% |

[0001045810-17-000016:8k_2_02:21]
Fiscal 2017 Summary

[0001045810-17-000016:8k_2_02:22]
| GAAP |
| ($ in millions except earnings per share) | FY17 | FY16 | Y/Y |
| Revenue | $6,910 | $5,010 | up 38% |
| Gross margin | 58.8 | % | 56.1 | % | up 270 bps |
| Operating expenses | $2,129 | $2,064 | up 3% |
| Operating income | $1,934 | $747 | up 159% |
| Net income | $1,666 | $614 | up 171% |
| Diluted earnings per share | $2.57 | $1.08 | up 138% |

[0001045810-17-000016:8k_2_02:23]
| Non-GAAP |
| ($ in millions except earnings per share) | FY17 | FY16 | Y/Y |
| Revenue | $6,910 | $5,010 | up 38% |
| Gross margin | 59.2 | % | 56.8 | % | up 240 bps |
| Operating expenses | $1,867 | $1,721 | up 8% |
| Operating income | $2,221 | $1,125 | up 97% |
| Net income | $1,851 | $929 | up 99% |
| Diluted earnings per share | $3.06 | $1.67 | up 83% |

[0001045810-17-000016:8k_2_02:24]
NVIDIA’s outlook for the first quarter of fiscal 2018 is as follows:

[0001045810-17-000016:8k_2_02:25]
| • | Revenue is expected to be $1.90 billion, plus or minus two percent. |

[0001045810-17-000016:8k_2_02:26]
| • | GAAP and non-GAAP gross margins are expected to be 59.5 percent and 59.7 percent, respectively, plus or minus 50 basis points. |

[0001045810-17-000016:8k_2_02:27]
| • | GAAP operating expenses are expected to be approximately $603 million. Non-GAAP operating expenses are expected to be approximately $520 million. |

[0001045810-17-000016:8k_2_02:28]
| • | GAAP other income and expense, net, is expected to be an expense of approximately $20 million, inclusive of additional charges from early conversions of convertible notes. Non-GAAP other income and expense, net, is expected to be an expense of approximately $4 million. |

[0001045810-17-000016:8k_2_02:29]
| • | GAAP and non-GAAP tax rates for the first quarter of fiscal 2018 are both expected to be 17 percent, plus or minus one percent, excluding any discrete items. |

[0001045810-17-000016:8k_2_02:30]
| • | Weighted average shares used in the GAAP and non-GAAP diluted EPS calculations are dependent on the weighted average stock price during the quarter. |

[0001045810-17-000016:8k_2_02:31]
| • | Capital expenditures are expected to be approximately $50 million to $60 million. |

[0001045810-17-000016:8k_2_02:32]
Fourth Quarter Fiscal 2017 Highlights

[0001045810-17-000016:8k_2_02:33]
During the fourth quarter, NVIDIA achieved progress in each of its four major platforms.

[0001045810-17-000016:8k_2_02:34]
Gaming:

[0001045810-17-000016:8k_2_02:35]
| • | Introduced GeForce® GTX 1050 and 1050 Ti mobile GPUs, which debuted in more than 30 gaming laptops at CES 2017. |

[0001045810-17-000016:8k_2_02:36]
| • | Launched the new SHIELD™ TV, integrating Google Assistant for TV, SmartThings Hub technology and the NVIDIA SPOT™ AI mic. |

[0001045810-17-000016:8k_2_02:37]
| • | Unveiled the GeForce NOW™ service, delivering an NVIDIA Pascal™ gaming PC, on demand, from the cloud to all computers. |

[0001045810-17-000016:8k_2_02:38]
Professional Visualization:

[0001045810-17-000016:8k_2_02:39]
| • | Launched NVIDIA’s new workstation-product lineup with Quadro® GP100, enabling a new class of supercomputing workstations. |

[0001045810-17-000016:8k_2_02:40]
| • | Introduced Quadro P5000, powering the first VR-ready mobile workstations from Dell and MSI. |

[0001045810-17-000016:8k_2_02:41]
Datacenter:

[0001045810-17-000016:8k_2_02:42]
| • | Collaborated with Microsoft to accelerate AI with a GPU-accelerated Microsoft Cognitive Toolkit available on the Microsoft Azure cloud and NVIDIA DGX-1™. |

[0001045810-17-000016:8k_2_02:43]
| • | Partnered with the National Cancer Institute and the U.S. Department of Energy to build CANDLE, an AI framework that will advance cancer research. |

[0001045810-17-000016:8k_2_02:44]
| • | Unveiled the NVIDIA DGX SATURNV AI supercomputer, powered by 124 Pascal-powered DGX-1 server nodes, which is the world’s most efficient supercomputer. |

[0001045810-17-000016:8k_2_02:45]
Automotive:

[0001045810-17-000016:8k_2_02:46]
| • | Partnered with Audi, to put advanced AI cars on the road by 2020. |

[0001045810-17-000016:8k_2_02:47]
| • | Partnered with Mercedes-Benz, to bring an NVIDIA AI-powered car to the market. |

[0001045810-17-000016:8k_2_02:48]
| • | Partnered with Bosch, the world’s largest automotive supplier, to bring self-driving systems to production vehicles |

[0001045810-17-000016:8k_2_02:49]
| • | Partnered with Germany’s ZF, to create a self-driving system for cars, trucks and commercial vehicles based on the NVIDIA DRIVE™ PX 2 AI car computer. |

[0001045810-17-000016:8k_2_02:50]
| • | Partnered with Europe’s HERE, to develop HERE HD Live Map into a real-time, high-definition mapping solution for autonomous vehicles. |

[0001045810-17-000016:8k_2_02:51]
| • | Partnered with Japan’s ZENRIN, to develop a cloud-to-car HD map solution for self-driving cars. |

[0001045810-17-000016:8k_2_02:52]
CFO Commentary

[0001045810-17-000016:8k_2_02:53]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-17-000016:8k_2_02:54]
Conference Call and Webcast Information

[0001045810-17-000016:8k_2_02:55]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2017 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 52907909. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its first quarter of fiscal 2018.

[0001045810-17-000016:8k_2_02:56]
Non-GAAP Measures

[0001045810-17-000016:8k_2_02:57]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, product warranty charge, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, loss on early debt conversions, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-17-000016:8k_2_02:58]
Keep Current on NVIDIA

[0001045810-17-000016:8k_2_02:59]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-17-000016:8k_2_02:60]
About NVIDIA

[0001045810-17-000016:8k_2_02:61]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. Today, NVIDIA is increasingly known as “the AI computing company.” More information at http://nvidianews.nvidia.com/.

[0001045810-17-000016:8k_2_02:62]
###

[0001045810-17-000016:8k_2_02:63]
For further information, contact:

[0001045810-17-000016:8k_2_02:64]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-17-000016:8k_2_02:65]
Certain statements in this press release including, but not limited to statements as to: the company’s GPU platform continuing to power gains and enjoying rapid adoption; the impact of GPU-based deep learning; the company’s intended capital return for fiscal 2018; the company’s next quarterly cash dividend; the company’s financial outlook for the first quarter of fiscal 2018; the company’s tax rates for the first quarter of fiscal 2018; and the impact and benefits of Quadro, CANDLE, and automotive partnerships are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended October 30, 2016. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-17-000016:8k_2_02:66]
© 2017 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Quadro, Tesla, GeForce NOW, NVIDIA DGX-1, NVIDIA DRIVE, NVIDIA SPOT, SHIELD and Pascal are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-17-000016:8k_2_02:67]
NVIDIA CORPORATION

[0001045810-17-000016:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-17-000016:8k_2_02:69]
(In millions, except per share data)

[0001045810-17-000016:8k_2_02:70]
(Unaudited)

[0001045810-17-000016:8k_2_02:71]
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 29, |  | January 31, |  | January 29, |  | January 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue | $ | 2,173 |  |  | $ | 1,401 |  |  | $ | 6,910 |  |  | $ | 5,010 |  |
| Cost of revenue | 870 |  |  | 610 |  |  | 2,847 |  |  | 2,199 |  |
| Gross profit | 1,303 |  |  | 791 |  |  | 4,063 |  |  | 2,811 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 394 |  |  | 344 |  |  | 1,463 |  |  | 1,331 |  |
| Sales, general and administrative | 176 |  |  | 161 |  |  | 663 |  |  | 602 |  |
| Restructuring and other charges | — |  |  | 34 |  |  | 3 |  |  | 131 |  |
| Total operating expenses | 570 |  |  | 539 |  |  | 2,129 |  |  | 2,064 |  |
| Income from operations | 733 |  |  | 252 |  |  | 1,934 |  |  | 747 |  |
| Interest income | 17 |  |  | 11 |  |  | 54 |  |  | 39 |  |
| Interest expense | (18 | ) |  | (12 | ) |  | (58 | ) |  | (47 | ) |
| Other income (expense), net | (6 | ) |  | 2 |  |  | (25 | ) |  | 4 |  |
| Income before income tax expense | 726 |  |  | 253 |  |  | 1,905 |  |  | 743 |  |
| Income tax expense | 71 |  |  | 46 |  |  | 239 |  |  | 129 |  |
| Net income | $ | 655 |  |  | $ | 207 |  |  | $ | 1,666 |  |  | $ | 614 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.18 |  |  | $ | 0.38 |  |  | $ | 3.08 |  |  | $ | 1.13 |  |
| Diluted | $ | 0.99 |  |  | $ | 0.35 |  |  | $ | 2.57 |  |  | $ | 1.08 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 553 |  |  | 539 |  |  | 541 |  |  | 543 |  |
| Diluted | 660 |  |  | 593 |  |  | 649 |  |  | 569 |  |

[0001045810-17-000016:8k_2_02:72]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | January 29, |  | January 31, |
|  |  |  | 2017 |  | 2016 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 6,798 |  |  | $ | 5,037 |  |
|  | Accounts receivable, net |  | 826 |  |  | 505 |  |
|  | Inventories |  | 794 |  |  | 418 |  |
|  | Prepaid expenses and other current assets |  | 118 |  |  | 93 |  |
|  | Total current assets |  | 8,536 |  |  | 6,053 |  |
| Property and equipment, net |  | 521 |  |  | 466 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 104 |  |  | 166 |  |
| Other assets |  | 62 |  |  | 67 |  |
|  | Total assets |  | $ | 9,841 |  |  | $ | 7,370 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 485 |  |  | $ | 296 |  |
|  | Accrued and other current liabilities |  | 507 |  |  | 642 |  |
|  | Convertible short-term debt |  | 796 |  |  | 1,413 |  |
|  | Total current liabilities |  | 1,788 |  |  | 2,351 |  |
| Long-term debt |  | 1,983 |  |  | — |  |
| Other long-term liabilities |  | 271 |  |  | 453 |  |
| Capital lease obligations, long-term |  | 6 |  |  | 10 |  |
|  | Total liabilities |  | 4,048 |  |  | 2,814 |  |
| Convertible debt conversion obligation |  | 31 |  |  | 87 |  |
| Shareholders' equity |  | 5,762 |  |  | 4,469 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 9,841 |  |  | $ | 7,370 |  |

[0001045810-17-000016:8k_2_02:73]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 29, |  | October 30 |  | January 31, |  | January 29, |  | January 31, |
|  |  | 2017 |  | 2016 |  | 2016 |  | 2017 |  | 2016 |
| GAAP gross profit |  | $ | 1,303 |  |  | $ | 1,183 |  |  | $ | 791 |  |  | $ | 4,063 |  |  | $ | 2,811 |  |
| GAAP gross margin |  | 60.0 | % |  | 59.0 | % |  | 56.5 | % |  | 58.8 | % |  | 56.1 | % |
| Stock-based compensation expense (A) |  | 4 |  |  | 3 |  |  | 5 |  |  | 15 |  |  | 15 |  |
| Legal settlement costs (B) |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Product warranty charge (C) |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 20 |  |
| Non-GAAP gross profit |  | $ | 1,307 |  |  | $ | 1,186 |  |  | $ | 801 |  |  | $ | 4,088 |  |  | $ | 2,846 |  |
| Non-GAAP gross margin |  | 60.2 | % |  | 59.2 | % |  | 57.2 | % |  | 59.2 | % |  | 56.8 | % |
| GAAP operating expenses |  | $ | 570 |  |  | $ | 544 |  |  | $ | 539 |  |  | $ | 2,129 |  |  | $ | 2,064 |  |
| Stock-based compensation expense (A) |  | (68 | ) |  | (62 | ) |  | (56 | ) |  | (233 | ) |  | (190 | ) |
| Legal settlement costs (B) |  | — |  |  | — |  |  | — |  |  | (6 | ) |  | — |  |
| Acquisition-related costs (D) |  | (4 | ) |  | (4 | ) |  | (4 | ) |  | (16 | ) |  | (22 | ) |
| Contributions |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | — |  |
| Restructuring and other charges |  | — |  |  | — |  |  | (34 | ) |  | (3 | ) |  | (131 | ) |
| Non-GAAP operating expenses |  | $ | 498 |  |  | $ | 478 |  |  | $ | 445 |  |  | $ | 1,867 |  |  | $ | 1,721 |  |
| GAAP income from operations |  | $ | 733 |  |  | $ | 639 |  |  | $ | 252 |  |  | $ | 1,934 |  |  | $ | 747 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 76 |  |  | 69 |  |  | 104 |  |  | 287 |  |  | 378 |  |
| Non-GAAP income from operations |  | $ | 809 |  |  | $ | 708 |  |  | $ | 356 |  |  | $ | 2,221 |  |  | $ | 1,125 |  |
| GAAP other income (expense), net |  | $ | (7 | ) |  | $ | (18 | ) |  | $ | 1 |  |  | $ | (29 | ) |  | $ | (4 | ) |
| Gains from non-affiliated investments |  | (1 | ) |  | — |  |  | — |  |  | (4 | ) |  | (5 | ) |
| Interest expense related to amortization of debt discount |  | 4 |  |  | 6 |  |  | 7 |  |  | 25 |  |  | 29 |  |
| Loss on early debt conversions |  | 6 |  |  | 15 |  |  | — |  |  | 21 |  |  | — |  |
| Non-GAAP other income, net |  | $ | 2 |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 13 |  |  | $ | 20 |  |
| GAAP net income* |  | $ | 655 |  |  | $ | 542 |  |  | $ | 207 |  |  | $ | 1,666 |  |  | $ | 614 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 85 |  |  | 90 |  |  | 111 |  |  | 329 |  |  | 402 |  |
| Income tax impact of non-GAAP adjustments |  | (36 | ) |  | (62 | ) |  | (21 | ) |  | (144 | ) |  | (87 | ) |
| Non-GAAP net income |  | $ | 704 |  |  | $ | 570 |  |  | $ | 297 |  |  | $ | 1,851 |  |  | $ | 929 |  |

[0001045810-17-000016:8k_2_02:74]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 29, |  | October 30 |  | January 31, |  | January 29, |  | January 31, |
|  |  | 2017 |  | 2016 |  | 2016 |  | 2017 |  | 2016 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP* |  | $ | 0.99 |  |  | $ | 0.83 |  |  | $ | 0.35 |  |  | $ | 2.57 |  |  | $ | 1.08 |  |
| Non-GAAP |  | $ | 1.13 |  |  | $ | 0.94 |  |  | $ | 0.52 |  |  | $ | 3.06 |  |  | $ | 1.67 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP* |  | 660 |  |  | 653 |  |  | 593 |  |  | 649 |  |  | 569 |  |
| Anti-dilution impact from note hedge (E) |  | (36 | ) |  | (45 | ) |  | (26 | ) |  | (44 | ) |  | (13 | ) |
| Non-GAAP |  | 624 |  |  | 608 |  |  | 567 |  |  | 605 |  |  | 556 |  |
| GAAP net cash provided by operating activities* |  | $ | 721 |  |  | $ | 432 |  |  | $ | 510 |  |  | $ | 1,672 |  |  | $ | 1,175 |  |
| Purchase of property and equipment and intangible assets |  | (52 | ) |  | (38 | ) |  | (15 | ) |  | (176 | ) |  | (86 | ) |
| Free cash flow |  | $ | 669 |  |  | $ | 394 |  |  | $ | 495 |  |  | $ | 1,496 |  |  | $ | 1,089 |  |

[0001045810-17-000016:8k_2_02:75]
* In third quarter of fiscal 2017, NVIDIA adopted an accounting standard (ASU 2016-09), which requires adjustments to be reflected beginning in fiscal 2017, including all fiscal quarters within the year.

[0001045810-17-000016:8k_2_02:76]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 29, |  | October 30 |  | January 31, |  | January 29, |  | January 31, |
|  |  | 2017 |  | 2016 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenue |  | $ | 4 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 15 |  |  | $ | 15 |  |
| Research and development |  | $ | 40 |  |  | $ | 35 |  |  | $ | 33 |  |  | $ | 135 |  |  | $ | 115 |  |
| Sales, general and administrative |  | $ | 27 |  |  | $ | 27 |  |  | $ | 22 |  |  | $ | 98 |  |  | $ | 74 |  |
| (B) Legal settlement with Advanced Silicon Technologies LLC and other settlement related costs. |
| (C) Represents warranty charge associated with a product recall. |
| (D) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (E) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-17-000016:8k_2_02:77]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2018 Outlook |
| GAAP gross margin |  | 59.5 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 59.7 | % |
|  |  |  | Q1 FY2018 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 603 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (83 | ) |
| Non-GAAP operating expenses |  | $ | 520 |  |
