# NVDA MD&A — 0001045810-17-000027


## mdna

[0001045810-17-000027:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001045810-17-000027:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 1A. Risk Factors”, “Item 6. Selected Financial Data”, our Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Annual Report on Form 10-K, before deciding to purchase, hold or sell shares of our common stock.

[0001045810-17-000027:mdna:3]
Overview

[0001045810-17-000027:mdna:4]
Our Company and Our Businesses

[0001045810-17-000027:mdna:5]
Starting with a focus on PC graphics, NVIDIA invented the GPU to solve some of the most complex problems in computer science. We have extended our emphasis in recent years to the revolutionary field of AI.  NVIDIA delivers value to its customers through PC, mobile and cloud architectures. Vertical integration enables us to bring together hardware, system software, programmable algorithms, libraries, systems and services to create unique value for the markets we serve.  We specialize in markets in which GPU-based visual computing and accelerated computing platforms can provide tremendous throughput for applications.

[0001045810-17-000027:mdna:6]
Our two reportable segments - GPU and Tegra Processor - are based on a single underlying graphics architecture. From our proprietary processors, we have created specialized platforms that target the four large markets where our expertise is critical: Gaming, Professional Visualization, Datacenter, and Automotive.

[0001045810-17-000027:mdna:7]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for mobile gaming and entertainment devices, as well as autonomous robots, drones and cars.

[0001045810-17-000027:mdna:8]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-17-000027:mdna:9]
Recent Developments, Future Objectives and Challenges

[0001045810-17-000027:mdna:10]
Fiscal Year 2017 Summary

[0001045810-17-000027:mdna:11]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | Change |
|  | ($ in millions, except per share data) |
| Revenue | $ | 6,910 |  |  | $ | 5,010 |  |  | 38 | % |
| Gross margin | 58.8 | % |  | 56.1 | % |  | 270 bps |  |
| Operating expenses | $ | 2,129 |  |  | $ | 2,064 |  |  | 3 | % |
| Income from operations | $ | 1,934 |  |  | $ | 747 |  |  | 159 | % |
| Net income | $ | 1,666 |  |  | $ | 614 |  |  | 171 | % |
| Net income per diluted share | $ | 2.57 |  |  | $ | 1.08 |  |  | 138 | % |

[0001045810-17-000027:mdna:12]
Revenue for fiscal year 2017 grew 38% to $6.91 billion, reflecting growth in each of our market platforms -- Gaming, Professional Visualization, Datacenter, and Automotive. GPU business revenue was $5.82 billion, up 39% from a year earlier, led by growth in our GeForce GPU gaming and datacenter platforms. GeForce GPU gaming growth was fueled by strong adoption of our latest Pascal architecture. Datacenter growth reflected strong demand for deep learning training, cloud and virtualized computing, and sales of our new DGX-1 supercomputer. Tegra business revenue was $824 million, up 47% from a year ago, led by growth in automotive, primarily from infotainment modules, and gaming development platforms and services.

[0001045810-17-000027:mdna:13]
Gross margin for fiscal year 2017 was 58.8%, compared with 56.1% a year earlier, reflecting the growth of GeForce gaming GPUs, the growth of our GPU computing platforms for cloud, deep learning, AI, and graphics virtualization, and decreased sales volumes of lower margin products.

[0001045810-17-000027:mdna:14]
Operating expenses for fiscal year 2017 were $2.13 billion, up from $2.06 billion in the previous year. This reflects growth in headcount and related costs, partially offset by lower litigation and restructuring expenses.

[0001045810-17-000027:mdna:15]
Net income and net income per diluted share for fiscal year 2017 were $1.67 billion and $2.57, respectively, up 171% and 138%, respectively, from a year earlier. These increases were fueled by strong revenue growth, improved gross and operating margins, and a lower effective income tax rate as a result of a decrease in the amount of earnings subject to United States tax and the recognition of excess tax benefits from our adoption of a new accounting standard related to the simplification of certain aspects of stock-based compensation accounting.

[0001045810-17-000027:mdna:16]
We returned $1.00 billion to shareholders in fiscal year 2017 through share repurchases and quarterly cash dividends, and we intend to return approximately $1.25 billion to shareholders in fiscal year 2018.

[0001045810-17-000027:mdna:17]
Cash, cash equivalents and marketable securities were $6.80 billion as of January 29, 2017, up from $5.04 billion as of January 31, 2016.

[0001045810-17-000027:mdna:18]
GPU Business

[0001045810-17-000027:mdna:19]
During fiscal year 2017, we released many new gaming GPU products based on our new NVIDIA Pascal architecture, including GeForce GTX Titan X, GeForce GTX 1080, 1070, 1060, 1050 and 1050Ti. We also expanded the NVIDIA VRWorks software development kit, released our first game, NVIDIA VR Funhouse, and introduced NVIDIA Ansel, an in-game photography tool.

[0001045810-17-000027:mdna:20]
For datacenter, we introduced the Tesla P100, P40 and P4 GPU accelerators, based on the Pascal architecture, unveiled our Inception Program, which provides access to NVIDIA technology and expertise to support the growth of startups in deep learning and data science, introduced the Tesla M10 for virtualizing enterprise applications, launched the NVIDIA TensorRT deep learning inferencing framework, and began shipping the DGX-1 AI supercomputer to research organizations, universities, and multinationals. We also collaborated with Microsoft to accelerate AI with a GPU-accelerated Microsoft Cognitive Toolkit available on the Microsoft Azure cloud and NVIDIA DGX-1, partnered with the National Cancer Institute and the U.S. Department of Energy to build CANDLE, an AI framework that will advance cancer research, and unveiled the NVIDIA DGX SATURNV AI supercomputer, powered by 124 Pascal-powered DGX-1 server nodes.

[0001045810-17-000027:mdna:21]
29

[0001045810-17-000027:mdna:22]
For professional visualization, we enabled a new class of supercomputing workstations using Quadro GP100, introduced Quadro P5000 to power VR-ready mobile workstations, the 24GB Quadro M6000, the Quadro M2000, and unveiled the Quadro P6000 to power advanced workstations. We also refreshed NVIDIA DesignWorks and NVIDIA VRWorks with new updates and software development kits, introduced NVIDIA Iray physically-based rendering solutions, and unveiled Iray VR, which creates interactive, photorealistic virtual 3D worlds.

[0001045810-17-000027:mdna:23]
Tegra Processor Business

[0001045810-17-000027:mdna:24]
During fiscal year 2017, for the automotive market, we introduced the HD Mapping platform for self-driving cars, announced that our NVIDIA DRIVE PX 2 platform will power vehicles in the new ROBORACE autonomous car-racing circuit, initiated collaborative research in advanced self-driving technology with New York University’s pioneering deep learning team, and announced that NVIDIA DRIVE PX 2 will power a new AutoPilot system in all of Tesla Motors’ factory produced vehicles - the Model S, Model X and upcoming Model 3. We also announced a number of new partnerships aimed at getting AI-powered cars, trucks and commercial vehicles on the road, including partnerships with Audi, Bosch, Mercedes-Benz, and ZF. We also partnered with Europe’s HERE to develop a real-time, high-definition mapping solution for autonomous vehicles, and with Japan’s ZENRIN to develop a cloud-to-car high-definition map solution for self-driving cars.

[0001045810-17-000027:mdna:25]
We also expanded the NVIDIA SHIELD platform’s gaming content available for streaming from GeForce NOW, announced that NVIDIA gaming technology will power the Nintendo Switch home gaming system, and launched our new SHIELD TV, which integrates Google Assistant for TV, SmartThings Hub technology and the NVIDIA SPOT AI mic.

[0001045810-17-000027:mdna:26]
Critical Accounting Policies and Estimates

[0001045810-17-000027:mdna:27]
Management’s discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, inventories, income taxes, goodwill, cash equivalents and marketable securities, stock-based compensation, and litigation, investigation and settlement costs and other contingencies. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities.

[0001045810-17-000027:mdna:28]
We believe the following critical accounting policies affect our significant judgments and estimates used in the preparation of our consolidated financial statements. Our management has discussed the development and selection of these critical accounting policies and estimates with the Audit Committee of our Board of Directors. The Audit Committee has reviewed our disclosures relating to our critical accounting policies and estimates in this Annual Report on Form 10-K.

[0001045810-17-000027:mdna:29]
Revenue Recognition

[0001045810-17-000027:mdna:30]
Product Revenue

[0001045810-17-000027:mdna:31]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured.

[0001045810-17-000027:mdna:32]
For sales to certain distributors with rights of return for which the level of returns cannot be reasonably estimated, our policy is to defer recognition of revenue and related cost of revenue until the distributors resell the product and, in some cases, when customer return rights lapse.

[0001045810-17-000027:mdna:33]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. In such cases, the OEMs may not be our direct customers and therefore the quantity and mix of demand they place on their CEMs/ODMs may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents less than 0.5% of total revenue.

[0001045810-17-000027:mdna:34]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors, add-in card partners and other channel partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed.

[0001045810-17-000027:mdna:35]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-17-000027:mdna:36]
License and Development Revenue

[0001045810-17-000027:mdna:37]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete the project. We periodically evaluate the actual status of each project to ensure that the estimates to complete each contract remain accurate. Revenue recognized in any period is dependent on our progress toward completion of projects in progress. Significant management judgment and discretion are used to estimate total cost. Any changes in or deviations from these estimates could have a material effect on the amount of revenue we recognize in any period.

[0001045810-17-000027:mdna:38]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-17-000027:mdna:39]
Please refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-17-000027:mdna:40]
Inventories

[0001045810-17-000027:mdna:41]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions.

[0001045810-17-000027:mdna:42]
Situations that may result in excess or obsolete inventory include changes in business and economic conditions, changes in market conditions, sudden and significant decreases in demand for our products, inventory obsolescence because of changing technology and customer requirements, failure to estimate customer demand properly, or unexpected competitive pricing actions by our competition. In addition, cancellation or deferral of customer purchase orders could result in our holding excess inventory. Also, we may not be able to reduce our inventory purchase commitments in a timely manner in response to customer cancellations or deferrals.

[0001045810-17-000027:mdna:43]
The overall net effect on our gross margin from inventory provisions and sales of items previously written down was an unfavorable impact of 0.2%, 1.6%, and 0.6% in fiscal years 2017, 2016, and 2015, respectively. The charges we took to cost of sales for inventory provisions during these fiscal years were primarily related to the write-off of excess quantities of products whose inventory levels were higher than our updated forecasts of future demand for those products. As a fabless semiconductor company, we must make commitments to purchase inventory based on forecasts of future customer demand. In doing so, we must account for our third-party manufacturers' lead times and constraints. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001045810-17-000027:mdna:44]
Please refer to the Gross Profit and Gross Margin discussion below in this Management's Discussion and Analysis for further discussion.

[0001045810-17-000027:mdna:45]
Income Taxes

[0001045810-17-000027:mdna:46]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-17-000027:mdna:47]
United States income tax has not been provided for a portion of earnings of our non-U.S. subsidiaries to the extent that such earnings are considered to be indefinitely reinvested.

[0001045810-17-000027:mdna:48]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-17-000027:mdna:49]
As of January 29, 2017, we had a valuation allowance of $353 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-17-000027:mdna:50]
Goodwill

[0001045810-17-000027:mdna:51]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier, if indicators of potential impairment exist, using either a qualitative or a quantitative assessment. Our impairment review process compares the fair value of the reporting unit in which the goodwill resides to its carrying value. We have identified two reporting units, GPU and Tegra Processor, for the purposes of completing our goodwill analysis. Goodwill assigned to  the GPU and Tegra Processor reporting units as of January 29, 2017 was $210 million and $408 million, respectively. Determining the fair value of a reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. We also make judgments and assumptions in allocating assets and liabilities to each of our reporting units. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain.

[0001045810-17-000027:mdna:52]
During the fourth quarter of fiscal year 2017, we elected to use the quantitative assessment to test goodwill for impairment for each reporting unit. In applying the fair value based test of each reporting unit, the results from the income approach and the market approach were equally weighted. These valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, terminal or residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-17-000027:mdna:53]
When performing an income approach valuation, we incorporate the use of projected financial information and a discount rate that are developed using market participant based assumptions to our discounted cash flow model. Our estimates of discounted cash flow were based upon, among other things, certain assumptions about our expected future operating performance, such as revenue growth rates, operating margins, risk-adjusted discount rates, and future economic and market conditions. Our estimates may differ from actual cash flow due to, among other things, economic conditions, changes to our business model or changes in operating performance. Additionally, certain estimates of discounted cash flow involve businesses with limited financial history and developing revenue models, which increases the risk of differences between the projected and actual performance. The long-term financial forecasts that we utilize represent the best estimate that we have at this time and we believe that its underlying assumptions are reasonable. Significant differences between our estimates and actual cash flow could materially affect our future financial results, which could impact our future estimates of the fair value of our reporting units.

[0001045810-17-000027:mdna:54]
During the fourth quarter of fiscal year 2017, we concluded that there was no impairment of our goodwill. The fair values of our GPU and Tegra Processor reporting units significantly exceeded their respective carrying values. As such, even the application of a hypothetical 10% decrease to the fair value of each reporting unit would not have resulted in the fair value of either reporting unit being less than its carrying value. As an overall test of the reasonableness of estimated fair values of our reporting units, we reconciled the combined fair value estimates of our reporting units to our market capitalization as of the valuation date. The reconciliation confirmed that the fair values were relatively representative of the market views when applying a reasonable control premium to the market capitalization. However, any significant reductions in the actual amount of future cash flows realized by our reporting units, reductions in the value of market comparables, or reductions in our market capitalization could impact future estimates of the fair values of our reporting units. Such events could ultimately result in a charge to our earnings in future periods due to the potential for a write-down of the goodwill associated with our reporting units.

[0001045810-17-000027:mdna:55]
Cash Equivalents and Marketable Securities

[0001045810-17-000027:mdna:56]
Cash equivalents consist of financial instruments which are readily convertible into cash and have original maturities of three months or less at the time of acquisition.  Marketable securities consist primarily of highly liquid investments with maturities greater than three months when purchased. We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments.

[0001045810-17-000027:mdna:57]
We performed an impairment review of our investment portfolio as of January 29, 2017. We concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of January 29, 2017.

[0001045810-17-000027:mdna:58]
Please refer to Notes 6 and 7 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-17-000027:mdna:59]
Stock-based Compensation

[0001045810-17-000027:mdna:60]
Our stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, our employee stock purchase plan, or ESPP, and stock options. In fiscal year 2015, we shifted away from granting stock options and toward granting RSUs, PSUs and market-based PSUs to reflect changing market trends for equity incentives at our peer companies. The number of PSUs and market-based PSUs that will ultimately be awarded is contingent on the Company’s level of achievement compared with the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year.

[0001045810-17-000027:mdna:61]
Please refer to Notes 1 and 2 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-17-000027:mdna:62]
Litigation, Investigation and Settlement Costs

[0001045810-17-000027:mdna:63]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigations, and we cannot be certain that these actions or other third-party claims against us will be resolved without costly litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-17-000027:mdna:64]
Results of Operations

[0001045810-17-000027:mdna:65]
The following table sets forth, for the periods indicated, certain items in our Consolidated Statements of Income expressed as a percentage of revenue.

[0001045810-17-000027:mdna:66]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 41.2 |  |  | 43.9 |  |  | 44.5 |  |
| Gross profit | 58.8 |  |  | 56.1 |  |  | 55.5 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 21.2 |  |  | 26.6 |  |  | 29.0 |  |
| Sales, general and administrative | 9.6 |  |  | 12.0 |  |  | 10.3 |  |
| Restructuring and other charges | — |  |  | 2.6 |  |  | — |  |
| Total operating expenses | 30.8 |  |  | 41.2 |  |  | 39.3 |  |
| Income from operations | 28.0 |  |  | 14.9 |  |  | 16.2 |  |
| Interest income | 0.8 |  |  | 0.8 |  |  | 0.6 |  |
| Interest expense | (0.8 | ) |  | (0.9 | ) |  | (1.0 | ) |
| Other income (expense), net | (0.4 | ) |  | 0.1 |  |  | 0.3 |  |
| Income before income taxes | 27.6 |  |  | 14.9 |  |  | 16.1 |  |
| Income tax expense | 3.5 |  |  | 2.6 |  |  | 2.6 |  |
| Net income | 24.1 | % |  | 12.3 | % |  | 13.5 | % |

[0001045810-17-000027:mdna:67]
Revenue

[0001045810-17-000027:mdna:68]
NVIDIA’s products and services are built for three computing platforms - PC, datacenter/cloud, and mobile. For fiscal years 2017, 2016, and 2015, approximately 72%, 77%, and 75% of our revenue, respectively, was associated with the PC computing platform, of which GPUs for the gaming and professional visualization markets comprised approximately 92%, 88%, and 80%, respectively, while PC OEM represented approximately 8%, 12%, and 20%, respectively.

[0001045810-17-000027:mdna:69]
Revenue by Reportable Segments

[0001045810-17-000027:mdna:70]
|  | Year Ended |  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | $Change |  | %Change |  | January 31, 2016 |  | January 25, 2015 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| GPU | $ | 5,822 |  |  | $ | 4,187 |  |  | $ | 1,635 |  |  | 39 | % |  | $ | 4,187 |  |  | $ | 3,839 |  |  | $ | 348 |  |  | 9 | % |
| Tegra Processor | 824 |  |  | 559 |  |  | 265 |  |  | 47 | % |  | 559 |  |  | 579 |  |  | (20 | ) |  | (3 | )% |
| All Other | 264 |  |  | 264 |  |  | — |  |  | — | % |  | 264 |  |  | 264 |  |  | — |  |  | — | % |
| Total | $ | 6,910 |  |  | $ | 5,010 |  |  | $ | 1,900 |  |  | 38 | % |  | $ | 5,010 |  |  | $ | 4,682 |  |  | $ | 328 |  |  | 7 | % |

[0001045810-17-000027:mdna:71]
GPU Business. GPU business revenue increased by 39% in fiscal year 2017 compared to fiscal year 2016. This increase was due primarily to increased revenue from our GeForce GPU gaming and datacenter platforms. Sales of high-end GeForce GPU products for gaming increased over 40%, reflecting a combination of continued strength in PC gaming and strong demand for our recent Pascal-based GPU products. Datacenter revenue, including our Tesla, NVIDIA GRID, and DGX-1 brands, increased 145%, reflecting strong demand for deep learning training for AI, cloud, accelerated, and virtualized computing, and initial DGX-1 sales. Revenue from Quadro GPUs for professional visualization increased 11% due primarily to higher sales in high end desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-17-000027:mdna:72]
GPU business revenue increased by 9% in fiscal year 2016 compared to fiscal year 2015. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased over 30% reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products. Revenue from Tesla GPUs for Datacenter increased, driven by strong demand from hyperscale companies for deep learning for AI and accelerated computing. Revenue from Quadro GPUs for professional visualization declined due to weakness in the overall workstation market. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to the prior year.

[0001045810-17-000027:mdna:73]
Tegra Processor Business.  Tegra Processor business revenue increased by 47% in fiscal year 2017 compared to fiscal year 2016. This was driven by an increase of over 50% in sales of Tegra products and services serving automotive systems and an increase of almost 50% in gaming development platforms compared to last year.

[0001045810-17-000027:mdna:74]
Tegra Processor business revenue decreased by 3% in fiscal year 2016 compared to fiscal year 2015. This decrease was driven by a decline in sales of Tegra products for OEM smartphones and tablets of almost 90%, partially offset by an increase in sales of Tegra products serving automotive systems of almost 75%. Revenue also grew from development services and sales of SHIELD devices.

[0001045810-17-000027:mdna:75]
All Other. License revenue from the patent cross licensing arrangement we entered into with Intel in January 2011 was flat at $264 million for fiscal years 2017, 2016, and 2015. The remaining $44 million in revenue under this arrangement will be recognized in the first quarter of fiscal year 2018.

[0001045810-17-000027:mdna:76]
Concentration of Revenue

[0001045810-17-000027:mdna:77]
Revenue from sales to customers outside of the United States and Other Americas accounted for 80%, 79%, and 75% of total revenue for fiscal years 2017, 2016, and 2015, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-17-000027:mdna:78]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-17-000027:mdna:79]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
| Revenue: |  |  |  |  |  |
| Customer A | 12 | % |  | 11 | % |  | 11 | % |

[0001045810-17-000027:mdna:80]
Gross Profit and Gross Margin

[0001045810-17-000027:mdna:81]
Gross profit consists of total revenue, net of allowances, less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions, memory and component costs, and shipping costs. Cost of revenue also includes development costs for license and service arrangements and stock-based compensation related to personnel associated with manufacturing.

[0001045810-17-000027:mdna:82]
Our overall gross margin was 58.8%, 56.1%, and 55.5% for fiscal years 2017, 2016, and 2015, respectively. These increases were driven primarily by a higher mix of our GPU business, fewer inventory provisions, and lower warranty charges in our Tegra Processor business.

[0001045810-17-000027:mdna:83]
Charges to cost of sales for inventory provisions totaled $62 million, $112 million and $59 million for fiscal years 2017, 2016, and 2015, respectively, unfavorably impacting our gross margin by 0.9%, 2.2%, and 1.3%, respectively. Sales of inventory that was previously written-off or written-down totaled $51 million for fiscal year 2017 and $32 million for both fiscal years 2016 and 2015, favorably impacting our gross margin by 0.7%, 0.6%, and 0.7%, respectively. As a result, the overall net effect on our gross margin from inventory provisions and sales of items previously written down was an unfavorable impact of 0.2%, 1.6%, and 0.6% in fiscal years 2017, 2016, and 2015, respectively.

[0001045810-17-000027:mdna:84]
A discussion of our gross margin results for each of our reportable segments is as follows:

[0001045810-17-000027:mdna:85]
GPU Business. The gross margin of our GPU business increased during fiscal year 2017 when compared to fiscal year 2016 primarily due to product mix resulting from increased sales of our GeForce gaming, Tesla, GRID and Quadro GPU products, as well as a continued decrease in sales volumes of lower margin PC OEM products. The gross margin of our GPU business increased during fiscal year 2016 when compared to fiscal year 2015 primarily due to strong sales of our high end GeForce gaming GPU products and the decreased sales volume of lower margin PC OEM products.

[0001045810-17-000027:mdna:86]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during fiscal year 2017 when compared to fiscal year 2016, primarily due to fewer inventory provisions, and the absence of the warranty charge associated with the SHIELD tablet product recall during fiscal year 2016. The gross margin of our Tegra Processor business decreased during fiscal year 2016 when compared to fiscal year 2015 due to inventory provisions, a warranty charge associated with the SHIELD tablet product recall and higher automotive and SHIELD product sales, which have had comparably lower gross margins. The inventory provisions related primarily to older generation Tegra products, as well as inventory purchase commitments in excess of estimated demand and excess component inventories for SHIELD products.

[0001045810-17-000027:mdna:87]
Operating Expenses

[0001045810-17-000027:mdna:88]
|  | Year Ended |  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | $Change |  | %Change |  | January 31,2016 |  | January 25, 2015 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| Research and development expenses | $ | 1,463 |  |  | $ | 1,331 |  |  | $ | 132 |  |  | 10 | % |  | $ | 1,331 |  |  | $ | 1,360 |  |  | $ | (29 | ) |  | (2 | )% |
| Sales, general and administrative expenses | 663 |  |  | 602 |  |  | 61 |  |  | 10 | % |  | 602 |  |  | 480 |  |  | 122 |  |  | 25 | % |
| Restructuring and other charges | 3 |  |  | 131 |  |  | (128 | ) |  | (98 | )% |  | 131 |  |  | — |  |  | 131 |  |  | 100 | % |
| Total operating expenses | $ | 2,129 |  |  | $ | 2,064 |  |  | $ | 65 |  |  | 3 | % |  | $ | 2,064 |  |  | $ | 1,840 |  |  | $ | 224 |  |  | 12 | % |
| Research and development as a percentage of net revenue | 21.2 | % |  | 26.6 | % |  |  |  |  |  | 26.6 | % |  | 29.0 | % |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 9.6 | % |  | 12.0 | % |  |  |  |  |  | 12.0 | % |  | 10.3 | % |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | — | % |  | 2.6 | % |  |  |  |  |  | 2.6 | % |  | — | % |  |  |  |  |

[0001045810-17-000027:mdna:89]
Research and Development

[0001045810-17-000027:mdna:90]
Research and development expenses increased by 10% in fiscal year 2017 compared to fiscal year 2016, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-17-000027:mdna:91]
Research and development expenses decreased by 2% in fiscal year 2016 compared to fiscal year 2015. This decrease was primarily driven by the wind-down of Icera modem operations and other organization efficiencies, partially offset by increases in employee compensation and related costs, including stock-based compensation expense.

[0001045810-17-000027:mdna:92]
Sales, General and Administrative

[0001045810-17-000027:mdna:93]
Sales, general and administrative expenses increased by 10% in fiscal year 2017 compared to fiscal year 2016, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense. Offsetting these increases was a $57 million decrease in outside professional fees resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm during early fiscal year 2017.

[0001045810-17-000027:mdna:94]
Sales, general and administrative expenses increased by 25% in fiscal year 2016 compared to fiscal year 2015. Outside professional fees increased, primarily due to $70 million of legal fees associated with our litigation against Samsung and Qualcomm. Compensation and benefits increased by $39 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense. Advertising and promotions increased by $9 million resulting from digital advertising.

[0001045810-17-000027:mdna:95]
Restructuring and Other Charges

[0001045810-17-000027:mdna:96]
In fiscal year 2016, we began the wind down our Icera modem operations. As a result, our operating expenses for fiscal years 2017 and 2016 included $3 million and $131 million, respectively, of restructuring and other charges. Please refer to Note 17 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-17-000027:mdna:97]
Interest Income and Interest Expense

[0001045810-17-000027:mdna:98]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest expense is primarily comprised of coupon interest and debt discount amortization related to the Convertible Notes we issued in December 2013 and the Notes we issued in September 2016.

[0001045810-17-000027:mdna:99]
Interest income was $54 million, $39 million, and $28 million in fiscal years 2017, 2016, and 2015, respectively. These increases in interest income were primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-17-000027:mdna:100]
Interest expense was $58 million, $47 million, and $46 million in fiscal years 2017, 2016, and 2015. The increase in fiscal year 2017 compared to fiscal years 2016 and 2015 was due primarily to interest expense related to the Notes we issued in September 2016, partially offset by a decrease in interest expense as a result of the early conversion of a significant portion of the Convertible Notes during fiscal year 2017.

[0001045810-17-000027:mdna:101]
Other Income (Expense), Net

[0001045810-17-000027:mdna:102]
Other income (expense), net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, losses on early conversions of the Convertible Notes, and the impact of changes in foreign currency rates.

[0001045810-17-000027:mdna:103]
Net other income (expense) was $(25) million, $4 million, and $14 million in fiscal years 2017, 2016, and 2015, respectively. The net other (expense) in fiscal year 2017 compared to the net other income in fiscal year 2016 was primarily due to $21 million of losses we recognized from early conversions of the Convertible Notes. The decrease for fiscal year 2016 compared to fiscal year 2015 was primarily due to less gain recognized from sales of non-affiliated investments and more losses from foreign currency remeasurement.

[0001045810-17-000027:mdna:104]
Income Taxes

[0001045810-17-000027:mdna:105]
We recognized income tax expense of $239 million, $129 million and $124 million for fiscal years 2017, 2016, and 2015, respectively. Our annual effective tax rate was 12.5%, 17.3%, and 16.5% for fiscal years 2017, 2016, and 2015, respectively. The decrease in the effective tax rate in fiscal year 2017 as compared to fiscal years 2016 and 2015 was primarily due to the recognition of excess tax benefits from our adoption of a new accounting standard related to the simplification of certain aspects of stock-based compensation accounting. The higher effective tax rate in fiscal year 2016 as compared to fiscal years 2017 and 2015 was due to an additional amount of earnings subject to United States tax in fiscal year 2016, partially offset by a net income tax benefit related to the Icera modem restructuring in fiscal year 2016.

[0001045810-17-000027:mdna:106]
Our effective tax rate for each of the fiscal years was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate is lower than the United States federal statutory tax rate of 35%, favorable recognition in these fiscal years of the U.S. federal research tax credit, favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of the applicable statutes of limitations, and adoption of an accounting standard related to stock-based compensation in fiscal year 2017.

[0001045810-17-000027:mdna:107]
Please refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-17-000027:mdna:108]
Liquidity and Capital Resources

[0001045810-17-000027:mdna:109]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Cash and cash equivalents | $ | 1,766 |  |  | $ | 596 |  |
| Marketable securities | 5,032 |  |  | 4,441 |  |
| Cash, cash equivalents, and marketable securities | $ | 6,798 |  |  | $ | 5,037 |  |

[0001045810-17-000027:mdna:110]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,672 |  |  | $ | 1,175 |  |  | $ | 906 |  |
| Net cash used in investing activities | $ | (793 | ) |  | $ | (400 | ) |  | $ | (727 | ) |
| Net cash provided by (used in) financing activities | $ | 291 |  |  | $ | (676 | ) |  | $ | (834 | ) |

[0001045810-17-000027:mdna:111]
As of January 29, 2017, we had $6.80 billion in cash, cash equivalents and marketable securities, an increase of $1.76 billion from the end of fiscal year 2016. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions which are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types and includes certain limits on our portfolio duration.

[0001045810-17-000027:mdna:112]
Cash provided by operating activities increased in fiscal year 2017 compared to fiscal year 2016, primarily driven by an increase in net income and changes in working capital. Cash provided by operating activities increased in fiscal year 2016 compared to fiscal year 2015, primarily due to changes in working capital, partially offset by a decline in net income.

[0001045810-17-000027:mdna:113]
Cash used in investing activities increased in fiscal year 2017 compared to fiscal year 2016, primarily due to higher purchases of property and equipment and intangible assets and lower proceeds from sales and maturities of marketable securities. Cash used in investing activities for fiscal year 2016 decreased from fiscal year 2015, primarily due to higher proceeds from sales and maturities of marketable securities and lower purchases of property and equipment and intangible assets.

[0001045810-17-000027:mdna:114]
Cash was provided by financing activities in fiscal year 2017, primarily due to the $2.00 billion of Notes issued in September 2016, partially offset by $673 million of repayments of Convertible Notes and $1.00 billion of capital return to shareholders in the form of share repurchases and dividend payments. Cash was used in financing activities in fiscal year 2016, primarily due to $800 million of share repurchases and dividend payments. Cash used in financing activities decreased in fiscal year 2016 compared to fiscal year 2015, primarily due to lower share repurchases, partially offset by higher dividends.

[0001045810-17-000027:mdna:115]
38

[0001045810-17-000027:mdna:116]
Liquidity

[0001045810-17-000027:mdna:117]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of January 29, 2017 and January 31, 2016, we had $6.80 billion and $5.04 billion, respectively, in cash, cash equivalents and marketable securities. Our marketable securities consist principally of debt securities of corporations and United States government and its agencies, asset-backed securities, mortgage-backed securities issued by government-sponsored enterprises, money market funds and foreign government bonds. These investments are denominated in United States dollars. Please refer to Critical Accounting Policies and Estimates in Part II, Item 7, Quantitative and Qualitative Disclosures About Market Risk in Part II, Item 7A and Note 6 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-17-000027:mdna:118]
Our cash balances are held in numerous locations throughout the world, including substantial amounts held outside of the United States. As of January 29, 2017, we had cash, cash equivalents and marketable securities of $2.24 billion held within the United States and $4.56 billion held outside of the United States. Most of the amounts held outside the United States may be repatriated to the United States but, under current law, would be subject to U.S. federal income taxes, less applicable foreign tax credits. Further, repatriation of some foreign balances may be restricted by local laws. As of January 29, 2017, we have not provided for U.S. federal and state income taxes on approximately $3.13 billion of undistributed earnings of non-United States subsidiaries, as such earnings are considered indefinitely reinvested outside the United States. Although we have no current need to do so, if we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income tax, less applicable foreign tax credits, and reduced by the current amount of our U.S. federal and state net operating loss and tax credit carryforwards. Further, in addition to the $2.24 billion of cash, cash equivalents and marketable securities held within the United States and available to fund our U.S. operations and any other U.S. cash needs, we have access to external sources of financing if cash is needed in the United States other than by repatriation of foreign earnings where U.S. income tax may otherwise be due.  Accordingly, we do not reasonably expect any material effect on our business, as a whole, or to our financial flexibility with respect to our current cash balances held outside of the United States.

[0001045810-17-000027:mdna:119]
Capital Return to Shareholders

[0001045810-17-000027:mdna:120]
Dividend payments and share repurchases must be made from cash held in the United States. During fiscal year 2017, we repurchased a total of 15 million shares for $739 million and paid $261 million in cash dividends to our shareholders. As a result, we returned $1.00 billion to shareholders during fiscal year 2017, utilizing a significant amount of our U.S. cash balance previously taxed as of January 29, 2017.

[0001045810-17-000027:mdna:121]
For fiscal year 2018, we intend to return approximately $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. In November 2016, the Board authorized an additional $2.00 billion under our repurchase program and extended it through December 2020.

[0001045810-17-000027:mdna:122]
Our cash dividend program and the payment of future cash dividends under that program are subject to continued capital availability and our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders and are in compliance with all laws and agreements of NVIDIA applicable to the declaration and payment of cash dividends. Please refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-17-000027:mdna:123]
Convertible Notes

[0001045810-17-000027:mdna:124]
In December 2013, we issued $1.50 billion of Convertible Notes that mature on December 1, 2018 unless repurchased or converted prior to such date. The Convertible Notes first became convertible at the holders’ option beginning on the first day of fiscal year 2017. We utilized U.S. cash to settle an aggregate of $673 million in principal amount of the Convertible Notes during fiscal year 2017 and we have received additional conversion notices for an aggregate of $660 million in principal amount, $502 million of which have already settled, $103 million of which are expected to be settled in the first quarter of fiscal year 2018, and $55 million of which are expected to be settled in the second quarter of fiscal year 2018. Please refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-17-000027:mdna:125]
Notes Due 2021 and Notes Due 2026

[0001045810-17-000027:mdna:126]
On September 16, 2016, we issued $1.00 billion of the Notes Due 2021 and $1.00 billion of the Notes Due 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discounts and issuance costs. We intend to use the net proceeds from the Notes to prefund the repayment of the principal amount of early conversions of our Convertible Notes and for general corporate purposes such as dividend payments or share repurchases.

[0001045810-17-000027:mdna:127]
39

[0001045810-17-000027:mdna:128]
Revolving Credit Facility

[0001045810-17-000027:mdna:129]
On October 7, 2016, we entered into a Credit Agreement under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021, on which date all outstanding obligations would be due and payable. The Credit Agreement also permits us to obtain additional revolving loan commitments and/or commitments to issue letters of credit of up to $425 million, subject to certain conditions. As of January 29, 2017, we had not borrowed any amounts under the Credit Agreement.

[0001045810-17-000027:mdna:130]
Operating Capital and Capital Expenditure Requirements

[0001045810-17-000027:mdna:131]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating and capital expenditure requirements for at least the next twelve months.

[0001045810-17-000027:mdna:132]
Contractual Obligations

[0001045810-17-000027:mdna:133]
The following table summarizes our contractual obligations as of January 29, 2017:

[0001045810-17-000027:mdna:134]
|  | Payment Due By Period |
| Contractual Obligations | Total |  | Less than1 Year |  | 1-3 Years |  | 4-5 Years |  | More than5 Years |  | All Other |
|  | (In millions) |  |  |
| 1.00% Convertible Notes (1) | $ | 831 |  |  | $ | 831 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt (2) | 2,430 |  |  | 54 |  |  | 162 |  |  | 1,086 |  |  | 1,128 |  |  | — |  |
| Inventory purchase obligations | 1,001 |  |  | 1,001 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating leases (3) | 140 |  |  | 42 |  |  | 56 |  |  | 29 |  |  | 13 |  |  | — |  |
| Uncertain tax positions, interest and penalties (4) | 96 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 96 |  |
| Capital purchase obligations | 38 |  |  | 38 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Capital lease | 11 |  |  | 5 |  |  | 6 |  |  | — |  |  | — |  |  | — |  |
| Restructuring related obligation (5) | 13 |  |  | 13 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 4,560 |  |  | $ | 1,984 |  |  | $ | 224 |  |  | $ | 1,115 |  |  | $ | 1,141 |  |  | $ | 96 |  |

[0001045810-17-000027:mdna:135]
| (1) | Represents the aggregate principal amount of $827 million and anticipated interest payments of $4 million for the Convertible Notes. See Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K. |

[0001045810-17-000027:mdna:136]
| (2) | Represents the aggregate principal amount of $2.00 billion and anticipated interest payments of $430 million for the Notes. See Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K. |

[0001045810-17-000027:mdna:137]
| (3) | Excludes operating lease payments that we expect to make under an operating lease financing arrangement following construction of a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. The amount of the operating lease payments will be determined after the completion of construction. See the section below titled “Off-Balance Sheet Arrangements” for additional information. |

[0001045810-17-000027:mdna:138]
| (4) | Represents unrecognized tax benefits of $96 million which consists of $83 million and the related interest and penalties of $13 million recorded in non-current income tax payable as of January 29, 2017. We are unable to reasonably estimate the timing of any potential tax liability or interest/penalty payments in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. |

[0001045810-17-000027:mdna:139]
| (5) | Our operating expenses for the fiscal year 2017 included $3 million of restructuring and other charges related to the wind-down of our Icera modem operations. The $13 million represents the remaining balance of the restructuring liability as of January 29, 2017. |

[0001045810-17-000027:mdna:140]
Off-Balance Sheet Arrangements

[0001045810-17-000027:mdna:141]
We are constructing a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. The banks have committed to fund up to $380 million of costs relating to construction. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks. During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Please refer to Note 12 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion regarding our operating lease financing arrangement.

[0001045810-17-000027:mdna:142]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000027:mdna:143]
Please see Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a discussion of adoption of new and recently issued accounting pronouncements.
