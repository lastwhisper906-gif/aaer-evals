# NVDA notes — 0001045810-17-000027


## nvda:BalanceSheetComponentsTextBlock

[0001045810-17-000027:notes:1]
Balance Sheet Components

[0001045810-17-000027:notes:2]
Certain balance sheet components are as follows:

[0001045810-17-000027:notes:3]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 252 |  |  | $ | 105 |  |
| Work in-process | 176 |  |  | 103 |  |
| Finished goods | 366 |  |  | 210 |  |
| Total inventories | $ | 794 |  |  | $ | 418 |  |

[0001045810-17-000027:notes:4]
As of January 29, 2017, we had outstanding inventory purchase obligations totaling $1.00 billion.

[0001045810-17-000027:notes:5]
|  | January 29, 2017 |  | January 31, 2016 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Building | 13 |  |  | 13 |  |  | 25-30 |
| Test equipment | 427 |  |  | 354 |  |  | 3-5 |
| Computer equipment | 188 |  |  | 155 |  |  | 3-5 |
| Leasehold improvements | 176 |  |  | 174 |  |  | (B) |
| Software and licenses | 63 |  |  | 98 |  |  | 3-5 |
| Office furniture and equipment | 49 |  |  | 48 |  |  | 5 |
| Capital leases | 28 |  |  | 28 |  |  | (B) |
| Construction in process | 29 |  |  | 12 |  |  | (C) |
| Total property and equipment, gross | 1,191 |  |  | 1,100 |  |  |  |
| Accumulated depreciation and amortization | (670 | ) |  | (634 | ) |  |  |
| Total property and equipment, net | $ | 521 |  |  | $ | 466 |  |  |  |

[0001045810-17-000027:notes:6]
(A)  Land is a non-depreciable asset.

[0001045810-17-000027:notes:7]
(B)  Leasehold improvements and capital leases are amortized based on the lesser of either the asset’s estimated useful life or the remaining expected lease term.

[0001045810-17-000027:notes:8]
(C)  Construction in process represents assets that are not in service as of the balance sheet date.

[0001045810-17-000027:notes:9]
Depreciation expense for fiscal years 2017, 2016, and 2015 was $118 million, $124 million, and $143 million, respectively.

[0001045810-17-000027:notes:10]
Accumulated amortization of leasehold improvements and capital leases was $164 million and $155 million as of January 29, 2017 and January 31, 2016, respectively. Amortization of leasehold improvements and capital leases is included in depreciation and amortization expense.

[0001045810-17-000027:notes:11]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Accrued Liabilities: |  |  |  |
| Customer related liabilities (1) | $ | 197 |  |  | $ | 160 |  |
| Accrued payroll and related expenses | 137 |  |  | 79 |  |
| Deferred revenue (2) | 85 |  |  | 322 |  |
| Coupon interest on debt obligations | 21 |  |  | 3 |  |
| Accrued restructuring and other charges (3) | 13 |  |  | 23 |  |
| Professional service fees | 13 |  |  | 23 |  |
| Warranty accrual (4) | 8 |  |  | 11 |  |
| Accrued royalties | 7 |  |  | 1 |  |
| Leases payable | 4 |  |  | 4 |  |
| Taxes payable | 4 |  |  | 2 |  |
| Contributions payable | 4 |  |  | 3 |  |
| Other | 14 |  |  | 11 |  |
| Total accrued and other current liabilities | $ | 507 |  |  | $ | 642 |  |

[0001045810-17-000027:notes:12]
(1)  Customer related liabilities primarily includes accrued rebates and marketing development funds.

[0001045810-17-000027:notes:13]
| (2) | Deferred revenue under our patent cross licensing agreement with Intel Corporation will expire in March 2017. We will be recognizing revenue under this agreement through the first quarter of fiscal year 2018. |

[0001045810-17-000027:notes:14]
(3)  Please refer to Note 17 of these Notes to the Consolidated Financial Statements for a discussion regarding restructuring and other charges.

[0001045810-17-000027:notes:15]
(4)  Please refer to Note 10 of these Notes to the Consolidated Financial Statements for a discussion regarding warranties.

[0001045810-17-000027:notes:16]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Other Long Term Liabilities: |  |  |  |
| Deferred income tax liability (1) | $ | 141 |  |  | $ | 301 |  |
| Income tax payable | 96 |  |  | 78 |  |
| Contributions payable | 10 |  |  | 13 |  |
| Deferred revenue (2) | 4 |  |  | 44 |  |
| Other | 20 |  |  | 17 |  |
| Total other long-term liabilities | $ | 271 |  |  | $ | 453 |  |

[0001045810-17-000027:notes:17]
(1)  Please refer to the “Recently Adopted Accounting Pronouncement” section of Note 1 of these Notes to the Consolidated Financial Statements for a discussion regarding the impact of a recently adopted accounting pronouncement related to stock-based compensation.

[0001045810-17-000027:notes:18]
(2)  Deferred revenue under our patent cross licensing agreement with Intel Corporation is now located in short term deferred revenue as less than twelve months remains on the agreement.


## nvda:ScheduleofRevenuebyMarketsTableTextBlock

[0001045810-17-000027:notes:19]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
| Revenue: | (In millions) |
| Gaming | $ | 4,060 |  |  | $ | 2,818 |  |  | $ | 2,058 |  |
| Professional Visualization | 835 |  |  | 750 |  |  | 795 |  |
| Datacenter | 830 |  |  | 339 |  |  | 317 |  |
| Automotive | 487 |  |  | 320 |  |  | 183 |  |
| OEM & IP | 698 |  |  | 783 |  |  | 1,329 |  |
| Total revenue | $ | 6,910 |  |  | $ | 5,010 |  |  | $ | 4,682 |  |


## nvda:ScheduleofaccountsreceivablepercentagesfromsignificantcustomerstextblockTableTextBlock

[0001045810-17-000027:notes:20]
|  | January 29, 2017 |  | January 31, 2016 |
| Accounts Receivable: |  |  |  |
| Customer B | 19 | % |  | 21 | % |
| Customer C | 10 | % |  | 7 | % |


## nvda:SummaryofequityawardsgrantedunderequityincentiveplansTableTextBlock

[0001045810-17-000027:notes:21]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 12 |  |  | 13 |  |  | 13 |  |
| Estimated total grant-date fair value | $ | 591 |  |  | $ | 296 |  |  | $ | 228 |  |
| Weighted average grant-date fair value (per share) | $ | 50.57 |  |  | $ | 22.01 |  |  | $ | 17.68 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 4 |  |  | 6 |  |  | 7 |  |
| Weighted average price (per share) | $ | 18.51 |  |  | $ | 13.67 |  |  | $ | 10.99 |  |
| Weighted average grant-date fair value (per share) | $ | 5.80 |  |  | $ | 4.53 |  |  | $ | 4.99 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-17-000027:notes:22]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 627 |  |  | $ | 381 |  |
| Estimated weighted average remaining amortization period | (In years) |
| Stock options | 0.5 |  |  | 1.1 |  |
| RSUs, PSUs and market-based PSUs | 2.6 |  |  | 2.7 |  |
| ESPP | 0.6 |  |  | 0.7 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001045810-17-000027:notes:23]
Advertising Expenses

[0001045810-17-000027:notes:24]
We expense advertising costs in the period in which they are incurred. Advertising expenses for fiscal years 2017, 2016, and 2015 were $17 million, $30 million, and $21 million, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-17-000027:notes:25]
|  | January 29, 2017 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,397 |  |  | $ | 1 |  |  | $ | (10 | ) |  | $ | 2,388 |  |
| Debt securities of United States government agencies | 1,193 |  |  | — |  |  | (5 | ) |  | 1,188 |  |
| Debt securities issued by the United States Treasury | 852 |  |  | — |  |  | (2 | ) |  | 850 |  |
| Asset-backed securities | 490 |  |  | — |  |  | (1 | ) |  | 489 |  |
| Money market funds | 321 |  |  | — |  |  | — |  |  | 321 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 161 |  |  | 2 |  |  | (1 | ) |  | 162 |  |
| Foreign government bonds | 70 |  |  | — |  |  | — |  |  | 70 |  |
| Total | $ | 5,484 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 5,468 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 436 |  |
| Marketable securities |  |  |  |  |  |  | 5,032 |  |
| Total |  |  |  |  |  |  | $ | 5,468 |  |

[0001045810-17-000027:notes:26]
|  | January 31, 2016 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,903 |  |  | $ | 1 |  |  | $ | (3 | ) |  | $ | 1,901 |  |
| Debt securities of United States government agencies | 1,170 |  |  | 1 |  |  | (1 | ) |  | 1,170 |  |
| Debt securities issued by the United States Treasury | 800 |  |  | 1 |  |  | — |  |  | 801 |  |
| Asset-backed securities | 435 |  |  | — |  |  | — |  |  | 435 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 229 |  |  | 3 |  |  | (1 | ) |  | 231 |  |
| Foreign government bonds | 92 |  |  | — |  |  | — |  |  | 92 |  |
| Money market funds | 43 |  |  | — |  |  | — |  |  | 43 |  |
| Total | $ | 4,672 |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | 4,673 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 232 |  |
| Marketable securities |  |  |  |  |  |  | 4,441 |  |
| Total |  |  |  |  |  |  | $ | 4,673 |  |

[0001045810-17-000027:notes:27]
The following table provides the breakdown of the investments with unrealized losses as of January 29, 2017:

[0001045810-17-000027:notes:28]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 1,721 |  |  | $ | (10 | ) |  | $ | 55 |  |  | $ | — |  |  | $ | 1,776 |  |  | $ | (10 | ) |
| Debt securities issued by United States government agencies | 906 |  |  | (5 | ) |  | 28 |  |  | — |  |  | 934 |  |  | (5 | ) |
| Debt securities issued by the US Treasury | 629 |  |  | (2 | ) |  | — |  |  | — |  |  | 629 |  |  | (2 | ) |
| Mortgage backed securities issued by United States government-sponsored enterprises | 43 |  |  | — |  |  | 35 |  |  | (1 | ) |  | 78 |  |  | (1 | ) |
| Asset-backed securities | 383 |  |  | (1 | ) |  | 3 |  |  | — |  |  | 386 |  |  | (1 | ) |
| Total | $ | 3,682 |  |  | $ | (18 | ) |  | $ | 121 |  |  | $ | (1 | ) |  | $ | 3,803 |  |  | $ | (19 | ) |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001045810-17-000027:notes:29]
Cash and Cash Equivalents

[0001045810-17-000027:notes:30]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. As of January 29, 2017 and January 31, 2016, our cash and cash equivalents were $1.77 billion and $596 million, respectively, including $321 million and $43 million, respectively, invested in money market funds.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-17-000027:notes:31]
Commitments and Contingencies

[0001045810-17-000027:notes:32]
Inventory Purchase Obligations

[0001045810-17-000027:notes:33]
Capital Purchase Obligations

[0001045810-17-000027:notes:34]
As of January 29, 2017, we had outstanding capital purchase obligations totaling $38 million.

[0001045810-17-000027:notes:35]
Lease Obligations

[0001045810-17-000027:notes:36]
Our headquarters complex is located in Santa Clara, California and includes eight buildings that are leased properties. Future minimum lease payments related to headquarters operating leases total $50 million over the remaining terms of the leases, including predetermined rent escalations, and are included in the future minimum lease payment schedule below.

[0001045810-17-000027:notes:37]
In addition to the commitment of our headquarters, we have other domestic and international office facilities under operating leases expiring through fiscal year 2026. We also include non-cancelable obligations under certain software licensing arrangements as operating leases.

[0001045810-17-000027:notes:38]
Future minimum lease payments under our non-cancelable operating leases as of January 29, 2017, are as follows:

[0001045810-17-000027:notes:39]
|  | Future Minimum Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2018 | $ | 42 |  |
| 2019 | 36 |  |
| 2020 | 20 |  |
| 2021 | 17 |  |
| 2022 | 12 |  |
| 2023 and thereafter | 13 |  |
| Total | $ | 140 |  |

[0001045810-17-000027:notes:40]
Rent expense for fiscal years 2017, 2016, and 2015 was $46 million, $45 million, and $47 million, respectively.

[0001045810-17-000027:notes:41]
Capital lease obligations include building and office equipment lease obligations. The building lease relates to our datacenter in Santa Clara, California. Future minimum lease payments under the building capital lease total $11 million over the remaining lease term, including predetermined rent escalations, and are included in the future minimum lease payment schedule below:

[0001045810-17-000027:notes:42]
|  | Future Capital Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |  |
| 2018 | $ | 5 |  |
| 2019 | 6 |  |
| Total | $ | 11 |  |
| Present value of minimum lease payments | $ | 10 |  |
| Current portion | $ | 4 |  |
| Long-term portion | $ | 6 |  |

[0001045810-17-000027:notes:43]
Operating Lease Financing Arrangement

[0001045810-17-000027:notes:44]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-17-000027:notes:45]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-17-000027:notes:46]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-17-000027:notes:47]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-17-000027:notes:48]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.5 to 1.0. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-17-000027:notes:49]
Litigation

[0001045810-17-000027:notes:50]
Qualcomm, Inc. and various Samsung Entities

[0001045810-17-000027:notes:51]
In September 2014, NVIDIA filed complaints against Qualcomm, Inc. and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing. In November 2014, Samsung filed complaints against NVIDIA in the ITC and the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed certain patents.

[0001045810-17-000027:notes:52]
NVIDIA and Samsung, and NVIDIA and Qualcomm, also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office.

[0001045810-17-000027:notes:53]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941. On June 16, 2016, the ITC granted the joint motion and terminated the ITC investigation. The parties have also moved to dismiss all pending inter partes reviews. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party. On June 28, 2016, NVIDIA and Samsung executed a settlement agreement based on the April 28, 2016 memorandum of understanding.

[0001045810-17-000027:notes:54]
NVIDIA’s dismissals on May 11, 2016 and May 12, 2016 also terminated its claims against Qualcomm.

[0001045810-17-000027:notes:55]
Advanced Silicon Technologies LLC

[0001045810-17-000027:notes:56]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. On June 1, 2016, the ITC issued a Notice determining not to review the Administrative Law Judge’s determination, thereby finalizing termination of the investigation as to NVIDIA. Pursuant to the license agreement, $10 million was recorded as a charge to cost of revenue during fiscal year 2017.

[0001045810-17-000027:notes:57]
Polaris Innovations Limited

[0001045810-17-000027:notes:58]
On May 16, 2016, Polaris Innovations Limited filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe on six of its U.S. patents related generally to control of DRAM memory. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA.

[0001045810-17-000027:notes:59]
On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents. On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and transferred the case to the Northern District of California. An initial scheduling conference has been set for March 16, 2017. A trial date has not yet been set.

[0001045810-17-000027:notes:60]
On December 7, 2016, NVIDIA filed an inter partes review request with the United States Patent and Trademark Office, or USPTO, challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. An institution decision is expected in both of these matters in June 2017. If instituted, the USPTO will conduct a trial on the validity of each of these patents.

[0001045810-17-000027:notes:61]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. NVIDIA has retained counsel in Germany to defend this case. A trial date has not yet been set.

[0001045810-17-000027:notes:62]
Accounting for Loss Contingencies

[0001045810-17-000027:notes:63]
While there can be no assurance of favorable outcomes, we believe the claims made by other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of January 29, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001045810-17-000027:notes:64]
Product Warranties

[0001045810-17-000027:notes:65]
We generally offer limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001045810-17-000027:notes:66]
Stock-based Compensation

[0001045810-17-000027:notes:67]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for stock options, RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, we estimate forfeitures annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. If factors change, the compensation expense that we record under these accounting standards may differ significantly from what we have recorded in the current period.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001045810-17-000027:notes:68]
Comprehensive Income

[0001045810-17-000027:notes:69]
Comprehensive income consists of net income and other comprehensive income (loss). Other comprehensive income (loss) components include unrealized gains (losses) on available-for-sale securities and unrealized gains (losses) on cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-17-000027:notes:70]
Principles of Consolidation

[0001045810-17-000027:notes:71]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-17-000027:notes:72]
The following table presents the carrying value of the liability of the Convertible Notes:

[0001045810-17-000027:notes:73]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 827 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (31 | ) |  | (87 | ) |
| Net carrying amount | $ | 796 |  |  | $ | 1,413 |  |

[0001045810-17-000027:notes:74]
(1) As of January 29, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.8 years.

[0001045810-17-000027:notes:75]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

[0001045810-17-000027:notes:76]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Contractual coupon interest expense | $ | 9 |  |  | $ | 15 |  |  | $ | 15 |  |
| Amortization of debt discount | 24 |  |  | 29 |  |  | 28 |  |
| Total interest expense related to Convertible Notes | $ | 33 |  |  | $ | 44 |  |  | $ | 43 |  |


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001045810-17-000027:notes:77]
Restructuring and Other Charges

[0001045810-17-000027:notes:78]
Our restructuring and other charges include employee severance and related costs, the write-down of assets, and other exit costs. The severance and related costs include one-time termination benefits as well as certain statutory termination benefits or employee terminations under ongoing benefit arrangements. One-time termination benefits are recognized as a liability at estimated fair value when the approved plan of termination has been communicated to employees, unless employees must provide future service, in which case the benefits are recognized ratably over the future service period. Ongoing termination benefits arrangements are recognized as a liability at estimated fair value when the amount of such benefits becomes estimable and payment is probable. Any contract termination costs are recognized at estimated fair value when we terminate the contract in accordance with the contract terms. Other associated costs are recognized in the period the liability is incurred.


## us-gaap:DebtDisclosureTextBlock

[0001045810-17-000027:notes:79]
Debt

[0001045810-17-000027:notes:80]
Convertible Debt

[0001045810-17-000027:notes:81]
1.00 % Convertible Senior Notes Due 2018

[0001045810-17-000027:notes:82]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. The Convertible Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Convertible Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. Upon conversion, we will pay cash up to the aggregate principal amount of the Convertible Notes and may pay or deliver cash, shares of our common stock or a combination thereof, at our election, of our conversion obligation in excess of the aggregate principal amount of the Convertible Notes being converted. As of January 29, 2017, the conversion rate, after adjusting for dividend increases, was 49.8351 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0662 per share of common stock).

[0001045810-17-000027:notes:83]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continued to be convertible at the holders’ option through April 30, 2017.

[0001045810-17-000027:notes:84]
During fiscal year 2017, we paid cash to settle an aggregate of $673 million in principal amount of the Convertible Notes and have $827 million in principal amount outstanding as of January 29, 2017. We issued 23 million shares of our common stock for the excess conversion value, and recognized a loss of $21 million on early conversions, of the Convertible Notes. Based on the closing price of our common stock of $111.77 on the last trading day of fiscal year 2017, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $3.78 billion.

[0001045810-17-000027:notes:85]
Subsequent to January 29, 2017, we have settled an additional $502 million in principal amount of Convertible Notes and issued 20 million additional shares of our common stock for the excess conversion value. Based on additional conversion requests we have received, we expect to settle an additional $103 million in principal amount of Convertible Notes and issue additional shares of our common stock for the excess conversion value during the remainder of the first quarter of fiscal year 2018 and to settle another additional $55 million in principal amount of Convertible Notes and issue additional shares of our common stock for the excess conversion value during the second quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

[0001045810-17-000027:notes:86]
We separately accounted for the liability and equity components of the Convertible Notes at issuance, since our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

[0001045810-17-000027:notes:87]
As of January 29, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Consolidated Balance Sheet.

[0001045810-17-000027:notes:88]
Note Hedges and Warrants

[0001045810-17-000027:notes:89]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges. The Note Hedges have an adjusted strike price of $20.0662 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through January 29, 2017, we had received 23 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $673 million in principal amount of the Convertible Notes. Subsequently, we have received 20 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of an additional $502 million in principal amount, and we expect to receive additional shares of our common stock related to an additional $103 million in principal amount that is expected to settle during the first quarter of fiscal year 2018 and at least $55 million in principal amount that is expected to settle during the second quarter of fiscal year 2018.

[0001045810-17-000027:notes:90]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an adjusted strike price of $27.0122 per share. On December 12, 2016, we entered into an agreement with a counterparty bank to terminate 63 million of the 75 million warrants outstanding. In consideration for the termination of these warrants, we delivered a total of 48 million shares of common stock to the counterparty bank, the amount of which was determined each day based on the daily volume-weighted average price of the common stock during an observation period beginning December 13, 2016 and ending January 31, 2017. As of January 29, 2017, 44 million of the 48 million shares of our common stock had been issued related to the terminated Warrants. The remaining 4 million shares were issued in the beginning of fiscal year 2018.

[0001045810-17-000027:notes:91]
Long-Term Debt

[0001045810-17-000027:notes:92]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-17-000027:notes:93]
On September 16, 2016, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026 (collectively, the Notes). Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-17-000027:notes:94]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-17-000027:notes:95]
The carrying value of our long-term debt and the associated interest rates were as follows:

[0001045810-17-000027:notes:96]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.6 |  | 2.38% |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.6 |  | 3.31% |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,983 |  |

[0001045810-17-000027:notes:97]
Revolving Credit Facility

[0001045810-17-000027:notes:98]
On October 7, 2016, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021, on which all outstanding obligations would be due and payable. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of January 29, 2017, we had not borrowed any amounts under the Credit Agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-17-000027:notes:99]
Derivative Financial Instruments

[0001045810-17-000027:notes:100]
In fiscal year 2016, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building that entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments. This interest rate swap is designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are recorded in accumulated other comprehensive income (loss) and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur.

[0001045810-17-000027:notes:101]
In fiscal year 2017, we entered into foreign currency forward contracts with a total U.S. dollar equivalent notional value of $227 million to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income (loss) and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts as of January 29, 2017 was not significant. We also entered into foreign currency forward contracts with a total U.S. dollar equivalent notional value of $99 million to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than our reporting currency. These foreign currency forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded as a component of other income (expense), net, and offsets the change in fair value of the foreign currency denominated monetary assets and liabilities, which is also recorded in other income (expense), net.

[0001045810-17-000027:notes:102]
Under the master netting agreements with the respective counterparties to our foreign currency forward contracts, we are allowed to net settle transactions with the same counterparty, subject to applicable requirements. However, we present our derivative assets and liabilities at their gross fair values on our Consolidated Balance Sheets. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments.

[0001045810-17-000027:notes:103]
As of January 29, 2017, the maturities of the designated foreign currency forward contracts were three months or less.

[0001045810-17-000027:notes:104]
We formally assess, both at inception and on an ongoing basis, whether derivative financial instruments designated for hedge accounting treatment are highly effective. During fiscal year 2017, all derivative financial instruments designated for hedge accounting treatment were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-17-000027:notes:105]
For fiscal years 2017 and 2016, we recognized a net change in unrealized gains (losses) on derivative financial instruments designated for hedge accounting treatment of $4 million and $(4) million, respectively, net of tax, in other comprehensive income (loss).

[0001045810-17-000027:notes:106]
We expect to realize all gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months. However, we do not expect to reclassify any amount from accumulated other comprehensive income (loss) into earnings related to the interest rate swap as the underlying operating lease financing payments for our new headquarters building will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-17-000027:notes:107]
Stock-Based Compensation

[0001045810-17-000027:notes:108]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-17-000027:notes:109]
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts capitalized as inventory, as follows:

[0001045810-17-000027:notes:110]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Cost of revenue | $ | 15 |  |  | $ | 15 |  |  | $ | 12 |  |
| Research and development | 134 |  |  | 115 |  |  | 88 |  |
| Sales, general and administrative | 98 |  |  | 74 |  |  | 58 |  |
| Total | $ | 247 |  |  | $ | 204 |  |  | $ | 158 |  |

[0001045810-17-000027:notes:111]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2017, 2016, and 2015.

[0001045810-17-000027:notes:112]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-17-000027:notes:113]
Beginning fiscal year 2015, we shifted away from granting stock options and toward granting RSUs, PSUs and market-based PSUs to reflect changing market trends for equity incentives at our peer companies. The number of PSUs that will ultimately vest is contingent on the Company’s level of achievement versus the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year.

[0001045810-17-000027:notes:114]
Of the total fair value of equity awards, we estimated that the stock-based compensation expense related to the equity awards that are not expected to vest for fiscal years 2017, 2016, and 2015 was $98 million, $46 million, and $37 million, respectively.

[0001045810-17-000027:notes:115]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-17-000027:notes:116]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.5-2.0 |  | 0.5-2.0 |  | 0.5-2.0 |
| Risk-free interest rate | 0.5%-0.9% |  | 0.1%-0.7% |  | 0.1%-0.5% |
| Volatility | 30%-39% |  | 24%-34% |  | 23%-31% |
| Dividend yield | 0.7%-1.4% |  | 1.5%-1.8% |  | 1.7%-1.9% |

[0001045810-17-000027:notes:117]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-17-000027:notes:118]
Additionally, for employee stock option, RSU, PSU, and market-based PSU awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-17-000027:notes:119]
Equity Incentive Program

[0001045810-17-000027:notes:120]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans.

[0001045810-17-000027:notes:121]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-17-000027:notes:122]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, which was subsequently amended and restated, most recently in 2016, or the 2007 Plan.

[0001045810-17-000027:notes:123]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock unit, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. Up to 207 million shares of our common stock may be issued pursuant to stock awards granted under the 2007 Plan. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 29, 2017, there were 22 million shares available for future issuance.

[0001045810-17-000027:notes:124]
Stock options previously granted to employees, subject to certain exceptions, vest over a four year period, subject to continued service, with 25% vesting on the anniversary of the hire date in the case of new hires or the anniversary of the date of grant in the case of grants to existing employees and 6.25% vesting at the end of each quarterly period thereafter. Stock options previously granted under the 2007 Plan generally expire ten years from the date of grant.

[0001045810-17-000027:notes:125]
Subject to certain exceptions, RSUs granted to employees vest over a four year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and (i) for grants made prior to May 18, 2016, 12.5% vesting semi-annually thereafter until fully vested, and (ii) for grants made on or after May 18, 2016, 6.25% vesting quarterly thereafter until fully vested.

[0001045810-17-000027:notes:126]
PSUs vest over a four year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 12.5% vesting semi-annually thereafter until fully vested. Market-based PSUs vest 100% on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-17-000027:notes:127]
Unless terminated sooner, the 2007 Plan is scheduled to terminate on March 21, 2022. Our Board may suspend or terminate the 2007 Plan at any time. No awards may be granted under the 2007 Plan while the 2007 Plan is suspended or after it is terminated. The Board may also amend the 2007 Plan at any time. However, if legal, regulatory or listing requirements require shareholder approval, the amendment will not go into effect until the shareholders have approved the amendment.

[0001045810-17-000027:notes:128]
2012 Employee Stock Purchase Plan

[0001045810-17-000027:notes:129]
In 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, which was subsequently amended and restated, most recently in 2016, or the 2012 Plan, as the successor to the 1998 Employee Stock Purchase Plan.

[0001045810-17-000027:notes:130]
Up to 75 million shares of our common stock may be issued pursuant to purchases under the 2012 Plan. As of January 29, 2017, we had issued 23 million shares and reserved 52 million shares for future issuance under the 2012 Plan.

[0001045810-17-000027:notes:131]
The 2012 Plan is intended to qualify as an “employee stock purchase plan” under Section 423 of the Internal Revenue Code. Under the current offerings adopted pursuant to the 2012 Plan, each offering period is 24 months, which is divided into four purchase periods of six months.

[0001045810-17-000027:notes:132]
Employees are eligible to participate if they are employed by us or an affiliate of us as designated by the Board. Employees who participate in an offering may have up to 10% of their earnings withheld up to certain limitations and applied on specified dates determined by the Board to the purchase of shares of common stock. The Board may increase this percentage at its discretion, up to 15%. The price of common stock purchased under our ESPP will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the fair market value on each purchase date within the offering. Employees may end their participation in the ESPP at any time during the offering period, and participation ends automatically on termination of employment with us. In each case, the employee’s contributions are refunded.

[0001045810-17-000027:notes:133]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-17-000027:notes:134]
|  | RSUs, PSUs and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number ofShares |  | WeightedAverageGrant-DateFair Value |  | Number ofShares |  | Weighted Average Exercise PricePer Share |  | WeightedAverageRemaining Contractual Life |  | Aggregate IntrinsicValue (3) |
|  | (In millions, except years and per share data) |
| Balances, January 31, 2016 | 26 |  |  | $ | 19.12 |  |  | 13 |  |  | $ | 14.49 |  |  |  |  |  |
| Granted (1)(2) | 12 |  |  | $ | 50.57 |  |  | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  | (6 | ) |  | $ | 14.52 |  |  |  |  |  |
| Vested restricted stock | (10 | ) |  | $ | 17.93 |  |  | — |  |  | — |  |  |  |  |  |
| Canceled and forfeited | (1 | ) |  | $ | 23.68 |  |  | — |  |  | — |  |  |  |  |  |
| Balances, January 29, 2017 | 27 |  |  | $ | 32.84 |  |  | 7 |  |  | $ | 14.47 |  |  | 5.4 |  | $ | 724 |  |
| Exercisable as of January 29, 2017 |  |  |  |  | 7 |  |  | $ | 14.39 |  |  | 5.3 |  | $ | 667 |  |
| Vested and expected to vest after January 29, 2017 | 23 |  |  | $ | 32.74 |  |  | 7 |  |  | $ | 14.46 |  |  | 5.4 |  | $ | 715 |  |

[0001045810-17-000027:notes:135]
| (1) | Includes PSUs that will be issued and eligible to vest based on the corporate financial performance maximum target level achieved for fiscal year 2017. |

[0001045810-17-000027:notes:136]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs issued could range from 0 to 0.3 million shares. |

[0001045810-17-000027:notes:137]
| (3) | The aggregate intrinsic value in the table above represents the total pre-tax intrinsic value for in-the-money options at January 29, 2017, based on the $111.77 closing price of our common stock on January 27, 2017. |

[0001045810-17-000027:notes:138]
As of January 29, 2017 and January 31, 2016, there were 22 million and 14 million shares, respectively, of common stock reserved for future issuance under our equity incentive plans.

[0001045810-17-000027:notes:139]
The total intrinsic value of options exercised was $246 million, $75 million, and $62 million for fiscal years 2017, 2016, and 2015, respectively. Upon exercise of an option, we issue new shares of stock. The total fair value of options vested was $8 million, $17 million, and $33 million for fiscal years 2017, 2016, and 2015, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001045810-17-000027:notes:140]
Net Income Per Share

[0001045810-17-000027:notes:141]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to the Consolidated Financial Statements. The potentially dilutive shares resulting from the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted income per share when their inclusion is dilutive. However, unless actually exercised, the note hedges will not be included in the calculation of diluted net income per share, as their pre-exercised effect would be anti-dilutive under the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001045810-17-000027:notes:142]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income per share computations for the periods presented:

[0001045810-17-000027:notes:143]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 1,666 |  |  | $ | 614 |  |  | $ | 631 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 541 |  |  | 543 |  |  | 552 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |
| Equity awards | 26 |  |  | 13 |  |  | 11 |  |
| 1.00% Convertible Senior Notes | 44 |  |  | 13 |  |  | — |  |
| Warrants issued with the 1.00% Convertible Senior Notes | 38 |  |  | — |  |  | — |  |
| Diluted weighted average shares | 649 |  |  | 569 |  |  | 563 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 3.08 |  |  | $ | 1.13 |  |  | $ | 1.14 |  |
| Diluted (2) | $ | 2.57 |  |  | $ | 1.08 |  |  | $ | 1.12 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 8 |  |  | 10 |  |  | 12 |  |

[0001045810-17-000027:notes:144]
| (1) | Calculated as net income divided by basic weighted average shares. |

[0001045810-17-000027:notes:145]
| (2) | Calculated as net income divided by diluted weighted average shares. |

[0001045810-17-000027:notes:146]
The 1.00% Convertible Senior Notes, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0662 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share. The Warrants have a dilutive impact on net income per share if our average stock price for the quarter exceeds the adjusted strike price of $27.0122 per share. For fiscal year 2017, our average stock price was $59.30, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Convertible Notes and the Warrants to have a dilutive impact.

[0001045810-17-000027:notes:147]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transactions, or the Note Hedges, that we entered into concurrently with the issuance of the Convertible Notes, as its effect would be anti-dilutive. In the event of conversion of the Convertible Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Convertible Notes.

[0001045810-17-000027:notes:148]
On December 12, 2016, we entered into an agreement with a counterparty bank to terminate 63 million of the 75 million Warrants outstanding. In consideration for the termination of these Warrants, we delivered a total of 48 million shares of common stock to the counterparty bank, the amount of which was determined each day based on the daily volume-weighted average price of the common stock during an observation period beginning December 13, 2016 and ending January 31, 2017. As of January 29, 2017, 44 million of the 48 million shares of our common stock had been issued related to the terminated Warrants. The remaining 4 million shares were issued in the beginning of fiscal year 2018.

[0001045810-17-000027:notes:149]
Please refer to Note 11 of these Notes to the Consolidated Financial Statements for additional discussion regarding the Convertible Notes, Note Hedges, and Warrants.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-17-000027:notes:150]
Fair Value of Financial Assets and Liabilities

[0001045810-17-000027:notes:151]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. There were no significant transfers between Levels 1 and 2 assets for fiscal year 2017. Level 3 assets are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances. Most of our cash equivalents and marketable securities are valued based on Level 2 inputs. We did not have any investments classified as Level 3 as of January 29, 2017.

[0001045810-17-000027:notes:152]
|  |  | Fair Value at |
|  | Pricing Category |  | January 29, 2017 |  | January 31, 2016 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Corporate debt securities (1) | Level 2 |  | $ | 2,388 |  |  | $ | 1,901 |  |
| Debt securities of U.S. government agencies (2) | Level 2 |  | $ | 1,188 |  |  | $ | 1,170 |  |
| Debt securities issued by the United States Treasury (3) | Level 2 |  | $ | 850 |  |  | $ | 801 |  |
| Asset-backed securities (4) | Level 2 |  | $ | 489 |  |  | $ | 435 |  |
| Money market funds (5) | Level 1 |  | $ | 321 |  |  | $ | 43 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises (4) | Level 2 |  | $ | 162 |  |  | $ | 231 |  |
| Foreign government bonds (4) | Level 2 |  | $ | 70 |  |  | $ | 92 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (6) | Level 2 |  | $ | 4,474 |  |  | $ | 2,273 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (6) | Level 2 |  | $ | 975 |  |  | $ | — |  |
| 3.20% Notes Due 2026 (6) | Level 2 |  | $ | 961 |  |  | $ | — |  |
| Interest rate swap (7) | Level 2 |  | $ | 2 |  |  | $ | 7 |  |

[0001045810-17-000027:notes:153]
| (1) | Included $33 million and $51 million in cash equivalents as of January 29, 2017 and January 31, 2016, respectively, and $2.35 billion and $1.85 billion in marketable securities as of January 29, 2017 and January 31, 2016, respectively, on the Consolidated Balance Sheets. |

[0001045810-17-000027:notes:154]
| (2) | Included $27 million and $90 million in cash equivalents as of January 29, 2017 and January 31, 2016, respectively, and $1.16 billion and $1.08 billion in marketable securities as of January 29, 2017 and January 31, 2016, respectively, on the Consolidated Balance Sheets. |

[0001045810-17-000027:notes:155]
| (3) | Included $55 million in cash equivalents as of January 29, 2017 and $795 million and $801 million in marketable securities as of January 29, 2017 and January 31, 2016, respectively, on the Consolidated Balance Sheets. |

[0001045810-17-000027:notes:156]
| (4) | Reported in marketable securities on the Consolidated Balance Sheets. |

[0001045810-17-000027:notes:157]
| (5) | Reported in cash equivalents on the Consolidated Balance Sheets. |

[0001045810-17-000027:notes:158]
| (6) | The 1.00% Convertible Notes, 2.20% Notes Due 2021, and 3.20% Notes Due 2026 are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. See Note 11 of these Notes to the Consolidated Financial Statements for additional information. |

[0001045810-17-000027:notes:159]
| (7) | Please refer to Note 9 of these Notes to Consolidated Financial Statements for a discussion regarding our interest rate swap. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001045810-17-000027:notes:160]
Foreign Currency Remeasurement

[0001045810-17-000027:notes:161]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in “Other income (expense), net” in our Consolidated Statements of Income and to date have not been significant.

[0001045810-17-000027:notes:162]
The impact of gain or loss from foreign currency remeasurement included in determining other income (expense), net, was a $5 million loss for fiscal year 2017 and was not significant for fiscal years 2016 and 2015.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001045810-17-000027:notes:163]
Goodwill

[0001045810-17-000027:notes:164]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist.  For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-17-000027:notes:165]
For those reporting units where a significant change or event has occurred, where potential impairment indicators exist, or for which we have not performed a quantitative assessment recently, we utilize a two-step quantitative assessment to testing goodwill for impairment. The first step tests for possible impairment by applying a fair value-based test by weighting the results from the income approach and the market approach. The second step, if necessary, measures the amount of such impairment by applying fair value-based tests to individual assets and liabilities. Please refer to Note 4 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-17-000027:notes:166]
The carrying amount of goodwill is from the following acquisitions:

[0001045810-17-000027:notes:167]
|  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Icera | $ | 271 |  |  | $ | 271 |  |
| PortalPlayer | 105 |  |  | 105 |  |
| Mental Images | 59 |  |  | 59 |  |
| 3dfx | 50 |  |  | 50 |  |
| MediaQ | 35 |  |  | 35 |  |
| ULi | 31 |  |  | 31 |  |
| Hybrid Graphics | 28 |  |  | 28 |  |
| Ageia | 19 |  |  | 19 |  |
| Portland Group Inc. | 2 |  |  | 2 |  |
| Other | 18 |  |  | 18 |  |
| Total goodwill | $ | 618 |  |  | $ | 618 |  |

[0001045810-17-000027:notes:168]
The amount of goodwill allocated to our GPU and Tegra Processor reportable segments was $210 million and $408 million, respectively, as of both January 29, 2017 and January 31, 2016. Please refer to Note 16 of these Notes to the Consolidated Financial Statements for further discussion regarding segments.

[0001045810-17-000027:notes:169]
We utilized a two-step quantitative analysis to complete our annual impairment test during the fourth quarter of fiscal year 2017 and concluded that there was no impairment, as the fair value of our reporting units exceeded their carrying values. The first step tests for possible impairment by applying a fair value-based test by weighing the results from the income approach and the market approach. The second step, if necessary, measures the amount of such impairment by applying fair value-based tests to individual assets and liabilities.

[0001045810-17-000027:notes:170]
These income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business. When performing an income approach valuation, we incorporate the use of projected financial information and a discount rate that are developed using market participant based assumptions to our discounted cash flow model. Our estimates of discounted cash flow were based upon, among other things, certain assumptions about our expected future operating performance, such as revenue growth rates, operating margins, risk-adjusted discount rates, and future economic and market conditions. The market method of determining the fair value of our reporting units requires us to use judgment in the selection of appropriate market comparables.


## us-gaap:GuaranteesTextBlock

[0001045810-17-000027:notes:171]
Guarantees

[0001045810-17-000027:notes:172]
U.S. GAAP requires that upon issuance of a guarantee, the guarantor must recognize a liability for the fair value of the obligation it assumes under that guarantee. In addition, U.S. GAAP requires disclosures about the guarantees that an entity has issued, including a tabular reconciliation of the changes of the entity’s product warranty liabilities.

[0001045810-17-000027:notes:173]
Accrual for Product Warranty Liabilities

[0001045810-17-000027:notes:174]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-17-000027:notes:175]
In fiscal year 2016, we announced a voluntary recall and replacement of our SHIELD 8-inch tablets that were sold between July 2014 and July 2015. We have determined that the battery in these tablets can overheat, posing a fire hazard. The recall did not affect any other NVIDIA products. In fiscal year 2016, we recorded a $26 million charge against cost of revenue to cover anticipated customer warranty, repair, return, replacement and other associated costs.

[0001045810-17-000027:notes:176]
The estimated product returns and estimated product warranty liabilities are as follows:

[0001045810-17-000027:notes:177]
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Balance at beginning of period | $ | 11 |  |  | $ | 8 |  |  | $ | 8 |  |
| Additions | 2 |  |  | 27 |  |  | 5 |  |
| Deductions | (5 | ) |  | (24 | ) |  | (5 | ) |
| Balance at end of period | $ | 8 |  |  | $ | 11 |  |  | $ | 8 |  |

[0001045810-17-000027:notes:178]
In connection with certain agreements that we have entered into in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001045810-17-000027:notes:179]
Long-Lived Assets

[0001045810-17-000027:notes:180]
Intangible assets primarily represent rights acquired under technology licenses, patents, acquired intellectual property, trademarks and customer relationships and are subject to an annual impairment test. We currently amortize our intangible assets with definitive lives over periods ranging from three to ten years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.

[0001045810-17-000027:notes:181]
Long-lived assets, such as property and equipment and intangible assets subject to amortization are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset, or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-17-000027:notes:182]
Income Taxes

[0001045810-17-000027:notes:183]
The income tax expense applicable to income before income taxes consists of the following:

[0001045810-17-000027:notes:184]
|  | Year Ended |
|  | January 29,2017 |  | January 31,2016 |  | January 25,2015 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 7 |  |  | $ | (43 | ) |  | $ | 8 |  |
| State | 1 |  |  | 1 |  |  | 1 |  |
| Foreign | 34 |  |  | 25 |  |  | 17 |  |
| Total current | 42 |  |  | (17 | ) |  | 26 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | 199 |  |  | 134 |  |  | 84 |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | (2 | ) |  | — |  |  | (1 | ) |
| Total deferred | 197 |  |  | 134 |  |  | 83 |  |
| Charge in lieu of taxes attributable to employer stock option plans | — |  |  | 12 |  |  | 15 |  |
| Income tax expense | $ | 239 |  |  | $ | 129 |  |  | $ | 124 |  |

[0001045810-17-000027:notes:185]
Income before income tax consists of the following:

[0001045810-17-000027:notes:186]
|  | Year Ended |
|  | January 29,2017 |  | January 31,2016 |  | January 25,2015 |
|  | (In millions) |
| Domestic | $ | 600 |  |  | $ | 129 |  |  | $ | 174 |  |
| Foreign | 1,305 |  |  | 614 |  |  | 581 |  |
| Income before income tax | $ | 1,905 |  |  | $ | 743 |  |  | $ | 755 |  |

[0001045810-17-000027:notes:187]
The income tax expense differs from the amount computed by applying the federal statutory income tax rate of 35% to income before income taxes as follows:

[0001045810-17-000027:notes:188]
|  | Year Ended |
|  | January 29,2017 |  | January 31,2016 |  | January 25,2015 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 667 |  |  | $ | 260 |  |  | $ | 264 |  |
| Tax expense related to intercompany transaction | 10 |  |  | 10 |  |  | 10 |  |
| State income taxes, net of federal tax effect | 4 |  |  | 1 |  |  | 1 |  |
| Foreign tax rate differential | (315 | ) |  | (95 | ) |  | (120 | ) |
| Stock-based compensation (1) | (70 | ) |  | 13 |  |  | 4 |  |
| U.S. federal R&D tax credit | (52 | ) |  | (38 | ) |  | (34 | ) |
| Restructuring and expiration of statute of limitations | — |  |  | (21 | ) |  | — |  |
| Other | (5 | ) |  | (1 | ) |  | (1 | ) |
| Income tax expense | $ | 239 |  |  | $ | 129 |  |  | $ | 124 |  |

[0001045810-17-000027:notes:189]
| (1) | We adopted an accounting standard related to stock-based compensation effective February 1, 2016, which required the excess tax benefit to be reflected in our provision for income taxes rather than in additional paid-in-capital. The total related excess tax benefit recognized for fiscal year 2017 was $82 million. Please refer to Note 1 of these Notes to the Consolidated Financial Statements for additional information. |

[0001045810-17-000027:notes:190]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-17-000027:notes:191]
|  | January 29,2017 |  | January 31,2016 |
|  | (In millions) |
| Deferred tax assets: |  |
| Net operating loss carryforwards (1) | $ | 199 |  |  | $ | 57 |  |
| Accruals and reserves, not currently deductible for tax purposes | 40 |  |  | 58 |  |
| Property, equipment and intangible assets | 50 |  |  | 50 |  |
| Research and other tax credit carryforwards (1) | 728 |  |  | 404 |  |
| Stock-based compensation | 34 |  |  | 29 |  |
| Convertible debt | 6 |  |  | 9 |  |
| Gross deferred tax assets | 1,057 |  |  | 607 |  |
| Less valuation allowance (1) | (353 | ) |  | (272 | ) |
| Total deferred tax assets | 704 |  |  | 335 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (11 | ) |  | (17 | ) |
| Unremitted earnings of foreign subsidiaries | (827 | ) |  | (615 | ) |
| Gross deferred tax liabilities | (838 | ) |  | (632 | ) |
| Net deferred tax liability | $ | (134 | ) |  | $ | (297 | ) |

[0001045810-17-000027:notes:192]
| (1) | Balances as of January 29, 2017 reflect the adoption of an accounting standard related to stock-based compensation. Please refer to Note 1 of these Notes to the Consolidated Financial Statements for additional information. |

[0001045810-17-000027:notes:193]
We recognized income tax expense of $239 million, $129 million, and $124 million for fiscal years 2017, 2016, and 2015, respectively. Our annual effective tax rate was 12.5%, 17.3%, and 16.5% for fiscal years 2017, 2016, and 2015, respectively. The decrease in the effective tax rate in fiscal year 2017 as compared to fiscal years 2016 and 2015 was primarily due to the recognition of excess tax benefits from our adoption of a new accounting standard related to the simplification of certain aspects of stock-based compensation accounting. The higher effective tax rate in fiscal year 2016 as compared to fiscal years 2017 and 2015 was due to an additional amount of earnings subject to United States tax in fiscal year 2016, partially offset by a net income tax benefit related to the Icera modem restructuring in fiscal year 2016.

[0001045810-17-000027:notes:194]
Our effective tax rate for each of the fiscal years was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate is lower than the United States federal statutory tax rate of 35%, favorable recognition in these fiscal years of the U.S. federal research tax credit and favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of the applicable statutes of limitations, and adoption of an accounting standard related to stock-based compensation during fiscal year 2017.

[0001045810-17-000027:notes:195]
As of January 29, 2017 and January 31, 2016, we had a valuation allowance of $353 million and $272 million, respectively, related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-17-000027:notes:196]
As of January 29, 2017, we had federal, state and foreign net operating loss carryforwards of $448 million, $446 million and $219 million, respectively. The federal and state carryforwards will expire beginning in fiscal year 2022 and 2018, respectively. The foreign net operating loss carryforwards of $219 million may be carried forward indefinitely. As of January 29, 2017, we had federal research tax credit carryforwards of $541 million that will begin to expire in fiscal year 2018. We have state research tax credit carryforwards of $476 million, of which $457 million is attributable to the State of California and may be carried over indefinitely, and $19 million is attributable to various other states and will expire beginning in fiscal year 2018. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, states, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-17-000027:notes:197]
As of January 29, 2017, U.S. federal and state income taxes have not been provided on approximately $3.13 billion of undistributed earnings of non-United States subsidiaries as such earnings are considered to be indefinitely reinvested. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in our foreign subsidiaries as the determination of such amount is not practicable.

[0001045810-17-000027:notes:198]
As of January 29, 2017, we had $224 million of gross unrecognized tax benefits, of which $209 million would affect our effective tax rate if recognized. However, approximately $27 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $209 million of unrecognized tax benefits as of January 29, 2017 consisted of $83 million recorded in non-current income taxes payable and $126 million reflected as a reduction to the related deferred tax assets.

[0001045810-17-000027:notes:199]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-17-000027:notes:200]
|  | January 29,2017 |  | January 31,2016 |  | January 25,2015 |
|  | (In millions) |
| Balance at beginning of period | $ | 230 |  |  | $ | 254 |  |  | $ | 238 |  |
| Increases in tax positions for prior years | 3 |  |  | — |  |  | — |  |
| Decreases in tax positions for prior years | — |  |  | (1 | ) |  | (1 | ) |
| Increases in tax positions for current year | 46 |  |  | 28 |  |  | 23 |  |
| Settlements | (48 | ) |  | — |  |  | — |  |
| Lapse in statute of limitations | (7 | ) |  | (51 | ) |  | (6 | ) |
| Balance at end of period | $ | 224 |  |  | $ | 230 |  |  | $ | 254 |  |

[0001045810-17-000027:notes:201]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable, if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-17-000027:notes:202]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 29, 2017, January 31, 2016, and January 25, 2015, we had accrued $13 million, $11 million, and $14 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 29, 2017, non-current income taxes payable of $96 million consisted of unrecognized tax benefits of $83 million and the related interest and penalties of $13 million.

[0001045810-17-000027:notes:203]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 29, 2017, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-17-000027:notes:204]
We are subject to taxation by a number of taxing authorities both in the United States and throughout the world. As of January 29, 2017, the significant tax jurisdictions that may be subject to examination include the United States, Hong Kong, Taiwan, China, United Kingdom, Germany, and India for fiscal years 2003 through 2016. As of January 29, 2017, the significant tax jurisdictions for which we are currently under examination include India, Taiwan, and Germany for fiscal years 2003 through 2016.


## us-gaap:IncomeTaxPolicyTextBlock

[0001045810-17-000027:notes:205]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-17-000027:notes:206]
United States income tax has not been provided on a portion of earnings of our non-U.S. subsidiaries to the extent that such earnings are considered to be indefinitely reinvested.

[0001045810-17-000027:notes:207]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-17-000027:notes:208]
As of January 29, 2017, we had a valuation allowance of $353 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due, in part, to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-17-000027:notes:209]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. Please refer to Note 13 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-17-000027:notes:210]
Amortizable Intangible Assets

[0001045810-17-000027:notes:211]
The components of our amortizable intangible assets are as follows:

[0001045810-17-000027:notes:212]
|  | January 29, 2017 |  | January 31, 2016 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (167 | ) |  | $ | 26 |  |  | $ | 193 |  |  | $ | (152 | ) |  | $ | 41 |  |
| Patents and licensed technology | 468 |  |  | (390 | ) |  | 78 |  |  | 462 |  |  | (337 | ) |  | 125 |  |
| Total intangible assets | $ | 661 |  |  | $ | (557 | ) |  | $ | 104 |  |  | $ | 655 |  |  | $ | (489 | ) |  | $ | 166 |  |

[0001045810-17-000027:notes:213]
Amortization expense associated with intangible assets for fiscal years 2017, 2016, and 2015 was $68 million, $73 million, and $77 million, respectively. Future amortization expense for the net carrying amount of intangible assets as of January 29, 2017 is estimated to be $54 million in fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $7 million in fiscal year 2021, and $1 million in fiscal year 2022 until fully amortized.


## us-gaap:InventoryPolicyTextBlock

[0001045810-17-000027:notes:214]
Inventories

[0001045810-17-000027:notes:215]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.


## us-gaap:InvestmentPolicyTextBlock

[0001045810-17-000027:notes:216]
Fair Value of Financial Instruments

[0001045810-17-000027:notes:217]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 29, 2017 and January 31, 2016. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains (losses) included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains (losses) are recognized in earnings in the periods of change together with the offsetting losses (gains) on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains (losses) on the derivatives is initially reported as a component of other comprehensive income (loss) and is subsequently recognized in earnings when the hedged exposure is recognized in earnings.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-17-000027:notes:218]
|  | January 29, 2017 |  | January 31, 2016 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 2,209 |  |  | $ | 2,209 |  |  | $ | 1,619 |  |  | $ | 1,619 |  |
| Due in 1 - 5 years | 3,210 |  |  | 3,194 |  |  | 3,019 |  |  | 3,020 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 65 |  |  | 65 |  |  | 34 |  |  | 34 |  |
| Total | $ | 5,484 |  |  | $ | 5,468 |  |  | $ | 4,672 |  |  | $ | 4,673 |  |


## us-gaap:LeasePolicyTextBlock

[0001045810-17-000027:notes:219]
Rent Expense

[0001045810-17-000027:notes:220]
We recognize rent expense on a straight-line basis over the lease period and accrue for rent expense incurred, but not paid.


## us-gaap:LegalCostsPolicyTextBlock

[0001045810-17-000027:notes:221]
Litigation, Investigation and Settlement Costs

[0001045810-17-000027:notes:222]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001045810-17-000027:notes:223]
|  | January 29, 2017 |  | January 31, 2016 |
| Long-lived assets: | (In millions) |
| United States | $ | 440 |  |  | $ | 414 |  |
| Taiwan | 52 |  |  | 39 |  |
| India | 47 |  |  | 45 |  |
| China | 34 |  |  | 25 |  |
| Europe | 9 |  |  | 9 |  |
| Other Asia Pacific | 1 |  |  | 1 |  |
| Total long-lived assets | $ | 583 |  |  | $ | 533 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-17-000027:notes:224]
Marketable Securities

[0001045810-17-000027:notes:225]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax, and net realized gains and losses recorded in other income (expense), net, on the Consolidated Statements of Income.

[0001045810-17-000027:notes:226]
We performed an impairment review of our investment portfolio as of January 29, 2017. Factors considered included general market conditions, the duration and extent to which fair value is below cost, and our intent and ability to hold an investment for a sufficient period of time to allow for recovery in value. We also consider specific adverse conditions related to the financial health of and business outlook for an investee, including industry and sector performance, changes in technology, operational and financing cash flow factors, and changes in an investee’s credit rating. Investments that we identify as having an indicator of impairment are subject to further analysis to determine if the investment was other than temporarily impaired. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of January 29, 2017.

[0001045810-17-000027:notes:227]
The following is a summary of cash equivalents and marketable securities as of January 29, 2017 and January 31, 2016:

[0001045810-17-000027:notes:228]
The gross unrealized losses related to fixed income securities and were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities as of January 29, 2017 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity. Net realized gains were not significant for fiscal years 2017, 2016, and 2015.

[0001045810-17-000027:notes:229]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of January 29, 2017 and January 31, 2016 and are shown below by contractual maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-17-000027:notes:230]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000027:notes:231]
Recently Adopted Accounting Pronouncement

[0001045810-17-000027:notes:232]
In fiscal year 2017, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting. Among other elements, the new guidance eliminates additional paid in capital, or APIC, pools and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. We elected to early adopt this new guidance in the third quarter of fiscal year 2017, which required us to reflect any adjustments as of February 1, 2016.

[0001045810-17-000027:notes:233]
Early adoption of this guidance resulted in the following:

[0001045810-17-000027:notes:234]
| • | We recorded an excess tax benefit from stock-based compensation within income tax expense, rather than in APIC, of $82 million for fiscal year 2017. |

[0001045810-17-000027:notes:235]
| • | We recorded a cumulative-effect adjustment as of February 1, 2016 to increase retained earnings by $353 million, with a corresponding increase to deferred tax assets, to recognize the federal net operating loss and federal research tax credit carryforwards attributable to excess tax benefits on stock-based compensation that had not been previously recognized in APIC. We also recorded deferred tax assets of $63 million with a corresponding full valuation allowance related to state net operating loss and state research credit carryforwards. |

[0001045810-17-000027:notes:236]
| • | The excess tax benefit from stock-based compensation is now included in net operating cash rather than net financing cash in our Consolidated Statements of Cash Flows. We elected to apply this change in presentation prospectively and thus prior periods have not been adjusted. |

[0001045810-17-000027:notes:237]
We elected not to change our policy on accounting for forfeitures, although the new guidance provides an option for us to account for forfeitures as they occur, and thus continued to estimate forfeitures expected to occur to determine the amount of compensation cost to be recognized in each period.

[0001045810-17-000027:notes:238]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-17-000027:notes:239]
In January 2017, the FASB issued an accounting standards update that simplifies the test for goodwill impairment. The update eliminates the second step in the goodwill impairment test that requires an entity to determine the implied fair value of the reporting unit’s goodwill. Instead, an entity should recognize an impairment loss if the carrying value of the net assets assigned to the reporting unit exceeds the fair value of the reporting unit, with the impairment loss not to exceed the amount of goodwill allocated to the reporting unit. The update will be effective for us beginning in our fiscal year 2020, with early adoption permitted. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-17-000027:notes:240]
In October 2016, the FASB issued an accounting standards update that requires the recognition of income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-17-000027:notes:241]
In August 2016, the FASB issued an accounting standards update that clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not expected to have a material impact on our consolidated financial statements.

[0001045810-17-000027:notes:242]
In June 2016, the FASB issued an accounting standards update that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The update also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The update will be effective for us beginning in our first quarter of fiscal 2021, with early adoption permitted. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-17-000027:notes:243]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

[0001045810-17-000027:notes:244]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-17-000027:notes:245]
Employee Retirement Plans

[0001045810-17-000027:notes:246]
We have a 401(k) retirement plan covering substantially all of our United States employees. Under the plan, participating employees may defer up to 100% of their pre-tax earnings, subject to the Internal Revenue Service annual contribution limits. Effective January 2013, we began matching a portion of the employee contributions. Our contribution expense for fiscal years 2017, 2016, and 2015 was $12 million, $8 million, and $6 million, respectively. We also have defined contribution retirement plans outside of the United States to which we contributed $23 million, $21 million, and $20 million for fiscal years 2017, 2016, and 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001045810-17-000027:notes:247]
Property and Equipment

[0001045810-17-000027:notes:248]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to twenty five years. Depreciation expense includes the amortization of assets recorded under capital leases. Leasehold improvements and assets recorded under capital leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001045810-17-000027:notes:249]
Quarterly Summary (Unaudited)

[0001045810-17-000027:notes:250]
The following table sets forth our unaudited consolidated financial results, for the last eight fiscal quarters:

[0001045810-17-000027:notes:251]
|  | Fiscal Year 2017Quarters Ended |
|  | January 29, 2017 |  | October 30, 2016 |  | July 31,2016 |  | May 1, 2016 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 2,173 |  |  | $ | 2,004 |  |  | $ | 1,428 |  |  | $ | 1,305 |  |
| Cost of revenue | $ | 870 |  |  | $ | 821 |  |  | $ | 602 |  |  | $ | 554 |  |
| Gross profit | $ | 1,303 |  |  | $ | 1,183 |  |  | $ | 826 |  |  | $ | 751 |  |
| Net income (1) | $ | 655 |  |  | $ | 542 |  |  | $ | 261 |  |  | $ | 208 |  |
| Net income per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.18 |  |  | $ | 1.01 |  |  | $ | 0.49 |  |  | $ | 0.39 |  |
| Diluted | $ | 0.99 |  |  | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 0.35 |  |

[0001045810-17-000027:notes:252]
| (1) | In the third quarter of fiscal year 2017, we adopted an accounting standard related to stock-based compensation, which requires adjustments to be reflected beginning in fiscal year 2017. The adoption of the new accounting standard impacted our previously reported quarterly results for fiscal year 2017 as follows: |

[0001045810-17-000027:notes:253]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | May 1, 2016 |  | July 31, 2016 |
|  | As reported |  | As adjusted |  | As reported |  | As adjusted |  | As reported |  | As adjusted |
|  | (In millions, except per share data) |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | $ | 64 |  |  | $ | 56 |  |  | $ | 45 |  |  | $ | 33 |  |  | $ | 109 |  |  | $ | 89 |  |
| Net income | $ | 253 |  |  | $ | 261 |  |  | $ | 196 |  |  | $ | 208 |  |  | $ | 449 |  |  | $ | 469 |  |
| Basic net income per share | $ | 0.47 |  |  | $ | 0.49 |  |  | $ | 0.36 |  |  | $ | 0.39 |  |  | $ | 0.84 |  |  | $ | 0.88 |  |
| Diluted net income per share | $ | 0.40 |  |  | $ | 0.41 |  |  | $ | 0.33 |  |  | $ | 0.35 |  |  | $ | 0.73 |  |  | $ | 0.76 |  |
| Weighted average shares used in diluted net income per share computation | 631 |  |  | 634 |  |  | 597 |  |  | 599 |  |  | 617 |  |  | 620 |  |
| Condensed Consolidated Statements of Cash Flows: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 184 |  |  | $ | 201 |  |  | $ | 309 |  |  | $ | 318 |  |  | $ | 493 |  |  | $ | 519 |  |
| Net cash used in financing activities | $ | (35 | ) |  | $ | (52 | ) |  | $ | (534 | ) |  | $ | (545 | ) |  | $ | (570 | ) |  | $ | (597 | ) |

[0001045810-17-000027:notes:254]
|  | Fiscal Year 2016Quarters Ended |
|  | January 31, 2016 |  | October 25, 2015 |  | July 26,2015 |  | April 26, 2015 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 1,401 |  |  | $ | 1,305 |  |  | $ | 1,153 |  |  | $ | 1,151 |  |
| Cost of revenue | $ | 610 |  |  | $ | 572 |  |  | $ | 519 |  |  | $ | 498 |  |
| Gross profit | $ | 791 |  |  | $ | 733 |  |  | $ | 634 |  |  | $ | 653 |  |
| Net income | $ | 207 |  |  | $ | 247 |  |  | $ | 26 |  |  | $ | 134 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | 0.45 |  |  | $ | 0.05 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.44 |  |  | $ | 0.05 |  |  | $ | 0.24 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001045810-17-000027:notes:255]
Accounts Receivable

[0001045810-17-000027:notes:256]
We maintain an allowance for doubtful accounts receivable for estimated losses resulting from the inability of our customers to make required payments. We determine this allowance by identifying amounts for specific customer issues as well as amounts based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-17-000027:notes:257]
In fiscal year 2016, we began the wind down of our Icera modem operations. Our operating expenses for fiscal years 2017 and 2016 included $3 million and $131 million, respectively, of restructuring and other charges.

[0001045810-17-000027:notes:258]
|  | Year Ended |
|  | January 29, |  | January 31, |
|  | 2017 |  | 2016 |
|  | (In millions) |
| Employee severance and related costs | $ | 5 |  |  | $ | 82 |  |
| Tax subsidy (refund) impairment | (3 | ) |  | 17 |  |
| Facilities and related costs | — |  |  | 27 |  |
| Other exit costs | 1 |  |  | 5 |  |
| Restructuring and other charges | $ | 3 |  |  | $ | 131 |  |

[0001045810-17-000027:notes:259]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Consolidated Balance Sheets as of January 29, 2017 and January 31, 2016:

[0001045810-17-000027:notes:260]
|  | January 29, |  | January 31, |
|  | 2017 |  | 2016 |
|  | (In millions) |
| Balance at beginning of period | $ | 23 |  |  | $ | — |  |
| Restructuring and other charges | 3 |  |  | 131 |  |
| Cash payments | (13 | ) |  | (63 | ) |
| Non-cash adjustments | — |  |  | (45 | ) |
| Balance at end of period | $ | 13 |  |  | $ | 23 |  |

[0001045810-17-000027:notes:261]
The majority of the remaining balance of $13 million as of January 29, 2017 is expected to be paid during fiscal year 2018.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001045810-17-000027:notes:262]
Revenue Recognition

[0001045810-17-000027:notes:263]
Product Revenue

[0001045810-17-000027:notes:264]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured. For most sales, we use a binding purchase order and in certain cases we use a contractual agreement as evidence of an arrangement. We consider delivery to occur upon shipment provided title and risk of loss have passed to the customer. At the point of sale, we assess whether the arrangement fee is fixed or determinable and whether collection is reasonably assured. If we determine that collection of a fee is not reasonably assured, we defer the fee and recognize revenue at the time collection becomes reasonably assured, which is generally upon receipt of payment.

[0001045810-17-000027:notes:265]
For sales to certain distributors with rights of return for which the level of returns cannot be reasonably estimated, our policy is to defer recognition of revenue and related cost of revenue until the distributors resell the product and, in some cases, when customer return rights lapse.

[0001045810-17-000027:notes:266]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with original equipment manufacturers, or OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. In such cases, the OEMs may not be our direct customers and therefore the quantity and mix of demand they place on their contract equipment manufacturers, or CEMs, and original device manufacturers, or ODMs, may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents less than 0.5% of total revenue.

[0001045810-17-000027:notes:267]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors, add-in card partners and other channel partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed.

[0001045810-17-000027:notes:268]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-17-000027:notes:269]
License and Development Revenue

[0001045810-17-000027:notes:270]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete the project. A provision for estimated losses on contracts is made in the period in which the loss becomes probable and can be reasonably estimated. Costs incurred in advance of revenue recognized are recorded as deferred costs on uncompleted contracts. If the amount billed exceeds the amount of revenue recognized, the excess amount is recorded as deferred revenue.

[0001045810-17-000027:notes:271]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-17-000027:notes:272]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties.  We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001045810-17-000027:notes:273]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
| Revenue: |  |  |  |  |  |
| Customer A | 12 | % |  | 11 | % |  | 11 | % |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001045810-17-000027:notes:274]
|  | Year Ended |
|  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
| Revenue: | (In millions) |
| Taiwan | $ | 2,546 |  |  | $ | 1,912 |  |  | $ | 1,594 |  |
| China | 1,305 |  |  | 806 |  |  | 922 |  |
| Other Asia Pacific | 1,010 |  |  | 749 |  |  | 638 |  |
| United States | 904 |  |  | 643 |  |  | 791 |  |
| Europe | 659 |  |  | 482 |  |  | 369 |  |
| Other Americas | 486 |  |  | 418 |  |  | 368 |  |
| Total revenue | $ | 6,910 |  |  | $ | 5,010 |  |  | $ | 4,682 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-17-000027:notes:275]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 29, 2017: |  |  |  |  |  |  |  |
| Revenue | $ | 5,822 |  |  | $ | 824 |  |  | $ | 264 |  |  | $ | 6,910 |  |
| Depreciation and amortization expense | $ | 116 |  |  | $ | 29 |  |  | $ | 42 |  |  | $ | 187 |  |
| Operating income (loss) | $ | 2,180 |  |  | $ | (9 | ) |  | $ | (237 | ) |  | $ | 1,934 |  |
| Year Ended January 31, 2016: |  |  |  |  |  |  |  |
| Revenue | $ | 4,187 |  |  | $ | 559 |  |  | $ | 264 |  |  | $ | 5,010 |  |
| Depreciation and amortization expense | $ | 110 |  |  | $ | 43 |  |  | $ | 44 |  |  | $ | 197 |  |
| Operating income (loss) | $ | 1,344 |  |  | $ | (239 | ) |  | $ | (358 | ) |  | $ | 747 |  |
| Year Ended January 25, 2015: |  |  |  |  |  |  |  |
| Revenue | $ | 3,839 |  |  | $ | 579 |  |  | $ | 264 |  |  | $ | 4,682 |  |
| Depreciation and amortization expense | $ | 117 |  |  | $ | 57 |  |  | $ | 46 |  |  | $ | 220 |  |
| Operating income (loss) | $ | 1,113 |  |  | $ | (254 | ) |  | $ | (100 | ) |  | $ | 759 |  |

[0001045810-17-000027:notes:276]
|  |  | Year Ended |
|  |  | January 29, 2017 |  | January 31, 2016 |  | January 25, 2015 |
|  |  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |
| Unallocated revenue |  | $ | 264 |  |  | $ | 264 |  |  | $ | 264 |  |
| Stock-based compensation |  | (247 | ) |  | (204 | ) |  | (158 | ) |
| Unallocated cost of revenue and operating expenses |  | (215 | ) |  | (244 | ) |  | (169 | ) |
| Acquisition-related costs |  | (16 | ) |  | (22 | ) |  | (37 | ) |
| Legal settlement costs |  | (16 | ) |  | — |  |  | — |  |
| Contributions |  | (4 | ) |  | — |  |  | — |  |
| Restructuring and other charges |  | (3 | ) |  | (131 | ) |  | — |  |
| Product warranty charges |  | — |  |  | (21 | ) |  | — |  |
| Total |  | $ | (237 | ) |  | $ | (358 | ) |  | $ | (100 | ) |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-17-000027:notes:277]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-17-000027:notes:278]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2017 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | 1 |  | (1) | $ | — |  | (1) | $ | 3 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 9 |  | (2) | $ | (8 | ) | (4) | $ | 10 |  |
| Deferred tax valuation allowance |  | $ | 272 |  |  | $ | 81 |  | (3) | $ | — |  |  | $ | 353 |  |
| Fiscal year 2016 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3 |  |  | $ | — |  | (1) | $ | (1 | ) | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 14 |  |  | $ | 9 |  | (2) | $ | (14 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 261 |  |  | $ | 11 |  | (3) | $ | — |  |  | $ | 272 |  |
| Fiscal year 2015 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1 |  |  | $ | 3 |  | (1) | $ | (1 | ) | (1) | $ | 3 |  |
| Sales return allowance |  | $ | 14 |  |  | $ | 12 |  | (2) | $ | (12 | ) | (4) | $ | 14 |  |
| Deferred tax valuation allowance |  | $ | 244 |  |  | $ | 17 |  | (3) | $ | — |  |  | $ | 261 |  |

[0001045810-17-000027:notes:279]
(1)   Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end.

[0001045810-17-000027:notes:280]
(2)   Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue.

[0001045810-17-000027:notes:281]
(3)   Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions.

[0001045810-17-000027:notes:282]
(4)  Represents sales returns.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-17-000027:notes:283]
Segment Information

[0001045810-17-000027:notes:284]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-17-000027:notes:285]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-17-000027:notes:286]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for mobile gaming and entertainment devices, as well as autonomous robots, drones and cars.

[0001045810-17-000027:notes:287]
We have a single unifying architecture for our GPU and Tegra Processors. This architecture unification leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-17-000027:notes:288]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, contributions, restructuring and other charges, product warranty charge, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-17-000027:notes:289]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for NVIDIA as a whole. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-17-000027:notes:290]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-17-000027:notes:291]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-17-000027:notes:292]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and deposits and other assets, and exclude goodwill and intangible assets.

[0001045810-17-000027:notes:293]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-17-000027:notes:294]
Revenue was attributable to the GPU business.

[0001045810-17-000027:notes:295]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-17-000027:notes:296]
Organization and Summary of Significant Accounting Policies

[0001045810-17-000027:notes:297]
Our Company

[0001045810-17-000027:notes:298]
Starting with a focus on PC graphics, NVIDIA invented the GPU to solve some of the most complex problems in computer science. We have extended our emphasis in recent years to the revolutionary field of artificial intelligence.

[0001045810-17-000027:notes:299]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-17-000027:notes:300]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries, except where it is made clear that the term means only the parent company.

[0001045810-17-000027:notes:301]
Fiscal Year

[0001045810-17-000027:notes:302]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2017 and 2015 were 52-week years and fiscal year 2016 was a 53-week year.

[0001045810-17-000027:notes:303]
Reclassifications

[0001045810-17-000027:notes:304]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-17-000027:notes:305]
Use of Estimates

[0001045810-17-000027:notes:306]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States, or U.S. GAAP, requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-17-000027:notes:307]
Marketable securities consist primarily of highly liquid investments with maturities of greater than three months when purchased. We generally classify our marketable securities at the date of acquisition as available-for-sale. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax. The fair value of interest-bearing securities includes accrued interest. Any unrealized losses which are considered to be other-than-temporary impairments are recorded in the other income (expense), net, section of our Consolidated Statements of Income. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income (expense), net, section of our Consolidated Statements of Income.

[0001045810-17-000027:notes:308]
All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is not more likely than not that we will not be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings while loss related to all other factors is recorded in accumulated other comprehensive income (loss).

[0001045810-17-000027:notes:309]
Concentration of Credit Risk

[0001045810-17-000027:notes:310]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, accounts receivable, note hedge and interest rate swap. Our investment policy requires the purchase of high grade investment securities, the diversification of asset type and includes certain limits on our portfolio duration. All marketable securities are held in our name, managed by several investment managers and held by one major financial institution under a custodial arrangement. Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 29% of our accounts receivable balance from two customers as of January 29, 2017 and 28% of our account receivable balance from two customers as of January 31, 2016. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-17-000027:notes:311]
Intangible Assets and Other Long-Lived Assets


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-17-000027:notes:312]
Shareholders’ Equity

[0001045810-17-000027:notes:313]
Capital Return Program

[0001045810-17-000027:notes:314]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. On November 7, 2016, the Board authorized an additional $2.00 billion under our repurchase program and extended it through December 2020.

[0001045810-17-000027:notes:315]
During fiscal year 2017, we repurchased a total of 15 million shares for $739 million and paid $261 million in cash dividends to our shareholders, equivalent to $0.485 per share on an annual basis.

[0001045810-17-000027:notes:316]
Through January 29, 2017, we have repurchased an aggregate of 245 million shares under our share repurchase program for a total cost of $4.59 billion. All shares delivered from these repurchases have been placed into treasury stock. As of January 29, 2017, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $2.73 billion through December 2020.

[0001045810-17-000027:notes:317]
Convertible Preferred Stock

[0001045810-17-000027:notes:318]
As of January 29, 2017 and January 31, 2016, there were no shares of preferred stock outstanding.

[0001045810-17-000027:notes:319]
Common Stock

[0001045810-17-000027:notes:320]
We are authorized to issue up to 2.00 billion shares of our common stock at $0.001 per share par value.
