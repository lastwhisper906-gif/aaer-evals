# NVDA note change history — 0001045810-16-000300 → 0001045810-16-000353


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0001045810-16-000353:note_history:1]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The third quarter of fiscal years 2017 and 2016 were both 13-week quarters.
  (was, 2016-08-23, similarity 0.7494):
[0001045810-16-000300:note_history:1]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The second quarter of fiscal years 2017 and 2016 were both 13-week quarters.

- added (2016-11-22):
[0001045810-16-000353:note_history:2]
Recently Adopted Accounting Pronouncement

- added (2016-11-22):
[0001045810-16-000353:note_history:3]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting. Among other elements, the new guidance eliminates additional paid in capital, or APIC, pools and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The new standard is effective for us beginning in our first quarter of fiscal year 2018 with early adoption permitted. We elected to early adopt this new guidance in the third quarter of fiscal year 2017, which required us to reflect any adjustments as of February 1, 2016.

- added (2016-11-22):
[0001045810-16-000353:note_history:4]
Early adoption of this guidance resulted in the following:

- added (2016-11-22):
[0001045810-16-000353:note_history:5]
| • | We recorded excess tax benefits within income tax expense, rather than in APIC, of $12 million, $8 million and $42 million for the first, second and third quarters of fiscal year 2017, respectively. |

- added (2016-11-22):
[0001045810-16-000353:note_history:6]
| • | We recorded a cumulative-effect adjustment as of February 1, 2016 to increase retained earnings by $353 million, with a corresponding increase to deferred tax assets, to recognize the net operating loss and federal research tax credit carryforwards attributable to excess tax benefits on stock-based compensation that had not been previously recognized in APIC. |

- added (2016-11-22):
[0001045810-16-000353:note_history:7]
| • | The excess tax benefits are now included in net operating cash rather than net financing cash in our Condensed Consolidated Statements of Cash Flows. We elected to apply this change in presentation prospectively and thus prior periods have not been adjusted. |

- added (2016-11-22):
[0001045810-16-000353:note_history:8]
We elected not to change our policy on accounting for forfeitures, although the new guidance provides an option for us to account for forfeitures as they occur, and thus continued to estimate forfeitures expected to occur to determine the amount of compensation cost to be recognized in each period.

- added (2016-11-22):
[0001045810-16-000353:note_history:9]
The adoption of this new guidance impacted our previously reported quarterly results for fiscal year 2017 as follows:

- added (2016-11-22):
[0001045810-16-000353:note_history:10]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | May 1, 2016 |  | July 31, 2016 |
|  | As reported |  | As adjusted |  | As reported |  | As adjusted |  | As reported |  | As adjusted |
|  | (In millions, except per share data) |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | $ | 64 |  |  | $ | 56 |  |  | $ | 45 |  |  | $ | 33 |  |  | $ | 109 |  |  | $ | 89 |  |
| Net income | $ | 253 |  |  | $ | 261 |  |  | $ | 196 |  |  | $ | 208 |  |  | $ | 449 |  |  | $ | 469 |  |
| Basic net income per share | $ | 0.47 |  |  | $ | 0.49 |  |  | $ | 0.36 |  |  | $ | 0.39 |  |  | $ | 0.84 |  |  | $ | 0.88 |  |
| Diluted net income per share | $ | 0.40 |  |  | $ | 0.41 |  |  | $ | 0.33 |  |  | $ | 0.35 |  |  | $ | 0.73 |  |  | $ | 0.76 |  |
| Weighted average shares used in diluted net income per share computation | 631 |  |  | 634 |  |  | 597 |  |  | 599 |  |  | 617 |  |  | 620 |  |
| Condensed Consolidated Statements of Cash Flows: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 184 |  |  | $ | 201 |  |  | $ | 309 |  |  | $ | 318 |  |  | $ | 493 |  |  | $ | 519 |  |
| Net cash used in financing activities | $ | (35 | ) |  | $ | (52 | ) |  | $ | (534 | ) |  | $ | (545 | ) |  | $ | (570 | ) |  | $ | (597 | ) |

- added (2016-11-22):
[0001045810-16-000353:note_history:11]
Recent Accounting Pronouncements Not Yet Adopted

- added (2016-11-22):
[0001045810-16-000353:note_history:12]
In October 2016, the FASB issued an accounting standards update that requires the recognition of income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

- added (2016-11-22):
[0001045810-16-000353:note_history:13]
In August 2016, the FASB issued an accounting standards update that clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not expected to have a material impact on our consolidated financial statements.

- changed (2016-11-22):
[0001045810-16-000353:note_history:14]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.
  (was, 2016-08-23, similarity 0.9977):
[0001045810-16-000300:note_history:14]
In February 2016, FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.

- changed (2016-11-22):
[0001045810-16-000353:note_history:15]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. The new standard will be effective for us beginning in our first quarter of fiscal year 2019, although we are permitted to adopt the standard one year earlier. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption, or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.
  (was, 2016-08-23, similarity 0.7152):
[0001045810-16-000300:note_history:15]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). In March, April and May 2016, the FASB issued additional updates to the new revenue standard relating to reporting revenue on a gross versus net basis, identifying performance obligations and licensing arrangements, and narrow-scope improvements and practical expedients, respectively. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.

- removed (2016-11-22):
[0001045810-16-000300:note_history:16]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting, including income taxes at settlement, classifications in the statement of cash flows, forfeitures and net settlements, and will be effective in our first quarter of fiscal year 2018. Early adoption is permitted in any annual or interim period. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements and whether or not to adopt it early. We expect that the adoption of this accounting guidance will result in increased volatility of our effective tax rate, and changes in certain tax-related balance sheet line items and statement of cash flows classifications.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0001045810-16-000353:note_history:17]
The following table presents the carrying value of the Convertible Notes:
  (was, 2016-08-23, similarity 0.9104):
[0001045810-16-000300:note_history:17]
The following table presents the carrying value of the Notes:

- added (2016-11-22):
[0001045810-16-000353:note_history:18]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,056 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (45 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,011 |  |  | $ | 1,413 |  |

- changed (2016-11-22):
[0001045810-16-000353:note_history:19]
(1) As of October 30, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.1 years.
  (was, 2016-08-23, similarity 0.9507):
[0001045810-16-000300:note_history:19]
(1) As of July 31, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.3 years.

- changed (2016-11-22):
[0001045810-16-000353:note_history:20]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:
  (was, 2016-08-23, similarity 0.8866):
[0001045810-16-000300:note_history:20]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

- changed (2016-11-22):
[0001045810-16-000353:note_history:21]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 5 |  |  | 7 |  |  | 20 |  |  | 22 |  |
| Total interest expense related to Convertible Notes |  | $ | 8 |  |  | $ | 11 |  |  | $ | 30 |  |  | $ | 33 |  |
  (was, 2016-08-23, similarity 0.7456):
[0001045810-16-000300:note_history:21]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- removed (2016-11-22):
[0001045810-16-000300:note_history:22]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (72 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,428 |  |  | $ | 1,413 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-11-22):
[0001045810-16-000353:note_history:23]
Debt

- changed (2016-11-22):
[0001045810-16-000353:note_history:24]
On December 2, 2013, we issued $1.50 billion of 1.00% convertible senior notes, or the Convertible Notes, due 2018. The Convertible Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Convertible Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Convertible Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of October 30, 2016, the conversion rate has been adjusted to 49.8058 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0780 per share of common stock) for dividend increases.
  (was, 2016-08-23, similarity 0.7548):
[0001045810-16-000300:note_history:24]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of July 31, 2016, the conversion rate has been adjusted to 49.7818 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.0877 per share of common stock) for dividend increases made to that date.

- added (2016-11-22):
[0001045810-16-000353:note_history:25]
We separately accounted for the liability and equity components of the Convertible Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

- changed (2016-11-22):
[0001045810-16-000353:note_history:26]
The initial debt component of the Convertible Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Convertible Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method using an interest rate of 3.15%.
  (was, 2016-08-23, similarity 0.9692):
[0001045810-16-000300:note_history:26]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

- changed (2016-11-22):
[0001045810-16-000353:note_history:27]
The following table presents the carrying value of the Convertible Notes:
  (was, 2016-08-23, similarity 0.9104):
[0001045810-16-000300:note_history:27]
The following table presents the carrying value of the Notes:

- added (2016-11-22):
[0001045810-16-000353:note_history:28]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,056 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (45 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,011 |  |  | $ | 1,413 |  |

- changed (2016-11-22):
[0001045810-16-000353:note_history:29]
(1) As of October 30, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.1 years.
  (was, 2016-08-23, similarity 0.9507):
[0001045810-16-000300:note_history:29]
(1) As of July 31, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.3 years.

- changed (2016-11-22):
[0001045810-16-000353:note_history:30]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:
  (was, 2016-08-23, similarity 0.8866):
[0001045810-16-000300:note_history:30]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

- changed (2016-11-22):
[0001045810-16-000353:note_history:31]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 5 |  |  | 7 |  |  | 20 |  |  | 22 |  |
| Total interest expense related to Convertible Notes |  | $ | 8 |  |  | $ | 11 |  |  | $ | 30 |  |  | $ | 33 |  |
  (was, 2016-08-23, similarity 0.7456):
[0001045810-16-000300:note_history:31]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 31, |  | July 26, |  | July 31, |  | July 26, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- changed (2016-11-22):
[0001045810-16-000353:note_history:32]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Convertible Notes regardless of the foregoing conditions.
  (was, 2016-08-23, similarity 0.9599):
[0001045810-16-000300:note_history:32]
Holders may convert all or any portion of their Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Notes regardless of the foregoing conditions.

- added (2016-11-22):
[0001045810-16-000353:note_history:33]
The Convertible Notes first became convertible as of February 1, 2016. As of October 30, 2016, the Convertible Notes continued to be convertible at the holders’ option through January 29, 2017 as the price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended October 30, 2016. As such, the $1,011 million carrying value of the Convertible Notes continued to be classified as a current liability and the $45 million difference between the principal amount and the carrying value of the Convertible Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Convertible Notes are convertible. The determination of whether or not the Convertible Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Convertible Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

- changed (2016-11-22):
[0001045810-16-000353:note_history:34]
Upon conversion of the Convertible Notes, we will pay cash up to the aggregate principal amount of the Convertible Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Convertible Notes being converted. Based on the closing price of our common stock on October 28, 2016 (the last trading day of the third quarter of fiscal year 2017) of $70.56, the if-converted value of our Convertible Notes exceeded their principal amount by approximately $2.66 billion.
  (was, 2016-08-23, similarity 0.9187):
[0001045810-16-000300:note_history:34]
Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the closing price of our common stock on July 29, 2016 (the last trading day of the second quarter of fiscal year 2017) of $57.10, the if-converted value of our Notes exceeded their principal amount by approximately $2.76 billion.

- added (2016-11-22):
[0001045810-16-000353:note_history:35]
During both the three and nine months ended October 30, 2016, we paid cash to settle $444 million in principal amount, issued 15 million shares of our common stock with respect to the conversion obligation in excess of the principal amount, and recognized a loss of $15 million on early conversions, of the Convertible Notes. Further, we received additional conversion notices for an aggregate of $229 million in principal amount of the Convertible Notes during the third quarter of fiscal year 2017. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2017.

- changed (2016-11-22):
[0001045810-16-000353:note_history:36]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Convertible Notes, or $20.1630 per share. Adjusting for dividends paid through October 30, 2016, the strike price of the Note Hedges has been adjusted to $20.0780 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through October 30, 2016, we had received 15 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of an aggregate of $444 million in principal amount of the Convertible Notes.
  (was, 2016-08-23, similarity 0.8534):
[0001045810-16-000300:note_history:36]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through July 31, 2016, the strike price of the Note Hedges has been adjusted to $20.0877 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion. Through July 31, 2016, we had received 5,446 shares of our common stock from the exercise of a portion of the Note Hedges related to the conversion of an aggregate of $0.2 million in principal amount of the Notes.

- changed (2016-11-22):
[0001045810-16-000353:note_history:37]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of October 30, 2016, the strike price was adjusted to $27.0281 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 75 million shares of our common stock. As of October 30, 2016, the Warrants had not been exercised and remained outstanding. The value of the Warrants was initially recorded in equity and continues to be classified as equity.
  (was, 2016-08-23, similarity 0.9806):
[0001045810-16-000300:note_history:37]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of July 31, 2016, the strike price was adjusted to $27.0411 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 75 million shares of our common stock. As of July 31, 2016, the warrants had not been exercised and remained outstanding. The value of the warrants was initially recorded in equity and continues to be classified as equity.

- added (2016-11-22):
[0001045810-16-000353:note_history:38]
Long-Term Debt

- added (2016-11-22):
[0001045810-16-000353:note_history:39]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

- added (2016-11-22):
[0001045810-16-000353:note_history:40]
On September 16, 2016, we issued $1.00 billion of 2.20% notes due September 16, 2021 and $1.00 billion of 3.20% notes due September 16, 2026 (collectively, the Notes). Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2.20% Notes Due 2021 on or after August 16, 2021, or for redemptions of the 3.20% Notes Due 2026 on or after June 16, 2026.

- added (2016-11-22):
[0001045810-16-000353:note_history:41]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

- added (2016-11-22):
[0001045810-16-000353:note_history:42]
The net proceeds from the Notes were $1.99 billion, after deducting debt discount and issuance costs. We intend to use the net proceeds from the Notes to prefund the repayment of the principal amount of our Convertible Notes and for general corporate purposes such as dividend payments or share repurchases.

- added (2016-11-22):
[0001045810-16-000353:note_history:43]
The carrying value of our long-term debt and the associated interest rates were as follows:

- added (2016-11-22):
[0001045810-16-000353:note_history:44]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30,2016 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.9 |  | 2.38% |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.9 |  | 3.31% |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (18 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,982 |  |

- added (2016-11-22):
[0001045810-16-000353:note_history:45]
Revolving Credit Facility

- added (2016-11-22):
[0001045810-16-000353:note_history:46]
On October 7, 2016, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021, on which all outstanding obligations would be due and payable. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of October 30, 2016, we had not borrowed any amounts under the Credit Agreement.

- removed (2016-11-22):
[0001045810-16-000300:note_history:47]
We separately accounted for the liability and equity components of the Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

- removed (2016-11-22):
[0001045810-16-000300:note_history:48]
|  | July 31, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (72 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,428 |  |  | $ | 1,413 |  |

- removed (2016-11-22):
[0001045810-16-000300:note_history:49]
The Notes first became convertible as of February 1, 2016. As of July 31, 2016, the Notes continued to be convertible at the holders’ option through October 30, 2016 as the price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended July 31, 2016. As such, the $1.43 billion carrying value of the Notes continued to be classified as a current liability and the $72 million difference between the principal amount and the carrying value of the Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

- removed (2016-11-22):
[0001045810-16-000300:note_history:50]
During the three months ended July 31, 2016, an aggregate of $0.2 million in principal amount of the Notes was converted at the holders’ option, and we paid cash of $0.2 million and issued 5,446 shares of our common stock with respect to the conversion obligation in excess of the principal amount. We recognized an insignificant loss on extinguishment related to the conversions of the Notes for the three months ended July 31, 2016. As of July 31, 2016, the remaining aggregate principal amount of the Notes outstanding was $1,499.8 million. As of July 31, 2016, we had received conversion notices for an aggregate of $229 million in principal amount of the Notes plus an additional notice subsequent to July 31, 2016 for $200 million in principal amount of the Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2017.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-11-22):
[0001045810-16-000353:note_history:51]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30,2016 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.9 |  | 2.38% |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.9 |  | 3.31% |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (18 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,982 |  |
