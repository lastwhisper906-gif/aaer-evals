# NVDA 8-K — 0001045810-22-000163 filed 2022-11-16

## item codes, every 8-K on or before 2022-11-18

- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2022-11-18

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-22-000163:8k_2_02:1]
EX-99.1
2
q3fy23pr.htm
Q3FY23 PRESS RELEASE

[0001045810-22-000163:8k_2_02:2]
Document

[0001045810-22-000163:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-22-000163:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2023

[0001045810-22-000163:8k_2_02:5]
•Data Center revenue of $3.83 billion, up 31% from a year ago

[0001045810-22-000163:8k_2_02:6]
•Quarterly return to shareholders of $3.75 billion

[0001045810-22-000163:8k_2_02:7]
SANTA CLARA, Calif.-Nov. 16, 2022- NVIDIA (NASDAQ: NVDA) today reported revenue for the third quarter ended October 30, 2022, of $5.93 billion, down 17% from a year ago and down 12% from the previous quarter.

[0001045810-22-000163:8k_2_02:8]
GAAP earnings per diluted share for the quarter were $0.27, down 72% from a year ago and up 4% from the previous quarter. Non-GAAP earnings per diluted share were $0.58, down 50% from a year ago and up 14% from the previous quarter.

[0001045810-22-000163:8k_2_02:9]
“We are quickly adapting to the macro environment, correcting inventory levels and paving the way for new products,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-22-000163:8k_2_02:10]
“The ramp of our new platforms ― Ada Lovelace RTX graphics, Hopper AI computing, BlueField and Quantum networking, Orin for autonomous vehicles and robotics, and Omniverse ― is off to a great start and forms the foundation of our next phase of growth.

[0001045810-22-000163:8k_2_02:11]
“NVIDIA’s pioneering work in accelerated computing is more vital than ever. Limited by physics, general purpose computing has slowed to a crawl, just as AI demands more computing. Accelerated computing lets companies achieve orders-of-magnitude increases in productivity while saving money and the environment,” he said.

[0001045810-22-000163:8k_2_02:12]
During the third quarter of fiscal 2023, NVIDIA returned to shareholders $3.75 billion in share repurchases and cash dividends, bringing the return in the first three quarters to $9.29 billion. As of October 30, 2022, the company had $8.28 billion remaining under its share repurchase authorization through December 2023.

[0001045810-22-000163:8k_2_02:13]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on December 22, 2022, to all shareholders of record on December 1, 2022.

[0001045810-22-000163:8k_2_02:14]
Q3 Fiscal 2023 Summary

[0001045810-22-000163:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY23 | Q2 FY23 | Q3 FY22 | Q/Q | Y/Y |
| Revenue | $5,931 | $6,704 | $7,103 | Down 12% | Down 17% |
| Gross margin | 53.6 | % | 43.5 | % | 65.2 | % | Up 10.1 pts | Down 11.6 pts |
| Operating expenses | $2,576 | $2,416 | $1,960 | Up 7% | Up 31% |
| Operating income | $601 | $499 | $2,671 | Up 20% | Down 77% |
| Net income | $680 | $656 | $2,464 | Up 4% | Down 72% |
| Diluted earnings per share | $0.27 | $0.26 | $0.97 | Up 4% | Down 72% |

[0001045810-22-000163:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY23 | Q2 FY23 | Q3 FY22 | Q/Q | Y/Y |
| Revenue | $5,931 | $6,704 | $7,103 | Down 12% | Down 17% |
| Gross margin | 56.1 | % | 45.9 | % | 67.0 | % | Up 10.2 pts | Down 10.9 pts |
| Operating expenses | $1,793 | $1,749 | $1,375 | Up 3% | Up 30% |
| Operating income | $1,536 | $1,325 | $3,386 | Up 16% | Down 55% |
| Net income | $1,456 | $1,292 | $2,973 | Up 13% | Down 51% |
| Diluted earnings per share | $0.58 | $0.51 | $1.17 | Up 14% | Down 50% |

[0001045810-22-000163:8k_2_02:17]
Outlook

[0001045810-22-000163:8k_2_02:18]
NVIDIA’s outlook for the fourth quarter of fiscal 2023 is as follows:

[0001045810-22-000163:8k_2_02:19]
•Revenue is expected to be $6.00 billion, plus or minus 2%.

[0001045810-22-000163:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 63.2% and 66.0%, respectively, plus or minus 50 basis points.

[0001045810-22-000163:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.56 billion and $1.78 billion, respectively.

[0001045810-22-000163:8k_2_02:22]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $40 million, excluding gains and losses from non-affiliated investments.

[0001045810-22-000163:8k_2_02:23]
•GAAP and non-GAAP tax rates are expected to be 9.0%, plus or minus 1%, excluding any discrete items.

[0001045810-22-000163:8k_2_02:24]
Highlights

[0001045810-22-000163:8k_2_02:25]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-22-000163:8k_2_02:26]
Data Center

[0001045810-22-000163:8k_2_02:27]
•Third-quarter revenue was $3.83 billion, up 31% from a year ago and up 1% from the previous quarter.

[0001045810-22-000163:8k_2_02:28]
•Began shipping the NVIDIA® H100 Tensor Core GPU based on the new NVIDIA Hopper™ architecture, with first systems available now.

[0001045810-22-000163:8k_2_02:29]
•Announced at the SC22 supercomputing conference that NVIDIA H100 and Quantum-2 systems are being broadly adopted; that NVIDIA Omniverse™ connects to leading scientific computing visualization software; and that NVIDIA powers 90% of the new systems in the latest TOP500 list of the world’s fastest supercomputers, including the H100-powered system deployed at the Flatiron Institute, in the U.S, which topped the Green500 list of the most-efficient systems.

[0001045810-22-000163:8k_2_02:30]
•Announced a multi-year collaboration with Microsoft to help enterprises train, deploy and scale AI, including state-of-the-art models, through Microsoft Azure, which is deploying tens of thousands of A100 and H100 GPUs.

[0001045810-22-000163:8k_2_02:31]
•Announced a multi-year partnership with Oracle to bring NVIDIA’s full accelerated computing stack to Oracle Cloud Infrastructure, which is deploying tens of thousands more NVIDIA GPUs, including A100 and H100 accelerators.

[0001045810-22-000163:8k_2_02:32]
•Announced a partnership with Nuance Communications to bring AI-based diagnostic tools to clinical radiologists.

[0001045810-22-000163:8k_2_02:33]
•Announced that Rescale is integrating NVIDIA AI Enterprise software into its HPC-as-a-service offering.

[0001045810-22-000163:8k_2_02:34]
•Announced two new large language model cloud AI services — NVIDIA NeMo™ LLM and NVIDIA BioNeMo™ LLM — enabling developers to easily adapt LLMs and deploy customized AI applications for content generation, text summarization, protein structure and biomolecular property predictions, and more.

[0001045810-22-000163:8k_2_02:35]
•Announced that NVIDIA H100 Tensor Core GPUs set records in both AI inference and AI training on all workloads in their first appearances on the MLPerf AI benchmarks.

[0001045810-22-000163:8k_2_02:36]
•Unveiled the second generation of NVIDIA OVX™, powered by the Ada Lovelace GPU architecture and enhanced networking technology, enabling the creation of 3D worlds with groundbreaking real-time graphics, AI and digital-twin simulation capabilities.

[0001045810-22-000163:8k_2_02:37]
•Announced a new data center solution delivering zero-trust security optimized for VMware vSphere 8 combining Dell PowerEdge servers with NVIDIA BlueField® DPUs, NVIDIA GPUs and NVIDIA AI Enterprise software.

[0001045810-22-000163:8k_2_02:38]
Gaming

[0001045810-22-000163:8k_2_02:39]
•Third-quarter revenue was $1.57 billion, down 51% from a year ago and down 23% from the previous quarter.

[0001045810-22-000163:8k_2_02:40]
•Launched GeForce RTX™ 4090, the first Ada Lovelace architecture GPU for gamers and creators, which quickly sold out in many locations. Sales began today of the RTX 4080.

[0001045810-22-000163:8k_2_02:41]
•Introduced NVIDIA DLSS 3, an AI-powered performance multiplier for a new era of NVIDIA RTX™ neural rendering. More than 240 DLSS games and applications are now available, and 35 have announced support for DLSS 3, including Marvel’s Spider-Man Remastered, Cyberpunk 2077 and Microsoft Flight Simulator.

[0001045810-22-000163:8k_2_02:42]
•Shipped 37 new RTX games and apps, pushing up the total available to more than 360.

[0001045810-22-000163:8k_2_02:43]
•Expanded the GeForce NOW™ library with 85+ games, bringing the total available games to 1,400+.

[0001045810-22-000163:8k_2_02:44]
Professional Visualization

[0001045810-22-000163:8k_2_02:45]
•Third-quarter revenue was $200 million, down 65% from a year ago and down 60% from the previous quarter.

[0001045810-22-000163:8k_2_02:46]
•Introduced NVIDIA Omniverse™ Cloud, the company’s first software- and infrastructure-as-a-service offering, with a comprehensive suite of cloud services for artists, developers and enterprise teams to access metaverse applications.

[0001045810-22-000163:8k_2_02:47]
Automotive and Embedded

[0001045810-22-000163:8k_2_02:48]
•Third-quarter revenue was $251 million, up 86% from a year ago and up 14% from the previous quarter.

[0001045810-22-000163:8k_2_02:49]
•Introduced NVIDIA DRIVE Thor™, the company’s 2,000 TFLOPS next-generation centralized computer for safe and secure autonomous vehicles, with Geely-owned ZEEKR integrating it into electric vehicles in 2025.

[0001045810-22-000163:8k_2_02:50]
•Marked the launch of the all-electric Volvo EX90, powered by NVIDIA DRIVE Orin and Xavier™, and Polestar 3, the brand’s first SUV, which runs on the NVIDIA DRIVE™ platform.

[0001045810-22-000163:8k_2_02:51]
•Announced that Hozon Auto’s Neta brand will build future electric vehicles on the NVIDIA DRIVE Orin™ platform, enabling automated driving and intelligent features.

[0001045810-22-000163:8k_2_02:52]
•Announced new DRIVE IX ecosystem partners that are building on the company’s open AI cockpit software stack to deliver interactive features for vehicles.

[0001045810-22-000163:8k_2_02:53]
•Launched Jetson Orin Nano™ system-on-modules that deliver up to 80x the performance over the prior generation for entry-level edge AI and robotics.

[0001045810-22-000163:8k_2_02:54]
CFO Commentary

[0001045810-22-000163:8k_2_02:55]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-22-000163:8k_2_02:56]
Conference Call and Webcast Information

[0001045810-22-000163:8k_2_02:57]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2023 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal 2023.

[0001045810-22-000163:8k_2_02:58]
Non-GAAP Measures

[0001045810-22-000163:8k_2_02:59]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, contributions, IP-related costs, legal settlement costs, restructuring costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable and domestication tax benefit. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-22-000163:8k_2_02:60]
About NVIDIA

[0001045810-22-000163:8k_2_02:61]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and is fueling the creation of the metaverse. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-22-000163:8k_2_02:62]
###

[0001045810-22-000163:8k_2_02:63]
For further information, contact:

[0001045810-22-000163:8k_2_02:64]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-22-000163:8k_2_02:65]
Certain statements in this press release including, but not limited to, statements as to: NVIDIA quickly adapting to the macro environment, correcting inventory levels and paving the way for new products; the ramp of NVIDIA’s new platforms forming the foundation of NVIDIA’s next phase of growth; NVIDIA’s pioneering work in accelerated computing being more vital than ever; AI demanding more computing; accelerated computing letting companies achieve orders-of-magnitude increases in productivity while saving money and the environment; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the fourth quarter of fiscal 2023; NVIDIA’s expected tax rates for the fourth quarter of fiscal 2023; the benefits, impact, performance, and availabilities of our products and technologies; NVIDIA H100 and Quantum-2 systems being broadly adopted; the multi-year collaboration with Microsoft to help enterprises train, deploy and scale AI, including state-of-the-art models; the multi-year partnership with Oracle to bring NVIDIA’s full accelerated computing stack to Oracle Cloud Infrastructure; the partnership with Nuance Communications to bring AI-based diagnostic tools to clinical radiologists; Rescale integrating NVIDIA AI Enterprise into its HPC-as-a-service offering; NVIDIA NeMo LLM and NVIDIA BioNeMo LLM enabling developers to easily adapt LLMs and deploy customized AI applications for content generation, text summarization, protein structure, biomolecular property predictions, and more; the second generation of NVIDIA OVX enabling the creation of 3D worlds with groundbreaking real-time graphics, AI and digital-twin simulation capabilities; the new data center solution delivering zero-trust security optimized for VMware vSphere 8 combining Dell PowerEdge servers with NVIDIA BlueField DPUs, NVIDIA GPUs and NVIDIA AI Enterprise software; NVIDIA Omniverse Cloud providing a comprehensive suite of cloud services for artists, developers and enterprise teams to access metaverse applications; ZEEKR integrating NVIDIA DRIVE Thor into electric vehicles in 2025; Hozon Auto’s Neta brand building future electric vehicles on the NVIDIA DRIVE Orin platform, enabling automated driving and intelligent features; new DRIVE IX ecosystem partners building on the company’s open AI cockpit software stack to deliver interactive features for vehicles; and the Jetson Orin Nano system-on-modules delivering up to 80x the performance over the prior generation for entry-level edge AI and robotics are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-22-000163:8k_2_02:66]
© 2022 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, Jetson Orin Nano, NVIDIA BioNeMo, NVIDIA BlueField, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA DRIVE Thor, NVIDIA Hopper, NVIDIA NeMo, NVIDIA RTX, NVIDIA OVX and NVIDIA Omniverse are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000163:8k_2_02:67]
NVIDIA CORPORATION

[0001045810-22-000163:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-22-000163:8k_2_02:69]
(In millions, except per share data)

[0001045810-22-000163:8k_2_02:70]
(Unaudited)

[0001045810-22-000163:8k_2_02:71]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  |  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue | $ | 5,931 |  |  | $ | 7,103 |  |  | $ | 20,923 |  |  | $ | 19,271 |  |
| Cost of revenue | 2,754 |  |  | 2,472 |  |  | 9,400 |  |  | 6,795 |  |
| Gross profit | 3,177 |  |  | 4,631 |  |  | 11,523 |  |  | 12,476 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,945 |  |  | 1,403 |  |  | 5,387 |  |  | 3,802 |  |
|  | Sales, general and administrative | 631 |  |  | 557 |  |  | 1,815 |  |  | 1,603 |  |
|  | Acquisition termination cost | — |  |  | — |  |  | 1,353 |  |  | — |  |
|  |  | Total operating expenses | 2,576 |  |  | 1,960 |  |  | 8,555 |  |  | 5,405 |  |
| Income from operations | 601 |  |  | 2,671 |  |  | 2,968 |  |  | 7,071 |  |
|  | Interest income | 88 |  |  | 7 |  |  | 152 |  |  | 20 |  |
|  | Interest expense | (65) |  |  | (62) |  |  | (198) |  |  | (175) |  |
|  | Other, net | (11) |  |  | 22 |  |  | (29) |  |  | 160 |  |
|  |  | Other income (expense), net | 12 |  |  | (33) |  |  | (75) |  |  | 5 |  |
| Income before income tax | 613 |  |  | 2,638 |  |  | 2,893 |  |  | 7,076 |  |
| Income tax expense (benefit) | (67) |  |  | 174 |  |  | (61) |  |  | 327 |  |
| Net income | $ | 680 |  |  | $ | 2,464 |  |  | $ | 2,954 |  |  | $ | 6,749 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.27 |  |  | $ | 0.99 |  |  | $ | 1.18 |  |  | $ | 2.71 |  |
|  | Diluted | $ | 0.27 |  |  | $ | 0.97 |  |  | $ | 1.17 |  |  | $ | 2.67 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,483 |  |  | 2,499 |  |  | 2,495 |  |  | 2,493 |  |
|  | Diluted | 2,499 |  |  | 2,538 |  |  | 2,517 |  |  | 2,532 |  |

[0001045810-22-000163:8k_2_02:72]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | October 30, |  | January 30, |
|  |  |  |  | 2022 |  | 2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 13,143 |  |  | $ | 21,208 |  |
|  | Accounts receivable, net |  | 4,908 |  |  | 4,650 |  |
|  | Inventories |  | 4,454 |  |  | 2,605 |  |
|  | Prepaid expenses and other current assets |  | 718 |  |  | 366 |  |
|  |  | Total current assets |  | 23,223 |  |  | 28,829 |  |
| Property and equipment, net |  | 3,774 |  |  | 2,778 |  |
| Operating lease assets |  | 927 |  |  | 829 |  |
| Goodwill |  | 4,372 |  |  | 4,349 |  |
| Intangible assets, net |  | 1,850 |  |  | 2,339 |  |
| Deferred income tax assets |  | 2,762 |  |  | 1,222 |  |
| Other assets |  | 3,580 |  |  | 3,841 |  |
|  |  | Total assets |  | $ | 40,488 |  |  | $ | 44,187 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,491 |  |  | $ | 1,783 |  |
|  | Accrued and other current liabilities |  | 4,115 |  |  | 2,552 |  |
|  | Short-term debt |  | 1,249 |  |  | — |  |
|  |  | Total current liabilities |  | 6,855 |  |  | 4,335 |  |
| Long-term debt |  | 9,701 |  |  | 10,946 |  |
| Long-term operating lease liabilities |  | 798 |  |  | 741 |  |
| Other long-term liabilities |  | 1,785 |  |  | 1,553 |  |
|  |  | Total liabilities |  | 19,139 |  |  | 17,575 |  |
| Shareholders' equity |  | 21,349 |  |  | 26,612 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 40,488 |  |  | $ | 44,187 |  |

[0001045810-22-000163:8k_2_02:73]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 680 |  |  | $ | 2,464 |  |  | $ | 2,954 |  |  | $ | 6,749 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 745 |  |  | 559 |  |  | 1,971 |  |  | 1,453 |  |
| Depreciation and amortization | 406 |  |  | 298 |  |  | 1,118 |  |  | 865 |  |
| Losses (gains) on investments in non affiliates, net | 11 |  |  | (21) |  |  | 35 |  |  | (152) |  |
| Deferred income taxes | (532) |  |  | (20) |  |  | (1,517) |  |  | (182) |  |
| Acquisition termination cost | — |  |  | — |  |  | 1,353 |  |  | — |  |
| Other | (45) |  |  | 10 |  |  | (27) |  |  | 25 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | 410 |  |  | (366) |  |  | (258) |  |  | (1,523) |  |
| Inventories | (563) |  |  | (118) |  |  | (1,848) |  |  | (400) |  |
| Prepaid expenses and other assets | 247 |  |  | (1,575) |  |  | (1,307) |  |  | (1,557) |  |
| Accounts payable | (917) |  |  | 141 |  |  | (358) |  |  | 385 |  |
| Accrued and other current liabilities | (92) |  |  | (8) |  |  | 1,175 |  |  | 159 |  |
| Other long-term liabilities | 42 |  |  | 155 |  |  | 102 |  |  | 253 |  |
| Net cash provided by operating activities | 392 |  |  | 1,519 |  |  | 3,393 |  |  | 6,075 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 5,809 |  |  | 2,545 |  |  | 16,792 |  |  | 7,780 |  |
| Proceeds from sales of marketable securities | 75 |  |  | 211 |  |  | 1,806 |  |  | 916 |  |
| Purchases of marketable securities | (2,188) |  |  | (6,752) |  |  | (9,764) |  |  | (16,020) |  |
| Purchases related to property and equipment and intangible assets | (530) |  |  | (221) |  |  | (1,324) |  |  | (703) |  |
| Acquisitions, net of cash acquired | — |  |  | (203) |  |  | (49) |  |  | (203) |  |
| Investments and other, net | (18) |  |  | (18) |  |  | (83) |  |  | (14) |  |
| Net cash provided by (used in) investing activities | 3,148 |  |  | (4,438) |  |  | 7,378 |  |  | (8,244) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 143 |  |  | 149 |  |  | 349 |  |  | 277 |  |
| Payments related to repurchases of common stock | (3,485) |  |  | — |  |  | (8,826) |  |  | — |  |
| Payments related to tax on restricted stock units | (294) |  |  | (440) |  |  | (1,131) |  |  | (1,282) |  |
| Dividends paid | (100) |  |  | (100) |  |  | (300) |  |  | (298) |  |
| Principal payments on property and equipment and intangible assets | (18) |  |  | (22) |  |  | (54) |  |  | (62) |  |
| Issuance of debt, net of issuance costs | — |  |  | (8) |  |  | — |  |  | 4,977 |  |
| Repayment of debt | — |  |  | (1,000) |  |  | — |  |  | (1,000) |  |
| Other | 1 |  |  | — |  |  | 1 |  |  | (2) |  |
| Net cash provided by (used in) financing activities | (3,753) |  |  | (1,421) |  |  | (9,961) |  |  | 2,610 |  |
| Change in cash and cash equivalents | (213) |  |  | (4,340) |  |  | 810 |  |  | 441 |  |
| Cash and cash equivalents at beginning of period | 3,013 |  |  | 5,628 |  |  | 1,990 |  |  | 847 |  |
| Cash and cash equivalents at end of period | $ | 2,800 |  |  | $ | 1,288 |  |  | $ | 2,800 |  |  | $ | 1,288 |  |

[0001045810-22-000163:8k_2_02:74]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 30, |  | July 31, |  | October 31, |  | October 30, |  | October 31, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP gross profit |  | $ | 3,177 |  |  | $ | 2,915 |  |  | $ | 4,631 |  |  | $ | 11,523 |  |  | $ | 12,476 |  |
| GAAP gross margin |  | 53.6 | % |  | 43.5 | % |  | 65.2 | % |  | 55.1 | % |  | 64.7 | % |
|  | Acquisition-related and other costs (A) |  | 120 |  |  | 121 |  |  | 86 |  |  | 335 |  |  | 258 |  |
|  | Stock-based compensation expense (B) |  | 32 |  |  | 38 |  |  | 44 |  |  | 108 |  |  | 102 |  |
|  | IP-related costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Non-GAAP gross profit |  | $ | 3,329 |  |  | $ | 3,074 |  |  | $ | 4,761 |  |  | $ | 11,966 |  |  | $ | 12,844 |  |
| Non-GAAP gross margin |  | 56.1 | % |  | 45.9 | % |  | 67.0 | % |  | 57.2 | % |  | 66.6 | % |
| GAAP operating expenses |  | $ | 2,576 |  |  | $ | 2,416 |  |  | $ | 1,960 |  |  | $ | 8,555 |  |  | $ | 5,405 |  |
|  | Stock-based compensation expense (B) |  | (713) |  |  | (611) |  |  | (515) |  |  | (1,863) |  |  | (1,351) |  |
|  | Acquisition-related and other costs (A) |  | (54) |  |  | (54) |  |  | (70) |  |  | (164) |  |  | (224) |  |
|  | Restructuring costs (C) |  | (16) |  |  | — |  |  | — |  |  | (16) |  |  | — |  |
|  | Contributions |  | — |  |  | (2) |  |  | — |  |  | (2) |  |  | — |  |
|  | Acquisition termination cost |  | — |  |  | — |  |  | — |  |  | (1,353) |  |  | — |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | — |  |  | (7) |  |  | — |  |
| Non-GAAP operating expenses |  | $ | 1,793 |  |  | $ | 1,749 |  |  | $ | 1,375 |  |  | $ | 5,150 |  |  | $ | 3,830 |  |
| GAAP income from operations |  | $ | 601 |  |  | $ | 499 |  |  | $ | 2,671 |  |  | $ | 2,968 |  |  | $ | 7,071 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 935 |  |  | 826 |  |  | 715 |  |  | 3,848 |  |  | 1,943 |  |
| Non-GAAP income from operations |  | $ | 1,536 |  |  | $ | 1,325 |  |  | $ | 3,386 |  |  | $ | 6,816 |  |  | $ | 9,014 |  |
| GAAP other income (expense), net |  | $ | 12 |  |  | $ | (24) |  |  | $ | (33) |  |  | $ | (75) |  |  | $ | 5 |  |
|  | (Gains) losses from non-affiliated investments |  | 11 |  |  | 7 |  |  | (20) |  |  | 36 |  |  | (153) |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Non-GAAP other income (expense), net |  | $ | 24 |  |  | $ | (16) |  |  | $ | (52) |  |  | $ | (36) |  |  | $ | (145) |  |
| GAAP net income |  | $ | 680 |  |  | $ | 656 |  |  | $ | 2,464 |  |  | $ | 2,954 |  |  | $ | 6,749 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 947 |  |  | 833 |  |  | 696 |  |  | 3,887 |  |  | 1,793 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (171) |  |  | (197) |  |  | (187) |  |  | (649) |  |  | (381) |  |
|  | Domestication tax adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | (252) |  |
| Non-GAAP net income |  | $ | 1,456 |  |  | $ | 1,292 |  |  | $ | 2,973 |  |  | $ | 6,192 |  |  | $ | 7,909 |  |

[0001045810-22-000163:8k_2_02:75]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 30, |  | July 31, |  | October 31, |  | October 30, |  | October 31, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.27 |  |  | $ | 0.26 |  |  | $ | 0.97 |  |  | $ | 1.17 |  |  | $ | 2.67 |  |
|  | Non-GAAP |  | $ | 0.58 |  |  | $ | 0.51 |  |  | $ | 1.17 |  |  | $ | 2.46 |  |  | $ | 3.12 |  |
| Weighted average shares used in diluted net income per share computation |  | 2,499 |  |  | 2,516 |  |  | 2,538 |  |  | 2,517 |  |  | 2,532 |  |
| GAAP net cash provided by operating activities |  | $ | 392 |  |  | $ | 1,271 |  |  | $ | 1,519 |  |  | $ | 3,393 |  |  | $ | 6,075 |  |
|  | Purchases related to property and equipment and intangible assets |  | (530) |  |  | (432) |  |  | (221) |  |  | (1,324) |  |  | (703) |  |
|  | Principal payments on property and equipment |  | (18) |  |  | (15) |  |  | (22) |  |  | (54) |  |  | (62) |  |
| Free cash flow |  | $ | (156) |  |  | $ | 824 |  |  | $ | 1,276 |  |  | $ | 2,015 |  |  | $ | 5,310 |  |

[0001045810-22-000163:8k_2_02:76]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 30, |  | July 31, |  | October 31, |  | October 30, |  | October 31, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Cost of revenue |  | $ | 120 |  |  | $ | 121 |  |  | $ | 86 |  |  | $ | 335 |  |  | $ | 258 |  |
|  | Research and development |  | $ | 10 |  |  | $ | 10 |  |  | $ | 7 |  |  | $ | 29 |  |  | $ | 10 |  |
|  | Sales, general and administrative |  | $ | 44 |  |  | $ | 44 |  |  | $ | 63 |  |  | $ | 135 |  |  | $ | 214 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 30, |  | July 31, |  | October 31, |  | October 30, |  | October 31, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Cost of revenue |  | $ | 32 |  |  | $ | 38 |  |  | $ | 44 |  |  | $ | 108 |  |  | $ | 102 |  |
|  | Research and development |  | $ | 530 |  |  | $ | 452 |  |  | $ | 363 |  |  | $ | 1,365 |  |  | $ | 935 |  |
|  | Sales, general and administrative |  | $ | 183 |  |  | $ | 159 |  |  | $ | 152 |  |  | $ | 498 |  |  | $ | 416 |  |
| (C) Costs related to Russia branch office closure. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-22-000163:8k_2_02:77]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2023 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 63.2 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 2.8 | % |
| Non-GAAP gross margin |  | 66.0 | % |
| GAAP operating expenses |  | $ | 2,560 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (780) |  |
| Non-GAAP operating expenses |  | $ | 1,780 |  |
