# NVDA MD&A — 0001045810-22-000166


## mdna

[0001045810-22-000166:mdna:1]
[same as prior period, unchanged from 0001045810-22-000147:mdna:1]

[0001045810-22-000166:mdna:2]
[same as prior period, unchanged from 0001045810-22-000147:mdna:2]

[0001045810-22-000166:mdna:3]
[same as prior period, unchanged from 0001045810-22-000147:mdna:3]

[0001045810-22-000166:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, Mellanox, NVIDIA AI Enterprise, NVIDIA BioNeMo, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA DRIVE Thor, NVIDIA Hopper, NVIDIA Jetson, NVIDIA NeMo, NVIDIA Omniverse, NVIDIA RTX and Quadro are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000166:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 30, 2022 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q, of our Quarterly Reports on Form 10-Q for the fiscal quarters ended May 1, 2022 and July 31, 2022 and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase or sell shares of our common stock.

[0001045810-22-000166:mdna:6]
[same as prior period, unchanged from 0001045810-22-000147:mdna:6]

[0001045810-22-000166:mdna:7]
[same as prior period, unchanged from 0001045810-22-000147:mdna:7]

[0001045810-22-000166:mdna:8]
[same as prior period, unchanged from 0001045810-22-000147:mdna:8]

[0001045810-22-000166:mdna:9]
Our two operating segments are "Compute & Networking" and "Graphics," as described in Note 15 of the Notes to Condensed Consolidated Financial Statements.

[0001045810-22-000166:mdna:10]
[same as prior period, unchanged from 0001045810-22-000147:mdna:10]

[0001045810-22-000166:mdna:11]
[same as prior period, unchanged from 0001045810-22-000147:mdna:11]

[0001045810-22-000166:mdna:12]
[same as prior period, unchanged from 0001045810-22-000147:mdna:15]

[0001045810-22-000166:mdna:13]
Because we do not manufacture the semiconductors used for our products, we are dependent on third parties to manufacture and assemble our products. Our manufacturing lead times are very long, which requires us to make estimates of customers’ future demand. At the same time, we do not have a guaranteed supply of wafers, components and capacity, and our supply deliveries and production may be non-linear within a quarter or year, which has previously caused changes to expected revenue and cash flows, and which may reoccur in the future. If our estimates of customer

[0001045810-22-000166:mdna:14]
demand are ultimately inaccurate, as we have experienced from time to time, these conditions could lead to a significant mismatch between supply and demand. This mismatch has resulted in both product shortages and excess inventory, has varied across our market platforms, and significantly harmed our financial results.

[0001045810-22-000166:mdna:15]
We build finished products and maintain inventory in advance of anticipated demand. In periods of shortages impacting the semiconductor industry and/or limited supply or capacity in our supply chain, as we have experienced in the past, the lead time on our orders for certain supply has extended to more than twelve months, compared to a historical lead time of approximately six months. Extended lead times may continue if we experience other supply constraints caused by natural disasters or other events. As a result, we have paid premiums and provided deposits to secure future supply and capacity, which have increased our product costs, and may need to continue to do so in the future. We may not have the ability to reduce our supply commitments at the same rate or at all if our revenue declines. Our supply, which includes inventory on hand, purchase obligations and prepaid supply agreements, has grown significantly due to current supply chain conditions and complexity of our products. Purchase obligations and prepaid supply agreements represent approximately three quarters of our total supply.

[0001045810-22-000166:mdna:16]
Demand for our products is based on many factors, including our product introductions and transitions, time to market, competitor product releases and announcements, competing technologies, and changes in macroeconomic conditions, including rising inflation and fluctuating interest rates. Each of these factors has previously impacted, and can in the future impact, the timing and volume of our revenue. Our demand predictions may not be correct, as we have experienced from time to time. Product transitions are complex and frequently negatively impact our revenue as we manage shipments of legacy prior architecture products and channel partners prepare and adjust to support new products. We have recently begun transitioning architectures for both our Gaming and Data Center products, which may impair our ability to predict demand and impact our supply mix. We may experience, and have in the past experienced, reduced demand for current generation architectures when customers anticipate transitions. Although we have previously sold multiple product architectures at the same time, this trend may not continue for current and future architecture transitions. If we are unable to execute our architectural transitions as planned for any reason, our financial results may be negatively impacted. Our ability to sell certain products has in the past been and can in the future be impeded if components from third parties that are necessary for the finished product are not available. Additionally, we sell most of our products through channel partners, who sell to retailers, distributors, and/or end customers. As a result, the decisions made by our channel partners, retailers and distributors in response to changing market conditions and changes in end user demand for our products have impacted and could in the future continue to impact our ability to properly forecast demand, particularly as they are based on estimates provided by various downstream parties.

[0001045810-22-000166:mdna:17]
COVID-19-related disruptions and lockdowns in China have created and may continue to create supply and logistics constraints. The war in Ukraine has further strained global supply chains and may in the future result in a shortage of key materials that our suppliers, including our foundry partners, require to satisfy our needs.

[0001045810-22-000166:mdna:18]
Our products are designed for the Data Center, Gaming, Professional Visualization and Automotive markets. The use of our GPUs for use cases other than that for which they were designed and marketed, including new and unexpected use cases, has impacted and can in the future impact demand for our products, including by leading to inconsistent spikes and drops in demand. For example, many years ago, our Gaming GPUs began to be used for digital currency mining, including blockchain-based platforms such as Ethereum. It is difficult for us to estimate with any reasonable degree of precision the past or current impact of cryptocurrency mining, or forecast the future impact of cryptocurrency mining, on demand for our products. Volatility in the cryptocurrency market, including new compute technologies, price changes in cryptocurrencies, government cryptocurrency policies and regulations, new cryptocurrency standards, and changes in the method of verifying blockchain transactions, has impacted and can in the future impact cryptocurrency mining and demand for our products and can further impact our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the recently implemented Ethereum 2.0 merge may decrease the usage of GPUs for Ethereum mining as well as create increased aftermarket sales of our GPUs, which could negatively impact retail prices for our GPUs and reduce demand for our new GPUs. We previously introduced Lite Hash Rate, or LHR, GeForce GPUs with limited Ethereum mining capability and provided CMP products in an effort to address demand from gamers and direct miners to CMP. With the Ethereum 2.0 merge, NVIDIA Ampere and Ada Lovelace architectures no longer include LHR. In addition, our new products or previously sold products may be resold online or on the unauthorized “gray market,” which also makes demand forecasting difficult. Gray market products or reseller marketplaces compete with our distribution channels.

[0001045810-22-000166:mdna:19]
During the third quarter of fiscal year 2023, the U.S. government, or USG, announced new license requirements that, with certain exceptions, impact exports to China (including Hong Kong) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits and our A100X. The

[0001045810-22-000166:mdna:20]
25

[0001045810-22-000166:mdna:21]
new license requirements also apply to any future NVIDIA integrated circuit achieving both peak performance and chip-to-chip I/O performance equal to or greater than thresholds that are roughly equivalent to the A100, as well as any system or board that includes those circuits. We are also required to obtain a license to export a wide array of products, including networking products destined for certain end users and any system in China that can achieve single precision performance of 200 Petaops, or double precision performance of 100 Petaops, within a 41,600 cubic feet envelope.

[0001045810-22-000166:mdna:22]
We will be required to transition certain operations out of China, which could be costly and time consuming, and adversely affect our research and development and supply and distribution operations, as well as our revenue, during any such transition period.

[0001045810-22-000166:mdna:23]
We have engaged with customers in China to satisfy their demand with products not subject to the new license requirements, such as our new A800 offering. To the extent that a customer requires products covered by the new license requirements, we may seek a license for the customer but have no assurance that the USG will grant any exemptions or licenses for any customer, or that the USG will act on them in a timely manner. The new requirements may have a disproportionate impact on NVIDIA and may disadvantage NVIDIA against certain of our competitors who sell products that are not subject to the new restrictions or may be able to acquire licenses for their products.

[0001045810-22-000166:mdna:24]
Our revenue, profitability, cash flows, and competitive position may be harmed if customers in China do not want to purchase our alternative product offerings, if we are unable to provide contractual warranty or other extended service obligations, or if the USG does not grant licenses in a timely manner or denies licenses to significant customers. Even if the USG grants any requested licenses, the licenses may be temporary or impose burdensome conditions that we cannot or choose not to fulfill. The new requirements may benefit certain of our competitors, as the licensing process will make our sales and support efforts more cumbersome and less certain, and encourage customers in China to pursue alternatives to our products, including semiconductor suppliers based in China, Europe, and Israel.

[0001045810-22-000166:mdna:25]
[same as prior period, unchanged from 0001045810-22-000147:mdna:28]

[0001045810-22-000166:mdna:26]
During the third quarter of fiscal year 2023, we reopened our offices worldwide. We have and expect to incur incremental expenses and related in-office costs as we resume onsite services.

[0001045810-22-000166:mdna:27]
Restrictions may be imposed or reinstated as the pandemic resurfaces, such as ongoing lockdown measures due to COVID-19 containment efforts in China. End customer sales for our products in China have been negatively impacted and this impact may continue if future and continued lockdowns occur. These ongoing COVID-19-related disruptions and lockdowns in China have created and may continue to create supply chain and logistics constraints. Challenges in estimating demand could become more pronounced or volatile in the future on both a global and regional basis.

[0001045810-22-000166:mdna:28]
[same as prior period, unchanged from 0001045810-22-000147:mdna:32]

[0001045810-22-000166:mdna:29]
During the first quarter of fiscal year 2023, we paused direct sales to Russia. Direct sales to Russia in fiscal year 2022 were immaterial. Our revenue to partners that sell into Russia may be negatively impacted due to the war in Ukraine and we estimate that in fiscal year 2022, Russia accounted for approximately 2% of total end customer sales and 4% of Gaming end customer sales. During the third quarter of fiscal year 2023, we closed business operations in Russia.

[0001045810-22-000166:mdna:30]
[same as prior period, unchanged from 0001045810-22-000147:mdna:12]

[0001045810-22-000166:mdna:31]
In February 2022, NVIDIA and SoftBank announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing.

[0001045810-22-000166:mdna:32]
[same as prior period, unchanged from 0001045810-22-000147:mdna:41]

[0001045810-22-000166:mdna:33]
Third Quarter of Fiscal Year 2023 Summary

[0001045810-22-000166:mdna:34]
|  | Three Months Ended |  |  |  |  |
|  | October 30, 2022 |  | July 31, 2022 |  | October 31, 2021 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 5,931 |  |  | $ | 6,704 |  |  | $ | 7,103 |  |  | (12) | % |  | (17) | % |
| Gross margin | 53.6 | % |  | 43.5 | % |  | 65.2 | % |  | 10.1 pts |  | (11.6) pts |
| Operating expenses | $ | 2,576 |  |  | $ | 2,416 |  |  | $ | 1,960 |  |  | 7 | % |  | 31 | % |
| Income from operations | $ | 601 |  |  | $ | 499 |  |  | $ | 2,671 |  |  | 20 | % |  | (77) | % |
| Net income | $ | 680 |  |  | $ | 656 |  |  | $ | 2,464 |  |  | 4 | % |  | (72) | % |
| Net income per diluted share | $ | 0.27 |  |  | $ | 0.26 |  |  | $ | 0.97 |  |  | 4 | % |  | (72) | % |

[0001045810-22-000166:mdna:35]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

[0001045810-22-000166:mdna:36]
Revenue for the third quarter of fiscal year 2023 was $5.93 billion, down 17% from a year ago and down 12% sequentially.

[0001045810-22-000166:mdna:37]
Data Center revenue was up 31% from a year ago and up 1% sequentially. Year-on-year growth was broad-based across U.S. cloud service providers, consumer internet companies and other vertical industries. Sequential growth was impacted by softness in China. We started shipping our flagship H100 data center GPU based on the new Hopper-architecture.

[0001045810-22-000166:mdna:38]
During the third quarter, the U.S. government announced new restrictions on exports of our A100 and H100-based products to China, and any product destined for certain systems or entities in China. These restrictions impacted third-quarter revenue, with the decline largely offset by sales of alternative products into China.

[0001045810-22-000166:mdna:39]
Gaming revenue was down 51% from a year ago and down 23% sequentially, reflecting lower sell-in to partners to help align channel inventory levels with current demand expectations as macroeconomic conditions and COVID lockdowns in China continue to weigh on consumer demand. The year-on-year decrease was driven by lower GPU sales for both desktops and laptops; the sequential decline was primarily driven by lower GPU sales for laptops. We believe the recent transition in verifying Ethereum cryptocurrency transactions from proof-of-work to proof-of-stake has reduced the utility of GPUs for cryptocurrency mining. This may have contributed to increased aftermarket sales of our GPUs in certain markets, potentially impacting demand for some of our products, particularly in the low-end.

[0001045810-22-000166:mdna:40]
Professional Visualization revenue was down 65% from a year ago and down 60% sequentially, reflecting lower sell-in to partners to help align channel inventory levels with current demand expectations.

[0001045810-22-000166:mdna:41]
Automotive revenue was up 86% from a year ago and up 14% sequentially, primarily driven by revenue from self-driving solutions.

[0001045810-22-000166:mdna:42]
OEM and Other revenue was down 69% from a year ago and down 48% sequentially. The sequential decline was driven by lower Jetson and notebook OEM sales. Cryptocurrency Mining Processor (CMP) revenue was nominal in the current and prior quarter, and $105 million in the third quarter of fiscal year 2022.

[0001045810-22-000166:mdna:43]
Gross margin for the third quarter was down 11.6% from a year earlier, primarily due to a $702 million inventory charge, largely relating to lower Data Center demand in China, partially offset by a warranty-related benefit of approximately $70 million. Sequentially, gross margin was up 10.1% primarily due to lower inventory charges compared with the second quarter. The $702 million inventory charge consists of approximately $354 million for inventory on hand and approximately $348 million for inventory purchase obligations in excess of our current demand projections.

[0001045810-22-000166:mdna:44]
Operating expenses increased primarily due to compensation and data center infrastructure. The year-on-year increase also reflects employee growth.

[0001045810-22-000166:mdna:45]
[same as prior period, unchanged from 0001045810-22-000147:mdna:60]

[0001045810-22-000166:mdna:46]
Cash, cash equivalents and marketable securities were $13.14 billion, down from $19.30 billion a year ago and down from $17.04 billion a quarter ago. The year-on-year and sequential decreases reflect share repurchases and changes in operating cash flow.

[0001045810-22-000166:mdna:47]
During the third quarter and first nine months of fiscal year 2023, we returned $3.75 billion and $9.29 billion to shareholders in the form of share repurchases and cash dividends, respectively. As of the end of the third quarter of fiscal year 2023, we had $8.28 billion remaining under our share repurchase authorization through December 2023.

[0001045810-22-000166:mdna:48]
[same as prior period, unchanged from 0001045810-22-000147:mdna:51]

[0001045810-22-000166:mdna:49]
In Data Center, we began shipping production samples of the NVIDIA H100 Tensor Core GPU; announced a multi-year collaboration with Microsoft to build a cloud-based AI supercomputer; announced a multi-year partnership with Oracle to bring NVIDIA’s full accelerated computing stack to Oracle Cloud Infrastructure; announced that Rescale is integrating NVIDIA AI Enterprise into its HPC-as-service offering; announced two new large language model cloud AI services — NVIDIA NeMo LLM and NVIDIA BioNeMo LLM Service; and announced a new data center solution delivering zero-trust security optimized for VMware vSphere 8.

[0001045810-22-000166:mdna:50]
In Gaming, we began shipping GeForce RTX 4090; introduced NVIDIA DLSS 3; and expanded the GeForce NOW library with 85+ games bringing the total available games to 1,400+.

[0001045810-22-000166:mdna:51]
In Professional Visualization, we introduced NVIDIA Omniverse Cloud.

[0001045810-22-000166:mdna:52]
In Automotive, we introduced NVIDIA DRIVE Thor; announced that Hozon Auto’s Neta brand will build future EVs on the NVIDIA DRIVE Orin platform; marked the launch of Polestar 3; and announced new DRIVE IX ecosystem partners.

[0001045810-22-000166:mdna:53]
[same as prior period, unchanged from 0001045810-22-000147:mdna:56]

[0001045810-22-000166:mdna:54]
[same as prior period, unchanged from 0001045810-22-000147:mdna:57]

[0001045810-22-000166:mdna:55]
[same as prior period, unchanged from 0001045810-22-000147:mdna:58]

[0001045810-22-000166:mdna:56]
[same as prior period, unchanged from 0001045810-22-000147:mdna:59]

[0001045810-22-000166:mdna:57]
[same as prior period, unchanged from 0001045810-22-000147:mdna:61]

[0001045810-22-000166:mdna:58]
[same as prior period, unchanged from 0001045810-22-000147:mdna:62]

[0001045810-22-000166:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 46.4 |  |  | 34.8 |  |  | 44.9 |  |  | 35.3 |  |
| Gross profit | 53.6 |  |  | 65.2 |  |  | 55.1 |  |  | 64.7 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 32.8 |  |  | 19.8 |  |  | 25.7 |  |  | 19.7 |  |
| Sales, general and administrative | 10.6 |  |  | 7.8 |  |  | 8.7 |  |  | 8.3 |  |
| Acquisition termination cost | — |  |  | — |  |  | 6.5 |  |  | — |  |
| Total operating expenses | 43.4 |  |  | 27.6 |  |  | 40.9 |  |  | 28.0 |  |
| Income from operations | 10.2 |  |  | 37.6 |  |  | 14.2 |  |  | 36.7 |  |
| Interest income | 1.5 |  |  | 0.1 |  |  | 0.7 |  |  | 0.1 |  |
| Interest expense | (1.1) |  |  | (0.9) |  |  | (0.9) |  |  | (0.9) |  |
| Other, net | (0.2) |  |  | 0.3 |  |  | (0.1) |  |  | 0.8 |  |
| Other income (expense), net | 0.2 |  |  | (0.5) |  |  | (0.3) |  |  | — |  |
| Income before income tax | 10.4 |  |  | 37.1 |  |  | 13.9 |  |  | 36.7 |  |
| Income tax expense (benefit) | (1.1) |  |  | 2.4 |  |  | (0.3) |  |  | 1.7 |  |
| Net income | 11.5 | % |  | 34.7 | % |  | 14.2 | % |  | 35.0 | % |

[0001045810-22-000166:mdna:60]
[same as prior period, unchanged from 0001045810-22-000147:mdna:64]

[0001045810-22-000166:mdna:61]
[same as prior period, unchanged from 0001045810-22-000147:mdna:65]

[0001045810-22-000166:mdna:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30,2022 |  | October 31,2021 |  | $Change |  | %Change |  | October 30,2022 |  | October 31,2021 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 3,816 |  |  | $ | 3,011 |  |  | $ | 805 |  |  | 27 | % |  | $ | 11,395 |  |  | $ | 7,821 |  |  | $ | 3,574 |  |  | 46 | % |
| Graphics | 2,115 |  |  | 4,092 |  |  | (1,977) |  |  | (48) | % |  | 9,528 |  |  | 11,450 |  |  | (1,922) |  |  | (17) | % |
| Total | $ | 5,931 |  |  | $ | 7,103 |  |  | $ | (1,172) |  |  | (17) | % |  | $ | 20,923 |  |  | $ | 19,271 |  |  | $ | 1,652 |  |  | 9 | % |

[0001045810-22-000166:mdna:63]
Compute & Networking - The year-on-year growth was broad-based across U.S. cloud service providers, consumer internet companies and other vertical industries. We started shipping our flagship H100 data center GPU based on the new Hopper-architecture. CMP contributed an insignificant amount in the third quarter and first nine months of fiscal year 2023 compared to $105 million in the third quarter and $526 million in the first nine months of fiscal year 2022.

[0001045810-22-000166:mdna:64]
Graphics - The year-on-year decreases primarily reflect lower sell-in to partners to help align channel inventory levels with current demand expectations as macroeconomic conditions and COVID lockdowns in China continue to weigh on consumer demand.

[0001045810-22-000166:mdna:65]
[same as prior period, unchanged from 0001045810-22-000147:mdna:70]

[0001045810-22-000166:mdna:66]
Revenue from sales to customers outside of the United States accounted for 64% and 71% of total revenue for the third quarter and first nine months of fiscal year 2023, respectively, and 84% and 85% of total revenue for the third quarter and first nine months of fiscal year 2022, respectively. Revenue by geographic region is allocated to countries based on the billed location even if the revenue may be attributable to end customers in a different location.

[0001045810-22-000166:mdna:67]
One customer represented 10% of our total revenue for the third quarter of fiscal year 2023 and was attributable primarily to the Compute & Networking segment. No customer represented 10% or more of total revenue for the first nine months of fiscal year 2023 and for the third quarter and first nine months of fiscal year 2022.

[0001045810-22-000166:mdna:68]
[same as prior period, unchanged from 0001045810-22-000147:mdna:74]

[0001045810-22-000166:mdna:69]
Our overall gross margin decreased to 53.6% and 55.1% for the third quarter and first nine months of fiscal year 2023, respectively, from 65.2% and 64.7% for the third quarter and first nine months of fiscal year 2022, respectively. These decreases were primarily due to $702 million and $2.01 billion of inventory provisions in the third quarter and first nine months of fiscal year 2023, respectively. The third quarter of fiscal year 2023 included a warranty-related benefit of approximately $70 million. The $702 million inventory provision consists of approximately $354 million for inventory on hand and approximately $348 million for inventory purchase obligations in excess of our current demand projections. The $2.01 billion inventory provision in the first nine months of fiscal year 2023 consists of approximately $942 million for inventory on hand and approximately $1.07 billion for inventory purchase obligations in excess of our current demand projections.

[0001045810-22-000166:mdna:70]
Inventory provisions totaled $702 million and $107 million for the third quarter of fiscal years 2023 and 2022, respectively. Sales of inventory that was previously written-off or down totaled $21 million and $48 million for the third quarter of fiscal years 2023 and 2022, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 11.5% and 0.8% in the third quarter of fiscal years 2023 and 2022, respectively.

[0001045810-22-000166:mdna:71]
Inventory provisions totaled $2.01 billion and $238 million for the first nine months of fiscal years 2023 and 2022, respectively. Sales of inventory that was previously written-off or down totaled $59 million and $89 million for the first nine months of fiscal years 2023 and 2022, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 9.3% and 0.8% in the first nine months of fiscal years 2023 and 2022, respectively.

[0001045810-22-000166:mdna:72]
Compute & Networking - The gross margin of our Compute & Networking segment decreased during the third quarter and first nine months of fiscal year 2023 compared to the third quarter and first nine months of fiscal year 2022, primarily due to inventory provisions.

[0001045810-22-000166:mdna:73]
Graphics - The gross margin of our Graphics segment decreased during the third quarter of fiscal year 2023 compared to the third quarter of fiscal year 2022 primarily due to a lower-end mix within GeForce GPUs. The decrease in the first nine months of fiscal year 2023 compared to the first nine months of fiscal year 2022 was primarily related to inventory and related provisions and pricing programs.

[0001045810-22-000166:mdna:74]
[same as prior period, unchanged from 0001045810-22-000147:mdna:80]

[0001045810-22-000166:mdna:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30,2022 |  | October 31,2021 |  | $Change |  | %Change |  | October 30,2022 |  | October 31,2021 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 1,945 |  |  | $ | 1,403 |  |  | $ | 542 |  |  | 39 | % |  | $ | 5,387 |  |  | $ | 3,802 |  |  | $ | 1,585 |  |  | 42 | % |
| % of net revenue | 33 | % |  | 20 | % |  |  |  |  |  | 26 | % |  | 20 | % |  |  |  |  |
| Sales, general and administrative expenses | 631 |  |  | 557 |  |  | 74 |  |  | 13 | % |  | 1,815 |  |  | 1,603 |  |  | 212 |  |  | 13 | % |
| % of net revenue | 11 | % |  | 8 | % |  |  |  |  |  | 9 | % |  | 8 | % |  |  |  |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | — | % |  | 1,353 |  |  | — |  |  | 1,353 |  |  | (100) | % |
| % of net revenue | — | % |  | — | % |  |  |  |  |  | 6 | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 2,576 |  |  | $ | 1,960 |  |  | $ | 616 |  |  | 31 | % |  | $ | 8,555 |  |  | $ | 5,405 |  |  | $ | 3,150 |  |  | 58 | % |

[0001045810-22-000166:mdna:76]
Research and development expense increases for the third quarter of fiscal year 2023 were primarily driven by compensation, employee growth and data center infrastructure. Research and development expense increases for the first nine months of fiscal year 2023 were primarily driven by compensation, employee growth and engineering development costs.

[0001045810-22-000166:mdna:77]
Sales, general and administrative expense increases were primarily driven by compensation and employee growth.

[0001045810-22-000166:mdna:78]
[same as prior period, unchanged from 0001045810-22-000147:mdna:84]

[0001045810-22-000166:mdna:79]
[same as prior period, unchanged from 0001045810-22-000147:mdna:85]

[0001045810-22-000166:mdna:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30,2022 |  | October 31,2021 |  | $Change |  | %Change |  | October 30,2022 |  | October 31,2021 |  | $Change |  | %Change |
|  | ($ in millions) |
| Interest income | $ | 88 |  |  | $ | 7 |  |  | $ | 81 |  |  | 1,157 | % |  | $ | 152 |  |  | $ | 20 |  |  | $ | 132 |  |  | 660 | % |
| Interest expense | (65) |  |  | (62) |  |  | (3) |  |  | 5 | % |  | (198) |  |  | (175) |  |  | (23) |  |  | 13 | % |
| Other, net | (11) |  |  | 22 |  |  | (33) |  |  | (150) | % |  | (29) |  |  | 160 |  |  | (189) |  |  | (118) | % |
| Total | $ | 12 |  |  | $ | (33) |  |  | $ | 45 |  |  | (136) | % |  | $ | (75) |  |  | $ | 5 |  |  | $ | (80) |  |  | (1,600) | % |

[0001045810-22-000166:mdna:81]
[same as prior period, unchanged from 0001045810-22-000147:mdna:87]

[0001045810-22-000166:mdna:82]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our notes. The increase in expense for the first nine months of fiscal year 2023 compared to the first nine months of fiscal year 2022 reflects interest on the $5.00 billion note issued in June 2021.

[0001045810-22-000166:mdna:83]
Other, net, consists primarily of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. Changes in other, net, compared to the third quarter and first nine months of fiscal year 2022 were primarily driven by mark-to-market impact from publicly traded equity investments and changes in value from our non-affiliated private investments. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information regarding our investments in non-affiliated entities.

[0001045810-22-000166:mdna:84]
[same as prior period, unchanged from 0001045810-22-000147:mdna:90]

[0001045810-22-000166:mdna:85]
We recognized an income tax benefit of $67 million and $61 million for the third quarter and first nine months of fiscal year 2023, respectively, and an income tax expense of $174 million and $327 million for the third quarter and first nine months of fiscal year 2022, respectively. Income tax as a percentage of income before income tax was a benefit of 10.9% and 2.1% for the third quarter and first nine months of fiscal year 2023, respectively, and an expense of 6.6% and 4.6% for the third quarter and first nine months of fiscal year 2022, respectively.

[0001045810-22-000166:mdna:86]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2023 as compared to the same periods of fiscal year 2022 was primarily due to the increased tax benefit of the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit, relative to a lower expected profitability. This is partially offset by the impact of an increase in the proportion of earnings subject to U.S. tax in fiscal year 2023 and the one-time discrete benefit from re-valuing certain deferred tax assets in connection with the Domestication in fiscal year 2022.

[0001045810-22-000166:mdna:87]
[same as prior period, unchanged from 0001045810-22-000147:mdna:93]

[0001045810-22-000166:mdna:88]
|  | October 30, 2022 |  | January 30, 2022 |
|  | (In millions) |
| Cash and cash equivalents | $ | 2,800 |  |  | $ | 1,990 |  |
| Marketable securities | 10,343 |  |  | 19,218 |  |
| Cash, cash equivalents and marketable securities | $ | 13,143 |  |  | $ | 21,208 |  |

[0001045810-22-000166:mdna:89]
31

[0001045810-22-000166:mdna:90]
|  | Nine Months Ended |
|  | October 30, 2022 |  | October 31, 2021 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 3,393 |  |  | $ | 6,075 |  |
| Net cash provided by (used in) investing activities | $ | 7,378 |  |  | $ | (8,244) |  |
| Net cash provided by (used in) financing activities | $ | (9,961) |  |  | $ | 2,610 |  |

[0001045810-22-000166:mdna:91]
As of October 30, 2022, we had $13.14 billion in cash, cash equivalents and marketable securities, a decrease of $8.07 billion from the end of fiscal year 2022. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-22-000166:mdna:92]
Cash provided by operating activities decreased in the first nine months of fiscal year 2023 compared to the first nine months of fiscal year 2022, primarily due to tax payments, and a decrease in net income adjusted for certain non-cash items, such as the Arm acquisition termination cost of $1.35 billion, partially offset by changes in working capital.

[0001045810-22-000166:mdna:93]
Cash provided by investing activities increased in the first nine months of fiscal year 2023 compared to cash used in the first nine months of fiscal year 2022, primarily driven by higher marketable securities sales and maturities, lower purchases of marketable securities, offset by higher capital expenditures.

[0001045810-22-000166:mdna:94]
Cash used in financing activities increased in the first nine months of fiscal year 2023 compared to the first nine months of fiscal year 2022, which primarily reflects share repurchases and the absence of debt issuance proceeds in the first nine months of fiscal year 2023.

[0001045810-22-000166:mdna:95]
[same as prior period, unchanged from 0001045810-22-000147:mdna:100]

[0001045810-22-000166:mdna:96]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of October 30, 2022, we had $13.14 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations and debt due in fiscal year 2024. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance our future capital requirements.

[0001045810-22-000166:mdna:97]
[same as prior period, unchanged from 0001045810-22-000147:mdna:102]

[0001045810-22-000166:mdna:98]
We have approximately $1.38 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S. Other than that, substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of October 30, 2022 are available for use in the U.S. without incurring additional U.S. federal income taxes. We utilized nearly all our accumulated U.S. federal research tax credits during fiscal year 2022, which has resulted in higher cash tax payments starting in fiscal year 2023. In addition, beginning in fiscal year 2023, the 2017 Tax Cuts and Jobs Act requires taxpayers to capitalize research and development expenditures and to amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will impact cash flows from operations and will result in significantly higher cash tax payments starting in fiscal year 2023.

[0001045810-22-000166:mdna:99]
[same as prior period, unchanged from 0001045810-22-000147:mdna:104]

[0001045810-22-000166:mdna:100]
During the third quarter and first nine months of fiscal year 2023, we returned $3.65 billion and $8.99 billion, respectively, in share repurchases and $100 million and $300 million, respectively, in cash dividends. From October 31, 2022 through November 17, 2022, we repurchased 7 million shares for $1.05 billion pursuant to a Rule 10b5-1 trading plan.

[0001045810-22-000166:mdna:101]
[same as prior period, unchanged from 0001045810-22-000147:mdna:106]

[0001045810-22-000166:mdna:102]
[same as prior period, unchanged from 0001045810-22-000147:mdna:107]

[0001045810-22-000166:mdna:103]
As of October 30, 2022, we had outstanding:

[0001045810-22-000166:mdna:104]
[same as prior period, unchanged from 0001045810-22-000147:mdna:109]

[0001045810-22-000166:mdna:105]
[same as prior period, unchanged from 0001045810-22-000147:mdna:110]

[0001045810-22-000166:mdna:106]
[same as prior period, unchanged from 0001045810-22-000147:mdna:111]

[0001045810-22-000166:mdna:107]
[same as prior period, unchanged from 0001045810-22-000147:mdna:112]

[0001045810-22-000166:mdna:108]
[same as prior period, unchanged from 0001045810-22-000147:mdna:113]

[0001045810-22-000166:mdna:109]
[same as prior period, unchanged from 0001045810-22-000147:mdna:114]

[0001045810-22-000166:mdna:110]
[same as prior period, unchanged from 0001045810-22-000147:mdna:115]

[0001045810-22-000166:mdna:111]
[same as prior period, unchanged from 0001045810-22-000147:mdna:116]

[0001045810-22-000166:mdna:112]
[same as prior period, unchanged from 0001045810-22-000147:mdna:117]

[0001045810-22-000166:mdna:113]
We have a $575 million commercial paper program to support general corporate purposes. As of October 30, 2022, we had not issued any commercial paper.

[0001045810-22-000166:mdna:114]
[same as prior period, unchanged from 0001045810-22-000147:mdna:119]

[0001045810-22-000166:mdna:115]
We have unrecognized tax benefits of $869 million, which includes related interest and penalties of $80 million recorded in non-current income tax payable as of October 30, 2022. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-22-000166:mdna:116]
[same as prior period, unchanged from 0001045810-22-000147:mdna:121]

[0001045810-22-000166:mdna:117]
[same as prior period, unchanged from 0001045810-22-000147:mdna:122]

[0001045810-22-000166:mdna:118]
To date, there has been no material impact to our results of operations associated with global sustainability regulations, compliance, costs from sourcing renewable energy or climate-related business trends.

[0001045810-22-000166:mdna:119]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-22-000166:mdna:120]
There has been no adoption of any new and recently issued accounting pronouncements.
