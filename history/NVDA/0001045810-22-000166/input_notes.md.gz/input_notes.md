# NVDA notes — 0001045810-22-000166


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-22-000166:notes:1]
[same as prior period, unchanged from 0001045810-22-000147:notes:1]

[0001045810-22-000166:notes:2]
[same as prior period, unchanged from 0001045810-22-000147:notes:2]

[0001045810-22-000166:notes:3]
[same as prior period, unchanged from 0001045810-22-000147:notes:3]

[0001045810-22-000166:notes:4]
[same as prior period, unchanged from 0001045810-22-000147:notes:4]

[0001045810-22-000166:notes:5]
[same as prior period, unchanged from 0001045810-22-000147:notes:5]

[0001045810-22-000166:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The third quarters of fiscal years 2023 and 2022 were both 13-week quarters.

[0001045810-22-000166:notes:7]
[same as prior period, unchanged from 0001045810-22-000147:notes:7]

[0001045810-22-000166:notes:8]
[same as prior period, unchanged from 0001045810-22-000147:notes:8]

[0001045810-22-000166:notes:9]
Prior period intangible asset gross carrying amount and accumulated amortization in Note 9 have been adjusted to write off immaterial fully amortized intangible assets as of January 30, 2022.

[0001045810-22-000166:notes:10]
[same as prior period, unchanged from 0001045810-22-000147:notes:9]

[0001045810-22-000166:notes:11]
[same as prior period, unchanged from 0001045810-22-000147:notes:10]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-22-000166:notes:12]
[same as prior period, unchanged from 0001045810-22-000147:notes:11]

[0001045810-22-000166:notes:13]
In February 2022, NVIDIA and SoftBank Group Corp, or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-22-000166:notes:14]
[same as prior period, unchanged from 0001045810-22-000147:notes:13]

[0001045810-22-000166:notes:15]
Future minimum lease payments under our non-cancelable operating leases as of October 30, 2022 are as follows:

[0001045810-22-000166:notes:16]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first nine months of fiscal year 2023) | $ | 50 |  |
| 2024 | 188 |  |
| 2025 | 167 |  |
| 2026 | 149 |  |
| 2027 | 137 |  |
| 2028 and thereafter | 393 |  |
| Total | 1,084 |  |
| Less imputed interest | 130 |  |
| Present value of net future minimum lease payments | 954 |  |
| Less short-term operating lease liabilities | 156 |  |
| Long-term operating lease liabilities | $ | 798 |  |

[0001045810-22-000166:notes:17]
In addition to our existing operating lease obligations, we have operating leases, primarily for our data centers, that are expected to commence between the fourth quarter of fiscal year 2023 and fiscal year 2025 with lease terms of 2 to 8 years for $647 million.

[0001045810-22-000166:notes:18]
Operating lease expenses were $49 million and $44 million for the third quarter of fiscal years 2023 and 2022, respectively, and $139 million and $125 million for the first nine months of fiscal years 2023 and 2022, respectively. Short-term and variable lease expenses for the third quarter and first nine months of fiscal years 2023 and 2022 were not significant.

[0001045810-22-000166:notes:19]
[same as prior period, unchanged from 0001045810-22-000147:notes:18]

[0001045810-22-000166:notes:20]
|  | Nine Months Ended |
|  | October 30, 2022 |  | October 31, 2021 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 134 |  |  | $ | 114 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 213 |  |  | $ | 230 |  |

[0001045810-22-000166:notes:21]
As of October 30, 2022, our operating leases had a weighted average remaining lease term of 6.9 years and a weighted average discount rate of 2.82%. As of January 30, 2022, our operating leases had a weighted average remaining lease term of 7.1 years and a weighted average discount rate of 2.51%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-22-000166:notes:22]
[same as prior period, unchanged from 0001045810-22-000147:notes:21]

[0001045810-22-000166:notes:23]
[same as prior period, unchanged from 0001045810-22-000147:notes:22]

[0001045810-22-000166:notes:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
|  | (In millions) |
| Cost of revenue | $ | 32 |  |  | $ | 44 |  |  | $ | 108 |  |  | $ | 102 |  |
| Research and development | 530 |  |  | 363 |  |  | 1,365 |  |  | 935 |  |
| Sales, general and administrative | 183 |  |  | 152 |  |  | 498 |  |  | 416 |  |
| Total | $ | 745 |  |  | $ | 559 |  |  | $ | 1,971 |  |  | $ | 1,453 |  |

[0001045810-22-000166:notes:25]
[same as prior period, unchanged from 0001045810-22-000147:notes:24]

[0001045810-22-000166:notes:26]
[same as prior period, unchanged from 0001045810-22-000147:notes:25]

[0001045810-22-000166:notes:27]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 30, 2022 | 46 |  |  | $ | 114.19 |  |  |  |  |  |
| Granted | 23 |  |  | $ | 185.07 |  |  |  |  |  |
| Vested restricted stock | (18) |  |  | $ | 94.82 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 137.27 |  |  |  |  |  |
| Balances, October 30, 2022 | 50 |  |  | $ | 153.73 |  |  |  |  |  |

[0001045810-22-000166:notes:28]
As of October 30, 2022, there was $7.19 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.7 years for RSUs, PSUs, and market-based PSUs, and 1.1 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-22-000166:notes:29]
[same as prior period, unchanged from 0001045810-22-000147:notes:28]

[0001045810-22-000166:notes:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 680 |  |  | $ | 2,464 |  |  | $ | 2,954 |  |  | $ | 6,749 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,483 |  |  | 2,499 |  |  | 2,495 |  |  | 2,493 |  |
| Dilutive impact of outstandingequity awards | 16 |  |  | 39 |  |  | 22 |  |  | 39 |  |
| Diluted weighted average shares | 2,499 |  |  | 2,538 |  |  | 2,517 |  |  | 2,532 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.27 |  |  | $ | 0.99 |  |  | $ | 1.18 |  |  | $ | 2.71 |  |
| Diluted (2) | $ | 0.27 |  |  | $ | 0.97 |  |  | $ | 1.17 |  |  | $ | 2.67 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 36 |  |  | 2 |  |  | 29 |  |  | 21 |  |

[0001045810-22-000166:notes:31]
[same as prior period, unchanged from 0001045810-22-000147:notes:30]

[0001045810-22-000166:notes:32]
[same as prior period, unchanged from 0001045810-22-000147:notes:31]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-22-000166:notes:33]
Income Taxes
We recognized an income tax benefit of $67 million and $61 million for the third quarter and first nine months of fiscal year 2023, respectively, and an income tax expense of $174 million and $327 million for the third quarter and first nine months of fiscal year 2022, respectively. Income tax as a percentage of income before income tax was a benefit of 10.9% and 2.1% for the third quarter and first nine months of fiscal year 2023, respectively, and an expense of 6.6% and 4.6% for the third quarter and first nine months of fiscal year 2022, respectively.

[0001045810-22-000166:notes:34]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2023 as compared to the same periods of fiscal year 2022 was primarily due to the increased tax benefit of the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit, relative to a lower expected profitability. This is partially offset by the impact of an increase in the proportion of earnings subject to U.S. tax in fiscal year 2023 and the one-time discrete benefit from re-valuing certain deferred tax assets in connection with the domestication of one of our foreign subsidiaries, or the Domestication, in fiscal year 2022.

[0001045810-22-000166:notes:35]
Our effective tax rate for the first nine months of fiscal year 2023 was lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation and the U.S. federal research tax credit.

[0001045810-22-000166:notes:36]
Our effective tax rate for the first nine months of fiscal year 2022 was lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, the discrete benefit of the Domestication, and tax benefits related to stock-based compensation and the U.S. federal research tax credit.

[0001045810-22-000166:notes:37]
For the first nine months of fiscal year 2023, there were no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 30, 2022.
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 30, 2022, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-22-000166:notes:38]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-22-000166:notes:39]
The following is a summary of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022:

[0001045810-22-000166:notes:40]
|  | October 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,221 |  |  | $ | — |  |  | $ | (19) |  |  | $ | 4,202 |  |  | $ | 239 |  |  | $ | 3,963 |  |
| Debt securities issued by the U.S. Treasury | 4,176 |  |  | 1 |  |  | (60) |  |  | 4,117 |  |  | 1 |  |  | 4,116 |  |
| Debt securities issued by U.S. government agencies | 2,259 |  |  | — |  |  | (4) |  |  | 2,255 |  |  | 344 |  |  | 1,911 |  |
| Certificates of deposit | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 58 |  |  | 258 |  |
| Money market funds | 1,843 |  |  | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |  | — |  |
| Foreign government bonds | 99 |  |  | — |  |  | — |  |  | 99 |  |  | 4 |  |  | 95 |  |
| Total | $ | 12,914 |  |  | $ | 1 |  |  | $ | (83) |  |  | $ | 12,832 |  |  | $ | 2,489 |  |  | $ | 10,343 |  |

[0001045810-22-000166:notes:41]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the U.S. Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by U.S. government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

[0001045810-22-000166:notes:42]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-22-000166:notes:43]
|  | October 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the U.S. Treasury | $ | 1,928 |  |  | $ | (35) |  |  | $ | 1,051 |  |  | $ | (24) |  |  | $ | 2,979 |  |  | $ | (59) |  |
| Debt securities issued by U.S. government agencies | 1,888 |  |  | (4) |  |  | — |  |  | — |  |  | 1,888 |  |  | (4) |  |
| Corporate debt securities | 1,786 |  |  | (18) |  |  | 208 |  |  | (2) |  |  | 1,994 |  |  | (20) |  |
| Total | $ | 5,602 |  |  | $ | (57) |  |  | $ | 1,259 |  |  | $ | (26) |  |  | $ | 6,861 |  |  | $ | (83) |  |

[0001045810-22-000166:notes:44]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the U.S. Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

[0001045810-22-000166:notes:45]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

[0001045810-22-000166:notes:46]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022 are shown below by contractual maturity.

[0001045810-22-000166:notes:47]
|  | October 30, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 8,985 |  |  | $ | 8,952 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 3,929 |  |  | 3,880 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 12,914 |  |  | $ | 12,832 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-22-000166:notes:48]
[same as prior period, unchanged from 0001045810-22-000147:notes:47]

[0001045810-22-000166:notes:49]
|  |  | Fair Value at |
|  | Pricing Category |  | October 30, 2022 |  | January 30, 2022 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 1,843 |  |  | $ | 316 |  |
| Corporate debt securities | Level 2 |  | $ | 4,202 |  |  | $ | 9,974 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 4,117 |  |  | $ | 7,300 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,255 |  |  | $ | 1,612 |  |
| Certificates of deposit | Level 2 |  | $ | 316 |  |  | $ | 1,561 |  |
| Foreign government bonds | Level 2 |  | $ | 99 |  |  | $ | 150 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities (1) | Level 1 |  | $ | 27 |  |  | $ | 58 |  |
| Privately-held equity securities | Level 3 |  | $ | 287 |  |  | $ | 208 |  |
| Liabilities (2) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,217 |  |  | $ | 1,236 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,168 |  |  | $ | 1,224 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 945 |  |  | $ | 1,055 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,036 |  |  | $ | 1,200 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,281 |  |  | $ | 1,542 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 979 |  |  | $ | 1,200 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 764 |  |  | $ | 1,066 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,427 |  |  | $ | 2,147 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 344 |  |  | $ | 551 |  |

[0001045810-22-000166:notes:50]
(1)    Unrealized losses of $11 million and $35 million from investments in publicly-traded equity securities were recorded in other income (expense), net, in the third quarter and first nine months of fiscal year 2023, respectively. Unrealized gains of $8 million and $126 million from an investment in a publicly-traded equity security were recorded in other income (expense), net, in the third quarter and first nine months of fiscal year 2022, respectively.

[0001045810-22-000166:notes:51]
[same as prior period, unchanged from 0001045810-22-000147:notes:50]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-22-000166:notes:52]
[same as prior period, unchanged from 0001045810-22-000147:notes:51]

[0001045810-22-000166:notes:53]
|  | October 30, 2022 |  | January 30, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,093 |  |  | $ | (1,441) |  |  | $ | 1,652 |  |  | $ | 3,061 |  |  | $ | (947) |  |  | $ | 2,114 |  |
| Patents and licensed technology | 442 |  |  | (244) |  |  | 198 |  |  | 446 |  |  | (221) |  |  | 225 |  |
| Total intangible assets | $ | 3,535 |  |  | $ | (1,685) |  |  | $ | 1,850 |  |  | $ | 3,507 |  |  | $ | (1,168) |  |  | $ | 2,339 |  |

[0001045810-22-000166:notes:54]
(1)    During the first quarter of fiscal year 2023, we commenced amortization of a $630 million in-process research and development intangible asset related to our acquisition of Mellanox.

[0001045810-22-000166:notes:55]
Amortization expense associated with intangible assets was $181 million and $518 million for the third quarter and first nine months of fiscal year 2023, respectively, and $143 million and $418 million for the third quarter and first nine months of fiscal year 2022, respectively. Future amortization expense related to the net carrying amount of intangible assets as of October 30, 2022 is estimated to be $181 million for the remainder of fiscal year 2023, $600 million in fiscal year 2024, $538 million in fiscal year 2025, $244 million in fiscal year 2026, $141 million in fiscal year 2027, and $146 million in fiscal year 2028 and thereafter.
In the first nine months of fiscal year 2023, goodwill increased by $23 million and intangible assets increased by $33 million from acquisitions. We assigned $14 million of the increase in goodwill to our Compute & Networking segment and $9 million of the increase to our Graphics segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-22-000166:notes:56]
[same as prior period, unchanged from 0001045810-22-000147:notes:55]

[0001045810-22-000166:notes:57]
|  | October 30, |  | January 30, |
|  | 2022 |  | 2022 |
| Inventories: | (In millions) |
| Raw materials | $ | 1,936 |  |  | $ | 791 |  |
| Work in-process | 788 |  |  | 692 |  |
| Finished goods | 1,730 |  |  | 1,122 |  |
| Total inventories | $ | 4,454 |  |  | $ | 2,605 |  |

[0001045810-22-000166:notes:58]
|  | October 30, |  | January 30, |
|  | 2022 |  | 2022 |
| Other assets: | (In millions) |
| Prepaid supply agreements | $ | 2,771 |  |  | $ | 1,747 |  |
| Prepaid royalties | 393 |  |  | 409 |  |
| Investment in non-affiliated entities | 314 |  |  | 266 |  |
| Advanced consideration for acquisition (1) | — |  |  | 1,353 |  |
| Other | 102 |  |  | 66 |  |
| Total other assets | $ | 3,580 |  |  | $ | 3,841 |  |

[0001045810-22-000166:notes:59]
[same as prior period, unchanged from 0001045810-22-000147:notes:59]

[0001045810-22-000166:notes:60]
|  | October 30, |  | January 30, |
|  | 2022 |  | 2022 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 1,394 |  |  | $ | 1,000 |  |
| Excess inventory purchase obligations | 1,181 |  |  | 196 |  |
| Deferred revenue (1) | 338 |  |  | 300 |  |
| Accrued payroll and related expenses | 307 |  |  | 409 |  |
| Unsettled share repurchases | 162 |  |  | — |  |
| Product warranty | 104 |  |  | 46 |  |
| Taxes payable | 108 |  |  | 132 |  |
| Other | 521 |  |  | 469 |  |
| Total accrued and other current liabilities | $ | 4,115 |  |  | $ | 2,552 |  |

[0001045810-22-000166:notes:61]
(1)    Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements, support for hardware and software, and cloud services.

[0001045810-22-000166:notes:62]
|  | October 30, |  | January 30, |
|  | 2022 |  | 2022 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,057 |  |  | $ | 980 |  |
| Deferred income tax | 246 |  |  | 245 |  |
| Deferred revenue (2) | 213 |  |  | 202 |  |
| Other | 269 |  |  | 126 |  |
| Total other long-term liabilities | $ | 1,785 |  |  | $ | 1,553 |  |

[0001045810-22-000166:notes:63]
(1)    As of October 30, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $188 million, unrecognized tax benefits of $789 million, and related interest and penalties of $80 million. As of January 30, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, unrecognized tax benefits of $670 million, and related interest and penalties of $59 million.

[0001045810-22-000166:notes:64]
[same as prior period, unchanged from 0001045810-22-000147:notes:65]

[0001045810-22-000166:notes:65]
[same as prior period, unchanged from 0001045810-22-000147:notes:66]

[0001045810-22-000166:notes:66]
The following table shows the changes in deferred revenue during the first nine months of fiscal years 2023 and 2022:

[0001045810-22-000166:notes:67]
|  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 502 |  |  | $ | 451 |  |
| Deferred revenue additions during the period | 577 |  |  | 621 |  |
| Revenue recognized during the period | (528) |  |  | (583) |  |
| Balance at end of period | $ | 551 |  |  | $ | 489 |  |

[0001045810-22-000166:notes:68]
Revenue related to remaining performance obligations represents the contracted license and development arrangements and support for hardware and software. This includes deferred revenue currently recorded and amounts that will be invoiced in future periods. As of October 30, 2022, $681 million of revenue related to performance obligations had not been recognized, of which we expect to recognize approximately 47% over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-22-000166:notes:69]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of October 30, 2022 and January 30, 2022.

[0001045810-22-000166:notes:70]
[same as prior period, unchanged from 0001045810-22-000147:notes:71]

[0001045810-22-000166:notes:71]
The table below presents the notional value of our foreign currency forward contracts outstanding as of October 30, 2022 and January 30, 2022:

[0001045810-22-000166:notes:72]
|  | October 30,2022 |  | January 30,2022 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,139 |  |  | $ | 1,023 |  |
| Not designated for hedge accounting | $ | 330 |  |  | $ | 408 |  |

[0001045810-22-000166:notes:73]
As of October 30, 2022, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-22-000166:notes:74]
During the first nine months of fiscal years 2023 and 2022, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant.


## us-gaap:DebtDisclosureTextBlock

[0001045810-22-000166:notes:75]
Debt
Long-Term Debt

[0001045810-22-000166:notes:76]
The carrying values of our outstanding notes and their associated interest rates were as follows:

[0001045810-22-000166:notes:77]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.6 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (50) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | 10,950 |  |  | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,701 |  |  | $ | 10,946 |  |

[0001045810-22-000166:notes:78]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-22-000166:notes:79]
As of October 30, 2022, we have complied with the required covenants under the notes.

[0001045810-22-000166:notes:80]
Commercial Paper

[0001045810-22-000166:notes:81]
We have a $575 million commercial paper program to support general corporate purposes. As of October 30, 2022, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-22-000166:notes:82]
Commitments and Contingencies
Purchase Obligations

[0001045810-22-000166:notes:83]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-22-000166:notes:84]
We have entered into several long-term supply agreements, under which we have made advance payments and have $917 million remaining unpaid. As of October 30, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $7.02 billion, inclusive of the $917 million. Other non-inventory purchase obligations of $2.75 billion include $1.59 billion of multi-year cloud service agreements.

[0001045810-22-000166:notes:85]
Total gross future unconditional purchase commitments as of October 30, 2022 are as follows:

[0001045810-22-000166:notes:86]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first nine months of fiscal year 2023) | $ | 4,234 |  |
| 2024 | 3,362 |  |
| 2025 | 798 |  |
| 2026 | 504 |  |
| 2027 | 464 |  |
| 2028 and thereafter | 410 |  |
| Total | $ | 9,772 |  |

[0001045810-22-000166:notes:87]
Accrual for Product Warranty Liabilities

[0001045810-22-000166:notes:88]
The estimated amount of product warranty liabilities was $104 million and $46 million as of October 30, 2022 and January 30, 2022, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

[0001045810-22-000166:notes:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 168 |  |  | $ | 31 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions | 3 |  | 5 |  | 141 |  | 20 |
| Utilization | (67) |  |  | (4) |  |  | (83) |  |  | (10) |  |
| Balance at end of period | $ | 104 |  |  | $ | 32 |  |  | $ | 104 |  |  | $ | 32 |  |

[0001045810-22-000166:notes:90]
In the third quarter of fiscal year 2023, we recognized a warranty-related benefit of approximately $70 million in cost of revenue due to favorable product recovery.

[0001045810-22-000166:notes:91]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-22-000166:notes:92]
Securities Class Action and Derivative Lawsuits

[0001045810-22-000166:notes:93]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

[0001045810-22-000166:notes:94]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-22-000166:notes:95]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-22-000166:notes:96]
Accounting for Loss Contingencies

[0001045810-22-000166:notes:97]
As of October 30, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-22-000166:notes:98]
[same as prior period, unchanged from 0001045810-22-000147:notes:100]

[0001045810-22-000166:notes:99]
During the third quarter and first nine months of fiscal year 2023, we repurchased 28 million shares for $3.65 billion and 56 million shares for $8.99 billion, respectively. Since the inception of our share repurchase program through October 30, 2022, we have repurchased an aggregate of 1.10 billion shares for $16.07 billion. As of October 30, 2022, we were authorized, subject to certain specifications, to repurchase an additional $8.28 billion of shares through December 2023. From October 31, 2022 through November 17, 2022, we repurchased 7 million shares for $1.05 billion pursuant to a Rule 10b5-1 trading plan.

[0001045810-22-000166:notes:100]
During the third quarter and first nine months of fiscal year 2023, we paid $100 million and $300 million in cash dividends to our shareholders, respectively. During the third quarter and first nine months of fiscal year 2022, we paid $100 million and $298 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-22-000166:notes:101]
[same as prior period, unchanged from 0001045810-22-000147:notes:103]

[0001045810-22-000166:notes:102]
[same as prior period, unchanged from 0001045810-22-000147:notes:105]

[0001045810-22-000166:notes:103]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation

[0001045810-22-000166:notes:104]
graphics; vGPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse software for building 3D designs and virtual worlds.

[0001045810-22-000166:notes:105]
[same as prior period, unchanged from 0001045810-22-000147:notes:106]

[0001045810-22-000166:notes:106]
The “All Other” category includes the expenses that our CODM does not assign to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, acquisition-related and other costs, corporate infrastructure and support costs, restructuring costs, acquisition termination cost, IP-related and legal settlement costs, contributions, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-22-000166:notes:107]
[same as prior period, unchanged from 0001045810-22-000147:notes:108]

[0001045810-22-000166:notes:108]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 30, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 3,816 |  |  | $ | 2,115 |  |  | $ | — |  |  | $ | 5,931 |  |
| Operating income (loss) | $ | 1,086 |  |  | $ | 606 |  |  | $ | (1,091) |  |  | $ | 601 |  |
| Three Months Ended October 31, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 3,011 |  |  | $ | 4,092 |  |  | $ | — |  |  | $ | 7,103 |  |
| Operating income (loss) | $ | 1,332 |  |  | $ | 2,160 |  |  | $ | (821) |  |  | $ | 2,671 |  |
| Nine Months Ended October 30, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 11,395 |  |  | $ | 9,528 |  |  | $ | — |  |  | $ | 20,923 |  |
| Operating income (loss) | $ | 3,509 |  |  | $ | 3,739 |  |  | $ | (4,280) |  |  | $ | 2,968 |  |
| Nine Months Ended October 31, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 7,821 |  |  | $ | 11,450 |  |  | $ | — |  |  | $ | 19,271 |  |
| Operating income (loss) | $ | 3,227 |  |  | $ | 6,073 |  |  | $ | (2,229) |  |  | $ | 7,071 |  |

[0001045810-22-000166:notes:109]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (745) |  |  | $ | (559) |  |  | $ | (1,971) |  |  | $ | (1,453) |  |
| Acquisition-related and other costs | (174) |  |  | (156) |  |  | (499) |  |  | (482) |  |
| Unallocated cost of revenue and operating expenses | (156) |  |  | (106) |  |  | (432) |  |  | (286) |  |
| Restructuring costs | (16) |  |  | — |  |  | (16) |  |  | — |  |
| Acquisition termination cost | — |  |  | — |  |  | (1,353) |  |  | — |  |
| IP-related and legal settlement costs | — |  |  | — |  |  | (7) |  |  | (8) |  |
| Contributions | — |  |  | — |  |  | (2) |  |  | — |  |
| Total | $ | (1,091) |  |  | $ | (821) |  |  | $ | (4,280) |  |  | $ | (2,229) |  |

[0001045810-22-000166:notes:110]
Revenue by geographic region is allocated to individual countries based on the billing location of the customer. End customer location may be different than our customer’s billing location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-22-000166:notes:111]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 2,148 |  |  | $ | 1,126 |  |  | $ | 6,069 |  |  | $ | 2,890 |  |
| Taiwan | 1,153 |  |  | 2,187 |  |  | 5,134 |  |  | 5,932 |  |
| China (including Hong Kong) | 1,148 |  |  | 2,017 |  |  | 4,831 |  |  | 5,128 |  |
| Other countries | 1,482 |  |  | 1,773 |  |  | 4,889 |  |  | 5,321 |  |
| Total revenue | $ | 5,931 |  |  | $ | 7,103 |  |  | $ | 20,923 |  |  | $ | 19,271 |  |

[0001045810-22-000166:notes:112]
[same as prior period, unchanged from 0001045810-22-000147:notes:113]

[0001045810-22-000166:notes:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 3,833 |  |  | $ | 2,936 |  |  | $ | 11,389 |  |  | $ | 7,350 |  |
| Gaming | 1,574 |  |  | 3,221 |  |  | 7,236 |  |  | 9,042 |  |
| Professional Visualization | 200 |  |  | 577 |  |  | 1,318 |  |  | 1,468 |  |
| Automotive | 251 |  |  | 135 |  |  | 609 |  |  | 441 |  |
| OEM and Other | 73 |  |  | 234 |  |  | 371 |  |  | 970 |  |
| Total revenue | $ | 5,931 |  |  | $ | 7,103 |  |  | $ | 20,923 |  |  | $ | 19,271 |  |

[0001045810-22-000166:notes:114]
One customer represented 10% of our total revenue for the third quarter of fiscal year 2023 and was attributable primarily to the Compute & Networking segment. No customer represented 10% or more of total revenue for the first nine months of fiscal year 2023 and for the third quarter and first nine months of fiscal year 2022.
One customer represented 10% or more of accounts receivable for a total of 12% of our accounts receivable balance as of October 30, 2022. Two customers each represented 10% or more of accounts receivable for a total of 22% as of January 30, 2022.
