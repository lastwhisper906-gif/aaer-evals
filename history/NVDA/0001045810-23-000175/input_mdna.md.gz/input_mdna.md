# NVDA MD&A — 0001045810-23-000175


## mdna

[0001045810-23-000175:mdna:1]
[same as prior period, unchanged from 0001045810-23-000093:mdna:1]

[0001045810-23-000175:mdna:2]
[same as prior period, unchanged from 0001045810-23-000093:mdna:2]

[0001045810-23-000175:mdna:3]
[same as prior period, unchanged from 0001045810-23-000093:mdna:3]

[0001045810-23-000175:mdna:4]
[same as prior period, unchanged from 0001045810-23-000093:mdna:4]

[0001045810-23-000175:mdna:5]
[same as prior period, unchanged from 0001045810-23-000093:mdna:5]

[0001045810-23-000175:mdna:6]
[same as prior period, unchanged from 0001045810-23-000093:mdna:6]

[0001045810-23-000175:mdna:7]
Since our founding in 1993, NVIDIA has been a pioneer in accelerated computing. Our invention of the GPU in 1999 has sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and has fueled industrial digitalization across markets. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry.

[0001045810-23-000175:mdna:8]
[same as prior period, unchanged from 0001045810-23-000093:mdna:8]

[0001045810-23-000175:mdna:9]
[same as prior period, unchanged from 0001045810-23-000093:mdna:9]

[0001045810-23-000175:mdna:10]
[same as prior period, unchanged from 0001045810-23-000093:mdna:10]

[0001045810-23-000175:mdna:11]
Demand and Supply, Product Transitions, and New Products and Business Models

[0001045810-23-000175:mdna:12]
Demand for our data center systems and products has surged over the last two quarters and our demand visibility extends into next year. In order to meet this demand, we have increased our purchase obligations with existing suppliers, added new suppliers and entered into prepaid supply and capacity agreements. These increased purchase volumes and number of suppliers may create more supply chain complexity and execution risk. We expect our supply to increase each quarter through next year. We have entered and expect to continue to enter into supplier and capacity arrangements.

[0001045810-23-000175:mdna:13]
Product transitions are complex as we often ship both new and prior architecture products simultaneously and we and our channel partners prepare to ship and support new products. We are in various stages of transitioning the architecture of our Data Center, Professional Visualization, and Gaming products. Qualification time for new products, customers anticipating product transitions and channel partners

[0001045810-23-000175:mdna:14]
reducing channel inventory of prior architectures ahead of new product introductions can create reductions or volatility in our revenue. In addition, the bring up of new product architectures is complex due to functionality challenges and quality concerns not identified in manufacturing testing. These product quality issues may incur costs, increase our warranty costs, and delay further production of our architecture. While we have managed prior product transitions and have previously sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and we may incur additional costs.

[0001045810-23-000175:mdna:15]
We build technology and products for use cases and applications that may be new or may not yet exist such as our Omniverse platform, third-party large language models, and generative AI models. We have recently begun offering enterprise customers NVIDIA DGX cloud services directly and through our network of partners, which includes cloud-based infrastructure and software and services for training and deploying AI models, and NVIDIA AI Foundations for customizable pretrained AI models. Our demand estimates for new use cases, applications, and services can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate significant revenue from these use cases, applications, and services. New technologies such as generative AI models have emerged, and while they have driven increased demand for Data Center compute infrastructure, the long-term trajectory is unknown.

[0001045810-23-000175:mdna:16]
[same as prior period, unchanged from 0001045810-23-000093:mdna:19]

[0001045810-23-000175:mdna:17]
During the third quarter of fiscal year 2023, the U.S. government, or the USG, announced license requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits. During the second quarter of fiscal year 2024, the USG informed us of an additional licensing requirement for a subset of A100 and H100 products destined to certain customers and other regions, including some countries in the Middle East. We have sold alternative products in China not subject to the license requirements, such as our A800 or H800 offerings.

[0001045810-23-000175:mdna:18]
Given the strength of demand for our products worldwide, we do not anticipate that additional export restrictions, if adopted, would have an immediate material impact on our financial results. However, over the long term, our results and competitive position may be harmed, and we may be effectively excluded from all or part of the China market if there are further changes in the USG’s export controls, if customers in China do not want to purchase our alternative product offerings, if customers purchase product from competitors, if customers develop their own internal solution, if the USG does not grant licenses in a timely manner or denies licenses to significant customers, or if we incur significant transition costs.

[0001045810-23-000175:mdna:19]
While we work to enhance the resiliency and redundancy of our supply chain, which is currently concentrated in the Asia-Pacific, including China, Hong Kong, Korea and Taiwan, new export controls or changes to existing export controls could negatively impact our business.

[0001045810-23-000175:mdna:20]
Macroeconomic Factors

[0001045810-23-000175:mdna:21]
Macroeconomic factors, including inflation, increased interest rates, significant capital market volatility, global supply chain constraints and global economic and geopolitical developments, may have direct and indirect impacts on our results of operations. While difficult to isolate and quantify, these macroeconomic factors can impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Our product and solution pricing strategy generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-23-000175:mdna:22]
Second Quarter of Fiscal Year 2024 Summary

[0001045810-23-000175:mdna:23]
|  | Three Months Ended |  |  |  |  |
|  | July 30, 2023 |  | April 30, 2023 |  | July 31, 2022 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 13,507 |  |  | $ | 7,192 |  |  | $ | 6,704 |  |  | 88 | % |  | 101 | % |
| Gross margin | 70.1 | % |  | 64.6 | % |  | 43.5 | % |  | 5.5 pts |  | 26.6 pts |
| Operating expenses | $ | 2,662 |  |  | $ | 2,508 |  |  | $ | 2,416 |  |  | 6 | % |  | 10 | % |
| Operating income | $ | 6,800 |  |  | $ | 2,140 |  |  | $ | 499 |  |  | 218 | % |  | 1,263 | % |
| Net income | $ | 6,188 |  |  | $ | 2,043 |  |  | $ | 656 |  |  | 203 | % |  | 843 | % |
| Net income per diluted share | $ | 2.48 |  |  | $ | 0.82 |  |  | $ | 0.26 |  |  | 202 | % |  | 854 | % |

[0001045810-23-000175:mdna:24]
[same as prior period, unchanged from 0001045810-23-000093:mdna:25]

[0001045810-23-000175:mdna:25]
Revenue for the second quarter of fiscal year 2024 was $13.51 billion, up 101% from a year ago and up 88% sequentially.

[0001045810-23-000175:mdna:26]
Data Center revenue was up 171% from a year ago and up 141% sequentially, led by CSPs and large consumer internet companies. Strong demand for the NVIDIA HGX platform based on our Hopper and Ampere GPU architectures was primarily driven by the development of large language models and generative AI. Data Center Compute grew 195% from a year ago and 157% sequentially, largely reflecting the strong ramp of our Hopper-based HGX platform. Networking was up 94% from a year ago and up 85% sequentially, primarily on strong growth in InfiniBand infrastructure to support our HGX platform. In the second quarter of fiscal year 2024, CSPs represented slightly more than half of our estimated Data Center end demand, with large consumer internet companies being the next largest end demand, followed by enterprise and high performance computing.

[0001045810-23-000175:mdna:27]
Gaming revenue was up 22% from a year ago and up 11% sequentially, primarily reflecting demand for our GeForce RTX 40 Series GPUs based on the NVIDIA Ada Lovelace architecture following normalization of channel inventory levels.

[0001045810-23-000175:mdna:28]
Professional Visualization revenue was down 24% from a year ago and up 28% sequentially. The year-on-year decrease primarily reflects lower sell-in to partners following normalization of channel inventory levels. The sequential increase was primarily due to stronger enterprise workstation demand and the ramp of NVIDIA RTX products based on the Ada Lovelace Architecture.

[0001045810-23-000175:mdna:29]
Automotive revenue was up 15% from a year ago and down 15% sequentially. The year-on-year increase was primarily driven by sales of self-driving platforms. The sequential decrease primarily reflects lower overall auto demand, particularly in China.

[0001045810-23-000175:mdna:30]
Gross margin increased from a year ago and sequentially, primarily reflecting growth in Data Center sales. The year-on-year increase also reflects the impact on the year-ago gross margin from $1.34 billion in inventory provisions and related charges.

[0001045810-23-000175:mdna:31]
Operating expenses were up 10% from a year ago and up 6% sequentially, primarily driven by compensation and benefits, including stock-based compensation, reflecting growth in employees and compensation increases.

[0001045810-23-000175:mdna:32]
[same as prior period, unchanged from 0001045810-23-000093:mdna:36]

[0001045810-23-000175:mdna:33]
Data Center revenue for the second quarter of fiscal year 2024 was $10.32 billion, up 171% from a year ago. We announced that the NVIDIA GH200 Grace Hopper Superchip is available in the third quarter of fiscal year 2024; announced the NVIDIA L40S GPU - a universal data center processor for compute-intensive applications, including AI training and inference, is available now; unveiled the NVIDIA MGX server reference design; announced NVIDIA Spectrum-X, an accelerated networking platform for AI; and partnered with a

[0001045810-23-000175:mdna:34]
range of companies on AI initiatives, including ServiceNow, Accenture, VMware, Snowflake, WPP, SoftBank, and Hugging Face.

[0001045810-23-000175:mdna:35]
Gaming revenue for the second quarter of fiscal year 2024 was $2.49 billion, up 22% from a year ago. We began shipping the GeForce RTX 4060 family of GPUs; and announced NVIDIA Avatar Cloud Engine for Games, a custom AI model foundry service using AI-powered natural language interactions to transform games.

[0001045810-23-000175:mdna:36]
Professional Visualization revenue for the second quarter of fiscal year 2024 was $379 million, down 24% from a year ago. We announced new NVIDIA RTX GPUs for desktop workstations based on the Ada Lovelace architecture; and a major release of the NVIDIA Omniverse platform.

[0001045810-23-000175:mdna:37]
Automotive revenue for the second quarter of fiscal year 2024 was $253 million, up 15% from a year ago. We announced that NVIDIA DRIVE Orin is powering the new XPENG G6 Coupe SUVs; and announced a partnership with MediaTek, which will develop mainstream automotive systems on chips for global OEMs integrating a new NVIDIA GPU chiplet IP for AI and graphics.

[0001045810-23-000175:mdna:38]
[same as prior period, unchanged from 0001045810-23-000093:mdna:41]

[0001045810-23-000175:mdna:39]
[same as prior period, unchanged from 0001045810-23-000093:mdna:42]

[0001045810-23-000175:mdna:40]
[same as prior period, unchanged from 0001045810-23-000093:mdna:43]

[0001045810-23-000175:mdna:41]
[same as prior period, unchanged from 0001045810-23-000093:mdna:44]

[0001045810-23-000175:mdna:42]
[same as prior period, unchanged from 0001045810-23-000093:mdna:46]

[0001045810-23-000175:mdna:43]
[same as prior period, unchanged from 0001045810-23-000093:mdna:47]

[0001045810-23-000175:mdna:44]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 29.9 |  |  | 56.5 |  |  | 31.8 |  |  | 44.3 |  |
| Gross profit | 70.1 |  |  | 43.5 |  |  | 68.2 |  |  | 55.7 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 15.1 |  |  | 27.2 |  |  | 18.9 |  |  | 23.0 |  |
| Sales, general and administrative | 4.7 |  |  | 8.8 |  |  | 6.1 |  |  | 7.9 |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | 9.0 |  |
| Total operating expenses | 19.8 |  |  | 36.0 |  |  | 25.0 |  |  | 39.9 |  |
| Operating income | 50.3 |  |  | 7.5 |  |  | 43.2 |  |  | 15.8 |  |
| Interest income | 1.4 |  |  | 0.7 |  |  | 1.6 |  |  | 0.4 |  |
| Interest expense | (0.5) |  |  | (1.0) |  |  | (0.6) |  |  | (0.9) |  |
| Other, net | 0.4 |  |  | (0.1) |  |  | 0.2 |  |  | (0.1) |  |
| Other income (expense), net | 1.3 |  |  | (0.4) |  |  | 1.2 |  |  | (0.6) |  |
| Income before income tax | 51.6 |  |  | 7.1 |  |  | 44.4 |  |  | 15.2 |  |
| Income tax expense (benefit) | 5.9 |  |  | (2.7) |  |  | 4.6 |  |  | — |  |
| Net income | 45.7 | % |  | 9.8 | % |  | 39.8 | % |  | 15.2 | % |

[0001045810-23-000175:mdna:45]
[same as prior period, unchanged from 0001045810-23-000093:mdna:49]

[0001045810-23-000175:mdna:46]
Revenue for the second quarter and first half of fiscal year 2024 was $13.51 billion and $20.70 billion, up 101% and 38%, respectively.

[0001045810-23-000175:mdna:47]
[same as prior period, unchanged from 0001045810-23-000093:mdna:50]

[0001045810-23-000175:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | $Change |  | %Change |  | July 30,2023 |  | July 31,2022 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 10,402 |  |  | $ | 3,907 |  |  | $ | 6,495 |  |  | 166 | % |  | $ | 14,862 |  |  | $ | 7,579 |  |  | $ | 7,283 |  |  | 96 | % |
| Graphics | 3,105 |  |  | 2,797 |  |  | 308 |  |  | 11 | % |  | 5,837 |  |  | 7,413 |  |  | (1,576) |  |  | (21) | % |
| Total | $ | 13,507 |  |  | $ | 6,704 |  |  | $ | 6,803 |  |  | 101 | % |  | $ | 20,699 |  |  | $ | 14,992 |  |  | $ | 5,707 |  |  | 38 | % |

[0001045810-23-000175:mdna:49]
Compute & Networking - The increase in the second quarter and first half of fiscal year 2024 compared to the second quarter and first half of fiscal year 2023 was primarily due to higher Data Center revenue. Compute GPUs grew 208% year-on-year and 112% compared to the first half of fiscal year 2023 led by demand for NVIDIA HGX platform based on our Hopper and Ampere GPU architecture for large language models and generative AI. Networking was up 94% year-on-year and 63% compared to the first half of last year driven primarily by strong growth in InfiniBand infrastructure to support our HGX platform.

[0001045810-23-000175:mdna:50]
Graphics - The increase in the second quarter of fiscal year 2024 compared to the second quarter of fiscal year 2023 primarily reflects growth in Gaming GPUs related to the demand for our GeForce RTX 40 Series GPUs based on the NVIDIA Ada Lovelace architecture following normalization of channel inventory levels. The decrease in the first half of fiscal year 2024 compared to the first half of fiscal year 2023 primarily reflects 16% lower Gaming GPU sales and 36% lower Professional Visualization GPU sales, due to lower sell-in to partners following normalization of channel inventory levels.

[0001045810-23-000175:mdna:51]
[same as prior period, unchanged from 0001045810-23-000093:mdna:54]

[0001045810-23-000175:mdna:52]
Revenue by geographic region is allocated to countries based on the billed location even if the revenue may be attributable to end customers in a different location. Revenue from sales to customers outside of the United States accounted for 55% and 59% of total revenue for the second quarter and first half of fiscal year 2024, respectively, and 70% and 74% of total revenue for the second quarter and first half of fiscal year 2023, respectively. The increase in revenue to the United States for the second quarter and first half of fiscal year 2024 was primarily due to higher U.S.-based Data Center end demand.

[0001045810-23-000175:mdna:53]
Our customer and partner network incorporates original equipment manufacturers, original device manufacturers, system builders, system integrators, add-in board manufacturers, retailers/distributors, independent software vendors, internet and CSPs, automotive manufacturers and tier-1 automotive suppliers, mapping companies, start-ups, and other ecosystem participants. One data center distributor customer represented approximately 17% and 13% of total revenue for the second quarter and first half of fiscal year 2024, respectively, and was attributable to the Compute & Networking segment. There were no customers with 10% or more of total revenue for the second quarter and first half of fiscal year 2023.

[0001045810-23-000175:mdna:54]
A large CSP, which primarily purchases indirectly through multiple system integrators and distributors, is estimated to represent approximately 22% and 19% of total revenue for the second quarter and first half of fiscal year 2024, respectively, and was attributable to our Compute & Networking segment. Our estimated Compute & Networking end customer demand is concentrated among several large CSPs and consumer internet companies. Most of these large companies do not purchase directly from us but often purchase through multiple system integrators, distributors, and channel partners. We expect this concentration trend will continue.

[0001045810-23-000175:mdna:55]
[same as prior period, unchanged from 0001045810-23-000093:mdna:57]

[0001045810-23-000175:mdna:56]
Our overall gross margin increased to 70.1% and 68.2% for the second quarter and first half of fiscal year 2024, respectively, from 43.5% and 55.7% for the second quarter and first half of fiscal year 2023, respectively. The increase in the second quarter and first half of fiscal year 2024 compared to second quarter and first half of fiscal year 2023 was primarily due to higher revenue from Compute GPUs of 208% and 112%, respectively, and lower inventory provisions.

[0001045810-23-000175:mdna:57]
Provisions for inventory and excess inventory purchase obligations totaled $576 million and $709 million for the second quarter and first half of fiscal year 2024, respectively. Sales of inventory that was previously written off or down, or settlements of excess inventory purchase obligations, totaled $84 million and $134 million for the second quarter and first half of fiscal year 2024, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 3.6% and 2.8% in the second quarter and first half of fiscal year 2024, respectively.

[0001045810-23-000175:mdna:58]
Provisions for inventory and excess inventory purchase obligations totaled $1.22 billion and $1.31 billion for the second quarter and first half of fiscal year 2023, respectively. Sales of inventory that was previously written off or down, or settlements of excess inventory purchase obligations, totaled $23 million and $38 million for the second quarter and first half of fiscal year 2023, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 17.8% and 8.5% in the second quarter and first half of fiscal year 2023, respectively.

[0001045810-23-000175:mdna:59]
[same as prior period, unchanged from 0001045810-23-000093:mdna:62]

[0001045810-23-000175:mdna:60]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | $Change |  | %Change |  | July 30,2023 |  | July 31,2022 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 2,040 |  |  | $ | 1,824 |  |  | $ | 216 |  |  | 12 | % |  | $ | 3,916 |  |  | $ | 3,443 |  |  | $ | 473 |  |  | 14 | % |
| % of net revenue | 15.1 | % |  | 27.2 | % |  |  |  |  |  | 18.9 | % |  | 23.0 | % |  |  |  |  |
| Sales, general and administrative expenses | 622 |  |  | 592 |  |  | 30 |  |  | 5 | % |  | 1,253 |  |  | 1,183 |  |  | 70 |  |  | 6 | % |
| % of net revenue | 4.7 | % |  | 8.8 | % |  |  |  |  |  | 6.1 | % |  | 7.9 | % |  |  |  |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | 1,353 |  |  | (1,353) |  |  | (100) | % |
| % of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | 9.0 | % |  |  |  |  |
| Total operating expenses | $ | 2,662 |  |  | $ | 2,416 |  |  | $ | 246 |  |  | 10 | % |  | $ | 5,169 |  |  | $ | 5,979 |  |  | $ | (810) |  |  | (14) | % |
| % of net revenue | 19.8 | % |  | 36.0 | % |  |  |  |  |  | 25.0 | % |  | 39.9 | % |  |  |  |  |

[0001045810-23-000175:mdna:61]
The increases in research and development expenses and sales, general and administrative expenses for the second quarter and first half of fiscal year 2024 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-23-000175:mdna:62]
Acquisition termination cost

[0001045810-23-000175:mdna:63]
[same as prior period, unchanged from 0001045810-23-000093:mdna:65]

[0001045810-23-000175:mdna:64]
Operating Income

[0001045810-23-000175:mdna:65]
Operating income for the second quarter and first half of fiscal year 2024 was $6.80 billion and $8.94 billion, respectively, up 1,263% and 278% from a year ago, respectively.

[0001045810-23-000175:mdna:66]
Operating income by Reportable Segments

[0001045810-23-000175:mdna:67]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | $Change |  | %Change |  | July 30,2023 |  | July 31,2022 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 6,728 |  |  | $ | 816 |  |  | $ | 5,912 |  |  | 725 | % |  | $ | 8,887 |  |  | $ | 2,422 |  |  | $ | 6,465 |  |  | 267 | % |
| Graphics | 1,211 |  |  | 657 |  |  | 554 |  |  | 84 | % |  | 2,258 |  |  | 3,133 |  |  | (875) |  |  | (28) | % |
| All Other | (1,139) |  |  | (974) |  |  | (165) |  |  | 17 | % |  | (2,204) |  |  | (3,188) |  |  | 984 |  |  | (31) | % |
| Total | $ | 6,800 |  |  | $ | 499 |  |  | $ | 6,301 |  |  | 1,263 | % |  | $ | 8,941 |  |  | $ | 2,367 |  |  | $ | 6,574 |  |  | 278 | % |

[0001045810-23-000175:mdna:68]
30

[0001045810-23-000175:mdna:69]
Compute & Networking – Segment operating income increased during the second quarter and first half of fiscal year 2024 compared to the second quarter and first half of fiscal year 2023 primarily due to higher revenues.

[0001045810-23-000175:mdna:70]
Graphics - Segment operating income increased during the second quarter of fiscal year 2024 compared to the second quarter of fiscal year 2023 primarily due to higher revenues of 11%. Segment operating income was also impacted by inventory provisions which were $81 million in the second quarter of fiscal year 2024 compared to $396 million in the second quarter of fiscal year 2023. Segment operating income decreased during the first half of fiscal year 2024 compared to the first half of fiscal year 2023 primarily due to lower revenues of 21%. Segment operating income was also impacted by inventory provisions which were $125 million in the first half of fiscal year 2024 compared to $416 million in the first half of fiscal year 2023.

[0001045810-23-000175:mdna:71]
All Other expenses increased during the second quarter of fiscal year 2024 compared to the second quarter of fiscal year 2023 primarily due to higher stock-based compensation expense. All Other expenses decreased during the first half of fiscal year 2024 compared to the first half of fiscal year 2023 primarily due to an acquisition termination cost of $1.35 billion related to the Arm transaction in the prior year.

[0001045810-23-000175:mdna:72]
[same as prior period, unchanged from 0001045810-23-000093:mdna:67]

[0001045810-23-000175:mdna:73]
|  | Three Months Ended | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | $Change |  | July 30,2023 |  | July 31,2022 |  | $Change |
|  | ($ in millions) |
| Interest income | $ | 187 |  |  | $ | 46 |  |  | $ | 141 |  |  | $ | 338 |  |  | $ | 64 |  |  | $ | 274 |  |
| Interest expense | (65) |  |  | (65) |  |  | — |  |  | (131) |  |  | (132) |  |  | 1 |  |
| Other, net | 59 |  |  | (5) |  |  | 64 |  |  | 42 |  |  | (19) |  |  | 61 |  |
| Other income (expense), net | $ | 181 |  |  | $ | (24) |  |  | $ | 205 |  |  | $ | 249 |  |  | $ | (87) |  |  | $ | 336 |  |

[0001045810-23-000175:mdna:74]
[same as prior period, unchanged from 0001045810-23-000093:mdna:69]

[0001045810-23-000175:mdna:75]
[same as prior period, unchanged from 0001045810-23-000093:mdna:70]

[0001045810-23-000175:mdna:76]
Other, net, consists primarily of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. Change in other, net, compared to the second quarter and first half of fiscal year 2023 was primarily driven by mark-to-market gains from publicly traded equity investments.

[0001045810-23-000175:mdna:77]
[same as prior period, unchanged from 0001045810-23-000093:mdna:72]

[0001045810-23-000175:mdna:78]
Income tax was an expense of $793 million and $958 million for the second quarter and first half of fiscal year 2024, respectively, a benefit of $181 million for the second quarter of fiscal year 2023, and an expense of $6 million for the first half of fiscal year 2023. The income tax as a percentage of income before income tax was an expense of 11.4% and 10.4% for the second quarter and first half of fiscal year 2024, respectively, a benefit of 38.0% for the second quarter of fiscal year 2023, and an expense of 0.3% for the first half of fiscal year 2023.

[0001045810-23-000175:mdna:79]
The increase in the effective tax rate was primarily due to a decreased impact of tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit, relative to the increase in income before income tax.

[0001045810-23-000175:mdna:80]
[same as prior period, unchanged from 0001045810-23-000093:mdna:75]

[0001045810-23-000175:mdna:81]
|  | July 30, 2023 |  | January 29, 2023 |
|  | (In millions) |
| Cash and cash equivalents | $ | 5,783 |  |  | $ | 3,389 |  |
| Marketable securities | 10,240 |  |  | 9,907 |  |
| Cash, cash equivalents and marketable securities | $ | 16,023 |  |  | $ | 13,296 |  |

[0001045810-23-000175:mdna:82]
|  | Six Months Ended |
|  | July 30, 2023 |  | July 31, 2022 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 9,259 |  |  | $ | 3,001 |  |
| Net cash provided by (used in) investing activities | $ | (1,287) |  |  | $ | 4,230 |  |
| Net cash used in financing activities | $ | (5,479) |  |  | $ | (6,208) |  |

[0001045810-23-000175:mdna:83]
As of July 30, 2023, we had $16.02 billion in cash, cash equivalents, and marketable securities, an increase of $2.73 billion from the end of fiscal year 2023. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-23-000175:mdna:84]
Cash provided by operating activities increased in the first half of fiscal year 2024 compared to the first half of fiscal year 2023, primarily due to higher revenue and lower inventory, partially offset by higher accounts receivable. Accounts receivable in the second quarter of fiscal year 2024 benefited by approximately $1.25 billion from customer payments received ahead of the invoice due date.

[0001045810-23-000175:mdna:85]
Cash used in investing activities increased in the first half of fiscal year 2024 compared to the first half of fiscal year 2023, primarily driven by lower marketable securities sales and maturities, partially offset by lower purchases of marketable securities.

[0001045810-23-000175:mdna:86]
Cash used in financing activities decreased in the first half of fiscal year 2024 compared to the first half of fiscal year 2023, which primarily reflects lower share repurchases partially offset by a debt repayment in the second quarter of fiscal year 2024.

[0001045810-23-000175:mdna:87]
[same as prior period, unchanged from 0001045810-23-000093:mdna:82]

[0001045810-23-000175:mdna:88]
Our primary sources of liquidity are our cash, cash equivalents, and marketable securities, and the cash generated by our operations. As of July 30, 2023, we had $16.02 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of debt securities issued by the USG and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our debt obligations, future supply obligations and vendor and supplier prepayments. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-23-000175:mdna:89]
Except for approximately $1.38 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of July 30, 2023 are available for use in the U.S. without incurring additional U.S. federal income taxes. We expect to pay approximately $3.81 billion in cash taxes in the third quarter of fiscal year 2024 as we had previously deferred our federal income tax payments due to the disaster relief made available by the Internal Revenue Service for certain California taxpayers.

[0001045810-23-000175:mdna:90]
Primarily based upon increased cash tax payments, we expect that our cash flow from operations will decline in the third quarter of fiscal year 2024 compared to the second quarter of fiscal year 2024.

[0001045810-23-000175:mdna:91]
[same as prior period, unchanged from 0001045810-23-000093:mdna:86]

[0001045810-23-000175:mdna:92]
During the second quarter and first half of fiscal year 2024, we returned $3.28 billion in share repurchases and $99 million and $199 million, respectively, in cash dividends. From July 31, 2023 through August 24, 2023, we repurchased 2 million shares for $998 million pursuant to a Rule 10b5-1 trading plan.

[0001045810-23-000175:mdna:93]
Our cash dividend program and the payment of future cash dividends under that program are subject to the continuing determination by our Board of Directors that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-23-000175:mdna:94]
As of July 30, 2023, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $3.95 billion. On August 21, 2023, our Board of Directors approved an increase to our share repurchase program of an additional $25.00 billion, without expiration. As of August 24, 2023, a total of $27.95 billion was available for repurchase. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities. We plan to continue share repurchases this fiscal year.

[0001045810-23-000175:mdna:95]
The U.S. Inflation Reduction Act of 2022 was enacted on August 16, 2022 and requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. We do not expect this provision to have a material effect on our consolidated financial statements.

[0001045810-23-000175:mdna:96]
[same as prior period, unchanged from 0001045810-23-000093:mdna:89]

[0001045810-23-000175:mdna:97]
Our aggregate debt maturities as of July 30, 2023, by year payable, are as follows:

[0001045810-23-000175:mdna:98]
|  |  | July 30, 2023 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,250 |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 2,750 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (45) |  |
| Net carrying amount |  | 9,705 |  |
| Less short-term portion |  | (1,249) |  |
| Total long-term portion |  | $ | 8,456 |  |

[0001045810-23-000175:mdna:99]
We have a $575 million commercial paper program to support general corporate purposes. As of July 30, 2023, we had not issued any commercial paper.

[0001045810-23-000175:mdna:100]
[same as prior period, unchanged from 0001045810-23-000093:mdna:94]

[0001045810-23-000175:mdna:101]
We have unrecognized tax benefits of $1.25 billion, which includes related interest and penalties of $128 million recorded in non-current income tax payable as of July 30, 2023. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-23-000175:mdna:102]
[same as prior period, unchanged from 0001045810-23-000093:mdna:96]

[0001045810-23-000175:mdna:103]
[same as prior period, unchanged from 0001045810-23-000093:mdna:97]

[0001045810-23-000175:mdna:104]
[same as prior period, unchanged from 0001045810-23-000093:mdna:98]

[0001045810-23-000175:mdna:105]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-23-000175:mdna:106]
There has been no adoption of any new and recently issued accounting pronouncements.
