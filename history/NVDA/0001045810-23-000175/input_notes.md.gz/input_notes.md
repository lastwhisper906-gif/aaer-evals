# NVDA notes — 0001045810-23-000175


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-23-000175:notes:1]
[same as prior period, unchanged from 0001045810-23-000093:notes:1]

[0001045810-23-000175:notes:2]
[same as prior period, unchanged from 0001045810-23-000093:notes:2]

[0001045810-23-000175:notes:3]
[same as prior period, unchanged from 0001045810-23-000093:notes:3]

[0001045810-23-000175:notes:4]
[same as prior period, unchanged from 0001045810-23-000093:notes:4]

[0001045810-23-000175:notes:5]
[same as prior period, unchanged from 0001045810-23-000093:notes:5]

[0001045810-23-000175:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The second quarters of fiscal years 2024 and 2023 were both 13-week quarters.

[0001045810-23-000175:notes:7]
[same as prior period, unchanged from 0001045810-23-000093:notes:7]

[0001045810-23-000175:notes:8]
[same as prior period, unchanged from 0001045810-23-000093:notes:8]

[0001045810-23-000175:notes:9]
[same as prior period, unchanged from 0001045810-23-000093:notes:9]

[0001045810-23-000175:notes:10]
[same as prior period, unchanged from 0001045810-23-000093:notes:10]

[0001045810-23-000175:notes:11]
[same as prior period, unchanged from 0001045810-23-000093:notes:11]

[0001045810-23-000175:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-23-000175:notes:13]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the effect of this change in estimate for the three months ended July 30, 2023 was a benefit of $5 million and $28 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $33 million and net income of $27 million after tax, or $0.01 per both basic and diluted share. The effect of this change in estimate for the first half of fiscal year 2024 was a benefit of $7 million and $59 million for 
cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $66 million and net income of $55 million after tax, or $0.02 per both basic and diluted share.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-23-000175:notes:14]
[same as prior period, unchanged from 0001045810-23-000093:notes:14]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-23-000175:notes:15]
[same as prior period, unchanged from 0001045810-23-000093:notes:15]

[0001045810-23-000175:notes:16]
Future minimum lease payments under our non-cancelable operating leases as of July 30, 2023 are as follows:

[0001045810-23-000175:notes:17]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first half of fiscal year 2024) | $ | 134 |  |
| 2025 | 249 |  |
| 2026 | 227 |  |
| 2027 | 211 |  |
| 2028 | 191 |  |
| 2029 and thereafter | 415 |  |
| Total | 1,427 |  |
| Less imputed interest | 178 |  |
| Present value of net future minimum lease payments | 1,249 |  |
| Less short-term operating lease liabilities | 208 |  |
| Long-term operating lease liabilities | $ | 1,041 |  |

[0001045810-23-000175:notes:18]
In addition, we have operating leases, primarily for our data centers, that are expected to commence between the third quarter of fiscal year 2024 and the end of fiscal year 2025 with lease terms of 3 to 8 years for $205 million.

[0001045810-23-000175:notes:19]
Operating lease expenses were $67 million and $47 million for the second quarter of fiscal years 2024 and 2023, respectively, and $126 million and $90 million for the first half of fiscal years 2024 and 2023, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal years 2024 and 2023 were not significant.

[0001045810-23-000175:notes:20]
[same as prior period, unchanged from 0001045810-23-000093:notes:20]

[0001045810-23-000175:notes:21]
|  | Six Months Ended |
|  | July 30, 2023 |  | July 31, 2022 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 135 |  |  | $ | 91 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 299 |  |  | $ | 98 |  |

[0001045810-23-000175:notes:22]
As of July 30, 2023, our operating leases had a weighted average remaining lease term of 6.5 years and a weighted average discount rate of 3.47%. As of January 29, 2023, our operating leases had a weighted average remaining lease term of 6.8 years and a weighted average discount rate of 3.21%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-23-000175:notes:23]
[same as prior period, unchanged from 0001045810-23-000093:notes:23]

[0001045810-23-000175:notes:24]
[same as prior period, unchanged from 0001045810-23-000093:notes:24]

[0001045810-23-000175:notes:25]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  | (In millions) |
| Cost of revenue | $ | 31 |  |  | $ | 38 |  |  | $ | 58 |  |  | $ | 76 |  |
| Research and development | 600 |  |  | 452 |  |  | 1,124 |  |  | 836 |  |
| Sales, general and administrative | 211 |  |  | 159 |  |  | 394 |  |  | 315 |  |
| Total | $ | 842 |  |  | $ | 649 |  |  | $ | 1,576 |  |  | $ | 1,227 |  |

[0001045810-23-000175:notes:26]
[same as prior period, unchanged from 0001045810-23-000093:notes:26]

[0001045810-23-000175:notes:27]
[same as prior period, unchanged from 0001045810-23-000093:notes:27]

[0001045810-23-000175:notes:28]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 29, 2023 | 45 |  |  | $ | 158.45 |  |  |  |  |  |
| Granted | 13 |  |  | $ | 359.70 |  |  |  |  |  |
| Vested restricted stock | (11) |  |  | $ | 127.12 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 194.70 |  |  |  |  |  |
| Balances, July 30, 2023 | 46 |  |  | $ | 219.47 |  |  |  |  |  |

[0001045810-23-000175:notes:29]
As of July 30, 2023, there was $9.69 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.7 years for RSUs, PSUs, and market-based PSUs, and 1.0 year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-23-000175:notes:30]
[same as prior period, unchanged from 0001045810-23-000093:notes:30]

[0001045810-23-000175:notes:31]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 6,188 |  |  | $ | 656 |  |  | $ | 8,232 |  |  | $ | 2,274 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,473 |  |  | 2,495 |  |  | 2,472 |  |  | 2,500 |  |
| Dilutive impact of outstanding equity awards | 26 |  |  | 21 |  |  | 23 |  |  | 26 |  |
| Diluted weighted average shares | 2,499 |  |  | 2,516 |  |  | 2,495 |  |  | 2,526 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 2.50 |  |  | $ | 0.26 |  |  | $ | 3.33 |  |  | $ | 0.91 |  |
| Diluted (2) | $ | 2.48 |  |  | $ | 0.26 |  |  | $ | 3.30 |  |  | $ | 0.90 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 10 |  |  | 33 |  |  | 14 |  |  | 25 |  |

[0001045810-23-000175:notes:32]
[same as prior period, unchanged from 0001045810-23-000093:notes:32]

[0001045810-23-000175:notes:33]
[same as prior period, unchanged from 0001045810-23-000093:notes:33]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-23-000175:notes:34]
Income Taxes
Income tax was an expense of $793 million and $958 million for the second quarter and first half of fiscal year 2024, respectively, a benefit of $181 million for the second quarter of fiscal year 2023, and an expense of $6 million for the first half of fiscal year 2023. The income tax as a percentage of income before income tax was an expense of 11.4% and 10.4% for the second quarter and first half of fiscal year 2024, respectively, a benefit of 38.0% for the second quarter of fiscal year 2023, and an expense of 0.3% for the first half of fiscal year 2023.

[0001045810-23-000175:notes:35]
The increase in the effective tax rate was primarily due to a decreased impact of tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit, relative to the increase in income before income tax.

[0001045810-23-000175:notes:36]
Our effective tax rates for the first half of fiscal years 2024 and 2023 were lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation and the U.S. federal research tax credit.

[0001045810-23-000175:notes:37]
For the first half of fiscal year 2024, there were no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 29, 2023.

[0001045810-23-000175:notes:38]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 30, 2023, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-23-000175:notes:39]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-23-000175:notes:40]
The following is a summary of cash equivalents and marketable securities:

[0001045810-23-000175:notes:41]
|  | July 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,990 |  |  | $ | 1 |  |  | $ | (13) |  |  | $ | 5,978 |  |  | $ | 2,149 |  |  | $ | 3,829 |  |
| Debt securities issued by the U.S. Treasury | 3,716 |  |  | — |  |  | (31) |  |  | 3,685 |  |  | — |  |  | 3,685 |  |
| Debt securities issued by U.S. government agencies | 2,903 |  |  | — |  |  | (4) |  |  | 2,899 |  |  | 647 |  |  | 2,252 |  |
| Money market funds | 2,348 |  |  | — |  |  | — |  |  | 2,348 |  |  | 2,348 |  |  | — |  |
| Certificates of deposit | 690 |  |  | — |  |  | — |  |  | 690 |  |  | 265 |  |  | 425 |  |
| Foreign government bonds | 248 |  |  | — |  |  | — |  |  | 248 |  |  | 199 |  |  | 49 |  |
| Total | $ | 15,895 |  |  | $ | 1 |  |  | $ | (48) |  |  | $ | 15,848 |  |  | $ | 5,608 |  |  | $ | 10,240 |  |

[0001045810-23-000175:notes:42]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

[0001045810-23-000175:notes:43]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-23-000175:notes:44]
|  | July 30, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,595 |  |  | $ | (16) |  |  | $ | 1,375 |  |  | $ | (15) |  |  | $ | 2,970 |  |  | $ | (31) |  |
| Corporate debt securities | 1,379 |  |  | (9) |  |  | 802 |  |  | (4) |  |  | 2,181 |  |  | (13) |  |
| Debt securities issued by U.S. government agencies | 2,223 |  |  | (4) |  |  | — |  |  | — |  |  | 2,223 |  |  | (4) |  |
| Total | $ | 5,197 |  |  | $ | (29) |  |  | $ | 2,177 |  |  | $ | (19) |  |  | $ | 7,374 |  |  | $ | (48) |  |

[0001045810-23-000175:notes:45]
|  | January 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 2,444 |  |  | $ | (21) |  |  | $ | 1,172 |  |  | $ | (23) |  |  | $ | 3,616 |  |  | $ | (44) |  |
| Corporate debt securities | 1,188 |  |  | (7) |  |  | 696 |  |  | (5) |  |  | 1,884 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,307 |  |  | (2) |  |  | — |  |  | — |  |  | 1,307 |  |  | (2) |  |
| Total | $ | 4,939 |  |  | $ | (30) |  |  | $ | 1,868 |  |  | $ | (28) |  |  | $ | 6,807 |  |  | $ | (58) |  |

[0001045810-23-000175:notes:46]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

[0001045810-23-000175:notes:47]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-23-000175:notes:48]
|  | July 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,613 |  |  | $ | 12,592 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 3,282 |  |  | 3,256 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,895 |  |  | $ | 15,848 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |

[0001045810-23-000175:notes:49]
Restricted cash was $99 million as of July 30, 2023 and primarily represented amounts due to employees.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-23-000175:notes:50]
[same as prior period, unchanged from 0001045810-23-000093:notes:49]

[0001045810-23-000175:notes:51]
|  |  | Fair Value at |
|  | Pricing Category |  | July 30, 2023 |  | January 29, 2023 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 2,348 |  |  | $ | 1,777 |  |
| Corporate debt securities | Level 2 |  | $ | 5,978 |  |  | $ | 4,797 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 3,685 |  |  | $ | 4,142 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,899 |  |  | $ | 1,834 |  |
| Certificates of deposit | Level 2 |  | $ | 690 |  |  | $ | 365 |  |
| Foreign government bonds | Level 2 |  | $ | 248 |  |  | $ | 140 |  |
| Other assets (Investments in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities | Level 1 |  | $ | 124 |  |  | $ | 11 |  |
| Privately-held equity securities | Level 3 |  | $ | 676 |  |  | $ | 288 |  |
| Liabilities (1) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | — |  |  | $ | 1,230 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,199 |  |  | $ | 1,185 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 959 |  |  | $ | 966 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,089 |  |  | $ | 1,099 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,355 |  |  | $ | 1,364 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,042 |  |  | $ | 1,044 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 848 |  |  | $ | 870 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,609 |  |  | $ | 1,637 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 406 |  |  | $ | 410 |  |

[0001045810-23-000175:notes:52]
(1)    These liabilities are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-23-000175:notes:53]
[same as prior period, unchanged from 0001045810-23-000093:notes:53]

[0001045810-23-000175:notes:54]
|  | July 30, 2023 |  | January 29, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 2,642 |  |  | $ | (1,448) |  |  | $ | 1,194 |  |  | $ | 3,093 |  |  | $ | (1,614) |  |  | $ | 1,479 |  |
| Patents and licensed technology | 453 |  |  | (252) |  |  | 201 |  |  | 446 |  |  | (249) |  |  | 197 |  |
| Total intangible assets | $ | 3,095 |  |  | $ | (1,700) |  |  | $ | 1,395 |  |  | $ | 3,539 |  |  | $ | (1,863) |  |  | $ | 1,676 |  |

[0001045810-23-000175:notes:55]
Amortization expense associated with intangible assets was $146 million and $327 million for the second quarter and first half of fiscal year 2024, respectively, and $182 million and $336 million for the second quarter and first half of fiscal year 2023, respectively.

[0001045810-23-000175:notes:56]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of July 30, 2023:

[0001045810-23-000175:notes:57]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first half of fiscal year 2024) | $ | 288 |  |
| 2025 | 554 |  |
| 2026 | 259 |  |
| 2027 | 149 |  |
| 2028 | 36 |  |
| 2029 and thereafter | 109 |  |
| Total | $ | 1,395 |  |

[0001045810-23-000175:notes:58]
In the first half of fiscal year 2024, goodwill increased by $58 million from an acquisition, and was assigned to our Compute & Networking segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-23-000175:notes:59]
[same as prior period, unchanged from 0001045810-23-000093:notes:59]

[0001045810-23-000175:notes:60]
|  | July 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Inventories (1): | (In millions) |
| Raw materials | $ | 1,632 |  |  | $ | 2,430 |  |
| Work in-process | 1,058 |  |  | 466 |  |
| Finished goods | 1,629 |  |  | 2,263 |  |
| Total inventories | $ | 4,319 |  |  | $ | 5,159 |  |

[0001045810-23-000175:notes:61]
(1)    During the second quarter of fiscal years 2024 and 2023, we recorded an inventory provision of approximately $343 million and $570 million, respectively, in cost of revenue.

[0001045810-23-000175:notes:62]
|  | July 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Other Assets: | (In millions) |
| Prepaid supply and capacity agreements (1) | $ | 3,008 |  |  | $ | 2,989 |  |
| Investments in non-affiliated entities | 800 |  |  | 299 |  |
| Prepaid royalties | 375 |  |  | 387 |  |
| Prepaid cloud services | 170 |  |  | 23 |  |
| Other | 148 |  |  | 122 |  |
| Total other assets | $ | 4,501 |  |  | $ | 3,820 |  |

[0001045810-23-000175:notes:63]
(1)    As of July 30, 2023 and January 29, 2023, there were $799 million and $458 million of short-term prepaid supply and capacity agreements included in Prepaid expenses and other current assets, respectively.

[0001045810-23-000175:notes:64]
|  | July 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Accrued and Other Current Liabilities: | (In millions) |
| Taxes payable | $ | 2,803 |  |  | $ | 467 |  |
| Customer program accruals | 1,482 |  |  | 1,196 |  |
| Excess inventory purchase obligations (1) | 870 |  |  | 954 |  |
| Accrued payroll and related expenses | 642 |  |  | 530 |  |
| Deferred revenue (2) | 421 |  |  | 354 |  |
| Unsettled share repurchases | 217 |  |  | — |  |
| Operating leases | 208 |  |  | 176 |  |
| Product warranty and return provisions | 168 |  |  | 108 |  |
| Licenses and royalties | 144 |  |  | 149 |  |
| Other | 201 |  |  | 186 |  |
| Total accrued and other current liabilities | $ | 7,156 |  |  | $ | 4,120 |  |

[0001045810-23-000175:notes:65]
(1)    During the second quarter of fiscal years 2024 and 2023, we recorded an expense of approximately $232 million and $650 million, respectively, in cost of revenue for inventory purchase obligations in excess of our current demand projections, and cancellation and underutilization penalties.

[0001045810-23-000175:notes:66]
(2)    Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements, support for hardware and software, and cloud services.

[0001045810-23-000175:notes:67]
|  | July 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,350 |  |  | $ | 1,204 |  |
| Deferred income tax | 373 |  |  | 247 |  |
| Deferred revenue (2) | 308 |  |  | 218 |  |
| Licenses payable | 127 |  |  | 181 |  |
| Other | 65 |  |  | 63 |  |
| Total other long-term liabilities | $ | 2,223 |  |  | $ | 1,913 |  |

[0001045810-23-000175:notes:68]
[same as prior period, unchanged from 0001045810-23-000093:notes:65]

[0001045810-23-000175:notes:69]
[same as prior period, unchanged from 0001045810-23-000093:notes:66]

[0001045810-23-000175:notes:70]
[same as prior period, unchanged from 0001045810-23-000093:notes:67]

[0001045810-23-000175:notes:71]
The following table shows the changes in deferred revenue during the first half of fiscal years 2024 and 2023:

[0001045810-23-000175:notes:72]
|  | July 30, |  | July 31, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 572 |  |  | $ | 502 |  |
| Deferred revenue additions during the period | 713 |  |  | 399 |  |
| Revenue recognized during the period | (556) |  |  | (341) |  |
| Balance at end of period | $ | 729 |  |  | $ | 560 |  |

[0001045810-23-000175:notes:73]
Revenue allocated to remaining performance obligations, which includes deferred revenue and amounts that will be invoiced and recognized as revenue in future periods, was $717 million as of July 30, 2023. We expect to recognize approximately 44% of this revenue over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-23-000175:notes:74]
[same as prior period, unchanged from 0001045810-23-000093:notes:71]

[0001045810-23-000175:notes:75]
[same as prior period, unchanged from 0001045810-23-000093:notes:72]

[0001045810-23-000175:notes:76]
[same as prior period, unchanged from 0001045810-23-000093:notes:73]

[0001045810-23-000175:notes:77]
|  | July 30,2023 |  | January 29,2023 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,138 |  |  | $ | 1,128 |  |
| Non-designated hedges | $ | 367 |  |  | $ | 366 |  |

[0001045810-23-000175:notes:78]
The unrealized gains and losses or fair value of our foreign currency forward contracts was not significant as of July 30, 2023 and January 29, 2023.

[0001045810-23-000175:notes:79]
As of July 30, 2023, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-23-000175:notes:80]
During the first half of fiscal years 2024 and 2023, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-23-000175:notes:81]
Debt
Long-Term Debt

[0001045810-23-000175:notes:82]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:

[0001045810-23-000175:notes:83]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (45) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,705 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,456 |  |  | $ | 9,703 |  |

[0001045810-23-000175:notes:84]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-23-000175:notes:85]
On June 15, 2023, we repaid the 0.309% Notes Due 2023.

[0001045810-23-000175:notes:86]
As of July 30, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-23-000175:notes:87]
Commercial Paper

[0001045810-23-000175:notes:88]
We have a $575 million commercial paper program to support general corporate purposes. As of July 30, 2023, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-23-000175:notes:89]
Commitments and Contingencies
Purchase Obligations

[0001045810-23-000175:notes:90]
Our purchase obligations reflect our commitments to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-23-000175:notes:91]
As of July 30, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $11.15 billion. During the normal course of business, to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being

[0001045810-23-000175:notes:92]
placed, but these changes may result in the payment of costs incurred through the date of cancellation. Other non-inventory purchase obligations of $4.31 billion include $3.50 billion of multi-year cloud service agreements.

[0001045810-23-000175:notes:93]
Total future purchase commitments as of July 30, 2023 are as follows:

[0001045810-23-000175:notes:94]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first half of fiscal year 2024) | $ | 8,439 |  |
| 2025 | 3,960 |  |
| 2026 | 957 |  |
| 2027 | 999 |  |
| 2028 | 637 |  |
| 2029 and thereafter | 468 |  |
| Total | $ | 15,460 |  |

[0001045810-23-000175:notes:95]
Accrual for Product Warranty Liabilities

[0001045810-23-000175:notes:96]
The estimated amount of product warranty liabilities was $115 million and $82 million as of July 30, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

[0001045810-23-000175:notes:97]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2023 |  | July 31, 2022 |  | July 30, 2023 |  | July 31, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 77 |  |  | $ | 55 |  |  | $ | 82 |  |  | $ | 46 |  |
| Additions | 42 |  | 122 |  | 55 |  | 138 |
| Utilization | (4) |  |  | (9) |  |  | (22) |  |  | (16) |  |
| Balance at end of period | $ | 115 |  |  | $ | 168 |  |  | $ | 115 |  |  | $ | 168 |  |

[0001045810-23-000175:notes:98]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-23-000175:notes:99]
Litigation

[0001045810-23-000175:notes:100]
Securities Class Action and Derivative Lawsuits

[0001045810-23-000175:notes:101]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment

[0001045810-23-000175:notes:102]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case.

[0001045810-23-000175:notes:103]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-23-000175:notes:104]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-23-000175:notes:105]
Accounting for Loss Contingencies

[0001045810-23-000175:notes:106]
As of July 30, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-23-000175:notes:107]
[same as prior period, unchanged from 0001045810-23-000093:notes:103]

[0001045810-23-000175:notes:108]
During the second quarter and first half of fiscal year 2024, we repurchased 7.5 million shares of our common stock for $3.28 billion. During the second quarter and first half of fiscal year 2023, we repurchased 19 million and 28 million shares for $3.35 billion and $5.34 billion, respectively. Since the inception of our share repurchase program through July 30, 2023, we have repurchased an aggregate of 1.11 billion shares for a total cost of $20.40 billion. As of July 30, 2023, we were authorized, subject to certain specifications, to repurchase shares of our common stock up to $3.95 billion. On August 21, 2023, our Board of Directors approved an increase to our share repurchase program of an additional $25.00 billion, without expiration. From July 31, 2023 through August 24, 2023, we repurchased 2 million shares for $998 million pursuant to a Rule 10b5-1 trading plan. As of August 24, 2023, a total of $27.95 billion was available for repurchase. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-23-000175:notes:109]
During the second quarter and first half of fiscal year 2024, we paid $99 million and $199 million in cash dividends to our shareholders, respectively. During the second quarter and first half of fiscal year 2023, we paid $100 million and $200 million in cash dividends to our shareholders, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' 
continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-23-000175:notes:110]
[same as prior period, unchanged from 0001045810-23-000093:notes:106]

[0001045810-23-000175:notes:111]
The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive artificial intelligence, or AI, Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and cryptocurrency mining processors, or CMP.

[0001045810-23-000175:notes:112]
The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; virtual GPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating 3D internet applications.

[0001045810-23-000175:notes:113]
[same as prior period, unchanged from 0001045810-23-000093:notes:110]

[0001045810-23-000175:notes:114]
The “All Other” category includes the expenses that our CODM does not assign to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, acquisition-related and other costs, corporate infrastructure and support costs, acquisition termination cost, intellectual property related, or IP-related and legal settlement costs, contributions, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-23-000175:notes:115]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, our CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-23-000175:notes:116]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 30, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 10,402 |  |  | $ | 3,105 |  |  | $ | — |  |  | $ | 13,507 |  |
| Operating income (loss) | $ | 6,728 |  |  | $ | 1,211 |  |  | $ | (1,139) |  |  | $ | 6,800 |  |
| Three Months Ended July 31, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 3,907 |  |  | $ | 2,797 |  |  | $ | — |  |  | $ | 6,704 |  |
| Operating income (loss) | $ | 816 |  |  | $ | 657 |  |  | $ | (974) |  |  | $ | 499 |  |
| Six Months Ended July 30, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 14,862 |  |  | $ | 5,837 |  |  | $ | — |  |  | $ | 20,699 |  |
| Operating income (loss) | $ | 8,887 |  |  | $ | 2,258 |  |  | $ | (2,204) |  |  | $ | 8,941 |  |
| Six Months Ended July 31, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 7,579 |  |  | $ | 7,413 |  |  | $ | — |  |  | $ | 14,992 |  |
| Operating income (loss) | $ | 2,422 |  |  | $ | 3,133 |  |  | $ | (3,188) |  |  | $ | 2,367 |  |

[0001045810-23-000175:notes:117]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (842) |  |  | $ | (649) |  |  | $ | (1,576) |  |  | $ | (1,227) |  |
| Unallocated cost of revenue and operating expenses | (163) |  |  | (148) |  |  | (317) |  |  | (275) |  |
| Acquisition-related and other costs | (137) |  |  | (175) |  |  | (311) |  |  | (324) |  |
| IP-related and legal settlement costs | (2) |  |  | — |  |  | (10) |  |  | (7) |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | (1,353) |  |
| Contributions | — |  |  | (2) |  |  | — |  |  | (2) |  |
| Other | 5 |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | (1,139) |  |  | $ | (974) |  |  | $ | (2,204) |  |  | $ | (3,188) |  |

[0001045810-23-000175:notes:118]
Revenue by geographic region is allocated to individual countries based on the billing location of the customer. End customer location may be different than our customer’s billing location. The following table

[0001045810-23-000175:notes:119]
summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-23-000175:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 6,043 |  |  | $ | 1,988 |  |  | $ | 8,428 |  |  | $ | 3,921 |  |
| Taiwan | 2,839 |  |  | 1,204 |  |  | 4,635 |  |  | 3,981 |  |
| China (including Hong Kong) | 2,740 |  |  | 1,602 |  |  | 4,330 |  |  | 3,683 |  |
| Other countries | 1,885 |  |  | 1,910 |  |  | 3,306 |  |  | 3,407 |  |
| Total revenue | $ | 13,507 |  |  | $ | 6,704 |  |  | $ | 20,699 |  |  | $ | 14,992 |  |

[0001045810-23-000175:notes:121]
One data center distributor customer represented approximately 17% and 13% of total revenue for the second quarter and first half of fiscal year 2024, respectively, and was attributable to the Compute & Networking segment. There were no customers with 10% or more of total revenue for the second quarter and first half of fiscal year 2023.

[0001045810-23-000175:notes:122]
A large cloud service provider, or CSP, which primarily purchases indirectly through multiple system integrators and distributors, is estimated to represent approximately 22% and 19% of total revenue for the second quarter and first half of fiscal year 2024, respectively, and was attributable to our Compute & Networking segment.

[0001045810-23-000175:notes:123]
Two customers accounted for 16% and 13% of our accounts receivable balance as of July 30, 2023. Two customers accounted for 14% and 11% of our accounts receivable balance as of January 29, 2023.

[0001045810-23-000175:notes:124]
[same as prior period, unchanged from 0001045810-23-000093:notes:119]

[0001045810-23-000175:notes:125]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 10,323 |  |  | $ | 3,806 |  |  | $ | 14,607 |  |  | $ | 7,556 |  |
| Gaming | 2,486 |  |  | 2,042 |  |  | 4,726 |  |  | 5,662 |  |
| Professional Visualization | 379 |  |  | 496 |  |  | 674 |  |  | 1,118 |  |
| Automotive | 253 |  |  | 220 |  |  | 549 |  |  | 358 |  |
| OEM and Other | 66 |  |  | 140 |  |  | 143 |  |  | 298 |  |
| Total revenue | $ | 13,507 |  |  | $ | 6,704 |  |  | $ | 20,699 |  |  | $ | 14,992 |  |
