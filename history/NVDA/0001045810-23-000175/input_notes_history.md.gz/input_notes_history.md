# NVDA note change history — 0001045810-23-000093 → 0001045810-23-000175


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-28):
[0001045810-23-000175:note_history:1]
As of July 30, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $11.15 billion. During the normal course of business, to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being
  (was, 2023-05-26, similarity 0.9017):
[0001045810-23-000093:note_history:1]
As of April 30, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $7.27 billion. During the normal course of business, to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of cancellation.

- changed (2023-08-28):
[0001045810-23-000175:note_history:2]
placed, but these changes may result in the payment of costs incurred through the date of cancellation. Other non-inventory purchase obligations of $4.31 billion include $3.50 billion of multi-year cloud service agreements.
  (was, 2023-05-26, similarity 0.6848):
[0001045810-23-000093:note_history:2]
Other non-inventory purchase obligations of $3.26 billion include $2.43 billion of multi-year cloud service agreements.

- changed (2023-08-28):
[0001045810-23-000175:note_history:3]
Total future purchase commitments as of July 30, 2023 are as follows:
  (was, 2023-05-26, similarity 0.9457):
[0001045810-23-000093:note_history:3]
Total future purchase commitments as of April 30, 2023 are as follows:

- changed (2023-08-28):
[0001045810-23-000175:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first half of fiscal year 2024) | $ | 8,439 |  |
| 2025 | 3,960 |  |
| 2026 | 957 |  |
| 2027 | 999 |  |
| 2028 | 637 |  |
| 2029 and thereafter | 468 |  |
| Total | $ | 15,460 |  |
  (was, 2023-05-26, similarity 0.94):
[0001045810-23-000093:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first quarter) | $ | 6,667 |  |
| 2025 | 1,816 |  |
| 2026 | 753 |  |
| 2027 | 704 |  |
| 2028 | 332 |  |
| 2029 and thereafter | 255 |  |
| Total | $ | 10,527 |  |

- changed (2023-08-28):
[0001045810-23-000175:note_history:5]
The estimated amount of product warranty liabilities was $115 million and $82 million as of July 30, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:
  (was, 2023-05-26, similarity 0.98):
[0001045810-23-000093:note_history:5]
The estimated amount of product warranty liabilities was $77 million and $82 million as of April 30, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

- changed (2023-08-28):
[0001045810-23-000175:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2023 |  | July 31, 2022 |  | July 30, 2023 |  | July 31, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 77 |  |  | $ | 55 |  |  | $ | 82 |  |  | $ | 46 |  |
| Additions | 42 |  | 122 |  | 55 |  | 138 |
| Utilization | (4) |  |  | (9) |  |  | (22) |  |  | (16) |  |
| Balance at end of period | $ | 115 |  |  | $ | 168 |  |  | $ | 115 |  |  | $ | 168 |  |
  (was, 2023-05-26, similarity 0.7697):
[0001045810-23-000093:note_history:6]
|  | Three Months Ended |  |  |
|  | April 30, 2023 |  | May 1, 2022 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 82 |  |  | $ | 46 |  |  |  |  |  |
| Additions | 13 |  | 16 |  |  |  |  |
| Utilization | (18) |  |  | (7) |  |  |  |  |  |
| Balance at end of period | $ | 77 |  |  | $ | 55 |  |  |  |  |  |

- added (2023-08-28):
[0001045810-23-000175:note_history:7]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case.

- added (2023-08-28):
[0001045810-23-000175:note_history:8]
As of July 30, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2023-08-28):
[0001045810-23-000093:note_history:9]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

- removed (2023-08-28):
[0001045810-23-000093:note_history:10]
As of April 30, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-28):
[0001045810-23-000175:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The second quarters of fiscal years 2024 and 2023 were both 13-week quarters.
  (was, 2023-05-26, similarity 0.9759):
[0001045810-23-000093:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The first quarters of fiscal years 2024 and 2023 were both 13-week quarters.

- changed (2023-08-28):
[0001045810-23-000175:note_history:12]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the effect of this change in estimate for the three months ended July 30, 2023 was a benefit of $5 million and $28 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $33 million and net income of $27 million after tax, or $0.01 per both basic and diluted share. The effect of this change in estimate for the first half of fiscal year 2024 was a benefit of $7 million and $59 million for 
cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $66 million and net income of $55 million after tax, or $0.02 per both basic and diluted share.
  (was, 2023-05-26, similarity 0.8407):
[0001045810-23-000093:note_history:12]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the effect of this change in estimate for the three months ended April 30, 2023, was a benefit of $2 million and $31 million for cost of revenue and operating expenses, respectively. This resulted in an increase in operating income of $33 million and net income of $28 million after tax, or $0.01 per both basic and diluted share.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-28):
[0001045810-23-000175:note_history:13]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (45) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,705 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,456 |  |  | $ | 9,703 |  |
  (was, 2023-05-26, similarity 0.9934):
[0001045810-23-000093:note_history:13]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (46) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 10,954 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 9,704 |  |  | $ | 9,703 |  |

- added (2023-08-28):
[0001045810-23-000175:note_history:14]
On June 15, 2023, we repaid the 0.309% Notes Due 2023.

- changed (2023-08-28):
[0001045810-23-000175:note_history:15]
As of July 30, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2023-05-26, similarity 0.973):
[0001045810-23-000093:note_history:15]
As of April 30, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2023-08-28):
[0001045810-23-000175:note_history:16]
We have a $575 million commercial paper program to support general corporate purposes. As of July 30, 2023, we had not issued any commercial paper.
  (was, 2023-05-26, similarity 0.9749):
[0001045810-23-000093:note_history:16]
We have a $575 million commercial paper program to support general corporate purposes. As of April 30, 2023, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-28):
[0001045810-23-000175:note_history:17]
|  | July 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,990 |  |  | $ | 1 |  |  | $ | (13) |  |  | $ | 5,978 |  |  | $ | 2,149 |  |  | $ | 3,829 |  |
| Debt securities issued by the U.S. Treasury | 3,716 |  |  | — |  |  | (31) |  |  | 3,685 |  |  | — |  |  | 3,685 |  |
| Debt securities issued by U.S. government agencies | 2,903 |  |  | — |  |  | (4) |  |  | 2,899 |  |  | 647 |  |  | 2,252 |  |
| Money market funds | 2,348 |  |  | — |  |  | — |  |  | 2,348 |  |  | 2,348 |  |  | — |  |
| Certificates of deposit | 690 |  |  | — |  |  | — |  |  | 690 |  |  | 265 |  |  | 425 |  |
| Foreign government bonds | 248 |  |  | — |  |  | — |  |  | 248 |  |  | 199 |  |  | 49 |  |
| Total | $ | 15,895 |  |  | $ | 1 |  |  | $ | (48) |  |  | $ | 15,848 |  |  | $ | 5,608 |  |  | $ | 10,240 |  |

- added (2023-08-28):
[0001045810-23-000175:note_history:18]
|  | July 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,613 |  |  | $ | 12,592 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 3,282 |  |  | 3,256 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,895 |  |  | $ | 15,848 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |

- removed (2023-08-28):
[0001045810-23-000093:note_history:19]
|  | April 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,723 |  |  | $ | 4 |  |  | $ | (11) |  |  | $ | 6,716 |  |  | $ | 2,535 |  |  | $ | 4,181 |  |
| Debt securities issued by the U.S. Treasury | 3,996 |  |  | 2 |  |  | (31) |  |  | 3,967 |  |  | 421 |  |  | 3,546 |  |
| Debt securities issued by U.S. government agencies | 2,442 |  |  | 1 |  |  | (1) |  |  | 2,442 |  |  | 199 |  |  | 2,243 |  |
| Money market funds | 1,502 |  |  | — |  |  | — |  |  | 1,502 |  |  | 1,502 |  |  | — |  |
| Certificates of deposit | 395 |  |  | — |  |  | — |  |  | 395 |  |  | 173 |  |  | 222 |  |
| Foreign government bonds | 49 |  |  | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Total | $ | 15,107 |  |  | $ | 7 |  |  | $ | (43) |  |  | $ | 15,071 |  |  | $ | 4,830 |  |  | $ | 10,241 |  |

- removed (2023-08-28):
[0001045810-23-000093:note_history:20]
|  | April 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,654 |  |  | $ | 12,625 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 2,453 |  |  | 2,446 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,107 |  |  | $ | 15,071 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-28):
[0001045810-23-000175:note_history:21]
|  | July 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,990 |  |  | $ | 1 |  |  | $ | (13) |  |  | $ | 5,978 |  |  | $ | 2,149 |  |  | $ | 3,829 |  |
| Debt securities issued by the U.S. Treasury | 3,716 |  |  | — |  |  | (31) |  |  | 3,685 |  |  | — |  |  | 3,685 |  |
| Debt securities issued by U.S. government agencies | 2,903 |  |  | — |  |  | (4) |  |  | 2,899 |  |  | 647 |  |  | 2,252 |  |
| Money market funds | 2,348 |  |  | — |  |  | — |  |  | 2,348 |  |  | 2,348 |  |  | — |  |
| Certificates of deposit | 690 |  |  | — |  |  | — |  |  | 690 |  |  | 265 |  |  | 425 |  |
| Foreign government bonds | 248 |  |  | — |  |  | — |  |  | 248 |  |  | 199 |  |  | 49 |  |
| Total | $ | 15,895 |  |  | $ | 1 |  |  | $ | (48) |  |  | $ | 15,848 |  |  | $ | 5,608 |  |  | $ | 10,240 |  |

- changed (2023-08-28):
[0001045810-23-000175:note_history:22]
|  | July 30, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,595 |  |  | $ | (16) |  |  | $ | 1,375 |  |  | $ | (15) |  |  | $ | 2,970 |  |  | $ | (31) |  |
| Corporate debt securities | 1,379 |  |  | (9) |  |  | 802 |  |  | (4) |  |  | 2,181 |  |  | (13) |  |
| Debt securities issued by U.S. government agencies | 2,223 |  |  | (4) |  |  | — |  |  | — |  |  | 2,223 |  |  | (4) |  |
| Total | $ | 5,197 |  |  | $ | (29) |  |  | $ | 2,177 |  |  | $ | (19) |  |  | $ | 7,374 |  |  | $ | (48) |  |
  (was, 2023-05-26, similarity 0.7374):
[0001045810-23-000093:note_history:22]
|  | April 30, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,601 |  |  | $ | (11) |  |  | $ | 1,106 |  |  | $ | (20) |  |  | $ | 2,707 |  |  | $ | (31) |  |
| Debt securities issued by U.S. government agencies | 1,259 |  |  | (1) |  |  | — |  |  | — |  |  | 1,259 |  |  | (1) |  |
| Corporate debt securities | 945 |  |  | (4) |  |  | 838 |  |  | (7) |  |  | 1,783 |  |  | (11) |  |
| Total | $ | 3,805 |  |  | $ | (16) |  |  | $ | 1,944 |  |  | $ | (27) |  |  | $ | 5,749 |  |  | $ | (43) |  |

- added (2023-08-28):
[0001045810-23-000175:note_history:23]
|  | July 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,613 |  |  | $ | 12,592 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 3,282 |  |  | 3,256 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,895 |  |  | $ | 15,848 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |

- added (2023-08-28):
[0001045810-23-000175:note_history:24]
Restricted cash was $99 million as of July 30, 2023 and primarily represented amounts due to employees.

- removed (2023-08-28):
[0001045810-23-000093:note_history:25]
|  | April 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,723 |  |  | $ | 4 |  |  | $ | (11) |  |  | $ | 6,716 |  |  | $ | 2,535 |  |  | $ | 4,181 |  |
| Debt securities issued by the U.S. Treasury | 3,996 |  |  | 2 |  |  | (31) |  |  | 3,967 |  |  | 421 |  |  | 3,546 |  |
| Debt securities issued by U.S. government agencies | 2,442 |  |  | 1 |  |  | (1) |  |  | 2,442 |  |  | 199 |  |  | 2,243 |  |
| Money market funds | 1,502 |  |  | — |  |  | — |  |  | 1,502 |  |  | 1,502 |  |  | — |  |
| Certificates of deposit | 395 |  |  | — |  |  | — |  |  | 395 |  |  | 173 |  |  | 222 |  |
| Foreign government bonds | 49 |  |  | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Total | $ | 15,107 |  |  | $ | 7 |  |  | $ | (43) |  |  | $ | 15,071 |  |  | $ | 4,830 |  |  | $ | 10,241 |  |

- removed (2023-08-28):
[0001045810-23-000093:note_history:26]
|  | April 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,654 |  |  | $ | 12,625 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 2,453 |  |  | 2,446 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,107 |  |  | $ | 15,071 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-28):
[0001045810-23-000175:note_history:27]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (45) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,705 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,456 |  |  | $ | 9,703 |  |
  (was, 2023-05-26, similarity 0.9934):
[0001045810-23-000093:note_history:27]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (46) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 10,954 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 9,704 |  |  | $ | 9,703 |  |
