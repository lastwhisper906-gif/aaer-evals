# NVDA 8-K — 0001045810-23-000171 filed 2023-08-23

## item codes, every 8-K on or before 2023-08-28

- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2023-08-28

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-23-000171:8k_2_02:1]
EX-99.1
2
q2fy24pr.htm
Q2FY24 PRESS RELEASE

[0001045810-23-000171:8k_2_02:2]
Document

[0001045810-23-000171:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-23-000171:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2024

[0001045810-23-000171:8k_2_02:5]
•Record revenue of $13.51 billion, up 88% from Q1, up 101% from year ago

[0001045810-23-000171:8k_2_02:6]
•Record Data Center revenue of $10.32 billion, up 141% from Q1, up 171% from year ago

[0001045810-23-000171:8k_2_02:7]
SANTA CLARA, Calif.—Aug. 23, 2023―NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 30, 2023, of $13.51 billion, up 101% from a year ago and up 88% from the previous quarter.

[0001045810-23-000171:8k_2_02:8]
GAAP earnings per diluted share for the quarter were $2.48, up 854% from a year ago and up 202% from the previous quarter. Non-GAAP earnings per diluted share were $2.70, up 429% from a year ago and up 148% from the previous quarter.

[0001045810-23-000171:8k_2_02:9]
“A new computing era has begun. Companies worldwide are transitioning from general-purpose to accelerated computing and generative AI,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-23-000171:8k_2_02:10]
“NVIDIA GPUs connected by our Mellanox networking and switch technologies and running our CUDA AI software stack make up the computing infrastructure of generative AI.

[0001045810-23-000171:8k_2_02:11]
“During the quarter, major cloud service providers announced massive NVIDIA H100 AI infrastructures. Leading enterprise IT system and software providers announced partnerships to bring NVIDIA AI to every industry. The race is on to adopt generative AI,” he said.

[0001045810-23-000171:8k_2_02:12]
During the second quarter of fiscal 2024, NVIDIA returned $3.38 billion to shareholders in the form of 7.5 million shares repurchased for $3.28 billion, and cash dividends. As of the end of the second quarter, the company had $3.95 billion remaining under its share repurchase authorization. On August 21, 2023, the Board of Directors approved an additional $25.00 billion in share repurchases, without expiration. NVIDIA plans to continue share repurchases this fiscal year.

[0001045810-23-000171:8k_2_02:13]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on September 28, 2023, to all shareholders of record on September 7, 2023.

[0001045810-23-000171:8k_2_02:14]
Q2 Fiscal 2024 Summary

[0001045810-23-000171:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY24 | Q1 FY24 | Q2 FY23 | Q/Q | Y/Y |
| Revenue | $13,507 | $7,192 | $6,704 | Up 88% | Up 101% |
| Gross margin | 70.1 | % | 64.6 | % | 43.5 | % | Up 5.5 pts | Up 26.6 pts |
| Operating expenses | $2,662 | $2,508 | $2,416 | Up 6% | Up 10% |
| Operating income | $6,800 | $2,140 | $499 | Up 218% | Up 1,263% |
| Net income | $6,188 | $2,043 | $656 | Up 203% | Up 843% |
| Diluted earnings per share | $2.48 | $0.82 | $0.26 | Up 202% | Up 854% |

[0001045810-23-000171:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY24 | Q1 FY24 | Q2 FY23 | Q/Q | Y/Y |
| Revenue | $13,507 | $7,192 | $6,704 | Up 88% | Up 101% |
| Gross margin | 71.2 | % | 66.8 | % | 45.9 | % | Up 4.4 pts | Up 25.3 pts |
| Operating expenses | $1,838 | $1,750 | $1,749 | Up 5% | Up 5% |
| Operating income | $7,776 | $3,052 | $1,325 | Up 155% | Up 487% |
| Net income | $6,740 | $2,713 | $1,292 | Up 148% | Up 422% |
| Diluted earnings per share | $2.70 | $1.09 | $0.51 | Up 148% | Up 429% |

[0001045810-23-000171:8k_2_02:17]
Outlook

[0001045810-23-000171:8k_2_02:18]
NVIDIA’s outlook for the third quarter of fiscal 2024 is as follows:

[0001045810-23-000171:8k_2_02:19]
•Revenue is expected to be $16.00 billion, plus or minus 2%.

[0001045810-23-000171:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 71.5% and 72.5%, respectively, plus or minus 50 basis points.

[0001045810-23-000171:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.95 billion and $2.00 billion, respectively.

[0001045810-23-000171:8k_2_02:22]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $100 million, excluding gains and losses from non-affiliated investments.

[0001045810-23-000171:8k_2_02:23]
•GAAP and non-GAAP tax rates are expected to be 14.5%, plus or minus 1%, excluding any discrete items.

[0001045810-23-000171:8k_2_02:24]
Highlights

[0001045810-23-000171:8k_2_02:25]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-23-000171:8k_2_02:26]
Data Center

[0001045810-23-000171:8k_2_02:27]
•Second-quarter revenue was a record $10.32 billion, up 141% from the previous quarter and up 171% from a year ago.

[0001045810-23-000171:8k_2_02:28]
•Announced that the NVIDIA® GH200 Grace™ Hopper™ Superchip for complex AI and HPC workloads is shipping this quarter, with a second-generation version with HBM3e memory expected to ship in Q2 of calendar 2024.

[0001045810-23-000171:8k_2_02:29]
•Announced the NVIDIA L40S GPU — a universal data center processor designed to accelerate the most compute-intensive applications — available from leading server makers in a broad range of platforms, including NVIDIA OVX™ and NVIDIA AI-ready servers with NVIDIA BlueField® DPUs, beginning this quarter.

[0001045810-23-000171:8k_2_02:30]
•Unveiled NVIDIA MGX™, a server reference design available this quarter that lets system makers quickly and cost-effectively build more than 100 server variations for AI, HPC and NVIDIA Omniverse™ applications.

[0001045810-23-000171:8k_2_02:31]
•Announced NVIDIA Spectrum-X™, an accelerated networking platform designed to improve the performance and efficiency of Ethernet-based AI clouds, which is shipping this quarter.

[0001045810-23-000171:8k_2_02:32]
•Joined with global system makers to announce new NVIDIA RTX™ workstations with up to four new NVIDIA RTX 6000 Ada GPUs, as well as NVIDIA AI Enterprise and NVIDIA Omniverse Enterprise software, expected to ship this quarter.

[0001045810-23-000171:8k_2_02:33]
•Launched general availability of cloud instances based on NVIDIA H100 Tensor Core GPUs with Amazon Web Services, Microsoft Azure and regional cloud service providers.

[0001045810-23-000171:8k_2_02:34]
•Partnered with a range of companies on AI initiatives, including:

[0001045810-23-000171:8k_2_02:35]
◦ServiceNow and Accenture to develop AI Lighthouse, a first-of-its-kind program to fast-track the development and adoption of enterprise generative AI capabilities.

[0001045810-23-000171:8k_2_02:36]
◦VMware to extend the companies’ strategic partnership to ready enterprises running VMware’s cloud infrastructure for the era of generative AI with VMware Private AI Foundation with NVIDIA.

[0001045810-23-000171:8k_2_02:37]
◦Snowflake to provide businesses with an accelerated path to create customized generative AI applications using their own proprietary data.

[0001045810-23-000171:8k_2_02:38]
◦WPP to develop a generative AI-enabled content engine that lets creative teams produce high-quality commercial content faster, more efficiently and at scale while staying fully aligned with a client’s brand.

[0001045810-23-000171:8k_2_02:39]
◦SoftBank to create a platform for generative AI and 5G/6G applications based on the GH200, which SoftBank plans to roll out at new, distributed AI data centers across Japan.

[0001045810-23-000171:8k_2_02:40]
◦Hugging Face to give developers access to NVIDIA DGX™ Cloud AI supercomputing within the Hugging Face platform to train and tune advanced AI models.

[0001045810-23-000171:8k_2_02:41]
•Announced NVIDIA AI Workbench, an easy-to-use toolkit allowing developers to quickly create, test and customize pretrained generative AI models on a PC or workstation and then scale them, as well as NVIDIA AI Enterprise 4.0, the latest version of its enterprise software.

[0001045810-23-000171:8k_2_02:42]
•Set records in the latest MLPerf training benchmarks with H100 GPUs, excelling in a new measure for generative AI.

[0001045810-23-000171:8k_2_02:43]
Gaming

[0001045810-23-000171:8k_2_02:44]
•Second-quarter revenue was $2.49 billion, up 11% from the previous quarter and up 22% from a year ago.

[0001045810-23-000171:8k_2_02:45]
•Began shipping the GeForce RTX™ 4060 family of GPUs, bringing to gamers NVIDIA Ada Lovelace architecture and DLSS, starting at $299.

[0001045810-23-000171:8k_2_02:46]
•Announced NVIDIA Avatar Cloud Engine, or ACE, for Games, a custom AI model foundry service using AI-powered natural language interactions to transform games by bringing intelligence to non-playable characters.

[0001045810-23-000171:8k_2_02:47]
•Added 35 DLSS games, including Diablo IV, Ratchet & Clank: Rift Apart, Baldur’s Gate 3 and F1 23, as well as Portal: Prelude RTX, a path-traced game made by the community using NVIDIA’s RTX Remix creator tool.

[0001045810-23-000171:8k_2_02:48]
Professional Visualization

[0001045810-23-000171:8k_2_02:49]
•Second-quarter revenue was $379 million, up 28% from the previous quarter and down 24% from a year ago.

[0001045810-23-000171:8k_2_02:50]
•Announced three new desktop workstation RTX GPUs based on the Ada Lovelace architecture — NVIDIA RTX 5000, RTX 4500 and RTX 4000 — to deliver the latest AI, graphics and real-time rendering, which are shipping this quarter.

[0001045810-23-000171:8k_2_02:51]
•Announced a major release of the NVIDIA Omniverse platform, with new foundation applications and services for developers and industrial enterprises to optimize and enhance their 3D pipelines with OpenUSD and generative AI.

[0001045810-23-000171:8k_2_02:52]
•Joined with Pixar, Adobe, Apple and Autodesk to form the Alliance for OpenUSD to promote the standardization, development, evolution and growth of Universal Scene Description technology.

[0001045810-23-000171:8k_2_02:53]
Automotive

[0001045810-23-000171:8k_2_02:54]
•Second-quarter revenue was $253 million, down 15% from the previous quarter and up 15% from a year ago.

[0001045810-23-000171:8k_2_02:55]
•Announced that NVIDIA DRIVE Orin™ is powering the new XPENG G6 Coupe SUV’s intelligent advanced driver assistance system.

[0001045810-23-000171:8k_2_02:56]
•Partnered with MediaTek, which will develop mainstream automotive systems on chips for global OEMs, which integrate new NVIDIA GPU chiplet IP for AI and graphics.

[0001045810-23-000171:8k_2_02:57]
CFO Commentary

[0001045810-23-000171:8k_2_02:58]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-23-000171:8k_2_02:59]
Conference Call and Webcast Information

[0001045810-23-000171:8k_2_02:60]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2024 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2024.

[0001045810-23-000171:8k_2_02:61]
Non-GAAP Measures

[0001045810-23-000171:8k_2_02:62]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, IP-related costs, legal settlement costs, contributions, other, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-23-000171:8k_2_02:63]
About NVIDIA

[0001045810-23-000171:8k_2_02:64]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and is fueling industrial digitalization across markets. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-23-000171:8k_2_02:65]
###

[0001045810-23-000171:8k_2_02:66]
For further information, contact:

[0001045810-23-000171:8k_2_02:67]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-23-000171:8k_2_02:68]
Certain statements in this press release including, but not limited to, statements as to: companies worldwide transitioning from general-purpose to accelerated computing and generative AI; NVIDIA GPUs running CUDA AI software stack making up the computing infrastructure of generative AI; the race to adopt generative AI; NVIDIA’s plans to continue share repurchases; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook and expected tax rates for the third quarter of fiscal 2024; the benefits, impact, performance, features and availability of our products and technologies, including the NVIDIA GH200 Grace Hopper Superchip, NVIDIA L40S GPU, NVIDIA OVX, NVIDIA AI Enterprise, BlueField DPUs, NVIDIA MGX, NVIDIA Omniverse, NVIDIA Spectrum-X, NVIDIA RTX workstations, NVIDIA RTX 6000 Ada GPU, NVIDIA Omniverse Enterprise software, NVIDIA H100 Tensor Core GPU, NVIDIA DGX Cloud AI, NVIDIA AI Workbench, NVIDIA AI Enterprise 4.0, the GeForce RTX 4060 family, NVIDIA Ada Lovelace, DLSS, NVIDIA Avatar Cloud Engine, NVIDIA’s RTX Remix, NVIDIA RTX 5000, RTX 4500 and RTX 4000, and NVIDIA DRIVE Orin; and the benefits and impact of NVIDIA’s partnerships with ServiceNow, Accenture, VMware, Snowflake, WPP, SoftBank, Hugging Face, and MediaTek, and NVIDIA’s Alliance for OpenUSD with Pixar, Adobe, Apple and Autodesk are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-23-000171:8k_2_02:69]
© 2023 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, BlueField, GeForce, GeForce RTX, NVIDIA DGX, NVIDIA DRIVE Orin, NVIDIA Grace Hopper, NVIDIA Hopper, NVIDIA MGX, NVIDIA Omniverse, NVIDIA OVX, NVIDIA RTX, and NVIDIA Spectrum-X are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-23-000171:8k_2_02:70]
NVIDIA CORPORATION

[0001045810-23-000171:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-23-000171:8k_2_02:72]
(In millions, except per share data)

[0001045810-23-000171:8k_2_02:73]
(Unaudited)

[0001045810-23-000171:8k_2_02:74]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 30, 2023 |  | July 31, 2022 |  | July 30, 2023 |  | July 31, 2022 |
| Revenue | $ | 13,507 |  |  | $ | 6,704 |  |  | $ | 20,699 |  |  | $ | 14,992 |  |
| Cost of revenue | 4,045 |  |  | 3,789 |  |  | 6,589 |  |  | 6,646 |  |
| Gross profit | 9,462 |  |  | 2,915 |  |  | 14,110 |  |  | 8,346 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 2,040 |  |  | 1,824 |  |  | 3,916 |  |  | 3,443 |  |
|  | Sales, general and administrative | 622 |  |  | 592 |  |  | 1,253 |  |  | 1,183 |  |
|  | Acquisition termination cost | — |  |  | — |  |  | — |  |  | 1,353 |  |
|  |  | Total operating expenses | 2,662 |  |  | 2,416 |  |  | 5,169 |  |  | 5,979 |  |
| Operating income | 6,800 |  |  | 499 |  |  | 8,941 |  |  | 2,367 |  |
|  | Interest income | 187 |  |  | 46 |  |  | 338 |  |  | 64 |  |
|  | Interest expense | (65) |  |  | (65) |  |  | (131) |  |  | (132) |  |
|  | Other, net | 59 |  |  | (5) |  |  | 42 |  |  | (19) |  |
|  |  | Other income (expense), net | 181 |  |  | (24) |  |  | 249 |  |  | (87) |  |
| Income before income tax | 6,981 |  |  | 475 |  |  | 9,190 |  |  | 2,280 |  |
| Income tax expense (benefit) | 793 |  |  | (181) |  |  | 958 |  |  | 6 |  |
| Net income | $ | 6,188 |  |  | $ | 656 |  |  | $ | 8,232 |  |  | $ | 2,274 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 2.50 |  |  | $ | 0.26 |  |  | $ | 3.33 |  |  | $ | 0.91 |  |
|  | Diluted | $ | 2.48 |  |  | $ | 0.26 |  |  | $ | 3.30 |  |  | $ | 0.90 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,473 |  |  | 2,495 |  |  | 2,472 |  |  | 2,500 |  |
|  | Diluted | 2,499 |  |  | 2,516 |  |  | 2,495 |  |  | 2,526 |  |

[0001045810-23-000171:8k_2_02:75]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | July 30, 2023 |  | January 29, 2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 16,023 |  |  | $ | 13,296 |  |
|  | Accounts receivable, net |  | 7,066 |  |  | 3,827 |  |
|  | Inventories |  | 4,319 |  |  | 5,159 |  |
|  | Prepaid expenses and other current assets |  | 1,389 |  |  | 791 |  |
|  |  | Total current assets |  | 28,797 |  |  | 23,073 |  |
| Property and equipment, net |  | 3,799 |  |  | 3,807 |  |
| Operating lease assets |  | 1,235 |  |  | 1,038 |  |
| Goodwill |  | 4,430 |  |  | 4,372 |  |
| Intangible assets, net |  | 1,395 |  |  | 1,676 |  |
| Deferred income tax assets |  | 5,398 |  |  | 3,396 |  |
| Other assets |  | 4,501 |  |  | 3,820 |  |
|  |  | Total assets |  | $ | 49,555 |  |  | $ | 41,182 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,929 |  |  | $ | 1,193 |  |
|  | Accrued and other current liabilities |  | 7,156 |  |  | 4,120 |  |
|  | Short-term debt |  | 1,249 |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 10,334 |  |  | 6,563 |  |
| Long-term debt |  | 8,456 |  |  | 9,703 |  |
| Long-term operating lease liabilities |  | 1,041 |  |  | 902 |  |
| Other long-term liabilities |  | 2,223 |  |  | 1,913 |  |
|  |  | Total liabilities |  | 22,054 |  |  | 19,081 |  |
| Shareholders' equity |  | 27,501 |  |  | 22,101 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 49,555 |  |  | $ | 41,182 |  |

[0001045810-23-000171:8k_2_02:76]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 6,188 |  |  | $ | 656 |  |  | $ | 8,232 |  |  | $ | 2,274 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock based compensation expense | 842 |  |  | 648 |  |  | 1,576 |  |  | 1,226 |  |
| Depreciation and amortization | 365 |  |  | 378 |  |  | 749 |  |  | 712 |  |
| (Gains) losses on investments in non affiliates, net | (60) |  |  | 7 |  |  | (45) |  |  | 24 |  |
| Deferred income taxes | (746) |  |  | (443) |  |  | (1,881) |  |  | (985) |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | 1,353 |  |
| Other | (69) |  |  | (5) |  |  | (102) |  |  | 18 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (2,986) |  |  | 120 |  |  | (3,239) |  |  | (668) |  |
| Inventories | 296 |  |  | (725) |  |  | 861 |  |  | (1,285) |  |
| Prepaid expenses and other assets | (376) |  |  | (293) |  |  | (592) |  |  | (1,554) |  |
| Accounts payable | 777 |  |  | 304 |  |  | 789 |  |  | 559 |  |
| Accrued liabilities and other current liabilities | 1,986 |  |  | 633 |  |  | 2,675 |  |  | 1,267 |  |
| Other long-term liabilities | 131 |  |  | (10) |  |  | 236 |  |  | 60 |  |
| Net cash provided by operating activities | 6,348 |  |  | 1,270 |  |  | 9,259 |  |  | 3,001 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,598 |  |  | 5,036 |  |  | 5,111 |  |  | 10,983 |  |
| Proceeds from sales of marketable securities | — |  |  | 702 |  |  | — |  |  | 1,731 |  |
| Purchases of marketable securities | (2,542) |  |  | (3,644) |  |  | (5,343) |  |  | (7,576) |  |
| Purchase related to property and equipment and intangible assets | (289) |  |  | (433) |  |  | (537) |  |  | (794) |  |
| Acquisitions, net of cash acquired | — |  |  | (13) |  |  | (83) |  |  | (49) |  |
| Investments and other, net | (214) |  |  | (30) |  |  | (435) |  |  | (65) |  |
| Net cash provided by (used in) investing activities | (447) |  |  | 1,618 |  |  | (1,287) |  |  | 4,230 |  |

[0001045810-23-000171:8k_2_02:77]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 1 |  |  | 1 |  |  | 247 |  |  | 205 |  |
| Payments related to repurchases of common stock | (3,067) |  |  | (3,345) |  |  | (3,067) |  |  | (5,341) |  |
| Repayment of debt | (1,250) |  |  | — |  |  | (1,250) |  |  | — |  |
| Payments related to tax on restricted stock units | (672) |  |  | (305) |  |  | (1,179) |  |  | (837) |  |
| Dividends paid | (99) |  |  | (100) |  |  | (199) |  |  | (200) |  |
| Principal payments on property and equipment and intangible assets | (11) |  |  | (14) |  |  | (31) |  |  | (36) |  |
| Other | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net cash used in financing activities | (5,098) |  |  | (3,762) |  |  | (5,479) |  |  | (6,208) |  |
| Change in cash, cash equivalents, and restricted cash | 803 |  |  | (874) |  |  | 2,493 |  |  | 1,023 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 5,079 |  |  | 3,887 |  |  | 3,389 |  |  | 1,990 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 5,882 |  |  | $ | 3,013 |  |  | $ | 5,882 |  |  | $ | 3,013 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheet: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 5,783 |  |  | $ | 3,013 |  |  | $ | 5,783 |  |  | $ | 3,013 |  |
| Restricted cash, included in prepaid expenses and other current assets | 99 |  |  | — |  |  | 99 |  |  | — |  |
| Total cash, cash equivalents, and restricted cash | $ | 5,882 |  |  | $ | 3,013 |  |  | $ | 5,882 |  |  | $ | 3,013 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 227 |  |  | $ | 1,081 |  |  | $ | 328 |  |  | $ | 1,108 |  |

[0001045810-23-000171:8k_2_02:78]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP gross profit |  | $ | 9,462 |  |  | $ | 4,648 |  |  | $ | 2,915 |  |  | $ | 14,110 |  |  | $ | 8,346 |  |
| GAAP gross margin |  | 70.1 | % |  | 64.6 | % |  | 43.5 | % |  | 68.2 | % |  | 55.7 | % |
|  | Acquisition-related and other costs (A) |  | 119 |  |  | 119 |  |  | 121 |  |  | 239 |  |  | 214 |  |
|  | Stock-based compensation expense (B) |  | 31 |  |  | 27 |  |  | 38 |  |  | 58 |  |  | 76 |  |
|  | IP-related costs |  | 2 |  |  | 8 |  |  | — |  |  | 10 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 9,614 |  |  | $ | 4,802 |  |  | $ | 3,074 |  |  | $ | 14,417 |  |  | $ | 8,636 |  |
| Non-GAAP gross margin |  | 71.2 | % |  | 66.8 | % |  | 45.9 | % |  | 69.7 | % |  | 57.6 | % |
| GAAP operating expenses |  | $ | 2,662 |  |  | $ | 2,508 |  |  | $ | 2,416 |  |  | $ | 5,169 |  |  | $ | 5,979 |  |
|  | Stock-based compensation expense (B) |  | (811) |  |  | (708) |  |  | (611) |  |  | (1,518) |  |  | (1,151) |  |
|  | Acquisition-related and other costs (A) |  | (18) |  |  | (54) |  |  | (54) |  |  | (72) |  |  | (110) |  |
|  | Acquisition termination cost |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,353) |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |
|  | Contributions |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (2) |  |
|  | Other (C) |  | 5 |  |  | 4 |  |  | — |  |  | 10 |  |  | — |  |
| Non-GAAP operating expenses |  | $ | 1,838 |  |  | $ | 1,750 |  |  | $ | 1,749 |  |  | $ | 3,589 |  |  | $ | 3,356 |  |
| GAAP operating income |  | $ | 6,800 |  |  | $ | 2,140 |  |  | $ | 499 |  |  | $ | 8,941 |  |  | $ | 2,367 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 976 |  |  | 912 |  |  | 826 |  |  | 1,887 |  |  | 2,913 |  |
| Non-GAAP operating income |  | $ | 7,776 |  |  | $ | 3,052 |  |  | $ | 1,325 |  |  | $ | 10,828 |  |  | $ | 5,280 |  |
| GAAP other income (expense), net |  | $ | 181 |  |  | $ | 69 |  |  | $ | (24) |  |  | $ | 249 |  |  | $ | (87) |  |
|  | (Gains) losses from non-affiliated investments |  | (62) |  |  | 14 |  |  | 7 |  |  | (46) |  |  | 24 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Non-GAAP other income (expense), net |  | $ | 120 |  |  | $ | 84 |  |  | $ | (16) |  |  | $ | 205 |  |  | $ | (61) |  |
| GAAP net income |  | $ | 6,188 |  |  | $ | 2,043 |  |  | $ | 656 |  |  | $ | 8,232 |  |  | $ | 2,274 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 915 |  |  | 927 |  |  | 833 |  |  | 1,843 |  |  | 2,940 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (363) |  |  | (257) |  |  | (197) |  |  | (622) |  |  | (478) |  |
| Non-GAAP net income |  | $ | 6,740 |  |  | $ | 2,713 |  |  | $ | 1,292 |  |  | $ | 9,453 |  |  | $ | 4,736 |  |

[0001045810-23-000171:8k_2_02:79]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 2.48 |  |  | $ | 0.82 |  |  | $ | 0.26 |  |  | $ | 3.30 |  |  | $ | 0.90 |  |
|  | Non-GAAP |  | $ | 2.70 |  |  | $ | 1.09 |  |  | $ | 0.51 |  |  | $ | 3.79 |  |  | $ | 1.87 |  |
| Weighted average shares used in diluted net income per share computation |  | 2,499 |  |  | 2,490 |  |  | 2,516 |  |  | 2,495 |  |  | 2,527 |  |
| GAAP net cash provided by operating activities |  | $ | 6,348 |  |  | $ | 2,911 |  |  | $ | 1,271 |  |  | $ | 9,259 |  |  | $ | 3,001 |  |
|  | Purchases related to property and equipment and intangible assets |  | (289) |  |  | (248) |  |  | (432) |  |  | (537) |  |  | (794) |  |
|  | Principal payments on property and equipment and intangible assets |  | (11) |  |  | (20) |  |  | (15) |  |  | (31) |  |  | (36) |  |
| Free cash flow |  | $ | 6,048 |  |  | $ | 2,643 |  |  | $ | 824 |  |  | $ | 8,691 |  |  | $ | 2,171 |  |

[0001045810-23-000171:8k_2_02:80]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Cost of revenue |  | $ | 119 |  |  | $ | 119 |  |  | $ | 121 |  |  | $ | 239 |  |  | $ | 214 |  |
|  | Research and development |  | $ | 12 |  |  | $ | 12 |  |  | $ | 10 |  |  | $ | 24 |  |  | $ | 19 |  |
|  | Sales, general and administrative |  | $ | 6 |  |  | $ | 42 |  |  | $ | 44 |  |  | $ | 48 |  |  | $ | 91 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Cost of revenue |  | $ | 31 |  |  | $ | 27 |  |  | $ | 38 |  |  | $ | 58 |  |  | $ | 76 |  |
|  | Research and development |  | $ | 600 |  |  | $ | 524 |  |  | $ | 452 |  |  | $ | 1,124 |  |  | $ | 836 |  |
|  | Sales, general and administrative |  | $ | 211 |  |  | $ | 184 |  |  | $ | 159 |  |  | $ | 394 |  |  | $ | 315 |  |
| (C) Other consists of assets held for sale related adjustments. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-23-000171:8k_2_02:81]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2024 |
|  |  |  | Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 71.5 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 1.0 | % |
| Non-GAAP gross margin |  | 72.5 | % |
| GAAP operating expenses |  | $ | 2,950 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (950) |  |
| Non-GAAP operating expenses |  | $ | 2,000 |  |
