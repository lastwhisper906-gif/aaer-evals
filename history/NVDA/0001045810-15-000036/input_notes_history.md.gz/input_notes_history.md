# NVDA note change history — 0001045810-14-000158 → 0001045810-14-000188


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-19):
[0001045810-14-000188:note_history:1]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process, and because the Trustee's case remains pending on appeal, we have not reversed the $30.6 million accrual - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx - that we recorded during the three months ended October 30, 2005.
  (was, 2014-08-20, similarity 0.8873):
[0001045810-14-000158:note_history:1]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process.

- changed (2014-11-19):
[0001045810-14-000188:note_history:2]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. Oral argument on the appeal was held on October 8, 2014.  On November 6, 2014, the Ninth Circuit affirmed the District Court’s decision upholding the ruling of the Bankruptcy Court. The Trustee has until November 20, 2014 to seek a rehearing.
  (was, 2014-08-20, similarity 0.6624):
[0001045810-14-000158:note_history:2]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The hearing on the appeal is currently scheduled for October 8, 2014.

- changed (2014-11-19):
[0001045810-14-000188:note_history:3]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014.  On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal.  On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal.  Plaintiffs’ request was denied on November 10, 2014. Plaintiffs have until February 9, 2015 to file a petition for writ of certiorari to the United States Supreme Court.
  (was, 2014-08-20, similarity 0.7736):
[0001045810-14-000158:note_history:3]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014 and the appeal is currently under submission.

- added (2014-11-19):
[0001045810-14-000188:note_history:4]
Patent Infringement Cases

- added (2014-11-19):
[0001045810-14-000188:note_history:5]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing.  In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures.  On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway.

- added (2014-11-19):
[0001045810-14-000188:note_history:6]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement.  On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action. The court granted the motion to stay on October 23, 2014.

- added (2014-11-19):
[0001045810-14-000188:note_history:7]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. The complaint alleges that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA has not yet responded to the complaint.

- removed (2014-11-19):
[0001045810-14-000158:note_history:8]
While the conditional settlement reached in November 2005 never progressed through the confirmation process, the Trustee's case still remains pending on appeal. Accordingly, we have not reversed the accrual of $30.6 million - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx - that we recorded during the three months ended October 30, 2005, pending resolution of the appeal of the Trustee's case.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-11-19):
[0001045810-14-000188:note_history:9]
Significant Accounting Policies

- added (2014-11-19):
[0001045810-14-000188:note_history:10]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-11-19):
[0001045810-14-000188:note_history:11]
Significant Accounting Policies

- added (2014-11-19):
[0001045810-14-000188:note_history:12]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.

- changed (2014-11-19):
[0001045810-14-000188:note_history:13]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The third quarters of fiscal years 2015 and 2014 are both 13-week quarters.
  (was, 2014-08-20, similarity 0.9771):
[0001045810-14-000158:note_history:13]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The second quarters of fiscal years 2015 and 2014 are both 13-week quarters.

- added (2014-11-19):
[0001045810-14-000188:note_history:14]
In August 2014, the Financial Accounting Standards Board, or FASB, issued new guidance related to our responsibility to evaluate whether there is substantial doubt about our ability to continue ongoing business operations and to provide relevant footnote disclosures. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The adoption of this guidance is not expected to have a material impact on our financial statements.

- changed (2014-11-19):
[0001045810-14-000188:note_history:15]
In June 2014, the FASB issued new guidance related to stock-based compensation. The new guidance requires that a performance target that affects vesting, and that could be achieved after the requisite service period is rendered, be treated as a performance condition. The new guidance is effective for interim periods within and those fiscal years, beginning after December 15, 2015. We currently do not have awards with a performance target where the employee would be eligible to vest in the award regardless of whether the employee is rendering service on the date the performance target is achieved. Therefore, we believe, the adoption of this new accounting guidance will not have an impact on our consolidated financial statements.
  (was, 2014-08-20, similarity 0.9152):
[0001045810-14-000158:note_history:15]
In June 2014, the Financial Accounting Standards Board, or FASB, issued new guidance related to stock-based compensation. The new guidance requires that a performance target that affects vesting, and that could be achieved after the requisite service period is rendered, be treated as a performance condition. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. We currently do not have awards with a performance target where the employee would be eligible to vest in the award regardless of whether the employee is rendering service on the date the performance target is achieved. Therefore, we believe, the adoption of this new accounting guidance will not have an impact on our consolidated financial statements.

- changed (2014-11-19):
[0001045810-14-000188:note_history:16]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period.  Early adoption is not permitted.  We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.
  (was, 2014-08-20, similarity 0.997):
[0001045810-14-000158:note_history:16]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period.  Early adoption is not permitted.  We may adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.

- removed (2014-11-19):
[0001045810-14-000158:note_history:17]
In July 2013, the FASB issued updated guidance regarding the presentation of unrecognized tax benefits when a net operating loss carry forward, similar tax loss, or tax credit carry forward exists. The guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carry forward, a similar tax loss, or a tax credit carry forward when settlement in this manner is available under the tax law. We adopted this guidance in our interim period ended April 27, 2014. The adoption of this guidance did not impact our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-19):
[0001045810-14-000188:note_history:18]
As of October 26, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.
  (was, 2014-08-20, similarity 0.9876):
[0001045810-14-000158:note_history:18]
As of July 27, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

- changed (2014-11-19):
[0001045810-14-000188:note_history:19]
|  |  | October 26, |  | January 26, |
|  |  | 2014 |  | 2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (122,741 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,377,259 |  |  | $ | 1,356,375 |  |
  (was, 2014-08-20, similarity 0.9072):
[0001045810-14-000158:note_history:19]
|  |  | July 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (129,751 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,370,249 |  |  | $ | 1,356,375 |  |

- changed (2014-11-19):
[0001045810-14-000188:note_history:20]
(1)   As of October 26, 2014, the unamortized debt discount will be amortized over a remaining period of 4.1 years.
  (was, 2014-08-20, similarity 0.9469):
[0001045810-14-000158:note_history:20]
(1)   As of July 27, 2014, the unamortized debt discount will be amortized over a remaining period of 4.4 years.

- changed (2014-11-19):
[0001045810-14-000188:note_history:21]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:
  (was, 2014-08-20, similarity 0.9847):
[0001045810-14-000158:note_history:21]
The following table presents the interest expense for the contractual interest and the accretion of debt discount and issuance costs:

- changed (2014-11-19):
[0001045810-14-000188:note_history:22]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 11,250 |  |  | $ | — |  |
| Amortization of debt discount |  | 7,010 |  |  | — |  |  | 20,884 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 146 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,809 |  |  | $ | — |  |  | $ | 32,280 |  |  | $ | — |  |
  (was, 2014-08-20, similarity 0.9012):
[0001045810-14-000158:note_history:22]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 7,500 |  |  | $ | — |  |
| Amortization of debt discount |  | 6,973 |  |  | — |  |  | 13,874 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 97 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,772 |  |  | $ | — |  |  | $ | 21,471 |  |  | $ | — |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-19):
[0001045810-14-000188:note_history:23]
|  |  | October 26, |  | January 26, |
|  |  | 2014 |  | 2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (122,741 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,377,259 |  |  | $ | 1,356,375 |  |
  (was, 2014-08-20, similarity 0.9072):
[0001045810-14-000158:note_history:23]
|  |  | July 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (129,751 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,370,249 |  |  | $ | 1,356,375 |  |

- changed (2014-11-19):
[0001045810-14-000188:note_history:24]
(1)   As of October 26, 2014, the unamortized debt discount will be amortized over a remaining period of 4.1 years.
  (was, 2014-08-20, similarity 0.9469):
[0001045810-14-000158:note_history:24]
(1)   As of July 27, 2014, the unamortized debt discount will be amortized over a remaining period of 4.4 years.

- changed (2014-11-19):
[0001045810-14-000188:note_history:25]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:
  (was, 2014-08-20, similarity 0.9847):
[0001045810-14-000158:note_history:25]
The following table presents the interest expense for the contractual interest and the accretion of debt discount and issuance costs:

- changed (2014-11-19):
[0001045810-14-000188:note_history:26]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 11,250 |  |  | $ | — |  |
| Amortization of debt discount |  | 7,010 |  |  | — |  |  | 20,884 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 146 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,809 |  |  | $ | — |  |  | $ | 32,280 |  |  | $ | — |  |
  (was, 2014-08-20, similarity 0.9012):
[0001045810-14-000158:note_history:26]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 7,500 |  |  | $ | — |  |
| Amortization of debt discount |  | 6,973 |  |  | — |  |  | 13,874 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 97 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,772 |  |  | $ | — |  |  | $ | 21,471 |  |  | $ | — |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-11-19):
[0001045810-14-000158:note_history:27]
Subsequent Event

- removed (2014-11-19):
[0001045810-14-000158:note_history:28]
In August 2014, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we paid $310.0 million to purchase shares of our common stock and received 10.9 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
