# NVDA 8-K — 0001045810-15-000013 filed 2015-02-11

## item codes, every 8-K on or before 2015-03-12

- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2015-03-12

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-15-000013:8k_2_02:1]
EX-99.1
2
q415pr.htm
Q4'15 PRESS RELEASE

[0001045810-15-000013:8k_2_02:2]
Q4'15 PR

[0001045810-15-000013:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-15-000013:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2015

[0001045810-15-000013:8k_2_02:5]
| • | Record revenue in Q4 of $1.25 billion, up 9 percent from $1.14 billion a year earlier. |

[0001045810-15-000013:8k_2_02:6]
| • | GAAP diluted EPS in Q4 of $0.35, up 40 percent from $0.25 a year earlier. Non-GAAP diluted EPS in Q4 of $0.43, up 34 percent from $0.32 a year earlier. |

[0001045810-15-000013:8k_2_02:7]
| • | Record revenue in fiscal 2015 of $4.68 billion, up 13 percent from $4.13 billion a year earlier. |

[0001045810-15-000013:8k_2_02:8]
| • | GAAP diluted EPS in fiscal 2015 of $1.12, up 51 percent from $0.74 a year earlier. Non-GAAP diluted EPS in fiscal 2015 of $1.42, up 43 percent from $0.99 a year earlier. |

[0001045810-15-000013:8k_2_02:9]
SANTA CLARA, Calif.-Feb. 11, 2015-NVIDIA (NASDAQ: NVDA) today reported record revenue for the fourth quarter ended January 25, 2015, of $1.25 billion, up 9 percent from $1.14 billion a year earlier and up 2 percent from $1.23 billion the previous quarter.

[0001045810-15-000013:8k_2_02:10]
Revenue for fiscal 2015 was a record $4.68 billion, up 13 percent from $4.13 billion a year earlier.

[0001045810-15-000013:8k_2_02:11]
GAAP earnings per diluted share for the quarter were $0.35, up 40 percent from $0.25 a year earlier and up 13 percent from $0.31 in the previous quarter. Non-GAAP earnings per diluted share were $0.43, up 34 percent from $0.32 a year earlier and up 10 percent from $0.39 in the previous quarter.

[0001045810-15-000013:8k_2_02:12]
GAAP earnings per diluted share for fiscal 2015 were $1.12, up 51 percent from $0.74 a year earlier. Non-GAAP earnings per diluted share were $1.42, up 43 percent from $0.99 a year earlier.

[0001045810-15-000013:8k_2_02:13]
“Momentum is accelerating in each of our market-specialized platforms, driving record revenue in the quarter and full year,” said Jen-Hsun Huang, president and chief executive officer of NVIDIA.

[0001045810-15-000013:8k_2_02:14]
"GeForce and SHIELD are extending our reach in the rapidly growing global gaming market. Our DRIVE auto-computing platform is at the center of the advance toward self-driving cars. GRID is enabling enterprises to finally virtualize graphics-intensive applications. And our Tesla accelerated computing platform is helping to ignite the deep learning revolution.

[0001045810-15-000013:8k_2_02:15]
"The success of these platforms highlights the growing importance of visual computing and the opportunities ahead for NVIDIA," he said.

[0001045810-15-000013:8k_2_02:16]
During the fourth quarter, NVIDIA paid $46 million in cash dividends and repurchased 0.2 million shares.  During fiscal 2015, the company paid $186 million in cash dividends and repurchased 44.4 million shares for $814 million. As a result, the company returned to shareholders $1.0 billion in fiscal 2015.

[0001045810-15-000013:8k_2_02:17]
Since the restart of its capital return program in the fourth quarter of fiscal 2013, NVIDIA has returned approximately $2.22 billion to shareholders. This return represents 111 percent of the company’s cumulative free cash flow for fiscal years 2013 through 2015, reflecting the acceleration of the capital return program from cash generated in previous years.

[0001045810-15-000013:8k_2_02:18]
The company intends to return approximately $600 million to shareholders through ongoing quarterly cash dividends and share repurchases in fiscal 2016.

[0001045810-15-000013:8k_2_02:19]
NVIDIA will pay its next quarterly cash dividend of $0.085 per share on March 19, 2015, to all shareholders of record on February 26, 2015. NVIDIA expects that a portion of this dividend payment may be considered a return of capital for U.S. federal income tax purposes.

[0001045810-15-000013:8k_2_02:20]
| GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q4 FY15 | Q3 FY15 | Q4 FY14 | Q/Q | Y/Y |
| Revenue | $1,251 | $1,225 | $1,144 | up 2% | up 9% |
| Gross margin | 55.9% | 55.2% | 54.1% | up 70 bps | up 180 bps |
| Operating expenses | $468 | $463 | $452 | up 1% | up 4% |
| Net income | $193 | $173 | $147 | up 12% | up 31% |
| Diluted earnings per share | $0.35 | $0.31 | $0.25 | up 13% | up 40% |

[0001045810-15-000013:8k_2_02:21]
| Non-GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q4 FY15 | Q3 FY15 | Q4 FY14 | Q/Q | Y/Y |
| Revenue | $1,251 | $1,225 | $1,144 | up 2% | up 9% |
| Gross margin | 56.2% | 55.5% | 53.8% | up 70 bps | up 240 bps |
| Operating expenses | $420 | $415 | $408 | up 1% | up 3% |
| Net income | $241 | $220 | $187 | up 10% | up 29% |
| Diluted earnings per share | $0.43 | $0.39 | $0.32 | up 10% | up 34% |

[0001045810-15-000013:8k_2_02:22]
NVIDIA’s outlook for the first quarter of fiscal 2016 is as follows:

[0001045810-15-000013:8k_2_02:23]
| • | Revenue is expected to be $1.16 billion, plus or minus two percent. |

[0001045810-15-000013:8k_2_02:24]
| • | GAAP and non-GAAP gross margins are expected to be 56.2 percent and 56.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-15-000013:8k_2_02:25]
| • | GAAP operating expenses are expected to be approximately $478 million; non-GAAP operating expenses are expected to be approximately $425 million, inclusive of litigation costs. |

[0001045810-15-000013:8k_2_02:26]
| • | GAAP and non-GAAP tax rates for the first quarter of fiscal 2016 are expected to be 20 percent, plus or minus one percent - excluding the benefit of the U.S. Federal R&D tax credit which expired December 31, 2014. |

[0001045810-15-000013:8k_2_02:27]
| • | Capital expenditures are expected to be approximately $30 million to $40 million. |

[0001045810-15-000013:8k_2_02:28]
Fourth Quarter Fiscal 2015 Highlights

[0001045810-15-000013:8k_2_02:29]
During the fourth quarter, NVIDIA achieved progress in each of its market-specialized platforms:

[0001045810-15-000013:8k_2_02:30]
Gaming:

[0001045810-15-000013:8k_2_02:31]
| • | Introduced the GeForce® GTX™ 960 GPU, bringing the power and efficiency of the Maxwell architecture to the gaming market’s $199 sweet spot. |

[0001045810-15-000013:8k_2_02:32]
Enterprise Graphics:

[0001045810-15-000013:8k_2_02:33]
| • | Announced, shortly after the quarter, that the new version of VMware’s virtualization suite, VMware Horizon 6, includes the capability to deliver scalable, virtualized 3D graphics enabled by NVIDIA GRID vGPU™. |

[0001045810-15-000013:8k_2_02:34]
Accelerated Computing:

[0001045810-15-000013:8k_2_02:35]
| • | Announced that the NVIDIA Tesla® Accelerated Computing Platform will power the U.S. Department of Energy’s next-generation supercomputers, expected to deliver at least three-times greater performance than today's most powerful system. They will be based on IBM POWER servers equipped with Tesla GPUs and NVIDIA NVLink™ high-speed GPU interconnect technology. |

[0001045810-15-000013:8k_2_02:36]
| • | Launched the Tesla K80 dual-GPU accelerator, designed to power a wide range of machine learning, data-analytics and high performance computing applications. |

[0001045810-15-000013:8k_2_02:37]
Automotive:

[0001045810-15-000013:8k_2_02:38]
| • | Unveiled at the International Consumer Electronics Show the NVIDIA® Tegra® X1 mobile processor - a 256-core Maxwell™ architecture-based mobile super chip with over one teraflops of computing power. |

[0001045810-15-000013:8k_2_02:39]
| • | Launched NVIDIA DRIVE™ automotive computers, which move the industry closer to the era of auto-piloted cars and run next-generation infotainment systems. |

[0001045810-15-000013:8k_2_02:40]
CFO Commentary

[0001045810-15-000013:8k_2_02:41]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-15-000013:8k_2_02:42]
Conference Call and Webcast Information

[0001045810-15-000013:8k_2_02:43]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2015 financial results and current financial prospects today at 2 p.m. Pacific Time (5 p.m. Eastern Time). To listen to the conference call, dial (303) 223-4365; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its first quarter fiscal 2016.

[0001045810-15-000013:8k_2_02:44]
Non-GAAP Measures

[0001045810-15-000013:8k_2_02:45]
To supplement NVIDIA’s Condensed Consolidated Statements of Operations and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP other income and expense, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, legal settlements, a credit related to a weak die/packaging material set, acquisition-related costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, other expense and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user's overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and our non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-15-000013:8k_2_02:46]
To Keep Current on NVIDIA:

[0001045810-15-000013:8k_2_02:47]
| • | Keep up with the NVIDIA Blog, and follow us on Facebook, Google+, Twitter, LinkedIn and Instagram. |

[0001045810-15-000013:8k_2_02:48]
| • | View NVIDIA videos on YouTube and images on Flickr. |

[0001045810-15-000013:8k_2_02:49]
| • | Use the Pulse news reader to subscribe to the NVIDIA Daily News feed. |

[0001045810-15-000013:8k_2_02:50]
About NVIDIA

[0001045810-15-000013:8k_2_02:51]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-15-000013:8k_2_02:52]
###

[0001045810-15-000013:8k_2_02:53]
For further information, contact:

[0001045810-15-000013:8k_2_02:54]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-15-000013:8k_2_02:55]
Certain statements in this press release including, but not limited to statements as to: momentum accelerating in each of the company’s market-specialized platforms; GeForce and SHIELD extending the company’s reach in the rapidly growing global gaming market; GRID enabling enterprises to virtualize graphics-intensive applications; the Tesla accelerated computing platform helping to ignite the deep learning revolution; the growing importance of visual computing; the company’s intent to return approximately $600 million to shareholders in fiscal 2016; a portion of the company’s dividend payment being considered a return of capital; the company’s financial outlook for the first quarter of fiscal 2016; the company’s tax rates for the first quarter of fiscal 2016; and the benefits and features of the GeForce GTX 960 GPU, NVIDIA GRID vGPU, the NVIDIA Tesla Accelerated Computing Platform, the Tesla K80 dual-GPU accelerator, the Tegra X1 mobile processor and NVIDIA DRIVE are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended October 26, 2014. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-15-000013:8k_2_02:56]
© 2015 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GTX, Tegra, Tesla, GRID vGPU, Maxwell, NVLink, NVIDIA GRID, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-15-000013:8k_2_02:57]
NVIDIA CORPORATION

[0001045810-15-000013:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-15-000013:8k_2_02:59]
(In thousands, except per share data)

[0001045810-15-000013:8k_2_02:60]
(Unaudited)

[0001045810-15-000013:8k_2_02:61]
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 25, |  | January 26, |  | January 25, |  | January 26, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue | $ | 1,250,514 |  |  | $ | 1,144,218 |  |  | $ | 4,681,507 |  |  | $ | 4,130,162 |  |
| Cost of revenue | 550,911 |  |  | 524,976 |  |  | 2,082,030 |  |  | 1,862,399 |  |
| Gross profit | 699,603 |  |  | 619,242 |  |  | 2,599,477 |  |  | 2,267,763 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 348,253 |  |  | 336,641 |  |  | 1,359,725 |  |  | 1,335,834 |  |
| Sales, general and administrative | 120,214 |  |  | 115,677 |  |  | 480,763 |  |  | 435,702 |  |
| Total operating expenses | 468,467 |  |  | 452,318 |  |  | 1,840,488 |  |  | 1,771,536 |  |
| Operating income | 231,136 |  |  | 166,924 |  |  | 758,989 |  |  | 496,227 |  |
| Interest income | 8,129 |  |  | 4,156 |  |  | 28,090 |  |  | 17,119 |  |
| Interest expense | 11,594 |  |  | 7,935 |  |  | 46,133 |  |  | 10,443 |  |
| Other income, net | 188 |  |  | 5,743 |  |  | 13,890 |  |  | 7,351 |  |
| Income before income tax expense | 227,859 |  |  | 168,888 |  |  | 754,836 |  |  | 510,254 |  |
| Income tax expense | 34,731 |  |  | 21,971 |  |  | 124,249 |  |  | 70,264 |  |
| Net income | $ | 193,128 |  |  | $ | 146,917 |  |  | $ | 630,587 |  |  | $ | 439,990 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.26 |  |  | $ | 1.14 |  |  | $ | 0.75 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.25 |  |  | $ | 1.12 |  |  | $ | 0.74 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 544,170 |  |  | 568,483 |  |  | 552,319 |  |  | 587,893 |  |
| Diluted | 556,573 |  |  | 577,356 |  |  | 563,068 |  |  | 594,517 |  |

[0001045810-15-000013:8k_2_02:62]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  | January 25, |  | January 26, |
|  |  |  | 2015 |  | 2014 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,623,339 |  |  | $ | 4,671,810 |  |
|  | Accounts receivable, net |  | 473,637 |  |  | 426,357 |  |
|  | Inventories |  | 482,893 |  |  | 387,765 |  |
|  | Prepaid expenses and other current assets |  | 133,428 |  |  | 138,779 |  |
|  | Total current assets |  | 5,713,297 |  |  | 5,624,711 |  |
| Property and equipment, net |  | 557,282 |  |  | 582,740 |  |
| Goodwill |  | 618,179 |  |  | 643,179 |  |
| Intangible assets, net |  | 221,714 |  |  | 296,012 |  |
| Other assets |  | 90,896 |  |  | 104,252 |  |
|  | Total assets |  | $ | 7,201,368 |  |  | $ | 7,250,894 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 293,223 |  |  | $ | 324,391 |  |
|  | Accrued liabilities and other current liabilities |  | 602,807 |  |  | 621,105 |  |
|  | Total current liabilities |  | 896,030 |  |  | 945,496 |  |
| Long-term debt |  | 1,384,342 |  |  | 1,356,375 |  |
| Other long-term liabilities |  | 488,928 |  |  | 475,125 |  |
| Capital lease obligations, long-term |  | 14,086 |  |  | 17,500 |  |
| Stockholders' equity |  | 4,417,982 |  |  | 4,456,398 |  |
|  | Total liabilities and stockholders' equity |  | $ | 7,201,368 |  |  | $ | 7,250,894 |  |

[0001045810-15-000013:8k_2_02:63]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 25, |  | October 26, |  | January 26, |  | January 25, |  | January 26, |
|  |  | 2015 |  | 2014 |  | 2014 |  | 2015 |  | 2014 |
| GAAP gross profit |  | $ | 699,603 |  |  | $ | 676,698 |  |  | $ | 619,242 |  |  | $ | 2,599,477 |  |  | $ | 2,267,763 |  |
| GAAP gross margin |  | 55.9 | % |  | 55.2 | % |  | 54.1 | % |  | 55.5 | % |  | 54.9 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 3,426 |  |  | 3,021 |  |  | 2,777 |  |  | 12,022 |  |  | 10,688 |  |
| Legal settlement |  | — |  |  | — |  |  | 1,450 |  |  | — |  |  | 3,740 |  |
| Credit from a weak die/packaging material set (B) |  | — |  |  | — |  |  | (7,782 | ) |  | — |  |  | (7,782 | ) |
| Non-GAAP gross profit |  | $ | 703,029 |  |  | $ | 679,719 |  |  | $ | 615,687 |  |  | $ | 2,611,499 |  |  | $ | 2,274,409 |  |
| Non-GAAP gross margin |  | 56.2 | % |  | 55.5 | % |  | 53.8 | % |  | 55.8 | % |  | 55.1 | % |
| GAAP operating expenses |  | $ | 468,467 |  |  | $ | 463,383 |  |  | $ | 452,318 |  |  | $ | 1,840,488 |  |  | $ | 1,771,536 |  |
| Stock-based compensation expense included in operating expense (A) |  | (39,044 | ) |  | (38,414 | ) |  | (33,427 | ) |  | (145,819 | ) |  | (125,607 | ) |
| Acquisition-related costs (B) |  | (9,169 | ) |  | (9,572 | ) |  | (9,250 | ) |  | (37,355 | ) |  | (31,652 | ) |
| Other expense (C) |  | — |  |  | — |  |  | (1,845 | ) |  | — |  |  | (4,080 | ) |
| Non-GAAP operating expenses |  | $ | 420,254 |  |  | $ | 415,397 |  |  | $ | 407,796 |  |  | $ | 1,657,314 |  |  | $ | 1,610,197 |  |
| GAAP other income (expense), net | $ | (3,277 | ) |  | $ | (4,245 | ) |  | $ | 1,964 |  |  | $ | (4,153 | ) |  | $ | 14,027 |  |
| Gains and losses from non-affiliated investments |  | — |  |  | — |  |  | (3,074 | ) |  | (14,482 | ) |  | (3,074 | ) |
| Interest expense related to amortization of debt discount |  | 7,083 |  |  | 7,010 |  |  | 4,600 |  |  | 27,967 |  |  | 4,600 |  |
| Non-GAAP other income (expense), net | $ | 3,806 |  |  | $ | 2,765 |  |  | $ | 3,490 |  |  | $ | 9,332 |  |  | $ | 15,553 |  |
| GAAP net income |  | $ | 193,128 |  |  | $ | 172,967 |  |  | $ | 146,917 |  |  | $ | 630,587 |  |  | $ | 439,990 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 58,722 |  |  | 58,017 |  |  | 42,493 |  |  | 208,681 |  |  | 169,511 |  |
| Income tax impact of non-GAAP adjustments |  | (10,783 | ) |  | (10,549 | ) |  | (1,924 | ) |  | (38,280 | ) |  | (21,094 | ) |
| Non-GAAP net income |  | $ | 241,067 |  |  | $ | 220,435 |  |  | $ | 187,486 |  |  | $ | 800,988 |  |  | $ | 588,407 |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.35 |  |  | $ | 0.31 |  |  | $ | 0.25 |  |  | $ | 1.12 |  |  | $ | 0.74 |  |
| Non-GAAP |  | $ | 0.43 |  |  | $ | 0.39 |  |  | $ | 0.32 |  |  | $ | 1.42 |  |  | $ | 0.99 |  |
| Shares used in diluted net income per share computation |  | 556,573 |  |  | 558,201 |  |  | 577,356 |  |  | 563,068 |  |  | 594,517 |  |
| Metrics: |  |  |  |  |  |  |  |  |  |  |
| GAAP net cash flow provided by operating activities |  | $ | 442,729 |  |  | $ | 215,623 |  |  | $ | 400,712 |  |  | $ | 905,656 |  |  | $ | 835,146 |  |
| Purchase of property and equipment and intangible assets |  | (31,045 | ) |  | (39,741 | ) |  | (66,374 | ) |  | (122,381 | ) |  | (255,186 | ) |
| Free cash flow |  | $ | 411,684 |  |  | $ | 175,882 |  |  | $ | 334,338 |  |  | $ | 783,275 |  |  | $ | 579,960 |  |

[0001045810-15-000013:8k_2_02:64]
| (A) Excludes stock-based compensation as follows: |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 25, |  | October 26, |  | January 26, |  | January 25, |  | January 26, |
|  |  | 2015 |  | 2014 |  | 2014 |  | 2015 |  | 2014 |
| Cost of revenue |  | $ | 3,426 |  |  | $ | 3,021 |  |  | $ | 2,777 |  |  | $ | 12,022 |  |  | $ | 10,688 |  |
| Research and development |  | $ | 23,719 |  |  | $ | 22,680 |  |  | $ | 21,548 |  |  | $ | 88,355 |  |  | $ | 82,940 |  |
| Sales, general and administrative |  | $ | 15,325 |  |  | $ | 15,734 |  |  | $ | 11,879 |  |  | $ | 57,464 |  |  | $ | 42,667 |  |
| (B) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (C) Includes intangible asset write-off, restructuring charge, and legal settlement cost, net of credits. |

[0001045810-15-000013:8k_2_02:65]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2016 Outlook |
| GAAP gross margin |  | 56.2 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 56.5 | % |
|  |  |  | Q1 FY2016 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 478 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (53 | ) |
| Non-GAAP operating expenses |  | $ | 425 |  |
