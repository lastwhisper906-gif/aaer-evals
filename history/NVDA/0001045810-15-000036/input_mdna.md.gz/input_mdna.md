# NVDA MD&A — 0001045810-15-000036


## mdna

[0001045810-15-000036:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001045810-15-000036:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 1A. Risk Factors”, “Item 6. Selected Financial Data”, our Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Annual Report on Form 10-K, before deciding to purchase, hold or sell shares of our common stock.

[0001045810-15-000036:mdna:3]
Overview

[0001045810-15-000036:mdna:4]
Our Company and Our Businesses

[0001045810-15-000036:mdna:5]
NVIDIA is dedicated to advancing visual computing, enabling individuals to interact with digital ideas, data and entertainment with an ease and efficiency unmatched by any other communication medium.

[0001045810-15-000036:mdna:6]
Our business model has three elements: creating NVIDIA-branded products and services, offering our processors to original equipment manufacturers, or OEMs, and licensing our intellectual property. NVIDIA-branded products and services are visual computing platforms that address four large markets: Gaming, Enterprise, High Performance Computing & Cloud, and Automotive.

[0001045810-15-000036:mdna:7]
Our two business segments - GPU and Tegra Processor - are based on a single underlying graphics architecture. In addition to the two reporting segments, the “All Other” category primarily includes licensing revenue from our patent cross licensing agreement with Intel, which we expect to recognize through March 2017.

[0001045810-15-000036:mdna:8]
GPUs, the engines of visual computing, are among the world's most complex processors. Our GPU product brands aimed at specialized markets include GeForce for gamers; Quadro for designers; Tesla for researchers, deep learning and big-data analysts; and GRID for cloud-based visual computing users.

[0001045810-15-000036:mdna:9]
We also integrate our GPUs into tiny mobile chips called system-on-a-chip (SOC) processors, which power tablets, and automotive infotainment and safety systems. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs with audio, video and input/output capabilities. They can also be integrated with baseband processors to add voice and data communication. Tegra conserves power while delivering state-of-the-art graphics and multimedia processing.

[0001045810-15-000036:mdna:10]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-15-000036:mdna:11]
Recent Developments, Future Objectives and Challenges

[0001045810-15-000036:mdna:12]
GPU Business

[0001045810-15-000036:mdna:13]
During fiscal year 2015, we announced and shipped GeForce GPUs based on our new Maxwell architecture and we surpassed fifty million installations of our GeForce Experience client, which provides game-ready drivers, optimized play settings, and streaming and sharing of gameplay. We also disclosed the first details of our Pascal GPU architecture, which will succeed Maxwell. Pascal is expected to feature 3D memory and NVLink interconnect technology.

[0001045810-15-000036:mdna:14]
Quadro professional graphics continue to maintain market leadership. We refreshed our Quadro product lineup during fiscal year 2015 and also extended our product lineup to include Maxwell-based GPUs.

[0001045810-15-000036:mdna:15]
We extended our reach in accelerated datacenter computing, with the world’s fifteen most highly-efficient supercomputers all utilizing our Tesla GPUs. We continued to expand our reach in the big data analytics market, with IBM announcing future support for GPU acceleration in its IBM DB2 with BLU acceleration. We launched our Tesla K80 dual-GPU accelerator, which is designed to power a wide range of machine learning, data-analytics and high performance computing applications. In addition, we announced that our Tesla GPUs will power the U.S. Department of Energy’s next-generation supercomputers in conjunction with our NVIDIA NVLink high-speed interconnect technology. These systems are to be deployed at Oak Ridge and Lawrence Livermore National Laboratories and will serve scientists to accelerate their research.

[0001045810-15-000036:mdna:16]
We announced that NVIDIA GRID technology will be available on the VMware Horizon DaaS Platform to deliver 3D graphics on virtualized desktops and applications delivered through the cloud, partnered with VMware on a customer access program for NVIDIA GRID with companies like Airbus, CH2M Hill, MetroHealth and Halliburton, and announced that the new version of VMware’s virtualization suite, VMware Horizon 6, includes the capability to deliver scalable, virtualized 3D graphics enabled by NVIDIA GRID vGPU. NVIDIA GRID graphics virtualization continued to gain momentum as more companies come forward to experience cloud-based GPU-accelerated virtual desktops through our “Try GRID” online demonstration.

[0001045810-15-000036:mdna:17]
Tegra Processor Business

[0001045810-15-000036:mdna:18]
During fiscal year 2015, we expanded our SHIELD family of gaming devices, adding the SHIELD tablet and SHIELD wireless controller to the product family that also includes the SHIELD portable. We also launched our GRID On-Demand Streaming Service, providing it free for SHIELD users through June 30, 2015.

[0001045810-15-000036:mdna:19]
We announced the NVIDIA Tegra X1 mobile processor, a 256-core Maxwell architecture-based mobile super chip with over one teraflops of computing power. Our Tegra K1 processor was featured in Google’s Nexus 9 and Project Tango tablets, in NVIDIA's SHIELD tablet and in Chromebooks made by Acer and HP, and was one of the first processors to support Android TV. Tegra K1 was also included in our launch of Jetson TK1, a development platform aimed at automotive, robotics, defense and embedded applications.

[0001045810-15-000036:mdna:20]
In automotive, we launched NVIDIA DRIVE automotive computers - a computing platform for advanced driver assistance systems and digital cockpits that could enable auto-piloted cars and run state of the art infotainment systems.  NVIDIA DRIVE is powered by the Tegra X1. We also announced that many automobile manufacturers were shipping various new models with infotainment systems powered by NVIDIA, including the BMW i8 and i3, the Volkswagen Golf and Passat, and the Honda Civic, Civic Tourer and CR-V.

[0001045810-15-000036:mdna:21]
Capital Return to Shareholders

[0001045810-15-000036:mdna:22]
During fiscal year 2015, we repurchased 44.4 million shares of our common stock for $813.6 million and paid $186.5 million in cash dividends. As a result, we returned $1.00 billion to shareholders during fiscal year 2015 in the form of share repurchases and dividend payments.

[0001045810-15-000036:mdna:23]
On November 6, 2014 we announced our intention to return approximately $600.0 million to our shareholders in fiscal year 2016 through a combination of share repurchases and cash dividends. On February 11, 2015, we declared that we would pay our next quarterly cash dividend of $0.085 per share on March 19, 2015, to all shareholders of record on February 26, 2015.

[0001045810-15-000036:mdna:24]
Please refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-15-000036:mdna:25]
Litigation

[0001045810-15-000036:mdna:26]
In September 2014, we filed lawsuits against Qualcomm, Inc. and various Samsung entities in the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for using our GPU patents without a license. On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. The complaint alleges that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor.  On December 19, 2014, Samsung filed an amended, longer complaint but asserting the same claims against NVIDIA.

[0001045810-15-000036:mdna:27]
Please refer to Note 12 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-15-000036:mdna:28]
Critical Accounting Policies and Estimates

[0001045810-15-000036:mdna:29]
Management’s discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, inventories, income taxes, goodwill, cash equivalents and marketable securities, stock-based compensation, and litigation, investigation and settlement costs and other contingencies. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities.

[0001045810-15-000036:mdna:30]
We believe the following critical accounting policies affect our significant judgments and estimates used in the preparation of our consolidated financial statements. Our management has discussed the development and selection of these critical accounting policies and estimates with the Audit Committee of our Board of Directors. The Audit Committee has reviewed our disclosures relating to our critical accounting policies and estimates in this Annual Report on Form 10-K.

[0001045810-15-000036:mdna:31]
Revenue Recognition

[0001045810-15-000036:mdna:32]
Product Revenue

[0001045810-15-000036:mdna:33]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured.

[0001045810-15-000036:mdna:34]
For sales to certain distributors with rights of return for which the level of returns cannot be reasonably estimated, our policy is to defer recognition of revenue and related cost of revenue until the distributors resell the product and, in some cases, when customer return rights lapse.

[0001045810-15-000036:mdna:35]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. In such cases, the OEMs may not be our direct customers and therefore the quantity and mix of demand they place on their CEMs/ODMs may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents approximately 0.5% of total revenue.

[0001045810-15-000036:mdna:36]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors, add-in card partners and other channel partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed.

[0001045810-15-000036:mdna:37]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-15-000036:mdna:38]
License and Development Revenue

[0001045810-15-000036:mdna:39]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual direct labor hours incurred to date as a percentage of the estimated total direct labor hours required to complete the project. We periodically evaluate the actual status of each project to ensure that the estimates to complete each contract remain accurate. Revenue recognized in any period is dependent on our progress toward completion of projects in progress. Significant management judgment and discretion are used to estimate total direct labor hours. Any changes in or deviations from these estimates could have a material effect on the amount of revenue we recognize in any period.

[0001045810-15-000036:mdna:40]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-15-000036:mdna:41]
Please refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-15-000036:mdna:42]
Inventories

[0001045810-15-000036:mdna:43]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions.

[0001045810-15-000036:mdna:44]
Situations that may result in excess or obsolete inventory include changes in business and economic conditions, changes in consumer confidence caused by changes in market conditions, sudden and significant decreases in demand for our products, inventory obsolescence because of rapidly changing technology and customer requirements, failure to estimate customer demand properly for older products as newer products are introduced, or unexpected competitive pricing actions by our competition. In addition, cancellation or deferral of customer purchase orders could result in our holding excess inventory. Also, because we often sell a substantial portion of our products in the last month of each quarter, we may not be able to reduce our inventory purchase commitments in a timely manner in response to customer cancellations or deferrals.

[0001045810-15-000036:mdna:45]
Charges to cost of sales for inventory provisions totaled $59.4 million, $50.1 million and $89.9 million for fiscal years 2015, 2014 and 2013, unfavorably impacting our gross margin by 1.3%, 1.2% and 2.1%, respectively. Sales of inventory that was previously written-off or written-down totaled $32.4 million, $43.4 million and $53.7 million for fiscal years 2015, 2014 and 2013, favorably impacting our gross margin by 0.7%, 1.1% and 1.3%, respectively. As a result, the overall net effect on our gross margin from inventory provisions and sales of items previously written down was an unfavorable impact of 0.6%, 0.1% and 0.8% in fiscal years 2015, 2014 and 2013, respectively.

[0001045810-15-000036:mdna:46]
During fiscal years 2015, 2014 and 2013, the charges we took to cost of sales for inventory provisions were primarily related to the write-off of excess quantities of GPU and Tegra Processor products whose inventory levels were higher than our updated forecasts of future demand for those products. As a fabless semiconductor company, we must make commitments to purchase inventory based on forecasts of future customer demand. In doing so, we must account for our third-party manufacturers' lead times and constraints. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001045810-15-000036:mdna:47]
Please refer to the Gross Profit and Gross Margin discussion below in this Management's Discussion and Analysis for further discussion.

[0001045810-15-000036:mdna:48]
Income Taxes

[0001045810-15-000036:mdna:49]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-15-000036:mdna:50]
United States income tax has not been provided on a portion of earnings of our non-U.S. subsidiaries to the extent that such earnings are considered to be indefinitely reinvested.

[0001045810-15-000036:mdna:51]
Our calculation of current and deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of current and deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-15-000036:mdna:52]
As of January 25, 2015, we had a valuation allowance of $261.0 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due, in part, to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-15-000036:mdna:53]
Goodwill

[0001045810-15-000036:mdna:54]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist, using either a qualitative or a quantitative assessment.  Our impairment review process compares the fair value of the reporting unit in which the goodwill resides to its carrying value.  We have identified two reporting units, GPU and Tegra Processor, for the purposes of completing our goodwill analysis.  Goodwill assigned to these reporting units as of January 25, 2015 was $209.7 million and $408.5 million, respectively.  Determining the number of reporting units and the fair value of a reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. We also make judgments and assumptions in allocating assets and liabilities to each of our reporting units. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain.

[0001045810-15-000036:mdna:55]
During the fourth quarter of fiscal year 2015, we elected to use the quantitative assessment to test goodwill for impairment for each reporting unit.  In applying the fair value based test of each reporting unit, the results from the income approach and the market approach were equally weighted. These valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, terminal or residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-15-000036:mdna:56]
When performing an income approach valuation, we incorporate the use of projected financial information and a discount rate that are developed using market participant based assumptions to our discounted cash flow model. Our estimates of discounted cash flow were based upon, among other things, certain assumptions about our expected future operating performance, such as revenue growth rates, operating margins, risk-adjusted discount rates, and future economic and market conditions. Our estimates may differ from actual cash flow due to, among other things, economic conditions, changes to our business model or changes in operating performance. Additionally, certain estimates of discounted cash flow involve businesses with limited financial history and developing revenue models, which increases the risk of differences between the projected and actual performance. The long-term financial forecasts that we utilize represent the best estimate that we have at this time and we believe that its underlying assumptions are reasonable. Significant differences between our estimates and actual cash flow could materially affect our future financial results, which could impact our future estimates of the fair value of our reporting units.

[0001045810-15-000036:mdna:57]
During the fourth quarter of fiscal year 2015, we concluded that there was no impairment of our goodwill. The fair value of our GPU reporting unit significantly exceeded its carrying value and the fair value of our Tegra Processor reporting unit exceeded its carrying value by 21%. As such, even if we applied a hypothetical 10% decrease to the fair value of each reporting unit, it still would not have resulted in the fair value of our reporting units being less than their carrying values. As an overall test of the reasonableness of estimated fair values of our reporting units, we reconciled the combined fair value estimates of our reporting units to our market capitalization as of the valuation date. The reconciliation confirmed that the fair values were relatively representative of the market views when applying a reasonable control premium to the market capitalization. However, any significant reductions in the actual amount of future cash flows realized by our reporting units, reductions in the value of market comparables, or reductions in our market capitalization could impact future estimates of the fair values of our reporting units. Such events could ultimately result in a charge to our earnings in future periods due to the potential for a write-down of the goodwill associated with our reporting units.

[0001045810-15-000036:mdna:58]
In particular, the fair value of our Tegra reporting unit exceeded its carrying value by approximately 21%.  The fair value of this reporting unit was assessed using a combination of income and market approaches. The underlying assumptions we used in assessing the fair value of the Tegra reporting unit include, but are not limited to, assumptions around future revenue growth rates, gross margins, operating expense investment levels, overall market growth rates, our market share of the overall market, and the appropriate discount rates to apply to future cash flows. If the actual future results of the Tegra reporting unit do not achieve the levels we estimated in assessing its fair value, the fair value of the Tegra reporting unit could decline. A future decline in the fair value of the Tegra reporting unit could result a charge to our earnings as a result of a write-down of the value of the goodwill associated with that reporting unit.

[0001045810-15-000036:mdna:59]
Our next annual evaluation of the goodwill by reporting unit will be performed during the fourth quarter of fiscal year 2016, or earlier if indicators of potential impairment exist. Such indicators include, but are not limited to, challenging economic conditions, such as a decline in our operating results, an unfavorable industry or macroeconomic environment, a substantial decline in our stock price, or any other adverse change in market conditions. Such conditions could have the effect of changing one of the critical assumptions or estimates we use to calculate the fair value of our reporting units, which could result in a decrease in fair value and require us to record goodwill impairment charges.

[0001045810-15-000036:mdna:60]
Cash Equivalents and Marketable Securities

[0001045810-15-000036:mdna:61]
Cash equivalents consist of financial instruments which are readily convertible into cash and have original maturities of three months or less at the time of acquisition.  Marketable securities consist primarily of highly liquid investments with maturities of greater than three months when purchased.

[0001045810-15-000036:mdna:62]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. Most of our cash equivalents and marketable securities are valued based on Level 2 inputs. We did not have any investments classified as Level 3 as of January 25, 2015.

[0001045810-15-000036:mdna:63]
All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments.

[0001045810-15-000036:mdna:64]
If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is more likely than not that we will not be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings.

[0001045810-15-000036:mdna:65]
We performed an impairment review of our investment portfolio as of January 25, 2015. We concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio of available-for-sale investments as of January 25, 2015.

[0001045810-15-000036:mdna:66]
Stock-based Compensation

[0001045810-15-000036:mdna:67]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units, or PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-15-000036:mdna:68]
During fiscal year 2015, we shifted away from granting stock options and toward granting RSUs and PSUs to reflect changing market trends for equity incentives at our peer companies. The number of PSUs that will ultimately vest is contingent on the Company’s level of achievement compared with the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year. The number of shares of our stock to be received at vesting ranges from 0% to 200% of the target amount.

[0001045810-15-000036:mdna:69]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of RSUs and PSUs. The compensation expense for RSUs is recognized using a straight-line attribution method over the requisite employee service period, while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our ESPP using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model.

[0001045810-15-000036:mdna:70]
Our RSU and PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair value of RSUs and PSUs is discounted by the dividend yield. Additionally, we estimate forfeitures annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. If factors change, the compensation expense that we record under these accounting standards may differ significantly from what we have recorded in the current period.

[0001045810-15-000036:mdna:71]
Litigation, Investigation and Settlement Costs

[0001045810-15-000036:mdna:72]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigations, and we cannot be certain that these actions or other third-party claims against us will be resolved without costly litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-15-000036:mdna:73]
Results of Operations

[0001045810-15-000036:mdna:74]
The following table sets forth, for the periods indicated, certain items in our consolidated statements of operations expressed as a percentage of revenue.

[0001045810-15-000036:mdna:75]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 44.5 |  |  | 45.1 |  |  | 48.0 |  |
| Gross profit | 55.5 |  |  | 54.9 |  |  | 52.0 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 29.0 |  |  | 32.3 |  |  | 26.8 |  |
| Sales, general and administrative | 10.3 |  |  | 10.5 |  |  | 10.1 |  |
| Total operating expenses | 39.3 |  |  | 42.8 |  |  | 36.9 |  |
| Income from operations | 16.2 |  |  | 12.1 |  |  | 15.1 |  |
| Interest income | 0.6 |  |  | 0.4 |  |  | 0.5 |  |
| Interest expense | (1.0 | ) |  | (0.3 | ) |  | (0.1 | ) |
| Other income (expense), net | 0.3 |  |  | 0.2 |  |  | (0.1 | ) |
| Income before income taxes | 16.1 |  |  | 12.4 |  |  | 15.4 |  |
| Income tax expense | 2.6 |  |  | 1.7 |  |  | 2.3 |  |
| Net income | 13.5 | % |  | 10.7 | % |  | 13.1 | % |

[0001045810-15-000036:mdna:76]
Revenue

[0001045810-15-000036:mdna:77]
|  | Year Ended |  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | $Change |  | %Change |  | January 26, 2014 |  | January 27, 2013 |  | $Change |  | %Change |
|  | (In millions) |  | (In millions) |
| GPU | $3,838.9 |  | $3,468.1 |  | $370.8 |  | 11 | % |  | $3,468.1 |  | $3,251.7 |  | $216.4 |  | 7 | % |
| Tegra Processor | 578.6 |  |  | 398.0 |  |  | 180.6 |  |  | 45 | % |  | 398.0 |  |  | 764.4 |  |  | (366.4 | ) |  | (48 | )% |
| All Other | 264.0 |  |  | 264.0 |  |  | — |  |  | — | % |  | 264.0 |  |  | 264.0 |  |  | — |  |  | — | % |
| Total | $4,681.5 |  | $4,130.1 |  | $551.4 |  | 13 | % |  | $4,130.1 |  | $4,280.1 |  | $(150.0) |  | (4 | )% |

[0001045810-15-000036:mdna:78]
Revenue was $4.68 billion, $4.13 billion and $4.28 billion for fiscal years 2015, 2014 and 2013, respectively. A discussion of our revenue results for each of our reporting segments and the All Other category is as follows:

[0001045810-15-000036:mdna:79]
GPU Business. GPU business revenue increased by 11% in fiscal year 2015 compared to fiscal year 2014. This increase was due primarily to higher revenue from GeForce GTX GPUs and associated memory for gaming, reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products. Revenue from Tesla for accelerated datacenter computing increased due to large project wins with cloud service providers and revenue from our NVIDIA GRID virtualization products also increased as this platform gained momentum. Revenue from GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-15-000036:mdna:80]
GPU business revenue increased by 7% in fiscal year 2014 compared to fiscal year 2013. This increase was largely attributable to strength in our high-end GeForce GTX GPUs driven by gaming market segment demand. The GPU business also benefited from higher sales of Tesla accelerated datacenter computing and Quadro enterprise products in fiscal year 2014. Offsetting these growth areas were declines in the overall market for mainstream desktop PCs and notebooks, which contributed to lower unit volumes of our mainstream GeForce GPUs.

[0001045810-15-000036:mdna:81]
Tegra Processor Business.  Tegra Processor business revenue increased by 45% in fiscal year 2015 compared to fiscal year 2014. This increase was driven by higher sales of Tegra products serving automotive infotainment systems, smartphones and tablet devices, and the onset of SHIELD tablet sales in fiscal year 2015.

[0001045810-15-000036:mdna:82]
Tegra Processor business revenue decreased by 48% in fiscal year 2014 compared to fiscal year 2013. This decrease was primarily due to lower sales of our previous generation Tegra 3-based products for smartphones and tablet devices. Additionally, sales of our embedded products for entertainment devices and revenue from license fees related to game consoles also decreased during fiscal year 2014. These decreases were partially offset by increased sales of Tegra 4-based products for smartphones and tablet devices, as well as for automotive infotainment systems.

[0001045810-15-000036:mdna:83]
All Other.  License revenue from the patent cross licensing arrangement we entered into with Intel in January 2011 was flat at $264.0 million for fiscal years 2015, 2014 and 2013.

[0001045810-15-000036:mdna:84]
Concentration of Revenue

[0001045810-15-000036:mdna:85]
Revenue from sales to customers outside of the United States and Other Americas accounted for 75% of total revenue for both fiscal years 2015 and 2014, and 74% of total revenue for fiscal year 2013. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-15-000036:mdna:86]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-15-000036:mdna:87]
|  | Year Ended |
|  | January 25, 2015 |  | January 26,2014 |  | January 27,2013 |
| Revenue: |  |  |  |  |  |
| Customer A | 11 | % |  | 11 | % |  | 13 | % |
| Customer B | 9 | % |  | 10 | % |  | 9 | % |

[0001045810-15-000036:mdna:88]
Gross Profit and Gross Margin

[0001045810-15-000036:mdna:89]
Gross profit consists of total revenue, net of allowances, less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, board and  device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions and shipping costs. Cost of revenue also includes development costs for license and service arrangements and stock-based compensation related to personnel associated with manufacturing.

[0001045810-15-000036:mdna:90]
Gross margin is the percentage of gross profit to revenue. Our gross margin can vary in any period depending on the mix of types of products sold. Our gross margin is significantly impacted by the mix of products we sell, which is often difficult to estimate with accuracy. Therefore, if we experience product transition challenges, if we achieve significant revenue growth in our lower margin product lines, or if we are unable to earn as much revenue as we expect from higher margin product lines, our gross margin may be negatively impacted.

[0001045810-15-000036:mdna:91]
Our overall gross margin was 55.5%, 54.9% and 52.0% for fiscal years 2015, 2014 and 2013, respectively.  The increase over these fiscal years was driven primarily by a richer product mix in our GPU business, partially offset by lower Tegra business margins.

[0001045810-15-000036:mdna:92]
Charges to cost of sales for inventory provisions totaled $59.4 million, $50.1 million and $89.9 million for fiscal years 2015, 2014 and 2013, unfavorably impacting our gross margin by 1.3%, 1.2% and 2.1%, respectively. Sales of inventory that was previously written-off or written-down totaled $32.4 million, $43.4 million and $53.7 million for fiscal years 2015, 2014 and 2013, favorably impacting our gross margin by 0.7%, 1.1% and 1.3%, respectively. As a result, the overall net effect on our gross margin from inventory provisions and sales of items previously written down was an unfavorable impact of 0.6%, 0.1% and 0.8% in fiscal years 2015, 2014 and 2013, respectively.

[0001045810-15-000036:mdna:93]
A discussion of our gross margin results for each of our reporting segments is as follows:

[0001045810-15-000036:mdna:94]
GPU Business. The gross margin of our GPU business increased during fiscal year 2015 when compared to fiscal year 2014 due to richer product mix resulting from strong sales of high-end GeForce GTX GPU products based on our Maxwell architecture and the volume increase in our Tesla accelerated computing products. The increase in fiscal year 2014 when compared to fiscal year 2013 was primarily due to a combination of a richer product mix of our high-end GeForce GTX GPU, Tesla high performance computing, and Quadro professional workstation products.  Lower inventory provisions for excess inventory in fiscal year 2014 also contributed to the increase.

[0001045810-15-000036:mdna:95]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased during fiscal year 2015 when compared to fiscal year 2014, and during fiscal year 2014 when compared to fiscal year 2013. These decreases were driven primarily by a combination of an overall decline in margins of our Tegra products and a less rich mix between tablet products, which have had higher gross margins, and smartphone and automotive module products, which have had comparably lower gross margins.

[0001045810-15-000036:mdna:96]
Operating Expenses

[0001045810-15-000036:mdna:97]
|  | Year Ended |  | Year Ended |
|  | January 25,2015 |  | January 26,2014 |  | $Change |  | %Change |  | January 26,2014 |  | January 27,2013 |  | $Change |  | %Change |
|  | (In millions) |  | (In millions) |
| Research and development expenses | $ | 1,359.7 |  |  | $ | 1,335.8 |  |  | $ | 23.9 |  |  | 2 | % |  | $ | 1,335.8 |  |  | $ | 1,147.3 |  |  | $ | 188.5 |  |  | 16 | % |
| Sales, general and administrative expenses | 480.8 |  |  | 435.7 |  |  | 45.1 |  |  | 10 | % |  | 435.7 |  |  | 430.8 |  |  | 4.9 |  |  | 1 | % |
| Total operating expenses | $ | 1,840.5 |  |  | $ | 1,771.5 |  |  | $ | 69.0 |  |  | 4 | % |  | $ | 1,771.5 |  |  | $ | 1,578.1 |  |  | $ | 193.4 |  |  | 12 | % |
| Research and development as a percentage of net revenue | 29.0 | % |  | 32.3 | % |  |  |  |  |  | 32.3 | % |  | 26.8 | % |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 10.3 | % |  | 10.5 | % |  |  |  |  |  | 10.5 | % |  | 10.1 | % |  |  |  |  |

[0001045810-15-000036:mdna:98]
Research and Development

[0001045810-15-000036:mdna:99]
Research and development expenses remained relatively flat during fiscal year 2015 compared to fiscal year 2014. Compensation and benefits increased by $56.5 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense. Offsetting this increase was a $38.9 million decrease in engineering development expenses.

[0001045810-15-000036:mdna:100]
Research and development expenses increased by 16% in fiscal year 2014 compared to fiscal year 2013. Compensation and benefits increased by $101.9 million resulting from employee additions, employee compensation increases and related costs. The growth in engineering employees also drove an increase in facilities and IT support expense of $34.6 million, purchases of computer and software supplies of $14.1 million and depreciation and amortization of $11.0 million. In addition, engineering development expenses increased by $23.2 million, primarily related to the ramp up of Tegra products.

[0001045810-15-000036:mdna:101]
Sales, General and Administrative

[0001045810-15-000036:mdna:102]
Sales, general and administrative expenses increased by 10% in fiscal year 2015 compared to fiscal year 2014. Compensation and benefits increased by $53.7 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense. Facilities costs increased by $10.3 million as we expanded our offices internationally and leased an office building within the boundaries of our main Santa Clara campus. Offsetting these increases were a decrease in outside professional fees of $8.8 million as well as more favorable international taxes and government subsidies.

[0001045810-15-000036:mdna:103]
Sales, general and administrative expenses remained relatively flat during fiscal year 2014 compared to fiscal year 2013.  Compensation and benefits increased by $37.9 million resulting from employee additions, employee compensation increases and related costs. Offsetting this increase were the absence of both a $20.1 million charge for a charitable contribution and a charge of $3.1 million for a class action settlement that we recorded in fiscal year 2013.

[0001045810-15-000036:mdna:104]
Interest Income and Interest Expense

[0001045810-15-000036:mdna:105]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest expense is primarily comprised of coupon interest and debt discount amortization related to the convertible notes issued in the fourth quarter of fiscal year 2014.

[0001045810-15-000036:mdna:106]
Interest income was $28.1 million, $17.1 million and $19.9 million in fiscal years 2015, 2014 and 2013, respectively. The increase in fiscal year 2015 compared to fiscal year 2014 was primarily due to higher average cash balances as we invested the proceeds from the convertible notes we issued in December 2013 in interest bearing securities. The decrease in fiscal year 2014 compared to fiscal year 2013 was primarily due to the result of lower average cash balances as we liquidated a portion of our investment portfolio to fund an accelerated share repurchase transaction during the second quarter of fiscal year 2014.

[0001045810-15-000036:mdna:107]
Interest expense was $46.1 million, $10.4 million and $3.3 million in fiscal years 2015, 2014 and 2013, respectively.  The increases in fiscal years 2015 and 2014 compared to fiscal years 2014 and 2013, respectively, were primarily due to coupon interest and debt discount amortization related to the convertible notes we issued in December 2013.

[0001045810-15-000036:mdna:108]
Other Income and Expense

[0001045810-15-000036:mdna:109]
Other income and expense primarily consists of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, and the impact of changes in foreign currency rates.

[0001045810-15-000036:mdna:110]
Net other income (expense) was $13.9 million, $7.4 million and $(2.8) million in fiscal years 2015, 2014 and 2013, respectively. The increase for fiscal year 2015 compared to fiscal year 2014 was primarily due to a gain from the sale of a non-affiliated investment, partially offset by the recognition of an impairment loss of a non-affiliated investment during the second quarter of fiscal year 2015 and losses from foreign currency remeasurement. The increase in other income for fiscal year 2014 compared to fiscal year 2013 was primarily due to an increase in gains from foreign currency remeasurements and a gain from the sale of a non-affiliated investment.

[0001045810-15-000036:mdna:111]
Income Taxes

[0001045810-15-000036:mdna:112]
We recognized income tax expense of $124.2 million, $70.3 million and $99.5 million during fiscal years 2015, 2014 and 2013, respectively. Income tax expense as a percentage of income before taxes, or our annual effective tax rate, was 16.5%, 13.8%, and 15.0% in fiscal years 2015, 2014 and 2013, respectively. The difference in the effective tax rates amongst the three years was primarily due to an increase in the amount of earnings subject to United States tax in fiscal year 2015 and a higher percentage of research tax credit benefit in fiscal year 2014.

[0001045810-15-000036:mdna:113]
Our effective tax rate on income before tax for the fiscal years was lower than the United States federal statutory rate of  35% due to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate is lower, favorable recognition of the U.S. federal research tax credit and release of tax reserves as a result of the expiration of statutes of limitations in certain non-U.S. jurisdictions for which we had not previously recognized related tax benefits.

[0001045810-15-000036:mdna:114]
Please refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-15-000036:mdna:115]
Liquidity and Capital Resources

[0001045810-15-000036:mdna:116]
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In millions) |
| Cash and cash equivalents | $ | 496.7 |  |  | $ | 1,151.6 |  |
| Marketable securities | 4,126.7 |  |  | 3,520.2 |  |
| Cash, cash equivalents, and marketable securities | $ | 4,623.4 |  |  | $ | 4,671.8 |  |

[0001045810-15-000036:mdna:117]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 905.7 |  |  | $ | 835.1 |  |  | $ | 824.2 |  |
| Net cash (used in) investing activities | $ | (727.0 | ) |  | $ | (805.9 | ) |  | $ | (744.0 | ) |
| Net cash (used in) provided by financing activities | $ | (833.5 | ) |  | $ | 389.6 |  |  | $ | (15.3 | ) |

[0001045810-15-000036:mdna:118]
As of January 25, 2015, we had $4.62 billion in cash, cash equivalents and marketable securities, a decrease of $48.5 million from the end of fiscal year 2014. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions which are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types and includes certain limits on our portfolio duration.

[0001045810-15-000036:mdna:119]
Cash provided by operating activities increased in fiscal year 2015 compared to fiscal year 2014 primarily due to higher net income from revenue growth and contained operating expenses, partially offset by an increase in inventories resulting from the introduction of newly launched Maxwell-based GPUs and certain Tegra SOCs and SHIELD devices, and an increase in accounts receivable. Cash provided by operating activities increased slightly in fiscal year 2014 compared to fiscal year 2013 primarily due to a decrease in operating assets offset by a decrease in net income. The decrease in operating assets was driven mainly by a combination of a decrease in accounts receivable, resulting from strong collections and linear monthly shipments in the fourth quarter of fiscal year 2014, and a decrease in inventories.

[0001045810-15-000036:mdna:120]
Cash used in investing activities for fiscal year 2015 decreased from fiscal year 2014 primarily due to lower purchases of property and equipment and intangible assets. Cash used in investing activities for fiscal year 2014 increased from fiscal year 2013 driven primarily by capital expenditures in fiscal year 2014 for new technology licenses and leasehold improvements at our facilities in various locations.

[0001045810-15-000036:mdna:121]
Cash used in financing activities in fiscal year 2015 resulted primarily from our repurchase of $813.6 million of shares of our common stock and our cash dividend payments totaling $186.5 million.  These uses of cash were offset by cash proceeds of $153.5 million from common stock issued under our employee stock plans. Cash provided by financing activities increased in fiscal year 2014 due primarily to the net proceeds of $1.48 billion we received from the convertible note offering that was completed during the fourth quarter of fiscal year 2014, as well as cash proceeds of $70.2 million from common stock issued under our employee stock plans.  Concurrent with the convertible note offering, we used net proceeds of $108.0 million to fund the related note hedge and warrant transactions. During fiscal year 2014, we also used $887.3 million to repurchase shares of our common stock and paid $181.3 million of cash dividends to shareholders.

[0001045810-15-000036:mdna:122]
37

[0001045810-15-000036:mdna:123]
Liquidity

[0001045810-15-000036:mdna:124]
Our primary source of liquidity is cash generated by our operations. Our investment portfolio consists principally of cash and cash equivalents, debt securities of corporations and United States government and its agencies, asset-backed securities, mortgage-backed securities issued by government-sponsored enterprises, money market funds and foreign government bonds. These investments are denominated in United States dollars. As of January 25, 2015, we did not have any investments in auction-rate preferred securities.

[0001045810-15-000036:mdna:125]
Please refer to Note 7 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-15-000036:mdna:126]
As of January 25, 2015 and January 26, 2014, we had $4.62 billion and $4.67 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of January 25, 2015, we were in compliance with our investment policy. As of January 25, 2015, our investments in U.S. government agencies and U.S. government sponsored enterprises represented 35% of our total investment portfolio, while the financial sector accounted for 30% of our total investment portfolio. All of our investments are with A/A3 or better rated securities.

[0001045810-15-000036:mdna:127]
We performed an impairment review of our investment portfolio as of January 25, 2015.  Based on our quarterly impairment review, we concluded that our investments were appropriately valued and did not record any impairment during fiscal year 2015.

[0001045810-15-000036:mdna:128]
Net realized gains were $0.1 million, $2.4 million and $0.5 million for fiscal years 2015, 2014 and 2013, respectively.  As of January 25, 2015, we had a net unrealized gain of $8.4 million, which was comprised of gross unrealized gains of $11.0 million, offset by $2.6 million of gross unrealized losses.  As of January 26, 2014, we had a net unrealized gain of $4.8 million, which was comprised of gross unrealized gains of $7.2 million, offset by $2.4 million of gross unrealized losses.

[0001045810-15-000036:mdna:129]
Our accounts receivable are highly concentrated. Two customers accounted for 30% of our accounts receivable balance at January 25, 2015. We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure.

[0001045810-15-000036:mdna:130]
Our cash balances are held in numerous locations throughout the world, including substantial amounts held outside of the United States. As of January 25, 2015, we had cash, cash equivalents and marketable securities of $1.72 billion held within the United States and $2.90 billion held outside of the United States.  Most of the amounts held outside the United States may be repatriated to the United States but, under current law, would be subject to U.S. federal income taxes, less applicable foreign tax credits.  Further, repatriation of some foreign balances may be restricted by local laws. As of January 25, 2015, we have not provided for U.S. federal and state income taxes on approximately $2.27 billion of undistributed earnings of non-United States subsidiaries, as such earnings are considered indefinitely reinvested outside the United States.  Although we have no current need to do so, if we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income tax, less applicable foreign tax credits, and reduced by the current amount of our U.S. federal and state net operating loss and tax credit carryforwards.  Further, in addition to the $1.72 billion of cash, cash equivalents and marketable securities held within the United States and available to fund our U.S. operations and any other U.S. cash needs, we have access to external sources of financing if cash is needed in the United States other than by repatriation of foreign earnings where U.S. income tax may otherwise be due.  Accordingly, we do not reasonably expect any material effect on our business, as a whole, or to our financial flexibility with respect to our current cash balances held outside of the United States.

[0001045810-15-000036:mdna:131]
Dividend payments and any share repurchases must be made from cash held in the United States. For fiscal year 2015, we made total cash dividend payments of $186.5 million and repurchased $813.6 million of our common stock, utilizing a significant amount of our U.S. cash balance previously taxed as of January 25, 2015.

[0001045810-15-000036:mdna:132]
Convertible Notes

[0001045810-15-000036:mdna:133]
On December 2, 2013, we issued $1.50 billion of 1.00% Convertible Senior Notes, or the Notes, due in 2018 and concurrently entered into separate note hedge and warrant transactions and used $14.3 million to repurchase shares of our common stock from purchasers of the Notes in privately negotiated transactions. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. As of January 25, 2015, none of the conditions allowing holders of the Notes to convert had been met. Please refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-15-000036:mdna:134]
Capital Return to Shareholders

[0001045810-15-000036:mdna:135]
Our Board of Directors has authorized us to repurchase up to $3.70 billion of our common stock through January 2016. As of January 25, 2015, we had repurchased $3,265.2 million of that amount, leaving up to $434.8 million available under this authorization through January 2016. During fiscal year 2015, we repurchased 44.4 million shares of our common stock for $813.6 million and paid $186.5 million in cash dividends - equivalent to $0.085 per share on a quarterly basis, or $0.34 per share on an annual basis - to our common shareholders. As a result, we returned $1.0 billion to shareholders during fiscal year 2015 in the form of share repurchases and dividend payments.

[0001045810-15-000036:mdna:136]
On November 6, 2014 we announced our intention to return approximately $600.0 million to our shareholders in fiscal year 2016 through a combination of share repurchases and cash dividends. On February 11, 2015, we declared that we would pay our next quarterly cash dividend of $0.085 per share on March 19, 2015, to all shareholders of record on February 26, 2015.

[0001045810-15-000036:mdna:137]
Our cash dividend program and the payment of future cash dividends under that program are subject to continued capital availability and our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders and are in compliance with all laws and agreements of NVIDIA applicable to the declaration and payment of cash dividends. Please refer to Note 14 of the Notes to Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-15-000036:mdna:138]
Operating Capital and Capital Expenditure Requirements

[0001045810-15-000036:mdna:139]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating, acquisition, share repurchase, cash dividend and capital requirements for at least the next twelve months.  However, there is no assurance that we will not need to raise additional equity or debt financing within this time frame. Additional financing may not be available on favorable terms or at all and may be dilutive to our then-current shareholders. We also may require additional capital for other purposes not presently contemplated. If we are unable to obtain sufficient capital, we could be required to curtail capital equipment purchases or research and development expenditures, which could harm our business. Factors that could affect our cash used or generated from operations and, as a result, our need to seek additional borrowings or capital include:

[0001045810-15-000036:mdna:140]
| • | decreased demand and market acceptance for our products and/or our customers’ products; |

[0001045810-15-000036:mdna:141]
| • | inability to successfully develop and produce in volume production our next-generation products; |

[0001045810-15-000036:mdna:142]
| • | competitive pressures resulting in lower than expected average selling prices; and |

[0001045810-15-000036:mdna:143]
| • | new product announcements or product introductions by our competitors. |

[0001045810-15-000036:mdna:144]
We expect to spend approximately $150.0 million to $200.0 million for capital expenditures during fiscal year 2016, primarily for facilities, emulation equipment, computers and engineering workstations.

[0001045810-15-000036:mdna:145]
Contractual Obligations

[0001045810-15-000036:mdna:146]
The following table summarizes our contractual obligations as of January 25, 2015:

[0001045810-15-000036:mdna:147]
|  | Payment Due By Period |
| Contractual Obligations | Total |  | Less than1 Year |  | 1-3 Years |  | 4-5 Years |  | More than5 Years |  | All Other |
|  | (In thousands) |  |  |
| 1.00% Convertible Senior Notes due 2018 (1) | $ | 1,560,000 |  |  | $ | 15,000 |  |  | $ | 30,000 |  |  | $ | 1,515,000 |  |  | $ | — |  |  | $ | — |  |
| Inventory purchase obligations | 456,000 |  |  | 456,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating leases (2) | 241,311 |  |  | 76,741 |  |  | 100,312 |  |  | 36,781 |  |  | 27,477 |  |  | — |  |
| Uncertain tax positions, interest and penalties (3) | 120,961 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 120,961 |  |
| Capital purchase obligations | 51,000 |  |  | 51,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Capital lease | 22,156 |  |  | 5,303 |  |  | 11,060 |  |  | 5,793 |  |  | — |  |  | — |  |
| Retention program (4) | 3,521 |  |  | 3,521 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 2,454,949 |  |  | $ | 607,565 |  |  | $ | 141,372 |  |  | $ | 1,557,574 |  |  | $ | 27,477 |  |  | $ | 120,961 |  |

[0001045810-15-000036:mdna:148]
| (1) | Represents the aggregate principal amount of $1.50 billion and anticipated interest payments of $60.0 million of the Notes. See Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K. |

[0001045810-15-000036:mdna:149]
| (2) | Includes facilities leases as well as non-cancelable obligations under certain software licensing arrangements in the operating lease category. |

[0001045810-15-000036:mdna:150]
| (3) | Represents unrecognized tax benefits of $121.0 million which consists of $106.6 million plus the related interest and penalties of $14.4 million recorded in non-current income tax payable as of January 25, 2015. We are unable to reasonably estimate the timing of any potential tax liability or interest/penalty payments in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. |

[0001045810-15-000036:mdna:151]
| (4) | Represents the remaining portion of a retention program totaling approximately $61.5 million that we initiated in fiscal year 2012 in connection with our acquisition of Icera. As of January 25, 2015, we have made payments of $58.0 million in connection with this program. The remaining payments will be paid out within the next year. |

[0001045810-15-000036:mdna:152]
Off-Balance Sheet Arrangements

[0001045810-15-000036:mdna:153]
During fiscal years 2015, 2014 and 2013, we had no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001045810-15-000036:mdna:154]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000036:mdna:155]
Please see Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a discussion of adoption of new and recently issued accounting pronouncements.
