# NVDA notes — 0001045810-15-000036


## nvda:AssetPurchaseDisclosureTextBlock

[0001045810-15-000036:notes:1]
3dfx

[0001045810-15-000036:notes:2]
During fiscal year 2002, we completed the purchase of certain assets from 3dfx Interactive, Inc., or 3dfx, for an aggregate purchase price of $74.2 million. On December 15, 2000, NVIDIA Corporation and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or the APA, which closed on April 18, 2001, to purchase certain graphics chip assets from 3dfx.

[0001045810-15-000036:notes:3]
In October 2002, 3dfx filed for Chapter 11 bankruptcy protection in the United States Bankruptcy Court for the Northern District of California. In March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx’s bankruptcy estate served his complaint on NVIDIA. The Trustee’s complaint asserted claims for, among other things, successor liability and fraudulent transfer and sought additional payments from us. In early November 2005, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors’ Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee’s claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx.  The Trustee advised that he intended to object to the settlement.

[0001045810-15-000036:notes:4]
The conditional settlement never progressed substantially through the confirmation process. On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. Oral argument on the appeal was held on October 8, 2014. On November 6, 2014, the Ninth Circuit affirmed the District Court’s decision upholding the ruling of the Bankruptcy Court. As a result, we paid $5.6 million in related legal expenses. The case concluded on February 5, 2015 and we reversed the $25.0 million liability for additional contingent consideration and reduced the goodwill related to our 3dfx acquisition by the same amount as of January 25, 2015.

[0001045810-15-000036:notes:5]
Please refer to Note 12 of these Notes to the Consolidated Financial Statements for further information regarding this litigation.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-15-000036:notes:6]
Balance Sheet Components

[0001045810-15-000036:notes:7]
Certain balance sheet components are as follows:

[0001045810-15-000036:notes:8]
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 156,846 |  |  | $ | 126,896 |  |
| Work in-process | 91,778 |  |  | 94,844 |  |
| Finished goods | 234,269 |  |  | 166,025 |  |
| Total inventories | $ | 482,893 |  |  | $ | 387,765 |  |

[0001045810-15-000036:notes:9]
|  | January 25, 2015 |  | January 26, 2014 |  | EstimatedUseful Life |
|  | (In thousands) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218,496 |  |  | $ | 218,496 |  |  | (A) |
| Building | 19,268 |  |  | 19,268 |  |  | 5-25 |
| Test equipment | 397,319 |  |  | 412,862 |  |  | 3-5 |
| Software and licenses | 112,967 |  |  | 120,435 |  |  | 3-5 |
| Leasehold improvements | 173,691 |  |  | 178,884 |  |  | (B) |
| Computer equipment | 152,733 |  |  | 204,344 |  |  | 3 |
| Office furniture and equipment | 48,692 |  |  | 58,874 |  |  | 5 |
| Capital leases | 28,481 |  |  | 28,481 |  |  | (B) |
| Construction in process | 27,610 |  |  | 41,176 |  |  | (C) |
| Total property and equipment, gross | 1,179,257 |  |  | 1,282,820 |  |  |  |
| Accumulated depreciation and amortization | (621,975 | ) |  | (700,080 | ) |  |  |
| Total property and equipment, net | $ | 557,282 |  |  | $ | 582,740 |  |  |  |

[0001045810-15-000036:notes:10]
(A)  Land is a non-depreciable asset.

[0001045810-15-000036:notes:11]
(B)  Leasehold improvements and capital leases are amortized based on the lesser of either the asset’s estimated useful life or the remaining expected lease term.

[0001045810-15-000036:notes:12]
(C)  Construction in process represents assets that are not in service as of the balance sheet date.

[0001045810-15-000036:notes:13]
Depreciation expense for fiscal years 2015, 2014 and 2013 was $143.1 million, $164.0 million and $157.6 million, respectively.

[0001045810-15-000036:notes:14]
Accumulated amortization of leasehold improvements and capital leases was $139.6 million and $146.4 million at January 25, 2015 and January 26, 2014, respectively. Amortization of leasehold improvements and capital leases is included in depreciation and amortization expense.

[0001045810-15-000036:notes:15]
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In thousands) |
| Accrued Liabilities: |  |  |  |
| Deferred revenue (1) | $ | 292,735 |  |  | $ | 268,808 |  |
| Customer related liabilities (2) | 146,724 |  |  | 163,945 |  |
| Accrued payroll and related expenses | 112,173 |  |  | 109,721 |  |
| Professional service fees | 17,025 |  |  | 13,572 |  |
| Facilities related liabilities | 7,603 |  |  | 5,216 |  |
| Warranty accrual (3) | 7,523 |  |  | 7,571 |  |
| Taxes payable, short- term | 2,810 |  |  | 2,378 |  |
| Coupon interest on Notes | 2,542 |  |  | 2,500 |  |
| Accrued legal settlement (4) | — |  |  | 30,600 |  |
| Other | 13,672 |  |  | 16,794 |  |
| Total accrued liabilities and other | $ | 602,807 |  |  | $ | 621,105 |  |

[0001045810-15-000036:notes:16]
(1)  The increase in fiscal year 2015 compared to fiscal year 2014 was due primarily to higher volumes with certain distributors.

[0001045810-15-000036:notes:17]
(2)  This includes primarily accrued customer programs. Please refer to Note 1 of these Notes to the Consolidated Financial Statements for discussion regarding the nature of accrued customer programs and their accounting treatment related to our revenue recognition policies and estimates.

[0001045810-15-000036:notes:18]
(3)  Please refer to Note 10 of these Notes to the Consolidated Financial Statements for discussion regarding the warranty accrual.

[0001045810-15-000036:notes:19]
(4)  Please refer to Note 4 and Note 12 of these Notes to the Consolidated Financial Statements for discussion regarding the 3dfx litigation.

[0001045810-15-000036:notes:20]
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In thousands) |
| Other Long Term Liabilities: |  |  |  |
| Deferred income tax liability | $ | 232,307 |  |  | $ | 157,953 |  |
| Income tax payable | 120,961 |  |  | 119,977 |  |
| Deferred revenue | 107,838 |  |  | 172,199 |  |
| Asset retirement obligations | 7,428 |  |  | 11,056 |  |
| Other | 20,394 |  |  | 13,940 |  |
| Total other long-term liabilities | $ | 488,928 |  |  | $ | 475,125 |  |


## nvda:ScheduleofaccountsreceivablepercentagesfromsignificantcustomerstextblockTableTextBlock

[0001045810-15-000036:notes:21]
|  | January 25, 2015 |  | January 26, 2014 |
| Accounts Receivable: |  |  |  |
| Customer B | 20 | % |  | 23 | % |
| Customer C | 10 | % |  | 9 | % |


## nvda:SummaryofequityawardsgrantedunderequityincentiveplansTableTextBlock

[0001045810-15-000036:notes:22]
|  | Year Ended |
|  | January 25, |  | January 26, |  | January 27, |
| 2015 |  | 2014 |  | 2013 |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |
| Awards granted | 86 |  |  | 6,149 |  |  | 7,119 |  |
| Estimated total grant-date fair value | $ | 345 |  |  | $ | 21,310 |  |  | $ | 38,326 |  |
| Weighted average grant-date fair value (per share) | $ | 4.02 |  |  | $ | 3.47 |  |  | $ | 5.38 |  |
| RSUs and PSUs |  |  |  |  |  |
| Awards granted | 12,912 |  |  | 10,757 |  |  | 8,136 |  |
| Estimated total grant-date fair value | $ | 228,223 |  |  | $ | 144,798 |  |  | $ | 112,795 |  |
| Weighted average grant-date fair value (per share) | $ | 17.68 |  |  | $ | 13.46 |  |  | $ | 13.86 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 6,672 |  |  | 6,124 |  |  | 5,463 |  |
| Weighted average price (per share) | $ | 10.99 |  |  | $ | 10.79 |  |  | $ | 10.83 |  |
| Weighted average grant-date fair value (per share) | $ | 4.99 |  |  | $ | 5.60 |  |  | $ | 5.16 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-15-000036:notes:23]
|  | January 25, |  | January 26, |
|  | 2015 |  | 2014 |
|  | (In thousands) |
| Aggregated unearned stock-based compensation expense | $ | 291,416 |  |  | $ | 256,500 |  |
| Estimated weighted average amortization period | (In years) |
| Stock Options | 1.8 |  |  | 2.5 |  |
| RSUs and PSUs | 2.8 |  |  | 2.7 |  |
| ESPP | 0.5 |  |  | 0.6 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001045810-15-000036:notes:24]
Advertising Expenses

[0001045810-15-000036:notes:25]
We expense advertising costs in the period in which they are incurred. Advertising expenses for fiscal years 2015, 2014 and 2013 were $14.6 million, $13.1 million and $9.2 million, respectively.


## us-gaap:AssetRetirementObligationsAndEnvironmentalCostPolicyTextBlock

[0001045810-15-000036:notes:26]
Accounting for Asset Retirement Obligations

[0001045810-15-000036:notes:27]
We account for asset retirement obligations associated with the retirement of tangible long-lived assets and the associated asset retirement costs. The accounting guidance applies to legal obligations associated with the retirement of long-lived assets that result from the acquisition, construction, development and/or normal use of the assets and requires that the fair value of a liability for an asset retirement obligation be recognized in the period in which it is incurred if a reasonable estimate of fair value can be made. The fair value of the liability is added to the carrying amount of the associated asset and this additional carrying amount is depreciated over the life of the asset. As of January 25, 2015 and January 26, 2014, our asset retirement obligations to return the leasehold improvements at our headquarters facility and certain laboratories at our domestic and international facilities to their original condition upon lease termination were $7.4 million and $11.1 million, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-15-000036:notes:28]
|  | January 25, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 2,184,925 |  |  | $ | 2,600 |  |  | $ | (1,214 | ) |  | $ | 2,186,311 |  |
| Debt securities of United States government agencies | 749,630 |  |  | 917 |  |  | (227 | ) |  | 750,320 |  |
| Debt securities issued by United States Treasury | 533,673 |  |  | 2,694 |  |  | (3 | ) |  | 536,364 |  |
| Asset-backed securities | 453,088 |  |  | 125 |  |  | (329 | ) |  | 452,884 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 274,366 |  |  | 4,589 |  |  | (850 | ) |  | 278,105 |  |
| Money market funds | 132,495 |  |  | — |  |  | — |  |  | 132,495 |  |
| Foreign government bonds | 84,800 |  |  | 121 |  |  | (5 | ) |  | 84,916 |  |
| Total | $ | 4,412,977 |  |  | $ | 11,046 |  |  | $ | (2,628 | ) |  | $ | 4,421,395 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 294,710 |  |
| Marketable securities |  |  |  |  |  |  | 4,126,685 |  |
| Total |  |  |  |  |  |  | $ | 4,421,395 |  |

[0001045810-15-000036:notes:29]
|  | January 26, 2014 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 1,762,833 |  |  | $ | 1,837 |  |  | $ | (945 | ) |  | $ | 1,763,725 |  |
| Debt securities of United States government agencies | 1,012,740 |  |  | 848 |  |  | (261 | ) |  | 1,013,327 |  |
| Debt securities issued by United States Treasury | 495,889 |  |  | 621 |  |  | (57 | ) |  | 496,453 |  |
| Money market funds | 307,865 |  |  | — |  |  | — |  |  | 307,865 |  |
| Asset-backed securities | 258,017 |  |  | 15 |  |  | (315 | ) |  | 257,717 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 185,594 |  |  | 3,837 |  |  | (725 | ) |  | 188,706 |  |
| Foreign government bonds | 64,955 |  |  | 20 |  |  | (120 | ) |  | 64,855 |  |
| Total | $ | 4,087,893 |  |  | $ | 7,178 |  |  | $ | (2,423 | ) |  | $ | 4,092,648 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 572,425 |  |
| Marketable securities |  |  |  |  |  |  | 3,520,223 |  |
| Total |  |  |  |  |  |  | $ | 4,092,648 |  |

[0001045810-15-000036:notes:30]
The following table provides the breakdown of the investments that were in a continuous unrealized loss position at January 25, 2015:

[0001045810-15-000036:notes:31]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In thousands) |
| Corporate debt securities | $ | 709,392 |  |  | $ | (1,199 | ) |  | $ | 10,085 |  |  | $ | (15 | ) |  | $ | 719,477 |  |  | $ | (1,214 | ) |
| Mortgage backed securities issued by United States government-sponsored enterprises | 81,245 |  |  | (639 | ) |  | 21,314 |  |  | (211 | ) |  | 102,559 |  |  | (850 | ) |
| Debt securities of United States Treasury | 10,026 |  |  | (3 | ) |  | — |  |  | — |  |  | 10,026 |  |  | (3 | ) |
| Debt securities issued by United States government agencies | 246,480 |  |  | (227 | ) |  | — |  |  | — |  |  | 246,480 |  |  | (227 | ) |
| Asset-backed securities | 306,066 |  |  | (323 | ) |  | 4,476 |  |  | (6 | ) |  | 310,542 |  |  | (329 | ) |
| Foreign government bonds | 11,008 |  |  | (5 | ) |  | — |  |  | — |  |  | 11,008 |  |  | (5 | ) |
| Total | $ | 1,364,217 |  |  | $ | (2,396 | ) |  | $ | 35,875 |  |  | $ | (232 | ) |  | $ | 1,400,092 |  |  | $ | (2,628 | ) |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001045810-15-000036:notes:32]
Cash and Cash Equivalents

[0001045810-15-000036:notes:33]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. As of January 25, 2015 and January 26, 2014, our cash and cash equivalents were $496.7 million and $1,151.6 million, respectively, which include $132.5 million and $307.9 million invested in money market funds for fiscal year 2015 and fiscal year 2014, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-15-000036:notes:34]
Commitments and Contingencies

[0001045810-15-000036:notes:35]
Inventory Purchase Obligations

[0001045810-15-000036:notes:36]
At January 25, 2015, we had outstanding inventory purchase obligations totaling $456.0 million.

[0001045810-15-000036:notes:37]
Capital Purchase Obligations

[0001045810-15-000036:notes:38]
At January 25, 2015, we had outstanding capital purchase obligations totaling $51.0 million.

[0001045810-15-000036:notes:39]
Lease Obligations

[0001045810-15-000036:notes:40]
Our headquarters complex is located in Santa Clara, California and includes eight buildings that are leased properties. Future minimum lease payments related to headquarters operating leases total $73.1 million over the remaining terms of the leases, including predetermined rent escalations, and are included in the future minimum lease payment schedule below.

[0001045810-15-000036:notes:41]
In addition to the commitment of our headquarters, we have other domestic and international office facilities under operating leases expiring through fiscal year 2025. We also include non-cancelable obligations under certain software licensing arrangements as operating leases.

[0001045810-15-000036:notes:42]
Future minimum lease payments under our non-cancelable operating leases as of January 25, 2015, are as follows:

[0001045810-15-000036:notes:43]
|  | Future Minimum Lease Obligations |
|  | (In thousands) |
| Fiscal Year: |  |
| 2016 | $ | 76,741 |  |
| 2017 | 66,242 |  |
| 2018 | 34,070 |  |
| 2019 | 26,793 |  |
| 2020 | 9,988 |  |
| 2021 and thereafter | 27,477 |  |
| Total | $ | 241,311 |  |

[0001045810-15-000036:notes:44]
Rent expense for the years ended January 25, 2015, January 26, 2014 and January 27, 2013 was $47.3 million, $43.8 million and $38.4 million, respectively.

[0001045810-15-000036:notes:45]
Capital lease obligations include building and office equipment lease obligations. The building lease relates to our datacenter in Santa Clara, California. Future minimum lease payments under the building capital lease total $20.9 million over the remaining lease term, including predetermined rent escalations, and are included in the future minimum lease payment schedule below:

[0001045810-15-000036:notes:46]
|  | Future Capital Lease Obligations |
|  | (In thousands) |
| Fiscal Year: |  |  |
| 2016 | $ | 5,303 |  |
| 2017 | 5,453 |  |
| 2018 | 5,607 |  |
| 2019 | 5,767 |  |
| 2020 | 26 |  |
| 2021 and thereafter | — |  |
| Total | $ | 22,156 |  |
| Present value of minimum lease payments | $ | 17,500 |  |
| Current portion | $ | 3,414 |  |
| Long-term portion | $ | 14,086 |  |

[0001045810-15-000036:notes:47]
Litigation

[0001045810-15-000036:notes:48]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx. The transaction closed on April 18, 2001. In October 2002, 3dfx filed for bankruptcy.

[0001045810-15-000036:notes:49]
Following the bankruptcy, in March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us. The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which difference the Trustee estimated to exceed $50.0 million. The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.

[0001045810-15-000036:notes:50]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement never progressed substantially through the confirmation process.

[0001045810-15-000036:notes:51]
In March 2007, a trial was held regarding certain valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.” This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending. On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment. That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008. The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.

[0001045810-15-000036:notes:52]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. Oral argument on the appeal was held on October 8, 2014. On November 6, 2014, the Ninth Circuit affirmed the District Court’s decision upholding the ruling of the Bankruptcy Court and the case concluded on February 5, 2015.

[0001045810-15-000036:notes:53]
Securities Cases

[0001045810-15-000036:notes:54]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended.

[0001045810-15-000036:notes:55]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.

[0001045810-15-000036:notes:56]
Patent Infringement Cases

[0001045810-15-000036:notes:57]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway.  On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the patents at issue. A decision on claim construction is expected in March 2015.

[0001045810-15-000036:notes:58]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action. The court granted the motion to stay on October 23, 2014.

[0001045810-15-000036:notes:59]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, Samsung filed an amended, longer complaint but asserting the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the amended complaint on January 26, 2015 and filed an amended answer on March 3, 2015. On January 12, 2015, NVIDIA moved to transfer the action to the Northern District of California and to sever and stay the proceedings against Velocity Micro, Inc. Briefing on the motion to transfer is now complete and submitted to the court for decision.

[0001045810-15-000036:notes:60]
Accounting for Loss Contingencies

[0001045810-15-000036:notes:61]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of January 25, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001045810-15-000036:notes:62]
Product Warranties

[0001045810-15-000036:notes:63]
We generally offer limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001045810-15-000036:notes:64]
Stock-based Compensation

[0001045810-15-000036:notes:65]
We estimate the fair value of employee stock options on the date of grant using a binomial model and recognize the expense using a straight-line attribution method over the requisite employee service period. We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units, or PSUs. The compensation expense for the RSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001045810-15-000036:notes:66]
Comprehensive Income

[0001045810-15-000036:notes:67]
Comprehensive income consists of net income and other comprehensive income (loss). Other comprehensive income (loss) components include unrealized gains (losses) on available-for-sale securities, net of tax.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-15-000036:notes:68]
Principles of Consolidation

[0001045810-15-000036:notes:69]
Our consolidated financial statements include the accounts of NVIDIA Corporation and its wholly-owned subsidiaries. All material intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001045810-15-000036:notes:70]
Long-Term Debt

[0001045810-15-000036:notes:71]
1.00 % Convertible Senior Notes Due 2018

[0001045810-15-000036:notes:72]
On December 2, 2013, we issued $1.50 billion of the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of  $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-15-000036:notes:73]
Holders may convert their notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter commencing after the fiscal quarter ended on  April 27, 2014 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their notes regardless of the foregoing conditions. Upon conversion, we will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0001045810-15-000036:notes:74]
As of January 25, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Consolidated Balance Sheets.

[0001045810-15-000036:notes:75]
In accordance with ASC 470-20 Debt with Conversion and Other Options, all cash-settled convertible debt should be separated into debt and equity components at issuance and be assigned a fair value.   The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-15-000036:notes:76]
The initial debt component of the Notes was valued at $1,351.8 million based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $125.7 million and recorded as a debt discount. This amount, together with the $22.5 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $148.2 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-15-000036:notes:77]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-15-000036:notes:78]
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In thousands) |
| Amount of the equity component | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) | (115,658 | ) |  | (143,625 | ) |
| Net carrying amount | $ | 1,384,342 |  |  | $ | 1,356,375 |  |

[0001045810-15-000036:notes:79]
(1) As of January 25, 2015, the remaining period over which the unamortized debt discount will be amortized is 3.9 years.

[0001045810-15-000036:notes:80]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

[0001045810-15-000036:notes:81]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In thousands) |
| Contractual coupon interest expense | $ | 15,000 |  |  | $ | 2,500 |  |
| Amortization of debt discount | 27,967 |  |  | 4,600 |  |
| Amortization of debt issuance costs | 195 |  |  | 34 |  |
| Total interest expense related to Notes | $ | 43,162 |  |  | $ | 7,134 |  |

[0001045810-15-000036:notes:82]
Note Hedges and Warrants

[0001045810-15-000036:notes:83]
The net proceeds from the Notes were approximately $1,477.5 million after payment of the initial purchaser's discount.  Concurrently with the offering of the Notes, we entered into the Note Hedges with a strike price equal to the initial conversion price of the Notes, or approximately $20.16 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would pay to the holders of the Notes upon conversion. We paid $167.1 million for the Note Hedges.

[0001045810-15-000036:notes:84]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with a strike price to the holders of the Warrants of $27.14 per share. The Warrants are net share settled and cover, subject to customary antidilution adjustments, 74.4 million shares of our common stock. We received $59.1 million for the Warrants transaction.

[0001045810-15-000036:notes:85]
The $108.0 million net cost of the Note Hedges offset by the proceeds from the Warrants was included as a net reduction to additional paid-in capital in the shareholders’ equity section of our consolidated balance sheets, in accordance with the guidance in ASC 815-40 Derivatives and Hedging-Contracts in Entity's Own Equity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-15-000036:notes:86]
Stock-Based Compensation

[0001045810-15-000036:notes:87]
Our stock-based compensation expense is associated with stock options, RSUs, PSUs and our ESPP.

[0001045810-15-000036:notes:88]
Our consolidated statements of income include stock-based compensation expense, net of amounts capitalized as inventory, as follows:

[0001045810-15-000036:notes:89]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  | (In thousands) |
| Cost of revenue | $ | 12,022 |  |  | $ | 10,688 |  |  | $ | 10,490 |  |
| Research and development | 88,355 |  |  | 82,940 |  |  | 82,157 |  |
| Sales, general and administrative | 57,464 |  |  | 42,667 |  |  | 44,015 |  |
| Total | $ | 157,841 |  |  | $ | 136,295 |  |  | $ | 136,662 |  |

[0001045810-15-000036:notes:90]
Stock-based compensation capitalized in inventories resulted in a net charge of $0.1 million, $0.1 million and $0.4 million in cost of revenue during the fiscal years 2015, 2014 and 2013, respectively.

[0001045810-15-000036:notes:91]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-15-000036:notes:92]
During fiscal year 2015, we shifted away from granting stock options and toward granting RSUs and PSUs to reflect changing market trends for equity incentives at our peer companies. The number of PSUs that will ultimately vest is contingent on the Company’s level of achievement versus the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year. The number of shares of our stock to be received at vesting typically ranges from 0% to 200% of the target amount.

[0001045810-15-000036:notes:93]
Of the estimated total grant-date fair value, we estimated that the stock-based compensation expense related to the equity awards that are not expected to vest for fiscal years 2015, 2014 and 2013 was $36.6 million, $29.7 million and $27.1 million, respectively.

[0001045810-15-000036:notes:94]
Valuation Assumptions

[0001045810-15-000036:notes:95]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of RSUs and PSUs. Compensation expense for RSUs is recognized using a straight-line attribution method over the requisite employee service period, while compensation expense for PSUs is recognized using an accelerated amortization model.

[0001045810-15-000036:notes:96]
We estimate the fair value of employee stock options on the date of grant using a binomial model and recognize the expense using a straight-line attribution method over the requisite employee service period.

[0001045810-15-000036:notes:97]
We estimate the fair value of shares to be issued under our ESPP using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model.

[0001045810-15-000036:notes:98]
The fair value of stock options granted under our stock option plans and shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-15-000036:notes:99]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  | (Using a binomial model) |
| Stock Options |  |  |  |  |  |
| Weighted average expected life (in years) | 2.5-3.2 |  | 2.4-3.5 |  | 3.1-4.9 |
| Risk-free interest rate | 2.5%-2.8% |  | 1.8%-3.0% |  | 1.5%-2.3% |
| Volatility | 31% |  | 28%-37% |  | 39%-49% |
| Dividend yield | 1.8%-1.9% |  | 1.9%-2.4% |  | 2.4% |

[0001045810-15-000036:notes:100]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.5-2.0 |  | 0.5-2.0 |  | 0.5-2.0 |  |
| Risk-free interest rate | 0.1%-0.5% |  | 0.1%-0.4% |  | 0.1%-0.3% |  |
| Volatility | 23%-31% |  | 32%-37% |  | 44%-47% |  |
| Dividend yield | 1.7%-1.9% |  | 2.0%-2.4% |  | — |  |

[0001045810-15-000036:notes:101]
The expected life of employee stock options is a derived output of our valuation model and is impacted by the underlying assumptions of our company. For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date.

[0001045810-15-000036:notes:102]
The risk-free interest rate assumption used to value stock options and ESPP is based upon observed interest rates on Treasury bills appropriate for the expected term of the award.

[0001045810-15-000036:notes:103]
Our expected stock price volatility assumption for stock options and ESPP is estimated using implied volatility.

[0001045810-15-000036:notes:104]
For awards granted on or subsequent to November 8, 2012, we use a dividend yield at grant date, based on the per share dividends declared during the most recent quarter. Our RSU and PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair value of RSUs and PSUs is discounted by the dividend yield.

[0001045810-15-000036:notes:105]
Additionally, for employee stock options and RSU and PSU awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-15-000036:notes:106]
Equity Incentive Program

[0001045810-15-000036:notes:107]
We grant stock options, RSUs, PSUs, and stock purchase rights under the following equity incentive plans.

[0001045810-15-000036:notes:108]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-15-000036:notes:109]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, or the 2007 Plan. The 2007 Plan was amended and restated in 2012, 2013 and 2014, or the Restated 2007 Plan.

[0001045810-15-000036:notes:110]
The Restated 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock unit, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. With the 2014 amendment and restatement of the 2007 Plan, which increased the number of shares of common stock authorized for issuance under the 2007 Plan by 10,000,000 shares, up to 187,767,766 shares of our common stock may be issued pursuant to stock awards granted under the Restated 2007 Plan. Currently, we grant stock options, RSUs and PSUs under the Restated 2007 Plan, under which, as of January 25, 2015, there were 24,501,781 shares available for future issuance.

[0001045810-15-000036:notes:111]
Stock options granted to employees, subject to certain exceptions, vest over a four year period, subject to continued service, with 25% vesting on the anniversary of the hire date in the case of new hires or the anniversary of the date of grant in the case of grants to existing employees and 6.25% vesting at the end of each quarterly period thereafter. Options granted under the 2007 Plan generally expire ten years from the date of grant.

[0001045810-15-000036:notes:112]
Subject to certain exceptions, RSUs granted to employees vest over a four year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 12.5% vesting semi-annually thereafter until fully vested.

[0001045810-15-000036:notes:113]
PSUs granted to employees vest on a similar schedule, although the number of shares subject to PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-15-000036:notes:114]
Unless terminated sooner, the Restated 2007 Plan is scheduled to terminate on March 21, 2022. Our Board may suspend or terminate the Restated 2007 Plan at any time. No awards may be granted under the Restated 2007 Plan while the Restated 2007 Plan is suspended or after it is terminated. The Board may also amend the Restated 2007 Plan at any time. However, if legal, regulatory or listing requirements require shareholder approval, the amendment will not go into effect until the shareholders have approved the amendment.

[0001045810-15-000036:notes:115]
PortalPlayer, Inc. 1999 Stock Option Plan

[0001045810-15-000036:notes:116]
We assumed options issued under the PortalPlayer, Inc. 1999 Stock Option Plan, or the 1999 Plan, when we completed our acquisition of PortalPlayer on January 5, 2007.  As of January 25, 2015, there were no outstanding options to purchase NVIDIA common stock under the 1999 Plan and we do not intend to grant future stock awards under the 1999 Plan as the plan expired on July 28, 2014.

[0001045810-15-000036:notes:117]
1998 and 2012 Employee Stock Purchase Plans

[0001045810-15-000036:notes:118]
In February 1998, our Board approved the 1998 Employee Stock Purchase Plan, or the 1998 Plan. At the Annual Meeting of Shareholders held on May 17, 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, or the 2012 Plan, as the successor to the 1998 Plan.  At the Annual Meeting of Shareholders held on May 23, 2014, our shareholders approved an amendment and restatement of the 2012 Plan, or the Restated 2012 Plan.

[0001045810-15-000036:notes:119]
Prior to the effective date of the 2012 Plan, we had authorized a total of 78,000,000 shares for issuance under the 1998 Plan, 54,567,667 shares of which had been issued, 15,000,000 shares of which were reserved for issuance pursuant to outstanding purchase rights and 8,432,333 shares of which were available for future issuance. Upon its approval by our shareholders in 2012, the maximum aggregate number of shares that could be issued under the 2012 Plan would not exceed 55,432,333 shares.

[0001045810-15-000036:notes:120]
Effective upon the August 31, 2012 purchase date pursuant to the 1998 Plan, of the 15,000,000 shares which had been reserved for issuance pursuant to outstanding purchase rights, 2,687,698 shares were issued pursuant to outstanding purchase rights, 183,000 shares were available but reserved for future issuance, and the remaining 12,129,302 shares were moved into the share reserve of the 2012 Plan. Effective upon the final February 28, 2013 purchase date pursuant to the 1998 Plan, 8,819 shares were issued pursuant to outstanding purchase rights, and the remaining 174,181 shares were moved into the share reserve of the 2012 Plan. With the 2014 amendment and restatement of the 2012 Plan, which increased the share reserve of the Restated 2012 Plan by 12,500,000 shares, up to 65,235,816 shares of our common stock may be issued pursuant to purchases under the Restated 2012 Plan. At January 25, 2015, we had issued 12,787,748 shares and reserved 52,448,068 shares for future issuance under the Restated 2012 Plan.

[0001045810-15-000036:notes:121]
The Restated 2012 Plan is intended to qualify as an “employee stock purchase plan” under Section 423 of the Internal Revenue Code. Under the current offerings adopted pursuant to the Restated 2012 Plan, each offering period is 24 months, which is divided into four purchase periods of six months.

[0001045810-15-000036:notes:122]
Employees are eligible to participate if they are employed by us or an affiliate of us as designated by the Board. Employees who participate in an offering may have up to 10% of their earnings withheld up to certain limitations and applied on specified dates determined by the Board to the purchase of shares of common stock. The Board may increase this percentage at its discretion, up to 15%. The price of common stock purchased under our ESPP will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the purchase date of each offering period. Employees may end their participation in the ESPP at any time during the offering period, and participation ends automatically on termination of employment with us. In each case, the employee’s contributions are refunded.

[0001045810-15-000036:notes:123]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-15-000036:notes:124]
|  | Options Outstanding |  | RSUs and PSUs Outstanding |
|  | Number ofShares |  | Weighted Average Exercise PricePer Share |  | WeightedAverageRemaining Contractual Life |  | Aggregate IntrinsicValue (1) |  | Number ofShares |  | WeightedAverageGrant-DateFair Value |
|  | (In thousands, except years and per share data) |
| Balances, January 26, 2014 | 32,504 |  |  | $ | 14.22 |  |  |  |  |  |  | 18,852 |  |  | $ | 13.82 |  |
| Granted (2) | 86 |  |  | $ | 18.75 |  |  |  |  |  |  | 12,912 |  |  | $ | 17.68 |  |
| Exercised | (9,795 | ) |  | $ | 12.64 |  |  |  |  |  |  | — |  |  | — |  |
| Vested restricted stock | — |  |  | — |  |  |  |  |  |  | (7,163 | ) |  | $ | 13.78 |  |
| Canceled and forfeited | (1,450 | ) |  | $ | 19.27 |  |  |  |  |  |  | (1,326 | ) |  | $ | 14.44 |  |
| Balances, January 25, 2015 | 21,345 |  |  | $ | 14.61 |  |  | 5.9 |  | $ | 130,923 |  |  | 23,275 |  |  | $ | 15.94 |  |
| Exercisable at January 25, 2015 | 15,120 |  |  | $ | 14.70 |  |  | 5.1 |  | $ | 91,434 |  |  |  |  |  |
| Vested and expected to vest after January 25, 2015 | 20,356 |  |  | $ | 14.62 |  |  | 5.8 |  | $ | 124,575 |  |  | 18,988 |  |  | $ | 15.96 |  |

[0001045810-15-000036:notes:125]
| (1) | The aggregate intrinsic value in the table above represents the total pre-tax intrinsic value for in-the-money options at January 25, 2015, based on the $20.71 closing stock price of our common stock on the NASDAQ Global Select Market on January 23, 2015, the last trading day of fiscal year 2015, which would have been received by the option holders had all in-the-money option holders exercised their options as of that date. The total number of in-the-money options outstanding and exercisable as of January 25, 2015 was 21.1 million shares and 14.9 million shares, respectively. |

[0001045810-15-000036:notes:126]
| (2) | Includes the total number of PSUs issuable if the maximum corporate financial performance target level for fiscal year 2015 is achieved. Depending on the actual level of achievement of the corporate performance target at the end of fiscal year 2015, the range of PSUs issued could be from 1.3 million to 2.5 million shares. The PSUs were granted during the first quarter of fiscal year 2015 to our CEO and senior management as approved by our Compensation Committee. |

[0001045810-15-000036:notes:127]
As of January 25, 2015 and January 26, 2014, there were 24.5 million and 24.7 million shares of common stock reserved for future issuance under our equity incentive plans.

[0001045810-15-000036:notes:128]
The total intrinsic value of options exercised was $61.9 million, $14.4 million and $21.1 million for fiscal years 2015, 2014 and 2013, respectively. Upon exercise of an option, we issue new shares of stock. The total fair value of options vested was $32.6 million, $34.6 million and $40.3 million for fiscal years 2015, 2014 and 2013, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001045810-15-000036:notes:129]
Net Income Per Share

[0001045810-15-000036:notes:130]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive.  Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to the Consolidated Financial Statements. The potentially dilutive shares resulting from the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted income per share when their inclusion is dilutive. However, unless actually exercised, the note hedges will not be included in the calculation of diluted net income per share, as their pre-exercised effect would be anti-dilutive under the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001045810-15-000036:notes:131]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income per share computations for the periods presented:

[0001045810-15-000036:notes:132]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  | (In thousands, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 630,587 |  |  | $ | 439,990 |  |  | $ | 562,536 |  |
| Denominator: |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 552,319 |  |  | 587,893 |  |  | 619,324 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock awards outstanding | 10,749 |  |  | 6,624 |  |  | 5,633 |  |
| Denominator for diluted net income per share, weighted average shares | 563,068 |  |  | 594,517 |  |  | 624,957 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.14 |  |  | $ | 0.75 |  |  | $ | 0.91 |  |
| Diluted | $ | 1.12 |  |  | $ | 0.74 |  |  | $ | 0.90 |  |
| Potentially dilutive securities excluded from income per diluted share because their effect would have been anti-dilutive | 11,807 |  |  | 25,630 |  |  | 26,784 |  |

[0001045810-15-000036:notes:133]
The denominator for diluted net income per share for fiscal years 2015 and 2014 does not include any effect from the 1.00 % Convertible Senior Notes due 2018, or the Notes. In accordance with ASC 260, Earnings per Share, commencing after the fiscal quarter ending on April 27, 2014, the Notes will not impact the denominator for diluted net income per share unless the average price of our common stock, as calculated under the terms of the Notes, exceeds the conversion price of $20.16 per share.  Likewise, the denominator for diluted net income per share will not include any effect from the warrants unless the average price of our common stock, as calculated under the terms of the warrants, exceeds $27.14 per share.

[0001045810-15-000036:notes:134]
The denominator for diluted net income per share for fiscal years 2015 and 2014 also does not include any effect from the convertible note hedge transaction, or the Note Hedges. In future periods, the denominator for diluted net income per share will exclude any effect of the Note Hedges, as their effect would be anti-dilutive. In the event an actual conversion of any or all of the Notes occurs, the shares that would be delivered to us under the Note Hedges are designed to neutralize the dilutive effect of the shares that we would issue under the Notes. Please refer to Note 11 of these Notes to the Consolidated Financial Statements for discussion regarding the Notes.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-15-000036:notes:135]
Fair Value of Financial Assets and Liabilities

[0001045810-15-000036:notes:136]
Financial assets measured at fair value

[0001045810-15-000036:notes:137]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. There were no significant transfers between Levels 1 and 2 assets for the year ended January 25, 2015. Level 3 assets are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances. Most of our cash equivalents and marketable securities are valued based on Level 2 inputs. We did not have any investments classified as Level 3 as of January 25, 2015.

[0001045810-15-000036:notes:138]
Financial assets measured at fair value are summarized below:

[0001045810-15-000036:notes:139]
|  |  |  | Fair Value Measurement at Reporting Date Using |
|  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |
|  | January 25, 2015 |  | (Level 1) |  | (Level 2) |
|  | (In thousands) |
| Debt securities of United States government agencies (1) | $ | 750,320 |  |  | $ | — |  |  | $ | 750,320 |  |
| Corporate debt securities (2) | 2,186,311 |  |  | — |  |  | 2,186,311 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises (3) | 278,105 |  |  | — |  |  | 278,105 |  |
| Money market funds (4) | 132,495 |  |  | 132,495 |  |  | — |  |
| Debt securities issued by United States Treasury (3) | 536,364 |  |  | — |  |  | 536,364 |  |
| Asset-backed securities (3) | 452,884 |  |  | — |  |  | 452,884 |  |
| Foreign government bonds (3) | 84,916 |  |  | — |  |  | 84,916 |  |
| Total assets | $ | 4,421,395 |  |  | $ | 132,495 |  |  | $ | 4,288,900 |  |

[0001045810-15-000036:notes:140]
| (1) | Includes $15.0 million in Cash Equivalents and $735.3 million in Marketable Securities on the Consolidated Balance Sheet. |

[0001045810-15-000036:notes:141]
| (2) | Includes $147.2 million in Cash Equivalents and $2.0 billion in Marketable Securities on the Consolidated Balance Sheet. |

[0001045810-15-000036:notes:142]
| (3) | Included in Marketable Securities on the Consolidated Balance Sheet. |

[0001045810-15-000036:notes:143]
| (4) | Included in Cash Equivalents on the Consolidated Balance Sheet. |

[0001045810-15-000036:notes:144]
Financial liabilities measured at fair value

[0001045810-15-000036:notes:145]
We issued $1.50 billion Convertible Senior Notes, or Notes, in December 2013. The Notes are carried at their original issuance value, net of unamortized debt discount, and are not marked to market each period. The estimated fair value of the Notes was  $1,679.6 million and $1,528.4 million, respectively, as of January 25, 2015 and January 26, 2014. The estimated fair value of the Notes was determined on the basis of market prices observable for similar instruments and is considered Level 2 in the fair value hierarchy. Please refer to Note 11 of these Notes to the Consolidated Financial Statements for further information regarding the Notes.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001045810-15-000036:notes:146]
Foreign Currency Remeasurement

[0001045810-15-000036:notes:147]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in “Other income (expense), net” in our Consolidated Statements of Income and to date have not been significant.

[0001045810-15-000036:notes:148]
The impact of gain or loss from foreign currency remeasurement included in determining other income (expense), net for fiscal years 2015, 2014 and 2013 was $0.5 million, $4.7 million and $(1.5) million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001045810-15-000036:notes:149]
Goodwill

[0001045810-15-000036:notes:150]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist.  For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-15-000036:notes:151]
For those reporting units where a significant change or event has occurred, where potential impairment indicators exist, or for which we have not performed a quantitative assessment recently, we utilize a two-step quantitative assessment to testing goodwill for impairment. The first step tests for possible impairment by applying a fair value-based test by weighing the results from the income approach and the market approach.  The second step, if necessary, measures the amount of such impairment by applying fair value-based tests to individual assets and liabilities.  Please refer to Note 5 of these Notes to the Consolidated Financial Statements for additional information.

[0001045810-15-000036:notes:152]
Intangible Assets

[0001045810-15-000036:notes:153]
Intangible assets primarily represent rights acquired under technology licenses, patents, acquired intellectual property, trademarks and customer relationships and are subject to an annual impairment test. We currently amortize our intangible assets with definitive lives over periods ranging from one to ten years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-15-000036:notes:154]
The carrying amount of goodwill is as follows:

[0001045810-15-000036:notes:155]
|  | January 25, 2015 |  | January 26, 2014 |
|  | (In thousands) |
| Icera | $ | 271,186 |  |  | $ | 271,186 |  |
| PortalPlayer | 104,896 |  |  | 104,896 |  |
| 3dfx | 50,326 |  |  | 75,326 |  |
| Mental Images | 59,252 |  |  | 59,252 |  |
| MediaQ | 35,167 |  |  | 35,167 |  |
| ULi | 31,115 |  |  | 31,115 |  |
| Hybrid Graphics | 27,906 |  |  | 27,906 |  |
| Ageia | 19,198 |  |  | 19,198 |  |
| Portland Group Inc. | 2,149 |  |  | 2,149 |  |
| Other | 16,984 |  |  | 16,984 |  |
| Total goodwill | $ | 618,179 |  |  | $ | 643,179 |  |

[0001045810-15-000036:notes:156]
The $25.0 million decrease in goodwill as of January 25, 2015, when compared to January 26, 2014 is due to conclusion of the 3dfx case without requiring additional contingent consideration. Please refer to Note 4 of these Notes to the Consolidated Financial Statements for further discussion regarding the 3dfx case.

[0001045810-15-000036:notes:157]
The amount of goodwill allocated to our GPU and Tegra Processor segments as of January 25, 2015 was $209.7 million and $408.5 million, respectively, and as of January 26, 2014 was $230.4 million and $412.8 million, respectively. Please refer to Note 16 of these Notes to the Consolidated Financial Statements for further discussion regarding segments.

[0001045810-15-000036:notes:158]
We allocate goodwill to our reporting units and perform our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist. For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis. We utilized a quantitative analysis to complete our most recent annual impairment test during the fourth quarter of fiscal year 2015 and concluded that there was no impairment, as the fair value of our reporting units exceeded their carrying values.

[0001045810-15-000036:notes:159]
In a qualitative analysis, we evaluate factors including, but not limited to, macro-economic conditions, market and industry conditions, the competitive environment, the operational stability and the overall financial performance of the reporting units, including cost factors and actual revenue results. For reporting units in which the qualitative assessment concludes it is more likely than not that the fair value is more than its carrying value, no further goodwill impairment testing is required.

[0001045810-15-000036:notes:160]
For those reporting units where a significant change or event has occurred, where potential impairment indicators exist, or for which we have not performed a quantitative assessment recently, we utilize a two-step quantitative assessment to testing goodwill for impairment. The first step tests for possible impairment by applying a fair value-based test by weighing the results from the income approach and the market approach. These valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, terminal or residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-15-000036:notes:161]
When performing an income approach valuation, we incorporate the use of projected financial information and a discount rate that are developed using market participant based assumptions to our discounted cash flow model. Our estimates of discounted cash flow were based upon, among other things, certain assumptions about our expected future operating performance, such as revenue growth rates, operating margins, risk-adjusted discount rates, and future economic and market conditions. The market method of determining the fair value of our reporting units requires us to use judgment in the selection of appropriate market comparables.


## us-gaap:GuaranteesTextBlock

[0001045810-15-000036:notes:162]
Guarantees

[0001045810-15-000036:notes:163]
U.S. GAAP requires that upon issuance of a guarantee, the guarantor must recognize a liability for the fair value of the obligation it assumes under that guarantee. In addition, U.S. GAAP requires disclosures about the guarantees that an entity has issued, including a tabular reconciliation of the changes of the entity’s product warranty liabilities.

[0001045810-15-000036:notes:164]
Accrual for Product Warranty Liabilities

[0001045810-15-000036:notes:165]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. During periods prior to fiscal year 2013, we recorded a cumulative net charge of $475.9 million, most of which was charged against cost of revenue, to cover customer warranty, repair, return, replacement and other costs arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products used in notebook configurations. During fiscal year 2014, we released the remaining $7.8 million unclaimed balance of that warranty accrual.

[0001045810-15-000036:notes:166]
The estimated product returns and estimated product warranty liabilities for fiscal years 2015, 2014 and 2013 are as follows:

[0001045810-15-000036:notes:167]
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  | (In thousands) |
| Balance at beginning of period (1) | $ | 7,571 |  |  | $ | 14,874 |  |  | $ | 18,406 |  |
| Additions | 5,441 |  |  | 6,786 |  |  | 5,738 |  |
| Deductions (2) | (5,489 | ) |  | (14,089 | ) |  | (9,270 | ) |
| Balance at end of period | $ | 7,523 |  |  | $ | 7,571 |  |  | $ | 14,874 |  |

[0001045810-15-000036:notes:168]
(1)  Includes a balance of $9.6 million and $13.2 million for fiscal years 2014 and 2013, respectively, for the remaining amount of the warranty accrual associated with incremental repair and replacement costs from a weak die/packaging material set, which we recorded prior to fiscal year 2013.

[0001045810-15-000036:notes:169]
(2)  Includes $1.8 million and $3.0 million for fiscal years 2014 and 2013, respectively, in payments related to weak die/packaging set warranty accrual recorded prior to fiscal year 2013, and $7.8 million related to the release of the final unclaimed portion of that accrual during fiscal year 2014.

[0001045810-15-000036:notes:170]
In connection with certain agreements that we have executed in the past, we have at times provided indemnities to cover the indemnified party for matters such as tax, product and employee liabilities. We have also on occasion included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. As such, we have not recorded any liability in our Consolidated Financial Statements for such indemnifications.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001045810-15-000036:notes:171]
Impairment of Long-Lived Assets

[0001045810-15-000036:notes:172]
Long-lived assets, such as property and equipment and intangible assets subject to amortization are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset, or asset group may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset, or asset group to estimated undiscounted future cash flows expected to be generated by the asset, or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the consolidated balance sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-15-000036:notes:173]
Income Taxes

[0001045810-15-000036:notes:174]
The income tax expense applicable to income before income taxes consists of the following:

[0001045810-15-000036:notes:175]
|  | Year Ended |
|  | January 25,2015 |  | January 26,2014 |  | January 27,2013 |
|  | (In thousands) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 7,995 |  |  | $ | 7,896 |  |  | $ | 7,506 |  |
| State | 818 |  |  | 1,234 |  |  | 1,016 |  |
| Foreign | 17,356 |  |  | 18,513 |  |  | 16,766 |  |
| Total current | 26,169 |  |  | 27,643 |  |  | 25,288 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | 83,827 |  |  | 17,070 |  |  | 28,143 |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | (1,258 | ) |  | (1,640 | ) |  | 3,717 |  |
| Total deferred | 82,569 |  |  | 15,430 |  |  | 31,860 |  |
| Charge in lieu of taxes attributable to employer stock option plans | 15,511 |  |  | 27,191 |  |  | 42,355 |  |
| Income tax expense | $ | 124,249 |  |  | $ | 70,264 |  |  | $ | 99,503 |  |

[0001045810-15-000036:notes:176]
Income before income tax consists of the following:

[0001045810-15-000036:notes:177]
|  | Year Ended |
|  | January 25,2015 |  | January 26,2014 |  | January 27,2013 |
|  | (In thousands) |
| Domestic | $ | 173,865 |  |  | $ | 79,136 |  |  | $ | 99,422 |  |
| Foreign | 580,971 |  |  | 431,118 |  |  | 562,617 |  |
| Income before income tax | $ | 754,836 |  |  | $ | 510,254 |  |  | $ | 662,039 |  |

[0001045810-15-000036:notes:178]
The income tax expense differs from the amount computed by applying the federal statutory income tax rate of 35% to income before income taxes as follows:

[0001045810-15-000036:notes:179]
|  | Year Ended |
|  | January 25,2015 |  | January 26,2014 |  | January 27,2013 |
|  | (In thousands) |
| Tax expense computed at federal statutory rate | $ | 264,192 |  |  | $ | 178,589 |  |  | $ | 231,714 |  |
| State income taxes, net of federal tax effect | 681 |  |  | 1,608 |  |  | 1,048 |  |
| Foreign tax rate differential | (119,786 | ) |  | (93,831 | ) |  | (123,626 | ) |
| U.S. federal R&D tax credit | (34,319 | ) |  | (30,155 | ) |  | (29,294 | ) |
| Stock-based compensation | 4,332 |  |  | 8,900 |  |  | 11,876 |  |
| Tax expense related to intercompany transaction | 9,785 |  |  | 9,785 |  |  | 9,785 |  |
| Other | (636 | ) |  | (4,632 | ) |  | (2,000 | ) |
| Income tax expense | $ | 124,249 |  |  | $ | 70,264 |  |  | $ | 99,503 |  |

[0001045810-15-000036:notes:180]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-15-000036:notes:181]
|  | January 25,2015 |  | January 26,2014 |
|  | (In thousands) |
| Deferred tax assets: |  |
| Net operating loss carryforwards | $ | 72,322 |  |  | $ | 81,629 |  |
| Accruals and reserves, not currently deductible for tax purposes | 109,123 |  |  | 131,932 |  |
| Property, equipment and intangible assets | 45,593 |  |  | 48,358 |  |
| Research and other tax credit carryforwards | 350,655 |  |  | 306,975 |  |
| Stock-based compensation | 29,850 |  |  | 33,135 |  |
| Convertible debt | 12,327 |  |  | 14,885 |  |
| Gross deferred tax assets | 619,870 |  |  | 616,914 |  |
| Less valuation allowance | (260,985 | ) |  | (244,487 | ) |
| Total deferred tax assets | 358,885 |  |  | 372,427 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (24,463 | ) |  | (33,244 | ) |
| Unremitted earnings of foreign subsidiaries | (500,031 | ) |  | (425,401 | ) |
| Gross deferred tax liabilities | (524,494 | ) |  | (458,645 | ) |
| Net deferred tax liability | $ | (165,609 | ) |  | $ | (86,218 | ) |

[0001045810-15-000036:notes:182]
We recognized income tax expense of $124.2 million, $70.3 million and $99.5 million during fiscal years 2015, 2014 and 2013, respectively. Income tax expense as a percentage of income before taxes, or our annual effective tax rate, was 16.5% in fiscal year 2015, 13.8% in fiscal year 2014 and 15.0% in fiscal year 2013. The difference in the effective tax rates amongst the three years was primarily due to an increase in the amount of earnings subject to United States tax in fiscal year 2015 and a higher percentage of research tax credit benefit in fiscal year 2014.

[0001045810-15-000036:notes:183]
Our effective tax rate on income before tax for the fiscal years was lower than the United States federal statutory rate of 35% due to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate is lower, favorable recognition of the U.S. federal research tax credit and release of tax reserves as a result of the expiration of statutes of limitations in certain non-U.S. jurisdictions for which we had not previously recognized related tax benefits.

[0001045810-15-000036:notes:184]
As of January 25, 2015 and January 26, 2014 we had a valuation allowance of  $261.0 million and $244.5 million, respectively,  related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-15-000036:notes:185]
Our deferred tax assets do not include the excess tax benefit related to stock-based compensation that are a component of our federal and state net operating loss and research tax credit carryforwards in the amount of $411.9 million as of January 25, 2015. Consistent with prior years, the excess tax benefit reflected in our net operating loss and research tax credit carryforwards will be accounted for as a credit to shareholders' equity, if and when realized.

[0001045810-15-000036:notes:186]
As of January 25, 2015, we had federal, state and foreign net operating loss carryforwards of $521.5 million, $667.2 million and $332.6 million, respectively. The federal and state carryforwards will expire beginning in fiscal year 2022 and 2016, respectively. The foreign net operating loss carryforwards of $316.7 million may be carried forward indefinitely and the remainder of $15.9 million will begin to expire in fiscal year 2016. As of January 25, 2015, we had federal research tax credit carryforwards of $429.6 million that will begin to expire in fiscal year 2018. We have state research tax credit carryforwards of $411.7 million, of which $395.9 million is attributable to the State of California and may be carried over indefinitely, and $15.8 million is attributable to various other states and will expire beginning in fiscal year 2016. We have other state tax credit carryforwards of $3.0 million that will expire in fiscal year 2026 and foreign tax credit carryforwards of $18.4 million, which may be refunded in fiscal years 2016 through 2019 if not utilized. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, states, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-15-000036:notes:187]
As of January 25, 2015, U.S. federal and state income taxes have not been provided on approximately $2.27 billion of undistributed earnings of non-United States subsidiaries as such earnings are considered to be indefinitely reinvested. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in our foreign subsidiaries as the determination of such amount is not practicable.

[0001045810-15-000036:notes:188]
As of January 25, 2015, we had $253.7 million of gross unrecognized tax benefits, of which $228.7 million would affect our effective tax rate if recognized. However, approximately $45.3 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $228.7 million of unrecognized tax benefits as of January 25, 2015 consisted of $106.6 million recorded in non-current income taxes payable and $122.1 million reflected as a reduction to the related deferred tax assets.

[0001045810-15-000036:notes:189]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-15-000036:notes:190]
|  | January 25,2015 |  | January 26,2014 |  | January 27,2013 |
|  | (In thousands) |
| Balance at beginning of period | $ | 237,738 |  |  | $ | 220,543 |  |  | $ | 138,262 |  |
| Increases in tax positions for prior years | — |  |  | — |  |  | 18,800 |  |
| Decreases in tax positions for prior years | (871 | ) |  | (714 | ) |  | (304 | ) |
| Increases in tax positions for current year | 22,865 |  |  | 22,787 |  |  | 67,764 |  |
| Lapse in statute of limitations | (5,997 | ) |  | (4,878 | ) |  | (3,979 | ) |
| Balance at end of period | $ | 253,735 |  |  | $ | 237,738 |  |  | $ | 220,543 |  |

[0001045810-15-000036:notes:191]
We classify an unrecognized tax benefit as a current liability, or as a reduction of the deferred tax assets or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. Likewise, the amount is classified as a long-term liability, reduction of long-term deferred tax assets or amount refundable, if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-15-000036:notes:192]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 25, 2015, January 26, 2014, and January 27, 2013, we had accrued $14.4 million, $12.9 million and $11.3 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 25, 2015, non-current income taxes payable of $121.0 million consisted of unrecognized tax benefits of $106.6 million and the related interest and penalties of $14.4 million.

[0001045810-15-000036:notes:193]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 25, 2015, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-15-000036:notes:194]
We are subject to taxation by a number of taxing authorities both in the United States and throughout the world. As of January 25, 2015, the material tax jurisdictions that may be subject to examination include the United States, Taiwan, Canada, China, Germany, Hong Kong, France, Japan, and India for fiscal years 2003 through 2014. As of January 25, 2015, the material tax jurisdictions for which we are currently under examination include the state of California for fiscal years 2011 through 2012, and India, France and Germany for fiscal years 2003 through 2014.


## us-gaap:IncomeTaxPolicyTextBlock

[0001045810-15-000036:notes:195]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-15-000036:notes:196]
United States income tax has not been provided on a portion of earnings of our non-U.S. subsidiaries to the extent that such earnings are considered to be indefinitely reinvested.

[0001045810-15-000036:notes:197]
Our calculation of current and deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of current and deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-15-000036:notes:198]
As of January 25, 2015, we had a valuation allowance of $261.0 million  related to state and certain foreign deferred tax assets that management determined are not likely to be realized due, in part, to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes.  To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-15-000036:notes:199]
Our deferred tax assets do not include the excess tax benefit related to stock-based compensation that are a component of our federal and state net operating loss and research tax credit carryforwards in the amount of $411.9 million as of January 25, 2015. Consistent with prior years, the excess tax benefit reflected in our net operating loss and research tax credit carryforwards will be accounted for as a credit to shareholders' equity, if and when realized. In determining if and when excess tax benefits have been realized, we have elected to utilize the with-and-without approach with respect to such excess tax benefits. We have also elected to ignore the indirect tax effects of stock-based compensation deductions for financial and accounting reporting purposes, and specifically to recognize the full effect of the research tax credit in income from operations.

[0001045810-15-000036:notes:200]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. Please refer to Note 13 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-15-000036:notes:201]
Amortizable Intangible Assets

[0001045810-15-000036:notes:202]
The components of our amortizable intangible assets are as follows:

[0001045810-15-000036:notes:203]
|  | January 25, 2015 |  | January 26, 2014 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageUseful Life |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted Average Useful Life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Acquisition-related intangible assets | $ | 189,239 |  |  | $ | (134,062 | ) |  | $ | 55,177 |  |  | 6.8 |  | $ | 189,239 |  |  | $ | (114,104 | ) |  | $ | 75,135 |  |  | 6.5 |
| Patents and licensed technology | 448,873 |  |  | (282,336 | ) |  | 166,537 |  |  | 7.2 |  | 446,196 |  |  | (225,319 | ) |  | 220,877 |  |  | 7.2 |
| Total intangible assets | $ | 638,112 |  |  | $ | (416,398 | ) |  | $ | 221,714 |  |  |  |  | $ | 635,435 |  |  | $ | (339,423 | ) |  | $ | 296,012 |  |  |  |

[0001045810-15-000036:notes:204]
Amortization expense associated with intangible assets for fiscal years 2015, 2014 and 2013 was $77.0 million, $72.7 million and $68.4 million, respectively. Amortization expense increased compared to the prior year primarily due to the addition of licensed technology during fiscal year 2015. Future amortization expense for the net carrying amount of intangible assets at January 25, 2015 is estimated to be $71.9 million in fiscal year 2016, $63.6 million in fiscal year 2017, $49.1 million in fiscal year 2018, $20.4 million in fiscal year 2019, $11.9 million in fiscal year 2020 and $4.8 million in fiscal years subsequent to fiscal year 2020 until fully amortized.


## us-gaap:InventoryPolicyTextBlock

[0001045810-15-000036:notes:205]
Inventories

[0001045810-15-000036:notes:206]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.


## us-gaap:InvestmentPolicyTextBlock

[0001045810-15-000036:notes:207]
Fair Value of Financial Instruments

[0001045810-15-000036:notes:208]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 25, 2015 and January 26, 2014. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-15-000036:notes:209]
|  | January 25, 2015 |  | January 26, 2014 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In thousands) |
| Less than one year | $ | 1,570,233 |  |  | $ | 1,570,622 |  |  | $ | 1,883,132 |  |  | $ | 1,883,753 |  |
| Due in 1 - 5 years | 2,719,852 |  |  | 2,725,945 |  |  | 2,114,289 |  |  | 2,117,387 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 122,893 |  |  | 124,828 |  |  | 90,472 |  |  | 91,508 |  |
| Total | $ | 4,412,978 |  |  | $ | 4,421,395 |  |  | $ | 4,087,893 |  |  | $ | 4,092,648 |  |


## us-gaap:LeasePolicyTextBlock

[0001045810-15-000036:notes:210]
Rent Expense

[0001045810-15-000036:notes:211]
We recognize rent expense on a straight-line basis over the lease period and accrue for rent expense incurred, but not paid.


## us-gaap:LegalCostsPolicyTextBlock

[0001045810-15-000036:notes:212]
Litigation, Investigation and Settlement Costs

[0001045810-15-000036:notes:213]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-15-000036:notes:214]
Marketable Securities

[0001045810-15-000036:notes:215]
All of the cash equivalents and marketable securities are classified as “available-for-sale” securities. Investments in both fixed and floating rate interest earning instruments carry a degree of interest rate risk. Fixed rate debt securities may have their market value adversely impacted due to a rise in interest rates, while floating rate securities may produce less income than expected if interest rates fall. Due in part to these factors, our future investment income may fall short of expectations due to changes in interest rates or if the decline in fair value of our publicly traded debt or equity investments is judged to be other-than-temporary. We may suffer losses in principal if we are forced to sell securities that decline in market value due to changes in interest rates. However, because any debt securities we hold are classified as “available-for-sale,” no gains or losses are realized in our consolidated statement of income due to changes in interest rates unless such securities are sold prior to maturity or unless declines in market values are determined to be other-than-temporary. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income, a component of shareholders’ equity, net of tax.

[0001045810-15-000036:notes:216]
The following is a summary of cash equivalents and marketable securities at January 25, 2015 and January 26, 2014:

[0001045810-15-000036:notes:217]
We performed an impairment review of our investment portfolio as of January 25, 2015. Factors considered included general market conditions, the duration and extent to which fair value is below cost, and our intent and ability to hold an investment for a sufficient period of time to allow for recovery in value. We also consider specific adverse conditions related to the financial health of and business outlook for an investee, including industry and sector performance, changes in technology, operational and financing cash flow factors, and changes in an investee’s credit rating. Investments that we identify as having an indicator of impairment are subject to further analysis to determine if the investment was other than temporarily impaired. Based on our quarterly impairment review and having considered the guidance in the relevant accounting literature, we concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio of available for sale investments as of January 25, 2015.

[0001045810-15-000036:notes:218]
As of January 25, 2015, we had nine investments that were in an unrealized loss position with total unrealized losses amounting to $2.4 million and with a duration of less than one year. The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at January 25, 2015 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-15-000036:notes:219]
Net realized gains were $0.1 million, $2.4 million and $0.5 million for fiscal years 2015, 2014, and 2013, respectively.  As of January 25, 2015, we had a net unrealized gain of $8.4 million, which was comprised of gross unrealized gains of $11.0 million, offset by $2.6 million of gross unrealized losses. As of January 26, 2014, we had a net unrealized gain of $4.8 million, which was comprised of gross unrealized gains of $7.2 million, offset by $2.4 million of gross unrealized losses.

[0001045810-15-000036:notes:220]
The amortized cost and estimated fair value of cash equivalents and marketable securities which are primarily debt instruments are classified as available-for-sale at January 25, 2015 and January 26, 2014 and are shown below by contractual maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-15-000036:notes:221]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000036:notes:222]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. Early adoption is not permitted. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-15-000036:notes:223]
Employee Retirement Plans

[0001045810-15-000036:notes:224]
We have a 401(k) Retirement Plan covering substantially all of our United States employees. Under the plan, participating employees may defer up to 100% of their pre-tax earnings, subject to the Internal Revenue Service annual contribution limits. Effective January 2013, we began matching a portion of the employee contributions. Our contribution expense in fiscal years 2015 and 2014 was $5.8 million and $5.1 million, respectively. We also have defined contribution retirement plans outside of the United States to which we contributed $19.7 million, $16.2 million and $16.7 million for fiscal years 2015, 2014 and 2013, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001045810-15-000036:notes:225]
Property and Equipment

[0001045810-15-000036:notes:226]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to twenty five years. Depreciation expense includes the amortization of assets recorded under capital leases. Leasehold improvements and assets recorded under capital leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001045810-15-000036:notes:227]
Quarterly Summary (Unaudited)

[0001045810-15-000036:notes:228]
The following table sets forth our unaudited consolidated financial results, for the last eight fiscal quarters:

[0001045810-15-000036:notes:229]
|  | Fiscal Year 2015Quarters Ended |
|  | January 25, 2015 |  | October 26, 2014 |  | July 27,2014 |  | April 27, 2014 |
|  | (In thousands, except per share data) |
| Statement of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 1,250,514 |  |  | $ | 1,225,382 |  |  | $ | 1,102,824 |  |  | $ | 1,102,787 |  |
| Cost of revenue | $ | 550,911 |  |  | $ | 548,684 |  |  | $ | 483,850 |  |  | $ | 498,585 |  |
| Gross profit | $ | 699,603 |  |  | $ | 676,698 |  |  | $ | 618,974 |  |  | $ | 604,202 |  |
| Net income | $ | 193,128 |  |  | $ | 172,967 |  |  | $ | 127,976 |  |  | $ | 136,516 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.32 |  |  | $ | 0.23 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.31 |  |  | $ | 0.22 |  |  | $ | 0.24 |  |

[0001045810-15-000036:notes:230]
|  | Fiscal Year 2014Quarters Ended |
|  | January 26, 2014 |  | October 27, 2013 |  | July 28,2013 |  | April 28, 2013 |
|  | (In thousands, except per share data) |
| Statement of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 1,144,218 |  |  | $ | 1,053,967 |  |  | $ | 977,238 |  |  | $ | 954,739 |  |
| Cost of revenue | $ | 524,976 |  |  | $ | 469,552 |  |  | $ | 431,700 |  |  | $ | 436,171 |  |
| Gross profit | $ | 619,242 |  |  | $ | 584,415 |  |  | $ | 545,538 |  |  | $ | 518,568 |  |
| Net income | $ | 146,917 |  |  | $ | 118,734 |  |  | $ | 96,448 |  |  | $ | 77,891 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.26 |  |  | $ | 0.20 |  |  | $ | 0.16 |  |  | $ | 0.13 |  |
| Diluted | $ | 0.25 |  |  | $ | 0.20 |  |  | $ | 0.16 |  |  | $ | 0.13 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001045810-15-000036:notes:231]
Accounts Receivable

[0001045810-15-000036:notes:232]
We maintain an allowance for doubtful accounts receivable for estimated losses resulting from the inability of our customers to make required payments. We determine this allowance, which consists of an amount identified for specific customer issues as well as an amount based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001045810-15-000036:notes:233]
Revenue Recognition

[0001045810-15-000036:notes:234]
Product Revenue

[0001045810-15-000036:notes:235]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured. For most sales, we use a binding purchase order and in certain cases we use a contractual agreement as evidence of an arrangement. We consider delivery to occur upon shipment provided title and risk of loss have passed to the customer. At the point of sale, we assess whether the arrangement fee is fixed or determinable and whether collection is reasonably assured. If we determine that collection of a fee is not reasonably assured, we defer the fee and recognize revenue at the time collection becomes reasonably assured, which is generally upon receipt of payment.

[0001045810-15-000036:notes:236]
For sales to certain distributors with rights of return for which the level of returns cannot be reasonably estimated, our policy is to defer recognition of revenue and related cost of revenue until the distributors resell the product  and, in some cases, when customer return rights lapse.

[0001045810-15-000036:notes:237]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Unclaimed rebates are reversed to revenue.

[0001045810-15-000036:notes:238]
Our customer programs also include marketing development funds, or MDFs.  MDFs represent monies paid to retailers, system builders, original equipment manufacturers, or OEMs, distributors, add-in card partners and other channel partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF programs.

[0001045810-15-000036:notes:239]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-15-000036:notes:240]
License and Development Revenue

[0001045810-15-000036:notes:241]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual direct labor hours incurred to date as a percentage of the estimated total direct labor hours required to complete the project. A provision for estimated losses on contracts is made in the period in which the loss becomes probable and can be reasonably estimated. Costs incurred in advance of revenue recognized are recorded as deferred costs on uncompleted contracts. If the amount billed exceeds the amount of revenue recognized, the excess amount is recorded as deferred revenue.

[0001045810-15-000036:notes:242]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-15-000036:notes:243]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties.  We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.

[0001045810-15-000036:notes:244]
Research and Development Expense

[0001045810-15-000036:notes:245]
Research and development expense includes the conceptual formulation, design, and testing of product alternatives, construction of prototypes, and operation of pilot plants  Research and development costs are charged to expense as incurred.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001045810-15-000036:notes:246]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
| Revenue: |  |  |  |  |  |
| Customer A | 11 | % |  | 11 | % |  | 13 | % |
| Customer B | 9 | % |  | 10 | % |  | 9 | % |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001045810-15-000036:notes:247]
|  | Year Ended |
|  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
| Revenue: | (In thousands) |
| Taiwan | $ | 1,594,435 |  |  | $ | 1,321,503 |  |  | $ | 1,356,838 |  |
| China | 922,121 |  |  | 793,790 |  |  | 780,493 |  |
| United States | 790,614 |  |  | 726,830 |  |  | 799,430 |  |
| Other Asia Pacific | 637,029 |  |  | 675,339 |  |  | 783,573 |  |
| Europe | 368,921 |  |  | 295,160 |  |  | 263,488 |  |
| Other Americas | 368,387 |  |  | 317,540 |  |  | 296,337 |  |
| Total revenue | $ | 4,681,507 |  |  | $ | 4,130,162 |  |  | $ | 4,280,159 |  |

[0001045810-15-000036:notes:248]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and deposits and other assets, and exclude goodwill and intangible assets.

[0001045810-15-000036:notes:249]
|  | January 25, 2015 |  | January 26, 2014 |
| Long-lived assets: | (In thousands) |
| United States | $ | 467,277 |  |  | $ | 522,461 |  |
| Taiwan | 52,176 |  |  | 51,993 |  |
| Europe | 51,521 |  |  | 50,677 |  |
| India | 48,544 |  |  | 31,456 |  |
| China | 28,073 |  |  | 29,313 |  |
| Other Asia Pacific | 587 |  |  | 1,092 |  |
| Total long-lived assets | $ | 648,178 |  |  | $ | 686,992 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-15-000036:notes:250]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In thousands) |
| Year Ended January 25, 2015: |  |  |  |  |  |  |  |
| Revenue | $ | 3,838,906 |  |  | $ | 578,601 |  |  | $ | 264,000 |  |  | $ | 4,681,507 |  |
| Depreciation and amortization expense | $ | 116,683 |  |  | $ | 57,282 |  |  | $ | 46,160 |  |  | $ | 220,125 |  |
| Operating income (loss) | $ | 1,113,350 |  |  | $ | (254,435 | ) |  | $ | (99,926 | ) |  | $ | 758,989 |  |
| Year Ended January 26, 2014: |  |  |  |  |  |  |  |
| Revenue | $ | 3,468,144 |  |  | $ | 398,018 |  |  | $ | 264,000 |  |  | $ | 4,130,162 |  |
| Depreciation and amortization expense | $ | 146,571 |  |  | $ | 49,839 |  |  | $ | 42,738 |  |  | $ | 239,148 |  |
| Operating income (loss) | $ | 834,763 |  |  | $ | (268,068 | ) |  | $ | (70,468 | ) |  | $ | 496,227 |  |
| Year Ended January 27, 2013: |  |  |  |  |  |  |  |
| Revenue | $ | 3,251,712 |  |  | $ | 764,447 |  |  | $ | 264,000 |  |  | $ | 4,280,159 |  |
| Depreciation and amortization expense | $ | 143,262 |  |  | $ | 40,793 |  |  | $ | 42,180 |  |  | $ | 226,235 |  |
| Operating income (loss) | $ | 694,338 |  |  | $ | 40,508 |  |  | $ | (86,607 | ) |  | $ | 648,239 |  |

[0001045810-15-000036:notes:251]
|  |  | Year Ended |
|  |  | January 25, 2015 |  | January 26, 2014 |  | January 27, 2013 |
|  |  | (In thousands) |
| Reconciling items included in "All Other" category: |  |  |  |  |
| Revenue not allocated to reporting segments |  | $ | 264,000 |  |  | $ | 264,000 |  |  | $ | 264,000 |  |
| Unallocated corporate operating expenses and other expenses |  | (168,730 | ) |  | (166,483 | ) |  | (157,680 | ) |
| Stock-based compensation |  | (157,841 | ) |  | (136,295 | ) |  | (136,662 | ) |
| Acquisition-related costs, net |  | (37,355 | ) |  | (31,652 | ) |  | (36,138 | ) |
| Other non-recurring expenses and benefits |  | — |  |  | (38 | ) |  | (20,127 | ) |
| Total |  | $ | (99,926 | ) |  | $ | (70,468 | ) |  | $ | (86,607 | ) |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-15-000036:notes:252]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-15-000036:notes:253]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In thousands) |
| Year ended January 25, 2015 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 848 |  |  | $ | 2,837 |  | (1) | $ | (793 | ) | (1) | $ | 2,892 |  |
| Sales return allowance |  | $ | 14,111 |  |  | $ | 12,427 |  | (2) | $ | (12,447 | ) | (4) | $ | 14,091 |  |
| Deferred tax valuation allowance |  | $ | 244,487 |  |  | $ | 16,498 |  | (3) | $ | — |  |  | $ | 260,985 |  |
| Year ended January 26, 2014 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,804 |  |  | $ | 309 |  | (1) | $ | (1,265 | ) | (1) | $ | 848 |  |
| Sales return allowance |  | $ | 14,790 |  |  | $ | 15,881 |  | (2) | $ | (16,560 | ) | (4) | $ | 14,111 |  |
| Deferred tax valuation allowance |  | $ | 224,774 |  |  | $ | 19,713 |  | (3) | $ | — |  |  | $ | 244,487 |  |
| Year ended January 27, 2013 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 973 |  |  | $ | 1,139 |  | (1) | $ | (308 | ) | (1) | $ | 1,804 |  |
| Sales return allowance |  | $ | 13,881 |  |  | $ | 16,533 |  | (2) | $ | (15,624 | ) | (4) | $ | 14,790 |  |
| Deferred tax valuation allowance |  | $ | 212,285 |  |  | $ | 12,489 |  | (3) | $ | — |  |  | $ | 224,774 |  |

[0001045810-15-000036:notes:254]
(1)  Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end.

[0001045810-15-000036:notes:255]
(2)  Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue.

[0001045810-15-000036:notes:256]
(3)  Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions.

[0001045810-15-000036:notes:257]
(4)  Represents allowance for sales returns written off.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-15-000036:notes:258]
Segment Information

[0001045810-15-000036:notes:259]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance.  Our operating segments are equivalent to our reportable segments.

[0001045810-15-000036:notes:260]
We report our business in two primary reporting segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-15-000036:notes:261]
Our GPU product brands aimed at specialized markets include GeForce for gamers; Quadro for designers; Tesla for researchers, deep learning and big-data analysts; and GRID for cloud-based visual computing users.

[0001045810-15-000036:notes:262]
We also integrate our GPUs into tiny mobile chips called system-on-a-chip (SOC) processors, which power tablets, and automotive infotainment and safety systems. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs with audio, video and input/output capabilities. They can also be integrated with baseband processors to add voice and data communication. Tegra conserves power while delivering state-of-the-art graphics and multimedia processing.

[0001045810-15-000036:notes:263]
We have a single unifying architecture for our GPU and Tegra Processors. This architecture unification leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reporting segments, our CODM assigns 100% of those expenses to the reporting segment that benefits the most. The revenue and cost of revenue of the reporting segments was not affected, and comparative periods presented below reflect the impact of this change.

[0001045810-15-000036:notes:264]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-15-000036:notes:265]
Our CODM does not review any information regarding total assets on a reporting segment basis. Reporting segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for NVIDIA as a whole. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-15-000036:notes:266]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following tables summarize information pertaining to our revenue from customers based on invoicing address in different geographic regions:

[0001045810-15-000036:notes:267]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-15-000036:notes:268]
Revenue from customer A was attributable to both the GPU and Tegra Processor businesses, while revenue from customer B was attributable to the GPU business.

[0001045810-15-000036:notes:269]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-15-000036:notes:270]
Organization and Summary of Significant Accounting Policies

[0001045810-15-000036:notes:271]
Our Company

[0001045810-15-000036:notes:272]
NVIDIA is dedicated to advancing visual computing. We enable individuals to interact with digital ideas, data and entertainment with an ease and efficiency unmatched by any other communication medium.

[0001045810-15-000036:notes:273]
Our two reporting segments - GPU and Tegra Processor - are based on a single underlying graphics architecture.

[0001045810-15-000036:notes:274]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-15-000036:notes:275]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries, except where it is made clear that the term means only the parent company.

[0001045810-15-000036:notes:276]
Fiscal Year

[0001045810-15-000036:notes:277]
We operate on a 52- or a 53-week year, ending on the last Sunday in January. Fiscal years 2015, 2014 and 2013 were 52-week years.

[0001045810-15-000036:notes:278]
Reclassifications

[0001045810-15-000036:notes:279]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-15-000036:notes:280]
Use of Estimates

[0001045810-15-000036:notes:281]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States, or U.S. GAAP, requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, inventories, income taxes, goodwill, cash equivalents and marketable securities, stock-based compensation, and litigation, investigation and settlement costs and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-15-000036:notes:282]
Marketable securities consist primarily of highly liquid investments with maturities of greater than three months when purchased. We generally classify our marketable securities at the date of acquisition as available-for-sale. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income, a component of shareholders’ equity, net of tax. The fair value of interest-bearing securities includes accrued interest. Any unrealized losses which are considered to be other-than-temporary impairments are recorded in the other income and expense section of our consolidated statements of income. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income and expense section of our consolidated statements of income.

[0001045810-15-000036:notes:283]
All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is not more likely than not that we will not be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings while loss related to all other factors is recorded as other comprehensive income.

[0001045810-15-000036:notes:284]
Concentration of Credit Risk

[0001045810-15-000036:notes:285]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, accounts receivable and the note hedge. Our investment policy requires the purchase of high grade investment securities, the diversification of asset type and includes certain limits on our portfolio duration. All marketable securities are held in our name, managed by several investment managers and held by one major financial institution under a custodial arrangement. Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 30% of our accounts receivable balance from two customers at January 25, 2015 and approximately 23% of our accounts receivable balance from one customer at January 26, 2014. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-15-000036:notes:286]
Shareholders’ Equity

[0001045810-15-000036:notes:287]
Share Repurchase Program

[0001045810-15-000036:notes:288]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. Most recently, in November 2013, the Board extended the previously authorized repurchase program through January 2016 and authorized an additional $1.00 billion for an aggregate of $3.70 billion under the repurchase program.

[0001045810-15-000036:notes:289]
During fiscal year 2015, we repurchased a total of 44.4 million shares of our common stock for $813.6 million and paid $186.5 million in cash dividends - equivalent to $0.085 per share on a quarterly basis, or $0.34 per share on an annual basis - to our common shareholders. As a result, we returned $1.0 billion to shareholders during fiscal year 2015 in the form of share repurchases and dividend payments.

[0001045810-15-000036:notes:290]
Through the end of fiscal year 2015, we have repurchased an aggregate of 205.6 million shares under our share repurchase program for a total cost of $3,265.2 million. All shares delivered from these repurchases have been placed into treasury stock. As of January 25, 2015, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $434.8 million through January 2016.

[0001045810-15-000036:notes:291]
On November 6, 2014, we announced our intention to return approximately $600.0 million to our shareholders in fiscal year 2016 through a combination of share repurchases and cash dividends. On February 11, 2015, we declared that we would pay our next quarterly cash dividend of $0.085 per share on March 19, 2015, to all shareholders of record on February 26, 2015.

[0001045810-15-000036:notes:292]
In addition to our Board authorized share repurchases, we withhold common stock shares associated with net share settlements to cover tax withholding obligations upon the vesting of RSU and PSU awards under our equity incentive program. During fiscal year 2015, we withheld approximately 2.3 million shares at a total cost of $43.7 million through net share settlements. Please refer to Note 2 of these Notes to the Consolidated Financial Statements for further information regarding stock-based compensation related to equity awards granted under our equity incentive programs.

[0001045810-15-000036:notes:293]
Convertible Preferred Stock

[0001045810-15-000036:notes:294]
As of January 25, 2015 and January 26, 2014, there were no shares of preferred stock outstanding.
