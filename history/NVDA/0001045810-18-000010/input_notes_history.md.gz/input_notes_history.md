# NVDA note change history — 0001045810-17-000123 → 0001045810-17-000172


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-11-21):
[0001045810-17-000172:note_history:1]
In November 2017, subsequent to the end of the third quarter of fiscal year 2018, we exercised the option to terminate the off-balance sheet, build-to-suit operating lease financing arrangement related to our new Santa Clara campus building. In the fourth quarter of fiscal year 2018, we expect to refinance and purchase the property for approximately $350 million.

- changed (2017-11-21):
[0001045810-17-000172:note_history:2]
On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. On June 12, 2017, NVIDIA was notified that the nullity actions against EP1428225 and DE 1020066043668 were served on Polaris and that Polaris has filed a formal response opposing each nullity complaint. On July 14, 2017, the German Patent Court acknowledged receipt of a nullity action filed by NVIDIA challenging the validity of DE 10223167. On September 13, 2017, NVIDIA was notified that the nullity action against DE10223167 was served on Polaris. Polaris has not yet responded to this action.
  (was, 2017-08-23, similarity 0.8271):
[0001045810-17-000123:note_history:2]
On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. On June 12, 2017, NVIDIA was notified that the nullity actions against EP1428225 and DE 1020066043668 were served on Polaris and that Polaris has filed a formal response opposing each nullity complaint. On July 14, 2017, the German Patent Court acknowledged receipt of a nullity action filed by NVIDIA challenging the validity of DE 10223167. Polaris has not yet responded to this action.

- changed (2017-11-21):
[0001045810-17-000172:note_history:3]
While there can be no assurance of favorable outcomes, we believe the claims made by the other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 29, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2017-08-23, similarity 0.9932):
[0001045810-17-000123:note_history:3]
While there can be no assurance of favorable outcomes, we believe the claims made by the other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 30, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2017-11-21):
[0001045810-17-000123:note_history:4]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the third quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

- removed (2017-11-21):
[0001045810-17-000123:note_history:5]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring in December 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

- removed (2017-11-21):
[0001045810-17-000123:note_history:6]
We have been overseeing the construction of the headquarters building. The banks committed to fund up to $380 million of costs relating to construction. Advances have been made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest is capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

- removed (2017-11-21):
[0001045810-17-000123:note_history:7]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

- removed (2017-11-21):
[0001045810-17-000123:note_history:8]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to the financial covenant to maintain a maximum total leverage ratio not to exceed 3.5 to 1.0. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0001045810-17-000172:note_history:9]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The third quarter of fiscal years 2018 and 2017 were both 13-week quarters.
  (was, 2017-08-23, similarity 0.9757):
[0001045810-17-000123:note_history:9]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The second quarter of fiscal years 2018 and 2017 were both 13-week quarters.

- added (2017-11-21):
[0001045810-17-000172:note_history:10]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. Most prominent among the amendments is the requirement for changes in the fair value of our equity investments, with certain exceptions, to be recognized through net income rather than other comprehensive income. The update will be effective for us beginning in our first quarter of fiscal year 2019. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.

- added (2017-11-21):
[0001045810-17-000172:note_history:11]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. Given the scope of work required to implement the recognition and disclosure requirements under the new guidance, we have made progress in and continue to assess changes in policies, processes, systems and controls necessary to meet the additional requirements of the guidance. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.

- removed (2017-11-21):
[0001045810-17-000123:note_history:12]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-11-21):
[0001045810-17-000172:note_history:13]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 24 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (1 | ) |  | (31 | ) |
| Net carrying amount | $ | 23 |  |  | $ | 796 |  |

- changed (2017-11-21):
[0001045810-17-000172:note_history:14]
(1) As of October 29, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.1 years.
  (was, 2017-08-23, similarity 0.9507):
[0001045810-17-000123:note_history:14]
(1) As of July 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.3 years.

- changed (2017-11-21):
[0001045810-17-000172:note_history:15]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 10 |  |
| Amortization of debt discount |  | — |  |  | 5 |  |  | 2 |  |  | 20 |  |
| Total interest expense related to Convertible Notes |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 30 |  |
  (was, 2017-08-23, similarity 0.7839):
[0001045810-17-000123:note_history:15]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 8 |  |
| Amortization of debt discount |  | 1 |  |  | 7 |  |  | 2 |  |  | 14 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | 22 |  |

- removed (2017-11-21):
[0001045810-17-000123:note_history:16]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 86 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (2 | ) |  | (31 | ) |
| Net carrying amount | $ | 84 |  |  | $ | 796 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0001045810-17-000172:note_history:17]
During the third quarter of fiscal year 2018, we paid cash to settle an aggregate of $62 million in principal amount of the Convertible Notes and had $24 million in principal amount outstanding as of October 29, 2017. We also issued 3 million shares of our common stock for the excess conversion value and recognized a loss of $1 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $201.86 on the last trading day of the third quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of October 29, 2017 exceeded their principal amount by approximately $217 million. As of October 29, 2017, the conversion rate was 49.8977 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0410 per share of common stock).
  (was, 2017-08-23, similarity 0.6124):
[0001045810-17-000123:note_history:17]
During the second quarter of fiscal year 2018, we paid cash to settle an aggregate of $136 million in principal amount of the Convertible Notes and had $86 million in principal amount outstanding as of July 30, 2017. We also issued 5 million shares of our common stock for the excess conversion value and recognized a loss of $3 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $164.39 on the last trading day of the second quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of July 30, 2017 exceeded their principal amount by approximately $619 million. As of July 30, 2017, the conversion rate was 49.8804 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0480 per share of common stock).

- changed (2017-11-21):
[0001045810-17-000172:note_history:18]
Through the third quarter of fiscal year 2018, we settled an aggregate of $1.48 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $8 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.
  (was, 2017-08-23, similarity 0.9832):
[0001045810-17-000123:note_history:18]
Through the second quarter of fiscal year 2018, we settled an aggregate of $1.41 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $62 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

- added (2017-11-21):
[0001045810-17-000172:note_history:19]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances, determined on a quarterly basis.  All outstanding Convertible Notes are convertible at the holders’ option through January 28, 2018.

- changed (2017-11-21):
[0001045810-17-000172:note_history:20]
As of October 29, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.
  (was, 2017-08-23, similarity 0.9832):
[0001045810-17-000123:note_history:20]
As of July 30, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

- added (2017-11-21):
[0001045810-17-000172:note_history:21]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 24 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (1 | ) |  | (31 | ) |
| Net carrying amount | $ | 23 |  |  | $ | 796 |  |

- changed (2017-11-21):
[0001045810-17-000172:note_history:22]
(1) As of October 29, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.1 years.
  (was, 2017-08-23, similarity 0.9507):
[0001045810-17-000123:note_history:22]
(1) As of July 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.3 years.

- changed (2017-11-21):
[0001045810-17-000172:note_history:23]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 10 |  |
| Amortization of debt discount |  | — |  |  | 5 |  |  | 2 |  |  | 20 |  |
| Total interest expense related to Convertible Notes |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 30 |  |
  (was, 2017-08-23, similarity 0.7839):
[0001045810-17-000123:note_history:23]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 8 |  |
| Amortization of debt discount |  | 1 |  |  | 7 |  |  | 2 |  |  | 14 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | 22 |  |

- added (2017-11-21):
[0001045810-17-000172:note_history:24]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. During the third quarter of fiscal year 2018, we had received 3 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $62 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $8 million in principal amount that is expected to settle during the fourth quarter of fiscal year 2018.

- changed (2017-11-21):
[0001045810-17-000172:note_history:25]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction. All outstanding Warrants were terminated by the second quarter of fiscal year 2018.
  (was, 2017-08-23, similarity 0.7906):
[0001045810-17-000123:note_history:25]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction.

- changed (2017-11-21):
[0001045810-17-000172:note_history:26]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.
  (was, 2017-08-23, similarity 0.9964):
[0001045810-17-000123:note_history:26]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026 (collectively, the Notes). Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

- changed (2017-11-21):
[0001045810-17-000172:note_history:27]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (15 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,985 |  |  | $ | 1,983 |  |
  (was, 2017-08-23, similarity 0.9849):
[0001045810-17-000123:note_history:27]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |

- removed (2017-11-21):
[0001045810-17-000123:note_history:28]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continue to be convertible at the holders’ option through October 29, 2017.

- removed (2017-11-21):
[0001045810-17-000123:note_history:29]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 86 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (2 | ) |  | (31 | ) |
| Net carrying amount | $ | 84 |  |  | $ | 796 |  |

- removed (2017-11-21):
[0001045810-17-000123:note_history:30]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.0480 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. During the second quarter of fiscal year 2018, we had received 5 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $136 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $62 million in principal amount that is expected to settle during the third quarter of fiscal year 2018.

- removed (2017-11-21):
[0001045810-17-000123:note_history:31]
In the fourth quarter of fiscal year 2017, we entered into an agreement to terminate  63 million Warrants and, in consideration, we delivered a total of 48 million shares of common stock to the counterparty bank. In the second quarter of fiscal year 2018, we entered into a second agreement to terminate the remaining 12 million Warrants outstanding and, in consideration, we delivered a total of 10 million shares of common stock to the counterparty bank.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0001045810-17-000172:note_history:32]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (15 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,985 |  |  | $ | 1,983 |  |
  (was, 2017-08-23, similarity 0.9849):
[0001045810-17-000123:note_history:32]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |
