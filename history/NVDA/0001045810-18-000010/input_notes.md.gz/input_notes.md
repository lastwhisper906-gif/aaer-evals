# NVDA notes — 0001045810-18-000010


## nvda:BalanceSheetComponentsTextBlock

[0001045810-18-000010:notes:1]
Balance Sheet Components

[0001045810-18-000010:notes:2]
Certain balance sheet components are as follows:

[0001045810-18-000010:notes:3]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 227 |  |  | $ | 252 |  |
| Work in-process | 192 |  |  | 176 |  |
| Finished goods | 377 |  |  | 366 |  |
| Total inventories | $ | 796 |  |  | $ | 794 |  |

[0001045810-18-000010:notes:4]
|  | January 28, 2018 |  | January 29, 2017 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Building | 348 |  |  | 13 |  |  | 25-30 (B) |
| Test equipment | 462 |  |  | 427 |  |  | 3-5 |
| Computer equipment | 285 |  |  | 188 |  |  | 3-5 |
| Leasehold improvements | 198 |  |  | 176 |  |  | (C) |
| Software and licenses | 88 |  |  | 63 |  |  | 3-5 |
| Office furniture and equipment | 79 |  |  | 49 |  |  | 5 |
| Capital leases | 28 |  |  | 28 |  |  | (C) |
| Construction in process | 31 |  |  | 29 |  |  | (D) |
| Total property and equipment, gross | 1,737 |  |  | 1,191 |  |  |  |
| Accumulated depreciation and amortization | (740 | ) |  | (670 | ) |  |  |
| Total property and equipment, net | $ | 997 |  |  | $ | 521 |  |  |  |

[0001045810-18-000010:notes:5]
| (A) | Land is a non-depreciable asset. |

[0001045810-18-000010:notes:6]
| (B) | In January 2018, we terminated the off-balance sheet, build-to-suit operating lease financing arrangement related to our new Santa Clara campus building and exercised our option to purchase the property for $335 million, which has been recorded as Property and Equipment, net in our Consolidated Balance Sheet. |

[0001045810-18-000010:notes:7]
| (C) | Leasehold improvements and capital leases are amortized based on the lesser of either the asset’s estimated useful life or the remaining expected lease term. |

[0001045810-18-000010:notes:8]
| (D) | Construction in process represents assets that are not available for their intended use as of the balance sheet date. |

[0001045810-18-000010:notes:9]
Depreciation expense for fiscal years 2018, 2017, and 2016 was $144 million, $118 million, and $124 million, respectively.

[0001045810-18-000010:notes:10]
Accumulated amortization of leasehold improvements and capital leases was $178 million and $164 million as of January 28, 2018 and January 29, 2017, respectively. Amortization of leasehold improvements and capital leases is included in depreciation and amortization expense.

[0001045810-18-000010:notes:11]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Accrued and Other Current Liabilities: |  |  |  |
| Customer related liabilities (1) | $ | 181 |  |  | $ | 197 |  |
| Accrued payroll and related expenses | 172 |  |  | 137 |  |
| Deferred revenue (2) | 53 |  |  | 85 |  |
| Taxes payable | 33 |  |  | 4 |  |
| Coupon interest on debt obligations | 20 |  |  | 21 |  |
| Accrued royalties | 17 |  |  | 7 |  |
| Professional service fees | 15 |  |  | 13 |  |
| Warranty accrual (3) | 15 |  |  | 8 |  |
| Accrued restructuring and other charges | 7 |  |  | 13 |  |
| Leases payable | 5 |  |  | 4 |  |
| Contributions payable | 4 |  |  | 4 |  |
| Other | 20 |  |  | 14 |  |
| Total accrued and other current liabilities | $ | 542 |  |  | $ | 507 |  |

[0001045810-18-000010:notes:12]
| (1) | Customer related liabilities include accrued customer programs, such as rebates and marketing development funds. |

[0001045810-18-000010:notes:13]
| (2) | Deferred revenue primarily includes customer advances and deferrals related to license and service arrangements. |

[0001045810-18-000010:notes:14]
| (3) | Refer to Note 10 of these Notes to the Consolidated Financial Statements for a discussion regarding warranties. |

[0001045810-18-000010:notes:15]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Other Long-Term Liabilities: |  |  |  |
| Income tax payable (1) | $ | 559 |  |  | $ | 96 |  |
| Deferred income tax liability | 18 |  |  | 141 |  |
| Deferred revenue | 15 |  |  | 4 |  |
| Employee benefits liability | 12 |  |  | 10 |  |
| Contributions payable | 9 |  |  | 9 |  |
| Deferred rent | 9 |  |  | 6 |  |
| Licenses payable | 8 |  |  | 1 |  |
| Other | 2 |  |  | 10 |  |
| Total other long-term liabilities | $ | 632 |  |  | $ | 277 |  |

[0001045810-18-000010:notes:16]
| (1) | Represents the long-term portion of the one-time transition tax payable of $369 million, as well as unrecognized tax benefits of $175 million and related interest and penalties of $15 million. Refer to Note 13 of these Notes to the Consolidated Financial Statements for additional information. |


## nvda:ScheduleofRevenuebyMarketsTableTextBlock

[0001045810-18-000010:notes:17]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
| Revenue: | (In millions) |
| Gaming | $ | 5,513 |  |  | $ | 4,060 |  |  | $ | 2,818 |  |
| Professional Visualization | 934 |  |  | 835 |  |  | 750 |  |
| Datacenter | 1,932 |  |  | 830 |  |  | 339 |  |
| Automotive | 558 |  |  | 487 |  |  | 320 |  |
| OEM & IP | 777 |  |  | 698 |  |  | 783 |  |
| Total revenue | $ | 9,714 |  |  | $ | 6,910 |  |  | $ | 5,010 |  |


## nvda:ScheduleofaccountsreceivablepercentagesfromsignificantcustomerstextblockTableTextBlock

[0001045810-18-000010:notes:18]
|  | January 28, 2018 |  | January 29, 2017 |
| Accounts Receivable: |  |  |  |
| Customer A | 17 | % |  | 19 | % |
| Customer B | 11 | % |  | 1 | % |


## nvda:SummaryofequityawardsgrantedunderequityincentiveplansTableTextBlock

[0001045810-18-000010:notes:19]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 6 |  |  | 12 |  |  | 13 |  |
| Estimated total grant-date fair value | $ | 929 |  |  | $ | 591 |  |  | $ | 296 |  |
| Weighted average grant-date fair value (per share) | $ | 145.91 |  |  | $ | 50.57 |  |  | $ | 22.01 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 5 |  |  | 4 |  |  | 6 |  |
| Weighted average price (per share) | $ | 21.24 |  |  | $ | 18.51 |  |  | $ | 13.67 |  |
| Weighted average grant-date fair value (per share) | $ | 7.12 |  |  | $ | 5.80 |  |  | $ | 4.53 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-18-000010:notes:20]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 1,091 |  |  | $ | 627 |  |
| Estimated weighted average remaining amortization period | (In years) |
| RSUs, PSUs and market-based PSUs | 2.3 |  |  | 2.6 |  |
| ESPP | 0.7 |  |  | 0.6 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001045810-18-000010:notes:21]
Advertising Expenses

[0001045810-18-000010:notes:22]
We expense advertising costs in the period in which they are incurred. Advertising expenses for fiscal years 2018, 2017, and 2016 were $25 million, $17 million, and $30 million, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-18-000010:notes:23]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

[0001045810-18-000010:notes:24]
|  | January 29, 2017 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,397 |  |  | $ | 1 |  |  | $ | (10 | ) |  | $ | 2,388 |  |  | $ | 33 |  |  | $ | 2,355 |  |
| Debt securities of United States government agencies | 1,193 |  |  | — |  |  | (5 | ) |  | 1,188 |  |  | 27 |  |  | 1,161 |  |
| Debt securities issued by the United States Treasury | 852 |  |  | — |  |  | (2 | ) |  | 850 |  |  | 55 |  |  | 795 |  |
| Asset-backed securities | 490 |  |  | — |  |  | (1 | ) |  | 489 |  |  | — |  |  | 489 |  |
| Money market funds | 321 |  |  | — |  |  | — |  |  | 321 |  |  | 321 |  |  | — |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 161 |  |  | 2 |  |  | (1 | ) |  | 162 |  |  | — |  |  | 162 |  |
| Foreign government bonds | 70 |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Total | $ | 5,484 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 5,468 |  |  | $ | 436 |  |  | $ | 5,032 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001045810-18-000010:notes:25]
Cash and Cash Equivalents

[0001045810-18-000010:notes:26]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. As of January 28, 2018 and January 29, 2017, our cash and cash equivalents were $4.00 billion and $1.77 billion, respectively, including $3.79 billion and $321 million, respectively, invested in money market funds.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-18-000010:notes:27]
Commitments and Contingencies

[0001045810-18-000010:notes:28]
Inventory Purchase Obligations

[0001045810-18-000010:notes:29]
As of January 28, 2018, we had outstanding inventory purchase obligations totaling $1.33 billion.

[0001045810-18-000010:notes:30]
Capital Purchase Obligations

[0001045810-18-000010:notes:31]
As of January 28, 2018, we had outstanding capital purchase obligations totaling $135 million.

[0001045810-18-000010:notes:32]
Lease Obligations

[0001045810-18-000010:notes:33]
Our headquarters complex is located in Santa Clara, California and includes ten buildings that are leased properties. Future minimum lease payments related to headquarters operating leases total $63 million over the remaining terms of the leases, including predetermined rent escalations, and are included in the future minimum lease payment schedule below.

[0001045810-18-000010:notes:34]
Additionally, we have other domestic and international office facilities, including datacenter space, under operating leases expiring through fiscal year 2027. We also include non-cancelable obligations under certain software licensing arrangements as operating leases.

[0001045810-18-000010:notes:35]
Future minimum lease payments under our non-cancelable operating leases as of January 28, 2018, are as follows:

[0001045810-18-000010:notes:36]
|  | Future Minimum Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2019 | $ | 63 |  |
| 2020 | 53 |  |
| 2021 | 50 |  |
| 2022 | 44 |  |
| 2023 | 25 |  |
| 2024 and thereafter | 11 |  |
| Total | $ | 246 |  |

[0001045810-18-000010:notes:37]
Rent expense for fiscal years 2018, 2017, and 2016 was $54 million, $46 million, and $45 million, respectively.

[0001045810-18-000010:notes:38]
Operating Lease Financing Arrangement

[0001045810-18-000010:notes:39]
In January 2018, we exercised the option to terminate the off-balance sheet, build-to-suit operating lease financing arrangement related to our new Santa Clara campus building, and purchased the building for $335 million.

[0001045810-18-000010:notes:40]
Litigation

[0001045810-18-000010:notes:41]
Polaris Innovations Limited

[0001045810-18-000010:notes:42]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM: 6,532,505; 7,124,325; 7,405,993; 7,886,122; 8,161,344; and 8,207,976. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-18-000010:notes:43]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.

[0001045810-18-000010:notes:44]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for U.S. Patent Nos. 6,532,505; 7,405,993; 7,886,122; and 8,161,344. The USPTO declined to institute IPRs on U.S. Patent Nos. 7,124,325 and 8,207,976.

[0001045810-18-000010:notes:45]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

[0001045810-18-000010:notes:46]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM: European Patent No. EP1428225, and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.

[0001045810-18-000010:notes:47]
An oral hearing is scheduled for February 21, 2019.

[0001045810-18-000010:notes:48]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

[0001045810-18-000010:notes:49]
ZiiLabs 1 Patents Lawsuit

[0001045810-18-000010:notes:50]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs: 6,683,615; 7,050,061; 7,710,425; and 9,098,943, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd. a publicly traded Singapore company.  The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents.  On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

[0001045810-18-000010:notes:51]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. Patent No. 6,977,649.

[0001045810-18-000010:notes:52]
ZiiLabs 2 Patents Lawsuits

[0001045810-18-000010:notes:53]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. Patents: 6,181,355; 6,900,800; 8,144,156; and 8,643,659, or the ZiiLabs 2 Patents.  The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

[0001045810-18-000010:notes:54]
On December 29, 2017, ZiiLabs filed a request with the U.S. International Trade Commission, or USITC, to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same.  ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

[0001045810-18-000010:notes:55]
Accounting for Loss Contingencies

[0001045810-18-000010:notes:56]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of January 28, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001045810-18-000010:notes:57]
Product Warranties

[0001045810-18-000010:notes:58]
We generally offer a limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001045810-18-000010:notes:59]
Stock-based Compensation

[0001045810-18-000010:notes:60]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, we estimate forfeitures annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. If factors change, the compensation expense that we record under these accounting standards may differ significantly from what we have recorded in the current period.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001045810-18-000010:notes:61]
Comprehensive Income

[0001045810-18-000010:notes:62]
Comprehensive income consists of net income and other comprehensive income or loss. Other comprehensive income or loss components include unrealized gains or losses on available-for-sale securities and unrealized gains or losses on cash flow hedges.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-18-000010:notes:63]
Principles of Consolidation

[0001045810-18-000010:notes:64]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-18-000010:notes:65]
The following table presents the carrying value of the Convertible Notes:

[0001045810-18-000010:notes:66]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 15 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | — |  |  | (31 | ) |
| Net carrying amount | $ | 15 |  |  | $ | 796 |  |

[0001045810-18-000010:notes:67]
(1) As of January 28, 2018, the balance of unamortized debt discount was not significant and will be fully amortized in fiscal year 2019.

[0001045810-18-000010:notes:68]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

[0001045810-18-000010:notes:69]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Contractual coupon interest expense | $ | — |  |  | $ | 9 |  |  | $ | 15 |  |
| Amortization of debt discount | 2 |  |  | 24 |  |  | 29 |  |
| Total interest expense related to Convertible Notes | $ | 2 |  |  | $ | 33 |  |  | $ | 44 |  |


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001045810-18-000010:notes:70]
Restructuring and Other Charges

[0001045810-18-000010:notes:71]
Our restructuring and other charges include employee severance and related costs, the write-down of assets, and other exit costs. The severance and related costs include one-time termination benefits as well as certain statutory termination benefits or employee terminations under ongoing benefit arrangements. One-time termination benefits are recognized as a liability at estimated fair value when the approved plan of termination has been communicated to employees, unless employees must provide future service, in which case the benefits are recognized ratably over the future service period. Ongoing termination benefits arrangements are recognized as a liability at estimated fair value when the amount of such benefits becomes estimable and payment is probable. Any contract termination costs are recognized at estimated fair value when we terminate the contract in accordance with the contract terms. Other associated costs are recognized in the period the liability is incurred. Our operating expenses for fiscal year 2016 included $131 million of restructuring and other charges related to the wind-down of our Icera operations, which was comprised mainly of employee severance, facilities, and related costs. Restructuring charges were not significant for fiscal years 2018 and 2017.


## us-gaap:DebtDisclosureTextBlock

[0001045810-18-000010:notes:72]
Debt

[0001045810-18-000010:notes:73]
Long-Term Debt

[0001045810-18-000010:notes:74]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-18-000010:notes:75]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-18-000010:notes:76]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-18-000010:notes:77]
The carrying value of our long-term debt and the associated interest rates were as follows:

[0001045810-18-000010:notes:78]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | January 28, 2018 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.6 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (15 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,985 |  |  | $ | 1,983 |  |

[0001045810-18-000010:notes:79]
Convertible Debt

[0001045810-18-000010:notes:80]
1.00% Convertible Senior Notes Due 2018

[0001045810-18-000010:notes:81]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through January 28, 2018, we had settled an aggregate of $1.48 billion of the Convertible Notes. The Convertible Notes are unsecured, unsubordinated obligations of the Company paying interest in cash semi-annually at a rate of 1.00% per annum and will mature on December 1, 2018 unless previously repurchased or converted. Upon conversion, we pay cash up to the aggregate principal amount and pay or deliver cash, shares of our common stock or a combination thereof, at our election, of our conversion obligation in excess of the aggregate principal amount being converted.

[0001045810-18-000010:notes:82]
Holders may convert all or any portion of their Convertible Notes at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition has been met, all outstanding Convertible Notes are convertible at the holders’ option through April 29, 2018.

[0001045810-18-000010:notes:83]
During fiscal year 2018, we paid cash to settle $812 million in principal amount of the Convertible Notes and had $15 million in principal amount outstanding as of January 28, 2018. We also issued 33 million shares of our common stock for the excess conversion value and recognized a loss of $19 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $243.33 on the last trading day of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $174 million. As of January 28, 2018, the conversion rate was 49.9127 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0350 per share of common stock).

[0001045810-18-000010:notes:84]
We separately accounted for the liability and equity components of the Convertible Notes as our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

[0001045810-18-000010:notes:85]
As of January 28, 2018, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Consolidated Balance Sheet. The convertible debt conversion obligation as of January 28, 2018 was not significant.

[0001045810-18-000010:notes:86]
Note Hedges and Warrants

[0001045810-18-000010:notes:87]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges. The Note Hedges have an adjusted strike price of $20.0350 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through January 28, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.48 billion in principal amount of the Convertible Notes.

[0001045810-18-000010:notes:88]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants. In fiscal year 2017, we entered into an agreement to terminate 63 million warrants and delivered a total of 48 million shares of common stock. In fiscal year 2018, we entered into a second agreement to terminate the remaining 12 million warrants outstanding and delivered a total of 10 million shares of common stock. Therefore, no warrants were outstanding as of January 28, 2018.

[0001045810-18-000010:notes:89]
Revolving Credit Facility

[0001045810-18-000010:notes:90]
In fiscal year 2017, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of January 28, 2018, we had not borrowed any amounts and were in compliance with all related covenants under the Credit Agreement.

[0001045810-18-000010:notes:91]
Commercial Paper

[0001045810-18-000010:notes:92]
In December 2017, we established a commercial paper program to support general corporate purposes. Under the program, we can issue up to $575 million in commercial paper. As of January 28, 2018, there was no commercial paper outstanding.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-18-000010:notes:93]
Derivative Financial Instruments

[0001045810-18-000010:notes:94]
In fiscal year 2016, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new Santa Clara campus building. In January 2018, we terminated the operating lease financing arrangement and purchased the property. Concurrently, the related interest rate swap was terminated.

[0001045810-18-000010:notes:95]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of January 28, 2018 and January 29, 2017.

[0001045810-18-000010:notes:96]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-18-000010:notes:97]
The table below presents the notional value of our foreign currency forward contracts outstanding as of January 28, 2018 and January 29, 2017:

[0001045810-18-000010:notes:98]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 104 |  |  | $ | 67 |  |
| Not designated for hedge accounting | $ | 94 |  |  | $ | 32 |  |

[0001045810-18-000010:notes:99]
As of January 28, 2018, the maturities of the designated foreign currency forward contracts were three months or less. We expect to realize all gains and losses deferred into accumulated other comprehensive income or loss related to these foreign currency forward contracts within the next twelve months.

[0001045810-18-000010:notes:100]
During fiscal years 2018 and 2017, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-18-000010:notes:101]
Stock-Based Compensation

[0001045810-18-000010:notes:102]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-18-000010:notes:103]
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts capitalized as inventory, as follows:

[0001045810-18-000010:notes:104]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Cost of revenue | $ | 21 |  |  | $ | 15 |  |  | $ | 15 |  |
| Research and development | 219 |  |  | 134 |  |  | 115 |  |
| Sales, general and administrative | 151 |  |  | 98 |  |  | 74 |  |
| Total | $ | 391 |  |  | $ | 247 |  |  | $ | 204 |  |

[0001045810-18-000010:notes:105]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2018, 2017, and 2016.

[0001045810-18-000010:notes:106]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-18-000010:notes:107]
Beginning fiscal year 2015, we shifted away from granting stock options and toward granting RSUs, PSUs and market-based PSUs to reflect changing market trends for equity incentives at our peer companies. As of January 28, 2018, there were 5 million stock options outstanding and the amount of unvested stock options was not significant. The number of PSUs that will ultimately vest is contingent on the Company’s level of achievement versus the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year.

[0001045810-18-000010:notes:108]
Of the total fair value of equity awards, we estimated that the stock-based compensation expense related to the equity awards that are not expected to vest for fiscal years 2018, 2017, and 2016 was $156 million, $98 million, and $46 million, respectively.

[0001045810-18-000010:notes:109]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-18-000010:notes:110]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.5-2.0 |  | 0.5-2.0 |  | 0.5-2.0 |
| Risk-free interest rate | 0.8%-1.4% |  | 0.5%-0.9% |  | 0.1%-0.7% |
| Volatility | 40%-54% |  | 30%-39% |  | 24%-34% |
| Dividend yield | 0.3%-0.5% |  | 0.7%-1.4% |  | 1.5%-1.8% |

[0001045810-18-000010:notes:111]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-18-000010:notes:112]
Additionally, for employee stock option, RSU, PSU, and market-based PSU awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-18-000010:notes:113]
Equity Incentive Program

[0001045810-18-000010:notes:114]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans.

[0001045810-18-000010:notes:115]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-18-000010:notes:116]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, as most recently amended and restated, the 2007 Plan.

[0001045810-18-000010:notes:117]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock units, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. Up to 207 million shares of our common stock may be issued pursuant to stock awards granted under the 2007 Plan. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 28, 2018, there were 16 million shares available for future issuance.

[0001045810-18-000010:notes:118]
Stock options previously granted to employees, subject to certain exceptions, vest over a four year period, subject to continued service, with 25% vesting on the anniversary of the hire date in the case of new hires or the anniversary of the date of grant in the case of grants to existing employees and 6.25% vesting quarterly thereafter. These stock options generally expire ten years from the date of grant.

[0001045810-18-000010:notes:119]
Subject to certain exceptions, RSUs and PSUs granted to employees vest over a four year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and (i) for grants made prior to May 18, 2016, 12.5% vesting semi-annually thereafter, and (ii) for grants made on or after May 18, 2016, 6.25% vesting quarterly thereafter. Market-based PSUs vest 100% on approximately the three year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-18-000010:notes:120]
Unless terminated sooner, the 2007 Plan is scheduled to terminate on March 21, 2022. Our Board may suspend or terminate the 2007 Plan at any time. No awards may be granted under the 2007 Plan while the 2007 Plan is suspended or after it is terminated. The Board may also amend the 2007 Plan at any time. However, if legal, regulatory or listing requirements require shareholder approval, the amendment will not go into effect until the shareholders have approved the amendment.

[0001045810-18-000010:notes:121]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-18-000010:notes:122]
In 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, as most recently amended and restated, the 2012 Plan, as the successor to the 1998 Employee Stock Purchase Plan.

[0001045810-18-000010:notes:123]
Up to 75 million shares of our common stock may be issued pursuant to purchases under the 2012 Plan. As of January 28, 2018, we had issued 28 million shares and reserved 47 million shares for future issuance under the 2012 Plan.

[0001045810-18-000010:notes:124]
The 2012 Plan is intended to qualify as an “employee stock purchase plan” under Section 423 of the Internal Revenue Code. Under the current offerings adopted pursuant to the 2012 Plan, each offering period is approximately 24 months, which is generally divided into four purchase periods of six months.

[0001045810-18-000010:notes:125]
Employees are eligible to participate if they are employed by us or an affiliate of us as designated by the Board. Employees who participate in an offering may have up to 10% of their earnings withheld up to certain limitations and applied on specified dates determined by the Board to the purchase of shares of common stock. The Board may increase this percentage at its discretion, up to 15%. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the fair market value on each purchase date within the offering. Employees may end their participation in the 2012 Plan at any time during the offering period, and participation ends automatically on termination of employment with us. In each case, the employee’s contributions are refunded.

[0001045810-18-000010:notes:126]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-18-000010:notes:127]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
|  | (In millions, except years and per share data) |
| Balances, January 29, 2017 | 27 |  |  | $ | 32.84 |  |
| Granted (1)(2) | 6 |  |  | $ | 145.91 |  |
| Vested restricted stock | (11 | ) |  | $ | 28.80 |  |
| Canceled and forfeited | — |  |  | $ | — |  |
| Balances, January 28, 2018 | 22 |  |  | $ | 66.72 |  |
| Vested and expected to vest after January 28, 2018 | 18 |  |  | $ | 66.43 |  |

[0001045810-18-000010:notes:128]
| (1) | Includes PSUs that will be issued and eligible to vest based on the corporate financial performance maximum target level achieved for fiscal year 2018. |

[0001045810-18-000010:notes:129]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 0.1 million shares. |

[0001045810-18-000010:notes:130]
As of January 28, 2018 and January 29, 2017, there were 16 million and 22 million shares, respectively, of common stock reserved for future issuance under our equity incentive plans.

[0001045810-18-000010:notes:131]
The total intrinsic value of options exercised was $318 million, $246 million, and $75 million for fiscal years 2018, 2017, and 2016, respectively. Upon exercise of an option, we issue new shares of stock. The total fair value of options vested was $1 million, $8 million, and $17 million for fiscal years 2018, 2017, and 2016, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001045810-18-000010:notes:132]
Net Income Per Share

[0001045810-18-000010:notes:133]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to the Consolidated Financial Statements. The potentially dilutive shares resulting from the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted income per share when their inclusion is dilutive. However, unless actually exercised, the note hedges were not included in the calculation of diluted net income per share, as their pre-exercised effect would be anti-dilutive under the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001045810-18-000010:notes:134]
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-18-000010:notes:135]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 3,047 |  |  | $ | 1,666 |  |  | $ | 614 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 599 |  |  | 541 |  |  | 543 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |
| Equity awards | 24 |  |  | 26 |  |  | 13 |  |
| 1.00% Convertible Senior Notes | 5 |  |  | 44 |  |  | 13 |  |
| Warrants issued with the 1.00% Convertible Senior Notes | 4 |  |  | 38 |  |  | — |  |
| Diluted weighted average shares | 632 |  |  | 649 |  |  | 569 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 5.09 |  |  | $ | 3.08 |  |  | $ | 1.13 |  |
| Diluted (2) | $ | 4.82 |  |  | $ | 2.57 |  |  | $ | 1.08 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 4 |  |  | 8 |  |  | 10 |  |

[0001045810-18-000010:notes:136]
| (1) | Calculated as net income divided by basic weighted average shares. |

[0001045810-18-000010:notes:137]
| (2) | Calculated as net income divided by diluted weighted average shares. |

[0001045810-18-000010:notes:138]
The 1.00% Convertible Senior Notes, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0350 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share. As of January 28, 2018, there were no warrants outstanding.

[0001045810-18-000010:notes:139]
For fiscal year 2018, our average stock price was $158.35, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Convertible Notes and the Warrants to have a dilutive impact.

[0001045810-18-000010:notes:140]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transactions, or the Note Hedges, that we entered into concurrently with the issuance of the Convertible Notes, as its effect would be anti-dilutive. In the event of conversion of the Convertible Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Convertible Notes.

[0001045810-18-000010:notes:141]
Refer to Note 11 of these Notes to the Consolidated Financial Statements for additional discussion regarding the Convertible Notes, Note Hedges, and Warrants.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-18-000010:notes:142]
Fair Value of Financial Assets and Liabilities

[0001045810-18-000010:notes:143]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We classify securities within Level 1 when the fair value is obtained from real time quotes in active markets involving identical securities. We classify securities within Level 2 when pricing is obtained from real time quotes of similar securities in active markets or alternative pricing sources and models utilizing market observable inputs to determine fair value. There were no significant transfers between Levels 1 and 2 for fiscal year 2018. Level 3 assets are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances. We did not have any securities classified as Level 3 as of January 28, 2018.

[0001045810-18-000010:notes:144]
|  |  | Fair Value at |
|  | Pricing Category |  | January 28, 2018 |  | January 29, 2017 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 3,789 |  |  | $ | 321 |  |
| Corporate debt securities | Level 2 |  | $ | 1,295 |  |  | $ | 2,388 |  |
| Debt securities of U.S. government agencies | Level 2 |  | $ | 815 |  |  | $ | 1,188 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 573 |  |  | $ | 850 |  |
| Asset-backed securities | Level 2 |  | $ | 252 |  |  | $ | 489 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 130 |  |  | $ | 162 |  |
| Foreign government bonds | Level 2 |  | $ | 41 |  |  | $ | 70 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 189 |  |  | $ | 4,474 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 982 |  |  | $ | 975 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 986 |  |  | $ | 961 |  |
| Interest rate swap (2) | Level 2 |  | $ | — |  |  | $ | 2 |  |

[0001045810-18-000010:notes:145]
| (1) | These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 11 of these Notes to the Consolidated Financial Statements for additional information. |

[0001045810-18-000010:notes:146]
| (2) | In January 2018, we terminated the interest rate swap. Refer to Note 9 of these Notes to Consolidated Financial Statements for additional information. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001045810-18-000010:notes:147]
Foreign Currency Remeasurement

[0001045810-18-000010:notes:148]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in other income or expense in our Consolidated Statements of Income and to date have not been significant.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001045810-18-000010:notes:149]
Goodwill

[0001045810-18-000010:notes:150]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist.  For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-18-000010:notes:151]
For those reporting units where a significant change or event has occurred, where potential impairment indicators exist, or for which we have not performed a quantitative assessment recently, we perform a quantitative assessment to testing goodwill for impairment. It tests for possible impairment by applying a fair value-based test by weighting the results from the income approach and the market approach. Refer to Note 4 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-18-000010:notes:152]
The carrying amount of goodwill is from the following acquisitions:

[0001045810-18-000010:notes:153]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Icera | $ | 271 |  |  | $ | 271 |  |
| PortalPlayer | 105 |  |  | 105 |  |
| Mental Images | 59 |  |  | 59 |  |
| 3dfx | 50 |  |  | 50 |  |
| MediaQ | 35 |  |  | 35 |  |
| ULi | 31 |  |  | 31 |  |
| Other | 67 |  |  | 67 |  |
| Total goodwill | $ | 618 |  |  | $ | 618 |  |

[0001045810-18-000010:notes:154]
The amount of goodwill allocated to our GPU and Tegra Processor reporting units was $210 million and $408 million, respectively, as of both January 28, 2018 and January 29, 2017. Refer to Note 16 of these Notes to the Consolidated Financial Statements for further discussion regarding segments.

[0001045810-18-000010:notes:155]
We completed our annual impairment test during the fourth quarter of fiscal year 2018 and concluded that there was no impairment, as the fair value of our reporting units exceeded their carrying values. The fair value was determined by weighing the results from the income approach and the market approach.

[0001045810-18-000010:notes:156]
These income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business. When performing an income approach valuation, we incorporate the use of projected financial information and a discount rate that are developed using market participant based assumptions to our discounted cash flow model. Our estimates of discounted cash flow were based upon, among other things, certain assumptions about our expected future operating performance, such as revenue growth rates, operating margins, risk-adjusted discount rates, and future economic and market conditions. The market method of determining the fair value of our reporting units requires us to use judgment in the selection of appropriate market comparables.


## us-gaap:GuaranteesTextBlock

[0001045810-18-000010:notes:157]
Guarantees

[0001045810-18-000010:notes:158]
U.S. GAAP requires that upon issuance of a guarantee, the guarantor must recognize a liability for the fair value of the obligation it assumes under that guarantee. In addition, U.S. GAAP requires disclosures about the guarantees that an entity has issued, including a tabular reconciliation of the changes of the entity’s product warranty liabilities.

[0001045810-18-000010:notes:159]
Accrual for Product Warranty Liabilities

[0001045810-18-000010:notes:160]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-18-000010:notes:161]
The estimated product returns and estimated product warranty liabilities recorded in accrued and other current liabilities on our Consolidated Balance Sheets as of January 28, 2018 and January 29, 2017 are as follows:

[0001045810-18-000010:notes:162]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 8 |  |  | $ | 11 |  |
| Additions | 14 |  |  | 2 |  |
| Deductions | (7 | ) |  | (5 | ) |
| Balance at end of period | $ | 15 |  |  | $ | 8 |  |

[0001045810-18-000010:notes:163]
In connection with certain agreements that we have entered into in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001045810-18-000010:notes:164]
Long-Lived Assets

[0001045810-18-000010:notes:165]
Intangible assets primarily represent rights acquired under technology licenses, patents, acquired intellectual property, trademarks and customer relationships and are subject to an annual impairment test. We currently amortize our intangible assets with definitive lives over periods ranging from three to ten years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.

[0001045810-18-000010:notes:166]
Long-lived assets, such as property and equipment and intangible assets subject to amortization are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset, or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-18-000010:notes:167]
Income Taxes

[0001045810-18-000010:notes:168]
The income tax expense (benefit) applicable to income before income taxes consists of the following:

[0001045810-18-000010:notes:169]
|  | Year Ended |
|  | January 28,2018 |  | January 29,2017 |  | January 31,2016 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 464 |  |  | $ | 7 |  |  | $ | (43 | ) |
| State | 1 |  |  | 1 |  |  | 1 |  |
| Foreign | 43 |  |  | 34 |  |  | 25 |  |
| Total current | 508 |  |  | 42 |  |  | (17 | ) |
| Deferred taxes: |  |  |  |  |  |
| Federal | (376 | ) |  | 199 |  |  | 134 |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | 17 |  |  | (2 | ) |  | — |  |
| Total deferred | (359 | ) |  | 197 |  |  | 134 |  |
| Charge in lieu of taxes attributable to employer stock option plans | — |  |  | — |  |  | 12 |  |
| Income tax expense | $ | 149 |  |  | $ | 239 |  |  | $ | 129 |  |

[0001045810-18-000010:notes:170]
Income before income tax consists of the following:

[0001045810-18-000010:notes:171]
|  | Year Ended |
|  | January 28,2018 |  | January 29,2017 |  | January 31,2016 |
|  | (In millions) |
| Domestic (1) | $ | 1,600 |  |  | $ | 600 |  |  | $ | 129 |  |
| Foreign | 1,596 |  |  | 1,305 |  |  | 614 |  |
| Income before income tax | $ | 3,196 |  |  | $ | 1,905 |  |  | $ | 743 |  |

[0001045810-18-000010:notes:172]
| (1) | The increase in domestic income is primarily due to jurisdictional allocation of stock-based compensation charges. |

[0001045810-18-000010:notes:173]
The income tax expense differs from the amount computed by applying the blended U.S. federal statutory rate of 33.9% for fiscal year 2018 and U.S. federal statutory rate of 35% for fiscal years 2017 and 2016 to income before income taxes as follows:

[0001045810-18-000010:notes:174]
|  | Year Ended |
|  | January 28,2018 |  | January 29,2017 |  | January 31,2016 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 1,084 |  |  | $ | 667 |  |  | $ | 260 |  |
| Expense (benefit) resulting from: |  |  |  |  |  |
| State income taxes, net of federal tax effect | 10 |  |  | 4 |  |  | 1 |  |
| Foreign tax rate differential | (545 | ) |  | (315 | ) |  | (95 | ) |
| Stock-based compensation (1) | (181 | ) |  | (70 | ) |  | 13 |  |
| Tax Cuts and Jobs Act of 2017 (2) | (133 | ) |  | — |  |  | — |  |
| U.S. federal R&D tax credit | (87 | ) |  | (52 | ) |  | (38 | ) |
| Tax expense related to intercompany transaction | — |  |  | 10 |  |  | 10 |  |
| Restructuring and expiration of statute of limitations | — |  |  | — |  |  | (21 | ) |
| Other | 1 |  |  | (5 | ) |  | (1 | ) |
| Income tax expense | $ | 149 |  |  | $ | 239 |  |  | $ | 129 |  |

[0001045810-18-000010:notes:175]
| (1) | We adopted an accounting standard related to stock-based compensation effective February 1, 2016, which required the excess tax benefit to be reflected in our provision for income taxes rather than in additional paid-in-capital. The total related excess tax benefit recognized for fiscal year 2018 and 2017 was $197 million and $82 million, respectively. |

[0001045810-18-000010:notes:176]
| (2) | We recognized a provisional tax benefit of $133 million, which was included as a component of income tax expense. |

[0001045810-18-000010:notes:177]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-18-000010:notes:178]
|  | January 28,2018 |  | January 29,2017 |
|  | (In millions) |
| Deferred tax assets: |  |
| Net operating loss carryforwards | $ | 67 |  |  | $ | 199 |  |
| Accruals and reserves, not currently deductible for tax purposes | 24 |  |  | 40 |  |
| Property, equipment and intangible assets | 32 |  |  | 50 |  |
| Research and other tax credit carryforwards | 579 |  |  | 728 |  |
| Stock-based compensation | 24 |  |  | 34 |  |
| Convertible debt | — |  |  | 6 |  |
| Gross deferred tax assets | 726 |  |  | 1,057 |  |
| Less valuation allowance | (469 | ) |  | (353 | ) |
| Total deferred tax assets | 257 |  |  | 704 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (4 | ) |  | (11 | ) |
| Unremitted earnings of foreign subsidiaries | (26 | ) |  | (827 | ) |
| Gross deferred tax liabilities | (30 | ) |  | (838 | ) |
| Net deferred tax asset (liability) | $ | 227 |  |  | $ | (134 | ) |

[0001045810-18-000010:notes:179]
We recognized income tax expense of $149 million, $239 million, and $129 million for fiscal years 2018, 2017, and 2016, respectively. Our annual effective tax rate was 4.7%, 12.5%, and 17.3% for fiscal years 2018, 2017, and 2016, respectively.

[0001045810-18-000010:notes:180]
In December 2017, the TCJA was enacted into law. The TCJA significantly changes U.S. tax law, including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, a requirement for companies to pay a one-time transition tax on the earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign-source earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us in the fourth quarter of fiscal year 2018, while other provisions will impact us beginning in fiscal year 2019.

[0001045810-18-000010:notes:181]
The corporate tax reduction is effective as of January 1, 2018. Since we operate on a fiscal year rather than a calendar year, we are subject to transitional tax rules. As a result, our fiscal year 2018 federal statutory rate is a blended rate of 33.9%.  The change in the statutory tax rate from 35% to 33.9% for fiscal year 2018 did not have a significant impact on the effective tax rate.

[0001045810-18-000010:notes:182]
U.S. GAAP requires companies to recognize the effect of tax law changes in the period of enactment. However, the SEC also issued guidance that allows companies to record provisional amounts during a measurement period not to exceed one year. Accordingly, as of January 28, 2018, we recognized a provisional tax benefit of $133 million as a component of income tax expense, which is our reasonable estimate of the effects of the tax law changes on existing deferred tax balances and the calculation of the one-time transition tax.

[0001045810-18-000010:notes:183]
The one-time transition tax is based on the post-1986 earnings and profits, or E&P, of our foreign subsidiaries. We had previously accrued deferred taxes on a portion of these same earnings. We recorded a provisional one-time transition tax liability of $971 million and released the previously accrued deferred tax liabilities of $1.15 billion, resulting in a net decrease to income tax expense of $176 million.

[0001045810-18-000010:notes:184]
We have reasonably estimated, but not yet completed, the calculation of the total post-1986 E&P for our foreign subsidiaries. Our calculation of the transition tax may change with further analysis, additional guidance from the U.S. federal and state tax authorities and additional guidance for the associated income tax accounting.

[0001045810-18-000010:notes:185]
As a result of the reduction of the corporate income tax rate to 21%, companies were required to remeasure their deferred tax assets and liabilities as of the date of enactment. As a result, we recorded a provisional income tax expense of $43 million on the write-down of our deferred tax balance.

[0001045810-18-000010:notes:186]
The decrease in the effective tax rate in fiscal year 2018 as compared to fiscal years 2017 and 2016 was primarily due to the provisional impact of the tax law changes and the recognition of excess tax benefits related to stock-based compensation. The decrease in our effective tax rate in fiscal year 2017 as compared to fiscal year 2016 was primarily due to the recognition of excess tax benefits from our adoption of a new accounting standard in fiscal year 2017 related to the simplification of certain aspects of stock-based compensation accounting.

[0001045810-18-000010:notes:187]
Our effective tax rate  for fiscal year 2018 was lower than the blended U.S. federal statutory rate of 33.9% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition of the U.S. federal research tax credit, the provisional impact of the recent tax law changes in 2018, and excess tax benefits related to stock-based compensation.

[0001045810-18-000010:notes:188]
Our effective tax rate  for fiscal years 2017 and 2016 was lower than U.S. federal statutory tax rate of 35% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition in those fiscal years of the U.S. federal research tax credit, favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of the applicable statutes of limitations, and adoption of an accounting standard related to stock-based compensation in fiscal year 2017.

[0001045810-18-000010:notes:189]
As of January 28, 2018 and January 29, 2017, we had a valuation allowance of $469 million and $353 million, respectively, related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-18-000010:notes:190]
As of January 28, 2018, we had federal, state and foreign net operating loss carryforwards of $74 million, $226 million and $281 million, respectively. The federal and state carryforwards will expire beginning in fiscal year 2023 and 2019, respectively. The foreign net operating loss carryforwards of $281 million may be carried forward indefinitely. As of January 28, 2018, we had federal research tax credit carryforwards of $361 million that will begin to expire in fiscal year 2032. We have state research tax credit carryforwards of $575 million, of which $554 million is attributable to the State of California and may be carried over indefinitely, and $21 million is attributable to various other states and will expire beginning in fiscal year 2019. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, states, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-18-000010:notes:191]
As of January 28, 2018, we had $447 million of gross unrecognized tax benefits, of which $413 million would affect our effective tax rate if recognized. However, approximately $58 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $413 million of unrecognized tax benefits as of January 28, 2018 consisted of $175 million recorded in non-current income taxes payable and $238 million reflected as a reduction to the related deferred tax assets.

[0001045810-18-000010:notes:192]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-18-000010:notes:193]
|  | January 28,2018 |  | January 29,2017 |  | January 31,2016 |
|  | (In millions) |
| Balance at beginning of period | $ | 224 |  |  | $ | 230 |  |  | $ | 254 |  |
| Increases in tax positions for prior years | 7 |  |  | 3 |  |  | — |  |
| Decreases in tax positions for prior years | (1 | ) |  | — |  |  | (1 | ) |
| Increases in tax positions for current year | 222 |  |  | 46 |  |  | 28 |  |
| Settlements | — |  |  | (48 | ) |  | — |  |
| Lapse in statute of limitations | (5 | ) |  | (7 | ) |  | (51 | ) |
| Balance at end of period | $ | 447 |  |  | $ | 224 |  |  | $ | 230 |  |

[0001045810-18-000010:notes:194]
The increase in the unrecognized tax benefit in fiscal year 2018 is primarily due to the one-time transition tax imposed on foreign earnings under the TCJA. We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-18-000010:notes:195]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 28, 2018, January 29, 2017, and January 31, 2016, we had accrued $15 million, $13 million, and $11 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 28, 2018, unrecognized tax benefits of $175 million and the related interest and penalties of $15 million are included in non-current income taxes payable.

[0001045810-18-000010:notes:196]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 28, 2018, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-18-000010:notes:197]
We are subject to taxation by a number of taxing authorities both in the United States and throughout the world. As of January 28, 2018, the significant tax jurisdictions that may be subject to examination include the United States, Hong Kong, Taiwan, China, United Kingdom, Germany, and India for fiscal years 2003 through 2017. As of January 28, 2018, the significant tax jurisdictions for which we are currently under examination include India, Taiwan, UK, and Germany for fiscal years 2003 through 2017.


## us-gaap:IncomeTaxPolicyTextBlock

[0001045810-18-000010:notes:198]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-18-000010:notes:199]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-18-000010:notes:200]
As of January 28, 2018, we had a valuation allowance of $469 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-18-000010:notes:201]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-18-000010:notes:202]
In December 2017, the Tax Cuts and Jobs Act, or TCJA, was enacted into law. The TCJA significantly changes U.S. tax law including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, a requirement for companies to pay a one-time transition tax on the earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign-source earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us in the fourth quarter of fiscal year 2018, while other provisions will impact us beginning in fiscal year 2019. Refer to Note 13 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-18-000010:notes:203]
Amortizable Intangible Assets

[0001045810-18-000010:notes:204]
The components of our amortizable intangible assets are as follows:

[0001045810-18-000010:notes:205]
|  | January 28, 2018 |  | January 29, 2017 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (180 | ) |  | $ | 15 |  |  | $ | 193 |  |  | $ | (167 | ) |  | $ | 26 |  |
| Patents and licensed technology | 469 |  |  | (432 | ) |  | 37 |  |  | 468 |  |  | (390 | ) |  | 78 |  |
| Total intangible assets | $ | 664 |  |  | $ | (612 | ) |  | $ | 52 |  |  | $ | 661 |  |  | $ | (557 | ) |  | $ | 104 |  |

[0001045810-18-000010:notes:206]
Amortization expense associated with intangible assets for fiscal years 2018, 2017, and 2016 was $55 million, $68 million, and $73 million, respectively. Future amortization expense for the net carrying amount of intangible assets as of January 28, 2018 is estimated to be $26 million in fiscal year 2019, $17 million in fiscal year 2020, $8 million in fiscal year 2021, and $1 million in fiscal year 2022 and thereafter until fully amortized.


## us-gaap:InventoryPolicyTextBlock

[0001045810-18-000010:notes:207]
Inventories

[0001045810-18-000010:notes:208]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or net realizable value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.


## us-gaap:InvestmentPolicyTextBlock

[0001045810-18-000010:notes:209]
Fair Value of Financial Instruments

[0001045810-18-000010:notes:210]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 28, 2018 and January 29, 2017. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains or losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains or losses are recognized in earnings in the periods of change together with the offsetting losses or gains on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-18-000010:notes:211]
|  | January 28, 2018 |  | January 29, 2017 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 5,381 |  |  | $ | 5,375 |  |  | $ | 2,209 |  |  | $ | 2,209 |  |
| Due in 1 - 5 years | 1,500 |  |  | 1,485 |  |  | 3,210 |  |  | 3,194 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 35 |  |  | 35 |  |  | 65 |  |  | 65 |  |
| Total | $ | 6,916 |  |  | $ | 6,895 |  |  | $ | 5,484 |  |  | $ | 5,468 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0001045810-18-000010:notes:212]
Litigation, Investigation and Settlement Costs

[0001045810-18-000010:notes:213]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001045810-18-000010:notes:214]
Rent Expense

[0001045810-18-000010:notes:215]
We recognize rent expense on a straight-line basis over the lease period and accrue for rent expense incurred, but not paid.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001045810-18-000010:notes:216]
|  | January 28, 2018 |  | January 29, 2017 |
| Long-lived assets: | (In millions) |
| United States | $ | 928 |  |  | $ | 440 |  |
| Taiwan | 58 |  |  | 52 |  |
| India | 40 |  |  | 47 |  |
| China | 33 |  |  | 34 |  |
| Europe | 11 |  |  | 9 |  |
| Other Asia Pacific | 1 |  |  | 1 |  |
| Total long-lived assets | $ | 1,071 |  |  | $ | 583 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-18-000010:notes:217]
Marketable Securities

[0001045810-18-000010:notes:218]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities.

[0001045810-18-000010:notes:219]
The following is a summary of cash equivalents and marketable securities as of January 28, 2018 and January 29, 2017:

[0001045810-18-000010:notes:220]
The following table provides the breakdown of unrealized losses as of January 28, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-18-000010:notes:221]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 433 |  |  | $ | (2 | ) |  | $ | 801 |  |  | $ | (7 | ) |  | $ | 1,234 |  |  | $ | (9 | ) |
| Debt securities issued by United States government agencies | 175 |  |  | (1 | ) |  | 640 |  |  | (6 | ) |  | 815 |  |  | (7 | ) |
| Debt securities issued by the US Treasury | 170 |  |  | (1 | ) |  | 404 |  |  | (3 | ) |  | 574 |  |  | (4 | ) |
| Asset-backed securities | 73 |  |  | — |  |  | 179 |  |  | (2 | ) |  | 252 |  |  | (2 | ) |
| Foreign government bonds | — |  |  | — |  |  | 41 |  |  | (1 | ) |  | 41 |  |  | (1 | ) |
| Total | $ | 851 |  |  | $ | (4 | ) |  | $ | 2,065 |  |  | $ | (19 | ) |  | $ | 2,916 |  |  | $ | (23 | ) |

[0001045810-18-000010:notes:222]
The gross unrealized losses related to fixed income securities and were primarily due to changes in interest rates, which we believe are temporary in nature. Currently, we have the intent and ability to hold our investments until maturity. For fiscal years 2018, 2017, and 2016, there were no other-than-temporary impairment losses and net realized gains were not significant.

[0001045810-18-000010:notes:223]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of January 28, 2018 and January 29, 2017 are shown below by contractual maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-18-000010:notes:224]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000010:notes:225]
Recently Adopted Accounting Pronouncements

[0001045810-18-000010:notes:226]
In October 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which requires the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We elected to early adopt this new guidance in the first quarter of fiscal year 2018, which required us to reflect any adjustments as of January 30, 2017. Upon adoption of this guidance, we recorded a cumulative-effect adjustment as of the first day of fiscal year 2018 to decrease retained earnings by $28 million, with a corresponding decrease to prepaid taxes that had not been previously recognized in income tax expense.

[0001045810-18-000010:notes:227]
In January 2017, the FASB issued an accounting standards update that simplifies the test for goodwill impairment. The update eliminates the second step in the goodwill impairment test that requires an entity to determine the implied fair value of the reporting unit’s goodwill. Instead, an entity should recognize an impairment loss if the carrying value of the net assets assigned to the reporting unit exceeds the fair value of the reporting unit, with the impairment loss not to exceed the amount of goodwill allocated to the reporting unit. We adopted this guidance in the fourth quarter of fiscal year 2018 and applied it prospectively, as permitted by the standard. The adoption of this accounting guidance did not have a material impact on our consolidated financial statements.

[0001045810-18-000010:notes:228]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-18-000010:notes:229]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. Most prominent among the amendments is the requirement for changes in the fair value of our equity investments to be recognized through net income rather than other comprehensive income. The update will be effective for us beginning in our first quarter of fiscal year 2019. We anticipate the adoption of this accounting standard to increase the volatility of our other income or expense, net, due to the remeasurement of certain of our equity securities, primarily our investments in non-affiliates, for fair value changes.

[0001045810-18-000010:notes:230]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

[0001045810-18-000010:notes:231]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. We have made progress in, and continue to assess changes in policies, processes, systems and controls necessary to meet the additional requirements of the guidance. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new revenue standard, we do not expect it to have a material impact on our consolidated financial statements. However, we do expect to provide additional disclosure under this guidance, including more information regarding estimates and judgments, practical expedients used, contract balances and performance obligations.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-18-000010:notes:232]
Employee Retirement Plans

[0001045810-18-000010:notes:233]
We have a 401(k) retirement plan covering substantially all of our United States employees. Under the plan, participating employees may defer up to 80% of their pre-tax earnings, subject to the Internal Revenue Service annual contribution limits and we match a portion of the employee contributions. Our contribution expense for fiscal years 2018, 2017, and 2016 was $23 million, $12 million, and $8 million, respectively. We also have defined contribution retirement plans outside of the United States to which we contributed $25 million, $23 million, and $21 million for fiscal years 2018, 2017, and 2016, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001045810-18-000010:notes:234]
Property and Equipment

[0001045810-18-000010:notes:235]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization of assets recorded under capital leases. Leasehold improvements and assets recorded under capital leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001045810-18-000010:notes:236]
Quarterly Summary (Unaudited)

[0001045810-18-000010:notes:237]
The following table sets forth our unaudited consolidated financial results, for the last eight fiscal quarters:

[0001045810-18-000010:notes:238]
|  | Fiscal Year 2018Quarters Ended |
|  | January 28, 2018 |  | October 28, 2017 |  | July 29, 2017 |  | April 29, 2017 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 2,911 |  |  | $ | 2,636 |  |  | $ | 2,230 |  |  | $ | 1,937 |  |
| Cost of revenue | $ | 1,110 |  |  | $ | 1,067 |  |  | $ | 928 |  |  | $ | 787 |  |
| Gross profit | $ | 1,801 |  |  | $ | 1,569 |  |  | $ | 1,302 |  |  | $ | 1,150 |  |
| Net income (1) | $ | 1,118 |  |  | $ | 838 |  |  | $ | 583 |  |  | $ | 507 |  |
| Net income per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.84 |  |  | $ | 1.39 |  |  | $ | 0.98 |  |  | $ | 0.86 |  |
| Diluted | $ | 1.78 |  |  | $ | 1.33 |  |  | $ | 0.92 |  |  | $ | 0.79 |  |

[0001045810-18-000010:notes:239]
| (1) | In the fourth quarter of fiscal year 2018, we recorded a U.S. tax reform provisional net tax benefit of $133 million associated with the one-time transition tax on our historical foreign earnings and the adjustment of deferred tax balances to the lower corporate tax rate. Refer to Note 13 of these Notes to the Consolidated Financial Statements for a discussion regarding the U.S. tax reform. |

[0001045810-18-000010:notes:240]
|  | Fiscal Year 2017Quarters Ended |
|  | January 29, 2017 |  | October 30, 2016 |  | July 31,2016 |  | May 1, 2016 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 2,173 |  |  | $ | 2,004 |  |  | $ | 1,428 |  |  | $ | 1,305 |  |
| Cost of revenue | $ | 870 |  |  | $ | 821 |  |  | $ | 602 |  |  | $ | 554 |  |
| Gross profit | $ | 1,303 |  |  | $ | 1,183 |  |  | $ | 826 |  |  | $ | 751 |  |
| Net income (1) | $ | 655 |  |  | $ | 542 |  |  | $ | 261 |  |  | $ | 208 |  |
| Net income per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.18 |  |  | $ | 1.01 |  |  | $ | 0.49 |  |  | $ | 0.39 |  |
| Diluted | $ | 0.99 |  |  | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 0.35 |  |

[0001045810-18-000010:notes:241]
| (1) | In the third quarter of fiscal year 2017, we adopted an accounting standard related to stock-based compensation, which requires adjustments to be reflected beginning in fiscal year 2017. The adoption of the new accounting standard impacted our previously reported quarterly results for fiscal year 2017. |


## us-gaap:ReceivablesPolicyTextBlock

[0001045810-18-000010:notes:242]
Accounts Receivable

[0001045810-18-000010:notes:243]
We maintain an allowance for doubtful accounts receivable for estimated losses resulting from the inability of our customers to make required payments. We determine this allowance by identifying amounts for specific customer issues as well as amounts based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001045810-18-000010:notes:244]
Revenue Recognition

[0001045810-18-000010:notes:245]
Product Revenue

[0001045810-18-000010:notes:246]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured. For most sales, we use a binding purchase order and in certain cases we use a contractual agreement as evidence of an arrangement. We consider delivery to occur upon shipment provided title and risk of loss have passed to the customer. At the point of sale, we assess whether the arrangement fee is fixed or determinable and whether collection is reasonably assured. If we determine that collection of a fee is not reasonably assured, we defer the fee and recognize revenue at the time collection becomes reasonably assured, which is generally upon receipt of payment.

[0001045810-18-000010:notes:247]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor, as we typically find that over 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents less than 0.5% of total revenue.

[0001045810-18-000010:notes:248]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to our partners that are earmarked for market segment development and expansion and are typically designed to support our partners’ activities while also promoting NVIDIA products. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed.

[0001045810-18-000010:notes:249]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-18-000010:notes:250]
License and Development Revenue

[0001045810-18-000010:notes:251]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete the project. A provision for estimated losses on contracts is made in the period in which the loss becomes probable and can be reasonably estimated. Costs incurred in advance of revenue recognized are recorded as deferred costs on uncompleted contracts. If the amount billed exceeds the amount of revenue recognized, the excess amount is recorded as deferred revenue.

[0001045810-18-000010:notes:252]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-18-000010:notes:253]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties.  We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001045810-18-000010:notes:254]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
| Revenue: | (In millions) |
| Taiwan | $ | 2,991 |  |  | $ | 2,546 |  |  | $ | 1,912 |  |
| Other Asia Pacific | 2,066 |  |  | 1,010 |  |  | 749 |  |
| China | 1,896 |  |  | 1,305 |  |  | 806 |  |
| United States | 1,274 |  |  | 904 |  |  | 643 |  |
| Europe | 768 |  |  | 659 |  |  | 482 |  |
| Other Americas | 719 |  |  | 486 |  |  | 418 |  |
| Total revenue | $ | 9,714 |  |  | $ | 6,910 |  |  | $ | 5,010 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-18-000010:notes:255]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 28, 2018: |  |  |  |  |  |  |  |
| Revenue | $ | 8,137 |  |  | $ | 1,534 |  |  | $ | 43 |  |  | $ | 9,714 |  |
| Depreciation and amortization expense | $ | 123 |  |  | $ | 37 |  |  | $ | 39 |  |  | $ | 199 |  |
| Operating income (loss) | $ | 3,507 |  |  | $ | 303 |  |  | $ | (600 | ) |  | $ | 3,210 |  |
| Year Ended January 29, 2017: |  |  |  |  |  |  |  |
| Revenue | $ | 5,822 |  |  | $ | 824 |  |  | $ | 264 |  |  | $ | 6,910 |  |
| Depreciation and amortization expense | $ | 116 |  |  | $ | 29 |  |  | $ | 42 |  |  | $ | 187 |  |
| Operating income (loss) | $ | 2,180 |  |  | $ | (9 | ) |  | $ | (237 | ) |  | $ | 1,934 |  |
| Year Ended January 31, 2016: |  |  |  |  |  |  |  |
| Revenue | $ | 4,187 |  |  | $ | 559 |  |  | $ | 264 |  |  | $ | 5,010 |  |
| Depreciation and amortization expense | $ | 110 |  |  | $ | 43 |  |  | $ | 44 |  |  | $ | 197 |  |
| Operating income (loss) | $ | 1,344 |  |  | $ | (239 | ) |  | $ | (358 | ) |  | $ | 747 |  |

[0001045810-18-000010:notes:256]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |
| Unallocated revenue | $ | 43 |  |  | $ | 264 |  |  | $ | 264 |  |
| Stock-based compensation | (391 | ) |  | (247 | ) |  | (204 | ) |
| Unallocated cost of revenue and operating expenses | (237 | ) |  | (215 | ) |  | (244 | ) |
| Acquisition-related costs | (13 | ) |  | (16 | ) |  | (22 | ) |
| Contributions | (2 | ) |  | (4 | ) |  | — |  |
| Legal settlement costs | — |  |  | (16 | ) |  | — |  |
| Restructuring and other charges | — |  |  | (3 | ) |  | (131 | ) |
| Product warranty charges | — |  |  | — |  |  | (21 | ) |
| Total | $ | (600 | ) |  | $ | (237 | ) |  | $ | (358 | ) |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-18-000010:notes:257]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-18-000010:notes:258]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2018 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3 |  |  | $ | 1 |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 10 |  |  | $ | 15 |  | (2) | $ | (16 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 353 |  |  | $ | 116 |  | (3) | $ | — |  |  | $ | 469 |  |
| Fiscal year 2017 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | 1 |  | (1) | $ | — |  | (1) | $ | 3 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 9 |  | (2) | $ | (8 | ) | (4) | $ | 10 |  |
| Deferred tax valuation allowance |  | $ | 272 |  |  | $ | 81 |  | (3) | $ | — |  |  | $ | 353 |  |
| Fiscal year 2016 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3 |  |  | $ | — |  | (1) | $ | (1 | ) | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 14 |  |  | $ | 9 |  | (2) | $ | (14 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 261 |  |  | $ | 11 |  | (3) | $ | — |  |  | $ | 272 |  |

[0001045810-18-000010:notes:259]
| (1) | Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end. |

[0001045810-18-000010:notes:260]
| (2) | Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue. |

[0001045810-18-000010:notes:261]
| (3) | Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information. |

[0001045810-18-000010:notes:262]
| (4) | Represents sales returns. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-18-000010:notes:263]
Segment Information

[0001045810-18-000010:notes:264]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-18-000010:notes:265]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-18-000010:notes:266]
While our GPU and CUDA architecture is unified, our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for consoles and mobile gaming and entertainment devices.

[0001045810-18-000010:notes:267]
Under the single unifying graphics architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-18-000010:notes:268]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, contributions, restructuring and other charges, product warranty charge, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-18-000010:notes:269]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for NVIDIA as a whole. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-18-000010:notes:270]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-18-000010:notes:271]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-18-000010:notes:272]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and deposits and other assets, and exclude goodwill and intangible assets.

[0001045810-18-000010:notes:273]
No single customer represented more than 10% of total revenue for fiscal year 2018. In fiscal years 2017 and 2016, we had one customer that represented 12% and 11% of our total revenue, respectively. The revenue was attributable to the GPU business.

[0001045810-18-000010:notes:274]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-18-000010:notes:275]
Organization and Summary of Significant Accounting Policies

[0001045810-18-000010:notes:276]
Our Company

[0001045810-18-000010:notes:277]
Starting with a focus on PC graphics, NVIDIA invented the GPU to solve some of the most complex problems in computer science. We have extended our focus in recent years to the revolutionary field of artificial intelligence.

[0001045810-18-000010:notes:278]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-18-000010:notes:279]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries, except where it is made clear that the term means only the parent company.

[0001045810-18-000010:notes:280]
Fiscal Year

[0001045810-18-000010:notes:281]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years and fiscal year 2016 was a 53-week year.

[0001045810-18-000010:notes:282]
Reclassifications

[0001045810-18-000010:notes:283]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-18-000010:notes:284]
Use of Estimates

[0001045810-18-000010:notes:285]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-18-000010:notes:286]
Marketable securities consist primarily of highly liquid investments with maturities of greater than three months when purchased. We generally classify our marketable securities at the date of acquisition as available-for-sale. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. The fair value of interest-bearing securities includes accrued interest. Any unrealized losses which are considered to be other-than-temporary impairments are recorded in the other income or expense, net, section of our Consolidated Statements of Income. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income or expense, net, section of our Consolidated Statements of Income.

[0001045810-18-000010:notes:287]
All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is not more likely than not that we will not be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings while loss related to all other factors is recorded in accumulated other comprehensive income or loss.

[0001045810-18-000010:notes:288]
Concentration of Credit Risk

[0001045810-18-000010:notes:289]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, accounts receivable, note hedge and interest rate swap. Our investment policy requires the purchase of high grade investment securities, the diversification of asset type and includes certain limits on our portfolio duration. All marketable securities are held in our name, managed by several investment managers and held by one major financial institution under a custodial arrangement. Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 28% of our accounts receivable balance from two customers as of January 28, 2018 and 29% of our account receivable balance from two customers as of January 29, 2017. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-18-000010:notes:290]
Intangible Assets and Other Long-Lived Assets


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-18-000010:notes:291]
Shareholders’ Equity

[0001045810-18-000010:notes:292]
Capital Return Program

[0001045810-18-000010:notes:293]
Beginning August 2004, our Board of Directors authorized us to repurchase our stock.

[0001045810-18-000010:notes:294]
During fiscal year 2018, we repurchased a total of 6 million shares for $909 million and paid $341 million in cash dividends to our shareholders.

[0001045810-18-000010:notes:295]
Through January 28, 2018, we have repurchased an aggregate of 251 million shares under our share repurchase program for a total cost of $5.5 billion. All shares delivered from these repurchases have been placed into treasury stock. As of January 28, 2018, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.82 billion through December 2020.

[0001045810-18-000010:notes:296]
Preferred Stock

[0001045810-18-000010:notes:297]
As of January 28, 2018 and January 29, 2017, there were no shares of preferred stock outstanding.

[0001045810-18-000010:notes:298]
Common Stock

[0001045810-18-000010:notes:299]
We are authorized to issue up to 2.00 billion shares of our common stock at $0.001 per share par value.
