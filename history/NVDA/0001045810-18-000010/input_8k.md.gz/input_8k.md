# NVDA 8-K — 0001045810-18-000004 filed 2018-02-08

## item codes, every 8-K on or before 2018-02-28

- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2018-02-28

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-18-000004:8k_2_02:1]
EX-99.1
2
q4fy18pr.htm
Q4FY18 PRESS RELEASE

[0001045810-18-000004:8k_2_02:2]
Exhibit

[0001045810-18-000004:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-18-000004:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2018

[0001045810-18-000004:8k_2_02:5]
| • | Record quarterly revenue of $2.91 billion, up 34 percent from a year ago |

[0001045810-18-000004:8k_2_02:6]
| • | Record full-year revenue of $9.71 billion, up 41 percent from a year ago |

[0001045810-18-000004:8k_2_02:7]
| • | Record quarterly GAAP gross margin of 61.9 percent, non-GAAP gross margin of 62.1 percent |

[0001045810-18-000004:8k_2_02:8]
| • | Record full-year GAAP EPS of $4.82, up 88 percent from a year ago |

[0001045810-18-000004:8k_2_02:9]
SANTA CLARA, Calif.-Feb. 8, 2018-NVIDIA (NASDAQ: NVDA) today reported record revenue for the fourth quarter ended January 28, 2018, of $2.91 billion, up 34 percent from $2.17 billion a year earlier, and up 10 percent from $2.64 billion in the previous quarter.

[0001045810-18-000004:8k_2_02:10]
GAAP earnings per diluted share for the quarter were a record $1.78, up 80 percent from $0.99 a year ago and up 34 percent from $1.33 in the previous quarter. Non-GAAP earnings per diluted share were $1.72, also a record, up 52 percent from $1.13 a year earlier and up 29 percent from $1.33 in the previous quarter.

[0001045810-18-000004:8k_2_02:11]
For fiscal 2018, revenue was a record $9.71 billion, up 41 percent from $6.91 billion a year earlier. GAAP earnings per diluted share were a record $4.82, up 88 percent from $2.57 a year earlier. Non-GAAP earnings per diluted share were $4.92, also a record, up 61 percent from $3.06 a year earlier.

[0001045810-18-000004:8k_2_02:12]
“We achieved another record quarter, capping an excellent year,” said Jensen Huang, founder and chief executive officer of NVIDIA. “In a powerful sign of our progress, attendees at NVIDIA’s GPU Technology Conferences reached 22,000, up tenfold in five years, as software developers working in AI, self-driving cars, and a broad range of other fields continued to discover the acceleration and money-saving benefits of our GPU computing platform.

[0001045810-18-000004:8k_2_02:13]
“Industries around the world are racing to incorporate AI. Virtually every internet and cloud service provider has embraced our Volta GPUs. Hundreds of transportation companies are using our NVIDIA DRIVE platform. From manufacturing and healthcare to smart cities, innovators are using our platform to invent the future,” he said.

[0001045810-18-000004:8k_2_02:14]
Capital Return

[0001045810-18-000004:8k_2_02:15]
During fiscal 2018, NVIDIA returned $1.25 billion to shareholders through a combination of $909 million in share repurchases and $341 million in quarterly cash dividends.

[0001045810-18-000004:8k_2_02:16]
For fiscal 2019, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000004:8k_2_02:17]
NVIDIA will pay its next quarterly cash dividend of $0.15 per share on March 16, 2018, to all shareholders of record on February 23, 2018.

[0001045810-18-000004:8k_2_02:18]
Q4 Fiscal 2018 Summary

[0001045810-18-000004:8k_2_02:19]
| GAAP |
| ($ in millions except earnings per share) | Q4 FY18 | Q3 FY18 | Q4 FY17 | Q/Q | Y/Y |
| Revenue | $2,911 | $2,636 | $2,173 | Up 10% | Up 34% |
| Gross margin | 61.9% | 59.5% | 60.0% | Up 240 bps | Up 190 bps |
| Operating expenses | $728 | $674 | $570 | Up 8% | Up 28% |
| Operating income | $1,073 | $895 | $733 | Up 20% | Up 46% |
| Net income | $1,118 | $838 | $655 | Up 33% | Up 71% |
| Diluted earnings per share | $1.78 | $1.33 | $0.99 | Up 34% | Up 80% |

[0001045810-18-000004:8k_2_02:20]
| Non-GAAP |
| ($ in millions except earnings per share) | Q4 FY18 | Q3 FY18 | Q4 FY17 | Q/Q | Y/Y |
| Revenue | $2,911 | $2,636 | $2,173 | Up 10% | Up 34% |
| Gross margin | 62.1% | 59.7% | 60.2% | Up 240 bps | Up 190 bps |
| Operating expenses | $607 | $570 | $498 | Up 6% | Up 22% |
| Operating income | $1,202 | $1,005 | $809 | Up 20% | Up 49% |
| Net income | $1,081 | $833 | $704 | Up 30% | Up 54% |
| Diluted earnings per share | $1.72 | $1.33 | $1.13 | Up 29% | Up 52% |

[0001045810-18-000004:8k_2_02:21]
Fiscal 2018 Summary

[0001045810-18-000004:8k_2_02:22]
| GAAP |
| ($ in millions except earnings per share) | FY18 | FY17 | Y/Y |
| Revenue | $9,714 | $6,910 | Up 41% |
| Gross margin | 59.9 | % | 58.8 | % | Up 110 bps |
| Operating expenses | $2,612 | $2,129 | Up 23% |
| Operating income | $3,210 | $1,934 | Up 66% |
| Net income | $3,047 | $1,666 | Up 83% |
| Diluted earnings per share | $4.82 | $2.57 | Up 88% |

[0001045810-18-000004:8k_2_02:23]
| Non-GAAP |
| ($ in millions except earnings per share) | FY18 | FY17 | Y/Y |
| Revenue | $9,714 | $6,910 | Up 41% |
| Gross margin | 60.2 | % | 59.2 | % | Up 100 bps |
| Operating expenses | $2,227 | $1,867 | Up 19% |
| Operating income | $3,617 | $2,221 | Up 63% |
| Net income | $3,085 | $1,851 | Up 67% |
| Diluted earnings per share | $4.92 | $3.06 | Up 61% |

[0001045810-18-000004:8k_2_02:24]
NVIDIA’s outlook for the first quarter of fiscal 2019 is as follows:

[0001045810-18-000004:8k_2_02:25]
| • | Revenue is expected to be $2.90 billion, plus or minus two percent. |

[0001045810-18-000004:8k_2_02:26]
| • | GAAP and non-GAAP gross margins are expected to be 62.7 percent and 63.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-18-000004:8k_2_02:27]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $770 million and $645 million, respectively. |

[0001045810-18-000004:8k_2_02:28]
| • | GAAP and non-GAAP other income and expense are both expected to be nominal. |

[0001045810-18-000004:8k_2_02:29]
| • | GAAP and non-GAAP tax rates are both expected to be 12 percent, plus or minus one percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which the company expects to generate variability on a quarter by quarter basis. |

[0001045810-18-000004:8k_2_02:30]
Fourth Quarter Fiscal 2018 Highlights

[0001045810-18-000004:8k_2_02:31]
During the fourth quarter, NVIDIA achieved progress in these areas:

[0001045810-18-000004:8k_2_02:32]
Datacenter

[0001045810-18-000004:8k_2_02:33]
| • | Announced that NVIDIA Tesla® V100 GPU accelerators are now available through every major computer maker and have been chosen by every major cloud to deliver AI and high performance computing. |

[0001045810-18-000004:8k_2_02:34]
| • | Added a record 34 GPU-accelerated systems to the Top500 supercomputer list, bringing the company’s total to 87. |

[0001045810-18-000004:8k_2_02:35]
| • | Announced partnerships to further AI in key vertical industries, including initiatives with GE Health and Nuance in medical imaging; Baker Hughes, a GE company, in oil and gas; and Japan’s Komatsu in construction and mining. |

[0001045810-18-000004:8k_2_02:36]
| • | Expanded the NVIDIA® GPU Cloud container registry to support scientists using HPC applications, and AI researchers using desktop GPUs. |

[0001045810-18-000004:8k_2_02:37]
Gaming

[0001045810-18-000004:8k_2_02:38]
| • | Announced gaming laptops using the Max-Q design, which are 3x faster and 3x thinner than previous-generation gaming laptops. |

[0001045810-18-000004:8k_2_02:39]
| • | Introduced BFGDs™, big format gaming displays, providing ultra-low latency PC gaming and integrated streaming on a high-end 65-inch display using NVIDIA G-SYNC™ technology with NVIDIA SHIELD™. |

[0001045810-18-000004:8k_2_02:40]
| • | Enhanced GeForce Experience™ with new tools, including NVIDIA Freestyle for customizing gameplay and an updated interface for the NVIDIA Ansel photo mode, as well as new titles including PlayerUnknown’s Battleground and Fortnite that support NVIDIA ShadowPlay™ Highlights for capturing gaming achievements. |

[0001045810-18-000004:8k_2_02:41]
| • | Increased its GeForce GPU share among gamers on the Steam online gaming platform to 86 percent. |

[0001045810-18-000004:8k_2_02:42]
| • | Introduced two new collector’s edition Star Wars-themed NVIDIA TITAN Xp GPUs, tied to the release of Star Wars: The Last Jedi. |

[0001045810-18-000004:8k_2_02:43]
Automotive

[0001045810-18-000004:8k_2_02:44]
| • | Announced and demonstrated NVIDIA DRIVE™ Xavier™, the world’s first autonomous machine processor, with customer availability in the first quarter. |

[0001045810-18-000004:8k_2_02:45]
| • | Announced NVIDIA DRIVE, the world’s first functionally safe AI self-driving platform, plus a suite of tools to test and validate neural networks by simulating all kind of driving conditions. |

[0001045810-18-000004:8k_2_02:46]
| • | Unveiled partnerships with Uber and Aurora to develop self-driving cars using the open NVIDIA DRIVE AI self-driving platform. |

[0001045810-18-000004:8k_2_02:47]
| • | Partnered with ZF and Baidu to create the first production AI autonomous vehicle platform for the China market, with Chery as the first customer. |

[0001045810-18-000004:8k_2_02:48]
| • | Partnered with Volkswagen to integrate AI into future VW vehicles using the NVIDIA DRIVE IX intelligent experience platform and create AI cockpits with enhanced convenience and safety features. |

[0001045810-18-000004:8k_2_02:49]
| • | Announced NVIDIA is powering the Mercedes-Benz MBUX in-car AI smart cockpit system, going into production next month with the new A-Class. |

[0001045810-18-000004:8k_2_02:50]
| • | Announced NVIDIA is partnering with Continental to build AI self-driving vehicle systems, from enhanced Level 2 to Level 5, for production in 2021. |

[0001045810-18-000004:8k_2_02:51]
CFO Commentary

[0001045810-18-000004:8k_2_02:52]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-18-000004:8k_2_02:53]
Conference Call and Webcast Information

[0001045810-18-000004:8k_2_02:54]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2018 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 6265639. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2019.

[0001045810-18-000004:8k_2_02:55]
Non-GAAP Measures

[0001045810-18-000004:8k_2_02:56]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, debt-related costs, the associated tax impact of these items, where applicable, and the provisional tax benefit from income tax reform. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-18-000004:8k_2_02:57]
Keep Current on NVIDIA

[0001045810-18-000004:8k_2_02:58]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-18-000004:8k_2_02:59]
About NVIDIA

[0001045810-18-000004:8k_2_02:60]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-18-000004:8k_2_02:61]
###

[0001045810-18-000004:8k_2_02:62]
For further information, contact:

[0001045810-18-000004:8k_2_02:63]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6474 |  | (408) 566-5150 |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-18-000004:8k_2_02:64]
Certain statements in this press release including, but not limited to statements as to: software developers working in AI, self-driving cars and other fields discovering the benefits of NVIDIA’s GPU computing platform; industries racing to incorporate AI; internet and cloud service providers embracing our Volta GPUs; the use of the NVIDIA DRIVE platform by transportation companies; the use of our platform in a variety of fields to invent the future; NVIDIA’s intended capital return for fiscal 2019; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the first quarter of fiscal 2019; NVIDIA’s tax rates for the first quarter of fiscal year 2019; the impact and benefits of NVIDIA Tesla V100 GPU accelerators, the expansion of the NVIDIA GPU Cloud container registry, the GeForce Experience and its new tools, NVIDIA DRIVE, partnerships with GE Health, Nuance, Baker Hughes, Komatsu, Uber, Aurora, ZF, Baidu, Volkswagen and Continental; the abilities, benefits and performance of laptops using the Max-Q design and BFGDs; the availability of NVIDIA DRIVE Xavier; and Mercedes-Benz MBUX use of NVIDIA technology and its production schedule are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended October 29, 2017. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-18-000004:8k_2_02:65]
© 2018 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Tesla, BFGD, GeForce Experience, GeForce NOW, NVIDIA Ansel, NVIDIA DRIVE, NVIDIA G-SYNC, NVIDIA Shadow Play, NVIDIA SHIELD and Xavier are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. MaxQ® is the registered trademark of Maxim Integrated Products, Inc. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-18-000004:8k_2_02:66]
NVIDIA CORPORATION

[0001045810-18-000004:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-18-000004:8k_2_02:68]
(In millions, except per share data)

[0001045810-18-000004:8k_2_02:69]
(Unaudited)

[0001045810-18-000004:8k_2_02:70]
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 28, |  | January 29, |  | January 28, |  | January 29, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue | $ | 2,911 |  |  | $ | 2,173 |  |  | $ | 9,714 |  |  | $ | 6,910 |  |
| Cost of revenue | 1,110 |  |  | 870 |  |  | 3,892 |  |  | 2,847 |  |
| Gross profit | 1,801 |  |  | 1,303 |  |  | 5,822 |  |  | 4,063 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 508 |  |  | 394 |  |  | 1,797 |  |  | 1,466 |  |
| Sales, general and administrative | 220 |  |  | 176 |  |  | 815 |  |  | 663 |  |
| Total operating expenses | 728 |  |  | 570 |  |  | 2,612 |  |  | 2,129 |  |
| Income from operations | 1,073 |  |  | 733 |  |  | 3,210 |  |  | 1,934 |  |
| Interest income | 20 |  |  | 17 |  |  | 69 |  |  | 54 |  |
| Interest expense | (15 | ) |  | (18 | ) |  | (61 | ) |  | (58 | ) |
| Other, net | — |  |  | (6 | ) |  | (22 | ) |  | (25 | ) |
| Total other income (expense) | 5 |  |  | (7 | ) |  | (14 | ) |  | (29 | ) |
| Income before income tax | 1,078 |  |  | 726 |  |  | 3,196 |  |  | 1,905 |  |
| Income tax expense (benefit) | (40 | ) |  | 71 |  |  | 149 |  |  | 239 |  |
| Net income | $ | 1,118 |  |  | $ | 655 |  |  | $ | 3,047 |  |  | $ | 1,666 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.84 |  |  | $ | 1.18 |  |  | $ | 5.09 |  |  | $ | 3.08 |  |
| Diluted | $ | 1.78 |  |  | $ | 0.99 |  |  | $ | 4.82 |  |  | $ | 2.57 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 606 |  |  | 553 |  |  | 599 |  |  | 541 |  |
| Diluted | 628 |  |  | 660 |  |  | 632 |  |  | 649 |  |

[0001045810-18-000004:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | January 28, |  | January 29, |
|  |  |  | 2018 |  | 2017 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 7,108 |  |  | $ | 6,798 |  |
|  | Accounts receivable, net |  | 1,265 |  |  | 826 |  |
|  | Inventories |  | 796 |  |  | 794 |  |
|  | Prepaid expenses and other current assets |  | 86 |  |  | 118 |  |
|  | Total current assets |  | 9,255 |  |  | 8,536 |  |
| Property and equipment, net |  | 997 |  |  | 521 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 52 |  |  | 104 |  |
| Other assets |  | 319 |  |  | 62 |  |
|  | Total assets |  | $ | 11,241 |  |  | $ | 9,841 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 596 |  |  | $ | 485 |  |
|  | Accrued and other current liabilities |  | 542 |  |  | 507 |  |
|  | Convertible short-term debt |  | 15 |  |  | 796 |  |
|  | Total current liabilities |  | 1,153 |  |  | 1,788 |  |
| Long-term debt |  | 1,985 |  |  | 1,983 |  |
| Other long-term liabilities |  | 632 |  |  | 277 |  |
|  | Total liabilities |  | 3,770 |  |  | 4,048 |  |
| Convertible debt conversion obligation |  | — |  |  | 31 |  |
| Shareholders' equity |  | 7,471 |  |  | 5,762 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 11,241 |  |  | $ | 9,841 |  |

[0001045810-18-000004:8k_2_02:72]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 28, |  | October 29, |  | January 29, |  | January 28, |  | January 29, |
|  |  | 2018 |  | 2017 |  | 2017 |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 1,801 |  |  | $ | 1,569 |  |  | $ | 1,303 |  |  | $ | 5,822 |  |  | $ | 4,063 |  |
| GAAP gross margin |  | 61.9 | % |  | 59.5 | % |  | 60.0 | % |  | 59.9 | % |  | 58.8 | % |
| Stock-based compensation expense (A) |  | 7 |  |  | 6 |  |  | 4 |  |  | 21 |  |  | 15 |  |
| Legal settlement costs |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 10 |  |
| Non-GAAP gross profit |  | $ | 1,809 |  |  | $ | 1,575 |  |  | $ | 1,307 |  |  | $ | 5,844 |  |  | $ | 4,088 |  |
| Non-GAAP gross margin |  | 62.1 | % |  | 59.7 | % |  | 60.2 | % |  | 60.2 | % |  | 59.2 | % |
| GAAP operating expenses |  | $ | 728 |  |  | $ | 674 |  |  | $ | 570 |  |  | $ | 2,612 |  |  | $ | 2,129 |  |
| Stock-based compensation expense (A) |  | (119 | ) |  | (101 | ) |  | (68 | ) |  | (370 | ) |  | (233 | ) |
| Acquisition-related costs (B) |  | (2 | ) |  | (3 | ) |  | (4 | ) |  | (13 | ) |  | (16 | ) |
| Contributions |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | (4 | ) |
| Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | (6 | ) |
| Restructuring and other charges |  | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Non-GAAP operating expenses |  | $ | 607 |  |  | $ | 570 |  |  | $ | 498 |  |  | $ | 2,227 |  |  | $ | 1,867 |  |
| GAAP income from operations |  | $ | 1,073 |  |  | $ | 895 |  |  | $ | 733 |  |  | $ | 3,210 |  |  | $ | 1,934 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 129 |  |  | 110 |  |  | 76 |  |  | 407 |  |  | 287 |  |
| Non-GAAP income from operations |  | $ | 1,202 |  |  | $ | 1,005 |  |  | $ | 809 |  |  | $ | 3,617 |  |  | $ | 2,221 |  |
| GAAP other income (expense) |  | $ | 5 |  |  | $ | 1 |  |  | $ | (7 | ) |  | $ | (14 | ) |  | $ | (29 | ) |
| Gains from non-affiliated investments |  | (2 | ) |  | — |  |  | (1 | ) |  | (2 | ) |  | (4 | ) |
| Debt-related costs (C) |  | 2 |  |  | 1 |  |  | 6 |  |  | 20 |  |  | 21 |  |
| Interest expense related to amortization of debt discount |  | — |  |  | — |  |  | 4 |  |  | 3 |  |  | 25 |  |
| Non-GAAP other income (expense) |  | $ | 5 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 13 |  |
| GAAP net income |  | $ | 1,118 |  |  | $ | 838 |  |  | $ | 655 |  |  | $ | 3,047 |  |  | $ | 1,666 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 129 |  |  | 111 |  |  | 85 |  |  | 428 |  |  | 329 |  |
| Income tax impact of non-GAAP adjustments (D) |  | (33 | ) |  | (116 | ) |  | (36 | ) |  | (257 | ) |  | (144 | ) |
| Provisional tax benefit from income tax reform |  | (133 | ) |  | — |  |  | — |  |  | (133 | ) |  | — |  |
| Non-GAAP net income |  | $ | 1,081 |  |  | $ | 833 |  |  | $ | 704 |  |  | $ | 3,085 |  |  | $ | 1,851 |  |

[0001045810-18-000004:8k_2_02:73]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 28, |  | October 29, |  | January 29, |  | January 28, |  | January 29, |
|  |  | 2018 |  | 2017 |  | 2017 |  | 2018 |  | 2017 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 1.78 |  |  | $ | 1.33 |  |  | $ | 0.99 |  |  | $ | 4.82 |  |  | $ | 2.57 |  |
| Non-GAAP |  | $ | 1.72 |  |  | $ | 1.33 |  |  | $ | 1.13 |  |  | $ | 4.92 |  |  | $ | 3.06 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 628 |  |  | 628 |  |  | 660 |  |  | 632 |  |  | 649 |  |
| Anti-dilution impact from note hedge (E) |  | (1 | ) |  | (2 | ) |  | (36 | ) |  | (5 | ) |  | (44 | ) |
| Non-GAAP |  | 627 |  |  | 626 |  |  | 624 |  |  | 627 |  |  | 605 |  |
| GAAP net cash provided by operating activities |  | $ | 1,358 |  |  | $ | 1,157 |  |  | $ | 721 |  |  | $ | 3,502 |  |  | $ | 1,672 |  |
| Purchase of property and equipment and intangible assets |  | (416 | ) |  | (69 | ) |  | (52 | ) |  | (593 | ) |  | (176 | ) |
| Free cash flow |  | $ | 942 |  |  | $ | 1,088 |  |  | $ | 669 |  |  | $ | 2,909 |  |  | $ | 1,496 |  |

[0001045810-18-000004:8k_2_02:74]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 28, |  | October 29, |  | January 29, |  | January 28, |  | January 29, |
|  |  | 2018 |  | 2017 |  | 2017 |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 7 |  |  | $ | 6 |  |  | $ | 4 |  |  | $ | 21 |  |  | $ | 15 |  |
| Research and development |  | $ | 73 |  |  | $ | 61 |  |  | $ | 40 |  |  | $ | 219 |  |  | $ | 135 |  |
| Sales, general and administrative |  | $ | 46 |  |  | $ | 40 |  |  | $ | 27 |  |  | $ | 151 |  |  | $ | 98 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Consists of loss on early debt conversions and termination of interest rate swap. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (E) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-18-000004:8k_2_02:75]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2019 Outlook |
| GAAP gross margin |  | 62.7 | % |
|  | Impact of stock-based compensation expense |  | 0.3 | % |
| Non-GAAP gross margin |  | 63.0 | % |
|  |  |  | Q1 FY2019 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 770 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (125 | ) |
| Non-GAAP operating expenses |  | $ | 645 |  |
