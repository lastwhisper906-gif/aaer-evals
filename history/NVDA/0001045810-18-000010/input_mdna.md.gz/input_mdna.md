# NVDA MD&A — 0001045810-18-000010


## mdna

[0001045810-18-000010:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001045810-18-000010:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 1A. Risk Factors”, “Item 6. Selected Financial Data”, our Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Annual Report on Form 10-K, before deciding to purchase, hold or sell shares of our common stock.

[0001045810-18-000010:mdna:3]
Overview

[0001045810-18-000010:mdna:4]
Our Company and Our Businesses

[0001045810-18-000010:mdna:5]
Starting with a focus on PC graphics, NVIDIA invented the GPU to solve some of the most complex problems in computer science. We have extended our focus in recent years to the revolutionary field of AI. Fueled by the sustained demand for better 3D graphics and the scale of the gaming market, NVIDIA has evolved the GPU into a computer brain at the intersection of VR, HPC, and AI.

[0001045810-18-000010:mdna:6]
Our two reportable segments - GPU and Tegra Processor - are based on a single underlying architecture. From our proprietary processors, we have created platforms that address four large markets where our expertise is critical: Gaming, Professional Visualization, Datacenter, and Automotive.

[0001045810-18-000010:mdna:7]
While our GPU and CUDA architecture is unified, our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for consoles and mobile gaming and entertainment devices.

[0001045810-18-000010:mdna:8]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-18-000010:mdna:9]
Recent Developments, Future Objectives and Challenges

[0001045810-18-000010:mdna:10]
Fiscal Year 2018 Summary

[0001045810-18-000010:mdna:11]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | Change |
|  | ($ in millions, except per share data) |
| Revenue | $ | 9,714 |  |  | $ | 6,910 |  |  | Up 41% |
| Gross margin | 59.9 | % |  | 58.8 | % |  | Up 110 bps |
| Operating expenses | $ | 2,612 |  |  | $ | 2,129 |  |  | Up 23% |
| Income from operations | $ | 3,210 |  |  | $ | 1,934 |  |  | Up 66% |
| Net income | $ | 3,047 |  |  | $ | 1,666 |  |  | Up 83% |
| Net income per diluted share | $ | 4.82 |  |  | $ | 2.57 |  |  | Up 88% |

[0001045810-18-000010:mdna:12]
Revenue for fiscal year 2018 grew 41% to $9.71 billion, reflecting broad growth in each of our market platforms - gaming, professional visualization, datacenter, and automotive.

[0001045810-18-000010:mdna:13]
GPU business revenue was $8.14 billion, up 40% from a year earlier, led by growth in gaming, datacenter, and professional visualization. Strong growth across our Pascal-based GeForce gaming GPUs was driven by growth associated with GPU refreshes/upgrades, new gamers, new games, eSports, and cryptocurrency mining. Revenue for datacenter, including Tesla, NVIDIA GRID and NVIDIA DGX, was $1.93 billion, up 133% year on year, led by strong sales of our Volta architecture, including V100 GPU accelerators, which began shipping in the first half of fiscal year 2018 and are available through major computer makers and cloud providers, new DGX systems, and design wins in HPC. Professional visualization revenue grew 12% year over year to $934 million, led by ultra-high-end and high-end desktop workstations, as well as unique form factors and emerging opportunities, including AI, deep learning, VR and rendering.

[0001045810-18-000010:mdna:14]
23

[0001045810-18-000010:mdna:15]
Tegra processor business revenue was $1.53 billion, up 86% from a year ago. Tegra processor business revenue includes SOC modules for the Nintendo Switch gaming console and development services. Also included was automotive revenue of $558 million, which was up 15% from a year earlier, incorporating infotainment modules, production DRIVE PX platforms, and development agreements for self-driving cars.

[0001045810-18-000010:mdna:16]
Revenue from our patent license agreement with Intel concluded in the first quarter of fiscal year 2018.

[0001045810-18-000010:mdna:17]
Gross margin for fiscal year 2018 was 59.9%, compared with 58.8% a year earlier, reflecting a favorable shift in mix, the growth of our GeForce gaming GPUs, and the growth of our GPU computing platform for cloud, deep learning, AI, and graphics virtualization, partially offset by the conclusion of our patent license agreement with Intel.

[0001045810-18-000010:mdna:18]
Operating expenses for fiscal year 2018 were $2.61 billion, up from $2.13 billion in the previous year. This reflects growth in employees and related costs, as well as investments in growth initiatives, including gaming, AI, and autonomous driving.

[0001045810-18-000010:mdna:19]
We recorded a U.S. tax reform provisional net tax benefit of $133 million associated with the one-time transition tax on our historical foreign earnings and the adjustment of deferred tax balances to the lower corporate tax rate.

[0001045810-18-000010:mdna:20]
Net income and net income per diluted share for fiscal year 2018 were $3.05 billion and $4.82, respectively, up 83% and 88%, respectively, from a year earlier, fueled by strong revenue growth and improved gross and operating margins.

[0001045810-18-000010:mdna:21]
We returned $1.25 billion to shareholders in fiscal year 2018 through a combination of $909 million in share repurchases and $341 million in quarterly cash dividends. In November 2017, we declared an increase in our quarterly cash dividend to $0.15 per share from $0.14 per share. For fiscal year 2019, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000010:mdna:22]
Cash, cash equivalents and marketable securities were $7.11 billion as of January 28, 2018, compared with $6.80 billion as of January 29, 2017. The increase was primarily related to the increase in operating income.

[0001045810-18-000010:mdna:23]
GPU Business

[0001045810-18-000010:mdna:24]
During fiscal year 2018, we released many new gaming GPU products based on our new NVIDIA Pascal architecture, including GeForce GTX 1070 Ti, 1080 Ti, and TITAN Xp. We also announced gaming laptops using the Max-Q design, which are 3x faster and 3x thinner than previous-generation gaming laptops, and enhanced GeForce Experience with new tools, including NVIDIA Freestyle for customizing gameplay and an updated interface for the NVIDIA Ansel™ photo mode, as well as new titles including PlayerUnknown's Battleground and Fortnite that support NVIDIA ShadowPlay™ Highlights for capturing gaming achievements.

[0001045810-18-000010:mdna:25]
For our professional visualization platform, we opened early access to NVIDIA Holodeck, and launched the Quadro Virtual Data Center Workstation; introduced Project Holodeck, a photorealistic, collaborative VR environment; launched external GPU support for creative professionals; and released the NVIDIA Optix 5.0 and NVIDIA VRWorks 360 Video software development kits.

[0001045810-18-000010:mdna:26]
For our datacenter platform, we announced that NVIDIA Tesla V100 GPU accelerators are available through virtually every major computer maker and have been chosen by nearly every major cloud provider to deliver AI and HPC. We added 34 GPU-accelerated systems to the Top 500 supercomputer list, bringing the total number of systems relying on NVIDIA GPUs to 87, announced partnerships to further AI in key vertical industries, and launched the NVIDIA GPU Cloud container registry to support scientists using HPC applications and AI researchers using desktop GPUs.

[0001045810-18-000010:mdna:27]
Tegra Processor Business

[0001045810-18-000010:mdna:28]
During fiscal year 2018, for the automotive market, we announced the NVIDIA DRIVE AI self-driving platform, which enables automakers and Tier-1 suppliers to accelerate production of automated and autonomous vehicles, the NVIDIA DRIVE Xavier autonomous machine processor to power the NVIDIA DRIVE software stack, and NVIDIA DRIVE PX Pegasus, an auto-grade AI computer designed to enable driverless robotaxis without steering wheels, pedals or mirrors. We also announced several new partnerships aimed at getting AI-powered cars, trucks and commercial vehicles on the road, including partnerships with Aurora, Autoliv, Baidu, Bosch, Continental, Mercedes-Benz, Uber, Volkswagen, Volvo, Toyota, and ZF.

[0001045810-18-000010:mdna:29]
In addition, we introduced NVIDIA Jetson TX2, a high-performance, low-power computer platform for delivering AI at the edge, with deep learning and computer vision capabilities for robots, drones and smart cameras, the NVIDIA Isaac robot simulator for training intelligent machines in simulated real-world conditions before deployment, and the NVIDIA Metropolis platform, used by more than 50 partners to make cities safer and smarter by applying deep learning to surveillance video streams.

[0001045810-18-000010:mdna:30]
Critical Accounting Policies and Estimates

[0001045810-18-000010:mdna:31]
Management’s discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, inventories, income taxes, goodwill, cash equivalents and marketable securities, stock-based compensation, and litigation, investigation and settlement costs and other contingencies. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities.

[0001045810-18-000010:mdna:32]
We believe the following critical accounting policies affect our significant judgments and estimates used in the preparation of our consolidated financial statements. Our management has discussed the development and selection of these critical accounting policies and estimates with the Audit Committee of our Board of Directors. The Audit Committee has reviewed our disclosures relating to our critical accounting policies and estimates in this Annual Report on Form 10-K.

[0001045810-18-000010:mdna:33]
Revenue Recognition

[0001045810-18-000010:mdna:34]
Product Revenue

[0001045810-18-000010:mdna:35]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured.

[0001045810-18-000010:mdna:36]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor, as we typically find that over 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents less than 0.5% of total revenue.

[0001045810-18-000010:mdna:37]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to our partners that are earmarked for market segment development and expansion and are typically designed to support our partners’ activities while also promoting NVIDIA products. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed.

[0001045810-18-000010:mdna:38]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-18-000010:mdna:39]
License and Development Revenue

[0001045810-18-000010:mdna:40]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete the project. We periodically evaluate the actual status of each project to ensure that the estimates to complete each contract remain accurate. Revenue recognized in any period is dependent on our progress toward completion of projects in progress. Significant management judgment and discretion are used to estimate total cost. Any changes in or deviations from these estimates could have a material effect on the amount of revenue we recognize in any period.

[0001045810-18-000010:mdna:41]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-18-000010:mdna:42]
Refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:43]
Inventories

[0001045810-18-000010:mdna:44]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or net realizable value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions.

[0001045810-18-000010:mdna:45]
Situations that may result in excess or obsolete inventory include changes in business and economic conditions, changes in market conditions, sudden and significant decreases in demand for our products, inventory obsolescence because of changing technology and customer requirements, failure to estimate customer demand properly, or unexpected competitive pricing actions by our competition. In addition, cancellation or deferral of customer purchase orders could result in our holding excess inventory.

[0001045810-18-000010:mdna:46]
The overall net effect on our gross margin from inventory provisions and sales of items previously written down was insignificant in fiscal years 2018 and 2017 and an unfavorable impact of 1.6% in fiscal year 2016. The charges we took to cost of sales for inventory provisions during these fiscal years were primarily related to the write-off of excess quantities of products whose inventory levels were higher than our updated forecasts of future demand for those products. As a fabless semiconductor company, we must make commitments to purchase inventory based on forecasts of future customer demand. In doing so, we must account for our third-party manufacturers' lead times and constraints. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001045810-18-000010:mdna:47]
Refer to the Gross Profit and Gross Margin discussion below in this Management's Discussion and Analysis for further discussion.

[0001045810-18-000010:mdna:48]
Income Taxes

[0001045810-18-000010:mdna:49]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-18-000010:mdna:50]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-18-000010:mdna:51]
As of January 28, 2018, we had a valuation allowance of $469 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-18-000010:mdna:52]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-18-000010:mdna:53]
The TCJA, which was enacted in December 2017, significantly changes U.S. tax law, including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, a requirement for companies to pay a one-time transition tax on the earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign-source earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us in the fourth quarter of fiscal year 2018, while other provisions will impact us beginning in fiscal year 2019. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information specific to accounting for income taxes and the impacts from the enactment of the TCJA.

[0001045810-18-000010:mdna:54]
Goodwill

[0001045810-18-000010:mdna:55]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier, if indicators of potential impairment exist, using either a qualitative or a quantitative assessment. Our impairment review process compares the fair value of the reporting unit in which the goodwill resides to its carrying value. We have identified two reporting units, GPU and Tegra Processor, for the purposes of completing our goodwill analysis. Goodwill assigned to the GPU and Tegra Processor reporting units as of January 28, 2018 was $210 million and $408 million, respectively. Determining the fair value of a reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. We also make judgments and assumptions in allocating assets and liabilities to each of our reporting units. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain.

[0001045810-18-000010:mdna:56]
We use the quantitative assessment to test goodwill for impairment for each reporting unit. In applying the fair value based test of each reporting unit, the results from the income approach and the market approach were equally weighted. These valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, terminal or residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-18-000010:mdna:57]
During the fourth quarter of fiscal year 2018, we concluded that there was no impairment of our goodwill. The fair values of our GPU and Tegra Processor reporting units significantly exceeded their respective carrying values. As such, even the application of a hypothetical 10% decrease to the fair value of each reporting unit would not have resulted in the fair value of either reporting unit being less than its carrying value.

[0001045810-18-000010:mdna:58]
Refer to Note 4 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:59]
Cash Equivalents and Marketable Securities

[0001045810-18-000010:mdna:60]
Cash equivalents consist of financial instruments which are readily convertible into cash and have original maturities of three months or less at the time of acquisition. Marketable securities consist primarily of highly liquid investments with maturities greater than three months when purchased. We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments.

[0001045810-18-000010:mdna:61]
We performed an impairment review of our investment portfolio as of January 28, 2018. We concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of January 28, 2018.

[0001045810-18-000010:mdna:62]
Refer to Notes 6 and 7 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:63]
Stock-based Compensation

[0001045810-18-000010:mdna:64]
Our stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP. The number of PSUs and market-based PSUs that will ultimately be awarded is contingent on the Company’s level of achievement compared with the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year.

[0001045810-18-000010:mdna:65]
Refer to Notes 1 and 2 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:66]
Litigation, Investigation and Settlement Costs

[0001045810-18-000010:mdna:67]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigations, and we cannot be certain that these actions or other third-party claims against us will be resolved without costly litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such

[0001045810-18-000010:mdna:68]
events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-18-000010:mdna:69]
Results of Operations

[0001045810-18-000010:mdna:70]
The following table sets forth, for the periods indicated, certain items in our Consolidated Statements of Income expressed as a percentage of revenue.

[0001045810-18-000010:mdna:71]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 40.1 |  |  | 41.2 |  |  | 43.9 |  |
| Gross profit | 59.9 |  |  | 58.8 |  |  | 56.1 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 18.5 |  |  | 21.2 |  |  | 26.6 |  |
| Sales, general and administrative | 8.4 |  |  | 9.6 |  |  | 12.0 |  |
| Restructuring and other charges | — |  |  | — |  |  | 2.6 |  |
| Total operating expenses | 26.9 |  |  | 30.8 |  |  | 41.2 |  |
| Income from operations | 33.0 |  |  | 28.0 |  |  | 14.9 |  |
| Interest income | 0.7 |  |  | 0.8 |  |  | 0.8 |  |
| Interest expense | (0.6 | ) |  | (0.8 | ) |  | (0.9 | ) |
| Other, net | (0.2 | ) |  | (0.4 | ) |  | 0.1 |  |
| Total other income (expense) | (0.1 | ) |  | (0.4 | ) |  | — |  |
| Income before income tax expense | 32.9 |  |  | 27.6 |  |  | 14.9 |  |
| Income tax expense | 1.5 |  |  | 3.5 |  |  | 2.6 |  |
| Net income | 31.4 | % |  | 24.1 | % |  | 12.3 | % |

[0001045810-18-000010:mdna:72]
Revenue

[0001045810-18-000010:mdna:73]
Revenue by Reportable Segments

[0001045810-18-000010:mdna:74]
|  | Year Ended |  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | $Change |  | %Change |  | January 29, 2017 |  | January 31, 2016 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| GPU | $ | 8,137 |  |  | $ | 5,822 |  |  | $ | 2,315 |  |  | 40 | % |  | $ | 5,822 |  |  | $ | 4,187 |  |  | $ | 1,635 |  |  | 39 | % |
| Tegra Processor | 1,534 |  |  | 824 |  |  | 710 |  |  | 86 | % |  | 824 |  |  | 559 |  |  | 265 |  |  | 47 | % |
| All Other | 43 |  |  | 264 |  |  | (221 | ) |  | (84 | )% |  | 264 |  |  | 264 |  |  | — |  |  | — | % |
| Total | $ | 9,714 |  |  | $ | 6,910 |  |  | $ | 2,804 |  |  | 41 | % |  | $ | 6,910 |  |  | $ | 5,010 |  |  | $ | 1,900 |  |  | 38 | % |

[0001045810-18-000010:mdna:75]
GPU Business. GPU business revenue increased by 40% in fiscal year 2018 compared to fiscal year 2017 led by growth in gaming, datacenter and professional visualization. Revenue from sales of GeForce GPU products for gaming increased over 20%, reflecting continued strong demand for our Pascal-based GPU products. Datacenter revenue, including Tesla, GRID and DGX, increased 133%, reflecting strong demand from hyperscale and cloud customers for deep learning training and accelerated GPU computing as well as demand for HPC, DGX AI supercomputing and GRID virtualization platforms. Revenue from Quadro GPUs for professional visualization increased by 12% due primarily to higher sales in both high end desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs increased by over 90% due primarily to strong demand for GPU products targeted for cryptocurrency mining.

[0001045810-18-000010:mdna:76]
GPU business revenue increased by 39% in fiscal year 2017 compared to fiscal year 2016. This increase was primarily due to increased revenue from our GeForce GPU gaming and datacenter platforms. Sales of high-end GeForce GPU products for gaming increased over 40%, reflecting a combination of continued strength in PC gaming and strong demand for our recent Pascal-based GPU products. Datacenter revenue, including our Tesla, NVIDIA GRID, and DGX-1 brands, increased by 145%, reflecting strong demand for deep learning training for AI, cloud, accelerated, and virtualized

[0001045810-18-000010:mdna:77]
computing and initial DGX-1 sales. Revenue from Quadro GPUs for professional visualization increased 11% due primarily to higher sales in high end desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to fiscal year 2016.

[0001045810-18-000010:mdna:78]
Tegra Processor Business.  Tegra Processor business revenue increased by 86% in fiscal year 2018 compared to fiscal year 2017. This was driven by an increase of over 300% in revenue from SOC modules for gaming platforms and development services, and an increase of 15% in automotive revenue, primarily from infotainment modules, DRIVE PX platforms and development agreements for self-driving cars.

[0001045810-18-000010:mdna:79]
Tegra Processor business revenue increased by 47% in fiscal year 2017 compared to fiscal year 2016. This was driven by an increase of over 50% in sales of Tegra products and services serving automotive systems and an increase of almost 50% in gaming development platforms and services compared to fiscal year 2016.

[0001045810-18-000010:mdna:80]
All Other. Our patent license agreement with Intel concluded in the first quarter of fiscal year 2018. For fiscal year 2018, we recognized related revenue of $43 million, down from $264 million for fiscal years 2017 and 2016.

[0001045810-18-000010:mdna:81]
Concentration of Revenue

[0001045810-18-000010:mdna:82]
Revenue from sales to customers outside of the United States and Other Americas accounted for 79%, 80%, and 79% of total revenue for fiscal years 2018, 2017, and 2016, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-18-000010:mdna:83]
No single customer represented more than 10% of total revenue for fiscal year 2018. In fiscal years 2017 and 2016, we had one customer that represented 12% and 11% of our total revenue, respectively.

[0001045810-18-000010:mdna:84]
Gross Profit and Gross Margin

[0001045810-18-000010:mdna:85]
Gross profit consists of total revenue, net of allowances, less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions, memory and component costs, and shipping costs. Cost of revenue also includes development costs for license and service arrangements and stock-based compensation related to personnel associated with manufacturing.

[0001045810-18-000010:mdna:86]
Our overall gross margin was 59.9%, 58.8%, and 56.1% for fiscal years 2018, 2017, and 2016, respectively. These increases were driven primarily by a favorable shift in mix, the growth of our GeForce gaming GPU revenue, and the growth of our datacenter revenue for cloud, deep learning, AI, and graphics virtualization. The increase in fiscal year 2018 was partially offset by the conclusion of our patent license agreement with Intel in the first quarter of fiscal year 2018.

[0001045810-18-000010:mdna:87]
Charges to cost of sales for inventory provisions totaled $48 million, $62 million, and $112 million for fiscal years 2018, 2017, and 2016, respectively. Sales of inventory that was previously written-off or written-down totaled $35 million, $51 million, and $32 million for fiscal years 2018, 2017, and 2016, respectively. As a result, the overall net effect on our gross margin from inventory provisions and sales of items previously written down was insignificant for fiscal years 2018 and 2017, and an unfavorable impact of 1.6% for fiscal year 2016.

[0001045810-18-000010:mdna:88]
A discussion of our gross margin results for each of our reportable segments is as follows:

[0001045810-18-000010:mdna:89]
GPU Business. The gross margin of our GPU business increased during fiscal year 2018 when compared to fiscal year 2017, primarily due to strong sales of our GeForce gaming GPU products and revenue growth in datacenter, including Tesla, GRID and DGX, for cloud, deep learning, AI, and graphics virtualization. The gross margin of our GPU business increased during fiscal year 2017 when compared to fiscal year 2016 primarily due to product mix resulting from increased sales of our gaming, datacenter, and professional visualization GPU products, as well as a continued decrease in sales volumes of lower margin PC OEM products.

[0001045810-18-000010:mdna:90]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during fiscal year 2018 when compared to fiscal year 2017, primarily due to revenue growth in gaming development platforms and automotive. The gross margin of our Tegra Processor business increased during fiscal year 2017 when compared to fiscal year 2016, primarily due to fewer inventory provisions, and the absence of the warranty charge associated with the SHIELD tablet product recall during fiscal year 2016.

[0001045810-18-000010:mdna:91]
Operating Expenses

[0001045810-18-000010:mdna:92]
|  | Year Ended |  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | $Change |  | %Change |  | January 29,2017 |  | January 31, 2016 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| Research and development expenses | $ | 1,797 |  |  | $ | 1,463 |  |  | $ | 334 |  |  | 23 | % |  | $ | 1,463 |  |  | $ | 1,331 |  |  | $ | 132 |  |  | 10 | % |
| % of net revenue | 18.5 | % |  | 21.2 | % |  |  |  |  |  | 21.2 | % |  | 26.6 | % |  |  |  |  |
| Sales, general and administrative expenses | 815 |  |  | 663 |  |  | 152 |  |  | 23 | % |  | 663 |  |  | 602 |  |  | 61 |  |  | 10 | % |
| % of net revenue | 8.4 | % |  | 9.6 | % |  |  |  |  |  | 9.6 | % |  | 12.0 | % |  |  |  |  |
| Restructuring and other charges | — |  |  | 3 |  |  | (3 | ) |  | (100 | )% |  | 3 |  |  | 131 |  |  | (128 | ) |  | (98 | )% |
| % of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | 2.6 | % |  |  |  |  |
| Total operating expenses | $ | 2,612 |  |  | $ | 2,129 |  |  | $ | 483 |  |  | 23 | % |  | $ | 2,129 |  |  | $ | 2,064 |  |  | $ | 65 |  |  | 3 | % |

[0001045810-18-000010:mdna:93]
Research and Development

[0001045810-18-000010:mdna:94]
Research and development expenses increased by 23% in fiscal year 2018 compared to fiscal year 2017 and increased 10% in fiscal year 2017 compared to fiscal year 2016, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000010:mdna:95]
Sales, General and Administrative

[0001045810-18-000010:mdna:96]
Sales, general and administrative expenses increased by 23% in fiscal year 2018 compared to fiscal year 2017 and increased by 10% in fiscal year 2017 compared to fiscal year 2016, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense. Offsetting these increases was a decrease in outside professional fees of $11 million in fiscal year 2018 and $57 million in fiscal year 2017 resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-18-000010:mdna:97]
Restructuring and Other Charges

[0001045810-18-000010:mdna:98]
In fiscal year 2016, we began to wind down our Icera modem operations. As a result, our operating expenses for fiscal year 2016 included $131 million of restructuring and other charges.

[0001045810-18-000010:mdna:99]
Total Other Income (Expense)

[0001045810-18-000010:mdna:100]
Interest Income and Interest Expense

[0001045810-18-000010:mdna:101]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $69 million, $54 million, and $39 million in fiscal years 2018, 2017, and 2016, respectively. The increase in interest income was primarily due to higher average invested balances and higher yields on our investments from a rising interest rate environment.

[0001045810-18-000010:mdna:102]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016, and the Convertible Notes issued in December 2013. Interest expense was $61 million, $58 million, and $47 million in fiscal years 2018, 2017, and 2016.

[0001045810-18-000010:mdna:103]
Other, Net

[0001045810-18-000010:mdna:104]
Other, net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, losses on early conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Net other expense was $22 million and $25 million in fiscal years 2018 and 2017, respectively, and was insignificant in fiscal year 2016. The net other expense in fiscal years 2018 and 2017 was primarily due to losses on early conversions of the Convertible Notes.

[0001045810-18-000010:mdna:105]
Income Taxes

[0001045810-18-000010:mdna:106]
The TCJA, which was enacted in December 2017, significantly changes U.S. tax law, including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, a requirement for companies to pay a one-time transition tax on the earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign-source earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us in the fourth quarter of fiscal year 2018, while other provisions will impact us beginning in fiscal year 2019.

[0001045810-18-000010:mdna:107]
The corporate tax reduction is effective as of January 1, 2018. Since we operate on a fiscal year rather than a calendar year, we are subject to transitional tax rules. As a result, our fiscal year 2018 federal statutory rate is a blended rate of 33.9%. The change in the statutory tax rate from 35% to 33.9% for fiscal year 2018 did not have a significant impact on the effective tax rate.

[0001045810-18-000010:mdna:108]
We recognized income tax expense of $149 million, $239 million and $129 million for fiscal years 2018, 2017, and 2016, respectively. Our annual effective tax rate was 4.7%, 12.5%, and 17.3% for fiscal years 2018, 2017, and 2016, respectively. The decrease in our effective tax rate in fiscal year 2018 as compared to fiscal years 2017 and 2016 was primarily due to the provisional impact of the recent tax law changes and the recognition of excess tax benefits related to stock-based compensation. The decrease in our effective tax rate in fiscal year 2017 as compared to fiscal year 2016 was primarily due to the recognition of excess tax benefits from our adoption of a new accounting standard in fiscal year 2017 related to the simplification of certain aspects of stock-based compensation accounting.

[0001045810-18-000010:mdna:109]
Our effective tax rate  for fiscal year 2018 was lower than the blended U.S. federal statutory rate of 33.9% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition of the U.S. federal research tax credit, the provisional impact of the recent tax law changes in 2018, and excess tax benefits related to stock-based compensation.

[0001045810-18-000010:mdna:110]
Our effective tax rate  for fiscal years 2017 and 2016 was lower than U.S. federal statutory tax rate of 35% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition in those fiscal years of the U.S. federal research tax credit, favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of the applicable statutes of limitations, and adoption of an accounting standard related to stock-based compensation in fiscal year 2017.

[0001045810-18-000010:mdna:111]
For fiscal year 2018, we recognized provisional amounts for the tax effects of the TCJA, which were included as components of income tax expense and reflected in our effective tax rate for fiscal year 2018. We will continue to assess the impact of the recently enacted tax law on our business and our consolidated financial statements. The final impact of the TCJA recorded by us may vary materially from the provisional impact recorded due to a number of uncertainties and factors, including the need for further guidance and clarification of the new law by U.S. federal and state tax authorities and the need for further guidance on the income tax accounting.

[0001045810-18-000010:mdna:112]
In addition to the impact on fiscal year 2018, the TCJA also establishes new tax laws that will be effective for our fiscal year 2019. While each of these new tax laws is expected to have some impact on our tax expense for fiscal year 2019 and future periods, we expect the provision designed to tax the low-taxed income of foreign subsidiaries to have the most significant impact.

[0001045810-18-000010:mdna:113]
Because of the complexity of the new tax laws on the low-taxed income of certain foreign subsidiaries, we are continuing to evaluate this provision of the TCJA and the application of related accounting standards. Based on recent deliberations of the Financial Accounting Standards Board, or FASB, we expect to be allowed to make an accounting policy choice of either (1) treating taxes due on future taxable income in the U.S. as a current-period expense when incurred or (2) factoring such amounts into our measurement of deferred taxes. Our selection of an accounting policy will depend, in part, on our analysis of relevant facts to determine what the expected impact would be under each method.

[0001045810-18-000010:mdna:114]
Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:115]
Liquidity and Capital Resources

[0001045810-18-000010:mdna:116]
|  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Cash and cash equivalents | $ | 4,002 |  |  | $ | 1,766 |  |
| Marketable securities | 3,106 |  |  | 5,032 |  |
| Cash, cash equivalents, and marketable securities | $ | 7,108 |  |  | $ | 6,798 |  |

[0001045810-18-000010:mdna:117]
|  | Year Ended |
|  | January 28, 2018 |  | January 29, 2017 |  | January 31, 2016 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 3,502 |  |  | $ | 1,672 |  |  | $ | 1,175 |  |
| Net cash provided by (used in) investing activities | $ | 1,278 |  |  | $ | (793 | ) |  | $ | (400 | ) |
| Net cash provided by (used in) financing activities | $ | (2,544 | ) |  | $ | 291 |  |  | $ | (676 | ) |

[0001045810-18-000010:mdna:118]
As of January 28, 2018, we had $7.11 billion in cash, cash equivalents and marketable securities, an increase of $310 million from the end of fiscal year 2017. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions. Our portfolio managers are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-18-000010:mdna:119]
Cash provided by operating activities increased in fiscal year 2018 compared to fiscal year 2017 and in fiscal year 2017 compared to fiscal year 2016, primarily due to higher net income and changes in working capital.

[0001045810-18-000010:mdna:120]
Cash provided by investing activities increased in fiscal year 2018 compared to fiscal year 2017, primarily due to a reduction in purchases of marketable securities, partially offset by the purchase of our previously-financed Santa Clara campus building. Cash used in investing activities for fiscal year 2017 increased from fiscal year 2016, primarily due to higher purchases of property and equipment and intangible assets and lower proceeds from sales and maturities of marketable securities.

[0001045810-18-000010:mdna:121]
Cash used in financing activities increased in fiscal year 2018 compared to fiscal year 2017, primarily due to cash provided from the issuance of $2.00 billion of Notes in fiscal year 2017 as well as higher repayments of Convertible Notes, tax payments related to employee stock plans, share repurchases and dividend payments in fiscal year 2018. Cash provided by financing activities in fiscal year 2017 increased from fiscal year 2016, primarily due to the $2.00 billion of Notes issued in September 2016, partially offset by the repayments of Convertible Notes and $1.00 billion of capital return to shareholders in the form of share repurchases and dividend payments.

[0001045810-18-000010:mdna:122]
Liquidity

[0001045810-18-000010:mdna:123]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of January 28, 2018 and January 29, 2017, we had $7.11 billion and $6.80 billion, respectively, in cash, cash equivalents and marketable securities. Our marketable securities consist of debt securities issued by the United States government and its agencies, highly rated corporations and financial institutions, asset-backed issuers, mortgage-backed securities by government-sponsored enterprises, and foreign government entities. These marketable securities are denominated in United States dollars. Refer to Critical Accounting Policies and Estimates in Part II, Item 7, Quantitative and Qualitative Disclosures About Market Risk in Part II, Item 7A and Note 6 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:124]
The recent TCJA that was signed into law in December 2017 subjects U.S. companies to a one-time transition tax on certain earnings of foreign subsidiaries. Our reasonable estimate of the one-time transition tax that resulted from enactment of the TCJA is $401 million, which will be payable in eight annual installments. Accordingly, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of January 28, 2018 will now be available for use in the U.S. without incurring additional U.S. federal income taxes. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-18-000010:mdna:125]
32

[0001045810-18-000010:mdna:126]
Capital Return to Shareholders

[0001045810-18-000010:mdna:127]
During fiscal year 2018, we repurchased a total of 6 million shares for $909 million and paid $341 million in cash dividends to our shareholders. As a result, we returned $1.25 billion to shareholders during fiscal year 2018.

[0001045810-18-000010:mdna:128]
For fiscal year 2019, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000010:mdna:129]
Our cash dividend program and the payment of future cash dividends under that program are subject to our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders. Refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-18-000010:mdna:130]
Notes Due 2021 and Notes Due 2026

[0001045810-18-000010:mdna:131]
In fiscal year 2017, we issued $1.00 billion of the Notes Due 2021 and $1.00 billion of the Notes Due 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discounts and issuance costs.

[0001045810-18-000010:mdna:132]
Convertible Notes

[0001045810-18-000010:mdna:133]
As of January 28, 2018, we had $15 million of Convertible Notes outstanding. Refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-18-000010:mdna:134]
Revolving Credit Facility

[0001045810-18-000010:mdna:135]
In fiscal year 2017, we entered into a Credit Agreement under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021. The Credit Agreement also permits us to obtain additional revolving loan commitments and/or commitments to issue letters of credit of up to $425 million, subject to certain conditions. As of January 28, 2018, we had not borrowed any amounts and were in compliance with all related covenants under the Credit Agreement.

[0001045810-18-000010:mdna:136]
Commercial Paper

[0001045810-18-000010:mdna:137]
In December 2017, we established a commercial paper program to support general corporate purposes. Under the program, we can issue up to $575 million in commercial paper. As of January 28, 2018, there was no commercial paper outstanding.

[0001045810-18-000010:mdna:138]
Operating Capital and Capital Expenditure Requirements

[0001045810-18-000010:mdna:139]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating and capital expenditure requirements for at least the next twelve months.

[0001045810-18-000010:mdna:140]
Off-Balance Sheet Arrangements

[0001045810-18-000010:mdna:141]
In January 2018, we terminated the off-balance sheet, build-to-suit operating lease financing arrangement related to our new Santa Clara campus building and exercised our option to purchase the property for $335 million, which was recorded in Property and equipment, net, in our Consolidated Balance Sheet. Refer to Note 12 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-18-000010:mdna:142]
Contractual Obligations

[0001045810-18-000010:mdna:143]
The following table summarizes our contractual obligations as of January 28, 2018:

[0001045810-18-000010:mdna:144]
|  | Payment Due By Period |
| Contractual Obligations | Total |  | Less than1 Year |  | 1-3 Years |  | 4-5 Years |  | More than5 Years |  | All Other |
|  | (In millions) |
| Long-term debt (1) | $ | 2,376 |  |  | $ | 54 |  |  | $ | 162 |  |  | $ | 1,064 |  |  | $ | 1,096 |  |  | $ | — |  |
| Inventory purchase obligations | 1,331 |  |  | 1,331 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Transition tax payable (2) | 401 |  |  | 32 |  |  | 64 |  |  | 64 |  |  | 241 |  |  | — |  |
| Uncertain tax positions, interest and penalties (3) | 190 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 190 |  |
| Operating leases | 246 |  |  | 63 |  |  | 103 |  |  | 69 |  |  | 11 |  |  | — |  |
| Capital purchase obligations | 135 |  |  | 135 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| 1.00% Convertible Notes (4) | 15 |  |  | 15 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total contractual obligations | $ | 4,694 |  |  | $ | 1,630 |  |  | $ | 329 |  |  | $ | 1,197 |  |  | $ | 1,348 |  |  | $ | 190 |  |

[0001045810-18-000010:mdna:145]
| (1) | Represents the aggregate principal amount of $2.00 billion and anticipated interest payments of $376 million for the Notes. Refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K. |

[0001045810-18-000010:mdna:146]
| (2) | Represents our reasonable estimate of a provisional tax payable amount of $401 million for the one-time transition tax that resulted from enactment of the TCJA in fiscal year 2018, which will be payable in eight annual installments. The first installment of $32 million is classified as a current income tax payable. The installment amounts will be equal to 8% of the total liability, payable in fiscal years 2019 through 2023, 15% in fiscal year 2024, 20% in fiscal year 2025 and 25% in fiscal year 2026. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K, for additional information about the one-time transition tax. |

[0001045810-18-000010:mdna:147]
| (3) | Represents unrecognized tax benefits of $190 million which consists of $175 million and the related interest and penalties of $15 million recorded in non-current income tax payable as of January 28, 2018. We are unable to reasonably estimate the timing of any potential tax liability or interest/penalty payments in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. |

[0001045810-18-000010:mdna:148]
| (4) | Represents the aggregate principal amount of $15 million for the Convertible Notes. Refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K. |

[0001045810-18-000010:mdna:149]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000010:mdna:150]
Refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a discussion of adoption of new and recently issued accounting pronouncements.
