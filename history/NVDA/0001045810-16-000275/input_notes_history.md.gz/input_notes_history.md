# NVDA note change history — 0001045810-15-000173 → 0001045810-16-000275


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-25):
[0001045810-16-000275:note_history:1]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.
  (was, 2015-11-18, similarity 0.9789):
[0001045810-15-000173:note_history:1]
In the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

- added (2016-05-25):
[0001045810-16-000275:note_history:2]
In September 2014, NVIDIA filed complaints against Qualcomm, Inc. and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing. In November 2014, Samsung filed complaints against NVIDIA in the ITC and the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed certain patents.

- added (2016-05-25):
[0001045810-16-000275:note_history:3]
NVIDIA and Samsung, and NVIDIA and Qualcomm, also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office.

- added (2016-05-25):
[0001045810-16-000275:note_history:4]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941; the motion has not yet been granted. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party.

- added (2016-05-25):
[0001045810-16-000275:note_history:5]
NVIDIA’s dismissals on May 11, 2016 and May 12, 2016 also terminated its claims against Qualcomm.

- added (2016-05-25):
[0001045810-16-000275:note_history:6]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. The Initial Determination is expected to become the Final Determination of the ITC on or before June 9, 2016. Pursuant to the license agreement, we paid Advanced Silicon Technologies $16 million during the three months ended May 1, 2016, of which $6 million was recorded as a patent-related intangible asset and $10 million was recorded as a charge to cost of revenue.

- added (2016-05-25):
[0001045810-16-000275:note_history:7]
We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2016-05-25):
[0001045810-15-000173:note_history:8]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to exclude importation of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures, or the Accused Products. On October 6, 2014, the ITC instituted an investigation of NVIDIA’s claim. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the seven patents at issue. In June 2015, NVIDIA moved to terminate all asserted claims on four patents and these motions were granted. The ITC held an evidentiary hearing on certain asserted claims of the three remaining patents from June 22 through June 26, 2015. On October 9, 2015, the ITC Administrative Law Judge rendered an initial determination that importation of the Samsung Accused Products did not violate U.S. law. NVIDIA is currently seeking review of the decision by the full commission of the ITC. The commission will decide whether to review parts of the initial determination on or before December 14, 2015 and the target date for the final decision is February 10, 2016.

- removed (2016-05-25):
[0001045810-15-000173:note_history:9]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm exercised their statutory right to stay the Delaware proceedings in light of the pending ITC action and the court granted the motion to stay on October 23, 2014.

- removed (2016-05-25):
[0001045810-15-000173:note_history:10]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung amended its complaint twice, first on December 19, 2014, and then on April 10, 2015, without changing its legal claims. Samsung seeks monetary damages and certain injunctive relief as to some of the asserted patents. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction preventing it from infringing two of the asserted patents and those patents were dismissed from the case with prejudice. Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015. On October 15, 2015, NVIDIA’s Motion for Entry of Judgment of Noninfringement was granted as to one of Samsung’s patents. Five patents currently asserted against NVIDIA remain and a jury trial is currently scheduled to begin January 19, 2016.

- removed (2016-05-25):
[0001045810-15-000173:note_history:11]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents and seeking an exclusion order barring importation of NVIDIA products alleged to infringe Samsung’s patents. On December 23, 2014, the ITC instituted an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case. A hearing on Samsung’s three remaining patents was held from August 18 through August 21, 2015. Post-hearing briefing is complete and the Administrative Law Judge is scheduled to issue his initial determination by December 22, 2015. The target date for the final determination by the ITC is April 22, 2016.

- removed (2016-05-25):
[0001045810-15-000173:note_history:12]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed eleven requests for inter partes review on eight of Samsung’s asserted patents. Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA, and Qualcomm has filed three additional requests for inter partes review on two patents asserted by NVIDIA. The United States Patent and Trademark Office has, to date, decided to review three patents owned by NVIDIA, and three patents owned by Samsung. All other requests are currently pending.

- removed (2016-05-25):
[0001045810-15-000173:note_history:13]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 25, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-25):
[0001045810-16-000275:note_history:14]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The first quarter of fiscal years 2017 and 2016 were both 13-week quarters.
  (was, 2015-11-18, similarity 0.9737):
[0001045810-15-000173:note_history:14]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 was a 52-week year. The third quarters of fiscal years 2016 and 2015 were both 13-week quarters.

- changed (2016-05-25):
[0001045810-16-000275:note_history:15]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.
  (was, 2015-11-18, similarity 0.9528):
[0001045810-15-000173:note_history:15]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All material inter-company balances and transactions have been eliminated in consolidation.

- changed (2016-05-25):
[0001045810-16-000275:note_history:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2015-11-18, similarity 0.9871):
[0001045810-15-000173:note_history:16]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- added (2016-05-25):
[0001045810-16-000275:note_history:17]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting, including income taxes at settlement, classifications in the statement of cash flows, forfeitures and net settlements, and will be effective in our first quarter of fiscal year 2018. Early adoption is permitted in any annual or interim period. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements.

- added (2016-05-25):
[0001045810-16-000275:note_history:18]
In February 2016, FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements, however, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.

- added (2016-05-25):
[0001045810-16-000275:note_history:19]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). In March, April and May 2016, the FASB issued additional updates to the new revenue standard relating to reporting revenue on a gross versus net basis, identifying performance obligations and licensing arrangements, and narrow-scope improvements and practical expedients, respectively. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.

- removed (2016-05-25):
[0001045810-15-000173:note_history:20]
Restructuring and Other Charges

- removed (2016-05-25):
[0001045810-15-000173:note_history:21]
Our restructuring and other charges primarily comprise of employee severance and related costs, write-down of assets, and other exit costs. The severance and related costs could include one-time termination benefits as well as certain statutory termination benefits or employee terminations under ongoing benefit arrangements. One-time termination benefits are recognized as a liability at estimated fair value when the approved plan of termination has been communicated to employees, unless employees must provide future service, in which case the benefits are recognized ratably over the future service period. Ongoing termination benefits arrangements are recognized as a liability at estimated fair value when the amount of such benefits becomes estimable and payment is probable. Any contract termination costs are recognized at estimated fair value when we terminate the contract in accordance with the contract terms. Other associated costs are recognized in the period the liability is incurred.

- removed (2016-05-25):
[0001045810-15-000173:note_history:22]
In July 2015, the Financial Accounting Standards Board, or FASB, issued an accounting standards update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements.

- removed (2016-05-25):
[0001045810-15-000173:note_history:23]
In April 2015, the FASB issued an accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

- removed (2016-05-25):
[0001045810-15-000173:note_history:24]
In April 2015, the FASB issued an accounting standards update that provides clarification on whether a cloud computing arrangement includes a software license. If a software license is included, the customer should account for the license consistent with its accounting for other software licenses. If a software license is not included, the arrangement should be accounted for as a service contract. The update is effective for reporting periods beginning after December 15, 2015, with early adoption permitted. Companies can elect to adopt the standard update prospectively or retrospectively to arrangements entered into, or materially modified, after the effective date. The update will be effective for us beginning in our first quarter of fiscal year 2017. We expect the adoption of this accounting guidance to result in an increase in software license assets and related depreciation expense, and a corresponding decrease in prepaid service contract assets and related service contract expense in our consolidated financial statements.

- removed (2016-05-25):
[0001045810-15-000173:note_history:25]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-05-25):
[0001045810-16-000275:note_history:26]
The following table presents the carrying amounts of the liability and equity components:

- added (2016-05-25):
[0001045810-16-000275:note_history:27]
|  |  | May 1, |  | January 31, |
|  |  | 2016 |  | 2016 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 39 |  |  | $ | 39 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (79 | ) |  | (87 | ) |
| Net carrying amount |  | $ | 1,421 |  |  | $ | 1,413 |  |

- added (2016-05-25):
[0001045810-16-000275:note_history:28]
(1) As of May 1, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.6 years.

- added (2016-05-25):
[0001045810-16-000275:note_history:29]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

- added (2016-05-25):
[0001045810-16-000275:note_history:30]
|  |  | Three Months Ended |
|  |  | May 1, |  | April 26, |
|  |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 8 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 12 |  |  | $ | 11 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-25):
[0001045810-16-000275:note_history:31]
Convertible Debt
  (was, 2015-11-18, similarity 0.6):
[0001045810-15-000173:note_history:31]
Long-Term Debt

- added (2016-05-25):
[0001045810-16-000275:note_history:32]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of May 1, 2016, the conversion rate has been adjusted to 49.7481 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.1013 per share of common stock) for dividend increases made to that date.

- added (2016-05-25):
[0001045810-16-000275:note_history:33]
We separately accounted for the liability and equity components of the Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

- changed (2016-05-25):
[0001045810-16-000275:note_history:34]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.
  (was, 2015-11-18, similarity 0.9733):
[0001045810-15-000173:note_history:34]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method and an interest rate of 3.15%.

- changed (2016-05-25):
[0001045810-16-000275:note_history:35]
|  |  | May 1, |  | January 31, |
|  |  | 2016 |  | 2016 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 39 |  |  | $ | 39 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (79 | ) |  | (87 | ) |
| Net carrying amount |  | $ | 1,421 |  |  | $ | 1,413 |  |
  (was, 2015-11-18, similarity 0.9829):
[0001045810-15-000173:note_history:35]
|  |  | October 25, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (94 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,406 |  |  | $ | 1,384 |  |

- changed (2016-05-25):
[0001045810-16-000275:note_history:36]
(1) As of May 1, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.6 years.
  (was, 2015-11-18, similarity 0.6822):
[0001045810-15-000173:note_history:36]
(1) As of October 25, 2015, the unamortized debt discount will be amortized over a remaining period of 3.1 years.

- changed (2016-05-25):
[0001045810-16-000275:note_history:37]
|  |  | Three Months Ended |
|  |  | May 1, |  | April 26, |
|  |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 8 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 12 |  |  | $ | 11 |  |
  (was, 2015-11-18, similarity 0.7507):
[0001045810-15-000173:note_history:37]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 22 |  |  | 21 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 33 |  |  | $ | 32 |  |

- added (2016-05-25):
[0001045810-16-000275:note_history:38]
Holders may convert all or any portion of their Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Notes regardless of the foregoing conditions.

- added (2016-05-25):
[0001045810-16-000275:note_history:39]
The price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended January 31, 2016. Therefore, as of January 31, 2016, the conversion threshold had been met and the Notes became convertible at the holders’ option beginning on February 1, 2016 and ending on May 1, 2016. As such, the $1.41 billion carrying value of the Notes as of January 31, 2016 was classified as a current liability and the $87 million difference between the principal amount and the carrying value of the Notes was reclassified from shareholders' equity to convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet as of January 31, 2016.

- added (2016-05-25):
[0001045810-16-000275:note_history:40]
As of May 1, 2016, the Notes continued to be convertible at the holders’ option for the period beginning on May 2, 2016 and ending on July 31, 2016. As such, the $1.42 billion carrying value of the Notes as of May 1, 2016 continued to be classified as a current liability and the $79 million difference between the principal amount and the carrying value of the Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

- added (2016-05-25):
[0001045810-16-000275:note_history:41]
Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the closing price of our common stock on April 29, 2016 (the last trading day of the first quarter of fiscal year 2017) of $35.53, the if-converted value of our Notes exceeded their principal amount by approximately $1.15 billion. As of May 1, 2016, we had received conversion notices for a total of $0.2 million aggregate principal amount of the Notes, for which conversion is expected to be completed in the second quarter of fiscal year 2017. As of May 1, 2016, no conversions had taken place.

- added (2016-05-25):
[0001045810-16-000275:note_history:42]
Note Hedges and Warrants

- added (2016-05-25):
[0001045810-16-000275:note_history:43]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through May 1, 2016, the strike price of the Note Hedges has been adjusted to $20.1013 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion.

- added (2016-05-25):
[0001045810-16-000275:note_history:44]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of May 1, 2016, the strike price was adjusted to $27.0594 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 74 million shares of our common stock.

- removed (2016-05-25):
[0001045810-15-000173:note_history:45]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted earlier in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

- removed (2016-05-25):
[0001045810-15-000173:note_history:46]
As of October 25, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the carrying value of the Notes would be classified as a current liability and the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-05-25):
[0001045810-15-000173:note_history:47]
|  |  | October 25, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (94 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,406 |  |  | $ | 1,384 |  |

- removed (2016-05-25):
[0001045810-15-000173:note_history:48]
(1) As of October 25, 2015, the unamortized debt discount will be amortized over a remaining period of 3.1 years.

- removed (2016-05-25):
[0001045810-15-000173:note_history:49]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

- removed (2016-05-25):
[0001045810-15-000173:note_history:50]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 22 |  |  | 21 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 33 |  |  | $ | 32 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-05-25):
[0001045810-15-000173:note_history:51]
Subsequent Event

- removed (2016-05-25):
[0001045810-15-000173:note_history:52]
On November 9, 2015, as part of our stock repurchase program, we entered into an ASR with an investment bank, under which we made an upfront payment of $135 million to purchase shares of our common stock and received an initial delivery of 3 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
