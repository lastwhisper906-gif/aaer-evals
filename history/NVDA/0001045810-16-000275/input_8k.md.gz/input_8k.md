# NVDA 8-K — 0001045810-16-000243 filed 2016-05-12

## item codes, every 8-K on or before 2016-05-25

- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2016-05-25

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-16-000243:8k_2_02:1]
EX-99.1
2
q117pr.htm
Q1'17 PRESS RELEASE

[0001045810-16-000243:8k_2_02:2]
SEC Exhibit

[0001045810-16-000243:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-16-000243:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2017

[0001045810-16-000243:8k_2_02:5]
| • | Revenue of $1.30 billion, up 13 percent from a year ago - growth across all platforms |

[0001045810-16-000243:8k_2_02:6]
| • | GAAP EPS of $0.33, up 38 percent from a year ago. Non-GAAP EPS of $0.46, up 39 percent |

[0001045810-16-000243:8k_2_02:7]
| • | Sharply growing customer engagements in deep learning |

[0001045810-16-000243:8k_2_02:8]
SANTA CLARA, Calif.-May 12, 2016-NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended May 1, 2016, of $1.30 billion, up 13 percent from $1.15 billion a year earlier, and down 7 percent from $1.40 billion in the previous quarter.

[0001045810-16-000243:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.33, up 38 percent from $0.24 a year ago and down 6 percent from $0.35 in the previous quarter. Non-GAAP earnings per diluted share were $0.46, up 39 percent from $0.33 a year earlier and down 12 percent from $0.52 in the previous quarter.

[0001045810-16-000243:8k_2_02:10]
“We are enjoying growth in all of our platforms - gaming, professional visualization, datacenter and auto,” said Jen-Hsun Huang, co-founder and chief executive officer, NVIDIA. “Accelerating our growth is deep learning, a new computing model that uses the GPU’s massive computing power to learn artificial intelligence algorithms. Its adoption is sweeping one industry after another, driving demand for our GPUs.

[0001045810-16-000243:8k_2_02:11]
“Our new Pascal GPU architecture will give a giant boost to deep learning, gaming and VR. We are excited to bring a new wave of innovations to the markets we serve.  Pascal processors are in full production and will be available later this month,” he said.

[0001045810-16-000243:8k_2_02:12]
Capital Return

[0001045810-16-000243:8k_2_02:13]
During the first quarter, NVIDIA entered into a $500 million accelerated share repurchase agreement and paid $62 million in quarterly cash dividends.

[0001045810-16-000243:8k_2_02:14]
For fiscal 2017, NVIDIA intends to return approximately $1.0 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-16-000243:8k_2_02:15]
NVIDIA will pay its next quarterly cash dividend of $0.115 per share on June 20, 2016, to all shareholders of record on May 26, 2016.

[0001045810-16-000243:8k_2_02:16]
Q1 FY2017 Summary

[0001045810-16-000243:8k_2_02:17]
| GAAP |
| ($ in millions except earnings per share) | Q1 FY17 | Q4 FY16 | Q1 FY16 | Q/Q | Y/Y |
| Revenue | $1,305 | $1,401 | $1,151 | Down 7% | Up 13% |
| Gross margin | 57.5% | 56.5% | 56.7% | Up 100 bps | Up 80 bps |
| Operating expenses | $506 | $539 | $477 | Down 6% | Up 6% |
| Operating income | $245 | $252 | $176 | Down 3% | Up 39% |
| Net income | $196 | $207 | $134 | Down 5% | Up 46% |
| Diluted earnings per share | $0.33 | $0.35 | $0.24 | Down 6% | Up 38% |

[0001045810-16-000243:8k_2_02:18]
| Non-GAAP |
| ($ in millions except earnings per share) | Q1 FY17 | Q4 FY16 | Q1 FY16 | Q/Q | Y/Y |
| Revenue | $1,305 | $1,401 | $1,151 | Down 7% | Up 13% |
| Gross margin | 58.6% | 57.2% | 56.9% | Up 140 bps | Up 170 bps |
| Operating expenses | $443 | $445 | $425 | -- | Up 4% |
| Operating income | $322 | $356 | $231 | Down 10% | Up 39% |
| Net income | $263 | $297 | $187 | Down 11% | Up 41% |
| Diluted earnings per share | $0.46 | $0.52 | $0.33 | Down 12% | Up 39% |

[0001045810-16-000243:8k_2_02:19]
NVIDIA’s outlook for the second quarter of fiscal 2017 is as follows:

[0001045810-16-000243:8k_2_02:20]
| • | Revenue is expected to be $1.35 billion, plus or minus two percent. |

[0001045810-16-000243:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 57.7 percent and 58.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-16-000243:8k_2_02:22]
| • | GAAP operating expenses are expected to be approximately $500 million. Non-GAAP operating expenses are expected to be approximately $445 million. |

[0001045810-16-000243:8k_2_02:23]
| • | GAAP and non-GAAP tax rates for the second quarter of fiscal 2017 are both expected to be 20 percent, plus or minus one percent. |

[0001045810-16-000243:8k_2_02:24]
| • | Capital expenditures are expected to be approximately $30 million to $40 million. |

[0001045810-16-000243:8k_2_02:25]
First Quarter Fiscal 2017 Highlights

[0001045810-16-000243:8k_2_02:26]
During the first quarter, NVIDIA achieved progress in each of its four major platforms.

[0001045810-16-000243:8k_2_02:27]
Gaming:

[0001045810-16-000243:8k_2_02:28]
| • | Launched GeForce® GTX 1080 and GTX 1070, based on the new NVIDIA Pascal™ architecture, bringing the biggest performance gains over the previous generation of processors in a decade. |

[0001045810-16-000243:8k_2_02:29]
| • | Expanded the NVIDIA VRWorks™ software development kit with Simultaneous Multi-Projection, which heightens realism with new display capabilities, and VRWorks Audio, which delivers physically modeled positional audio. |

[0001045810-16-000243:8k_2_02:30]
| • | Introduced NVIDIA Ansel™, an in-game photography tool that lets gamers compose shots from any angle and share them as single images or 360-degree panoramas for viewing in VR. |

[0001045810-16-000243:8k_2_02:31]
| • | Expanded the NVIDIA SHIELD™ platform’s gaming content available for streaming from GeForce NOW™ with new titles from Sega, Square Enix and Warner Bros. Interactive Entertainment. |

[0001045810-16-000243:8k_2_02:32]
Professional Visualization:

[0001045810-16-000243:8k_2_02:33]
| • | Extended NVIDIA Quadro® leadership in pro visualization markets, with the high-end 24GB Quadro M6000, the mid-range Quadro M2000 and new NVIDIA Iray® physically based rendering solutions. |

[0001045810-16-000243:8k_2_02:34]
| • | Unveiled Iray VR, which creates interactive, photorealistic virtual 3D worlds with unparalleled fidelity, enabling the immersive viewing of buildings and products not yet built. |

[0001045810-16-000243:8k_2_02:35]
| • | Expanded NVIDIA’s VR Ready program into the professional market. |

[0001045810-16-000243:8k_2_02:36]
Datacenter:

[0001045810-16-000243:8k_2_02:37]
| • | Hosted the seventh annual GPU Technology Conference with 5,500 attendees, 600 technical sessions and 200 exhibitors, focused on artificial intelligence, VR and self-driving cars. |

[0001045810-16-000243:8k_2_02:38]
| • | Unveiled the NVIDIA Tesla® P100 GPU, the most advanced accelerator ever built, based on the Pascal architecture. |

[0001045810-16-000243:8k_2_02:39]
| • | Revealed the NVIDIA DGX-1™, the world’s first deep-learning supercomputing in a box, with the computing throughput of more than 250 servers. |

[0001045810-16-000243:8k_2_02:40]
| • | Joined Massachusetts General Hospital as the founding technology partner of the MGH Clinical Data Science Center to advance healthcare by applying AI to improve the detection, diagnosis, treatment and management of diseases. |

[0001045810-16-000243:8k_2_02:41]
| • | Received VMware’s Global Technical Partner of the Year and European Regional Technical Partner of the Year awards for partnership with NVIDIA GRID™ and VMware ESX. |

[0001045810-16-000243:8k_2_02:42]
Automotive:

[0001045810-16-000243:8k_2_02:43]
| • | Made history as NVIDIA-powered WEpods became the first self-driving shuttles to take to public roads. |

[0001045810-16-000243:8k_2_02:44]
| • | Introduced HD Mapping, an end-to-end mapping platform for self-driving cars. |

[0001045810-16-000243:8k_2_02:45]
| • | Announced that NVIDIA DRIVE™ PX 2 will power all vehicles in ROBORACE, a new autonomous car-racing circuit to debut later this year. |

[0001045810-16-000243:8k_2_02:46]
CFO Commentary

[0001045810-16-000243:8k_2_02:47]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-16-000243:8k_2_02:48]
Conference Call and Webcast Information

[0001045810-16-000243:8k_2_02:49]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2017 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (212) 231-2919; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its second quarter of fiscal 2017.

[0001045810-16-000243:8k_2_02:50]
Non-GAAP Measures

[0001045810-16-000243:8k_2_02:51]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, per diluted share impact of certain charges, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, legal settlement costs, product warranty charge, acquisition-related costs, advanced healthcare contribution, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Per diluted share impact of certain charges is calculated as such charges, net of income tax, divided by GAAP diluted shares. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-16-000243:8k_2_02:52]
Keep Current on NVIDIA

[0001045810-16-000243:8k_2_02:53]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-16-000243:8k_2_02:54]
About NVIDIA

[0001045810-16-000243:8k_2_02:55]
NVIDIA (NASDAQ: NVDA) is a computer technology company that has pioneered GPU-accelerated computing. It targets the world’s most demanding users - gamers, designers and scientists - with products, services and software that power amazing experiences in virtual reality, artificial intelligence, professional visualization and autonomous cars. More information at http://nvidianews.nvidia.com/.

[0001045810-16-000243:8k_2_02:56]
###

[0001045810-16-000243:8k_2_02:57]
For further information, contact:

[0001045810-16-000243:8k_2_02:58]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-16-000243:8k_2_02:59]
Certain statements in this press release including, but not limited to statements as to: growth in all of the company’s platforms; the adoption of deep learning and its impact; the launch of the company’s Pascal GPU architecture; the company’s intended fiscal 2017 capital return; the company’s next quarterly cash dividend; the company’s financial outlook for the second quarter of fiscal 2017; the company’s tax rates for the second quarter of fiscal 2017; and NVIDIA DRIVE PX2 powering all vehicles in ROBORACE are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-K for the fiscal period ended January 31, 2016. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-16-000243:8k_2_02:60]
© 2016 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Quadro, Tesla, Ansel, GeForce NOW, Iray, NVIDIA DGX-1, NVIDIA VRWorks, NVIDIA DRIVE, NVIDIA GRID, Pascal, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-16-000243:8k_2_02:61]
NVIDIA CORPORATION

[0001045810-16-000243:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-16-000243:8k_2_02:63]
(In millions, except per share data)

[0001045810-16-000243:8k_2_02:64]
(Unaudited)

[0001045810-16-000243:8k_2_02:65]
|  | Three Months Ended |
|  | May 1, |  | April 26, |
|  | 2016 |  | 2015 |
| Revenue | $ | 1,305 |  |  | $ | 1,151 |  |
| Cost of revenue | 554 |  |  | 498 |  |
| Gross profit | 751 |  |  | 653 |  |
| Operating expenses |  |  |  |
| Research and development | 346 |  |  | 339 |  |
| Sales, general and administrative | 159 |  |  | 138 |  |
| Restructuring and other charges | 1 |  |  | — |  |
| Total operating expenses | 506 |  |  | 477 |  |
| Income from operations | 245 |  |  | 176 |  |
| Interest income | 12 |  |  | 9 |  |
| Interest expense | (12 | ) |  | (12 | ) |
| Other expense, net | (4 | ) |  | (1 | ) |
| Income before income tax expense | 241 |  |  | 172 |  |
| Income tax expense | 45 |  |  | 38 |  |
| Net income | $ | 196 |  |  | $ | 134 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.36 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.24 |  |
| Weighted average shares used in per share computation: |  |  |  |
| Basic | 537 |  |  | 549 |  |
| Diluted | 597 |  |  | 568 |  |

[0001045810-16-000243:8k_2_02:66]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | May 1, |  | January 31, |
|  |  |  | 2016 |  | 2016 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,754 |  |  | $ | 5,037 |  |
|  | Accounts receivable, net |  | 523 |  |  | 505 |  |
|  | Inventories |  | 394 |  |  | 418 |  |
|  | Prepaid expenses and other current assets |  | 119 |  |  | 93 |  |
|  | Total current assets |  | 5,790 |  |  | 6,053 |  |
| Property and equipment, net |  | 479 |  |  | 466 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 155 |  |  | 166 |  |
| Other assets |  | 66 |  |  | 67 |  |
|  | Total assets |  | $ | 7,108 |  |  | $ | 7,370 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 320 |  |  | $ | 296 |  |
|  | Accrued and other current liabilities |  | 636 |  |  | 642 |  |
|  | Convertible short-term debt |  | 1,421 |  |  | 1,413 |  |
|  | Total current liabilities |  | 2,377 |  |  | 2,351 |  |
| Other long-term liabilities |  | 447 |  |  | 453 |  |
| Capital lease obligations, long-term |  | 9 |  |  | 10 |  |
|  | Total liabilities |  | 2,833 |  |  | 2,814 |  |
| Convertible debt conversion obligation |  | 79 |  |  | 87 |  |
| Shareholders' equity |  | 4,196 |  |  | 4,469 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 7,108 |  |  | $ | 7,370 |  |

[0001045810-16-000243:8k_2_02:67]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |
|  |  | May 1, |  | January 31, |  | April 26, |
|  |  | 2016 |  | 2016 |  | 2015 |
| GAAP gross profit |  | $ | 751 |  |  | $ | 791 |  |  | $ | 653 |  |
| GAAP gross margin |  | 57.5 | % |  | 56.5 | % |  | 56.7 | % |
| Stock-based compensation expense (A) |  | 4 |  |  | 5 |  |  | 2 |  |
| Legal settlement costs (B) |  | 10 |  |  | — |  |  | — |  |
| Product warranty charge (C) |  | — |  |  | 5 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 765 |  |  | $ | 801 |  |  | $ | 655 |  |
| Non-GAAP gross margin |  | 58.6 | % |  | 57.2 | % |  | 56.9 | % |
| GAAP operating expenses |  | $ | 506 |  |  | $ | 539 |  |  | $ | 477 |  |
| Stock-based compensation expense (A) |  | (49 | ) |  | (56 | ) |  | (43 | ) |
| Legal settlement costs (B) |  | (6 | ) |  | — |  |  | — |  |
| Acquisition-related costs (D) |  | (4 | ) |  | (4 | ) |  | (9 | ) |
| Advanced healthcare contribution |  | (3 | ) |  | — |  |  | — |  |
| Restructuring and other charges |  | (1 | ) |  | (34 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 443 |  |  | $ | 445 |  |  | $ | 425 |  |
| GAAP income from operations |  | $ | 245 |  |  | $ | 252 |  |  | $ | 176 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 77 |  |  | 104 |  |  | 54 |  |
| Non-GAAP income from operations |  | $ | 322 |  |  | $ | 356 |  |  | $ | 230 |  |
| GAAP other income (expense), net |  | $ | (4 | ) |  | $ | 1 |  |  | $ | (4 | ) |
| Gains from non-affiliated investments |  | (3 | ) |  | — |  |  | — |  |
| Interest expense related to amortization of debt discount |  | 7 |  |  | 7 |  |  | 7 |  |
| Non-GAAP other income (expense), net |  | $ | — |  |  | $ | 8 |  |  | $ | 3 |  |
| GAAP net income |  | $ | 196 |  |  | $ | 207 |  |  | $ | 134 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 81 |  |  | 111 |  |  | 63 |  |
| Income tax impact of non-GAAP adjustments |  | (14 | ) |  | (21 | ) |  | (10 | ) |
| Non-GAAP net income |  | $ | 263 |  |  | $ | 297 |  |  | $ | 187 |  |

[0001045810-16-000243:8k_2_02:68]
|  |  | Three Months Ended |
|  |  | May 1, |  | January 31, |  | April 26, |
|  |  | 2016 |  | 2016 |  | 2015 |
| Diluted net income per share |  |  |  |  |  |  |
| GAAP |  | $ | 0.33 |  |  | $ | 0.35 |  |  | $ | 0.24 |  |
| Non-GAAP |  | $ | 0.46 |  |  | $ | 0.52 |  |  | $ | 0.33 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |
| GAAP |  | 597 |  |  | 593 |  |  | 568 |  |
| Anti-dilution impact from note hedge (E) |  | (29 | ) |  | (26 | ) |  | (6 | ) |
| Non-GAAP |  | 568 |  |  | 567 |  |  | 562 |  |
| Per share impact: |  |  |  |  |  |  |
| Legal settlement costs |  | $ | 16 |  |  | $ | — |  |  | $ | — |  |
| Advanced healthcare contribution |  | 3 |  |  | — |  |  | — |  |
| Restructuring and other charges |  | 1 |  |  | 34 |  |  | — |  |
| Income tax impact |  | (7 | ) |  | (9 | ) |  | — |  |
| Charges, net of income tax impact |  | $ | 13 |  |  | $ | 25 |  |  | $ | — |  |
| GAAP per diluted share impact |  | $ | 0.02 |  |  | $ | 0.04 |  |  | $ | — |  |
| GAAP net cash provided by operating activities |  | $ | 309 |  |  | $ | 510 |  |  | $ | 246 |  |
| Purchase of property and equipment and intangible assets |  | (55 | ) |  | (15 | ) |  | (30 | ) |
| Free cash flow |  | $ | 254 |  |  | $ | 495 |  |  | $ | 216 |  |

[0001045810-16-000243:8k_2_02:69]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |
|  |  | Three Months Ended |
|  |  | May 1, |  | January 31, |  | April 26, |
|  |  | 2016 |  | 2016 |  | 2015 |
| Cost of revenue |  | $ | 4 |  |  | $ | 5 |  |  | $ | 2 |  |
| Research and development |  | $ | 29 |  |  | $ | 33 |  |  | $ | 27 |  |
| Sales, general and administrative |  | $ | 20 |  |  | $ | 22 |  |  | $ | 16 |  |
| (B) Legal settlement with Advanced Silicon Technologies LLC and other settlement related costs. |
| (C) Represents warranty charge associated with a product recall. |
| (D) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (E) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under U.S. GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-16-000243:8k_2_02:70]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2017 Outlook |
| GAAP gross margin |  | 57.7 | % |
|  | Impact of stock-based compensation expense |  | 0.3 | % |
| Non-GAAP gross margin |  | 58.0 | % |
|  |  |  | Q2 FY2017 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 500 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (55 | ) |
| Non-GAAP operating expenses |  | $ | 445 |  |
