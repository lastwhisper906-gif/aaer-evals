# NVDA notes — 0001045810-16-000275


## nvda:BalanceSheetComponentsTextBlock

[0001045810-16-000275:notes:1]
[same as prior period, unchanged from 0001045810-15-000173:notes:1]

[0001045810-16-000275:notes:2]
[same as prior period, unchanged from 0001045810-15-000173:notes:2]

[0001045810-16-000275:notes:3]
|  | May 1, |  | January 31, |
|  | 2016 |  | 2016 |
| Inventories: | (In millions) |
| Raw materials | $ | 124 |  |  | $ | 105 |  |
| Work in-process | 105 |  |  | 103 |  |
| Finished goods | 165 |  |  | 210 |  |
| Total inventories | $ | 394 |  |  | $ | 418 |  |

[0001045810-16-000275:notes:4]
As of May 1, 2016, we had outstanding inventory purchase obligations totaling $696 million.

[0001045810-16-000275:notes:5]
|  | May 1, |  | January 31, |
|  | 2016 |  | 2016 |
| Accrued and Other Current Liabilities: | (In millions) |
| Deferred revenue | $ | 350 |  |  | $ | 322 |  |
| Customer related liabilities (1) | 142 |  |  | 160 |  |
| Accrued payroll and related expenses | 62 |  |  | 79 |  |
| Accrued restructuring and other charges (2) | 19 |  |  | 23 |  |
| Professional service fees | 18 |  |  | 23 |  |
| Warranty accrual (3) | 10 |  |  | 11 |  |
| Income taxes payable | 9 |  |  | 2 |  |
| Coupon interest on Notes | 6 |  |  | 3 |  |
| Contributions payable | 4 |  |  | 3 |  |
| Other | 16 |  |  | 16 |  |
| Total accrued and other current liabilities | $ | 636 |  |  | $ | 642 |  |

[0001045810-16-000275:notes:6]
| (1) | Customer related liabilities include accrued customer programs, such as rebates and marketing development funds. |

[0001045810-16-000275:notes:7]
| (2) | Please refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding restructuring and other charges. |

[0001045810-16-000275:notes:8]
| (3) | Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding warranties. |

[0001045810-16-000275:notes:9]
|  | May 1, |  | January 31, |
|  | 2016 |  | 2016 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 333 |  |  | $ | 301 |  |
| Income taxes payable | 78 |  |  | 78 |  |
| Contributions payable | 15 |  |  | 13 |  |
| Interest rate swap (1) | 8 |  |  | 7 |  |
| Deferred revenue (2) | 1 |  |  | 44 |  |
| Other | 12 |  |  | 10 |  |
| Total other long-term liabilities | $ | 447 |  |  | $ | 453 |  |

[0001045810-16-000275:notes:10]
[same as prior period, unchanged from 0001045810-15-000173:notes:11]

[0001045810-16-000275:notes:11]
| (2) | Deferred revenue under our patent cross licensing agreement with Intel Corporation is now located in short term deferred revenue as less than twelve months remains on the agreement. |


## nvda:ScheduleofAccountReceivablefromMajorCustomersTableTextBlock

[0001045810-16-000275:notes:12]
|  | May 1, 2016 |  | January 26, 2016 |
| Accounts Receivable: |  |  |  |
| Customer B | 19 | % |  | 21 | % |
| Customer C | 13 | % |  | — | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-16-000275:notes:13]
|  | Three Months Ended |
|  | May 1, |  | April 26, |
|  | 2016 |  | 2015 |
|  | (In millions) |
| Revenue: |  |  |  |
| Gaming | $ | 687 |  |  | $ | 587 |  |
| Professional Visualization | 189 |  |  | 181 |  |
| Datacenter | 143 |  |  | 88 |  |
| Automotive | 113 |  |  | 77 |  |
| OEM & IP | 173 |  |  | 218 |  |
| Total revenue | $ | 1,305 |  |  | $ | 1,151 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-16-000275:notes:14]
|  | May 1, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 401 |  |  | $ | 381 |  |
| Estimated weighted average amortization period | (In years) |
| Stock options | 1.0 |  |  | 1.1 |  |
| RSUs, PSUs and market-based PSUs | 2.8 |  |  | 2.7 |  |
| ESPP | 0.6 |  |  | 0.7 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-16-000275:notes:15]
|  | May 1, 2016 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,791 |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | 1,793 |  |
| Debt securities of United States government agencies | 1,027 |  |  | 1 |  |  | — |  |  | 1,028 |  |
| Debt securities issued by United States Treasury | 716 |  |  | 2 |  |  | — |  |  | 718 |  |
| Asset-backed securities | 380 |  |  | 1 |  |  | — |  |  | 381 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 187 |  |  | 3 |  |  | (2 | ) |  | 188 |  |
| Foreign government bonds | 102 |  |  | — |  |  | — |  |  | 102 |  |
| Money market funds | 31 |  |  | — |  |  | — |  |  | 31 |  |
| Total | $ | 4,234 |  |  | $ | 10 |  |  | $ | (3 | ) |  | $ | 4,241 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 34 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 4,207 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,241 |  |

[0001045810-16-000275:notes:16]
|  | January 31, 2016 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,903 |  |  | $ | 1 |  |  | $ | (3 | ) |  | $ | 1,901 |  |
| Debt securities of United States government agencies | 1,170 |  |  | 1 |  |  | (1 | ) |  | 1,170 |  |
| Debt securities issued by United States Treasury | 800 |  |  | 1 |  |  | — |  |  | 801 |  |
| Asset-backed securities | 435 |  |  | — |  |  | — |  |  | 435 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 229 |  |  | 3 |  |  | (1 | ) |  | 231 |  |
| Foreign government bonds | 92 |  |  | — |  |  | — |  |  | 92 |  |
| Money market funds | 43 |  |  | — |  |  | — |  |  | 43 |  |
| Total | $ | 4,672 |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | 4,673 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 232 |  |
| Marketable securities |  |  |  |  |  |  | 4,441 |  |
| Total |  |  |  |  |  |  | $ | 4,673 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-16-000275:notes:17]
Basis of Presentation

[0001045810-16-000275:notes:18]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 31, 2016 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2016, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2016.

[0001045810-16-000275:notes:19]
Significant Accounting Policies

[0001045810-16-000275:notes:20]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 31, 2016. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-16-000275:notes:21]
Commitments and Contingencies

[0001045810-16-000275:notes:22]
Operating Lease Financing Arrangement

[0001045810-16-000275:notes:23]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-16-000275:notes:24]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-16-000275:notes:25]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-16-000275:notes:26]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-16-000275:notes:27]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-16-000275:notes:28]
Patent Infringement Cases

[0001045810-16-000275:notes:29]
In September 2014, NVIDIA filed complaints against Qualcomm, Inc. and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing. In November 2014, Samsung filed complaints against NVIDIA in the ITC and the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed certain patents.

[0001045810-16-000275:notes:30]
NVIDIA and Samsung, and NVIDIA and Qualcomm, also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office.

[0001045810-16-000275:notes:31]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941; the motion has not yet been granted. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party.

[0001045810-16-000275:notes:32]
NVIDIA’s dismissals on May 11, 2016 and May 12, 2016 also terminated its claims against Qualcomm.

[0001045810-16-000275:notes:33]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. The Initial Determination is expected to become the Final Determination of the ITC on or before June 9, 2016. Pursuant to the license agreement, we paid Advanced Silicon Technologies $16 million during the three months ended May 1, 2016, of which $6 million was recorded as a patent-related intangible asset and $10 million was recorded as a charge to cost of revenue.

[0001045810-16-000275:notes:34]
Accounting for Loss Contingencies

[0001045810-16-000275:notes:35]
We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-16-000275:notes:36]
[same as prior period, unchanged from 0001045810-15-000173:notes:31]

[0001045810-16-000275:notes:37]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-16-000275:notes:38]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-16-000275:notes:39]
|  |  | May 1, |  | January 31, |
|  |  | 2016 |  | 2016 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 39 |  |  | $ | 39 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (79 | ) |  | (87 | ) |
| Net carrying amount |  | $ | 1,421 |  |  | $ | 1,413 |  |

[0001045810-16-000275:notes:40]
(1) As of May 1, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.6 years.

[0001045810-16-000275:notes:41]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-16-000275:notes:42]
|  |  | Three Months Ended |
|  |  | May 1, |  | April 26, |
|  |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 8 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 12 |  |  | $ | 11 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-16-000275:notes:43]
Convertible Debt

[0001045810-16-000275:notes:44]
1.00 % Convertible Senior Notes Due 2018

[0001045810-16-000275:notes:45]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of May 1, 2016, the conversion rate has been adjusted to 49.7481 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.1013 per share of common stock) for dividend increases made to that date.

[0001045810-16-000275:notes:46]
We separately accounted for the liability and equity components of the Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-16-000275:notes:47]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-16-000275:notes:48]
Holders may convert all or any portion of their Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Notes regardless of the foregoing conditions.

[0001045810-16-000275:notes:49]
The price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended January 31, 2016. Therefore, as of January 31, 2016, the conversion threshold had been met and the Notes became convertible at the holders’ option beginning on February 1, 2016 and ending on May 1, 2016. As such, the $1.41 billion carrying value of the Notes as of January 31, 2016 was classified as a current liability and the $87 million difference between the principal amount and the carrying value of the Notes was reclassified from shareholders' equity to convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet as of January 31, 2016.

[0001045810-16-000275:notes:50]
As of May 1, 2016, the Notes continued to be convertible at the holders’ option for the period beginning on May 2, 2016 and ending on July 31, 2016. As such, the $1.42 billion carrying value of the Notes as of May 1, 2016 continued to be classified as a current liability and the $79 million difference between the principal amount and the carrying value of the Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

[0001045810-16-000275:notes:51]
Upon conversion of the Notes, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the closing price of our common stock on April 29, 2016 (the last trading day of the first quarter of fiscal year 2017) of $35.53, the if-converted value of our Notes exceeded their principal amount by approximately $1.15 billion. As of May 1, 2016, we had received conversion notices for a total of $0.2 million aggregate principal amount of the Notes, for which conversion is expected to be completed in the second quarter of fiscal year 2017. As of May 1, 2016, no conversions had taken place.

[0001045810-16-000275:notes:52]
Note Hedges and Warrants

[0001045810-16-000275:notes:53]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through May 1, 2016, the strike price of the Note Hedges has been adjusted to $20.1013 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion.

[0001045810-16-000275:notes:54]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of May 1, 2016, the strike price was adjusted to $27.0594 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 74 million shares of our common stock.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-16-000275:notes:55]
Derivative Financial Instruments

[0001045810-16-000275:notes:56]
In August 2015, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building, which entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments. This interest rate swap is designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are recorded in accumulated other comprehensive income (loss) and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur.

[0001045810-16-000275:notes:57]
During the first quarter of fiscal year 2017, we entered into six foreign currency forward contracts with a total U.S. dollar equivalent notional value of $35 million to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income (loss) and will be reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts as of May 1, 2016 was not significant.

[0001045810-16-000275:notes:58]
Under the master netting agreements with the respective counterparties to our foreign currency forward contracts, we are allowed to net settle transactions with the same counterparty, subject to applicable requirements. However, we present our derivative assets and liabilities at their gross fair values on our Condensed Consolidated Balance Sheets. We are not required to pledge, and are not entitled to receive, cash collateral related to these derivative instruments.

[0001045810-16-000275:notes:59]
As of May 1, 2016, the maturities of the designated foreign currency forward contracts were three months or less.

[0001045810-16-000275:notes:60]
We formally assess, both at inception and on an ongoing basis, whether the derivative financial instruments are highly effective. For the three months ended May 1, 2016, all derivative financial instruments were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-16-000275:notes:61]
The amount of gain or (loss) recognized in other comprehensive income on derivative financial instruments was not significant for the three months ended May 1, 2016.

[0001045810-16-000275:notes:62]
We expect to realize all of the amounts deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months. We do not expect to reclassify any amount from accumulated other comprehensive income (loss) into earnings related to the interest rate swap as the underlying operating lease financing payments for our new headquarters building will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-16-000275:notes:63]
[same as prior period, unchanged from 0001045810-15-000173:notes:54]

[0001045810-16-000275:notes:64]
[same as prior period, unchanged from 0001045810-15-000173:notes:55]

[0001045810-16-000275:notes:65]
Our Condensed Consolidated Statements of Income include stock-based compensation expense, net of amounts capitalized as inventory, as follows:

[0001045810-16-000275:notes:66]
|  | Three Months Ended |
|  | May 1, 2016 |  | April 26, 2015 |
|  | (In millions) |
| Cost of revenue | $ | 4 |  |  | $ | 2 |  |
| Research and development | 29 |  |  | 27 |  |
| Sales, general and administrative | 20 |  |  | 16 |  |
| Total | $ | 53 |  |  | $ | 45 |  |

[0001045810-16-000275:notes:67]
[same as prior period, unchanged from 0001045810-15-000173:notes:60]

[0001045810-16-000275:notes:68]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-16-000275:notes:69]
|  | RSUs, PSUs and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted Average Exercise Price Per Share |
|  | (In millions, except per share data) |
| Balances, January 31, 2016 | 26 |  |  | $ | 19.12 |  |  | 13 |  |  | $ | 14.49 |  |
| Granted (1) (2) | 3 |  |  | $ | 32.01 |  |  | — |  |  | $ | — |  |
| Exercised | — |  |  | $ | — |  |  | (2 | ) |  | $14.05 |
| Vested restricted stock | (3 | ) |  | $ | 16.63 |  |  | — |  |  | — |  |
| Canceled and forfeited | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balances, May 1, 2016 | 26 |  |  | $ | 21.29 |  |  | 11 |  |  | $ | 14.57 |  |

[0001045810-16-000275:notes:70]
| (1) | Represents PSUs that will be issued and eligible to vest if the corporate financial performance maximum target level for fiscal year 2017 is achieved. Depending on the actual level of achievement of the corporate performance target at the end of fiscal year 2017, the PSUs issued could range from 0 to 2 million shares. |

[0001045810-16-000275:notes:71]
| (2) | Represents market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs issued could range from 0 to 0.3 million shares. |

[0001045810-16-000275:notes:72]
Of the total fair value of equity awards granted during the three months ended May 1, 2016 and April 26, 2015, the stock-based compensation expense related to equity awards that are not expected to vest was $10 million and $5 million, respectively.

[0001045810-16-000275:notes:73]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of May 1, 2016 and January 31, 2016:


## us-gaap:EarningsPerShareTextBlock

[0001045810-16-000275:notes:74]
[same as prior period, unchanged from 0001045810-15-000173:notes:68]

[0001045810-16-000275:notes:75]
[same as prior period, unchanged from 0001045810-15-000173:notes:69]

[0001045810-16-000275:notes:76]
|  | Three Months Ended |
|  | May 1, |  | April 26, |
|  | 2016 |  | 2015 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |
| Net income | $ | 196 |  |  | $ | 134 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 537 |  |  | 549 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |
| Equity awards outstanding | 18 |  |  | 13 |  |
| 1% Convertible Senior Notes | 29 |  |  | 6 |  |
| Warrants issued with the Notes | 13 |  |  | — |  |
| Diluted weighted average shares | 597 |  |  | 568 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 0.36 |  |  | $ | 0.24 |  |
| Diluted (2) | $ | 0.33 |  |  | $ | 0.24 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 3 |  |  | 3 |  |

[0001045810-16-000275:notes:77]
| (1) | Calculated as net income divided by basic weighted average shares. |

[0001045810-16-000275:notes:78]
| (2) | Calculated as net income divided by diluted weighted average shares. |

[0001045810-16-000275:notes:79]
The 1.00% Convertible Senior Notes, or the Notes, are included in the calculation of diluted net income per share. The Notes will have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.1013 per share. The Warrants outstanding are included in the calculation of diluted net income per share. The Warrants have a dilutive impact on net income per share if our average stock price for the quarter exceeds the adjusted strike price of $27.0594 per share. For the three months ended May 1, 2016, our average stock price was $32.63, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Notes and the Warrants to have a dilutive impact for this period.

[0001045810-16-000275:notes:80]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transaction, or the Note Hedges, that we entered into concurrently with the issuance of the Notes, as its effect would be anti-dilutive. In the event of conversion of the Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Notes.

[0001045810-16-000275:notes:81]
[same as prior period, unchanged from 0001045810-15-000173:notes:74]


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-16-000275:notes:82]
|  |  | Fair Value at |
|  | Pricing Category |  | May 1, 2016 |  | January 31, 2016 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Corporate debt securities (1) | Level 2 |  | $ | 1,793 |  |  | $ | 1,901 |  |
| Debt securities of United States government agencies (2) | Level 2 |  | $ | 1,028 |  |  | $ | 1,170 |  |
| Debt securities issued by United States Treasury (2) | Level 2 |  | $ | 718 |  |  | $ | 801 |  |
| Asset-backed securities (2) | Level 2 |  | $ | 381 |  |  | $ | 435 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises (2) | Level 2 |  | $ | 188 |  |  | $ | 231 |  |
| Foreign government bonds (2) | Level 2 |  | $ | 102 |  |  | $ | 92 |  |
| Money market funds (3) | Level 1 |  | $ | 31 |  |  | $ | 43 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (4) | Level 2 |  | $ | 2,675 |  |  | $ | 2,273 |  |
| Other noncurrent liability: |  |  |  |  |  |
| Interest rate swap (5) | Level 2 |  | $ | (8 | ) |  | $ | (7 | ) |

[0001045810-16-000275:notes:83]
| (1) | Included $3 million and $51 million in cash equivalents as of May 1, 2016 and January 31, 2016, respectively, and $1.79 billion and $1.85 billion in marketable securities as of May 1, 2016 and January 31, 2016, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000275:notes:84]
| (2) | Reported in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000275:notes:85]
| (3) | Reported in cash equivalents on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000275:notes:86]
| (4) | The Notes are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount, and are not marked to fair value each period. See Note 11 of these Notes to Condensed Consolidated Financial Statements for additional information on the Notes. |

[0001045810-16-000275:notes:87]
| (5) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-16-000275:notes:88]
[same as prior period, unchanged from 0001045810-15-000173:notes:83]

[0001045810-16-000275:notes:89]
We measure our cash equivalents, marketable securities, and interest rate swap at fair value using quoted market prices of identical assets or similar assets from active markets. We review the fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 assets or liabilities for the three months ended May 1, 2016, and we did not have any investments or liabilities classified as Level 3 as of May 1, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-16-000275:notes:90]
[same as prior period, unchanged from 0001045810-15-000173:notes:85]

[0001045810-16-000275:notes:91]
We recognized income tax expense of $45 million and $38 million for the three months ended May 1, 2016 and April 26, 2015, respectively. Our effective tax rate was 18.6% and 22.0% for the three months ended May 1, 2016 and April 26, 2015, respectively.

[0001045810-16-000275:notes:92]
The decrease in our effective tax rate in the three months ended May 1, 2016 as compared to the same period in the prior fiscal year was primarily due to the favorable benefit of the U.S. federal research tax credit, which was permanently re-enacted on December 18, 2015 under the Protecting Americans from Tax Hikes Act of 2015, and lower permanent tax differences related to stock-based compensation, partially offset by an increase in the amount of earnings subject to U.S. tax.

[0001045810-16-000275:notes:93]
Our effective tax rate for the first three months of fiscal year 2017 of 18.6% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit and discrete events that occurred in the first three months of fiscal year 2017 primarily attributable to tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-16-000275:notes:94]
As of May 1, 2016, we had approximately $50 million of unrecognized tax benefits related to various U.S. state income tax positions. We reasonably expect our current review by the state of California to close within the next twelve months. Upon closure of this review, we reasonably expect that some amount of these state tax benefits would become available for recognition as a deferred tax asset. However, as we have a full valuation allowance on state deferred tax assets, we do not expect this to have a significant impact on our consolidated financial statements. For the three months ended May 1, 2016, there have been no other significant changes to our tax years that remain subject to review by major tax jurisdictions. Further, there have been no significant changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 31, 2016, other than the recognition of tax benefits upon the expiration of statutes of limitations in certain non-U.S. jurisdictions in the three months ended May 1, 2016.

[0001045810-16-000275:notes:95]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-16-000275:notes:96]
Amortizable Intangible Assets

[0001045810-16-000275:notes:97]
[same as prior period, unchanged from 0001045810-15-000173:notes:94]

[0001045810-16-000275:notes:98]
|  | May 1, 2016 |  | January 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (156 | ) |  | $ | 37 |  |  | $ | 193 |  |  | $ | (152 | ) |  | $ | 41 |  |
| Patents and licensed technology | 468 |  |  | (350 | ) |  | 118 |  |  | 462 |  |  | (337 | ) |  | 125 |  |
| Total intangible assets | $ | 661 |  |  | $ | (506 | ) |  | $ | 155 |  |  | $ | 655 |  |  | $ | (489 | ) |  | $ | 166 |  |

[0001045810-16-000275:notes:99]
Amortization expense associated with intangible assets was $17 million and $19 million for the three months ended May 1, 2016 and April 26, 2015, respectively. Future amortization expense related to the net carrying amount of intangible assets as of May 1, 2016 is estimated to be $51 million for the remainder of fiscal year 2017, $54 million in fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $7 million in fiscal year 2021 and a total of $1 million in fiscal year 2022 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-16-000275:notes:100]
|  | May 1, 2016 |  | January 31, 2016 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 1,714 |  |  | $ | 1,716 |  |  | $ | 1,619 |  |  | $ | 1,619 |  |
| Due in 1 - 5 years | 2,474 |  |  | 2,479 |  |  | 3,019 |  |  | 3,020 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 46 |  |  | 46 |  |  | 34 |  |  | 34 |  |
| Total | $ | 4,234 |  |  | $ | 4,241 |  |  | $ | 4,672 |  |  | $ | 4,673 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-16-000275:notes:101]
[same as prior period, unchanged from 0001045810-15-000173:notes:98]

[0001045810-16-000275:notes:102]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax, and net realized gains and losses recorded in other income and expense, net, on the Condensed Consolidated Statements of Income.

[0001045810-16-000275:notes:103]
We performed an impairment review of our investment portfolio as of May 1, 2016. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of May 1, 2016.

[0001045810-16-000275:notes:104]
The following is a summary of cash equivalents and marketable securities as of May 1, 2016 and January 31, 2016:

[0001045810-16-000275:notes:105]
The following table provides the breakdown of the investments with unrealized losses as of May 1, 2016:

[0001045810-16-000275:notes:106]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 422 |  |  | $ | (1 | ) |  | $ | 108 |  |  | $ | — |  |  | $ | 530 |  |  | $ | (1 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 60 |  |  | (1 | ) |  | 34 |  |  | — |  |  | 94 |  |  | (1 | ) |
| Total | $ | 482 |  |  | $ | (2 | ) |  | $ | 142 |  |  | $ | — |  |  | $ | 624 |  |  | $ | (2 | ) |

[0001045810-16-000275:notes:107]
The gross unrealized losses as of May 1, 2016 related to fixed income securities were due to changes in interest rates and are temporary in nature. We have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-16-000275:notes:108]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of May 1, 2016 and January 31, 2016 and are shown below by contractual maturity:

[0001045810-16-000275:notes:109]
Net realized losses were not significant for the three months ended May 1, 2016. Net realized gains were $3 million for the three months ended April 26, 2015.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-16-000275:notes:110]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-16-000275:notes:111]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting, including income taxes at settlement, classifications in the statement of cash flows, forfeitures and net settlements, and will be effective in our first quarter of fiscal year 2018. Early adoption is permitted in any annual or interim period. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements.

[0001045810-16-000275:notes:112]
In February 2016, FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements, however, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.

[0001045810-16-000275:notes:113]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). In March, April and May 2016, the FASB issued additional updates to the new revenue standard relating to reporting revenue on a gross versus net basis, identifying performance obligations and licensing arrangements, and narrow-scope improvements and practical expedients, respectively. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-16-000275:notes:114]
[same as prior period, unchanged from 0001045810-15-000173:notes:111]

[0001045810-16-000275:notes:115]
[same as prior period, unchanged from 0001045810-15-000173:notes:112]

[0001045810-16-000275:notes:116]
[same as prior period, unchanged from 0001045810-15-000173:notes:113]

[0001045810-16-000275:notes:117]
[same as prior period, unchanged from 0001045810-15-000173:notes:114]

[0001045810-16-000275:notes:118]
The estimated product returns and estimated product warranty liabilities as of May 1, 2016 and January 31, 2016 were as follows:

[0001045810-16-000275:notes:119]
|  | May 1, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| Balance at beginning of period | $ | 11 |  |  | $ | 8 |  |
| Additions | 1 |  |  | 27 |  |
| Deductions | (2 | ) |  | (24 | ) |
| Balance at end of period | $ | 10 |  |  | $ | 11 |  |

[0001045810-16-000275:notes:120]
In connection with certain agreements that we have entered into in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-16-000275:notes:121]
|  | Three Months Ended |
|  | May 1, 2016 |  | April 26, 2015 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |
| Unallocated revenue | $ | 66 |  |  | $ | 66 |  |
| Unallocated cost of revenue and operating expenses | (54 | ) |  | (57 | ) |
| Stock-based compensation | (53 | ) |  | (45 | ) |
| Legal settlement costs | (16 | ) |  | — |  |
| Acquisition-related costs | (4 | ) |  | (9 | ) |
| Advanced healthcare contribution | (3 | ) |  | — |  |
| Restructuring and other charges | (1 | ) |  | — |  |
| Total | $ | (65 | ) |  | $ | (45 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-16-000275:notes:122]
Restructuring and Other Charges

[0001045810-16-000275:notes:123]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera modem operations. Our operating expenses for the three months ended May 1, 2016 included $1 million of restructuring and other charges.

[0001045810-16-000275:notes:124]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Condensed Consolidated Balance Sheets as of May 1, 2016:

[0001045810-16-000275:notes:125]
|  | May 1, |
|  | 2016 |
|  | (In millions) |
| Balance at beginning of period | $ | 23 |  |
| Restructuring and other charges | 1 |  |
| Cash payments | (5 | ) |
| Non-cash adjustments | — |  |
| Balance at end of period | $ | 19 |  |

[0001045810-16-000275:notes:126]
The majority of the remaining balance of $19 million as of May 1, 2016 is expected to be paid during fiscal year 2017.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-16-000275:notes:127]
|  | Three Months Ended |
|  | May 1, |  | April 26, |
|  | 2016 |  | 2015 |
|  | (In millions) |
| Revenue: |  |  |  |
| Taiwan | $ | 445 |  |  | $ | 388 |  |
| China | 247 |  |  | 173 |  |
| United States | 194 |  |  | 180 |  |
| Other Asia Pacific | 160 |  |  | 188 |  |
| Europe | 156 |  |  | 119 |  |
| Other Americas | 103 |  |  | 103 |  |
| Total revenue | $ | 1,305 |  |  | $ | 1,151 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001045810-16-000275:notes:128]
|  | Three Months Ended |
|  | May 1, 2016 |  | April 26, 2015 |
| Revenue: |  |  |  |
| Customer A | 12 | % |  | 10 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-16-000275:notes:129]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended May 1, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 1,079 |  |  | $ | 160 |  |  | $ | 66 |  |  | $ | 1,305 |  |
| Depreciation and amortization expense | $ | 28 |  |  | $ | 7 |  |  | $ | 10 |  |  | $ | 45 |  |
| Operating income (loss) | $ | 348 |  |  | $ | (38 | ) |  | $ | (65 | ) |  | $ | 245 |  |
| Three Months Ended April 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 940 |  |  | $ | 145 |  |  | $ | 66 |  |  | $ | 1,151 |  |
| Depreciation and amortization expense | $ | 28 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 54 |  |
| Operating income (loss) | $ | 278 |  |  | $ | (57 | ) |  | $ | (45 | ) |  | $ | 176 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-16-000275:notes:130]
[same as prior period, unchanged from 0001045810-15-000173:notes:134]

[0001045810-16-000275:notes:131]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-16-000275:notes:132]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a unified underlying graphics architecture.

[0001045810-16-000275:notes:133]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla for researchers and analysts focused on artificial intelligence, deep learning and big-data; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs aimed at online gaming and entertainment devices, as well as autonomous robots, drones and cars.

[0001045810-16-000275:notes:134]
We have a single unifying architecture for our GPU and Tegra Processors. This architecture unification leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-16-000275:notes:135]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, legal settlement costs, amortization of acquisition-related intangible assets, other acquisition-related costs, an advanced healthcare contribution, restructuring and other charges, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-16-000275:notes:136]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for NVIDIA as a whole. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-16-000275:notes:137]
[same as prior period, unchanged from 0001045810-15-000173:notes:142]

[0001045810-16-000275:notes:138]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-16-000275:notes:139]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-16-000275:notes:140]
Revenue from the above customer was attributable to the GPU business.

[0001045810-16-000275:notes:141]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-16-000275:notes:142]
[same as prior period, unchanged from 0001045810-15-000173:notes:145]

[0001045810-16-000275:notes:143]
[same as prior period, unchanged from 0001045810-15-000173:notes:146]

[0001045810-16-000275:notes:144]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The first quarter of fiscal years 2017 and 2016 were both 13-week quarters.

[0001045810-16-000275:notes:145]
[same as prior period, unchanged from 0001045810-15-000173:notes:148]

[0001045810-16-000275:notes:146]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-16-000275:notes:147]
[same as prior period, unchanged from 0001045810-15-000173:notes:150]

[0001045810-16-000275:notes:148]
Capital Return Program

[0001045810-16-000275:notes:149]
[same as prior period, unchanged from 0001045810-15-000173:notes:152]

[0001045810-16-000275:notes:150]
In March 2016, we entered into an accelerated share repurchase, or ASR, agreement with an investment bank, under which we made an upfront payment of $500 million to purchase shares of our common stock and received an initial delivery of 12 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions of the ASR agreement.

[0001045810-16-000275:notes:151]
We accounted for the ASR program as two separate transactions: (i) the 12 million shares of common stock initially delivered to us were accounted for as a treasury stock transaction and (ii) the unsettled contract was determined to be a forward contract indexed to our own common stock. The initial delivery of 12 million shares resulted in an immediate reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted net income per share. We have determined that the forward contract met all of the applicable criteria for equity classification. As a result, we recorded $410 million as treasury stock and $90 million, the implied value of the forward contract, as additional paid-in-capital, or APIC, in our Condensed Consolidated Balance Sheets as of May 1, 2016. The remainder of the shares are anticipated to be delivered to us in the second quarter of fiscal year 2017 and, at that time, the forward contract will be reclassified from APIC to treasury stock.

[0001045810-16-000275:notes:152]
During the three months ended May 1, 2016, we also paid $62 million in cash dividends to our shareholders, equivalent to $0.1150 per share. As a result, we returned $562 million to shareholders during the three months ended May 1, 2016 in the form of share repurchases and dividend payments.

[0001045810-16-000275:notes:153]
Through May 1, 2016, we have repurchased an aggregate of 243 million shares under our share repurchase program for a total cost of $4.35 billion. All shares delivered from these repurchases have been placed into treasury stock. As of May 1, 2016, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $0.97 billion.

[0001045810-16-000275:notes:154]
We intend to return approximately $1.00 billion to our shareholders in fiscal year 2017 through a combination of share repurchases and cash dividends. We also declared on May 12, 2016 that we would pay our next quarterly cash dividend of $0.1150 per share on June 20, 2016, to all shareholders of record on May 26, 2016.

[0001045810-16-000275:notes:155]
[same as prior period, unchanged from 0001045810-15-000173:notes:157]

[0001045810-16-000275:notes:156]
As of May 1, 2016 and January 31, 2016, there were no shares of preferred stock outstanding.

[0001045810-16-000275:notes:157]
[same as prior period, unchanged from 0001045810-15-000173:notes:159]

[0001045810-16-000275:notes:158]
[same as prior period, unchanged from 0001045810-15-000173:notes:160]
