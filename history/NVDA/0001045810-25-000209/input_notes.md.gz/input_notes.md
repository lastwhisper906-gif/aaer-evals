# NVDA notes — 0001045810-25-000209


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-25-000209:notes:1]
[same as prior period, unchanged from 0001045810-25-000116:notes:1]

[0001045810-25-000209:notes:2]
[same as prior period, unchanged from 0001045810-25-000116:notes:2]

[0001045810-25-000209:notes:3]
[same as prior period, unchanged from 0001045810-25-000116:notes:3]

[0001045810-25-000209:notes:4]
[same as prior period, unchanged from 0001045810-25-000116:notes:5]

[0001045810-25-000209:notes:5]
[same as prior period, unchanged from 0001045810-25-000116:notes:6]

[0001045810-25-000209:notes:6]
[same as prior period, unchanged from 0001045810-25-000116:notes:7]

[0001045810-25-000209:notes:7]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The second quarters of fiscal years 2026 and 2025 were both 13-week quarters.

[0001045810-25-000209:notes:8]
[same as prior period, unchanged from 0001045810-25-000116:notes:9]

[0001045810-25-000209:notes:9]
[same as prior period, unchanged from 0001045810-25-000116:notes:10]

[0001045810-25-000209:notes:10]
[same as prior period, unchanged from 0001045810-25-000116:notes:11]

[0001045810-25-000209:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, non-marketable equity securities, other contingencies, property, plant, and equipment, restructuring and other charges, revenue recognition, and stock-based compensation. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-25-000209:notes:12]
Recently Issued Accounting Pronouncements

[0001045810-25-000209:notes:13]
[same as prior period, unchanged from 0001045810-25-000116:notes:14]

[0001045810-25-000209:notes:14]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending January 25, 2026.

[0001045810-25-000209:notes:15]
[same as prior period, unchanged from 0001045810-25-000116:notes:16]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-25-000209:notes:16]
[same as prior period, unchanged from 0001045810-25-000116:notes:17]

[0001045810-25-000209:notes:17]
[same as prior period, unchanged from 0001045810-25-000116:notes:18]

[0001045810-25-000209:notes:18]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Cost of revenue | $ | 58 |  |  | $ | 40 |  |  | $ | 123 |  |  | $ | 75 |  |
| Research and development | 1,191 |  |  | 832 |  |  | 2,254 |  |  | 1,559 |  |
| Sales, general and administrative | 375 |  |  | 282 |  |  | 722 |  |  | 530 |  |
| Total | $ | 1,624 |  |  | $ | 1,154 |  |  | $ | 3,099 |  |  | $ | 2,164 |  |

[0001045810-25-000209:notes:19]
[same as prior period, unchanged from 0001045810-25-000116:notes:20]

[0001045810-25-000209:notes:20]
[same as prior period, unchanged from 0001045810-25-000116:notes:21]

[0001045810-25-000209:notes:21]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balance as of Jan 26, 2025 | 274 |  |  | $ | 44.75 |  |
| Granted | 48 |  |  | $ | 108.52 |  |
| Vested | (78) |  |  | $ | 36.00 |  |
| Canceled and forfeited | (5) |  |  | $ | 52.34 |  |
| Balance as of Jul 27, 2025 | 239 |  |  | $ | 60.19 |  |

[0001045810-25-000209:notes:22]
As of July 27, 2025, aggregate unearned stock-based compensation expense was $14.0 billion, which is expected to be recognized over a weighted average period of 2.2 years for RSUs, PSUs, and market-based PSUs, and one year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-25-000209:notes:23]
[same as prior period, unchanged from 0001045810-25-000116:notes:24]

[0001045810-25-000209:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 26,422 |  |  | $ | 16,599 |  |  | $ | 45,197 |  |  | $ | 31,480 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,366 |  |  | 24,578 |  |  | 24,404 |  |  | 24,599 |  |
| Dilutive impact of outstanding equity awards | 166 |  |  | 270 |  |  | 167 |  |  | 270 |  |
| Diluted weighted average shares | 24,532 |  |  | 24,848 |  |  | 24,571 |  |  | 24,869 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.08 |  |  | $ | 0.68 |  |  | $ | 1.85 |  |  | $ | 1.28 |  |
| Diluted (2) | $ | 1.08 |  |  | $ | 0.67 |  |  | $ | 1.84 |  |  | $ | 1.27 |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 3 |  |  | 5 |  |  | 60 |  |  | 68 |  |

[0001045810-25-000209:notes:25]
[same as prior period, unchanged from 0001045810-25-000116:notes:26]

[0001045810-25-000209:notes:26]
[same as prior period, unchanged from 0001045810-25-000116:notes:27]

[0001045810-25-000209:notes:27]
[same as prior period, unchanged from 0001045810-25-000116:notes:28]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-25-000209:notes:28]
Income Taxes
Income tax expense was $4.8 billion and $2.6 billion for the second quarter, and $7.9 billion and $5.0 billion for the first half, of fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 15.3% and 13.6% for the second quarter, and 14.9% and 13.7% for the first half, of fiscal years 2026 and 2025, respectively.

[0001045810-25-000209:notes:29]
The effective tax rate increased primarily due to a lower tax benefit from stock-based compensation, partially offset by an increase in tax benefit from foreign-derived deduction eligible income.

[0001045810-25-000209:notes:30]
Our effective tax rates for the first half of fiscal years 2026 and 2025 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from foreign-derived deduction eligible income, stock-based compensation, income earned in jurisdictions that are subject to taxes at rates lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit.

[0001045810-25-000209:notes:31]
In July 2025, the One Big Beautiful Bill Act (OBBBA) was enacted into law and contains several changes to key U.S. federal income tax laws. As of July 27, 2025, we have recognized the tax effects of certain OBBBA provisions, which did not have a material impact on our second quarter.

[0001045810-25-000209:notes:32]
[same as prior period, unchanged from 0001045810-25-000116:notes:32]

[0001045810-25-000209:notes:33]
[same as prior period, unchanged from 0001045810-25-000116:notes:33]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-25-000209:notes:34]
Cash Equivalents and Marketable Securities
The fair values of our financial assets are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis. The following is a summary of cash equivalents and marketable securities:

[0001045810-25-000209:notes:35]
|  | Jul 27, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 23,967 |  |  | $ | 76 |  |  | $ | (11) |  |  | $ | 24,032 |  |  | $ | 3,784 |  |  | $ | 20,248 |  |
| Corporate debt securities | Level 2 | 21,564 |  |  | 81 |  |  | (9) |  |  | 21,636 |  |  | 2,214 |  |  | 19,422 |  |
| Money market funds | Level 1 | 5,245 |  |  | — |  |  | — |  |  | 5,245 |  |  | 5,245 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,238 |  |  | 7 |  |  | (2) |  |  | 2,243 |  |  | — |  |  | 2,243 |  |
| Certificates of deposit | Level 2 | 108 |  |  | — |  |  | — |  |  | 108 |  |  | 108 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 53,162 |  |  | 164 |  |  | (22) |  |  | 53,304 |  |  | 11,351 |  |  | 41,953 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,199 |  |  | — |  |  | 3,199 |  |
| Total |  | $ | 53,162 |  |  | $ | 164 |  |  | $ | (22) |  |  | $ | 56,503 |  |  | $ | 11,351 |  |  | $ | 45,152 |  |

[0001045810-25-000209:notes:36]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of July 27, 2025 was $2.8 billion and was subject to a short-term restriction on the ability to sell.

[0001045810-25-000209:notes:37]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $1.9 billion and $1.7 billion for the second quarter and first half of fiscal year 2026, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were $132 million and $181 million for the second quarter and first half of fiscal year 2025, respectively.

[0001045810-25-000209:notes:38]
|  | Jan 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

[0001045810-25-000209:notes:39]
The following table provides the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-25-000209:notes:40]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 7,319 |  |  | $ | (11) |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 3,539 |  |  | (9) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 768 |  |  | (2) |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 11,626 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

[0001045810-25-000209:notes:41]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater, with balances of $15 million and $213 million as of July 27, 2025 and January 26, 2025, respectively, were not significant.

[0001045810-25-000209:notes:42]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-25-000209:notes:43]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-25-000209:notes:44]
|  | Jul 27, 2025 |
|  | (In millions) |
| Less than one year | $ | 22,521 |  |
| Due in 1 - 5 years | 30,783 |  |
| Total | $ | 53,304 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-25-000209:notes:45]
[same as prior period, unchanged from 0001045810-25-000116:notes:45]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-25-000209:notes:46]
Fair Value of Non-marketable Equity Securities
Our non-marketable equity securities are recorded in long-term other assets on our Condensed Consolidated Balance Sheets and valued under the measurement alternative. Gains and losses on these investments, realized and unrealized, are recognized in Other income (expense), net on our Condensed Consolidated Statements of Income.

[0001045810-25-000209:notes:47]
Adjustments to the carrying value of our non-marketable equity securities during the second quarter and first half of fiscal years 2026 and 2025 were as follows:

[0001045810-25-000209:notes:48]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 3,240 |  |  | $ | 1,463 |  |  | $ | 3,387 |  |  | $ | 1,321 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 299 |  |  | 294 |  |  | 948 |  |  | 421 |  |
| Unrealized gains | 267 |  |  | 77 |  |  | 330 |  |  | 92 |  |
| Reclassification (1) | (5) |  |  | — |  |  | (848) |  |  | — |  |
| Impairments and unrealized losses | (2) |  |  | (15) |  |  | (18) |  |  | (15) |  |
| Balance at end of period | $ | 3,799 |  |  | $ | 1,819 |  |  | $ | 3,799 |  |  | $ | 1,819 |  |

[0001045810-25-000209:notes:49]
(1)   Represents reclassifications from non-marketable equity securities to marketable securities following public market trading.

[0001045810-25-000209:notes:50]
Non-marketable equity securities had cumulative gross unrealized gains of $661 million and $362 million, and cumulative gross unrealized losses and impairments of $93 million and $60 million on securities held as of July 27, 2025 and July 28, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-25-000209:notes:51]
[same as prior period, unchanged from 0001045810-25-000116:notes:54]

[0001045810-25-000209:notes:52]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 3,054 |  |  | $ | (2,484) |  |  | $ | 570 |  |  | $ | 2,900 |  |  | $ | (2,264) |  |  | $ | 636 |  |
| Patents and licensed technology | 473 |  |  | (288) |  |  | 185 |  |  | 449 |  |  | (278) |  |  | 171 |  |
| Total intangible assets | $ | 3,527 |  |  | $ | (2,772) |  |  | $ | 755 |  |  | $ | 3,349 |  |  | $ | (2,542) |  |  | $ | 807 |  |

[0001045810-25-000209:notes:53]
Amortization expense associated with intangible assets was $84 million and $146 million for the second quarter, and $243 million and $289 million for the first half, of fiscal years 2026 and 2025, respectively.

[0001045810-25-000209:notes:54]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of July 27, 2025:

[0001045810-25-000209:notes:55]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first half of fiscal year 2026) | $ | 160 |  |
| 2027 | 300 |  |
| 2028 | 145 |  |
| 2029 | 46 |  |
| 2030 | 11 |  |
| 2031 and thereafter | 93 |  |
| Total | $ | 755 |  |

[0001045810-25-000209:notes:56]
In the first half of fiscal year 2026, goodwill increased by $567 million from acquisitions and was allocated to our Compute & Networking reporting unit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-25-000209:notes:57]
Balance Sheet Components
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, original device manufacturers, or ODMs, original equipment manufacturers, or OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. Three direct customers accounted for 23%, 19% and 14% of our accounts receivable balance as of July 27, 2025. Two direct customers accounted for 17% and 16% of our accounts receivable balance as of January 26, 2025.

[0001045810-25-000209:notes:58]
[same as prior period, unchanged from 0001045810-25-000116:notes:61]

[0001045810-25-000209:notes:59]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
| Inventories: | (In millions) |
| Raw materials | $ | 1,843 |  |  | $ | 3,408 |  |
| Work in process | 4,411 |  |  | 3,399 |  |
| Finished goods | 8,708 |  |  | 3,273 |  |
| Total inventories (1) | $ | 14,962 |  |  | $ | 10,080 |  |

[0001045810-25-000209:notes:60]
(1)    We recorded an inventory provision of $886 million and $345 million for the second quarter of fiscal years 2026 and 2025, respectively, and $3.2 billion and $555 million for the first half of fiscal years 2026 and 2025, respectively, in cost of revenue.

[0001045810-25-000209:notes:61]
[same as prior period, unchanged from 0001045810-25-000116:notes:64]

[0001045810-25-000209:notes:62]
Property, equipment and intangible assets acquired but not paid for the first half of fiscal years 2026 and 2025 were $1.1 billion and not significant, respectively.

[0001045810-25-000209:notes:63]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
| Other Assets (Long Term): | (In millions) |
| Non-marketable equity securities | $ | 3,799 |  |  | $ | 3,387 |  |
| Prepaid supply and capacity agreements (1) | 1,776 |  |  | 1,747 |  |
| Income tax receivable | 1,042 |  |  | 750 |  |
| Prepaid royalties | 327 |  |  | 340 |  |
| Other | 272 |  |  | 201 |  |
| Total other assets | $ | 7,216 |  |  | $ | 6,425 |  |

[0001045810-25-000209:notes:64]
$1.8 billion and $3.3 billion were included in short-term Prepaid expenses and other current assets as of July 27, 2025 and January 26, 2025, respectively.

[0001045810-25-000209:notes:65]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 4,705 |  |  | $ | 4,880 |  |
| Excess inventory purchase obligations (1) | 3,154 |  |  | 2,095 |  |
| Product warranty and return provisions | 2,245 |  |  | 1,373 |  |
| Taxes payable | 1,910 |  |  | 881 |  |
| Accrued payroll and related expenses | 1,227 |  |  | 848 |  |
| Deferred revenue (2) | 980 |  |  | 837 |  |
| Operating leases | 301 |  |  | 288 |  |
| Licenses and royalties | 284 |  |  | 175 |  |
| Unsettled share repurchases | 185 |  |  | 132 |  |
| Other | 202 |  |  | 228 |  |
| Total accrued and other current liabilities | $ | 15,193 |  |  | $ | 11,737 |  |

[0001045810-25-000209:notes:66]
(1)    We recorded $137 million and $563 million for the second quarter of fiscal years 2026 and 2025, respectively, and $3.1 billion and $746 million for the first half of fiscal years 2026 and 2025, respectively, in cost of revenue

[0001045810-25-000209:notes:67]
(2)    Includes customer advances and unearned revenue related to hardware support, software support, cloud services, and license and development arrangements. The balance as of July 27, 2025 and January 26, 2025 included $80 million and $81 million of customer advances, respectively.

[0001045810-25-000209:notes:68]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 3,081 |  |  | $ | 2,188 |  |
| Deferred income tax | 1,351 |  |  | 886 |  |
| Deferred revenue (2) | 1,055 |  |  | 976 |  |
| Licenses payable | 325 |  |  | 116 |  |
| Other | 243 |  |  | 79 |  |
| Total other long-term liabilities | $ | 6,055 |  |  | $ | 4,245 |  |

[0001045810-25-000209:notes:69]
(1)    Primarily comprised of unrecognized tax benefits and related interest and penalties.

[0001045810-25-000209:notes:70]
(2)    Includes unearned revenue related to hardware support, software support, and cloud services.

[0001045810-25-000209:notes:71]
[same as prior period, unchanged from 0001045810-25-000116:notes:74]

[0001045810-25-000209:notes:72]
The following table shows the changes in short- and long-term deferred revenue during the first half of fiscal years 2026 and 2025:

[0001045810-25-000209:notes:73]
|  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,813 |  |  | $ | 1,337 |  |
| Deferred revenue additions (1) | 8,275 |  |  | 1,478 |  |
| Revenue recognized (2) | (8,053) |  |  | (1,094) |  |
| Balance at end of period | $ | 2,035 |  |  | $ | 1,721 |  |

[0001045810-25-000209:notes:74]
(1)    Includes $7.5 billion and $770 million of customer advances for the first half of fiscal years 2026 and 2025, respectively.

[0001045810-25-000209:notes:75]
(2)    Includes $7.5 billion and $664 million related to customer advances for the first half of fiscal years 2026 and 2025, respectively.

[0001045810-25-000209:notes:76]
We recognized revenue of $479 million and $323 million in the first half of fiscal years 2026 and 2025, respectively, that were included in the prior year end deferred revenue balance.

[0001045810-25-000209:notes:77]
As of July 27, 2025, revenue related to remaining performance obligations from contracts greater than one year in length was $1.9 billion, which includes $1.8 billion from deferred revenue and $118 million which has not yet been billed nor recognized as revenue. Approximately 40% of revenue from contracts greater than one year in length will be recognized over the next twelve months.


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001045810-25-000209:notes:78]
(1)    $1.8 billion and $3.3 billion were included in short-term Prepaid expenses and other current assets as of July 27, 2025 and January 26, 2025, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-25-000209:notes:79]
Derivative Financial Instruments
We utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. The foreign currency forward contracts for operating expenses are designated as accounting hedges. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings. During the first half of fiscal years 2026 and 2025, the impact of foreign currency forward contracts designated as accounting hedges on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.

[0001045810-25-000209:notes:80]
[same as prior period, unchanged from 0001045810-25-000116:notes:82]

[0001045810-25-000209:notes:81]
[same as prior period, unchanged from 0001045810-25-000116:notes:83]

[0001045810-25-000209:notes:82]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
|  | (In millions) |
| Designated as accounting hedges | $ | 1,577 |  |  | $ | 1,424 |  |
| Not designated as accounting hedges | $ | 939 |  |  | $ | 1,297 |  |

[0001045810-25-000209:notes:83]
The unrealized gains and losses or fair value of our foreign currency contracts were not significant as of July 27, 2025 and January 26, 2025.

[0001045810-25-000209:notes:84]
As of July 27, 2025, all foreign currency contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months were not significant.


## us-gaap:DebtDisclosureTextBlock

[0001045810-25-000209:notes:85]
Debt
Long-Term Debt

[0001045810-25-000209:notes:86]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.1 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (34) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,466 |  |  | $ | 8,463 |  |

[0001045810-25-000209:notes:87]
As of July 27, 2025 and January 26, 2025, the estimated fair value of debt was $7.4 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

[0001045810-25-000209:notes:88]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity of the notes is calendar year.

[0001045810-25-000209:notes:89]
As of July 27, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-25-000209:notes:90]
Commercial Paper

[0001045810-25-000209:notes:91]
We have a $575 million commercial paper program to support general corporate purposes. As of July 27, 2025 and January 26, 2025, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-25-000209:notes:92]
Commitments and Contingencies
Commitments

[0001045810-25-000209:notes:93]
Our commitments include obligations to purchase components used to manufacture our products, including certain software and technology licenses, investments, long-lived assets, long-term supply and capacity agreements, multi-year cloud service agreements, and other goods and services.

[0001045810-25-000209:notes:94]
We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs.

[0001045810-25-000209:notes:95]
Total future commitments as of July 27, 2025 are as follows:

[0001045810-25-000209:notes:96]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first half of fiscal year 2026) | $ | 30,930 |  |
| 2027 | 6,573 |  |
| 2028 | 3,915 |  |
| 2029 | 2,736 |  |
| 2030 | 1,402 |  |
| 2031 and thereafter | 218 |  |
| Total | $ | 45,774 |  |

[0001045810-25-000209:notes:97]
Accrual for Product Warranty Liabilities

[0001045810-25-000209:notes:98]
The estimated amount of product warranty liabilities was $2.1 billion and $1.3 billion as of July 27, 2025 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-25-000209:notes:99]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,080 |  |  | $ | 532 |  |  | $ | 1,290 |  |  | $ | 306 |  |
| Additions | 220 |  |  | 237 |  |  | 1,090 |  |  | 471 |  |
| Utilization | (156) |  |  | (28) |  |  | (236) |  |  | (36) |  |
| Balance at end of period | $ | 2,144 |  |  | $ | 741 |  |  | $ | 2,144 |  |  | $ | 741 |  |

[0001045810-25-000209:notes:100]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-25-000209:notes:101]
Litigation

[0001045810-25-000209:notes:102]
Securities Class Action and Derivative Lawsuits

[0001045810-25-000209:notes:103]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the

[0001045810-25-000209:notes:104]
NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

[0001045810-25-000209:notes:105]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-25-000209:notes:106]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-25-000209:notes:107]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. On August 11, 2025, the court granted the parties’ stipulation to voluntarily dismiss with prejudice plaintiff City of Westland Police and Fire Retirement System. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-25-000209:notes:108]
Accounting for Loss Contingencies

[0001045810-25-000209:notes:109]
As of July 27, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-25-000209:notes:110]
Shareholders’ Equity 
Capital Return Program 
67 million and 63 million shares of our common stock for $9.7 billion and $7.0 billion during the second quarter of fiscal years 2026 and 2025, respectively, and 193 million and 162 million shares of our common stock for $24.2 billion and $15.1 billion during the first half of fiscal years 2026 and 2025, respectively. As of July 27, 2025, we were authorized, subject to certain specifications, to repurchase up to $14.7 billion of our common stock.
From July 28, 2025 through August 26, 2025, we repurchased 20 million shares for $3.5 billion pursuant to a pre-established trading plan. On August 26, 2025, our Board of Directors approved an additional $60.0 billion in share repurchase authorization, without expiration. As of August 26, 2025, a total of $71.2 billion was available for repurchase.
$244 million and $246 million during the second quarter, and $488 million and $344 million during the first half, of fiscal years 2026 and 2025, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-25-000209:notes:111]
Segment Information
Our Chief Executive Officer is our chief operating decision maker, or CODM, and reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. Our CODM assesses operating performance of each segment based on regularly provided segment revenue and segment operating income. Operating results by segment include costs or expenses directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments. Our CODM reviews expenses on a consolidated basis, and expenses attributable to each segment are not regularly provided to our CODM.

[0001045810-25-000209:notes:112]
[same as prior period, unchanged from 0001045810-25-000116:notes:117]

[0001045810-25-000209:notes:113]
[same as prior period, unchanged from 0001045810-25-000116:notes:118]

[0001045810-25-000209:notes:114]
Certain expenses are not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related and other costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-25-000209:notes:115]
Our CODM does not review any information regarding total assets on a reportable segment basis. There are no intersegment transactions. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments.

[0001045810-25-000209:notes:116]
|  | Compute & Networking |  | Graphics |  | Total |  |  |  |  |
|  | (In millions) |
| Three Months Ended Jul 27, 2025 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 41,331 |  |  | $ | 5,412 |  |  | $ | 46,743 |  |  |  |  |  |
| Other segment items (1) | 12,968 |  |  | 3,170 |  |  | 16,138 |  |  |  |  |  |
| Operating income (loss) | $ | 28,363 |  |  | $ | 2,242 |  |  | $ | 30,605 |  |  |  |  |  |
| Three Months Ended Jul 28, 2024 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 26,446 |  |  | $ | 3,594 |  |  | $ | 30,040 |  |  |  |  |  |
| Other segment items (1) | 7,598 |  |  | 2,225 |  |  | 9,823 |  |  |  |  |  |
| Operating income (loss) | $ | 18,848 |  |  | $ | 1,369 |  |  | $ | 20,217 |  |  |  |  |  |
| Six Months Ended Jul 27, 2025 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 80,920 |  |  | $ | 9,885 |  |  | $ | 90,805 |  |  |  |  |  |
| Other segment items (1) | 30,503 |  |  | 6,003 |  |  | 36,506 |  |  |  |  |  |
| Operating income (loss) | $ | 50,417 |  |  | $ | 3,882 |  |  | $ | 54,299 |  |  |  |  |  |
| Six Months Ended Jul 28, 2024 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 49,121 |  |  | $ | 6,963 |  |  | $ | 56,084 |  |  |  |  |  |
| Other segment items (1) | 13,225 |  |  | 4,354 |  |  | 17,579 |  |  |  |  |  |
| Operating income (loss) | $ | 35,896 |  |  | $ | 2,609 |  |  | $ | 38,505 |  |  |  |  |  |

[0001045810-25-000209:notes:117]
[same as prior period, unchanged from 0001045810-25-000116:notes:122]

[0001045810-25-000209:notes:118]
Depreciation and amortization expense attributable to our Compute and Networking segment was $383 million and $161 million for the second quarter, and $684 million and $307 million for the first half, of fiscal years 2026 and 2025, respectively. Depreciation and amortization expense attributable to our Graphics segment was $148 million and $86 million for the second quarter, and $252 million and $171 million for the first half, of fiscal years 2026 and 2025, respectively. Acquisition-related intangible amortization expense is not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance.

[0001045810-25-000209:notes:119]
A reconciliation of segment operating income to consolidated income before income tax for the second quarter and first half of fiscal years 2026 and 2025 were as follows:

[0001045810-25-000209:notes:120]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |  |  |
|  | (In millions) |  |  |
| Segment operating income | $ | 30,605 |  |  | $ | 20,217 |  |  | $ | 54,299 |  |  | $ | 38,505 |  |  |  |
| Stock-based compensation expense | (1,624) |  |  | (1,154) |  |  | (3,099) |  |  | (2,164) |  |  |  |
| Unallocated cost of revenue and operating expenses | (440) |  |  | (280) |  |  | (859) |  |  | (508) |  |  |  |
| Acquisition-related and other costs | (101) |  |  | (141) |  |  | (263) |  |  | (282) |  |  |  |
| Interest income | 592 |  |  | 444 |  |  | 1,108 |  |  | 803 |  |  |  |
| Interest expense | (62) |  |  | (61) |  |  | (124) |  |  | (125) |  |  |  |
| Other income (expense), net | 2,236 |  |  | 189 |  |  | 2,055 |  |  | 264 |  |  |  |
| Consolidated income before income tax | $ | 31,206 |  |  | $ | 19,214 |  |  | $ | 53,117 |  |  | $ | 36,493 |  |  |  |

[0001045810-25-000209:notes:121]
[same as prior period, unchanged from 0001045810-25-000116:notes:125]

[0001045810-25-000209:notes:122]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Geographic Revenue based upon Customer Billing Location: |  |  |  |  |  |  |  |
| United States | $ | 23,470 |  |  | $ | 13,022 |  |  | $ | 44,209 |  |  | $ | 26,518 |  |
| Singapore (1) | 10,156 |  |  | 5,622 |  |  | 19,173 |  |  | 9,659 |  |
| Taiwan | 8,529 |  |  | 5,740 |  |  | 15,687 |  |  | 10,113 |  |
| China (including Hong Kong) | 2,769 |  |  | 3,667 |  |  | 8,291 |  |  | 6,158 |  |
| Other | 1,819 |  |  | 1,989 |  |  | 3,445 |  |  | 3,636 |  |
| Total revenue | $ | 46,743 |  |  | $ | 30,040 |  |  | $ | 90,805 |  |  | $ | 56,084 |  |

[0001045810-25-000209:notes:123]
(1)    Singapore represented 22%, and 21% of the second quarter and first half of fiscal year 2026 total revenue based upon customer billing location, respectively. Customers use Singapore to centralize invoicing while our products are almost always shipped elsewhere. Over 99% of controlled Data Center compute revenue billed to Singapore was for orders from U.S.-based customers for the second quarter and first half of fiscal year 2026. Controlled Data Center compute refers to products that meet the characteristics of Export Control Classification Numbers 3A090.a or 4A090.a.

[0001045810-25-000209:notes:124]
Revenue from sales to customers outside of the United States accounted for 50% and 51% of total revenue for the second quarter and first half of fiscal year 2026, respectively, and 57% and 53% of total revenue for the second quarter and first half of fiscal year 2025, respectively.

[0001045810-25-000209:notes:125]
[same as prior period, unchanged from 0001045810-25-000116:notes:129]

[0001045810-25-000209:notes:126]
For the second quarter of fiscal year 2026, sales to one direct customer, Customer A, represented 23% of total revenue; and sales to a second direct customer, Customer B, represented 16% of total revenue, respectively, both of which were attributable to the Compute & Networking segment. For the first half of fiscal year 2026, sales to one direct customer, Customer A, represented 20% of total revenue; and sales to a second direct customer, Customer B, represented 15% of total revenue, respectively, both of which were attributable to the Compute & Networking segment.

[0001045810-25-000209:notes:127]
Sales to four direct customers represented 14%, 11%, 11%, and 10% of revenue for the second quarter, and sales to three direct customers represented 14%, 10%, and 10% of revenue for the first half, of fiscal year 2025, all of which were attributable to the Compute & Networking segment.

[0001045810-25-000209:notes:128]
[same as prior period, unchanged from 0001045810-25-000116:notes:131]

[0001045810-25-000209:notes:129]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Revenue by End Market: |  |  |  |  |  |  |  |
| Data Center | $ | 41,096 |  |  | $ | 26,272 |  |  | $ | 80,208 |  |  | $ | 48,835 |  |
| Compute | 33,844 |  |  | 22,604 |  |  | 67,999 |  |  | 41,996 |  |
| Networking | 7,252 |  |  | 3,668 |  |  | 12,209 |  |  | 6,839 |  |
| Gaming | 4,287 |  |  | 2,880 |  |  | 8,050 |  |  | 5,527 |  |
| Professional Visualization | 601 |  |  | 454 |  |  | 1,110 |  |  | 881 |  |
| Automotive | 586 |  |  | 346 |  |  | 1,153 |  |  | 675 |  |
| OEM and Other | 173 |  |  | 88 |  |  | 284 |  |  | 166 |  |
| Total revenue | $ | 46,743 |  |  | $ | 30,040 |  |  | $ | 90,805 |  |  | $ | 56,084 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-25-000209:notes:130]
The table below presents details of our reportable segments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-25-000209:notes:131]
Leases
Our lease obligations primarily consist of operating leases for our offices and data centers, with lease periods expiring between fiscal years 2026 and 2041.

[0001045810-25-000209:notes:132]
Future minimum lease obligations under our non-cancelable lease agreements as of July 27, 2025 were as follows:

[0001045810-25-000209:notes:133]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first half of fiscal year 2026) | $ | 174 |  |
| 2027 | 418 |  |
| 2028 | 397 |  |
| 2029 | 353 |  |
| 2030 | 277 |  |
| 2031 and thereafter | 925 |  |
| Total | 2,544 |  |
| Less imputed interest | 412 |  |
| Present value of net future minimum lease payments | 2,132 |  |
| Less short-term operating lease liabilities | 301 |  |
| Long-term operating lease liabilities | $ | 1,831 |  |

[0001045810-25-000209:notes:134]
Between the third quarter of fiscal year 2026 and fiscal year 2030, we expect to commence leases with future obligations of $7.1 billion primarily of data center leases, with lease terms of 2 to 15 years.

[0001045810-25-000209:notes:135]
Operating lease expenses were $109 million and $84 million for the second quarter, and $210 million and $164 million for the first half, of fiscal years 2026 and 2025, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal years 2026 and 2025 were not significant.

[0001045810-25-000209:notes:136]
[same as prior period, unchanged from 0001045810-25-000116:notes:139]

[0001045810-25-000209:notes:137]
|  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 200 |  |  | $ | 146 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 458 |  |  | $ | 405 |  |

[0001045810-25-000209:notes:138]
As of July 27, 2025, our operating leases have a weighted average remaining lease term of 7.5 years and a weighted average discount rate of 4.35%. As of January 26, 2025, our operating leases had a weighted average remaining lease term of 6.5 years and a weighted average discount rate of 4.16%.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-25-000209:notes:139]
| Name |  | Title of Director or Officer |  | Action |  | Date |  | Total Shares of Common Stock to be Sold |
| A. Brooke Seawell |  | Director |  | Termination |  | July 14, 2025 |  | 1,153,049* |

[0001045810-25-000209:notes:140]
*The Rule 10b5-1 Trading Arrangement was adopted on March 19, 2025 for sales through July 31, 2025, with an estimated formulaic number of shares. 770,522 shares were actually sold under the Rule 10b5-1 Trading Arrangement prior to termination.
