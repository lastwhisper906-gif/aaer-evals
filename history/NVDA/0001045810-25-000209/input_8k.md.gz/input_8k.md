# NVDA 8-K — 0001045810-25-000207 filed 2025-08-27

## item codes, every 8-K on or before 2025-08-27

- 2025-08-27 0001045810-25-000207 — 2.02, 9.01
- 2025-08-05 0001045810-25-000197 — 5.02
- 2025-07-01 0001045810-25-000179 — 5.07
- 2025-05-28 0001045810-25-000115 — 2.02, 9.01
- 2025-04-15 0001045810-25-000082 — 8.01
- 2025-03-07 0001045810-25-000039 — 5.02
- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2025-08-27

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-25-000207:8k_2_02:1]
EX-99.1
2
q2fy26pr.htm
EX-99.1

[0001045810-25-000207:8k_2_02:2]
Document

[0001045810-25-000207:8k_2_02:3]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2026

[0001045810-25-000207:8k_2_02:4]
•Revenue of $46.7 billion, up 6% from Q1 and up 56% from a year ago

[0001045810-25-000207:8k_2_02:5]
•Data Center revenue of $41.1 billion, up 5% from Q1 and up 56% from a year ago

[0001045810-25-000207:8k_2_02:6]
•Blackwell Data Center revenue grew 17% sequentially

[0001045810-25-000207:8k_2_02:7]
SANTA CLARA, Calif.—Aug. 27, 2025―NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 27, 2025, of $46.7 billion, up 6% from the previous quarter and up 56% from a year ago. NVIDIA’s Blackwell Data Center revenue grew 17% sequentially.

[0001045810-25-000207:8k_2_02:8]
There were no H20 sales to China-based customers in the second quarter. NVIDIA benefited from a $180 million release of previously reserved H20 inventory, from approximately $650 million in unrestricted H20 sales to a customer outside of China.

[0001045810-25-000207:8k_2_02:9]
For the quarter, GAAP and non-GAAP gross margins were 72.4% and 72.7%, respectively. Excluding the $180 million release, non-GAAP gross margin for the quarter would have been 72.3%.

[0001045810-25-000207:8k_2_02:10]
For the quarter, GAAP and non-GAAP earnings per diluted share were $1.08 and $1.05, respectively. Excluding the $180 million release and related tax impact, non-GAAP diluted earnings per share for the quarter would have been $1.04.

[0001045810-25-000207:8k_2_02:11]
“Blackwell is the AI platform the world has been waiting for, delivering an exceptional generational leap — production of Blackwell Ultra is ramping at full speed, and demand is extraordinary,” said Jensen Huang, founder and CEO of NVIDIA. “NVIDIA NVLink rack-scale computing is revolutionary, arriving just in time as reasoning AI models drive orders-of-magnitude increases in training and inference performance. The AI race is on, and Blackwell is the platform at its center.”

[0001045810-25-000207:8k_2_02:12]
During the first half of fiscal 2026, NVIDIA returned $24.3 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the second quarter, the company had $14.7 billion remaining under its share repurchase authorization. On August 26, 2025, the Board of Directors approved an additional $60.0 billion to the Company’s share repurchase authorization, without expiration.

[0001045810-25-000207:8k_2_02:13]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on October 2, 2025, to all shareholders of record on September 11, 2025.

[0001045810-25-000207:8k_2_02:14]
Q2 Fiscal 2026 Summary

[0001045810-25-000207:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY26 | Q1 FY26 | Q2 FY25 | Q/Q | Y/Y |
| Revenue | $46,743 | $44,062 | $30,040 | 6 | % | 56 | % |
| Gross margin | 72.4 | % | 60.5 | % | 75.1 | % | 11.9 pts | (2.7) pts |
| Operating expenses | $5,413 | $5,030 | $3,932 | 8 | % | 38 | % |
| Operating income | $28,440 | $21,638 | $18,642 | 31 | % | 53 | % |
| Net income | $26,422 | $18,775 | $16,599 | 41 | % | 59 | % |
| Diluted earnings per share | $1.08 | $0.76 | $0.67 | 42 | % | 61 | % |

[0001045810-25-000207:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY26 | Q1 FY26 | Q2 FY25 | Q/Q | Y/Y |
| Revenue | $46,743 | $44,062 | $30,040 | 6 | % | 56 | % |
| Gross margin | 72.7 | % | 61.0 | % | 75.7 | % | 11.7 pts | (3.0) pts |
| Gross margin excluding H20 related charges/releases, net | 72.3 | % | 71.3 | % |  | 1.0 | pt |  |
| Operating expenses | $3,795 | $3,583 | $2,792 | 6 | % | 36 | % |
| Operating income | $30,165 | $23,275 | $19,937 | 30 | % | 51 | % |
| Net income | $25,783 | $19,894 | $16,952 | 30 | % | 52 | % |
| Diluted earnings per share | $1.05 | $0.81 | $0.68 | 30 | % | 54 | % |
| Diluted earnings per share excluding H20 related charges/releases, net and related tax impact | $1.04 | $0.96 |  | 8 | % |  |

[0001045810-25-000207:8k_2_02:17]
Outlook

[0001045810-25-000207:8k_2_02:18]
NVIDIA’s outlook for the third quarter of fiscal 2026 is as follows:

[0001045810-25-000207:8k_2_02:19]
•Revenue is expected to be $54.0 billion, plus or minus 2%. The company has not assumed any H20 shipments to China in the outlook.

[0001045810-25-000207:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 73.3% and 73.5%, respectively, plus or minus 50 basis points. The company continues to expect to exit the year with non-GAAP gross margins in the mid-70% range.

[0001045810-25-000207:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $5.9 billion and $4.2 billion, respectively. Full year fiscal 2026 operating expense growth is expected to be in the high-30% range.

[0001045810-25-000207:8k_2_02:22]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $500 million, excluding gains and losses from non-marketable and publicly-held equity securities.

[0001045810-25-000207:8k_2_02:23]
•GAAP and non-GAAP tax rates are expected to be 16.5%, plus or minus 1%, excluding any discrete items.

[0001045810-25-000207:8k_2_02:24]
Highlights

[0001045810-25-000207:8k_2_02:25]
NVIDIA achieved progress since its first quarter earnings announcement in these areas:

[0001045810-25-000207:8k_2_02:26]
Data Center

[0001045810-25-000207:8k_2_02:27]
•Second-quarter revenue was $41.1 billion, up 5% from the previous quarter and up 56% from a year ago.

[0001045810-25-000207:8k_2_02:28]
•Announced that the NVIDIA RTX PRO™ 6000 Blackwell Server Edition GPU is coming to the world’s most popular enterprise servers; Disney, Foxconn, Hitachi Ltd., Hyundai Motor Group, Lilly, SAP and TSMC are among the first to adopt the servers.

[0001045810-25-000207:8k_2_02:29]
•Introduced NVIDIA® Spectrum-XGS Ethernet to connect distributed data centers for giga-scale AI.

[0001045810-25-000207:8k_2_02:30]
•Revealed that NVIDIA is working with European nations, including France, Germany, Italy, Spain and the U.K., as well as technology industry leaders to build NVIDIA Blackwell AI infrastructure, including the world’s first industrial AI cloud for European manufacturers, to fuel region’s next industrial transformation.

[0001045810-25-000207:8k_2_02:31]
•Announced the expansion of NVIDIA DGX Cloud Lepton™ to connect Europe’s developers to NVIDIA’s global compute ecosystem.

[0001045810-25-000207:8k_2_02:32]
•Collaborated with partners globally to build and accelerate advanced AI supercomputers, including Doudna (U.S.), JUPITER (Germany), Blue Lion (Germany), Isambard (U.K.) and FugakuNEXT (Japan).

[0001045810-25-000207:8k_2_02:33]
•Revealed that model builders across Europe and the Middle East are optimizing their sovereign large language models with NVIDIA Nemotron™, which will be available on Perplexity.

[0001045810-25-000207:8k_2_02:34]
•Supported the launch of OpenAI’s open gpt-oss models, delivering industry-leading gpt-oss-120b performance of 1.5 million tokens per second on a single NVIDIA Blackwell GB200 NVL72 rack-scale system.

[0001045810-25-000207:8k_2_02:35]
•Announced a collaboration with Novo Nordisk and DCAI to advance drug discovery.

[0001045810-25-000207:8k_2_02:36]
•Revealed that the NVIDIA Blackwell platform delivered the highest performance at scale on every MLPerf Training benchmark.

[0001045810-25-000207:8k_2_02:37]
•Teamed with Ansys and DCAI to advance quantum algorithms for fluid dynamics using the NVIDIA CUDA-Q™ platform on Denmark’s Gefion supercomputer.

[0001045810-25-000207:8k_2_02:38]
•Introduced NVFP4, a 4-bit format purpose-built to deliver exceptional inference latency, for pretraining next-generation large language models.

[0001045810-25-000207:8k_2_02:39]
Gaming and AI PC

[0001045810-25-000207:8k_2_02:40]
•Second-quarter Gaming revenue was $4.3 billion, up 14% from the previous quarter and up 49% from a year ago.

[0001045810-25-000207:8k_2_02:41]
•Launched the Blackwell-powered NVIDIA GeForce RTX™ 5060, which quickly became NVIDIA’s fastest-ramping x60-class GPU ever.

[0001045810-25-000207:8k_2_02:42]
•Made industry-leading NVIDIA DLSS 4 technology available in over 175 games and apps, and coming next to top games such as Borderlands 4, Resident Evil Requiem and Phantom Blade Zero.

[0001045810-25-000207:8k_2_02:43]
•Announced Blackwell coming to GeForce NOW™ with the new Install-to-Play feature, doubling the game library to over 4,500 titles.

[0001045810-25-000207:8k_2_02:44]
•Partnered with OpenAI on the launch of its newest open-weight models optimized for RTX GPUs for fast, local inference in popular tools like Ollama, llama.cpp and Microsoft AI Foundry Local.

[0001045810-25-000207:8k_2_02:45]
Professional Visualization

[0001045810-25-000207:8k_2_02:46]
•Second-quarter revenue was $601 million, up 18% from the previous quarter and up 32% from a year ago.

[0001045810-25-000207:8k_2_02:47]
•Announced NVIDIA RTX PRO 4000 SFF Edition and RTX PRO 2000 Blackwell GPUs.

[0001045810-25-000207:8k_2_02:48]
•Expanded partnership with Siemens to digitalize and enable the manufacturing factory of the future.

[0001045810-25-000207:8k_2_02:49]
•Announced new NVIDIA Omniverse™ libraries and software development kits to accelerate physical AI development.

[0001045810-25-000207:8k_2_02:50]
Automotive and Robotics

[0001045810-25-000207:8k_2_02:51]
•Second-quarter Automotive revenue was $586 million, up 3% from the previous quarter and up 69% from a year ago.

[0001045810-25-000207:8k_2_02:52]
•Announced that the full-stack NVIDIA DRIVE™ AV software platform is now in full production to accelerate the large-scale deployment of safe, intelligent transportation.

[0001045810-25-000207:8k_2_02:53]
•Achieved second consecutive win in the End-to-End Driving at Scale category of the Autonomous Grand Challenge at the Computer Vision and Pattern Recognition conference.

[0001045810-25-000207:8k_2_02:54]
•Commenced initial shipments of the NVIDIA DRIVE AGX Thor™ system-on-a-chip.

[0001045810-25-000207:8k_2_02:55]
•Announced the general availability of NVIDIA Jetson AGX Thor™ developer kit and production modules, powerful new AI supercomputers designed to power millions of robots across industries.

[0001045810-25-000207:8k_2_02:56]
•Released the NVIDIA Halos full-stack safety platform for robotic development.

[0001045810-25-000207:8k_2_02:57]
•Announced new NVIDIA Cosmos™ world foundation models that accelerate the development and deployment of robotics solutions.

[0001045810-25-000207:8k_2_02:58]
CFO Commentary

[0001045810-25-000207:8k_2_02:59]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-25-000207:8k_2_02:60]
Conference Call and Webcast Information

[0001045810-25-000207:8k_2_02:61]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2026 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2026.

[0001045810-25-000207:8k_2_02:62]
Non-GAAP Measures

[0001045810-25-000207:8k_2_02:63]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains/losses from non-marketable and publicly-held equity securities, net, interest expense related to amortization of debt discount, H20 related charges/releases, net and the associated tax impact of these items where applicable. The inclusion of H20

[0001045810-25-000207:8k_2_02:64]
related charges/releases, net in the reconciliations to adjust the related GAAP financial measures was a result of the U.S. government informing NVIDIA in April 2025 that it requires a license for export to China of H20 product. The H20 product was designed primarily for the China market. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-25-000207:8k_2_02:65]
About NVIDIA

[0001045810-25-000207:8k_2_02:66]
NVIDIA (NASDAQ: NVDA) is the world leader in accelerated computing.

[0001045810-25-000207:8k_2_02:67]
###

[0001045810-25-000207:8k_2_02:68]
For further information, contact:

[0001045810-25-000207:8k_2_02:69]
| Toshiya Hari |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| toshiyah@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-25-000207:8k_2_02:70]
© 2025 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, NVIDIA Cosmos, NVIDIA CUDA-Q, NVIDIA DGX Cloud Lepton, NVIDIA DRIVE, NVIDIA DRIVE AGX Thor, NVIDIA GeForce RTX, NVIDIA Jetson AGX Thor, NVIDIA Nemotron, NVIDIA Omniverse, and NVIDIA RTX PRO are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-25-000207:8k_2_02:71]
NVIDIA CORPORATION

[0001045810-25-000207:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-25-000207:8k_2_02:73]
(In millions, except per share data)

[0001045810-25-000207:8k_2_02:74]
(Unaudited)

[0001045810-25-000207:8k_2_02:75]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue | $ | 46,743 |  |  | $ | 30,040 |  |  | $ | 90,805 |  |  | $ | 56,084 |  |
| Cost of revenue | 12,890 |  |  | 7,466 |  |  | 30,284 |  |  | 13,105 |  |
| Gross profit | 33,853 |  |  | 22,574 |  |  | 60,521 |  |  | 42,979 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 4,291 |  |  | 3,090 |  |  | 8,280 |  |  | 5,810 |  |
|  | Sales, general and administrative | 1,122 |  |  | 842 |  |  | 2,163 |  |  | 1,618 |  |
|  |  | Total operating expenses | 5,413 |  |  | 3,932 |  |  | 10,443 |  |  | 7,428 |  |
| Operating income | 28,440 |  |  | 18,642 |  |  | 50,078 |  |  | 35,551 |  |
|  | Interest income | 592 |  |  | 444 |  |  | 1,108 |  |  | 803 |  |
|  | Interest expense | (62) |  |  | (61) |  |  | (124) |  |  | (125) |  |
|  | Other income (expense), net | 2,236 |  |  | 189 |  |  | 2,055 |  |  | 264 |  |
|  |  | Total other income (expense), net | 2,766 |  |  | 572 |  |  | 3,039 |  |  | 942 |  |
| Income before income tax | 31,206 |  |  | 19,214 |  |  | 53,117 |  |  | 36,493 |  |
| Income tax expense | 4,784 |  |  | 2,615 |  |  | 7,920 |  |  | 5,013 |  |
| Net income | $ | 26,422 |  |  | $ | 16,599 |  |  | $ | 45,197 |  |  | $ | 31,480 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 1.08 |  |  | $ | 0.68 |  |  | $ | 1.85 |  |  | $ | 1.28 |  |
|  | Diluted | $ | 1.08 |  |  | $ | 0.67 |  |  | $ | 1.84 |  |  | $ | 1.27 |  |
| Weighted average shares used in per share computation: |
|  | Basic | 24,366 |  |  | 24,578 |  |  | 24,404 |  |  | 24,599 |  |
|  | Diluted | 24,532 |  |  | 24,848 |  |  | 24,571 |  |  | 24,869 |  |

[0001045810-25-000207:8k_2_02:76]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | July 27, |  | January 26, |
|  |  |  |  | 2025 |  | 2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 56,791 |  |  | $ | 43,210 |  |
|  | Accounts receivable, net |  | 27,808 |  |  | 23,065 |  |
|  | Inventories |  | 14,962 |  |  | 10,080 |  |
|  | Prepaid expenses and other current assets |  | 2,658 |  |  | 3,771 |  |
|  |  | Total current assets |  | 102,219 |  |  | 80,126 |  |
| Property and equipment, net |  | 9,141 |  |  | 6,283 |  |
| Operating lease assets |  | 2,084 |  |  | 1,793 |  |
| Goodwill |  | 5,755 |  |  | 5,188 |  |
| Intangible assets, net |  | 755 |  |  | 807 |  |
| Deferred income tax assets |  | 13,570 |  |  | 10,979 |  |
| Other assets |  | 7,216 |  |  | 6,425 |  |
|  |  | Total assets |  | $ | 140,740 |  |  | $ | 111,601 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 9,064 |  |  | $ | 6,310 |  |
|  | Accrued and other current liabilities |  | 15,193 |  |  | 11,737 |  |
|  |  | Total current liabilities |  | 24,257 |  |  | 18,047 |  |
| Long-term debt |  | 8,466 |  |  | 8,463 |  |
| Long-term operating lease liabilities |  | 1,831 |  |  | 1,519 |  |
| Other long-term liabilities |  | 6,055 |  |  | 4,245 |  |
|  |  | Total liabilities |  | 40,609 |  |  | 32,274 |  |
| Shareholders' equity |  | 100,131 |  |  | 79,327 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 140,740 |  |  | $ | 111,601 |  |

[0001045810-25-000207:8k_2_02:77]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | July 27, |  | July 28, |  | July 27, |  | July 28, |  |  |  |  |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 26,422 |  |  | $ | 16,599 |  |  | $ | 45,197 |  |  | $ | 31,480 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,624 |  |  | 1,154 |  |  | 3,099 |  |  | 2,164 |  |  |  |  |  |
| Depreciation and amortization | 668 |  |  | 433 |  |  | 1,280 |  |  | 843 |  |  |  |  |  |
| Deferred income taxes | 18 |  |  | (1,699) |  |  | (2,160) |  |  | (3,276) |  |  |  |  |  |
| Gains on non-marketable equity securities and publicly-held equity securities, net | (2,247) |  |  | (193) |  |  | (2,073) |  |  | (264) |  |  |  |  |  |
| Other | (100) |  |  | (144) |  |  | (196) |  |  | (288) |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | (5,675) |  |  | (1,767) |  |  | (4,743) |  |  | (4,133) |  |  |  |  |  |
| Inventories | (3,622) |  |  | (803) |  |  | (4,880) |  |  | (1,380) |  |  |  |  |  |
| Prepaid expenses and other assets | 387 |  |  | 714 |  |  | 946 |  |  | (12) |  |  |  |  |  |
| Accounts payable | 1,314 |  |  | 823 |  |  | 2,255 |  |  | 801 |  |  |  |  |  |
| Accrued and other current liabilities | (4,053) |  |  | (888) |  |  | 3,075 |  |  | 3,314 |  |  |  |  |  |
| Other long-term liabilities | 629 |  |  | 260 |  |  | 979 |  |  | 584 |  |  |  |  |  |
| Net cash provided by operating activities | 15,365 |  |  | 14,489 |  |  | 42,779 |  |  | 29,833 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 3,130 |  |  | 4,094 |  |  | 6,252 |  |  | 8,098 |  |  |  |  |  |
| Proceeds from sales of marketable securities | 20 |  |  | 15 |  |  | 487 |  |  | 164 |  |  |  |  |  |
| Proceeds from sales of non-marketable equity securities | 70 |  |  | 50 |  |  | 70 |  |  | 105 |  |  |  |  |  |
| Purchases of marketable securities | (7,812) |  |  | (5,744) |  |  | (14,358) |  |  | (15,047) |  |  |  |  |  |
| Purchase related to property and equipment and intangible assets | (1,894) |  |  | (977) |  |  | (3,122) |  |  | (1,346) |  |  |  |  |  |
| Purchases of non-marketable equity securities | (346) |  |  | (344) |  |  | (995) |  |  | (534) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (294) |  |  | (279) |  |  | (677) |  |  | (317) |  |  |  |  |  |
| Net cash used in investing activities | (7,126) |  |  | (3,185) |  |  | (12,343) |  |  | (8,877) |  |  |  |  |  |

[0001045810-25-000207:8k_2_02:78]
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | — |  |  | — |  |  | 370 |  |  | 285 |  |  |  |  |  |
| Payments related to repurchases of common stock | (9,721) |  |  | (7,158) |  |  | (23,815) |  |  | (14,898) |  |  |  |  |  |
| Payments related to employee stock plan taxes | (1,848) |  |  | (1,637) |  |  | (3,380) |  |  | (3,389) |  |  |  |  |  |
| Dividends paid | (244) |  |  | (246) |  |  | (488) |  |  | (344) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (21) |  |  | (29) |  |  | (73) |  |  | (69) |  |  |  |  |  |
| Repayment of debt | — |  |  | (1,250) |  |  | — |  |  | (1,250) |  |  |  |  |  |
| Net cash used in financing activities | (11,834) |  |  | (10,320) |  |  | (27,386) |  |  | (19,665) |  |  |  |  |  |
| Change in cash and cash equivalents | (3,595) |  |  | 984 |  |  | 3,050 |  |  | 1,291 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 15,234 |  |  | 7,587 |  |  | 8,589 |  |  | 7,280 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 11,639 |  |  | $ | 8,571 |  |  | $ | 11,639 |  |  | $ | 8,571 |  |  |  |  |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 8,094 |  |  | $ | 7,208 |  |  | $ | 8,451 |  |  | $ | 7,449 |  |  |  |  |  |

[0001045810-25-000207:8k_2_02:79]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 27, |  | April 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  |  | 2025 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| GAAP cost of revenue |  | $ | 12,890 |  |  | $ | 17,394 |  |  | $ | 7,466 |  |  | $ | 30,284 |  |  | $ | 13,105 |  |
| GAAP gross profit |  | $ | 33,853 |  |  | $ | 26,668 |  |  | $ | 22,574 |  |  | $ | 60,521 |  |  | $ | 42,979 |  |
| GAAP gross margin |  | 72.4 | % |  | 60.5 | % |  | 75.1 | % |  | 66.6 | % |  | 76.6 | % |
|  | Acquisition-related and other costs (A) |  | 49 |  |  | 123 |  |  | 118 |  |  | 170 |  |  | 238 |  |
|  | Stock-based compensation expense (B) |  | 58 |  |  | 64 |  |  | 40 |  |  | 123 |  |  | 75 |  |
|  | Other |  | — |  |  | 3 |  |  | (3) |  |  | 4 |  |  | (4) |  |
| Non-GAAP cost of revenue |  | $ | 12,783 |  |  | $ | 17,204 |  |  | $ | 7,311 |  |  | $ | 29,987 |  |  | $ | 12,796 |  |
| Non-GAAP gross profit |  | $ | 33,960 |  |  | $ | 26,858 |  |  | $ | 22,729 |  |  | $ | 60,818 |  |  | $ | 43,288 |  |
| Non-GAAP gross margin |  | 72.7 | % |  | 61.0 | % |  | 75.7 | % |  | 67.0 | % |  | 77.2 | % |
|  | H20 related charges/(releases), net |  | (180) |  |  | 4,538 |  |  |  |  | 4,358 |  |  |  |
| Non-GAAP gross profit, as adjusted to exclude H20 related charges/releases, net |  | $ | 33,780 |  |  | $ | 31,396 |  |  |  |  | $ | 65,176 |  |  |  |
|  | Non-GAAP gross margin, as adjusted to exclude H20 related charges/releases, net |  | 72.3 | % |  | 71.3 | % |  |  |  | 71.8 | % |  |  |
| GAAP operating expenses |  | $ | 5,413 |  |  | $ | 5,030 |  |  | $ | 3,932 |  |  | $ | 10,443 |  |  | $ | 7,428 |  |
|  | Stock-based compensation expense (B) |  | (1,566) |  |  | (1,410) |  |  | (1,114) |  |  | (2,976) |  |  | (2,089) |  |
|  | Acquisition-related and other costs (A) |  | (37) |  |  | (37) |  |  | (26) |  |  | (74) |  |  | (48) |  |
|  | Other |  | (15) |  |  | — |  |  | — |  |  | (15) |  |  | — |  |
| Non-GAAP operating expenses |  | $ | 3,795 |  |  | $ | 3,583 |  |  | $ | 2,792 |  |  | $ | 7,378 |  |  | $ | 5,291 |  |
| GAAP operating income |  | $ | 28,440 |  |  | $ | 21,638 |  |  | $ | 18,642 |  |  | $ | 50,078 |  |  | $ | 35,551 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,725 |  |  | 1,637 |  |  | 1,295 |  |  | 3,362 |  |  | 2,446 |  |
| Non-GAAP operating income |  | $ | 30,165 |  |  | $ | 23,275 |  |  | $ | 19,937 |  |  | $ | 53,440 |  |  | $ | 37,997 |  |
| GAAP total other income (expense), net |  | $ | 2,766 |  |  | $ | 272 |  |  | $ | 572 |  |  | $ | 3,039 |  |  | $ | 942 |  |
|  | (Gains) losses from non-marketable equity securities and publicly-held equity securities, net |  | (2,247) |  |  | 175 |  |  | (193) |  |  | (2,073) |  |  | (264) |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Non-GAAP total other income (expense), net |  | $ | 520 |  |  | $ | 448 |  |  | $ | 380 |  |  | $ | 968 |  |  | $ | 680 |  |
| GAAP net income |  | $ | 26,422 |  |  | $ | 18,775 |  |  | $ | 16,599 |  |  | $ | 45,197 |  |  | $ | 31,480 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | (521) |  |  | 1,813 |  |  | 1,103 |  |  | 1,291 |  |  | 2,184 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (166) |  |  | (694) |  |  | (750) |  |  | (859) |  |  | (1,475) |  |
|  | Tax expense from OBBBA* |  | 48 |  |  | — |  |  | — |  |  | 48 |  |  | — |  |
| Non-GAAP net income |  | $ | 25,783 |  |  | $ | 19,894 |  |  | $ | 16,952 |  |  | $ | 45,677 |  |  | $ | 32,189 |  |
|  | Total pre-tax impact of H20 related charges/(releases), net |  | (180) |  |  | 4,538 |  |  |  |  | 4,358 |  |  |  |

[0001045810-25-000207:8k_2_02:80]
|  | Income tax impact of H20 related charges/releases, net |  | (8) |  |  | (797) |  |  |  |  | (805) |  |  |  |
| Non-GAAP net income, as adjusted to exclude H20 related charges/releases, net |  | $ | 25,595 |  |  | $ | 23,635 |  |  |  |  | $ | 49,230 |  |  |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 1.08 |  |  | $ | 0.76 |  |  | $ | 0.67 |  |  | $ | 1.84 |  |  | $ | 1.27 |  |
|  | Non-GAAP |  | $ | 1.05 |  |  | $ | 0.81 |  |  | $ | 0.68 |  |  | $ | 1.86 |  |  | $ | 1.29 |  |
|  | Non-GAAP, as adjusted to exclude H20 related charges/releases, net |  | $ | 1.04 |  |  | $ | 0.96 |  |  |  |  | $ | 2.00 |  |  |  |
| Weighted average shares used in diluted net income per share computation |  | 24,532 |  |  | 24,611 |  |  | 24,848 |  |  | 24,571 |  |  | 24,869 |  |
| GAAP net cash provided by operating activities |  | $ | 15,365 |  |  | $ | 27,414 |  |  | $ | 14,489 |  |  | $ | 42,779 |  |  | $ | 29,833 |  |
|  | Purchases related to property and equipment and intangible assets |  | (1,894) |  |  | (1,227) |  |  | (977) |  |  | (3,122) |  |  | (1,346) |  |
|  | Principal payments on property and equipment and intangible assets |  | (21) |  |  | (52) |  |  | (29) |  |  | (73) |  |  | (69) |  |
| Free cash flow |  | $ | 13,450 |  |  | $ | 26,135 |  |  | $ | 13,483 |  |  | $ | 39,584 |  |  | $ | 28,418 |  |
| *Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act) |

[0001045810-25-000207:8k_2_02:81]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 27, |  | April 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  |  | 2025 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Cost of revenue |  | $ | 49 |  |  | $ | 123 |  |  | $ | 118 |  |  | $ | 170 |  |  | $ | 238 |  |
|  | Research and development |  | $ | 29 |  |  | $ | 28 |  |  | $ | 17 |  |  | $ | 57 |  |  | $ | 30 |  |
|  | Sales, general and administrative |  | $ | 8 |  |  | $ | 9 |  |  | $ | 9 |  |  | $ | 17 |  |  | $ | 18 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 27, |  | April 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  |  | 2025 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Cost of revenue |  | $ | 58 |  |  | $ | 64 |  |  | $ | 40 |  |  | $ | 123 |  |  | $ | 75 |  |
|  | Research and development |  | $ | 1,191 |  |  | $ | 1,063 |  |  | $ | 832 |  |  | $ | 2,254 |  |  | $ | 1,559 |  |
|  | Sales, general and administrative |  | $ | 375 |  |  | $ | 347 |  |  | $ | 282 |  |  | $ | 722 |  |  | $ | 530 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-25-000207:8k_2_02:82]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2026 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 73.3 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.2 | % |
| Non-GAAP gross margin |  | 73.5 | % |
| GAAP operating expenses |  | $ | 5,900 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,700) |  |
| Non-GAAP operating expenses |  | $ | 4,200 |  |
