# NVDA note change history — 0001045810-25-000116 → 0001045810-25-000209


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-27):
[0001045810-25-000209:note_history:1]
Commitments and Contingencies
Commitments
  (was, 2025-05-28, similarity 0.7912):
[0001045810-25-000116:note_history:1]
Commitments and Contingencies
Purchase Obligations

- added (2025-08-27):
[0001045810-25-000209:note_history:2]
Our commitments include obligations to purchase components used to manufacture our products, including certain software and technology licenses, investments, long-lived assets, long-term supply and capacity agreements, multi-year cloud service agreements, and other goods and services.

- added (2025-08-27):
[0001045810-25-000209:note_history:3]
We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs.

- changed (2025-08-27):
[0001045810-25-000209:note_history:4]
Total future commitments as of July 27, 2025 are as follows:
  (was, 2025-05-28, similarity 0.8667):
[0001045810-25-000116:note_history:4]
Total future purchase commitments as of April 27, 2025 are as follows:

- added (2025-08-27):
[0001045810-25-000209:note_history:5]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first half of fiscal year 2026) | $ | 30,930 |  |
| 2027 | 6,573 |  |
| 2028 | 3,915 |  |
| 2029 | 2,736 |  |
| 2030 | 1,402 |  |
| 2031 and thereafter | 218 |  |
| Total | $ | 45,774 |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:6]
The estimated amount of product warranty liabilities was $2.1 billion and $1.3 billion as of July 27, 2025 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:
  (was, 2025-05-28, similarity 0.9791):
[0001045810-25-000116:note_history:6]
The estimated amount of product warranty liabilities was $2.1 billion and $1.3 billion as of April 27, 2025 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:

- changed (2025-08-27):
[0001045810-25-000209:note_history:7]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,080 |  |  | $ | 532 |  |  | $ | 1,290 |  |  | $ | 306 |  |
| Additions | 220 |  |  | 237 |  |  | 1,090 |  |  | 471 |  |
| Utilization | (156) |  |  | (28) |  |  | (236) |  |  | (36) |  |
| Balance at end of period | $ | 2,144 |  |  | $ | 741 |  |  | $ | 2,144 |  |  | $ | 741 |  |
  (was, 2025-05-28, similarity 0.7443):
[0001045810-25-000116:note_history:7]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 1,290 |  |  | $ | 306 |  |  |  |  |  |
| Additions | 870 |  |  | 234 |  |  |  |  |  |
| Utilization | (80) |  |  | (8) |  |  |  |  |  |
| Balance at end of period | $ | 2,080 |  |  | $ | 532 |  |  |  |  |  |

- added (2025-08-27):
[0001045810-25-000209:note_history:8]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the

- changed (2025-08-27):
[0001045810-25-000209:note_history:9]
NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.
  (was, 2025-05-28, similarity 0.8417):
[0001045810-25-000116:note_history:9]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

- changed (2025-08-27):
[0001045810-25-000209:note_history:10]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2025-05-28, similarity 0.9337):
[0001045810-25-000116:note_history:10]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 5, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Corporation Securities Litigation action, the district court extended the stay for 30 days while the parties discuss next steps and ordered the parties to file a joint status report by March 7, 2025. On March 7, 2025, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- changed (2025-08-27):
[0001045810-25-000209:note_history:11]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. On August 11, 2025, the court granted the parties’ stipulation to voluntarily dismiss with prejudice plaintiff City of Westland Police and Fire Retirement System. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.
  (was, 2025-05-28, similarity 0.7716):
[0001045810-25-000116:note_history:11]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

- added (2025-08-27):
[0001045810-25-000209:note_history:12]
As of July 27, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2025-08-27):
[0001045810-25-000116:note_history:13]
Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

- removed (2025-08-27):
[0001045810-25-000116:note_history:14]
As of April 27, 2025, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $29.8 billion, an increase from the prior year led by commitments, capacity and components for our Blackwell architecture. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $13.7 billion, including $10.6 billion of multi-year cloud service agreements. We expect our cloud service agreements to primarily be used to support our research and development efforts, as well as our DGX Cloud offerings.

- removed (2025-08-27):
[0001045810-25-000116:note_history:15]
|  | Purchase Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first quarter of fiscal year 2026) | $ | 31,445 |  |
| 2027 | 5,923 |  |
| 2028 | 3,110 |  |
| 2029 | 2,072 |  |
| 2030 | 752 |  |
| 2031 and thereafter | 218 |  |
| Total | $ | 43,520 |  |

- removed (2025-08-27):
[0001045810-25-000116:note_history:16]
As of April 27, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-27):
[0001045810-25-000209:note_history:17]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The second quarters of fiscal years 2026 and 2025 were both 13-week quarters.
  (was, 2025-05-28, similarity 0.9701):
[0001045810-25-000116:note_history:17]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The first quarters of fiscal years 2026 and 2025 were both 13-week quarters.

- changed (2025-08-27):
[0001045810-25-000209:note_history:18]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending January 25, 2026.
  (was, 2025-05-28, similarity 0.9918):
[0001045810-25-000116:note_history:18]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the year ending January 25, 2026.

- removed (2025-08-27):
[0001045810-25-000116:note_history:19]
In June 2024, we executed a ten-for-one stock split of our common stock. All share, equity award and per share amounts presented herein have been retrospectively adjusted to reflect the stock split.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-27):
[0001045810-25-000209:note_history:20]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.1 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (34) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,466 |  |  | $ | 8,463 |  |
  (was, 2025-05-28, similarity 0.9953):
[0001045810-25-000116:note_history:20]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (36) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,464 |  |  | $ | 8,463 |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:21]
As of July 27, 2025 and January 26, 2025, the estimated fair value of debt was $7.4 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.
  (was, 2025-05-28, similarity 0.9786):
[0001045810-25-000116:note_history:21]
As of April 27, 2025 and January 26, 2025, the estimated fair value of debt was $7.3 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

- changed (2025-08-27):
[0001045810-25-000209:note_history:22]
As of July 27, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2025-05-28, similarity 0.9707):
[0001045810-25-000116:note_history:22]
As of April 27, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2025-08-27):
[0001045810-25-000209:note_history:23]
We have a $575 million commercial paper program to support general corporate purposes. As of July 27, 2025 and January 26, 2025, we had no commercial paper outstanding.
  (was, 2025-05-28, similarity 0.922):
[0001045810-25-000116:note_history:23]
We have a $575 million commercial paper program to support general corporate purposes. As of April 27, 2025, we had no commercial paper outstanding.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-27):
[0001045810-25-000209:note_history:24]
|  | Jul 27, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 23,967 |  |  | $ | 76 |  |  | $ | (11) |  |  | $ | 24,032 |  |  | $ | 3,784 |  |  | $ | 20,248 |  |
| Corporate debt securities | Level 2 | 21,564 |  |  | 81 |  |  | (9) |  |  | 21,636 |  |  | 2,214 |  |  | 19,422 |  |
| Money market funds | Level 1 | 5,245 |  |  | — |  |  | — |  |  | 5,245 |  |  | 5,245 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,238 |  |  | 7 |  |  | (2) |  |  | 2,243 |  |  | — |  |  | 2,243 |  |
| Certificates of deposit | Level 2 | 108 |  |  | — |  |  | — |  |  | 108 |  |  | 108 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 53,162 |  |  | 164 |  |  | (22) |  |  | 53,304 |  |  | 11,351 |  |  | 41,953 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,199 |  |  | — |  |  | 3,199 |  |
| Total |  | $ | 53,162 |  |  | $ | 164 |  |  | $ | (22) |  |  | $ | 56,503 |  |  | $ | 11,351 |  |  | $ | 45,152 |  |
  (was, 2025-05-28, similarity 0.6885):
[0001045810-25-000116:note_history:24]
|  | Apr 27, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 23,135 |  |  | $ | 120 |  |  | $ | (4) |  |  | $ | 23,251 |  |  | $ | 5,414 |  |  | $ | 17,837 |  |
| Corporate debt securities | 19,976 |  |  | 85 |  |  | (10) |  |  | 20,051 |  |  | 2,868 |  |  | 17,183 |  |
| Money market funds | 6,522 |  |  | — |  |  | — |  |  | 6,522 |  |  | 6,522 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,134 |  |  | 12 |  |  | (1) |  |  | 2,145 |  |  | — |  |  | 2,145 |  |
| Certificates of deposit | 126 |  |  | — |  |  | — |  |  | 126 |  |  | 126 |  |  | — |  |
| Foreign government bonds | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 51,933 |  |  | 218 |  |  | (15) |  |  | 52,136 |  |  | 14,930 |  |  | 37,206 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 1,251 |  |  | — |  |  | 1,251 |  |
| Total | $ | 51,933 |  |  | $ | 218 |  |  | $ | (15) |  |  | $ | 53,387 |  |  | $ | 14,930 |  |  | $ | 38,457 |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:25]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of July 27, 2025 was $2.8 billion and was subject to a short-term restriction on the ability to sell.
  (was, 2025-05-28, similarity 0.6154):
[0001045810-25-000116:note_history:25]
(1)    The balance as of the first quarter of fiscal year 2026 includes an investment in CoreWeave, Inc., or CoreWeave, which was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of April 27, 2025 was $1 billion and is subject to a short-term restriction on the ability to sell.

- changed (2025-08-27):
[0001045810-25-000209:note_history:26]
|  | Jan 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |
  (was, 2025-05-28, similarity 0.6606):
[0001045810-25-000116:note_history:26]
|  | Jan 26, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:27]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.
  (was, 2025-05-28, similarity 0.936):
[0001045810-25-000116:note_history:27]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

- added (2025-08-27):
[0001045810-25-000209:note_history:28]
|  | Jul 27, 2025 |
|  | (In millions) |
| Less than one year | $ | 22,521 |  |
| Due in 1 - 5 years | 30,783 |  |
| Total | $ | 53,304 |  |

- removed (2025-08-27):
[0001045810-25-000116:note_history:29]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 25,756 |  |  | $ | 25,781 |  |  | $ | 18,426 |  |  | $ | 18,450 |  |
| Due in 1 - 5 years | 26,177 |  |  | 26,355 |  |  | 23,636 |  |  | 23,656 |  |
| Total | $ | 51,933 |  |  | $ | 52,136 |  |  | $ | 42,062 |  |  | $ | 42,106 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-08-27):
[0001045810-25-000209:note_history:30]
Cash Equivalents and Marketable Securities
The fair values of our financial assets are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis. The following is a summary of cash equivalents and marketable securities:

- changed (2025-08-27):
[0001045810-25-000209:note_history:31]
|  | Jul 27, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 23,967 |  |  | $ | 76 |  |  | $ | (11) |  |  | $ | 24,032 |  |  | $ | 3,784 |  |  | $ | 20,248 |  |
| Corporate debt securities | Level 2 | 21,564 |  |  | 81 |  |  | (9) |  |  | 21,636 |  |  | 2,214 |  |  | 19,422 |  |
| Money market funds | Level 1 | 5,245 |  |  | — |  |  | — |  |  | 5,245 |  |  | 5,245 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,238 |  |  | 7 |  |  | (2) |  |  | 2,243 |  |  | — |  |  | 2,243 |  |
| Certificates of deposit | Level 2 | 108 |  |  | — |  |  | — |  |  | 108 |  |  | 108 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 53,162 |  |  | 164 |  |  | (22) |  |  | 53,304 |  |  | 11,351 |  |  | 41,953 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,199 |  |  | — |  |  | 3,199 |  |
| Total |  | $ | 53,162 |  |  | $ | 164 |  |  | $ | (22) |  |  | $ | 56,503 |  |  | $ | 11,351 |  |  | $ | 45,152 |  |
  (was, 2025-05-28, similarity 0.6885):
[0001045810-25-000116:note_history:31]
|  | Apr 27, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 23,135 |  |  | $ | 120 |  |  | $ | (4) |  |  | $ | 23,251 |  |  | $ | 5,414 |  |  | $ | 17,837 |  |
| Corporate debt securities | 19,976 |  |  | 85 |  |  | (10) |  |  | 20,051 |  |  | 2,868 |  |  | 17,183 |  |
| Money market funds | 6,522 |  |  | — |  |  | — |  |  | 6,522 |  |  | 6,522 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,134 |  |  | 12 |  |  | (1) |  |  | 2,145 |  |  | — |  |  | 2,145 |  |
| Certificates of deposit | 126 |  |  | — |  |  | — |  |  | 126 |  |  | 126 |  |  | — |  |
| Foreign government bonds | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 51,933 |  |  | 218 |  |  | (15) |  |  | 52,136 |  |  | 14,930 |  |  | 37,206 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 1,251 |  |  | — |  |  | 1,251 |  |
| Total | $ | 51,933 |  |  | $ | 218 |  |  | $ | (15) |  |  | $ | 53,387 |  |  | $ | 14,930 |  |  | $ | 38,457 |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:32]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of July 27, 2025 was $2.8 billion and was subject to a short-term restriction on the ability to sell.
  (was, 2025-05-28, similarity 0.6154):
[0001045810-25-000116:note_history:32]
(1)    The balance as of the first quarter of fiscal year 2026 includes an investment in CoreWeave, Inc., or CoreWeave, which was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of April 27, 2025 was $1 billion and is subject to a short-term restriction on the ability to sell.

- added (2025-08-27):
[0001045810-25-000209:note_history:33]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $1.9 billion and $1.7 billion for the second quarter and first half of fiscal year 2026, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were $132 million and $181 million for the second quarter and first half of fiscal year 2025, respectively.

- changed (2025-08-27):
[0001045810-25-000209:note_history:34]
|  | Jan 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |
  (was, 2025-05-28, similarity 0.6606):
[0001045810-25-000116:note_history:34]
|  | Jan 26, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:35]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 7,319 |  |  | $ | (11) |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 3,539 |  |  | (9) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 768 |  |  | (2) |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 11,626 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |
  (was, 2025-05-28, similarity 0.9956):
[0001045810-25-000116:note_history:35]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 6,854 |  |  | $ | (4) |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 2,775 |  |  | (10) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 321 |  |  | (1) |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 9,950 |  |  | $ | (15) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

- changed (2025-08-27):
[0001045810-25-000209:note_history:36]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater, with balances of $15 million and $213 million as of July 27, 2025 and January 26, 2025, respectively, were not significant.
  (was, 2025-05-28, similarity 0.9434):
[0001045810-25-000116:note_history:36]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater of $66 million and $213 million as of April 27, 2025 and January 26, 2025, respectively, were not significant.

- changed (2025-08-27):
[0001045810-25-000209:note_history:37]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.
  (was, 2025-05-28, similarity 0.936):
[0001045810-25-000116:note_history:37]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

- added (2025-08-27):
[0001045810-25-000209:note_history:38]
|  | Jul 27, 2025 |
|  | (In millions) |
| Less than one year | $ | 22,521 |  |
| Due in 1 - 5 years | 30,783 |  |
| Total | $ | 53,304 |  |

- removed (2025-08-27):
[0001045810-25-000116:note_history:39]
Cash Equivalents and Marketable Securities
The following is a summary of cash equivalents and marketable securities:

- removed (2025-08-27):
[0001045810-25-000116:note_history:40]
Net unrealized losses on investments in publicly-held equity securities held at period end were $222 million for the first quarter of fiscal year 2026. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for the first quarter of fiscal year 2025.

- removed (2025-08-27):
[0001045810-25-000116:note_history:41]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 25,756 |  |  | $ | 25,781 |  |  | $ | 18,426 |  |  | $ | 18,450 |  |
| Due in 1 - 5 years | 26,177 |  |  | 26,355 |  |  | 23,636 |  |  | 23,656 |  |
| Total | $ | 51,933 |  |  | $ | 52,136 |  |  | $ | 42,062 |  |  | $ | 42,106 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-27):
[0001045810-25-000209:note_history:42]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.1 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (34) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,466 |  |  | $ | 8,463 |  |
  (was, 2025-05-28, similarity 0.9953):
[0001045810-25-000116:note_history:42]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (36) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,464 |  |  | $ | 8,463 |  |
