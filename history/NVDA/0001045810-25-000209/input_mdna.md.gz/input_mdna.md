# NVDA MD&A — 0001045810-25-000209


## mdna

[0001045810-25-000209:mdna:1]
[same as prior period, unchanged from 0001045810-25-000116:mdna:1]

[0001045810-25-000209:mdna:2]
[same as prior period, unchanged from 0001045810-25-000116:mdna:2]

[0001045810-25-000209:mdna:3]
[same as prior period, unchanged from 0001045810-25-000116:mdna:3]

[0001045810-25-000209:mdna:4]
[same as prior period, unchanged from 0001045810-25-000116:mdna:4]

[0001045810-25-000209:mdna:5]
[same as prior period, unchanged from 0001045810-25-000116:mdna:5]

[0001045810-25-000209:mdna:6]
[same as prior period, unchanged from 0001045810-25-000116:mdna:6]

[0001045810-25-000209:mdna:7]
[same as prior period, unchanged from 0001045810-25-000116:mdna:7]

[0001045810-25-000209:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, and digital twin applications.

[0001045810-25-000209:mdna:9]
[same as prior period, unchanged from 0001045810-25-000116:mdna:9]

[0001045810-25-000209:mdna:10]
[same as prior period, unchanged from 0001045810-25-000116:mdna:10]

[0001045810-25-000209:mdna:11]
[same as prior period, unchanged from 0001045810-25-000116:mdna:11]

[0001045810-25-000209:mdna:12]
Revenue growth in the second quarter and the first half of fiscal year 2026 was driven by data center compute and networking platforms for accelerated computing and AI solutions. Our Blackwell GPU revenue ramp continued during the first half of the year, including our transition to Blackwell Ultra platforms.

[0001045810-25-000209:mdna:13]
In April 2025, the U.S. government, or USG, informed us that a license is required for exports of our H20 product into the China market. As a result of these new requirements, we incurred a $4.5 billion charge in the first quarter of fiscal year 2026 associated with H20 for excess inventory and purchase obligations, as the demand for H20 diminished. In August 2025, the USG granted licenses that would allow us to ship certain H20 products to certain China-based customers, but to date, we have not generated any revenue or shipped any H20 products under those licenses. USG officials have expressed an expectation that the USG will receive 15% of the revenue generated from licensed H20 sales, but to date, the USG has not published a regulation codifying such requirement. In the second quarter, we recognized approximately $650 million of H20 revenue from sales to an unrestricted customer outside of China, resulting in a $180 million release of previously reserved H20 inventory. There were no H20 sales to China-based customers in the second quarter.

[0001045810-25-000209:mdna:14]
We continue to execute Data Center compute product introductions, bringing new advanced architectures on a one-year product cadence. We began shipping production units of our new Blackwell Ultra platforms including GB300 in the second quarter of fiscal year 2026. Our product transitions and sophisticated system configurations may create challenges in managing supply and demand. This could result in revenue volatility, quality or production issues, increased

[0001045810-25-000209:mdna:15]
inventory provisions, warranty costs, or product delays. Customers may postpone purchasing existing products due to frequent new releases or may adopt new technologies more gradually than anticipated, affecting our revenue timing and supply chain expenses. The recent rise of high-quality open-source foundation models is making advanced AI capabilities broadly accessible. Open-source AI is becoming increasingly important across the ecosystem and it is dependent on developer adoption. If the most widely adopted open-source models are developed or deployed on our competitors’ platforms, it could significantly weaken the influence of our platform, reduce developer engagement, and limit demand for our products and services. Future demand for our platform will depend on our ability to support, scale, and optimize the next generation of AI models—including open-source large language models—across our full stack of software and hardware offerings.

[0001045810-25-000209:mdna:16]
[same as prior period, unchanged from 0001045810-25-000116:mdna:17]

[0001045810-25-000209:mdna:17]
In January 2025, the USG published the “AI Diffusion” IFR in the Federal Register. The IFR would have imposed a worldwide licensing requirement on our most popular data center products, such as our H200, GB200 and GB300. In May 2025, the USG announced that it would rescind the AI Diffusion IFR and implement a replacement rule. The scope, timing, and requirements of the forthcoming rule remain uncertain. The replacement rule may impose new restrictions on our products or operations and/or add license requirements that could have a material impact on our business, operating results, and financial condition.

[0001045810-25-000209:mdna:18]
The rapid evolution of global trade policies, such as new export controls and tariffs, has added complexity and increased costs throughout our supply chain, and these challenges are likely to persist. Ongoing uncertainty regarding the scope and application of such measures may adversely affect investment decisions by us and our partners, disrupt supply chain operations, and impact the timing and volume of customer purchases due to challenges in forecasting future costs and demand.

[0001045810-25-000209:mdna:19]
[same as prior period, unchanged from 0001045810-25-000116:mdna:20]

[0001045810-25-000209:mdna:20]
[same as prior period, unchanged from 0001045810-25-000116:mdna:21]

[0001045810-25-000209:mdna:21]
[same as prior period, unchanged from 0001045810-25-000116:mdna:22]

[0001045810-25-000209:mdna:22]
Second Quarter of Fiscal Year 2026 Summary

[0001045810-25-000209:mdna:23]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Jul 27, 2025 |  | Apr 27, 2025 |  | Jul 28, 2024 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 46,743 |  |  | $ | 44,062 |  |  | $ | 30,040 |  |  | 6 | % |  | 56 | % |
| Gross margin | 72.4 | % |  | 60.5 | % |  | 75.1 | % |  | 11.9 | pts |  | (2.7) | pts |
| Operating expenses | $ | 5,413 |  |  | $ | 5,030 |  |  | $ | 3,932 |  |  | 8 | % |  | 38 | % |
| Operating income | $ | 28,440 |  |  | $ | 21,638 |  |  | $ | 18,642 |  |  | 31 | % |  | 53 | % |
| Net income | $ | 26,422 |  |  | $ | 18,775 |  |  | $ | 16,599 |  |  | 41 | % |  | 59 | % |
| Net income per diluted share | $ | 1.08 |  |  | $ | 0.76 |  |  | $ | 0.67 |  |  | 42 | % |  | 61 | % |

[0001045810-25-000209:mdna:24]
We benefited from a $180 million release of previously reserved H20 inventory related to the sale of approximately $650 million of H20 to an unrestricted customer outside of China. There were no H20 sales to China-based customers in the second quarter of fiscal year 2026.

[0001045810-25-000209:mdna:25]
Revenue was $46.7 billion, up 56% from a year ago and up 6% sequentially.

[0001045810-25-000209:mdna:26]
Data Center revenue was $41.1 billion, up 56% from a year ago and up 5% sequentially. The strong year-on-year and sequential growth was driven by demand for our accelerated computing platform used for large language models, recommendation engines, and generative and agentic AI applications. We continue to ramp our Blackwell architecture, which grew 17% sequentially, including our newest architecture, Blackwell Ultra. We recognized Blackwell revenue across

[0001045810-25-000209:mdna:27]
all customer categories, led by large cloud service providers, which represented approximately 50% of Data Center revenue.

[0001045810-25-000209:mdna:28]
Data Center compute revenue was $33.8 billion, up 50% from a year ago. Sequentially, compute revenue declined 1%, driven by a $4.0 billion reduction in H20 sales. Networking revenue was $7.3 billion, up 98% from a year ago and up 46% sequentially, driven by the growth of NVLink compute fabric for GB200 and GB300 systems, the ramp of XDR InfiniBand products, and adoption of Ethernet for AI solutions at cloud service providers and consumer internet companies.

[0001045810-25-000209:mdna:29]
Gaming revenue was up 49% from a year ago and up 14% sequentially, with strong sales and increased supply of our Blackwell product.

[0001045810-25-000209:mdna:30]
Professional Visualization revenue was up 32% from a year ago and up 18% sequentially, driven by the acceleration of Blackwell sales in our Notebook products, addressing AI workflows, real-time graphics rendering and data simulation.

[0001045810-25-000209:mdna:31]
Automotive revenue was up 69% from a year ago and up 3% sequentially, driven by strong adoption of our self-driving platforms.

[0001045810-25-000209:mdna:32]
Gross margin decreased from a year ago as our Blackwell revenue consists primarily of full-scale datacenter systems compared to Hopper HGX systems last year. Gross margin increased sequentially as the prior quarter included a $4.5 billion charge associated with H20 excess inventory and purchase obligations.

[0001045810-25-000209:mdna:33]
Operating expenses were up 38% from a year ago and up 8% sequentially. The increases were primarily driven by compute and infrastructure costs and higher compensation and benefits due to compensation increases and employee growth.

[0001045810-25-000209:mdna:34]
[same as prior period, unchanged from 0001045810-25-000116:mdna:33]

[0001045810-25-000209:mdna:35]
[same as prior period, unchanged from 0001045810-25-000116:mdna:34]

[0001045810-25-000209:mdna:36]
[same as prior period, unchanged from 0001045810-25-000116:mdna:35]

[0001045810-25-000209:mdna:37]
[same as prior period, unchanged from 0001045810-25-000116:mdna:36]

[0001045810-25-000209:mdna:38]
[same as prior period, unchanged from 0001045810-25-000116:mdna:37]

[0001045810-25-000209:mdna:39]
[same as prior period, unchanged from 0001045810-25-000116:mdna:38]

[0001045810-25-000209:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 27.6 |  |  | 24.9 |  |  | 33.4 |  |  | 23.4 |  |
| Gross profit | 72.4 |  |  | 75.1 |  |  | 66.6 |  |  | 76.6 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 9.2 |  |  | 10.3 |  |  | 9.1 |  |  | 10.4 |  |
| Sales, general and administrative | 2.4 |  |  | 2.8 |  |  | 2.4 |  |  | 2.9 |  |
| Total operating expenses | 11.6 |  |  | 13.1 |  |  | 11.5 |  |  | 13.3 |  |
| Operating income | 60.8 |  |  | 62.0 |  |  | 55.1 |  |  | 63.3 |  |
| Interest income | 1.3 |  |  | 1.5 |  |  | 1.2 |  |  | 1.4 |  |
| Interest expense | (0.1) |  |  | (0.2) |  |  | (0.1) |  |  | (0.2) |  |
| Other income (expense), net | 4.8 |  |  | 0.6 |  |  | 2.3 |  |  | 0.5 |  |
| Total other income (expense), net | 6.0 |  |  | 1.9 |  |  | 3.4 |  |  | 1.7 |  |
| Income before income tax | 66.8 |  |  | 63.9 |  |  | 58.5 |  |  | 65.0 |  |
| Income tax expense | 10.2 |  |  | 8.7 |  |  | 8.7 |  |  | 8.9 |  |
| Net income | 56.6 | % |  | 55.2 | % |  | 49.8 | % |  | 56.1 | % |

[0001045810-25-000209:mdna:41]
[same as prior period, unchanged from 0001045810-25-000116:mdna:40]

[0001045810-25-000209:mdna:42]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | %Change |  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 41,331 |  |  | $ | 26,446 |  |  | $ | 14,885 |  |  | 56 | % |  | $ | 80,920 |  |  | $ | 49,121 |  |  | $ | 31,799 |  |  | 65 | % |
| Graphics | 5,412 |  |  | 3,594 |  |  | 1,818 |  |  | 51 | % |  | 9,885 |  |  | 6,963 |  |  | 2,922 |  |  | 42 | % |
| Total | $ | 46,743 |  |  | $ | 30,040 |  |  | $ | 16,703 |  |  | 56 | % |  | $ | 90,805 |  |  | $ | 56,084 |  |  | $ | 34,721 |  |  | 62 | % |

[0001045810-25-000209:mdna:43]
[same as prior period, unchanged from 0001045810-25-000116:mdna:42]

[0001045810-25-000209:mdna:44]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | %Change |  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 28,363 |  |  | $ | 18,848 |  |  | $ | 9,515 |  |  | 50 | % |  | $ | 50,417 |  |  | $ | 35,896 |  |  | $ | 14,521 |  |  | 40 | % |
| Graphics | 2,242 |  |  | 1,369 |  |  | 873 |  |  | 64 | % |  | $ | 3,882 |  |  | 2,609 |  |  | 1,273 |  |  | 49 | % |
| Total | $ | 30,605 |  |  | $ | 20,217 |  |  | $ | 10,388 |  |  | 51 | % |  | $ | 54,299 |  |  | $ | 38,505 |  |  | $ | 15,794 |  |  | 41 | % |

[0001045810-25-000209:mdna:45]
Compute & Networking revenue – The year over year increase in the second quarter and first half of fiscal year 2026 was driven by demand for our accelerated computing platform used for large language models, recommendation engines, and generative and agentic AI applications. Revenue from Data Center computing grew 62% year-on-year compared to the first half of fiscal year 2025, driven by demand for our Blackwell computing platform. Revenue from Data Center networking grew 79% year-on-year compared to the first half of fiscal year 2025 driven by the growth of NVLink compute fabric for GB200 and GB300 systems, the ramp of XDR InfiniBand products, and adoption of Ethernet for AI solutions at cloud service providers and consumer internet companies.

[0001045810-25-000209:mdna:46]
Graphics revenue – The year over year increase in the second quarter and first half of fiscal year 2026 was driven by sales of our Blackwell architecture.

[0001045810-25-000209:mdna:47]
Reportable segment operating income – The year over year increase in Compute & Networking segment operating income in the second quarter of fiscal year 2026 was driven by the growth in revenue. The year over year increase in Compute & Networking segment operating income in the first half of fiscal year 2026 was driven by the growth in revenue, partially offset by a $4.5 billion charge associated with H20 excess inventory and purchase obligations in the first quarter of fiscal year 2026. The year over year increase in Graphics segment operating income in the second quarter and first half of fiscal year 2026 was driven by the growth in revenue.

[0001045810-25-000209:mdna:48]
[same as prior period, unchanged from 0001045810-25-000116:mdna:49]

[0001045810-25-000209:mdna:49]
[same as prior period, unchanged from 0001045810-25-000116:mdna:50]

[0001045810-25-000209:mdna:50]
Direct Customers – For the second quarter of fiscal year 2026, sales to one direct customer, Customer A, represented 23% of total revenue; and sales to a second direct customer, Customer B, represented 16% of total revenue, respectively, both of which were attributable to the Compute & Networking segment. For the first half of fiscal year 2026, sales to one direct customer, Customer A, represented 20% of total revenue; and sales to a second direct customer, Customer B, represented 15% of total revenue, respectively, both of which were attributable to the Compute & Networking segment.

[0001045810-25-000209:mdna:51]
Sales to four direct customers represented 14%, 11%, 11%, and 10% of revenue for the second quarter, and sales to three direct customers represented 14%, 10%, and 10% of revenue for the first half, of fiscal year 2025, all of which were attributable to the Compute & Networking segment.

[0001045810-25-000209:mdna:52]
Indirect Customers – Indirect customer revenue is an estimation based upon multiple factors including customer purchase order information, product specifications, internal sales data, and other sources. Actual indirect customer revenue may differ from our estimates. Indirect customers primarily purchase our products through system integrators and distributors. For the second quarter of fiscal year 2026, two indirect customers—primarily purchasing our products through Direct Customers A and B—are each estimated to represent 10% or more of total revenue and attributable to the

[0001045810-25-000209:mdna:53]
Compute & Networking segment. For the first half of fiscal year 2026, one indirect customer—primarily purchasing through Direct Customer A—is estimated to represent 10% or more of total revenue and attributable to the Compute & Networking segment.

[0001045810-25-000209:mdna:54]
We estimate that in the second quarter and first half of fiscal year 2026, an AI research and deployment company contributed to a meaningful amount of our revenue, through various direct and indirect customers.

[0001045810-25-000209:mdna:55]
[same as prior period, unchanged from 0001045810-25-000116:mdna:54]

[0001045810-25-000209:mdna:56]
Revenue by geographic region is designated based on the billing location of direct customers even if the estimated revenue may be attributable to indirect customers in a different location. Revenue from sales to customers outside of the United States accounted for 50% and 51% of total revenue for the second quarter and first half of fiscal year 2026, respectively, and 57% and 53% of total revenue for the second quarter and first half of fiscal year 2025, respectively.

[0001045810-25-000209:mdna:57]
[same as prior period, unchanged from 0001045810-25-000116:mdna:56]

[0001045810-25-000209:mdna:58]
[same as prior period, unchanged from 0001045810-25-000116:mdna:57]

[0001045810-25-000209:mdna:59]
Gross margins decreased to 72.4% for the second quarter of fiscal year 2026 compared to 75.1% for the second quarter of fiscal year 2025, and 66.6% for the first half of fiscal year 2026 compared to 76.6% for the first half of fiscal year 2025, as our Blackwell revenue consists primarily of full-scale datacenter systems compared to Hopper HGX systems last year. Gross margin for the first half of fiscal year 2026 was also impacted by a $4.5 billion charge associated with H20 excess inventory and purchase obligations.

[0001045810-25-000209:mdna:60]
Provisions for inventory and excess inventory purchase obligations totaled $1.0 billion and $6.3 billion for the second quarter and first half of fiscal year 2026, respectively, including $4.5 billion associated with H20 excess inventory and purchase obligations for the first quarter of fiscal year 2026. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $501 million and $937 million for the second quarter and first half of fiscal year 2026, respectively. The second quarter of fiscal year 2026 included a provision release of $180 million upon the sale of H20 products outside of the China market. The net effect on our gross margin was an unfavorable impact of 1.1% and 5.9% in the second quarter and first half of fiscal year 2026, respectively.

[0001045810-25-000209:mdna:61]
Provisions for inventory and excess inventory purchase obligations totaled $908 million and $1.3 billion for the second quarter and first half of fiscal year 2025, respectively, and were primarily due to low-yielding Blackwell material. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $85 million and $199 million for the second quarter and first half of fiscal year 2025, respectively. The net effect on our gross margin was an unfavorable impact of 2.7% and 2.0% in the second quarter and first half of fiscal year 2025, respectively.

[0001045810-25-000209:mdna:62]
[same as prior period, unchanged from 0001045810-25-000116:mdna:61]

[0001045810-25-000209:mdna:63]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | %Change |  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 4,291 |  |  | $ | 3,090 |  |  | $ | 1,201 |  |  | 39 | % |  | $ | 8,280 |  |  | $ | 5,810 |  |  | $ | 2,470 |  |  | 43 | % |
| Sales, general and administrative expenses | 1,122 |  |  | 842 |  |  | 280 |  |  | 33 | % |  | 2,163 |  |  | 1,618 |  |  | 545 |  |  | 34 | % |
| Total operating expenses | $ | 5,413 |  |  | $ | 3,932 |  |  | $ | 1,481 |  |  | 38 | % |  | $ | 10,443 |  |  | $ | 7,428 |  |  | $ | 3,015 |  |  | 41 | % |

[0001045810-25-000209:mdna:64]
The increases in research and development expenses for the second quarter and first half of fiscal year 2026 were primarily driven by a 68% and 69% increase in compute and infrastructure, 30% and 32% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, and a 68% and 116% increase in engineering development costs for new product introductions, respectively.

[0001045810-25-000209:mdna:65]
The increases in sales, general and administrative expenses for the second quarter and first half of fiscal year 2026 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-25-000209:mdna:66]
[same as prior period, unchanged from 0001045810-25-000116:mdna:65]

[0001045810-25-000209:mdna:67]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |  | Jul 27, 2025 |  | Jul 28, 2024 |  | $Change |
|  | ($ in millions) |
| Interest income | $ | 592 |  |  | $ | 444 |  |  | $ | 148 |  |  | $ | 1,108 |  |  | $ | 803 |  |  | $ | 305 |  |
| Interest expense | (62) |  |  | (61) |  |  | (1) |  |  | (124) |  |  | (125) |  |  | 1 |  |
| Other income (expense), net | 2,236 |  |  | 189 |  |  | 2,047 |  |  | 2,055 |  |  | 264 |  |  | 1,791 |  |
| Total other income (expense), net | $ | 2,766 |  |  | $ | 572 |  |  | $ | 2,194 |  |  | $ | 3,039 |  |  | $ | 942 |  |  | $ | 2,097 |  |

[0001045810-25-000209:mdna:68]
The increase in interest income for the second quarter and first half of fiscal year 2026 was primarily due to growth in cash, cash equivalents, and debt securities.

[0001045810-25-000209:mdna:69]
[same as prior period, unchanged from 0001045810-25-000116:mdna:68]

[0001045810-25-000209:mdna:70]
Other income (expense), net consists of realized or unrealized gains and losses from investments in non-marketable equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other income (expense), net, compared to the second quarter and first half of fiscal year 2025, was primarily driven by unrealized gains in our publicly-held equity securities. Refer to Notes 5 and 6 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding our investments in non-marketable equity securities and publicly-held equity securities.

[0001045810-25-000209:mdna:71]
[same as prior period, unchanged from 0001045810-25-000116:mdna:70]

[0001045810-25-000209:mdna:72]
Income tax expense was $4.8 billion and $2.6 billion for the second quarter, and $7.9 billion and $5.0 billion for the first half, of fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 15.3% and 13.6% for the second quarter, and 14.9% and 13.7% for the first half, of fiscal years 2026 and 2025, respectively.

[0001045810-25-000209:mdna:73]
The effective tax rate increased primarily due to a lower tax benefit from stock-based compensation, partially offset by an increase in tax benefit from foreign-derived deduction eligible income.

[0001045810-25-000209:mdna:74]
In July 2025, the OBBBA was enacted into law and contains several changes to key U.S. federal income tax laws. As of July 27, 2025, we have recognized the tax effects of certain OBBBA provisions, which did not have a material impact on our second quarter. We will continue to evaluate the impact of these legislative changes as tax authorities provide additional guidance and interpretation.

[0001045810-25-000209:mdna:75]
[same as prior period, unchanged from 0001045810-25-000116:mdna:73]

[0001045810-25-000209:mdna:76]
[same as prior period, unchanged from 0001045810-25-000116:mdna:74]

[0001045810-25-000209:mdna:77]
[same as prior period, unchanged from 0001045810-25-000116:mdna:76]

[0001045810-25-000209:mdna:78]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
|  | (In millions) |
| Cash and cash equivalents | $ | 11,639 |  |  | $ | 8,589 |  |
| Marketable securities | 45,152 |  |  | 34,621 |  |
| Cash, cash equivalents and marketable securities | $ | 56,791 |  |  | $ | 43,210 |  |

[0001045810-25-000209:mdna:79]
|  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 42,779 |  |  | $ | 29,833 |  |
| Net cash used in investing activities | $ | (12,343) |  |  | $ | (8,877) |  |
| Net cash used in financing activities | $ | (27,386) |  |  | $ | (19,665) |  |

[0001045810-25-000209:mdna:80]
[same as prior period, unchanged from 0001045810-25-000116:mdna:79]

[0001045810-25-000209:mdna:81]
Cash provided by operating activities increased in the first half of fiscal year 2026 compared to the first half of fiscal year 2025 due to higher revenue.

[0001045810-25-000209:mdna:82]
Cash used in investing activities increased in the first half of fiscal year 2026 compared to the first half of fiscal year 2025, primarily driven by lower maturities of marketable securities and higher purchases of property and equipment.

[0001045810-25-000209:mdna:83]
Cash used in financing activities increased in the first half of fiscal year 2026 compared to the first half of fiscal year 2025, mainly due to higher share repurchases.

[0001045810-25-000209:mdna:84]
[same as prior period, unchanged from 0001045810-25-000116:mdna:83]

[0001045810-25-000209:mdna:85]
Our primary sources of liquidity include cash, cash equivalents, marketable securities, and cash generated by our operations. As of July 27, 2025, we had $56.8 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and thereafter for the foreseeable future, including our future supply obligations. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-25-000209:mdna:86]
Our marketable securities consist of publicly-held equity securities, debt securities issued by the USG and its agencies, highly-rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly-rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-25-000209:mdna:87]
Except for approximately $1.7 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. at the end of the first half of fiscal year 2026 are available for use in the U.S. without incurring additional U.S. federal income taxes. We made two estimated federal tax payments in the second quarter of fiscal year 2026, as compared with no estimated tax payments in the first quarter of fiscal year 2026. We are evaluating the full effects of the OBBBA on our cash tax position.

[0001045810-25-000209:mdna:88]
[same as prior period, unchanged from 0001045810-25-000116:mdna:87]

[0001045810-25-000209:mdna:89]
We repurchased 67 million and 193 million shares of our common stock for $9.7 billion and $24.2 billion during the second quarter and first half of fiscal year 2026, respectively. As of July 27, 2025, we were authorized, subject to certain specifications, to repurchase up to $14.7 billion of our common stock.

[0001045810-25-000209:mdna:90]
From July 28, 2025 through August 26, 2025, we repurchased 20 million shares for $3.5 billion pursuant to a pre-established trading plan. On August 26, 2025, our Board of Directors approved an additional $60.0 billion in share repurchase authorization, without expiration. As of August 26, 2025, a total of $71.2 billion was available for repurchase. We may execute repurchases from time to time, subject to market conditions, operating requirements and other investment opportunities, in the open market, in privately negotiated transactions, pursuant to a Rule 10b5-1 trading plan or in structured share repurchase agreements in compliance with Rule 10b-18 of the Exchange Act. Our share repurchase program may be suspended at any time at our discretion.

[0001045810-25-000209:mdna:91]
We paid cash dividends to our shareholders of $244 million and $488 million during the second quarter and first half of fiscal year 2026, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.

[0001045810-25-000209:mdna:92]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for the second quarter and first half of fiscal years 2026 and 2025.

[0001045810-25-000209:mdna:93]
[same as prior period, unchanged from 0001045810-25-000116:mdna:93]

[0001045810-25-000209:mdna:94]
Our aggregate debt maturities as of July 27, 2025, by year payable, are as follows:

[0001045810-25-000209:mdna:95]
|  |  | Jul 27, 2025 |
|  |  | (In millions) |
| Due in one to five years |  | $ | 3,750 |  |
| Due in five to ten years |  | 1,250 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (34) |  |
| Net long-term carrying amount |  | $ | 8,466 |  |

[0001045810-25-000209:mdna:96]
We have a $575 million commercial paper program to support general corporate purposes. As of July 27, 2025, we had no commercial paper outstanding.

[0001045810-25-000209:mdna:97]
[same as prior period, unchanged from 0001045810-25-000116:mdna:97]

[0001045810-25-000209:mdna:98]
[same as prior period, unchanged from 0001045810-25-000116:mdna:98]

[0001045810-25-000209:mdna:99]
Unrecognized tax benefits were $2.9 billion, which includes related interest and penalties, were recorded in non-current income tax payable as of July 27, 2025. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 4 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-25-000209:mdna:100]
[same as prior period, unchanged from 0001045810-25-000116:mdna:100]

[0001045810-25-000209:mdna:101]
[same as prior period, unchanged from 0001045810-25-000116:mdna:101]

[0001045810-25-000209:mdna:102]
[same as prior period, unchanged from 0001045810-25-000116:mdna:102]

[0001045810-25-000209:mdna:103]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-25-000209:mdna:104]
There has been no adoption of any new and recently issued accounting pronouncements.
