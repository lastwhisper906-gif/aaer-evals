# NVDA MD&A — 0001045810-14-000188


## mdna

[0001045810-14-000188:mdna:1]
[same as prior period, unchanged from 0001045810-14-000158:mdna:1]

[0001045810-14-000188:mdna:2]
[same as prior period, unchanged from 0001045810-14-000158:mdna:2]

[0001045810-14-000188:mdna:3]
[same as prior period, unchanged from 0001045810-14-000158:mdna:3]

[0001045810-14-000188:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GTX, ICERA, Jetson, Maxwell, NVIDIA GRID, NVLink, Quadro, SHIELD, Tegra, and Tesla are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-14-000188:mdna:5]
[same as prior period, unchanged from 0001045810-14-000158:mdna:5]

[0001045810-14-000188:mdna:6]
[same as prior period, unchanged from 0001045810-14-000158:mdna:6]

[0001045810-14-000188:mdna:7]
[same as prior period, unchanged from 0001045810-14-000158:mdna:7]

[0001045810-14-000188:mdna:8]
[same as prior period, unchanged from 0001045810-14-000158:mdna:8]

[0001045810-14-000188:mdna:9]
Our strategy is to be the world leader in visual computing. We target applications in each of the major computing platforms - PC, Datacenter/Cloud, Mobile - where we can create value. Our target markets are gaming, design and visualization, high performance computing, or HPC, and data center, and automotive and smart devices. We deploy business models we believe are best suited for each application, whether IP, chips, systems, or NVIDIA-branded devices and services.

[0001045810-14-000188:mdna:10]
Our businesses are based on two technologies with a consistent underlying graphics architecture: the GPU and the Tegra Processor.

[0001045810-14-000188:mdna:11]
[same as prior period, unchanged from 0001045810-14-000158:mdna:11]

[0001045810-14-000188:mdna:12]
[same as prior period, unchanged from 0001045810-14-000158:mdna:12]

[0001045810-14-000188:mdna:13]
[same as prior period, unchanged from 0001045810-14-000158:mdna:13]

[0001045810-14-000188:mdna:14]
[same as prior period, unchanged from 0001045810-14-000158:mdna:14]

[0001045810-14-000188:mdna:15]
[same as prior period, unchanged from 0001045810-14-000158:mdna:15]

[0001045810-14-000188:mdna:16]
[same as prior period, unchanged from 0001045810-14-000158:mdna:16]

[0001045810-14-000188:mdna:17]
[same as prior period, unchanged from 0001045810-14-000158:mdna:17]

[0001045810-14-000188:mdna:18]
[same as prior period, unchanged from 0001045810-14-000158:mdna:18]

[0001045810-14-000188:mdna:19]
[same as prior period, unchanged from 0001045810-14-000158:mdna:19]

[0001045810-14-000188:mdna:20]
[same as prior period, unchanged from 0001045810-14-000158:mdna:20]

[0001045810-14-000188:mdna:21]
During the third quarter of fiscal year 2015, we released our new GeForce GTX 980 and GTX 970 series products for desktops and notebooks based on our Maxwell-based architecture. We also extended Maxwell-based processors into our Quadro product lineup. We continued to expand our reach in the big data analytics market, with IBM announcing future support for GPU acceleration in its IBM DB2 with BLU acceleration. In addition, we partnered with VMware to announce a customer access program for NVIDIA GRID with companies like Airbus, CH2M Hill, MetroHealth and Halliburton being the initial customers. NVIDIA GRID graphics virtualization also continued to gain momentum as more companies come forward to experience cloud-based GPU-accelerated virtual desktops through our “Try GRID” online demonstration.

[0001045810-14-000188:mdna:22]
[same as prior period, unchanged from 0001045810-14-000158:mdna:21]

[0001045810-14-000188:mdna:23]
During the first quarter of fiscal year 2015, we released our new GeForce GTX 750 and GeForce GTX 800M series products which include our NVIDIA Maxwell-based products, and disclosed the first details of our Pascal GPU architecture, which will succeed NVIDIA Maxwell.  Pascal is expected to feature 3D memory and NVLink interconnect technology. NVLink is planned to be incorporated in future POWER8 CPUs from IBM. We also announced that NVIDIA GRID technology will be available on the VMware Horizon DaaS Platform to deliver 3D graphics on virtualized desktops and applications delivered through the cloud.  In addition, we joined IBM, Google, and others to launch the OpenPOWER Foundation, an initiative to bring IBM’s POWER CPU to mainstream servers.

[0001045810-14-000188:mdna:24]
[same as prior period, unchanged from 0001045810-14-000158:mdna:23]

[0001045810-14-000188:mdna:25]
During the third quarter of fiscal year 2015, our Tegra K1 mobile processor was featured in the Google Nexus 9 tablet and NVIDIA's SHIELD tablet with 32GB of memory and LTE connectivity. Acer and HP also announced Chromebooks featuring Tegra K1. In addition, Honda announced that the infotainment systems in three of its car models for the European market - the Civic, Civic Tourer and CR-V, will include Tegra-based systems.

[0001045810-14-000188:mdna:26]
[same as prior period, unchanged from 0001045810-14-000158:mdna:24]

[0001045810-14-000188:mdna:27]
[same as prior period, unchanged from 0001045810-14-000158:mdna:25]

[0001045810-14-000188:mdna:28]
[same as prior period, unchanged from 0001045810-14-000158:mdna:26]

[0001045810-14-000188:mdna:29]
As part of our stock repurchase program, during the first nine months of fiscal year 2015, we entered into two accelerated share repurchase agreements, or ASRs, that were completed in July 2014 and October 2014, respectively. Under the terms of these ASRs, we paid $810.0 million to purchase shares of our common stock and received an aggregate of 44.2 million shares.  Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding these ASRs.  Additionally, we paid $140.2 million in cash dividends during the first nine months of fiscal year 2015.  As such, in the aggregate for the first nine months of fiscal year 2015, we returned a total of $950.2 million of capital to shareholders.

[0001045810-14-000188:mdna:30]
On November 6, 2014, we announced our intent to return $600.0 million in capital to our shareholders in fiscal year 2016 through a combination of stock repurchases and quarterly dividend payments.

[0001045810-14-000188:mdna:31]
Litigation

[0001045810-14-000188:mdna:32]
In September 2014, we filed lawsuits against Qualcomm, Inc. and various Samsung entities in the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for using our GPU patents without a license. The ITC has subsequently determined that it will investigate the case and hold an evidentiary hearing in June 2015. On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. The complaint alleges that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor.

[0001045810-14-000188:mdna:33]
[same as prior period, unchanged from 0001045810-14-000158:mdna:28]

[0001045810-14-000188:mdna:34]
[same as prior period, unchanged from 0001045810-14-000158:mdna:29]

[0001045810-14-000188:mdna:35]
[same as prior period, unchanged from 0001045810-14-000158:mdna:30]

[0001045810-14-000188:mdna:36]
[same as prior period, unchanged from 0001045810-14-000158:mdna:31]

[0001045810-14-000188:mdna:37]
[same as prior period, unchanged from 0001045810-14-000158:mdna:32]

[0001045810-14-000188:mdna:38]
[same as prior period, unchanged from 0001045810-14-000158:mdna:33]

[0001045810-14-000188:mdna:39]
[same as prior period, unchanged from 0001045810-14-000158:mdna:34]

[0001045810-14-000188:mdna:40]
[same as prior period, unchanged from 0001045810-14-000158:mdna:35]

[0001045810-14-000188:mdna:41]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | October 26, 2014 |  |  | October 27, 2013 |  |  | October 26, 2014 |  |  | October 27, 2013 |  |
| Revenue | 100.0 |  | % |  | 100.0 |  | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 44.8 |  |  |  | 44.6 |  |  |  | 44.6 |  |  | 44.8 |  |
| Gross profit | 55.2 |  |  |  | 55.4 |  |  |  | 55.4 |  |  | 55.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 27.8 |  |  |  | 32.3 |  |  |  | 29.5 |  |  | 33.5 |  |
| Sales, general and administrative | 10.1 |  |  |  | 9.8 |  |  |  | 10.5 |  |  | 10.7 |  |
| Total operating expenses | 37.9 |  |  |  | 42.1 |  |  |  | 40.0 |  |  | 44.2 |  |
| Operating income | 17.3 |  |  |  | 13.3 |  |  |  | 15.4 |  |  | 11.0 |  |
| Interest income | 0.6 |  |  |  | 0.4 |  |  |  | 0.6 |  |  | 0.4 |  |
| Interest expense | 0.9 |  |  |  | 0.1 |  |  |  | 1.0 |  |  | 0.1 |  |
| Other income (expense), net | — |  |  |  | (0.3 | ) |  |  | 0.4 |  |  | 0.1 |  |
| Income before income tax expense | 17.0 |  |  |  | 13.3 |  |  |  | 15.4 |  |  | 11.4 |  |
| Income tax expense | 2.9 |  |  |  | 2.2 |  |  |  | 2.6 |  |  | 1.6 |  |
| Net income | 14.1 |  | % |  | 11.1 |  | % |  | 12.8 | % |  | 9.8 | % |

[0001045810-14-000188:mdna:42]
Three and nine months ended October 26, 2014 and October 27, 2013

[0001045810-14-000188:mdna:43]
[same as prior period, unchanged from 0001045810-14-000158:mdna:38]

[0001045810-14-000188:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, 2014 |  | October 27, 2013 |  | $Change |  | %Change |  | October 26, 2014 |  | October 27, 2013 |  | $Change |  | %Change |
|  | (In millions) |  |  |  | (In millions) |  |  |
| GPU | $ | 991.2 |  |  | $ | 876.8 |  |  | $ | 114.4 |  |  | 13 | % |  | $ | 2,766.6 |  |  | $ | 2,521.1 |  |  | $ | 245.5 |  |  | 10 | % |
| Tegra Processor | 168.2 |  |  | 111.1 |  |  | 57.1 |  |  | 51 | % |  | 466.4 |  |  | 266.9 |  |  | 199.5 |  |  | 75 | % |
| All Other | 66.0 |  |  | 66.0 |  |  | — |  |  | — | % |  | 198.0 |  |  | 198.0 |  |  | — |  |  | — | % |
| Total | $ | 1,225.4 |  |  | $ | 1,054.0 |  |  | $ | 171.4 |  |  | 16 | % |  | $ | 3,431.0 |  |  | $ | 2,985.9 |  |  | $ | 445.1 |  |  | 15 | % |

[0001045810-14-000188:mdna:45]
Revenue for the third quarter of fiscal year 2015 increased by 16% when compared to the third quarter of fiscal year 2014.  Revenue for the first nine months of fiscal year 2015 increased by 15% when compared to the first nine months of fiscal year 2014.  A discussion of our revenue results for each of our operating segments is as follows:

[0001045810-14-000188:mdna:46]
GPU Business. GPU business revenue increased by 13% in the third quarter of fiscal year 2015 compared to the third quarter of fiscal year 2014 and by 10% in the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014. These increases were due primarily to higher revenue from GeForce GPUs for gaming desktops and notebooks, reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products.  Revenue from Tesla for high performance computing also increased driven by large project wins with cloud service providers and government customers. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-14-000188:mdna:47]
Tegra Processor Business. Tegra Processor business revenue increased by 51% in the third quarter of fiscal year 2015 compared to the third quarter of fiscal year 2014, and by 75% in the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014.  These increases were driven by sales of Tegra products serving automobile infotainment systems, mobile devices, embedded systems, and the onset of SHIELD tablet sales.

[0001045810-14-000188:mdna:48]
28

[0001045810-14-000188:mdna:49]
All Other. We recognized $66.0 million and $198.0 million in revenue from the patent cross licensing arrangement with Intel during the third quarter of fiscal years 2015 and 2014, and the first nine months of fiscal years 2015 and 2014, respectively.

[0001045810-14-000188:mdna:50]
[same as prior period, unchanged from 0001045810-14-000158:mdna:45]

[0001045810-14-000188:mdna:51]
Revenue from sales to customers outside of the United States and Other Americas accounted for 74% of total revenue for the third quarter of fiscal year 2015 and 75% of total revenue for the first nine months of fiscal year 2015, respectively.  Revenue from sales to customers outside of the United States and Other Americas accounted for 74% of total revenue for both the third quarter and first nine months of fiscal year 2014.  Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-14-000188:mdna:52]
Revenue from significant customers, those representing 10% or more of total revenue, was 10% of our total revenue from one customer for the third quarter and first nine months of fiscal year 2015.  Revenue from significant customers was 11% of our total revenue from one customer for the third quarter of fiscal year 2014 and 21% of our total revenue from two customers for the first nine months of fiscal year 2014, respectively.

[0001045810-14-000188:mdna:53]
[same as prior period, unchanged from 0001045810-14-000158:mdna:48]

[0001045810-14-000188:mdna:54]
[same as prior period, unchanged from 0001045810-14-000158:mdna:49]

[0001045810-14-000188:mdna:55]
[same as prior period, unchanged from 0001045810-14-000158:mdna:50]

[0001045810-14-000188:mdna:56]
Our overall gross margin was 55.2% and 55.4% for the third quarter of fiscal years 2015 and 2014, respectively, and 55.4% and 55.2% for the first nine months of fiscal years 2015 and 2014, respectively.

[0001045810-14-000188:mdna:57]
Charges to cost of sales for inventory provisions totaled $12.7 million and $9.6 million for the third quarter of fiscal years 2015 and 2014, respectively, unfavorably impacting our gross margin by 1.0% and 0.9%, respectively. Sales of inventory that was previously written-off or written-down totaled $12.2 million and $7.7 million for the third quarter of fiscal years 2015 and 2014, respectively, favorably impacting our gross margin by 1.0% and 0.7%, respectively.  As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was no impact for the third quarter of fiscal year 2015 and a 0.2% unfavorable impact for the third quarter of fiscal year 2014.

[0001045810-14-000188:mdna:58]
Charges to cost of sales for inventory provisions totaled $35.7 million and $33.7 million for the first nine months of fiscal years 2015 and 2014, respectively, unfavorably impacting our gross margin by 1.0% and 1.1%, respectively. Sales of inventory that was previously written-off or written-down totaled $26.0 million and $38.6 million for the first nine months of fiscal years 2015 and 2014, respectively, favorably impacting our gross margin by 0.8% and 1.3%, respectively.  As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.2% unfavorable impact for the first nine months of fiscal year 2015 and a 0.2% favorable impact for the first nine months of fiscal year 2014.

[0001045810-14-000188:mdna:59]
[same as prior period, unchanged from 0001045810-14-000158:mdna:54]

[0001045810-14-000188:mdna:60]
GPU Business. The gross margin of our GPU business increased in the third quarter and first nine months of fiscal year 2015 compared to the third quarter and first nine months of fiscal year 2014. GPU margins increased primarily due to a richer product mix resulting from stronger sales of our Maxwell-based GeForce GPU products. Additionally, the volume increase of Tesla and GRID products also contributed to a richer mix of GPU sales.

[0001045810-14-000188:mdna:61]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased in the third quarter and first nine months of fiscal year 2015 compared to the third quarter and first nine months of fiscal year 2014. Tegra Processor margins decreased across most product categories and were also negatively impacted by the decline in license and royalty revenue associated with game consoles compared to the prior year.

[0001045810-14-000188:mdna:62]
29

[0001045810-14-000188:mdna:63]
[same as prior period, unchanged from 0001045810-14-000158:mdna:57]

[0001045810-14-000188:mdna:64]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | October 26, 2014 |  | October 27, 2013 |  | $Change |  | %Change |  | October 26, 2014 |  | October 27, 2013 |  | $Change |  | %Change |  |
|  | (In millions) |  |  |  | (In millions) |  |  |  |
| Research and development expenses | $ | 340.1 |  |  | $ | 340.3 |  |  | $ | (0.2 | ) |  | — |  | % | $ | 1,011.5 |  |  | $ | 999.2 |  |  | $ | 12.3 |  |  | 1 | % |
| Sales, general and administrative expenses | 123.3 |  |  | 103.1 |  |  | 20.2 |  |  | 20 |  | % | 360.5 |  |  | 320.0 |  |  | 40.5 |  |  | 13 | % |
| Total operating expenses | $ | 463.4 |  |  | $ | 443.4 |  |  | $ | 20.0 |  |  | 5 |  | % | $ | 1,372.0 |  |  | $ | 1,319.2 |  |  | $ | 52.8 |  |  | 4 | % |
| Research and development as a percentage of net revenue | 28 |  | % | 32 |  | % |  |  |  |  |  |  | 29 |  | % | 33 |  | % |  |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 10 |  | % | 10 |  | % |  |  |  |  |  |  | 11 |  | % | 11 |  | % |  |  |  |  |  |

[0001045810-14-000188:mdna:65]
[same as prior period, unchanged from 0001045810-14-000158:mdna:59]

[0001045810-14-000188:mdna:66]
Research and development expenses remained relatively flat during the third quarter of fiscal year 2015 compared to the third quarter of fiscal year 2014. Compensation and benefits increased by $14.2 million resulting from employee additions, employee compensation increases and related costs. Offsetting these increases was a $10.7 million decrease in engineering development expenses.

[0001045810-14-000188:mdna:67]
Research and development expenses increased by 1% during the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014. Compensation and benefits increased by $38.6 million resulting from employee additions, employee compensation increases and related costs, partially offset by a $22.2 million decrease in engineering development expenses.

[0001045810-14-000188:mdna:68]
[same as prior period, unchanged from 0001045810-14-000158:mdna:62]

[0001045810-14-000188:mdna:69]
Sales, general and administrative expenses increased by 20% during the third quarter of fiscal year 2015 compared to the third quarter of fiscal year 2014. This increase was primarily due to a $16.0 million increase resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense. Advertising and marketing expenses also increased by $5.5 million as we continue to market our newly-launched GPU and SHIELD products. Offsetting these increases was a decrease of $3.0 million in outside professional fees.

[0001045810-14-000188:mdna:70]
Sales, general and administrative expenses increased by 13% during the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014. This increase was primarily due to a $40.6 million increase resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense. Facilities costs increased by $8.1 million as we expanded our offices internationally and leased an office building within the boundaries of our main Santa Clara campus.  Offsetting these increases were decreases in outside professional fees of $9.9 million as well as more favorable international taxes and government subsidies.

[0001045810-14-000188:mdna:71]
[same as prior period, unchanged from 0001045810-14-000158:mdna:66]

[0001045810-14-000188:mdna:72]
[same as prior period, unchanged from 0001045810-14-000158:mdna:67]

[0001045810-14-000188:mdna:73]
Interest income increased by $3.4 million and $7.0 million during the third quarter and first nine months of fiscal years 2015 and 2014, respectively. The increase was primarily due to higher average cash balances as we invested the proceeds from the convertible notes we issued in December 2013 in interest bearing securities.

[0001045810-14-000188:mdna:74]
Interest expense increased by $10.7 million and $32.0 million during the third quarter and first nine months of fiscal years 2015 and 2014, respectively. The increase was primarily due to coupon interest and debt discount amortization related to the convertible notes we issued in December 2013.

[0001045810-14-000188:mdna:75]
[same as prior period, unchanged from 0001045810-14-000158:mdna:70]

[0001045810-14-000188:mdna:76]
[same as prior period, unchanged from 0001045810-14-000158:mdna:71]

[0001045810-14-000188:mdna:77]
Other income increased by $2.0 million during the third quarter of fiscal year 2015 compared to the same period in the prior fiscal year. This increase was due to higher foreign currency translation gains. Other income increased by $14.9 million during the first nine months of fiscal year 2015 compared to the same period in the prior fiscal year due to a gain from the sale of a non-affiliated investment, offset by lower foreign currency translation gains.

[0001045810-14-000188:mdna:78]
Other expense remained relatively flat during the third quarter of fiscal year 2015 compared to the third quarter of fiscal year 2014. Other expense increased by $2.8 million for the first nine months of fiscal year 2015 compared to the same period in the prior fiscal year due to the recognition of an impairment loss in a non-affiliated investment during the second quarter of fiscal year 2015. Additionally, losses from realized foreign exchange translations were greater in the first nine months of fiscal year 2015.

[0001045810-14-000188:mdna:79]
[same as prior period, unchanged from 0001045810-14-000158:mdna:74]

[0001045810-14-000188:mdna:80]
We recognized income tax expense of $36.1 million and $89.5 million for the third quarter and first nine months of fiscal year 2015, respectively, and $22.8 million and $48.3 million for the third quarter and first nine months of fiscal year 2014, respectively.  Income tax expense as a percentage of income before taxes, or our effective tax rate, was 17.3% and 17.0% for the third quarter and first nine months of fiscal year 2015, respectively, and 16.1% and 14.2% for the third quarter and first nine months of fiscal year 2014, respectively.

[0001045810-14-000188:mdna:81]
The increase in our effective tax rate in fiscal year 2015 as compared to the same periods in the prior fiscal year was primarily related to the expiration of the U.S. federal research tax credit on December 31, 2013 which resulted in no tax benefit in the first nine months of fiscal year 2015.

[0001045810-14-000188:mdna:82]
Our effective tax rate on income before tax for the first nine months of fiscal year 2015 of 17.0% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate.  Further, our effective tax rate for the first nine months of fiscal year 2015 of 17.0% differs from our annual projected effective tax rate as of the first nine months of fiscal year 2015 of 18.5% due to discrete events that occurred in the first nine months of fiscal year 2015 primarily attributable to the tax benefit recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-14-000188:mdna:83]
Our effective tax rate on income before tax for the first nine months of fiscal year 2014 of 14.2% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax and the benefit of the U.S. federal research tax credit.

[0001045810-14-000188:mdna:84]
[same as prior period, unchanged from 0001045810-14-000158:mdna:79]

[0001045810-14-000188:mdna:85]
[same as prior period, unchanged from 0001045810-14-000158:mdna:81]

[0001045810-14-000188:mdna:86]
|  | As of October 26,2014 |  | As of January 26,2014 |
|  | (In millions) |
| Cash and cash equivalents | $ | 394.7 |  |  | $ | 1,151.6 |  |
| Marketable securities | 3,846.1 |  |  | 3,520.2 |  |
| Cash, cash equivalents, and marketable securities | $ | 4,240.8 |  |  | $ | 4,671.8 |  |

[0001045810-14-000188:mdna:87]
As of October 26, 2014, we had $4.24 billion in cash, cash equivalents and marketable securities, a decrease of $431.0 million from $4.67 billion as of January 26, 2014. This decrease was primarily due to the accelerated share repurchase transactions totaling $810.0 million that we entered into and the $140.2 million in dividends we paid during the first nine months of fiscal year 2015, partially offset by cash generated from operations. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions that are required to follow our investment policy, which requires the purchase of high grade investment securities and the diversification of asset type and includes certain limits on our portfolio duration.

[0001045810-14-000188:mdna:88]
|  | Nine Months Ended |
|  | October 26, |  | October 27, |
|  | 2014 |  | 2013 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 462.9 |  |  | $ | 434.4 |  |
| Net cash provided by (used in) investing activities | $ | (408.9 | ) |  | $ | 293.7 |  |
| Net cash used in financing activities | $ | (811.0 | ) |  | $ | (898.8 | ) |

[0001045810-14-000188:mdna:89]
[same as prior period, unchanged from 0001045810-14-000158:mdna:85]

[0001045810-14-000188:mdna:90]
Operating activities consist primarily of net income for the fiscal period, offset by the impact of non-cash expenses such as depreciation and amortization expense, stock-based compensation expense, gains or losses from sale and disposal of long-lived assets and investments, and interest expense from the amortization of debt discount, as well as changes in operating assets and liabilities, such as accounts receivable, inventories and accounts payable.

[0001045810-14-000188:mdna:91]
Cash provided by operating activities increased in the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014. The increase was primarily due to higher net income from revenue growth and contained operating expenses, partially offset by higher accounts receivable.

[0001045810-14-000188:mdna:92]
[same as prior period, unchanged from 0001045810-14-000158:mdna:88]

[0001045810-14-000188:mdna:93]
Investing activities consist primarily of purchases, sales and maturities of marketable securities, acquisitions of businesses and purchases of property and equipment, including leasehold improvements for our facilities and intangible assets.

[0001045810-14-000188:mdna:94]
Investing activities shifted to net cash used in investing activities during the first nine months of fiscal year 2015 from cash provided by investing activities during the first nine months of fiscal year 2014. This shift was primarily due to higher purchases of marketable securities and fewer sales of marketable securities as we reinvested the proceeds received from the convertible note offering that was completed during December 2013. Partially offsetting this was a decrease in capital expenditures and an increase in maturities of marketable securities for the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014. The primary reason for net cash provided by investing activities in the first nine months of fiscal year 2014 was the result of liquidation of a portion of our investment portfolio to fund the accelerated share repurchase transaction that was entered into in May 2013.

[0001045810-14-000188:mdna:95]
32

[0001045810-14-000188:mdna:96]
[same as prior period, unchanged from 0001045810-14-000158:mdna:91]

[0001045810-14-000188:mdna:97]
[same as prior period, unchanged from 0001045810-14-000158:mdna:92]

[0001045810-14-000188:mdna:98]
Cash used in financing activities decreased in the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014, primarily due to an increase in proceeds from common stock issued from employee stock option exercises and employee stock purchase plans, partially offset by a decrease in stock repurchases during the first nine months of fiscal year 2015 compared to the first nine months of fiscal year 2014.

[0001045810-14-000188:mdna:99]
[same as prior period, unchanged from 0001045810-14-000158:mdna:94]

[0001045810-14-000188:mdna:100]
[same as prior period, unchanged from 0001045810-14-000158:mdna:95]

[0001045810-14-000188:mdna:101]
[same as prior period, unchanged from 0001045810-14-000158:mdna:96]

[0001045810-14-000188:mdna:102]
As of October 26, 2014 and January 26, 2014, we had $4.24 billion and $4.67 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of October 26, 2014, we were in compliance with our investment policy.  As of October 26, 2014, our investments in government agencies and government-sponsored enterprises represented 36% of our total investment portfolio, while the financial sector accounted for 31% of our total investment portfolio.  All of our investments are with A/A3 or better rated securities.

[0001045810-14-000188:mdna:103]
We performed an impairment review of our investment portfolio as of October 26, 2014. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and did not record any impairment during the third quarter of fiscal year 2015.

[0001045810-14-000188:mdna:104]
Net realized gains and losses for the three and nine months ended October 26, 2014, and for the three months ended October 27, 2013, were not significant. Net realized gains for the nine months ended October 27, 2013 were $1.8 million. As of October 26, 2014, we had a net unrealized gain of $10.4 million, which was comprised of gross unrealized gains of $12.0 million, offset by gross unrealized losses of $1.6 million. As of January 26, 2014, we had a net unrealized gain of $4.8 million, which was comprised of gross unrealized gains of $7.2 million, offset by $2.4 million of gross unrealized losses.

[0001045810-14-000188:mdna:105]
Our accounts receivable are highly concentrated. One customer accounted for 17% of our accounts receivable balance at October 26, 2014. We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure.

[0001045810-14-000188:mdna:106]
Our cash balances are held in numerous locations throughout the world, including substantial amounts held outside of the United States.  Most of the amounts held outside the United States may be repatriated to the United States.  However, if we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal income tax at rate of 35% less utilization of any net operating loss carryforwards, and further offset by any applicable research and foreign tax credits, plus any state income taxes on such income.  Repatriation of some foreign balances may be restricted by local laws.

[0001045810-14-000188:mdna:107]
33

[0001045810-14-000188:mdna:108]
Dividend payments and any stock repurchases must be made from cash held in the United States.  In the first nine months of fiscal year 2015, we made total cash dividend payments of $140.2 million and repurchased $810.0 million of our common stock, utilizing a significant amount of our U.S. cash balance previously taxed as of October 26, 2014.

[0001045810-14-000188:mdna:109]
Capital Return to Shareholders

[0001045810-14-000188:mdna:110]
Our Board of Directors has authorized us to repurchase up to $3.70 billion of our common stock through January 2016.  As of October 26, 2014, we had repurchased $3.26 billion of that amount, leaving up to $438.4 million available under this authorization through January 2016. As part of our stock repurchase program, during the first nine months of fiscal year 2015, we entered into two accelerated share repurchase agreements, or ASRs, that were completed in July 2014 and October 2014, respectively. Under the terms of these ASRs, we paid $810.0 million to purchase shares of our common stock and received an aggregate of 44.2 million shares.  Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding these ASRs.

[0001045810-14-000188:mdna:111]
During the first nine months of fiscal year 2015, we paid $140.2 million in cash dividends to our common shareholders. This dividend was equivalent to $0.085 per share on a quarterly basis, or $0.34 per share on an annual basis.  We also declared that we would pay our next quarterly cash dividend of $0.085 per share on December 15, 2014, to all shareholders of record on November 21, 2014.

[0001045810-14-000188:mdna:112]
As such, in the aggregate for the first nine months of fiscal year 2015, we have returned a total of $950.2 million of our intended capital return of $1.00 billion to shareholders during fiscal year 2015. On November 6, 2014, we announced our intent to return $600.0 million in capital to our shareholders in fiscal year 2016 through a combination of stock repurchases and quarterly dividend payments.

[0001045810-14-000188:mdna:113]
Our cash dividend program and the payment of future cash dividends under that program are subject to continued capital availability and our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders and are in compliance with all laws and agreements of NVIDIA applicable to the declaration and payment of cash dividends.

[0001045810-14-000188:mdna:114]
[same as prior period, unchanged from 0001045810-14-000158:mdna:108]

[0001045810-14-000188:mdna:115]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating, acquisition, stock repurchase, cash dividend and capital requirements for at least the next twelve months. However, there is no assurance that we will not need to raise additional equity or debt financing within this time frame. Additional financing may not be available on favorable terms or at all and may be dilutive to our then-current shareholders. We also may require additional capital for other purposes not presently contemplated.

[0001045810-14-000188:mdna:116]
[same as prior period, unchanged from 0001045810-14-000158:mdna:110]

[0001045810-14-000188:mdna:117]
[same as prior period, unchanged from 0001045810-14-000158:mdna:111]

[0001045810-14-000188:mdna:118]
As of October 26, 2014, we had outstanding inventory purchase obligations totaling $512.2 million. There were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014.

[0001045810-14-000188:mdna:119]
[same as prior period, unchanged from 0001045810-14-000158:mdna:113]

[0001045810-14-000188:mdna:120]
[same as prior period, unchanged from 0001045810-14-000158:mdna:114]

[0001045810-14-000188:mdna:121]
As of October 26, 2014, we had no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001045810-14-000188:mdna:122]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-14-000188:mdna:123]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
