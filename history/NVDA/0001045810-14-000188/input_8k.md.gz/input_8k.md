# NVDA 8-K — 0001045810-14-000182 filed 2014-11-06

## item codes, every 8-K on or before 2014-11-19

- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2014-11-19

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-14-000182:8k_2_02:1]
EX-99.1
2
q315pr.htm
Q3'15 PRESS RELEASE

[0001045810-14-000182:8k_2_02:2]
Q3'15 PR

[0001045810-14-000182:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-14-000182:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2015

[0001045810-14-000182:8k_2_02:5]
| • | Record revenue of $1.23 billion in quarter, up 16 percent from a year earlier |

[0001045810-14-000182:8k_2_02:6]
| • | GAAP diluted EPS of $0.31 in quarter, up from $0.20 a year earlier; non-GAAP diluted EPS of $0.39, up from $0.26 a year earlier |

[0001045810-14-000182:8k_2_02:7]
| • | Record revenue of $3.43 billion in first three quarters, up 15 percent from a year earlier |

[0001045810-14-000182:8k_2_02:8]
SANTA CLARA, Calif.-Nov. 6, 2014-NVIDIA (NASDAQ: NVDA) today reported revenue for the third quarter ended October 26, 2014, of $1.23 billion, up 16 percent from $1.05 billion a year earlier and up 11 percent from $1.10 billion the previous quarter.  Revenue for the first three quarters of fiscal 2015 was a record $3.43 billion, up 15 percent from $2.99 billion a year earlier.

[0001045810-14-000182:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.31, up 55 percent from $0.20 a year earlier and up 41 percent from the previous quarter. Non-GAAP earnings per diluted share were $0.39, up 50 percent from $0.26 a year earlier and up 30 percent from the previous quarter.

[0001045810-14-000182:8k_2_02:10]
“NVIDIA’s focus on creating visual computing platforms for datacenter, mobile and PC drove record revenue this quarter,” said Jen-Hsun Huang, president and chief executive officer of NVIDIA.

[0001045810-14-000182:8k_2_02:11]
“Growth drivers have kicked in for us on several fronts. High-performance computing, virtualization and web service providers have created demand for our GPU-accelerated datacenter platforms. Automakers are using Tegra to help reinvent the driving experience. And our new Maxwell architecture is a giant leap forward that has triggered a major upgrade cycle by PC gamers.”

[0001045810-14-000182:8k_2_02:12]
During the third quarter, NVIDIA paid $46 million in cash dividends and received 16.8 million shares under a $310 million structured repurchase agreement it entered into in the quarter. During the first three quarters of fiscal 2015, the company paid $140 million in cash dividends and repurchased 44.2 million shares. As a result, the company has returned to shareholders $950 million in the first three quarters of fiscal 2015.

[0001045810-14-000182:8k_2_02:13]
Since restarting its capital return program in the fourth quarter of fiscal 2013, NVIDIA has returned approximately $2.17 billion to shareholders. This represents 136 percent of the company’s cumulative free cash flow for fiscal years 2013 to 2015 to date, and reflects the acceleration of the capital return program of cash generated in previous years.

[0001045810-14-000182:8k_2_02:14]
The company intends to return approximately $600 million to shareholders in fiscal 2016 through ongoing quarterly cash dividends and share repurchases.

[0001045810-14-000182:8k_2_02:15]
NVIDIA will pay its next quarterly cash dividend of $0.085 per share on Dec. 15, 2014, to all shareholders of record on Nov. 21, 2014.  NVIDIA expects that a portion of this dividend payment may be considered a return of capital for U.S. federal income tax purposes.

[0001045810-14-000182:8k_2_02:16]
| GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q3 FY15 | Q2 FY15 | Q3 FY14 | Q/Q | Y/Y |
| Revenue | $1,225 | $1,103 | $1,054 | up 11% | up 16% |
| Gross margin | 55.2% | 56.1% | 55.4% | down 90 bps | down 20 bps |
| Operating expenses | $463 | $456 | $443 | up 2% | up 5% |
| Net income | $173 | $128 | $119 | up 35% | up 45% |
| Diluted earnings per share | $0.31 | $0.22 | $0.20 | up 41% | up 55% |

[0001045810-14-000182:8k_2_02:17]
| Non-GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q3 FY15 | Q2 FY15 | Q3 FY14 | Q/Q | Y/Y |
| Revenue | $1,225 | $1,103 | $1,054 | up 11% | up 16% |
| Gross margin | 55.5% | 56.4% | 55.7% | down 90 bps | down 20 bps |
| Operating expenses | $415 | $411 | $405 | up 1% | up 2% |
| Net income | $220 | $173 | $154 | up 27% | up 43% |
| Diluted earnings per share | $0.39 | $0.30 | $0.26 | up 30% | up 50% |

[0001045810-14-000182:8k_2_02:18]
NVIDIA’s outlook for the fourth quarter of fiscal 2015 is as follows:

[0001045810-14-000182:8k_2_02:19]
| • | Revenue is expected to be $1.20 billion, plus or minus two percent. |

[0001045810-14-000182:8k_2_02:20]
| • | GAAP and non-GAAP gross margins are expected to be 55.2 percent and 55.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-14-000182:8k_2_02:21]
| • | GAAP operating expenses are expected to be approximately $470 million; non-GAAP operating expenses are expected to be approximately $422 million, inclusive of litigation costs. |

[0001045810-14-000182:8k_2_02:22]
| • | GAAP and non-GAAP tax rates for the fourth quarter of fiscal 2015 are both expected to be 18 percent, plus or minus one percentage point. This estimate excludes any discrete tax events that may occur during a quarter which, if realized, may increase or decrease NVIDIA’s actual effective tax rates in such quarter. |

[0001045810-14-000182:8k_2_02:23]
| • | Capital expenditures are expected to be approximately $40 million to $50 million. |

[0001045810-14-000182:8k_2_02:24]
Third Quarter Fiscal 2015 Highlights

[0001045810-14-000182:8k_2_02:25]
During the third quarter, NVIDIA:

[0001045810-14-000182:8k_2_02:26]
| • | Launched flagship NVIDIA® GeForce® GTX™ GPUs for gaming based on Maxwell™, its 10th generation GPU architecture, which sets new standards of efficiency and performance. |

[0001045810-14-000182:8k_2_02:27]
| • | Extended Maxwell-based processors into the company’s upgraded NVIDIA Quadro® lineup. |

[0001045810-14-000182:8k_2_02:28]
| • | Continued Tesla®’s push into the big data analytics market. IBM announced future support for GPU acceleration in its IBM DB2 with BLU database software; NVIDIA released a deep learning library to enable faster growth in machine learning; and nearly all teams in the recent ImageNet international computer-vision competition used GPUs. |

[0001045810-14-000182:8k_2_02:29]
| • | Announced its early customer access program for NVIDIA GRID™ with VMware, which is drawing strong interest from companies worldwide. Among those signing up were airline-manufacturer Airbus, international construction group CH2M Hill and U.S. healthcare-provider MetroHealth. |

[0001045810-14-000182:8k_2_02:30]
| • | Added new wins for the Tegra® K1 mobile processor, including the Google Nexus 9 tablet and NVIDIA’s SHIELD™ tablet with 32GB of memory and LTE connectivity. Acer and HP also announced Chromebooks with Tegra K1. |

[0001045810-14-000182:8k_2_02:31]
| • | Surpassed 6 million cars on the road with infotainment systems powered by NVIDIA. Honda also announced that three of its models - the Civic, Civic Tourer and CR-V - will include Tegra-based systems in the European market. |

[0001045810-14-000182:8k_2_02:32]
| • | Filed lawsuits against Samsung and Qualcomm in the International Trade Commission (ITC) and U.S. District Court in Delaware for using NVIDIA GPU patents without a license. The ITC has subsequently determined that it will investigate the case and hold an evidentiary hearing in June of 2015. |

[0001045810-14-000182:8k_2_02:33]
CFO Commentary

[0001045810-14-000182:8k_2_02:34]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-14-000182:8k_2_02:35]
Conference Call and Webcast Information

[0001045810-14-000182:8k_2_02:36]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2015 financial results and current financial prospects today at 2:00 p.m. Pacific Time (5:00 p.m. Eastern Time). To listen to the conference call, dial (303) 223-2684; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at the NVIDIA investor relations web site http://investor.nvidia.com/ and at www.streetevents.com. The webcast will be recorded and available for replay until the company's conference call to discuss its financial results for its fourth quarter fiscal 2015.

[0001045810-14-000182:8k_2_02:37]
Non-GAAP Measures

[0001045810-14-000182:8k_2_02:38]
To supplement NVIDIA’s Condensed Consolidated Statements of Operations and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP other income and expense, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, legal settlements, acquisition-related costs, gains and losses from non-affiliated investments, interest expense related to the amortization of debt discount, other expense and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user's overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and our non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-14-000182:8k_2_02:39]
To Keep Current on NVIDIA:

[0001045810-14-000182:8k_2_02:40]
| • | Keep up with the NVIDIA Blog. |

[0001045810-14-000182:8k_2_02:41]
| • | Like NVIDIA on Facebook. |

[0001045810-14-000182:8k_2_02:42]
| • | Connect with NVIDIA on LinkedIn. |

[0001045810-14-000182:8k_2_02:43]
| • | Follow @NVIDIA on Twitter. |

[0001045810-14-000182:8k_2_02:44]
| • | View NVIDIA videos on YouTube. |

[0001045810-14-000182:8k_2_02:45]
| • | Use the Pulse news reader to subscribe to the NVIDIA Daily News feed. |

[0001045810-14-000182:8k_2_02:46]
About NVIDIA

[0001045810-14-000182:8k_2_02:47]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-14-000182:8k_2_02:48]
Certain statements in this press release including, but not limited to statements as to: demand for the company’s GPU-accelerated datacenter platforms; automakers using Tegra to help reinvent the driving experience; Maxwell architecture as a giant leap forward; the company’s intent to return $600 million to shareholders in fiscal 2016; a portion of the company’s dividend payment being considered a return of capital; the company’s financial outlook for the fourth quarter of fiscal 2015; and the company’s tax rate for the fourth quarter of fiscal 2015 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended July 27, 2014. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-14-000182:8k_2_02:49]
© 2014 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GTX, Quadro, Tegra, Tesla, Maxwell, NVIDIA GRID, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-14-000182:8k_2_02:50]
###

[0001045810-14-000182:8k_2_02:51]
For further information, contact:

[0001045810-14-000182:8k_2_02:52]
| Raj Santhanam |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| rsanthanam@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-14-000182:8k_2_02:53]
NVIDIA CORPORATION

[0001045810-14-000182:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-14-000182:8k_2_02:55]
(In thousands, except per share data)

[0001045810-14-000182:8k_2_02:56]
(Unaudited)

[0001045810-14-000182:8k_2_02:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenue | $ | 1,225,382 |  |  | $ | 1,053,967 |  |  | $ | 3,430,993 |  |  | $ | 2,985,944 |  |
| Cost of revenue | 548,684 |  |  | 469,552 |  |  | 1,531,119 |  |  | 1,337,423 |  |
| Gross profit | 676,698 |  |  | 584,415 |  |  | 1,899,874 |  |  | 1,648,521 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 340,085 |  |  | 340,294 |  |  | 1,011,472 |  |  | 999,193 |  |
| Sales, general and administrative | 123,298 |  |  | 103,133 |  |  | 360,549 |  |  | 320,025 |  |
| Total operating expenses | 463,383 |  |  | 443,427 |  |  | 1,372,021 |  |  | 1,319,218 |  |
| Operating income | 213,315 |  |  | 140,988 |  |  | 527,853 |  |  | 329,303 |  |
| Interest income | 7,422 |  |  | 4,022 |  |  | 19,961 |  |  | 12,963 |  |
| Interest expense | 11,542 |  |  | 819 |  |  | 34,539 |  |  | 2,508 |  |
| Other income (expense), net | (125 | ) |  | (2,707 | ) |  | 13,702 |  |  | 1,608 |  |
| Income before income tax expense | 209,070 |  |  | 141,484 |  |  | 526,977 |  |  | 341,366 |  |
| Income tax expense | 36,103 |  |  | 22,750 |  |  | 89,518 |  |  | 48,293 |  |
| Net income | $ | 172,967 |  |  | $ | 118,734 |  |  | $ | 437,459 |  |  | $ | 293,073 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.32 |  |  | $ | 0.20 |  |  | $ | 0.79 |  |  | $ | 0.49 |  |
| Diluted | $ | 0.31 |  |  | $ | 0.20 |  |  | $ | 0.77 |  |  | $ | 0.49 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 547,789 |  |  | 580,870 |  |  | 555,035 |  |  | 594,363 |  |
| Diluted | 558,201 |  |  | 588,752 |  |  | 565,653 |  |  | 600,108 |  |

[0001045810-14-000182:8k_2_02:58]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  | October 26, |  | January 26, |
|  |  |  | 2014 |  | 2014 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,240,797 |  |  | $ | 4,671,810 |  |
|  | Accounts receivable, net |  | 563,400 |  |  | 426,357 |  |
|  | Inventories |  | 408,081 |  |  | 387,765 |  |
|  | Prepaid expenses and other current assets |  | 128,831 |  |  | 138,779 |  |
|  | Total current assets |  | 5,341,109 |  |  | 5,624,711 |  |
| Property and equipment, net |  | 566,601 |  |  | 582,740 |  |
| Goodwill |  | 643,179 |  |  | 643,179 |  |
| Intangible assets, net |  | 241,301 |  |  | 296,012 |  |
| Other assets |  | 93,679 |  |  | 104,252 |  |
|  | Total assets |  | $ | 6,885,869 |  |  | $ | 7,250,894 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 328,097 |  |  | $ | 324,391 |  |
|  | Accrued liabilities and other current liabilities |  | 605,810 |  |  | 621,105 |  |
|  | Total current liabilities |  | 933,907 |  |  | 945,496 |  |
| Long-term debt |  | 1,377,259 |  |  | 1,356,375 |  |
| Other long-term liabilities |  | 355,133 |  |  | 475,125 |  |
| Capital lease obligations, long-term |  | 14,977 |  |  | 17,500 |  |
| Stockholders' equity |  | 4,204,593 |  |  | 4,456,398 |  |
|  | Total liabilities and stockholders' equity |  | $ | 6,885,869 |  |  | $ | 7,250,894 |  |

[0001045810-14-000182:8k_2_02:59]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | July 27, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP gross profit |  | $ | 676,698 |  |  | $ | 618,974 |  |  | $ | 584,415 |  |  | $ | 1,899,874 |  |  | $ | 1,648,521 |  |
| GAAP gross margin |  | 55.2 | % |  | 56.1 | % |  | 55.4 | % |  | 55.4 | % |  | 55.2 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 3,021 |  |  | 2,656 |  |  | 3,090 |  |  | 8,596 |  |  | 7,911 |  |
| Legal settlement |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,290 |  |
| Non-GAAP gross profit |  | $ | 679,719 |  |  | $ | 621,630 |  |  | $ | 587,505 |  |  | $ | 1,908,470 |  |  | $ | 1,658,722 |  |
| Non-GAAP gross margin |  | 55.5 | % |  | 56.4 | % |  | 55.7 | % |  | 55.6 | % |  | 55.6 | % |
| GAAP operating expenses |  | $ | 463,383 |  |  | $ | 455,795 |  |  | $ | 443,427 |  |  | $ | 1,372,021 |  |  | $ | 1,319,218 |  |
| Stock-based compensation expense included in operating expense (A) |  | (38,414 | ) |  | (35,759 | ) |  | (31,209 | ) |  | (106,775 | ) |  | (92,180 | ) |
| Acquisition-related costs (B) |  | (9,572 | ) |  | (9,173 | ) |  | (4,577 | ) |  | (28,186 | ) |  | (22,402 | ) |
| Other expense (C) |  | — |  |  | — |  |  | (2,235 | ) |  | — |  |  | (2,235 | ) |
| Non-GAAP operating expenses |  | $ | 415,397 |  |  | $ | 410,863 |  |  | $ | 405,406 |  |  | $ | 1,237,060 |  |  | $ | 1,202,401 |  |
| GAAP other income (expense), net | $ | (4,245 | ) |  | $ | (8,554 | ) |  | $ | 496 |  |  | $ | (876 | ) |  | $ | 12,063 |  |
| Gains and losses from non-affiliated investments |  | — |  |  | 2,500 |  |  | — |  |  | (14,482 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | 7,010 |  |  | 6,973 |  |  | — |  |  | 20,884 |  |  | — |  |
| Non-GAAP other income (expense), net | $ | 2,765 |  |  | $ | 919 |  |  | $ | 496 |  |  | $ | 5,526 |  |  | $ | 12,063 |  |
| GAAP net income |  | $ | 172,967 |  |  | $ | 127,976 |  |  | $ | 118,734 |  |  | $ | 437,459 |  |  | $ | 293,073 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 58,017 |  |  | 57,061 |  |  | 41,111 |  |  | 149,959 |  |  | 127,018 |  |
| Income tax impact of non-GAAP adjustments |  | (10,549 | ) |  | (11,606 | ) |  | (6,055 | ) |  | (27,497 | ) |  | (19,170 | ) |
| Non-GAAP net income |  | $ | 220,435 |  |  | $ | 173,431 |  |  | $ | 153,790 |  |  | $ | 559,921 |  |  | $ | 400,921 |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.31 |  |  | $ | 0.22 |  |  | $ | 0.20 |  |  | $ | 0.77 |  |  | $ | 0.49 |  |
| Non-GAAP |  | $ | 0.39 |  |  | $ | 0.30 |  |  | $ | 0.26 |  |  | $ | 0.99 |  |  | $ | 0.67 |  |
| Shares used in diluted net income per share computation |  | 558,201 |  |  | 570,572 |  |  | 588,752 |  |  | 565,653 |  |  | 600,108 |  |
| Metrics: |  |  |  |  |  |  |  |  |  |  |
| GAAP net cash flow provided by operating activities |  | $ | 215,623 |  |  | $ | 96,282 |  |  | $ | 162,315 |  |  | $ | 462,927 |  |  | $ | 434,434 |  |
| Purchase of property and equipment and intangible assets |  | (39,741 | ) |  | (22,527 | ) |  | (38,159 | ) |  | (91,336 | ) |  | (188,812 | ) |
| Free cash flow |  | $ | 175,882 |  |  | $ | 73,755 |  |  | $ | 124,156 |  |  | $ | 371,591 |  |  | $ | 245,622 |  |

[0001045810-14-000182:8k_2_02:60]
| (A) Excludes stock-based compensation as follows: |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | July 27, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of revenue |  | $ | 3,021 |  |  | $ | 2,656 |  |  | $ | 3,090 |  |  | $ | 8,596 |  |  | $ | 7,911 |  |
| Research and development |  | $ | 22,680 |  |  | $ | 21,462 |  |  | $ | 20,902 |  |  | $ | 64,636 |  |  | $ | 61,392 |  |
| Sales, general and administrative |  | $ | 15,734 |  |  | $ | 14,297 |  |  | $ | 10,307 |  |  | $ | 42,139 |  |  | $ | 30,788 |  |
| (B) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (C) Consists of restructuring charges. |

[0001045810-14-000182:8k_2_02:61]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2015 Outlook |
| GAAP gross margin |  | 55.2 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 55.5 | % |
|  |  |  | Q4 FY2015 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 470 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (48 | ) |
| Non-GAAP operating expenses |  | $ | 422 |  |
