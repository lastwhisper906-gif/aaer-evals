# NVDA notes — 0001045810-14-000188


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001045810-14-000188:notes:1]
|  | October 26, |  | January 26, |
|  | 2014 |  | 2014 |
| Accrued Liabilities and Other Current Liabilities: | (In thousands) |
| Deferred revenue, short-term | $ | 240,829 |  |  | $ | 265,616 |  |
| Accrued customer programs (1) | 154,185 |  |  | 157,840 |  |
| Accrued payroll and related expenses | 98,870 |  |  | 109,721 |  |
| Accrued legal settlement (2) | 30,600 |  |  | 30,600 |  |
| Customer advances | 17,806 |  |  | 9,297 |  |
| Professional service fees | 12,368 |  |  | 13,572 |  |
| Warranty accrual (3) | 7,222 |  |  | 7,571 |  |
| Coupon interest on Notes | 6,292 |  |  | 2,500 |  |
| Taxes payable, short-term | 5,512 |  |  | 2,378 |  |
| Facilities related liabilities | 15,781 |  |  | 5,216 |  |
| Other | 16,345 |  |  | 16,794 |  |
| Total accrued liabilities and other current liabilities | $ | 605,810 |  |  | $ | 621,105 |  |

[0001045810-14-000188:notes:2]
[same as prior period, unchanged from 0001045810-14-000158:notes:2]

[0001045810-14-000188:notes:3]
(2)  Please refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the 3dfx litigation.

[0001045810-14-000188:notes:4]
[same as prior period, unchanged from 0001045810-14-000158:notes:4]


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-14-000188:notes:5]
|  | October 26, 2014 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 1,954,162 |  |  | $ | 3,418 |  |  | $ | (520 | ) |  | $ | 1,957,060 |  |
| Debt securities of United States government agencies | 585,391 |  |  | 787 |  |  | (53 | ) |  | 586,125 |  |
| Debt securities issued by United States Treasury | 575,188 |  |  | 2,891 |  |  | (66 | ) |  | 578,013 |  |
| Asset-backed securities | 437,791 |  |  | 159 |  |  | (199 | ) |  | 437,751 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 273,812 |  |  | 4,590 |  |  | (718 | ) |  | 277,684 |  |
| Foreign government bonds | 85,259 |  |  | 135 |  |  | (16 | ) |  | 85,378 |  |
| Money market funds | 72,881 |  |  | — |  |  | — |  |  | 72,881 |  |
| Total | $ | 3,984,484 |  |  | $ | 11,980 |  |  | $ | (1,572 | ) |  | $ | 3,994,892 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 148,778 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 3,846,114 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 3,994,892 |  |

[0001045810-14-000188:notes:6]
|  | January 26, 2014 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 1,762,833 |  |  | $ | 1,837 |  |  | $ | (945 | ) |  | $ | 1,763,725 |  |
| Debt securities of United States government agencies | 1,012,740 |  |  | 848 |  |  | (261 | ) |  | 1,013,327 |  |
| Debt securities issued by United States Treasury | 495,889 |  |  | 621 |  |  | (57 | ) |  | 496,453 |  |
| Money market funds | 307,865 |  |  | — |  |  | — |  |  | 307,865 |  |
| Asset-backed securities | 258,017 |  |  | 15 |  |  | (315 | ) |  | 257,717 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 185,594 |  |  | 3,837 |  |  | (725 | ) |  | 188,706 |  |
| Foreign government bonds | 64,955 |  |  | 20 |  |  | (120 | ) |  | 64,855 |  |
| Total | $ | 4,087,893 |  |  | $ | 7,178 |  |  | $ | (2,423 | ) |  | $ | 4,092,648 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 572,425 |  |
| Marketable securities |  |  |  |  |  |  | 3,520,223 |  |
| Total |  |  |  |  |  |  | $ | 4,092,648 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-14-000188:notes:7]
Commitments and Contingencies

[0001045810-14-000188:notes:8]
3dfx

[0001045810-14-000188:notes:9]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx. The transaction closed on April 18, 2001. In October 2002, 3dfx filed for bankruptcy.

[0001045810-14-000188:notes:10]
Following the bankruptcy, in March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us. The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which difference the Trustee estimated to exceed $50.0 million. The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.

[0001045810-14-000188:notes:11]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process, and because the Trustee's case remains pending on appeal, we have not reversed the $30.6 million accrual - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx - that we recorded during the three months ended October 30, 2005.

[0001045810-14-000188:notes:12]
In March 2007, a trial was held regarding certain valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.” This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending. On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment. That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008. The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.

[0001045810-14-000188:notes:13]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. Oral argument on the appeal was held on October 8, 2014.  On November 6, 2014, the Ninth Circuit affirmed the District Court’s decision upholding the ruling of the Bankruptcy Court. The Trustee has until November 20, 2014 to seek a rehearing.

[0001045810-14-000188:notes:14]
Securities Cases

[0001045810-14-000188:notes:15]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934.

[0001045810-14-000188:notes:16]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014.  On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal.  On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal.  Plaintiffs’ request was denied on November 10, 2014. Plaintiffs have until February 9, 2015 to file a petition for writ of certiorari to the United States Supreme Court.

[0001045810-14-000188:notes:17]
Patent Infringement Cases

[0001045810-14-000188:notes:18]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing.  In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures.  On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway.

[0001045810-14-000188:notes:19]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement.  On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action. The court granted the motion to stay on October 23, 2014.

[0001045810-14-000188:notes:20]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. The complaint alleges that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA has not yet responded to the complaint.

[0001045810-14-000188:notes:21]
Accounting for Loss Contingencies

[0001045810-14-000188:notes:22]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. With the exception of the 3dfx case, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-14-000188:notes:23]
[same as prior period, unchanged from 0001045810-14-000158:notes:20]

[0001045810-14-000188:notes:24]
[same as prior period, unchanged from 0001045810-14-000158:notes:21]


## us-gaap:DebtDisclosureTextBlock

[0001045810-14-000188:notes:25]
Long-Term Debt

[0001045810-14-000188:notes:26]
1.00 % Convertible Senior Notes Due 2018

[0001045810-14-000188:notes:27]
On December 2, 2013, we issued $1.50 billion of 1.00% convertible senior notes due 2018, or the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-14-000188:notes:28]
Holders may convert their notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter commencing after the fiscal quarter ended on  April 27, 2014 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their notes regardless of the foregoing conditions. Upon conversion, we will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0001045810-14-000188:notes:29]
As of October 26, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

[0001045810-14-000188:notes:30]
In accordance with ASC 470-20 Debt with Conversion and Other Options, all cash-settled convertible debt should be separated into debt and equity components at issuance and be assigned a fair value.   The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-14-000188:notes:31]
The initial debt component of the Notes was valued at $1,351.8 million based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $125.7 million and recorded as a debt discount. This amount, together with the $22.5 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $148.2 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-14-000188:notes:32]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-14-000188:notes:33]
|  |  | October 26, |  | January 26, |
|  |  | 2014 |  | 2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (122,741 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,377,259 |  |  | $ | 1,356,375 |  |

[0001045810-14-000188:notes:34]
(1)   As of October 26, 2014, the unamortized debt discount will be amortized over a remaining period of 4.1 years.

[0001045810-14-000188:notes:35]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-14-000188:notes:36]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 11,250 |  |  | $ | — |  |
| Amortization of debt discount |  | 7,010 |  |  | — |  |  | 20,884 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 146 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,809 |  |  | $ | — |  |  | $ | 32,280 |  |  | $ | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-14-000188:notes:37]
[same as prior period, unchanged from 0001045810-14-000158:notes:34]

[0001045810-14-000188:notes:38]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units, or PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-14-000188:notes:39]
We estimate the fair value of employee stock options on the date of grant using a binomial model and recognize the expense using a straight-line attribution method over the requisite employee service period. We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of RSUs and PSUs. The compensation expense for the RSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model.  We estimate the fair value of shares to be issued under our ESPP using the Black-Scholes model at the commencement of an offering period in March and September of each year.  Stock-based compensation for our employee stock purchase plan is expensed using an accelerated amortization model.

[0001045810-14-000188:notes:40]
[same as prior period, unchanged from 0001045810-14-000158:notes:37]

[0001045810-14-000188:notes:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, 2014 |  | October 27, 2013 |  | October 26, 2014 |  | October 27, 2013 |
|  | (In thousands) |
| Cost of revenue | $ | 3,021 |  |  | $ | 3,090 |  |  | $ | 8,596 |  |  | $ | 7,911 |  |
| Research and development | 22,680 |  |  | 20,902 |  |  | 64,636 |  |  | 61,392 |  |
| Sales, general and administrative | 15,734 |  |  | 10,307 |  |  | 42,139 |  |  | 30,788 |  |
| Total | $ | 41,435 |  |  | $ | 34,299 |  |  | $ | 115,371 |  |  | $ | 100,091 |  |

[0001045810-14-000188:notes:42]
[same as prior period, unchanged from 0001045810-14-000158:notes:45]

[0001045810-14-000188:notes:43]
[same as prior period, unchanged from 0001045810-14-000158:notes:46]

[0001045810-14-000188:notes:44]
|  | Options Outstanding |  | Weighted Average Exercise Price |
| Stock Options | (In thousands) |  | (Per share) |
| Balances, January 26, 2014 | 32,504 |  |  | $14.22 |
| Granted | 86 |  |  | $18.66 |
| Exercised | (7,945 | ) |  | $12.59 |
| Cancelled | (1,361 | ) |  | $19.49 |
| Balances, October 26, 2014 | 23,284 |  |  | $14.48 |

[0001045810-14-000188:notes:45]
|  | RSUs and PSUs Outstanding |  | Weighted Average Grant-Date Fair Value |
| RSUs and PSUs | (In thousands) |  | (Per share) |
| Balances, January 26, 2014 | 18,852 |  |  | $13.82 |
| Granted (1) | 12,506 |  |  | $17.63 |
| Vested | (7,138 | ) |  | $13.75 |
| Cancelled | (1,089 | ) |  | $14.21 |
| Balances, October 26, 2014 | 23,131 |  |  | $15.88 |

[0001045810-14-000188:notes:46]
(1)    Includes the total number of PSUs issuable if the maximum corporate financial performance target level for fiscal year 2015 is achieved. Depending on the actual level of achievement of the corporate performance goal at the end of fiscal year 2015, the range of PSUs issued could be from 1.3 million to 2.5 million shares. The PSUs were granted during the first quarter of fiscal year 2015 to our CEO and senior management as approved by our Compensation Committee.

[0001045810-14-000188:notes:47]
Of the total grant-date fair value, we estimated the stock-based compensation expense related to the stock options, RSUs and PSUs that were not expected to vest was $35.2 million for the nine months ended October 26, 2014.  As of October 26, 2014 and January 26, 2014, the aggregate amount of unearned stock-based compensation expense related to our stock options, RSUs and PSUs was $322.6 million and $241.3 million, respectively, adjusted for estimated forfeitures.  As of October 26, 2014 and January 26, 2014, we expected to recognize the unearned stock-based compensation expense related to stock options over an estimated weighted average amortization period of 2.0 years and 2.5 years, respectively. As of October 26, 2014 and January 26, 2014, we expected to recognize the unearned stock-based compensation expense related to RSUs and PSUs over an estimated weighted average amortization period of 3.0 years and 2.7 years, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-14-000188:notes:48]
[same as prior period, unchanged from 0001045810-14-000158:notes:50]

[0001045810-14-000188:notes:49]
[same as prior period, unchanged from 0001045810-14-000158:notes:51]

[0001045810-14-000188:notes:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 172,967 |  |  | $ | 118,734 |  |  | $ | 437,459 |  |  | $ | 293,073 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 547,789 |  |  | 580,870 |  |  | 555,035 |  |  | 594,363 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Equity awards outstanding | 10,412 |  |  | 7,882 |  |  | 10,618 |  |  | 5,745 |  |
| Denominator for diluted net income per share, weighted average shares | 558,201 |  |  | 588,752 |  |  | 565,653 |  |  | 600,108 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic net income per share | $ | 0.32 |  |  | $ | 0.20 |  |  | $ | 0.79 |  |  | $ | 0.49 |  |
| Diluted net income per share | $ | 0.31 |  |  | $ | 0.20 |  |  | $ | 0.77 |  |  | $ | 0.49 |  |
| Potentially dilutive securities excluded from diluted net income per share because their effect would have been anti-dilutive | 11,324 |  |  | 21,870 |  |  | 16,155 |  |  | 27,351 |  |

[0001045810-14-000188:notes:51]
The denominator for diluted net income per share for the three and nine months ended October 26, 2014 did not include any effect from the 1.00% Convertible Senior Notes due 2018, or the Notes. The calculation of the dilution impact is based on the treasury stock method in accordance with Accounting Standards Codification, or ASC 260, Earnings per Share. Commencing after the fiscal quarter ended on April 27, 2014, the Notes will not impact the denominator for diluted net income per share unless the average price of our common stock, as calculated under the terms of the Notes, exceeds the conversion price of $20.16 per share. Likewise, the denominator for diluted net income per share will not include any effect from the warrants that were issued simultaneously with the Notes unless the average price of our common stock, as calculated under the terms of the warrants, exceeds $27.14 per share. Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Notes.

[0001045810-14-000188:notes:52]
The denominator for diluted net income per share for the three and nine months ended October 26, 2014 also did not include any effect from the note hedges that were issued simultaneously with the Notes. In future periods, the denominator for diluted net income per share will exclude any effect of the note hedges, unless in the event an actual conversion of any or all of the Notes occurs, the shares that would be delivered to us under the note hedges are designed to neutralize the dilutive effect of the shares that we would issue under the Notes.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001045810-14-000188:notes:53]
|  |  |  | Fair Value Measurement as of October 26, 2014 Using |
|  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |
|  | October 26, 2014 |  | (Level 1) |  | (Level 2) |
|  | (In thousands) |
| Corporate debt securities (1) | $ | 1,957,060 |  |  | $ | — |  |  | $ | 1,957,060 |  |
| Debt securities of United States government agencies (2) | 586,125 |  |  | — |  |  | 586,125 |  |
| Debt securities issued by United States Treasury (2) | 578,013 |  |  | — |  |  | 578,013 |  |
| Asset-backed securities (2) | 437,751 |  |  | — |  |  | 437,751 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (2) | 277,684 |  |  | — |  |  | 277,684 |  |
| Foreign government bonds (2) | 85,378 |  |  | — |  |  | 85,378 |  |
| Money market funds (3) | 72,881 |  |  | 72,881 |  |  | — |  |
| Total cash equivalents and marketable securities | $ | 3,994,892 |  |  | $ | 72,881 |  |  | $ | 3,922,011 |  |

[0001045810-14-000188:notes:54]
| (1) | Includes $75.9 million in cash equivalents and $1.88 billion in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-14-000188:notes:55]
| (2) | Included in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-14-000188:notes:56]
| (3) | Included in cash equivalents on the Condensed Consolidated Balance Sheet |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-14-000188:notes:57]
[same as prior period, unchanged from 0001045810-14-000158:notes:60]

[0001045810-14-000188:notes:58]
Financial assets measured at fair value

[0001045810-14-000188:notes:59]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets.  Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets.  Our available-for-sale securities are classified as having Level 2 inputs.  Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian.  We review the fair value hierarchy classification on a quarterly basis.  Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.  There were no significant transfers between Levels 1 and 2 assets for the three and nine months ended October 26, 2014.

[0001045810-14-000188:notes:60]
[same as prior period, unchanged from 0001045810-14-000158:notes:63]

[0001045810-14-000188:notes:61]
| (3) | Included in cash equivalents on the Condensed Consolidated Balance Sheets. |

[0001045810-14-000188:notes:62]
Financial liabilities measured at fair value

[0001045810-14-000188:notes:63]
We issued $1.50 billion Convertible Senior Notes, or Notes, in December 2013. The Notes are carried at their original issuance value, net of unamortized debt discount, and are not marked to market each period. The estimated fair value of the Notes was $1.70 billion and $1.53 billion as of October 26, 2014 and January 26, 2014, respectively.  The estimated fair value of the Notes was determined on the basis of market prices observable for similar instruments and is considered Level 2 in the fair value hierarchy.  Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the Notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-14-000188:notes:64]
[same as prior period, unchanged from 0001045810-14-000158:notes:67]

[0001045810-14-000188:notes:65]
We recognized income tax expense of $36.1 million and $89.5 million for the three and nine months ended October 26, 2014, respectively, and $22.8 million and $48.3 million for the three and nine months ended October 27, 2013, respectively.  Income tax expense as a percentage of income before taxes, or our effective tax rate, was 17.3% and 17.0% for the three and nine months ended October 26, 2014, respectively, and 16.1% and 14.2% for the three and nine months ended October 27, 2013, respectively.

[0001045810-14-000188:notes:66]
The increase in our effective tax rate in fiscal year 2015 as compared to the same period in the prior fiscal year was primarily related to the expiration of the U.S. federal research tax credit on December 31, 2013 which resulted in no tax benefit in the nine months ended October 26, 2014.

[0001045810-14-000188:notes:67]
Our effective tax rate on income before tax for the first nine months of fiscal year 2015 of 17.0% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate.  Further, our effective tax rate for the first nine months of fiscal year 2015 of 17.0% differs from our annual projected effective tax rate for the first nine months of fiscal year 2015 of 18.5% due to discrete events that occurred in the first nine months of fiscal year 2015 primarily attributable to the tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-14-000188:notes:68]
Our effective tax rate on income before tax for the first nine months of fiscal year 2014 of 14.2% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax and the benefit of the U.S. federal research tax credit.

[0001045810-14-000188:notes:69]
For the nine months ended October 26, 2014, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions.  Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 26, 2014, other than the recognition of tax benefits upon the expiration of statute of limitation in certain non-U.S. jurisdictions in the nine months ended October 26, 2014.

[0001045810-14-000188:notes:70]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where it is believed not more-likely-than-not that the position will be sustained upon examination, amounts asserted by tax authorities could be greater or less than our accrued position.  Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.  As of October 26, 2014, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-14-000188:notes:71]
[same as prior period, unchanged from 0001045810-14-000158:notes:74]

[0001045810-14-000188:notes:72]
[same as prior period, unchanged from 0001045810-14-000158:notes:75]

[0001045810-14-000188:notes:73]
|  | October 26, 2014 |  | January 26, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | Accumulated Amortization |  | Net CarryingAmount |
|  | (In thousands) |
| Acquisition-related intangible assets | $ | 189,239 |  |  | $ | (129,073 | ) |  | $ | 60,166 |  |  | $ | 189,239 |  |  | $ | (114,104 | ) |  | $ | 75,135 |  |
| Patents and licensed technology | 449,204 |  |  | (268,069 | ) |  | 181,135 |  |  | 446,196 |  |  | (225,319 | ) |  | 220,877 |  |
| Total intangible assets | $ | 638,443 |  |  | $ | (397,142 | ) |  | $ | 241,301 |  |  | $ | 635,435 |  |  | $ | (339,423 | ) |  | $ | 296,012 |  |

[0001045810-14-000188:notes:74]
Amortization expense associated with intangible assets for the three and nine months ended October 26, 2014 was $19.3 million and $57.7 million, respectively.  Amortization expense associated with intangible assets for the three and nine months ended October 27, 2013 was $19.6 million and $55.6 million, respectively.  Future amortization expense related to the net carrying amount of intangible assets at October 26, 2014 is estimated to be $19.3 million for the remainder of fiscal year 2015, $71.9 million in fiscal year 2016, $63.8 million in fiscal year 2017, $49.1 million in fiscal year 2018, $20.5 million in fiscal year 2019 and a total of $16.7 million in fiscal year 2020 and beyond.


## us-gaap:InventoryDisclosureTextBlock

[0001045810-14-000188:notes:75]
|  | October 26, |  | January 26, |
|  | 2014 |  | 2014 |
| Inventories: | (In thousands) |
| Raw materials | $ | 128,588 |  |  | $ | 126,896 |  |
| Work in-process | 78,849 |  |  | 94,844 |  |
| Finished goods | 200,644 |  |  | 166,025 |  |
| Total inventories | $ | 408,081 |  |  | $ | 387,765 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-14-000188:notes:76]
|  | October 26, 2014 |  | January 26, 2014 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In thousands) |
| Less than 1 year | $ | 1,378,709 |  |  | $ | 1,379,705 |  |  | $ | 1,883,132 |  |  | $ | 1,883,753 |  |
| Due in 1 - 5 years | 2,490,537 |  |  | 2,497,644 |  |  | 2,114,289 |  |  | 2,117,387 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 115,238 |  |  | 117,543 |  |  | 90,472 |  |  | 91,508 |  |
| Total | $ | 3,984,484 |  |  | $ | 3,994,892 |  |  | $ | 4,087,893 |  |  | $ | 4,092,648 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-14-000188:notes:77]
[same as prior period, unchanged from 0001045810-14-000158:notes:80]

[0001045810-14-000188:notes:78]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value, with the related unrealized gains and losses included in accumulated other comprehensive income, a component of stockholders’ equity, net of tax, and net realized gains and losses recorded in other income, net, on the Condensed Consolidated Statements of Income.

[0001045810-14-000188:notes:79]
We performed an impairment review of our investment portfolio as of October 26, 2014. Based on our quarterly impairment review and having considered the guidance in the relevant accounting literature, we concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio as of October 26, 2014.

[0001045810-14-000188:notes:80]
The following is a summary of cash equivalents and marketable securities at October 26, 2014 and January 26, 2014:

[0001045810-14-000188:notes:81]
The following table provides the breakdown of the investments with unrealized losses at October 26, 2014:

[0001045810-14-000188:notes:82]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In thousands) |
| Corporate debt securities | $ | 698,851 |  |  | $ | (83 | ) |  | $ | 1,258,209 |  |  | $ | (437 | ) |  | $ | 1,957,060 |  |  | $ | (520 | ) |
| Debt securities of United States government agencies | 278,703 |  |  | (8 | ) |  | 307,422 |  |  | (45 | ) |  | 586,125 |  |  | (53 | ) |
| Debt securities issued by United States Treasury | 71,564 |  |  | (66 | ) |  | 506,449 |  |  | — |  |  | 578,013 |  |  | (66 | ) |
| Asset-backed securities | 224,100 |  |  | (27 | ) |  | 213,651 |  |  | (173 | ) |  | 437,751 |  |  | (200 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | — |  |  | — |  |  | 277,684 |  |  | (717 | ) |  | 277,684 |  |  | (717 | ) |
| Foreign government bonds | 33,606 |  |  | — |  |  | 51,772 |  |  | (16 | ) |  | 85,378 |  |  | (16 | ) |
| Total | $ | 1,306,824 |  |  | $ | (184 | ) |  | $ | 2,615,187 |  |  | $ | (1,388 | ) |  | $ | 3,922,011 |  |  | $ | (1,572 | ) |

[0001045810-14-000188:notes:83]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at October 26, 2014 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-14-000188:notes:84]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale at October 26, 2014 and January 26, 2014 and are shown below by contractual maturity.

[0001045810-14-000188:notes:85]
Net realized gains and losses for the three and nine months ended October 26, 2014, and for the three months ended October 27, 2013, were not significant. Net realized gains for the nine months ended October 27, 2013 were $1.8 million.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001045810-14-000188:notes:86]
[same as prior period, unchanged from 0001045810-14-000158:notes:89]

[0001045810-14-000188:notes:87]
[same as prior period, unchanged from 0001045810-14-000158:notes:90]

[0001045810-14-000188:notes:88]
Significant Accounting Policies

[0001045810-14-000188:notes:89]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001045810-14-000188:notes:90]
|  | October 26, |  | January 26, |
|  | 2014 |  | 2014 |
| Other Long-Term Liabilities: | (In thousands) |
| Deferred income tax liability | $ | 210,388 |  |  | $ | 157,953 |  |
| Income taxes payable, long-term | 122,854 |  |  | 119,977 |  |
| Deferred revenue, long-term (1) | — |  |  | 172,199 |  |
| Asset retirement obligation | 7,406 |  |  | 11,056 |  |
| Other | 14,485 |  |  | 13,940 |  |
| Total other long-term liabilities | $ | 355,133 |  |  | $ | 475,125 |  |

[0001045810-14-000188:notes:91]
(1)    Consists primarily of annual consideration received in advance of our performance obligation under our patent cross licensing agreement with Intel Corporation entered into in January 2011. The decrease in deferred revenue, long-term, is a result of revenue recognized during the nine months ended October 26, 2014.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-14-000188:notes:92]
[same as prior period, unchanged from 0001045810-14-000158:notes:93]

[0001045810-14-000188:notes:93]
[same as prior period, unchanged from 0001045810-14-000158:notes:94]

[0001045810-14-000188:notes:94]
[same as prior period, unchanged from 0001045810-14-000158:notes:95]

[0001045810-14-000188:notes:95]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties.  Under limited circumstances, we may offer an extended limited warranty to customers for certain products.  Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product warranty liabilities for the three and nine months ended October 26, 2014 and October 27, 2013 were as follows:

[0001045810-14-000188:notes:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands) |
| Balance at beginning of period | $ | 8,202 |  |  | $ | 17,474 |  |  | $ | 7,571 |  |  | $ | 14,874 |  |
| Additions | 988 |  |  | 1,143 |  |  | 4,177 |  |  | 6,043 |  |
| Deductions | (1,968 | ) |  | (2,655 | ) |  | (4,526 | ) |  | (4,955 | ) |
| Balance at end of period | $ | 7,222 |  |  | $ | 15,962 |  |  | $ | 7,222 |  |  | $ | 15,962 |  |

[0001045810-14-000188:notes:97]
[same as prior period, unchanged from 0001045810-14-000158:notes:98]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-14-000188:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, 2014 |  | October 27, 2013 |  | October 26, 2014 |  | October 27, 2013 |
|  | (In thousands) |
| Reconciling items included in "All Other" category : |  |  |  |  |  |  |
| Revenue not allocated to reporting segments | $ | 66,000 |  |  | $ | 66,000 |  |  | $ | 198,000 |  |  | $ | 198,000 |  |
| Unallocated corporate operating expenses | (42,676 | ) |  | (40,033 | ) |  | (127,709 | ) |  | (125,700 | ) |
| Stock-based compensation | (41,435 | ) |  | (34,299 | ) |  | (115,371 | ) |  | (100,091 | ) |
| Acquisition-related costs | (9,572 | ) |  | (4,577 | ) |  | (28,186 | ) |  | (22,402 | ) |
| Other non-recurring expenses | — |  |  | (2,235 | ) |  | — |  |  | (4,525 | ) |
| Total | $ | (27,683 | ) |  | $ | (15,144 | ) |  | $ | (73,266 | ) |  | $ | (54,718 | ) |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001045810-14-000188:notes:99]
[same as prior period, unchanged from 0001045810-14-000158:notes:100]


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-14-000188:notes:100]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 405,612 |  |  | $ | 319,018 |  |  | $ | 1,109,388 |  |  | $ | 927,903 |  |
| China | 238,212 |  |  | 206,374 |  |  | 713,442 |  |  | 565,504 |  |
| United States | 215,484 |  |  | 195,529 |  |  | 594,541 |  |  | 545,303 |  |
| Other Asia Pacific | 169,793 |  |  | 174,691 |  |  | 475,442 |  |  | 507,065 |  |
| Other Americas | 100,531 |  |  | 79,382 |  |  | 275,355 |  |  | 220,920 |  |
| Europe | 95,750 |  |  | 78,973 |  |  | 262,825 |  |  | 219,249 |  |
| Total revenue | $ | 1,225,382 |  |  | $ | 1,053,967 |  |  | $ | 3,430,993 |  |  | $ | 2,985,944 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-14-000188:notes:101]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-14-000188:notes:102]
In August 2014, the Financial Accounting Standards Board, or FASB, issued new guidance related to our responsibility to evaluate whether there is substantial doubt about our ability to continue ongoing business operations and to provide relevant footnote disclosures. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The adoption of this guidance is not expected to have a material impact on our financial statements.

[0001045810-14-000188:notes:103]
In June 2014, the FASB issued new guidance related to stock-based compensation. The new guidance requires that a performance target that affects vesting, and that could be achieved after the requisite service period is rendered, be treated as a performance condition. The new guidance is effective for interim periods within and those fiscal years, beginning after December 15, 2015. We currently do not have awards with a performance target where the employee would be eligible to vest in the award regardless of whether the employee is rendering service on the date the performance target is achieved. Therefore, we believe, the adoption of this new accounting guidance will not have an impact on our consolidated financial statements.

[0001045810-14-000188:notes:104]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period.  Early adoption is not permitted.  We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-14-000188:notes:105]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In thousands) |
| Three Months Ended October 26, 2014 |  |  |  |  |  |  |  |
| Revenue | $ | 991,217 |  |  | $ | 168,165 |  |  | $ | 66,000 |  |  | $ | 1,225,382 |  |
| Depreciation and amortization expense | $ | 29,175 |  |  | $ | 14,665 |  |  | $ | 11,640 |  |  | $ | 55,480 |  |
| Operating income (loss) | $ | 294,289 |  |  | $ | (53,291 | ) |  | $ | (27,683 | ) |  | $ | 213,315 |  |
| Three Months Ended October 27, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 876,833 |  |  | $ | 111,134 |  |  | $ | 66,000 |  |  | $ | 1,053,967 |  |
| Depreciation and amortization expense | $ | 38,677 |  |  | $ | 13,164 |  |  | $ | 10,885 |  |  | $ | 62,726 |  |
| Operating income (loss) | $ | 220,351 |  |  | $ | (64,219 | ) |  | $ | (15,144 | ) |  | $ | 140,988 |  |
| Nine Months Ended October 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,766,560 |  |  | $ | 466,433 |  |  | $ | 198,000 |  |  | $ | 3,430,993 |  |
| Depreciation and amortization expense | $ | 88,193 |  |  | $ | 43,395 |  |  | $ | 34,582 |  |  | $ | 166,170 |  |
| Operating income (loss) | $ | 770,393 |  |  | $ | (169,274 | ) |  | $ | (73,266 | ) |  | $ | 527,853 |  |
| Nine Months Ended October 27, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,521,058 |  |  | $ | 266,886 |  |  | $ | 198,000 |  |  | $ | 2,985,944 |  |
| Depreciation and amortization expense | $ | 116,389 |  |  | $ | 36,479 |  |  | $ | 31,442 |  |  | $ | 184,310 |  |
| Operating income (loss) | $ | 586,791 |  |  | $ | (202,770 | ) |  | $ | (54,718 | ) |  | $ | 329,303 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-14-000188:notes:106]
[same as prior period, unchanged from 0001045810-14-000158:notes:107]

[0001045810-14-000188:notes:107]
[same as prior period, unchanged from 0001045810-14-000158:notes:108]

[0001045810-14-000188:notes:108]
[same as prior period, unchanged from 0001045810-14-000158:notes:109]

[0001045810-14-000188:notes:109]
[same as prior period, unchanged from 0001045810-14-000158:notes:110]

[0001045810-14-000188:notes:110]
[same as prior period, unchanged from 0001045810-14-000158:notes:111]

[0001045810-14-000188:notes:111]
[same as prior period, unchanged from 0001045810-14-000158:notes:112]

[0001045810-14-000188:notes:112]
[same as prior period, unchanged from 0001045810-14-000158:notes:113]

[0001045810-14-000188:notes:113]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on invoicing address in different geographic regions:

[0001045810-14-000188:notes:114]
The following table summarizes information pertaining to our revenue from significant customers, those representing 10% or more of total revenue for the respective dates:

[0001045810-14-000188:notes:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenue: |  |  |  |  |  |  |  |
| Customer A | 10 | % |  | 9 | % |  | 10 | % |  | 10 | % |
| Customer B | 8 | % |  | 11 | % |  | 9 | % |  | 11 | % |

[0001045810-14-000188:notes:116]
Revenue from Customer A was attributable primarily to the GPU business for the three and nine months ended October 26, 2014 and to both the GPU and Tegra Processor businesses for the three and nine months ended October 27, 2013.  Revenue from Customer B was attributable to the GPU business for all comparative periods presented.

[0001045810-14-000188:notes:117]
The following table summarizes information pertaining to our accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods:

[0001045810-14-000188:notes:118]
|  | October 26, 2014 |  | January 26, 2014 |
| Accounts Receivable: |  |  |  |
| Customer B | 17 | % |  | 23 | % |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-14-000188:notes:119]
[same as prior period, unchanged from 0001045810-14-000158:notes:120]

[0001045810-14-000188:notes:120]
[same as prior period, unchanged from 0001045810-14-000158:notes:121]

[0001045810-14-000188:notes:121]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The third quarters of fiscal years 2015 and 2014 are both 13-week quarters.

[0001045810-14-000188:notes:122]
[same as prior period, unchanged from 0001045810-14-000158:notes:123]

[0001045810-14-000188:notes:123]
[same as prior period, unchanged from 0001045810-14-000158:notes:124]

[0001045810-14-000188:notes:124]
[same as prior period, unchanged from 0001045810-14-000158:notes:125]

[0001045810-14-000188:notes:125]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-14-000188:notes:126]
[same as prior period, unchanged from 0001045810-14-000158:notes:127]

[0001045810-14-000188:notes:127]
[same as prior period, unchanged from 0001045810-14-000158:notes:128]

[0001045810-14-000188:notes:128]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. In November 2013, the Board extended the previously authorized repurchase program through January 2016 and authorized an additional $1.00 billion for an aggregate of $3.70 billion under the repurchase program. Through October 26, 2014, we have repurchased an aggregate of 205.4 million shares under our stock repurchase program for a total cost of $3.26 billion.  As of October 26, 2014, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $438.4 million through January 2016.

[0001045810-14-000188:notes:129]
The repurchases will be made in the open market, in privately negotiated transactions, or in structured stock repurchase programs, in compliance with Rule 10b-18 of the Exchange Act, subject to market conditions, applicable legal requirements, and other factors. The program does not obligate NVIDIA to acquire any particular amount of common stock and the program may be suspended at any time at our discretion. As part of our share repurchase program, we have entered into, and we may continue to enter into, structured share repurchase transactions. These agreements generally require that we make an up-front payment in exchange for the right to receive a fixed number of shares of our common stock upon execution of the agreement, and a potential incremental number of shares of our common stock, within a pre-determined range, at the end of the term of the agreement.

[0001045810-14-000188:notes:130]
In November 2013, we announced the intention to return $1.00 billion to shareholders in fiscal year 2015 in the form of share repurchases and cash dividends. In February 2014, we executed an accelerated share repurchase, or ASR, agreement for $500.0 million that was completed in July 2014. Under this ASR, we repurchased 27.4 million shares in aggregate at an average price of $18.23 per share. In August 2014, we executed another ASR for $310.0 million that was completed in October 2014. Under this ASR, we repurchased 16.8 million shares in aggregate at an average price of $18.47 per share. The shares delivered under these ASRs resulted in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share. As of October 26, 2014, all shares delivered from these ASRs have been placed into treasury stock.

[0001045810-14-000188:notes:131]
Cash Dividends

[0001045810-14-000188:notes:132]
During the three and nine months ended October 26, 2014, we paid $46.1 million and $140.2 million, respectively, in cash dividends to our common shareholders. These dividends were equivalent to $0.085 per share on a quarterly basis, or $0.34 per share on an annual basis.

[0001045810-14-000188:notes:133]
[same as prior period, unchanged from 0001045810-14-000158:notes:134]

[0001045810-14-000188:notes:134]
[same as prior period, unchanged from 0001045810-14-000158:notes:135]

[0001045810-14-000188:notes:135]
[same as prior period, unchanged from 0001045810-14-000158:notes:136]

[0001045810-14-000188:notes:136]
[same as prior period, unchanged from 0001045810-14-000158:notes:137]


## nvda:AssetPurchaseDisclosureTextBlock

[0001045810-14-000188:notes:137]
[same as prior period, unchanged from 0001045810-14-000158:notes:140]

[0001045810-14-000188:notes:138]
[same as prior period, unchanged from 0001045810-14-000158:notes:141]

[0001045810-14-000188:notes:139]
The conditional settlement reached in November 2005 never progressed through the confirmation process and the Trustee’s case still remains pending appeal. As such, we have not reversed the accrual of $30.6 million - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx – that we recorded during the three months ended October 30, 2005, pending resolution of the appeal of the Trustee’s case.

[0001045810-14-000188:notes:140]
The 3dfx asset purchase price of $95.0 million and $4.2 million of direct transaction costs were allocated based on fair values presented below. The final allocation of the purchase price of the 3dfx assets is contingent upon the outcome of all of the 3dfx litigation. Please refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for further information regarding this litigation.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-14-000188:notes:141]
[same as prior period, unchanged from 0001045810-14-000158:notes:144]

[0001045810-14-000188:notes:142]
[same as prior period, unchanged from 0001045810-14-000158:notes:145]

[0001045810-14-000188:notes:143]
At October 26, 2014, we had outstanding inventory purchase obligations totaling $512.2 million.
