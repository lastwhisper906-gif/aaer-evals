# NVDA MD&A — 0001045810-17-000123


## mdna

[0001045810-17-000123:mdna:1]
[same as prior period, unchanged from 0001045810-17-000075:mdna:1]

[0001045810-17-000123:mdna:2]
[same as prior period, unchanged from 0001045810-17-000075:mdna:2]

[0001045810-17-000123:mdna:3]
[same as prior period, unchanged from 0001045810-17-000075:mdna:3]

[0001045810-17-000123:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, Jetson, NVIDIA DGX, NVIDIA DRIVE, NVIDIA GRID, NVIDIA VRWorks, OptiX, and Pascal are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. MAXQ® is the registered trademark of Maxim Integrated Products, Inc. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-17-000123:mdna:5]
[same as prior period, unchanged from 0001045810-17-000075:mdna:5]

[0001045810-17-000123:mdna:6]
[same as prior period, unchanged from 0001045810-17-000075:mdna:6]

[0001045810-17-000123:mdna:7]
[same as prior period, unchanged from 0001045810-17-000075:mdna:7]

[0001045810-17-000123:mdna:8]
[same as prior period, unchanged from 0001045810-17-000075:mdna:8]

[0001045810-17-000123:mdna:9]
[same as prior period, unchanged from 0001045810-17-000075:mdna:9]

[0001045810-17-000123:mdna:10]
[same as prior period, unchanged from 0001045810-17-000075:mdna:10]

[0001045810-17-000123:mdna:11]
[same as prior period, unchanged from 0001045810-17-000075:mdna:11]

[0001045810-17-000123:mdna:12]
[same as prior period, unchanged from 0001045810-17-000075:mdna:12]

[0001045810-17-000123:mdna:13]
Second Quarter of Fiscal Year 2018 Summary

[0001045810-17-000123:mdna:14]
|  | Three Months Ended |  |  |  |  |
|  | July 30, 2017 |  | April 30, 2017 |  | July 31, 2016 |  | Q/Q |  | Y/Y |
|  | ($ in millions, except per share data) |
| Revenue | $ | 2,230 |  |  | $ | 1,937 |  |  | $ | 1,428 |  |  | 15 | % |  | 56 | % |
| Gross margin | 58.4 | % |  | 59.4 | % |  | 57.9 | % |  | (100) bps |  |  | 50 bps |  |
| Operating expenses | $ | 614 |  |  | $ | 596 |  |  | $ | 509 |  |  | 3 | % |  | 21 | % |
| Income from operations | $ | 688 |  |  | $ | 554 |  |  | $ | 317 |  |  | 24 | % |  | 117 | % |
| Net income | $ | 583 |  |  | $ | 507 |  |  | $ | 261 |  |  | 15 | % |  | 123 | % |
| Net income per diluted share | $ | 0.92 |  |  | $ | 0.79 |  |  | $ | 0.41 |  |  | 16 | % |  | 124 | % |

[0001045810-17-000123:mdna:15]
Revenue for the second quarter of fiscal year 2018 increased 56% year over year and 15% sequentially. Growth was driven by GPUs for gaming, datacenter, and professional visualization, as well as Tegra processors.

[0001045810-17-000123:mdna:16]
GPU business revenue was $1.90 billion, up 59% from a year earlier and up 21% sequentially, led by strength across all platforms, including datacenter, gaming, and professional visualization, along with PC OEM sales. GeForce GPU gaming results were led by continued strong adoption of Pascal-based GeForce GTX gaming platforms. Datacenter revenue (including Tesla, NVIDIA GRID and DGX) was $416 million, up 175% year on year and up 2% sequentially. Datacenter revenue reflects initial shipments of our newest Volta GPU architecture and V100 platform. Datacenter growth was fueled by strong demand by hyperscale and cloud customers for deep learning training and accelerated GPU computing, as well as demand for HPC, DGX AI supercomputing and GRID virtualization platforms. Professional visualization revenue grew 10% year over year and up 15% sequentially to $235 million, led by high-end mobile platforms. Our PC OEM revenue includes GPUs designed for mainstream desktops, notebooks, and cryptocurrency mining. The recent rise in cryptocurrency prices resulted in increased demand in OEM GPU sales.

[0001045810-17-000123:mdna:17]
Tegra processor business revenue, which included gaming development platforms and services, was $333 million, up 101% from a year ago and flat sequentially. Tegra processor business revenue includes system-on-a-chip (SOCs) modules for the Nintendo Switch gaming console and development services. Also included was automotive revenue of $142 million, which was up 19% from a year earlier and up 1% sequentially, incorporating infotainment modules, production DRIVE PX platforms, and development agreements for self-driving cars.

[0001045810-17-000123:mdna:18]
24

[0001045810-17-000123:mdna:19]
Revenue from our patent license agreement with Intel concluded in the first quarter of fiscal year 2018, when it was $43 million.

[0001045810-17-000123:mdna:20]
Gross margin for the second quarter of fiscal year 2018 was 58.4%, reflecting a sequential decrease associated with the absence of licensing revenue from Intel.

[0001045810-17-000123:mdna:21]
Operating expenses for the second quarter of fiscal year 2018 were $614 million, up 21% from a year earlier and up 3% sequentially, reflecting increased headcount and related costs for our growth initiatives - gaming, artificial intelligence, and autonomous driving.

[0001045810-17-000123:mdna:22]
Income from operations for the second quarter of fiscal year 2018 was $688 million, up 117% from a year earlier and up 24% sequentially. Net income and net income per diluted share for the second quarter of fiscal year 2018 were $583 million and $0.92, respectively, up 123% and 124%, respectively, from a year earlier, fueled by strong revenue growth and improved gross and operating margins.

[0001045810-17-000123:mdna:23]
During the first half of fiscal year 2018, we paid $758 million in share repurchases and $166 million in cash dividends. For fiscal year 2018, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-17-000123:mdna:24]
Cash, cash equivalents and marketable securities were $5.88 billion as of July 30, 2017, compared with $6.21 billion at the end of the prior quarter. The sequential decrease was primarily related to share repurchases made under our capital return program.

[0001045810-17-000123:mdna:25]
[same as prior period, unchanged from 0001045810-17-000075:mdna:21]

[0001045810-17-000123:mdna:26]
During the second quarter of fiscal year 2018, we introduced Max-Q, a design approach to make gaming laptops thinner, quieter, and faster. For our datacenter platform, we announced and began shipping NVIDIA Tesla V100 GPU accelerators, the first GPU based on the new Volta architecture; unveiled a new lineup of NVIDIA DGX AI supercomputers; and disclosed that the world’s 13 most energy-efficient supercomputers on the Green 500 list run on NVIDIA Tesla accelerators. For our professional visualization platform, we introduced Project Holodeck, a photorealistic, collaborative VR environment; launched external GPU support for creative professionals; and released the NVIDIA Optix 5.0 and NVIDIA VRWorks 360 Video software development kits.

[0001045810-17-000123:mdna:27]
[same as prior period, unchanged from 0001045810-17-000075:mdna:22]

[0001045810-17-000123:mdna:28]
[same as prior period, unchanged from 0001045810-17-000075:mdna:24]

[0001045810-17-000123:mdna:29]
During the second quarter of fiscal year 2018, we announced that Toyota selected NVIDIA DRIVE PX for its next-generation autonomous cars; Volvo and Autoliv selected DRIVE PX for self-driving cars targeted to hit the market by 2021; ZF and HELLA, two leading automotive suppliers, announced a system based on DRIVE PX to deliver the highest NCAP safety ratings for cars; and Baidu announced that its Project Apollo open-source self-driving platform for the China market will use DRIVE PX. We also introduced the NVIDIA Isaac robot simulator for training intelligent machines in simulated real-world conditions before deployment; and announced the NVIDIA Metropolis platform, used by more than 50 partners to make cities safer and smarter by applying deep learning to surveillance video streams.

[0001045810-17-000123:mdna:30]
During the first quarter of fiscal year 2018, we announced with Bosch, one of the world’s largest auto suppliers, plans to create a new Bosch-branded AI self-driving car computer. We also announced a collaboration with PACCAR, one of the world's largest truck makers with brands including Peterbilt, Kenworth and DAF, to develop solutions for autonomous trucks. We also announced NVIDIA Jetson TX2, a high-performance, low-power computer platform for delivering AI at the edge, with deep learning and computer vision capabilities for robots, drones and smart cameras.

[0001045810-17-000123:mdna:31]
25

[0001045810-17-000123:mdna:32]
[same as prior period, unchanged from 0001045810-17-000075:mdna:26]

[0001045810-17-000123:mdna:33]
[same as prior period, unchanged from 0001045810-17-000075:mdna:27]

[0001045810-17-000123:mdna:34]
[same as prior period, unchanged from 0001045810-17-000075:mdna:28]

[0001045810-17-000123:mdna:35]
[same as prior period, unchanged from 0001045810-17-000075:mdna:29]

[0001045810-17-000123:mdna:36]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |  | July 30, 2017 |  | July 31, 2016 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 41.6 |  |  | 42.1 |  |  | 41.2 |  |  | 42.3 |  |
| Gross profit | 58.4 |  |  | 57.9 |  |  | 58.8 |  |  | 57.7 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 18.7 |  |  | 24.5 |  |  | 19.8 |  |  | 25.5 |  |
| Sales, general and administrative | 8.9 |  |  | 11.0 |  |  | 9.2 |  |  | 11.6 |  |
| Restructuring and other charges | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Total operating expenses | 27.6 |  |  | 35.6 |  |  | 29.0 |  |  | 37.2 |  |
| Income from operations | 30.9 |  |  | 22.2 |  |  | 29.8 |  |  | 20.5 |  |
| Interest income | 0.7 |  |  | 0.8 |  |  | 0.7 |  |  | 0.8 |  |
| Interest expense | (0.7 | ) |  | (0.8 | ) |  | (0.7 | ) |  | (0.8 | ) |
| Other, net | (0.2 | ) |  | — |  |  | (0.5 | ) |  | (0.1 | ) |
| Total other income (expense) | (0.2 | ) |  | — |  |  | (0.5 | ) |  | (0.1 | ) |
| Income before income tax expense | 30.7 |  |  | 22.2 |  |  | 29.3 |  |  | 20.4 |  |
| Income tax expense | 4.5 |  |  | 3.9 |  |  | 3.1 |  |  | 3.3 |  |
| Net income | 26.2 | % |  | 18.3 | % |  | 26.2 | % |  | 17.1 | % |

[0001045810-17-000123:mdna:37]
[same as prior period, unchanged from 0001045810-17-000075:mdna:32]

[0001045810-17-000123:mdna:38]
[same as prior period, unchanged from 0001045810-17-000075:mdna:33]

[0001045810-17-000123:mdna:39]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |  | $Change |  | %Change |  | July 30, 2017 |  | July 31, 2016 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 1,897 |  |  | $ | 1,196 |  |  | $ | 701 |  |  | 59 | % |  | $ | 3,459 |  |  | $ | 2,275 |  |  | $ | 1,184 |  |  | 52 | % |
| Tegra Processor | 333 |  |  | 166 |  |  | 167 |  |  | 101 | % |  | 665 |  |  | 326 |  |  | 339 |  |  | 104 | % |
| All Other | — |  |  | 66 |  |  | (66 | ) |  | (100 | )% |  | 43 |  |  | 132 |  |  | (89 | ) |  | (67 | )% |
| Total | $ | 2,230 |  |  | $ | 1,428 |  |  | $ | 802 |  |  | 56 | % |  | $ | 4,167 |  |  | $ | 2,733 |  |  | $ | 1,434 |  |  | 52 | % |

[0001045810-17-000123:mdna:40]
[same as prior period, unchanged from 0001045810-17-000075:mdna:23]

[0001045810-17-000123:mdna:41]
GPU Business. GPU business revenue increased by 59% for the second quarter of fiscal year 2018 compared to the second quarter of fiscal year 2017. This increase was due primarily to increased revenue from sales of GeForce GPU products for gaming, which increased over 30%, reflecting continued strong demand for our Pascal-based GPU products. Datacenter revenue, including Tesla, GRID and DGX, increased 175%, reflecting strong demand for hyperscale and cloud customers for deep learning training and accelerated GPU computing as well as demand for DGX AI supercomputing and GRID virtualization platforms. Revenue from Quadro GPUs for professional visualization increased 10% due primarily to higher sales of high-end mobile workstation products. Our PC OEM revenue increased by approximately 200% due primarily to strong demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-17-000123:mdna:42]
GPU business revenue increased by 52% in the first half of fiscal year 2018 compared to the first half of fiscal year 2017. This increase was due primarily to increased revenue from sales of GeForce GPU products for gaming, which increased over 30%, reflecting continued strong demand for our Pascal-based GPU products. Datacenter revenue, including Tesla, GRID and DGX, increased 180%, reflecting strong demand for hyperscale and cloud customers for deep learning training and accelerated GPU computing as well as demand for DGX AI supercomputing and GRID virtualization platforms. Revenue from Quadro GPUs for professional visualization increased 9% due primarily to higher sales in both desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs increased by over 90% due primarily to strong demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-17-000123:mdna:43]
Tegra Processor Business. Tegra Processor business revenue increased by 101% for the second quarter of fiscal year 2018 compared to the second quarter of fiscal year 2017. This was driven by an increase of over 800% in revenue from gaming development platforms and services, and an increase of 19% in automotive revenue, primarily from infotainment modules.

[0001045810-17-000123:mdna:44]
Tegra Processor business revenue increased by 104% in the first half of fiscal year 2018 compared to the first half of fiscal year 2017. This was driven by an increase of over 850% in revenue from gaming development platforms and services, and an increase of over 20% in sales of Tegra products serving automotive systems, primarily from infotainment modules compared to last year.

[0001045810-17-000123:mdna:45]
All Other. Our patent license agreement with Intel concluded in the first quarter of fiscal year 2018. For the first half of fiscal year 2018, we recognized related revenue of $43 million, down from $132 million for the first half of fiscal year 2017.

[0001045810-17-000123:mdna:46]
[same as prior period, unchanged from 0001045810-17-000075:mdna:38]

[0001045810-17-000123:mdna:47]
Revenue from sales to customers outside of the United States and Other Americas accounted for 79% and 78% of total revenue for the second quarter and first half of fiscal year 2018, respectively. Revenue from sales to customers outside of the United States and Other Americas accounted for 78% of total revenue for both the second quarter and first half of fiscal year 2017. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-17-000123:mdna:48]
[same as prior period, unchanged from 0001045810-17-000075:mdna:40]

[0001045810-17-000123:mdna:49]
Our overall gross margin increased to 58.4% for the second quarter of fiscal year 2018 from 57.9% for the second quarter of fiscal year 2017, and increased to 58.8% for the first half of fiscal year 2018 from 57.7% for the first half of fiscal year 2017. These increases were primarily due to the growth in GPU business revenue from our Datacenter platforms, increased sales of GeForce GTX products for gaming, and improved gross margins in our Tegra Processor business. These increases were partially offset by the absence of licensing revenue from Intel.

[0001045810-17-000123:mdna:50]
Inventory provision costs totaled $13 million and $5 million for the second quarter of fiscal years 2018 and 2017, respectively, unfavorably impacting our gross margin by 0.6% and 0.3%, respectively. Sales of inventory that was previously written-off or written-down totaled $9 million and $12 million for the second quarter of fiscal years 2018 and 2017, respectively, favorably impacting our gross margin by 0.4% and 0.9%, respectively. As a result, the overall net effect on our gross margin from charges for inventory provision costs and sales of items previously written-off or written-down was a 0.2% unfavorable impact for the second quarter of fiscal year 2018 and a 0.5% favorable impact for the second quarter of fiscal year 2017.

[0001045810-17-000123:mdna:51]
Inventory provision costs totaled $16 million and $27 million for the first half of fiscal years 2018 and 2017, respectively, unfavorably impacting our gross margin by 0.4% and 1.0%, respectively. Sales of inventory that was previously written-off or written-down totaled $22 million and $20 million for the first half of fiscal years 2018 and 2017, respectively, favorably impacting our gross margin by 0.5% and 0.7%, respectively. As a result, the overall net effect on our gross margin from charges for inventory provision costs and sales of items previously written-off or written-down was a 0.2% favorable impact for the first half of fiscal year 2018 and a 0.3% unfavorable impact for the first half of fiscal year 2017.

[0001045810-17-000123:mdna:52]
[same as prior period, unchanged from 0001045810-17-000075:mdna:43]

[0001045810-17-000123:mdna:53]
GPU Business. The gross margin of our GPU business increased during the second quarter and first half of fiscal year 2018 compared to the second quarter and first half of fiscal year 2017. GPU margins increased primarily due to revenue growth in Datacenter driven by strong demand for Tesla products by hyperscale and cloud customers for deep learning training and accelerated GPU computing as well as demand for DGX AI supercomputing and GRID virtualization platforms and strong sales of our GeForce GTX gaming products.

[0001045810-17-000123:mdna:54]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the second quarter and first half of fiscal year 2018 compared to the second quarter and first half of fiscal year 2017. The increase in Tegra margins was due primarily to strong sales of Tegra products serving automotive systems.

[0001045810-17-000123:mdna:55]
[same as prior period, unchanged from 0001045810-17-000075:mdna:46]

[0001045810-17-000123:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |  | $Change |  | %Change |  | July 30, 2017 |  | July 31, 2016 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 416 |  |  | $ | 350 |  |  | $ | 66 |  |  | 19 | % |  | $ | 827 |  |  | $ | 697 |  |  | $ | 130 |  |  | 19 | % |
| Sales, general and administrative expenses | 198 |  |  | 157 |  |  | 41 |  |  | 26 | % |  | 383 |  |  | 316 |  |  | 67 |  |  | 21 | % |
| Restructuring and other charges | — |  |  | 2 |  |  | (2 | ) |  | (100 | )% |  | — |  |  | 3 |  |  | (3 | ) |  | (100 | )% |
| Total operating expenses | $ | 614 |  |  | $ | 509 |  |  | $ | 105 |  |  | 21 | % |  | $ | 1,210 |  |  | $ | 1,016 |  |  | $ | 194 |  |  | 19 | % |
| Research and development expenses as a percentage of net revenue | 19 | % |  | 25 | % |  |  |  |  |  |  |  | 20 | % |  | 26 | % |  |  |  |  |
| Sales, general and administrative expenses as a percentage of net revenue | 9 | % |  | 11 | % |  |  |  |  |  |  |  | 9 | % |  | 12 | % |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001045810-17-000123:mdna:57]
[same as prior period, unchanged from 0001045810-17-000075:mdna:48]

[0001045810-17-000123:mdna:58]
Research and development expenses increased by 19% during the second quarter and first half of fiscal year 2018 compared to the second quarter and first half of fiscal year 2017, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-17-000123:mdna:59]
[same as prior period, unchanged from 0001045810-17-000075:mdna:50]

[0001045810-17-000123:mdna:60]
Sales, general and administrative expenses increased by 26% during the second quarter of fiscal year 2018 compared to the second quarter of fiscal year 2017, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-17-000123:mdna:61]
Sales, general and administrative expenses increased by 21% during the first half of fiscal year 2018 compared to the first half of fiscal year 2017, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense. Offsetting these increases was a decrease in outside professional fees of $11 million resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-17-000123:mdna:62]
[same as prior period, unchanged from 0001045810-17-000075:mdna:52]

[0001045810-17-000123:mdna:63]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera operations. No restructuring charges were recorded during the second quarter and first half of fiscal year 2018. Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-17-000123:mdna:64]
[same as prior period, unchanged from 0001045810-17-000075:mdna:54]

[0001045810-17-000123:mdna:65]
[same as prior period, unchanged from 0001045810-17-000075:mdna:55]

[0001045810-17-000123:mdna:66]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $15 million and $12 million during the second quarter of fiscal years 2018 and 2017, respectively, and $31 million and $23 million during the first half of fiscal years 2018 and 2017, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-17-000123:mdna:67]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016, and the Convertible Notes issued in December 2013. Interest expense was $15 million and $12 million during the second quarter of fiscal years 2018 and 2017, respectively, and $31 million and $23 million during the first half of fiscal years 2018 and 2017, respectively.

[0001045810-17-000123:mdna:68]
[same as prior period, unchanged from 0001045810-17-000075:mdna:59]

[0001045810-17-000123:mdna:69]
Other, net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, losses on early debt conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Other, net, was an expense of $4 million during the second quarter of fiscal year 2018 and $21 million during the first half of fiscal year 2018, consisting primarily of $3 million and $17 million of losses recognized from early conversions of the Convertible Notes during the second quarter and first half of fiscal year 2018, respectively. Other, net, was not significant during the second quarter or first half of fiscal year 2017.

[0001045810-17-000123:mdna:70]
[same as prior period, unchanged from 0001045810-17-000075:mdna:61]

[0001045810-17-000123:mdna:71]
We recognized income tax expense of $101 million and $130 million for the second quarter and first half of fiscal year 2018, respectively, and $56 million and $89 million for the second quarter and first half of fiscal year 2017, respectively. Income tax expense as a percentage of income before income tax was 14.8% and 10.7% for the second quarter and first half of fiscal year 2018, respectively, and 17.6% and 15.9% for the second quarter and first half of fiscal year 2017, respectively.

[0001045810-17-000123:mdna:72]
The decrease in our effective tax rate in the second quarter and first half of fiscal year 2018 as compared to the same periods in the prior fiscal year primarily reflects the recognition of tax benefits related to stock-based compensation and a proportional decrease in the amount of earnings subject to United States tax.

[0001045810-17-000123:mdna:73]
[same as prior period, unchanged from 0001045810-17-000075:mdna:64]

[0001045810-17-000123:mdna:74]
[same as prior period, unchanged from 0001045810-17-000075:mdna:65]

[0001045810-17-000123:mdna:75]
|  | July 30, 2017 |  | January 29, 2017 |
|  | (In millions) |
| Cash and cash equivalents | $ | 1,988 |  |  | $ | 1,766 |  |
| Marketable securities | 3,889 |  |  | 5,032 |  |
| Cash, cash equivalents and marketable securities | $ | 5,877 |  |  | $ | 6,798 |  |

[0001045810-17-000123:mdna:76]
|  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 987 |  |  | $ | 519 |  |
| Net cash provided by (used in) investing activities | $ | 1,016 |  |  | $ | (93 | ) |
| Net cash used in financing activities | $ | (1,781 | ) |  | $ | (596 | ) |

[0001045810-17-000123:mdna:77]
As of July 30, 2017, we had $5.88 billion in cash, cash equivalents and marketable securities, a decrease of $921 million from the end of fiscal year 2017. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions. Our portfolio managers are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-17-000123:mdna:78]
Cash provided by operating activities increased in the first half of fiscal year 2018 compared to the first half of fiscal year 2017, primarily due to higher net income, partially offset by changes in working capital.

[0001045810-17-000123:mdna:79]
Cash provided by investing activities increased in the first half of fiscal year 2018 compared to the first half of fiscal year 2017, primarily due to lower purchases of marketable securities.

[0001045810-17-000123:mdna:80]
Cash used in financing activities increased in the first half of fiscal year 2018 compared to the first half of fiscal year 2017, primarily due to repayments of Convertible Notes, higher share repurchases and payments related to employee stock plans.

[0001045810-17-000123:mdna:81]
[same as prior period, unchanged from 0001045810-17-000075:mdna:72]

[0001045810-17-000123:mdna:82]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of July 30, 2017 and January 29, 2017, we had $5.88 billion and $6.80 billion, respectively, in cash, cash equivalents and marketable securities. Our marketable securities consist principally of debt securities of corporations and United States government and its agencies, asset-backed securities, mortgage-backed securities issued by government-sponsored enterprises, money market funds and foreign government bonds. These investments are denominated in United States dollars. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of July 30, 2017, we were in compliance with our investment policy. As of July 30, 2017, our investments in government agencies and government-sponsored enterprises represented 33% of our total investment portfolio, while the financial sector accounted for 18% of our total investment portfolio.  All of our investments are in A/A3 or better rated securities.

[0001045810-17-000123:mdna:83]
[same as prior period, unchanged from 0001045810-17-000075:mdna:74]

[0001045810-17-000123:mdna:84]
[same as prior period, unchanged from 0001045810-17-000075:mdna:75]

[0001045810-17-000123:mdna:85]
[same as prior period, unchanged from 0001045810-17-000075:mdna:76]

[0001045810-17-000123:mdna:86]
Dividend payments and share repurchases must be made from cash held in the United States. During the second quarter and first half of fiscal year 2018, we repurchased a total of 5 million shares for $758 million and made cash dividend payments to our shareholders of $84 million and $166 million, respectively.

[0001045810-17-000123:mdna:87]
[same as prior period, unchanged from 0001045810-17-000075:mdna:78]

[0001045810-17-000123:mdna:88]
[same as prior period, unchanged from 0001045810-17-000075:mdna:79]

[0001045810-17-000123:mdna:89]
[same as prior period, unchanged from 0001045810-17-000075:mdna:80]

[0001045810-17-000123:mdna:90]
In December 2013, we issued $1.50 billion of Convertible Notes that mature in December 2018 unless repurchased or converted prior to such date. The Convertible Notes first became convertible at the holders’ option beginning on the first day of fiscal year 2017. We have utilized U.S. cash to settle an aggregate of $1.41 billion in principal amount of the Convertible Notes through the second quarter of fiscal year 2018 and we have received additional conversion notices for an aggregate of $62 million in principal amount, which are expected to be settled in the third quarter of fiscal year 2018. Please refer to Note 11 of the Notes to the Condensed Consolidated Financial Statements for further discussion.

[0001045810-17-000123:mdna:91]
[same as prior period, unchanged from 0001045810-17-000075:mdna:82]

[0001045810-17-000123:mdna:92]
[same as prior period, unchanged from 0001045810-17-000075:mdna:83]

[0001045810-17-000123:mdna:93]
[same as prior period, unchanged from 0001045810-17-000075:mdna:84]

[0001045810-17-000123:mdna:94]
We are constructing a new headquarters building in Santa Clara, California, which is currently targeted for completion in the third quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. The banks have committed to fund up to $380 million of costs relating to construction. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. The lease has an initial 7.5 year term expiring in December 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks. During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Please refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for a discussion regarding our operating lease financing arrangement.

[0001045810-17-000123:mdna:95]
[same as prior period, unchanged from 0001045810-17-000075:mdna:86]

[0001045810-17-000123:mdna:96]
As of July 30, 2017, we had outstanding inventory purchase obligations totaling $1.04 billion. Except as described above with respect to the Convertible Notes and the Notes, there were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017.

[0001045810-17-000123:mdna:97]
[same as prior period, unchanged from 0001045810-17-000075:mdna:88]

[0001045810-17-000123:mdna:98]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000123:mdna:99]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
