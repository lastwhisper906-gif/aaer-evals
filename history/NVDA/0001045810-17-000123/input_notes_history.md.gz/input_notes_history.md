# NVDA note change history — 0001045810-17-000075 → 0001045810-17-000123


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-23):
[0001045810-17-000123:note_history:1]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the third quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.
  (was, 2017-05-23, similarity 0.9892):
[0001045810-17-000075:note_history:1]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

- added (2017-08-23):
[0001045810-17-000123:note_history:2]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

- added (2017-08-23):
[0001045810-17-000123:note_history:3]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California. The California Court has not set a trial date.

- added (2017-08-23):
[0001045810-17-000123:note_history:4]
On December 7, 2016, NVIDIA filed a petition for inter partes review with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. On May 30, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 6,532,505, another patent asserted by Polaris. On June 22, 2017, the USPTO instituted inter partes review of U.S Patent No. 7,886,122. On June 23, 2017, the USPTO denied institution of inter partes review of U.S. Patent No. 7,124,325. On July 25, 2017, NVIDIA filed inter partes requests with the USPTO challenging the validity of U.S. Patent No. 8,207,976, another patent asserted by Polaris. Also on July 25, 2017, NVIDIA filed inter partes requests with the USPTO for U.S. Patent No. 8,161,344 challenging the validity of further claims and an additional inter partes request for U.S. Patent No. 7,124,325. All of the patents that Polaris has asserted in the U.S. litigation are now subject to requests for inter partes review, with institution decisions forthcoming.

- added (2017-08-23):
[0001045810-17-000123:note_history:5]
On May 9, 2017, NVIDIA filed a Motion to Stay the California action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  On June 15, 2017, the Motion to Stay was granted. The action has now been stayed until December 14, 2017 pending the institution of the inter partes review of these patents.

- added (2017-08-23):
[0001045810-17-000123:note_history:6]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. An oral hearing has been scheduled for February 21, 2019.

- added (2017-08-23):
[0001045810-17-000123:note_history:7]
On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. On June 12, 2017, NVIDIA was notified that the nullity actions against EP1428225 and DE 1020066043668 were served on Polaris and that Polaris has filed a formal response opposing each nullity complaint. On July 14, 2017, the German Patent Court acknowledged receipt of a nullity action filed by NVIDIA challenging the validity of DE 10223167. Polaris has not yet responded to this action.

- added (2017-08-23):
[0001045810-17-000123:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by the other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 30, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2017-08-23):
[0001045810-17-000075:note_history:9]
On May 16, 2016, Polaris Innovations Limited, a non-practicing entity and wholly-owned subsidiary of Wi-LAN Inc., filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe on six of its U.S. patents related generally to control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA.

- removed (2017-08-23):
[0001045810-17-000075:note_history:10]
On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents. On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and transferred the case to the Northern District of California. A trial date has not yet been set.

- removed (2017-08-23):
[0001045810-17-000075:note_history:11]
On December 7, 2016, NVIDIA filed an inter partes review request with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. An institution decision is expected in both of these matters in June 2017. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. If instituted, the USPTO will conduct a trial on the validity of each of these patents.

- removed (2017-08-23):
[0001045810-17-000075:note_history:12]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. NVIDIA has retained counsel in Germany to defend this case. A trial date has not yet been set. On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. Polaris has not yet responded to these actions.

- removed (2017-08-23):
[0001045810-17-000075:note_history:13]
On May 9, 2017, NVIDIA filed a Motion to Stay the action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  If the motion is granted, the action will be suspended until the inter partes reviews are finally resolved.

- removed (2017-08-23):
[0001045810-17-000075:note_history:14]
While there can be no assurance of favorable outcomes, we believe the claims made by other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 30, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-23):
[0001045810-17-000123:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The second quarter of fiscal years 2018 and 2017 were both 13-week quarters.
  (was, 2017-05-23, similarity 0.9757):
[0001045810-17-000075:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The first quarter of fiscal years 2018 and 2017 were both 13-week quarters.

- changed (2017-08-23):
[0001045810-17-000123:note_history:16]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.
  (was, 2017-05-23, similarity 0.8845):
[0001045810-17-000075:note_history:16]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-08-23):
[0001045810-17-000123:note_history:17]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 86 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (2 | ) |  | (31 | ) |
| Net carrying amount | $ | 84 |  |  | $ | 796 |  |

- changed (2017-08-23):
[0001045810-17-000123:note_history:18]
(1) As of July 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.3 years.
  (was, 2017-05-23, similarity 0.9683):
[0001045810-17-000075:note_history:18]
(1) As of April 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.6 years.

- added (2017-08-23):
[0001045810-17-000123:note_history:19]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 8 |  |
| Amortization of debt discount |  | 1 |  |  | 7 |  |  | 2 |  |  | 14 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | 22 |  |

- removed (2017-08-23):
[0001045810-17-000075:note_history:20]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 222 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (7 | ) |  | (31 | ) |
| Net carrying amount | $ | 215 |  |  | $ | 796 |  |

- removed (2017-08-23):
[0001045810-17-000075:note_history:21]
|  |  | Three Months Ended |
|  |  | April 30, |  | May 1, |
|  |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |
| Amortization of debt discount |  | 1 |  |  | 8 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 12 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-23):
[0001045810-17-000123:note_history:22]
During the second quarter of fiscal year 2018, we paid cash to settle an aggregate of $136 million in principal amount of the Convertible Notes and had $86 million in principal amount outstanding as of July 30, 2017. We also issued 5 million shares of our common stock for the excess conversion value and recognized a loss of $3 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $164.39 on the last trading day of the second quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of July 30, 2017 exceeded their principal amount by approximately $619 million. As of July 30, 2017, the conversion rate was 49.8804 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0480 per share of common stock).
  (was, 2017-05-23, similarity 0.6145):
[0001045810-17-000075:note_history:22]
During the first quarter of fiscal year 2018, we paid cash to settle an aggregate of $605 million in principal amount of the Convertible Notes and had $222 million in principal amount outstanding as of April 30, 2017. We also issued 24 million shares of our common stock for the excess conversion value and recognized a loss of $14 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $104.30 on the last trading day of the first quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of April 30, 2017 exceeded their principal amount by approximately $933 million. As of April 30, 2017, the conversion rate was 49.8598 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0562 per share of common stock).

- changed (2017-08-23):
[0001045810-17-000123:note_history:23]
Through the second quarter of fiscal year 2018, we settled an aggregate of $1.41 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $62 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.
  (was, 2017-05-23, similarity 0.9832):
[0001045810-17-000075:note_history:23]
Through the first quarter of fiscal year 2018, we settled an aggregate of $1.28 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $136 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the second quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

- changed (2017-08-23):
[0001045810-17-000123:note_history:24]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continue to be convertible at the holders’ option through October 29, 2017.
  (was, 2017-05-23, similarity 0.9927):
[0001045810-17-000075:note_history:24]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continue to be convertible at the holders’ option through July 30, 2017.

- changed (2017-08-23):
[0001045810-17-000123:note_history:25]
As of July 30, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.
  (was, 2017-05-23, similarity 0.9862):
[0001045810-17-000075:note_history:25]
As of April 30, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

- added (2017-08-23):
[0001045810-17-000123:note_history:26]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 86 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (2 | ) |  | (31 | ) |
| Net carrying amount | $ | 84 |  |  | $ | 796 |  |

- changed (2017-08-23):
[0001045810-17-000123:note_history:27]
(1) As of July 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.3 years.
  (was, 2017-05-23, similarity 0.9683):
[0001045810-17-000075:note_history:27]
(1) As of April 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.6 years.

- added (2017-08-23):
[0001045810-17-000123:note_history:28]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 8 |  |
| Amortization of debt discount |  | 1 |  |  | 7 |  |  | 2 |  |  | 14 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | 22 |  |

- changed (2017-08-23):
[0001045810-17-000123:note_history:29]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.0480 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. During the second quarter of fiscal year 2018, we had received 5 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $136 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $62 million in principal amount that is expected to settle during the third quarter of fiscal year 2018.
  (was, 2017-05-23, similarity 0.9627):
[0001045810-17-000075:note_history:29]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges. The Note Hedges have an adjusted strike price of $20.0562 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. During the first quarter of fiscal year 2018, we had received 24 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $605 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $136 million in principal amount that is expected to settle during the second quarter of fiscal year 2018.

- added (2017-08-23):
[0001045810-17-000123:note_history:30]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction.

- added (2017-08-23):
[0001045810-17-000123:note_history:31]
In the fourth quarter of fiscal year 2017, we entered into an agreement to terminate  63 million Warrants and, in consideration, we delivered a total of 48 million shares of common stock to the counterparty bank. In the second quarter of fiscal year 2018, we entered into a second agreement to terminate the remaining 12 million Warrants outstanding and, in consideration, we delivered a total of 10 million shares of common stock to the counterparty bank.

- changed (2017-08-23):
[0001045810-17-000123:note_history:32]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |
  (was, 2017-05-23, similarity 0.9904):
[0001045810-17-000075:note_history:32]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |

- removed (2017-08-23):
[0001045810-17-000075:note_history:33]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 222 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (7 | ) |  | (31 | ) |
| Net carrying amount | $ | 215 |  |  | $ | 796 |  |

- removed (2017-08-23):
[0001045810-17-000075:note_history:34]
|  |  | Three Months Ended |
|  |  | April 30, |  | May 1, |
|  |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |
| Amortization of debt discount |  | 1 |  |  | 8 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 12 |  |

- removed (2017-08-23):
[0001045810-17-000075:note_history:35]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an adjusted strike price of $26.9988 per share. In the fourth quarter of fiscal year 2017, we contracted with a counterparty bank to terminate 63 million of the 75 million warrants outstanding and issued 48 million shares of our common stock related to the terminated Warrants.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-23):
[0001045810-17-000123:note_history:36]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |
  (was, 2017-05-23, similarity 0.9904):
[0001045810-17-000075:note_history:36]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |
