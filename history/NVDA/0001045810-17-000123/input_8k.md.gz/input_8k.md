# NVDA 8-K — 0001045810-17-000117 filed 2017-08-10

## item codes, every 8-K on or before 2017-08-23

- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2017-08-23

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-17-000117:8k_2_02:1]
EX-99.1
2
q2fy18pr.htm
Q2FY18 PRESS RELEASE

[0001045810-17-000117:8k_2_02:2]
Exhibit

[0001045810-17-000117:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-17-000117:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2018

[0001045810-17-000117:8k_2_02:5]
| • | Record revenue of $2.23 billion, up 56 percent from a year ago |

[0001045810-17-000117:8k_2_02:6]
| • | GAAP EPS of $0.92, up 124 percent from a year ago |

[0001045810-17-000117:8k_2_02:7]
| • | Non-GAAP EPS of $1.01, up 91 percent from a year ago |

[0001045810-17-000117:8k_2_02:8]
| • | Broad growth across all platforms |

[0001045810-17-000117:8k_2_02:9]
SANTA CLARA, Calif.-August 10, 2017-NVIDIA (NASDAQ: NVDA) today reported record revenue for the second quarter ended July 30, 2017, of $2.23 billion, up 56 percent from $1.43 billion a year earlier, and up 15 percent from $1.94 billion in the previous quarter.

[0001045810-17-000117:8k_2_02:10]
GAAP earnings per diluted share for the quarter were $0.92, up 124 percent from $0.41 a year ago and up 16 percent from $0.79 in the previous quarter. Non-GAAP earnings per diluted share were $1.01, up 91 percent from $0.53 a year earlier and up 19 percent from $0.85 in the previous quarter.

[0001045810-17-000117:8k_2_02:11]
“Adoption of NVIDIA GPU computing is accelerating, driving growth across our businesses,” said Jensen Huang, founder and chief executive officer of NVIDIA. “Datacenter revenue increased more than two and a half times. A growing number of car and robot-taxi companies are choosing our DRIVE PX self-driving computing platform. And in Gaming, increasingly the world’s most popular form of entertainment, we power the fastest growing platforms - GeForce and Nintendo Switch.

[0001045810-17-000117:8k_2_02:12]
“Nearly every industry and company is awakening to the power of AI. Our new Volta GPU, the most complex processor ever built, delivers a 100-fold speedup for deep learning beyond our best GPU of four years ago. This quarter, we shipped Volta in volume to leading AI customers. This is the era of AI, and the NVIDIA GPU has become its brain. We have incredible opportunities ahead of us,” he said.

[0001045810-17-000117:8k_2_02:13]
Capital Return

[0001045810-17-000117:8k_2_02:14]
During the first half of fiscal 2018, NVIDIA paid $758 million in share repurchases and $166 million in cash dividends. For fiscal 2018, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-17-000117:8k_2_02:15]
NVIDIA will pay its next quarterly cash dividend of $0.14 per share on September 18, 2017, to all shareholders of record on August 24, 2017.

[0001045810-17-000117:8k_2_02:16]
Q2 FY2018 Summary

[0001045810-17-000117:8k_2_02:17]
| GAAP |
| ($ in millions except earnings per share) | Q2 FY18 | Q1 FY18 | Q2 FY17 | Q/Q | Y/Y |
| Revenue | $2,230 | $1,937 | $1,428 | Up 15% | Up 56% |
| Gross margin | 58.4% | 59.4% | 57.9% | Down 100 bps | Up 50 bps |
| Operating expenses | $614 | $596 | $509 | Up 3% | Up 21% |
| Operating income | $688 | $554 | $317 | Up 24% | Up 117% |
| Net income | $583 | $507 | $261 | Up 15% | Up 123% |
| Diluted earnings per share | $0.92 | $0.79 | $0.41 | Up 16% | Up 124% |

[0001045810-17-000117:8k_2_02:18]
| Non-GAAP |
| ($ in millions except earnings per share) | Q2 FY18 | Q1 FY18 | Q2 FY17 | Q/Q | Y/Y |
| Revenue | $2,230 | $1,937 | $1,428 | Up 15% | Up 56% |
| Gross margin | 58.6% | 59.6% | 58.1% | Down 100 bps | Up 50 bps |
| Operating expenses | $533 | $517 | $448 | Up 3% | Up 19% |
| Operating income | $773 | $637 | $382 | Up 21% | Up 102% |
| Net income | $638 | $533 | $313 | Up 20% | Up 104% |
| Diluted earnings per share | $1.01 | $0.85 | $0.53 | Up 19% | Up 91% |

[0001045810-17-000117:8k_2_02:19]
NVIDIA’s outlook for the third quarter of fiscal 2018 is as follows:

[0001045810-17-000117:8k_2_02:20]
| • | Revenue is expected to be $2.35 billion, plus or minus two percent. |

[0001045810-17-000117:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 58.6 percent and 58.8 percent, respectively, plus or minus 50 basis points. |

[0001045810-17-000117:8k_2_02:22]
| • | GAAP operating expenses are expected to be approximately $672 million. Non-GAAP operating expenses are expected to be approximately $570 million. |

[0001045810-17-000117:8k_2_02:23]
| • | GAAP other income and expense is expected to be an expense of approximately $2 million, inclusive of additional charges from early conversions of convertible notes. Non-GAAP other income and expense is expected to be nominal. |

[0001045810-17-000117:8k_2_02:24]
| • | GAAP and non-GAAP tax rates are both expected to be 17 percent, plus or minus one percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which we expect to generate variability on a quarter by quarter basis. |

[0001045810-17-000117:8k_2_02:25]
| • | Capital expenditures are expected to be approximately $65 million to $75 million. |

[0001045810-17-000117:8k_2_02:26]
Second Quarter Fiscal 2018 Highlights

[0001045810-17-000117:8k_2_02:27]
During the second quarter, NVIDIA achieved progress in these areas:

[0001045810-17-000117:8k_2_02:28]
Datacenter:

[0001045810-17-000117:8k_2_02:29]
| • | Announced and began shipping NVIDIA® Tesla® V100 GPU accelerators, the first GPU based on the new Volta architecture. |

[0001045810-17-000117:8k_2_02:30]
| • | Unveiled new lineup of NVIDIA DGX™ AI supercomputers, with a large installation at Facebook. |

[0001045810-17-000117:8k_2_02:31]
| • | Announced the NVIDIA GPU Cloud Platform, giving developers a comprehensive software suite for AI development. |

[0001045810-17-000117:8k_2_02:32]
| • | Disclosed that the world’s 13 most energy-efficient supercomputers on the Green 500 list run on NVIDIA Tesla accelerators. |

[0001045810-17-000117:8k_2_02:33]
| • | Announced partnerships with VW and Baidu to bring AI deeper into their organizations. |

[0001045810-17-000117:8k_2_02:34]
Gaming:

[0001045810-17-000117:8k_2_02:35]
| • | Introduced Max-Q, a design approach to make gaming laptops thinner, quieter and faster. |

[0001045810-17-000117:8k_2_02:36]
| • | Collaborated with Activision and Bungie to bring Destiny 2 to the PC for the first time. |

[0001045810-17-000117:8k_2_02:37]
| • | Expanded GeForce® Experience™ to China, at the ChinaJoy gaming conference. |

[0001045810-17-000117:8k_2_02:38]
Professional Visualization:

[0001045810-17-000117:8k_2_02:39]
| • | Introduced Project Holodeck, a photorealistic, collaborative VR environment. |

[0001045810-17-000117:8k_2_02:40]
| • | Announced steps to bring AI to ray tracing to advance the iterative design process, including the launch of NVIDIA OptiX™ 5.0 SDK. |

[0001045810-17-000117:8k_2_02:41]
| • | Launched NVIDIA TITAN X and NVIDIA Quadro® external GPU support for the 25 million creative professionals using thin and light notebooks. |

[0001045810-17-000117:8k_2_02:42]
| • | Released the NVIDIA VRWorks™ 360 Video SDK, which enables high-quality, 360-degree live stereo streaming. |

[0001045810-17-000117:8k_2_02:43]
Automotive:

[0001045810-17-000117:8k_2_02:44]
| • | Toyota selected NVIDIA DRIVE™ PX for its next-generation autonomous cars. |

[0001045810-17-000117:8k_2_02:45]
| • | Volvo and Autoliv selected DRIVE PX for self-driving cars targeted to hit the market by 2021. |

[0001045810-17-000117:8k_2_02:46]
| • | ZF and HELLA, two leading automotive suppliers, announced a system based on DRIVE PX to deliver the highest NCAP safety ratings for cars. |

[0001045810-17-000117:8k_2_02:47]
| • | Baidu announced that its Project Apollo open-source self-driving platform for the China market will use DRIVE PX. |

[0001045810-17-000117:8k_2_02:48]
Edge Computing:

[0001045810-17-000117:8k_2_02:49]
| • | Introduced the NVIDIA Isaac robot simulator for training intelligent machines in simulated real-world conditions before deployment. |

[0001045810-17-000117:8k_2_02:50]
| • | Announced the NVIDIA Metropolis platform, used by more than 50 partners to make cities safer and smarter by applying deep learning to video streams. |

[0001045810-17-000117:8k_2_02:51]
CFO Commentary

[0001045810-17-000117:8k_2_02:52]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-17-000117:8k_2_02:53]
Conference Call and Webcast Information

[0001045810-17-000117:8k_2_02:54]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2018 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 56356419. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2018.

[0001045810-17-000117:8k_2_02:55]
Non-GAAP Measures

[0001045810-17-000117:8k_2_02:56]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, loss on early debt conversions, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-17-000117:8k_2_02:57]
Keep Current on NVIDIA

[0001045810-17-000117:8k_2_02:58]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-17-000117:8k_2_02:59]
About NVIDIA

[0001045810-17-000117:8k_2_02:60]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-17-000117:8k_2_02:61]
###

[0001045810-17-000117:8k_2_02:62]
For further information, contact:

[0001045810-17-000117:8k_2_02:63]
| Shawn Simmons |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-5784 |  | (408) 566-5150 |
| ssimmons@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-17-000117:8k_2_02:64]
Certain statements in this press release including, but not limited to statements as to:  adoption of NVIDIA GPU computing accelerating and driving growth; a growing number of car and robot-taxi companies choosing DRIVE PX; gaming being the world’s most popular form of entertainment; GeForce and Nintendo Switch as the fastest growing platforms; the impact of AI and the company’s Volta GPU; the company’s intended capital return for fiscal 2018; the company’s next quarterly cash dividend; the company’s financial outlook for the third quarter of fiscal 2018; the company’s tax rates for the third quarter of fiscal 2018; the impact and benefits of the NVIDIA GPU Cloud Platform, partnerships with VW and Baidu, Max-Q, Project Holodeck, OptiX 5.0 SDK, VRWorks 360 Video SDK, DRIVE PX, the NVIDIA Isaac robot simulator and the NVIDIA Metropolis platform; and the use of DRIVE PX by Baidu’s self-driving platform are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended April 30, 2017. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-17-000117:8k_2_02:65]
© 2017 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, DGX, DRIVE, GeForce, OptiX, Quadro, Tesla and VRWorks are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. MAXQ® is the registered trademark of Maxim Integrated Products, Inc. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-17-000117:8k_2_02:66]
NVIDIA CORPORATION

[0001045810-17-000117:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-17-000117:8k_2_02:68]
(In millions, except per share data)

[0001045810-17-000117:8k_2_02:69]
(Unaudited)

[0001045810-17-000117:8k_2_02:70]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue | $ | 2,230 |  |  | $ | 1,428 |  |  | $ | 4,167 |  |  | $ | 2,733 |  |
| Cost of revenue | 928 |  |  | 602 |  |  | 1,715 |  |  | 1,156 |  |
| Gross profit | 1,302 |  |  | 826 |  |  | 2,452 |  |  | 1,577 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 416 |  |  | 350 |  |  | 827 |  |  | 697 |  |
| Sales, general and administrative | 198 |  |  | 157 |  |  | 383 |  |  | 316 |  |
| Restructuring and other charges | — |  |  | 2 |  |  | — |  |  | 3 |  |
| Total operating expenses | 614 |  |  | 509 |  |  | 1,210 |  |  | 1,016 |  |
| Income from operations | 688 |  |  | 317 |  |  | 1,242 |  |  | 561 |  |
| Interest income | 15 |  |  | 12 |  |  | 31 |  |  | 23 |  |
| Interest expense | (15 | ) |  | (12 | ) |  | (31 | ) |  | (23 | ) |
| Other, net | (4 | ) |  | — |  |  | (21 | ) |  | (3 | ) |
| Total other income (expense) | (4 | ) |  | — |  |  | (21 | ) |  | (3 | ) |
| Income before income tax expense | 684 |  |  | 317 |  |  | 1,221 |  |  | 558 |  |
| Income tax expense | 101 |  |  | 56 |  |  | 130 |  |  | 89 |  |
| Net income | $ | 583 |  |  | $ | 261 |  |  | $ | 1,091 |  |  | $ | 469 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.98 |  |  | $ | 0.49 |  |  | $ | 1.83 |  |  | $ | 0.88 |  |
| Diluted | $ | 0.92 |  |  | $ | 0.41 |  |  | $ | 1.71 |  |  | $ | 0.76 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 597 |  |  | 534 |  |  | 595 |  |  | 536 |  |
| Diluted | 633 |  |  | 634 |  |  | 637 |  |  | 620 |  |

[0001045810-17-000117:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | July 30, |  | January 29, |
|  |  |  | 2017 |  | 2017 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 5,877 |  |  | $ | 6,798 |  |
|  | Accounts receivable, net |  | 1,213 |  |  | 826 |  |
|  | Inventories |  | 855 |  |  | 794 |  |
|  | Prepaid expenses and other current assets |  | 125 |  |  | 118 |  |
|  | Total current assets |  | 8,070 |  |  | 8,536 |  |
| Property and equipment, net |  | 578 |  |  | 521 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 76 |  |  | 104 |  |
| Other assets |  | 60 |  |  | 62 |  |
|  | Total assets |  | $ | 9,402 |  |  | $ | 9,841 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 431 |  |  | $ | 485 |  |
|  | Accrued and other current liabilities |  | 517 |  |  | 507 |  |
|  | Convertible short-term debt |  | 84 |  |  | 796 |  |
|  | Total current liabilities |  | 1,032 |  |  | 1,788 |  |
| Long-term debt |  | 1,984 |  |  | 1,983 |  |
| Other long-term liabilities |  | 408 |  |  | 271 |  |
| Capital lease obligations, long-term |  | 3 |  |  | 6 |  |
|  | Total liabilities |  | 3,427 |  |  | 4,048 |  |
| Convertible debt conversion obligation |  | 2 |  |  | 31 |  |
| Shareholders' equity |  | 5,973 |  |  | 5,762 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 9,402 |  |  | $ | 9,841 |  |

[0001045810-17-000117:8k_2_02:72]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| GAAP gross profit |  | $ | 1,302 |  |  | $ | 1,150 |  |  | $ | 826 |  |  | $ | 2,452 |  |  | $ | 1,577 |  |
| GAAP gross margin |  | 58.4 | % |  | 59.4 | % |  | 57.9 | % |  | 58.8 | % |  | 57.7 | % |
| Stock-based compensation expense (A) |  | 4 |  |  | 4 |  |  | 4 |  |  | 8 |  |  | 8 |  |
| Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Non-GAAP gross profit |  | $ | 1,306 |  |  | $ | 1,154 |  |  | $ | 830 |  |  | $ | 2,460 |  |  | $ | 1,595 |  |
| Non-GAAP gross margin |  | 58.6 | % |  | 59.6 | % |  | 58.1 | % |  | 59.0 | % |  | 58.4 | % |
| GAAP operating expenses |  | $ | 614 |  |  | $ | 596 |  |  | $ | 509 |  |  | $ | 1,210 |  |  | $ | 1,016 |  |
| Stock-based compensation expense (A) |  | (77 | ) |  | (73 | ) |  | (54 | ) |  | (150 | ) |  | (104 | ) |
| Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | (6 | ) |
| Acquisition-related costs (B) |  | (4 | ) |  | (4 | ) |  | (4 | ) |  | (8 | ) |  | (8 | ) |
| Contributions |  | — |  |  | (2 | ) |  | (1 | ) |  | (2 | ) |  | (4 | ) |
| Restructuring and other charges |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (3 | ) |
| Non-GAAP operating expenses |  | $ | 533 |  |  | $ | 517 |  |  | $ | 448 |  |  | $ | 1,050 |  |  | $ | 891 |  |
| GAAP income from operations |  | $ | 688 |  |  | $ | 554 |  |  | $ | 317 |  |  | $ | 1,242 |  |  | $ | 561 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 85 |  |  | 83 |  |  | 65 |  |  | 168 |  |  | 143 |  |
| Non-GAAP income from operations |  | $ | 773 |  |  | $ | 637 |  |  | $ | 382 |  |  | $ | 1,410 |  |  | $ | 704 |  |
| GAAP other income (expense) |  | $ | (4 | ) |  | $ | (18 | ) |  | $ | — |  |  | $ | (21 | ) |  | $ | (3 | ) |
| Gains from non-affiliated investments |  | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Interest expense related to amortization of debt discount |  | 1 |  |  | 2 |  |  | 7 |  |  | 3 |  |  | 14 |  |
| Loss on early debt conversions |  | 3 |  |  | 14 |  |  | — |  |  | 17 |  |  | — |  |
| Non-GAAP other income (expense) |  | $ | — |  |  | $ | (2 | ) |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 8 |  |
| GAAP net income |  | $ | 583 |  |  | $ | 507 |  |  | $ | 261 |  |  | $ | 1,091 |  |  | $ | 469 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 89 |  |  | 99 |  |  | 72 |  |  | 188 |  |  | 153 |  |
| Income tax impact of non-GAAP adjustments |  | (34 | ) |  | (73 | ) |  | (20 | ) |  | (108 | ) |  | (46 | ) |
| Non-GAAP net income |  | $ | 638 |  |  | $ | 533 |  |  | $ | 313 |  |  | $ | 1,171 |  |  | $ | 576 |  |

[0001045810-17-000117:8k_2_02:73]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.92 |  |  | $ | 0.79 |  |  | $ | 0.41 |  |  | $ | 1.71 |  |  | $ | 0.76 |  |
| Non-GAAP |  | $ | 1.01 |  |  | $ | 0.85 |  |  | $ | 0.53 |  |  | $ | 1.87 |  |  | $ | 0.99 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 633 |  |  | 641 |  |  | 634 |  |  | 637 |  |  | 620 |  |
| Anti-dilution impact from note hedge (C) |  | (4 | ) |  | (14 | ) |  | (43 | ) |  | (10 | ) |  | (37 | ) |
| Non-GAAP |  | 629 |  |  | 627 |  |  | 591 |  |  | 627 |  |  | 583 |  |
| GAAP net cash provided by operating activities |  | $ | 705 |  |  | $ | 282 |  |  | $ | 201 |  |  | $ | 987 |  |  | $ | 519 |  |
| Purchase of property and equipment and intangible assets |  | (55 | ) |  | (53 | ) |  | (33 | ) |  | (108 | ) |  | (88 | ) |
| Free cash flow |  | $ | 650 |  |  | $ | 229 |  |  | $ | 168 |  |  | $ | 879 |  |  | $ | 431 |  |

[0001045810-17-000117:8k_2_02:74]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | April 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenue |  | $ | 4 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Research and development |  | $ | 44 |  |  | $ | 41 |  |  | $ | 30 |  |  | $ | 85 |  |  | $ | 59 |  |
| Sales, general and administrative |  | $ | 33 |  |  | $ | 31 |  |  | $ | 24 |  |  | $ | 65 |  |  | $ | 44 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-17-000117:8k_2_02:75]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2018 Outlook |
| GAAP gross margin |  | 58.6 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 58.8 | % |
|  |  |  | Q3 FY2018 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 672 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (102 | ) |
| Non-GAAP operating expenses |  | $ | 570 |  |
| GAAP other income (expense) |  | $ | (2 | ) |
|  | Loss on early debt conversions and interest expense related to amortization of debt discount |  | 2 |  |
| Non-GAAP other income (expense) |  | $ | — |  |
