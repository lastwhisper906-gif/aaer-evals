# NVDA notes — 0001045810-17-000123


## nvda:BalanceSheetComponentsTextBlock

[0001045810-17-000123:notes:1]
[same as prior period, unchanged from 0001045810-17-000075:notes:1]

[0001045810-17-000123:notes:2]
[same as prior period, unchanged from 0001045810-17-000075:notes:2]

[0001045810-17-000123:notes:3]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
| Inventories: | (In millions) |
| Raw materials | $ | 294 |  |  | $ | 252 |  |
| Work in-process | 209 |  |  | 176 |  |
| Finished goods | 352 |  |  | 366 |  |
| Total inventories | $ | 855 |  |  | $ | 794 |  |

[0001045810-17-000123:notes:4]
As of July 30, 2017, we had outstanding inventory purchase obligations totaling $1.04 billion.

[0001045810-17-000123:notes:5]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer related liabilities (1) | $ | 218 |  |  | $ | 197 |  |
| Accrued payroll and related expenses | 120 |  |  | 137 |  |
| Deferred revenue (2) | 74 |  |  | 85 |  |
| Coupon interest on debt obligations | 20 |  |  | 21 |  |
| Professional service fees | 15 |  |  | 13 |  |
| Warranty accrual (3) | 14 |  |  | 8 |  |
| Taxes payable | 12 |  |  | 4 |  |
| Accrued royalties | 11 |  |  | 7 |  |
| Accrued restructuring and other charges (4) | 10 |  |  | 13 |  |
| Leases payable | 5 |  |  | 4 |  |
| Contributions payable | 4 |  |  | 4 |  |
| Other | 14 |  |  | 14 |  |
| Total accrued and other current liabilities | $ | 517 |  |  | $ | 507 |  |

[0001045810-17-000123:notes:6]
[same as prior period, unchanged from 0001045810-17-000075:notes:6]

[0001045810-17-000123:notes:7]
| (2) | Deferred revenue primarily includes customer advances and deferrals related to license and service arrangements. |

[0001045810-17-000123:notes:8]
| (3) | Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding warranties. |

[0001045810-17-000123:notes:9]
| (4) | Please refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding restructuring and other charges. |

[0001045810-17-000123:notes:10]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 252 |  |  | $ | 141 |  |
| Income tax payable | 105 |  |  | 96 |  |
| Contributions payable | 12 |  |  | 9 |  |
| Employee benefits liability | 11 |  |  | 10 |  |
| Deferred rent | 8 |  |  | 6 |  |
| Licenses payable | 7 |  |  | 1 |  |
| Deferred revenue | 6 |  |  | 4 |  |
| Other | 7 |  |  | 4 |  |
| Total other long-term liabilities | $ | 408 |  |  | $ | 271 |  |


## nvda:ScheduleofAccountReceivablefromMajorCustomersTableTextBlock

[0001045810-17-000123:notes:11]
|  |  | July 30, |  | January 29, |
|  |  | 2017 |  | 2017 |
| Accounts Receivable: |  |  |  |  |
| Customer A |  | 14 | % |  | 19 | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-17-000123:notes:12]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,186 |  |  | $ | 781 |  |  | $ | 2,213 |  |  | $ | 1,468 |  |
| Professional Visualization | 235 |  |  | 214 |  |  | 440 |  |  | 403 |  |
| Datacenter | 416 |  |  | 151 |  |  | 825 |  |  | 294 |  |
| Automotive | 142 |  |  | 119 |  |  | 282 |  |  | 232 |  |
| OEM & IP | 251 |  |  | 163 |  |  | 407 |  |  | 336 |  |
| Total revenue | $ | 2,230 |  |  | $ | 1,428 |  |  | $ | 4,167 |  |  | $ | 2,733 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-17-000123:notes:13]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 697 |  |  | $ | 627 |  |
| Estimated weighted average remaining amortization period | (In years) |
| Stock options | 0.1 |  |  | 0.5 |  |
| RSUs, PSUs, and market-based PSUs | 2.4 |  |  | 2.6 |  |
| ESPP | 0.6 |  |  | 0.6 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-17-000123:notes:14]
|  | July 30, 2017 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 1,664 |  |  | $ | 1 |  |  | $ | (5 | ) |  | $ | 1,660 |  |  | $ | — |  |  | $ | 1,660 |  |
| Debt securities of United States government agencies | 1,030 |  |  | — |  |  | (4 | ) |  | 1,026 |  |  | — |  |  | 1,026 |  |
| Debt securities issued by the United States Treasury | 658 |  |  | — |  |  | (2 | ) |  | 656 |  |  | — |  |  | 656 |  |
| Asset-backed securities | 330 |  |  | — |  |  | (1 | ) |  | 329 |  |  | — |  |  | 329 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 153 |  |  | 2 |  |  | (1 | ) |  | 154 |  |  | — |  |  | 154 |  |
| Foreign government bonds | 64 |  |  | — |  |  | — |  |  | 64 |  |  | — |  |  | 64 |  |
| Money market funds | 1,663 |  |  | — |  |  | — |  |  | 1,663 |  |  | 1,663 |  |  | — |  |
| Total | $ | 5,562 |  |  | $ | 3 |  |  | $ | (13 | ) |  | $ | 5,552 |  |  | $ | 1,663 |  |  | $ | 3,889 |  |

[0001045810-17-000123:notes:15]
[same as prior period, unchanged from 0001045810-17-000075:notes:15]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-17-000123:notes:16]
[same as prior period, unchanged from 0001045810-17-000075:notes:16]

[0001045810-17-000123:notes:17]
[same as prior period, unchanged from 0001045810-17-000075:notes:17]

[0001045810-17-000123:notes:18]
[same as prior period, unchanged from 0001045810-17-000075:notes:18]

[0001045810-17-000123:notes:19]
[same as prior period, unchanged from 0001045810-17-000075:notes:19]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-17-000123:notes:20]
Commitments and Contingencies

[0001045810-17-000123:notes:21]
Operating Lease Financing Arrangement

[0001045810-17-000123:notes:22]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the third quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-17-000123:notes:23]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring in December 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-17-000123:notes:24]
We have been overseeing the construction of the headquarters building. The banks committed to fund up to $380 million of costs relating to construction. Advances have been made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest is capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-17-000123:notes:25]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-17-000123:notes:26]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to the financial covenant to maintain a maximum total leverage ratio not to exceed 3.5 to 1.0. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-17-000123:notes:27]
Litigation

[0001045810-17-000123:notes:28]
Polaris Innovations Limited

[0001045810-17-000123:notes:29]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-17-000123:notes:30]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California. The California Court has not set a trial date.

[0001045810-17-000123:notes:31]
On December 7, 2016, NVIDIA filed a petition for inter partes review with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. On May 30, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 6,532,505, another patent asserted by Polaris. On June 22, 2017, the USPTO instituted inter partes review of U.S Patent No. 7,886,122. On June 23, 2017, the USPTO denied institution of inter partes review of U.S. Patent No. 7,124,325. On July 25, 2017, NVIDIA filed inter partes requests with the USPTO challenging the validity of U.S. Patent No. 8,207,976, another patent asserted by Polaris. Also on July 25, 2017, NVIDIA filed inter partes requests with the USPTO for U.S. Patent No. 8,161,344 challenging the validity of further claims and an additional inter partes request for U.S. Patent No. 7,124,325. All of the patents that Polaris has asserted in the U.S. litigation are now subject to requests for inter partes review, with institution decisions forthcoming.

[0001045810-17-000123:notes:32]
On May 9, 2017, NVIDIA filed a Motion to Stay the California action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  On June 15, 2017, the Motion to Stay was granted. The action has now been stayed until December 14, 2017 pending the institution of the inter partes review of these patents.

[0001045810-17-000123:notes:33]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. An oral hearing has been scheduled for February 21, 2019.

[0001045810-17-000123:notes:34]
On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. On June 12, 2017, NVIDIA was notified that the nullity actions against EP1428225 and DE 1020066043668 were served on Polaris and that Polaris has filed a formal response opposing each nullity complaint. On July 14, 2017, the German Patent Court acknowledged receipt of a nullity action filed by NVIDIA challenging the validity of DE 10223167. Polaris has not yet responded to this action.

[0001045810-17-000123:notes:35]
Accounting for Loss Contingencies

[0001045810-17-000123:notes:36]
While there can be no assurance of favorable outcomes, we believe the claims made by the other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 30, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-17-000123:notes:37]
[same as prior period, unchanged from 0001045810-17-000075:notes:36]

[0001045810-17-000123:notes:38]
[same as prior period, unchanged from 0001045810-17-000075:notes:37]


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-17-000123:notes:39]
The following table presents the carrying value of the Convertible Notes:

[0001045810-17-000123:notes:40]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 86 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (2 | ) |  | (31 | ) |
| Net carrying amount | $ | 84 |  |  | $ | 796 |  |

[0001045810-17-000123:notes:41]
(1) As of July 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.3 years.

[0001045810-17-000123:notes:42]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

[0001045810-17-000123:notes:43]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 8 |  |
| Amortization of debt discount |  | 1 |  |  | 7 |  |  | 2 |  |  | 14 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | 22 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-17-000123:notes:44]
Debt

[0001045810-17-000123:notes:45]
Convertible Debt

[0001045810-17-000123:notes:46]
1.00% Convertible Senior Notes Due 2018

[0001045810-17-000123:notes:47]
During the second quarter of fiscal year 2018, we paid cash to settle an aggregate of $136 million in principal amount of the Convertible Notes and had $86 million in principal amount outstanding as of July 30, 2017. We also issued 5 million shares of our common stock for the excess conversion value and recognized a loss of $3 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $164.39 on the last trading day of the second quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of July 30, 2017 exceeded their principal amount by approximately $619 million. As of July 30, 2017, the conversion rate was 49.8804 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0480 per share of common stock).

[0001045810-17-000123:notes:48]
Through the second quarter of fiscal year 2018, we settled an aggregate of $1.41 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $62 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the third quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

[0001045810-17-000123:notes:49]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continue to be convertible at the holders’ option through October 29, 2017.

[0001045810-17-000123:notes:50]
We separately accounted for the liability and equity components of the Convertible Notes at issuance, since our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

[0001045810-17-000123:notes:51]
As of July 30, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

[0001045810-17-000123:notes:52]
Note Hedges and Warrants

[0001045810-17-000123:notes:53]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.0480 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. During the second quarter of fiscal year 2018, we had received 5 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $136 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $62 million in principal amount that is expected to settle during the third quarter of fiscal year 2018.

[0001045810-17-000123:notes:54]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction.

[0001045810-17-000123:notes:55]
In the fourth quarter of fiscal year 2017, we entered into an agreement to terminate  63 million Warrants and, in consideration, we delivered a total of 48 million shares of common stock to the counterparty bank. In the second quarter of fiscal year 2018, we entered into a second agreement to terminate the remaining 12 million Warrants outstanding and, in consideration, we delivered a total of 10 million shares of common stock to the counterparty bank.

[0001045810-17-000123:notes:56]
Long-Term Debt

[0001045810-17-000123:notes:57]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-17-000123:notes:58]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026 (collectively, the Notes). Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-17-000123:notes:59]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-17-000123:notes:60]
The carrying value of our long-term debt and the associated interest rates were as follows:

[0001045810-17-000123:notes:61]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-17-000123:notes:62]
[same as prior period, unchanged from 0001045810-17-000075:notes:60]

[0001045810-17-000123:notes:63]
[same as prior period, unchanged from 0001045810-17-000075:notes:61]

[0001045810-17-000123:notes:64]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income (loss) and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts as of July 30, 2017 was not significant.

[0001045810-17-000123:notes:65]
[same as prior period, unchanged from 0001045810-17-000075:notes:63]

[0001045810-17-000123:notes:66]
[same as prior period, unchanged from 0001045810-17-000075:notes:64]

[0001045810-17-000123:notes:67]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |  | July 30, 2017 |  | July 31, 2016 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 89 |  |  | $ | 61 |  |  | $ | 163 |  |  | $ | 96 |  |
| Not designated for hedge accounting | $ | 69 |  |  | $ | 13 |  |  | $ | 120 |  |  | $ | 13 |  |

[0001045810-17-000123:notes:68]
[same as prior period, unchanged from 0001045810-17-000075:notes:66]

[0001045810-17-000123:notes:69]
As of July 30, 2017, the maturities of the designated foreign currency forward contracts were three months or less. We expect to realize all gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months.

[0001045810-17-000123:notes:70]
We formally assess, both at inception and on an ongoing basis, whether derivative financial instruments designated for hedge accounting treatment are highly effective. For the second quarter and first half of fiscal years 2018 and 2017, all derivative financial instruments designated for hedge accounting treatment were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-17-000123:notes:71]
The net change in unrealized gains (losses) on derivative financial instruments designated for hedge accounting treatment was not significant for the second quarter and first half of fiscal years 2018 and 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-17-000123:notes:72]
[same as prior period, unchanged from 0001045810-17-000075:notes:71]

[0001045810-17-000123:notes:73]
[same as prior period, unchanged from 0001045810-17-000075:notes:72]

[0001045810-17-000123:notes:74]
[same as prior period, unchanged from 0001045810-17-000075:notes:73]

[0001045810-17-000123:notes:75]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |  | July 30, 2017 |  | July 31, 2016 |
|  | (In millions) |
| Cost of revenue | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Research and development | 44 |  |  | 30 |  |  | 85 |  |  | 59 |  |
| Sales, general and administrative | 33 |  |  | 24 |  |  | 65 |  |  | 44 |  |
| Total | $ | 81 |  |  | $ | 58 |  |  | $ | 158 |  |  | $ | 111 |  |

[0001045810-17-000123:notes:76]
[same as prior period, unchanged from 0001045810-17-000075:notes:75]

[0001045810-17-000123:notes:77]
[same as prior period, unchanged from 0001045810-17-000075:notes:76]

[0001045810-17-000123:notes:78]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted Average Exercise Price Per Share |
|  | (In millions, except per share data) |
| Balances, January 29, 2017 | 27 |  |  | $ | 32.84 |  |  | 7 |  |  | $ | 14.47 |  |
| Granted (1) (2) | 3 |  |  | $ | 106.65 |  |  | — |  |  | $ | — |  |
| Exercised | — |  |  | $ | — |  |  | (1 | ) |  | $ | 14.51 |  |
| Vested | (5 | ) |  | $ | 21.06 |  |  | — |  |  | $ | — |  |
| Balances, July 30, 2017 | 25 |  |  | $ | 42.54 |  |  | 6 |  |  | $ | 14.46 |  |

[0001045810-17-000123:notes:79]
[same as prior period, unchanged from 0001045810-17-000075:notes:78]

[0001045810-17-000123:notes:80]
[same as prior period, unchanged from 0001045810-17-000075:notes:79]

[0001045810-17-000123:notes:81]
Of the total fair value of equity awards granted during the second quarter and first half of fiscal year 2018, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $10 million and $39 million, respectively. Of the total fair value of equity awards granted during the second quarter and first half of fiscal year 2017, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $5 million and $17 million, respectively.

[0001045810-17-000123:notes:82]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of July 30, 2017 and January 29, 2017:


## us-gaap:EarningsPerShareTextBlock

[0001045810-17-000123:notes:83]
[same as prior period, unchanged from 0001045810-17-000075:notes:82]

[0001045810-17-000123:notes:84]
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-17-000123:notes:85]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 583 |  |  | $ | 261 |  |  | $ | 1,091 |  |  | $ | 469 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 597 |  |  | 534 |  |  | 595 |  |  | 536 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards | 26 |  |  | 26 |  |  | 26 |  |  | 23 |  |
| 1% Convertible Senior Notes | 4 |  |  | 43 |  |  | 9 |  |  | 37 |  |
| Warrants issued with the 1% Convertible Senior Notes | 6 |  |  | 31 |  |  | 7 |  |  | 24 |  |
| Diluted weighted average shares | 633 |  |  | 634 |  |  | 637 |  |  | 620 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.98 |  |  | $ | 0.49 |  |  | $ | 1.83 |  |  | $ | 0.88 |  |
| Diluted (2) | $ | 0.92 |  |  | $ | 0.41 |  |  | $ | 1.71 |  |  | $ | 0.76 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | — |  |  | — |  |  | 1 |  |  | 2 |  |

[0001045810-17-000123:notes:86]
[same as prior period, unchanged from 0001045810-17-000075:notes:85]

[0001045810-17-000123:notes:87]
[same as prior period, unchanged from 0001045810-17-000075:notes:86]

[0001045810-17-000123:notes:88]
The 1.00% Convertible Senior Notes, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0480 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share. The Warrants have a dilutive impact on net income per share if our average stock price for the quarter exceeds the adjusted strike price of $26.9876 per share. All outstanding Warrants were terminated during the second quarter of fiscal year 2018.

[0001045810-17-000123:notes:89]
For the second quarter and first half of fiscal year 2018, our average stock price was $144.57 and $124.89, respectively, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Convertible Notes and the Warrants to have a dilutive impact for these periods.

[0001045810-17-000123:notes:90]
[same as prior period, unchanged from 0001045810-17-000075:notes:88]

[0001045810-17-000123:notes:91]
In the fourth quarter of fiscal year 2017, we entered into an agreement to terminate 63 million Warrants and, in consideration, we delivered a total of 48 million shares of common stock to the counterparty bank. In the second quarter of fiscal year 2018, we entered into a second agreement to terminate the remaining 12 million Warrants outstanding and, in consideration, we delivered a total of 10 million shares of common stock to the counterparty bank.

[0001045810-17-000123:notes:92]
[same as prior period, unchanged from 0001045810-17-000075:notes:91]


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-17-000123:notes:93]
|  |  | Fair Value at |
|  | Pricing Category |  | July 30, 2017 |  | January 29, 2017 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 1,660 |  |  | $ | 2,388 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,026 |  |  | $ | 1,188 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 656 |  |  | $ | 850 |  |
| Asset-backed securities | Level 2 |  | $ | 329 |  |  | $ | 489 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 154 |  |  | $ | 162 |  |
| Foreign government bonds | Level 2 |  | $ | 64 |  |  | $ | 70 |  |
| Money market funds | Level 1 |  | $ | 1,663 |  |  | $ | 321 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 693 |  |  | $ | 4,474 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 996 |  |  | $ | 975 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 1,000 |  |  | $ | 961 |  |
| Interest rate swap (2) | Level 2 |  | $ | 5 |  |  | $ | 2 |  |

[0001045810-17-000123:notes:94]
[same as prior period, unchanged from 0001045810-17-000075:notes:93]

[0001045810-17-000123:notes:95]
[same as prior period, unchanged from 0001045810-17-000075:notes:94]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-17-000123:notes:96]
[same as prior period, unchanged from 0001045810-17-000075:notes:95]

[0001045810-17-000123:notes:97]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review the fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 assets for the second quarter of fiscal year 2018. We did not have any investments classified as Level 3 as of July 30, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-17-000123:notes:98]
[same as prior period, unchanged from 0001045810-17-000075:notes:97]

[0001045810-17-000123:notes:99]
We recognized income tax expense of $101 million and $130 million for the second quarter and first half of fiscal year 2018, respectively, and $56 million and $89 million for the second quarter and first half of fiscal year 2017, respectively.  Income tax expense as a percentage of income before income tax for the second quarter and first half of fiscal year 2018 was 14.8% and 10.7%, respectively, and 17.6% and 15.9% for the second quarter and first half of fiscal year 2017, respectively.

[0001045810-17-000123:notes:100]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2018 as compared to the same periods in the prior fiscal year primarily reflects the recognition of tax benefits related to stock-based compensation and a proportional decrease in the amount of earnings subject to United States tax.

[0001045810-17-000123:notes:101]
Our effective tax rates for the first half of fiscal years 2018 and 2017 of 10.7% and 15.9%, respectively, were lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-17-000123:notes:102]
For the first half of fiscal year 2018, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 29, 2017.

[0001045810-17-000123:notes:103]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 30, 2017, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-17-000123:notes:104]
[same as prior period, unchanged from 0001045810-17-000075:notes:103]

[0001045810-17-000123:notes:105]
[same as prior period, unchanged from 0001045810-17-000075:notes:104]

[0001045810-17-000123:notes:106]
|  | July 30, 2017 |  | January 29, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (175 | ) |  | $ | 18 |  |  | $ | 193 |  |  | $ | (167 | ) |  | $ | 26 |  |
| Patents and licensed technology | 469 |  |  | (411 | ) |  | 58 |  |  | 468 |  |  | (390 | ) |  | 78 |  |
| Total intangible assets | $ | 662 |  |  | $ | (586 | ) |  | $ | 76 |  |  | $ | 661 |  |  | $ | (557 | ) |  | $ | 104 |  |

[0001045810-17-000123:notes:107]
Amortization expense associated with intangible assets was $14 million and $29 million for the second quarter and first half of fiscal year 2018, respectively, and $18 million and $35 million for the second quarter and first half of fiscal year 2017, respectively. Future amortization expense related to the net carrying amount of intangible assets as of July 30, 2017 is estimated to be $25 million for the remainder of fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $8 million in fiscal year 2021, and $1 million in fiscal year 2022 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-17-000123:notes:108]
|  | July 30, 2017 |  | January 29, 2017 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 3,086 |  |  | $ | 3,085 |  |  | $ | 2,209 |  |  | $ | 2,209 |  |
| Due in 1 - 5 years | 2,423 |  |  | 2,414 |  |  | 3,210 |  |  | 3,194 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 53 |  |  | 53 |  |  | 65 |  |  | 65 |  |
| Total | $ | 5,562 |  |  | $ | 5,552 |  |  | $ | 5,484 |  |  | $ | 5,468 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-17-000123:notes:109]
[same as prior period, unchanged from 0001045810-17-000075:notes:108]

[0001045810-17-000123:notes:110]
[same as prior period, unchanged from 0001045810-17-000075:notes:109]

[0001045810-17-000123:notes:111]
We performed an impairment review of our investment portfolio as of July 30, 2017. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of July 30, 2017.

[0001045810-17-000123:notes:112]
The following is a summary of cash equivalents and marketable securities as of July 30, 2017 and January 29, 2017:

[0001045810-17-000123:notes:113]
The following table provides the breakdown of unrealized losses as of July 30, 2017, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-17-000123:notes:114]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 1,243 |  |  | $ | (4 | ) |  | $ | 86 |  |  | $ | (1 | ) |  | $ | 1,329 |  |  | $ | (5 | ) |
| Debt securities issued by United States government agencies | 881 |  |  | (3 | ) |  | 100 |  |  | (1 | ) |  | 981 |  |  | (4 | ) |
| Debt securities issued by the United States Treasury | 645 |  |  | (2 | ) |  | — |  |  | — |  |  | 645 |  |  | (2 | ) |
| Asset-backed securities | 304 |  |  | (1 | ) |  | — |  |  | — |  |  | 304 |  |  | (1 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 40 |  |  | — |  |  | 36 |  |  | (1 | ) |  | 76 |  |  | (1 | ) |
|  | $ | 3,113 |  |  | $ | (10 | ) |  | $ | 222 |  |  | $ | (3 | ) |  | $ | 3,335 |  |  | $ | (13 | ) |

[0001045810-17-000123:notes:115]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities as of July 30, 2017 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity. Net realized gains and losses were not significant for the second quarter and first half of fiscal years 2018 and 2017.

[0001045810-17-000123:notes:116]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of July 30, 2017 and January 29, 2017 and are shown below by contractual maturity:


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-17-000123:notes:117]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000123:notes:118]
Recently Adopted Accounting Pronouncement

[0001045810-17-000123:notes:119]
In October 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which requires the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We elected to early adopt this new guidance in the first quarter of fiscal year 2018, which required us to reflect any adjustments as of January 30, 2017. Upon adoption of this guidance, we recorded a cumulative-effect adjustment as of the first day of fiscal year 2018 to decrease retained earnings by $28 million, with a corresponding decrease to prepaid taxes that had not been previously recognized in income tax expense.

[0001045810-17-000123:notes:120]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-17-000123:notes:121]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

[0001045810-17-000123:notes:122]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-17-000123:notes:123]
[same as prior period, unchanged from 0001045810-17-000075:notes:122]

[0001045810-17-000123:notes:124]
[same as prior period, unchanged from 0001045810-17-000075:notes:123]

[0001045810-17-000123:notes:125]
[same as prior period, unchanged from 0001045810-17-000075:notes:124]

[0001045810-17-000123:notes:126]
[same as prior period, unchanged from 0001045810-17-000075:notes:125]

[0001045810-17-000123:notes:127]
The estimated product returns and estimated product warranty liabilities as of July 30, 2017 and January 29, 2017 were as follows:

[0001045810-17-000123:notes:128]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 8 |  |  | $ | 11 |  |
| Additions | 8 |  |  | 2 |  |
| Deductions | (2 | ) |  | (5 | ) |
| Balance at end of period | $ | 14 |  |  | $ | 8 |  |

[0001045810-17-000123:notes:129]
[same as prior period, unchanged from 0001045810-17-000075:notes:128]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-17-000123:notes:130]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2017 |  | July 31, 2016 |  | July 30, 2017 |  | July 31, 2016 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | 66 |  |  | $ | 43 |  |  | $ | 132 |  |
| Stock-based compensation expense | (81 | ) |  | (58 | ) |  | (158 | ) |  | (111 | ) |
| Unallocated cost of revenue and operating expenses | (59 | ) |  | (49 | ) |  | (114 | ) |  | (104 | ) |
| Acquisition-related costs | (4 | ) |  | (4 | ) |  | (8 | ) |  | (8 | ) |
| Restructuring and other charges | — |  |  | (2 | ) |  | — |  |  | (3 | ) |
| Contributions | — |  |  | (1 | ) |  | (2 | ) |  | (4 | ) |
| Legal settlement costs | — |  |  | — |  |  | — |  |  | (16 | ) |
| Total | $ | (144 | ) |  | $ | (48 | ) |  | $ | (239 | ) |  | $ | (114 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-17-000123:notes:131]
[same as prior period, unchanged from 0001045810-17-000075:notes:130]

[0001045810-17-000123:notes:132]
In fiscal year 2016, we began the wind-down of our Icera operations. No restructuring charges were recorded during the second quarter and first half of fiscal year 2018.

[0001045810-17-000123:notes:133]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Condensed Consolidated Balance Sheets as of July 30, 2017 and January 29, 2017:

[0001045810-17-000123:notes:134]
|  | July 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 13 |  |  | $ | 23 |  |
| Restructuring and other charges | — |  |  | 3 |  |
| Cash payments | (3 | ) |  | (13 | ) |
| Balance at end of period | $ | 10 |  |  | $ | 13 |  |

[0001045810-17-000123:notes:135]
The majority of the remaining balance of $10 million as of July 30, 2017 is expected to be paid during the next twelve months.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-17-000123:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, |  | July 31, |  | July 30, |  | July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 674 |  |  | $ | 505 |  |  | $ | 1,277 |  |  | $ | 949 |  |
| China | 481 |  |  | 256 |  |  | 810 |  |  | 504 |  |
| Other Asia Pacific | 420 |  |  | 191 |  |  | 797 |  |  | 351 |  |
| United States | 278 |  |  | 206 |  |  | 631 |  |  | 400 |  |
| Other Americas | 199 |  |  | 103 |  |  | 292 |  |  | 206 |  |
| Europe | 178 |  |  | 167 |  |  | 360 |  |  | 323 |  |
| Total revenue | $ | 2,230 |  |  | $ | 1,428 |  |  | $ | 4,167 |  |  | $ | 2,733 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-17-000123:notes:137]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 30, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 1,897 |  |  | $ | 333 |  |  | $ | — |  |  | $ | 2,230 |  |
| Depreciation and amortization expense | $ | 29 |  |  | $ | 9 |  |  | $ | 11 |  |  | $ | 49 |  |
| Operating income (loss) | $ | 761 |  |  | $ | 71 |  |  | $ | (144 | ) |  | $ | 688 |  |
| Three Months Ended July 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,196 |  |  | $ | 166 |  |  | $ | 66 |  |  | $ | 1,428 |  |
| Depreciation and amortization expense | $ | 29 |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 47 |  |
| Operating income (loss) | $ | 379 |  |  | $ | (14 | ) |  | $ | (48 | ) |  | $ | 317 |  |
| Six Months Ended July 30, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 3,459 |  |  | $ | 665 |  |  | $ | 43 |  |  | $ | 4,167 |  |
| Depreciation and amortization expense | $ | 57 |  |  | $ | 18 |  |  | $ | 21 |  |  | $ | 96 |  |
| Operating income (loss) | $ | 1,363 |  |  | $ | 118 |  |  | $ | (239 | ) |  | $ | 1,242 |  |
| Six Months Ended July 31, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 2,275 |  |  | $ | 326 |  |  | $ | 132 |  |  | $ | 2,733 |  |
| Depreciation and amortization expense | $ | 57 |  |  | $ | 14 |  |  | $ | 21 |  |  | $ | 92 |  |
| Operating income (loss) | $ | 727 |  |  | $ | (52 | ) |  | $ | (114 | ) |  | $ | 561 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-17-000123:notes:138]
[same as prior period, unchanged from 0001045810-17-000075:notes:137]

[0001045810-17-000123:notes:139]
[same as prior period, unchanged from 0001045810-17-000075:notes:138]

[0001045810-17-000123:notes:140]
[same as prior period, unchanged from 0001045810-17-000075:notes:139]

[0001045810-17-000123:notes:141]
[same as prior period, unchanged from 0001045810-17-000075:notes:140]

[0001045810-17-000123:notes:142]
[same as prior period, unchanged from 0001045810-17-000075:notes:141]

[0001045810-17-000123:notes:143]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, unallocated cost of revenue and operating expenses, acquisition-related costs, restructuring and other charges, contributions, legal settlement costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-17-000123:notes:144]
[same as prior period, unchanged from 0001045810-17-000075:notes:143]

[0001045810-17-000123:notes:145]
[same as prior period, unchanged from 0001045810-17-000075:notes:144]

[0001045810-17-000123:notes:146]
[same as prior period, unchanged from 0001045810-17-000075:notes:145]

[0001045810-17-000123:notes:147]
[same as prior period, unchanged from 0001045810-17-000075:notes:146]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-17-000123:notes:148]
[same as prior period, unchanged from 0001045810-17-000075:notes:147]

[0001045810-17-000123:notes:149]
[same as prior period, unchanged from 0001045810-17-000075:notes:148]

[0001045810-17-000123:notes:150]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The second quarter of fiscal years 2018 and 2017 were both 13-week quarters.

[0001045810-17-000123:notes:151]
[same as prior period, unchanged from 0001045810-17-000075:notes:150]

[0001045810-17-000123:notes:152]
[same as prior period, unchanged from 0001045810-17-000075:notes:151]

[0001045810-17-000123:notes:153]
[same as prior period, unchanged from 0001045810-17-000075:notes:152]

[0001045810-17-000123:notes:154]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-17-000123:notes:155]
[same as prior period, unchanged from 0001045810-17-000075:notes:154]

[0001045810-17-000123:notes:156]
[same as prior period, unchanged from 0001045810-17-000075:notes:155]

[0001045810-17-000123:notes:157]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock.

[0001045810-17-000123:notes:158]
During the second quarter and first half of fiscal year 2018, we repurchased a total of 5 million shares for $758 million and made cash dividend payments to our shareholders of $84 million and $166 million, respectively.

[0001045810-17-000123:notes:159]
Through July 30, 2017, we have repurchased an aggregate of 250 million shares under our share repurchase program for a total cost of $5.35 billion since the inception of the program. All shares delivered from these repurchases have been placed into treasury stock. As of July 30, 2017, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.97 billion through December 2020.

[0001045810-17-000123:notes:160]
[same as prior period, unchanged from 0001045810-17-000075:notes:158]

[0001045810-17-000123:notes:161]
As of July 30, 2017 and January 29, 2017, there were no shares of preferred stock outstanding.

[0001045810-17-000123:notes:162]
[same as prior period, unchanged from 0001045810-17-000075:notes:160]

[0001045810-17-000123:notes:163]
[same as prior period, unchanged from 0001045810-17-000075:notes:161]
