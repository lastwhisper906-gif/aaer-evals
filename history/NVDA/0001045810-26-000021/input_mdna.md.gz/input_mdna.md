# NVDA MD&A — 0001045810-26-000021


## mdna

[0001045810-26-000021:mdna:1]
Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001045810-26-000021:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 1A. Risk Factors,” our Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Annual Report on Form 10-K, before deciding to purchase, hold, or sell shares of our common stock.

[0001045810-26-000021:mdna:3]
Overview

[0001045810-26-000021:mdna:4]
Our Company and Our Businesses

[0001045810-26-000021:mdna:5]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, and digital twin applications. NVIDIA is now a data center scale AI infrastructure company reshaping all industries.

[0001045810-26-000021:mdna:6]
Our two operating segments are "Compute & Networking" and "Graphics." Refer to Note 16 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-26-000021:mdna:7]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-26-000021:mdna:8]
Recent Developments, Future Objectives and Challenges

[0001045810-26-000021:mdna:9]
Revenue growth in fiscal year 2026 was driven by data center compute and networking platforms for accelerated computing and AI solutions. Our Blackwell architectures represented the majority of our Data Center revenue.

[0001045810-26-000021:mdna:10]
The availability of data centers, energy, and capital to support the buildout of NVIDIA AI infrastructure by our customers and partners is crucial, and any shortage of these or other necessary resources could impact our future revenue and financial performance. Expanding energy capacity to meet demand is a complex, multi-year process that involves significant regulatory, technical, and construction challenges. In addition, access to capital can be particularly constrained for less-capitalized companies, which may face difficulties securing financing for large-scale infrastructure projects. These limitations could delay customer and partner deployments or reduce the scale of accelerated computing and AI adoption.

[0001045810-26-000021:mdna:11]
We continue to execute Data Center compute product introductions, bringing new advanced architectures on a one-year product cadence, including our Rubin platform. We began shipping production units of our new Blackwell Ultra platforms including GB300 in the second quarter of fiscal year 2026. The complexity of our product transitions and sophisticated system configurations has and may in the future cause delays in production and create challenges in managing supply and demand. This could further result in revenue volatility, quality issues, increased inventory provisions, decreases in product yields and higher material costs, and/or increased warranty costs. Customers may postpone purchasing new architectures or may adopt new technologies more gradually than anticipated, affecting our revenue timing and supply chain expenses.

[0001045810-26-000021:mdna:12]
In April 2025, the USG informed us that a license is required for exports of our H20 product into the China market. As a result of these requirements, we incurred a $4.5 billion charge in the first quarter of fiscal year 2026 associated with H20 for excess inventory and purchase obligations, as the demand for H20 diminished. In August 2025, the USG granted licenses that would allow us to ship certain H20 products to certain China-based customers. We generated approximately $60 million in H20 revenue under those licenses.

[0001045810-26-000021:mdna:13]
In February 2026, the USG granted a license that would allow us to ship small amounts of H200 products to specific China-based customers. To date, we have not generated any revenue under the H200 licensing program, and do not yet know whether any imports will be allowed into China. The license requires that the H200s go through an inspection process in the United States prior to any shipment to the customer. As a result, any H200 shipped under the new licensing program will be subject to a 25% tariff upon importation into the United States.

[0001045810-26-000021:mdna:14]
The recent rise in high-quality open-source foundation models is making advanced AI capabilities broadly accessible. Open-source AI is dependent on developer adoption and if deployed on our competitors’ platforms, it could reduce demand for our products and services.

[0001045810-26-000021:mdna:15]
While currently our supply chain is mainly concentrated in Asia, we are expanding into the U.S. and Latin America. These moves are expected to strengthen our supply chain, add resiliency and redundancy, and meet the growing demand for AI infrastructure. Our ability to increase manufacturing capabilities will depend on the local region's manufacturing ecosystem's capacity to ramp production supply to the required volume and on a timely basis.

[0001045810-26-000021:mdna:16]
We have made, and expect to continue making, investments that support our technology roadmap and the broader AI ecosystem. In fiscal year 2026, we made the following investments:

[0001045810-26-000021:mdna:17]
•We invested $17.5 billion in private companies and infrastructure funds, primarily to support early‑stage startups. These investments include AI model makers that purchase our products directly or through CSPs. Many of these investments are illiquid and non‑marketable. The related early-stage startups may not become profitable in the near term, or at all, and there can be no assurance that we will realize a return on our investments.

[0001045810-26-000021:mdna:18]
•We made investments in publicly-held equity securities where the value may fluctuate significantly due to changes in stock prices and could adversely affect our financial results.

[0001045810-26-000021:mdna:19]
•To support the build-out of complex datacenter infrastructures, we enter into commercial arrangements, including guarantees with partners. We provided $3.5 billion in land, power, and shell guarantees to early‑stage companies, generally over multi‑year periods. If the escrow and the partners' operating activities are not sufficient to cover an event of default under these guarantees, we may elect to assume the underlying leases for internal use or sublease them to third parties.

[0001045810-26-000021:mdna:20]
Macroeconomic factors, including tariffs, inflation, interest rate changes, capital market volatility, global supply chain constraints, and global economic and geopolitical developments, have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors impact our supply chain and manufacturing costs, employee wages, costs for capital equipment, the value of our investments, revenue and competitive position. Our product and solution pricing generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-26-000021:mdna:21]
Refer to “Item 1A. Risk Factors – Risks Related to Regulatory, Legal, Our Stock and Other Matters” for a further discussion of the potential impact of these factors on our business.

[0001045810-26-000021:mdna:22]
Fiscal Year 2026 Summary

[0001045810-26-000021:mdna:23]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Change |
|  | ($ in millions, except per share data) |
| Revenue | $ | 215,938 |  |  | $ | 130,497 |  |  | Up 65% |
| Gross margin | 71.1 | % |  | 75.0 | % |  | -3.9 pts |
| Operating expenses | $ | 23,076 |  |  | $ | 16,405 |  |  | Up 41% |
| Operating income | $ | 130,387 |  |  | $ | 81,453 |  |  | Up 60% |
| Net income | $ | 120,067 |  |  | $ | 72,880 |  |  | Up 65% |
| Net income per diluted share | $ | 4.90 |  |  | $ | 2.94 |  |  | Up 67% |

[0001045810-26-000021:mdna:24]
Revenue for fiscal year 2026 was $215.9 billion, up 65% from a year ago.

[0001045810-26-000021:mdna:25]
Data Center revenue for fiscal year 2026 was up 68% from a year ago. The strong year-on-year growth was driven by the major platform shifts – accelerated computing and AI.

[0001045810-26-000021:mdna:26]
Gaming revenue for fiscal year 2026 was up 41% from a year ago, driven by strong Blackwell demand. We expect supply constraints to be a headwind to Gaming in the first quarter of fiscal 2027 and beyond.

[0001045810-26-000021:mdna:27]
Professional Visualization revenue for fiscal year 2026 was up 70% from a year ago, driven by exceptional demand for Blackwell as well as the launch of our new DGX Spark.

[0001045810-26-000021:mdna:28]
Automotive revenue for fiscal year 2026 was up 39% from a year ago, driven by continued adoption of our self-driving platforms.

[0001045810-26-000021:mdna:29]
Gross margin decreased in fiscal year 2026 as our business model transitioned from offering Hopper HGX systems to Blackwell full-scale datacenter solutions. The gross margin decrease was also impacted by a $4.5 billion charge associated with H20 excess inventory and purchase obligations.

[0001045810-26-000021:mdna:30]
Operating expenses for fiscal year 2026 were up 41% from a year ago, driven by higher compensation and benefits expenses due to employee growth and compute and infrastructure costs.

[0001045810-26-000021:mdna:31]
Critical Accounting Estimates

[0001045810-26-000021:mdna:32]
Our consolidated financial statements are prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and could have a material impact on our financial condition or results of operations. We have critical accounting estimates in the areas of inventories, income taxes, non-marketable equity securities, and revenue recognition. Refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a summary of significant accounting policies.

[0001045810-26-000021:mdna:33]
Inventories

[0001045810-26-000021:mdna:34]
We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory, and for excess product purchase commitments. Most of our inventory provisions relate to excess quantities of products or components, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions, which requires management judgment.

[0001045810-26-000021:mdna:35]
Situations that may result in excess or obsolete inventory or excess product purchase commitments include changes in business and economic conditions, changes in market conditions, sudden and significant decreases in demand for our products, including potential cancellation or deferral of customer purchase orders, inventory obsolescence because of changing technology and customer requirements, new product introductions resulting in less demand for existing products or inconsistent spikes in demand, failure to estimate customer demand properly, ordering in advance of historical lead-times, government regulations and the impact of changes in future demand, or increase in demand for competitive products, including competitive actions.

[0001045810-26-000021:mdna:36]
The net effect on our gross margin from inventory provisions and sales of items previously written down was an unfavorable impact of 2.6% in fiscal year 2026 and 2.3% in fiscal year 2025. Our inventory and capacity purchase commitments are based on forecasts of future customer demand and consider our third-party manufacturers' lead times and constraints. Our manufacturing lead times can be and have been long, and in some cases, extended beyond twelve months for some products. We may place non-cancellable inventory orders for certain product components in advance of our historical lead times, pay premiums and provide deposits to secure future supply and capacity. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001045810-26-000021:mdna:37]
Refer to the Gross Profit and Gross Margin discussion below in this Management's Discussion and Analysis for further discussion.

[0001045810-26-000021:mdna:38]
Income Taxes

[0001045810-26-000021:mdna:39]
We are subject to income taxes in the U.S. and foreign jurisdictions. Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the U.S. or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential U.S. and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-26-000021:mdna:40]
We record a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized based on all available evidence. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-26-000021:mdna:41]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-26-000021:mdna:42]
Non-Marketable Equity Securities

[0001045810-26-000021:mdna:43]
Non-marketable equity securities consist of investments in private companies without readily determinable fair values. They are measured at cost minus impairment, if any, and are adjusted for observable price changes in orderly transactions for a similar investment in the same issuer (the measurement alternative). These adjustments may require use of unobservable inputs.

[0001045810-26-000021:mdna:44]
We assess impairment quarterly based on qualitative and quantitative factors, including the investee’s operating performance and market trends.

[0001045810-26-000021:mdna:45]
Revenue Recognition

[0001045810-26-000021:mdna:46]
Revenue Allowances

[0001045810-26-000021:mdna:47]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to reflect our estimated exposure for product returns. Return rights for certain stocking distributors for specific products are contractually limited based on a percentage of prior quarter shipments. For shipments to other customers, we do not allow returns, although we may approve returns for credit or refund based on applicable facts and circumstances.

[0001045810-26-000021:mdna:48]
We account for customer programs, which involve rebates and marketing development funds, or MDFs, as a reduction in revenue and accrue for such programs based on the amount we expect to be claimed by customers. Certain customer programs include distributor price incentives or other channel programs for specific products and customer classes which require judgment as to whether the applicable incentives will be attained. Estimates for customer program accruals include a combination of historical attainment and claim rates and may be adjusted based on relevant internal and external factors.

[0001045810-26-000021:mdna:49]
Contracts with Multiple Performance Obligations

[0001045810-26-000021:mdna:50]
Our contracts may contain more than one performance obligation. Judgment is required in determining whether each performance obligation within a customer contract is distinct. Except for License and Development Arrangements, NVIDIA products and services function on a standalone basis and do not require a significant amount of integration or interdependency. Therefore, multiple performance obligations contained within a customer contract are considered distinct and are not combined for revenue recognition purposes.

[0001045810-26-000021:mdna:51]
We allocate the total transaction price to each distinct performance obligation in an arrangement with multiple performance obligations on a relative standalone selling price basis. In most cases, we can establish standalone selling price based on directly observable prices of products or services sold separately in comparable circumstances to similar customers. If standalone selling price is not directly observable, such as when we do not sell a product or service separately, we determine standalone selling price based on market data and other observable inputs.

[0001045810-26-000021:mdna:52]
Results of Operations

[0001045810-26-000021:mdna:53]
A discussion regarding our financial condition and results of operations for fiscal year 2026 compared to fiscal year 2025 is presented below. A discussion regarding our financial condition and results of operations for fiscal year 2025 compared to fiscal year 2024 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025, filed with the SEC on February 26, 2025, which is available free of charge on the SEC’s website at http://www.sec.gov and at our investor relations website, http://investor.nvidia.com.

[0001045810-26-000021:mdna:54]
The following table sets forth, for the periods indicated, certain items in our Consolidated Statements of Income expressed as a percentage of revenue.

[0001045810-26-000021:mdna:55]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |
| Revenue | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 28.9 |  |  | 25.0 |  |
| Gross profit | 71.1 |  |  | 75.0 |  |
| Operating expenses |  |  |  |
| Research and development | 8.6 |  |  | 9.9 |  |
| Sales, general and administrative | 2.1 |  |  | 2.7 |  |
| Total operating expenses | 10.7 |  |  | 12.6 |  |
| Operating income | 60.4 |  |  | 62.4 |  |
| Interest income | 1.1 |  |  | 1.4 |  |
| Interest expense | (0.1) |  |  | (0.2) |  |
| Other income, net | 4.2 |  |  | 0.8 |  |
| Total other income, net | 5.2 |  |  | 2.0 |  |
| Income before income tax | 65.5 |  |  | 64.4 |  |
| Income tax expense | 9.9 |  |  | 8.6 |  |
| Net income | 55.6 | % |  | 55.8 | % |

[0001045810-26-000021:mdna:56]
Reportable Segments

[0001045810-26-000021:mdna:57]
Revenue by Reportable Segments

[0001045810-26-000021:mdna:58]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 193,479 |  |  | $ | 116,193 |  |  | $ | 77,286 |  |  | 67 | % |
| Graphics | 22,459 |  |  | 14,304 |  |  | 8,155 |  |  | 57 | % |
| Total | $ | 215,938 |  |  | $ | 130,497 |  |  | $ | 85,441 |  |  | 65 | % |

[0001045810-26-000021:mdna:59]
Operating Income by Reportable Segments

[0001045810-26-000021:mdna:60]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 130,141 |  |  | $ | 82,875 |  |  | $ | 47,266 |  |  | 57 | % |
| Graphics | 9,156 |  |  | 5,085 |  |  | 4,071 |  |  | 80 | % |
| Total | $ | 139,297 |  |  | $ | 87,960 |  |  | $ | 51,337 |  |  | 58 | % |

[0001045810-26-000021:mdna:61]
Compute & Networking revenue – The year over year increase was driven by the major platform shifts – accelerated computing and AI. Revenue from Data Center computing grew 59% driven by demand for our Blackwell computing platform. Revenue from Data Center networking grew 142% driven by the introduction and continued ramp of NVLink compute fabric for GB200 and GB300 systems and the growth of Ethernet and InfiniBand platforms.

[0001045810-26-000021:mdna:62]
Graphics revenue – The year over year increase was driven by sales of our Blackwell architecture.

[0001045810-26-000021:mdna:63]
Reportable segment operating income – The year over year increase in Compute & Networking segment operating income was driven by growth in revenue, partially offset by a $4.5 billion charge associated with H20 excess inventory and purchase obligations in the first quarter of fiscal year 2026. The year over year increase in Graphics segment operating income was driven by the growth in revenue.

[0001045810-26-000021:mdna:64]
Concentration of Revenue

[0001045810-26-000021:mdna:65]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, Neocloud builders, AI model makers, enterprises, and public sector entities. Our revenue is concentrated among a limited number of direct and indirect customers and this trend may continue.

[0001045810-26-000021:mdna:66]
Direct Customers – For fiscal year 2026, sales to one direct customer represented 22% of total revenue and sales to another direct customer represented 14% of total revenue, all of which were primarily attributable to the Compute & Networking segment.

[0001045810-26-000021:mdna:67]
For fiscal year 2025, sales to one direct customer represented 12% of total revenue and sales to two direct customers each represented 11% of total revenue, all of which were primarily attributable to the Compute & Networking segment.

[0001045810-26-000021:mdna:68]
For fiscal year 2024, sales to one direct customer represented 13% of total revenue, and were primarily attributable to the Compute & Networking segment.

[0001045810-26-000021:mdna:69]
Indirect Customers – Indirect customer revenue is an estimation based upon multiple factors including customer purchase order information, product specifications, internal sales data, and other sources. Indirect customers primarily purchase our products through system integrators and distributors. We generate a significant amount of our revenue from a limited number of indirect customers, some individually representing 10% or more of our revenue. Certain companies purchase cloud and related services through various direct and indirect customers. We estimate that one AI research and deployment company contributed to a meaningful amount of our revenue purchasing cloud services from our customers in fiscal year 2026.

[0001045810-26-000021:mdna:70]
Revenue by geographic region is designated based on the location of the headquarters of direct customers. The end customer and shipping location may be different from our customers' headquarters location. Revenue from sales to customers headquartered outside of the United States accounted for 31% and 41% of total revenue for fiscal years 2026 and 2025, respectively.

[0001045810-26-000021:mdna:71]
Gross Profit and Gross Margin

[0001045810-26-000021:mdna:72]
Gross profit consists of total net revenue less cost of revenue. Cost of revenue consists of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions, memory and component costs, tariffs, and shipping costs. Cost of revenue also includes acquisition-related intangible amortization expense, costs for license and development and service arrangements, IP-related costs, and stock-based compensation related to personnel associated with manufacturing operations.

[0001045810-26-000021:mdna:73]
Gross margins decreased to 71.1% in fiscal year 2026 from 75.0% in fiscal year 2025 as our business model transitioned from offering Hopper HGX systems to Blackwell full-scale datacenter solutions and a $4.5 billion charge associated with H20 excess inventory and purchase obligations in the first quarter of fiscal year 2026.

[0001045810-26-000021:mdna:74]
Provisions for inventory and excess inventory purchase obligations totaled $7.2 billion and $3.7 billion for fiscal years 2026 and 2025, respectively, including $4.5 billion associated with H20 excess inventory and purchase obligations for the first quarter of fiscal year 2026. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $1.5 billion and $689 million for fiscal years 2026 and 2025, respectively. The net effect on our gross margin was an unfavorable impact of 2.6% and 2.3% in fiscal years 2026 and 2025, respectively.

[0001045810-26-000021:mdna:75]
Operating Expenses

[0001045810-26-000021:mdna:76]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development | $ | 18,497 |  |  | $ | 12,914 |  |  | $ | 5,583 |  |  | 43 | % |
| Sales, general and administrative | 4,579 |  |  | 3,491 |  |  | 1,088 |  |  | 31 | % |
| Total operating expenses | $ | 23,076 |  |  | $ | 16,405 |  |  | $ | 6,671 |  |  | 41 | % |

[0001045810-26-000021:mdna:77]
The increases in research and development expenses for fiscal year 2026 were driven by a 29% increase in compensation and benefits expense, including stock-based compensation, reflecting employee growth and compensation increases and a 79% increase in compute and infrastructure.

[0001045810-26-000021:mdna:78]
41

[0001045810-26-000021:mdna:79]
The increases in sales, general and administrative expenses for fiscal year 2026 were primarily driven by compensation and benefits expense, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-26-000021:mdna:80]
Total Other Income, Net

[0001045810-26-000021:mdna:81]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | $Change |  |  |
|  | ($ in millions) |
| Interest income | $ | 2,300 |  |  | $ | 1,786 |  |  | $ | 514 |  |  |  |
| Interest expense | (259) |  |  | (247) |  |  | (12) |  |  |  |
| Other income, net | 9,022 |  |  | 1,034 |  |  | 7,988 |  |  |  |
| Total other income, net | $ | 11,063 |  |  | $ | 2,573 |  |  | $ | 8,490 |  |  |  |

[0001045810-26-000021:mdna:82]
The increase in interest income was primarily due to growth in cash, cash equivalents, and debt securities.

[0001045810-26-000021:mdna:83]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our notes.

[0001045810-26-000021:mdna:84]
Other income, net primarily consists of realized or unrealized gains and losses from investments in non-marketable equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other income, net, compared to fiscal year 2025, was primarily driven by unrealized gains in non-marketable and publicly-held equity securities, including gains from our previously announced investment in Intel’s common stock. Refer to Note 7 and 8 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information regarding our non-marketable equity securities.

[0001045810-26-000021:mdna:85]
Income Taxes

[0001045810-26-000021:mdna:86]
Income tax expense was $21.4 billion and $11.1 billion for fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 15.1% and 13.3% for fiscal years 2026 and 2025, respectively.

[0001045810-26-000021:mdna:87]
The effective tax rate increased primarily due to a lower percentage of tax benefits from stock-based compensation, FDDEI, and U.S. federal research tax credit relative to the increase in income before income tax.

[0001045810-26-000021:mdna:88]
Our effective tax rates for fiscal years 2026 and 2025 were lower than the U.S. federal statutory rate of 21.0% primarily due to tax benefits from FDDEI, stock-based compensation, income earned in jurisdictions that are subject to taxes at rates lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit.

[0001045810-26-000021:mdna:89]
In July 2025, the One Big Beautiful Bill Act (OBBBA) was enacted into law and contains several changes to key U.S. federal income tax laws. We have recognized the tax effects of currently effective OBBBA provisions in our results for fiscal year 2026. We will continue to evaluate the impact of these legislative changes as tax authorities provide additional guidance and interpretation.

[0001045810-26-000021:mdna:90]
As of January 25, 2026, based on recent jurisdictional taxable income and expected future earnings, we concluded certain state deferred tax assets are more likely than not realizable and released $711 million of valuation allowance.

[0001045810-26-000021:mdna:91]
Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-26-000021:mdna:92]
Liquidity and Capital Resources

[0001045810-26-000021:mdna:93]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | (In millions) |
| Cash and cash equivalents | $ | 10,605 |  |  | $ | 8,589 |  |
| Marketable securities | 51,951 |  |  | 34,621 |  |
| Cash, cash equivalents, and marketable securities | $ | 62,556 |  |  | $ | 43,210 |  |

[0001045810-26-000021:mdna:94]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 102,718 |  |  | $ | 64,089 |  |
| Net cash used in investing activities | $ | (52,228) |  |  | $ | (20,421) |  |
| Net cash used in financing activities | $ | (48,474) |  |  | $ | (42,359) |  |

[0001045810-26-000021:mdna:95]
Our fixed income security investments include highly rated, diversified investment types and credit exposures with shorter maturities.

[0001045810-26-000021:mdna:96]
Cash provided by operating activities increased in fiscal year 2026 compared to fiscal year 2025, due to higher revenue.

[0001045810-26-000021:mdna:97]
Cash used in investing activities increased in fiscal year 2026 compared to fiscal year 2025, primarily driven by higher purchases of equity investment securities and the execution of a non-exclusive license agreement with Groq.

[0001045810-26-000021:mdna:98]
Cash used in financing activities increased in fiscal year 2026 compared to fiscal year 2025, mainly due to higher share repurchases.

[0001045810-26-000021:mdna:99]
Liquidity

[0001045810-26-000021:mdna:100]
Our primary sources of liquidity include cash, cash equivalents, marketable securities, and cash generated by our operations. As of January 25, 2026, we had $62.6 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and for the foreseeable future, including our future obligations. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-26-000021:mdna:101]
Our marketable securities consist of publicly-held equity securities, debt securities issued by the U.S. government and its agencies, highly-rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly-rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-26-000021:mdna:102]
Except for approximately $1.7 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. at the end of fiscal year 2026 are available for use in the U.S. without incurring additional U.S. federal income taxes. Our first quarter of any fiscal year (including fiscal year 2027) generally does not include any estimated federal and state income tax payments and our second quarter of any fiscal year (including fiscal year 2027) generally includes two estimated federal and state income tax payments.

[0001045810-26-000021:mdna:103]
Capital Return to Shareholders

[0001045810-26-000021:mdna:104]
On August 26, 2025, our Board of Directors approved an additional $60.0 billion in share repurchase authorization, without expiration. In fiscal year 2026, we repurchased 282 million shares of our common stock for $40.4 billion. As of January 25, 2026, we were authorized, subject to certain specifications, to repurchase up to $58.5 billion of our common stock.

[0001045810-26-000021:mdna:105]
From January 26, 2026 through February 20, 2026, we repurchased 8 million shares for $1.5 billion pursuant to a pre-established trading plan. We may execute repurchases from time to time, subject to market conditions, operating requirements, and other investment opportunities, in the open market, in privately negotiated transactions, pursuant to a Rule 10b5-1 trading plan or in structured share repurchase agreements in compliance with Rule 10b-18 of the Exchange Act. Our share repurchase program may be suspended at any time at our discretion.

[0001045810-26-000021:mdna:106]
In fiscal year 2026, we paid cash dividends to our shareholders of $974 million. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.

[0001045810-26-000021:mdna:107]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for fiscal years 2026 and 2025.

[0001045810-26-000021:mdna:108]
43

[0001045810-26-000021:mdna:109]
Outstanding Indebtedness and Commercial Paper Program

[0001045810-26-000021:mdna:110]
Our aggregate debt maturities as of January 25, 2026, by year payable, are as follows:

[0001045810-26-000021:mdna:111]
|  |  | Jan 25, 2026 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,000 |  |
| Due in one to five years |  | 2,750 |  |
| Due in five to ten years |  | 1,250 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (32) |  |
| Net carrying amount |  | $ | 8,468 |  |
| Less short-term portion |  | 999 |  |
| Total long-term portion |  | $ | 7,469 |  |

[0001045810-26-000021:mdna:112]
In January 2026, we increased the amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes from time to time or all at once up to $25.0 billion. As of January 25, 2026, no commercial paper was outstanding. We will continue to evaluate issuing commercial paper as a component of our overall liquidity strategy.

[0001045810-26-000021:mdna:113]
Refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-26-000021:mdna:114]
Material Cash Requirements and Other Obligations

[0001045810-26-000021:mdna:115]
For descriptions of our facility lease guarantees, long-term debt, purchase commitments, and operating lease obligations, refer to Note 10, Note 11, Note 12, and Note 17 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K, respectively.

[0001045810-26-000021:mdna:116]
We expect to continue investing in our ecosystem. We are finalizing an investment and partnership agreement with OpenAI. There is no assurance that we will enter into an investment and partnership agreement with OpenAI or that a transaction will be completed. Refer to Item 1A. Risk Factors for additional information regarding our investments.

[0001045810-26-000021:mdna:117]
During fiscal year 2026 and fiscal year 2025, we spent $6.1 billion and $3.4 billion on capital expenditures, respectively. We expect to increase capital expenditures in fiscal year 2027 relative to fiscal year 2026 to support the future growth of our business.

[0001045810-26-000021:mdna:118]
Unrecognized tax benefits of $4.0 billion, which includes related interest and penalties of $374 million, were recorded in non-current income tax payable at the end of fiscal year 2026. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2023 and 2024. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further information.

[0001045810-26-000021:mdna:119]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-26-000021:mdna:120]
Refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a discussion of adoption of new and recently issued accounting pronouncements.
