# NVDA 10-K controls and the auditor's report


## auditors_report

[0001045810-26-000021:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001045810-26-000021:auditors_report:2]
To the Board of Directors and Shareholders of NVIDIA Corporation

[0001045810-26-000021:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001045810-26-000021:auditors_report:4]
We have audited the accompanying consolidated balance sheets of NVIDIA Corporation and its subsidiaries (the “Company”) as of January 25, 2026 and January 26, 2025, and the related consolidated statements of income, comprehensive income, shareholders' equity, and cash flows for each of the three years in the period ended January 25, 2026, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of January 25, 2026, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001045810-26-000021:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 25, 2026 and January 26, 2025, and the results of its operations and its cash flows for each of the three years in the period ended January 25, 2026 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of January 25, 2026, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001045810-26-000021:auditors_report:6]
Basis for Opinions

[0001045810-26-000021:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Annual Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001045810-26-000021:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001045810-26-000021:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001045810-26-000021:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0001045810-26-000021:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001045810-26-000021:auditors_report:12]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001045810-26-000021:auditors_report:13]
49

[0001045810-26-000021:auditors_report:14]
Critical Audit Matters

[0001045810-26-000021:auditors_report:15]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001045810-26-000021:auditors_report:16]
Valuation of Inventories - Provisions for Excess or Obsolete Inventories and Excess Product Purchase Commitments

[0001045810-26-000021:auditors_report:17]
As described in Notes 1, 9, and 12 to the consolidated financial statements, the Company charges cost of sales for inventory provisions to write-down inventory for excess or obsolete inventory and for excess product purchase commitments. Most of the Company’s inventory provisions relate to excess quantities of products, based on the Company’s inventory levels and future product purchase commitments compared to assumptions about future demand including the impact of market conditions such as regulatory export restrictions on their products. As of January 25, 2026, the Company’s consolidated inventories balance was $21.4 billion and the Company’s consolidated outstanding inventory purchase and long-term supply and capacity obligations balance was $95.2 billion, of which a significant portion relates to inventory purchase obligations.

[0001045810-26-000021:auditors_report:18]
The principal considerations for our determination that performing procedures relating to the valuation of inventories, specifically the provisions for excess or obsolete inventories and excess product purchase commitments, is a critical audit matter are the significant judgment by management when developing provisions for excess or obsolete inventories and excess product purchase commitments, including developing assumptions related to future demand and market conditions. This in turn led to significant auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s assumptions related to future demand and market conditions.

[0001045810-26-000021:auditors_report:19]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s provisions for excess or obsolete inventories and excess product purchase commitments, including controls over management’s assumptions related to future demand and market conditions. These procedures also included, among others, testing management’s process for developing the provisions for excess or obsolete inventories and excess product purchase commitments; evaluating the appropriateness of management’s approach; testing the completeness and accuracy of underlying data used in the approach; and evaluating the reasonableness of management’s assumptions related to future demand and market conditions. Evaluating management’s assumptions related to future demand and market conditions involved evaluating whether the assumptions used by management were reasonable considering (i) current and past results, including historical product life cycle, (ii) the consistency with external market and industry data, and (iii) changes in technology.

[0001045810-26-000021:auditors_report:20]
/s/PricewaterhouseCoopers LLP

[0001045810-26-000021:auditors_report:21]
San Jose, California

[0001045810-26-000021:auditors_report:22]
February 25, 2026

[0001045810-26-000021:auditors_report:23]
We have served as the Company’s auditor since 2004.

[0001045810-26-000021:auditors_report:24]
50

[0001045810-26-000021:auditors_report:25]
NVIDIA Corporation and Subsidiaries


## item_9a

[0001045810-26-000021:item_9a:1]
Item 9A. Controls and Procedures

[0001045810-26-000021:item_9a:2]
Controls and Procedures

[0001045810-26-000021:item_9a:3]
Disclosure Controls and Procedures

[0001045810-26-000021:item_9a:4]
Based on their evaluation as of January 25, 2026, our management, including our Chief Executive Officer and Chief Financial Officer, has concluded that our disclosure controls and procedures (as defined in Rule 13a-15(e) under the Exchange Act) were effective to provide reasonable assurance that the information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC rules and forms, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosures.

[0001045810-26-000021:item_9a:5]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001045810-26-000021:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our

[0001045810-26-000021:item_9a:7]
45

[0001045810-26-000021:item_9a:8]
management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 25, 2026 based on the criteria set forth in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under the criteria set forth in Internal Control — Integrated Framework, our management concluded that our internal control over financial reporting was effective as of January 25, 2026.

[0001045810-26-000021:item_9a:9]
The effectiveness of our internal control over financial reporting as of January 25, 2026 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in its report which is included herein.

[0001045810-26-000021:item_9a:10]
Changes in Internal Control Over Financial Reporting

[0001045810-26-000021:item_9a:11]
There have been no changes in our internal control over financial reporting during the quarter ended January 25, 2026 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. We are continuing a phased upgrade of our enterprise resource planning, or ERP, system to update our existing core financial systems. The ERP system is designed to accurately maintain our financial records used to report operating results. We will continue to evaluate each quarter whether there are changes that materially affect our internal control over financial reporting.

[0001045810-26-000021:item_9a:12]
Inherent Limitations on Effectiveness of Controls

[0001045810-26-000021:item_9a:13]
Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.
