# NVDA notes — 0001045810-26-000021


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001045810-26-000021:notes:1]
Portions of the registrant's Proxy Statement for its 2026 Annual Meeting of Shareholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated by reference into Part III, Items 10-14 of this Annual Report on Form 10-K.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001045810-26-000021:notes:2]
We have in place certain infrastructure, systems, policies, and procedures that are designed to proactively prevent or reduce the impact of, and reactively address circumstances that arise when, events such as a cybersecurity incident occur. These include processes for assessing, identifying, and managing material risks from cybersecurity threats. Our information security management programs generally follow certain processes outlined in frameworks such as the ISO 27001 international standard for information security management and we evaluate and evolve our security measures as appropriate. We consult with external parties, such as cybersecurity firms and risk management and governance experts, on risk management and strategy.

[0001045810-26-000021:notes:3]
Identifying, assessing, and managing cybersecurity risk is integrated into our overall risk management systems and processes, and we have in place cybersecurity and data privacy training and policies designed to (a) respond to new requirements in global privacy and cybersecurity laws and (b) prevent, detect, respond to, mitigate and recover from identified and significant cybersecurity threats.

[0001045810-26-000021:notes:4]
We also have a vendor risk assessment process consisting of, depending on the nature and sensitivity of the supplier and data they process on our behalf, the distribution and review of supplier questionnaires designed to help us evaluate cybersecurity risks that we may encounter when working with third parties that have access to confidential and other sensitive company information. We take steps to review that such vendors have implemented data privacy and security controls that help mitigate the cybersecurity risks associated with these vendors, depending on the nature and sensitivity of the supplier and data they process on our behalf. We routinely assess our high-risk suppliers’ conformance to industry standards (e.g., ISO 27001, ISO 28001, and C-TPAT), and we evaluate them for additional information, product, and physical security requirements.

[0001045810-26-000021:notes:5]
Refer to “Item 1A. Risk factors” in this annual report on Form 10-K for additional information about cybersecurity-related risks.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001045810-26-000021:notes:6]
Information security matters, including managing and assessing risks from cybersecurity threats, remain under the oversight of the Company’s Board of Directors, or the Board. The Audit Committee of the Board, or the Audit Committee, also reviews the adequacy and effectiveness of the Company’s information security policies and practices and the internal controls regarding information security risks. The Audit Committee receives regular information security updates from management, including our Chief Security Officer and members of our security team. The Board also receives annual reports on information security matters from our Chief Security Officer and members of our security team.

[0001045810-26-000021:notes:7]
Our security efforts are managed by a team of executive cybersecurity, IT, engineering, operations, and legal professionals. We have established a cross-functional leadership team, consisting of executive-level leaders, that meets regularly to review cybersecurity matters and evaluate emerging threats. With oversight and guidance provided by the cross-functional leadership team, our information security teams refine our practices to address emerging security risks and changes in regulations. Our executive-level leadership team also participates in cybersecurity incident response efforts by engaging with the incident response team and helping direct the company’s response to and assessment of certain cybersecurity incidents.

[0001045810-26-000021:notes:8]
We have designated a Chief Security Officer, reporting to our Senior Vice President of Software Engineering, to oversee the identification, assessment, and management of material cybersecurity risks. Our Chief Security Officer’s cybersecurity expertise includes over 18 years of combined government and private sector assignments.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-26-000021:notes:9]
The following members of our Board of Directors and/or officers adopted, modified or terminated a trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c), or a Rule 10b5-1 Trading Arrangement:

[0001045810-26-000021:notes:10]
| Name |  | Title of Director or Officer |  | Action |  | Date |  | Total Shares of Common Stock to be Sold |  | Expiration Date |
| John O. Dabiri |  | Director |  | Adoption |  | 12/10/2025 |  | 3,984* |  | 12/7/2026 |
| Colette M. Kress |  | Executive Vice President and Chief Financial Officer |  | Adoption |  | 12/18/2025 |  | 500,000 |  | 3/23/2027 |

[0001045810-26-000021:notes:11]
*Estimated assuming our closing stock price as of January 23, 2026. The number of shares is based on an estimate because the plan specifies a formulaic dollar amount of shares to be sold.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-26-000021:notes:12]
Organization and Summary of Significant Accounting Policies
Our Company

[0001045810-26-000021:notes:13]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-26-000021:notes:14]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-26-000021:notes:15]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation. Non-marketable equity securities, previously presented within other assets, were reclassified to be presented separately on our consolidated balance sheets and had no impact to total assets or consolidated statement of cash flows.

[0001045810-26-000021:notes:16]
Fiscal Year

[0001045810-26-000021:notes:17]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2026, 2025 and 2024 were all 52-week years. Fiscal year 2027 will be a 53-week year with the fourth quarter consisting of 14 weeks.

[0001045810-26-000021:notes:18]
Principles of Consolidation

[0001045810-26-000021:notes:19]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-26-000021:notes:20]
Use of Estimates

[0001045810-26-000021:notes:21]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, non-marketable equity securities, other contingencies, property, plant, and equipment, revenue recognition, and stock-based compensation. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-26-000021:notes:22]
Revenue Recognition

[0001045810-26-000021:notes:23]
We derive our revenue primarily from product sales including hardware and systems. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract (where revenue is allocated on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation); and (5) recognition of revenue when, or as, we satisfy a performance obligation. Payment from customers, per our standard payment terms, is generally due shortly after delivery of our products.

[0001045810-26-000021:notes:24]
Product Sales Revenue

[0001045810-26-000021:notes:25]
Revenue from product sales is recognized upon transfer of control of products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Certain products are sold with support or an extended warranty. Support and extended warranty revenue are recognized ratably over the service period, or as services are performed. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-26-000021:notes:26]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to accurately reflect our estimated exposure for product returns.

[0001045810-26-000021:notes:27]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and MDFs which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for such programs for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-26-000021:notes:28]
Contracts with Multiple Performance Obligations

[0001045810-26-000021:notes:29]
Our contracts may contain more than one deliverable, each of which is separately accounted for as a distinct performance obligation. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001045810-26-000021:notes:30]
We allocate the total transaction price to each distinct performance obligation in an arrangement with multiple performance obligations on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers. When determining standalone selling price, we maximize the use of observable inputs.

[0001045810-26-000021:notes:31]
Product Warranties

[0001045810-26-000021:notes:32]
We offer a limited warranty to end-users ranging from one to three years for products to repair or replace products for manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-26-000021:notes:33]
Stock-based Compensation

[0001045810-26-000021:notes:34]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units, or PSUs, that are based on our corporate financial performance targets. We use a Monte Carlo simulation on the date of grant to estimate the fair value of PSUs that are based on our stock performance compared to market performance, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model based on performance targets probable of achievement. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, for RSUs, PSUs, and market-based PSUs, we estimate expected forfeitures based on our historical forfeitures.

[0001045810-26-000021:notes:35]
Litigation, Investigation and Settlement Costs

[0001045810-26-000021:notes:36]
We currently are, and will likely continue to be subject to claims, litigation, and other actions, including potential regulatory proceedings, involving patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, commercial disputes, goods and services offered by us and by third parties, and other matters. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments or judgments. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs. If we determine that a loss is reasonably possible and the loss or range of loss can be estimated, we disclose the reasonably possible loss.

[0001045810-26-000021:notes:37]
Foreign Currency Remeasurement

[0001045810-26-000021:notes:38]
We use the U.S. dollar as our functional currency for our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at exchange rates in effect during each period, except for those expenses related to non-monetary balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in earnings in our Consolidated Statements of Income and to date have not been significant.

[0001045810-26-000021:notes:39]
Income Taxes

[0001045810-26-000021:notes:40]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-26-000021:notes:41]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change

[0001045810-26-000021:notes:42]
based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the U.S., or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential U.S. and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-26-000021:notes:43]
As of January 25, 2026, we had a valuation allowance of $768 million related to capital loss carryforwards, and certain other deferred tax assets that management determined are not likely to be realized due, in part, to jurisdictional projections of future taxable income, including capital gains. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-26-000021:notes:44]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-26-000021:notes:45]
Net Income Per Share

[0001045810-26-000021:notes:46]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Any anti-dilutive effect of equity awards outstanding is not included in the computation of diluted net income per share.

[0001045810-26-000021:notes:47]
Cash and Cash Equivalents and Marketable Securities

[0001045810-26-000021:notes:48]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. Marketable securities consist of highly liquid debt investments with maturities of greater than three months when purchased and publicly-held equity securities. We classify these investments as current or long term based on the nature of the investments and their availability for use in current operations.

[0001045810-26-000021:notes:49]
We record our debt investments as cash equivalents and marketable debt securities and classify them at the date of acquisition as available-for-sale. These available-for-sale debt securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. The fair value of interest-bearing debt securities includes accrued interest. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the Other income (expense), net, section of our Consolidated Statements of Income.

[0001045810-26-000021:notes:50]
Available-for-sale debt securities are subject to impairment review. If the estimated fair value of available-for-sale debt securities is less than its amortized cost basis, we determine if the difference, if any, is caused by expected credit losses and write-down the amortized cost basis of the securities if it is more likely than not we will be required or we intend to sell the securities before recovery of its amortized cost basis. Allowances for credit losses and write-downs are recognized in the Other income, net, net section of our Consolidated Statements of Income.

[0001045810-26-000021:notes:51]
Publicly-held equity securities and money market funds have readily determinable fair values with changes in fair value recorded in Other income, net.

[0001045810-26-000021:notes:52]
Fair Value of Financial Instruments

[0001045810-26-000021:notes:53]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 25, 2026 and January 26, 2025. Marketable debt and equity securities are reported at fair value. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as accounting hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings. For derivative instruments not designated as accounting hedges, changes in fair value are recognized in earnings.

[0001045810-26-000021:notes:54]
Financial instruments measured and disclosed at fair value are classified and disclosed based on the observability of inputs used in the determination of fair value as follows:

[0001045810-26-000021:notes:55]
•Level 1: Observable inputs such as quoted prices in active markets.

[0001045810-26-000021:notes:56]
•Level 2: Observable inputs other than Level 1 prices, such as quoted prices in less active markets or model-derived valuations that are observable either directly or indirectly.

[0001045810-26-000021:notes:57]
•Level 3: Unobservable inputs in which there is little or no market data that are significant to the fair value of the assets or liabilities.

[0001045810-26-000021:notes:58]
Concentration of Credit Risk

[0001045810-26-000021:notes:59]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, lease guarantees, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio maturities. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-26-000021:notes:60]
Inventories

[0001045810-26-000021:notes:61]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory, and for excess product purchase commitments. Most of our inventory provisions relate to excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand including the impact of regulatory export restrictions on our products. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up. We record a liability for noncancelable purchase commitments with suppliers for quantities in excess of our future demand forecasts consistent with our valuation of obsolete or excess inventory.

[0001045810-26-000021:notes:62]
Property and Equipment

[0001045810-26-000021:notes:63]
Property and equipment are stated at cost less accumulated depreciation. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets of two to seven years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization of assets recorded under finance leases. Leasehold improvements and assets recorded under finance leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.

[0001045810-26-000021:notes:64]
Leases

[0001045810-26-000021:notes:65]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term. We combine lease and non-lease components for offices and data centers in determining the operating lease assets and liabilities.

[0001045810-26-000021:notes:66]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease costs are recognized on a straight-line basis over the lease term.

[0001045810-26-000021:notes:67]
Goodwill

[0001045810-26-000021:notes:68]
We allocate goodwill to reporting units based on the expected benefit from the business combination. Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist. In completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-26-000021:notes:69]
Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting units. Goodwill impairments were not identified for the periods presented.

[0001045810-26-000021:notes:70]
Intangible Assets and Other Long-Lived Assets

[0001045810-26-000021:notes:71]
Intangible assets primarily represent acquired intangible assets including developed technology and customer relationships, as well as rights acquired under technology licenses, patents, and acquired IP. We currently amortize our intangible assets with finite lives over periods ranging from one to twenty years using a method that reflects the pattern

[0001045810-26-000021:notes:72]
in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.

[0001045810-26-000021:notes:73]
Long-lived assets, such as property and equipment and intangible assets subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. The recoverability of assets or asset groups to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.

[0001045810-26-000021:notes:74]
Business Combination

[0001045810-26-000021:notes:75]
The Company applies a screen test to evaluate if substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets to determine whether a transaction is accounted for as an asset acquisition or business combination. We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the measurement period's conclusion or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our Consolidated Statements of Income.

[0001045810-26-000021:notes:76]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

[0001045810-26-000021:notes:77]
Non-Marketable Equity Securities

[0001045810-26-000021:notes:78]
Non-marketable equity securities consist of investments in privately-held companies that do not have a readily determinable fair value. These investments are measured at cost minus impairment, if any, and are adjusted for changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer, or the measurement alternative. Fair value is based upon observable inputs in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. All gains and losses on these investments, realized and unrealized, are recognized in Other income, net on our Consolidated Statements of Income.

[0001045810-26-000021:notes:79]
We assess whether an impairment loss has occurred on our investments in non-marketable equity securities, accounted for under the measurement alternative based on quantitative and qualitative factors. If any impairment is identified for non-marketable equity securities, we write down the investment to its fair value and record the corresponding charge through Other income, net on our Consolidated Statements of Income.

[0001045810-26-000021:notes:80]
The Company assesses its investments for significant influence to determine the appropriate method of accounting, including application of the equity method. Equity method investments were not material.

[0001045810-26-000021:notes:81]
Recently Issued Accounting Pronouncements

[0001045810-26-000021:notes:82]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-26-000021:notes:83]
In November 2024, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-26-000021:notes:84]
Groq
In December 2025, we entered into a non‑exclusive license agreement with Groq, Inc., or Groq, for its language processing unit technology and hired certain Groq employees. No customer contracts, existing products, or equity interests were purchased. We recorded $14.4 billion of goodwill and a $2.5 billion developed technology intangible asset, valued using a cost‑to‑recreate methodology with a five‑year useful life. Goodwill, primarily attributable to the workforce and future development of the licensed technology, was recorded in the Compute & Networking reporting unit. Total consideration consists of $13.0 billion paid at closing and $4 billion, inclusive of imputed interest, payable within one year included in Accrued and Other Current Liabilities on our Consolidated Balance Sheets. The goodwill is tax deductible. Pro forma results of operations have not been presented because the effect was not material.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-26-000021:notes:85]
Stock-Based Compensation
We recognize stock-based compensation expense from grants of restricted stock units, or RSUs, performance stock units, or PSUs, and market-based PSUs, and issuances under our employee stock purchase plan, or ESPP.

[0001045810-26-000021:notes:86]
Consolidated Statements of Income include stock-based compensation expense as follows:

[0001045810-26-000021:notes:87]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Cost of revenue | $ | 261 |  |  | $ | 178 |  |  | $ | 141 |  |
| Research and development | 4,676 |  |  | 3,423 |  |  | 2,532 |  |
| Sales, general and administrative | 1,449 |  |  | 1,136 |  |  | 876 |  |
| Total | $ | 6,386 |  |  | $ | 4,737 |  |  | $ | 3,549 |  |

[0001045810-26-000021:notes:88]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-26-000021:notes:89]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 70 |  |  | 89 |  |  | 140 |  |
| Estimated total grant-date fair value | $ | 9,389 |  |  | $ | 7,834 |  |  | $ | 5,316 |  |
| Weighted average grant-date fair value per share | $ | 133.97 |  |  | $ | 87.99 |  |  | $ | 37.41 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 13 |  |  | 30 |  |  | 30 |  |
| Weighted average price per share | $ | 49.13 |  |  | $ | 17.74 |  |  | $ | 15.81 |  |
| Weighted average grant-date fair value per share | $ | 20.75 |  |  | $ | 8.61 |  |  | $ | 6.99 |  |

[0001045810-26-000021:notes:90]
As of January 25, 2026, aggregate unearned stock-based compensation expense was $14.8 billion, which is expected to be recognized over a weighted average period of 2.3 years for RSUs, PSUs, and market-based PSUs, and 0.9 years for ESPP.

[0001045810-26-000021:notes:91]
The fair value of shares issued under our ESPP has been estimated with the following assumptions:

[0001045810-26-000021:notes:92]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.1-2.0 |  | 0.1-2.0 |  | 0.1-2.0 |
| Risk-free interest rate | 3.5%-4.3% |  | 3.6%-5.4% |  | 3.9%-5.5% |
| Volatility | 26%-96% |  | 31%-75% |  | 31%-67% |
| Dividend yield | 0.03% |  | 0.03% |  | 0.06% |

[0001045810-26-000021:notes:93]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSUs, PSUs, and market-based PSUs are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-26-000021:notes:94]
Additionally, for RSUs, PSUs, and market-based PSUs, we estimate expected forfeitures based on our historical forfeitures.

[0001045810-26-000021:notes:95]
Equity Incentive Program

[0001045810-26-000021:notes:96]
We grant RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans. In addition, in connection with our acquisitions of various companies, we have assumed certain stock-based awards granted under their stock incentive plans and converted them into our RSUs.

[0001045810-26-000021:notes:97]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-26-000021:notes:98]
The NVIDIA Corporation Amended and Restated 2007 Equity Incentive Plan, or the 2007 Plan, authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, RSUs, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. We grant RSUs, PSUs and market-based PSUs under the 2007 Plan. As of January 25, 2026, up to 192 million shares of our common stock could be issued pursuant to stock awards granted under the 2007 Plan, and 1.3 billion shares were available for future grants.

[0001045810-26-000021:notes:99]
Subject to certain exceptions, RSUs vest generally over four years subject to continued service. PSUs vest over four years, subject to continued service and performance conditions. Market-based PSUs vest on approximately the third anniversary of the date of grant subject to market conditions. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-26-000021:notes:100]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-26-000021:notes:101]
Employees who participate in the NVIDIA Corporation Amended and Restated 2012 Employee Stock Purchase Plan, or as most recently amended and restated, the 2012 Plan, may have up to 25% of their earnings withheld to purchase shares of common stock. The Board may decrease this percentage at its discretion. Each offering period is about 24 months, divided into four purchase periods of six months. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period or the fair market value of the common stock on each purchase date within the offering. As of January 25, 2026, we had 2.2 billion shares reserved for future issuance under the 2012 Plan.

[0001045810-26-000021:notes:102]
Equity Award Activity

[0001045810-26-000021:notes:103]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-26-000021:notes:104]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balance as of Jan 26, 2025 | 274 |  |  | $ | 44.75 |  |
| Granted | 70 |  |  | $ | 133.97 |  |
| Vested | (146) |  |  | $ | 39.14 |  |
| Canceled and forfeited | (9) |  |  | $ | 59.29 |  |
| Balance as of Jan 25, 2026 | 189 |  |  | $ | 81.51 |  |
| Vested and expected to vest after Jan 25, 2026 | 188 |  |  | $ | 81.15 |  |

[0001045810-26-000021:notes:105]
As of January 25, 2026 and January 26, 2025, there were 1.3 billion and 1.4 billion shares, respectively, of common stock available for future grants under our equity incentive plans.

[0001045810-26-000021:notes:106]
The total fair value of RSUs and PSUs, as of their respective vesting dates, during the years ended January 25, 2026, January 26, 2025, and January 28, 2024, was $22.2 billion, $15.1 billion, and $8.2 billion, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-26-000021:notes:107]
Net Income Per Share
The following is the basic and diluted net income per share computations for the periods presented:

[0001045810-26-000021:notes:108]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 120,067 |  |  | $ | 72,880 |  |  | $ | 29,760 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 24,359 |  |  | 24,555 |  |  | 24,690 |  |
| Dilutive impact of outstanding equity awards | 155 |  |  | 249 |  |  | 250 |  |
| Diluted weighted average shares | 24,514 |  |  | 24,804 |  |  | 24,940 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 4.93 |  |  | $ | 2.97 |  |  | $ | 1.21 |  |
| Diluted (2) | $ | 4.90 |  |  | $ | 2.94 |  |  | $ | 1.19 |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 41 |  |  | 51 |  |  | 150 |  |

[0001045810-26-000021:notes:109]
(1)    Net income divided by basic weighted average shares.

[0001045810-26-000021:notes:110]
(2)    Net income divided by diluted weighted average shares.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-26-000021:notes:111]
Goodwill
As of January 25, 2026, the total carrying amount of goodwill was $20.8 billion, consisting of goodwill balances allocated to our Compute & Networking and Graphics reporting units of $20.5 billion and $370 million, respectively. As of January 26, 2025, the total carrying amount of goodwill was $5.2 billion, consisting of goodwill balances allocated to our Compute & Networking and Graphics reporting units of $4.8 billion and $370 million, respectively. Goodwill increased by $15.6 billion in fiscal year 2026 and was allocated to our Compute & Networking reporting unit. During the fourth quarters of fiscal years 2026, 2025, and 2024, we completed our annual qualitative impairment tests and concluded that goodwill was not impaired.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-26-000021:notes:112]
Amortizable Intangible Assets
The components of our amortizable intangible assets are as follows:

[0001045810-26-000021:notes:113]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 5,656 |  |  | $ | (2,580) |  |  | $ | 3,076 |  |  | $ | 2,900 |  |  | $ | (2,264) |  |  | $ | 636 |  |
| Patents and licensed technology | 528 |  |  | (298) |  |  | 230 |  |  | 449 |  |  | (278) |  |  | 171 |  |
| Total intangible assets | $ | 6,184 |  |  | $ | (2,878) |  |  | $ | 3,306 |  |  | $ | 3,349 |  |  | $ | (2,542) |  |  | $ | 807 |  |

[0001045810-26-000021:notes:114]
Amortization expense associated with intangible assets for fiscal years 2026, 2025, and 2024 was $488 million, $593 million, and $614 million, respectively.

[0001045810-26-000021:notes:115]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of January 25, 2026:

[0001045810-26-000021:notes:116]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2027 | $ | 923 |  |
| 2028 | 729 |  |
| 2029 | 592 |  |
| 2030 | 511 |  |
| 2031 | 468 |  |
| 2032 and thereafter | 83 |  |
| Total | $ | 3,306 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-26-000021:notes:117]
Cash Equivalents and Marketable Securities
The fair values of our financial assets are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis. The following is a summary of cash equivalents and marketable securities:

[0001045810-26-000021:notes:118]
|  | Jan 25, 2026 |  |  |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,635 |  |  | $ | 77 |  |  | $ | (3) |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | 21,709 |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,410 |  |  | 92 |  |  | (3) |  |  | 15,499 |  |  | 345 |  |  | 15,154 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,157 |  |  | 4 |  |  | — |  |  | 2,161 |  |  | — |  |  | 2,161 |  |  | — |  |
| Certificates of deposit | Level 2 | 110 |  |  | — |  |  | — |  |  | 110 |  |  | 110 |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |
| Money market funds | Level 1 | 7,830 |  |  | — |  |  | — |  |  | 7,830 |  |  | 7,830 |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 17,726 |  |  | — |  |  | 12,886 |  |  | 4,840 |  |
| Total |  | $ | 47,182 |  |  | $ | 174 |  |  | $ | (6) |  |  | $ | 65,076 |  |  | $ | 8,285 |  |  | $ | 51,951 |  |  | $ | 4,840 |  |

[0001045810-26-000021:notes:119]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading. The balance as of January 25, 2026 includes $10.5 billion of investments which are subject to short-term lock-up restrictions on the ability to sell.

[0001045810-26-000021:notes:120]
(2)    The long-term portion of marketable equity securities, which are subject to lock-up restrictions through December 2027 of $4.8 billion as of January 25, 2026, is included in other assets.

[0001045810-26-000021:notes:121]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $6.6 billion for fiscal year 2026. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for fiscal years 2025 and 2024.

[0001045810-26-000021:notes:122]
Net realized gains on investments in publicly-held equity securities sold were not significant for fiscal years 2026, 2025, and 2024, reflecting the difference between the sale proceeds and the carrying value of the equity securities at the beginning of the period or the purchase date, if later.

[0001045810-26-000021:notes:123]
|  | Jan 26, 2025 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

[0001045810-26-000021:notes:124]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-26-000021:notes:125]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | Less than 12 Months |  | Less than 12 Months |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 10,666 |  |  | $ | (3) |  |  | $ | 6,315 |  |  | $ | (22) |  |
| Corporate debt securities | 1,332 |  |  | (3) |  |  | 5,291 |  |  | (29) |  |
| Debt securities issued by U.S. government agencies | 1,134 |  |  | — |  |  | 816 |  |  | (5) |  |
| Total | $ | 13,132 |  |  | $ | (6) |  |  | $ | 12,422 |  |  | $ | (56) |  |

[0001045810-26-000021:notes:126]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater as of January 25, 2026 and January 26, 2025 were not significant. Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-26-000021:notes:127]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-26-000021:notes:128]
|  | Jan 25, 2026 |
|  | (In millions) |
| Less than one year | $ | 20,427 |  |
| Due in 1 - 5 years | 19,093 |  |
| Total | $ | 39,520 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-26-000021:notes:129]
The following is a summary of cash equivalents and marketable securities:


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-26-000021:notes:130]
Non-marketable Equity Securities
Our non-marketable equity securities are valued under the measurement alternative applying valuation methods based on observable transactions for similar investments of the same issuer and unobservable inputs such as volatility, expected

[0001045810-26-000021:notes:131]
time to liquidity, risk free rate and security-specific rights and obligations. Gains and losses on these investments, realized and unrealized, are recognized in Other income, net on our Consolidated Statements of Income.

[0001045810-26-000021:notes:132]
Adjustments to the carrying value of our non-marketable equity securities during fiscal years 2026 and 2025 were as follows:

[0001045810-26-000021:notes:133]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | (In millions) |
| Balance at beginning of period | $ | 3,387 |  |  | $ | 1,321 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |
| Net additions | 17,444 |  |  | 1,309 |  |
| Unrealized gains | 2,369 |  |  | 816 |  |
| Reclassification (1) | (848) |  |  | — |  |
| Impairments and unrealized losses | (101) |  |  | (59) |  |
| Balance at end of period | $ | 22,251 |  |  | $ | 3,387 |  |

[0001045810-26-000021:notes:134]
(1)   Represents reclassifications from non-marketable equity securities to marketable securities following public market trading.

[0001045810-26-000021:notes:135]
Non-marketable equity securities had cumulative gross unrealized gains of $2.7 billion and $1.1 billion, and cumulative gross unrealized losses and impairments of $176 million and $105 million on securities held as of January 25, 2026 and January 26, 2025, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-26-000021:notes:136]
Balance Sheet Components
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. Three direct customers accounted for 25%, 18%, and 13% of our accounts receivable balance as of January 25, 2026. Two direct customers accounted for 17% and 16% of our accounts receivable balance as of January 26, 2025.

[0001045810-26-000021:notes:137]
Certain balance sheet components are as follows:

[0001045810-26-000021:notes:138]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
| Inventories: | (In millions) |
| Raw materials | $ | 3,807 |  |  | $ | 3,408 |  |
| Work in process | 8,822 |  |  | 3,399 |  |
| Finished goods | 8,774 |  |  | 3,273 |  |
| Total inventories (1) | $ | 21,403 |  |  | $ | 10,080 |  |

[0001045810-26-000021:notes:139]
(1)    In fiscal years 2026 and 2025, we recorded inventory provisions of $4.0 billion and $1.6 billion, respectively, in cost of revenue.

[0001045810-26-000021:notes:140]
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | EstimatedUseful Life |
| Property and Equipment: | (In millions) |  | (In years) |
| Land | $ | 777 |  |  | $ | 511 |  |  | (A) |
| Buildings, leasehold improvements, and furniture | 2,891 |  |  | 2,076 |  |  | (B) |
| Equipment, compute hardware, and software | 12,619 |  |  | 7,568 |  |  | 2-7 |
| Construction in process | 683 |  |  | 529 |  |  | (C) |
| Total property and equipment, gross | 16,970 |  |  | 10,684 |  |  |  |
| Accumulated depreciation and amortization | (6,587) |  |  | (4,401) |  |  |  |
| Total property and equipment, net | $ | 10,383 |  |  | $ | 6,283 |  |  |  |

[0001045810-26-000021:notes:141]
(A)Land is a non-depreciable asset.

[0001045810-26-000021:notes:142]
(B)The estimated useful lives of our buildings are up to thirty years. Leasehold improvements and finance leases are amortized based on the lesser of either the asset’s estimated useful life or the expected remaining lease term.

[0001045810-26-000021:notes:143]
(C)Construction in process represents assets that are not available for their intended use.

[0001045810-26-000021:notes:144]
Depreciation expense for fiscal years 2026, 2025, and 2024 was $2.4 billion, $1.3 billion, and $894 million, respectively.

[0001045810-26-000021:notes:145]
Accumulated amortization of leasehold improvements and finance leases was $519 million and $410 million as of January 25, 2026 and January 26, 2025, respectively.

[0001045810-26-000021:notes:146]
Property, equipment and intangible assets acquired but not paid for during fiscal years 2026, 2025, and 2024 were $820 million, $525 million, and $170 million, respectively.

[0001045810-26-000021:notes:147]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 5,318 |  |  | $ | 4,880 |  |
| Accrued purchase consideration | 3,921 |  |  | 9 |  |
| Product warranty | 2,807 |  |  | 1,290 |  |
| Excess inventory purchase obligations (1) | 2,739 |  |  | 2,095 |  |
| Taxes payable | 2,669 |  |  | 881 |  |
| Deferred revenue (2) | 1,379 |  |  | 837 |  |
| Accrued payroll and related expenses | 1,146 |  |  | 848 |  |
| Other | 1,373 |  |  | 897 |  |
| Total accrued and other current liabilities | $ | 21,352 |  |  | $ | 11,737 |  |

[0001045810-26-000021:notes:148]
In fiscal years 2026 and 2025, we recorded an expense of approximately $3.2 billion and $2.0 billion, respectively, in cost of revenue.Includes customer advances and unearned revenue related to hardware and software support, cloud services, and license and development arrangements. The balance as of January 25, 2026 and January 26, 2025 included $160 million and $81 million of customer advances, respectively.

[0001045810-26-000021:notes:149]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 3,958 |  |  | $ | 2,188 |  |
| Deferred income tax | 1,774 |  |  | 886 |  |
| Deferred revenue (2) | 1,193 |  |  | 976 |  |
| Other | 381 |  |  | 195 |  |
| Total other long-term liabilities | $ | 7,306 |  |  | $ | 4,245 |  |

[0001045810-26-000021:notes:150]
(1)Primarily comprised of unrecognized tax benefits and related interest and penalties.

[0001045810-26-000021:notes:151]
(2)Includes unearned revenue related to hardware and software support and cloud services.

[0001045810-26-000021:notes:152]
Deferred Revenue

[0001045810-26-000021:notes:153]
The following table shows the changes in short- and long-term deferred revenue during fiscal years 2026 and 2025:

[0001045810-26-000021:notes:154]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,813 |  |  | $ | 1,337 |  |
| Deferred revenue additions (1) | 11,137 |  |  | 5,083 |  |
| Revenue recognized (2) | (10,378) |  |  | (4,607) |  |
| Balance at end of period | $ | 2,572 |  |  | $ | 1,813 |  |

[0001045810-26-000021:notes:155]
(1)    Includes $9.0 billion and $3.6 billion of customer advances for fiscal years 2026 and 2025, respectively.

[0001045810-26-000021:notes:156]
(2)    Includes $8.9 billion and $3.7 billion related to customer advances for fiscal years 2026 and 2025, respectively.

[0001045810-26-000021:notes:157]
We recognized revenue of $974 million and $729 million in fiscal years 2026 and 2025, respectively, that were included in the prior year end deferred revenue balance.

[0001045810-26-000021:notes:158]
As of January 25, 2026, revenue related to remaining performance obligations from contracts greater than one year in length was $2.3 billion, which includes $1.9 billion from deferred revenue and $390 million which has not yet been billed nor recognized as revenue. Approximately 42% of revenue from contracts greater than one year in length will be recognized over the next twelve months.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-26-000021:notes:159]
Derivative Financial Instruments
Foreign Currency Derivatives

[0001045810-26-000021:notes:160]
We utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. The foreign currency forward contracts for operating expenses are designated as accounting hedges. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings. In fiscal years 2026 and 2025, the impact of foreign currency forward contracts designated as accounting hedges on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.

[0001045810-26-000021:notes:161]
We also entered into foreign currency forward contracts mitigating the impact of foreign currency movements on monetary assets and liabilities. For our foreign currency contracts for assets and liabilities, the change in fair value of these non-designated contracts was recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which was also recorded in other income or expense.

[0001045810-26-000021:notes:162]
The table below presents the notional value of our foreign currency contracts outstanding:

[0001045810-26-000021:notes:163]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | (In millions) |
| Designated as accounting hedges | $ | 1,765 |  |  | $ | 1,424 |  |
| Not designated as accounting hedges | $ | 2,332 |  |  | $ | 1,297 |  |

[0001045810-26-000021:notes:164]
The unrealized gains and losses or fair value of our foreign currency contracts were not significant as of January 25, 2026 and January 26, 2025.

[0001045810-26-000021:notes:165]
As of January 25, 2026, all foreign currency contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months were not significant.

[0001045810-26-000021:notes:166]
Facility Lease Guarantees

[0001045810-26-000021:notes:167]
In fiscal year 2026, we entered into agreements to guarantee partners’ facility lease obligations in the event of their default in exchange for warrants. The maximum gross exposure under all agreements is $3.5 billion, which is reduced as the partners make payments to the lessors over terms ranging from 5 to 7 years. The partners have placed $712 million in escrow to mitigate our potential exposure. The guarantees, classified as credit derivatives with changes in fair value recognized in Other income and expense, were not material.


## us-gaap:DebtDisclosureTextBlock

[0001045810-26-000021:notes:168]
Debt

[0001045810-26-000021:notes:169]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Jan 25, 2026 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.4 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.2 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.4 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.2 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.2 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.2 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (32) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 8,468 |  |  | 8,463 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 7,469 |  |  | $ | 8,463 |  |

[0001045810-26-000021:notes:170]
As of January 25, 2026 and January 26, 2025, the estimated fair value of debt was $7.5 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

[0001045810-26-000021:notes:171]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity of the notes is calendar year.

[0001045810-26-000021:notes:172]
As of January 25, 2026, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-26-000021:notes:173]
In January 2026, we increased the size of our commercial paper program from $575 million to $25.0 billion. As of January 25, 2026, no commercial paper was outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-26-000021:notes:174]
Commitments and Contingencies
Commitments

[0001045810-26-000021:notes:175]
Manufacturing, supply, and capacity commitments reflect datacenter-scale production and longer future ordering horizons across current and future product architectures. We enter into agreements with our supply vendors that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Changes to these agreements may result in additional costs. As of January 25, 2026, these commitments were $95.2 billion, of which substantially all will be paid through fiscal year 2027.

[0001045810-26-000021:notes:176]
Multi-year cloud service agreement commitments as of January 25, 2026, were $27 billion, for which $7 billion, $6 billion, $5 billion, $5 billion, $2 billion, and $2 billion will be paid in fiscal years 2027, 2028, 2029, 2030, 2031, and 2032 and thereafter, respectively. Some cloud service capacity may be reduced, terminated or sold to others by the CSPs, in which case our commitments will be reduced. We expect cloud service agreements to be used to support our research and development efforts.

[0001045810-26-000021:notes:177]
Investment commitments are $11.4 billion as of January 25, 2026, subject to certain contingencies, of which we expect substantially all will be made through fiscal year 2027.

[0001045810-26-000021:notes:178]
Other commitments were $3.4 billion as of January 25, 2026, of which the majority will be paid through fiscal year 2027.

[0001045810-26-000021:notes:179]
Accrual for Product Warranty Liabilities

[0001045810-26-000021:notes:180]
The estimated amount of product warranty liabilities was $2.8 billion and $1.3 billion as of January 25, 2026 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-26-000021:notes:181]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,290 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 2,474 |  |  | 1,203 |  |  | 278 |  |
| Utilization | (957) |  |  | (219) |  |  | (54) |  |
| Balance at end of period | $ | 2,807 |  |  | $ | 1,290 |  |  | $ | 306 |  |

[0001045810-26-000021:notes:182]
In fiscal years 2026, 2025, and 2024 the additions in product warranty liabilities primarily related to our Compute & Networking segment.

[0001045810-26-000021:notes:183]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.

[0001045810-26-000021:notes:184]
Litigation

[0001045810-26-000021:notes:185]
Securities Class Action and Derivative Lawsuits

[0001045810-26-000021:notes:186]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

[0001045810-26-000021:notes:187]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-26-000021:notes:188]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities

[0001045810-26-000021:notes:189]
Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-26-000021:notes:190]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. On August 11, 2025, the court granted the parties’ stipulation to voluntarily dismiss with prejudice plaintiff City of Westland Police and Fire Retirement System. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-26-000021:notes:191]
Accounting for Loss Contingencies

[0001045810-26-000021:notes:192]
As of January 25, 2026, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-26-000021:notes:193]
Income Taxes
The FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid, which we adopted on a prospective basis for the year ending January 25, 2026.

[0001045810-26-000021:notes:194]
The Income tax expense applicable to income before income taxes consists of the following:

[0001045810-26-000021:notes:195]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 19,039 |  |  | $ | 14,032 |  |  | $ | 5,710 |  |
| State | 1,218 |  |  | 892 |  |  | 335 |  |
| Foreign | 2,550 |  |  | 699 |  |  | 502 |  |
| Total current | 22,807 |  |  | 15,623 |  |  | 6,547 |  |
| Deferred income taxes: |  |  |  |  |  |
| Federal | (1,364) |  |  | (4,515) |  |  | (2,499) |  |
| State | (885) |  |  | (242) |  |  | (206) |  |
| Foreign | 825 |  |  | 280 |  |  | 216 |  |
| Total deferred | (1,424) |  |  | (4,477) |  |  | (2,489) |  |
| Income tax expense | $ | 21,383 |  |  | $ | 11,146 |  |  | $ | 4,058 |  |

[0001045810-26-000021:notes:196]
Income before income tax consists of the following:

[0001045810-26-000021:notes:197]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| U.S. | $ | 123,181 |  |  | $ | 77,456 |  |  | $ | 29,495 |  |
| Foreign | 18,269 |  |  | 6,570 |  |  | 4,323 |  |
| Income before income tax | $ | 141,450 |  |  | $ | 84,026 |  |  | $ | 33,818 |  |

[0001045810-26-000021:notes:198]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21.0% to income before income taxes for the fiscal year ended January 25, 2026 as follows:

[0001045810-26-000021:notes:199]
|  | Year Ended |
|  | Jan 25, 2026 |  |  |  |  |
|  | (In millions, except percentages) |
| US Federal Statutory Tax Rate | $ | 29,704 |  |  | 21.0 | % |  |  |  |  |  |  |  |  |
| State and Local Income Taxes, Net of Federal Income Tax Effect (1) | 258 |  |  | 0.2 | % |  |  |  |  |  |  |  |  |
| Foreign tax effects |  |  |  |  |  |  |  |  |  |  |  |
| Israel |  |  |  |  |  |  |  |  |  |  |  |
| Reduced statutory tax rate on qualifying income | (3,064) |  |  | (2.2) | % |  |  |  |  |  |  |  |  |
| Other | 1,606 |  |  | 1.2 | % |  |  |  |  |  |  |  |  |
| Other foreign jurisdictions | 741 |  |  | 0.5 | % |  |  |  |  |  |  |  |  |
| Effect of cross-border tax laws |  |  |  |  |  |  |  |  |  |  |  |
| Foreign-derived deduction eligible income | (4,208) |  |  | (3.0) | % |  |  |  |  |  |  |  |  |
| Other | (142) |  |  | (0.1) | % |  |  |  |  |  |  |  |  |
| Tax credits | (1,933) |  |  | (1.4) | % |  |  |  |  |  |  |  |  |
| Nontaxable or nondeductible items |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (1,475) |  |  | (1.0) | % |  |  |  |  |  |  |  |  |
| Other | 29 |  |  | — | % |  |  |  |  |  |  |  |  |
| Other (2) | (133) |  |  | (0.1) | % |  |  |  |  |  |  |  |  |
| Income tax expense | $ | 21,383 |  |  | 15.1 | % |  |  |  |  |  |  |  |  |

[0001045810-26-000021:notes:200]
(1) State taxes in California, Tennessee, Arizona, and Illinois made up the majority of the tax effect in fiscal year 2026.

[0001045810-26-000021:notes:201]
(2) Includes the tax effects of enactment of new tax laws, change in valuation allowance, and change in unrecognized tax benefits.

[0001045810-26-000021:notes:202]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21% to income before income taxes for fiscal years ended January 26, 2025 and January 28, 2024 as follows:

[0001045810-26-000021:notes:203]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions, except percentages) |
| Tax expense computed at federal statutory rate | $ | 17,645 |  |  | 21.0 | % |  | $ | 7,102 |  |  | 21.0 | % |
| Expense (benefit) resulting from: |  |  |  |  |  |  |  |
| State income taxes, net of federal tax effect | 554 |  |  | 0.7 | % |  | 120 |  |  | 0.4 | % |
| Foreign-derived deduction eligible income | (2,976) |  |  | (3.5) | % |  | (1,408) |  |  | (4.2) | % |
| Stock-based compensation | (2,097) |  |  | (2.5) | % |  | (741) |  |  | (2.2) | % |
| U.S. federal research and development tax credit | (990) |  |  | (1.2) | % |  | (431) |  |  | (1.3) | % |
| Foreign tax rate differential | (984) |  |  | (1.2) | % |  | (467) |  |  | (1.4) | % |
| Other | (6) |  |  | — | % |  | (117) |  |  | (0.3) | % |
| Income tax expense | $ | 11,146 |  |  | 13.3 | % |  | $ | 4,058 |  |  | 12.0 | % |

[0001045810-26-000021:notes:204]
In July 2025, the OBBBA was enacted into law and contains several changes to key U.S. federal income tax laws. We have recognized the tax effects of currently effective OBBBA provisions in our results for fiscal year 2026.

[0001045810-26-000021:notes:205]
The amount of cash paid for income taxes (net of refunds) for the fiscal year ended January 25, 2026 is as follows:

[0001045810-26-000021:notes:206]
|  | Year Ended |
|  | Jan 25, 2026 |  |  |  |  |
|  | (In millions) |
| Federal | $ | 16,755 |  |  |  |  |  |
| State |  |  |  |  |  |
| California | 1,049 |  |  |  |  |  |
| Other | 1,041 |  |  |  |  |  |
| Foreign |  |  |  |  |  |
| Israel | 1,287 |  |  |  |  |  |
| Other | 156 |  |  |  |  |  |
| Total income taxes paid, net of refunds | $ | 20,288 |  |  |  |  |  |

[0001045810-26-000021:notes:207]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-26-000021:notes:208]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
|  | (In millions) |
| Deferred tax assets: |  |
| Capitalized research and development expenditure | $ | 5,436 |  |  | $ | 6,256 |  |
| Net controlled foreign corporation tested income deferred tax assets | 5,389 |  |  | 2,820 |  |
| Accruals and reserves, not currently deductible for tax purposes | 3,644 |  |  | 2,058 |  |
| Research and other tax credit carryforwards | 718 |  |  | 759 |  |
| Operating lease liabilities | 554 |  |  | 299 |  |
| Net operating loss and capital loss carryforwards | 443 |  |  | 456 |  |
| Other deferred tax assets | 679 |  |  | 566 |  |
| Gross deferred tax assets | 16,863 |  |  | 13,214 |  |
| Less valuation allowance | (768) |  |  | (1,610) |  |
| Total deferred tax assets | 16,095 |  |  | 11,604 |  |
| Deferred tax liabilities: |  |  |  |
| Equity investments | (2,227) |  |  | (264) |  |
| Unremitted earnings of foreign subsidiaries | (1,813) |  |  | (891) |  |
| Operating lease assets | (533) |  |  | (286) |  |
| Acquired intangibles | (38) |  |  | (70) |  |
| Gross deferred tax liabilities | (4,611) |  |  | (1,511) |  |
| Net deferred tax asset (1) | $ | 11,484 |  |  | $ | 10,093 |  |

[0001045810-26-000021:notes:209]
(1)    Net deferred tax asset includes long-term deferred tax assets of $13.3 billion and $11.0 billion and long-term deferred tax liabilities of $1.8 billion and $886 million for fiscal years 2026 and 2025, respectively. Long-term deferred tax liabilities are included in other long-term liabilities on our Consolidated Balance Sheets.

[0001045810-26-000021:notes:210]
As of January 25, 2026, we intend to indefinitely reinvest approximately $1.4 billion of cumulative undistributed earnings held by certain subsidiaries. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to these investments as the determination of such amount is not practicable.

[0001045810-26-000021:notes:211]
As of January 25, 2026 and January 26, 2025, we had a valuation allowance of $768 million and $1.6 billion, respectively, related to capital loss carryforwards, and certain other deferred tax assets that management determined are not likely to be realized due, in part, to jurisdictional projections of future taxable income, including capital gains. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-26-000021:notes:212]
As of January 25, 2026, based on recent jurisdictional taxable income and expected future earnings, we concluded certain state deferred tax assets are more likely than not realizable and released $711 million of valuation allowance.

[0001045810-26-000021:notes:213]
As of January 25, 2026, we had U.S. federal, state and foreign net operating loss carryforwards of $747 million, $427 million and $503 million, respectively. The federal and state carryforwards will begin to expire in fiscal year 2027. The foreign net operating loss carryforwards may be carried forward indefinitely. As of January 25, 2026, we had federal research tax credit carryforwards of $56 million, before the impact of uncertain tax positions, that will begin to expire in fiscal year 2027. We have state research tax credit carryforwards of $1.4 billion, before the impact of uncertain tax positions, of which $1.3 billion is attributable to the State of California and may be carried over indefinitely and $132 million is attributable to various other states and will begin to expire in fiscal year 2028. As of January 25, 2026, we had federal capital loss carryforwards of $902 million that will begin to expire in fiscal year 2028.

[0001045810-26-000021:notes:214]
Our tax attributes remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of tax attributes may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the tax attributes may expire or be denied before utilization.

[0001045810-26-000021:notes:215]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-26-000021:notes:216]
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,861 |  |  | $ | 1,670 |  |  | $ | 1,238 |  |
| Increases in tax positions for current year | 1,959 |  |  | 1,268 |  |  | 616 |  |
| Increases in tax positions for prior years | 57 |  |  | 48 |  |  | 87 |  |
| Lapse in statute of limitations | (224) |  |  | (27) |  |  | (19) |  |
| Decreases in tax positions for prior years | (157) |  |  | (88) |  |  | (148) |  |
| Settlements | (76) |  |  | (10) |  |  | (104) |  |
| Balance at end of period | $ | 4,420 |  |  | $ | 2,861 |  |  | $ | 1,670 |  |

[0001045810-26-000021:notes:217]
Included in the balance of unrecognized tax benefits as of January 25, 2026 are $3.7 billion of tax benefits that would affect our effective tax rate if recognized.

[0001045810-26-000021:notes:218]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or long-term amount refundable, if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-26-000021:notes:219]
We include interest and penalties related to unrecognized tax benefits as a component of income tax expense. We recognized net interest and penalties related to unrecognized tax benefits in the income tax expense line of our consolidated statements of income of $103 million, $92 million, and $42 million during fiscal years 2026, 2025, and 2024, respectively. As of January 25, 2026 and January 26, 2025, we have accrued $374 million and $251 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our gross unrecognized tax benefits.

[0001045810-26-000021:notes:220]
We are subject to examination by taxing authorities both in the United States and other countries. As of January 25, 2026, the significant tax jurisdictions that may be subject to examination include the United States for fiscal years after 2022, as well as Canada, China, Germany, Hong Kong, India, Israel, Italy, and Taiwan for fiscal years 2014 through 2025. As of January 25, 2026, the significant tax jurisdictions for which we are currently under examination include the United States, Germany, Hong Kong, India, Israel, and Taiwan for fiscal years 2014 through 2025.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-26-000021:notes:221]
Shareholders’ Equity
Capital Return Program

[0001045810-26-000021:notes:222]
On August 26, 2025, our Board of Directors approved an additional $60.0 billion in share repurchase authorization, without expiration. In fiscal years 2026 and 2025, we repurchased 282 million and 310 million shares of our common stock for $40.4 billion and $34.0 billion, respectively. As of January 25, 2026, we were authorized, subject to certain specifications, to repurchase up to $58.5 billion of our common stock.

[0001045810-26-000021:notes:223]
From January 26, 2026 through February 20, 2026, we repurchased 8 million shares for $1.5 billion pursuant to a pre-established trading plan.

[0001045810-26-000021:notes:224]
In fiscal years 2026, 2025, and 2024, we paid cash dividends to our shareholders of $974 million, $834 million, and $395 million, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-26-000021:notes:225]
Employee Retirement Plans
We provide tax-qualified defined contribution plans to eligible employees in the U.S. and certain other countries. Our contribution expense for fiscal years 2026, 2025, and 2024 was $442 million, $314 million, and $255 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-26-000021:notes:226]
Segment Information
Our Chief Executive Officer is our chief operating decision maker, or CODM, and reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. Our CODM assesses operating performance of each segment based on regularly provided segment revenue and segment operating income. Operating results by segment include costs or expenses directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments. Our

[0001045810-26-000021:notes:227]
CODM reviews expenses on a consolidated basis, and expenses attributable to each segment are not regularly provided to our CODM.

[0001045810-26-000021:notes:228]
The Compute & Networking segment includes our Data Center accelerated computing and networking platforms and AI solutions and software, and Automotive platforms and autonomous and electric vehicle solutions including software.

[0001045810-26-000021:notes:229]
The Graphics segment includes GeForce GPUs for gaming and PCs, and Quadro/NVIDIA RTX GPUs for enterprise workstation graphics.

[0001045810-26-000021:notes:230]
Certain expenses are not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related and other costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-26-000021:notes:231]
Our CODM does not review any information regarding total assets on a reportable segment basis. There are no intersegment transactions. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments.

[0001045810-26-000021:notes:232]
|  | Compute & Networking |  | Graphics |  | Total |
|  | (In millions) |
| Year Ended Jan 25, 2026 |  |  |  |  |  |
| Revenue | $ | 193,479 |  |  | $ | 22,459 |  |  | $ | 215,938 |  |
| Other segment items (1) | 63,338 |  |  | 13,303 |  |  | 76,641 |  |
| Operating income | $ | 130,141 |  |  | $ | 9,156 |  |  | $ | 139,297 |  |
| Year Ended Jan 26, 2025 |  |  |  |  |  |
| Revenue | $ | 116,193 |  |  | $ | 14,304 |  |  | $ | 130,497 |  |
| Other segment items (1) | 33,318 |  |  | 9,219 |  |  | 42,537 |  |
| Operating income | $ | 82,875 |  |  | $ | 5,085 |  |  | $ | 87,960 |  |
| Year Ended Jan 28, 2024 |  |  |  |  |  |
| Revenue | $ | 47,405 |  |  | $ | 13,517 |  |  | $ | 60,922 |  |
| Other segment items (1) | 15,389 |  |  | 7,671 |  |  | 23,060 |  |
| Operating income | $ | 32,016 |  |  | $ | 5,846 |  |  | $ | 37,862 |  |

[0001045810-26-000021:notes:233]
(1)Other segment items primarily include product costs and inventory provisions, compensation and benefits excluding stock-based compensation expense, computing infrastructure expenses, and engineering development costs.

[0001045810-26-000021:notes:234]
Depreciation and amortization expense attributable to our Compute & Networking segment for fiscal years 2026, 2025, and 2024 was $1.6 billion, $732 million, and $457 million, respectively. Depreciation and amortization expense attributable to our Graphics segment for fiscal years 2026, 2025, and 2024 was $590 million, $372 million, and $307 million, respectively. Acquisition-related intangible amortization expense is not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance.

[0001045810-26-000021:notes:235]
A reconciliation of segment operating income to consolidated income before income tax for fiscal years 2026, 2025, and 2024 were as follows:

[0001045810-26-000021:notes:236]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Segment operating income | $ | 139,297 |  |  | $ | 87,960 |  |  | $ | 37,862 |  |
| Stock-based compensation expense | (6,386) |  |  | (4,737) |  |  | (3,549) |  |
| Unallocated operating expenses | (1,997) |  |  | (1,171) |  |  | (728) |  |
| Acquisition-related and other costs | (527) |  |  | (599) |  |  | (613) |  |
| Interest income | 2,300 |  |  | 1,786 |  |  | 866 |  |
| Interest expense | (259) |  |  | (247) |  |  | (257) |  |
| Other income, net | 9,022 |  |  | 1,034 |  |  | 237 |  |
| Consolidated income before income tax | $ | 141,450 |  |  | $ | 84,026 |  |  | $ | 33,818 |  |

[0001045810-26-000021:notes:237]
Revenue by geographic area is based upon the location of the customers’ headquarters. The end customer and shipping location may be different from our customers' headquarters location.

[0001045810-26-000021:notes:238]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
| Geographic Revenue based upon Customer Headquarters Location (1): | (In millions) |
| United States | $ | 149,617 |  |  | $ | 77,482 |  |  | $ | 31,533 |  |
| Taiwan (2) | 42,345 |  |  | 23,600 |  |  | 14,912 |  |
| China (including Hong Kong) | 19,677 |  |  | 25,048 |  |  | 12,330 |  |
| Other | 4,299 |  |  | 4,367 |  |  | 2,147 |  |
| Total revenue | $ | 215,938 |  |  | $ | 130,497 |  |  | $ | 60,922 |  |

[0001045810-26-000021:notes:239]
(1)In the third quarter of fiscal year 2026, we changed to revenue based upon the location of our customers’ headquarters as we believe it provides a better representation of the geographic profile of our revenue. Prior period information has been recast to reflect this change.

[0001045810-26-000021:notes:240]
(2)In fiscal year 2026, we estimate 76% of Data Center revenue from Taiwan-headquartered customers was attributed to end customers based in the United States and Europe.

[0001045810-26-000021:notes:241]
Revenue from sales to customers headquartered outside of the United States accounted for 31%, 41%, and 48% of total revenue for fiscal years 2026, 2025, and 2024, respectively. The increase in revenue to the United States for fiscal years 2026 and 2025 was primarily due to higher U.S.-based Compute & Networking segment demand.

[0001045810-26-000021:notes:242]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, Neocloud builders, AI model makers, enterprises, and public sector entities. Our revenue is concentrated among a limited number of direct and indirect customers and this trend may continue.

[0001045810-26-000021:notes:243]
Direct Customers – For fiscal year 2026, sales to one direct customer represented 22% of total revenue and sales to another direct customer represented 14% of total revenue, all of which were primarily attributable to the Compute & Networking segment.

[0001045810-26-000021:notes:244]
For fiscal year 2025, sales to one direct customer represented 12% of total revenue and sales to two direct customers each represented 11% of total revenue, all of which were primarily attributable to the Compute & Networking segment.

[0001045810-26-000021:notes:245]
For fiscal year 2024, sales to one direct customer represented 13% of total revenue, and were primarily attributable to the Compute & Networking segment.

[0001045810-26-000021:notes:246]
The following table summarizes revenue by specialized markets:

[0001045810-26-000021:notes:247]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
| Revenue by End Market: | (In millions) |
| Data Center | $ | 193,737 |  |  | $ | 115,186 |  |  | $ | 47,525 |  |
| Compute | 162,361 |  |  | 102,196 |  |  | 38,950 |  |
| Networking | 31,376 |  |  | 12,990 |  |  | 8,575 |  |
| Gaming | 16,042 |  |  | 11,350 |  |  | 10,447 |  |
| Professional Visualization | 3,191 |  |  | 1,878 |  |  | 1,553 |  |
| Automotive | 2,349 |  |  | 1,694 |  |  | 1,091 |  |
| OEM and Other | 619 |  |  | 389 |  |  | 306 |  |
| Total revenue | $ | 215,938 |  |  | $ | 130,497 |  |  | $ | 60,922 |  |

[0001045810-26-000021:notes:248]
The following table presents summarized information for long-lived assets by country. Long-lived assets consist of property and equipment and exclude other assets, operating lease assets, goodwill, and intangible assets.

[0001045810-26-000021:notes:249]
|  | Jan 25, 2026 |  | Jan 26, 2025 |
| Long-lived assets: | (In millions) |
| United States | $ | 5,125 |  |  | $ | 3,626 |  |
| Taiwan | 3,219 |  |  | 1,481 |  |
| Israel | 1,471 |  |  | 840 |  |
| Other | 568 |  |  | 336 |  |
| Total long-lived assets | $ | 10,383 |  |  | $ | 6,283 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-26-000021:notes:250]
The table below presents details of our reportable segments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-26-000021:notes:251]
Leases
Our lease obligations primarily consist of operating leases for our offices and data centers, with lease periods expiring between fiscal years 2027 and 2041.

[0001045810-26-000021:notes:252]
Future minimum lease obligations under our non-cancelable lease agreements as of January 25, 2026 were as follows:

[0001045810-26-000021:notes:253]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2027 | $ | 493 |  |
| 2028 | 485 |  |
| 2029 | 457 |  |
| 2030 | 381 |  |
| 2031 | 314 |  |
| 2032 and thereafter | 1,494 |  |
| Total | 3,624 |  |
| Less imputed interest | 680 |  |
| Present value of net future minimum lease payments | 2,944 |  |
| Less short-term operating lease liabilities | 372 |  |
| Long-term operating lease liabilities | $ | 2,572 |  |

[0001045810-26-000021:notes:254]
Between fiscal years 2027 and 2030, we expect to commence leases with future obligations of $22.7 billion, primarily data center leases to support our research and development efforts, with lease terms of 1.8 to 20 years.

[0001045810-26-000021:notes:255]
Operating lease costs for fiscal years 2026, 2025, and 2024 were $462 million, $356 million, and $269 million, respectively. Short-term and variable lease costs for fiscal years 2026, 2025, and 2024 were not significant.

[0001045810-26-000021:notes:256]
Other information related to leases was as follows:

[0001045810-26-000021:notes:257]
|  | Year Ended |
|  | Jan 25, 2026 |  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |  |  |
| Operating cash flow used for operating leases | $ | 428 |  |  | $ | 313 |  |  | $ | 286 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 1,439 |  |  | $ | 877 |  |  | $ | 531 |  |

[0001045810-26-000021:notes:258]
As of January 25, 2026, our operating leases have a weighted average remaining lease term of 8.8 years and a weighted average discount rate of 4.38%. As of January 26, 2025, our operating leases had a weighted average remaining lease term of 6.5 years and a weighted average discount rate of 4.16%.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-26-000021:notes:259]
Schedule II – Valuation and Qualifying Accounts

[0001045810-26-000021:notes:260]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2026 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 82 |  |  | $ | 188 |  | (2) | $ | (100) |  | (4) | $ | 170 |  |
| Deferred tax valuation allowance |  | $ | 1,610 |  |  | $ | 31 |  | (3) | $ | (873) |  | (3) | $ | 768 |  |
| Fiscal year 2025 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 109 |  |  | $ | 151 |  | (2) | $ | (178) |  | (4) | $ | 82 |  |
| Deferred tax valuation allowance |  | $ | 1,552 |  |  | $ | 58 |  | (3) | $ | — |  | (3) | $ | 1,610 |  |
| Fiscal year 2024 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 26 |  |  | $ | 213 |  | (2) | $ | (130) |  | (4) | $ | 109 |  |
| Deferred tax valuation allowance |  | $ | 1,484 |  |  | $ | 162 |  | (3) | $ | (94) |  | (3) | $ | 1,552 |  |

[0001045810-26-000021:notes:261]
(1)Additions represent either expense or acquired balances and deductions represent write-offs.

[0001045810-26-000021:notes:262]
(2)Additions represent estimated product returns charged as a reduction to revenue or an acquired balance.

[0001045810-26-000021:notes:263]
(3)Additional valuation allowance on deferred tax assets not likely to be realized. Additions represent additional valuation allowance on certain state and other deferred tax assets. Deductions mainly represent the release of valuation allowance on certain state deferred tax assets. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-26-000021:notes:264]
(4)Represents sales returns.
