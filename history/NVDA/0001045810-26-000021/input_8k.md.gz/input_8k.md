# NVDA 8-K — 0001045810-26-000019 filed 2026-02-25

## item codes, every 8-K on or before 2026-02-25

- 2026-02-25 0001045810-26-000019 — 2.02, 9.01
- 2026-01-23 0001045810-26-000003 — 5.02
- 2025-11-19 0001045810-25-000228 — 2.02, 9.01
- 2025-08-27 0001045810-25-000207 — 2.02, 9.01
- 2025-08-05 0001045810-25-000197 — 5.02
- 2025-07-01 0001045810-25-000179 — 5.07
- 2025-05-28 0001045810-25-000115 — 2.02, 9.01
- 2025-04-15 0001045810-25-000082 — 8.01
- 2025-03-07 0001045810-25-000039 — 5.02
- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2026-02-25

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-26-000019:8k_2_02:1]
EX-99.1
2
q4fy26pr.htm
EX-99.1

[0001045810-26-000019:8k_2_02:2]
Document

[0001045810-26-000019:8k_2_02:3]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2026

[0001045810-26-000019:8k_2_02:4]
•Record quarterly revenue of $68.1 billion, up 20% from Q3 and up 73% from a year ago

[0001045810-26-000019:8k_2_02:5]
•Record quarterly Data Center revenue of $62.3 billion, up 22% from Q3 and up 75% from a year ago

[0001045810-26-000019:8k_2_02:6]
•Record full-year revenue of $215.9 billion, up 65%

[0001045810-26-000019:8k_2_02:7]
SANTA CLARA, Calif.—Feb. 25, 2026―NVIDIA (NASDAQ: NVDA) today reported record revenue for the fourth quarter ended January 25, 2026, of $68.1 billion, up 20% from the previous quarter and up 73% from a year ago. For fiscal 2026, revenue was $215.9 billion, up 65% from a year ago.

[0001045810-26-000019:8k_2_02:8]
For the quarter, GAAP and non-GAAP gross margins were 75.0% and 75.2%, respectively. For fiscal 2026, GAAP and non-GAAP gross margins were 71.1% and 71.3%, respectively.

[0001045810-26-000019:8k_2_02:9]
For the quarter, GAAP and non-GAAP earnings per diluted share were $1.76 and $1.62, respectively. For fiscal 2026, GAAP and non-GAAP earnings per diluted share were $4.90 and $4.77, respectively.

[0001045810-26-000019:8k_2_02:10]
“Computing demand is growing exponentially — the agentic AI inflection point has arrived. Grace Blackwell with NVLink is the king of inference today — delivering an order-of-magnitude lower cost per token — and Vera Rubin will extend that leadership even further,” said Jensen Huang, founder and CEO of NVIDIA. “Enterprise adoption of agents is skyrocketing. Our customers are racing to invest in AI compute — the factories powering the AI industrial revolution and their future growth.”

[0001045810-26-000019:8k_2_02:11]
During fiscal 2026, NVIDIA returned $41.1 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the fourth quarter, the company had $58.5 billion remaining under its share repurchase authorization.

[0001045810-26-000019:8k_2_02:12]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on April 1, 2026, to all shareholders of record on March 11, 2026.

[0001045810-26-000019:8k_2_02:13]
Q4 Fiscal 2026 Summary

[0001045810-26-000019:8k_2_02:14]
| GAAP |
| ($ in millions, except earnings per share) | Q4 FY26 | Q3 FY26 | Q4 FY25 | Q/Q | Y/Y |
| Revenue | $68,127 | $57,006 | $39,331 | 20 | % | 73 | % |
| Gross margin | 75.0 | % | 73.4 | % | 73.0 | % | 1.6 pts | 2.0 pts |
| Operating expenses | $6,794 | $5,839 | $4,689 | 16 | % | 45 | % |
| Operating income | $44,299 | $36,010 | $24,034 | 23 | % | 84 | % |
| Net income | $42,960 | $31,910 | $22,091 | 35 | % | 94 | % |
| Diluted earnings per share | $1.76 | $1.30 | $0.89 | 35 | % | 98 | % |

[0001045810-26-000019:8k_2_02:15]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q4 FY26 | Q3 FY26 | Q4 FY25 | Q/Q | Y/Y |
| Revenue | $68,127 | $57,006 | $39,331 | 20 | % | 73 | % |
| Gross margin | 75.2 | % | 73.6 | % | 73.5 | % | 1.6 pts | 1.7 pts |
| Operating expenses | $5,102 | $4,215 | $3,378 | 21 | % | 51 | % |
| Operating income | $46,107 | $37,752 | $25,516 | 22 | % | 81 | % |
| Net income | $39,552 | $31,767 | $22,066 | 25 | % | 79 | % |
| Diluted earnings per share | $1.62 | $1.30 | $0.89 | 25 | % | 82 | % |

[0001045810-26-000019:8k_2_02:16]
Fiscal 2026 Summary

[0001045810-26-000019:8k_2_02:17]
| GAAP |
| ($ in millions, except earnings per share) |  |  | FY26 | FY25 | Y/Y |
| Revenue |  |  | $215,938 | $130,497 | 65 | % |
| Gross margin |  |  | 71.1 | % | 75.0 | % | (3.9) pts |
| Operating expenses |  |  | $23,076 | $16,405 | 41 | % |
| Operating income |  |  | $130,387 | $81,453 | 60 | % |
| Net income |  |  | $120,067 | $72,880 | 65 | % |
| Diluted earnings per share |  |  | $4.90 | $2.94 | 67 | % |

[0001045810-26-000019:8k_2_02:18]
| Non-GAAP |
| ($ in millions, except earnings per share) |  |  | FY26 | FY25 | Y/Y |
| Revenue |  |  | $215,938 | $130,497 | 65 | % |
| Gross margin |  |  | 71.3 | % | 75.5 | % | (4.2) pts |
| Operating expenses |  |  | $16,694 | $11,716 | 42 | % |
| Operating income |  |  | $137,300 | $86,789 | 58 | % |
| Net income |  |  | $116,997 | $74,265 | 58 | % |
| Diluted earnings per share |  |  | $4.77 | $2.99 | 60 | % |

[0001045810-26-000019:8k_2_02:19]
Outlook

[0001045810-26-000019:8k_2_02:20]
Beginning in the first quarter of fiscal 2027, NVIDIA will include stock-based compensation expense in non-GAAP financial measures. Stock-based compensation is a foundational component of NVIDIA’s compensation program to attract and retain world-class talent.

[0001045810-26-000019:8k_2_02:21]
NVIDIA’s outlook for the first quarter of fiscal 2027 is as follows:

[0001045810-26-000019:8k_2_02:22]
•Revenue is expected to be $78.0 billion, plus or minus 2%. NVIDIA is not assuming any Data Center compute revenue from China in its outlook.

[0001045810-26-000019:8k_2_02:23]
•GAAP and non-GAAP gross margins are expected to be 74.9% and 75.0%, respectively, plus or minus 50 basis points, inclusive of a 0.1% impact from stock-based compensation expense.

[0001045810-26-000019:8k_2_02:24]
•GAAP and non-GAAP operating expenses are expected to be approximately $7.7 billion and $7.5 billion, respectively, inclusive of $1.9 billion of stock-based compensation expense.

[0001045810-26-000019:8k_2_02:25]
For the full year fiscal 2027, GAAP and non-GAAP tax rates are expected to be between 17.0% and 19.0%, excluding any discrete items and material changes to NVIDIA’s tax environment.

[0001045810-26-000019:8k_2_02:26]
Highlights

[0001045810-26-000019:8k_2_02:27]
Data Center

[0001045810-26-000019:8k_2_02:28]
•Fourth-quarter revenue was a record $62.3 billion, up 22% from the previous quarter and up 75% from a year ago, driven by the major platform shifts — accelerated computing and AI. Full-year revenue rose 68% to a record $193.7 billion.

[0001045810-26-000019:8k_2_02:29]
•Unveiled the NVIDIA Rubin platform, comprising six new chips to deliver up to a 10x reduction in inference token cost, compared with the NVIDIA Blackwell platform; cloud providers Amazon Web Services (AWS), Google Cloud, Microsoft Azure and Oracle Cloud Infrastructure will be among the first to deploy Vera Rubin-based instances.

[0001045810-26-000019:8k_2_02:30]
•Announced that the NVIDIA BlueField®-4 data processor powers the NVIDIA Inference Context Memory Storage Platform, a new class of AI-native storage infrastructure for the next frontier of AI.

[0001045810-26-000019:8k_2_02:31]
•Announced a multiyear, multigenerational strategic partnership with Meta spanning on-premises, cloud and AI infrastructure, including the large-scale deployment of NVIDIA CPUs, networking and millions of NVIDIA Blackwell and Rubin GPUs.

[0001045810-26-000019:8k_2_02:32]
•Revealed that NVIDIA Blackwell Ultra delivers up to 50x better performance and 35x lower cost for agentic AI compared with the NVIDIA Hopper platform, according to new SemiAnalysis InferenceX benchmark results.

[0001045810-26-000019:8k_2_02:33]
•Expanded AWS partnership with new technology integrations across interconnect technology, cloud infrastructure, open models and physical AI.

[0001045810-26-000019:8k_2_02:34]
•Revealed that leading inference providers, including Baseten, DeepInfra, Fireworks AI and Together AI, cut AI costs by up to 10x with open source models on NVIDIA Blackwell.

[0001045810-26-000019:8k_2_02:35]
•Debuted the NVIDIA Nemotron™ 3 family of open models, data and libraries designed to power transparent, efficient and specialized agentic AI development across industries; released new open models, data and tools for agentic AI, physical AI and autonomous vehicle development.

[0001045810-26-000019:8k_2_02:36]
•Announced an investment and deep technology partnership with Anthropic, which is scaling its Claude model on Microsoft Azure, powered by NVIDIA systems.

[0001045810-26-000019:8k_2_02:37]
•Entered into a non-exclusive licensing agreement with Groq to accelerate AI inference at global scale.

[0001045810-26-000019:8k_2_02:38]
•Strengthened a collaboration with CoreWeave to accelerate the buildout of more than 5 gigawatts of AI factories by 2030.

[0001045810-26-000019:8k_2_02:39]
•Announced an expanded strategic partnership with Synopsys to revolutionize engineering and design across industries.

[0001045810-26-000019:8k_2_02:40]
•Announced a co-innovation AI lab with Lilly to reinvent drug discovery in the age of AI.

[0001045810-26-000019:8k_2_02:41]
•Announced a major expansion of NVIDIA BioNeMo™, an open development platform that enables lab-in-the-loop workflows to develop breakthroughs in AI-driven biology and drug discovery.

[0001045810-26-000019:8k_2_02:42]
•Joined the U.S. Department of Energy’s Genesis Mission as a private industry partner to support U.S. AI leadership in key areas including energy, scientific research and national security.

[0001045810-26-000019:8k_2_02:43]
•Launched the NVIDIA Earth-2 family of open models — the world’s first fully open, accelerated set of models and tools for AI weather.

[0001045810-26-000019:8k_2_02:44]
•Revealed that India’s global systems integrators Infosys, Persistent, Tech Mahindra and Wipro are building the next wave of enterprise agents with NVIDIA AI.

[0001045810-26-000019:8k_2_02:45]
•Partnered with global industrial software leaders Cadence, Siemens and Synopsys and India’s largest manufacturers to drive India’s AI boom using applications accelerated by NVIDIA CUDA-X™ and NVIDIA Omniverse™ libraries.

[0001045810-26-000019:8k_2_02:46]
Gaming and AI PC

[0001045810-26-000019:8k_2_02:47]
•Fourth-quarter Gaming revenue was $3.7 billion, up 47% from a year ago, driven by strong Blackwell demand, and down 13% from the previous quarter as channel inventory naturally moderated following a season of strong holiday demand. Full-year revenue rose 41% to a record $16.0 billion.

[0001045810-26-000019:8k_2_02:48]
•Announced NVIDIA DLSS 4.5, delivering major AI-powered advances in graphics quality.

[0001045810-26-000019:8k_2_02:49]
•Launched NVIDIA G-SYNC® Pulsar, extending the ultimate gaming display platform with new levels of motion clarity in esports.

[0001045810-26-000019:8k_2_02:50]
•Advanced NVIDIA RTX™ AI performance and adoption, delivering up to 35% faster large language model inference in leading AI PC frameworks and up to 3x performance in AI-generated visuals.

[0001045810-26-000019:8k_2_02:51]
Professional Visualization

[0001045810-26-000019:8k_2_02:52]
•Fourth-quarter revenue was $1.3 billion, up 74% from the previous quarter and up 159% from a year ago, driven by exceptional demand for Blackwell. Full-year revenue rose 70% to a record $3.2 billion.

[0001045810-26-000019:8k_2_02:53]
•Launched the NVIDIA RTX PRO™ 5000 72GB Blackwell GPU to power larger models and agentic workflows.

[0001045810-26-000019:8k_2_02:54]
•Expanded global availability of NVIDIA DGX Spark™ for the latest open models and delivered updates for improved performance.

[0001045810-26-000019:8k_2_02:55]
Automotive and Robotics

[0001045810-26-000019:8k_2_02:56]
•Fourth-quarter Automotive revenue was $604 million, up 2% from the previous quarter and up 6% from a year ago, driven by continued adoption of NVIDIA’s self-driving platforms. Full-year revenue rose 39% to a record $2.3 billion.

[0001045810-26-000019:8k_2_02:57]
•Unveiled the NVIDIA Alpamayo family of open AI models, simulation tools and datasets designed to accelerate the next era of safe, reasoning‑based autonomous vehicle (AV) development.

[0001045810-26-000019:8k_2_02:58]
•Partnered with Mercedes-Benz on the all-new Mercedes-Benz CLA, which introduces enhanced level 2 driver assistance powered by NVIDIA DRIVE AV software, AI infrastructure and accelerated compute.

[0001045810-26-000019:8k_2_02:59]
•Announced that the NVIDIA DRIVE Hyperion™ ecosystem is expanding to include tier 1 suppliers, automotive integrators and sensor partners including Aeva, AUMOVIO, Astemo, Arbe, Bosch, Hesai, Magna, Omnivision, Quanta, Sony and ZF Group.

[0001045810-26-000019:8k_2_02:60]
•Announced new NVIDIA Cosmos™ and NVIDIA Isaac™ GR00T open models, frameworks and AI infrastructure for physical AI; global industry leaders including Boston Dynamics, Caterpillar, Franka Robotics, Humanoid, LG Electronics and NEURA Robotics are using the NVIDIA robotics stack.

[0001045810-26-000019:8k_2_02:61]
•Expanded a strategic partnership with Siemens to build the industrial AI operating system.

[0001045810-26-000019:8k_2_02:62]
•Announced a strategic partnership with Dassault Systèmes to build an industrial AI platform powering virtual twins.

[0001045810-26-000019:8k_2_02:63]
CFO Commentary

[0001045810-26-000019:8k_2_02:64]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-26-000019:8k_2_02:65]
Conference Call and Webcast Information

[0001045810-26-000019:8k_2_02:66]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2026 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2027.

[0001045810-26-000019:8k_2_02:67]
Non-GAAP Measures

[0001045810-26-000019:8k_2_02:68]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. The reconciliations for fiscal years 2025 and 2026 adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains/losses from non-marketable and publicly-held equity securities, net, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures will no longer exclude stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both

[0001045810-26-000019:8k_2_02:69]
purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-26-000019:8k_2_02:70]
About NVIDIA

[0001045810-26-000019:8k_2_02:71]
NVIDIA (NASDAQ: NVDA) is the world leader in AI and accelerated computing.

[0001045810-26-000019:8k_2_02:72]
###

[0001045810-26-000019:8k_2_02:73]
For further information, contact:

[0001045810-26-000019:8k_2_02:74]
| Toshiya Hari |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| toshiyah@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-26-000019:8k_2_02:75]
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, DGX Spark, BlueField, NVIDIA DRIVE Hyperion, NVIDIA RTX, NVIDIA RTX PRO, NVIDIA Cosmos, NVIDIA Isaac, Nemotron, BioNeMo, CUDA-X, Omniverse and G-SYNC are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-26-000019:8k_2_02:76]
NVIDIA CORPORATION

[0001045810-26-000019:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-26-000019:8k_2_02:78]
(In millions, except per share data)

[0001045810-26-000019:8k_2_02:79]
(Unaudited)

[0001045810-26-000019:8k_2_02:80]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 25, |  | January 26, |  | January 25, |  | January 26, |
|  |  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue | $ | 68,127 |  |  | $ | 39,331 |  |  | $ | 215,938 |  |  | $ | 130,497 |  |
| Cost of revenue | 17,034 |  |  | 10,608 |  |  | 62,475 |  |  | 32,639 |  |
| Gross profit | 51,093 |  |  | 28,723 |  |  | 153,463 |  |  | 97,858 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 5,512 |  |  | 3,714 |  |  | 18,497 |  |  | 12,914 |  |
|  | Sales, general and administrative | 1,282 |  |  | 975 |  |  | 4,579 |  |  | 3,491 |  |
|  |  | Total operating expenses | 6,794 |  |  | 4,689 |  |  | 23,076 |  |  | 16,405 |  |
| Operating income | 44,299 |  |  | 24,034 |  |  | 130,387 |  |  | 81,453 |  |
|  | Interest income | 568 |  |  | 511 |  |  | 2,300 |  |  | 1,786 |  |
|  | Interest expense | (74) |  |  | (61) |  |  | (259) |  |  | (247) |  |
|  | Other income, net | 5,604 |  |  | 733 |  |  | 9,022 |  |  | 1,034 |  |
|  |  | Total other income, net | 6,098 |  |  | 1,183 |  |  | 11,063 |  |  | 2,573 |  |
| Income before income tax | 50,397 |  |  | 25,217 |  |  | 141,450 |  |  | 84,026 |  |
| Income tax expense | 7,437 |  |  | 3,126 |  |  | 21,383 |  |  | 11,146 |  |
| Net income | $ | 42,960 |  |  | $ | 22,091 |  |  | $ | 120,067 |  |  | $ | 72,880 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 1.77 |  |  | $ | 0.90 |  |  | $ | 4.93 |  |  | $ | 2.97 |  |
|  | Diluted | $ | 1.76 |  |  | $ | 0.89 |  |  | $ | 4.90 |  |  | $ | 2.94 |  |
| Weighted average shares used in per share computation: |
|  | Basic | 24,304 |  |  | 24,489 |  |  | 24,359 |  |  | 24,555 |  |
|  | Diluted | 24,432 |  |  | 24,706 |  |  | 24,514 |  |  | 24,804 |  |

[0001045810-26-000019:8k_2_02:81]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | January 25, |  | January 26, |
|  |  |  |  | 2026 |  | 2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 62,556 |  |  | $ | 43,210 |  |
|  | Accounts receivable, net |  | 38,466 |  |  | 23,065 |  |
|  | Inventories |  | 21,403 |  |  | 10,080 |  |
|  | Prepaid expenses and other current assets |  | 3,180 |  |  | 3,771 |  |
|  |  | Total current assets |  | 125,605 |  |  | 80,126 |  |
| Property and equipment, net |  | 10,383 |  |  | 6,283 |  |
| Operating lease assets |  | 2,867 |  |  | 1,793 |  |
| Goodwill |  | 20,832 |  |  | 5,188 |  |
| Intangible assets, net |  | 3,306 |  |  | 807 |  |
| Deferred income tax assets |  | 13,258 |  |  | 10,979 |  |
| Non-marketable equity securities |  | 22,251 |  |  | 3,387 |  |
| Other assets |  | 8,301 |  |  | 3,038 |  |
|  |  | Total assets |  | $ | 206,803 |  |  | $ | 111,601 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 9,812 |  |  | $ | 6,310 |  |
|  | Accrued and other current liabilities |  | 21,352 |  |  | 11,737 |  |
|  | Short-term debt |  | 999 |  |  | — |  |
|  |  | Total current liabilities |  | 32,163 |  |  | 18,047 |  |
| Long-term debt |  | 7,469 |  |  | 8,463 |  |
| Long-term operating lease liabilities |  | 2,572 |  |  | 1,519 |  |
| Other long-term liabilities |  | 7,306 |  |  | 4,245 |  |
|  |  | Total liabilities |  | 49,510 |  |  | 32,274 |  |
| Shareholders' equity |  | 157,293 |  |  | 79,327 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 206,803 |  |  | $ | 111,601 |  |

[0001045810-26-000019:8k_2_02:82]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Twelve Months Ended |  |  |
|  | January 25, |  | January 26, |  | January 25, |  | January 26, |  |  |  |  |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 42,960 |  |  | $ | 22,091 |  |  | $ | 120,067 |  |  | $ | 72,880 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,633 |  |  | 1,321 |  |  | 6,386 |  |  | 4,737 |  |  |  |  |  |
| Depreciation and amortization | 811 |  |  | 543 |  |  | 2,843 |  |  | 1,864 |  |  |  |  |  |
| Gains on non-marketable equity securities and publicly-held equity securities, net | (5,491) |  |  | (727) |  |  | (8,918) |  |  | (1,030) |  |  |  |  |  |
| Deferred income taxes | 611 |  |  | (598) |  |  | (1,424) |  |  | (4,477) |  |  |  |  |  |
| Other | (9) |  |  | (138) |  |  | (287) |  |  | (502) |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | (5,073) |  |  | (5,370) |  |  | (15,399) |  |  | (13,063) |  |  |  |  |  |
| Inventories | (1,621) |  |  | (2,424) |  |  | (11,324) |  |  | (4,781) |  |  |  |  |  |
| Prepaid expenses and other assets | (281) |  |  | 331 |  |  | 577 |  |  | (395) |  |  |  |  |  |
| Accounts payable | 1,064 |  |  | 867 |  |  | 3,096 |  |  | 3,357 |  |  |  |  |  |
| Accrued and other current liabilities | 1,053 |  |  | 360 |  |  | 5,257 |  |  | 4,278 |  |  |  |  |  |
| Other long-term liabilities | 533 |  |  | 372 |  |  | 1,844 |  |  | 1,221 |  |  |  |  |  |
| Net cash provided by operating activities | 36,190 |  |  | 16,628 |  |  | 102,718 |  |  | 64,089 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from sales of marketable securities | 14,670 |  |  | 177 |  |  | 15,157 |  |  | 495 |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,246 |  |  | 1,710 |  |  | 11,226 |  |  | 11,195 |  |  |  |  |  |
| Proceeds from sales of non-marketable equity securities | 12 |  |  | — |  |  | 84 |  |  | 171 |  |  |  |  |  |
| Purchases of marketable securities | (20,540) |  |  | (7,010) |  |  | (40,616) |  |  | (26,575) |  |  |  |  |  |
| Purchases of non-marketable equity securities | (12,800) |  |  | (478) |  |  | (17,502) |  |  | (1,486) |  |  |  |  |  |
| Groq, Inc. | (13,000) |  |  | — |  |  | (13,000) |  |  | — |  |  |  |  |  |
| Purchases related to property and equipment and intangible assets | (1,284) |  |  | (1,077) |  |  | (6,042) |  |  | (3,236) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (165) |  |  | (542) |  |  | (1,535) |  |  | (1,007) |  |  |  |  |  |
| Other | — |  |  | 22 |  |  | — |  |  | 22 |  |  |  |  |  |
| Net cash used in investing activities | (30,861) |  |  | (7,198) |  |  | (52,228) |  |  | (20,421) |  |  |  |  |  |

[0001045810-26-000019:8k_2_02:83]
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | — |  |  | — |  |  | 644 |  |  | 490 |  |  |  |  |  |
| Payments related to repurchases of common stock | (3,815) |  |  | (7,810) |  |  | (40,086) |  |  | (33,706) |  |  |  |  |  |
| Payments related to employee stock plan taxes | (2,139) |  |  | (1,861) |  |  | (7,948) |  |  | (6,930) |  |  |  |  |  |
| Dividends paid | (243) |  |  | (245) |  |  | (974) |  |  | (834) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (4) |  |  | (32) |  |  | (101) |  |  | (129) |  |  |  |  |  |
| Repayment of debt | — |  |  | — |  |  | — |  |  | (1,250) |  |  |  |  |  |
| Other | (9) |  |  | — |  |  | (9) |  |  | — |  |  |  |  |  |
| Net cash used in financing activities | (6,210) |  |  | (9,948) |  |  | (48,474) |  |  | (42,359) |  |  |  |  |  |
| Change in cash and cash equivalents | (881) |  |  | (518) |  |  | 2,016 |  |  | 1,309 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 11,486 |  |  | 9,107 |  |  | 8,589 |  |  | 7,280 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 10,605 |  |  | $ | 8,589 |  |  | $ | 10,605 |  |  | $ | 8,589 |  |  |  |  |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 6,979 |  |  | $ | 4,129 |  |  | $ | 20,288 |  |  | $ | 15,118 |  |  |  |  |  |

[0001045810-26-000019:8k_2_02:84]
|  | NVIDIA CORPORATION |  |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |  |
|  | (In millions, except per share data) |  |
|  | (Unaudited) |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |  |
|  |  |  | January 25, |  | October 26, |  | January 26, |  | January 25, |  | January 26, |  |
|  |  |  | 2026 |  | 2025 |  | 2025 |  | 2026 |  | 2025 |  |
| GAAP cost of revenue |  | $ | 17,034 |  |  | $ | 15,157 |  |  | $ | 10,608 |  |  | $ | 62,475 |  |  | $ | 32,639 |  |  |
| GAAP gross profit |  | $ | 51,093 |  |  | $ | 41,849 |  |  | $ | 28,723 |  |  | $ | 153,463 |  |  | $ | 97,858 |  |  |
| GAAP gross margin |  | 75.0 | % |  | 73.4 | % |  | 73.0 | % |  | 71.1 | % |  | 75.0 | % |  |
|  | Acquisition-related and other costs (A) |  | 48 |  |  | 48 |  |  | 118 |  |  | 267 |  |  | 472 |  |  |
|  | Stock-based compensation expense (B) |  | 69 |  |  | 70 |  |  | 53 |  |  | 261 |  |  | 178 |  |  |
|  | Other |  | (1) |  |  | — |  |  | — |  |  | 3 |  |  | (3) |  |  |
| Non-GAAP cost of revenue |  | $ | 16,918 |  |  | $ | 15,039 |  |  | $ | 10,437 |  |  | $ | 61,944 |  |  | $ | 31,992 |  |  |
| Non-GAAP gross profit |  | $ | 51,209 |  |  | $ | 41,967 |  |  | $ | 28,894 |  |  | $ | 153,994 |  |  | $ | 98,505 |  |  |
| Non-GAAP gross margin** |  | 75.2 | % |  | 73.6 | % |  | 73.5 | % |  | 71.3 | % |  | 75.5 | % |  |
| GAAP operating expenses |  | $ | 6,794 |  |  | $ | 5,839 |  |  | $ | 4,689 |  |  | $ | 23,076 |  |  | $ | 16,405 |  |  |
|  | Stock-based compensation expense (B) |  | (1,564) |  |  | (1,585) |  |  | (1,268) |  |  | (6,125) |  |  | (4,559) |  |  |
|  | Acquisition-related and other costs (A) |  | (90) |  |  | (39) |  |  | (43) |  |  | (204) |  |  | (130) |  |  |
|  | Other |  | (38) |  |  | — |  |  | — |  |  | (53) |  |  | — |  |  |
| Non-GAAP operating expenses |  | $ | 5,102 |  |  | $ | 4,215 |  |  | $ | 3,378 |  |  | $ | 16,694 |  |  | $ | 11,716 |  |  |
| GAAP operating income |  | $ | 44,299 |  |  | $ | 36,010 |  |  | $ | 24,034 |  |  | $ | 130,387 |  |  | $ | 81,453 |  |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,808 |  |  | 1,742 |  |  | 1,482 |  |  | 6,913 |  |  | 5,336 |  |  |
| Non-GAAP operating income |  | $ | 46,107 |  |  | $ | 37,752 |  |  | $ | 25,516 |  |  | $ | 137,300 |  |  | $ | 86,789 |  |  |
| GAAP total other income, net |  | $ | 6,098 |  |  | $ | 1,926 |  |  | $ | 1,183 |  |  | $ | 11,063 |  |  | $ | 2,573 |  |  |
|  | Gains from non-marketable equity securities and publicly-held equity securities, net |  | (5,491) |  |  | (1,354) |  |  | (727) |  |  | (8,918) |  |  | (1,030) |  |  |
|  | Other (C) |  | 13 |  |  | 1 |  |  | 1 |  |  | 16 |  |  | 4 |  |  |
| Non-GAAP total other income, net |  | $ | 620 |  |  | $ | 573 |  |  | $ | 457 |  |  | $ | 2,161 |  |  | $ | 1,547 |  |  |
| GAAP net income |  | $ | 42,960 |  |  | $ | 31,910 |  |  | $ | 22,091 |  |  | $ | 120,067 |  |  | $ | 72,880 |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | (3,670) |  |  | 389 |  |  | 756 |  |  | (1,989) |  |  | 4,310 |  |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | 262 |  |  | (532) |  |  | (781) |  |  | (1,129) |  |  | (2,925) |  |  |
|  | Tax expense from OBBBA* |  | — |  |  | — |  |  | — |  |  | 48 |  |  | — |  |  |
| Non-GAAP net income** |  | $ | 39,552 |  |  | $ | 31,767 |  |  | $ | 22,066 |  |  | $ | 116,997 |  |  | $ | 74,265 |  |  |

[0001045810-26-000019:8k_2_02:85]
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 1.76 |  |  | $ | 1.30 |  |  | $ | 0.89 |  |  | $ | 4.90 |  |  | $ | 2.94 |  |  |
|  | Non-GAAP** |  | $ | 1.62 |  |  | $ | 1.30 |  |  | $ | 0.89 |  |  | $ | 4.77 |  |  | $ | 2.99 |  |  |
| Weighted average shares used in diluted net income per share computation |  | 24,432 |  |  | 24,483 |  |  | 24,706 |  |  | 24,514 |  |  | 24,804 |  |  |
| GAAP net cash provided by operating activities |  | $ | 36,190 |  |  | $ | 23,750 |  |  | $ | 16,628 |  |  | $ | 102,718 |  |  | $ | 64,089 |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (1,284) |  |  | (1,637) |  |  | (1,077) |  |  | (6,042) |  |  | (3,236) |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (4) |  |  | (24) |  |  | (32) |  |  | (101) |  |  | (129) |  |  |
| Free cash flow |  | $ | 34,902 |  |  | $ | 22,089 |  |  | $ | 15,519 |  |  | $ | 96,575 |  |  | $ | 60,724 |  |  |
| *Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act). |  |
| **Includes H20 charges/(releases), net, which were $4.5 billion and ($180 million) for the first and second quarter of fiscal 2026, respectively, and insignificant for both the third and fourth quarter of fiscal 2026. |  |

[0001045810-26-000019:8k_2_02:86]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |  |
|  |  |  | January 25, |  | October 26, |  | January 26, |  | January 25, |  | January 26, |  |
|  |  |  | 2026 |  | 2025 |  | 2025 |  | 2026 |  | 2025 |  |
|  | Cost of revenue |  | $ | 48 |  |  | $ | 48 |  |  | $ | 118 |  |  | $ | 267 |  |  | $ | 472 |  |  |
|  | Research and development |  | $ | 83 |  |  | $ | 35 |  |  | $ | 27 |  |  | $ | 176 |  |  | $ | 79 |  |  |
|  | Sales, general and administrative |  | $ | 7 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 28 |  |  | $ | 51 |  |  |
| (B) Stock-based compensation consists of the following: |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |  |
|  |  |  | January 25, |  | October 26, |  | January 26, |  | January 25, |  | January 26, |  |
|  |  |  | 2026 |  | 2025 |  | 2025 |  | 2026 |  | 2025 |  |
|  | Cost of revenue |  | $ | 69 |  |  | $ | 70 |  |  | $ | 53 |  |  | $ | 261 |  |  | $ | 178 |  |  |
|  | Research and development |  | $ | 1,217 |  |  | $ | 1,206 |  |  | $ | 955 |  |  | $ | 4,676 |  |  | $ | 3,423 |  |  |
|  | Sales, general and administrative |  | $ | 347 |  |  | $ | 379 |  |  | $ | 313 |  |  | $ | 1,449 |  |  | $ | 1,136 |  |  |
| (C) Interest expense related to acquisition consideration discount to be paid in the future and amortization of debt discount. |  |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |

[0001045810-26-000019:8k_2_02:87]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2027 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 74.9 | % |
|  | Impact of acquisition-related costs and other costs |  | 0.1 | % |
| Non-GAAP gross margin* |  | 75.0 | % |
| GAAP operating expenses |  | $ | 7,700 |  |
|  | Acquisition-related costs and other costs |  | (200) |  |
| Non-GAAP operating expenses* |  | $ | 7,500 |  |
| *Beginning in the first quarter of fiscal 2027, NVIDIA will include stock-based compensation expense in its non-GAAP financial measures. Stock-based compensation expense for the first quarter of fiscal 2027 is expected to have a 0.1% impact on non-GAAP gross margin and $1.9 billion in non-GAAP operating expenses. |
