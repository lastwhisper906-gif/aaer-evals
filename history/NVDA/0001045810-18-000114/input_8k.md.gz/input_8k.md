# NVDA 8-K — 0001045810-18-000113 filed 2018-08-16

## item codes, every 8-K on or before 2018-08-16

- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2018-08-16

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-18-000113:8k_2_02:1]
EX-99.1
2
q2fy19pr.htm
Q2FY19 PRESS RELEASE

[0001045810-18-000113:8k_2_02:2]
Exhibit

[0001045810-18-000113:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-18-000113:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2019

[0001045810-18-000113:8k_2_02:5]
| • | Record revenue from all platforms - Datacenter, Gaming, Professional Visualization, Automotive |

[0001045810-18-000113:8k_2_02:6]
| • | Revenue of $3.12 billion, up 40 percent from a year ago |

[0001045810-18-000113:8k_2_02:7]
| • | GAAP EPS of $1.76, up 91 percent from a year ago |

[0001045810-18-000113:8k_2_02:8]
SANTA CLARA, Calif.-Aug. 16, 2018-NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 29, 2018, of $3.12 billion, up 40 percent from $2.23 billion a year earlier, and down 3 percent from $3.21 billion in the previous quarter.

[0001045810-18-000113:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $1.76, up 91 percent from $0.92 a year ago and down 11 percent from $1.98 in the previous quarter. Non-GAAP earnings per diluted share were $1.94, up 92 percent from $1.01 a year earlier and down 5 percent from $2.05 in the previous quarter.

[0001045810-18-000113:8k_2_02:10]
“Growth across every platform - AI, Gaming, Professional Visualization, self-driving cars - drove another great quarter,” said Jensen Huang, founder and CEO of NVIDIA. “Fueling our growth is the widening gap between demand for computing across every industry and the limits reached by traditional computing. Developers are jumping on the GPU-accelerated computing model that we pioneered for the boost they need.

[0001045810-18-000113:8k_2_02:11]
“We announced Turing this week. Turing is the world’s first ray-tracing GPU and completes the NVIDIA RTX platform, realizing a 40-year dream of the computer graphics industry. Turing is a giant leap forward and the greatest advance for computing since we introduced CUDA over a decade ago.”

[0001045810-18-000113:8k_2_02:12]
Capital Return

[0001045810-18-000113:8k_2_02:13]
During the first half of fiscal 2019, NVIDIA returned $837 million to shareholders through a combination of $655 million in share repurchases and $182 million in quarterly cash dividends.

[0001045810-18-000113:8k_2_02:14]
For fiscal 2019, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000113:8k_2_02:15]
NVIDIA will pay its next quarterly cash dividend of $0.15 per share on September 21, 2018, to all shareholders of record on August 30, 2018.

[0001045810-18-000113:8k_2_02:16]
Q2 Fiscal 2019 Summary

[0001045810-18-000113:8k_2_02:17]
| GAAP |
| ($ in millions except earnings per share) | Q2 FY19 | Q1 FY19 | Q2 FY18 | Q/Q | Y/Y |
| Revenue | $3,123 | $3,207 | $2,230 | Down 3% | Up 40% |
| Gross margin | 63.3% | 64.5% | 58.4% | Down 120 bps | Up 490 bps |
| Operating expenses | $818 | $773 | $614 | Up 6% | Up 33% |
| Operating income | $1,157 | $1,295 | $688 | Down 11% | Up 68% |
| Net income | $1,101 | $1,244 | $583 | Down 11% | Up 89% |
| Diluted earnings per share | $1.76 | $1.98 | $0.92 | Down 11% | Up 91% |

[0001045810-18-000113:8k_2_02:18]
| Non-GAAP |
| ($ in millions except earnings per share) | Q2 FY19 | Q1 FY19 | Q2 FY18 | Q/Q | Y/Y |
| Revenue | $3,123 | $3,207 | $2,230 | Down 3% | Up 40% |
| Gross margin | 63.5% | 64.7% | 58.6% | Down 120 bps | Up 490 bps |
| Operating expenses | $692 | $648 | $533 | Up 7% | Up 30% |
| Operating income | $1,290 | $1,428 | $773 | Down 10% | Up 67% |
| Net income | $1,210 | $1,285 | $638 | Down 6% | Up 90% |
| Diluted earnings per share | $1.94 | $2.05 | $1.01 | Down 5% | Up 92% |

[0001045810-18-000113:8k_2_02:19]
NVIDIA’s outlook for the third quarter of fiscal 2019 is as follows:

[0001045810-18-000113:8k_2_02:20]
| • | Revenue is expected to be $3.25 billion, plus or minus two percent. |

[0001045810-18-000113:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 62.6 percent and 62.8 percent, respectively, plus or minus 50 basis points. |

[0001045810-18-000113:8k_2_02:22]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $870 million and $730 million, respectively. |

[0001045810-18-000113:8k_2_02:23]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $20 million. |

[0001045810-18-000113:8k_2_02:24]
| • | GAAP and non-GAAP tax rates are both expected to be 9 percent, plus or minus one percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-18-000113:8k_2_02:25]
Recent Highlights

[0001045810-18-000113:8k_2_02:26]
This week, NVIDIA reinvented computer graphics with the launch of its Turing™ GPU architecture, the company’s most important innovation since the invention of the CUDA® GPU more than a decade ago. Turing is the world’s first ray-tracing GPU. It features new RT Cores to accelerate ray tracing and new Tensor Cores for AI inferencing -- which, together for the first time, make real-time ray tracing possible - as well as more powerful compute for simulation and enhanced rasterization. Turing completes the NVIDIA RTX™ platform, a new hybrid rendering graphics approach that combines rasterization, ray tracing, compute and AI to enable real-time ray tracing, the Holy Grail of computer graphics. Turing will reset the look of video games and open up the $250 billion visual effects industry to GPUs.

[0001045810-18-000113:8k_2_02:27]
NVIDIA Research continues to push the possibilities of AI with deep learning inventions such as a new technique that produces high-quality slow-motion video from standard slow-motion video; a new technique that cleans up grainy or pixelated photos simply by looking at corrupted photos; and a new method to train robots to carry out actions by observing human activity. Its work received four honors at the recent Computer Vision and Pattern Recognition Conference. It also received a $23 million contract from the Defense Advanced Research Projects Agency to work with a team of university and industry researchers to develop post-Moore’s law systems.

[0001045810-18-000113:8k_2_02:28]
Other highlights of each market platform since the first quarter earnings release include:

[0001045810-18-000113:8k_2_02:29]
Datacenter

[0001045810-18-000113:8k_2_02:30]
| • | Grew Datacenter revenue by 83 percent from a year earlier to $760 million. |

[0001045810-18-000113:8k_2_02:31]
| • | Marked the launch of Summit, the world’s fastest supercomputer, at Oak Ridge National Laboratory, powered by more than 27,000 NVIDIA® Volta Tensor Core GPUs. |

[0001045810-18-000113:8k_2_02:32]
| • | Announced that five of the world’s seven fastest supercomputers are powered by NVIDIA GPUs, based on the new list of the world’s 500 fastest systems. NVIDIA GPUs provide 56 percent of the list’s new computing power. |

[0001045810-18-000113:8k_2_02:33]
| • | Introduced NVIDIA HGX-2™, the first unified computing platform for both AI and high performance computing. A number of partners around the world, including cloud service providers, server OEMs and ODMs, are building systems incorporating HGX-2. |

[0001045810-18-000113:8k_2_02:34]
| • | Google Cloud integrated into its offerings the NVIDIA Tesla® P4 GPU optimized for AI inference and graphics virtualization. |

[0001045810-18-000113:8k_2_02:35]
| • | Researchers at Fast.ai achieved the fastest-ever AI training time using NVIDIA Tesla V100 GPUs available on Amazon Web Services. |

[0001045810-18-000113:8k_2_02:36]
| • | Launched AIRI Mini with Pure Storage and ONTAP AI with NetApp, providing enterprises with an easy-to-deploy, modular approach for implementing and scaling deep learning. |

[0001045810-18-000113:8k_2_02:37]
Gaming

[0001045810-18-000113:8k_2_02:38]
| • | Grew Gaming revenue by 52 percent from a year earlier to $1.80 billion. |

[0001045810-18-000113:8k_2_02:39]
| • | Announced there are more than 25 Max-Q GeForce gaming notebook designs offered by all major OEMs, enabling high-end performance for thin and light notebooks. |

[0001045810-18-000113:8k_2_02:40]
| • | Next-generation NVIDIA G-SYNC® HDR displays began shipping, delivering stunning 1,000 NIT HDR, stutter-free gaming. |

[0001045810-18-000113:8k_2_02:41]
Professional Visualization

[0001045810-18-000113:8k_2_02:42]
| • | Grew Professional Visualization revenue by 20 percent from a year earlier to $281 million. |

[0001045810-18-000113:8k_2_02:43]
| • | Unveiled its first Turing-based GPUs -- NVIDIA® Quadro RTX™ 8000, RTX 6000 and RTX 5000 -- which will revolutionize the craft of some 50 million designers and artists. |

[0001045810-18-000113:8k_2_02:44]
| • | Introduced the NVIDIA RTX Server, a full ray-tracing global illumination rendering server that will give a giant boost for the world’s render farms as Moore’s law ends. |

[0001045810-18-000113:8k_2_02:45]
| • | Announced broad industry support for the NVIDIA RTX platform from the world’s top graphics software companies. |

[0001045810-18-000113:8k_2_02:46]
Automotive

[0001045810-18-000113:8k_2_02:47]
| • | Grew Automotive revenue by 13 percent from a year earlier to $161 million. |

[0001045810-18-000113:8k_2_02:48]
| • | Announced that Daimler and Bosch have selected NVIDIA’s DRIVE™ platform to bring fully automated and driverless vehicles to city streets, with pilot testing to begin next year in Silicon Valley. |

[0001045810-18-000113:8k_2_02:49]
CFO Commentary

[0001045810-18-000113:8k_2_02:50]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-18-000113:8k_2_02:51]
Conference Call and Webcast Information

[0001045810-18-000113:8k_2_02:52]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2019 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 3298827. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com.

[0001045810-18-000113:8k_2_02:53]
The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2019.

[0001045810-18-000113:8k_2_02:54]
Non-GAAP Measures

[0001045810-18-000113:8k_2_02:55]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, contributions, gains from non-affiliated investments, interest expense related to amortization of debt discount, debt-related costs, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-18-000113:8k_2_02:56]
Keep Current on NVIDIA

[0001045810-18-000113:8k_2_02:57]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-18-000113:8k_2_02:58]
About NVIDIA

[0001045810-18-000113:8k_2_02:59]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-18-000113:8k_2_02:60]
###

[0001045810-18-000113:8k_2_02:61]
For further information, contact:

[0001045810-18-000113:8k_2_02:62]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-18-000113:8k_2_02:63]
Certain statements in this press release including, but not limited to, statements as to: the widening gap between demand for computing across every industry and the limits reached by traditional computing; developers jumping on the GPU accelerated computing model that we pioneered for the boost they need; Turing being the world’s first ray tracing GPU and it completing the NVIDIA RTX platform, a 40-year dream of the computer graphics industry; Turing being a giant leap forward and the greatest advance for computing since our introduction of CUDA; NVIDIA’s intended capital return for fiscal 2019; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the third quarter of fiscal 2019; NVIDIA’s expected tax rates for the third quarter of fiscal 2019; our expectation to generate variability from excess tax benefits or deficiencies related to stock-based compensation; the impact, benefits, abilities and performance of our Turing GPU architecture, including its ability to make real-time ray tracing possible along with compute simulation and enhanced rasterization, it being the world’s first ray tracing GPU, it completing the NVIDIA RTX platform, a new hybrid rendering graphics approach, the holy grail of computer graphics, it resetting the look of video games and opening up the $250 billion visual effects industry to GPUs; NVIDIA Research continuing to push the possibilities of AI with deep learning inventions, including new techniques and methods; partners around the world building systems to incorporate NVIDIA HGX-2; Google Cloud integrating the NVIDIA Tesla

[0001045810-18-000113:8k_2_02:64]
P4 GPU into its offerings; launching AIRI Mini and ONTAP AI to provide enterprises with an easy-to-deploy, modular approach for implementing and scaling deep learning; Max-Q notebook designs enabling high-end performance for thin and light notebooks; NVIDIA G-SYNC HDR displays being shipped and delivering 1000 NIT HDR stutter-free gaming; NVIDIA Quadro RTX 8000, Quadro RTX 6000 and Quadro RTX 5000 revolutionizing the craft of designers and artists; NVIDIA RTX Server giving a giant boost for the world’s render farms as Moore’s Law ends; and the use of NVIDIA’s DRIVE platform by Daimler and Bosch to bring fully automated and driverless vehicles to city streets, with pilot testing to begin next year are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward- looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-18-000113:8k_2_02:65]
© 2018 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, Quadro, Tesla, CUDA, NVIDIA DRIVE, NVIDIA G-SYNC, NVIDIA HGX, NVIDIA Isaac, NVIDIA RTX, NVIDIA Turing and Quadro RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Max-Q® is the registered trademark of Maxim Integrated Products, Inc. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-18-000113:8k_2_02:66]
NVIDIA CORPORATION

[0001045810-18-000113:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-18-000113:8k_2_02:68]
(In millions, except per share data)

[0001045810-18-000113:8k_2_02:69]
(Unaudited)

[0001045810-18-000113:8k_2_02:70]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue | $ | 3,123 |  |  | $ | 2,230 |  |  | $ | 6,330 |  |  | $ | 4,167 |  |
| Cost of revenue | 1,148 |  |  | 928 |  |  | 2,287 |  |  | 1,715 |  |
| Gross profit | 1,975 |  |  | 1,302 |  |  | 4,043 |  |  | 2,452 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 581 |  |  | 416 |  |  | 1,124 |  |  | 827 |  |
| Sales, general and administrative | 237 |  |  | 198 |  |  | 467 |  |  | 383 |  |
| Total operating expenses | 818 |  |  | 614 |  |  | 1,591 |  |  | 1,210 |  |
| Income from operations | 1,157 |  |  | 688 |  |  | 2,452 |  |  | 1,242 |  |
| Interest income | 32 |  |  | 15 |  |  | 57 |  |  | 31 |  |
| Interest expense | (14 | ) |  | (15 | ) |  | (29 | ) |  | (31 | ) |
| Other, net | 5 |  |  | (4 | ) |  | 11 |  |  | (21 | ) |
| Total other income (expense) | 23 |  |  | (4 | ) |  | 39 |  |  | (21 | ) |
| Income before income tax | 1,180 |  |  | 684 |  |  | 2,491 |  |  | 1,221 |  |
| Income tax expense | 79 |  |  | 101 |  |  | 146 |  |  | 130 |  |
| Net income | $ | 1,101 |  |  | $ | 583 |  |  | $ | 2,345 |  |  | $ | 1,091 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.81 |  |  | $ | 0.98 |  |  | $ | 3.86 |  |  | $ | 1.83 |  |
| Diluted | $ | 1.76 |  |  | $ | 0.92 |  |  | $ | 3.74 |  |  | $ | 1.71 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 607 |  |  | 597 |  |  | 607 |  |  | 595 |  |
| Diluted | 626 |  |  | 633 |  |  | 627 |  |  | 637 |  |

[0001045810-18-000113:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | July 29, |  | January 28, |
|  |  |  | 2018 |  | 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 7,943 |  |  | $ | 7,108 |  |
|  | Accounts receivable, net |  | 1,662 |  |  | 1,265 |  |
|  | Inventories |  | 1,090 |  |  | 796 |  |
|  | Prepaid expenses and other current assets |  | 136 |  |  | 86 |  |
|  | Total current assets |  | 10,831 |  |  | 9,255 |  |
| Property and equipment, net |  | 1,162 |  |  | 997 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 51 |  |  | 52 |  |
| Other assets |  | 220 |  |  | 319 |  |
|  | Total assets |  | $ | 12,882 |  |  | $ | 11,241 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 800 |  |  | $ | 596 |  |
|  | Accrued and other current liabilities |  | 648 |  |  | 542 |  |
|  | Convertible short-term debt |  | 14 |  |  | 15 |  |
|  | Total current liabilities |  | 1,462 |  |  | 1,153 |  |
| Long-term debt |  | 1,987 |  |  | 1,985 |  |
| Other long-term liabilities |  | 638 |  |  | 632 |  |
|  | Total liabilities |  | 4,087 |  |  | 3,770 |  |
| Shareholders' equity |  | 8,795 |  |  | 7,471 |  |
|  | Total liabilities and shareholders' equity |  | $ | 12,882 |  |  | $ | 11,241 |  |

[0001045810-18-000113:8k_2_02:72]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 29, |  | April 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2018 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 1,975 |  |  | $ | 2,068 |  |  | $ | 1,302 |  |  | $ | 4,043 |  |  | $ | 2,452 |  |
| GAAP gross margin |  | 63.3 | % |  | 64.5 | % |  | 58.4 | % |  | 63.9 | % |  | 58.8 | % |
| Stock-based compensation expense (A) |  | 8 |  |  | 8 |  |  | 4 |  |  | 16 |  |  | 8 |  |
| Non-GAAP gross profit |  | $ | 1,983 |  |  | $ | 2,076 |  |  | $ | 1,306 |  |  | $ | 4,059 |  |  | $ | 2,460 |  |
| Non-GAAP gross margin |  | 63.5 | % |  | 64.7 | % |  | 58.6 | % |  | 64.1 | % |  | 59.0 | % |
| GAAP operating expenses |  | $ | 818 |  |  | $ | 773 |  |  | $ | 614 |  |  | $ | 1,591 |  |  | $ | 1,210 |  |
| Stock-based compensation expense (A) |  | (124 | ) |  | (121 | ) |  | (77 | ) |  | (246 | ) |  | (150 | ) |
| Acquisition-related costs (B) |  | (2 | ) |  | (2 | ) |  | (4 | ) |  | (4 | ) |  | (8 | ) |
| Legal settlement costs |  | — |  |  | (2 | ) |  | — |  |  | — |  |  | — |  |
| Contributions |  | — |  |  | — |  |  | — |  |  | — |  |  | (2 | ) |
| Non-GAAP operating expenses |  | $ | 692 |  |  | $ | 648 |  |  | $ | 533 |  |  | $ | 1,341 |  |  | $ | 1,050 |  |
| GAAP income from operations |  | $ | 1,157 |  |  | $ | 1,295 |  |  | $ | 688 |  |  | $ | 2,452 |  |  | $ | 1,242 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 133 |  |  | 133 |  |  | 85 |  |  | 266 |  |  | 168 |  |
| Non-GAAP income from operations |  | $ | 1,290 |  |  | $ | 1,428 |  |  | $ | 773 |  |  | $ | 2,718 |  |  | $ | 1,410 |  |
| GAAP other income (expense) |  | $ | 23 |  |  | $ | 16 |  |  | $ | (4 | ) |  | $ | 39 |  |  | $ | (21 | ) |
| Gains from non-affiliated investments (C) |  | (2 | ) |  | (6 | ) |  | — |  |  | (8 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | — |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |
| Debt-related costs (D) |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 17 |  |
| Non-GAAP other income (expense) |  | $ | 21 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 32 |  |  | $ | (1 | ) |
| GAAP net income |  | $ | 1,101 |  |  | $ | 1,244 |  |  | $ | 583 |  |  | $ | 2,345 |  |  | $ | 1,091 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 131 |  |  | 128 |  |  | 89 |  |  | 259 |  |  | 188 |  |
| Income tax impact of non-GAAP adjustments (E) |  | (22 | ) |  | (87 | ) |  | (34 | ) |  | (109 | ) |  | (108 | ) |
| Non-GAAP net income |  | $ | 1,210 |  |  | $ | 1,285 |  |  | $ | 638 |  |  | $ | 2,495 |  |  | $ | 1,171 |  |

[0001045810-18-000113:8k_2_02:73]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 29, |  | April 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2018 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 1.76 |  |  | $ | 1.98 |  |  | $ | 0.92 |  |  | $ | 3.74 |  |  | $ | 1.71 |  |
| Non-GAAP |  | $ | 1.94 |  |  | $ | 2.05 |  |  | $ | 1.01 |  |  | $ | 3.99 |  |  | $ | 1.87 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 626 |  |  | 627 |  |  | 633 |  |  | 627 |  |  | 637 |  |
| Anti-dilution impact from note hedge (F) |  | (1 | ) |  | (1 | ) |  | (4 | ) |  | (1 | ) |  | (10 | ) |
| Non-GAAP |  | 625 |  |  | 626 |  |  | 629 |  |  | 626 |  |  | 627 |  |
| GAAP net cash provided by operating activities |  | $ | 913 |  |  | $ | 1,445 |  |  | $ | 705 |  |  | $ | 2,358 |  |  | $ | 987 |  |
| Purchase of property and equipment and intangible assets |  | (128 | ) |  | (118 | ) |  | (55 | ) |  | (247 | ) |  | (108 | ) |
| Free cash flow |  | $ | 785 |  |  | $ | 1,327 |  |  | $ | 650 |  |  | $ | 2,111 |  |  | $ | 879 |  |

[0001045810-18-000113:8k_2_02:74]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 29, |  | April 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2018 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 8 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 8 |  |
| Research and development |  | $ | 76 |  |  | $ | 74 |  |  | $ | 44 |  |  | $ | 150 |  |  | $ | 85 |  |
| Sales, general and administrative |  | $ | 48 |  |  | $ | 47 |  |  | $ | 33 |  |  | $ | 96 |  |  | $ | 65 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Consists of unrealized gains from non-affiliated investments. |
| (D) Consists of loss on early debt conversions and termination of interest rate swap. |
| (E) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (F) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-18-000113:8k_2_02:75]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2019 Outlook |
| GAAP gross margin |  | 62.6 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 62.8 | % |
|  |  |  | Q3 FY2019 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 870 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (140 | ) |
| Non-GAAP operating expenses |  | $ | 730 |  |
