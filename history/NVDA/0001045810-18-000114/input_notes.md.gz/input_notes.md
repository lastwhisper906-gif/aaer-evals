# NVDA notes — 0001045810-18-000114


## nvda:BalanceSheetComponentsTextBlock

[0001045810-18-000114:notes:1]
[same as prior period, unchanged from 0001045810-18-000080:notes:1]

[0001045810-18-000114:notes:2]
[same as prior period, unchanged from 0001045810-18-000080:notes:2]

[0001045810-18-000114:notes:3]
|  | July 29, |  | January 28, |
|  | 2018 |  | 2018 |
| Inventories: | (In millions) |
| Raw materials | $ | 421 |  |  | $ | 227 |  |
| Work in-process | 266 |  |  | 192 |  |
| Finished goods | 403 |  |  | 377 |  |
| Total inventories | $ | 1,090 |  |  | $ | 796 |  |

[0001045810-18-000114:notes:4]
As of July 29, 2018, we had outstanding inventory purchase obligations totaling $1.91 billion.

[0001045810-18-000114:notes:5]
|  | July 29, |  | January 28, |
|  | 2018 |  | 2018 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 248 |  |  | $ | 181 |  |
| Accrued payroll and related expenses | 170 |  |  | 172 |  |
| Deferred revenue (1) | 77 |  |  | 53 |  |
| Taxes payable | 39 |  |  | 33 |  |
| Coupon interest on debt obligations | 20 |  |  | 20 |  |
| Accrued royalties | 19 |  |  | 17 |  |
| Warranty accrual (2) | 16 |  |  | 15 |  |
| Professional service fees | 15 |  |  | 15 |  |
| Other | 44 |  |  | 36 |  |
| Total accrued and other current liabilities | $ | 648 |  |  | $ | 542 |  |

[0001045810-18-000114:notes:6]
[same as prior period, unchanged from 0001045810-18-000080:notes:6]

[0001045810-18-000114:notes:7]
[same as prior period, unchanged from 0001045810-18-000080:notes:7]

[0001045810-18-000114:notes:8]
|  | July 29, |  | January 28, |
|  | 2018 |  | 2018 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 544 |  |  | $ | 559 |  |
| Deferred revenue (2) | 27 |  |  | 15 |  |
| Deferred income tax liability | 21 |  |  | 18 |  |
| Employee benefits liability | 18 |  |  | 12 |  |
| Deferred rent | 14 |  |  | 9 |  |
| Other | 14 |  |  | 19 |  |
| Total other long-term liabilities | $ | 638 |  |  | $ | 632 |  |

[0001045810-18-000114:notes:9]
| (1) | As of July 29, 2018, represents the long-term portion of the one-time transition tax payable of $337 million, as well as unrecognized tax benefits of $191 million and related interest and penalties of $16 million. |

[0001045810-18-000114:notes:10]
[same as prior period, unchanged from 0001045810-18-000080:notes:10]


## nvda:DebtSecuritiesAvailableforsaleTableTextBlock

[0001045810-18-000114:notes:11]
The following is a summary of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018:

[0001045810-18-000114:notes:12]
|  | July 29, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,491 |  |  | $ | 1 |  |  | $ | (8 | ) |  | $ | 2,484 |  |  | $ | — |  |  | $ | 2,484 |  |
| Debt securities issued by the United States Treasury | 2,412 |  |  | — |  |  | (2 | ) |  | 2,410 |  |  | — |  |  | 2,410 |  |
| Debt securities of United States government agencies | 1,993 |  |  | — |  |  | (6 | ) |  | 1,987 |  |  | — |  |  | 1,987 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Asset-backed securities | 206 |  |  | — |  |  | (2 | ) |  | 204 |  |  | — |  |  | 204 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 107 |  |  | 2 |  |  | (1 | ) |  | 108 |  |  | — |  |  | 108 |  |
| Foreign government bonds | 32 |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total | $ | 7,724 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 7,708 |  |  | $ | 483 |  |  | $ | 7,225 |  |

[0001045810-18-000114:notes:13]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

[0001045810-18-000114:notes:14]
The following table provides the breakdown of unrealized losses as of July 29, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-18-000114:notes:15]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 925 |  |  | $ | (1 | ) |  | $ | 559 |  |  | $ | (5 | ) |  | $ | 1,484 |  |  | $ | (6 | ) |
| Debt securities issued by the United States Treasury | 754 |  |  | — |  |  | 410 |  |  | (2 | ) |  | 1,164 |  |  | (2 | ) |
| Corporate debt securities | 310 |  |  | (1 | ) |  | 742 |  |  | (7 | ) |  | 1,052 |  |  | (8 | ) |
| Asset-backed securities | 49 |  |  | (1 | ) |  | 155 |  |  | (1 | ) |  | 204 |  |  | (2 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 15 |  |  | — |  |  | 31 |  |  | (1 | ) |  | 46 |  |  | (1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |  | — |  |
|  | $ | 2,053 |  |  | $ | (3 | ) |  | $ | 1,928 |  |  | $ | (16 | ) |  | $ | 3,981 |  |  | $ | (19 | ) |

[0001045810-18-000114:notes:16]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018 are shown below by contractual maturity.

[0001045810-18-000114:notes:17]
|  | July 29, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,991 |  |  | $ | 5,981 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,705 |  |  | 1,699 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 28 |  |  | 28 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,724 |  |  | $ | 7,708 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |


## nvda:RevenueFromContractwithCustomerPolicyTextBlock

[0001045810-18-000114:notes:18]
Revenue Recognition

[0001045810-18-000114:notes:19]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-18-000114:notes:20]
Product Sales Revenue

[0001045810-18-000114:notes:21]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-18-000114:notes:22]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-18-000114:notes:23]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-18-000114:notes:24]
License and Development Arrangements

[0001045810-18-000114:notes:25]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-18-000114:notes:26]
Software Licensing

[0001045810-18-000114:notes:27]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-18-000114:notes:28]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-18-000114:notes:29]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,805 |  |  | $ | 1,186 |  |  | $ | 3,528 |  |  | $ | 2,213 |  |
| Professional Visualization | 281 |  |  | 235 |  |  | 532 |  |  | 440 |  |
| Datacenter | 760 |  |  | 416 |  |  | 1,461 |  |  | 825 |  |
| Automotive | 161 |  |  | 142 |  |  | 306 |  |  | 282 |  |
| OEM & IP | 116 |  |  | 251 |  |  | 503 |  |  | 407 |  |
| Total revenue | $ | 3,123 |  |  | $ | 2,230 |  |  | $ | 6,330 |  |  | $ | 4,167 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-18-000114:notes:30]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of July 29, 2018 and January 28, 2018:

[0001045810-18-000114:notes:31]
|  | July 29, |  | January 28, |
|  | 2018 |  | 2018 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 1,048 |  |  | $ | 1,091 |  |
| Estimated weighted average remaining amortization period | (In years) |
| RSUs, PSUs, and market-based PSUs | 2.1 |  |  | 2.3 |  |
| ESPP | 0.9 |  |  | 0.7 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001045810-18-000114:notes:32]
Basis of Presentation

[0001045810-18-000114:notes:33]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2018 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-18-000114:notes:34]
Commitments and Contingencies

[0001045810-18-000114:notes:35]
Litigation

[0001045810-18-000114:notes:36]
Polaris Innovations Limited

[0001045810-18-000114:notes:37]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-18-000114:notes:38]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.

[0001045810-18-000114:notes:39]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for four U.S. patents and declined to institute IPRs on two U.S. patents. The USPTO issued a Final Written Decision on the IPR relating to one of the patents on June 19, 2018, finding claims 1-23 and 28 unpatentable but that claims 24-27 were not proved unpatentable.

[0001045810-18-000114:notes:40]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

[0001045810-18-000114:notes:41]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.

[0001045810-18-000114:notes:42]
An oral hearing is scheduled for February 21, 2019.

[0001045810-18-000114:notes:43]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

[0001045810-18-000114:notes:44]
ZiiLabs 1 Patents Lawsuit

[0001045810-18-000114:notes:45]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

[0001045810-18-000114:notes:46]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. patent.

[0001045810-18-000114:notes:47]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the ITC investigation over the ZiiLabs 2 patents.

[0001045810-18-000114:notes:48]
ZiiLabs 2 Patents Lawsuits

[0001045810-18-000114:notes:49]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

[0001045810-18-000114:notes:50]
On February 22, 2018, the Delaware Court stayed the district court action on the ZiiLabs 2 patents pending the resolution of the ITC Investigation over the ZiiLabs 2 patents.

[0001045810-18-000114:notes:51]
On December 29, 2017, ZiiLabs filed a request with the U.S. International Trade Commission, or USITC, to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

[0001045810-18-000114:notes:52]
On February 28, 2018, NVIDIA and the other respondents answered the ITC complaint and asserted various defenses including non-infringement and invalidity of the four asserted ZiiLabs 2 patents.

[0001045810-18-000114:notes:53]
On May 10, 2018, the Administrative Law Judge presiding over the investigation issued an Initial Determination terminating the investigation with respect to one of the patents.  On July 17, 2018, the USITC affirmed this decision on modified grounds.

[0001045810-18-000114:notes:54]
Accounting for Loss Contingencies

[0001045810-18-000114:notes:55]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 29, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-18-000114:notes:56]
[same as prior period, unchanged from 0001045810-18-000080:notes:50]

[0001045810-18-000114:notes:57]
[same as prior period, unchanged from 0001045810-18-000080:notes:51]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001045810-18-000114:notes:58]
The following table shows the changes in deferred revenue during the first half of fiscal year 2019:

[0001045810-18-000114:notes:59]
|  | July 29, |
|  | 2018 |
|  | (In millions) |
| Balance as of January 28, 2018 | $ | 68 |  |
| Adjustment to retained earnings upon adoption of new revenue standard | (5 | ) |
| Balance as of January 29, 2018 | 63 |  |
| Deferred revenue added during the period | 194 |  |
| Revenue recognized during the period | (153 | ) |
| Balance as of July 29, 2018 | $ | 104 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-18-000114:notes:60]
Debt

[0001045810-18-000114:notes:61]
Long-Term Debt

[0001045810-18-000114:notes:62]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-18-000114:notes:63]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-18-000114:notes:64]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-18-000114:notes:65]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-18-000114:notes:66]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |

[0001045810-18-000114:notes:67]
Convertible Debt

[0001045810-18-000114:notes:68]
1.00% Convertible Senior Notes Due 2018

[0001045810-18-000114:notes:69]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through the second quarter of fiscal year 2019, we had settled an aggregate of $1.49 billion of the Convertible Notes. The Convertible Notes will mature on December 1, 2018 and we had $14 million in principal amount outstanding as of July 29, 2018. Effective August 1, 2018, holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date of December 1, 2018 regardless of conversion conditions.

[0001045810-18-000114:notes:70]
During the second quarter of fiscal year 2019, we paid cash to settle an insignificant amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $11 million in principal amount of the Convertible Notes which are expected to be settled in the third quarter of fiscal year 2019. During the second quarter of fiscal year 2019, we also issued one thousand shares of our common stock for the excess conversion value and the related loss on early conversions was not significant. Based on the closing price of our common stock of $252.02 on the last trading day of the second quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $162 million. As of July 29, 2018, the conversion rate was 49.94 shares of common stock per $1,000 principal amount of the Convertible Notes.

[0001045810-18-000114:notes:71]
Note Hedges

[0001045810-18-000114:notes:72]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.02 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through July 29, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.49 billion in principal amount of the Convertible Notes.

[0001045810-18-000114:notes:73]
Revolving Credit Facility

[0001045810-18-000114:notes:74]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 29, 2018, we had not borrowed any amounts under this agreement.

[0001045810-18-000114:notes:75]
Commercial Paper

[0001045810-18-000114:notes:76]
We have a $575 million commercial paper program to support general corporate purposes. As of July 29, 2018, we had not issued any commercial paper.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-18-000114:notes:77]
[same as prior period, unchanged from 0001045810-18-000080:notes:71]

[0001045810-18-000114:notes:78]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of July 29, 2018 and January 28, 2018.

[0001045810-18-000114:notes:79]
[same as prior period, unchanged from 0001045810-18-000080:notes:73]

[0001045810-18-000114:notes:80]
The table below presents the notional value of our foreign currency forward contracts outstanding as of July 29, 2018 and January 28, 2018:

[0001045810-18-000114:notes:81]
|  | July 29, 2018 |  | January 28, 2018 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 396 |  |  | $ | 104 |  |
| Not designated for hedge accounting | $ | 92 |  |  | $ | 94 |  |

[0001045810-18-000114:notes:82]
As of July 29, 2018, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-18-000114:notes:83]
During the second quarter and first half of fiscal years 2019 and 2018, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-18-000114:notes:84]
[same as prior period, unchanged from 0001045810-18-000080:notes:78]

[0001045810-18-000114:notes:85]
Our stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-18-000114:notes:86]
Our Condensed Consolidated Statements of Income include stock-based compensation expense, net of amounts allocated to inventory, as follows:

[0001045810-18-000114:notes:87]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2018 |  | July 30, 2017 |  | July 29, 2018 |  | July 30, 2017 |
|  | (In millions) |
| Cost of revenue | $ | 8 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 8 |  |
| Research and development | 76 |  |  | 44 |  |  | 150 |  |  | 85 |  |
| Sales, general and administrative | 48 |  |  | 33 |  |  | 96 |  |  | 65 |  |
| Total | $ | 132 |  |  | $ | 81 |  |  | $ | 262 |  |  | $ | 158 |  |

[0001045810-18-000114:notes:88]
[same as prior period, unchanged from 0001045810-18-000080:notes:82]

[0001045810-18-000114:notes:89]
[same as prior period, unchanged from 0001045810-18-000080:notes:83]

[0001045810-18-000114:notes:90]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balances, January 28, 2018 | 22 |  |  | $ | 66.72 |  |
| Granted (1) (2) | 1 |  |  | $ | 240.22 |  |
| Vested restricted stock | (5 | ) |  | $ | 39.64 |  |
| Canceled and forfeited | — |  |  | $ | — |  |
| Balances, July 29, 2018 | 18 |  |  | $ | 84.56 |  |

[0001045810-18-000114:notes:91]
| (1) | Includes the number of PSUs granted that will be issued and eligible to vest if the maximum corporate financial performance goal for fiscal year 2019 is achieved. Depending on the actual level of the corporate performance achievement at the end of fiscal year 2019, the PSUs issued could be up to 0.3 million shares. |

[0001045810-18-000114:notes:92]
| (2) | Includes the number of market-based PSUs granted that will be issued and eligible to vest if the maximum goal for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to those of the companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 45 thousand shares. |

[0001045810-18-000114:notes:93]
Of the total fair value of equity awards granted during the second quarter and first half of fiscal year 2019, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $12 million and $31 million, respectively. Of the total fair value of equity awards granted during the second quarter and first half of fiscal year 2018, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $10 million and $39 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-18-000114:notes:94]
[same as prior period, unchanged from 0001045810-18-000080:notes:89]

[0001045810-18-000114:notes:95]
[same as prior period, unchanged from 0001045810-18-000080:notes:90]

[0001045810-18-000114:notes:96]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 1,101 |  |  | $ | 583 |  |  | $ | 2,345 |  |  | $ | 1,091 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 607 |  |  | 597 |  |  | 607 |  |  | 595 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards | 18 |  |  | 26 |  |  | 19 |  |  | 26 |  |
| 1.00% Convertible Senior Notes | 1 |  |  | 4 |  |  | 1 |  |  | 9 |  |
| Warrants issued with the 1.00% ConvertibleSenior Notes | — |  |  | 6 |  |  | — |  |  | 7 |  |
| Diluted weighted average shares | 626 |  |  | 633 |  |  | 627 |  |  | 637 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.81 |  |  | $ | 0.98 |  |  | $ | 3.86 |  |  | $ | 1.83 |  |
| Diluted (2) | $ | 1.76 |  |  | $ | 0.92 |  |  | $ | 3.74 |  |  | $ | 1.71 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | — |  |  | — |  |  | 1 |  |  | 1 |  |

[0001045810-18-000114:notes:97]
[same as prior period, unchanged from 0001045810-18-000080:notes:92]

[0001045810-18-000114:notes:98]
[same as prior period, unchanged from 0001045810-18-000080:notes:93]

[0001045810-18-000114:notes:99]
The 1.00% Convertible Senior Notes Due 2018, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.02 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share. As of July 29, 2018, there were no warrants outstanding.

[0001045810-18-000114:notes:100]
[same as prior period, unchanged from 0001045810-18-000080:notes:97]


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-18-000114:notes:101]
|  |  | Fair Value at |
|  | Pricing Category |  | July 29, 2018 |  | January 28, 2018 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 2,484 |  |  | $ | 1,295 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 2,410 |  |  | $ | 573 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,987 |  |  | $ | 815 |  |
| Money market funds | Level 1 |  | $ | 483 |  |  | $ | 3,789 |  |
| Asset-backed securities | Level 2 |  | $ | 204 |  |  | $ | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 108 |  |  | $ | 130 |  |
| Foreign government bonds | Level 2 |  | $ | 32 |  |  | $ | 41 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 175 |  |  | $ | 189 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 970 |  |  | $ | 982 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 970 |  |  | $ | 986 |  |

[0001045810-18-000114:notes:102]
| (1) | These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information. |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-18-000114:notes:103]
[same as prior period, unchanged from 0001045810-18-000080:notes:99]

[0001045810-18-000114:notes:104]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 financial assets and liabilities for the second quarter of fiscal year 2019. Level 3 financial assets and liabilities are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-18-000114:notes:105]
[same as prior period, unchanged from 0001045810-18-000080:notes:102]

[0001045810-18-000114:notes:106]
We recognized income tax expense of $79 million and $146 million for the second quarter and first half of fiscal year 2019, respectively, and $101 million and $130 million for the second quarter and first half of fiscal year 2018, respectively. Income tax expense as a percentage of income before income tax for the second quarter and first half of fiscal year 2019 was 6.7% and 5.9%, respectively, and 14.8% and 10.7% for the second quarter and first half of fiscal year 2018, respectively.

[0001045810-18-000114:notes:107]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2019 as compared to the same periods in the prior fiscal year was primarily due to a decrease in the U.S. statutory tax rate from 35% to 21% as a result of U.S. tax reform, partially offset by a decrease in the impact of tax benefits from stock-based compensation.

[0001045810-18-000114:notes:108]
Our effective tax rates for the first half of fiscal years 2019 and 2018 of 5.9% and 10.7%, respectively, were lower than the U.S. federal statutory rates of 21% and 33.9%, for fiscal years 2019 and 2018, respectively, due to higher income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-18-000114:notes:109]
In December 2017, the SEC issued guidance that allows companies to record provisional amounts for the tax effects of the Tax Cuts and Job Acts, or TCJA, during a measurement period not to exceed one year. The TCJA was effective in the fourth quarter of fiscal year 2018 and we have recorded provisional amounts based on reasonable estimates for those tax effects. For the second quarter of fiscal year 2019, we have not recorded any adjustments to our provisional amounts. We will continue our analysis of these provisional amounts, which are still subject to change during the measurement period based on further guidance on accounting interpretations from the FASB and application of the law from the U.S. Department of Treasury, including proposed regulations relating to the one-time transition tax issued on August 1, 2018.

[0001045810-18-000114:notes:110]
The TCJA subjects a U.S. corporation to tax on its global intangible low-taxed income, or GILTI. Under U.S. GAAP, we can make an accounting policy election to either treat taxes due on the GILTI as a current period expense or factor such amounts into our measurement of deferred taxes. Given the complexity of the GILTI provisions, we are still evaluating its effects and have not yet determined our accounting policy. We expect to complete our analysis within the measurement period. For the second quarter of fiscal year 2019, because we are still evaluating the effects of the GILTI provisions, we have included tax expense related to GILTI for current-year operations in our estimated annual effective tax rate and have not provided for GILTI on deferred items.

[0001045810-18-000114:notes:111]
For the first half of fiscal year 2019, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 28, 2018.

[0001045810-18-000114:notes:112]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 29, 2018, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-18-000114:notes:113]
On August 1, 2018, the Internal Revenue Service and the Department of the Treasury issued proposed regulations relating to the one-time transition tax provision of the TCJA. Any required adjustment must be recorded during the measurement period as determined in accordance with the SEC guidance. While we are currently evaluating the potential impact of the regulations, we expect to record a discrete tax benefit in the third quarter of fiscal year 2019 related to our provisional U.S. tax reform transition tax amount.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-18-000114:notes:114]
[same as prior period, unchanged from 0001045810-18-000080:notes:110]

[0001045810-18-000114:notes:115]
[same as prior period, unchanged from 0001045810-18-000080:notes:111]

[0001045810-18-000114:notes:116]
|  | July 29, 2018 |  | January 28, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (184 | ) |  | $ | 11 |  |  | $ | 195 |  |  | $ | (180 | ) |  | $ | 15 |  |
| Patents and licensed technology | 485 |  |  | (445 | ) |  | 40 |  |  | 469 |  |  | (432 | ) |  | 37 |  |
| Total intangible assets | $ | 680 |  |  | $ | (629 | ) |  | $ | 51 |  |  | $ | 664 |  |  | $ | (612 | ) |  | $ | 52 |  |

[0001045810-18-000114:notes:117]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during the first half of fiscal year 2019. Amortization expense associated with intangible assets was $6 million and $17 million for the second quarter and first half of fiscal year 2019, respectively, and $14 million and $29 million for the second quarter and first half of fiscal year 2018, respectively. Future amortization expense related to the net carrying amount of intangible assets as of July 29, 2018 is estimated to be $12 million for the remainder of fiscal year 2019, $20 million in fiscal year 2020, $11 million in fiscal year 2021, $4 million in fiscal year 2022, $3 million in fiscal year 2023, and $1 million in fiscal 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-18-000114:notes:118]
Marketable Securities

[0001045810-18-000114:notes:119]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-18-000114:notes:120]
The gross unrealized losses related to fixed income securities were primarily due to changes in interest rates, which we believe are temporary in nature. We have the intent and ability to hold our investments until maturity. For the second quarter and first half of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-18-000114:notes:121]
New Revenue Accounting Standard

[0001045810-18-000114:notes:122]
Method and Impact of Adoption

[0001045810-18-000114:notes:123]
On January 29, 2018, we adopted the new revenue accounting standard using the modified retrospective method and applied it to contracts that were not completed as of that date. Upon adoption, we recognized the cumulative effect of the new standard as a $7 million increase to opening retained earnings, net of tax. Comparative information for prior periods has not been adjusted. The impact of the new standard on our consolidated financial statements for the second quarter and first half of fiscal year 2019 was not significant.

[0001045810-18-000114:notes:124]
Deferred Revenue and Performance Obligations

[0001045810-18-000114:notes:125]
Deferred revenue is comprised mainly of customer advances and deferrals related to license and development arrangements and PCS related to software licensing. The following table shows the changes in deferred revenue during the first half of fiscal year 2019:

[0001045810-18-000114:notes:126]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of July 29, 2018, the amount of our remaining performance obligations that have not been recognized as revenue was $235 million, of which we expect to recognize approximately 50% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-18-000114:notes:127]
Refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for additional information, including disaggregated revenue disclosures.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-18-000114:notes:128]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000114:notes:129]
Recently Adopted Accounting Pronouncements

[0001045810-18-000114:notes:130]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We adopted this guidance on January 29, 2018 using the modified retrospective approach. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000114:notes:131]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We are now required to recognize changes in the fair value of our equity investments through net income rather than other comprehensive income. We adopted this guidance in the first quarter of fiscal year 2019 and applied it prospectively. The adoption of this guidance did not have a significant impact on our consolidated financial statements.

[0001045810-18-000114:notes:132]
Recent Accounting Pronouncement Not Yet Adopted

[0001045810-18-000114:notes:133]
In February 2016 and July 2018, the FASB issued accounting standards updates regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The FASB also recently provided a practical expedient transition method to adopt the new lease accounting requirements. We are evaluating the impact of adopting the new lease accounting standards on our consolidated financial statements, systems and processes in conjunction with our review of lease agreements. The updates will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-18-000114:notes:134]
[same as prior period, unchanged from 0001045810-18-000080:notes:135]

[0001045810-18-000114:notes:135]
U.S. GAAP requires that upon issuance of a guarantee, the guarantor must recognize a liability for the fair value of the obligation it assumes under that guarantee.

[0001045810-18-000114:notes:136]
[same as prior period, unchanged from 0001045810-18-000080:notes:137]

[0001045810-18-000114:notes:137]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product returns and estimated product warranty liabilities was $16 million and $15 million as of July 29, 2018 and January 28, 2018, respectively.

[0001045810-18-000114:notes:138]
[same as prior period, unchanged from 0001045810-18-000080:notes:139]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-18-000114:notes:139]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2018 |  | July 30, 2017 |  | July 29, 2018 |  | July 30, 2017 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 43 |  |
| Stock-based compensation expense | (132 | ) |  | (81 | ) |  | (262 | ) |  | (158 | ) |
| Unallocated cost of revenue and operating expenses | (65 | ) |  | (59 | ) |  | (129 | ) |  | (114 | ) |
| Acquisition-related costs | (2 | ) |  | (4 | ) |  | (4 | ) |  | (8 | ) |
| Contributions | — |  |  | — |  |  | — |  |  | (2 | ) |
| Total | $ | (199 | ) |  | $ | (144 | ) |  | $ | (395 | ) |  | $ | (239 | ) |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-18-000114:notes:140]
The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-18-000114:notes:141]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 843 |  |  | $ | 674 |  |  | $ | 1,810 |  |  | $ | 1,277 |  |
| China | 760 |  |  | 481 |  |  | 1,514 |  |  | 810 |  |
| Other Asia Pacific | 676 |  |  | 420 |  |  | 1,259 |  |  | 797 |  |
| United States | 413 |  |  | 278 |  |  | 847 |  |  | 631 |  |
| Europe | 234 |  |  | 178 |  |  | 469 |  |  | 360 |  |
| Other Americas | 197 |  |  | 199 |  |  | 431 |  |  | 292 |  |
| Total revenue | $ | 3,123 |  |  | $ | 2,230 |  |  | $ | 6,330 |  |  | $ | 4,167 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-18-000114:notes:142]
The table below presents details of our reportable segments and the “All Other” category.

[0001045810-18-000114:notes:143]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 29, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 2,656 |  |  | $ | 467 |  |  | $ | — |  |  | $ | 3,123 |  |
| Depreciation and amortization expense | $ | 43 |  |  | $ | 12 |  |  | $ | 3 |  |  | $ | 58 |  |
| Operating income (loss) | $ | 1,259 |  |  | $ | 97 |  |  | $ | (199 | ) |  | $ | 1,157 |  |
| Three Months Ended July 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,897 |  |  | $ | 333 |  |  | $ | — |  |  | $ | 2,230 |  |
| Depreciation and amortization expense | $ | 29 |  |  | $ | 9 |  |  | $ | 11 |  |  | $ | 49 |  |
| Operating income (loss) | $ | 761 |  |  | $ | 71 |  |  | $ | (144 | ) |  | $ | 688 |  |
| Six Months Ended July 29, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 5,421 |  |  | $ | 909 |  |  | $ | — |  |  | $ | 6,330 |  |
| Depreciation and amortization expense | $ | 83 |  |  | $ | 22 |  |  | $ | 11 |  |  | $ | 116 |  |
| Operating income (loss) | $ | 2,653 |  |  | $ | 194 |  |  | $ | (395 | ) |  | $ | 2,452 |  |
| Six Months Ended July 30, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 3,459 |  |  | $ | 665 |  |  | $ | 43 |  |  | $ | 4,167 |  |
| Depreciation and amortization expense | $ | 57 |  |  | $ | 18 |  |  | $ | 21 |  |  | $ | 96 |  |
| Operating income (loss) | $ | 1,363 |  |  | $ | 118 |  |  | $ | (239 | ) |  | $ | 1,242 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-18-000114:notes:144]
[same as prior period, unchanged from 0001045810-18-000080:notes:143]

[0001045810-18-000114:notes:145]
[same as prior period, unchanged from 0001045810-18-000080:notes:144]

[0001045810-18-000114:notes:146]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying architecture.

[0001045810-18-000114:notes:147]
While our GPU and CUDA architecture is unified, our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for artificial intelligence, or AI, data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for consoles and mobile gaming and entertainment devices.

[0001045810-18-000114:notes:148]
Under the single unifying architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-18-000114:notes:149]
[same as prior period, unchanged from 0001045810-18-000080:notes:148]

[0001045810-18-000114:notes:150]
[same as prior period, unchanged from 0001045810-18-000080:notes:149]

[0001045810-18-000114:notes:151]
[same as prior period, unchanged from 0001045810-18-000080:notes:150]

[0001045810-18-000114:notes:152]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal years 2019 and 2018.

[0001045810-18-000114:notes:153]
Accounts receivable from significant customers, those representing more than 10% of total accounts receivable, aggregated approximately 26% of our accounts receivable balance from two customers as of July 29, 2018, and approximately 28% of our accounts receivable balance from two customers as of January 28, 2018.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-18-000114:notes:154]
[same as prior period, unchanged from 0001045810-18-000080:notes:154]

[0001045810-18-000114:notes:155]
Significant Accounting Policies

[0001045810-18-000114:notes:156]
Except for the accounting policy for revenue recognition, which was updated as a result of adopting a new accounting standard related to revenue recognition, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

[0001045810-18-000114:notes:157]
[same as prior period, unchanged from 0001045810-18-000080:notes:155]

[0001045810-18-000114:notes:158]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The second quarters of fiscal years 2019 and 2018 were both 13-week quarters.

[0001045810-18-000114:notes:159]
[same as prior period, unchanged from 0001045810-18-000080:notes:157]

[0001045810-18-000114:notes:160]
[same as prior period, unchanged from 0001045810-18-000080:notes:158]

[0001045810-18-000114:notes:161]
[same as prior period, unchanged from 0001045810-18-000080:notes:159]

[0001045810-18-000114:notes:162]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-18-000114:notes:163]
[same as prior period, unchanged from 0001045810-18-000080:notes:161]

[0001045810-18-000114:notes:164]
[same as prior period, unchanged from 0001045810-18-000080:notes:162]

[0001045810-18-000114:notes:165]
[same as prior period, unchanged from 0001045810-18-000080:notes:163]

[0001045810-18-000114:notes:166]
During the first half of fiscal year 2019, we repurchased a total of 3 million shares for $655 million. During the second quarter and first half of fiscal year 2019, we also paid $91 million and $182 million, respectively, in cash dividends to our shareholders.

[0001045810-18-000114:notes:167]
Through July 29, 2018, we have repurchased an aggregate of 254 million shares under our share repurchase program for a total cost of $6.16 billion. All shares delivered from these repurchases have been placed into treasury stock. As of July 29, 2018, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.16 billion through December 2020.

[0001045810-18-000114:notes:168]
[same as prior period, unchanged from 0001045810-18-000080:notes:166]

[0001045810-18-000114:notes:169]
As of July 29, 2018 and January 28, 2018, there were no shares of preferred stock outstanding.

[0001045810-18-000114:notes:170]
[same as prior period, unchanged from 0001045810-18-000080:notes:168]

[0001045810-18-000114:notes:171]
[same as prior period, unchanged from 0001045810-18-000080:notes:169]
