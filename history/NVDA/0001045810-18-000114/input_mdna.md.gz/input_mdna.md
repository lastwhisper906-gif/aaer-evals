# NVDA MD&A — 0001045810-18-000114


## mdna

[0001045810-18-000114:mdna:1]
[same as prior period, unchanged from 0001045810-18-000080:mdna:1]

[0001045810-18-000114:mdna:2]
[same as prior period, unchanged from 0001045810-18-000080:mdna:2]

[0001045810-18-000114:mdna:3]
[same as prior period, unchanged from 0001045810-18-000080:mdna:3]

[0001045810-18-000114:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, Turing, Jetson, G-SYNC, Jetson, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Constellation, NVIDIA DRIVE Sim, NVIDIA GRID, NVIDIA HGX, NVIDIA Holodeck, NVIDIA Isaac NVIDIA NVSwitch, NVIDIA RTX, NVSwitch, Pascal, TensorRT and Xavier are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-18-000114:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 6. Selected Financial Data” of our Annual Report on Form 10-K for the fiscal year ended January 28, 2018 and “Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-18-000114:mdna:6]
[same as prior period, unchanged from 0001045810-18-000080:mdna:7]

[0001045810-18-000114:mdna:7]
[same as prior period, unchanged from 0001045810-18-000080:mdna:8]

[0001045810-18-000114:mdna:8]
[same as prior period, unchanged from 0001045810-18-000080:mdna:9]

[0001045810-18-000114:mdna:9]
[same as prior period, unchanged from 0001045810-18-000080:mdna:10]

[0001045810-18-000114:mdna:10]
[same as prior period, unchanged from 0001045810-18-000080:mdna:11]

[0001045810-18-000114:mdna:11]
[same as prior period, unchanged from 0001045810-18-000080:mdna:12]

[0001045810-18-000114:mdna:12]
22

[0001045810-18-000114:mdna:13]
[same as prior period, unchanged from 0001045810-18-000080:mdna:13]

[0001045810-18-000114:mdna:14]
Second Quarter of Fiscal Year 2019 Summary

[0001045810-18-000114:mdna:15]
|  | Three Months Ended |  |  |  |  |
|  | July 29, 2018 |  | April 29, 2018 |  | July 30, 2017 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 3,123 |  |  | $ | 3,207 |  |  | $ | 2,230 |  |  | (3 | )% |  | 40 | % |
| Gross margin | 63.3 | % |  | 64.5 | % |  | 58.4 | % |  | (120) bps |  |  | 490 bps |  |
| Operating expenses | $ | 818 |  |  | $ | 773 |  |  | $ | 614 |  |  | 6 | % |  | 33 | % |
| Income from operations | $ | 1,157 |  |  | $ | 1,295 |  |  | $ | 688 |  |  | (11 | )% |  | 68 | % |
| Net income | $ | 1,101 |  |  | $ | 1,244 |  |  | $ | 583 |  |  | (11 | )% |  | 89 | % |
| Net income per diluted share | $ | 1.76 |  |  | $ | 1.98 |  |  | $ | 0.92 |  |  | (11 | )% |  | 91 | % |

[0001045810-18-000114:mdna:16]
Revenue for the second quarter of fiscal year 2019 increased 40% year over year and decreased 3% sequentially. Each of our market platforms - gaming, professional visualization, datacenter, and automotive - produced sequential and year-over-year growth.

[0001045810-18-000114:mdna:17]
GPU business revenue was $2.66 billion, up 40% from a year earlier and down 4% sequentially, led by gaming, professional visualization, and datacenter, offsetting a substantial decline in cryptocurrency GPUs. Gaming revenue was $1.80 billion, up 52% from a year ago and up 5% sequentially. Gaming GPU growth was fueled by Pascal-based GPUs for desktops and by high-performance notebooks based on our Max-Q technology. Professional visualization revenue was $281 million, up 20% from a year earlier and up 12% sequentially. Datacenter revenue was $760 million, up 83% from a year ago and up 8% sequentially, led by strong sales of our Volta architecture products, including NVIDIA Tesla V100 and DGX systems. OEM and IP revenue was $116 million, down 54% from a year ago and down 70% sequentially, driven by lower demand for GPUs for cryptocurrency mining. Cryptocurrency-related revenue included in OEM was $18 million, and we expect it to be negligible going forward.

[0001045810-18-000114:mdna:18]
Tegra Processor business revenue - which includes Automotive, SOC modules for the Nintendo Switch gaming console, and other embedded Tegra platforms - was $467 million, up 40% from a year ago and up 6% sequentially.  Automotive revenue of $161 million was up 13% from a year earlier and up 11% sequentially, incorporating infotainment modules, production DRIVE PX platforms, and development agreements with automotive companies.

[0001045810-18-000114:mdna:19]
Gross margin for the second quarter of fiscal year 2019 was 63.3%. Gross margin is normalizing to our core business and includes only minor benefits from cryptocurrency mining demand.

[0001045810-18-000114:mdna:20]
Operating expenses for the second quarter of fiscal year 2019 were $818 million, up 33% from a year earlier and up 6% sequentially, reflecting increased headcount and related costs for our growth initiatives - gaming, AI, and autonomous driving.

[0001045810-18-000114:mdna:21]
Income from operations for the second quarter of fiscal year 2019 was $1.16 billion, up 68% from a year earlier and down 11% sequentially. Net income and net income per diluted share for the second quarter of fiscal year 2019 were $1.10 billion and $1.76, respectively, up 89% and 91%, respectively, from a year earlier, fueled by strong revenue growth and improved gross and operating margins.

[0001045810-18-000114:mdna:22]
During the first half of fiscal year 2019, we returned $837 million to shareholders through a combination of $655 million in share repurchases and $182 million in cash dividends. For fiscal year 2019, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000114:mdna:23]
Cash, cash equivalents and marketable securities were $7.94 billion as of July 29, 2018, compared with $7.30 billion at the end of the prior quarter. The sequential increase was primarily related to second quarter operating income, partially offset by changes in working capital.

[0001045810-18-000114:mdna:24]
[same as prior period, unchanged from 0001045810-18-000080:mdna:27]

[0001045810-18-000114:mdna:25]
During the second quarter of fiscal year 2019, we marked the launch of the Summit supercomputer at Oak Ridge National Laboratory, powered by NVIDIA Volta Tensor Core GPUs; introduced NVIDIA HGX-2, a unified computing platform for both AI and high performance computing; announced that five of the world’s seven fastest supercomputers are powered by

[0001045810-18-000114:mdna:26]
NVIDIA GPUs; introduced the NVIDIA HGX-2 platform for both AI and HPC; and launched AIRI Mini with Pure Storage and ONTAP AI with NetApp for implementing and scaling deep learning. We also announced a number of Max-Q GeForce gaming notebook designs offered by major OEMs, enabling high-end performance for thin and light notebooks; disclosed that next-generation NVIDIA G-SYNC HDR displays are being shipped, enabling stutter-free gaming; and announced NVIDIA’s role in VirtualLink, a consortium establishing an industry standard to enable next-gen VR headsets to connect with PCs using a single, high-bandwidth USB Type-C connector. In August 2018, we unveiled our first Turing-based GPUs -- NVIDIA Quadro RTX 8000, RTX 6000 and RTX 5000 -- which we believe will revolutionize the work of millions of designers and artists; and introduced the NVIDIA RTX Server, a ray-tracing global illumination rendering server for render farms.

[0001045810-18-000114:mdna:27]
[same as prior period, unchanged from 0001045810-18-000080:mdna:28]

[0001045810-18-000114:mdna:28]
[same as prior period, unchanged from 0001045810-18-000080:mdna:29]

[0001045810-18-000114:mdna:29]
During the second quarter of fiscal year 2019, we announced that Daimler and Bosch have selected NVIDIA’s DRIVE platform to bring automated and driverless vehicles to city streets, with pilot testing set to begin next year in Silicon Valley.

[0001045810-18-000114:mdna:30]
[same as prior period, unchanged from 0001045810-18-000080:mdna:30]

[0001045810-18-000114:mdna:31]
[same as prior period, unchanged from 0001045810-18-000080:mdna:31]

[0001045810-18-000114:mdna:32]
[same as prior period, unchanged from 0001045810-18-000080:mdna:32]

[0001045810-18-000114:mdna:33]
[same as prior period, unchanged from 0001045810-18-000080:mdna:33]

[0001045810-18-000114:mdna:34]
[same as prior period, unchanged from 0001045810-18-000080:mdna:34]

[0001045810-18-000114:mdna:35]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2018 |  | July 30, 2017 |  | July 29, 2018 |  | July 30, 2017 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 36.7 |  |  | 41.6 |  |  | 36.1 |  |  | 41.2 |  |
| Gross profit | 63.3 |  |  | 58.4 |  |  | 63.9 |  |  | 58.8 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 18.6 |  |  | 18.7 |  |  | 17.8 |  |  | 19.8 |  |
| Sales, general and administrative | 7.7 |  |  | 8.9 |  |  | 7.4 |  |  | 9.2 |  |
| Total operating expenses | 26.3 |  |  | 27.6 |  |  | 25.2 |  |  | 29.0 |  |
| Income from operations | 37.0 |  |  | 30.9 |  |  | 38.7 |  |  | 29.8 |  |
| Interest income | 1.0 |  |  | 0.7 |  |  | 0.9 |  |  | 0.7 |  |
| Interest expense | (0.4 | ) |  | (0.7 | ) |  | (0.5 | ) |  | (0.7 | ) |
| Other, net | 0.2 |  |  | (0.2 | ) |  | 0.2 |  |  | (0.5 | ) |
| Total other income (expense) | 0.8 |  |  | (0.2 | ) |  | 0.6 |  |  | (0.5 | ) |
| Income before income tax | 37.8 |  |  | 30.7 |  |  | 39.3 |  |  | 29.3 |  |
| Income tax expense | 2.5 |  |  | 4.5 |  |  | 2.3 |  |  | 3.1 |  |
| Net income | 35.3 | % |  | 26.2 | % |  | 37.0 | % |  | 26.2 | % |

[0001045810-18-000114:mdna:36]
[same as prior period, unchanged from 0001045810-18-000080:mdna:36]

[0001045810-18-000114:mdna:37]
[same as prior period, unchanged from 0001045810-18-000080:mdna:37]

[0001045810-18-000114:mdna:38]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2018 |  | July 30, 2017 |  | $Change |  | %Change |  | July 29, 2018 |  | July 30, 2017 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,656 |  |  | $ | 1,897 |  |  | $ | 759 |  |  | 40 | % |  | $ | 5,421 |  |  | $ | 3,459 |  |  | $ | 1,962 |  |  | 57 | % |
| Tegra Processor | 467 |  |  | 333 |  |  | 134 |  |  | 40 | % |  | 909 |  |  | 665 |  |  | 244 |  |  | 37 | % |
| All Other | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | 43 |  |  | (43 | ) |  | (100 | )% |
| Total | $ | 3,123 |  |  | $ | 2,230 |  |  | $ | 893 |  |  | 40 | % |  | $ | 6,330 |  |  | $ | 4,167 |  |  | $ | 2,163 |  |  | 52 | % |

[0001045810-18-000114:mdna:39]
GPU Business. GPU business revenue increased by 40% for the second quarter of fiscal year 2019 compared to the second quarter of fiscal year 2018. This increase was due primarily to 50% growth in sales of GeForce GPU products for gaming, driven by Pascal-based GPUs for desktops and by high-performance notebooks based on our Max-Q technology. Datacenter revenue, including Tesla, GRID and DGX, increased 83%, reflecting strong sales of our Volta architecture products, including NVIDIA Tesla V100 and DGX systems. Revenue from Quadro GPUs for professional visualization increased 20% due primarily to higher sales across desktop and mobile workstation products. Our PC OEM revenue decreased by almost 60% driven by lower demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-18-000114:mdna:40]
GPU business revenue increased by 57% for the first half of fiscal year 2019 compared to the first half of fiscal year 2018. This increase was due primarily to almost 60% growth in sales of GeForce GPU products for gaming, driven by Pascal-based GPUs for desktops and by high-performance notebooks based on our Max-Q technology. Datacenter revenue, including Tesla, GRID and DGX, increased 77%, reflecting strong sales of our Volta architecture, including NVIDIA Tesla V100 and DGX systems. Revenue from Quadro GPUs for professional visualization increased 21% due primarily to higher sales across desktop and mobile workstation products. Our PC OEM revenue increased by almost 50% due primarily to sales of GPU products targeted for use in cryptocurrency mining in the first quarter of fiscal year 2019.

[0001045810-18-000114:mdna:41]
Tegra Processor Business. Tegra Processor business revenue increased by 40% for the second quarter of fiscal year 2019 compared to the second quarter of fiscal year 2018. This was driven by an increase of over 75% in revenue from SOC modules for gaming platforms and development services, and an increase of 13% in automotive revenue, primarily from DRIVE PX platforms and development agreements with automotive companies, as well as from infotainment modules.

[0001045810-18-000114:mdna:42]
Tegra Processor business revenue increased by 37% for the first half of fiscal year 2019 compared to the first half of fiscal year 2018. This was driven by an increase of over 80% in revenue from SOC modules for gaming platforms and development services, and an increase of 9% in automotive revenue, primarily from DRIVE PX platforms and development agreements with automotive companies, as well as from infotainment modules.

[0001045810-18-000114:mdna:43]
[same as prior period, unchanged from 0001045810-18-000080:mdna:41]

[0001045810-18-000114:mdna:44]
[same as prior period, unchanged from 0001045810-18-000080:mdna:42]

[0001045810-18-000114:mdna:45]
Revenue from sales to customers outside of the United States and Other Americas accounted for 80% of total revenue for both the second quarter and first half of fiscal year 2019. Revenue from sales to customers outside of the United States and Other Americas accounted for 79% and 78% of total revenue for the second quarter and first half of fiscal year 2018, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-18-000114:mdna:46]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal years 2019 and 2018.

[0001045810-18-000114:mdna:47]
[same as prior period, unchanged from 0001045810-18-000080:mdna:45]

[0001045810-18-000114:mdna:48]
Our overall gross margin increased to 63.3% and 63.9% for the second quarter and first half of fiscal year 2019, respectively, primarily due to a favorable mix shift within our GPU segment.

[0001045810-18-000114:mdna:49]
Inventory provisions totaled $21 million and $13 million for the second quarter of fiscal years 2019 and 2018, respectively. Sales of inventory that was previously written-off or written-down totaled $12 million and $9 million for the second quarter of fiscal years 2019 and 2018, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.3% and 0.2% for the second quarter of fiscal years 2019 and 2018, respectively.

[0001045810-18-000114:mdna:50]
Inventory provisions totaled $54 million and $16 million for the first half of fiscal years 2019 and 2018, respectively. Sales of inventory that was previously written-off or written-down totaled $16 million and $22 million for the first half of fiscal years 2019 and 2018, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.6% for the first half of fiscal year 2019 and a favorable impact of 0.2% for the first half of fiscal year 2018.

[0001045810-18-000114:mdna:51]
[same as prior period, unchanged from 0001045810-18-000080:mdna:48]

[0001045810-18-000114:mdna:52]
GPU Business. The gross margin of our GPU business increased during the second quarter and first half of fiscal year 2019 compared to the second quarter and first half of fiscal year 2018, primarily due to strong sales of high-end GeForce gaming GPUs and revenue growth in Datacenter.

[0001045810-18-000114:mdna:53]
Tegra Processor Business. The gross margin of our Tegra Processor business was flat during the second quarter of fiscal year 2019 compared to the second quarter of fiscal year 2018. Gross margin of our Tegra Processor business increased during the first half of fiscal year 2019 compared to the first half of fiscal year 2018, primarily due to a favorable mix shift.

[0001045810-18-000114:mdna:54]
[same as prior period, unchanged from 0001045810-18-000080:mdna:51]

[0001045810-18-000114:mdna:55]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2018 |  | July 30, 2017 |  | $Change |  | %Change |  | July 29, 2018 |  | July 30, 2017 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| Research and development expenses | $ | 581 |  |  | $ | 416 |  |  | $ | 165 |  |  | 40 | % |  | $ | 1,124 |  |  | $ | 827 |  |  | $ | 297 |  |  | 36 | % |
| % of net revenue | 19 | % |  | 19 | % |  |  |  |  |  | 18 | % |  | 20 | % |  |  |  |  |
| Sales, general and administrative expenses | 237 |  |  | 198 |  |  | 39 |  |  | 20 | % |  | 467 |  |  | 383 |  |  | 84 |  |  | 22 | % |
| % of net revenue | 8 | % |  | 9 | % |  |  |  |  |  | 7 | % |  | 9 | % |  |  |  |  |
| Total operating expenses | $ | 818 |  |  | $ | 614 |  |  | $ | 204 |  |  | 33 | % |  | $ | 1,591 |  |  | $ | 1,210 |  |  | $ | 381 |  |  | 31 | % |

[0001045810-18-000114:mdna:56]
[same as prior period, unchanged from 0001045810-18-000080:mdna:53]

[0001045810-18-000114:mdna:57]
Research and development expenses increased by 40% and 36% during the second quarter and first half of fiscal year 2019, compared to the second quarter and first half of fiscal year 2018, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000114:mdna:58]
[same as prior period, unchanged from 0001045810-18-000080:mdna:55]

[0001045810-18-000114:mdna:59]
Sales, general and administrative expenses increased by 20% and 22% during the second quarter and first half of fiscal year 2019, compared to the second quarter and first half of fiscal year 2018, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000114:mdna:60]
[same as prior period, unchanged from 0001045810-18-000080:mdna:57]

[0001045810-18-000114:mdna:61]
[same as prior period, unchanged from 0001045810-18-000080:mdna:58]

[0001045810-18-000114:mdna:62]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $32 million and $15 million during the second quarter of fiscal years 2019 and 2018, respectively, and $57 million and $31 million during the first half of fiscal years 2019 and 2018, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-18-000114:mdna:63]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016, and the 1.00% Convertible Notes Due 2018, or the Convertible Notes, issued in December 2013. Interest expense was $14 million and $15 million during the second quarter of fiscal years 2019 and 2018, respectively, and $29 million and $31 million during the first half of fiscal years 2019 and 2018, respectively.

[0001045810-18-000114:mdna:64]
[same as prior period, unchanged from 0001045810-18-000080:mdna:62]

[0001045810-18-000114:mdna:65]
Other, net, consists primarily of realized or unrealized gains and losses from non-affiliated investments, losses on early debt conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Other, net, was not significant during the second quarter or the first half of fiscal year 2019. Other, net, was not significant during the second quarter of

[0001045810-18-000114:mdna:66]
fiscal year 2018 and $21 million of expense during the first half of fiscal year 2018, consisting primarily of $17 million of losses recognized from early conversions of the Convertible Notes during the first half of fiscal year 2018.

[0001045810-18-000114:mdna:67]
[same as prior period, unchanged from 0001045810-18-000080:mdna:64]

[0001045810-18-000114:mdna:68]
We recognized income tax expense of $79 million and $146 million for the second quarter and first half of fiscal year 2019, respectively, and $101 million and $130 million for the second quarter and first half of fiscal year 2018, respectively. Income tax expense as a percentage of income before income tax for the second quarter and first half of fiscal year 2019 was 6.7% and 5.9%, respectively, and 14.8% and 10.7% for the second quarter and first half of fiscal year 2018, respectively.

[0001045810-18-000114:mdna:69]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2019 as compared to the same periods in the prior fiscal year was primarily due to a decrease in the U.S. statutory tax rate from 35% to 21% as a result of U.S. tax reform, partially offset by a decrease in the impact of tax benefits from stock-based compensation.

[0001045810-18-000114:mdna:70]
[same as prior period, unchanged from 0001045810-18-000080:mdna:67]

[0001045810-18-000114:mdna:71]
[same as prior period, unchanged from 0001045810-18-000080:mdna:68]

[0001045810-18-000114:mdna:72]
|  | July 29, 2018 |  | January 28, 2018 |
|  | (In millions) |
| Cash and cash equivalents | $ | 718 |  |  | $ | 4,002 |  |
| Marketable securities | 7,225 |  |  | 3,106 |  |
| Cash, cash equivalents and marketable securities | $ | 7,943 |  |  | $ | 7,108 |  |

[0001045810-18-000114:mdna:73]
|  | Six Months Ended |
|  | July 29, 2018 |  | July 30, 2017 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 2,358 |  |  | $ | 987 |  |
| Net cash provided by (used in) investing activities | $ | (4,356 | ) |  | $ | 1,016 |  |
| Net cash used in financing activities | $ | (1,286 | ) |  | $ | (1,781 | ) |

[0001045810-18-000114:mdna:74]
As of July 29, 2018, we had $7.94 billion in cash, cash equivalents and marketable securities, an increase of $835 million from the end of fiscal year 2018.  Our portfolio of cash equivalents and marketable securities is managed internally. Our investment policy requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-18-000114:mdna:75]
Cash provided by operating activities increased in the first half of fiscal year 2019 compared to the first half of fiscal year 2018, due to higher net income and changes in working capital.

[0001045810-18-000114:mdna:76]
Cash used in investing activities increased in the first half of fiscal year 2019 compared to the first half of fiscal year 2018, due to higher purchases of marketable securities, partially offset by higher maturities of marketable securities.

[0001045810-18-000114:mdna:77]
Cash used in financing activities decreased in the first half of fiscal year 2019 compared to the first half of fiscal year 2018, due to lower repayments of Convertible Notes, partially offset by higher tax payments related to employee stock plans.

[0001045810-18-000114:mdna:78]
[same as prior period, unchanged from 0001045810-18-000080:mdna:76]

[0001045810-18-000114:mdna:79]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, asset-backed issuers, mortgage-backed securities by government-sponsored enterprises, and foreign government entities. These marketable securities are denominated in United States dollars. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000114:mdna:80]
As a result of the Tax Cuts and Job Acts that was signed into law in December 2017, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of July 29, 2018 are available for use in the United States without incurring additional U.S. federal income taxes. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000114:mdna:81]
[same as prior period, unchanged from 0001045810-18-000080:mdna:79]

[0001045810-18-000114:mdna:82]
During the first half of fiscal year 2019, we repurchased a total of 3 million shares for $655 million. During the second quarter and first half of fiscal year 2019, we also paid $91 million and $182 million, respectively, in cash dividends to our shareholders.

[0001045810-18-000114:mdna:83]
[same as prior period, unchanged from 0001045810-18-000080:mdna:81]

[0001045810-18-000114:mdna:84]
[same as prior period, unchanged from 0001045810-18-000080:mdna:82]

[0001045810-18-000114:mdna:85]
[same as prior period, unchanged from 0001045810-18-000080:mdna:83]

[0001045810-18-000114:mdna:86]
[same as prior period, unchanged from 0001045810-18-000080:mdna:84]

[0001045810-18-000114:mdna:87]
[same as prior period, unchanged from 0001045810-18-000080:mdna:85]

[0001045810-18-000114:mdna:88]
As of July 29, 2018, we had $14 million of Convertible Notes outstanding. Subsequently, we received additional conversion notices for an aggregate of $11 million in principal amount of the Convertible Notes, which are expected to be settled in the third quarter of fiscal year 2019. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-18-000114:mdna:89]
Revolving Credit Facility

[0001045810-18-000114:mdna:90]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 29, 2018, we had not borrowed any amounts under this agreement.

[0001045810-18-000114:mdna:91]
[same as prior period, unchanged from 0001045810-18-000080:mdna:89]

[0001045810-18-000114:mdna:92]
We have a $575 million commercial paper program to support general corporate purposes. As of July 29, 2018, we had not issued any commercial paper.

[0001045810-18-000114:mdna:93]
[same as prior period, unchanged from 0001045810-18-000080:mdna:91]

[0001045810-18-000114:mdna:94]
In the second quarter of fiscal year 2019, we began construction on a 750,000 square foot building on our Santa Clara campus, which is currently targeted for completion in fiscal year 2022. We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating requirements for at least the next twelve months.

[0001045810-18-000114:mdna:95]
[same as prior period, unchanged from 0001045810-18-000080:mdna:93]

[0001045810-18-000114:mdna:96]
As of July 29, 2018, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-18-000114:mdna:97]
[same as prior period, unchanged from 0001045810-18-000080:mdna:95]

[0001045810-18-000114:mdna:98]
[same as prior period, unchanged from 0001045810-18-000080:mdna:96]

[0001045810-18-000114:mdna:99]
[same as prior period, unchanged from 0001045810-18-000080:mdna:97]

[0001045810-18-000114:mdna:100]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000114:mdna:101]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
