# NVDA note change history — 0001045810-18-000080 → 0001045810-18-000114


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-16):
[0001045810-18-000114:note_history:1]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.
  (was, 2018-05-22, similarity 0.6046):
[0001045810-18-000080:note_history:1]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM: 6,532,505; 7,124,325; 7,405,993; 7,886,122; 8,161,344; and 8,207,976. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

- changed (2018-08-16):
[0001045810-18-000114:note_history:2]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for four U.S. patents and declined to institute IPRs on two U.S. patents. The USPTO issued a Final Written Decision on the IPR relating to one of the patents on June 19, 2018, finding claims 1-23 and 28 unpatentable but that claims 24-27 were not proved unpatentable.
  (was, 2018-05-22, similarity 0.6169):
[0001045810-18-000080:note_history:2]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for U.S. Patent Nos. 6,532,505; 7,405,993; 7,886,122; and 8,161,344. The USPTO declined to institute IPRs on U.S. Patent Nos. 7,124,325 and 8,207,976.

- changed (2018-08-16):
[0001045810-18-000114:note_history:3]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.
  (was, 2018-05-22, similarity 0.9268):
[0001045810-18-000080:note_history:3]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM: European Patent No. EP1428225, and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.

- added (2018-08-16):
[0001045810-18-000114:note_history:4]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

- changed (2018-08-16):
[0001045810-18-000114:note_history:5]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. patent.
  (was, 2018-05-22, similarity 0.9758):
[0001045810-18-000080:note_history:5]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. Patent No. 6,977,649.

- added (2018-08-16):
[0001045810-18-000114:note_history:6]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

- added (2018-08-16):
[0001045810-18-000114:note_history:7]
On May 10, 2018, the Administrative Law Judge presiding over the investigation issued an Initial Determination terminating the investigation with respect to one of the patents.  On July 17, 2018, the USITC affirmed this decision on modified grounds.

- added (2018-08-16):
[0001045810-18-000114:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 29, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2018-08-16):
[0001045810-18-000080:note_history:9]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs: 6,683,615; 7,050,061; 7,710,425; and 9,098,943, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd. a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

- removed (2018-08-16):
[0001045810-18-000080:note_history:10]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. Patents: 6,181,355; 6,900,800; 8,144,156; and 8,643,659, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

- removed (2018-08-16):
[0001045810-18-000080:note_history:11]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 29, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2018-08-16):
[0001045810-18-000080:note_history:12]
Basis of Presentation

- removed (2018-08-16):
[0001045810-18-000080:note_history:13]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2018 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

- removed (2018-08-16):
[0001045810-18-000080:note_history:14]
Significant Accounting Policies

- removed (2018-08-16):
[0001045810-18-000080:note_history:15]
Except for the accounting policy for revenue recognition, which was updated as a result of adopting a new accounting standard related to revenue recognition, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

- removed (2018-08-16):
[0001045810-18-000080:note_history:16]
Revenue Recognition

- removed (2018-08-16):
[0001045810-18-000080:note_history:17]
We derive our revenue primarily from product sales, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- removed (2018-08-16):
[0001045810-18-000080:note_history:18]
Product Sales Revenue

- removed (2018-08-16):
[0001045810-18-000080:note_history:19]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

- removed (2018-08-16):
[0001045810-18-000080:note_history:20]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- removed (2018-08-16):
[0001045810-18-000080:note_history:21]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- removed (2018-08-16):
[0001045810-18-000080:note_history:22]
License and Development Arrangements

- removed (2018-08-16):
[0001045810-18-000080:note_history:23]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

- removed (2018-08-16):
[0001045810-18-000080:note_history:24]
Software Licensing

- removed (2018-08-16):
[0001045810-18-000080:note_history:25]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-16):
[0001045810-18-000114:note_history:26]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.
  (was, 2018-05-22, similarity 0.9286):
[0001045810-18-000080:note_history:26]
We derive our revenue primarily from product sales, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- changed (2018-08-16):
[0001045810-18-000114:note_history:27]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.
  (was, 2018-05-22, similarity 0.9906):
[0001045810-18-000080:note_history:27]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- changed (2018-08-16):
[0001045810-18-000114:note_history:28]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The second quarters of fiscal years 2019 and 2018 were both 13-week quarters.
  (was, 2018-05-22, similarity 0.9759):
[0001045810-18-000080:note_history:28]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The first quarters of fiscal years 2019 and 2018 were both 13-week quarters.

- added (2018-08-16):
[0001045810-18-000114:note_history:29]
In February 2016 and July 2018, the FASB issued accounting standards updates regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The FASB also recently provided a practical expedient transition method to adopt the new lease accounting requirements. We are evaluating the impact of adopting the new lease accounting standards on our consolidated financial statements, systems and processes in conjunction with our review of lease agreements. The updates will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

- removed (2018-08-16):
[0001045810-18-000080:note_history:30]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The update will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.


## nvda:DebtSecuritiesAvailableforsaleTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-08-16):
[0001045810-18-000114:note_history:31]
The following is a summary of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018:

- added (2018-08-16):
[0001045810-18-000114:note_history:32]
|  | July 29, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,491 |  |  | $ | 1 |  |  | $ | (8 | ) |  | $ | 2,484 |  |  | $ | — |  |  | $ | 2,484 |  |
| Debt securities issued by the United States Treasury | 2,412 |  |  | — |  |  | (2 | ) |  | 2,410 |  |  | — |  |  | 2,410 |  |
| Debt securities of United States government agencies | 1,993 |  |  | — |  |  | (6 | ) |  | 1,987 |  |  | — |  |  | 1,987 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Asset-backed securities | 206 |  |  | — |  |  | (2 | ) |  | 204 |  |  | — |  |  | 204 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 107 |  |  | 2 |  |  | (1 | ) |  | 108 |  |  | — |  |  | 108 |  |
| Foreign government bonds | 32 |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total | $ | 7,724 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 7,708 |  |  | $ | 483 |  |  | $ | 7,225 |  |

- added (2018-08-16):
[0001045810-18-000114:note_history:33]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

- added (2018-08-16):
[0001045810-18-000114:note_history:34]
The following table provides the breakdown of unrealized losses as of July 29, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- added (2018-08-16):
[0001045810-18-000114:note_history:35]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 925 |  |  | $ | (1 | ) |  | $ | 559 |  |  | $ | (5 | ) |  | $ | 1,484 |  |  | $ | (6 | ) |
| Debt securities issued by the United States Treasury | 754 |  |  | — |  |  | 410 |  |  | (2 | ) |  | 1,164 |  |  | (2 | ) |
| Corporate debt securities | 310 |  |  | (1 | ) |  | 742 |  |  | (7 | ) |  | 1,052 |  |  | (8 | ) |
| Asset-backed securities | 49 |  |  | (1 | ) |  | 155 |  |  | (1 | ) |  | 204 |  |  | (2 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 15 |  |  | — |  |  | 31 |  |  | (1 | ) |  | 46 |  |  | (1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |  | — |  |
|  | $ | 2,053 |  |  | $ | (3 | ) |  | $ | 1,928 |  |  | $ | (16 | ) |  | $ | 3,981 |  |  | $ | (19 | ) |

- added (2018-08-16):
[0001045810-18-000114:note_history:36]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018 are shown below by contractual maturity.

- added (2018-08-16):
[0001045810-18-000114:note_history:37]
|  | July 29, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,991 |  |  | $ | 5,981 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,705 |  |  | 1,699 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 28 |  |  | 28 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,724 |  |  | $ | 7,708 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-16):
[0001045810-18-000114:note_history:38]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |
  (was, 2018-05-22, similarity 0.9904):
[0001045810-18-000080:note_history:38]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (14 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,986 |  |  | $ | 1,985 |  |

- added (2018-08-16):
[0001045810-18-000114:note_history:39]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through the second quarter of fiscal year 2019, we had settled an aggregate of $1.49 billion of the Convertible Notes. The Convertible Notes will mature on December 1, 2018 and we had $14 million in principal amount outstanding as of July 29, 2018. Effective August 1, 2018, holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date of December 1, 2018 regardless of conversion conditions.

- added (2018-08-16):
[0001045810-18-000114:note_history:40]
During the second quarter of fiscal year 2019, we paid cash to settle an insignificant amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $11 million in principal amount of the Convertible Notes which are expected to be settled in the third quarter of fiscal year 2019. During the second quarter of fiscal year 2019, we also issued one thousand shares of our common stock for the excess conversion value and the related loss on early conversions was not significant. Based on the closing price of our common stock of $252.02 on the last trading day of the second quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $162 million. As of July 29, 2018, the conversion rate was 49.94 shares of common stock per $1,000 principal amount of the Convertible Notes.

- changed (2018-08-16):
[0001045810-18-000114:note_history:41]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.02 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through July 29, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.49 billion in principal amount of the Convertible Notes.
  (was, 2018-05-22, similarity 0.992):
[0001045810-18-000080:note_history:41]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.0296 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through April 29, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.49 billion in principal amount of the Convertible Notes.

- added (2018-08-16):
[0001045810-18-000114:note_history:42]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 29, 2018, we had not borrowed any amounts under this agreement.

- added (2018-08-16):
[0001045810-18-000114:note_history:43]
We have a $575 million commercial paper program to support general corporate purposes. As of July 29, 2018, we had not issued any commercial paper.

- removed (2018-08-16):
[0001045810-18-000080:note_history:44]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through the first quarter of fiscal year 2019, we had settled an aggregate of $1.49 billion of the Convertible Notes. The Convertible Notes are unsecured, unsubordinated obligations of the Company paying interest in cash semi-annually at a rate of 1.00% per annum and will mature on December 1, 2018 unless previously repurchased or converted. Upon conversion, we pay cash up to the aggregate principal amount and pay or deliver cash, shares of our common stock or a combination thereof, at our election, of our conversion obligation in excess of the aggregate principal amount being converted.

- removed (2018-08-16):
[0001045810-18-000080:note_history:45]
Holders may convert all or any portion of their Convertible Notes at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition has been met, all outstanding Convertible Notes are convertible at the holders’ option through July 29, 2018.

- removed (2018-08-16):
[0001045810-18-000080:note_history:46]
During the first quarter of fiscal year 2019, we paid cash to settle an aggregate of $2 million in principal amount of the Convertible Notes and had $14 million in principal amount outstanding as of April 29, 2018. We also issued 74 thousand shares of our common stock for the excess conversion value and the related loss on early conversions was not significant. Based on the closing price of our common stock of $226.33 on the last trading day of the first quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $144 million. As of April 29, 2018, the conversion rate was 49.9261 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0296 per share of common stock).

- removed (2018-08-16):
[0001045810-18-000080:note_history:47]
In fiscal year 2017, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of April 29, 2018, we had not borrowed any amounts and were in compliance with all related covenants under the Credit Agreement.

- removed (2018-08-16):
[0001045810-18-000080:note_history:48]
In fiscal year 2018, we established a commercial paper program to support general corporate purposes. Under the program, we can issue up to $575 million in commercial paper. As of April 29, 2018, we had not issued any commercial paper and there was no commercial paper outstanding.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-08-16):
[0001045810-18-000114:note_history:49]
Marketable Securities

- added (2018-08-16):
[0001045810-18-000114:note_history:50]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

- added (2018-08-16):
[0001045810-18-000114:note_history:51]
The following is a summary of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018:

- added (2018-08-16):
[0001045810-18-000114:note_history:52]
|  | July 29, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,491 |  |  | $ | 1 |  |  | $ | (8 | ) |  | $ | 2,484 |  |  | $ | — |  |  | $ | 2,484 |  |
| Debt securities issued by the United States Treasury | 2,412 |  |  | — |  |  | (2 | ) |  | 2,410 |  |  | — |  |  | 2,410 |  |
| Debt securities of United States government agencies | 1,993 |  |  | — |  |  | (6 | ) |  | 1,987 |  |  | — |  |  | 1,987 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Asset-backed securities | 206 |  |  | — |  |  | (2 | ) |  | 204 |  |  | — |  |  | 204 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 107 |  |  | 2 |  |  | (1 | ) |  | 108 |  |  | — |  |  | 108 |  |
| Foreign government bonds | 32 |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total | $ | 7,724 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 7,708 |  |  | $ | 483 |  |  | $ | 7,225 |  |

- added (2018-08-16):
[0001045810-18-000114:note_history:53]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

- added (2018-08-16):
[0001045810-18-000114:note_history:54]
The following table provides the breakdown of unrealized losses as of July 29, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- added (2018-08-16):
[0001045810-18-000114:note_history:55]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 925 |  |  | $ | (1 | ) |  | $ | 559 |  |  | $ | (5 | ) |  | $ | 1,484 |  |  | $ | (6 | ) |
| Debt securities issued by the United States Treasury | 754 |  |  | — |  |  | 410 |  |  | (2 | ) |  | 1,164 |  |  | (2 | ) |
| Corporate debt securities | 310 |  |  | (1 | ) |  | 742 |  |  | (7 | ) |  | 1,052 |  |  | (8 | ) |
| Asset-backed securities | 49 |  |  | (1 | ) |  | 155 |  |  | (1 | ) |  | 204 |  |  | (2 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 15 |  |  | — |  |  | 31 |  |  | (1 | ) |  | 46 |  |  | (1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |  | — |  |
|  | $ | 2,053 |  |  | $ | (3 | ) |  | $ | 1,928 |  |  | $ | (16 | ) |  | $ | 3,981 |  |  | $ | (19 | ) |

- added (2018-08-16):
[0001045810-18-000114:note_history:56]
The gross unrealized losses related to fixed income securities were primarily due to changes in interest rates, which we believe are temporary in nature. We have the intent and ability to hold our investments until maturity. For the second quarter and first half of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.

- added (2018-08-16):
[0001045810-18-000114:note_history:57]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018 are shown below by contractual maturity.

- added (2018-08-16):
[0001045810-18-000114:note_history:58]
|  | July 29, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,991 |  |  | $ | 5,981 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,705 |  |  | 1,699 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 28 |  |  | 28 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,724 |  |  | $ | 7,708 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: title_similarity, score: 1.0

- changed (2018-08-16):
[0001045810-18-000114:note_history:59]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |
  (was, 2018-05-22, similarity 0.9904):
[0001045810-18-000080:note_history:59]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (14 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,986 |  |  | $ | 1,985 |  |


## nvda:RevenueFromContractwithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-16):
[0001045810-18-000114:note_history:60]
Revenue Recognition

- added (2018-08-16):
[0001045810-18-000114:note_history:61]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- added (2018-08-16):
[0001045810-18-000114:note_history:62]
Product Sales Revenue

- added (2018-08-16):
[0001045810-18-000114:note_history:63]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

- added (2018-08-16):
[0001045810-18-000114:note_history:64]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- added (2018-08-16):
[0001045810-18-000114:note_history:65]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- added (2018-08-16):
[0001045810-18-000114:note_history:66]
License and Development Arrangements

- added (2018-08-16):
[0001045810-18-000114:note_history:67]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

- added (2018-08-16):
[0001045810-18-000114:note_history:68]
Software Licensing

- added (2018-08-16):
[0001045810-18-000114:note_history:69]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.
