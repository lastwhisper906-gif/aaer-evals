# NVDA notes — 0001045810-24-000029


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001045810-24-000029:notes:1]
Portions of the registrant's Proxy Statement for its 2024 Annual Meeting of Shareholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated by reference into Part III, Items 10-14 of this Annual Report on Form 10-K.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-24-000029:notes:2]
On December 18, 2023, John O. Dabiri, a member of our Board of Directors, adopted a trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale through December 2, 2024 of an estimated 553 shares of our common stock, assuming our closing stock price as of January 26, 2024. The number of shares is based on an estimate because the plan specifies a formulaic dollar amount of shares to be sold.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-24-000029:notes:3]
Organization and Summary of Significant Accounting Policies
Our Company

[0001045810-24-000029:notes:4]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-24-000029:notes:5]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-24-000029:notes:6]
Fiscal Year

[0001045810-24-000029:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024, 2023 and 2022 were all 52-week years.

[0001045810-24-000029:notes:8]
Principles of Consolidation

[0001045810-24-000029:notes:9]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-24-000029:notes:10]
Use of Estimates

[0001045810-24-000029:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories and product purchase commitments, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-24-000029:notes:12]
In February 2023, we assessed the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of most of our server, storage, and network equipment from three to four or five years, and our assembly and test equipment from five to seven years. The effect of this change for the fiscal year ended January 28, 2024 was a benefit of $33 million and $102 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $135 million and net income of $114 million after tax, or $0.05 per both basic and diluted share.

[0001045810-24-000029:notes:13]
Revenue Recognition

[0001045810-24-000029:notes:14]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, software licensing, and cloud services. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract (where revenue is allocated on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation); and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-24-000029:notes:15]
Product Sales Revenue

[0001045810-24-000029:notes:16]
Revenue from product sales is recognized upon transfer of control of products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Certain products are sold with support or an extended warranty for the incorporated system, hardware, and/or software. Support and extended warranty revenue are recognized ratably over the service period, or as services are performed. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-24-000029:notes:17]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to accurately reflect our estimated exposure for product returns.

[0001045810-24-000029:notes:18]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for such programs for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-24-000029:notes:19]
License and Development Arrangements

[0001045810-24-000029:notes:20]
Our license and development arrangements with customers typically require significant customization of our IP components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-24-000029:notes:21]
Software Licensing

[0001045810-24-000029:notes:22]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with the right to receive, on a when-and-if available basis, future unspecified software updates and upgrades. Revenue from software licenses is recognized up front when the software is made available to the customer. Software support revenue is recognized ratably over the service period, or as services are performed.

[0001045810-24-000029:notes:23]
Cloud Services

[0001045810-24-000029:notes:24]
Cloud services, which allow customers to use hosted software and hardware infrastructure without taking possession of the software or hardware, are provided on a subscription basis or a combination of subscription plus usage. Revenue related to subscription-based cloud services is recognized ratably over the contract period. Revenue related to cloud services based on usage is recognized as usage occurs. Cloud services are typically sold on a standalone basis, but certain offerings may be sold with hardware and/or software and related support.

[0001045810-24-000029:notes:25]
Contracts with Multiple Performance Obligations

[0001045810-24-000029:notes:26]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation. We account for multiple agreements with a single customer as a single contract if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001045810-24-000029:notes:27]
We allocate the total transaction price to each distinct performance obligation in a multiple performance obligations arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers. When determining standalone selling price, we maximize the use of observable inputs.

[0001045810-24-000029:notes:28]
If a contract contains a single performance obligation, no allocation is required.

[0001045810-24-000029:notes:29]
Product Warranties

[0001045810-24-000029:notes:30]
We offer a limited warranty to end-users ranging from one to three years for products to repair or replace products for manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-24-000029:notes:31]
Stock-based Compensation

[0001045810-24-000029:notes:32]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, for RSU, PSU, and market-based PSU awards, we estimate forfeitures semi-annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-24-000029:notes:33]
Litigation, Investigation and Settlement Costs

[0001045810-24-000029:notes:34]
We currently, are, and will likely continue to be subject to claims, litigation, and other actions, including potential regulatory proceedings, involving patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, commercial disputes, goods and services offered by us and by third parties, and other matters. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions

[0001045810-24-000029:notes:35]
or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments or judgments. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-24-000029:notes:36]
Foreign Currency Remeasurement

[0001045810-24-000029:notes:37]
We use the U.S. dollar as our functional currency for our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at exchange rates in effect during each period, except for those expenses related to non-monetary balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in earnings in our Consolidated Statements of Income and to date have not been significant.

[0001045810-24-000029:notes:38]
Income Taxes

[0001045810-24-000029:notes:39]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-24-000029:notes:40]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the U.S., or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential U.S. and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-24-000029:notes:41]
As of January 28, 2024, we had a valuation allowance of $1.6 billion related to capital loss carryforwards, and certain state and other deferred tax assets that management determined are not likely to be realized due, in part, to jurisdictional projections of future taxable income, including capital gains. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-24-000029:notes:42]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-24-000029:notes:43]
Net Income Per Share

[0001045810-24-000029:notes:44]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Any anti-dilutive effect of equity awards outstanding is not included in the computation of diluted net income per share.

[0001045810-24-000029:notes:45]
Cash and Cash Equivalents and Marketable Securities

[0001045810-24-000029:notes:46]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. Marketable securities consist of highly liquid debt investments with maturities of greater than three months when purchased. We currently classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0001045810-24-000029:notes:47]
We classify our cash equivalents and marketable securities related to debt securities at the date of acquisition as available-for-sale. These available-for-sale debt securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. The fair value of interest-bearing debt securities includes accrued interest. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income (expense), net, section of our Consolidated Statements of Income.

[0001045810-24-000029:notes:48]
Available-for-sale debt investments are subject to a periodic impairment review. If the estimated fair value of available-for-sale debt securities is less than its amortized cost basis, we determine if the difference, if any, is caused by expected credit losses and write-down the amortized cost basis of the securities if it is more likely than not we will be required or

[0001045810-24-000029:notes:49]
we intend to sell the securities before recovery of its amortized cost basis. Allowances for credit losses and write-downs are recognized in the other income (expense), net section of our Consolidated Statements of Income.

[0001045810-24-000029:notes:50]
Fair Value of Financial Instruments

[0001045810-24-000029:notes:51]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 28, 2024 and January 29, 2023. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains or losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains or losses are recognized in earnings in the periods of change together with the offsetting losses or gains on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings. For derivative instruments not designated for hedge accounting, changes in fair value are recognized in earnings.

[0001045810-24-000029:notes:52]
Concentration of Credit Risk

[0001045810-24-000029:notes:53]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio duration. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-24-000029:notes:54]
Inventories

[0001045810-24-000029:notes:55]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory, and for excess product purchase commitments. Most of our inventory provisions relate to excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up. We record a liability for noncancelable purchase commitments with suppliers for quantities in excess of our future demand forecasts consistent with our valuation of obsolete or excess inventory.

[0001045810-24-000029:notes:56]
Property and Equipment

[0001045810-24-000029:notes:57]
Property and equipment are stated at cost less accumulated depreciation. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets of three to seven years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization of assets recorded under finance leases. Leasehold improvements and assets recorded under finance leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.

[0001045810-24-000029:notes:58]
Leases

[0001045810-24-000029:notes:59]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

[0001045810-24-000029:notes:60]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0001045810-24-000029:notes:61]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

[0001045810-24-000029:notes:62]
Goodwill

[0001045810-24-000029:notes:63]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist. In completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-24-000029:notes:64]
Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting units.

[0001045810-24-000029:notes:65]
The quantitative impairment test considers both the income approach and the market approach to estimate a reporting unit’s fair value. The income and market valuation approaches consider factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-24-000029:notes:66]
Intangible Assets and Other Long-Lived Assets

[0001045810-24-000029:notes:67]
Intangible assets primarily represent acquired intangible assets including developed technology and customer relationships, as well as rights acquired under technology licenses, patents, and acquired IP. We currently amortize our intangible assets with finite lives over periods ranging from one to twenty years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.

[0001045810-24-000029:notes:68]
Long-lived assets, such as property and equipment and intangible assets subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. The recoverability of assets or asset groups to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.

[0001045810-24-000029:notes:69]
Business Combination

[0001045810-24-000029:notes:70]
We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the measurement period's conclusion or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our Consolidated Statements of Income.

[0001045810-24-000029:notes:71]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

[0001045810-24-000029:notes:72]
Investments in Non-Affiliated Entities

[0001045810-24-000029:notes:73]
Our investment in non-affiliates consists of marketable equity securities, which are publicly traded, and non-marketable equity securities, which are investments in privately held companies. Marketable equity securities have readily determinable fair values with changes in fair value recorded in other income (expense), net. Non-marketable equity securities include investments that do not have a readily determinable fair value. The investments that do not have readily determinable fair value are measured at cost minus impairment, if any, and are adjusted for changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer, or the measurement alternative. Fair value is based upon observable inputs in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. All gains and losses on these investments, realized and unrealized, are recognized in other income (expense), net on our Consolidated Statements of Income.

[0001045810-24-000029:notes:74]
We assess whether an impairment loss has occurred on our investments in non-marketable equity securities, accounted for under the measurement alternative based on quantitative and qualitative factors. If any impairment is identified for non-marketable equity securities, we write down the investment to its fair value and record the corresponding charge through other income (expense), net on our Consolidated Statements of Income.

[0001045810-24-000029:notes:75]
Recently Issued Accounting Pronouncements

[0001045810-24-000029:notes:76]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-24-000029:notes:77]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard to provide for additional disclosures about significant expenses in operating segments. The standard is effective for our annual reporting for fiscal year 2025 and for interim period reporting starting in fiscal year 2026 retrospectively. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

[0001045810-24-000029:notes:78]
In December 2023, the FASB issued a new accounting standard which provides for new and changes to income tax disclosures including disaggregation of the rate reconciliation and income taxes paid disclosures. The amendments in the standard are effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. We expect to adopt this standard in our annual period beginning fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-24-000029:notes:79]
Business Combination
Termination of the Arm Share Purchase Agreement

[0001045810-24-000029:notes:80]
In February 2022, NVIDIA and SoftBank Group Corp, or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank. The parties agreed to terminate it due to significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.4 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-24-000029:notes:81]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2025 and 2035.

[0001045810-24-000029:notes:82]
Future minimum lease payments under our non-cancelable operating leases as of January 28, 2024, are as follows:

[0001045810-24-000029:notes:83]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 | $ | 290 |  |
| 2026 | 270 |  |
| 2027 | 253 |  |
| 2028 | 236 |  |
| 2029 | 202 |  |
| 2030 and thereafter | 288 |  |
| Total | 1,539 |  |
| Less imputed interest | 192 |  |
| Present value of net future minimum lease payments | 1,347 |  |
| Less short-term operating lease liabilities | 228 |  |
| Long-term operating lease liabilities | $ | 1,119 |  |

[0001045810-24-000029:notes:84]
In addition, we have operating leases, primarily for our data centers, that are expected to commence within fiscal year 2025 with lease terms of 1 to 10 years for $1.1 billion.

[0001045810-24-000029:notes:85]
Operating lease expenses for fiscal years 2024, 2023, and 2022 were $269 million, $193 million, $168 million, respectively. Short-term and variable lease expenses for fiscal years 2024, 2023, and 2022 were not significant.

[0001045810-24-000029:notes:86]
Other information related to leases was as follows:

[0001045810-24-000029:notes:87]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |  |  |
| Operating cash flows used for operating leases | $ | 286 |  |  | $ | 184 |  |  | $ | 154 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 531 |  |  | $ | 358 |  |  | $ | 266 |  |

[0001045810-24-000029:notes:88]
As of January 28, 2024, our operating leases had a weighted average remaining lease term of 6.1 years and a weighted average discount rate of 3.76%. As of January 29, 2023, our operating leases had a weighted average remaining lease term of 6.8 years and a weighted average discount rate of 3.21%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-24-000029:notes:89]
Stock-Based Compensation
Our stock-based compensation expense is associated with RSUs, performance stock units based on our corporate financial performance targets, or PSUs, performance stock units based on market conditions, or market-based PSUs, and our ESPP.

[0001045810-24-000029:notes:90]
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts allocated to inventory, as follows:

[0001045810-24-000029:notes:91]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| Cost of revenue | $ | 141 |  |  | $ | 138 |  |  | $ | 141 |  |
| Research and development | 2,532 |  |  | 1,892 |  |  | 1,298 |  |
| Sales, general and administrative | 876 |  |  | 680 |  |  | 565 |  |
| Total | $ | 3,549 |  |  | $ | 2,710 |  |  | $ | 2,004 |  |

[0001045810-24-000029:notes:92]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2024, 2023, and 2022.

[0001045810-24-000029:notes:93]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-24-000029:notes:94]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 14 |  |  | 25 |  |  | 18 |  |
| Estimated total grant-date fair value | $ | 5,316 |  |  | $ | 4,505 |  |  | $ | 3,492 |  |
| Weighted average grant-date fair value per share | $ | 374.08 |  |  | $ | 183.72 |  |  | $ | 190.69 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 3 |  |  | 3 |  |  | 5 |  |
| Weighted average price per share | $ | 158.07 |  |  | $ | 122.54 |  |  | $ | 56.36 |  |
| Weighted average grant-date fair value per share | $ | 69.90 |  |  | $ | 51.87 |  |  | $ | 23.24 |  |

[0001045810-24-000029:notes:95]
As of January 28, 2024, there was $8.6 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.5 years for RSUs, PSUs, and market-based PSUs, and 0.8 years for ESPP.

[0001045810-24-000029:notes:96]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-24-000029:notes:97]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.1-2.0 |  | 0.1-2.0 |  | 0.1-2.0 |
| Risk-free interest rate | 3.9%-5.5% |  | —%-4.6% |  | —%-0.5% |
| Volatility | 31%-67% |  | 43%-72% |  | 20%-58% |
| Dividend yield | 0.1% |  | 0.1% |  | 0.1% |

[0001045810-24-000029:notes:98]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-24-000029:notes:99]
Additionally, for RSU, PSU, and market-based PSU awards, we estimate forfeitures semi-annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-24-000029:notes:100]
Equity Incentive Program

[0001045810-24-000029:notes:101]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans. In addition, in connection with our acquisitions of various companies, we have assumed certain stock-based awards granted under their stock incentive plans and converted them into our RSUs.

[0001045810-24-000029:notes:102]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-24-000029:notes:103]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, or as most recently amended and restated, the 2007 Plan.

[0001045810-24-000029:notes:104]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, RSUs, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. As of January 28, 2024, up to 37 million shares of our common stock could be issued pursuant to stock awards granted under the 2007 Plan. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 28, 2024, there were 147 million shares available for future grants.

[0001045810-24-000029:notes:105]
Subject to certain exceptions, RSUs granted to employees vest (A) over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25% vesting quarterly thereafter, (B) over a three-year period, subject to continued service, with 40% vesting on a pre-determined date that is close to the anniversary of the date of grant and 7.5% vesting quarterly thereafter, or (C) over a four-year period, subject to continued service, with 6.25% vesting quarterly. PSUs vest over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25% vesting quarterly thereafter. Market-based PSUs vest 100% on about the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-24-000029:notes:106]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-24-000029:notes:107]
In 2012, our shareholders approved the NVIDIA Corporation 2012 Employee Stock Purchase Plan, or as most recently amended and restated, the 2012 Plan.

[0001045810-24-000029:notes:108]
Employees who participate in the 2012 Plan may have up to 15% of their earnings withheld to purchase shares of common stock. The Board may decrease this percentage at its discretion. Each offering period is about 24 months, divided into four purchase periods of six months. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period or the fair market value of the common stock on each purchase date within the offering. As of January 28, 2024, we had 227 million shares reserved for future issuance under the 2012 Plan.

[0001045810-24-000029:notes:109]
Equity Award Activity

[0001045810-24-000029:notes:110]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-24-000029:notes:111]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
|  | (In millions, except per share data) |
| Balances, Jan 29, 2023 | 45 |  |  | $ | 158.45 |  |
| Granted | 14 |  |  | $ | 374.08 |  |
| Vested restricted stock | (21) |  |  | $ | 148.56 |  |
| Canceled and forfeited | (1) |  |  | $ | 206.35 |  |
| Balances, Jan 28, 2024 | 37 |  |  | $ | 245.94 |  |
| Vested and expected to vest after Jan 28, 2024 | 37 |  |  | $ | 245.49 |  |

[0001045810-24-000029:notes:112]
As of January 28, 2024 and January 29, 2023, there were 147 million and 160 million shares, respectively, of common stock available for future grants under our equity incentive plans.

[0001045810-24-000029:notes:113]
The total fair value of RSUs and PSUs, as of their respective vesting dates, during the years ended January 28, 2024, January 29, 2023, and January 30, 2022, was $8.2 billion, $4.3 billion, and $5.6 billion, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-24-000029:notes:114]
Net Income Per Share
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-24-000029:notes:115]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 29,760 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 2,469 |  |  | 2,487 |  |  | 2,496 |  |
| Dilutive impact of outstanding equity awards | 25 |  |  | 20 |  |  | 39 |  |
| Diluted weighted average shares | 2,494 |  |  | 2,507 |  |  | 2,535 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 12.05 |  |  | $ | 1.76 |  |  | $ | 3.91 |  |
| Diluted (2) | $ | 11.93 |  |  | $ | 1.74 |  |  | $ | 3.85 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 15 |  |  | 40 |  |  | 21 |  |

[0001045810-24-000029:notes:116]
(1)    Calculated as net income divided by basic weighted average shares.

[0001045810-24-000029:notes:117]
(2)    Calculated as net income divided by diluted weighted average shares.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-24-000029:notes:118]
GoodwillAs of January 28, 2024, the total carrying amount of goodwill was $4.4 billion, consisting of goodwill balances allocated to our Compute & Networking and Graphics reporting units of $4.1 billion and $370 million, respectively. As of January 29, 2023, the total carrying amount of goodwill was $4.4 billion, consisting of goodwill balances allocated to our Compute & Networking and Graphics reporting units of $4.0 billion and $370 million, respectively. Goodwill increased by $59 million in fiscal year 2024 from an immaterial acquisition and was allocated to our Compute & Networking reporting unit. During the fourth quarters of fiscal years 2024, 2023, and 2022, we completed our annual qualitative impairment tests and concluded that goodwill was not impaired.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-24-000029:notes:119]
Amortizable Intangible Assets
The components of our amortizable intangible assets are as follows:

[0001045810-24-000029:notes:120]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 2,642 |  |  | $ | (1,720) |  |  | $ | 922 |  |  | $ | 3,093 |  |  | $ | (1,614) |  |  | $ | 1,479 |  |
| Patents and licensed technology | 449 |  |  | (259) |  |  | 190 |  |  | 446 |  |  | (249) |  |  | 197 |  |
| Total intangible assets | $ | 3,091 |  |  | $ | (1,979) |  |  | $ | 1,112 |  |  | $ | 3,539 |  |  | $ | (1,863) |  |  | $ | 1,676 |  |

[0001045810-24-000029:notes:121]
(1)    During the first quarter of fiscal year 2023, we commenced amortization of a $630 million in-process research and development intangible asset related to our acquisition of Mellanox.

[0001045810-24-000029:notes:122]
Amortization expense associated with intangible assets for fiscal years 2024, 2023, and 2022 was $614 million, $699 million, and $563 million, respectively.

[0001045810-24-000029:notes:123]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of January 28, 2024:

[0001045810-24-000029:notes:124]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 | $ | 555 |  |
| 2026 | 261 |  |
| 2027 | 150 |  |
| 2028 | 37 |  |
| 2029 | 9 |  |
| 2030 and thereafter | 100 |  |
| Total | $ | 1,112 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-24-000029:notes:125]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-24-000029:notes:126]
The following is a summary of cash equivalents and marketable securities:

[0001045810-24-000029:notes:127]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

[0001045810-24-000029:notes:128]
|  | Jan 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

[0001045810-24-000029:notes:129]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-24-000029:notes:130]
|  | Jan 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 3,343 |  |  | $ | (5) |  |  | $ | 1,078 |  |  | $ | (5) |  |  | $ | 4,421 |  |  | $ | (10) |  |
| Corporate debt securities | 1,306 |  |  | (3) |  |  | 618 |  |  | (2) |  |  | 1,924 |  |  | (5) |  |
| Debt securities issued by U.S. government agencies | 670 |  |  | (1) |  |  | — |  |  | — |  |  | 670 |  |  | (1) |  |
| Total | $ | 5,319 |  |  | $ | (9) |  |  | $ | 1,696 |  |  | $ | (7) |  |  | $ | 7,015 |  |  | $ | (16) |  |

[0001045810-24-000029:notes:131]
|  | Jan 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 2,444 |  |  | $ | (21) |  |  | $ | 1,172 |  |  | $ | (23) |  |  | $ | 3,616 |  |  | $ | (44) |  |
| Corporate debt securities | 1,188 |  |  | (7) |  |  | 696 |  |  | (5) |  |  | 1,884 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,307 |  |  | (2) |  |  | — |  |  | — |  |  | 1,307 |  |  | (2) |  |
| Total | $ | 4,939 |  |  | $ | (30) |  |  | $ | 1,868 |  |  | $ | (28) |  |  | $ | 6,807 |  |  | $ | (58) |  |

[0001045810-24-000029:notes:132]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

[0001045810-24-000029:notes:133]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-24-000029:notes:134]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 16,336 |  |  | $ | 16,329 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 9,348 |  |  | 9,395 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 25,684 |  |  | $ | 25,724 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-24-000029:notes:135]
Fair Value of Financial Assets and Liabilities and Investments in Non-Affiliated Entities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-24-000029:notes:136]
|  |  | Fair Value at |
|  | Pricing Category |  | Jan 28, 2024 |  | Jan 29, 2023 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 3,031 |  |  | $ | 1,777 |  |
| Corporate debt securities | Level 2 |  | $ | 10,152 |  |  | $ | 4,797 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 9,524 |  |  | $ | 4,142 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,333 |  |  | $ | 1,834 |  |
| Certificates of deposit | Level 2 |  | $ | 510 |  |  | $ | 365 |  |
| Foreign government bonds | Level 2 |  | $ | 174 |  |  | $ | 140 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities | Level 1 |  | $ | 225 |  |  | $ | 11 |  |
| Liabilities (1) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | — |  |  | $ | 1,230 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,228 |  |  | $ | 1,185 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 970 |  |  | $ | 966 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,115 |  |  | $ | 1,099 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,367 |  |  | $ | 1,364 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,057 |  |  | $ | 1,044 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 851 |  |  | $ | 870 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,604 |  |  | $ | 1,637 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 403 |  |  | $ | 410 |  |

[0001045810-24-000029:notes:137]
(1)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs.

[0001045810-24-000029:notes:138]
Our investments in non-affiliated entities include marketable equity securities, which are publicly traded, and non-marketable equity securities, which are primarily investments in privately held companies. Our marketable equity securities have readily determinable fair values and are recorded as long-term other assets on our Consolidated Balance Sheets at fair value with changes in fair value recorded in Other income and expense, net on our Consolidated Statements of Income. Marketable equity securities totaled $225 million and $11 million as of January 28, 2024 and January 29, 2023, respectively. The net unrealized and realized gains and losses of investments in marketable securities net were not significant for fiscal years 2024, 2023 and 2022.

[0001045810-24-000029:notes:139]
Our non-marketable equity securities are recorded in long-term other assets on our Consolidated Balance Sheets. The carrying value of our non-marketable equity securities totaled $1.3 billion and $288 million as of January 28, 2024 and January 29, 2023, respectively. Gains and losses on these investments, realized and unrealized, are recognized in Other income and expense, net on our Consolidated Statements of Income.

[0001045810-24-000029:notes:140]
Adjustments to the carrying value of our non-marketable equity securities accounted for under the measurement alternative were as follows:

[0001045810-24-000029:notes:141]
|  | Year Ended |
|  | Jan 28, 2024 |
|  | (In millions) |
| Carrying amount as of Jan 29, 2023 | $ | 288 |  |
| Adjustments related to non-marketable equity securities: |  |
| Net additions | 859 |  |
| Unrealized gains | 194 |  |
| Impairments and unrealized losses | (20) |  |
| Carrying amount as of Jan 28, 2024 | $ | 1,321 |  |

[0001045810-24-000029:notes:142]
In the fourth quarter of fiscal year 2024, one of our private company investments completed a secondary equity raise that resulted in an unrealized gain of $178 million.

[0001045810-24-000029:notes:143]
Net unrealized gains recognized for the year ended January 28, 2024 for non-marketable investments in non-affiliated entities still held as of January 28, 2024 were $174 million. Net unrealized and realized gains related to non-marketable equity securities were not significant for fiscal years 2023 and 2022.

[0001045810-24-000029:notes:144]
The following table summarizes the cumulative gross unrealized gains and cumulative gross unrealized losses and impairments related to non-marketable equity securities accounted for under the measurement alternative:

[0001045810-24-000029:notes:145]
|  | Jan 28, 2024 |
|  | (In millions) |
| Cumulative gross unrealized gains | $ | 270 |  |
| Cumulative gross unrealized losses and impairments | (45) |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-24-000029:notes:146]
Balance Sheet Components
Two customers accounted for 24% and 11% of our accounts receivable balance as of January 28, 2024. Two customers accounted for 14% and 11% of our accounts receivable balance as of January 29, 2023.

[0001045810-24-000029:notes:147]
Certain balance sheet components are as follows:

[0001045810-24-000029:notes:148]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | (In millions) |
| Inventories (1): |  |  |  |
| Raw materials | $ | 1,719 |  |  | $ | 2,430 |  |
| Work in-process | 1,505 |  |  | 466 |  |
| Finished goods | 2,058 |  |  | 2,263 |  |
| Total inventories | $ | 5,282 |  |  | $ | 5,159 |  |

[0001045810-24-000029:notes:149]
(1)   In fiscal years 2024 and 2023, we recorded an inventory provision of $774 million and $1.0 billion, respectively, in cost of revenue.

[0001045810-24-000029:notes:150]
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Buildings, leasehold improvements, and furniture | 1,816 |  |  | 1,598 |  |  | (B) |
| Equipment, compute hardware, and software | 5,200 |  |  | 4,303 |  |  | 3-7 |
| Construction in process | 189 |  |  | 382 |  |  | (C) |
| Total property and equipment, gross | 7,423 |  |  | 6,501 |  |  |  |
| Accumulated depreciation and amortization | (3,509) |  |  | (2,694) |  |  |  |
| Total property and equipment, net | $ | 3,914 |  |  | $ | 3,807 |  |  |  |

[0001045810-24-000029:notes:151]
(A)Land is a non-depreciable asset.

[0001045810-24-000029:notes:152]
(B)The estimated useful lives of our buildings are up to thirty years. Leasehold improvements and finance leases are amortized based on the lesser of either the asset’s estimated useful life or the expected remaining lease term.

[0001045810-24-000029:notes:153]
(C)Construction in process represents assets that are not available for their intended use as of the balance sheet date.

[0001045810-24-000029:notes:154]
Depreciation expense for fiscal years 2024, 2023, and 2022 was $894 million, $844 million, and $611 million, respectively.

[0001045810-24-000029:notes:155]
Accumulated amortization of leasehold improvements and finance leases was $400 million and $327 million as of January 28, 2024 and January 29, 2023, respectively.

[0001045810-24-000029:notes:156]
Property, equipment and intangible assets acquired by assuming related liabilities during fiscal years 2024, 2023, and 2022 were $170 million, $374 million, and $258 million, respectively.

[0001045810-24-000029:notes:157]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
| Other assets: | (In millions) |
| Prepaid supply and capacity agreements (1) | $ | 2,458 |  |  | $ | 2,989 |  |
| Investments in non-affiliated entities | 1,546 |  |  | 299 |  |
| Prepaid royalties | 364 |  |  | 387 |  |
| Other | 132 |  |  | 145 |  |
| Total other assets | $ | 4,500 |  |  | $ | 3,820 |  |

[0001045810-24-000029:notes:158]
(1)As of January 28, 2024 and January 29, 2023, there was an additional $2.5 billion and $458 million of short-term prepaid supply and capacity agreements included in Prepaid expenses and other current assets, respectively.

[0001045810-24-000029:notes:159]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | (In millions) |
| Accrued and Other Current Liabilities: |  |  |  |
| Customer program accruals | $ | 2,081 |  |  | $ | 1,196 |  |
| Excess inventory purchase obligations (1) | 1,655 |  |  | 954 |  |
| Deferred revenue (2) | 764 |  |  | 354 |  |
| Accrued payroll and related expenses | 675 |  |  | 530 |  |
| Product warranty and return provisions | 415 |  |  | 108 |  |
| Taxes payable | 296 |  |  | 467 |  |
| Operating leases | 228 |  |  | 176 |  |
| Unsettled share repurchases | 187 |  |  | 117 |  |
| Licenses and royalties | 182 |  |  | 149 |  |
| Other | 199 |  |  | 69 |  |
| Total accrued and other current liabilities | $ | 6,682 |  |  | $ | 4,120 |  |

[0001045810-24-000029:notes:160]
(1)In fiscal years 2024 and 2023, we recorded an expense of approximately $1.4 billion and $1.1 billion, respectively, in cost of revenue for inventory purchase obligations in excess of our current demand projections, supplier charges and for penalties related to cancellations and underutilization.

[0001045810-24-000029:notes:161]
(2)Deferred revenue primarily includes customer advances and deferrals related to support for hardware and software, license and development arrangements, and cloud services. $233 million and $35 million of the balance in fiscal 2024 and 2023 respectively, related to customer advances.

[0001045810-24-000029:notes:162]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | (In millions) |
| Other Long-Term Liabilities: |  |  |  |
| Income tax payable (1) | $ | 1,361 |  |  | $ | 1,204 |  |
| Deferred income tax | 462 |  |  | 247 |  |
| Deferred revenue (2) | 573 |  |  | 218 |  |
| Licenses payable | 80 |  |  | 181 |  |
| Other | 65 |  |  | 63 |  |
| Total other long-term liabilities | $ | 2,541 |  |  | $ | 1,913 |  |

[0001045810-24-000029:notes:163]
(1)Income tax payable is comprised of the long-term portion of the one-time transition tax payable, unrecognized tax benefits, and related interest and penalties.

[0001045810-24-000029:notes:164]
(2)Deferred revenue primarily includes deferrals related to support for hardware and software.

[0001045810-24-000029:notes:165]
Deferred Revenue

[0001045810-24-000029:notes:166]
The following table shows the changes in deferred revenue during fiscal years 2024 and 2023.

[0001045810-24-000029:notes:167]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 572 |  |  | $ | 502 |  |
| Deferred revenue additions during the period | 2,038 |  |  | 830 |  |
| Revenue recognized during the period | (1,273) |  |  | (760) |  |
| Balance at end of period | $ | 1,337 |  |  | $ | 572 |  |

[0001045810-24-000029:notes:168]
Revenue recognized during fiscal year 2024 that was included in deferred revenue as of January 29, 2023 was $338 million. Revenue recognized during fiscal year 2023 that was included in deferred revenue as of January 30, 2022 was $282 million.

[0001045810-24-000029:notes:169]
Revenue related to remaining performance obligations represents the contracted license and development arrangements and support for hardware and software. This includes deferred revenue currently recorded and amounts that will be

[0001045810-24-000029:notes:170]
invoiced in future periods. Revenue allocated to remaining performance obligations, which includes deferred revenue and amounts that will be invoiced and recognized as revenue in future periods, was $1.1 billion as of January 28, 2024. We expect to recognize approximately 40% of this revenue over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-24-000029:notes:171]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur.

[0001045810-24-000029:notes:172]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than the U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-24-000029:notes:173]
The table below presents the notional value of our foreign currency forward contracts outstanding:

[0001045810-24-000029:notes:174]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,168 |  |  | $ | 1,128 |  |
| Non-designated hedges | $ | 597 |  |  | $ | 366 |  |

[0001045810-24-000029:notes:175]
The unrealized gains and losses or fair value of our foreign currency forward contracts was not significant as of January 28, 2024 and January 29, 2023.

[0001045810-24-000029:notes:176]
As of January 28, 2024, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-24-000029:notes:177]
During fiscal years 2024 and 2023, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-24-000029:notes:178]
Debt
Long-Term Debt

[0001045810-24-000029:notes:179]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:

[0001045810-24-000029:notes:180]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Jan 28, 2024 |  | Jan 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 (1) |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.4 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.4 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.2 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.4 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.2 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.2 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.2 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (41) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,709 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,459 |  |  | $ | 9,703 |  |

[0001045810-24-000029:notes:181]
(1)   In fiscal year 2024, we repaid the 0.309% Notes Due 2023.

[0001045810-24-000029:notes:182]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-24-000029:notes:183]
As of January 28, 2024, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-24-000029:notes:184]
Commercial Paper

[0001045810-24-000029:notes:185]
We have a $575 million commercial paper program to support general corporate purposes. As of January 28, 2024, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-24-000029:notes:186]
Commitments and Contingencies
Purchase Obligations

[0001045810-24-000029:notes:187]
Our purchase obligations reflect our commitments to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-24-000029:notes:188]
As of January 28, 2024, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $16.1 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of cancellation. Other non-inventory purchase obligations were $4.6 billion, which includes $3.5 billion of multi-year cloud service agreements, primarily to support our research and development efforts.

[0001045810-24-000029:notes:189]
Total future purchase commitments as of January 28, 2024 are as follows:

[0001045810-24-000029:notes:190]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 | $ | 17,316 |  |
| 2026 | 1,143 |  |
| 2027 | 1,060 |  |
| 2028 | 770 |  |
| 2029 and thereafter | 418 |  |
| Total | $ | 20,707 |  |

[0001045810-24-000029:notes:191]
Accrual for Product Warranty Liabilities

[0001045810-24-000029:notes:192]
The estimated amount of product warranty liabilities was $306 million and $82 million as of January 28, 2024 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

[0001045810-24-000029:notes:193]
|  |  | Year Ended |
|  |  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| Balance at beginning of period |  | $ | 82 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions |  | 278 |  |  | 145 |  | 40 |
| Utilization |  | (54) |  |  | (109) |  |  | (16) |  |
| Balance at end of period |  | $ | 306 |  |  | $ | 82 |  |  | $ | 46 |  |

[0001045810-24-000029:notes:194]
In fiscal years 2024 and 2023, the additions in product warranty liabilities primarily related to Compute & Networking segment.

[0001045810-24-000029:notes:195]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.

[0001045810-24-000029:notes:196]
Litigation

[0001045810-24-000029:notes:197]
Securities Class Action and Derivative Lawsuits

[0001045810-24-000029:notes:198]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s

[0001045810-24-000029:notes:199]
resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA’s deadline to file a petition for a writ of certiorari is March 4, 2024.

[0001045810-24-000029:notes:200]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties are conferring regarding the next steps in this derivative matter. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-24-000029:notes:201]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties are conferring regarding the next steps in these derivative matters. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-24-000029:notes:202]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-24-000029:notes:203]
Accounting for Loss Contingencies

[0001045810-24-000029:notes:204]
As of January 28, 2024, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-24-000029:notes:205]
Income Taxes
The income tax expense (benefit) applicable to income before income taxes consists of the following:

[0001045810-24-000029:notes:206]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 5,710 |  |  | $ | 1,703 |  |  | $ | 482 |  |
| State | 335 |  |  | 46 |  |  | 42 |  |
| Foreign | 502 |  |  | 228 |  |  | 71 |  |
| Total current | 6,547 |  |  | 1,977 |  |  | 595 |  |
| Deferred income taxes: |  |  |  |  |  |
| Federal | (2,499) |  |  | (2,165) |  |  | (420) |  |
| State | (206) |  |  | — |  |  | — |  |
| Foreign | 216 |  |  | 1 |  |  | 14 |  |
| Total deferred | (2,489) |  |  | (2,164) |  |  | (406) |  |
| Income tax expense (benefit) | $ | 4,058 |  |  | $ | (187) |  |  | $ | 189 |  |

[0001045810-24-000029:notes:207]
Income before income tax consists of the following:

[0001045810-24-000029:notes:208]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| U.S. | $ | 29,495 |  |  | $ | 3,477 |  |  | $ | 8,446 |  |
| Foreign | 4,323 |  |  | 704 |  |  | 1,495 |  |
| Income before income tax | $ | 33,818 |  |  | $ | 4,181 |  |  | $ | 9,941 |  |

[0001045810-24-000029:notes:209]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21% to income before income taxes as follows:

[0001045810-24-000029:notes:210]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions, except percentages) |
| Tax expense computed at federal statutory rate | $ | 7,102 |  |  | 21.0 | % |  | $ | 878 |  |  | 21.0 | % |  | $ | 2,088 |  |  | 21.0 | % |
| Expense (benefit) resulting from: |  |  |  |  |  |  |  |  |  |  |  |
| State income taxes, net of federal tax effect | 120 |  |  | 0.4 | % |  | 50 |  |  | 1.2 | % |  | 42 |  |  | 0.4 | % |
| Foreign-derived intangible income | (1,408) |  |  | (4.2) | % |  | (739) |  |  | (17.7) | % |  | (520) |  |  | (5.2) | % |
| Stock-based compensation | (741) |  |  | (2.2) | % |  | (309) |  |  | (7.4) | % |  | (337) |  |  | (3.4) | % |
| Foreign tax rate differential | (467) |  |  | (1.4) | % |  | (83) |  |  | (2.0) | % |  | (497) |  |  | (5.0) | % |
| U.S. federal research and development tax credit | (431) |  |  | (1.3) | % |  | (278) |  |  | (6.6) | % |  | (289) |  |  | (2.9) | % |
| Acquisition termination cost | — |  |  | — | % |  | 261 |  |  | 6.2 | % |  | — |  |  | — | % |
| IP domestication | — |  |  | — | % |  | — |  |  | — | % |  | (244) |  |  | (2.5) | % |
| Other | (117) |  |  | (0.3) | % |  | 33 |  |  | 0.8 | % |  | (54) |  |  | (0.5) | % |
| Income tax expense (benefit) | $ | 4,058 |  |  | 12.0 | % |  | $ | (187) |  |  | (4.5) | % |  | $ | 189 |  |  | 1.9 | % |

[0001045810-24-000029:notes:211]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-24-000029:notes:212]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
|  | (In millions) |
| Deferred tax assets: |  |
| Capitalized research and development expenditure | $ | 3,376 |  |  | $ | 1,859 |  |
| GILTI deferred tax assets | 1,576 |  |  | 800 |  |
| Accruals and reserves, not currently deductible for tax purposes | 1,121 |  |  | 686 |  |
| Research and other tax credit carryforwards | 936 |  |  | 951 |  |
| Net operating loss and capital loss carryforwards | 439 |  |  | 409 |  |
| Operating lease liabilities | 263 |  |  | 193 |  |
| Stock-based compensation | 106 |  |  | 99 |  |
| Property, equipment and intangible assets | 4 |  |  | 66 |  |
| Other deferred tax assets | 179 |  |  | 91 |  |
| Gross deferred tax assets | 8,000 |  |  | 5,154 |  |
| Less valuation allowance | (1,552) |  |  | (1,484) |  |
| Total deferred tax assets | 6,448 |  |  | 3,670 |  |
| Deferred tax liabilities: |  |  |  |
| Unremitted earnings of foreign subsidiaries | (502) |  |  | (228) |  |
| Operating lease assets | (255) |  |  | (179) |  |
| Acquired intangibles | (74) |  |  | (115) |  |
| Gross deferred tax liabilities | (831) |  |  | (522) |  |
| Net deferred tax asset (1) | $ | 5,617 |  |  | $ | 3,148 |  |

[0001045810-24-000029:notes:213]
(1)  Net deferred tax asset includes long-term deferred tax assets of $6.1 billion and $3.4 billion and long-term deferred tax liabilities of $462 million and $247 million for fiscal years 2024 and 2023, respectively. Long-term deferred tax liabilities are included in other long-term liabilities on our Consolidated Balance Sheets.

[0001045810-24-000029:notes:214]
As of January 28, 2024, we intend to indefinitely reinvest approximately $1.1 billion and $250 million of cumulative undistributed earnings held by certain subsidiaries in Israel and the United Kingdom, respectively. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to these investments as the determination of such amount is not practicable.

[0001045810-24-000029:notes:215]
As of January 28, 2024 and January 29, 2023, we had a valuation allowance of $1.6 billion and $1.5 billion, respectively, related to capital loss carryforwards, and certain state and other deferred tax assets that management determined are not likely to be realized due, in part, to jurisdictional projections of future taxable income, including capital gains. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-24-000029:notes:216]
As of January 28, 2024, we had U.S. federal, state and foreign net operating loss carryforwards of $315 million, $342 million and $361 million, respectively. The federal and state carryforwards will begin to expire in fiscal years 2026 and 2025, respectively. The foreign net operating loss carryforwards of $361 million may be carried forward indefinitely. As of January 28, 2024, we had federal research tax credit carryforwards of $31 million, before the impact of uncertain tax positions, that will begin to expire in fiscal year 2025. We have state research tax credit carryforwards of $1.6 billion, before the impact of uncertain tax positions. $1.5 billion is attributable to the State of California and may be carried over indefinitely and $75 million is attributable to various other states and will begin to expire in fiscal year 2025. As of January 28, 2024, we had federal capital loss carryforwards of $1.4 billion that will begin to expire in fiscal year 2025.

[0001045810-24-000029:notes:217]
Our tax attributes remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of tax attributes may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the tax attributes may expire or be denied before utilization.

[0001045810-24-000029:notes:218]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-24-000029:notes:219]
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,238 |  |  | $ | 1,013 |  |  | $ | 776 |  |
| Increases in tax positions for current year | 616 |  |  | 268 |  |  | 246 |  |
| Increases in tax positions for prior years | 87 |  |  | 1 |  |  | 14 |  |
| Decreases in tax positions for prior years | (148) |  |  | (15) |  |  | (4) |  |
| Settlements | (104) |  |  | (9) |  |  | (8) |  |
| Lapse in statute of limitations | (19) |  |  | (20) |  |  | (11) |  |
| Balance at end of period | $ | 1,670 |  |  | $ | 1,238 |  |  | $ | 1,013 |  |

[0001045810-24-000029:notes:220]
Included in the balance of unrecognized tax benefits as of January 28, 2024 are $1.0 billion of tax benefits that would affect our effective tax rate if recognized.

[0001045810-24-000029:notes:221]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term amount refundable, if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-24-000029:notes:222]
We include interest and penalties related to unrecognized tax benefits as a component of income tax expense. We recognized net interest and penalties related to unrecognized tax benefits in the income tax expense line of our consolidated statements of income of $42 million, $33 million, and $14 million during fiscal years 2024, 2023 and 2022, respectively. As of January 28, 2024 and January 29, 2023, we have accrued $140 million and $95 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our gross unrecognized tax benefits.

[0001045810-24-000029:notes:223]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 28, 2024, we have not identified any positions for which it is reasonably possible that the total amounts of unrecognized tax benefits will significantly increase or decrease within the next twelve months.

[0001045810-24-000029:notes:224]
We are subject to taxation by taxing authorities both in the United States and other countries. As of January 28, 2024, the significant tax jurisdictions that may be subject to examination include the United States for fiscal years after 2020, as well as China, Germany, Hong Kong, India, Israel, Taiwan, and the United Kingdom for fiscal years 2005 through 2023. As of January 28, 2024, the significant tax jurisdictions for which we are currently under examination include Germany, India, Israel, and Taiwan for fiscal years 2005 through 2023.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-24-000029:notes:225]
Shareholders’ Equity
Capital Return Program

[0001045810-24-000029:notes:226]
In August 2023, our Board of Directors approved an increase to our share repurchase program of an additional $25.0 billion, without expiration. During fiscal year 2024, we repurchased 21 million shares of our common stock for $9.7 billion. As of January 28, 2024, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $22.5 billion. From January 29, 2024 through February 16, 2024, we repurchased 2.8 million shares for $1.9 billion pursuant to a Rule 10b5-1 trading plan. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-24-000029:notes:227]
During fiscal years 2024, 2023, and 2022, we paid $395 million, $398 million, and $399 million in cash dividends to our shareholders, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-24-000029:notes:228]
In fiscal year 2022, we retired our existing 349 million treasury shares. These shares assumed the status of authorized and unissued shares upon retirement. The excess of repurchase price over par value was allocated between additional paid-in capital and retained earnings, resulting in a reduction in additional paid-in capital by $20 million and retained earnings by $12.0 billion. Any future repurchased shares will assume the status of authorized and unissued shares.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-24-000029:notes:229]
Employee Retirement Plans
We provide tax-qualified defined contribution plans to eligible employees in the U.S. and certain other countries. Our contribution expense for fiscal years 2024, 2023, and 2022 was $255 million, $227 million, and $168 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-24-000029:notes:230]
Segment Information 
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance.

[0001045810-24-000029:notes:231]
The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive artificial intelligence, or AI, Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and DGX Cloud.

[0001045810-24-000029:notes:232]
The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; virtual GPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating 3D internet applications.

[0001045810-24-000029:notes:233]
Operating results by segment include costs or expenses that are directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

[0001045810-24-000029:notes:234]
The “All Other” category includes the expenses that our CODM does not assign to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related and other costs, intellectual property related, or IP-related costs, acquisition termination cost, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-24-000029:notes:235]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, our CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-24-000029:notes:236]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended Jan 28, 2024: |  |  |  |  |  |  |  |
| Revenue | $ | 47,405 |  |  | $ | 13,517 |  |  | $ | — |  |  | $ | 60,922 |  |
| Operating income (loss) | $ | 32,016 |  |  | $ | 5,846 |  |  | $ | (4,890) |  |  | $ | 32,972 |  |
| Year Ended Jan 29, 2023: |  |  |  |  |  |  |  |
| Revenue | $ | 15,068 |  |  | $ | 11,906 |  |  | $ | — |  |  | $ | 26,974 |  |
| Operating income (loss) | $ | 5,083 |  |  | $ | 4,552 |  |  | $ | (5,411) |  |  | $ | 4,224 |  |
| Year Ended Jan 30, 2022: |  |  |  |  |  |  |  |
| Revenue | $ | 11,046 |  |  | $ | 15,868 |  |  | $ | — |  |  | $ | 26,914 |  |
| Operating income (loss) | $ | 4,598 |  |  | $ | 8,492 |  |  | $ | (3,049) |  |  | $ | 10,041 |  |

[0001045810-24-000029:notes:237]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |
| Stock-based compensation expense | $ | (3,549) |  |  | $ | (2,710) |  |  | $ | (2,004) |  |
| Unallocated cost of revenue and operating expenses | (728) |  |  | (595) |  |  | (399) |  |
| Acquisition-related and other costs | (583) |  |  | (674) |  |  | (636) |  |
| IP-related and legal settlement costs | (40) |  |  | (23) |  |  | (10) |  |
| Restructuring costs and other | — |  |  | (54) |  |  | — |  |
| Acquisition termination cost | — |  |  | (1,353) |  |  | — |  |
| Other | 10 |  |  | (2) |  |  | — |  |
| Total | $ | (4,890) |  |  | $ | (5,411) |  |  | $ | (3,049) |  |

[0001045810-24-000029:notes:238]
Revenue by geographic areas is designated based upon the billing location of the customer. End customer location may be different than our customer’s billing location. Revenue by geographic areas was as follows:

[0001045810-24-000029:notes:239]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
| Revenue: | (In millions) |
| United States | $ | 26,966 |  |  | $ | 8,292 |  |  | $ | 4,349 |  |
| Taiwan | 13,405 |  |  | 6,986 |  |  | 8,544 |  |
| China (including Hong Kong) | 10,306 |  |  | 5,785 |  |  | 7,111 |  |
| Other countries | 10,245 |  |  | 5,911 |  |  | 6,910 |  |
| Total revenue | $ | 60,922 |  |  | $ | 26,974 |  |  | $ | 26,914 |  |

[0001045810-24-000029:notes:240]
Revenue from sales to customers outside of the United States accounted for 56%, 69%, and 84% of total revenue for fiscal years 2024, 2023, and 2022, respectively. The increase in revenue to the United States for fiscal year 2024 was primarily due to higher U.S.-based Compute & Networking segment demand.

[0001045810-24-000029:notes:241]
Sales to one customer represented 13% of total revenue for fiscal year 2024, which was attributable to the Compute & Networking segment. No customer represented 10% or more of total revenue for fiscal years 2023 and 2022.

[0001045810-24-000029:notes:242]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-24-000029:notes:243]
|  | Year Ended |
|  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
| Revenue: | (In millions) |
| Data Center | $ | 47,525 |  |  | $ | 15,005 |  |  | $ | 10,613 |  |
| Gaming | 10,447 |  |  | 9,067 |  |  | 12,462 |  |
| Professional Visualization | 1,553 |  |  | 1,544 |  |  | 2,111 |  |
| Automotive | 1,091 |  |  | 903 |  |  | 566 |  |
| OEM and Other | 306 |  |  | 455 |  |  | 1,162 |  |
| Total revenue | $ | 60,922 |  |  | $ | 26,974 |  |  | $ | 26,914 |  |

[0001045810-24-000029:notes:244]
The following table presents summarized information for long-lived assets by country. Long-lived assets consist of property and equipment and exclude other assets, operating lease assets, goodwill, and intangible assets.

[0001045810-24-000029:notes:245]
|  | Jan 28, 2024 |  | Jan 29, 2023 |
| Long-lived assets: | (In millions) |
| United States | $ | 2,595 |  |  | $ | 2,587 |  |
| Taiwan | 773 |  |  | 702 |  |
| Israel | 325 |  |  | 283 |  |
| Other countries | 221 |  |  | 235 |  |
| Total long-lived assets | $ | 3,914 |  |  | $ | 3,807 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-24-000029:notes:246]
Schedule II – Valuation and Qualifying Accounts

[0001045810-24-000029:notes:247]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2024 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 26 |  |  | $ | 213 |  | (2) | $ | (130) |  | (4) | $ | 109 |  |
| Deferred tax valuation allowance |  | $ | 1,484 |  |  | $ | 162 |  | (3) | $ | (94) |  | (3) | $ | 1,552 |  |
| Fiscal year 2023 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 13 |  |  | $ | 104 |  | (2) | $ | (91) |  | (4) | $ | 26 |  |
| Deferred tax valuation allowance |  | $ | 907 |  |  | $ | 577 |  | (3) | $ | — |  |  | $ | 1,484 |  |
| Fiscal year 2022 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 17 |  |  | $ | 19 |  | (2) | $ | (23) |  | (4) | $ | 13 |  |
| Deferred tax valuation allowance |  | $ | 728 |  |  | $ | 179 |  | (3) | $ | — |  |  | $ | 907 |  |

[0001045810-24-000029:notes:248]
(1)Additions represent either expense or acquired balances and deductions represent write-offs.

[0001045810-24-000029:notes:249]
(2)Additions represent estimated product returns charged as a reduction to revenue or an acquired balance.

[0001045810-24-000029:notes:250]
(3)Additional valuation allowance on deferred tax assets not likely to be realized. Additions represent additional valuation allowance on capital loss carryforwards, and certain state and other deferred tax assets. Deductions represent the release of valuation allowance on certain state deferred tax assets. Refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-24-000029:notes:251]
(4)Represents sales returns.
