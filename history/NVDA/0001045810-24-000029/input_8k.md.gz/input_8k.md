# NVDA 8-K — 0001045810-24-000028 filed 2024-02-21

## item codes, every 8-K on or before 2024-02-21

- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2024-02-21

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-24-000028:8k_2_02:1]
EX-99.1
2
q4fy24pr.htm
Q4FY24 PRESS RELEASE

[0001045810-24-000028:8k_2_02:2]
Document

[0001045810-24-000028:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-24-000028:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2024

[0001045810-24-000028:8k_2_02:5]
•Record quarterly revenue of $22.1 billion, up 22% from Q3, up 265% from year ago

[0001045810-24-000028:8k_2_02:6]
•Record quarterly Data Center revenue of $18.4 billion, up 27% from Q3, up 409% from year ago

[0001045810-24-000028:8k_2_02:7]
•Record full-year revenue of $60.9 billion, up 126%

[0001045810-24-000028:8k_2_02:8]
SANTA CLARA, Calif.—Feb. 21, 2024―NVIDIA (NASDAQ: NVDA) today reported revenue for the fourth quarter ended January 28, 2024, of $22.1 billion, up 22% from the previous quarter and up 265% from a year ago.

[0001045810-24-000028:8k_2_02:9]
For the quarter, GAAP earnings per diluted share was $4.93, up 33% from the previous quarter and up 765% from a year ago. Non-GAAP earnings per diluted share was $5.16, up 28% from the previous quarter and up 486% from a year ago.

[0001045810-24-000028:8k_2_02:10]
For fiscal 2024, revenue was up 126% to $60.9 billion. GAAP earnings per diluted share was $11.93, up 586% from a year ago. Non-GAAP earnings per diluted share was $12.96, up 288% from a year ago.

[0001045810-24-000028:8k_2_02:11]
“Accelerated computing and generative AI have hit the tipping point. Demand is surging worldwide across companies, industries and nations,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-24-000028:8k_2_02:12]
“Our Data Center platform is powered by increasingly diverse drivers — demand for data processing, training and inference from large cloud-service providers and GPU-specialized ones, as well as from enterprise software and consumer internet companies. Vertical industries — led by auto, financial services and healthcare — are now at a multibillion-dollar level.

[0001045810-24-000028:8k_2_02:13]
“NVIDIA RTX, introduced less than six years ago, is now a massive PC platform for generative AI, enjoyed by 100 million gamers and creators. The year ahead will bring major new product cycles with exceptional innovations to help propel our industry forward. Come join us at next month’s GTC, where we and our rich ecosystem will reveal the exciting future ahead,” he said.

[0001045810-24-000028:8k_2_02:14]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on March 27, 2024, to all shareholders of record on March 6, 2024.

[0001045810-24-000028:8k_2_02:15]
Q4 Fiscal 2024 Summary

[0001045810-24-000028:8k_2_02:16]
| GAAP |
| ($ in millions, except earnings per share) | Q4 FY24 | Q3 FY24 | Q4 FY23 | Q/Q | Y/Y |
| Revenue | $22,103 | $18,120 | $6,051 | Up 22% | Up 265% |
| Gross margin | 76.0 | % | 74.0 | % | 63.3 | % | Up 2.0 pts | Up 12.7 pts |
| Operating expenses | $3,176 | $2,983 | $2,576 | Up 6% | Up 23% |
| Operating income | $13,615 | $10,417 | $1,257 | Up 31% | Up 983% |
| Net income | $12,285 | $9,243 | $1,414 | Up 33% | Up 769% |
| Diluted earnings per share | $4.93 | $3.71 | $0.57 | Up 33% | Up 765% |

[0001045810-24-000028:8k_2_02:17]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q4 FY24 | Q3 FY24 | Q4 FY23 | Q/Q | Y/Y |
| Revenue | $22,103 | $18,120 | $6,051 | Up 22% | Up 265% |
| Gross margin | 76.7 | % | 75.0 | % | 66.1 | % | Up 1.7 pts | Up 10.6 pts |
| Operating expenses | $2,210 | $2,026 | $1,775 | Up 9% | Up 25% |
| Operating income | $14,749 | $11,557 | $2,224 | Up 28% | Up 563% |
| Net income | $12,839 | $10,020 | $2,174 | Up 28% | Up 491% |
| Diluted earnings per share | $5.16 | $4.02 | $0.88 | Up 28% | Up 486% |

[0001045810-24-000028:8k_2_02:18]
Fiscal 2024 Summary

[0001045810-24-000028:8k_2_02:19]
| GAAP |
| ($ in millions, except earnings per share) | FY24 | FY23 | Y/Y |
| Revenue | $60,922 | $26,974 | Up 126% |
| Gross margin | 72.7 | % | 56.9 | % | Up 15.8 pts |
| Operating expenses | $11,329 | $11,132 | Up 2% |
| Operating income | $32,972 | $4,224 | Up 681% |
| Net income | $29,760 | $4,368 | Up 581% |
| Diluted earnings per share | $11.93 | $1.74 | Up 586% |

[0001045810-24-000028:8k_2_02:20]
| Non-GAAP |
| ($ in millions, except earnings per share) | FY24 | FY23 | Y/Y |
| Revenue | $60,922 | $26,974 | Up 126% |
| Gross margin | 73.8 | % | 59.2 | % | Up 14.6 pts |
| Operating expenses | $7,825 | $6,925 | Up 13% |
| Operating income | $37,134 | $9,040 | Up 311% |
| Net income | $32,312 | $8,366 | Up 286% |
| Diluted earnings per share | $12.96 | $3.34 | Up 288% |

[0001045810-24-000028:8k_2_02:21]
Outlook

[0001045810-24-000028:8k_2_02:22]
NVIDIA’s outlook for the first quarter of fiscal 2025 is as follows:

[0001045810-24-000028:8k_2_02:23]
•Revenue is expected to be $24.0 billion, plus or minus 2%.

[0001045810-24-000028:8k_2_02:24]
•GAAP and non-GAAP gross margins are expected to be 76.3% and 77.0%, respectively, plus or minus 50 basis points.

[0001045810-24-000028:8k_2_02:25]
•GAAP and non-GAAP operating expenses are expected to be approximately $3.5 billion and $2.5 billion, respectively.

[0001045810-24-000028:8k_2_02:26]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $250 million, excluding gains and losses from non-affiliated investments.

[0001045810-24-000028:8k_2_02:27]
•GAAP and non-GAAP tax rates are expected to be 17.0%, plus or minus 1%, excluding any discrete items.

[0001045810-24-000028:8k_2_02:28]
Highlights

[0001045810-24-000028:8k_2_02:29]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-24-000028:8k_2_02:30]
Data Center

[0001045810-24-000028:8k_2_02:31]
•Fourth-quarter revenue was a record $18.4 billion, up 27% from the previous quarter and up 409% from a year ago. Full-year revenue rose 217% to a record $47.5 billion.

[0001045810-24-000028:8k_2_02:32]
•Launched, in collaboration with Google, optimizations across NVIDIA’s data center and PC AI platforms for Gemma, Google’s groundbreaking open language models.

[0001045810-24-000028:8k_2_02:33]
•Expanded its strategic collaboration with Amazon Web Services to host NVIDIA® DGX™ Cloud on AWS.

[0001045810-24-000028:8k_2_02:34]
•Announced that Amgen will use the NVIDIA DGX SuperPOD™ to power insights into drug discovery, diagnostics and precision medicine.

[0001045810-24-000028:8k_2_02:35]
•Announced NVIDIA NeMo™ Retriever, a generative AI microservice that lets enterprises connect custom large language models with enterprise data to deliver highly accurate responses for AI applications.

[0001045810-24-000028:8k_2_02:36]
•Introduced NVIDIA MONAI™ cloud APIs to help developers and platform providers integrate AI into their medical-imaging offerings.

[0001045810-24-000028:8k_2_02:37]
•Announced that Singtel will bring generative AI services to Singapore through energy-efficient data centers that the telco is building with NVIDIA Hopper™ architecture GPUs.

[0001045810-24-000028:8k_2_02:38]
•Introduced plans with Cisco to help enterprises quickly and easily deploy and manage secure AI infrastructure.

[0001045810-24-000028:8k_2_02:39]
•Supported the National Artificial Intelligence Research Resource pilot program, a major step by the U.S. government toward a shared national research infrastructure.

[0001045810-24-000028:8k_2_02:40]
Gaming

[0001045810-24-000028:8k_2_02:41]
•Fourth-quarter revenue was $2.9 billion, flat from the previous quarter and up 56% from a year ago. Full-year revenue rose 15% to $10.4 billion.

[0001045810-24-000028:8k_2_02:42]
•Launched GeForce RTX™ 40 SUPER Series GPUs, starting at $599, which support the latest NVIDIA RTX™ technologies, including DLSS 3.5 Ray Reconstruction and NVIDIA Reflex.

[0001045810-24-000028:8k_2_02:43]
•Announced generative AI capabilities for its installed base of over 100 million RTX AI PCs, including Tensor-RT™ LLM to accelerate inference on large language models, and Chat with RTX, a tech demo that lets users personalize a chatbot with their own content.

[0001045810-24-000028:8k_2_02:44]
•Introduced microservices for the NVIDIA Avatar Cloud Engine, allowing game and application developers to integrate state-of-the-art generative AI models into non-playable characters.

[0001045810-24-000028:8k_2_02:45]
•Reached the milestone of 500 AI-powered RTX games and applications utilizing NVIDIA DLSS, ray tracing and other NVIDIA RTX technologies.

[0001045810-24-000028:8k_2_02:46]
Professional Visualization

[0001045810-24-000028:8k_2_02:47]
•Fourth-quarter revenue was $463 million, up 11% from the previous quarter and up 105% from a year ago. Full-year revenue rose 1% to $1.6 billion.

[0001045810-24-000028:8k_2_02:48]
•Announced adoption of NVIDIA Omniverse™ by the global automotive-configurator ecosystem.

[0001045810-24-000028:8k_2_02:49]
•Announced the NVIDIA RTX 2000 Ada Generation GPU, bringing the latest AI, graphics and compute technology to compact workstations.

[0001045810-24-000028:8k_2_02:50]
Automotive

[0001045810-24-000028:8k_2_02:51]
•Fourth-quarter revenue was $281 million, up 8% from the previous quarter and down 4% from a year ago. Full-year revenue rose 21% to $1.1 billion.

[0001045810-24-000028:8k_2_02:52]
•Announced further adoption of its NVIDIA DRIVE® platform, with Great Wall Motors, ZEEKR and Xiaomi using DRIVE Orin™ to power intelligent automated-driving systems and Li Auto selecting DRIVE Thor™ as its centralized car computer.

[0001045810-24-000028:8k_2_02:53]
CFO Commentary

[0001045810-24-000028:8k_2_02:54]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-24-000028:8k_2_02:55]
Conference Call and Webcast Information

[0001045810-24-000028:8k_2_02:56]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2024 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2025.

[0001045810-24-000028:8k_2_02:57]
Non-GAAP Measures

[0001045810-24-000028:8k_2_02:58]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, IP-related costs, other, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s

[0001045810-24-000028:8k_2_02:59]
non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-24-000028:8k_2_02:60]
About NVIDIA

[0001045810-24-000028:8k_2_02:61]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and is fueling industrial digitalization across markets. NVIDIA is now a full-stack computing infrastructure company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-24-000028:8k_2_02:62]
###

[0001045810-24-000028:8k_2_02:63]
For further information, contact:

[0001045810-24-000028:8k_2_02:64]
| Simona Jankowski |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-24-000028:8k_2_02:65]
Certain statements in this press release including, but not limited to, statements as to: demand for accelerated computing and generative AI surging worldwide across companies, industries and nations; our Data Center platform being powered by increasingly diverse drivers, including demand for data processing, training and inference from large cloud-service providers and GPU-specialized ones, as well as from enterprise software and consumer internet companies; vertical industries led by auto, financial, services and healthcare now at a multibillion-dollar level; NVIDIA RTX becoming a massive PC platform for generative AI enjoyed by 100 million gamers and creators; the year ahead bringing major new product cycles with exceptional innovations to help propel our industry forward; our upcoming conference at GTC, where we and our rich ecosystem will reveal the exciting future ahead; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook and expected tax rates for the first quarter of fiscal 2025; the benefits, impact, performance, features and availability of NVIDIA’s products and technologies, including NVIDIA AI platforms, NVIDIA DGX Cloud, NVIDIA DGX SuperPOD, NVIDIA NeMo Retriever, NVIDIA MONAI cloud APIs, NVIDIA Hopper architecture GPUs, NVIDIA GeForce RTX 40 SUPER Series GPUs, NVIDIA DLSS 3.5 Ray Reconstruction, NVIDIA Reflex, NVIDIA TensorRT-LLM, Chat with RTX, microservices for the NVIDIA Avatar Cloud Engine, NVIDIA DLSS, ray tracing and other NVIDIA RTX technologies, NVIDIA Omniverse, NVIDIA RTX 2000 Ada Generation GPU, NVIDIA DRIVE platform, NVIDIA DRIVE Orin and NVIDIA DRIVE Thor; and our collaborations with third parties are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; and unexpected loss of performance of our products or technologies when integrated into systems, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-24-000028:8k_2_02:66]
© 2024 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce RTX, NVIDIA DGX, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA DRIVE Thor, NVIDIA Hopper, NVIDIA MONAI, NVIDIA NeMo, NVIDIA Omniverse, NVIDIA RTX and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-24-000028:8k_2_02:67]
NVIDIA CORPORATION

[0001045810-24-000028:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-24-000028:8k_2_02:69]
(In millions, except per share data)

[0001045810-24-000028:8k_2_02:70]
(Unaudited)

[0001045810-24-000028:8k_2_02:71]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 28, |  | January 29, |  | January 28, |  | January 29, |
|  |  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue | $ | 22,103 |  |  | $ | 6,051 |  |  | $ | 60,922 |  |  | $ | 26,974 |  |
| Cost of revenue | 5,312 |  |  | 2,218 |  |  | 16,621 |  |  | 11,618 |  |
| Gross profit | 16,791 |  |  | 3,833 |  |  | 44,301 |  |  | 15,356 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 2,465 |  |  | 1,951 |  |  | 8,675 |  |  | 7,339 |  |
|  | Sales, general and administrative | 711 |  |  | 625 |  |  | 2,654 |  |  | 2,440 |  |
|  | Acquisition termination cost | — |  |  | — |  |  | — |  |  | 1,353 |  |
|  |  | Total operating expenses | 3,176 |  |  | 2,576 |  |  | 11,329 |  |  | 11,132 |  |
| Operating income | 13,615 |  |  | 1,257 |  |  | 32,972 |  |  | 4,224 |  |
|  | Interest income | 294 |  |  | 115 |  |  | 866 |  |  | 267 |  |
|  | Interest expense | (63) |  |  | (65) |  |  | (257) |  |  | (262) |  |
|  | Other, net | 260 |  |  | (18) |  |  | 237 |  |  | (48) |  |
|  |  | Other income (expense), net | 491 |  |  | 32 |  |  | 846 |  |  | (43) |  |
| Income before income tax | 14,106 |  |  | 1,289 |  |  | 33,818 |  |  | 4,181 |  |
| Income tax expense (benefit) | 1,821 |  |  | (125) |  |  | 4,058 |  |  | (187) |  |
| Net income | $ | 12,285 |  |  | $ | 1,414 |  |  | $ | 29,760 |  |  | $ | 4,368 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 4.98 |  |  | $ | 0.57 |  |  | $ | 12.05 |  |  | $ | 1.76 |  |
|  | Diluted | $ | 4.93 |  |  | $ | 0.57 |  |  | $ | 11.93 |  |  | $ | 1.74 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,466 |  |  | 2,464 |  |  | 2,469 |  |  | 2,487 |  |
|  | Diluted | 2,490 |  |  | 2,477 |  |  | 2,494 |  |  | 2,507 |  |

[0001045810-24-000028:8k_2_02:72]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | January 28, |  | January 29, |
|  |  |  |  | 2024 |  | 2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 25,984 |  |  | $ | 13,296 |  |
|  | Accounts receivable, net |  | 9,999 |  |  | 3,827 |  |
|  | Inventories |  | 5,282 |  |  | 5,159 |  |
|  | Prepaid expenses and other current assets |  | 3,080 |  |  | 791 |  |
|  |  | Total current assets |  | 44,345 |  |  | 23,073 |  |
| Property and equipment, net |  | 3,914 |  |  | 3,807 |  |
| Operating lease assets |  | 1,346 |  |  | 1,038 |  |
| Goodwill |  | 4,430 |  |  | 4,372 |  |
| Intangible assets, net |  | 1,112 |  |  | 1,676 |  |
| Deferred income tax assets |  | 6,081 |  |  | 3,396 |  |
| Other assets |  | 4,500 |  |  | 3,820 |  |
|  |  | Total assets |  | $ | 65,728 |  |  | $ | 41,182 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 2,699 |  |  | $ | 1,193 |  |
|  | Accrued and other current liabilities |  | 6,682 |  |  | 4,120 |  |
|  | Short-term debt |  | 1,250 |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 10,631 |  |  | 6,563 |  |
| Long-term debt |  | 8,459 |  |  | 9,703 |  |
| Long-term operating lease liabilities |  | 1,119 |  |  | 902 |  |
| Other long-term liabilities |  | 2,541 |  |  | 1,913 |  |
|  |  | Total liabilities |  | 22,750 |  |  | 19,081 |  |
| Shareholders' equity |  | 42,978 |  |  | 22,101 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 65,728 |  |  | $ | 41,182 |  |

[0001045810-24-000028:8k_2_02:73]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 28, |  | January 29, |  | January 28, |  | January 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 12,285 |  |  | $ | 1,414 |  |  | $ | 29,760 |  |  | $ | 4,368 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 993 |  |  | 738 |  |  | 3,549 |  |  | 2,709 |  |
| Depreciation and amortization | 387 |  |  | 426 |  |  | 1,508 |  |  | 1,544 |  |
| Deferred income taxes | (78) |  |  | (647) |  |  | (2,489) |  |  | (2,164) |  |
| (Gains) losses on investments in non-affiliated entities, net | (260) |  |  | 10 |  |  | (238) |  |  | 45 |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | 1,353 |  |
| Other | (109) |  |  | 20 |  |  | (278) |  |  | (7) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (1,690) |  |  | 1,081 |  |  | (6,172) |  |  | 822 |  |
| Inventories | (503) |  |  | (706) |  |  | (98) |  |  | (2,554) |  |
| Prepaid expenses and other assets | (1,184) |  |  | (210) |  |  | (1,522) |  |  | (1,517) |  |
| Accounts payable | 281 |  |  | (193) |  |  | 1,531 |  |  | (551) |  |
| Accrued and other current liabilities | 1,072 |  |  | 166 |  |  | 2,025 |  |  | 1,341 |  |
| Other long-term liabilities | 305 |  |  | 150 |  |  | 514 |  |  | 252 |  |
| Net cash provided by operating activities | 11,499 |  |  | 2,249 |  |  | 28,090 |  |  | 5,641 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 1,731 |  |  | 2,633 |  |  | 9,732 |  |  | 19,425 |  |
| Proceeds from sales of marketable securities | 50 |  |  | — |  |  | 50 |  |  | 1,806 |  |
| Purchases of marketable securities | (7,524) |  |  | (2,133) |  |  | (18,211) |  |  | (11,897) |  |
| Purchase related to property and equipment and intangible assets | (253) |  |  | (509) |  |  | (1,069) |  |  | (1,833) |  |
| Acquisitions, net of cash acquired | — |  |  | — |  |  | (83) |  |  | (49) |  |
| Investments in non-affiliated entities and other, net | (113) |  |  | 5 |  |  | (985) |  |  | (77) |  |
| Net cash provided by (used in) investing activities | (6,109) |  |  | (4) |  |  | (10,566) |  |  | 7,375 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | — |  |  | 5 |  |  | 403 |  |  | 355 |  |
| Payments related to repurchases of common stock | (2,660) |  |  | (1,212) |  |  | (9,533) |  |  | (10,039) |  |
| Payments related to tax on restricted stock units | (841) |  |  | (344) |  |  | (2,783) |  |  | (1,475) |  |
| Repayment of debt | — |  |  | — |  |  | (1,250) |  |  | — |  |
| Dividends paid | (99) |  |  | (98) |  |  | (395) |  |  | (398) |  |

[0001045810-24-000028:8k_2_02:74]
| Principal payments on property and equipment and intangible assets | (29) |  |  | (4) |  |  | (74) |  |  | (58) |  |
| Other | — |  |  | (3) |  |  | (1) |  |  | (2) |  |
| Net cash used in financing activities | (3,629) |  |  | (1,656) |  |  | (13,633) |  |  | (11,617) |  |
| Change in cash and cash equivalents | 1,761 |  |  | 589 |  |  | 3,891 |  |  | 1,399 |  |
| Cash and cash equivalents at beginning of period | 5,519 |  |  | 2,800 |  |  | 3,389 |  |  | 1,990 |  |
| Cash and cash equivalents at end of period | $ | 7,280 |  |  | $ | 3,389 |  |  | $ | 7,280 |  |  | $ | 3,389 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 1,874 |  |  | $ | 32 |  |  | $ | 6,549 |  |  | $ | 1,404 |  |
| Cash paid for interest | $ | 26 |  |  | $ | 28 |  |  | $ | 252 |  |  | $ | 254 |  |

[0001045810-24-000028:8k_2_02:75]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 28, |  | October 29 |  | January 29, |  | January 28, |  | January 29, |
|  |  |  | 2024 |  | 2023 |  | 2023 |  | 2024 |  | 2023 |
| GAAP gross profit |  | $ | 16,791 |  |  | $ | 13,400 |  |  | $ | 3,833 |  |  | $ | 44,301 |  |  | $ | 15,356 |  |
| GAAP gross margin |  | 76.0 | % |  | 74.0 | % |  | 63.3 | % |  | 72.7 | % |  | 56.9 | % |
|  | Acquisition-related and other costs (A) |  | 119 |  |  | 119 |  |  | 120 |  |  | 477 |  |  | 455 |  |
|  | Stock-based compensation expense (B) |  | 45 |  |  | 38 |  |  | 30 |  |  | 141 |  |  | 138 |  |
|  | IP-related costs |  | 4 |  |  | 26 |  |  | 16 |  |  | 40 |  |  | 16 |  |
| Non-GAAP gross profit |  | $ | 16,959 |  |  | $ | 13,583 |  |  | $ | 3,999 |  |  | $ | 44,959 |  |  | $ | 15,965 |  |
| Non-GAAP gross margin |  | 76.7 | % |  | 75.0 | % |  | 66.1 | % |  | 73.8 | % |  | 59.2 | % |
| GAAP operating expenses |  | $ | 3,176 |  |  | $ | 2,983 |  |  | $ | 2,576 |  |  | $ | 11,329 |  |  | $ | 11,132 |  |
|  | Stock-based compensation expense (B) |  | (948) |  |  | (941) |  |  | (709) |  |  | (3,408) |  |  | (2,572) |  |
|  | Acquisition-related and other costs (A) |  | (18) |  |  | (16) |  |  | (54) |  |  | (106) |  |  | (219) |  |
|  | Acquisition termination cost |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,353) |  |
|  | Other (C) |  | — |  |  | — |  |  | (38) |  |  | 10 |  |  | (63) |  |
| Non-GAAP operating expenses |  | $ | 2,210 |  |  | $ | 2,026 |  |  | $ | 1,775 |  |  | $ | 7,825 |  |  | $ | 6,925 |  |
| GAAP operating income |  | $ | 13,615 |  |  | $ | 10,417 |  |  | $ | 1,257 |  |  | $ | 32,972 |  |  | $ | 4,224 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,134 |  |  | 1,140 |  |  | 967 |  |  | 4,162 |  |  | 4,816 |  |
| Non-GAAP operating income |  | $ | 14,749 |  |  | $ | 11,557 |  |  | $ | 2,224 |  |  | $ | 37,134 |  |  | $ | 9,040 |  |
| GAAP other income (expense), net |  | $ | 491 |  |  | $ | 105 |  |  | $ | 32 |  |  | $ | 846 |  |  | $ | (43) |  |
|  | (Gains) losses from non-affiliated investments |  | (260) |  |  | 69 |  |  | 10 |  |  | (238) |  |  | 45 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 5 |  |
| Non-GAAP other income (expense), net |  | $ | 232 |  |  | $ | 175 |  |  | $ | 43 |  |  | $ | 612 |  |  | $ | 7 |  |
| GAAP net income |  | $ | 12,285 |  |  | $ | 9,243 |  |  | $ | 1,414 |  |  | $ | 29,760 |  |  | $ | 4,368 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 875 |  |  | 1,210 |  |  | 978 |  |  | 3,928 |  |  | 4,865 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (321) |  |  | (433) |  |  | (218) |  |  | (1,376) |  |  | (867) |  |
| Non-GAAP net income |  | $ | 12,839 |  |  | $ | 10,020 |  |  | $ | 2,174 |  |  | $ | 32,312 |  |  | $ | 8,366 |  |

[0001045810-24-000028:8k_2_02:76]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 28, |  | October 29 |  | January 29, |  | January 28, |  | January 29, |
|  |  |  | 2024 |  | 2023 |  | 2023 |  | 2024 |  | 2023 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 4.93 |  |  | $ | 3.71 |  |  | $ | 0.57 |  |  | $ | 11.93 |  |  | $ | 1.74 |  |
|  | Non-GAAP |  | $ | 5.16 |  |  | $ | 4.02 |  |  | $ | 0.88 |  |  | $ | 12.96 |  |  | $ | 3.34 |  |
| Weighted average shares used in diluted net income per share computation |  | 2,490 |  |  | 2,494 |  |  | 2,477 |  |  | 2,494 |  |  | 2,507 |  |
| GAAP net cash provided by operating activities |  | $ | 11,499 |  |  | $ | 7,333 |  |  | $ | 2,249 |  |  | $ | 28,090 |  |  | $ | 5,641 |  |
|  | Purchases related to property and equipment and intangible assets |  | (253) |  |  | (278) |  |  | (509) |  |  | (1,069) |  |  | (1,833) |  |
|  | Principal payments on property and equipment and intangible assets |  | (29) |  |  | (13) |  |  | (4) |  |  | (74) |  |  | (58) |  |
| Free cash flow |  | $ | 11,217 |  |  | $ | 7,042 |  |  | $ | 1,736 |  |  | $ | 26,947 |  |  | $ | 3,750 |  |

[0001045810-24-000028:8k_2_02:77]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets and transaction costs, and are included in the following line items: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 28, |  | October 29 |  | January 29, |  | January 28, |  | January 29, |
|  |  |  | 2024 |  | 2023 |  | 2023 |  | 2024 |  | 2023 |
|  | Cost of revenue |  | $ | 119 |  |  | $ | 119 |  |  | $ | 120 |  |  | $ | 477 |  |  | $ | 455 |  |
|  | Research and development |  | $ | 12 |  |  | $ | 12 |  |  | $ | 10 |  |  | $ | 49 |  |  | $ | 39 |  |
|  | Sales, general and administrative |  | $ | 6 |  |  | $ | 4 |  |  | $ | 44 |  |  | $ | 57 |  |  | $ | 180 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 28, |  | October 29 |  | January 29, |  | January 28, |  | January 29, |
|  |  |  | 2024 |  | 2023 |  | 2023 |  | 2024 |  | 2023 |
|  | Cost of revenue |  | $ | 45 |  |  | $ | 38 |  |  | $ | 30 |  |  | $ | 141 |  |  | $ | 138 |  |
|  | Research and development |  | $ | 706 |  |  | $ | 701 |  |  | $ | 527 |  |  | $ | 2,532 |  |  | $ | 1,892 |  |
|  | Sales, general and administrative |  | $ | 242 |  |  | $ | 240 |  |  | $ | 182 |  |  | $ | 876 |  |  | $ | 680 |  |
| (C) Other consists of costs related to Russia branch office closure, assets held for sale related adjustments, legal settlement costs, and contributions. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-24-000028:8k_2_02:78]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2025 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 76.3 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.7 | % |
| Non-GAAP gross margin |  | 77.0 | % |
| GAAP operating expenses |  | $ | 3,480 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (980) |  |
| Non-GAAP operating expenses |  | $ | 2,500 |  |
