# NVDA note change history — 0001045810-23-000175 → 0001045810-23-000227


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0001045810-23-000227:note_history:1]
As of October 29, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $17.11 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of
  (was, 2023-08-28, similarity 0.7992):
[0001045810-23-000175:note_history:1]
As of July 30, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $11.15 billion. During the normal course of business, to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being

- added (2023-11-21):
[0001045810-23-000227:note_history:2]
cancellation. Other non-inventory purchase obligations were $4.43 billion, which includes $3.60 billion of multi-year cloud service agreements, primarily to support our research and development efforts.

- changed (2023-11-21):
[0001045810-23-000227:note_history:3]
Total future purchase commitments as of October 29, 2023 are as follows:
  (was, 2023-08-28, similarity 0.916):
[0001045810-23-000175:note_history:3]
Total future purchase commitments as of July 30, 2023 are as follows:

- changed (2023-11-21):
[0001045810-23-000227:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first nine months of fiscal year 2024) | $ | 6,499 |  |
| 2025 | 11,861 |  |
| 2026 | 1,128 |  |
| 2027 | 1,038 |  |
| 2028 | 660 |  |
| 2029 and thereafter | 354 |  |
| Total | $ | 21,540 |  |
  (was, 2023-08-28, similarity 0.9691):
[0001045810-23-000175:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first half of fiscal year 2024) | $ | 8,439 |  |
| 2025 | 3,960 |  |
| 2026 | 957 |  |
| 2027 | 999 |  |
| 2028 | 637 |  |
| 2029 and thereafter | 468 |  |
| Total | $ | 15,460 |  |

- changed (2023-11-21):
[0001045810-23-000227:note_history:5]
The estimated amount of product warranty liabilities was $142 million and $82 million as of October 29, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:
  (was, 2023-08-28, similarity 0.9757):
[0001045810-23-000175:note_history:5]
The estimated amount of product warranty liabilities was $115 million and $82 million as of July 30, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

- added (2023-11-21):
[0001045810-23-000227:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2023 |  | October 30, 2022 |  | October 29, 2023 |  | October 30, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 115 |  |  | $ | 168 |  |  | $ | 82 |  |  | $ | 46 |  |
| Additions | 50 |  |  | 3 |  |  | 105 |  |  | 141 |  |
| Utilization | (23) |  |  | (67) |  |  | (45) |  |  | (83) |  |
| Balance at end of period | $ | 142 |  |  | $ | 104 |  |  | $ | 142 |  |  | $ | 104 |  |

- changed (2023-11-21):
[0001045810-23-000227:note_history:7]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.
  (was, 2023-08-28, similarity 0.9261):
[0001045810-23-000175:note_history:7]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

- changed (2023-11-21):
[0001045810-23-000227:note_history:8]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023.
  (was, 2023-08-28, similarity 0.7529):
[0001045810-23-000175:note_history:8]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case.

- changed (2023-11-21):
[0001045810-23-000227:note_history:9]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties will meet and confer regarding the next steps in this derivative matter. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.
  (was, 2023-08-28, similarity 0.9282):
[0001045810-23-000175:note_history:9]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

- changed (2023-11-21):
[0001045810-23-000227:note_history:10]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties will meet and confer regarding the next steps in these derivative matters. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2023-08-28, similarity 0.9179):
[0001045810-23-000175:note_history:10]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2023-11-21):
[0001045810-23-000227:note_history:11]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures.

- changed (2023-11-21):
[0001045810-23-000227:note_history:12]
As of October 29, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2023-08-28, similarity 0.9916):
[0001045810-23-000175:note_history:12]
As of July 30, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2023-11-21):
[0001045810-23-000175:note_history:13]
placed, but these changes may result in the payment of costs incurred through the date of cancellation. Other non-inventory purchase obligations of $4.31 billion include $3.50 billion of multi-year cloud service agreements.

- removed (2023-11-21):
[0001045810-23-000175:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2023 |  | July 31, 2022 |  | July 30, 2023 |  | July 31, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 77 |  |  | $ | 55 |  |  | $ | 82 |  |  | $ | 46 |  |
| Additions | 42 |  | 122 |  | 55 |  | 138 |
| Utilization | (4) |  |  | (9) |  |  | (22) |  |  | (16) |  |
| Balance at end of period | $ | 115 |  |  | $ | 168 |  |  | $ | 115 |  |  | $ | 168 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0001045810-23-000227:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The third quarters of fiscal years 2024 and 2023 were both 13-week quarters.
  (was, 2023-08-28, similarity 0.9759):
[0001045810-23-000175:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The second quarters of fiscal years 2024 and 2023 were both 13-week quarters.

- changed (2023-11-21):
[0001045810-23-000227:note_history:16]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the estimated effect of this change for the three months ended October 29, 2023 was a benefit of $17 million and $24 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $41 million and net income of $36 million after tax, or $0.01 per both basic and diluted share. The estimated effect of this change for the first nine months of fiscal year 2024 was a benefit of $24 million and $83 million 
for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $107 million and net income of $91 million after tax, or $0.04 per both basic and diluted share.
  (was, 2023-08-28, similarity 0.6821):
[0001045810-23-000175:note_history:16]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the effect of this change in estimate for the three months ended July 30, 2023 was a benefit of $5 million and $28 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $33 million and net income of $27 million after tax, or $0.01 per both basic and diluted share. The effect of this change in estimate for the first half of fiscal year 2024 was a benefit of $7 million and $59 million for 
cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $66 million and net income of $55 million after tax, or $0.02 per both basic and diluted share.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0001045810-23-000227:note_history:17]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (44) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,706 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,457 |  |  | $ | 9,703 |  |
  (was, 2023-08-28, similarity 0.9935):
[0001045810-23-000175:note_history:17]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (45) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,705 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,456 |  |  | $ | 9,703 |  |

- changed (2023-11-21):
[0001045810-23-000227:note_history:18]
As of October 29, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2023-08-28, similarity 0.9579):
[0001045810-23-000175:note_history:18]
As of July 30, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2023-11-21):
[0001045810-23-000227:note_history:19]
We have a $575 million commercial paper program to support general corporate purposes. As of October 29, 2023, we had not issued any commercial paper.
  (was, 2023-08-28, similarity 0.9609):
[0001045810-23-000175:note_history:19]
We have a $575 million commercial paper program to support general corporate purposes. As of July 30, 2023, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0001045810-23-000227:note_history:20]
|  | October 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,937 |  |  | $ | 1 |  |  | $ | (20) |  |  | $ | 6,918 |  |  | $ | 1,714 |  |  | $ | 5,204 |  |
| Debt securities issued by the U.S. Treasury | 5,075 |  |  | 1 |  |  | (24) |  |  | 5,052 |  |  | — |  |  | 5,052 |  |
| Money market funds | 3,190 |  |  | — |  |  | — |  |  | 3,190 |  |  | 3,190 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,316 |  |  | — |  |  | (5) |  |  | 2,311 |  |  | 100 |  |  | 2,211 |  |
| Certificates of deposit | 418 |  |  | — |  |  | — |  |  | 418 |  |  | 198 |  |  | 220 |  |
| Foreign government bonds | 175 |  |  | — |  |  | — |  |  | 175 |  |  | 100 |  |  | 75 |  |
| Total | $ | 18,111 |  |  | $ | 2 |  |  | $ | (49) |  |  | $ | 18,064 |  |  | $ | 5,302 |  |  | $ | 12,762 |  |
  (was, 2023-08-28, similarity 0.8882):
[0001045810-23-000175:note_history:20]
|  | July 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,990 |  |  | $ | 1 |  |  | $ | (13) |  |  | $ | 5,978 |  |  | $ | 2,149 |  |  | $ | 3,829 |  |
| Debt securities issued by the U.S. Treasury | 3,716 |  |  | — |  |  | (31) |  |  | 3,685 |  |  | — |  |  | 3,685 |  |
| Debt securities issued by U.S. government agencies | 2,903 |  |  | — |  |  | (4) |  |  | 2,899 |  |  | 647 |  |  | 2,252 |  |
| Money market funds | 2,348 |  |  | — |  |  | — |  |  | 2,348 |  |  | 2,348 |  |  | — |  |
| Certificates of deposit | 690 |  |  | — |  |  | — |  |  | 690 |  |  | 265 |  |  | 425 |  |
| Foreign government bonds | 248 |  |  | — |  |  | — |  |  | 248 |  |  | 199 |  |  | 49 |  |
| Total | $ | 15,895 |  |  | $ | 1 |  |  | $ | (48) |  |  | $ | 15,848 |  |  | $ | 5,608 |  |  | $ | 10,240 |  |

- added (2023-11-21):
[0001045810-23-000227:note_history:21]
|  | October 29, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,405 |  |  | $ | 11,388 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 6,706 |  |  | 6,676 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 18,111 |  |  | $ | 18,064 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |

- removed (2023-11-21):
[0001045810-23-000175:note_history:22]
|  | July 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,613 |  |  | $ | 12,592 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 3,282 |  |  | 3,256 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,895 |  |  | $ | 15,848 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0001045810-23-000227:note_history:23]
|  | October 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,937 |  |  | $ | 1 |  |  | $ | (20) |  |  | $ | 6,918 |  |  | $ | 1,714 |  |  | $ | 5,204 |  |
| Debt securities issued by the U.S. Treasury | 5,075 |  |  | 1 |  |  | (24) |  |  | 5,052 |  |  | — |  |  | 5,052 |  |
| Money market funds | 3,190 |  |  | — |  |  | — |  |  | 3,190 |  |  | 3,190 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,316 |  |  | — |  |  | (5) |  |  | 2,311 |  |  | 100 |  |  | 2,211 |  |
| Certificates of deposit | 418 |  |  | — |  |  | — |  |  | 418 |  |  | 198 |  |  | 220 |  |
| Foreign government bonds | 175 |  |  | — |  |  | — |  |  | 175 |  |  | 100 |  |  | 75 |  |
| Total | $ | 18,111 |  |  | $ | 2 |  |  | $ | (49) |  |  | $ | 18,064 |  |  | $ | 5,302 |  |  | $ | 12,762 |  |
  (was, 2023-08-28, similarity 0.8882):
[0001045810-23-000175:note_history:23]
|  | July 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,990 |  |  | $ | 1 |  |  | $ | (13) |  |  | $ | 5,978 |  |  | $ | 2,149 |  |  | $ | 3,829 |  |
| Debt securities issued by the U.S. Treasury | 3,716 |  |  | — |  |  | (31) |  |  | 3,685 |  |  | — |  |  | 3,685 |  |
| Debt securities issued by U.S. government agencies | 2,903 |  |  | — |  |  | (4) |  |  | 2,899 |  |  | 647 |  |  | 2,252 |  |
| Money market funds | 2,348 |  |  | — |  |  | — |  |  | 2,348 |  |  | 2,348 |  |  | — |  |
| Certificates of deposit | 690 |  |  | — |  |  | — |  |  | 690 |  |  | 265 |  |  | 425 |  |
| Foreign government bonds | 248 |  |  | — |  |  | — |  |  | 248 |  |  | 199 |  |  | 49 |  |
| Total | $ | 15,895 |  |  | $ | 1 |  |  | $ | (48) |  |  | $ | 15,848 |  |  | $ | 5,608 |  |  | $ | 10,240 |  |

- changed (2023-11-21):
[0001045810-23-000227:note_history:24]
|  | October 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Corporate debt securities | $ | 2,773 |  |  | $ | (16) |  |  | $ | 852 |  |  | $ | (4) |  |  | $ | 3,625 |  |  | $ | (20) |  |
| Debt securities issued by the U.S. Treasury | 2,098 |  |  | (12) |  |  | 1,371 |  |  | (12) |  |  | 3,469 |  |  | (24) |  |
| Debt securities issued by U.S. government agencies | 1,447 |  |  | (5) |  |  | — |  |  | — |  |  | 1,447 |  |  | (5) |  |
| Total | $ | 6,318 |  |  | $ | (33) |  |  | $ | 2,223 |  |  | $ | (16) |  |  | $ | 8,541 |  |  | $ | (49) |  |
  (was, 2023-08-28, similarity 0.8275):
[0001045810-23-000175:note_history:24]
|  | July 30, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,595 |  |  | $ | (16) |  |  | $ | 1,375 |  |  | $ | (15) |  |  | $ | 2,970 |  |  | $ | (31) |  |
| Corporate debt securities | 1,379 |  |  | (9) |  |  | 802 |  |  | (4) |  |  | 2,181 |  |  | (13) |  |
| Debt securities issued by U.S. government agencies | 2,223 |  |  | (4) |  |  | — |  |  | — |  |  | 2,223 |  |  | (4) |  |
| Total | $ | 5,197 |  |  | $ | (29) |  |  | $ | 2,177 |  |  | $ | (19) |  |  | $ | 7,374 |  |  | $ | (48) |  |

- added (2023-11-21):
[0001045810-23-000227:note_history:25]
|  | October 29, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,405 |  |  | $ | 11,388 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 6,706 |  |  | 6,676 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 18,111 |  |  | $ | 18,064 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |

- removed (2023-11-21):
[0001045810-23-000175:note_history:26]
|  | July 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,613 |  |  | $ | 12,592 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 3,282 |  |  | 3,256 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,895 |  |  | $ | 15,848 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |

- removed (2023-11-21):
[0001045810-23-000175:note_history:27]
Restricted cash was $99 million as of July 30, 2023 and primarily represented amounts due to employees.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0001045810-23-000227:note_history:28]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (44) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,706 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,457 |  |  | $ | 9,703 |  |
  (was, 2023-08-28, similarity 0.9935):
[0001045810-23-000175:note_history:28]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (45) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,705 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,456 |  |  | $ | 9,703 |  |
