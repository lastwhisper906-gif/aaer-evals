# NVDA MD&A — 0001045810-22-000147


## mdna

[0001045810-22-000147:mdna:1]
[same as prior period, unchanged from 0001045810-22-000079:mdna:1]

[0001045810-22-000147:mdna:2]
[same as prior period, unchanged from 0001045810-22-000079:mdna:2]

[0001045810-22-000147:mdna:3]
[same as prior period, unchanged from 0001045810-22-000079:mdna:3]

[0001045810-22-000147:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, Mellanox, NVIDIA AI Enterprise, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA Grace, NVIDIA HGX, NVIDIA Jetson, NVIDIA NeMO, NVIDIA Omniverse, NVIDIA QODA, NVIDIA RTX, NVIDIA Studio and Quadro, are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000147:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 30, 2022 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase or sell shares of our common stock.

[0001045810-22-000147:mdna:6]
[same as prior period, unchanged from 0001045810-22-000079:mdna:6]

[0001045810-22-000147:mdna:7]
[same as prior period, unchanged from 0001045810-22-000079:mdna:7]

[0001045810-22-000147:mdna:8]
[same as prior period, unchanged from 0001045810-22-000079:mdna:8]

[0001045810-22-000147:mdna:9]
[same as prior period, unchanged from 0001045810-22-000079:mdna:9]

[0001045810-22-000147:mdna:10]
[same as prior period, unchanged from 0001045810-22-000079:mdna:10]

[0001045810-22-000147:mdna:11]
[same as prior period, unchanged from 0001045810-22-000079:mdna:11]

[0001045810-22-000147:mdna:12]
[same as prior period, unchanged from 0001045810-22-000079:mdna:12]

[0001045810-22-000147:mdna:13]
[same as prior period, unchanged from 0001045810-22-000079:mdna:13]

[0001045810-22-000147:mdna:14]
23

[0001045810-22-000147:mdna:15]
Demand and Supply

[0001045810-22-000147:mdna:16]
Because we do not manufacture the semiconductors used for our products, we are dependent on third parties to manufacture and assemble our products. Our manufacturing lead times are very long, which requires us to make estimates of customers’ future demand. At the same time, we do not have a guaranteed supply of wafers, components and capacity, and our supply deliveries and production may be non-linear within a quarter or year, which has previously caused changes to expected revenue and cash flows, and which may reoccur in the future. If our estimates of customer demand are ultimately inaccurate, as we have experienced from time to time, these conditions could lead to a significant mismatch between supply and demand. This mismatch has resulted in product shortages and excess inventory, has varied across our market platforms, and significantly harmed our financial results.

[0001045810-22-000147:mdna:17]
We build finished products and maintain inventory in advance of anticipated demand. In periods of shortages impacting the semiconductor industry and/or limited supply or capacity in our supply chain, as we have experienced in the past, the lead time on our orders for certain supply has extended to more than twelve months, compared to a historical lead time of approximately six months. Extended lead times may continue if we experience other supply constraints caused by natural disasters or other events. As a result, we have paid premiums and provided deposits to secure future supply and capacity, which have increased our product costs, and may need to continue to do so in the future. Our supply, which includes inventory on hand, purchase obligations and prepaid supply agreements, has grown significantly due to current supply chain conditions and complexity of our products. Purchase obligations and prepaid supply agreements represent approximately three quarters of our total supply.

[0001045810-22-000147:mdna:18]
Demand for our products is based on many factors, including our product introductions and transitions, time to market, competitor product releases and announcements, competing technologies, and changes in macroeconomic conditions, including rising inflation. Each of these factors has previously impacted, and can in the future impact, the timing and volume of our revenue. Our demand predictions may not be correct, as we have experienced from time to time. Product transitions are complex and frequently negatively impact our revenue as we manage shipments of legacy prior architecture products and channel partners prepare and adjust to support new products. We are entering a timeframe when we will transition architectures for both our Gaming and Data Center products, which may impair our ability to predict demand and impact our supply mix. We may experience, and have in the past experienced, reduced demand for current generation architectures when customers anticipate transitions. If we are unable to execute our architectural transitions as planned for any reason, our financial results may be negatively impacted. Our ability to sell certain products has in the past been and can in the future be impeded if components from third parties that are necessary for the finished product are not available. Additionally, we sell most of our products through channel partners, who sell to retailers, distributors, and/or end customers. As a result, the decisions made by our channel partners, retailers and distributors in response to changing market conditions and changes in end user demand for our products have impacted and could in the future continue to impact our ability to properly forecast demand, particularly as they are based on estimates provided by various downstream parties.

[0001045810-22-000147:mdna:19]
In recent periods, COVID-19-related disruptions and lockdowns in China have created and may continue to create supply and logistics constraints. The war in Ukraine has further strained global supply chains and may in the future result in a shortage of key materials that our suppliers, including our foundry partners, require to satisfy our needs.

[0001045810-22-000147:mdna:20]
Our GPUs are designed for the Gaming, Data Center, Professional Visualization and Automotive markets. The use of our GPUs for use cases other than that for which they were designed and marketed, including new and unexpected use cases, has impacted and can in the future impact demand for our products, including by leading to inconsistent spikes and drops in demand. For example, many years ago, our Gaming GPUs began to be used for digital currency mining, including blockchain-based platforms such as Ethereum. It is difficult for us to estimate with any reasonable degree of precision the past or current impact of cryptocurrency mining, or forecast the future impact of cryptocurrency mining, on demand for our products. Volatility in the cryptocurrency market, including new compute technologies, price changes in cryptocurrencies, government cryptocurrency policies and regulations, new cryptocurrency standards, and changes in the method of verifying blockchain transactions, has impacted and can in the future impact cryptocurrency mining and demand for our products and can further impact our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the pending Ethereum 2.0 merge may decrease the usage of GPUs for Ethereum mining as well as create increased aftermarket resales of our GPUs, which could negatively impact retail prices for our GPUs, increase returns of our products in the distribution channel, and reduce demand for our new GPUs. We have introduced Lite Hash Rate, or LHR, GeForce GPUs with limited Ethereum mining capability and provided CMP products in an effort to address demand from gamers and direct miners to CMP. Beginning in the second quarter of fiscal year 2022, most desktop NVIDIA Ampere architecture GeForce GPU shipments were LHR to help direct GeForce GPUs to gamers. Attempts in the aftermarket to improve the hash rate capabilities of our LHR cards have been successful and our gaming cards may become more attractive to miners, increasing demand for our

[0001045810-22-000147:mdna:21]
24

[0001045810-22-000147:mdna:22]
gaming GPUs and limiting our ability to supply our gaming cards to non-mining customers. We cannot predict whether our strategy of using LHR cards and CMP will achieve our desired outcome. In addition, our new products or previously sold products may be resold online or on the unauthorized “gray market,” which also makes demand forecasting difficult. Gray market products or reseller marketplaces compete with our distribution channels.

[0001045810-22-000147:mdna:23]
In the second quarter of fiscal year 2023, Gaming revenue experienced lower sell-in of our Gaming GPUs, reflecting reduced channel partner sales due to macroeconomic headwinds, including the negative impact of high inflation on consumer spending and weaker consumer purchasing power in markets whose currencies weakened relative to the U.S. dollar, as our sales are in U.S. dollars. Our channel partners reduced their inventory and are transitioning to a lower value mix of inventory to better align with demand as well as an architectural transition, and we implemented pricing programs with them to address challenging market conditions that we expect to persist into the third quarter of fiscal year 2023. The sequential decline in Gaming revenue also resulted from the war in Ukraine impacting sales in Europe and lockdowns in China due to COVID-19. The extent to which reduced cryptocurrency mining contributed to the decline in Gaming demand is difficult for us to reasonably quantify. Economic conditions in China drove lower sales to China hyperscale customers, impacting our Data Center revenue, and drove lower sales of Gaming products. We and our customers are also experiencing Data Center supply chain disruptions as our customers delay purchases pending the availability of other third party components. These recent reductions in demand and our reduced expectations of future demand have required us to record charges for excess inventory on hand and on order, and cancellation and underutilization penalties. Potential future demand reductions could require additional reserves. Mismatches between our supply and demand may occur in future quarters.

[0001045810-22-000147:mdna:24]
On August 26, 2022, the U.S. government, or USG, informed us that it has imposed a new license requirement, effective immediately, for any future export to China (including Hong Kong) and Russia of our A100 and forthcoming H100 integrated circuits. DGX or any other systems which incorporate A100 or H100 integrated circuits and our A100X are also covered by the new license requirement.  The license requirement also includes any future NVIDIA integrated circuit achieving both peak performance and chip-to-chip I/O performance equal to or greater than thresholds that are roughly equivalent to the A100, as well as any system that includes those circuits. A license is required to export technology to support or develop covered products.  The USG indicated that the new license requirement will address the risk that the covered products may be used in, or diverted to, a ‘military end use’ or ‘military end user’ in China and Russia.  We do not sell products to customers in Russia.

[0001045810-22-000147:mdna:25]
The new license requirement may impact our ability to complete our development of H100 in a timely manner or support existing customers of A100 and may require us to transition certain operations out of China, which could be costly and time consuming, and adversely affect our research and development and supply and distribution operations, as well as our revenue, during any such transition period. We are engaged with the USG and are seeking exemptions for our internal development and support activities.

[0001045810-22-000147:mdna:26]
We are engaging with customers in China and are seeking to satisfy their planned or future purchases of our Data Center products with products not subject to the new license requirement.  To the extent that a customer requires products covered by the new license requirement, we may seek a license for the customer but have no assurance that the USG will grant any exemptions or licenses for any customer, or that the USG will act on them in a timely manner.  The new requirement may have a disproportionate impact on NVIDIA and may disadvantage NVIDIA against our competitors, who are not subject to the same restrictions.

[0001045810-22-000147:mdna:27]
Our outlook for our third fiscal quarter provided on August 24, 2022 included approximately $400 million in potential sales to China which may be subject to the new license requirement. Our future revenue and profitability may be substantially reduced relative to this outlook, and our competitive position may be harmed, if customers do not want to purchase our alternative product offerings or if the USG does not grant licenses in a timely manner or denies licenses to significant customers.  Even if the USG grants the requested licenses, the new requirement may benefit our competitors, as the licensing process will make our sales and support efforts more cumbersome, less certain, and encourage customers in China to pursue alternatives to our products, including semiconductor suppliers based in China, Europe, and Israel.

[0001045810-22-000147:mdna:28]
[same as prior period, unchanged from 0001045810-22-000079:mdna:19]

[0001045810-22-000147:mdna:29]
As the COVID-19 pandemic continues, most of our employees continue to work remotely and we have paused most business travel. When our offices begin to reopen, we expect to incur incremental expenses and related in-office costs as we resume onsite services.

[0001045810-22-000147:mdna:30]
Consumer and enterprise behavior during the COVID-19 pandemic, such as fluctuating demand for our Gaming, Data Center, and workstation products, has made it more difficult for us to estimate future demand and may have changed pre-pandemic behaviors. At the same time, restrictions that may be imposed or reinstated as the pandemic continues, such as recent lockdown measures due to COVID-19 containment efforts in China, have negatively impacted end customer sales for our products in China and this impact may continue if future lockdowns are imposed. These challenges in estimating demand are expected to be more pronounced or volatile in the future on both a global and regional basis and may continue in the future when the effects of the pandemic subside. Additionally, recent COVID-19-related disruptions and lockdowns in China have created and may continue to create supply chain and logistics constraints.

[0001045810-22-000147:mdna:31]
The timing and overall demand from customers, and the limited availability of supply chain, logistical services and component supply, as a result of COVID-19, has had and may continue to have a material net negative impact on our business and financial results.

[0001045810-22-000147:mdna:32]
Russia

[0001045810-22-000147:mdna:33]
During the first quarter of fiscal year 2023, we paused direct sales to Russia. Direct sales to Russia in fiscal year 2022 were immaterial. Our revenue to partners that sell into Russia may be negatively impacted due to the war in Ukraine and we estimate that in fiscal year 2022, Russia accounted for approximately 2% of total end customer sales and 4% of Gaming end customer sales. Long lived assets in Russia are immaterial.

[0001045810-22-000147:mdna:34]
Second Quarter of Fiscal Year 2023 Summary

[0001045810-22-000147:mdna:35]
|  | Three Months Ended |  |  |  |  |
|  | July 31, 2022 |  | May 1, 2022 |  | August 1, 2021 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 6,704 |  |  | $ | 8,288 |  |  | $ | 6,507 |  |  | (19) | % |  | 3 | % |
| Gross margin | 43.5 | % |  | 65.5 | % |  | 64.8 | % |  | (22.0) pts |  | (21.3) pts |
| Operating expenses | $ | 2,416 |  |  | $ | 3,563 |  |  | $ | 1,771 |  |  | (32) | % |  | 36 | % |
| Income from operations | $ | 499 |  |  | $ | 1,868 |  |  | $ | 2,444 |  |  | (73) | % |  | (80) | % |
| Net income | $ | 656 |  |  | $ | 1,618 |  |  | $ | 2,374 |  |  | (59) | % |  | (72) | % |
| Net income per diluted share | $ | 0.26 |  |  | $ | 0.64 |  |  | $ | 0.94 |  |  | (59) | % |  | (72) | % |

[0001045810-22-000147:mdna:36]
[same as prior period, unchanged from 0001045810-22-000079:mdna:25]

[0001045810-22-000147:mdna:37]
Revenue for the second quarter of fiscal year 2023 was $6.70 billion, up 3% from a year ago and down 19% sequentially.

[0001045810-22-000147:mdna:38]
Gaming revenue was down 33% from a year ago and down 44% sequentially. These decreases were primarily attributable to lower sell-in of Gaming products, reflecting reduced channel partner sales due to macroeconomic headwinds. In addition to reducing sell-in, we implemented pricing programs with channel partners to address challenging market conditions that are expected to persist into the third quarter of fiscal year 2023.

[0001045810-22-000147:mdna:39]
Our GPUs are capable of cryptocurrency mining, though we have limited visibility into how much this impacts our overall GPU demand. Volatility in the cryptocurrency market – such as declines in cryptocurrency prices or changes in method of verifying transactions, including proof of work or proof of stake – has in the past impacted, and can in the future impact, demand for our products and our ability to accurately estimate it. As noted last quarter, we had expected cryptocurrency mining to make a diminishing contribution to Gaming demand. We are unable to accurately quantify the extent to which reduced cryptocurrency mining contributed to the decline in Gaming demand.

[0001045810-22-000147:mdna:40]
Data Center revenue was up 61% from a year ago and up 1% sequentially. The year-on-year increase was primarily driven by hyperscale customer revenue, which nearly doubled. Sequentially, sales to North America hyperscale and cloud computing customers increased, but were more than offset by lower sales to China hyperscale customers affected by economic conditions in China. Vertical industries grew both sequentially and year-on-year. Key workloads driving

[0001045810-22-000147:mdna:41]
26

[0001045810-22-000147:mdna:42]
growth included natural language processing, deep recommenders, autonomous vehicle fleet data processing and training, and cloud graphics.

[0001045810-22-000147:mdna:43]
Professional Visualization revenue was down 4% from a year ago and down 20% sequentially. The sequential increase in mobile revenue was more than offset by lower desktop revenue, particularly at the high end.

[0001045810-22-000147:mdna:44]
Automotive revenue was up 45% from a year ago and up 59% sequentially. These increases were driven by revenue from self-driving and AI cockpit solutions, partially offset by a decline of legacy cockpit revenue.

[0001045810-22-000147:mdna:45]
OEM and Other revenue was down 66% from a year ago and down 11% sequentially. The sequential decline was driven by lower notebook OEM sales, partially offset by higher Jetson sales. CMP revenue was nominal in the current and prior quarter, and $266 million a year ago.

[0001045810-22-000147:mdna:46]
Gross margin decreases were primarily due to a $1.34 billion charge, comprised of $1.22 billion for inventory and related reserves and $122 million for warranty reserves.

[0001045810-22-000147:mdna:47]
The $1.22 billion charge for inventory and related reserves is based on revised expectations of future demand, primarily relating to Data Center and Gaming. The charge consists of approximately $570 million for inventory on hand and approximately $650 million for inventory purchase obligations in excess of our current demand projections, and cancellation and underutilization penalties.

[0001045810-22-000147:mdna:48]
Operating expense includes a $1.35 billion acquisition termination charge related to the Arm transaction in the prior quarter. Operating expenses were influenced primarily by employee growth costs, as well as increases in salaries to support our employees during this high inflationary environment, and engineering development of new products coming to market.

[0001045810-22-000147:mdna:49]
Cash, cash equivalents and marketable securities were $17.04 billion, down from $19.65 billion a year ago and down from $20.34 billion a quarter ago. The year-on-year and sequential decreases reflect share repurchases offset by operating cash flow generation.

[0001045810-22-000147:mdna:50]
During the second quarter of fiscal year 2023, we returned $3.44 billion to shareholders in the form of share repurchases and cash dividends. During the first half of fiscal year 2023, we returned $5.54 billion to shareholders in the form of share repurchases and cash dividends. We have $11.93 billion remaining under our share repurchase authorization through December 2023. We plan to continue share repurchases this fiscal year.

[0001045810-22-000147:mdna:51]
[same as prior period, unchanged from 0001045810-22-000079:mdna:39]

[0001045810-22-000147:mdna:52]
In our Data Center market platform, we announced that NVIDIA Grace superchips are being used to create HGX systems by some of the world’s leading computer makers; unveiled the NVIDIA Quantum Optimized Device Architecture; and provided updates for the NeMo Megatron large language model framework.

[0001045810-22-000147:mdna:53]
In our Gaming market platform, we increased the number of GeForce RTX and NVIDIA Studio laptops to 180+ and expanded the GeForce NOW library with 80 additional games bringing the total to over 1,350.

[0001045810-22-000147:mdna:54]
In our Professional Visualization market platform, we expanded our partnership with Siemens to enable the industrial metaverse and increase use of AI-driven digital twin technology and announced Omniverse Avatar Cloud Engine.

[0001045810-22-000147:mdna:55]
In our Automotive market platform, we announced rollout plans of new model vehicles using the DRIVE Orin compute platform by partners NIO, Li Auto, JIDU, and Human Horizons, as well as Pony.ai’s use of DRIVE Orin across its line of self-driving trucks and robotaxis.

[0001045810-22-000147:mdna:56]
[same as prior period, unchanged from 0001045810-22-000079:mdna:44]

[0001045810-22-000147:mdna:57]
[same as prior period, unchanged from 0001045810-22-000079:mdna:45]

[0001045810-22-000147:mdna:58]
[same as prior period, unchanged from 0001045810-22-000079:mdna:46]

[0001045810-22-000147:mdna:59]
[same as prior period, unchanged from 0001045810-22-000079:mdna:47]

[0001045810-22-000147:mdna:60]
27

[0001045810-22-000147:mdna:61]
[same as prior period, unchanged from 0001045810-22-000079:mdna:48]

[0001045810-22-000147:mdna:62]
[same as prior period, unchanged from 0001045810-22-000079:mdna:49]

[0001045810-22-000147:mdna:63]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 56.5 |  |  | 35.2 |  |  | 44.3 |  |  | 35.5 |  |
| Gross profit | 43.5 |  |  | 64.8 |  |  | 55.7 |  |  | 64.5 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 27.2 |  |  | 19.1 |  |  | 23.0 |  |  | 19.7 |  |
| Sales, general and administrative | 8.8 |  |  | 8.1 |  |  | 7.9 |  |  | 8.6 |  |
| Acquisition termination cost | — |  |  | — |  |  | 9.0 |  |  | — |  |
| Total operating expenses | 36.0 |  |  | 27.2 |  |  | 39.9 |  |  | 28.3 |  |
| Income from operations | 7.5 |  |  | 37.6 |  |  | 15.8 |  |  | 36.2 |  |
| Interest income | 0.7 |  |  | 0.1 |  |  | 0.4 |  |  | 0.1 |  |
| Interest expense | (1.0) |  |  | (0.9) |  |  | (0.9) |  |  | (0.9) |  |
| Other, net | (0.1) |  |  | 0.1 |  |  | (0.1) |  |  | 1.1 |  |
| Other income (expense), net | (0.4) |  |  | (0.7) |  |  | (0.6) |  |  | 0.3 |  |
| Income before income tax | 7.1 |  |  | 36.9 |  |  | 15.2 |  |  | 36.5 |  |
| Income tax expense (benefit) | (2.7) |  |  | 0.3 |  |  | — |  |  | 1.3 |  |
| Net income | 9.8 | % |  | 36.6 | % |  | 15.2 | % |  | 35.2 | % |

[0001045810-22-000147:mdna:64]
[same as prior period, unchanged from 0001045810-22-000079:mdna:51]

[0001045810-22-000147:mdna:65]
[same as prior period, unchanged from 0001045810-22-000079:mdna:52]

[0001045810-22-000147:mdna:66]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31,2022 |  | August 1,2021 |  | $Change |  | %Change |  | July 31,2022 |  | August 1,2021 |  | $Change |  | %Change |
|  | ($ in millions) |
| Graphics | $ | 2,797 |  |  | $ | 3,907 |  |  | $ | (1,110) |  |  | (28) | % |  | $ | 7,413 |  |  | $ | 7,358 |  |  | $ | 55 |  |  | 1 | % |
| Compute & Networking | 3,907 |  |  | 2,600 |  |  | 1,307 |  |  | 50 | % |  | 7,579 |  |  | 4,810 |  |  | 2,769 |  |  | 58 | % |
| Total | $ | 6,704 |  |  | $ | 6,507 |  |  | $ | 197 |  |  | 3 | % |  | $ | 14,992 |  |  | $ | 12,168 |  |  | $ | 2,824 |  |  | 23 | % |

[0001045810-22-000147:mdna:67]
Graphics - The year over year decrease was primarily attributable to lower sell-in of desktop Gaming and Professional Visualization products in the second quarter of fiscal year 2023 reflecting reduced channel partner sales due to macroeconomic headwinds. In addition to reducing sell-in, we implemented pricing programs in Gaming with channel partners to address challenging market conditions that are expected to persist into the third quarter of fiscal year 2023. Revenue on a year-to-date basis was essentially flat as the declines in sales of GeForce GPUs for desktops and SOCs for game consoles were offset by increases in sales of GeForce GPUs for laptops and Professional Visualization products.

[0001045810-22-000147:mdna:68]
Compute & Networking - The year-on-year increases were primarily driven by hyperscale customer revenue, which nearly doubled. Vertical industries grew year-on-year. Key workloads driving growth included natural language processing, deep recommenders, autonomous vehicle fleet data processing and training, and cloud graphics. CMP contributed an insignificant amount in the second quarter and first half of fiscal year 2023 compared to $266 million in second quarter and $421 million in the first half of fiscal year 2022.

[0001045810-22-000147:mdna:69]
28

[0001045810-22-000147:mdna:70]
[same as prior period, unchanged from 0001045810-22-000079:mdna:57]

[0001045810-22-000147:mdna:71]
Revenue from sales to customers outside of the United States accounted for 70% and 74% of total revenue for the second quarter and first half of fiscal year 2023, respectively, and 85% and 86% of total revenue for the second quarter and first half of fiscal year 2022, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-22-000147:mdna:72]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal years 2023 or 2022.

[0001045810-22-000147:mdna:73]
Data Center revenue included $287 million for orders originally scheduled for delivery primarily in the third quarter that were converted to second-quarter delivery with extended payment terms, while a number of second-quarter orders will be fulfilled in the third quarter given supply chain disruptions. These second quarter of fiscal year 2023 revenue transactions were recognized under our pre-established revenue recognition policy that includes extended payment terms conditions.

[0001045810-22-000147:mdna:74]
[same as prior period, unchanged from 0001045810-22-000079:mdna:60]

[0001045810-22-000147:mdna:75]
Our overall gross margin decreased to 43.5% and 55.7% for the second quarter and first half of fiscal year 2023, respectively, from 64.8% and 64.5% for the second quarter and first half of fiscal year 2022, respectively. These decreases were primarily due to a $1.34 billion charge in the second quarter of fiscal year 2023, comprised of $1.22 billion for inventory and related reserves, primarily relating to Data Center and Gaming, and $122 million for warranty reserves. The inventory and related reserves consist of approximately $570 million for inventory on hand and approximately $650 million for inventory purchase obligations in excess of our current demand projections, and cancellation and underutilization penalties. The warranty reserve is primarily due to a defect that was identified in a third-party component embedded in certain Data Center products.

[0001045810-22-000147:mdna:76]
Inventory provisions totaled $1.22 billion and $73 million for the second quarter of fiscal years 2023 and 2022, respectively. Sales of inventory that was previously written-off or down totaled $23 million and $20 million for the second quarter of fiscal years 2023 and 2022, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 17.8% and 0.8% in the second quarter of fiscal years 2023 and 2022, respectively.

[0001045810-22-000147:mdna:77]
Inventory provisions totaled $1.31 billion and $131 million for the first half of fiscal years 2023 and 2022, respectively. Sales of inventory that was previously written-off or down totaled $38 million and $41 million for the first half of fiscal years 2023 and 2022, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 8.5% and 0.7% in the first half of fiscal years 2023 and 2022, respectively.

[0001045810-22-000147:mdna:78]
Graphics - The gross margin of our Graphics segment decreased during the second quarter and first half of fiscal year 2023 compared to the second quarter and first half of fiscal year 2022, primarily due to inventory and related reserves. In addition, we implemented pricing programs with Gaming channel partners to address challenging market conditions, which reduced gross margin.

[0001045810-22-000147:mdna:79]
Compute & Networking - The gross margin of our Compute & Networking segment decreased during the second quarter and first half of fiscal year 2023 compared to the second quarter and first half of fiscal year 2022, primarily due to inventory related and warranty reserves.

[0001045810-22-000147:mdna:80]
[same as prior period, unchanged from 0001045810-22-000079:mdna:65]

[0001045810-22-000147:mdna:81]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31,2022 |  | August 1,2021 |  | $Change |  | %Change |  | July 31,2022 |  | August 1,2021 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 1,824 |  |  | $ | 1,245 |  |  | $ | 579 |  |  | 47 | % |  | $ | 3,443 |  |  | $ | 2,398 |  |  | $ | 1,045 |  |  | 44 | % |
| % of net revenue | 27 | % |  | 19 | % |  |  |  |  |  | 23 | % |  | 20 | % |  |  |  |  |
| Sales, general and administrative expenses | 592 |  |  | 526 |  |  | 66 |  |  | 13 | % |  | 1,183 |  |  | 1,046 |  |  | 137 |  |  | 13 | % |
| % of net revenue | 9 | % |  | 8 | % |  |  |  |  |  | 8 | % |  | 9 | % |  |  |  |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | — | % |  | 1,353 |  |  | — |  |  | 1,353 |  |  | (100) | % |
| % of net revenue | — | % |  | — | % |  |  |  |  |  | 9 | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 2,416 |  |  | $ | 1,771 |  |  | $ | 645 |  |  | 36 | % |  | $ | 5,979 |  |  | $ | 3,444 |  |  | $ | 2,535 |  |  | 74 | % |

[0001045810-22-000147:mdna:82]
Research and development expenses increases were primarily driven by compensation-related costs, including for employee growth as well as increases in salaries to support our employees during this high inflationary environment and stock-based compensation, and engineering development costs of new products coming to market.

[0001045810-22-000147:mdna:83]
Sales, general and administrative expenses increases were primarily driven by compensation-related costs, including for employee growth as well as increases in salaries to support our employees during this high inflationary environment and stock-based compensation, and infrastructure costs partially offset by lower legal fees.

[0001045810-22-000147:mdna:84]
[same as prior period, unchanged from 0001045810-22-000079:mdna:72]

[0001045810-22-000147:mdna:85]
[same as prior period, unchanged from 0001045810-22-000079:mdna:73]

[0001045810-22-000147:mdna:86]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31,2022 |  | August 1,2021 |  | $Change |  | %Change |  | July 31,2022 |  | August 1,2021 |  | $Change |  | %Change |
|  | ($ in millions) |
| Interest income | $ | 46 |  |  | $ | 6 |  |  | $ | 40 |  |  | 667 | % |  | $ | 64 |  |  | $ | 13 |  |  | $ | 51 |  |  | 392 | % |
| Interest expense | (65) |  |  | (60) |  |  | (5) |  |  | 8 | % |  | (132) |  |  | (113) |  |  | (19) |  |  | 17 | % |
| Other, net | (5) |  |  | 4 |  |  | (9) |  |  | (225) | % |  | (19) |  |  | 138 |  |  | (157) |  |  | (114) | % |
| Total | $ | (24) |  |  | $ | (50) |  |  | $ | 26 |  |  | (52) | % |  | $ | (87) |  |  | $ | 38 |  |  | $ | (125) |  |  | (329) | % |

[0001045810-22-000147:mdna:87]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. The increase in interest income was primarily due to higher interest rates earned on our investments.

[0001045810-22-000147:mdna:88]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our notes. The increase in expense reflects interest on the $5.00 billion note issued in June 2021.

[0001045810-22-000147:mdna:89]
Other, net, consists primarily of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. Changes in other, net, compared to the second quarter and first half of fiscal year 2022 were primarily driven by mark-to-market impact from publicly traded equity investments and changes in value from our non-affiliated private investments. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information regarding our investments in non-affiliated entities.

[0001045810-22-000147:mdna:90]
[same as prior period, unchanged from 0001045810-22-000079:mdna:77]

[0001045810-22-000147:mdna:91]
We recognized an income tax benefit of $181 million and an income tax expense of $6 million for the second quarter and first half of fiscal year 2023, respectively, and an income tax expense of $20 million and $153 million for the second quarter and first half of fiscal year 2022, respectively. Income tax as a percentage of income before income tax was a benefit of 38.0% for the second quarter of fiscal year 2023, and an expense of 0.3% for the first half of fiscal year 2023, and an expense of 0.9% and 3.4% for the second quarter and first half of fiscal year 2022, respectively.

[0001045810-22-000147:mdna:92]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2023 as compared to the same periods of fiscal year 2022 was primarily due to the increased tax benefit of stock-based compensation, the foreign-derived intangible income deduction, and the U.S. federal research tax credit, relative to a reduction in expected profitability. This is partially offset by the impact of an increase in the proportion of earnings subject to U.S. tax in fiscal year 2023 and the one-time discrete benefit from re-valuing certain deferred tax assets in connection with the Domestication in fiscal year 2022.

[0001045810-22-000147:mdna:93]
[same as prior period, unchanged from 0001045810-22-000079:mdna:80]

[0001045810-22-000147:mdna:94]
|  | July 31, 2022 |  | January 30, 2022 |
|  | (In millions) |
| Cash and cash equivalents | $ | 3,013 |  |  | $ | 1,990 |  |
| Marketable securities | 14,024 |  |  | 19,218 |  |
| Cash, cash equivalents and marketable securities | $ | 17,037 |  |  | $ | 21,208 |  |

[0001045810-22-000147:mdna:95]
|  | Six Months Ended |
|  | July 31, 2022 |  | August 1, 2021 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 3,001 |  |  | $ | 4,556 |  |
| Net cash provided by (used in) investing activities | $ | 4,230 |  |  | $ | (3,805) |  |
| Net cash provided by (used in) financing activities | $ | (6,208) |  |  | $ | 4,030 |  |

[0001045810-22-000147:mdna:96]
As of July 31, 2022, we had $17.04 billion in cash, cash equivalents and marketable securities, a decrease of $4.17 billion from the end of fiscal year 2022. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-22-000147:mdna:97]
Cash provided by operating activities decreased in the first half of fiscal year 2023 compared to the first half of fiscal year 2022, primarily due to advance payments on supply agreements, tax payments, and a decrease in net income adjusted for certain non-cash items, such as the Arm acquisition termination cost of $1.35 billion, partially offset by changes in working capital.

[0001045810-22-000147:mdna:98]
Cash provided by investing activities increased in the first half of fiscal year 2023 compared to cash used in the first half of fiscal year 2022, primarily driven by higher marketable securities sales and maturities and lower purchases of marketable securities.

[0001045810-22-000147:mdna:99]
Cash used in financing activities decreased in the first half of fiscal year 2023 compared to the first half of fiscal year 2022, which primarily reflects share repurchases and the absence of debt issuance in the first half of fiscal year 2023.

[0001045810-22-000147:mdna:100]
[same as prior period, unchanged from 0001045810-22-000079:mdna:87]

[0001045810-22-000147:mdna:101]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of July 31, 2022, we had $17.04 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance our future capital requirements.

[0001045810-22-000147:mdna:102]
For fiscal year 2023, we expect to use our existing cash and cash equivalents, our marketable securities, and the cash generated by our operations to fund our capital investments of approximately $1.80 billion to $2.00 billion related to property and equipment.

[0001045810-22-000147:mdna:103]
We have approximately $1.38 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S. Other than that, substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of July 31, 2022 are available for use in the U.S. without incurring additional U.S. federal income taxes. We utilized almost all of our accumulated U.S. federal research tax credits during fiscal year 2022, which has resulted in higher cash tax payments starting in fiscal year 2023. In addition, beginning in fiscal year 2023, the 2017 Tax Cuts and Jobs Act requires taxpayers to capitalize research and development expenditures and to amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will impact cash flows from operations and will result in significantly higher cash tax payments starting in fiscal year 2023.

[0001045810-22-000147:mdna:104]
[same as prior period, unchanged from 0001045810-22-000079:mdna:90]

[0001045810-22-000147:mdna:105]
During the second quarter and first half of fiscal year 2023, we returned $3.35 billion and $5.34 billion, respectively, in share repurchases and $100 million and $200 million, respectively, in cash dividends.

[0001045810-22-000147:mdna:106]
[same as prior period, unchanged from 0001045810-22-000079:mdna:92]

[0001045810-22-000147:mdna:107]
[same as prior period, unchanged from 0001045810-22-000079:mdna:93]

[0001045810-22-000147:mdna:108]
As of July 31, 2022, we had outstanding:

[0001045810-22-000147:mdna:109]
[same as prior period, unchanged from 0001045810-22-000079:mdna:95]

[0001045810-22-000147:mdna:110]
[same as prior period, unchanged from 0001045810-22-000079:mdna:96]

[0001045810-22-000147:mdna:111]
[same as prior period, unchanged from 0001045810-22-000079:mdna:97]

[0001045810-22-000147:mdna:112]
[same as prior period, unchanged from 0001045810-22-000079:mdna:98]

[0001045810-22-000147:mdna:113]
[same as prior period, unchanged from 0001045810-22-000079:mdna:99]

[0001045810-22-000147:mdna:114]
[same as prior period, unchanged from 0001045810-22-000079:mdna:100]

[0001045810-22-000147:mdna:115]
[same as prior period, unchanged from 0001045810-22-000079:mdna:101]

[0001045810-22-000147:mdna:116]
[same as prior period, unchanged from 0001045810-22-000079:mdna:102]

[0001045810-22-000147:mdna:117]
[same as prior period, unchanged from 0001045810-22-000079:mdna:103]

[0001045810-22-000147:mdna:118]
We have a $575 million commercial paper program to support general corporate purposes. As of July 31, 2022, we had not issued any commercial paper.

[0001045810-22-000147:mdna:119]
[same as prior period, unchanged from 0001045810-22-000079:mdna:105]

[0001045810-22-000147:mdna:120]
We have unrecognized tax benefits of $834 million, which includes related interest and penalties of $72 million recorded in non-current income tax payable as of July 31, 2022. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-22-000147:mdna:121]
[same as prior period, unchanged from 0001045810-22-000079:mdna:108]

[0001045810-22-000147:mdna:122]
[same as prior period, unchanged from 0001045810-22-000079:mdna:109]

[0001045810-22-000147:mdna:123]
To date, there has been no material impact to our results of operations associated with global sustainability regulations, compliance, costs from sourcing renewable energy or climate-related business trends. There are no material current climate change regulations impacting us, however, we are monitoring potential regulation changes in California, the United States, the United Kingdom, the European Union and other jurisdictions. We believe that climate change has not had a material impact to our revenue to date. We have not experienced any significant physical effects of climate change to date on our operations and results, nor any significant impacts on the cost or availability of insurance.

[0001045810-22-000147:mdna:124]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-22-000147:mdna:125]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of a new and recently issued accounting pronouncement.
