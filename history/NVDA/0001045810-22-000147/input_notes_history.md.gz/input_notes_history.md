# NVDA note change history — 0001045810-22-000079 → 0001045810-22-000147


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-31):
[0001045810-22-000147:note_history:1]
We have entered into several long-term supply agreements, under which we have made advance payments and have $929 million remaining unpaid. As of July 31, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.22 billion, inclusive of the $929 million. We also had other purchase obligations totaling $1.36 billion.
  (was, 2022-05-27, similarity 0.9865):
[0001045810-22-000079:note_history:1]
We have entered into several long-term supply agreements, under which we have made advance payments and have $1.02 billion remaining unpaid. As of May 1, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.59 billion, inclusive of the $1.02 billion. We also had other purchase obligations totaling $1.85 billion.

- changed (2022-08-31):
[0001045810-22-000147:note_history:2]
Total gross future unconditional purchase commitments as of July 31, 2022, are as follows:
  (was, 2022-05-27, similarity 0.9317):
[0001045810-22-000079:note_history:2]
Total future unconditional purchase commitments as of May 1, 2022, are as follows:

- added (2022-08-31):
[0001045810-22-000147:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first half of fiscal year 2023) | $ | 7,108 |  |
| 2024 | 2,730 |  |
| 2025 | 295 |  |
| 2026 | 49 |  |
| 2027 | 71 |  |
| 2028 and thereafter | 331 |  |
| Total | $ | 10,584 |  |

- added (2022-08-31):
[0001045810-22-000147:note_history:4]
The estimated amount of product warranty liabilities was $168 million and $46 million as of July 31, 2022 and January 30, 2022, respectively. In the second quarter of fiscal year 2023, we recorded $122 million in product warranty liabilities primarily related to a defect identified in a third-party component embedded in certain Data Center products. The estimated product returns and estimated product warranty activity consisted of the following:

- added (2022-08-31):
[0001045810-22-000147:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 55 |  |  | $ | 30 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions | 122 |  |  | 4 |  |  | 138 |  |  | 15 |  |
| Deductions | (9) |  |  | (3) |  |  | (16) |  |  | (6) |  |
| Balance at end of period | $ | 168 |  |  | $ | 31 |  |  | $ | 168 |  |  | $ | 31 |  |

- changed (2022-08-31):
[0001045810-22-000147:note_history:6]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.
  (was, 2022-05-27, similarity 0.9845):
[0001045810-22-000079:note_history:6]
With certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

- changed (2022-08-31):
[0001045810-22-000147:note_history:7]
As of July 31, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2022-05-27, similarity 0.9962):
[0001045810-22-000079:note_history:7]
As of May 1, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2022-08-31):
[0001045810-22-000079:note_history:8]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first quarter of fiscal year 2023) | $ | 8,344 |  |
| 2024 | 2,238 |  |
| 2025 | 406 |  |
| 2026 | 48 |  |
| 2027 | 70 |  |
| 2028 and thereafter | 330 |  |
| Total | $ | 11,436 |  |

- removed (2022-08-31):
[0001045810-22-000079:note_history:9]
The estimated amount of product warranty liabilities was $55 million and $46 million as of May 1, 2022 and January 30, 2022, respectively, and the activities were not significant.

- removed (2022-08-31):
[0001045810-22-000079:note_history:10]
Litigation


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-31):
[0001045810-22-000147:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The second quarters of fiscal years 2023 and 2022 were both 13-week quarters.
  (was, 2022-05-27, similarity 0.9759):
[0001045810-22-000079:note_history:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The first quarters of fiscal years 2023 and 2022 were both 13-week quarters.

- removed (2022-08-31):
[0001045810-22-000079:note_history:12]
On July 19, 2021, we executed a four-for-one stock split of our common stock. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the stock split.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-31):
[0001045810-22-000147:note_history:13]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 31, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.9 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (51) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,949 |  |  | $ | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,700 |  |  | $ | 10,946 |  |
  (was, 2022-05-27, similarity 0.9244):
[0001045810-22-000079:note_history:13]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 1, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 1.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 2.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (53) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,947 |  |  | $ | 10,946 |  |

- changed (2022-08-31):
[0001045810-22-000147:note_history:14]
As of July 31, 2022, we have complied with the required covenants under the notes.
  (was, 2022-05-27, similarity 0.9669):
[0001045810-22-000079:note_history:14]
As of May 1, 2022, we have complied with the required covenants under the notes.

- changed (2022-08-31):
[0001045810-22-000147:note_history:15]
We have a $575 million commercial paper program to support general corporate purposes. As of July 31, 2022, we had not issued any commercial paper.
  (was, 2022-05-27, similarity 0.9819):
[0001045810-22-000079:note_history:15]
We have a $575 million commercial paper program to support general corporate purposes. As of May 1, 2022, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-31):
[0001045810-22-000147:note_history:16]
The following is a summary of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022:
  (was, 2022-05-27, similarity 0.9758):
[0001045810-22-000079:note_history:16]
The following is a summary of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022:

- changed (2022-08-31):
[0001045810-22-000147:note_history:17]
|  | July 31, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,016 |  |  | $ | — |  |  | $ | (18) |  |  | $ | 7,998 |  |  | $ | 1,115 |  |  | $ | 6,883 |  |
| Debt securities issued by the United States Treasury | 4,068 |  |  | 1 |  |  | (39) |  |  | 4,030 |  |  | 108 |  |  | 3,922 |  |
| Debt securities issued by United States government agencies | 3,056 |  |  | — |  |  | (2) |  |  | 3,054 |  |  | 564 |  |  | 2,490 |  |
| Certificates of deposit | 856 |  |  | — |  |  | — |  |  | 856 |  |  | 128 |  |  | 728 |  |
| Money market funds | 639 |  |  | — |  |  | — |  |  | 639 |  |  | 639 |  |  | — |  |
| Foreign government bonds | 15 |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |
| Total | $ | 16,650 |  |  | $ | 1 |  |  | $ | (59) |  |  | $ | 16,592 |  |  | $ | 2,569 |  |  | $ | 14,023 |  |
  (was, 2022-05-27, similarity 0.6001):
[0001045810-22-000079:note_history:17]
|  | May 1, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,827 |  |  | $ | — |  |  | $ | (9) |  |  | $ | 9,818 |  |  | $ | 1,232 |  |  | $ | 8,586 |  |
| Debt securities issued by the United States Treasury | 6,157 |  |  | 3 |  |  | (38) |  |  | 6,122 |  |  | 1,324 |  |  | 4,798 |  |
| Debt securities issued by United States government agencies | 2,116 |  |  | — |  |  | — |  |  | 2,116 |  |  | 460 |  |  | 1,656 |  |
| Certificates of deposit | 1,302 |  |  | — |  |  | — |  |  | 1,302 |  |  | 41 |  |  | 1,261 |  |
| Money market funds | 419 |  |  | — |  |  | — |  |  | 419 |  |  | 419 |  |  | — |  |
| Foreign government bonds | 185 |  |  | — |  |  | — |  |  | 185 |  |  | 35 |  |  | 150 |  |
| Total | $ | 20,006 |  |  | $ | 3 |  |  | $ | (47) |  |  | $ | 19,962 |  |  | $ | 3,511 |  |  | $ | 16,451 |  |

- changed (2022-08-31):
[0001045810-22-000147:note_history:18]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022 are shown below by contractual maturity.
  (was, 2022-05-27, similarity 0.9844):
[0001045810-22-000079:note_history:18]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022 are shown below by contractual maturity.

- added (2022-08-31):
[0001045810-22-000147:note_history:19]
|  | July 31, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,628 |  |  | $ | 12,607 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,022 |  |  | 3,985 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 16,650 |  |  | $ | 16,592 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2022-08-31):
[0001045810-22-000079:note_history:20]
|  | May 1, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,196 |  |  | $ | 15,185 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,810 |  |  | 4,777 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 20,006 |  |  | $ | 19,962 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-31):
[0001045810-22-000147:note_history:21]
The following is a summary of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022:
  (was, 2022-05-27, similarity 0.9758):
[0001045810-22-000079:note_history:21]
The following is a summary of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022:

- changed (2022-08-31):
[0001045810-22-000147:note_history:22]
|  | July 31, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,016 |  |  | $ | — |  |  | $ | (18) |  |  | $ | 7,998 |  |  | $ | 1,115 |  |  | $ | 6,883 |  |
| Debt securities issued by the United States Treasury | 4,068 |  |  | 1 |  |  | (39) |  |  | 4,030 |  |  | 108 |  |  | 3,922 |  |
| Debt securities issued by United States government agencies | 3,056 |  |  | — |  |  | (2) |  |  | 3,054 |  |  | 564 |  |  | 2,490 |  |
| Certificates of deposit | 856 |  |  | — |  |  | — |  |  | 856 |  |  | 128 |  |  | 728 |  |
| Money market funds | 639 |  |  | — |  |  | — |  |  | 639 |  |  | 639 |  |  | — |  |
| Foreign government bonds | 15 |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |
| Total | $ | 16,650 |  |  | $ | 1 |  |  | $ | (59) |  |  | $ | 16,592 |  |  | $ | 2,569 |  |  | $ | 14,023 |  |
  (was, 2022-05-27, similarity 0.6001):
[0001045810-22-000079:note_history:22]
|  | May 1, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,827 |  |  | $ | — |  |  | $ | (9) |  |  | $ | 9,818 |  |  | $ | 1,232 |  |  | $ | 8,586 |  |
| Debt securities issued by the United States Treasury | 6,157 |  |  | 3 |  |  | (38) |  |  | 6,122 |  |  | 1,324 |  |  | 4,798 |  |
| Debt securities issued by United States government agencies | 2,116 |  |  | — |  |  | — |  |  | 2,116 |  |  | 460 |  |  | 1,656 |  |
| Certificates of deposit | 1,302 |  |  | — |  |  | — |  |  | 1,302 |  |  | 41 |  |  | 1,261 |  |
| Money market funds | 419 |  |  | — |  |  | — |  |  | 419 |  |  | 419 |  |  | — |  |
| Foreign government bonds | 185 |  |  | — |  |  | — |  |  | 185 |  |  | 35 |  |  | 150 |  |
| Total | $ | 20,006 |  |  | $ | 3 |  |  | $ | (47) |  |  | $ | 19,962 |  |  | $ | 3,511 |  |  | $ | 16,451 |  |

- changed (2022-08-31):
[0001045810-22-000147:note_history:23]
|  | July 31, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 2,793 |  |  | $ | (39) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,793 |  |  | $ | (39) |  |
| Debt securities issued by United States government agencies | 2,312 |  |  | (2) |  |  | — |  |  | — |  |  | 2,312 |  |  | (2) |  |
| Corporate debt securities | 1,925 |  |  | (17) |  |  | 105 |  |  | (1) |  |  | 2,030 |  |  | (18) |  |
| Total | $ | 7,030 |  |  | $ | (58) |  |  | $ | 105 |  |  | $ | (1) |  |  | $ | 7,135 |  |  | $ | (59) |  |
  (was, 2022-05-27, similarity 0.6959):
[0001045810-22-000079:note_history:23]
|  | May 1, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 2,955 |  |  | $ | (38) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,955 |  |  | $ | (38) |  |
| Corporate debt securities | 2,594 |  |  | (9) |  |  | 19 |  |  | — |  |  | 2,613 |  |  | (9) |  |
| Total | $ | 5,549 |  |  | $ | (47) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 5,568 |  |  | $ | (47) |  |

- changed (2022-08-31):
[0001045810-22-000147:note_history:24]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022 are shown below by contractual maturity.
  (was, 2022-05-27, similarity 0.9844):
[0001045810-22-000079:note_history:24]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022 are shown below by contractual maturity.

- added (2022-08-31):
[0001045810-22-000147:note_history:25]
|  | July 31, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,628 |  |  | $ | 12,607 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,022 |  |  | 3,985 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 16,650 |  |  | $ | 16,592 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2022-08-31):
[0001045810-22-000079:note_history:26]
|  | May 1, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,196 |  |  | $ | 15,185 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,810 |  |  | 4,777 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 20,006 |  |  | $ | 19,962 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-31):
[0001045810-22-000147:note_history:27]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 31, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.9 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (51) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,949 |  |  | $ | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,700 |  |  | $ | 10,946 |  |
  (was, 2022-05-27, similarity 0.9244):
[0001045810-22-000079:note_history:27]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 1, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 1.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 2.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (53) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,947 |  |  | $ | 10,946 |  |
