# NVDA notes — 0001045810-22-000147


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-22-000147:notes:1]
[same as prior period, unchanged from 0001045810-22-000079:notes:1]

[0001045810-22-000147:notes:2]
[same as prior period, unchanged from 0001045810-22-000079:notes:2]

[0001045810-22-000147:notes:3]
[same as prior period, unchanged from 0001045810-22-000079:notes:4]

[0001045810-22-000147:notes:4]
[same as prior period, unchanged from 0001045810-22-000079:notes:5]

[0001045810-22-000147:notes:5]
[same as prior period, unchanged from 0001045810-22-000079:notes:6]

[0001045810-22-000147:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The second quarters of fiscal years 2023 and 2022 were both 13-week quarters.

[0001045810-22-000147:notes:7]
[same as prior period, unchanged from 0001045810-22-000079:notes:8]

[0001045810-22-000147:notes:8]
[same as prior period, unchanged from 0001045810-22-000079:notes:9]

[0001045810-22-000147:notes:9]
[same as prior period, unchanged from 0001045810-22-000079:notes:10]

[0001045810-22-000147:notes:10]
[same as prior period, unchanged from 0001045810-22-000079:notes:11]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-22-000147:notes:11]
[same as prior period, unchanged from 0001045810-22-000079:notes:12]

[0001045810-22-000147:notes:12]
In February 2022, NVIDIA and SoftBank Group Corp, or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing in September 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-22-000147:notes:13]
[same as prior period, unchanged from 0001045810-22-000079:notes:14]

[0001045810-22-000147:notes:14]
Future minimum lease payments under our non-cancelable operating leases as of July 31, 2022 are as follows:

[0001045810-22-000147:notes:15]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first half of fiscal year 2023) | $ | 91 |  |
| 2024 | 169 |  |
| 2025 | 148 |  |
| 2026 | 132 |  |
| 2027 | 123 |  |
| 2028 and thereafter | 348 |  |
| Total | 1,011 |  |
| Less imputed interest | 123 |  |
| Present value of net future minimum lease payments | 888 |  |
| Less short-term operating lease liabilities | 145 |  |
| Long-term operating lease liabilities | $ | 743 |  |

[0001045810-22-000147:notes:16]
In addition to our existing operating lease obligations, we have operating leases that are expected to commence between the third quarter of fiscal year 2023 and fiscal year 2025 with lease terms of 2 to 8 years for $798 million, consisting primarily of data center space.

[0001045810-22-000147:notes:17]
Operating lease expenses were $47 million and $42 million for the second quarter of fiscal years 2023 and 2022, respectively, and $90 million and $81 million for the first half of fiscal years 2023 and 2022, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal years 2023 and 2022 were not significant.

[0001045810-22-000147:notes:18]
[same as prior period, unchanged from 0001045810-22-000079:notes:19]

[0001045810-22-000147:notes:19]
|  | Six Months Ended |
|  | July 31, 2022 |  | August 1, 2021 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 91 |  |  | $ | 75 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 98 |  |  | $ | 164 |  |

[0001045810-22-000147:notes:20]
As of July 31, 2022, our operating leases had a weighted average remaining lease term of 7.1 years and a weighted average discount rate of 2.73%. As of January 30, 2022, our operating leases had a weighted average remaining lease term of 7.1 years and a weighted average discount rate of 2.51%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-22-000147:notes:21]
[same as prior period, unchanged from 0001045810-22-000079:notes:22]

[0001045810-22-000147:notes:22]
[same as prior period, unchanged from 0001045810-22-000079:notes:23]

[0001045810-22-000147:notes:23]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  | (In millions) |
| Cost of revenue | $ | 38 |  |  | $ | 32 |  |  | $ | 76 |  |  | $ | 57 |  |
| Research and development | 452 |  |  | 297 |  |  | 836 |  |  | 573 |  |
| Sales, general and administrative | 159 |  |  | 136 |  |  | 315 |  |  | 264 |  |
| Total | $ | 649 |  |  | $ | 465 |  |  | $ | 1,227 |  |  | $ | 894 |  |

[0001045810-22-000147:notes:24]
[same as prior period, unchanged from 0001045810-22-000079:notes:25]

[0001045810-22-000147:notes:25]
[same as prior period, unchanged from 0001045810-22-000079:notes:26]

[0001045810-22-000147:notes:26]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 30, 2022 | 46 |  |  | $ | 114.19 |  |  |  |  |  |
| Granted | 22 |  |  | $ | 187.51 |  |  |  |  |  |
| Vested restricted stock | (11) |  |  | $ | 86.77 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 131.19 |  |  |  |  |  |
| Balances, July 31, 2022 | 56 |  |  | $ | 148.43 |  |  |  |  |  |

[0001045810-22-000147:notes:27]
As of July 31, 2022, there was $7.61 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.8 years for RSUs, PSUs, and market-based PSUs, and 1.0 year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-22-000147:notes:28]
[same as prior period, unchanged from 0001045810-22-000079:notes:29]

[0001045810-22-000147:notes:29]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 656 |  |  | $ | 2,374 |  |  | $ | 2,274 |  |  | $ | 4,285 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,495 |  |  | 2,493 |  |  | 2,500 |  |  | 2,489 |  |
| Dilutive impact of outstandingequity awards | 21 |  |  | 39 |  |  | 26 |  |  | 40 |  |
| Diluted weighted average shares | 2,516 |  |  | 2,532 |  |  | 2,526 |  |  | 2,529 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.26 |  |  | $ | 0.95 |  |  | $ | 0.91 |  |  | $ | 1.72 |  |
| Diluted (2) | $ | 0.26 |  |  | $ | 0.94 |  |  | $ | 0.90 |  |  | $ | 1.69 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 33 |  |  | 13 |  |  | 25 |  |  | 15 |  |

[0001045810-22-000147:notes:30]
[same as prior period, unchanged from 0001045810-22-000079:notes:31]

[0001045810-22-000147:notes:31]
[same as prior period, unchanged from 0001045810-22-000079:notes:32]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-22-000147:notes:32]
Income Taxes
We recognized an income tax benefit of $181 million and an income tax expense of $6 million for the second quarter and first half of fiscal year 2023, respectively, and an income tax expense of $20 million and $153 million for the second quarter and first half of fiscal year 2022, respectively. Income tax as a percentage of income before income tax was a benefit of 38.0% for the second quarter of fiscal year 2023, and an expense of 0.3% for the first half of fiscal year 2023 and an expense of 0.9% and 3.4% for the second quarter and first half of fiscal year 2022, respectively.

[0001045810-22-000147:notes:33]
The decrease in our effective tax rate for the second quarter and first half of fiscal year 2023 as compared to the same periods of fiscal year 2022 was primarily due to the increased tax benefit of stock-based compensation, the foreign-derived intangible income deduction, and the U.S. federal research tax credit, relative to a reduction in expected profitability. This is partially offset by the impact of an increase in the proportion of earnings subject to U.S. tax in fiscal year 2023 and the one-time discrete benefit from re-valuing certain deferred tax assets in connection with the domestication of one of our foreign subsidiaries, or the Domestication, in fiscal year 2022.

[0001045810-22-000147:notes:34]
Our effective tax rate for the first half of fiscal year 2023 was lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation and the U.S. federal research tax credit.

[0001045810-22-000147:notes:35]
Our effective tax rate for the first half of fiscal year 2022 was lower than the U.S. federal statutory rate of 21% due to the discrete benefit of the Domestication, tax benefits related to the foreign-derived intangible income deduction, income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, and tax benefits related to the U.S. federal research tax credit and stock-based compensation.

[0001045810-22-000147:notes:36]
For the first half of fiscal year 2023, there were no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 30, 2022.
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 31, 2022, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-22-000147:notes:37]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-22-000147:notes:38]
The following is a summary of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022:

[0001045810-22-000147:notes:39]
|  | July 31, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,016 |  |  | $ | — |  |  | $ | (18) |  |  | $ | 7,998 |  |  | $ | 1,115 |  |  | $ | 6,883 |  |
| Debt securities issued by the United States Treasury | 4,068 |  |  | 1 |  |  | (39) |  |  | 4,030 |  |  | 108 |  |  | 3,922 |  |
| Debt securities issued by United States government agencies | 3,056 |  |  | — |  |  | (2) |  |  | 3,054 |  |  | 564 |  |  | 2,490 |  |
| Certificates of deposit | 856 |  |  | — |  |  | — |  |  | 856 |  |  | 128 |  |  | 728 |  |
| Money market funds | 639 |  |  | — |  |  | — |  |  | 639 |  |  | 639 |  |  | — |  |
| Foreign government bonds | 15 |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |
| Total | $ | 16,650 |  |  | $ | 1 |  |  | $ | (59) |  |  | $ | 16,592 |  |  | $ | 2,569 |  |  | $ | 14,023 |  |

[0001045810-22-000147:notes:40]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

[0001045810-22-000147:notes:41]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-22-000147:notes:42]
|  | July 31, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 2,793 |  |  | $ | (39) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,793 |  |  | $ | (39) |  |
| Debt securities issued by United States government agencies | 2,312 |  |  | (2) |  |  | — |  |  | — |  |  | 2,312 |  |  | (2) |  |
| Corporate debt securities | 1,925 |  |  | (17) |  |  | 105 |  |  | (1) |  |  | 2,030 |  |  | (18) |  |
| Total | $ | 7,030 |  |  | $ | (58) |  |  | $ | 105 |  |  | $ | (1) |  |  | $ | 7,135 |  |  | $ | (59) |  |

[0001045810-22-000147:notes:43]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

[0001045810-22-000147:notes:44]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-22-000147:notes:45]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022 are shown below by contractual maturity.

[0001045810-22-000147:notes:46]
|  | July 31, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,628 |  |  | $ | 12,607 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,022 |  |  | 3,985 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 16,650 |  |  | $ | 16,592 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-22-000147:notes:47]
Fair Value of Financial Assets and Liabilities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-22-000147:notes:48]
|  |  | Fair Value at |
|  | Pricing Category |  | July 31, 2022 |  | January 30, 2022 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 639 |  |  | $ | 316 |  |
| Corporate debt securities | Level 2 |  | $ | 7,998 |  |  | $ | 9,974 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 4,030 |  |  | $ | 7,300 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 3,054 |  |  | $ | 1,612 |  |
| Certificates of deposit | Level 2 |  | $ | 856 |  |  | $ | 1,561 |  |
| Foreign government bonds | Level 2 |  | $ | 15 |  |  | $ | 150 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities (1) | Level 1 |  | $ | 41 |  |  | $ | 58 |  |
| Privately-held equity securities | Level 3 |  | $ | 266 |  |  | $ | 208 |  |
| Liabilities (2) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,220 |  |  | $ | 1,236 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,193 |  |  | $ | 1,224 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 1,013 |  |  | $ | 1,055 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,136 |  |  | $ | 1,200 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,431 |  |  | $ | 1,542 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,116 |  |  | $ | 1,200 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 927 |  |  | $ | 1,066 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,815 |  |  | $ | 2,147 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 451 |  |  | $ | 551 |  |

[0001045810-22-000147:notes:49]
(1)    Unrealized losses of $7 million and $31 million from investments in publicly-traded equity securities were recorded in other income (expense), net, in the second quarter and first half of fiscal year 2023, respectively. An unrealized loss of $6 million on an investment in a publicly-traded equity security was recorded in other income (expense), net in the second quarter of fiscal year 2022 and an unrealized gain of $118 million was recorded in other income (expense), net in the first half of fiscal year 2022.

[0001045810-22-000147:notes:50]
[same as prior period, unchanged from 0001045810-22-000079:notes:51]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-22-000147:notes:51]
[same as prior period, unchanged from 0001045810-22-000079:notes:52]

[0001045810-22-000147:notes:52]
|  | July 31, 2022 |  | January 30, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,260 |  |  | $ | (1,434) |  |  | $ | 1,826 |  |  | $ | 3,418 |  |  | $ | (1,304) |  |  | $ | 2,114 |  |
| Patents and licensed technology | 718 |  |  | (508) |  |  | 210 |  |  | 717 |  |  | (492) |  |  | 225 |  |
| Total intangible assets | $ | 3,978 |  |  | $ | (1,942) |  |  | $ | 2,036 |  |  | $ | 4,135 |  |  | $ | (1,796) |  |  | $ | 2,339 |  |

[0001045810-22-000147:notes:53]
(1)    During the first quarter of fiscal year 2023, we commenced amortization of the $630 million in-process research and development intangible asset related to our acquisition of Mellanox.

[0001045810-22-000147:notes:54]
Amortization expense associated with intangible assets was $182 million and $336 million for the second quarter and first half of fiscal year 2023, respectively, and $138 million and $275 million for the second quarter and first half of fiscal year 2022, respectively. Future amortization expense related to the net carrying amount of intangible assets as of July 31, 2022 is estimated to be $364 million for the remainder of fiscal year 2023, $601 million in fiscal year 2024, $539 million in fiscal year 2025, $245 million in fiscal year 2026, $141 million in fiscal year 2027, and $146 million in fiscal year 2028 and thereafter.
In the first half of fiscal year 2023, goodwill increased by $23 million and intangible assets increased by $32 million from acquisitions. We assigned $14 million of the increase in goodwill to our Compute & Networking segment and $9 million of the increase to our Graphics segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-22-000147:notes:55]
[same as prior period, unchanged from 0001045810-22-000079:notes:55]

[0001045810-22-000147:notes:56]
|  | July 31, |  | January 30, |
|  | 2022 |  | 2022 |
| Inventories (1): | (In millions) |
| Raw materials | $ | 1,534 |  |  | $ | 791 |  |
| Work in-process | 767 |  |  | 692 |  |
| Finished goods | 1,588 |  |  | 1,122 |  |
| Total inventories | $ | 3,889 |  |  | $ | 2,605 |  |

[0001045810-22-000147:notes:57]
(1)     During the second quarter of fiscal year 2023, we recorded an inventory reserve expense of approximately $570 million in cost of revenue.

[0001045810-22-000147:notes:58]
|  | July 31, |  | January 30, |
|  | 2022 |  | 2022 |
| Other assets: | (In millions) |
| Prepaid supply agreements | $ | 2,523 |  |  | $ | 1,747 |  |
| Prepaid royalties | 399 |  |  | 409 |  |
| Investment in non-affiliated entities | 307 |  |  | 266 |  |
| Advanced consideration for acquisition (1) | — |  |  | 1,353 |  |
| Other | 111 |  |  | 66 |  |
| Total other assets | $ | 3,340 |  |  | $ | 3,841 |  |

[0001045810-22-000147:notes:59]
[same as prior period, unchanged from 0001045810-22-000079:notes:58]

[0001045810-22-000147:notes:60]
|  | July 31, |  | January 30, |
|  | 2022 |  | 2022 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 1,463 |  |  | $ | 1,000 |  |
| Excess inventory purchase obligations (1) | 866 |  |  | 196 |  |
| Accrued payroll and related expenses | 421 |  |  | 409 |  |
| Deferred revenue (2) | 359 |  |  | 300 |  |
| Product warranty | 168 |  |  | 46 |  |
| Taxes payable | 158 |  |  | 132 |  |
| Other | 468 |  |  | 469 |  |
| Total accrued and other current liabilities | $ | 3,903 |  |  | $ | 2,552 |  |

[0001045810-22-000147:notes:61]
(1)    During the second quarter of fiscal year 2023, we recorded an expense of approximately $650 million in cost of revenue for inventory purchase obligations in excess of our current demand projections, and cancellation and underutilization penalties.

[0001045810-22-000147:notes:62]
(2)    Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements, support for hardware and software, and cloud services.

[0001045810-22-000147:notes:63]
|  | July 31, |  | January 30, |
|  | 2022 |  | 2022 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,022 |  |  | $ | 980 |  |
| Deferred income tax | 252 |  |  | 245 |  |
| Deferred revenue (2) | 201 |  |  | 202 |  |
| Other | 134 |  |  | 126 |  |
| Total other long-term liabilities | $ | 1,609 |  |  | $ | 1,553 |  |

[0001045810-22-000147:notes:64]
(1)    As of July 31, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $188 million, unrecognized tax benefits of $762 million, and related interest and penalties of $72 million. As of January 30, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, unrecognized tax benefits of $670 million, and related interest and penalties of $59 million.

[0001045810-22-000147:notes:65]
[same as prior period, unchanged from 0001045810-22-000079:notes:63]

[0001045810-22-000147:notes:66]
[same as prior period, unchanged from 0001045810-22-000079:notes:64]

[0001045810-22-000147:notes:67]
The following table shows the changes in deferred revenue during the first half of fiscal years 2023 and 2022:

[0001045810-22-000147:notes:68]
|  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 502 |  |  | $ | 451 |  |
| Deferred revenue additions during the period | 399 |  |  | 401 |  |
| Revenue recognized during the period | (341) |  |  | (362) |  |
| Balance at end of period | $ | 560 |  |  | $ | 490 |  |

[0001045810-22-000147:notes:69]
Revenue related to remaining performance obligations represents the contracted license and development arrangements and support for hardware and software. This includes deferred revenue currently recorded and amounts that will be invoiced in future periods. As of July 31, 2022, $645 million of revenue related to performance obligations had not been recognized, of which we expect to recognize approximately 48% over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-22-000147:notes:70]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of July 31, 2022 and January 30, 2022.

[0001045810-22-000147:notes:71]
[same as prior period, unchanged from 0001045810-22-000079:notes:69]

[0001045810-22-000147:notes:72]
The table below presents the notional value of our foreign currency forward contracts outstanding as of July 31, 2022 and January 30, 2022:

[0001045810-22-000147:notes:73]
|  | July 31,2022 |  | January 30,2022 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,090 |  |  | $ | 1,023 |  |
| Not designated for hedge accounting | $ | 378 |  |  | $ | 408 |  |

[0001045810-22-000147:notes:74]
As of July 31, 2022, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-22-000147:notes:75]
During the first half of fiscal years 2023 and 2022, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant.


## us-gaap:DebtDisclosureTextBlock

[0001045810-22-000147:notes:76]
Debt
Long-Term Debt

[0001045810-22-000147:notes:77]
The carrying values of our outstanding notes and their associated interest rates were as follows:

[0001045810-22-000147:notes:78]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 31, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.9 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (51) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,949 |  |  | $ | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,700 |  |  | $ | 10,946 |  |

[0001045810-22-000147:notes:79]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-22-000147:notes:80]
As of July 31, 2022, we have complied with the required covenants under the notes.

[0001045810-22-000147:notes:81]
Commercial Paper

[0001045810-22-000147:notes:82]
We have a $575 million commercial paper program to support general corporate purposes. As of July 31, 2022, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-22-000147:notes:83]
Commitments and Contingencies
Purchase Obligations

[0001045810-22-000147:notes:84]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-22-000147:notes:85]
We have entered into several long-term supply agreements, under which we have made advance payments and have $929 million remaining unpaid. As of July 31, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.22 billion, inclusive of the $929 million. We also had other purchase obligations totaling $1.36 billion.

[0001045810-22-000147:notes:86]
Total gross future unconditional purchase commitments as of July 31, 2022, are as follows:

[0001045810-22-000147:notes:87]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first half of fiscal year 2023) | $ | 7,108 |  |
| 2024 | 2,730 |  |
| 2025 | 295 |  |
| 2026 | 49 |  |
| 2027 | 71 |  |
| 2028 and thereafter | 331 |  |
| Total | $ | 10,584 |  |

[0001045810-22-000147:notes:88]
Accrual for Product Warranty Liabilities

[0001045810-22-000147:notes:89]
The estimated amount of product warranty liabilities was $168 million and $46 million as of July 31, 2022 and January 30, 2022, respectively. In the second quarter of fiscal year 2023, we recorded $122 million in product warranty liabilities primarily related to a defect identified in a third-party component embedded in certain Data Center products. The estimated product returns and estimated product warranty activity consisted of the following:

[0001045810-22-000147:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 55 |  |  | $ | 30 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions | 122 |  |  | 4 |  |  | 138 |  |  | 15 |  |
| Deductions | (9) |  |  | (3) |  |  | (16) |  |  | (6) |  |
| Balance at end of period | $ | 168 |  |  | $ | 31 |  |  | $ | 168 |  |  | $ | 31 |  |

[0001045810-22-000147:notes:91]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-22-000147:notes:92]
Securities Class Action and Derivative Lawsuits

[0001045810-22-000147:notes:93]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

[0001045810-22-000147:notes:94]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-22-000147:notes:95]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-22-000147:notes:96]
Settlement

[0001045810-22-000147:notes:97]
In May 2022, NVIDIA entered into a settlement with the SEC relating to MD&A disclosures in our Forms 10-Q for the second and third quarters of fiscal year 2018 concerning the impact of cryptocurrency mining on year-over-year growth in revenue for our gaming specialized market during those periods. As part of the settlement, without admitting or denying the findings in the administrative order issued by the SEC, NVIDIA agreed to cease-and-desist from violating certain federal securities laws and paid a $5.5 million civil penalty.

[0001045810-22-000147:notes:98]
Accounting for Loss Contingencies

[0001045810-22-000147:notes:99]
As of July 31, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-22-000147:notes:100]
[same as prior period, unchanged from 0001045810-22-000079:notes:98]

[0001045810-22-000147:notes:101]
During the second quarter and first half of fiscal year 2023, we repurchased a total of 19 million and 28 million shares for $3.35 billion and $5.34 billion, respectively. Through July 31, 2022, we have repurchased an aggregate of 1.07 billion shares under our share repurchase program for a total cost of $12.42 billion. As of July 31, 2022, we were authorized, subject to certain specifications, to repurchase additional common stock up to a total of $11.93 billion through December 2023.

[0001045810-22-000147:notes:102]
During the second quarter and first half of fiscal year 2023, we paid $100 million and $200 million in cash dividends to our shareholders, respectively. During the second quarter and first half of fiscal year 2022, we paid $100 million and $198 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-22-000147:notes:103]
[same as prior period, unchanged from 0001045810-22-000079:notes:102]

[0001045810-22-000147:notes:104]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; vGPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse software for building 3D designs and virtual worlds.

[0001045810-22-000147:notes:105]
[same as prior period, unchanged from 0001045810-22-000079:notes:105]

[0001045810-22-000147:notes:106]
[same as prior period, unchanged from 0001045810-22-000079:notes:106]

[0001045810-22-000147:notes:107]
[same as prior period, unchanged from 0001045810-22-000079:notes:107]

[0001045810-22-000147:notes:108]
[same as prior period, unchanged from 0001045810-22-000079:notes:108]

[0001045810-22-000147:notes:109]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 31, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 2,797 |  |  | $ | 3,907 |  |  | $ | — |  |  | $ | 6,704 |  |
| Operating income (loss) | $ | 657 |  |  | $ | 816 |  |  | $ | (974) |  |  | $ | 499 |  |
| Three Months Ended August 1, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 3,907 |  |  | $ | 2,600 |  |  | $ | — |  |  | $ | 6,507 |  |
| Operating income (loss) | $ | 2,127 |  |  | $ | 1,034 |  |  | $ | (717) |  |  | $ | 2,444 |  |
| Six Months Ended July 31, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 7,413 |  |  | $ | 7,579 |  |  | $ | — |  |  | $ | 14,992 |  |
| Operating income (loss) | $ | 3,133 |  |  | $ | 2,422 |  |  | $ | (3,188) |  |  | $ | 2,367 |  |
| Six Months Ended August 1, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 7,358 |  |  | $ | 4,810 |  |  | $ | — |  |  | $ | 12,168 |  |
| Operating income (loss) | $ | 3,913 |  |  | $ | 1,895 |  |  | $ | (1,408) |  |  | $ | 4,400 |  |

[0001045810-22-000147:notes:110]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (649) |  |  | $ | (465) |  |  | $ | (1,227) |  |  | $ | (894) |  |
| Acquisition-related and other costs | (175) |  |  | (158) |  |  | (324) |  |  | (325) |  |
| Unallocated cost of revenue and operating expenses | (148) |  |  | (90) |  |  | (275) |  |  | (180) |  |
| Contributions | (2) |  |  | — |  |  | (2) |  |  | — |  |
| IP-related and legal settlement costs | — |  |  | (4) |  |  | (7) |  |  | (9) |  |
| Acquisition termination cost | — |  |  | — |  |  | (1,353) |  |  | — |  |
| Total | $ | (974) |  |  | $ | (717) |  |  | $ | (3,188) |  |  | $ | (1,408) |  |

[0001045810-22-000147:notes:111]
[same as prior period, unchanged from 0001045810-22-000079:notes:111]

[0001045810-22-000147:notes:112]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 1,988 |  |  | $ | 996 |  |  | $ | 3,921 |  |  | $ | 1,764 |  |
| China (including Hong Kong) | 1,602 |  |  | 1,720 |  |  | 3,683 |  |  | 3,111 |  |
| Taiwan | 1,204 |  |  | 1,961 |  |  | 3,981 |  |  | 3,745 |  |
| Other countries | 1,910 |  |  | 1,830 |  |  | 3,407 |  |  | 3,548 |  |
| Total revenue | $ | 6,704 |  |  | $ | 6,507 |  |  | $ | 14,992 |  |  | $ | 12,168 |  |

[0001045810-22-000147:notes:113]
[same as prior period, unchanged from 0001045810-22-000079:notes:113]

[0001045810-22-000147:notes:114]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 2,042 |  |  | $ | 3,061 |  |  | $ | 5,662 |  |  | $ | 5,821 |  |
| Data Center | 3,806 |  |  | 2,366 |  |  | 7,556 |  |  | 4,414 |  |
| Professional Visualization | 496 |  |  | 519 |  |  | 1,118 |  |  | 891 |  |
| Automotive | 220 |  |  | 152 |  |  | 358 |  |  | 306 |  |
| OEM and Other | 140 |  |  | 409 |  |  | 298 |  |  | 736 |  |
| Total revenue | $ | 6,704 |  |  | $ | 6,507 |  |  | $ | 14,992 |  |  | $ | 12,168 |  |

[0001045810-22-000147:notes:115]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal years 2023 or 2022.

[0001045810-22-000147:notes:116]
Two customers each represented 10% or more of accounts receivable for a total of 21% of our accounts receivable balance as of July 31, 2022. Two customers each represented 10% or more of accounts receivable for a total of 22% as of January 30, 2022.
