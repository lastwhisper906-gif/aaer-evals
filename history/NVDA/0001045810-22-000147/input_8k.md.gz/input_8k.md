# NVDA 8-K — 0001045810-22-000136 filed 2022-08-24

## item codes, every 8-K on or before 2022-08-31

- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2022-08-31

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-22-000136:8k_2_02:1]
EX-99.1
2
q2fy23pr.htm
Q2FY23 PRESS RELEASE

[0001045810-22-000136:8k_2_02:2]
Document

[0001045810-22-000136:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-22-000136:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2023

[0001045810-22-000136:8k_2_02:5]
•Quarterly revenue of $6.70 billion, up 3% from a year ago

[0001045810-22-000136:8k_2_02:6]
•Data Center revenue of $3.81 billion, up 61% from a year ago

[0001045810-22-000136:8k_2_02:7]
•Quarterly return to shareholders of $3.44 billion

[0001045810-22-000136:8k_2_02:8]
SANTA CLARA, Calif.-Aug. 24, 2022- NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 31, 2022, of $6.70 billion, up 3% from a year ago and down 19% from the previous quarter.

[0001045810-22-000136:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.26, down 72% from a year ago and down 59% from the previous quarter. Non-GAAP earnings per diluted share were $0.51, down 51% from a year ago and down 63% from the previous quarter.

[0001045810-22-000136:8k_2_02:10]
“We are navigating our supply chain transitions in a challenging macro environment and we will get through this,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-22-000136:8k_2_02:11]
“Accelerated computing and AI, the pioneering work of our company, are transforming industries. Automotive is becoming a tech industry and is on track to be our next billion-dollar business. Advances in AI are driving our Data Center business while accelerating breakthroughs in fields from drug discovery to climate science to robotics.

[0001045810-22-000136:8k_2_02:12]
“I look forward to next month’s GTC conference, where we will share new advances in RTX, as well as breakthroughs in AI and the metaverse, the next evolution of the internet. Join us,” he said.

[0001045810-22-000136:8k_2_02:13]
During the second quarter of fiscal 2023, NVIDIA returned to shareholders $3.44 billion in share repurchases and cash dividends, following a return of $2.10 billion in the first quarter. The company has $11.93 billion remaining under its share repurchase authorization through December 2023. NVIDIA plans to continue share repurchases this fiscal year.

[0001045810-22-000136:8k_2_02:14]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on September 29, 2022, to all shareholders of record on September 8, 2022.

[0001045810-22-000136:8k_2_02:15]
Q2 Fiscal 2023 Summary

[0001045810-22-000136:8k_2_02:16]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY23 | Q1 FY23 | Q2 FY22 | Q/Q | Y/Y |
| Revenue | $6,704 | $8,288 | $6,507 | Down 19% | Up 3% |
| Gross margin | 43.5 | % | 65.5 | % | 64.8 | % | Down 22.0 pts | Down 21.3 pts |
| Operating expenses | $2,416 | $3,563 | $1,771 | Down 32% | Up 36% |
| Operating income | $499 | $1,868 | $2,444 | Down 73% | Down 80% |
| Net income | $656 | $1,618 | $2,374 | Down 59% | Down 72% |
| Diluted earnings per share | $0.26 | $0.64 | $0.94 | Down 59% | Down 72% |

[0001045810-22-000136:8k_2_02:17]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY23 | Q1 FY23 | Q2 FY22 | Q/Q | Y/Y |
| Revenue | $6,704 | $8,288 | $6,507 | Down 19% | Up 3% |
| Gross margin | 45.9 | % | 67.1 | % | 66.7 | % | Down 21.2 pts | Down 20.8 pts |
| Operating expenses | $1,749 | $1,608 | $1,266 | Up 9% | Up 38% |
| Operating income | $1,325 | $3,955 | $3,071 | Down 66% | Down 57% |
| Net income | $1,292 | $3,443 | $2,623 | Down 62% | Down 51% |
| Diluted earnings per share | $0.51 | $1.36 | $1.04 | Down 63% | Down 51% |

[0001045810-22-000136:8k_2_02:18]
Outlook

[0001045810-22-000136:8k_2_02:19]
NVIDIA’s outlook for the third quarter of fiscal 2023 is as follows:

[0001045810-22-000136:8k_2_02:20]
•Revenue is expected to be $5.90 billion, plus or minus 2%. Gaming and Professional Visualization revenue are expected to decline sequentially, as OEMs and channel partners reduce inventory levels to align with current levels of demand and prepare for NVIDIA’s new product generation. The company expects that decline to be partially offset by sequential growth in Data Center and Automotive.

[0001045810-22-000136:8k_2_02:21]
•GAAP and non-GAAP gross margins are expected to be 62.4% and 65.0%, respectively, plus or minus 50 basis points.

[0001045810-22-000136:8k_2_02:22]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.59 billion and $1.82 billion, respectively.

[0001045810-22-000136:8k_2_02:23]
•GAAP and non-GAAP other income and expense are expected to be an expense of approximately $10 million, excluding gains and losses from non-affiliated investments.

[0001045810-22-000136:8k_2_02:24]
•GAAP and non-GAAP tax rates are expected to be 9.5%, plus or minus 1%, excluding any discrete items.

[0001045810-22-000136:8k_2_02:25]
Highlights

[0001045810-22-000136:8k_2_02:26]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-22-000136:8k_2_02:27]
Data Center

[0001045810-22-000136:8k_2_02:28]
•Second-quarter revenue was $3.81 billion, up 61% from a year ago and up 1% from the previous quarter.

[0001045810-22-000136:8k_2_02:29]
•Announced that NVIDIA Grace™ superchips are being used to create HGX™ systems by some of the world’s leading computer makers — including Atos, Dell Technologies, GIGABYTE, HPE, Inspur, Lenovo and Supermicro.

[0001045810-22-000136:8k_2_02:30]
•Unveiled QODA™, the NVIDIA Quantum Optimized Device Architecture, a unified computing platform for speeding breakthroughs in quantum research and development across AI, HPC, health, finance and other disciplines.

[0001045810-22-000136:8k_2_02:31]
•Provided updates for the NeMo™ Megatron large language model framework that enable training speedups of up to 30%.

[0001045810-22-000136:8k_2_02:32]
•Expanded NVIDIA Fleet Command™ — a cloud service for deploying, managing and scaling AI applications at the edge — with features that enhance the seamless management of edge AI deployments.

[0001045810-22-000136:8k_2_02:33]
•Shared that, in the latest MLPerf training benchmark submissions, NVIDIA and its partners continued to provide the best overall AI training performance and the most submissions across all benchmarks.

[0001045810-22-000136:8k_2_02:34]
Gaming

[0001045810-22-000136:8k_2_02:35]
•Second-quarter revenue was $2.04 billion, down 33% from a year ago and down 44% from the previous quarter.

[0001045810-22-000136:8k_2_02:36]
•Added 30 RTX ON games and apps — including A Plague Tale: Requiem, Evil Dead: The Game and F1 22 — bringing the total available to 280+.

[0001045810-22-000136:8k_2_02:37]
•Increased the number of GeForce® RTX™ and NVIDIA Studio™ laptops to a record 180+, including introduction of the fastest-ever laptops with GeForce RTX 3080 Ti, 2-in-1 convertible gaming laptops and a broad range of Studio laptops.

[0001045810-22-000136:8k_2_02:38]
•Expanded the GeForce NOW™ library with 80 additional games — including Genshin Impact, Evil Dead the Game, Mass Effect Legendary Edition and Loopmancer with RTX — bringing the total to over 1,350.

[0001045810-22-000136:8k_2_02:39]
Professional Visualization

[0001045810-22-000136:8k_2_02:40]
•Second-quarter revenue was $496 million, down 4% from a year ago and down 20% from the previous quarter.

[0001045810-22-000136:8k_2_02:41]
•Expanded its partnership with Siemens to enable the industrial metaverse and increase use of AI-driven digital twin technology.

[0001045810-22-000136:8k_2_02:42]
•Announced Omniverse™ Avatar Cloud Engine, a suite of cloud-native AI models and services that make it easier to build and customize lifelike virtual assistants and digital humans.

[0001045810-22-000136:8k_2_02:43]
•Launched a broad initiative to evolve Universal Scene Description, the open-source and extensible language of 3D worlds, to become a foundation of the open metaverse.

[0001045810-22-000136:8k_2_02:44]
•Announced a major release of Omniverse with new frameworks, tools, apps and plugins, including 11 new connectors to the Omniverse USD ecosystem that bring the total to 112.

[0001045810-22-000136:8k_2_02:45]
•Co-founded the Metaverse Standards Forum to align with other members on the best ways to build the foundations of the metaverse.

[0001045810-22-000136:8k_2_02:46]
Automotive

[0001045810-22-000136:8k_2_02:47]
•Second-quarter revenue was $220 million, up 45% from a year ago and up 59% from the previous quarter.

[0001045810-22-000136:8k_2_02:48]
•Announced rollout plans of new model vehicles using the DRIVE Orin™ compute platform by partners NIO, Li Auto, JIDU, and Human Horizons, as well as Pony.ai’s use of DRIVE Orin across its line of self-driving trucks and robotaxis.

[0001045810-22-000136:8k_2_02:49]
CFO Commentary

[0001045810-22-000136:8k_2_02:50]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-22-000136:8k_2_02:51]
Conference Call and Webcast Information

[0001045810-22-000136:8k_2_02:52]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2023 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2023.

[0001045810-22-000136:8k_2_02:53]
Non-GAAP Measures

[0001045810-22-000136:8k_2_02:54]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP

[0001045810-22-000136:8k_2_02:55]
measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, contributions, IP-related costs, legal settlement costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable, domestication tax benefit, and foreign tax benefit. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-22-000136:8k_2_02:56]
About NVIDIA

[0001045810-22-000136:8k_2_02:57]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics and ignited the era of modern AI. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-22-000136:8k_2_02:58]
###

[0001045810-22-000136:8k_2_02:59]
For further information, contact:

[0001045810-22-000136:8k_2_02:60]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-22-000136:8k_2_02:61]
Certain statements in this press release including, but not limited to, statements as to: plans to continue share repurchases this fiscal year; the company navigating supply chain transitions in a challenging macro environment and getting through it; accelerated computing and AI transforming industries; Automotive becoming a tech industry and being on track to be the company’s next billion-dollar business; advances in AI driving the company’s Data Center business while accelerating breakthroughs; sharing at GTC new advances in RTX as well as breakthroughs in AI and the metaverse; the use of NVIDIA Grace superchips to create HGX systems by some of the world’s leading computer makers; QODA as a unified computing platform for speeding breakthroughs in quantum research and development; the NeMo Megatron large language model framework enabling training speedups; NVIDIA Fleet Command features enhancing management of edge AI deployments; NVIDIA and its partners continuing to provide the best overall AI training performance and the most submissions across all MLPerf training benchmarks; the expanded partnership with Siemens enabling the industrial metaverse and increasing use of AI-driven digital twin technology; Omniverse Avatar Cloud Engine making it easier to build and customize lifelike virtual assistants and digital humans; the initiative to evolve Universal Scene Description to become a foundation of the open metaverse; aligning with other members of the Metaverse Standards Forum on the best ways to build the foundations of the metaverse; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the third quarter of fiscal 2023; expectations that Gaming and Professional Visualization revenue will decline sequentially and be partially offset by sequential growth in Data Center and Automotive; and NVIDIA’s expected tax rates for the third quarter of fiscal 2023 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-22-000136:8k_2_02:62]
© 2022 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA Fleet Command, NVIDIA HGX, NVIDIA Grace, NVIDIA NeMo, NVIDIA Omniverse, NVIDIA QODA and NVIDIA Studio are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000136:8k_2_02:63]
NVIDIA CORPORATION

[0001045810-22-000136:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-22-000136:8k_2_02:65]
(In millions, except per share data)

[0001045810-22-000136:8k_2_02:66]
(Unaudited)

[0001045810-22-000136:8k_2_02:67]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  |  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue | $ | 6,704 |  |  | $ | 6,507 |  |  | $ | 14,992 |  |  | $ | 12,168 |  |
| Cost of revenue | 3,789 |  |  | 2,292 |  |  | 6,646 |  |  | 4,324 |  |
| Gross profit | 2,915 |  |  | 4,215 |  |  | 8,346 |  |  | 7,844 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,824 |  |  | 1,245 |  |  | 3,443 |  |  | 2,398 |  |
|  | Sales, general and administrative | 592 |  |  | 526 |  |  | 1,183 |  |  | 1,046 |  |
|  | Acquisition termination cost | — |  |  | — |  |  | 1,353 |  |  | — |  |
|  |  | Total operating expenses | 2,416 |  |  | 1,771 |  |  | 5,979 |  |  | 3,444 |  |
| Income from operations | 499 |  |  | 2,444 |  |  | 2,367 |  |  | 4,400 |  |
|  | Interest income | 46 |  |  | 6 |  |  | 64 |  |  | 13 |  |
|  | Interest expense | (65) |  |  | (60) |  |  | (132) |  |  | (113) |  |
|  | Other, net | (5) |  |  | 4 |  |  | (19) |  |  | 138 |  |
|  |  | Other income (expense), net | (24) |  |  | (50) |  |  | (87) |  |  | 38 |  |
| Income before income tax | 475 |  |  | 2,394 |  |  | 2,280 |  |  | 4,438 |  |
| Income tax expense (benefit) | (181) |  |  | 20 |  |  | 6 |  |  | 153 |  |
| Net income | $ | 656 |  |  | $ | 2,374 |  |  | $ | 2,274 |  |  | $ | 4,285 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.26 |  |  | $ | 0.95 |  |  | $ | 0.91 |  |  | $ | 1.72 |  |
|  | Diluted | $ | 0.26 |  |  | $ | 0.94 |  |  | $ | 0.90 |  |  | $ | 1.69 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,495 |  |  | 2,493 |  |  | 2,500 |  |  | 2,489 |  |
|  | Diluted | 2,516 |  |  | 2,532 |  |  | 2,526 |  |  | 2,529 |  |

[0001045810-22-000136:8k_2_02:68]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | July 31, |  | January 30, |
|  |  |  |  | 2022 |  | 2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 17,037 |  |  | $ | 21,208 |  |
|  | Accounts receivable, net |  | 5,317 |  |  | 4,650 |  |
|  | Inventories |  | 3,889 |  |  | 2,605 |  |
|  | Prepaid expenses and other current assets |  | 1,175 |  |  | 366 |  |
|  |  | Total current assets |  | 27,418 |  |  | 28,829 |  |
| Property and equipment, net |  | 3,233 |  |  | 2,778 |  |
| Operating lease assets |  | 852 |  |  | 829 |  |
| Goodwill |  | 4,372 |  |  | 4,349 |  |
| Intangible assets, net |  | 2,036 |  |  | 2,339 |  |
| Deferred income tax assets |  | 2,225 |  |  | 1,222 |  |
| Other assets |  | 3,340 |  |  | 3,841 |  |
|  |  | Total assets |  | $ | 43,476 |  |  | $ | 44,187 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 2,421 |  |  | $ | 1,783 |  |
|  | Accrued and other current liabilities |  | 3,903 |  |  | 2,552 |  |
|  | Short-term debt |  | 1,249 |  |  | — |  |
|  |  | Total current liabilities |  | 7,573 |  |  | 4,335 |  |
| Long-term debt |  | 9,700 |  |  | 10,946 |  |
| Long-term operating lease liabilities |  | 743 |  |  | 741 |  |
| Other long-term liabilities |  | 1,609 |  |  | 1,553 |  |
|  |  | Total liabilities |  | 19,625 |  |  | 17,575 |  |
| Shareholders' equity |  | 23,851 |  |  | 26,612 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 43,476 |  |  | $ | 44,187 |  |

[0001045810-22-000136:8k_2_02:69]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 656 |  |  | $ | 2,374 |  |  | $ | 2,274 |  |  | $ | 4,285 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 648 |  |  | 465 |  |  | 1,226 |  |  | 894 |  |
| Depreciation and amortization | 378 |  |  | 286 |  |  | 712 |  |  | 567 |  |
| Losses (gains) on investments in non affiliates, net | 7 |  |  | 1 |  |  | 24 |  |  | (133) |  |
| Deferred income taxes | (443) |  |  | (185) |  |  | (985) |  |  | (161) |  |
| Acquisition termination cost | — |  |  | — |  |  | 1,353 |  |  | — |  |
| Other | (5) |  |  | 18 |  |  | 18 |  |  | 16 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | 120 |  |  | (563) |  |  | (668) |  |  | (1,157) |  |
| Inventories | (725) |  |  | (123) |  |  | (1,285) |  |  | (282) |  |
| Prepaid expenses and other assets | (293) |  |  | 16 |  |  | (1,554) |  |  | 18 |  |
| Accounts payable | 304 |  |  | 209 |  |  | 559 |  |  | 245 |  |
| Accrued and other current liabilities | 633 |  |  | 133 |  |  | 1,267 |  |  | 166 |  |
| Other long-term liabilities | (10) |  |  | 51 |  |  | 60 |  |  | 98 |  |
| Net cash provided by operating activities | 1,270 |  |  | 2,682 |  |  | 3,001 |  |  | 4,556 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 5,036 |  |  | 2,096 |  |  | 10,983 |  |  | 5,236 |  |
| Proceeds from sales of marketable securities | 702 |  |  | 347 |  |  | 1,731 |  |  | 705 |  |
| Purchases of marketable securities | (3,644) |  |  | (4,798) |  |  | (7,576) |  |  | (9,268) |  |
| Purchases related to property and equipment and intangible assets | (433) |  |  | (183) |  |  | (794) |  |  | (481) |  |
| Acquisitions, net of cash acquired | (13) |  |  | — |  |  | (49) |  |  | — |  |
| Investments and other, net | (30) |  |  | 5 |  |  | (65) |  |  | 3 |  |
| Net cash provided by (used in) investing activities | 1,618 |  |  | (2,533) |  |  | 4,230 |  |  | (3,805) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 1 |  |  | 2 |  |  | 205 |  |  | 128 |  |
| Payments related to repurchases of common stock | (3,345) |  |  | — |  |  | (5,341) |  |  | — |  |
| Payments related to tax on restricted stock units | (305) |  |  | (365) |  |  | (837) |  |  | (843) |  |
| Dividends paid | (100) |  |  | (100) |  |  | (200) |  |  | (198) |  |
| Principal payments on property and equipment and intangible assets | (14) |  |  | (21) |  |  | (36) |  |  | (40) |  |
| Issuance of debt, net of issuance costs | — |  |  | 4,985 |  |  | — |  |  | 4,985 |  |
| Other | 1 |  |  | — |  |  | 1 |  |  | (2) |  |
| Net cash provided by (used in) financing activities | (3,762) |  |  | 4,501 |  |  | (6,208) |  |  | 4,030 |  |
| Change in cash and cash equivalents | (874) |  |  | 4,650 |  |  | 1,023 |  |  | 4,781 |  |
| Cash and cash equivalents at beginning of period | 3,887 |  |  | 978 |  |  | 1,990 |  |  | 847 |  |
| Cash and cash equivalents at end of period | $ | 3,013 |  |  | $ | 5,628 |  |  | $ | 3,013 |  |  | $ | 5,628 |  |

[0001045810-22-000136:8k_2_02:70]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 31, |  | May 1, |  | August 1, |  | July 31, |  | August 1, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP gross profit |  | $ | 2,915 |  |  | $ | 5,431 |  |  | $ | 4,215 |  |  | $ | 8,346 |  |  | $ | 7,844 |  |
| GAAP gross margin |  | 43.5 | % |  | 65.5 | % |  | 64.8 | % |  | 55.7 | % |  | 64.5 | % |
|  | Acquisition-related and other costs (A) |  | 121 |  |  | 94 |  |  | 86 |  |  | 214 |  |  | 173 |  |
|  | Stock-based compensation expense (B) |  | 38 |  |  | 38 |  |  | 32 |  |  | 76 |  |  | 57 |  |
|  | IP-related costs |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 9 |  |
| Non-GAAP gross profit |  | $ | 3,074 |  |  | $ | 5,563 |  |  | $ | 4,337 |  |  | $ | 8,636 |  |  | $ | 8,083 |  |
| Non-GAAP gross margin |  | 45.9 | % |  | 67.1 | % |  | 66.7 | % |  | 57.6 | % |  | 66.4 | % |
| GAAP operating expenses |  | $ | 2,416 |  |  | $ | 3,563 |  |  | $ | 1,771 |  |  | $ | 5,979 |  |  | $ | 3,444 |  |
|  | Stock-based compensation expense (B) |  | (611) |  |  | (540) |  |  | (433) |  |  | (1,151) |  |  | (837) |  |
|  | Acquisition-related and other costs (A) |  | (54) |  |  | (55) |  |  | (72) |  |  | (110) |  |  | (152) |  |
|  | Contributions |  | (2) |  |  | — |  |  | — |  |  | (2) |  |  | — |  |
|  | Acquisition termination cost |  | — |  |  | (1,353) |  |  | — |  |  | (1,353) |  |  | — |  |
|  | Legal settlement costs |  | — |  |  | (7) |  |  | — |  |  | (7) |  |  | — |  |
| Non-GAAP operating expenses |  | $ | 1,749 |  |  | $ | 1,608 |  |  | $ | 1,266 |  |  | $ | 3,356 |  |  | $ | 2,455 |  |
| GAAP income from operations |  | $ | 499 |  |  | $ | 1,868 |  |  | $ | 2,444 |  |  | $ | 2,367 |  |  | $ | 4,400 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 826 |  |  | 2,087 |  |  | 627 |  |  | 2,913 |  |  | 1,228 |  |
| Non-GAAP income from operations |  | $ | 1,325 |  |  | $ | 3,955 |  |  | $ | 3,071 |  |  | $ | 5,280 |  |  | $ | 5,628 |  |
| GAAP other income (expense), net |  | $ | (24) |  |  | $ | (63) |  |  | $ | (50) |  |  | $ | (87) |  |  | $ | 38 |  |
|  | (Gains) losses from non-affiliated investments |  | 7 |  |  | 17 |  |  | — |  |  | 24 |  |  | (133) |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Non-GAAP other income (expense), net |  | $ | (16) |  |  | $ | (45) |  |  | $ | (49) |  |  | $ | (61) |  |  | $ | (93) |  |
| GAAP net income |  | $ | 656 |  |  | $ | 1,618 |  |  | $ | 2,374 |  |  | $ | 2,274 |  |  | $ | 4,285 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 833 |  |  | 2,105 |  |  | 628 |  |  | 2,940 |  |  | 1,097 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (197) |  |  | (280) |  |  | (127) |  |  | (478) |  |  | (194) |  |
|  | Domestication tax adjustments |  | — |  |  | — |  |  | (252) |  |  | — |  |  | (252) |  |
| Non-GAAP net income |  | $ | 1,292 |  |  | $ | 3,443 |  |  | $ | 2,623 |  |  | $ | 4,736 |  |  | $ | 4,936 |  |

[0001045810-22-000136:8k_2_02:71]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 31, |  | May 1, |  | August 1, |  | July 31, |  | August 1, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.26 |  |  | $ | 0.64 |  |  | $ | 0.94 |  |  | $ | 0.90 |  |  | $ | 1.69 |  |
|  | Non-GAAP |  | $ | 0.51 |  |  | $ | 1.36 |  |  | $ | 1.04 |  |  | $ | 1.87 |  |  | $ | 1.95 |  |
| Weighted average shares used in diluted net income per share computation |  | 2,516 |  |  | 2,537 |  |  | 2,532 |  |  | 2,527 |  |  | 2,529 |  |
| GAAP net cash provided by operating activities |  | $ | 1,271 |  |  | $ | 1,731 |  |  | $ | 2,682 |  |  | $ | 3,001 |  |  | $ | 4,556 |  |
|  | Purchases related to property and equipment and intangible assets |  | (432) |  |  | (361) |  |  | (183) |  |  | (794) |  |  | (481) |  |
|  | Principal payments on property and equipment |  | (15) |  |  | (22) |  |  | (21) |  |  | (36) |  |  | (40) |  |
| Free cash flow |  | $ | 824 |  |  | $ | 1,348 |  |  | $ | 2,478 |  |  | $ | 2,171 |  |  | $ | 4,035 |  |

[0001045810-22-000136:8k_2_02:72]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs and certain compensation charges presented in the following line items: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 31, |  | May 1, |  | August 1, |  | July 31, |  | August 1, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Cost of revenue |  | $ | 121 |  |  | $ | 94 |  |  | $ | 86 |  |  | $ | 214 |  |  | $ | 173 |  |
|  | Research and development |  | $ | 10 |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 19 |  |  | $ | 4 |  |
|  | Sales, general and administrative |  | $ | 44 |  |  | $ | 46 |  |  | $ | 71 |  |  | $ | 91 |  |  | $ | 148 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | July 31, |  | May 1, |  | August 1, |  | July 31, |  | August 1, |
|  |  |  | 2022 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | Cost of revenue |  | $ | 38 |  |  | $ | 38 |  |  | $ | 32 |  |  | $ | 76 |  |  | $ | 57 |  |
|  | Research and development |  | $ | 452 |  |  | $ | 384 |  |  | $ | 297 |  |  | $ | 836 |  |  | $ | 573 |  |
|  | Sales, general and administrative |  | $ | 159 |  |  | $ | 156 |  |  | $ | 136 |  |  | $ | 315 |  |  | $ | 264 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-22-000136:8k_2_02:73]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2023 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 62.4 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 2.6 | % |
| Non-GAAP gross margin |  | 65.0 | % |
| GAAP operating expenses |  | $ | 2,590 |  |
|  | Stock-based compensation expense and acquisition-related costs | (770) |  |
| Non-GAAP operating expenses |  | $ | 1,820 |  |
