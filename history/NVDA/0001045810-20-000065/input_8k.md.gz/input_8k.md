# NVDA 8-K — 0001045810-20-000063 filed 2020-05-21

## item codes, every 8-K on or before 2020-05-21

- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2020-05-21

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-20-000063:8k_2_02:1]
EX-99.1
2
q1fy21pr.htm
Q1FY21 PRESS RELEASE

[0001045810-20-000063:8k_2_02:2]
Document

[0001045810-20-000063:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-20-000063:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2021

[0001045810-20-000063:8k_2_02:5]
•Revenue of $3.08 billion, up 39 percent from a year earlier

[0001045810-20-000063:8k_2_02:6]
•Record Data Center revenue of $1.14 billion, up 80 percent from a year earlier

[0001045810-20-000063:8k_2_02:7]
•Record GAAP gross margin of 65.1 percent

[0001045810-20-000063:8k_2_02:8]
SANTA CLARA, Calif.-May 21, 2020- NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 26, 2020, of $3.08 billion, up 39 percent from $2.22 billion a year earlier, and down 1 percent from $3.11 billion in the previous quarter.

[0001045810-20-000063:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $1.47, up 130 percent from $0.64 a year ago, and down 4 percent from $1.53 in the previous quarter. Non-GAAP earnings per diluted share were $1.80, up 105 percent from $0.88 a year earlier, and down 5 percent from $1.89 in the previous quarter.

[0001045810-20-000063:8k_2_02:10]
NVIDIA completed its acquisition of Mellanox Technologies Ltd. on April 27, 2020, for a transaction value of $7 billion. It also transitioned its GPU Technology Conference to an all-digital format, drawing more than 55,000 registered participants, while NVIDIA founder and CEO Jensen Huang’s keynote videos were viewed 3.8 million times in their first three days.

[0001045810-20-000063:8k_2_02:11]
“As the world battles COVID-19, we salute the first responders, healthcare workers, and service workers who courageously step in harm’s way to save lives and keep the world going,” Huang said. “We also thank the scientists around the world racing to find a vaccine for COVID-19.

[0001045810-20-000063:8k_2_02:12]
“NVIDIA had an excellent quarter. The acquisition of Mellanox expands our cloud and data center opportunity. We raised the bar for AI computing with the launch and shipment of our Ampere GPU. And our digital GTC conference attracted a record number of developers, highlighting the accelerating adoption of NVIDIA GPU computing.

[0001045810-20-000063:8k_2_02:13]
“Our Data Center business achieved a record and its first $1 billion quarter. NVIDIA is well positioned to advance the most powerful technology forces of our time – cloud computing and AI,” he said.

[0001045810-20-000063:8k_2_02:14]
In the first quarter of fiscal 2021, NVIDIA paid dividends of $98 million. Due to current market uncertainties, NVIDIA is evaluating the timing of resuming share repurchases and will remain nimble based on market conditions. NVIDIA is currently authorized to repurchase up to $7.24 billion in shares through December 2022. It remains committed to paying its quarterly dividend.

[0001045810-20-000063:8k_2_02:15]
Q1 Fiscal 2021 Summary

[0001045810-20-000063:8k_2_02:16]
| GAAP |  |  |  |  |  |
| ($ in millions, except earnings per share) | Q1 FY21 | Q4 FY20 | Q1 FY20 | Q/Q | Y/Y |
| Revenue | $3,080 | $3,105 | $2,220 | Down 1% | Up 39% |
| Gross margin | 65.1 | % | 64.9 | % | 58.4 | % | Up 20 bps | Up 670 bps |
| Operating expenses | $1,028 | $1,025 | $938 | -- | Up 10% |
| Operating income | $976 | $990 | $358 | Down 1% | Up 173% |
| Net income | $917 | $950 | $394 | Down 3% | Up 133% |
| Diluted earnings per share | $1.47 | $1.53 | $0.64 | Down 4% | Up 130% |

[0001045810-20-000063:8k_2_02:17]
| Non-GAAP |  |  |  |  |  |
| ($ in millions, except earnings per share) | Q1 FY21 | Q4 FY20 | Q1 FY20 | Q/Q | Y/Y |
| Revenue | $3,080 | $3,105 | $2,220 | Down 1% | Up 39% |
| Gross margin | 65.8 | % | 65.4 | % | 59.0 | % | Up 40 bps | Up 680 bps |
| Operating expenses | $821 | $810 | $753 | Up 1% | Up 9% |
| Operating income | $1,205 | $1,220 | $557 | Down 1% | Up 116% |
| Net income | $1,120 | $1,172 | $543 | Down 4% | Up 106% |
| Diluted earnings per share | $1.80 | $1.89 | $0.88 | Down 5% | Up 105% |

[0001045810-20-000063:8k_2_02:18]
NVIDIA’s outlook for the second quarter of fiscal 2021 includes the impact from the acquisition of Mellanox, which closed on the first day of the second quarter. The combined second quarter outlook is as follows:

[0001045810-20-000063:8k_2_02:19]
•Revenue is expected to be $3.65 billion, plus or minus 2 percent. Mellanox is expected to contribute a low-teens percentage of combined second quarter revenue.

[0001045810-20-000063:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 58.6 percent and 66.0 percent, respectively, plus or minus 50 basis points. The sequential decline in GAAP gross margins primarily reflects an increase in acquisition-related costs, most of which are non-recurring in nature.

[0001045810-20-000063:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $1.52 billion and $1.04 billion, respectively. The sequential change in GAAP operating expenses reflects an increase in stock-based compensation and acquisition-related costs. GAAP and non-GAAP operating expenses for the full year, which will include Mellanox starting with the second quarter, are expected at approximately $5.7 billion and $4.1 billion, respectively.

[0001045810-20-000063:8k_2_02:22]
•GAAP and non-GAAP other income and expense are expected to be an expense of approximately $50 million and $45 million, respectively.

[0001045810-20-000063:8k_2_02:23]
•GAAP and non-GAAP tax rates are both expected to be 9 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis.

[0001045810-20-000063:8k_2_02:24]
Highlights

[0001045810-20-000063:8k_2_02:25]
Since its previous earnings report, NVIDIA has achieved progress in these areas:

[0001045810-20-000063:8k_2_02:26]
Gaming

[0001045810-20-000063:8k_2_02:27]
•First-quarter revenue was $1.34 billion, down 10 percent sequentially and up 27 percent from a year earlier.

[0001045810-20-000063:8k_2_02:28]
•Launched Minecraft with RTX as an open beta on Windows 10, bringing real-time ray tracing, more realistic materials and DLSS 2.0 to the world’s best-selling videogame.

[0001045810-20-000063:8k_2_02:29]
•Announced the release of more than 100 new laptop models powered by NVIDIA GeForce® GPUs, bringing the RTX 2080 SUPER™ and RTX 2070 SUPER high-end GPUs to laptops for the first time, and enabling RTX 2060 laptop price points as low as $999 for a mass market audience.

[0001045810-20-000063:8k_2_02:30]
•Expanded the RTX Studio lineup with 10 new laptops from Acer, Gigabyte, MSI and Razer, powered by new GeForce RTX SUPER GPUs.

[0001045810-20-000063:8k_2_02:31]
•Released DLSS 2.0, the second generation of its deep learning neural network, which allows gamers on RTX GPUs to boost frame rates as much as two times and increase image resolution for supported games.

[0001045810-20-000063:8k_2_02:32]
•Expanded NVIDIA GeForce NOW™, which provides access to 650 games, with 1,500 more waiting to get on board, and has added 2 million users since going live in February.

[0001045810-20-000063:8k_2_02:33]
Data Center

[0001045810-20-000063:8k_2_02:34]
•First-quarter revenue was $1.14 billion, up 18 percent sequentially and up 80 percent from a year earlier.

[0001045810-20-000063:8k_2_02:35]
•Introduced the NVIDIA A100™ data center GPU, the first based on the new NVIDIA Ampere architecture, now in full production and shipping worldwide.

[0001045810-20-000063:8k_2_02:36]
•Launched the NVIDIA DGX A100™ – a 5-petaflops AI system that delivers elastic, software-defined data center infrastructure for the most demanding workloads – with the first system being used by Argonne National Laboratory on COVID-19 research.

[0001045810-20-000063:8k_2_02:37]
•Introduced two products for the NVIDIA EGX™ Edge AI platform — the EGX A100 for larger commercial off-the-shelf servers – combining the latest A100 GPU and Mellanox SmartNIC technology — and the EGX Jetson Xavier NX for micro-edge servers.

[0001045810-20-000063:8k_2_02:38]
•Released NVIDIA Jarvis™, an application framework enabling companies to offer real-time language-based AI services customized for their own industry, products and customers.

[0001045810-20-000063:8k_2_02:39]
•Collaborated with the open-source community to bring end-to-end GPU acceleration to Apache Spark 3.0, the world’s largest data analytics platform used by more than 500,000 data scientists.

[0001045810-20-000063:8k_2_02:40]
•Announced NVIDIA Merlin™, an application framework that democratizes AI-based deep recommender systems.

[0001045810-20-000063:8k_2_02:41]
•Launched the Mellanox ConnectX-6® Lx Smar tNIC – a highly secure, efficient 25/50 gigabit per second Ethernet smart network interface controller.

[0001045810-20-000063:8k_2_02:42]
Professional Visualization

[0001045810-20-000063:8k_2_02:43]
•First-quarter revenue was $307 million, down 7 percent sequentially and up 15 percent from a year earlier.

[0001045810-20-000063:8k_2_02:44]
•Powered Autodesk’s latest 3D visualization software, VRED 2021, with NVIDIA Quadro RTX — giving designers the ability to create with interactive ray tracing and AI-powered denoising.

[0001045810-20-000063:8k_2_02:45]
•Accelerated Altair’s AccuSolve and TheaRender engineering software with NVIDIA CUDA to speed the creation of high-quality simulations.

[0001045810-20-000063:8k_2_02:46]
•Brought Quadro professional graphics to HP’s ZBook Create and ZBook Studio mobile workstation lineup, offering outstanding performance, mobility and reliability to creatives.

[0001045810-20-000063:8k_2_02:47]
Automotive

[0001045810-20-000063:8k_2_02:48]
•First-quarter revenue was $155 million, down 5 percent sequentially and down 7 percent from a year earlier.

[0001045810-20-000063:8k_2_02:49]
•Announced that the Xpeng P7 all-electric sports sedan, with production deliveries beginning next month, uses the NVIDIA DRIVE AGX platform and DRIVE OS software to deliver level 3 automated driving.

[0001045810-20-000063:8k_2_02:50]
COVID-19 Efforts

[0001045810-20-000063:8k_2_02:51]
•NVIDIA and its employees have committed to donate more than $10 million to those affected during this period.

[0001045810-20-000063:8k_2_02:52]
•Accelerated promotions and raises for employees by several months.

[0001045810-20-000063:8k_2_02:53]
•Released AI models in collaboration with the National Institutes of Health to help researchers detect COVID-19 in lung scans.

[0001045810-20-000063:8k_2_02:54]
•Joined the White House’s COVID-19 High Performance Computing Consortium, alongside leaders from the U.S. government, industry and academia, to accelerate COVID-related research.

[0001045810-20-000063:8k_2_02:55]
•Provided a free 90-day license to NVIDIA Parabricks™, a genomics software stack that uses GPUs to accelerate the analysis of gene-sequencing data, to researchers working on COVID-related topics.

[0001045810-20-000063:8k_2_02:56]
CFO Commentary

[0001045810-20-000063:8k_2_02:57]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, as well as a presentation of first-quarter earnings, are available at http://investor.nvidia.com/.

[0001045810-20-000063:8k_2_02:58]
Conference Call and Webcast Information

[0001045810-20-000063:8k_2_02:59]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2021 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2021.

[0001045810-20-000063:8k_2_02:60]
Non-GAAP Measures

[0001045810-20-000063:8k_2_02:61]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income net, non-GAAP other expense net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, legal settlement costs, losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchase of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-20-000063:8k_2_02:62]
About NVIDIA

[0001045810-20-000063:8k_2_02:63]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI ― the next era of computing ― with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-20-000063:8k_2_02:64]
###

[0001045810-20-000063:8k_2_02:65]
For further information, contact:

[0001045810-20-000063:8k_2_02:66]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-20-000063:8k_2_02:67]
Certain statements in this press release including, but not limited to, statements as to: saluting first responders, healthcare workers and service workers and thanking scientists; Mellanox expanding our cloud and data center opportunities; raising the bar for AI computing with Ampere; digital GTC attracting record attendance and highlighting the accelerating adoption of NVIDIA GPU computing; NVIDIA’s position to advance cloud computing and AI; NVIDIA’s capital return program and evaluating the timing of share repurchases; the impact of COVID-19; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the second quarter of fiscal 2021, including the impact of the Mellanox acquisition; NVIDIA’s expected tax rates for the second quarter of fiscal 2021; NVIDIA’s expectation to generate variability from excess tax benefits or deficiencies; our operating expenses for the full year; Mellanox’s expected contribution to our revenue; NVIDIA projects being used for COVID-19 research; NVIDIA Merlin democratizing AI-based deep recommender systems; and the benefits, abilities and impact of: the RTX Studio lineup and GeForce RTX SUPER GPUs; NVIDIA A100, NVIDIA DGX A100, EGX A100, EGX Jetson Xavier NX, NVIDIA Jarvis, NVIDIA CUDA, Quadro, NVIDIA Parabricks, collaborating with the open-source community for Apache Spark 3.0, Mellanox ConnectX-6 SmartNIC, NVIDIA Merlin, DLSS 2.0 and what it allows, launching Minecraft with RTX, NVIDIA GeForce NOW and Xpeng P7 using NVIDIA DRIVE AGX Xavier AI compute platform and when deliveries will begin; the number of games waiting to get on NVIDIA GeForceNOW; the COVID-19 High Performance Computing Consortium and accelerating COVID-related research; NVIDIA Jarvis enabling companies to offer real-time language-based customized AI-services; global OEMs releasing new laptops, bringing RTX 2080 SUPER and RTX 2070 SUPER GPUs to laptops for the first time and enabling RTX 2060 laptops at low price points; and VRED 2021 giving designers the ability to create with ray tracing and AI-powered denoising are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-20-000063:8k_2_02:68]
© 2020 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Quadro DGX A100, DRIVE AGX Xavier, EGX A100, GeForce NOW, GeForce RTX SUPER, Mellanox ConnectX-6, Mellanox SmartNIC, NVIDIA A100, NVIDIA AGX, NVIDIA CUDA, NVIDIA DGX A100, NVIDIA DRIVE AGX Xavier, NVIDIA EGX Edge AI, NVIDIA EGX Jetson Xavier, NVIDIA Jarvis, NVIDIA Merlin, NVIDIA Parabricks, and NVIDIA RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-20-000063:8k_2_02:69]
NVIDIA CORPORATION

[0001045810-20-000063:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-20-000063:8k_2_02:71]
(In millions, except per share data)

[0001045810-20-000063:8k_2_02:72]
(Unaudited)

[0001045810-20-000063:8k_2_02:73]
|  |  |  | Three Months Ended |  |  |  |  |  |  |
|  |  |  | April 26, |  | April 28, |  |  |  |  |
|  |  |  | 2020 |  | 2019 |  |  |  |  |
| Revenue |  |  | $ | 3,080 |  |  | $ | 2,220 |  |  |  |  |  |
| Cost of revenue |  |  | 1,076 |  |  | 924 |  |  |  |  |  |
| Gross profit |  |  | 2,004 |  |  | 1,296 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |
|  | Research and development |  | 735 |  |  | 674 |  |  |  |  |  |
|  | Sales, general and administrative |  | 293 |  |  | 264 |  |  |  |  |  |
|  |  | Total operating expenses | 1,028 |  |  | 938 |  |  |  |  |  |
| Income from operations |  |  | 976 |  |  | 358 |  |  |  |  |  |
|  | Interest income |  | 31 |  |  | 44 |  |  |  |  |  |
|  | Interest expense |  | (25) |  |  | (13) |  |  |  |  |  |
|  | Other, net |  | (1) |  |  | — |  |  |  |  |  |
|  |  | Other income, net | 5 |  |  | 31 |  |  |  |  |  |
| Income before income tax |  |  | 981 |  |  | 389 |  |  |  |  |  |
| Income tax expense (benefit) |  |  | 64 |  |  | (5) |  |  |  |  |  |
| Net income |  |  | $ | 917 |  |  | $ | 394 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
|  | Basic |  | $ | 1.49 |  |  | $ | 0.65 |  |  |  |  |  |
|  | Diluted |  | $ | 1.47 |  |  | $ | 0.64 |  |  |  |  |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |  |  |
|  | Basic |  | 614 |  |  | 607 |  |  |  |  |  |
|  | Diluted |  | 622 |  |  | 616 |  |  |  |  |  |

[0001045810-20-000063:8k_2_02:74]
| NVIDIA CORPORATION |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |  |  |  |
| (In millions) |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |
|  |  |  |  | April 26, |  | January 26, |
|  |  |  |  | 2020 |  | 2020 |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  |  | $ | 16,354 |  |  | $ | 10,897 |  |
|  | Accounts receivable, net |  |  | 1,907 |  |  | 1,657 |  |
|  | Inventories |  |  | 1,128 |  |  | 979 |  |
|  | Prepaid expenses and other current assets |  |  | 195 |  |  | 157 |  |
|  |  | Total current assets |  | 19,584 |  |  | 13,690 |  |
| Property and equipment, net |  |  |  | 1,715 |  |  | 1,674 |  |
| Operating lease assets |  |  |  | 595 |  |  | 618 |  |
| Goodwill |  |  |  | 628 |  |  | 618 |  |
| Intangible assets, net |  |  |  | 80 |  |  | 49 |  |
| Deferred income tax assets |  |  |  | 533 |  |  | 548 |  |
| Other assets |  |  |  | 119 |  |  | 118 |  |
|  |  | Total assets |  | $ | 23,254 |  |  | $ | 17,315 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
|  | Accounts payable |  |  | $ | 761 |  |  | $ | 687 |  |
|  | Accrued and other current liabilities |  |  | 1,142 |  |  | 1,097 |  |
|  |  | Total current liabilities |  | 1,903 |  |  | 1,784 |  |
| Long-term debt |  |  |  | 6,959 |  |  | 1,991 |  |
| Long-term operating lease liabilities |  |  |  | 519 |  |  | 561 |  |
| Other long-term liabilities |  |  |  | 774 |  |  | 775 |  |
|  |  | Total liabilities |  | 10,155 |  |  | 5,111 |  |
| Shareholders' equity |  |  |  | 13,099 |  |  | 12,204 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 23,254 |  |  | $ | 17,315 |  |

[0001045810-20-000063:8k_2_02:75]
| NVIDIA CORPORATION |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |  |  |  |  |
| (In millions) |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26, |  | April 28, |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 917 |  |  |  | $ | 394 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 224 |  |  |  | 178 |  |  |  |  |  |
| Depreciation and amortization | 107 |  |  |  | 91 |  |  |  |  |  |
| Deferred income taxes | 16 |  |  |  | (42) |  |  |  |  |  |
| Other | 4 |  |  |  | (2) |  |  |  |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | (249) |  |  |  | 182 |  |  |  |  |  |
| Inventories | (151) |  |  |  | 153 |  |  |  |  |  |
| Prepaid expenses and other assets | (8) |  |  |  | 5 |  |  |  |  |  |
| Accounts payable | 71 |  |  |  | (123) |  |  |  |  |  |
| Accrued and other current liabilities | (32) |  |  |  | (129) |  |  |  |  |  |
| Other long-term liabilities | 10 |  |  |  | 13 |  |  |  |  |  |
| Net cash provided by operating activities |  | 909 |  |  |  | 720 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from sales of marketable securities | 1 |  |  |  | 26 |  |  |  |  |  |
| Proceeds from maturities of marketable securities | — |  |  |  | 2,219 |  |  |  |  |  |
| Purchases of marketable securities | (861) |  |  |  | (622) |  |  |  |  |  |
| Purchases of property and equipment and intangible assets | (155) |  |  |  | (128) |  |  |  |  |  |
| Acquisition of business, net of cash acquired | (34) |  |  |  | — |  |  |  |  |  |
| Investments and other, net | (6) |  |  |  | — |  |  |  |  |  |
| Net cash provided by (used in) investing activities |  | (1,055) |  |  |  | 1,495 |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Issuance of debt, net of issuance costs | 4,979 |  |  |  | — |  |  |  |  |  |
| Proceeds related to employee stock plans | 88 |  |  |  | 83 |  |  |  |  |  |
| Payments related to tax on restricted stock units | (222) |  |  |  | (211) |  |  |  |  |  |
| Dividends paid | (98) |  |  |  | (97) |  |  |  |  |  |
| Other | (3) |  |  |  | — |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  | 4,744 |  |  |  | (225) |  |  |  |  |  |
| Change in cash and cash equivalents | 4,598 |  |  |  | 1,990 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 10,896 |  |  |  | 782 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 15,494 |  |  |  | $ | 2,772 |  |  |  |  |  |

[0001045810-20-000063:8k_2_02:76]
|  | NVIDIA CORPORATION |  |  |  |  |  |  |  |  |  |  |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |  |  |  |  |  |  |  |  |  |  |
|  | (In millions, except per share data) |  |  |  |  |  |  |  |  |  |  |
|  | (Unaudited) |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  |  |  |  |  |  |  |  |
|  |  |  | April 26, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2020 |  | 2020 |  | 2019 |  |  |  |  |
| GAAP gross profit |  |  | $ | 2,004 |  |  | $ | 2,015 |  |  | $ | 1,296 |  |  |  |  |  |
| GAAP gross margin |  |  | 65.1 | % |  | 64.9 | % |  | 58.4 | % |  |  |  |  |
|  | Stock-based compensation expense (A) |  | 21 |  |  | 12 |  |  | 4 |  |  |  |  |  |
|  | Acquisition-related and other costs |  | 1 |  |  | — |  |  | — |  |  |  |  |  |
|  | Legal settlement costs |  | — |  |  | 3 |  |  | 10 |  |  |  |  |  |
| Non-GAAP gross profit |  |  | $ | 2,026 |  |  | $ | 2,030 |  |  | $ | 1,310 |  |  |  |  |  |
| Non-GAAP gross margin |  |  | 65.8 | % |  | 65.4 | % |  | 59.0 | % |  |  |  |  |
| GAAP operating expenses |  |  | $ | 1,028 |  |  | $ | 1,025 |  |  | $ | 938 |  |  |  |  |  |
|  | Stock-based compensation expense (A) |  | (203) |  |  | (208) |  |  | (174) |  |  |  |  |  |
|  | Acquisition-related and other costs |  | (4) |  |  | (7) |  |  | (10) |  |  |  |  |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | (1) |  |  |  |  |  |
| Non-GAAP operating expenses |  |  | $ | 821 |  |  | $ | 810 |  |  | $ | 753 |  |  |  |  |  |
| GAAP income from operations |  |  | $ | 976 |  |  | $ | 990 |  |  | $ | 358 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 229 |  |  | 230 |  |  | 199 |  |  |  |  |  |
| Non-GAAP income from operations |  |  | $ | 1,205 |  |  | $ | 1,220 |  |  | $ | 557 |  |  |  |  |  |
| GAAP other income, net |  |  | $ | 5 |  |  | $ | 26 |  |  | $ | 31 |  |  |  |  |  |
|  | Losses from non-affiliated investments |  | 3 |  |  | — |  |  | — |  |  |  |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP other income, net |  |  | $ | 9 |  |  | $ | 26 |  |  | $ | 31 |  |  |  |  |  |
| GAAP net income |  |  | $ | 917 |  |  | $ | 950 |  |  | $ | 394 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 232 |  |  | 230 |  |  | 199 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments (B) |  | (29) |  |  | (8) |  |  | (50) |  |  |  |  |  |
| Non-GAAP net income |  |  | $ | 1,120 |  |  | $ | 1,172 |  |  | $ | 543 |  |  |  |  |  |

[0001045810-20-000063:8k_2_02:77]
|  |  |  | Three Months Ended |  |  |  |  |  |  |  |  |
|  |  |  | April 26, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2020 |  | 2020 |  | 2019 |  |  |  |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 1.47 |  |  | $ | 1.53 |  |  | $ | 0.64 |  |  |  |  |  |
|  | Non-GAAP |  | $ | 1.80 |  |  | $ | 1.89 |  |  | $ | 0.88 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation |  |  | 622 |  |  | 621 |  |  | 616 |  |  |  |  |  |
| GAAP net cash provided by operating activities |  |  | $ | 909 |  |  | $ | 1,465 |  |  | $ | 720 |  |  |  |  |  |
|  | Purchase of property and equipment and intangible assets |  | (155) |  |  | (144) |  |  | (128) |  |  |  |  |  |
| Free cash flow |  |  | $ | 754 |  |  | $ | 1,321 |  |  | $ | 592 |  |  |  |  |  |

[0001045810-20-000063:8k_2_02:78]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  |  |  |  |  |  |  |  |
|  |  |  | April 26, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2020 |  | 2020 |  | 2019 |  |  |  |  |
|  | Cost of revenue |  | $ | 21 |  |  | $ | 12 |  |  | $ | 4 |  |  |  |  |  |
|  | Research and development |  | $ | 134 |  |  | $ | 140 |  |  | $ | 114 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 69 |  |  | $ | 68 |  |  | $ | 60 |  |  |  |  |  |
| (B) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |  |  |  |  |  |  |  |  |  |  |

[0001045810-20-000063:8k_2_02:79]
| NVIDIA CORPORATION |  |  |  |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |  |  |  |
|  |  |  | Q2 FY2021 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  |  | 58.6 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs |  | 7.4 | % |
| Non-GAAP gross margin |  |  | 66.0 | % |
| GAAP operating expenses |  |  | $ | 1,515 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (475) |  |
| Non-GAAP operating expenses |  |  | $ | 1,040 |  |
| GAAP other expense, net |  |  | $ | 50 |  |
|  | Interest expense from amortization of debt discount and other costs |  | (5) |  |
| Non-GAAP other expense, net |  |  | $ | 45 |  |
|  |  |  | FY2021 Outlook |
|  |  |  | ($ in millions) |
| GAAP operating expenses |  |  | $ | 5,700 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (1,600) |  |
| Non-GAAP operating expenses |  |  | $ | 4,100 |  |
