# NVDA notes — 0001045810-20-000065


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-20-000065:notes:1]
[same as prior period, unchanged from 0001045810-19-000170:notes:1]

[0001045810-20-000065:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 26, 2020 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

[0001045810-20-000065:notes:3]
[same as prior period, unchanged from 0001045810-19-000170:notes:3]

[0001045810-20-000065:notes:4]
There have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

[0001045810-20-000065:notes:5]
[same as prior period, unchanged from 0001045810-19-000170:notes:10]

[0001045810-20-000065:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The first quarters of fiscal years 2021 and 2020 were both 13-week quarters.

[0001045810-20-000065:notes:7]
[same as prior period, unchanged from 0001045810-19-000170:notes:12]

[0001045810-20-000065:notes:8]
[same as prior period, unchanged from 0001045810-19-000170:notes:13]

[0001045810-20-000065:notes:9]
[same as prior period, unchanged from 0001045810-19-000170:notes:14]

[0001045810-20-000065:notes:10]
[same as prior period, unchanged from 0001045810-19-000170:notes:15]

[0001045810-20-000065:notes:11]
[same as prior period, unchanged from 0001045810-19-000170:notes:16]

[0001045810-20-000065:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19 on our critical and significant accounting estimates. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-20-000065:notes:13]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000065:notes:14]
Recently Adopted Accounting Pronouncement

[0001045810-20-000065:notes:15]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. The Company adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to the Company's consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-20-000065:notes:16]
Acquisition of Mellanox Technologies, Ltd.Subsequent to the end of the first quarter of fiscal year 2021, we closed the acquisition of Mellanox Technologies Ltd., or Mellanox, for a transaction value of approximately $7.0 billion in cash on April 27, 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-20-000065:notes:17]
Leases
Our lease obligations consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2021 and 2035.

[0001045810-20-000065:notes:18]
Future minimum lease payments under our non-cancelable operating leases as of April 26, 2020, are as follows:

[0001045810-20-000065:notes:19]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2021 (excluding first quarter of fiscal year 2021) | $ | 90 |  |
| 2022 | 116 |  |
| 2023 | 102 |  |
| 2024 | 78 |  |
| 2025 | 61 |  |
| 2026 and thereafter | 289 |  |
| Total | 736 |  |
| Less imputed interest | 117 |  |
| Present value of net future minimum lease payments | 619 |  |
| Less short-term operating lease liabilities | 100 |  |
| Long-term operating lease liabilities | $ | 519 |  |

[0001045810-20-000065:notes:20]
Operating lease expense for the first quarters of fiscal years 2021 and 2020 was $31 million and $27 million, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2021 and 2020 were not significant.

[0001045810-20-000065:notes:21]
[same as prior period, unchanged from 0001045810-19-000170:notes:35]

[0001045810-20-000065:notes:22]
|  | Three Months Ended |  |  |
|  | April 26, 2020 |  |  |
|  | (In millions) |  |  |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 31 |  |  |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 3 |  |  |  |

[0001045810-20-000065:notes:23]
As of April 26, 2020, our operating leases had a weighted average remaining lease term of 8.2 years and a weighted average discount rate of 3.45%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-20-000065:notes:24]
[same as prior period, unchanged from 0001045810-19-000170:notes:38]

[0001045810-20-000065:notes:25]
[same as prior period, unchanged from 0001045810-19-000170:notes:39]

[0001045810-20-000065:notes:26]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26,2020 |  | April 28,2019 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |
| Cost of revenue | $ | 21 |  |  | $ | 4 |  |  |  |  |  |
| Research and development | 134 |  |  | 114 |  |  |  |  |  |
| Sales, general and administrative | 69 |  |  | 60 |  |  |  |  |  |
| Total | $ | 224 |  |  | $ | 178 |  |  |  |  |  |

[0001045810-20-000065:notes:27]
[same as prior period, unchanged from 0001045810-19-000170:notes:41]

[0001045810-20-000065:notes:28]
[same as prior period, unchanged from 0001045810-19-000170:notes:42]

[0001045810-20-000065:notes:29]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |  |  |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |  |  |  |  |  |  |
| Balances, January 26, 2020 | 14 |  |  | $ | 176.72 |  |  |  |  |  |
| Granted | 1 |  |  | $ | 254.61 |  |  |  |  |  |
| Vested restricted stock | (3) |  |  | $ | 144.27 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 161.66 |  |  |  |  |  |
| Balances, April 26, 2020 | 11 |  |  | $ | 191.23 |  |  |  |  |  |

[0001045810-20-000065:notes:30]
As of April 26, 2020, there was $1.81 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.4 years for RSUs, PSUs, and market-based PSUs, and 0.8 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-20-000065:notes:31]
[same as prior period, unchanged from 0001045810-19-000170:notes:47]

[0001045810-20-000065:notes:32]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26, |  | April 28, |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In millions, except per share data) |  |  |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 917 |  |  | $ | 394 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 614 |  |  | 607 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 8 |  |  | 9 |  |  |  |  |  |
| Diluted weighted average shares | 622 |  |  | 616 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.49 |  |  | $ | 0.65 |  |  |  |  |  |
| Diluted (2) | $ | 1.47 |  |  | $ | 0.64 |  |  |  |  |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 1 |  |  | 11 |  |  |  |  |  |

[0001045810-20-000065:notes:33]
(1) Calculated as net income divided by basic weighted average shares.

[0001045810-20-000065:notes:34]
(2) Calculated as net income divided by diluted weighted average shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-20-000065:notes:35]
Income Taxes
We recognized an income tax expense of $64 million for the first quarter of fiscal year 2021 and income tax benefit of $5 million for the first quarter of fiscal year 2020. The income tax expense as a percentage of income before income tax was 6.6% for the first quarter of fiscal year 2021 and income tax benefit as a percentage of income before income tax was 1.3% for the first quarter of fiscal year 2020.

[0001045810-20-000065:notes:36]
The increase in our effective tax rate for the first quarter of fiscal year 2021 as compared to the first quarter of fiscal year 2020 was primarily due to a decrease of tax benefits from stock-based compensation.

[0001045810-20-000065:notes:37]
Our effective tax rates for the first quarter of fiscal years 2021 and 2020 were lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-20-000065:notes:38]
For the first quarter of fiscal year 2021, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 26, 2020.

[0001045810-20-000065:notes:39]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.  As of April 26, 2020, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-20-000065:notes:40]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-20-000065:notes:41]
The following is a summary of cash equivalents and marketable securities as of April 26, 2020 and January 26, 2020:

[0001045810-20-000065:notes:42]
|  | April 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 11,128 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,128 |  |  | $ | 11,128 |  |  | $ | — |  |
| Corporate debt securities | 3,238 |  |  | — |  |  | — |  |  | 3,238 |  |  | 2,951 |  |  | 287 |  |
| Foreign government bonds | 870 |  |  | — |  |  | — |  |  | 870 |  |  | 870 |  |  | — |  |
| Certificates of deposit | 582 |  |  | — |  |  | — |  |  | 582 |  |  | 222 |  |  | 360 |  |
| Debt securities issued by United States government agencies | 381 |  |  | — |  |  | — |  |  | 381 |  |  | 168 |  |  | 213 |  |
| Total | $ | 16,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 16,199 |  |  | $ | 15,339 |  |  | $ | 860 |  |

[0001045810-20-000065:notes:43]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  |  |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

[0001045810-20-000065:notes:44]
The amortized cost and estimated fair value of cash equivalents and marketable securities of $16.20 billion and $10.78 billion as of April 26, 2020 and January 26, 2020, respectively, are all related to contracts with maturities of less than one year. Unrealized gains and losses were not significant for all periods presented. For the first quarter of fiscal years 2021 and 2020, net realized gains were not significant.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-20-000065:notes:45]
Fair Value of Financial Assets and LiabilitiesThe fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-20-000065:notes:46]
|  |  |  | Fair Value at |  |  |
|  | Pricing Category |  | April 26, 2020 |  | January 26, 2020 |
|  |  |  | (In millions) |  |  |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 11,128 |  |  | $ | 7,507 |  |
| Corporate debt securities | Level 2 |  | $ | 3,238 |  |  | $ | 592 |  |
| Foreign government bonds | Level 2 |  | $ | 870 |  |  | $ | 200 |  |
| Certificates of deposit | Level 2 |  | $ | 582 |  |  | $ | 27 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 381 |  |  | $ | 1,096 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | — |  |  | $ | 1,358 |  |
| Asset-backed securities | Level 2 |  | $ | — |  |  | $ | 1 |  |
| Liabilities |  |  |  |  |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 1,020 |  |  | $ | 1,065 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 1,104 |  |  | $ | 1,006 |  |
| 2.85% Notes Due 2030 (1) | Level 2 |  | $ | 1,635 |  |  | $ | — |  |
| 3.50% Notes Due 2040 (1) | Level 2 |  | $ | 1,134 |  |  | $ | — |  |
| 3.50% Notes Due 2050 (1) | Level 2 |  | $ | 2,336 |  |  | $ | — |  |
| 3.70% Notes Due 2060 (1) | Level 2 |  | $ | 594 |  |  | $ | — |  |

[0001045810-20-000065:notes:47]
(1)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance   costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-20-000065:notes:48]
[same as prior period, unchanged from 0001045810-19-000170:notes:68]

[0001045810-20-000065:notes:49]
|  | April 26, 2020 |  |  |  |  |  | January 26, 2020 |  |  |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  |  |  |  |  | (In millions) |  |  |  |  |
| Acquisition-related intangible assets | $ | 231 |  |  | $ | (195) |  |  | $ | 36 |  |  | $ | 195 |  |  | $ | (192) |  |  | $ | 3 |  |
| Patents and licensed technology | 522 |  |  | (478) |  |  | 44 |  |  | 520 |  |  | (474) |  |  | 46 |  |
| Total intangible assets | $ | 753 |  |  | $ | (673) |  |  | $ | 80 |  |  | $ | 715 |  |  | $ | (666) |  |  | $ | 49 |  |

[0001045810-20-000065:notes:50]
Amortization expense associated with intangible assets was $7 million for both the first quarters of fiscal years 2021 and 2020. Future amortization expense related to the net carrying amount of intangible assets as of April 26, 2020 is estimated to be $20 million for the remainder of fiscal year 2021, $21 million in fiscal year 2022, $18 million in fiscal year 2023, $12 million in fiscal year 2024, $7 million in fiscal year 2025, and $2 million in fiscal year 2026 and thereafter.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-20-000065:notes:51]
[same as prior period, unchanged from 0001045810-19-000170:notes:71]

[0001045810-20-000065:notes:52]
|  | April 26, |  | January 26, |
|  | 2020 |  | 2020 |
| Inventories: | (In millions) |  |  |
| Raw materials | $ | 341 |  |  | $ | 249 |  |
| Work in-process | 287 |  |  | 265 |  |
| Finished goods | 500 |  |  | 465 |  |
| Total inventories | $ | 1,128 |  |  | $ | 979 |  |

[0001045810-20-000065:notes:53]
|  | April 26, |  | January 26, |
|  | 2020 |  | 2020 |
| Accrued and Other Current Liabilities: | (In millions) |  |  |
| Customer program accruals | $ | 444 |  |  | $ | 462 |  |
| Deferred revenue (1) | 174 |  |  | 141 |  |
| Accrued payroll and related expenses | 164 |  |  | 185 |  |
| Operating lease liabilities | 100 |  |  | 91 |  |
| Licenses and royalties | 78 |  |  | 66 |  |
| Taxes payable | 74 |  |  | 61 |  |
| Product warranty and return provisions | 25 |  |  | 24 |  |
| Professional service fee | 20 |  |  | 18 |  |
| Other | 63 |  |  | 49 |  |
| Total accrued and other current liabilities | $ | 1,142 |  |  | $ | 1,097 |  |

[0001045810-20-000065:notes:54]
(1) Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and post contract customer support, or PCS.

[0001045810-20-000065:notes:55]
|  | April 26, |  | January 26, |
|  | 2020 |  | 2020 |
| Other Long-Term Liabilities: | (In millions) |  |  |
| Income tax payable (1) | $ | 535 |  |  | $ | 528 |  |
| Licenses payable | 84 |  |  | 110 |  |
| Deferred revenue (2) | 67 |  |  | 60 |  |
| Deferred income tax liability |  | 32 |  |  | 29 |  |
| Employee benefits liability | 23 |  |  | 22 |  |
| Other | 33 |  |  | 26 |  |
| Total other long-term liabilities | $ | 774 |  |  | $ | 775 |  |

[0001045810-20-000065:notes:56]
(1) As of April 26, 2020, income tax payable represents the long-term portion of the one-time transition tax payable of $317 million, as well as unrecognized tax benefits of $185 million and related interest and penalties of $33 million.

[0001045810-20-000065:notes:57]
(2) Deferred revenue primarily includes deferrals related to PCS.

[0001045810-20-000065:notes:58]
[same as prior period, unchanged from 0001045810-19-000170:notes:78]

[0001045810-20-000065:notes:59]
The following table shows the changes in deferred revenue during the first quarter of fiscal years 2021 and 2020:

[0001045810-20-000065:notes:60]
|  | April 26, |  | April 28, |
|  | 2020 |  | 2019 |
|  | (In millions) |  |  |
| Balance at beginning of period | $ | 201 |  |  | $ | 138 |  |
| Deferred revenue added during the period | 110 |  |  | 49 |  |
| Revenue recognized during the period | (70) |  |  | (53) |  |
| Balance at end of period | $ | 241 |  |  | $ | 134 |  |

[0001045810-20-000065:notes:61]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of April 26, 2020, the amount of our remaining performance obligations that has not been recognized as revenue was $389 million, of which we expect to recognize approximately 47% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-20-000065:notes:62]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of April 26, 2020 and January 26, 2020.

[0001045810-20-000065:notes:63]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than the U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-20-000065:notes:64]
The table below presents the notional value of our foreign currency forward contracts outstanding as of April 26, 2020 and January 26, 2020:

[0001045810-20-000065:notes:65]
|  | April 26,2020 |  | January 26,2020 |
|  | (In millions) |  |  |
| Designated as cash flow hedges | $ | 432 |  |  | $ | 428 |  |
| Not designated for hedge accounting | $ | 244 |  |  | $ | 287 |  |

[0001045810-20-000065:notes:66]
As of April 26, 2020, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-20-000065:notes:67]
During the first quarter of fiscal years 2021 and 2020, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-20-000065:notes:68]
Debt
Long-Term Debt

[0001045810-20-000065:notes:69]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and estimated issuance costs.

[0001045810-20-000065:notes:70]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-20-000065:notes:71]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-20-000065:notes:72]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-20-000065:notes:73]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.9 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.9 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 30.0 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 40.0 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (41) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,959 |  |  | $ | 1,991 |  |

[0001045810-20-000065:notes:74]
The Notes require the Company to comply with certain covenants for which the Company was in compliance as of April 26, 2020.

[0001045810-20-000065:notes:75]
Revolving Credit Facility

[0001045810-20-000065:notes:76]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 26, 2020, we had not borrowed any amounts under this agreement.

[0001045810-20-000065:notes:77]
The Credit Agreement governing the revolving credit facility requires the Company to comply with a leverage ratio covenant. As of April 26, 2020, the Company was in compliance with this financial covenant.

[0001045810-20-000065:notes:78]
Commercial Paper

[0001045810-20-000065:notes:79]
We have a $575 million commercial paper program to support general corporate purposes. As of April 26, 2020, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-20-000065:notes:80]
Commitments and Contingencies
Purchase Obligations

[0001045810-20-000065:notes:81]
As of April 26, 2020, we had outstanding inventory purchase obligations totaling $1.76 billion and other purchase obligations totaling $287 million.

[0001045810-20-000065:notes:82]
Accrual for Product Warranty Liabilities

[0001045810-20-000065:notes:83]
The estimated amount of product returns and warranty liabilities was $16 million and $15 million as of April 26, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.

[0001045810-20-000065:notes:84]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-20-000065:notes:85]
Litigation

[0001045810-20-000065:notes:86]
Securities Class Action and Derivative Lawsuits

[0001045810-20-000065:notes:87]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants. On March 16, 2020, the Court issued an order dismissing the consolidated class action complaint with leave to amend.  The plaintiffs filed an amended complaint on May 13, 2020.

[0001045810-20-000065:notes:88]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The Court approved the parties’ stipulation to stay the

[0001045810-20-000065:notes:89]
In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-20-000065:notes:90]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the Court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of the motion to dismiss filed by NVIDIA in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-20-000065:notes:91]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-20-000065:notes:92]
Accounting for Loss Contingencies

[0001045810-20-000065:notes:93]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of April 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-20-000065:notes:94]
[same as prior period, unchanged from 0001045810-19-000170:notes:116]

[0001045810-20-000065:notes:95]
[same as prior period, unchanged from 0001045810-19-000170:notes:117]

[0001045810-20-000065:notes:96]
Through April 26, 2020, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of April 26, 2020, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-20-000065:notes:97]
During the first quarter of fiscal year 2021, we paid $98 million in cash dividends to our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-20-000065:notes:98]
Segment Information
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. Previously, we had reported two operating segments: GPU and Tegra Processor. During the first quarter of fiscal year 2021, we changed our operating segments to be consistent with the revised manner in which our CODM reviews our financial performance and allocates resources. The two new operating segments are "Graphics" and "Compute & Networking". Comparative periods presented reflect this change. Our operating segments are equivalent to our reportable segments.

[0001045810-20-000065:notes:99]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro GPUs for enterprise design; GRID software for cloud-based visual and virtual computing; and automotive platforms for infotainment systems. Our Compute & Networking segment includes Data Center platforms and systems for artificial intelligence, or AI, high performance computing, or HPC, and accelerated computing; DRIVE for autonomous vehicles; and Jetson for robotics and other embedded platforms.

[0001045810-20-000065:notes:100]
Operating results by segment include costs or expenses that are directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

[0001045810-20-000065:notes:101]
The “All Other” category includes the expenses that our CODM does not assign to either Graphics or Compute & Networking for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-20-000065:notes:102]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-20-000065:notes:103]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |  |  |  |  |  |  |
| Three Months Ended April 26, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 1,906 |  |  | $ | 1,174 |  |  | $ | — |  |  | $ | 3,080 |  |
| Operating income (loss) | $ | 836 |  |  | $ | 451 |  |  | $ | (311) |  |  | $ | 976 |  |
| Three Months Ended April 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,526 |  |  | $ | 694 |  |  | $ | — |  |  | $ | 2,220 |  |
| Operating income (loss) | $ | 532 |  |  | $ | 95 |  |  | $ | (269) |  |  | $ | 358 |  |

[0001045810-20-000065:notes:104]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26,2020 |  | April 28,2019 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (224) |  |  | $ | (178) |  |  |  |  |  |
| Unallocated cost of revenue and operating expenses | (82) |  |  | (70) |  |  |  |  |  |
| Acquisition-related and other costs | (5) |  |  | (10) |  |  |  |  |  |
| Legal settlement costs | — |  |  | (11) |  |  |  |  |  |
| Total | $ | (311) |  |  | $ | (269) |  |  |  |  |  |

[0001045810-20-000065:notes:105]
[same as prior period, unchanged from 0001045810-19-000170:notes:133]

[0001045810-20-000065:notes:106]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26, |  | April 28, |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 813 |  |  | $ | 698 |  |  |  |  |  |
| China (including Hong Kong) | 758 |  |  | 553 |  |  |  |  |  |
| Other Asia Pacific | 607 |  |  | 422 |  |  |  |  |  |
| United States | 497 |  |  | 165 |  |  |  |  |  |
| Europe | 254 |  |  | 249 |  |  |  |  |  |
| Other countries | 151 |  |  | 133 |  |  |  |  |  |
| Total revenue | $ | 3,080 |  |  | $ | 2,220 |  |  |  |  |  |

[0001045810-20-000065:notes:107]
[same as prior period, unchanged from 0001045810-19-000170:notes:135]

[0001045810-20-000065:notes:108]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26, |  | April 28, |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,339 |  |  | $ | 1,055 |  |  |  |  |  |
| Professional Visualization | 307 |  |  | 266 |  |  |  |  |  |
| Data Center | 1,141 |  |  | 634 |  |  |  |  |  |
| Automotive | 155 |  |  | 166 |  |  |  |  |  |
| OEM and Other | 138 |  |  | 99 |  |  |  |  |  |
| Total revenue | $ | 3,080 |  |  | $ | 2,220 |  |  |  |  |  |

[0001045810-20-000065:notes:109]
No customer represented 10% or more of total revenue for the first quarter of fiscal year 2021. One customer represented 11% of our total revenue for the first quarter of fiscal year 2020, and was attributable primarily to the Graphics segment.

[0001045810-20-000065:notes:110]
One customer represented 15% and 21% of our accounts receivable balance as of April 26, 2020 and January 26, 2020, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-20-000065:notes:111]
Goodwill During the first quarter of fiscal year 2021, we changed our operating segments to Graphics and Compute & Networking, as discussed in Note 15 of these Notes to Condensed Consolidated Financial Statements. As a result, our reporting units also changed, and we have reassigned the goodwill balance to the new reporting units based on their relative fair values. We determined there was no goodwill impairment immediately prior to the reorganization. As of April 26, 2020, the total carrying amount of goodwill was $628 million and the amount of goodwill allocated to our Graphics and Compute & Networking reporting units were $347 million and $281 million, respectively. In the first quarter of fiscal year 2021, goodwill increased by $10 million related to acquisition activity.
