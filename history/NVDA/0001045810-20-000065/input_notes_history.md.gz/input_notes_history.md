# NVDA note change history — 0001045810-19-000170 → 0001045810-20-000065


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-21):
[0001045810-20-000065:note_history:1]
As of April 26, 2020, we had outstanding inventory purchase obligations totaling $1.76 billion and other purchase obligations totaling $287 million.
  (was, 2019-11-14, similarity 0.9565):
[0001045810-19-000170:note_history:1]
As of October 27, 2019, we had outstanding inventory purchase obligations totaling $980 million and other purchase obligations totaling $138 million.

- changed (2020-05-21):
[0001045810-20-000065:note_history:2]
The estimated amount of product returns and warranty liabilities was $16 million and $15 million as of April 26, 2020 and January 26, 2020, respectively, and the activities related to the warranty liabilities were not significant.
  (was, 2019-11-14, similarity 0.8525):
[0001045810-19-000170:note_history:2]
The estimated amount of product returns and warranty liabilities was $17 million and $18 million as of October 27, 2019 and January 27, 2019, respectively, and the activity related to the warranty liabilities were not significant.

- changed (2020-05-21):
[0001045810-20-000065:note_history:3]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.
  (was, 2019-11-14, similarity 0.9892):
[0001045810-19-000170:note_history:3]
In connection with certain agreements that we have entered in the past, we have provided indemnification to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

- changed (2020-05-21):
[0001045810-20-000065:note_history:4]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants. On March 16, 2020, the Court issued an order dismissing the consolidated class action complaint with leave to amend.  The plaintiffs filed an amended complaint on May 13, 2020.
  (was, 2019-11-14, similarity 0.9588):
[0001045810-19-000170:note_history:4]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

- changed (2020-05-21):
[0001045810-20-000065:note_history:5]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The Court approved the parties’ stipulation to stay the
  (was, 2019-11-14, similarity 0.9246):
[0001045810-19-000170:note_history:5]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

- added (2020-05-21):
[0001045810-20-000065:note_history:6]
In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

- changed (2020-05-21):
[0001045810-20-000065:note_history:7]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the Court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of the motion to dismiss filed by NVIDIA in the In Re NVIDIA Corporation Securities Litigation.
  (was, 2019-11-14, similarity 0.731):
[0001045810-19-000170:note_history:7]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and

- changed (2020-05-21):
[0001045810-20-000065:note_history:8]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of April 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.
  (was, 2019-11-14, similarity 0.9909):
[0001045810-19-000170:note_history:8]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of October 27, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.

- removed (2020-05-21):
[0001045810-19-000170:note_history:9]
Performance Obligations

- removed (2020-05-21):
[0001045810-19-000170:note_history:10]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of October 27, 2019, the amount of our remaining performance

- removed (2020-05-21):
[0001045810-19-000170:note_history:11]
obligations that has not been recognized as revenue was $395 million, of which we expect to recognize approximately 47% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

- removed (2020-05-21):
[0001045810-19-000170:note_history:12]
the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- removed (2020-05-21):
[0001045810-19-000170:note_history:13]
Litigation Related to Acquisition of Mellanox

- removed (2020-05-21):
[0001045810-19-000170:note_history:14]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Exchange Act and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but NVIDIA was not named as a defendant in any of these other lawsuits.  As of October 14, 2019, all stockholder lawsuits relating to NVIDIA’s pending acquisition of Mellanox, including the Stein lawsuit, had been voluntarily dismissed by the respective plaintiffs.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-21):
[0001045810-20-000065:note_history:15]
There have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.
  (was, 2019-11-14, similarity 0.8963):
[0001045810-19-000170:note_history:15]
Except for adopting a new accounting standard related to leases, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.

- changed (2020-05-21):
[0001045810-20-000065:note_history:16]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year and fiscal year 2020 is a 52-week year. The first quarters of fiscal years 2021 and 2020 were both 13-week quarters.
  (was, 2019-11-14, similarity 0.8608):
[0001045810-19-000170:note_history:16]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The third quarters of fiscal years 2020 and 2019 were both 13-week quarters.

- changed (2020-05-21):
[0001045810-20-000065:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19 on our critical and significant accounting estimates. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2019-11-14, similarity 0.8408):
[0001045810-19-000170:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and

- added (2020-05-21):
[0001045810-20-000065:note_history:18]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. The Company adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to the Company's consolidated financial statements.

- removed (2020-05-21):
[0001045810-19-000170:note_history:19]
Leases

- removed (2020-05-21):
[0001045810-19-000170:note_history:20]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

- removed (2020-05-21):
[0001045810-19-000170:note_history:21]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

- removed (2020-05-21):
[0001045810-19-000170:note_history:22]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

- removed (2020-05-21):
[0001045810-19-000170:note_history:23]
Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

- removed (2020-05-21):
[0001045810-19-000170:note_history:24]
other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- removed (2020-05-21):
[0001045810-19-000170:note_history:25]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases under which lease assets and liabilities are recognized on the balance sheet. We adopted this guidance on January 28, 2019 using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet. Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

- removed (2020-05-21):
[0001045810-19-000170:note_history:26]
Recent Accounting Pronouncement Not Yet Adopted
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. We expect to adopt the standard using the modified retrospective transition method beginning in the first quarter of fiscal year 2021. While we are still evaluating the impact of this standard on our Consolidated Financial Statements, we do not currently believe it will have a material impact upon adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-05-21):
[0001045810-20-000065:note_history:27]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and estimated issuance costs.

- changed (2020-05-21):
[0001045810-20-000065:note_history:28]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.
  (was, 2019-11-14, similarity 0.8281):
[0001045810-19-000170:note_history:28]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

- added (2020-05-21):
[0001045810-20-000065:note_history:29]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

- changed (2020-05-21):
[0001045810-20-000065:note_history:30]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.9 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.9 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 30.0 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 40.0 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (41) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,959 |  |  | $ | 1,991 |  |
  (was, 2019-11-14, similarity 0.7641):
[0001045810-19-000170:note_history:30]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 27, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 1.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (10 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,990 |  |  | $ | 1,988 |  |

- added (2020-05-21):
[0001045810-20-000065:note_history:31]
The Notes require the Company to comply with certain covenants for which the Company was in compliance as of April 26, 2020.

- changed (2020-05-21):
[0001045810-20-000065:note_history:32]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 26, 2020, we had not borrowed any amounts under this agreement.
  (was, 2019-11-14, similarity 0.974):
[0001045810-19-000170:note_history:32]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 27, 2019, we had not borrowed any amounts under this agreement.

- added (2020-05-21):
[0001045810-20-000065:note_history:33]
The Credit Agreement governing the revolving credit facility requires the Company to comply with a leverage ratio covenant. As of April 26, 2020, the Company was in compliance with this financial covenant.

- changed (2020-05-21):
[0001045810-20-000065:note_history:34]
We have a $575 million commercial paper program to support general corporate purposes. As of April 26, 2020, we had not issued any commercial paper.
  (was, 2019-11-14, similarity 0.9645):
[0001045810-19-000170:note_history:34]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2019, we had not issued any commercial paper.

- removed (2020-05-21):
[0001045810-19-000170:note_history:35]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

- removed (2020-05-21):
[0001045810-19-000170:note_history:36]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-21):
[0001045810-20-000065:note_history:37]
The following is a summary of cash equivalents and marketable securities as of April 26, 2020 and January 26, 2020:
  (was, 2019-11-14, similarity 0.9528):
[0001045810-19-000170:note_history:37]
The following is a summary of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019:

- added (2020-05-21):
[0001045810-20-000065:note_history:38]
|  | April 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 11,128 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,128 |  |  | $ | 11,128 |  |  | $ | — |  |
| Corporate debt securities | 3,238 |  |  | — |  |  | — |  |  | 3,238 |  |  | 2,951 |  |  | 287 |  |
| Foreign government bonds | 870 |  |  | — |  |  | — |  |  | 870 |  |  | 870 |  |  | — |  |
| Certificates of deposit | 582 |  |  | — |  |  | — |  |  | 582 |  |  | 222 |  |  | 360 |  |
| Debt securities issued by United States government agencies | 381 |  |  | — |  |  | — |  |  | 381 |  |  | 168 |  |  | 213 |  |
| Total | $ | 16,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 16,199 |  |  | $ | 15,339 |  |  | $ | 860 |  |

- added (2020-05-21):
[0001045810-20-000065:note_history:39]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  |  |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- removed (2020-05-21):
[0001045810-19-000170:note_history:40]
|  | October 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 5,883 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,883 |  |  | $ | 5,883 |  |  | $ | — |  |
| Corporate debt securities | 1,293 |  |  | — |  |  | — |  |  | 1,293 |  |  | 1,293 |  |  | — |  |
| Debt securities of United States government agencies | 1,204 |  |  | — |  |  | — |  |  | 1,204 |  |  | 1,204 |  |  | — |  |
| Money market funds | 1,070 |  |  | — |  |  | — |  |  | 1,070 |  |  | 1,070 |  |  | — |  |
| Foreign government debt securities | 178 |  |  | — |  |  | — |  |  | 178 |  |  | 178 |  |  | — |  |
| Certificates of deposit | 25 |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |  | — |  |
| Asset-backed securities | 4 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total | $ | 9,657 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,657 |  |  | $ | 9,653 |  |  | $ | 4 |  |

- removed (2020-05-21):
[0001045810-19-000170:note_history:41]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government debt securities | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

- removed (2020-05-21):
[0001045810-19-000170:note_history:42]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019 are shown below by contractual maturity.

- removed (2020-05-21):
[0001045810-19-000170:note_history:43]
|  | October 27, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | — |  |  | — |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | — |  |  | — |  |  | 22 |  |  | 22 |  |
| Total | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-21):
[0001045810-20-000065:note_history:44]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.
  (was, 2019-11-14, similarity 0.9219):
[0001045810-19-000170:note_history:44]
Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

- changed (2020-05-21):
[0001045810-20-000065:note_history:45]
The following is a summary of cash equivalents and marketable securities as of April 26, 2020 and January 26, 2020:
  (was, 2019-11-14, similarity 0.9528):
[0001045810-19-000170:note_history:45]
The following is a summary of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019:

- added (2020-05-21):
[0001045810-20-000065:note_history:46]
|  | April 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 11,128 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,128 |  |  | $ | 11,128 |  |  | $ | — |  |
| Corporate debt securities | 3,238 |  |  | — |  |  | — |  |  | 3,238 |  |  | 2,951 |  |  | 287 |  |
| Foreign government bonds | 870 |  |  | — |  |  | — |  |  | 870 |  |  | 870 |  |  | — |  |
| Certificates of deposit | 582 |  |  | — |  |  | — |  |  | 582 |  |  | 222 |  |  | 360 |  |
| Debt securities issued by United States government agencies | 381 |  |  | — |  |  | — |  |  | 381 |  |  | 168 |  |  | 213 |  |
| Total | $ | 16,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 16,199 |  |  | $ | 15,339 |  |  | $ | 860 |  |

- added (2020-05-21):
[0001045810-20-000065:note_history:47]
|  | January 26, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |  |  |
|  |  |  |  |  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  |  |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

- added (2020-05-21):
[0001045810-20-000065:note_history:48]
The amortized cost and estimated fair value of cash equivalents and marketable securities of $16.20 billion and $10.78 billion as of April 26, 2020 and January 26, 2020, respectively, are all related to contracts with maturities of less than one year. Unrealized gains and losses were not significant for all periods presented. For the first quarter of fiscal years 2021 and 2020, net realized gains were not significant.

- removed (2020-05-21):
[0001045810-19-000170:note_history:49]
|  | October 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 5,883 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,883 |  |  | $ | 5,883 |  |  | $ | — |  |
| Corporate debt securities | 1,293 |  |  | — |  |  | — |  |  | 1,293 |  |  | 1,293 |  |  | — |  |
| Debt securities of United States government agencies | 1,204 |  |  | — |  |  | — |  |  | 1,204 |  |  | 1,204 |  |  | — |  |
| Money market funds | 1,070 |  |  | — |  |  | — |  |  | 1,070 |  |  | 1,070 |  |  | — |  |
| Foreign government debt securities | 178 |  |  | — |  |  | — |  |  | 178 |  |  | 178 |  |  | — |  |
| Certificates of deposit | 25 |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |  | — |  |
| Asset-backed securities | 4 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total | $ | 9,657 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,657 |  |  | $ | 9,653 |  |  | $ | 4 |  |

- removed (2020-05-21):
[0001045810-19-000170:note_history:50]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government debt securities | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

- removed (2020-05-21):
[0001045810-19-000170:note_history:51]
For the third quarter and first nine months of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.

- removed (2020-05-21):
[0001045810-19-000170:note_history:52]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019 are shown below by contractual maturity.

- removed (2020-05-21):
[0001045810-19-000170:note_history:53]
|  | October 27, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | — |  |  | — |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | — |  |  | — |  |  | 22 |  |  | 22 |  |
| Total | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-21):
[0001045810-20-000065:note_history:54]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 26, 2020 |  | January 26, 2020 |
|  |  |  |  |  |  | (In millions) |  |  |
| 2.20% Notes Due 2021 |  | 1.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.9 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.9 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 30.0 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 40.0 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (41) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | $ | 6,959 |  |  | $ | 1,991 |  |
  (was, 2019-11-14, similarity 0.7641):
[0001045810-19-000170:note_history:54]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 27, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 1.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (10 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,990 |  |  | $ | 1,988 |  |
