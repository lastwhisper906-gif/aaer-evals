# NVDA MD&A — 0001045810-20-000065


## mdna

[0001045810-20-000065:mdna:1]
[same as prior period, unchanged from 0001045810-19-000170:mdna:1]

[0001045810-20-000065:mdna:2]
[same as prior period, unchanged from 0001045810-19-000170:mdna:2]

[0001045810-20-000065:mdna:3]
[same as prior period, unchanged from 0001045810-19-000170:mdna:3]

[0001045810-20-000065:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX SUPER, NVIDIA CUDA, NVIDIA DGX, NVIDIA EGX AI Edge, NVIDIA GRID, NVIDIA Jarvis, NVIDIA Jetson, NVIDIA Merlin, NVIDIA RTX, Mellanox, Quadro, Quadro RTX, and Tegra are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-20-000065:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 6. Selected Financial Data” of our Annual Report on Form 10-K for the fiscal year ended January 26, 2020 and “Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-20-000065:mdna:6]
[same as prior period, unchanged from 0001045810-19-000170:mdna:6]

[0001045810-20-000065:mdna:7]
[same as prior period, unchanged from 0001045810-19-000170:mdna:7]

[0001045810-20-000065:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Starting with a focus on PC graphics, we extended our focus in recent years to the revolutionary field of AI. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA leveraged its GPU architecture to create platforms for virtual reality, HPC, and AI.

[0001045810-20-000065:mdna:9]
Through fiscal year 2020, our reportable segments were GPU and Tegra Processor. Starting with the first quarter of fiscal year 2021, our reportable segments have changed to "Graphics" and "Compute & Networking".

[0001045810-20-000065:mdna:10]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro GPUs for enterprise design; GRID software for cloud-based visual and virtual computing; and automotive platforms for infotainment systems.

[0001045810-20-000065:mdna:11]
Our Compute & Networking segment includes Data Center platforms and systems for AI, HPC, and accelerated computing; DRIVE for autonomous vehicles; and Jetson for robotics and other embedded platforms. Starting with the second quarter of fiscal year 2021, we will include Mellanox revenue in this segment.

[0001045810-20-000065:mdna:12]
All prior period comparisons presented reflect our new reportable segments. Our market platforms – Gaming, Professional Visualization, Data Center, Automotive, OEM and Other – remain unchanged.  We will incorporate Mellanox in our Data Center market platform.

[0001045810-20-000065:mdna:13]
[same as prior period, unchanged from 0001045810-19-000170:mdna:11]

[0001045810-20-000065:mdna:14]
22

[0001045810-20-000065:mdna:15]
[same as prior period, unchanged from 0001045810-19-000170:mdna:12]

[0001045810-20-000065:mdna:16]
COVID-19

[0001045810-20-000065:mdna:17]
The novel strain of the coronavirus identified in late calendar 2019 (COVID-19) has spread to a worldwide pandemic within the first quarter of fiscal year 2021. Government authorities around the world implemented measures to try to contain the disease, such as travel bans and restrictions, quarantines, shelter-in-place orders and shutdowns. Since March 2020, most of our employees have been working remotely and we temporarily prohibited business travel.

[0001045810-20-000065:mdna:18]
During the first quarter of fiscal year 2021, we experienced disruptions to our supply chain and logistical services provided by outsourcing partners and component supply, primarily based in Asia. These disruptions adversely impacted our linearity of supply and sales within the quarter.

[0001045810-20-000065:mdna:19]
The shelter-in-place or similar global orders have impacted demand for our gaming products in many jurisdictions that rely on purchases at physical retailers due to temporary store closures, and demand from iCafes located in China which have temporarily closed. In addition, the global demand for automobiles has decreased during this time which negatively impacts demand for our automotive products and solutions. In some regions, the shelter-in-place orders have driven a temporary increase in demand, that may not be sustainable, for gaming, OEM platforms and compute infrastructure as a result of work from home, learn at home, and gaming.

[0001045810-20-000065:mdna:20]
The full extent and duration of COVID-19 is uncertain. If the COVID-19 pandemic continues for an extended period, the timing and overall demand from customers and the availability of supply chain, logistical services and component supply could have a material net negative impact on our business and financial results. Refer to Part II, Item 1A of this Form 10-Q for additional information under the heading “Risk Factors”.

[0001045810-20-000065:mdna:21]
First Quarter of Fiscal Year 2021 Summary

[0001045810-20-000065:mdna:22]
|  | Three Months Ended |  |  |  |  |  |  |  |  |
|  | April 26, 2020 |  | January 26, 2020 |  | April 28, 2019 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |  |  |  |  |
| Revenue | $ | 3,080 |  |  | $ | 3,105 |  |  | $ | 2,220 |  |  | (1) | % |  | 39 | % |
| Gross margin | 65.1 | % |  | 64.9 | % |  | 58.4 | % |  | 20 bps |  | 670 bps |
| Operating expenses | $ | 1,028 |  |  | $ | 1,025 |  |  | $ | 938 |  |  | — | % |  | 10 | % |
| Income from operations | $ | 976 |  |  | $ | 990 |  |  | $ | 358 |  |  | (1) | % |  | 173 | % |
| Net income | $ | 917 |  |  | $ | 950 |  |  | $ | 394 |  |  | (3) | % |  | 133 | % |
| Net income per diluted share | $ | 1.47 |  |  | $ | 1.53 |  |  | $ | 0.64 |  |  | (4) | % |  | 130 | % |

[0001045810-20-000065:mdna:23]
Revenue for the first quarter was $3.08 billion, up 39% from a year earlier and down 1% sequentially.

[0001045810-20-000065:mdna:24]
Graphics segment revenue for the first quarter was $1.91 billion, up 25% from a year earlier and down 9% sequentially.

[0001045810-20-000065:mdna:25]
Compute & Networking segment revenue for the first quarter was $1.17 billion, up 69% from a year ago and up 15% sequentially.

[0001045810-20-000065:mdna:26]
From a market-platform perspective, Gaming revenue for the first quarter was $1.34 billion, up 27% from a year ago and down 10% sequentially. The year-on-year increase reflects higher sales across our major gaming products. The sequential decrease reflects seasonally lower sales of GeForce desktop GPUs for gaming, partially offset by higher sales of SoCs for gaming platforms and GeForce laptop GPUs.

[0001045810-20-000065:mdna:27]
Professional Visualization revenue for the first quarter was $307 million, up 15% from a year earlier and down 7% sequentially. The year-on-year growth reflects strength in laptop and desktop workstations. The sequential decrease was driven by lower sales of desktop workstations, partially offset by strength in laptop workstations.

[0001045810-20-000065:mdna:28]
Data Center revenue for the first quarter was $1.14 billion, up 80% from a year ago and up 18% sequentially, driven by higher vertical industries and hyperscale demand.

[0001045810-20-000065:mdna:29]
Automotive revenue was $155 million, down 7% from a year earlier and down 5% sequentially, primarily reflecting lower legacy infotainment revenue.

[0001045810-20-000065:mdna:30]
OEM and Other revenue for the first quarter was $138 million, up 39% from a year ago and down 9% sequentially. The year-on-year increase was primarily due to higher demand for entry level laptop GPUs from PC OEMs. The sequential decrease reflects seasonally lower sales of entry-level GPUs for PC OEMs.

[0001045810-20-000065:mdna:31]
Gross margin for the first quarter of fiscal year 2021 was 65.1%, up 670 basis points from a year earlier and up 20 basis points sequentially. The year-on-year increase was primarily driven by GeForce GPU product mix and higher Data Center sales. The sequential increase was Data Center, partially offset by product mix in GeForce GPUs.

[0001045810-20-000065:mdna:32]
Operating expenses for the first quarter of fiscal year 2021 were $1.03 billion, up 10% from a year earlier and flat sequentially. The year-on-year growth primarily reflects employee additions and increases in employee compensation and other related costs, including stock-based compensation and infrastructure costs.

[0001045810-20-000065:mdna:33]
Income from operations for the first quarter of fiscal year 2021 was $976 million, up 173% from a year earlier and down 1% sequentially. Net income for the first quarter of fiscal year 2021 was $917 million. Net income per diluted share for the first quarter of fiscal year 2021 were $1.47, up 130% from a year earlier and down 4% sequentially.

[0001045810-20-000065:mdna:34]
In the first quarter of fiscal year 2021, we paid dividends of $98 million. Due to the current market uncertainties, we are evaluating the timing of resuming share repurchases and will remain nimble based on market conditions. We are currently authorized to repurchase up to $7.24 billion through December 2022. We remain committed to paying quarterly dividends.

[0001045810-20-000065:mdna:35]
Cash, cash equivalents and marketable securities at the end of the first quarter were $16.35 billion, up from $7.80 billion a year earlier and $10.90 billion in the prior quarter, reflecting the issuance of $5 billion of March 2020 Notes and strong operating cash flow.

[0001045810-20-000065:mdna:36]
Subsequent to the end of the first quarter of fiscal year 2021, we closed the acquisition of Mellanox for a transaction value of approximately $7.0 billion in cash on April 27, 2020.

[0001045810-20-000065:mdna:37]
Market Platform Highlights

[0001045810-20-000065:mdna:38]
During the first quarter of fiscal year 2021, in our Gaming platform, we launched Minecraft with RTX as an open beta on Windows 10; announced the release of laptop models powered by NVIDIA GeForce GPUs; expanded the RTX Studio lineup powered by new GeForce RTX SUPER GPUs; released DLSS 2.0; and expanded NVIDIA GeForce NOW.

[0001045810-20-000065:mdna:39]
In our Professional Visualization platform, we powered Autodesk’s latest 3D visualization software with NVIDIA Quadro RTX; accelerated Altair's engineering software with NVIDIA CUDA; and brought Quadro professional graphics to HP's mobile workstation lineup.

[0001045810-20-000065:mdna:40]
In our Data Center platform, we introduced NVIDIA A100 data center GPU, the first based on the NVIDIA Ampere architecture; launched the NVIDIA DGX A100; introduced two products for the EGX Edge AI platform; released NVIDIA Jarvis; collaborated with the open-source community to bring end-to-end GPU acceleration to Apache Spark 3.0; and announced NVIDIA Merlin.

[0001045810-20-000065:mdna:41]
[same as prior period, unchanged from 0001045810-19-000170:mdna:44]

[0001045810-20-000065:mdna:42]
[same as prior period, unchanged from 0001045810-19-000170:mdna:45]

[0001045810-20-000065:mdna:43]
[same as prior period, unchanged from 0001045810-19-000170:mdna:39]

[0001045810-20-000065:mdna:44]
[same as prior period, unchanged from 0001045810-19-000170:mdna:46]

[0001045810-20-000065:mdna:45]
[same as prior period, unchanged from 0001045810-19-000170:mdna:47]

[0001045810-20-000065:mdna:46]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 26,2020 |  | April 28,2019 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 34.9 |  |  | 41.6 |  |  |  |  |  |
| Gross profit | 65.1 |  |  | 58.4 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Research and development | 23.9 |  |  | 30.4 |  |  |  |  |  |
| Sales, general and administrative | 9.5 |  |  | 11.9 |  |  |  |  |  |
| Total operating expenses | 33.4 |  |  | 42.3 |  |  |  |  |  |
| Income from operations | 31.7 |  |  | 16.1 |  |  |  |  |  |
| Interest income | 1.0 |  |  | 2.0 |  |  |  |  |  |
| Interest expense | (0.8) |  |  | (0.6) |  |  |  |  |  |
| Other income, net | 0.2 |  |  | 1.4 |  |  |  |  |  |
| Income before income tax | 31.9 |  |  | 17.5 |  |  |  |  |  |
| Income tax expense (benefit) | 2.1 |  |  | (0.2) |  |  |  |  |  |
| Net income | 29.8 | % |  | 17.7 | % |  |  |  |  |

[0001045810-20-000065:mdna:47]
[same as prior period, unchanged from 0001045810-19-000170:mdna:49]

[0001045810-20-000065:mdna:48]
[same as prior period, unchanged from 0001045810-19-000170:mdna:50]

[0001045810-20-000065:mdna:49]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | April 26,2020 |  | April 28,2019 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Graphics | $ | 1,906 |  |  | $ | 1,526 |  |  | $ | 380 |  |  | 25 | % |  |  |  |  |  |  |  |  |
| Compute & Networking | 1,174 |  |  | 694 |  |  | 480 |  |  | 69 | % |  |  |  |  |  |  |  |  |
| Total | $ | 3,080 |  |  | $ | 2,220 |  |  | $ | 860 |  |  | 39 | % |  |  |  |  |  |  |  |  |

[0001045810-20-000065:mdna:50]
Graphics - Graphics segment revenue increased 25% in the first quarter of fiscal year 2021 compared to the first quarter of fiscal year 2020, which reflects growth in GeForce gaming and Quadro GPU revenue. Gaming increased 28%, reflecting revenue growth across all platforms. Revenue from Quadro GPUs increased by 24%, reflecting strength in desktop and laptop workstations.

[0001045810-20-000065:mdna:51]
Compute & Networking - Compute & Networking segment revenue increased 69% for the first quarter of fiscal year 2021 compared to the first quarter of fiscal year 2020, driven by an increase in data center-related sales for vertical industries and hyperscales.

[0001045810-20-000065:mdna:52]
[same as prior period, unchanged from 0001045810-19-000170:mdna:56]

[0001045810-20-000065:mdna:53]
Revenue from sales to customers outside of the United States accounted for 84% and 93% of total revenue for the first quarter of fiscal years 2021 and 2020, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-20-000065:mdna:54]
No customer represented 10% or more of total revenue or the first quarter of fiscal year 2021. One customer represented 11% of our total revenue for the first quarter of fiscal year 2020 and was attributable primarily to the Graphics segment.

[0001045810-20-000065:mdna:55]
25

[0001045810-20-000065:mdna:56]
[same as prior period, unchanged from 0001045810-19-000170:mdna:59]

[0001045810-20-000065:mdna:57]
Our overall gross margin increased to 65.1% for the first quarter of fiscal year 2021 from 58.4% for the first quarter of fiscal year 2020. The increase in fiscal year 2021 is primarily driven by GeForce GPU product mix and higher data center sales.

[0001045810-20-000065:mdna:58]
Inventory provisions totaled $36 million and $43 million for the first quarter of fiscal years 2021 and 2020, respectively. Sales of inventory that was previously written-off or -down totaled $39 million and $12 million for the first quarter of fiscal years 2021 and 2020, respectively. As a result, the overall net effect on our gross margin was a favorable impact of 0.1% and unfavorable impact of 1.4% for the first quarter of fiscal years 2021 and 2020, respectively.

[0001045810-20-000065:mdna:59]
[same as prior period, unchanged from 0001045810-19-000170:mdna:63]

[0001045810-20-000065:mdna:60]
Graphics - The gross margin of our Graphics segment increased during the first quarter of fiscal year 2021 compared to the first quarter of fiscal year 2020, primarily driven by GeForce GPU product mix.

[0001045810-20-000065:mdna:61]
Compute & Networking - The gross margin of our Compute & Networking segment increased during the first quarter of fiscal year 2021 compared to the first quarter of fiscal year 2020, primarily driven by higher data center sales.

[0001045810-20-000065:mdna:62]
[same as prior period, unchanged from 0001045810-19-000170:mdna:66]

[0001045810-20-000065:mdna:63]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | April 26,2020 |  | April 28,2019 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development expenses | $ | 735 |  |  | $ | 674 |  |  | $ | 61 |  |  | 9 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 24 | % |  | 30 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales, general and administrative expenses | 293 |  |  | 264 |  |  | 29 |  |  | 11 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 10 | % |  | 12 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 1,028 |  |  | $ | 938 |  |  | $ | 90 |  |  | 10 | % |  |  |  |  |  |  |  |  |

[0001045810-20-000065:mdna:64]
[same as prior period, unchanged from 0001045810-19-000170:mdna:68]

[0001045810-20-000065:mdna:65]
Research and development expenses increased by 9% during the first quarter of fiscal year 2021, compared to the first quarter of fiscal year 2020, driven primarily by employee additions, increases in employee compensation and other related costs, including infrastructure costs and stock-based compensation expense.

[0001045810-20-000065:mdna:66]
[same as prior period, unchanged from 0001045810-19-000170:mdna:70]

[0001045810-20-000065:mdna:67]
Sales, general and administrative expenses increased by 11% during the first quarter of fiscal year 2021, compared to the first quarter of fiscal year 2020, driven primarily by employee additions, increases in employee compensation and other related costs, including infrastructure costs and stock-based compensation expense.

[0001045810-20-000065:mdna:68]
Other Income, Net

[0001045810-20-000065:mdna:69]
[same as prior period, unchanged from 0001045810-19-000170:mdna:74]

[0001045810-20-000065:mdna:70]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $31 million and $44 million during the first quarter of fiscal years 2021 and 2020, respectively. The decrease in interest income was primarily due to lower interest earned on our investments.

[0001045810-20-000065:mdna:71]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our September 2016 Notes and March 2020 Notes. Interest expense was $25 million and $13 million during the first quarters of fiscal years 2021 and 2020, respectively.

[0001045810-20-000065:mdna:72]
[same as prior period, unchanged from 0001045810-19-000170:mdna:77]

[0001045810-20-000065:mdna:73]
We recognized an income tax expense of $64 million for the first quarter of fiscal year 2021 and an income tax benefit of $5 million for the first quarter of fiscal year 2020. The income tax expense as a percentage of income before income tax

[0001045810-20-000065:mdna:74]
was 6.6% for the first quarter of fiscal year 2021 and income tax benefit as a percentage of income before income tax was 1.3% for the first quarter of fiscal year 2020.

[0001045810-20-000065:mdna:75]
The increase in our effective tax rate for the first quarter of fiscal year 2021 as compared to the first quarter of fiscal year 2020 was primarily due to a decrease of tax benefits from stock-based compensation.

[0001045810-20-000065:mdna:76]
[same as prior period, unchanged from 0001045810-19-000170:mdna:81]

[0001045810-20-000065:mdna:77]
[same as prior period, unchanged from 0001045810-19-000170:mdna:82]

[0001045810-20-000065:mdna:78]
|  | April 26, 2020 |  | January 26, 2020 |
|  | (In millions) |  |  |
| Cash and cash equivalents | $ | 15,494 |  |  | $ | 10,896 |  |
| Marketable securities | 860 |  |  | 1 |  |
| Cash, cash equivalents and marketable securities | $ | 16,354 |  |  | $ | 10,897 |  |

[0001045810-20-000065:mdna:79]
|  | Three Months Ended |  |  |
|  | April 26, 2020 |  | April 28, 2019 |
|  | (In millions) |  |  |
| Net cash provided by operating activities | $ | 909 |  |  | $ | 720 |  |
| Net cash provided by (used in) investing activities | $ | (1,055) |  |  | $ | 1,495 |  |
| Net cash provided by (used in) financing activities | $ | 4,744 |  |  | $ | (225) |  |

[0001045810-20-000065:mdna:80]
As of April 26, 2020, we had $16.35 billion in cash, cash equivalents and marketable securities, an increase of $5.46 billion from the end of fiscal year 2020. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain limits on our portfolio duration.

[0001045810-20-000065:mdna:81]
Cash provided by operating activities increased in the first quarter of fiscal year 2021 compared to the first quarter of fiscal year 2020, due to higher net income partially offset by changes in working capital. Change in working capital was driven by an increase in accounts receivable, an increase in inventory, and changes in operating liabilities.

[0001045810-20-000065:mdna:82]
Cash used in investing activities increased in the first quarter of fiscal year 2021 compared to cash provided in the first quarter of fiscal year 2020, due to absence of maturities of marketable securities.

[0001045810-20-000065:mdna:83]
Cash provided by financing activities increased in the first quarter of fiscal year 2021 compared to cash used in the first quarter of fiscal year 2020, due to the debt issued in the first quarter of fiscal year 2021.

[0001045810-20-000065:mdna:84]
[same as prior period, unchanged from 0001045810-19-000170:mdna:89]

[0001045810-20-000065:mdna:85]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of April 26, 2020, we had $16.35 billion in cash, cash equivalents and marketable securities. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and certificates of deposits. These marketable securities are denominated in United States dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information.  We believe that we have sufficient liquidity to meet our operating requirements and capital expenditures for at least the next twelve months. Subsequent to the first quarter of fiscal year 2021, we used approximately $7.0 billion to close the Mellanox acquisition.

[0001045810-20-000065:mdna:86]
As a result of the Tax Cuts and Jobs Act, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of April 26, 2020 are available for use in the United States without incurring additional U.S. federal income taxes.

[0001045810-20-000065:mdna:87]
[same as prior period, unchanged from 0001045810-19-000170:mdna:92]

[0001045810-20-000065:mdna:88]
In the first quarter of fiscal year 2021, we returned $98 million in quarterly cash dividends. As of April 26, 2020, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022. We did not repurchase any shares during the first quarter of fiscal year 2021. Due to the

[0001045810-20-000065:mdna:89]
current market uncertainties, we are evaluating the timing of resuming share repurchases and will remain nimble based on market conditions. We remain committed to paying quarterly dividends.

[0001045810-20-000065:mdna:90]
Our cash dividend program and the payment of future cash dividends under that program are subject to our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-20-000065:mdna:91]
Outstanding Indebtedness and Credit Facilities

[0001045810-20-000065:mdna:92]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discounts and estimated issuance costs.

[0001045810-20-000065:mdna:93]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discounts and issuance costs.

[0001045810-20-000065:mdna:94]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 26, 2020, we had not borrowed any amounts under this agreement.

[0001045810-20-000065:mdna:95]
We have a $575 million commercial paper program to support general corporate purposes. As of April 26, 2020, we had not issued any commercial paper.

[0001045810-20-000065:mdna:96]
[same as prior period, unchanged from 0001045810-19-000170:mdna:103]

[0001045810-20-000065:mdna:97]
As of April 26, 2020, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-20-000065:mdna:98]
[same as prior period, unchanged from 0001045810-19-000170:mdna:105]

[0001045810-20-000065:mdna:99]
There were no material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020.

[0001045810-20-000065:mdna:100]
Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 26, 2020 for a description of our contractual obligations.

[0001045810-20-000065:mdna:101]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000065:mdna:102]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
