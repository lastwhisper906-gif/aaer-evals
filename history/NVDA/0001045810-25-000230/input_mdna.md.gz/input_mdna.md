# NVDA MD&A — 0001045810-25-000230


## mdna

[0001045810-25-000230:mdna:1]
[same as prior period, unchanged from 0001045810-25-000209:mdna:1]

[0001045810-25-000230:mdna:2]
[same as prior period, unchanged from 0001045810-25-000209:mdna:2]

[0001045810-25-000230:mdna:3]
[same as prior period, unchanged from 0001045810-25-000209:mdna:3]

[0001045810-25-000230:mdna:4]
[same as prior period, unchanged from 0001045810-25-000209:mdna:4]

[0001045810-25-000230:mdna:5]
[same as prior period, unchanged from 0001045810-25-000209:mdna:5]

[0001045810-25-000230:mdna:6]
[same as prior period, unchanged from 0001045810-25-000209:mdna:6]

[0001045810-25-000230:mdna:7]
[same as prior period, unchanged from 0001045810-25-000209:mdna:7]

[0001045810-25-000230:mdna:8]
[same as prior period, unchanged from 0001045810-25-000209:mdna:8]

[0001045810-25-000230:mdna:9]
[same as prior period, unchanged from 0001045810-25-000209:mdna:9]

[0001045810-25-000230:mdna:10]
[same as prior period, unchanged from 0001045810-25-000209:mdna:10]

[0001045810-25-000230:mdna:11]
[same as prior period, unchanged from 0001045810-25-000209:mdna:11]

[0001045810-25-000230:mdna:12]
Revenue growth in the third quarter was driven by data center compute and networking platforms for accelerated computing and AI solutions. Our Blackwell architectures are the majority of our Data Center revenue.

[0001045810-25-000230:mdna:13]
The availability of data centers, energy, and capital to support the buildout of NVIDIA AI infrastructure by our customers is crucial, and any shortage of these resources could impact our future revenue and financial performance. Expanding energy capacity to meet demand is a complex, multi-year process that involves significant regulatory, technical, and construction challenges. In addition, access to capital can be particularly constrained for less-capitalized companies, which may face difficulties securing financing for large-scale infrastructure projects. These limitations could delay customer deployments or reduce the scale of accelerated computing and AI adoption.

[0001045810-25-000230:mdna:14]
We continue to execute Data Center compute product introductions, bringing new advanced architectures on a one-year product cadence. We began shipping production units of our new Blackwell Ultra platforms including GB300 in the second quarter of fiscal year 2026 and continue to sell prior generation architecture. The complexity of our product transitions and sophisticated system configurations may cause delays in production or create challenges in managing supply and demand. This could result in revenue volatility, quality issues, increased inventory provisions, and/or increased warranty costs. Customers may postpone purchasing new architectures or may adopt new technologies more gradually than anticipated, affecting our revenue timing and supply chain expenses.

[0001045810-25-000230:mdna:15]
In April 2025, the U.S. government, or USG, informed us that a license is required for exports of our H20 product into the China market. As a result of these new requirements, we incurred a $4.5 billion charge in the first quarter of fiscal year 2026 associated with H20 for excess inventory and purchase obligations, as the demand for H20 diminished. In August 2025, the USG granted licenses that would allow us to ship certain H20 products to certain China-based customers, but to date, we have generated approximately $50 million in H20 revenue under those licenses. USG officials have expressed an expectation that the USG will receive 15% or more of the revenue generated from licensed sales of our products, but to date, the USG has not published a regulation codifying such requirement.

[0001045810-25-000230:mdna:16]
In January 2025, the USG published the “AI Diffusion” Interim Final Rule, or IFR, in the Federal Register. The IFR would have imposed a worldwide licensing requirement on our most recent data center products, such as our H200, GB200 and GB300. In May 2025, the USG announced that it would rescind the AI Diffusion IFR and implement a replacement rule. The scope, timing, and requirements of the forthcoming rule remain uncertain. The replacement rule may impose new restrictions on our products or operations and/or add license requirements that could have a material impact on our business, operating results, and financial condition. For example, in October 2025, the Senate passed the “GAIN AI Act” in the National Defense Authorization Act, or the NDAA. The GAIN AI Act would restrict the Trump Administration’s ability to adapt the Biden Administration’s export control rules and could also allow private U.S. persons to review and overturn licensing and foreign policy decisions made by the Trump Administration.

[0001045810-25-000230:mdna:17]
The recent rise in high-quality open-source foundation models is making advanced AI capabilities broadly accessible. Open-source AI is dependent on developer adoption and if deployed on our competitors’ platforms, it could reduce demand for our products and services.

[0001045810-25-000230:mdna:18]
The rapid evolution of global trade policies, such as export controls and tariffs, has added complexity and increased costs throughout our supply chain, and these challenges are likely to persist. Ongoing uncertainty regarding the scope and application of such measures may adversely affect investment decisions by us and our partners, disrupt supply chain operations, and impact the timing and volume of customer purchases due to challenges in forecasting future costs and demand.

[0001045810-25-000230:mdna:19]
We are increasing our U.S.-based manufacturing and investing in specialized equipment and processes to support domestic production. This move is expected to strengthen our supply chain, add resiliency and redundancy, and meet the growing demand for AI infrastructure. Our ability to increase manufacturing capabilities will depend on the domestic manufacturing ecosystem's capacity to ramp production supply to the required volume and on a timely basis.

[0001045810-25-000230:mdna:20]
[same as prior period, unchanged from 0001045810-25-000209:mdna:20]

[0001045810-25-000230:mdna:21]
[same as prior period, unchanged from 0001045810-25-000209:mdna:21]

[0001045810-25-000230:mdna:22]
Third Quarter of Fiscal Year 2026 Summary

[0001045810-25-000230:mdna:23]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Oct 26, 2025 |  | Jul 27, 2025 |  | Oct 27, 2024 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 57,006 |  |  | $ | 46,743 |  |  | $ | 35,082 |  |  | 22 | % |  | 62 | % |
| Gross margin | 73.4 | % |  | 72.4 | % |  | 74.6 | % |  | 1.0 | pts |  | (1.2) | pts |
| Operating expenses | $ | 5,839 |  |  | $ | 5,413 |  |  | $ | 4,287 |  |  | 8 | % |  | 36 | % |
| Operating income | $ | 36,010 |  |  | $ | 28,440 |  |  | $ | 21,869 |  |  | 27 | % |  | 65 | % |
| Net income | $ | 31,910 |  |  | $ | 26,422 |  |  | $ | 19,309 |  |  | 21 | % |  | 65 | % |
| Net income per diluted share | $ | 1.30 |  |  | $ | 1.08 |  |  | $ | 0.78 |  |  | 20 | % |  | 67 | % |

[0001045810-25-000230:mdna:24]
Revenue was $57.0 billion, up 62% from a year ago and up 22% sequentially.

[0001045810-25-000230:mdna:25]
Data Center revenue was $51.2 billion, up 66% from a year ago and up 25% sequentially, driven by three platform shifts –accelerated computing, powerful AI models, and agentic applications. Blackwell Ultra is now our leading architecture across all customer categories while our prior Blackwell architecture saw continued strong demand. H20 sales were insignificant in the third quarter of fiscal year 2026.

[0001045810-25-000230:mdna:26]
Data Center compute revenue was $43.0 billion, up 56% from a year ago and up 27% sequentially. Networking revenue was $8.2 billion, up 162% from a year ago from the introduction and continued growth of NVLink compute fabric for

[0001045810-25-000230:mdna:27]
26

[0001045810-25-000230:mdna:28]
GB200 and GB300 systems. Networking revenue was up 13% sequentially, driven by the growth of XDR InfiniBand products, NVLink, and Ethernet for AI solutions, while shipment timing and supply availability varied compared to the prior quarter.

[0001045810-25-000230:mdna:29]
Gaming revenue was up 30% from a year ago on the continued demand for Blackwell. Gaming revenue was down 1% sequentially as channel inventories have reached more normalized levels heading into the holiday season.

[0001045810-25-000230:mdna:30]
Professional Visualization revenue was up 56% from a year ago and up 26% sequentially, driven by the launch of our new DGX Spark as well as the growth of Blackwell sales.

[0001045810-25-000230:mdna:31]
Automotive revenue was up 32% from a year ago and up 1% sequentially, driven by continued adoption of our self-driving platforms.

[0001045810-25-000230:mdna:32]
Gross margin decreased from a year ago as our business model transitioned from offering Hopper HGX systems to Blackwell full-scale datacenter solutions. Gross margin increased sequentially as Blackwell ramped with an improved mix and cost structure.

[0001045810-25-000230:mdna:33]
Operating expenses were up 36% from a year ago and up 8% sequentially. The increases were primarily driven by compute and infrastructure costs, higher compensation and benefits due to compensation increases and employee growth and engineering development costs for new product introductions.

[0001045810-25-000230:mdna:34]
[same as prior period, unchanged from 0001045810-25-000209:mdna:34]

[0001045810-25-000230:mdna:35]
[same as prior period, unchanged from 0001045810-25-000209:mdna:35]

[0001045810-25-000230:mdna:36]
[same as prior period, unchanged from 0001045810-25-000209:mdna:36]

[0001045810-25-000230:mdna:37]
[same as prior period, unchanged from 0001045810-25-000209:mdna:37]

[0001045810-25-000230:mdna:38]
[same as prior period, unchanged from 0001045810-25-000209:mdna:38]

[0001045810-25-000230:mdna:39]
[same as prior period, unchanged from 0001045810-25-000209:mdna:39]

[0001045810-25-000230:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 26.6 |  |  | 25.4 |  |  | 30.7 |  |  | 24.2 |  |
| Gross profit | 73.4 |  |  | 74.6 |  |  | 69.3 |  |  | 75.8 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 8.3 |  |  | 9.7 |  |  | 8.8 |  |  | 10.1 |  |
| Sales, general and administrative | 2.0 |  |  | 2.6 |  |  | 2.2 |  |  | 2.8 |  |
| Total operating expenses | 10.3 |  |  | 12.3 |  |  | 11.0 |  |  | 12.9 |  |
| Operating income | 63.1 |  |  | 62.3 |  |  | 58.3 |  |  | 62.9 |  |
| Interest income | 1.1 |  |  | 1.3 |  |  | 1.2 |  |  | 1.4 |  |
| Interest expense | (0.1) |  |  | (0.2) |  |  | (0.1) |  |  | (0.2) |  |
| Other income, net | 2.4 |  |  | 0.1 |  |  | 2.3 |  |  | 0.3 |  |
| Total other income, net | 3.4 |  |  | 1.2 |  |  | 3.4 |  |  | 1.5 |  |
| Income before income tax | 66.5 |  |  | 63.5 |  |  | 61.7 |  |  | 64.4 |  |
| Income tax expense | 10.6 |  |  | 8.6 |  |  | 9.4 |  |  | 8.8 |  |
| Net income | 55.9 | % |  | 54.9 | % |  | 52.3 | % |  | 55.6 | % |

[0001045810-25-000230:mdna:41]
27

[0001045810-25-000230:mdna:42]
[same as prior period, unchanged from 0001045810-25-000209:mdna:41]

[0001045810-25-000230:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | %Change |  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 50,908 |  |  | $ | 31,036 |  |  | $ | 19,872 |  |  | 64 | % |  | $ | 131,828 |  |  | $ | 80,157 |  |  | $ | 51,671 |  |  | 64 | % |
| Graphics | 6,098 |  |  | 4,046 |  |  | 2,052 |  |  | 51 | % |  | 15,983 |  |  | 11,009 |  |  | 4,974 |  |  | 45 | % |
| Total | $ | 57,006 |  |  | $ | 35,082 |  |  | $ | 21,924 |  |  | 62 | % |  | $ | 147,811 |  |  | $ | 91,166 |  |  | $ | 56,645 |  |  | 62 | % |

[0001045810-25-000230:mdna:44]
[same as prior period, unchanged from 0001045810-25-000209:mdna:43]

[0001045810-25-000230:mdna:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | %Change |  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 35,721 |  |  | $ | 22,081 |  |  | $ | 13,640 |  |  | 62 | % |  | $ | 86,139 |  |  | $ | 57,977 |  |  | $ | 28,162 |  |  | 49 | % |
| Graphics | 2,546 |  |  | 1,502 |  |  | 1,044 |  |  | 70 | % |  | $ | 6,428 |  |  | 4,111 |  |  | 2,317 |  |  | 56 | % |
| Total | $ | 38,267 |  |  | $ | 23,583 |  |  | $ | 14,684 |  |  | 62 | % |  | $ | 92,567 |  |  | $ | 62,088 |  |  | $ | 30,479 |  |  | 49 | % |

[0001045810-25-000230:mdna:46]
Compute & Networking revenue – The year over year increase in the third quarter and first nine months of fiscal year 2026 was driven by three platform shifts –accelerated computing, powerful AI models, and agentic applications. Revenue from Data Center computing grew 59% year-on-year compared to the first nine months of fiscal year 2025, driven by demand for our Blackwell computing platform. Revenue from Data Center networking grew 105% year-on-year compared to the first nine months of fiscal year 2025 driven by the introduction and continued growth of NVLink compute fabric for GB200 and GB300 systems, the growth of XDR InfiniBand products, and adoption of Ethernet for AI solutions.

[0001045810-25-000230:mdna:47]
Graphics revenue – The year over year increase in the third quarter and first nine months of fiscal year 2026 was driven by sales of our Blackwell architecture.

[0001045810-25-000230:mdna:48]
Reportable segment operating income – The year over year increase in Compute & Networking segment operating income in the third quarter of fiscal year 2026 was driven by growth in revenue. The year over year increase in Compute & Networking segment operating income in the first nine months of fiscal year 2026 was driven by the growth in revenue, partially offset by a $4.5 billion charge associated with H20 excess inventory and purchase obligations in the first quarter of fiscal year 2026. The year over year increase in Graphics segment operating income in the third quarter and first nine months of fiscal year 2026 was driven by the growth in revenue.

[0001045810-25-000230:mdna:49]
[same as prior period, unchanged from 0001045810-25-000209:mdna:48]

[0001045810-25-000230:mdna:50]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, ODMs, OEMs, CSPs, hyperscale companies, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, Neocloud builders, hyperscale, consumer internet companies, enterprises, and public sector entities.

[0001045810-25-000230:mdna:51]
Direct Customers – For the third quarter of fiscal year 2026, four direct customers with sales greater than 10% of total revenue included: Customer A at 22%, Customer B at 15%, Customer C at 13%, and Customer D at 11%, which were attributable to the Compute & Networking segment. For the first nine months of fiscal year 2026, sales to two direct customers represented 21% and 13% of total revenue, respectively, both of which were attributable to the Compute & Networking segment. The customers referenced above may represent different customers than those reported in a previous period.

[0001045810-25-000230:mdna:52]
For the third quarter of fiscal year 2025, sales to three direct customers each represented 12% of total revenue, which were attributable to the Compute & Networking segment. For the first nine months of fiscal year 2025, sales to three direct customers represented 12%, 11%, and 11% of total revenue, which were attributable to the Compute & Networking segment.

[0001045810-25-000230:mdna:53]
Indirect Customers – Indirect customer revenue is an estimation based upon multiple factors including customer purchase order information, product specifications, internal sales data, and other sources. Indirect customers primarily purchase our products through system integrators and distributors.

[0001045810-25-000230:mdna:54]
We generate a significant amount of our revenue from a limited number of indirect customers, some individually representing 10% or more of our revenue. Certain companies purchase cloud and related services through various direct and indirect customers. We estimate that one AI research and deployment company contributed to a meaningful amount of our revenue purchasing cloud services from our customers in the third quarter of fiscal year 2026. Our revenue is concentrated among a limited number of direct, indirect and cloud service purchasers and this trend may continue.

[0001045810-25-000230:mdna:55]
Revenue by geographic region is designated based on the location of the customers' headquarters of direct customers even if the estimated revenue may be attributable to indirect customers in a different location. Revenue from sales to customers headquartered outside of the United States accounted for 31% and 34% of total revenue for the third quarter and first nine months of fiscal year 2026, respectively, and 44% and 41% of total revenue for the third quarter and first nine months of fiscal year 2025, respectively.

[0001045810-25-000230:mdna:56]
[same as prior period, unchanged from 0001045810-25-000209:mdna:57]

[0001045810-25-000230:mdna:57]
[same as prior period, unchanged from 0001045810-25-000209:mdna:58]

[0001045810-25-000230:mdna:58]
Gross margins decreased to 73.4% for the third quarter of fiscal year 2026 compared to 74.6% for the third quarter of fiscal year 2025, and 69.3% for the first nine months of fiscal year 2026 compared to 75.8% for the first nine months of fiscal year 2025, as our business model transitioned from offering Hopper HGX systems to Blackwell full-scale datacenter solutions. Gross margin for the first nine months of fiscal year 2026 was also impacted by a $4.5 billion charge associated with H20 excess inventory and purchase obligations.

[0001045810-25-000230:mdna:59]
Provisions for inventory and excess inventory purchase obligations totaled $410 million and $6.7 billion for the third quarter and first nine months of fiscal year 2026, respectively, including $4.5 billion associated with H20 excess inventory and purchase obligations for the first quarter of fiscal year 2026. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $366 million and $1.3 billion for the third quarter and first nine months of fiscal year 2026, respectively. The net effect on our gross margin was an unfavorable impact of 0.1% and 3.7% in the third quarter and first nine months of fiscal year 2026, respectively.

[0001045810-25-000230:mdna:60]
Provisions for inventory and excess inventory purchase obligations totaled $865 million and $2.2 billion for the third quarter and first nine months of fiscal year 2025, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $106 million and $305 million for the third quarter and first nine months of fiscal year 2025, respectively. The net effect on our gross margin was an unfavorable impact of 2.2% and 2.0% in the third quarter and first nine months of fiscal year 2025, respectively.

[0001045810-25-000230:mdna:61]
[same as prior period, unchanged from 0001045810-25-000209:mdna:62]

[0001045810-25-000230:mdna:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | %Change |  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 4,705 |  |  | $ | 3,390 |  |  | $ | 1,315 |  |  | 39 | % |  | $ | 12,985 |  |  | $ | 9,200 |  |  | $ | 3,785 |  |  | 41 | % |
| Sales, general and administrative expenses | 1,134 |  |  | 897 |  |  | 237 |  |  | 26 | % |  | 3,297 |  |  | 2,516 |  |  | 781 |  |  | 31 | % |
| Total operating expenses | $ | 5,839 |  |  | $ | 4,287 |  |  | $ | 1,552 |  |  | 36 | % |  | $ | 16,282 |  |  | $ | 11,716 |  |  | $ | 4,566 |  |  | 39 | % |

[0001045810-25-000230:mdna:63]
The increases in research and development expenses for the third quarter and first nine months of fiscal year 2026 were primarily driven by a 27% and 30% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, and an 83% and 75% increase in compute and infrastructure, respectively.

[0001045810-25-000230:mdna:64]
The increases in sales, general and administrative expenses for the third quarter and first nine months of fiscal year 2026 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-25-000230:mdna:65]
Total Other Income, Net

[0001045810-25-000230:mdna:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |  | Oct 26, 2025 |  | Oct 27, 2024 |  | $Change |
|  | ($ in millions) |
| Interest income | $ | 624 |  |  | $ | 472 |  |  | $ | 152 |  |  | $ | 1,732 |  |  | $ | 1,275 |  |  | $ | 457 |  |
| Interest expense | (61) |  |  | (61) |  |  | — |  |  | (186) |  |  | (186) |  |  | — |  |
| Other income, net | 1,363 |  |  | 36 |  |  | 1,327 |  |  | 3,418 |  |  | 301 |  |  | 3,117 |  |
| Total other income, net | $ | 1,926 |  |  | $ | 447 |  |  | $ | 1,479 |  |  | $ | 4,964 |  |  | $ | 1,390 |  |  | $ | 3,574 |  |

[0001045810-25-000230:mdna:67]
The increase in interest income for the third quarter and first nine months of fiscal year 2026 was primarily due to growth in cash, cash equivalents, and debt securities.

[0001045810-25-000230:mdna:68]
[same as prior period, unchanged from 0001045810-25-000209:mdna:69]

[0001045810-25-000230:mdna:69]
Other income, net consists of realized or unrealized gains and losses from investments in non-marketable equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other income, net, compared to the third quarter and first nine months of fiscal year 2025, was primarily driven by unrealized gains in our publicly-held equity securities and non-marketable equity securities. Refer to Notes 5 and 6 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding our investments in non-marketable equity securities and publicly-held equity securities.

[0001045810-25-000230:mdna:70]
[same as prior period, unchanged from 0001045810-25-000209:mdna:71]

[0001045810-25-000230:mdna:71]
Income tax expense was $6.0 billion and $3.0 billion for the third quarter, and $13.9 billion and $8.0 billion for the first nine months, of fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 15.9% and 13.5% for the third quarter, and 15.3% and 13.6% for the first nine months, of fiscal years 2026 and 2025, respectively.

[0001045810-25-000230:mdna:72]
The effective tax rate increased primarily due to a lower percentage of tax benefits from stock-based compensation and U.S. federal research tax credit relative to the increase in income before income tax.

[0001045810-25-000230:mdna:73]
Our effective tax rates for the first nine months of fiscal years 2026 and 2025 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from foreign-derived deduction eligible income, stock-based compensation, income earned in jurisdictions that are subject to taxes at rates lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit.

[0001045810-25-000230:mdna:74]
In July 2025, the OBBBA was enacted into law and contains several changes to key U.S. federal income tax laws. We have recognized the tax effects of currently effective OBBBA provisions, which are not material and are reflected in our results for the first nine months of fiscal year 2026. We will continue to evaluate the impact of these legislative changes as tax authorities provide additional guidance and interpretation.

[0001045810-25-000230:mdna:75]
[same as prior period, unchanged from 0001045810-25-000209:mdna:75]

[0001045810-25-000230:mdna:76]
[same as prior period, unchanged from 0001045810-25-000209:mdna:76]

[0001045810-25-000230:mdna:77]
[same as prior period, unchanged from 0001045810-25-000209:mdna:77]

[0001045810-25-000230:mdna:78]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
|  | (In millions) |
| Cash and cash equivalents | $ | 11,486 |  |  | $ | 8,589 |  |
| Marketable securities | 49,122 |  |  | 34,621 |  |
| Cash, cash equivalents and marketable securities | $ | 60,608 |  |  | $ | 43,210 |  |

[0001045810-25-000230:mdna:79]
|  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 66,530 |  |  | $ | 47,460 |  |
| Net cash used in investing activities | $ | (21,367) |  |  | $ | (13,223) |  |
| Net cash used in financing activities | $ | (42,266) |  |  | $ | (32,410) |  |

[0001045810-25-000230:mdna:80]
[same as prior period, unchanged from 0001045810-25-000209:mdna:80]

[0001045810-25-000230:mdna:81]
Cash provided by operating activities increased in the first nine months of fiscal year 2026 compared to the first nine months of fiscal year 2025 due to higher revenue.

[0001045810-25-000230:mdna:82]
Cash used in investing activities increased in the first nine months of fiscal year 2026 compared to the first nine months of fiscal year 2025, primarily driven by higher purchases of non-marketable equity securities and higher purchases of property and equipment.

[0001045810-25-000230:mdna:83]
Cash used in financing activities increased in the first nine months of fiscal year 2026 compared to the first nine months of fiscal year 2025, mainly due to higher share repurchases.

[0001045810-25-000230:mdna:84]
[same as prior period, unchanged from 0001045810-25-000209:mdna:84]

[0001045810-25-000230:mdna:85]
Our primary sources of liquidity include cash, cash equivalents, marketable securities, and cash generated by our operations. As of October 26, 2025, we had $60.6 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and thereafter for the foreseeable future, including our future obligations. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-25-000230:mdna:86]
[same as prior period, unchanged from 0001045810-25-000209:mdna:86]

[0001045810-25-000230:mdna:87]
Except for approximately $1.7 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. at the end of the first nine months of fiscal year 2026 are available for use in the U.S. without incurring additional U.S. federal income taxes. Our tax payments in fiscal year 2026 will decrease due to currently effective OBBBA provisions.

[0001045810-25-000230:mdna:88]
[same as prior period, unchanged from 0001045810-25-000209:mdna:88]

[0001045810-25-000230:mdna:89]
We repurchased 70 million and 262 million shares of our common stock for $12.6 billion and $36.7 billion during the third quarter and first nine months of fiscal year 2026, respectively. On August 26, 2025, our Board of Directors approved an additional $60.0 billion in share repurchase authorization, without expiration.  As of October 26, 2025, we were authorized, subject to certain specifications, to repurchase up to $62.2 billion of our common stock.

[0001045810-25-000230:mdna:90]
From October 27, 2025 through November 14, 2025, we repurchased 6 million shares for $1.1 billion pursuant to a pre-established trading plan. We may execute repurchases from time to time, subject to market conditions, operating requirements and other investment opportunities, in the open market, in privately negotiated transactions, pursuant to a Rule 10b5-1 trading plan or in structured share repurchase agreements in compliance with Rule 10b-18 of the Exchange Act. Our share repurchase program may be suspended at any time at our discretion.

[0001045810-25-000230:mdna:91]
We paid cash dividends to our shareholders of $243 million and $732 million during the third quarter and first nine months of fiscal year 2026, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.

[0001045810-25-000230:mdna:92]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for both the third quarter and first nine months of fiscal years 2026 and 2025.

[0001045810-25-000230:mdna:93]
31

[0001045810-25-000230:mdna:94]
[same as prior period, unchanged from 0001045810-25-000209:mdna:93]

[0001045810-25-000230:mdna:95]
Our aggregate debt maturities as of October 26, 2025, by year payable, are as follows:

[0001045810-25-000230:mdna:96]
|  |  | Oct 26, 2025 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,000 |  |
| Due in one to five years |  | $ | 2,750 |  |
| Due in five to ten years |  | 1,250 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (33) |  |
| Net carrying amount |  | $ | 8,467 |  |
| Less short-term portion |  | (999) |  |
| Total long-term portion |  | $ | 7,468 |  |

[0001045810-25-000230:mdna:97]
We have a $575 million commercial paper program to support general corporate purposes. As of October 26, 2025, we had no commercial paper outstanding.

[0001045810-25-000230:mdna:98]
[same as prior period, unchanged from 0001045810-25-000209:mdna:97]

[0001045810-25-000230:mdna:99]
[same as prior period, unchanged from 0001045810-25-000209:mdna:98]

[0001045810-25-000230:mdna:100]
Unrecognized tax benefits were $3.2 billion, which includes related interest and penalties, and were recorded in non-current income tax payable as of October 26, 2025. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 4 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-25-000230:mdna:101]
We expect to continue investing in strategic partnerships. In the third quarter of fiscal year 2026, we committed to invest $5 billion in Intel Corporation, subject to regulatory approval, and we entered into a letter of intent with an opportunity to invest in OpenAI. In November 2025, we entered into an agreement, subject to certain closing conditions, to invest up to $10 billion in Anthropic. There is no assurance that any investment will be completed on expected terms, if at all. Refer to Item 1A. Risk Factors for additional information regarding our investments.

[0001045810-25-000230:mdna:102]
Other than the contractual obligations described in Note 11, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025 for a description of our contractual obligations. For a description of our long-term debt, purchase obligations, and operating lease obligations, refer to Notes 10, 11, and 14 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q, respectively.

[0001045810-25-000230:mdna:103]
[same as prior period, unchanged from 0001045810-25-000209:mdna:101]

[0001045810-25-000230:mdna:104]
[same as prior period, unchanged from 0001045810-25-000209:mdna:102]

[0001045810-25-000230:mdna:105]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-25-000230:mdna:106]
There has been no adoption of any new and recently issued accounting pronouncements.
