# NVDA note change history — 0001045810-25-000209 → 0001045810-25-000230


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2025-11-19):
[0001045810-25-000230:note_history:1]
Manufacturing production, long-term supply and capacity, and other related commitments reflect long lead and cycle times for our current and future product architectures. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. As of October 26, 2025, these commitments were $50.3 billion, of which substantially all will be paid through fiscal year 2027.

- added (2025-11-19):
[0001045810-25-000230:note_history:2]
Multi-year cloud service agreement commitments as of October 26, 2025, were $26 billion for which $1 billion, $6 billion, $6 billion, $5 billion, $4 billion, and $4 billion will be paid in fiscal years 2026 (fourth quarter), 2027, 2028, 2029, 2030, and 2031 & thereafter, respectively. Some cloud service capacity may be reduced, terminated or sold to others by the CSPs, in which case our commitments will be reduced. We expect cloud service agreements to be used to support our research and development efforts and DGX Cloud offerings.
nvestment commitments are $6.5 billion as of October 26, 2025, including $5 billion in Intel Corporation which is subject to regulatory approval. In the third quarter of fiscal year 2026, we entered into a letter of intent with an opportunity to invest in OpenAI. In November 2025, we entered into an agreement, subject to certain closing conditions, to invest up to $10 billion in Anthropic.
Other commitments were $2.1 billion as of October 26, 2025, of which the majority will be paid through fiscal year 2027.

- added (2025-11-19):
[0001045810-25-000230:note_history:3]
The estimated product warranty activity consisted of the following:

- added (2025-11-19):
[0001045810-25-000230:note_history:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,144 |  |  | $ | 741 |  |  | $ | 1,290 |  |  | $ | 306 |  |
| Additions | 1,074 |  |  | 304 |  |  | 2,164 |  |  | 775 |  |
| Utilization | (511) |  |  | (36) |  |  | (747) |  |  | (72) |  |
| Balance at end of period | $ | 2,707 |  |  | $ | 1,009 |  |  | $ | 2,707 |  |  | $ | 1,009 |  |

- changed (2025-11-19):
[0001045810-25-000230:note_history:5]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.
  (was, 2025-08-27, similarity 0.8417):
[0001045810-25-000209:note_history:5]
NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

- changed (2025-11-19):
[0001045810-25-000230:note_history:6]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the
  (was, 2025-08-27, similarity 0.7614):
[0001045810-25-000209:note_history:6]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2025-11-19):
[0001045810-25-000230:note_history:7]
Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2025-11-19):
[0001045810-25-000230:note_history:8]
As of October 26, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.

- removed (2025-11-19):
[0001045810-25-000209:note_history:9]
Our commitments include obligations to purchase components used to manufacture our products, including certain software and technology licenses, investments, long-lived assets, long-term supply and capacity agreements, multi-year cloud service agreements, and other goods and services.

- removed (2025-11-19):
[0001045810-25-000209:note_history:10]
We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs.

- removed (2025-11-19):
[0001045810-25-000209:note_history:11]
Total future commitments as of July 27, 2025 are as follows:

- removed (2025-11-19):
[0001045810-25-000209:note_history:12]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first half of fiscal year 2026) | $ | 30,930 |  |
| 2027 | 6,573 |  |
| 2028 | 3,915 |  |
| 2029 | 2,736 |  |
| 2030 | 1,402 |  |
| 2031 and thereafter | 218 |  |
| Total | $ | 45,774 |  |

- removed (2025-11-19):
[0001045810-25-000209:note_history:13]
The estimated amount of product warranty liabilities was $2.1 billion and $1.3 billion as of July 27, 2025 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:

- removed (2025-11-19):
[0001045810-25-000209:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 27, 2025 |  | Jul 28, 2024 |  | Jul 27, 2025 |  | Jul 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,080 |  |  | $ | 532 |  |  | $ | 1,290 |  |  | $ | 306 |  |
| Additions | 220 |  |  | 237 |  |  | 1,090 |  |  | 471 |  |
| Utilization | (156) |  |  | (28) |  |  | (236) |  |  | (36) |  |
| Balance at end of period | $ | 2,144 |  |  | $ | 741 |  |  | $ | 2,144 |  |  | $ | 741 |  |

- removed (2025-11-19):
[0001045810-25-000209:note_history:15]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the

- removed (2025-11-19):
[0001045810-25-000209:note_history:16]
As of July 27, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-19):
[0001045810-25-000230:note_history:17]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The third quarters of fiscal years 2026 and 2025 were both 13-week quarters.
  (was, 2025-08-27, similarity 0.9701):
[0001045810-25-000209:note_history:17]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The second quarters of fiscal years 2026 and 2025 were both 13-week quarters.

- changed (2025-11-19):
[0001045810-25-000230:note_history:18]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.
  (was, 2025-08-27, similarity 0.9952):
[0001045810-25-000209:note_history:18]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

- changed (2025-11-19):
[0001045810-25-000230:note_history:19]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in the fiscal year 2026 annual report.
  (was, 2025-08-27, similarity 0.7445):
[0001045810-25-000209:note_history:19]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending January 25, 2026.

- changed (2025-11-19):
[0001045810-25-000230:note_history:20]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.
  (was, 2025-08-27, similarity 0.9948):
[0001045810-25-000209:note_history:20]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in our fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-19):
[0001045810-25-000230:note_history:21]
Debt

- changed (2025-11-19):
[0001045810-25-000230:note_history:22]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 26, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.9 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (33) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,467 |  |  | $ | 8,463 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 7,468 |  |  | $ | 8,463 |  |
  (was, 2025-08-27, similarity 0.8983):
[0001045810-25-000209:note_history:22]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.1 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (34) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,466 |  |  | $ | 8,463 |  |

- changed (2025-11-19):
[0001045810-25-000230:note_history:23]
As of October 26, 2025 and January 26, 2025, the estimated fair value of debt was $7.6 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.
  (was, 2025-08-27, similarity 0.9666):
[0001045810-25-000209:note_history:23]
As of July 27, 2025 and January 26, 2025, the estimated fair value of debt was $7.4 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

- changed (2025-11-19):
[0001045810-25-000230:note_history:24]
As of October 26, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2025-08-27, similarity 0.9544):
[0001045810-25-000209:note_history:24]
As of July 27, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2025-11-19):
[0001045810-25-000230:note_history:25]
Short-term Debt
  (was, 2025-08-27, similarity 0.6471):
[0001045810-25-000209:note_history:25]
Debt
Long-Term Debt

- added (2025-11-19):
[0001045810-25-000230:note_history:26]
As of October 26, 2025, short-term debt was $999 million.

- changed (2025-11-19):
[0001045810-25-000230:note_history:27]
We have a $575 million commercial paper program to support general corporate purposes. As of October 26, 2025 and January 26, 2025, we had no commercial paper outstanding.
  (was, 2025-08-27, similarity 0.9649):
[0001045810-25-000209:note_history:27]
We have a $575 million commercial paper program to support general corporate purposes. As of July 27, 2025 and January 26, 2025, we had no commercial paper outstanding.

- removed (2025-11-19):
[0001045810-25-000209:note_history:28]
Commercial Paper


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-19):
[0001045810-25-000230:note_history:29]
|  | Oct 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 22,032 |  |  | $ | 188 |  |  | $ | — |  |  | $ | 22,220 |  |  | $ | 665 |  |  | $ | 21,555 |  |
| Corporate debt securities | Level 2 | 21,588 |  |  | 172 |  |  | (1) |  |  | 21,759 |  |  | 320 |  |  | 21,439 |  |
| Money market funds | Level 1 | 8,610 |  |  | — |  |  | — |  |  | 8,610 |  |  | 8,610 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,206 |  |  | 12 |  |  | — |  |  | 2,218 |  |  | — |  |  | 2,218 |  |
| Certificates of deposit | Level 2 | 104 |  |  | — |  |  | — |  |  | 104 |  |  | 104 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 54,580 |  |  | 373 |  |  | (1) |  |  | 54,952 |  |  | 9,699 |  |  | 45,253 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,869 |  |  | — |  |  | 3,869 |  |
| Total |  | $ | 54,580 |  |  | $ | 373 |  |  | $ | (1) |  |  | $ | 58,821 |  |  | $ | 9,699 |  |  | $ | 49,122 |  |
  (was, 2025-08-27, similarity 0.8897):
[0001045810-25-000209:note_history:29]
|  | Jul 27, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 23,967 |  |  | $ | 76 |  |  | $ | (11) |  |  | $ | 24,032 |  |  | $ | 3,784 |  |  | $ | 20,248 |  |
| Corporate debt securities | Level 2 | 21,564 |  |  | 81 |  |  | (9) |  |  | 21,636 |  |  | 2,214 |  |  | 19,422 |  |
| Money market funds | Level 1 | 5,245 |  |  | — |  |  | — |  |  | 5,245 |  |  | 5,245 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,238 |  |  | 7 |  |  | (2) |  |  | 2,243 |  |  | — |  |  | 2,243 |  |
| Certificates of deposit | Level 2 | 108 |  |  | — |  |  | — |  |  | 108 |  |  | 108 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 53,162 |  |  | 164 |  |  | (22) |  |  | 53,304 |  |  | 11,351 |  |  | 41,953 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,199 |  |  | — |  |  | 3,199 |  |
| Total |  | $ | 53,162 |  |  | $ | 164 |  |  | $ | (22) |  |  | $ | 56,503 |  |  | $ | 11,351 |  |  | $ | 45,152 |  |

- changed (2025-11-19):
[0001045810-25-000230:note_history:30]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading.
  (was, 2025-08-27, similarity 0.7207):
[0001045810-25-000209:note_history:30]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of July 27, 2025 was $2.8 billion and was subject to a short-term restriction on the ability to sell.

- changed (2025-11-19):
[0001045810-25-000230:note_history:31]
|  | Oct 26, 2025 |
|  | (In millions) |
| Less than one year | $ | 21,848 |  |
| Due in 1 - 5 years | 33,104 |  |
| Total | $ | 54,952 |  |
  (was, 2025-08-27, similarity 0.9739):
[0001045810-25-000209:note_history:31]
|  | Jul 27, 2025 |
|  | (In millions) |
| Less than one year | $ | 22,521 |  |
| Due in 1 - 5 years | 30,783 |  |
| Total | $ | 53,304 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-19):
[0001045810-25-000230:note_history:32]
|  | Oct 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 22,032 |  |  | $ | 188 |  |  | $ | — |  |  | $ | 22,220 |  |  | $ | 665 |  |  | $ | 21,555 |  |
| Corporate debt securities | Level 2 | 21,588 |  |  | 172 |  |  | (1) |  |  | 21,759 |  |  | 320 |  |  | 21,439 |  |
| Money market funds | Level 1 | 8,610 |  |  | — |  |  | — |  |  | 8,610 |  |  | 8,610 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,206 |  |  | 12 |  |  | — |  |  | 2,218 |  |  | — |  |  | 2,218 |  |
| Certificates of deposit | Level 2 | 104 |  |  | — |  |  | — |  |  | 104 |  |  | 104 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 54,580 |  |  | 373 |  |  | (1) |  |  | 54,952 |  |  | 9,699 |  |  | 45,253 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,869 |  |  | — |  |  | 3,869 |  |
| Total |  | $ | 54,580 |  |  | $ | 373 |  |  | $ | (1) |  |  | $ | 58,821 |  |  | $ | 9,699 |  |  | $ | 49,122 |  |
  (was, 2025-08-27, similarity 0.8897):
[0001045810-25-000209:note_history:32]
|  | Jul 27, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 23,967 |  |  | $ | 76 |  |  | $ | (11) |  |  | $ | 24,032 |  |  | $ | 3,784 |  |  | $ | 20,248 |  |
| Corporate debt securities | Level 2 | 21,564 |  |  | 81 |  |  | (9) |  |  | 21,636 |  |  | 2,214 |  |  | 19,422 |  |
| Money market funds | Level 1 | 5,245 |  |  | — |  |  | — |  |  | 5,245 |  |  | 5,245 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,238 |  |  | 7 |  |  | (2) |  |  | 2,243 |  |  | — |  |  | 2,243 |  |
| Certificates of deposit | Level 2 | 108 |  |  | — |  |  | — |  |  | 108 |  |  | 108 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 53,162 |  |  | 164 |  |  | (22) |  |  | 53,304 |  |  | 11,351 |  |  | 41,953 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,199 |  |  | — |  |  | 3,199 |  |
| Total |  | $ | 53,162 |  |  | $ | 164 |  |  | $ | (22) |  |  | $ | 56,503 |  |  | $ | 11,351 |  |  | $ | 45,152 |  |

- changed (2025-11-19):
[0001045810-25-000230:note_history:33]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading.
  (was, 2025-08-27, similarity 0.7207):
[0001045810-25-000209:note_history:33]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of July 27, 2025 was $2.8 billion and was subject to a short-term restriction on the ability to sell.

- added (2025-11-19):
[0001045810-25-000230:note_history:34]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $670 million and $2.4 billion for the third quarter and first nine months of fiscal year 2026, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for the third quarter and first nine months of fiscal year 2025.

- changed (2025-11-19):
[0001045810-25-000230:note_history:35]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,223 |  |  | $ | — |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 899 |  |  | (1) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 75 |  |  | — |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 2,197 |  |  | $ | (1) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |
  (was, 2025-08-27, similarity 0.7757):
[0001045810-25-000209:note_history:35]
|  | Jul 27, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 7,319 |  |  | $ | (11) |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 3,539 |  |  | (9) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 768 |  |  | (2) |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 11,626 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

- changed (2025-11-19):
[0001045810-25-000230:note_history:36]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater, with balances of $337 million and $213 million as of October 26, 2025 and January 26, 2025, respectively, were not significant.
  (was, 2025-08-27, similarity 0.9751):
[0001045810-25-000209:note_history:36]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater, with balances of $15 million and $213 million as of July 27, 2025 and January 26, 2025, respectively, were not significant.

- changed (2025-11-19):
[0001045810-25-000230:note_history:37]
|  | Oct 26, 2025 |
|  | (In millions) |
| Less than one year | $ | 21,848 |  |
| Due in 1 - 5 years | 33,104 |  |
| Total | $ | 54,952 |  |
  (was, 2025-08-27, similarity 0.9739):
[0001045810-25-000209:note_history:37]
|  | Jul 27, 2025 |
|  | (In millions) |
| Less than one year | $ | 22,521 |  |
| Due in 1 - 5 years | 30,783 |  |
| Total | $ | 53,304 |  |

- removed (2025-11-19):
[0001045810-25-000209:note_history:38]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $1.9 billion and $1.7 billion for the second quarter and first half of fiscal year 2026, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were $132 million and $181 million for the second quarter and first half of fiscal year 2025, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-19):
[0001045810-25-000230:note_history:39]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 26, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.9 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (33) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,467 |  |  | $ | 8,463 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 7,468 |  |  | $ | 8,463 |  |
  (was, 2025-08-27, similarity 0.8983):
[0001045810-25-000209:note_history:39]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.1 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (34) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,466 |  |  | $ | 8,463 |  |
