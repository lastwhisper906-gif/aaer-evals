# NVDA 8-K — 0001045810-25-000228 filed 2025-11-19

## item codes, every 8-K on or before 2025-11-19

- 2025-11-19 0001045810-25-000228 — 2.02, 9.01
- 2025-08-27 0001045810-25-000207 — 2.02, 9.01
- 2025-08-05 0001045810-25-000197 — 5.02
- 2025-07-01 0001045810-25-000179 — 5.07
- 2025-05-28 0001045810-25-000115 — 2.02, 9.01
- 2025-04-15 0001045810-25-000082 — 8.01
- 2025-03-07 0001045810-25-000039 — 5.02
- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2025-11-19

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-25-000228:8k_2_02:1]
EX-99.1
2
q3fy26pr.htm
EX-99.1

[0001045810-25-000228:8k_2_02:2]
Document

[0001045810-25-000228:8k_2_02:3]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2026

[0001045810-25-000228:8k_2_02:4]
•Record revenue of $57.0 billion, up 22% from Q2 and up 62% from a year ago

[0001045810-25-000228:8k_2_02:5]
•Record Data Center revenue of $51.2 billion, up 25% from Q2 and up 66% from a year ago

[0001045810-25-000228:8k_2_02:6]
SANTA CLARA, Calif.—Nov. 19, 2025―NVIDIA (NASDAQ: NVDA) today reported record revenue for the third quarter ended October 26, 2025, of $57.0 billion, up 22% from the previous quarter and up 62% from a year ago.

[0001045810-25-000228:8k_2_02:7]
For the quarter, GAAP and non-GAAP gross margins were 73.4% and 73.6%, respectively.

[0001045810-25-000228:8k_2_02:8]
For the quarter, GAAP and non-GAAP earnings per diluted share were both $1.30.

[0001045810-25-000228:8k_2_02:9]
“Blackwell sales are off the charts, and cloud GPUs are sold out,” said Jensen Huang, founder and CEO of NVIDIA. “Compute demand keeps accelerating and compounding across training and inference — each growing exponentially. We’ve entered the virtuous cycle of AI. The AI ecosystem is scaling fast — with more new foundation model makers, more AI startups, across more industries, and in more countries. AI is going everywhere, doing everything, all at once.”

[0001045810-25-000228:8k_2_02:10]
During the first nine months of fiscal 2026, NVIDIA returned $37.0 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the third quarter, the company had $62.2 billion remaining under its share repurchase authorization.

[0001045810-25-000228:8k_2_02:11]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on December 26, 2025, to all shareholders of record on December 4, 2025.

[0001045810-25-000228:8k_2_02:12]
Q3 Fiscal 2026 Summary

[0001045810-25-000228:8k_2_02:13]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY26 | Q2 FY26 | Q3 FY25 | Q/Q | Y/Y |
| Revenue | $57,006 | $46,743 | $35,082 | 22 | % | 62 | % |
| Gross margin | 73.4 | % | 72.4 | % | 74.6 | % | 1.0 pts | (1.2) pts |
| Operating expenses | $5,839 | $5,413 | $4,287 | 8 | % | 36 | % |
| Operating income | $36,010 | $28,440 | $21,869 | 27 | % | 65 | % |
| Net income | $31,910 | $26,422 | $19,309 | 21 | % | 65 | % |
| Diluted earnings per share | $1.30 | $1.08 | $0.78 | 20 | % | 67 | % |

[0001045810-25-000228:8k_2_02:14]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY26 | Q2 FY26 | Q3 FY25 | Q/Q | Y/Y |
| Revenue | $57,006 | $46,743 | $35,082 | 22 | % | 62 | % |
| Gross margin | 73.6 | % | 72.7 | % | 75.0 | % | 0.9 pts | (1.4) pts |
| Operating expenses | $4,215 | $3,795 | $3,046 | 11 | % | 38 | % |
| Operating income | $37,752 | $30,165 | $23,276 | 25 | % | 62 | % |
| Net income | $31,767 | $25,783 | $20,010 | 23 | % | 59 | % |
| Diluted earnings per share | $1.30 | $1.05 | $0.81 | 24 | % | 60 | % |

[0001045810-25-000228:8k_2_02:15]
Outlook

[0001045810-25-000228:8k_2_02:16]
NVIDIA’s outlook for the fourth quarter of fiscal 2026 is as follows:

[0001045810-25-000228:8k_2_02:17]
•Revenue is expected to be $65.0 billion, plus or minus 2%.

[0001045810-25-000228:8k_2_02:18]
•GAAP and non-GAAP gross margins are expected to be 74.8% and 75.0%, respectively, plus or minus 50 basis points.

[0001045810-25-000228:8k_2_02:19]
•GAAP and non-GAAP operating expenses are expected to be approximately $6.7 billion and $5.0 billion, respectively.

[0001045810-25-000228:8k_2_02:20]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $500 million, excluding gains and losses from non-marketable and publicly-held equity securities.

[0001045810-25-000228:8k_2_02:21]
•GAAP and non-GAAP tax rates are expected to be 17.0%, plus or minus 1%, excluding any discrete items.

[0001045810-25-000228:8k_2_02:22]
Highlights

[0001045810-25-000228:8k_2_02:23]
Data Center

[0001045810-25-000228:8k_2_02:24]
•Third-quarter revenue was a record $51.2 billion, up 25% from the previous quarter and up 66% from a year ago.

[0001045810-25-000228:8k_2_02:25]
•Revealed that NVIDIA Blackwell achieved the highest performance and best overall efficiency in the SemiAnalysis InferenceMAX benchmarks, while delivering 10x throughput per megawatt compared with the previous generation.

[0001045810-25-000228:8k_2_02:26]
•Announced a strategic partnership with OpenAI to deploy at least 10 gigawatts of NVIDIA systems for OpenAI’s next-generation AI infrastructure.

[0001045810-25-000228:8k_2_02:27]
•Partnered with industry leaders, including Google Cloud, Microsoft, Oracle and xAI, to build America’s AI infrastructure with hundreds of thousands of NVIDIA GPUs.

[0001045810-25-000228:8k_2_02:28]
•Announced that, for the first time, Anthropic will run and scale on NVIDIA infrastructure, initially adopting 1 gigawatt of compute capacity with NVIDIA Grace Blackwell and Vera Rubin systems.

[0001045810-25-000228:8k_2_02:29]
•Announced a collaboration with Intel to jointly develop multiple generations of custom data center and PC products with NVIDIA NVLink.

[0001045810-25-000228:8k_2_02:30]
•Revealed plans to accelerate seven new supercomputers, including with Oracle to build the U.S. Department of Energy’s largest AI supercomputer, Solstice, featuring 100,000 NVIDIA Blackwell GPUs, plus another system, Equinox, featuring 10,000 NVIDIA Blackwell GPUs.

[0001045810-25-000228:8k_2_02:31]
•Celebrated the first NVIDIA Blackwell wafer produced on U.S. soil at TSMC’s Arizona facility, representing revitalization of U.S. manufacturing as Blackwell reached volume production.

[0001045810-25-000228:8k_2_02:32]
•Unveiled NVIDIA Rubin CPX, a new class of GPU purpose-built for massive-context processing.

[0001045810-25-000228:8k_2_02:33]
•Introduced NVIDIA NVQLink™, an open system architecture for tightly coupling the extreme performance of NVIDIA GPU computing with quantum processors, which will be adopted by more than a dozen supercomputing centers globally.

[0001045810-25-000228:8k_2_02:34]
•Revealed that Arm is extending its Neoverse platform with NVIDIA NVLink Fusion™ to accelerate AI data center adoption.

[0001045810-25-000228:8k_2_02:35]
•Revealed that Meta, Microsoft and Oracle will boost their AI data center networks with NVIDIA Spectrum-X™ Ethernet networking switches.

[0001045810-25-000228:8k_2_02:36]
•Introduced NVIDIA Omniverse™ DSX, a comprehensive, open blueprint for designing and operating gigawatt-scale AI factories.

[0001045810-25-000228:8k_2_02:37]
•Launched NVIDIA BlueField-4, the processor for the operating system of AI factories, with industry leaders including CoreWeave, Dell Technologies, Oracle Cloud Infrastructure, Palo Alto Networks, Red Hat and VAST Data building next-generation BlueField®-accelerated data center platforms.

[0001045810-25-000228:8k_2_02:38]
•Partnered with Nokia to add NVIDIA-powered AI-RAN products to Nokia’s industry-leading RAN portfolio, enabling communication service providers to launch AI-native 5G-Advanced and 6G networks on NVIDIA platforms.

[0001045810-25-000228:8k_2_02:39]
•Unveiled the all-American AI-RAN stack to accelerate the path to 6G with industry-leading partners Booz Allen, Cisco, MITRE, ODC and T-Mobile.

[0001045810-25-000228:8k_2_02:40]
•Teamed with Palantir Technologies to build a first-of-its-kind integrated technology stack for operational AI.

[0001045810-25-000228:8k_2_02:41]
•Set records on the new MLPerf Inference v5.1 benchmark with NVIDIA Blackwell Ultra, and won every MLPerf Training v5.1 benchmark.

[0001045810-25-000228:8k_2_02:42]
•Revealed that NVIDIA is working with partners including CoreWeave, Microsoft and Nscale to build the U.K.’s next generation of AI infrastructure, and announced an investment of £2 billion in the U.K. market.

[0001045810-25-000228:8k_2_02:43]
•Launched the world’s first Industrial AI Cloud with Deutsche Telekom to power the AI era of Germany’s industrial transformation.

[0001045810-25-000228:8k_2_02:44]
•Announced that NVIDIA is working with the South Korea government and industrial leaders, including Hyundai Motor Group, Samsung Electronics, SK Group and NAVER Cloud, to expand the nation’s AI infrastructure with over a quarter-million NVIDIA GPUs.

[0001045810-25-000228:8k_2_02:45]
Gaming and AI PC

[0001045810-25-000228:8k_2_02:46]
•Third-quarter Gaming revenue was $4.3 billion, down 1% from the previous quarter and up 30% from a year ago.

[0001045810-25-000228:8k_2_02:47]
•Launched Borderlands 4, Battlefield 6 and ARC Raiders with NVIDIA DLSS 4 with Multi Frame Generation and NVIDIA Reflex.

[0001045810-25-000228:8k_2_02:48]
•Celebrated 25 years of GeForce™ with the GeForce Gamer Festival in Seoul, South Korea, a live event including the latest NVIDIA RTX announcements.

[0001045810-25-000228:8k_2_02:49]
•Unveiled an NVIDIA RTX™ Remix update, adding an advanced path-traced particle system that enables modders to enhance traditional effects.

[0001045810-25-000228:8k_2_02:50]
•Released an NVIDIA Blueprint for 3D object generation, RTX-optimized NVIDIA TensorRT™ for Windows ML and performance boosts for leading AI tools on RTX AI PCs.

[0001045810-25-000228:8k_2_02:51]
Professional Visualization

[0001045810-25-000228:8k_2_02:52]
•Third-quarter revenue was $760 million, up 26% from the previous quarter and up 56% from a year ago.

[0001045810-25-000228:8k_2_02:53]
•Began shipping NVIDIA DGX Spark™, the world’s smallest AI supercomputer, delivering NVIDIA’s AI stack in a compact form factor.

[0001045810-25-000228:8k_2_02:54]
Automotive and Robotics

[0001045810-25-000228:8k_2_02:55]
•Third-quarter Automotive revenue was $592 million, up 1% from the previous quarter and up 32% from a year ago.

[0001045810-25-000228:8k_2_02:56]
•Introduced the NVIDIA DRIVE AGX Hyperion™ 10 autonomous vehicle development platform, a reference compute and sensor architecture designed to enable automakers and developers to build safe, scalable level 4 fleets.

[0001045810-25-000228:8k_2_02:57]
•Partnered with Uber to scale the world’s largest level 4-ready mobility network starting in 2027, targeting 100,000 vehicles.

[0001045810-25-000228:8k_2_02:58]
•Revealed that NVIDIA and U.S. manufacturing and robotics leaders, including Agility Robotics, Amazon Robotics, Belden, Caterpillar, Foxconn, Figure, Lucid Motors, Skild AI, Toyota, TSMC and Wistron, are driving America’s reindustrialization with physical AI.

[0001045810-25-000228:8k_2_02:59]
•Announced that leading industrial solutions providers, including PTC and Siemens, introduced new services that bring NVIDIA Omniverse™-powered digital twin workflows to their extensive installed base of customers.

[0001045810-25-000228:8k_2_02:60]
•Unveiled NVIDIA IGX Thor™, a powerful, industrial-grade platform built to bring real-time physical AI directly to the edge.

[0001045810-25-000228:8k_2_02:61]
CFO Commentary

[0001045810-25-000228:8k_2_02:62]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-25-000228:8k_2_02:63]
Conference Call and Webcast Information

[0001045810-25-000228:8k_2_02:64]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2026 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal 2026.

[0001045810-25-000228:8k_2_02:65]
Non-GAAP Measures

[0001045810-25-000228:8k_2_02:66]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains/losses from non-marketable and publicly-held equity securities, net, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-25-000228:8k_2_02:67]
About NVIDIA

[0001045810-25-000228:8k_2_02:68]
NVIDIA (NASDAQ: NVDA) is the world leader in AI and accelerated computing.

[0001045810-25-000228:8k_2_02:69]
###

[0001045810-25-000228:8k_2_02:70]
For further information, contact:

[0001045810-25-000228:8k_2_02:71]
| Toshiya Hari |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| toshiyah@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-25-000228:8k_2_02:72]
© 2025 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, DGX Spark, BlueField, GeForce, NVIDIA DRIVE AGX Hyperion, NVIDIA IGX Thor, NVIDIA Omniverse, NVIDIA RTX PRO, NVQLink, Spectrum-X, TensorRT, and NVLink Fusion are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-25-000228:8k_2_02:73]
NVIDIA CORPORATION

[0001045810-25-000228:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-25-000228:8k_2_02:75]
(In millions, except per share data)

[0001045810-25-000228:8k_2_02:76]
(Unaudited)

[0001045810-25-000228:8k_2_02:77]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue | $ | 57,006 |  |  | $ | 35,082 |  |  | $ | 147,811 |  |  | $ | 91,166 |  |
| Cost of revenue | 15,157 |  |  | 8,926 |  |  | 45,441 |  |  | 22,031 |  |
| Gross profit | 41,849 |  |  | 26,156 |  |  | 102,370 |  |  | 69,135 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 4,705 |  |  | 3,390 |  |  | 12,985 |  |  | 9,200 |  |
|  | Sales, general and administrative | 1,134 |  |  | 897 |  |  | 3,297 |  |  | 2,516 |  |
|  |  | Total operating expenses | 5,839 |  |  | 4,287 |  |  | 16,282 |  |  | 11,716 |  |
| Operating income | 36,010 |  |  | 21,869 |  |  | 86,088 |  |  | 57,419 |  |
|  | Interest income | 624 |  |  | 472 |  |  | 1,732 |  |  | 1,275 |  |
|  | Interest expense | (61) |  |  | (61) |  |  | (186) |  |  | (186) |  |
|  | Other income, net | 1,363 |  |  | 36 |  |  | 3,418 |  |  | 301 |  |
|  |  | Total other income, net | 1,926 |  |  | 447 |  |  | 4,964 |  |  | 1,390 |  |
| Income before income tax | 37,936 |  |  | 22,316 |  |  | 91,052 |  |  | 58,809 |  |
| Income tax expense | 6,026 |  |  | 3,007 |  |  | 13,945 |  |  | 8,020 |  |
| Net income | $ | 31,910 |  |  | $ | 19,309 |  |  | $ | 77,107 |  |  | $ | 50,789 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 1.31 |  |  | $ | 0.79 |  |  | $ | 3.16 |  |  | $ | 2.07 |  |
|  | Diluted | $ | 1.30 |  |  | $ | 0.78 |  |  | $ | 3.14 |  |  | $ | 2.04 |  |
| Weighted average shares used in per share computation: |
|  | Basic | 24,327 |  |  | 24,533 |  |  | 24,378 |  |  | 24,577 |  |
|  | Diluted | 24,483 |  |  | 24,774 |  |  | 24,542 |  |  | 24,837 |  |

[0001045810-25-000228:8k_2_02:78]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | October 26, |  | January 26, |
|  |  |  |  | 2025 |  | 2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 60,608 |  |  | $ | 43,210 |  |
|  | Accounts receivable, net |  | 33,391 |  |  | 23,065 |  |
|  | Inventories |  | 19,784 |  |  | 10,080 |  |
|  | Prepaid expenses and other current assets |  | 2,709 |  |  | 3,771 |  |
|  |  | Total current assets |  | 116,492 |  |  | 80,126 |  |
| Property and equipment, net |  | 9,780 |  |  | 6,283 |  |
| Operating lease assets |  | 2,281 |  |  | 1,793 |  |
| Goodwill |  | 6,261 |  |  | 5,188 |  |
| Intangible assets, net |  | 936 |  |  | 807 |  |
| Deferred income tax assets |  | 13,674 |  |  | 10,979 |  |
| Other assets |  | 11,724 |  |  | 6,425 |  |
|  |  | Total assets |  | $ | 161,148 |  |  | $ | 111,601 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 8,624 |  |  | $ | 6,310 |  |
|  | Accrued and other current liabilities |  | 16,452 |  |  | 11,737 |  |
|  | Short-term debt |  | 999 |  |  | — |  |
|  |  | Total current liabilities |  | 26,075 |  |  | 18,047 |  |
| Long-term debt |  | 7,468 |  |  | 8,463 |  |
| Long-term operating lease liabilities |  | 2,014 |  |  | 1,519 |  |
| Other long-term liabilities |  | 6,694 |  |  | 4,245 |  |
|  |  | Total liabilities |  | 42,251 |  |  | 32,274 |  |
| Shareholders' equity |  | 118,897 |  |  | 79,327 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 161,148 |  |  | $ | 111,601 |  |

[0001045810-25-000228:8k_2_02:79]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | October 26, |  | October 27, |  | October 26, |  | October 27, |  |  |  |  |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 31,910 |  |  | $ | 19,309 |  |  | $ | 77,107 |  |  | $ | 50,789 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,655 |  |  | 1,252 |  |  | 4,753 |  |  | 3,416 |  |  |  |  |  |
| Depreciation and amortization | 752 |  |  | 478 |  |  | 2,031 |  |  | 1,321 |  |  |  |  |  |
| Deferred income taxes | 124 |  |  | (602) |  |  | (2,035) |  |  | (3,879) |  |  |  |  |  |
| Gains on non-marketable equity securities and publicly-held equity securities, net | (1,354) |  |  | (37) |  |  | (3,426) |  |  | (302) |  |  |  |  |  |
| Other | (80) |  |  | (79) |  |  | (276) |  |  | (365) |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | (5,583) |  |  | (3,561) |  |  | (10,325) |  |  | (7,694) |  |  |  |  |  |
| Inventories | (4,823) |  |  | (978) |  |  | (9,703) |  |  | (2,357) |  |  |  |  |  |
| Prepaid expenses and other assets | (89) |  |  | (714) |  |  | 857 |  |  | (726) |  |  |  |  |  |
| Accounts payable | (223) |  |  | 1,689 |  |  | 2,032 |  |  | 2,490 |  |  |  |  |  |
| Accrued and other current liabilities | 1,129 |  |  | 606 |  |  | 4,204 |  |  | 3,918 |  |  |  |  |  |
| Other long-term liabilities | 332 |  |  | 266 |  |  | 1,311 |  |  | 849 |  |  |  |  |  |
| Net cash provided by operating activities | 23,750 |  |  | 17,629 |  |  | 66,530 |  |  | 47,460 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,728 |  |  | 1,386 |  |  | 8,980 |  |  | 9,485 |  |  |  |  |  |
| Proceeds from sales of non-marketable equity securities | 2 |  |  | 66 |  |  | 72 |  |  | 171 |  |  |  |  |  |
| Proceeds from sales of marketable securities | — |  |  | 154 |  |  | 487 |  |  | 318 |  |  |  |  |  |
| Purchases of marketable securities | (5,718) |  |  | (4,518) |  |  | (20,076) |  |  | (19,565) |  |  |  |  |  |
| Purchases of non-marketable equity securities | (3,706) |  |  | (473) |  |  | (4,702) |  |  | (1,008) |  |  |  |  |  |
| Purchases related to property and equipment and intangible assets | (1,637) |  |  | (813) |  |  | (4,758) |  |  | (2,159) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (694) |  |  | (147) |  |  | (1,370) |  |  | (465) |  |  |  |  |  |
| Net cash used in investing activities | (9,025) |  |  | (4,345) |  |  | (21,367) |  |  | (13,223) |  |  |  |  |  |

[0001045810-25-000228:8k_2_02:80]
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 274 |  |  | 204 |  |  | 643 |  |  | 489 |  |  |  |  |  |
| Payments related to repurchases of common stock | (12,456) |  |  | (10,998) |  |  | (36,271) |  |  | (25,895) |  |  |  |  |  |
| Payments related to employee stock plan taxes | (2,429) |  |  | (1,680) |  |  | (5,809) |  |  | (5,068) |  |  |  |  |  |
| Dividends paid | (243) |  |  | (245) |  |  | (732) |  |  | (589) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (24) |  |  | (29) |  |  | (97) |  |  | (97) |  |  |  |  |  |
| Repayment of debt | — |  |  | — |  |  | — |  |  | (1,250) |  |  |  |  |  |
| Net cash used in financing activities | (14,878) |  |  | (12,748) |  |  | (42,266) |  |  | (32,410) |  |  |  |  |  |
| Change in cash and cash equivalents | (153) |  |  | 536 |  |  | 2,897 |  |  | 1,827 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 11,639 |  |  | 8,571 |  |  | 8,589 |  |  | 7,280 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 11,486 |  |  | $ | 9,107 |  |  | $ | 11,486 |  |  | $ | 9,107 |  |  |  |  |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 4,858 |  |  | $ | 3,540 |  |  | $ | 13,309 |  |  | $ | 10,989 |  |  |  |  |  |

[0001045810-25-000228:8k_2_02:81]
|  | NVIDIA CORPORATION |  |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |  |
|  | (In millions, except per share data) |  |
|  | (Unaudited) |  |
|  |  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  |  | October 26, |  | July 27, |  | October 27, |  | October 26, |  | October 27, |  |
|  |  |  | 2025 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| GAAP cost of revenue |  | $ | 15,157 |  |  | $ | 12,890 |  |  | $ | 8,926 |  |  | $ | 45,441 |  |  | $ | 22,031 |  |  |
| GAAP gross profit |  | $ | 41,849 |  |  | $ | 33,853 |  |  | $ | 26,156 |  |  | $ | 102,370 |  |  | $ | 69,135 |  |  |
| GAAP gross margin |  | 73.4 | % |  | 72.4 | % |  | 74.6 | % |  | 69.3 | % |  | 75.8 | % |  |
|  | Acquisition-related and other costs (A) |  | 48 |  |  | 49 |  |  | 116 |  |  | 219 |  |  | 355 |  |  |
|  | Stock-based compensation expense (B) |  | 70 |  |  | 58 |  |  | 50 |  |  | 192 |  |  | 125 |  |  |
|  | Other |  | — |  |  | — |  |  | — |  |  | 4 |  |  | (4) |  |  |
| Non-GAAP cost of revenue |  | $ | 15,039 |  |  | $ | 12,783 |  |  | $ | 8,760 |  |  | $ | 45,026 |  |  | $ | 21,555 |  |  |
| Non-GAAP gross profit |  | $ | 41,967 |  |  | $ | 33,960 |  |  | $ | 26,322 |  |  | $ | 102,785 |  |  | $ | 69,611 |  |  |
| Non-GAAP gross margin** |  | 73.6 | % |  | 72.7 | % |  | 75.0 | % |  | 69.5 | % |  | 76.4 | % |  |
| GAAP operating expenses |  | $ | 5,839 |  |  | $ | 5,413 |  |  | $ | 4,287 |  |  | $ | 16,282 |  |  | $ | 11,716 |  |  |
|  | Stock-based compensation expense (B) |  | (1,585) |  |  | (1,566) |  |  | (1,202) |  |  | (4,561) |  |  | (3,291) |  |  |
|  | Acquisition-related and other costs (A) |  | (39) |  |  | (37) |  |  | (39) |  |  | (113) |  |  | (86) |  |  |
|  | Other |  | — |  |  | (15) |  |  | — |  |  | (15) |  |  | — |  |  |
| Non-GAAP operating expenses |  | $ | 4,215 |  |  | $ | 3,795 |  |  | $ | 3,046 |  |  | $ | 11,593 |  |  | $ | 8,339 |  |  |
| GAAP operating income |  | $ | 36,010 |  |  | $ | 28,440 |  |  | $ | 21,869 |  |  | $ | 86,088 |  |  | $ | 57,419 |  |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,742 |  |  | 1,725 |  |  | 1,407 |  |  | 5,104 |  |  | 3,853 |  |  |
| Non-GAAP operating income |  | $ | 37,752 |  |  | $ | 30,165 |  |  | $ | 23,276 |  |  | $ | 91,192 |  |  | $ | 61,272 |  |  |
| GAAP total other income, net |  | $ | 1,926 |  |  | $ | 2,766 |  |  | $ | 447 |  |  | $ | 4,964 |  |  | $ | 1,390 |  |  |
|  | Gains from non-marketable equity securities and publicly-held equity securities, net |  | (1,354) |  |  | (2,247) |  |  | (37) |  |  | (3,426) |  |  | (302) |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |  |
| Non-GAAP total other income, net |  | $ | 573 |  |  | $ | 520 |  |  | $ | 411 |  |  | $ | 1,541 |  |  | $ | 1,091 |  |  |
| GAAP net income |  | $ | 31,910 |  |  | $ | 26,422 |  |  | $ | 19,309 |  |  | $ | 77,107 |  |  | $ | 50,789 |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 389 |  |  | (521) |  |  | 1,371 |  |  | 1,680 |  |  | 3,554 |  |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (532) |  |  | (166) |  |  | (670) |  |  | (1,391) |  |  | (2,144) |  |  |
|  | Tax expense from OBBBA* |  | — |  |  | 48 |  |  | — |  |  | 48 |  |  | — |  |  |
| Non-GAAP net income** |  | $ | 31,767 |  |  | $ | 25,783 |  |  | $ | 20,010 |  |  | $ | 77,444 |  |  | $ | 52,199 |  |  |

[0001045810-25-000228:8k_2_02:82]
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 1.30 |  |  | $ | 1.08 |  |  | $ | 0.78 |  |  | $ | 3.14 |  |  | $ | 2.04 |  |  |
|  | Non-GAAP** |  | $ | 1.30 |  |  | $ | 1.05 |  |  | $ | 0.81 |  |  | $ | 3.16 |  |  | $ | 2.10 |  |  |
| Weighted average shares used in diluted net income per share computation |  | 24,483 |  |  | 24,532 |  |  | 24,774 |  |  | 24,542 |  |  | 24,837 |  |  |
| GAAP net cash provided by operating activities |  | $ | 23,750 |  |  | $ | 15,365 |  |  | $ | 17,629 |  |  | $ | 66,530 |  |  | $ | 47,460 |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (1,637) |  |  | (1,894) |  |  | (813) |  |  | (4,758) |  |  | (2,159) |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (24) |  |  | (21) |  |  | (29) |  |  | (97) |  |  | (97) |  |  |
| Free cash flow |  | $ | 22,089 |  |  | $ | 13,450 |  |  | $ | 16,787 |  |  | $ | 61,675 |  |  | $ | 45,204 |  |  |
| *Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act). |  |
| **Includes H20 charges/(releases), net, which were $4.5 billion, ($180 million), and insignificant, for the first, second, and third quarter of fiscal 2026, respectively. |  |

[0001045810-25-000228:8k_2_02:83]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 26, |  | July 27, |  | October 27, |  | October 26, |  | October 27, |
|  |  |  | 2025 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Cost of revenue |  | $ | 48 |  |  | $ | 49 |  |  | $ | 116 |  |  | $ | 219 |  |  | $ | 355 |  |
|  | Research and development |  | $ | 35 |  |  | $ | 29 |  |  | $ | 23 |  |  | $ | 93 |  |  | $ | 52 |  |
|  | Sales, general and administrative |  | $ | 4 |  |  | $ | 8 |  |  | $ | 16 |  |  | $ | 20 |  |  | $ | 34 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 26, |  | July 27, |  | October 27, |  | October 26, |  | October 27, |
|  |  |  | 2025 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | Cost of revenue |  | $ | 70 |  |  | $ | 58 |  |  | $ | 50 |  |  | $ | 192 |  |  | $ | 125 |  |
|  | Research and development |  | $ | 1,206 |  |  | $ | 1,191 |  |  | $ | 910 |  |  | $ | 3,460 |  |  | $ | 2,469 |  |
|  | Sales, general and administrative |  | $ | 379 |  |  | $ | 375 |  |  | $ | 292 |  |  | $ | 1,101 |  |  | $ | 822 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-25-000228:8k_2_02:84]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2026 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 74.8 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.2 | % |
| Non-GAAP gross margin |  | 75.0 | % |
| GAAP operating expenses |  | $ | 6,650 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,650) |  |
| Non-GAAP operating expenses |  | $ | 5,000 |  |
