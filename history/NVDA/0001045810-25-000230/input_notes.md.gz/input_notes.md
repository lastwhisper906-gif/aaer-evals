# NVDA notes — 0001045810-25-000230


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-25-000230:notes:1]
[same as prior period, unchanged from 0001045810-25-000209:notes:1]

[0001045810-25-000230:notes:2]
[same as prior period, unchanged from 0001045810-25-000209:notes:2]

[0001045810-25-000230:notes:3]
[same as prior period, unchanged from 0001045810-25-000209:notes:3]

[0001045810-25-000230:notes:4]
[same as prior period, unchanged from 0001045810-25-000209:notes:4]

[0001045810-25-000230:notes:5]
[same as prior period, unchanged from 0001045810-25-000209:notes:5]

[0001045810-25-000230:notes:6]
[same as prior period, unchanged from 0001045810-25-000209:notes:6]

[0001045810-25-000230:notes:7]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The third quarters of fiscal years 2026 and 2025 were both 13-week quarters.

[0001045810-25-000230:notes:8]
[same as prior period, unchanged from 0001045810-25-000209:notes:8]

[0001045810-25-000230:notes:9]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-25-000230:notes:10]
[same as prior period, unchanged from 0001045810-25-000209:notes:10]

[0001045810-25-000230:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, non-marketable equity securities, other contingencies, property, plant, and equipment, restructuring and other charges, revenue recognition, and stock-based compensation. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-25-000230:notes:12]
Recently Issued Accounting Pronouncements

[0001045810-25-000230:notes:13]
[same as prior period, unchanged from 0001045810-25-000209:notes:13]

[0001045810-25-000230:notes:14]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in the fiscal year 2026 annual report.

[0001045810-25-000230:notes:15]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-25-000230:notes:16]
[same as prior period, unchanged from 0001045810-25-000209:notes:16]

[0001045810-25-000230:notes:17]
[same as prior period, unchanged from 0001045810-25-000209:notes:17]

[0001045810-25-000230:notes:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Cost of revenue | $ | 70 |  |  | $ | 50 |  |  | $ | 192 |  |  | $ | 125 |  |
| Research and development | 1,206 |  |  | 910 |  |  | 3,460 |  |  | 2,469 |  |
| Sales, general and administrative | 379 |  |  | 292 |  |  | 1,101 |  |  | 822 |  |
| Total | $ | 1,655 |  |  | $ | 1,252 |  |  | $ | 4,753 |  |  | $ | 3,416 |  |

[0001045810-25-000230:notes:19]
[same as prior period, unchanged from 0001045810-25-000209:notes:19]

[0001045810-25-000230:notes:20]
[same as prior period, unchanged from 0001045810-25-000209:notes:20]

[0001045810-25-000230:notes:21]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balance as of Jan 26, 2025 | 274 |  |  | $ | 44.75 |  |
| Granted | 52 |  |  | $ | 114.76 |  |
| Vested | (116) |  |  | $ | 37.30 |  |
| Canceled and forfeited | (7) |  |  | $ | 55.62 |  |
| Balance as of Oct 26, 2025 | 203 |  |  | $ | 66.59 |  |

[0001045810-25-000230:notes:22]
As of October 26, 2025, aggregate unearned stock-based compensation expense was $13.1 billion, which is expected to be recognized over a weighted average period of 2.1 years for RSUs, PSUs, and market-based PSUs, and one year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-25-000230:notes:23]
[same as prior period, unchanged from 0001045810-25-000209:notes:23]

[0001045810-25-000230:notes:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 31,910 |  |  | $ | 19,309 |  |  | $ | 77,107 |  |  | $ | 50,789 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,327 |  |  | 24,533 |  |  | 24,378 |  |  | 24,577 |  |
| Dilutive impact of outstanding equity awards | 156 |  |  | 241 |  |  | 164 |  |  | 260 |  |
| Diluted weighted average shares | 24,483 |  |  | 24,774 |  |  | 24,542 |  |  | 24,837 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.31 |  |  | $ | 0.79 |  |  | $ | 3.16 |  |  | $ | 2.07 |  |
| Diluted (2) | $ | 1.30 |  |  | $ | 0.78 |  |  | $ | 3.14 |  |  | $ | 2.04 |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 6 |  |  | 9 |  |  | 20 |  |  | 72 |  |

[0001045810-25-000230:notes:25]
[same as prior period, unchanged from 0001045810-25-000209:notes:25]

[0001045810-25-000230:notes:26]
[same as prior period, unchanged from 0001045810-25-000209:notes:26]

[0001045810-25-000230:notes:27]
[same as prior period, unchanged from 0001045810-25-000209:notes:27]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-25-000230:notes:28]
Income Taxes
Income tax expense was $6.0 billion and $3.0 billion for the third quarter, and $13.9 billion and $8.0 billion for the first nine months, of fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 15.9% and 13.5% for the third quarter, and 15.3% and 13.6% for the first nine months, of fiscal years 2026 and 2025, respectively.

[0001045810-25-000230:notes:29]
The effective tax rate increased primarily due to a lower percentage of tax benefits from stock-based compensation and U.S. federal research tax credit relative to the increase in income before income tax.

[0001045810-25-000230:notes:30]
Our effective tax rates for the first nine months of fiscal years 2026 and 2025 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from foreign-derived deduction eligible income, stock-based compensation, income earned in jurisdictions that are subject to taxes at rates lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit.

[0001045810-25-000230:notes:31]
In July 2025, the One Big Beautiful Bill Act (OBBBA) was enacted into law and contains several changes to key U.S. federal income tax laws. We have recognized the tax effects of currently effective OBBBA provisions, which are not material and are reflected in our results for the first nine months of fiscal year 2026.

[0001045810-25-000230:notes:32]
[same as prior period, unchanged from 0001045810-25-000209:notes:32]

[0001045810-25-000230:notes:33]
[same as prior period, unchanged from 0001045810-25-000209:notes:33]

[0001045810-25-000230:notes:34]
We are currently under examination by the Internal Revenue Service for our fiscal years 2023 and 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-25-000230:notes:35]
Cash Equivalents and Marketable Securities
The fair values of our financial assets are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis. The following is a summary of cash equivalents and marketable securities:

[0001045810-25-000230:notes:36]
|  | Oct 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 22,032 |  |  | $ | 188 |  |  | $ | — |  |  | $ | 22,220 |  |  | $ | 665 |  |  | $ | 21,555 |  |
| Corporate debt securities | Level 2 | 21,588 |  |  | 172 |  |  | (1) |  |  | 21,759 |  |  | 320 |  |  | 21,439 |  |
| Money market funds | Level 1 | 8,610 |  |  | — |  |  | — |  |  | 8,610 |  |  | 8,610 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,206 |  |  | 12 |  |  | — |  |  | 2,218 |  |  | — |  |  | 2,218 |  |
| Certificates of deposit | Level 2 | 104 |  |  | — |  |  | — |  |  | 104 |  |  | 104 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 54,580 |  |  | 373 |  |  | (1) |  |  | 54,952 |  |  | 9,699 |  |  | 45,253 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,869 |  |  | — |  |  | 3,869 |  |
| Total |  | $ | 54,580 |  |  | $ | 373 |  |  | $ | (1) |  |  | $ | 58,821 |  |  | $ | 9,699 |  |  | $ | 49,122 |  |

[0001045810-25-000230:notes:37]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading.

[0001045810-25-000230:notes:38]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $670 million and $2.4 billion for the third quarter and first nine months of fiscal year 2026, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for the third quarter and first nine months of fiscal year 2025.

[0001045810-25-000230:notes:39]
|  | Jan 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

[0001045810-25-000230:notes:40]
The following table provides the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-25-000230:notes:41]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,223 |  |  | $ | — |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 899 |  |  | (1) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 75 |  |  | — |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 2,197 |  |  | $ | (1) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

[0001045810-25-000230:notes:42]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater, with balances of $337 million and $213 million as of October 26, 2025 and January 26, 2025, respectively, were not significant.

[0001045810-25-000230:notes:43]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-25-000230:notes:44]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-25-000230:notes:45]
|  | Oct 26, 2025 |
|  | (In millions) |
| Less than one year | $ | 21,848 |  |
| Due in 1 - 5 years | 33,104 |  |
| Total | $ | 54,952 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-25-000230:notes:46]
[same as prior period, unchanged from 0001045810-25-000209:notes:45]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-25-000230:notes:47]
Fair Value of Non-marketable Equity Securities
Our non-marketable equity securities are recorded in long-term other assets on our Condensed Consolidated Balance Sheets and valued under the measurement alternative. Gains and losses on these investments, realized and unrealized, are recognized in Other income, net on our Condensed Consolidated Statements of Income.

[0001045810-25-000230:notes:48]
Adjustments to the carrying value of our non-marketable equity securities during the third quarter and first nine months of fiscal years 2026 and 2025 were as follows:

[0001045810-25-000230:notes:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 3,799 |  |  | $ | 1,819 |  |  | $ | 3,387 |  |  | $ | 1,321 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 3,704 |  |  | 409 |  |  | 4,652 |  |  | 830 |  |
| Unrealized gains | 758 |  |  | 23 |  |  | 1,088 |  |  | 115 |  |
| Reclassification (1) | — |  |  | — |  |  | (848) |  |  | — |  |
| Impairments and unrealized losses | (74) |  |  | (14) |  |  | (92) |  |  | (29) |  |
| Balance at end of period | $ | 8,187 |  |  | $ | 2,237 |  |  | $ | 8,187 |  |  | $ | 2,237 |  |

[0001045810-25-000230:notes:50]
[same as prior period, unchanged from 0001045810-25-000209:notes:49]

[0001045810-25-000230:notes:51]
Non-marketable equity securities had cumulative gross unrealized gains of $1.4 billion and $374 million, and cumulative gross unrealized losses and impairments of $167 million and $74 million on securities held as of October 26, 2025 and October 27, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-25-000230:notes:52]
[same as prior period, unchanged from 0001045810-25-000209:notes:51]

[0001045810-25-000230:notes:53]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 3,146 |  |  | $ | (2,456) |  |  | $ | 690 |  |  | $ | 2,900 |  |  | $ | (2,264) |  |  | $ | 636 |  |
| Patents and licensed technology | 541 |  |  | (295) |  |  | 246 |  |  | 449 |  |  | (278) |  |  | 171 |  |
| Total intangible assets | $ | 3,687 |  |  | $ | (2,751) |  |  | $ | 936 |  |  | $ | 3,349 |  |  | $ | (2,542) |  |  | $ | 807 |  |

[0001045810-25-000230:notes:54]
Amortization expense associated with intangible assets was $96 million and $149 million for the third quarter, and $338 million and $438 million for the first nine months, of fiscal years 2026 and 2025, respectively.

[0001045810-25-000230:notes:55]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of October 26, 2025:

[0001045810-25-000230:notes:56]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first nine months, of fiscal year 2026) | $ | 107 |  |
| 2027 | 416 |  |
| 2028 | 222 |  |
| 2029 | 87 |  |
| 2030 | 11 |  |
| 2031 and thereafter | 93 |  |
| Total | $ | 936 |  |

[0001045810-25-000230:notes:57]
In the first nine months of fiscal year 2026, goodwill increased by $1.1 billion from acquisitions and was allocated to our Compute & Networking reporting unit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-25-000230:notes:58]
Balance Sheet Components
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, original device manufacturers, or ODMs, original equipment manufacturers, or OEMs, cloud service providers, or CSPs, hyperscale companies, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. Four direct customers accounted for 22%, 17%, 14% and 12% of our accounts receivable balance as of October 26, 2025. Two direct customers accounted for 17% and 16% of our accounts receivable balance as of January 26, 2025.

[0001045810-25-000230:notes:59]
[same as prior period, unchanged from 0001045810-25-000209:notes:58]

[0001045810-25-000230:notes:60]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
| Inventories: | (In millions) |
| Raw materials | $ | 4,209 |  |  | $ | 3,408 |  |
| Work in process | 8,735 |  |  | 3,399 |  |
| Finished goods | 6,840 |  |  | 3,273 |  |
| Total inventories (1) | $ | 19,784 |  |  | $ | 10,080 |  |

[0001045810-25-000230:notes:61]
(1)    We recorded inventory provisions of $378 million and $322 million for the third quarter of fiscal years 2026 and 2025, respectively, and $3.6 billion and $876 million for the first nine months of fiscal years 2026 and 2025, respectively, in cost of revenue.

[0001045810-25-000230:notes:62]
[same as prior period, unchanged from 0001045810-25-000209:notes:61]

[0001045810-25-000230:notes:63]
Property, equipment and intangible assets acquired but not paid for the first nine months of fiscal years 2026 and 2025 were $790 million and not significant, respectively.

[0001045810-25-000230:notes:64]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
| Other Assets (Long Term): | (In millions) |
| Non-marketable equity securities | $ | 8,187 |  |  | $ | 3,387 |  |
| Prepaid supply and capacity agreements (1) | 1,536 |  |  | 1,747 |  |
| Income tax receivable | 1,369 |  |  | 750 |  |
| Other | 632 |  |  | 541 |  |
| Total other assets | $ | 11,724 |  |  | $ | 6,425 |  |

[0001045810-25-000230:notes:65]
$2.0 billion and $3.3 billion were included in short-term Prepaid expenses and other current assets as of October 26, 2025 and January 26, 2025, respectively.

[0001045810-25-000230:notes:66]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 4,721 |  |  | $ | 4,880 |  |
| Excess inventory purchase obligations (1) | 2,770 |  |  | 2,095 |  |
| Product warranty | 2,707 |  |  | 1,290 |  |
| Taxes payable | 2,915 |  |  | 881 |  |
| Deferred revenue (2) | 1,248 |  |  | 837 |  |
| Accrued payroll and related expenses | 895 |  |  | 848 |  |
| Other | 1,196 |  |  | 906 |  |
| Total accrued and other current liabilities | $ | 16,452 |  |  | $ | 11,737 |  |

[0001045810-25-000230:notes:67]
(1)    We recorded $32 million and $543 million for the third quarter of fiscal years 2026 and 2025, respectively, and $3.1 billion and $1.3 billion for the first nine months of fiscal years 2026 and 2025, respectively, in cost of revenue.

[0001045810-25-000230:notes:68]
(2)    Includes customer advances and unearned revenue related to hardware and software support, cloud services, and license and development arrangements. The balance as of October 26, 2025 and January 26, 2025 included $127 million and $81 million of customer advances, respectively.

[0001045810-25-000230:notes:69]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 3,532 |  |  | $ | 2,188 |  |
| Deferred income tax | 1,621 |  |  | 886 |  |
| Deferred revenue (2) | 1,165 |  |  | 976 |  |
| Other | 376 |  |  | 195 |  |
| Total other long-term liabilities | $ | 6,694 |  |  | $ | 4,245 |  |

[0001045810-25-000230:notes:70]
[same as prior period, unchanged from 0001045810-25-000209:notes:69]

[0001045810-25-000230:notes:71]
(2)    Includes unearned revenue related to hardware and software support and cloud services.

[0001045810-25-000230:notes:72]
[same as prior period, unchanged from 0001045810-25-000209:notes:71]

[0001045810-25-000230:notes:73]
The following table shows the changes in short- and long-term deferred revenue during the first nine months of fiscal years 2026 and 2025:

[0001045810-25-000230:notes:74]
|  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,813 |  |  | $ | 1,337 |  |
| Deferred revenue additions (1) | 9,785 |  |  | 2,115 |  |
| Revenue recognized (2) | (9,185) |  |  | (1,867) |  |
| Balance at end of period | $ | 2,413 |  |  | $ | 1,585 |  |

[0001045810-25-000230:notes:75]
(1)    Includes $8.4 billion and $1.1 billion of customer advances for the first nine months of fiscal years 2026 and 2025, respectively.

[0001045810-25-000230:notes:76]
(2)    Includes $8.3 billion and $1.2 billion related to customer advances for the first nine months of fiscal years 2026 and 2025, respectively.

[0001045810-25-000230:notes:77]
We recognized revenue of $650 million and $585 million in the first nine months of fiscal years 2026 and 2025, respectively, that were included in the prior year end deferred revenue balance.

[0001045810-25-000230:notes:78]
As of October 26, 2025, revenue related to remaining performance obligations from contracts greater than one year in length was $2.5 billion, which includes $2.0 billion from deferred revenue and $449 million which has not yet been billed nor recognized as revenue. Approximately 40% of revenue from contracts greater than one year in length will be recognized over the next twelve months.


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001045810-25-000230:notes:79]
(1)    $2.0 billion and $3.3 billion were included in short-term Prepaid expenses and other current assets as of October 26, 2025 and January 26, 2025, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-25-000230:notes:80]
Derivative Financial Instruments
Foreign Currency Derivatives

[0001045810-25-000230:notes:81]
We utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. The foreign currency forward contracts for operating expenses are designated as accounting hedges. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings. During the first nine months of fiscal years 2026 and 2025, the impact of foreign currency forward contracts designated as accounting hedges on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.

[0001045810-25-000230:notes:82]
[same as prior period, unchanged from 0001045810-25-000209:notes:80]

[0001045810-25-000230:notes:83]
[same as prior period, unchanged from 0001045810-25-000209:notes:81]

[0001045810-25-000230:notes:84]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
|  | (In millions) |
| Designated as accounting hedges | $ | 1,736 |  |  | $ | 1,424 |  |
| Not designated as accounting hedges | $ | 592 |  |  | $ | 1,297 |  |

[0001045810-25-000230:notes:85]
The unrealized gains and losses or fair value of our foreign currency contracts were not significant as of October 26, 2025 and January 26, 2025.

[0001045810-25-000230:notes:86]
As of October 26, 2025, all foreign currency contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months were not significant.

[0001045810-25-000230:notes:87]
Facility Lease Guarantee

[0001045810-25-000230:notes:88]
In the third quarter of fiscal year 2026, we entered into an agreement to guarantee a partner's facility lease obligations in the event of their default. The agreement allows our partner to secure a limited-availability facility lease backed by our credit profile, in exchange for issuing us warrants. The maximum gross exposure is $860 million, which is reduced as the partner makes payments to the lessor over five years. The partner has placed $470 million in escrow and executed an agreement to sell the data center cloud capacity, mitigating our default risk. If the escrow and cloud capacity agreement are not sufficient to cover an event of default, we have the option to assume the lease for internal use or sublease. The guarantee, classified as a credit derivative with changes in fair value recognized in Other income and expense, has an insignificant fair value.


## us-gaap:DebtDisclosureTextBlock

[0001045810-25-000230:notes:89]
Debt

[0001045810-25-000230:notes:90]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 26, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.9 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (33) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,467 |  |  | $ | 8,463 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 7,468 |  |  | $ | 8,463 |  |

[0001045810-25-000230:notes:91]
As of October 26, 2025 and January 26, 2025, the estimated fair value of debt was $7.6 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

[0001045810-25-000230:notes:92]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity of the notes is calendar year.

[0001045810-25-000230:notes:93]
As of October 26, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-25-000230:notes:94]
Short-term Debt

[0001045810-25-000230:notes:95]
As of October 26, 2025, short-term debt was $999 million.

[0001045810-25-000230:notes:96]
We have a $575 million commercial paper program to support general corporate purposes. As of October 26, 2025 and January 26, 2025, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-25-000230:notes:97]
Commitments and Contingencies
Commitments

[0001045810-25-000230:notes:98]
Manufacturing production, long-term supply and capacity, and other related commitments reflect long lead and cycle times for our current and future product architectures. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. As of October 26, 2025, these commitments were $50.3 billion, of which substantially all will be paid through fiscal year 2027.

[0001045810-25-000230:notes:99]
Multi-year cloud service agreement commitments as of October 26, 2025, were $26 billion for which $1 billion, $6 billion, $6 billion, $5 billion, $4 billion, and $4 billion will be paid in fiscal years 2026 (fourth quarter), 2027, 2028, 2029, 2030, and 2031 & thereafter, respectively. Some cloud service capacity may be reduced, terminated or sold to others by the CSPs, in which case our commitments will be reduced. We expect cloud service agreements to be used to support our research and development efforts and DGX Cloud offerings.
nvestment commitments are $6.5 billion as of October 26, 2025, including $5 billion in Intel Corporation which is subject to regulatory approval. In the third quarter of fiscal year 2026, we entered into a letter of intent with an opportunity to invest in OpenAI. In November 2025, we entered into an agreement, subject to certain closing conditions, to invest up to $10 billion in Anthropic.
Other commitments were $2.1 billion as of October 26, 2025, of which the majority will be paid through fiscal year 2027.

[0001045810-25-000230:notes:100]
Accrual for Product Warranty Liabilities

[0001045810-25-000230:notes:101]
The estimated product warranty activity consisted of the following:

[0001045810-25-000230:notes:102]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,144 |  |  | $ | 741 |  |  | $ | 1,290 |  |  | $ | 306 |  |
| Additions | 1,074 |  |  | 304 |  |  | 2,164 |  |  | 775 |  |
| Utilization | (511) |  |  | (36) |  |  | (747) |  |  | (72) |  |
| Balance at end of period | $ | 2,707 |  |  | $ | 1,009 |  |  | $ | 2,707 |  |  | $ | 1,009 |  |

[0001045810-25-000230:notes:103]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-25-000230:notes:104]
Litigation

[0001045810-25-000230:notes:105]
Securities Class Action and Derivative Lawsuits

[0001045810-25-000230:notes:106]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

[0001045810-25-000230:notes:107]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-25-000230:notes:108]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the

[0001045810-25-000230:notes:109]
Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-25-000230:notes:110]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. On August 11, 2025, the court granted the parties’ stipulation to voluntarily dismiss with prejudice plaintiff City of Westland Police and Fire Retirement System. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-25-000230:notes:111]
Accounting for Loss Contingencies

[0001045810-25-000230:notes:112]
As of October 26, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-25-000230:notes:113]
Shareholders’ Equity 
Capital Return Program

[0001045810-25-000230:notes:114]
We repurchased 70 million and 92 million shares of our common stock for $12.6 billion and $11.1 billion during the third quarter of fiscal years 2026 and 2025, respectively, and 262 million and 254 million shares of our common stock for $36.7 billion and $26.2 billion during the first nine months of fiscal years 2026 and 2025, respectively. On August 26, 2025, our Board of Directors approved an additional $60.0 billion in share repurchase authorization, without expiration. As of October 26, 2025, we were authorized, subject to certain specifications, to repurchase up to $62.2 billion of our common stock.

[0001045810-25-000230:notes:115]
From October 27, 2025 through November 14, 2025, we repurchased 6 million shares for $1.1 billion pursuant to a pre-established trading plan.

[0001045810-25-000230:notes:116]
We paid cash dividends to our shareholders of $243 million and $245 million during the third quarter, and $732 million and $589 million during the first nine months, of fiscal years 2026 and 2025, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-25-000230:notes:117]
[same as prior period, unchanged from 0001045810-25-000209:notes:111]

[0001045810-25-000230:notes:118]
The Compute & Networking segment includes our Data Center accelerated computing platforms and artificial intelligence, or AI, solutions and software; networking; automotive platforms and autonomous and electric vehicle solutions including software; Jetson for robotics and other embedded platforms; and DGX Cloud computing services.

[0001045810-25-000230:notes:119]
[same as prior period, unchanged from 0001045810-25-000209:notes:113]

[0001045810-25-000230:notes:120]
[same as prior period, unchanged from 0001045810-25-000209:notes:114]

[0001045810-25-000230:notes:121]
[same as prior period, unchanged from 0001045810-25-000209:notes:115]

[0001045810-25-000230:notes:122]
|  | Compute & Networking |  | Graphics |  | Total |  |  |  |  |
|  | (In millions) |
| Three Months Ended Oct 26, 2025 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 50,908 |  |  | $ | 6,098 |  |  | $ | 57,006 |  |  |  |  |  |
| Other segment items (1) | 15,187 |  |  | 3,552 |  |  | 18,739 |  |  |  |  |  |
| Operating income (loss) | $ | 35,721 |  |  | $ | 2,546 |  |  | $ | 38,267 |  |  |  |  |  |
| Three Months Ended Oct 27, 2024 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 31,036 |  |  | $ | 4,046 |  |  | $ | 35,082 |  |  |  |  |  |
| Other segment items (1) | 8,955 |  |  | 2,544 |  |  | 11,499 |  |  |  |  |  |
| Operating income (loss) | $ | 22,081 |  |  | $ | 1,502 |  |  | $ | 23,583 |  |  |  |  |  |
| Nine Months Ended Oct 26, 2025 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 131,828 |  |  | $ | 15,983 |  |  | $ | 147,811 |  |  |  |  |  |
| Other segment items (1) | 45,689 |  |  | 9,555 |  |  | 55,244 |  |  |  |  |  |
| Operating income (loss) | $ | 86,139 |  |  | $ | 6,428 |  |  | $ | 92,567 |  |  |  |  |  |
| Nine Months Ended Oct 27, 2024 |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 80,157 |  |  | $ | 11,009 |  |  | $ | 91,166 |  |  |  |  |  |
| Other segment items (1) | 22,180 |  |  | 6,898 |  |  | 29,078 |  |  |  |  |  |
| Operating income (loss) | $ | 57,977 |  |  | $ | 4,111 |  |  | $ | 62,088 |  |  |  |  |  |

[0001045810-25-000230:notes:123]
(1)    Other segment items primarily include product costs and inventory provisions, compensation and benefits excluding stock-based compensation expense, computing infrastructure expenses, and engineering development costs.

[0001045810-25-000230:notes:124]
Depreciation and amortization expense attributable to our Compute and Networking segment was $439 million and $187 million for the third quarter, and $1.1 billion and $495 million for the first nine months, of fiscal years 2026 and 2025, respectively. Depreciation and amortization expense attributable to our Graphics segment was $175 million and $97 million for the third quarter, and $426 million and $268 million for the first nine months, of fiscal years 2026 and 2025, respectively. Acquisition-related intangible amortization expense is not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance.

[0001045810-25-000230:notes:125]
A reconciliation of segment operating income to consolidated income before income tax for the third quarter and first nine months of fiscal years 2026 and 2025 were as follows:

[0001045810-25-000230:notes:126]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |  |  |
|  | (In millions) |  |  |
| Segment operating income | $ | 38,267 |  |  | $ | 23,583 |  |  | $ | 92,567 |  |  | $ | 62,088 |  |  |  |
| Stock-based compensation expense | (1,655) |  |  | (1,252) |  |  | (4,753) |  |  | (3,416) |  |  |  |
| Unallocated operating expenses | (515) |  |  | (307) |  |  | (1,375) |  |  | (816) |  |  |  |
| Acquisition-related and other costs | (87) |  |  | (155) |  |  | (351) |  |  | (437) |  |  |  |
| Interest income | 624 |  |  | 472 |  |  | 1,732 |  |  | 1,275 |  |  |  |
| Interest expense | (61) |  |  | (61) |  |  | (186) |  |  | (186) |  |  |  |
| Other income, net | 1,363 |  |  | 36 |  |  | 3,418 |  |  | 301 |  |  |  |
| Consolidated income before income tax | $ | 37,936 |  |  | $ | 22,316 |  |  | $ | 91,052 |  |  | $ | 58,809 |  |  |  |

[0001045810-25-000230:notes:127]
Revenue by geographic area is based upon the location of the customers’ headquarters. The end customer and shipping location may be different from our customers’ headquarters location.

[0001045810-25-000230:notes:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Geographic Revenue based upon Customer Headquarters Location (1): |  |  |  |  |  |  |  |
| United States | $ | 39,177 |  |  | $ | 19,620 |  |  | $ | 97,759 |  |  | $ | 53,873 |  |
| Taiwan (2) | 13,751 |  |  | 6,188 |  |  | 30,301 |  |  | 17,364 |  |
| China (including Hong Kong) | 2,973 |  |  | 8,142 |  |  | 16,617 |  |  | 17,230 |  |
| Other | 1,105 |  |  | 1,132 |  |  | 3,134 |  |  | 2,699 |  |
| Total revenue | $ | 57,006 |  |  | $ | 35,082 |  |  | $ | 147,811 |  |  | $ | 91,166 |  |

[0001045810-25-000230:notes:129]
(1)    Previously, revenue by geographic area was reported based on the billing location of our customers, which often reflected a customer’s centralized invoicing location, even though our products were almost always shipped elsewhere. We believe changing to revenue based upon the location of our customers’ headquarters provides a better representation of the geographic profile of our revenue. Prior period information has been recast to reflect this change.

[0001045810-25-000230:notes:130]
(2)    In the third quarter of fiscal year 2026, we estimate 86% of Data Center revenue from Taiwan-headquartered customers is attributed to end customers based in the United States and Europe.

[0001045810-25-000230:notes:131]
Revenue from sales to customers headquartered outside of the United States accounted for 31% and 34% of total revenue for the third quarter and first nine months of fiscal year 2026, respectively, and 44% and 41% of total revenue for the third quarter and first nine months of fiscal year 2025, respectively.

[0001045810-25-000230:notes:132]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, ODMs, OEMs, CSPs, hyperscale companies, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, Neocloud builders, hyperscale, consumer internet companies, enterprises, and public sector entities.

[0001045810-25-000230:notes:133]
For the third quarter of fiscal year 2026, four direct customers with sales greater than 10% of total revenue included: Customer A at 22%, Customer B at 15%, Customer C at 13%, and Customer D at 11%, which were attributable to the Compute & Networking segment. For the first nine months of fiscal year 2026, sales to two direct customers represented 21% and 13% of total revenue, respectively, both of which were attributable to the Compute & Networking segment. The customers referenced above may represent different customers than those reported in a previous period.

[0001045810-25-000230:notes:134]
For the third quarter of fiscal year 2025, sales to three direct customers each represented 12% of total revenue, which were attributable to the Compute & Networking segment. For the first nine months of fiscal year 2025, sales to three direct customers represented 12%, 11%, and 11% of total revenue, which were attributable to the Compute & Networking segment.

[0001045810-25-000230:notes:135]
[same as prior period, unchanged from 0001045810-25-000209:notes:128]

[0001045810-25-000230:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Revenue by End Market: |  |  |  |  |  |  |  |
| Data Center | $ | 51,215 |  |  | $ | 30,771 |  |  | $ | 131,423 |  |  | $ | 79,606 |  |
| Compute | 43,028 |  |  | 27,644 |  |  | 111,027 |  |  | 69,640 |  |
| Networking | 8,187 |  |  | 3,127 |  |  | 20,396 |  |  | 9,966 |  |
| Gaming | 4,265 |  |  | 3,279 |  |  | 12,315 |  |  | 8,806 |  |
| Professional Visualization | 760 |  |  | 486 |  |  | 1,870 |  |  | 1,367 |  |
| Automotive | 592 |  |  | 449 |  |  | 1,745 |  |  | 1,124 |  |
| OEM and Other | 174 |  |  | 97 |  |  | 458 |  |  | 263 |  |
| Total revenue | $ | 57,006 |  |  | $ | 35,082 |  |  | $ | 147,811 |  |  | $ | 91,166 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-25-000230:notes:137]
[same as prior period, unchanged from 0001045810-25-000209:notes:130]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-25-000230:notes:138]
[same as prior period, unchanged from 0001045810-25-000209:notes:131]

[0001045810-25-000230:notes:139]
Future minimum lease obligations under our non-cancelable lease agreements as of October 26, 2025 were as follows:

[0001045810-25-000230:notes:140]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first nine months of fiscal year 2026) | $ | 118 |  |
| 2027 | 431 |  |
| 2028 | 413 |  |
| 2029 | 384 |  |
| 2030 | 308 |  |
| 2031 and thereafter | 1,200 |  |
| Total | 2,854 |  |
| Less imputed interest | 499 |  |
| Present value of net future minimum lease payments | 2,355 |  |
| Less short-term operating lease liabilities | 341 |  |
| Long-term operating lease liabilities | $ | 2,014 |  |

[0001045810-25-000230:notes:141]
Between the fourth quarter of fiscal year 2026 and fiscal year 2030, we expect to commence leases with future obligations of $7.5 billion, primarily for data center leases with lease terms of 1.5 to 15 years.

[0001045810-25-000230:notes:142]
Operating lease expenses were $122 million and $92 million for the third quarter, and $332 million and $258 million for the first nine months, of fiscal years 2026 and 2025, respectively. Short-term and variable lease expenses for the third quarter and first nine months of fiscal years 2026 and 2025 were not significant.

[0001045810-25-000230:notes:143]
[same as prior period, unchanged from 0001045810-25-000209:notes:136]

[0001045810-25-000230:notes:144]
|  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 301 |  |  | $ | 227 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 752 |  |  | $ | 679 |  |

[0001045810-25-000230:notes:145]
As of October 26, 2025, our operating leases have a weighted average remaining lease term of 8.0 years and a weighted average discount rate of 4.43%. As of January 26, 2025, our operating leases had a weighted average remaining lease term of 6.5 years and a weighted average discount rate of 4.16%.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-25-000230:notes:146]
| Name |  | Title of Director or Officer |  | Action |  | Date |  | Total Shares of Common Stock to be Sold |  | Expiration Date |
| Debora Shoquist |  | Executive Vice President, Operations |  | Adoption |  | 9/9/2025 |  | 309,840 |  | 12/31/2026 |
| Donald Robertson |  | Vice President and Chief Accounting Officer |  | Adoption |  | 9/18/2025 |  | 138,042 * |  | 12/31/2026 |
| Ajay Puri |  | Executive Vice President, Worldwide Field Operations |  | Adoption |  | 9/19/2025 |  | 1,000,000 |  | 6/24/2026 |

[0001045810-25-000230:notes:147]
* Includes 38,042 shares from future vests of equity awards, and the actual number of shares to be sold will be net of shares withheld by the Company for taxes.
