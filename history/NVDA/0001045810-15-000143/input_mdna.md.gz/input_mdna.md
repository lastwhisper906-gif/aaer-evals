# NVDA MD&A — 0001045810-15-000143


## mdna

[0001045810-15-000143:mdna:1]
[same as prior period, unchanged from 0001045810-15-000097:mdna:1]

[0001045810-15-000143:mdna:2]
[same as prior period, unchanged from 0001045810-15-000097:mdna:2]

[0001045810-15-000143:mdna:3]
[same as prior period, unchanged from 0001045810-15-000097:mdna:3]

[0001045810-15-000143:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce Experience, GTX, ICERA, Iray, Maxwell, NVIDIA DRIVE, NVIDIA GRID, NVIDIA SHIELD, Pascal, Quadro, SHIELD, Tegra, Tesla, and TITAN are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-15-000143:mdna:5]
[same as prior period, unchanged from 0001045810-15-000097:mdna:5]

[0001045810-15-000143:mdna:6]
[same as prior period, unchanged from 0001045810-15-000097:mdna:6]

[0001045810-15-000143:mdna:7]
[same as prior period, unchanged from 0001045810-15-000097:mdna:8]

[0001045810-15-000143:mdna:8]
[same as prior period, unchanged from 0001045810-15-000097:mdna:9]

[0001045810-15-000143:mdna:9]
Our business model has three elements: creating NVIDIA-branded products and services, offering our processors to original equipment manufacturers, or OEMs, and licensing our intellectual property. NVIDIA’s products and services are built on three computing platforms - PC, Datacenter/Cloud, and Mobile, and address primarily four large markets: Gaming, Enterprise, High Performance Computing & Cloud, and Automotive.

[0001045810-15-000143:mdna:10]
[same as prior period, unchanged from 0001045810-15-000097:mdna:11]

[0001045810-15-000143:mdna:11]
[same as prior period, unchanged from 0001045810-15-000097:mdna:12]

[0001045810-15-000143:mdna:12]
25

[0001045810-15-000143:mdna:13]
[same as prior period, unchanged from 0001045810-15-000097:mdna:13]

[0001045810-15-000143:mdna:14]
[same as prior period, unchanged from 0001045810-15-000097:mdna:14]

[0001045810-15-000143:mdna:15]
[same as prior period, unchanged from 0001045810-15-000097:mdna:15]

[0001045810-15-000143:mdna:16]
[same as prior period, unchanged from 0001045810-15-000097:mdna:16]

[0001045810-15-000143:mdna:17]
During the second quarter of fiscal year 2016, we released our new GeForce GTX 980 Ti GPU and we nearly doubled the users of our GeForce Experience PC gaming platform from a year earlier. Additionally, we shipped cuDNN 3.0, which improves performance of deep learning training on GPUs.

[0001045810-15-000143:mdna:18]
During the first quarter of fiscal year 2016, we launched the GeForce GTX TITAN X, a GPU with twice the performance and double the power efficiency of its predecessor. We also introduced Quadro M6000, a powerful professional GPU and the Quadro Visual Computing Appliance, containing eight M6000 GPUs. Further, we introduced a roadmap for physically based rendering, including Iray 2015 rendering software. During the quarter we also announced that our next-generation Pascal GPU architecture. This architecture is expected to accelerate deep learning applications faster than the current-generation Maxwell processors.

[0001045810-15-000143:mdna:19]
[same as prior period, unchanged from 0001045810-15-000097:mdna:19]

[0001045810-15-000143:mdna:20]
During the second quarter of fiscal year 2016, we launched the NVIDIA SHIELD Android TV device - our first living-room entertainment device powered by our Tegra X1 processor - which connects TVs to entertainment apps and services. For the automotive market, we are partnering with more than 50 companies to use our NVIDIA DRIVE PX platform - a car computer that utilizes deep learning to enable self-driving capabilities - previously announced in the first quarter of fiscal year 2016, in their autonomous driving efforts.

[0001045810-15-000143:mdna:21]
[same as prior period, unchanged from 0001045810-15-000097:mdna:21]

[0001045810-15-000143:mdna:22]
During the second quarter of fiscal year 2016, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we made an upfront payment of $400 million to purchase shares of our common stock and received an initial delivery of 14 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. Additionally, we paid $52 million in cash dividends for the second quarter of fiscal year 2016. In the aggregate for the second quarter of fiscal year 2016, we returned a total of $452 million of capital to shareholders. Please refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding the ASR.

[0001045810-15-000143:mdna:23]
Litigation

[0001045810-15-000143:mdna:24]
In September 2014, we filed lawsuits against Qualcomm, Inc. and various Samsung entities in the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for using our GPU patents without a license.  The ITC action was heard in June 2015 and sought to permanently bar several Samsung products that rely on our patents in the United States. The Delaware case has been stayed during the pendency of the ITC action.

[0001045810-15-000143:mdna:25]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. That complaint and subsequent amended complaints allege that we infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. We have answered the most recent complaint and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted by Samsung. After the court severed our counter-claims from the main action, we voluntarily dismissed our counter-claims from the case.  In June 2015, Velocity Micro voluntarily agreed to a permanent injunction preventing it from infringing certain patents and was dismissed from the case with prejudice. A Markman hearing was held in June 2015 and trial on Samsung’s claims is currently set to begin in January 2016.  Samsung’s false advertising claim was dismissed with prejudice in July 2015.

[0001045810-15-000143:mdna:26]
[same as prior period, unchanged from 0001045810-15-000097:mdna:29]

[0001045810-15-000143:mdna:27]
[same as prior period, unchanged from 0001045810-15-000097:mdna:30]

[0001045810-15-000143:mdna:28]
[same as prior period, unchanged from 0001045810-15-000097:mdna:31]

[0001045810-15-000143:mdna:29]
Operating Lease Financing Arrangement

[0001045810-15-000143:mdna:30]
During the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. This headquarters building is being financed under an off-balance sheet, build-to-suit operating lease arrangement. The banks have committed to fund up to $380 million of costs relating to construction.

[0001045810-15-000143:mdna:31]
Restructuring and Other Charges

[0001045810-15-000143:mdna:32]
In May 2015, we announced our intent to wind-down our Icera modem operations and that we were open to a sale of the technology or operations. During the three months ended July 26, 2015, we pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations.

[0001045810-15-000143:mdna:33]
Our operating expenses for the three months ended July 26, 2015 included $89 million of restructuring and other charges. We expect to incur additional restructuring charges to operating expense of $15 million to $25 million for the remainder of fiscal year 2016.  These restructuring activities will impact approximately 5% of our global workforce, and we expect them to be substantially completed by the end of fiscal year 2016.  Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000143:mdna:34]
Product Recall

[0001045810-15-000143:mdna:35]
On July 31, 2015, we announced a voluntary recall and replacement of our SHIELD 8-inch tablets that were sold between July 2014 and July 2015. We have determined that the battery in these tablets can overheat, posing a fire hazard. The recall does not affect any other NVIDIA products. During the six months ended July 26, 2015, we recorded a $21 million charge against cost of revenue, including $15 million during our fiscal quarter ended July 26, 2015, to cover anticipated customer warranty, repair, return, replacement and other associated costs. Please refer to Note 9 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000143:mdna:36]
[same as prior period, unchanged from 0001045810-15-000097:mdna:34]

[0001045810-15-000143:mdna:37]
[same as prior period, unchanged from 0001045810-15-000097:mdna:35]

[0001045810-15-000143:mdna:38]
[same as prior period, unchanged from 0001045810-15-000097:mdna:36]

[0001045810-15-000143:mdna:39]
[same as prior period, unchanged from 0001045810-15-000097:mdna:37]

[0001045810-15-000143:mdna:40]
[same as prior period, unchanged from 0001045810-15-000097:mdna:38]

[0001045810-15-000143:mdna:41]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, product warranty charge, restructuring and other charges, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-15-000143:mdna:42]
[same as prior period, unchanged from 0001045810-15-000097:mdna:40]

[0001045810-15-000143:mdna:43]
[same as prior period, unchanged from 0001045810-15-000097:mdna:41]

[0001045810-15-000143:mdna:44]
[same as prior period, unchanged from 0001045810-15-000097:mdna:42]

[0001045810-15-000143:mdna:45]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, 2015 |  | July 27, 2014 |  | July 26, 2015 |  | July 27, 2014 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 45.0 |  |  | 43.9 |  |  | 44.2 |  |  | 44.5 |  |
| Gross profit | 55.0 |  |  | 56.1 |  |  | 55.8 |  |  | 55.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 27.8 |  |  | 30.6 |  |  | 28.6 |  |  | 30.4 |  |
| Sales, general and administrative | 12.9 |  |  | 10.8 |  |  | 12.5 |  |  | 10.8 |  |
| Restructuring and other charges | 7.7 |  |  | — |  |  | 3.9 |  |  | — |  |
| Total operating expenses | 48.4 |  |  | 41.4 |  |  | 45.0 |  |  | 41.2 |  |
| Operating income | 6.7 |  |  | 14.7 |  |  | 10.8 |  |  | 14.3 |  |
| Interest income | 0.8 |  |  | 0.6 |  |  | 0.8 |  |  | 0.6 |  |
| Interest expense | (1.0 | ) |  | (1.0 | ) |  | (1.0 | ) |  | (1.0 | ) |
| Other income (expense), net | (0.1 | ) |  | (0.3 | ) |  | (0.1 | ) |  | 0.6 |  |
| Income before income tax | 6.4 |  |  | 14.0 |  |  | 10.5 |  |  | 14.5 |  |
| Income tax expense | 4.0 |  |  | 2.4 |  |  | 3.6 |  |  | 2.4 |  |
| Net income | 2.4 | % |  | 11.6 | % |  | 6.9 | % |  | 12.1 | % |

[0001045810-15-000143:mdna:46]
[same as prior period, unchanged from 0001045810-15-000097:mdna:45]

[0001045810-15-000143:mdna:47]
NVIDIA’s products and services are built for three computing platforms - PC, Datacenter/Cloud, and Mobile. In the first half of fiscal year 2016, approximately 75% of our revenue stemmed from products and services associated with the PC computing platform, of which GPUs for gaming and enterprise markets comprised over 85% while PC OEM represented less than 15%.

[0001045810-15-000143:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, 2015 |  | July 27, 2014 |  | $Change |  | %Change |  | July 26, 2015 |  | July 27, 2014 |  | $Change |  | %Change |
|  | (In millions) |  |  |  | (In millions) |  |  |
| GPU | $ | 959 |  |  | $ | 878 |  |  | $ | 81 |  |  | 9 | % |  | $ | 1,899 |  |  | $ | 1,776 |  |  | $ | 123 |  |  | 7 | % |
| Tegra Processor | 128 |  |  | 159 |  |  | (31 | ) |  | (19 | ) |  | 273 |  |  | 298 |  |  | (25 | ) |  | (8 | ) |
| All Other | 66 |  |  | 66 |  |  | — |  |  | — |  |  | 132 |  |  | 132 |  |  | — |  |  | — |  |
| Total | $ | 1,153 |  |  | $ | 1,103 |  |  | $ | 50 |  |  | 5 | % |  | $ | 2,304 |  |  | $ | 2,206 |  |  | $ | 98 |  |  | 4 | % |

[0001045810-15-000143:mdna:49]
Revenue for the second quarter of fiscal year 2016 increased by 5% when compared to the second quarter of fiscal year 2015. Revenue for the first half of fiscal year 2016 increased 4% when compared to the first half of fiscal year 2015.

[0001045810-15-000143:mdna:50]
28

[0001045810-15-000143:mdna:51]
Revenue by Operating Segments

[0001045810-15-000143:mdna:52]
GPU Business. GPU business revenue increased by 9% in the second quarter of fiscal year 2016 compared to the second quarter of fiscal year 2015. This increase was due primarily to growth in revenue from high-end GeForce GPUs for gaming, which increased over 50% fueled by continued strength in PC gaming. Revenue from Tesla GPUs for high performance computing and cloud decreased, reflecting variability in project purchasing. Revenue from Quadro GPUs for enterprise declined due to weakness in the overall workstation market. Revenue from GeForce GPU products for mainstream PC OEMs declined year-over-year compared to the second quarter of fiscal year 2015, reflecting the decline in overall consumer PCs.

[0001045810-15-000143:mdna:53]
GPU business revenue increased by 7% in the first half of fiscal year 2016 compared to the first half of fiscal year 2015. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased over 30% reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products. Revenue from Tesla GPUs for high performance computing and cloud increased, driven by strong demand with cloud service providers. Revenue from Quadro GPUs for enterprise declined due to weakness in the overall workstation market. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-15-000143:mdna:54]
Tegra Processor Business. Tegra Processor business revenue decreased by 19% in the second quarter of fiscal year 2016 compared to the second quarter of fiscal year 2015. This decrease was driven by a decline in sales of Tegra products for OEM smartphones and tablets of over 80%, partially offset by an increase in sales of Tegra products serving automotive systems of over 75%, plus increases in revenue from development services and sales of SHIELD devices.

[0001045810-15-000143:mdna:55]
Tegra Processor business revenue decreased by 8% in the first half of fiscal year 2016 compared to the first half of fiscal year 2015. This decrease was driven by a decline in sales of Tegra products for OEM smartphones and tablets of over 80%, partially offset by an increase in Automotive sales of Tegra products of nearly 100%.  Revenue also grew from development services and sales of SHIELD devices.

[0001045810-15-000143:mdna:56]
All Other. We recognized $66 million in revenue during the second quarter of both fiscal years 2016 and 2015 and $132 million in revenue during the first half of both fiscal years 2016 and 2015, from the patent cross licensing arrangement with Intel.

[0001045810-15-000143:mdna:57]
[same as prior period, unchanged from 0001045810-15-000097:mdna:51]

[0001045810-15-000143:mdna:58]
Revenue from sales to customers outside of the United States and Other Americas accounted for 80% of total revenue for the second quarter and 77% of total revenue for the first half of fiscal year 2016. Revenue from sales to customers outside of the United States and Other Americas accounted for 74% of total revenue for the second quarter and 75% of total revenue for the first half of fiscal year 2015. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-15-000143:mdna:59]
We generated revenue from significant customers, those representing 10% or more of total revenue. Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding significant customers.

[0001045810-15-000143:mdna:60]
[same as prior period, unchanged from 0001045810-15-000097:mdna:54]

[0001045810-15-000143:mdna:61]
[same as prior period, unchanged from 0001045810-15-000097:mdna:55]

[0001045810-15-000143:mdna:62]
Gross margin is the percentage of gross profit to revenue. Our gross margin can vary in any period depending on the mix of types of products sold. Our gross margin is impacted by the mix of products we sell. Product mix is difficult to estimate with accuracy.  Therefore, if we experience product transition challenges, including the introduction of NVIDIA-branded products such as SHIELD devices, if we achieve significant revenue growth in lower margin product lines or if we are unable to earn as much revenue as we expect from higher margin product lines, our gross margin may be negatively impacted.

[0001045810-15-000143:mdna:63]
Our overall gross margin was 55.0% and 56.1% for the second quarter of fiscal years 2016 and 2015, respectively, and 55.8% and 55.5% for the first half of fiscal years 2016 and 2015, respectively.

[0001045810-15-000143:mdna:64]
[same as prior period, unchanged from 0001045810-15-000097:mdna:85]

[0001045810-15-000143:mdna:65]
Charges to cost of sales for inventory provisions totaled $18 million and $13 million for the second quarter of fiscal years 2016 and 2015, respectively, unfavorably impacting our gross margin by 1.5% and 0.9%, respectively. Sales of inventory that was previously written-off or written-down totaled $10 million and $5 million for the second quarter of fiscal years 2016 and 2015, respectively, favorably impacting our gross margin by 0.9% and 0.7%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.6% unfavorable impact for the second quarter of fiscal year 2016 and a 0.2% unfavorable impact for the second quarter of fiscal year 2015.

[0001045810-15-000143:mdna:66]
Charges to cost of sales for inventory provisions totaled $31 million and $23 million for the first half of fiscal years 2016 and 2015, respectively, unfavorably impacting our gross margin by 1.4% and 1.2%, respectively. Sales of inventory that was previously written-off or written-down totaled $19 million and $31 million for the first half of fiscal years 2016 and 2015, respectively, favorably impacting our gross margin by 0.8% and 1.6%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.6% unfavorable impact for the first half of fiscal year 2016 and a 0.4% favorable impact for the first half of fiscal year 2015.

[0001045810-15-000143:mdna:67]
[same as prior period, unchanged from 0001045810-15-000097:mdna:59]

[0001045810-15-000143:mdna:68]
GPU Business. The gross margin of our GPU business increased in the second quarter and first half of fiscal year 2016 compared to the second quarter and first half of fiscal year 2015, respectively. GPU margins increased primarily due to a richer product mix resulting from lower sales of GeForce GPU products for mainstream PC OEMs and stronger sales of our GeForce GPU products for gaming.

[0001045810-15-000143:mdna:69]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased in the second quarter and first half of fiscal year 2016 compared to the second quarter and first half of fiscal year 2015, respectively, primarily due to the warranty charge associated with the SHIELD 8-inch tablet product recall.

[0001045810-15-000143:mdna:70]
[same as prior period, unchanged from 0001045810-15-000097:mdna:62]

[0001045810-15-000143:mdna:71]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, 2015 |  | July 27, 2014 |  | $Change |  | %Change |  | July 26, 2015 |  | July 27, 2014 |  | $Change |  | %Change |
|  | (In millions) |  |  |  | (In millions) |  |  |
| Research and development expenses | $ | 320 |  |  | $ | 337 |  |  | $ | (17 | ) |  | (5 | )% |  | $ | 658 |  |  | $ | 672 |  |  | $ | (14 | ) |  | (2 | )% |
| Sales, general and administrative expenses | 149 |  |  | 119 |  |  | 30 |  |  | 25 |  |  | 289 |  |  | 237 |  |  | 52 |  |  | 22 |  |
| Restructuring and other charges | 89 |  |  | — |  |  | 89 |  |  | 100 |  |  | 89 |  |  | — |  |  | 89 |  |  | 100 |  |
| Total operating expenses | $ | 558 |  |  | $ | 456 |  |  | $ | 102 |  |  | 22 | % |  | $ | 1,036 |  |  | $ | 909 |  |  | $ | 127 |  |  | 14 | % |
| Research and development as a percentage of net revenue | 28 | % |  | 31 | % |  |  |  |  |  |  |  | 29 | % |  | 30 | % |  |  |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 13 | % |  | 11 | % |  |  |  |  |  |  |  | 13 | % |  | 11 | % |  |  |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | 8 | % |  | — | % |  |  |  |  |  | 4 | % |  | — | % |  |  |  |  |

[0001045810-15-000143:mdna:72]
[same as prior period, unchanged from 0001045810-15-000097:mdna:64]

[0001045810-15-000143:mdna:73]
Research and development expenses decreased by 5% during the second quarter of fiscal year 2016 compared to the second quarter of fiscal year 2015 and decreased by 2% during the first half of fiscal year 2016 compared to the first half of fiscal year 2015.  These decreases were primarily driven by the wind-down of Icera modem operations and other organization efficiencies, partially offset by increases in employee compensation and related costs, including stock-based compensation expense.

[0001045810-15-000143:mdna:74]
[same as prior period, unchanged from 0001045810-15-000097:mdna:97]

[0001045810-15-000143:mdna:75]
[same as prior period, unchanged from 0001045810-15-000097:mdna:66]

[0001045810-15-000143:mdna:76]
Sales, general and administrative expenses increased by 25% during the second quarter of fiscal year 2016 compared to the second quarter of fiscal year 2015. Outside professional fees increased,  primarily due to $24 million of legal fees associated with our litigation against Samsung and Qualcomm. Compensation and benefits increased by $6 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense.

[0001045810-15-000143:mdna:77]
Sales, general and administrative expenses increased by 22% during the first half of fiscal year 2016 compared to the first half of fiscal year 2015. Outside professional fees increased, primarily due to $40 million of legal fees associated with our litigation against Samsung and Qualcomm. Compensation and benefits increased by $15 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense.

[0001045810-15-000143:mdna:78]
Restructuring and Other Charges

[0001045810-15-000143:mdna:79]
In May 2015, we announced our intent to wind-down our Icera modem operations and that we were open to a sale of the technology or operations. During the three months ended July 26, 2015, we pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations.  The wind-down of Icera modem operations allows for continued investment in strategic growth areas including our growth initiatives of deep learning, self-driving cars, and gaming.

[0001045810-15-000143:mdna:80]
Our operating expenses for the three months ended July 26, 2015 included $89 million of restructuring and other charges, as follows:

[0001045810-15-000143:mdna:81]
|  | Three Months Ended |
|  | July 26, |
|  | 2015 |
|  | (In millions) |
| Employee severance and related costs | $ | 56 |  |
| Tax subsidy impairment | 17 |  |
| Fixed assets impairment | 11 |  |
| Facilities and related costs | 2 |  |
| Other exit costs | 3 |  |
| Balance at July 26, 2015 | $ | 89 |  |

[0001045810-15-000143:mdna:82]
We expect to incur additional restructuring charges to operating expense of $15 million to $25 million for the remainder of fiscal year 2016.  These restructuring activities will impact approximately 5% of our global workforce, and we expect them to be substantially completed by the end of fiscal year 2016.  Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000143:mdna:83]
[same as prior period, unchanged from 0001045810-15-000097:mdna:68]

[0001045810-15-000143:mdna:84]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest expense is primarily comprised of coupon interest and debt discount amortization related to the convertible notes issued in December 2013. Interest income was $9 million and $7 million during the second quarter of fiscal years 2016 and 2015, respectively. Interest income was $18 million and $13 million during the first half of fiscal years 2016 and 2015, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities as well as higher purchased yields. Interest expense was $12 million and $22 million during the second quarter and first half of fiscal year 2016, respectively, relatively comparable to $12 million and $23 million during the second quarter and first half of fiscal year 2015, respectively.

[0001045810-15-000143:mdna:85]
[same as prior period, unchanged from 0001045810-15-000097:mdna:70]

[0001045810-15-000143:mdna:86]
Other income (expense), net consists primarily of realized gains and losses from the sale of marketable securities, sales of investments in non-affiliated companies, and the impact of changes in foreign currency rates. During the second quarter of fiscal years 2016 and 2015, we recorded other expense, net, of $1 million and $3 million, respectively. During the first half of fiscal years 2016 and 2015 we recorded other expense, net, of $2 million and other income, net, of $14 million, respectively. Other income in the first half of fiscal year 2015 included a $17 million gain from the sale of a non-affiliated investment.

[0001045810-15-000143:mdna:87]
31

[0001045810-15-000143:mdna:88]
[same as prior period, unchanged from 0001045810-15-000097:mdna:72]

[0001045810-15-000143:mdna:89]
We recognized income tax expense of $46 million and $84 million for the second quarter and first half of fiscal year 2016, respectively, and $27 million and $53 million for the second quarter and first half of fiscal year 2015, respectively.  Income tax expense as a percentage of income before taxes, or our effective tax rate, was 64.0% and 34.3% for the second quarter and first half of fiscal year 2016, respectively, and 17.2% and 16.8% for the second quarter and first half of fiscal year 2015, respectively.

[0001045810-15-000143:mdna:90]
Our income tax expense for the three months ended July 26, 2015 included a charge of $27 million for the write-down of a deferred tax asset related to our Icera modem operations, partially offset by a $13 million tax benefit related to the restructuring and other charges.

[0001045810-15-000143:mdna:91]
The increase in our effective tax rate in the second quarter of fiscal year 2016 as compared to the same period in the prior fiscal year was primarily due to the tax related charges in connection with the wind-down of the Icera modem operations, an increase in the amount of earnings subject to U.S. tax, and increase of permanent tax differences related to stock-based compensation in the first half of fiscal year 2016.

[0001045810-15-000143:mdna:92]
Our effective tax rate on income before tax for the first half of fiscal year 2016 of 34.3% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate. Further, our actual effective tax rate for the first half of fiscal year 2016 of 34.3% differs from our annual projected effective tax rate for this period of 22.2% due to certain discrete items, including the tax related charges attributable to the wind-down of the Icera modem operations, partially offset by tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-15-000143:mdna:93]
Our effective tax rate on income before tax for the first half of fiscal year 2015 of 16.8% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax.

[0001045810-15-000143:mdna:94]
On July 27, 2015, the U.S. Tax Court in Altera Corp. v. Commissioner, 145 T.C. No. 3 (2015) issued an opinion with respect to Altera’s litigation with the Internal Revenue Service, or IRS, concerning the treatment of stock-based compensation expense in an inter-company cost sharing arrangement. In ruling in favor of Altera, the Tax Court invalidated the portion of the Treasury regulations requiring the inclusion of stock-based compensation expense in such inter-company cost-sharing arrangements. The IRS has a 90 day period to appeal the decision, in which case the matter would come before the Ninth Circuit Court of Appeals.   Accordingly, we will continue to monitor the progress of this case for any significant impact on our consolidated financial statements.

[0001045810-15-000143:mdna:95]
[same as prior period, unchanged from 0001045810-15-000097:mdna:77]

[0001045810-15-000143:mdna:96]
[same as prior period, unchanged from 0001045810-15-000097:mdna:78]

[0001045810-15-000143:mdna:97]
|  | As of |
|  | July 26, 2015 |  | January 25, 2015 |
|  | (In millions) |
| Cash and cash equivalents | $ | 435 |  |  | $ | 497 |  |
| Marketable securities | 4,070 |  |  | 4,126 |  |
| Cash, cash equivalents, and marketable securities | $ | 4,505 |  |  | $ | 4,623 |  |

[0001045810-15-000143:mdna:98]
As of July 26, 2015, we had $4.51 billion in cash, cash equivalents and marketable securities, a decrease of $118 million from $4.62 billion as of January 25, 2015. This decrease was primarily due to share repurchases totaling $452 million and $99 million of dividends we paid during the first half of fiscal year 2016, offset by cash generated from operations.

[0001045810-15-000143:mdna:99]
|  | Six Months Ended |
|  | July 26, 2015 |  | July 27, 2014 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 409 |  |  | $ | 247 |  |
| Net cash provided by (used in) investing activities | $ | 12 |  |  | $ | (394 | ) |
| Net cash used in financing activities | $ | (483 | ) |  | $ | (490 | ) |

[0001045810-15-000143:mdna:100]
Cash provided by operating activities increased in the first half of fiscal year 2016 compared to the first half of fiscal year 2015. The increase was primarily due to changes in working capital, partially offset by a decline in net income.

[0001045810-15-000143:mdna:101]
Cash provided by (used in) investing activities increased in the first half of fiscal year 2016 compared to the first half of fiscal year 2015. The increase was primarily due to higher proceeds from sales and maturities of marketable securities.

[0001045810-15-000143:mdna:102]
Cash used in financing activities remained relatively comparable during both the first half of fiscal years 2016 and 2015.

[0001045810-15-000143:mdna:103]
[same as prior period, unchanged from 0001045810-15-000097:mdna:86]

[0001045810-15-000143:mdna:104]
Our primary source of liquidity is cash generated by our operations. Our investment portfolio consists principally of cash and cash equivalents, debt securities of corporations and United States government and its agencies, asset-backed securities, mortgage-backed securities issued by government-sponsored enterprises, money market funds and foreign government bonds. These investments are denominated in United States dollars. As of July 26, 2015, we did not have any investments in auction-rate preferred securities.

[0001045810-15-000143:mdna:105]
[same as prior period, unchanged from 0001045810-15-000097:mdna:88]

[0001045810-15-000143:mdna:106]
As of July 26, 2015 and January 25, 2015, we had $4.51 billion and $4.62 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of July 26, 2015, we were in compliance with our investment policy. As of July 26, 2015, our investments in government agencies and government-sponsored enterprises represented 35% of our total investment portfolio, while the financial sector accounted for 27% of our total investment portfolio.  All of our investments are in A/A3 or better rated securities.

[0001045810-15-000143:mdna:107]
[same as prior period, unchanged from 0001045810-15-000097:mdna:90]

[0001045810-15-000143:mdna:108]
Dividend payments and any share repurchases must be made from cash held in the United States. In the second quarter and first half of fiscal year 2016, we made total cash dividend payments of $52 million and $99 million, respectively, and repurchased $400 million and $452 million of our common stock in the second quarter and first half of fiscal year 2016, respectively, utilizing U.S. cash previously taxed as of July 26, 2015.

[0001045810-15-000143:mdna:109]
In the second quarter of fiscal year 2016, we began the wind-down of Icera modem operations.  Our operating expenses for the three months ended July 26, 2015 included $89 million of restructuring and other charges. We expect to incur additional restructuring charges to operating expense of $15 million to $25 million for the remainder of fiscal year 2016.  Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000143:mdna:110]
We believe our cash, cash equivalents and marketable securities balance will be sufficient to fund our capital needs.

[0001045810-15-000143:mdna:111]
[same as prior period, unchanged from 0001045810-15-000097:mdna:92]

[0001045810-15-000143:mdna:112]
During the second quarter of fiscal year 2016, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we made an upfront payment of $400 million to purchase shares of our common stock and received an initial delivery of 14 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. Additionally, we paid $52 million in cash dividends for the second quarter of fiscal year 2016. As such, in the aggregate for the second quarter of fiscal year 2016, we returned a total of $452 million of capital to shareholders.

[0001045810-15-000143:mdna:113]
Our cash dividend program and the payment of future cash dividends under that program are subject to continued capital availability and best interests of our shareholders and compliance of laws and agreements of NVIDIA.

[0001045810-15-000143:mdna:114]
[same as prior period, unchanged from 0001045810-15-000097:mdna:98]

[0001045810-15-000143:mdna:115]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating, acquisition, share repurchase, cash dividend and capital requirements for at least the next twelve months. However, there is no assurance that we will not need to raise additional equity or debt financing within this time frame. Additional financing may not be available on favorable terms or at all and may be dilutive to our then-current shareholders. We also may require additional capital for other purposes not presently contemplated.

[0001045810-15-000143:mdna:116]
During the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. This headquarters building is being financed as an operating lease arrangement. Under terms of this financing arrangement, costs incurred by us that are associated with the construction will be reimbursed by the banks.

[0001045810-15-000143:mdna:117]
[same as prior period, unchanged from 0001045810-15-000097:mdna:103]

[0001045810-15-000143:mdna:118]
During the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. The banks have committed to fund up to $380 million of costs relating to construction. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks. During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Please refer to Note 11 of the Notes to Condensed Consolidated Financial Statements for a discussion regarding our operating lease financing arrangement.

[0001045810-15-000143:mdna:119]
[same as prior period, unchanged from 0001045810-15-000097:mdna:100]

[0001045810-15-000143:mdna:120]
As of July 26, 2015, we had outstanding inventory purchase obligations totaling $487 million. Other than the off-balance sheet arrangement described above, there were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

[0001045810-15-000143:mdna:121]
[same as prior period, unchanged from 0001045810-15-000097:mdna:102]

[0001045810-15-000143:mdna:122]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000143:mdna:123]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
