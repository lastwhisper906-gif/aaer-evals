# NVDA 8-K — 0001045810-15-000131 filed 2015-08-06

## item codes, every 8-K on or before 2015-08-19

- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2015-08-19

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-15-000131:8k_2_02:1]
EX-99.1
2
q216pr.htm
Q2'16 PRESS RELEASE

[0001045810-15-000131:8k_2_02:2]
Q2'16 PR

[0001045810-15-000131:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-15-000131:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2016

[0001045810-15-000131:8k_2_02:5]
| • | Revenue rose 5 percent to $1.153 billion from $1.103 billion a year earlier |

[0001045810-15-000131:8k_2_02:6]
| • | Gaming and automotive revenue continued to grow strongly from a year earlier |

[0001045810-15-000131:8k_2_02:7]
| • | Working with more than 50 companies to use NVIDIA DRIVE PX in their autonomous driving efforts |

[0001045810-15-000131:8k_2_02:8]
SANTA CLARA, Calif.-Aug. 6, 2015-NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 26, 2015, of $1.153 billion, up 5 percent from $1.103 billion a year earlier, and up marginally from $1.151 billion the previous quarter.

[0001045810-15-000131:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.05. This includes a charge of $0.19 per diluted share in connection with the company’s decision to wind down its Icera® modem operations, after a viable buyer failed to emerge. It also includes a charge of $0.02 per diluted share related to the NVIDIA SHIELD™ tablet recall.

[0001045810-15-000131:8k_2_02:10]
Non-GAAP earnings per diluted share were $0.34, up 13 percent from $0.30 a year earlier, and up 3 percent from $0.33 in the previous quarter.

[0001045810-15-000131:8k_2_02:11]
“Our strong performance in a challenging environment reflects NVIDIA’s success in creating specialized visual computing platforms targeted at important growth markets,” said Jen-Hsun Huang, president and chief executive officer of NVIDIA.

[0001045810-15-000131:8k_2_02:12]
“Our gaming platforms continue to be fueled by growth in multiple vectors - new technologies like 4K and VR, blockbuster games with amazing production values, and increasing worldwide fan engagement in e-sports. We’re working with more than 50 companies that are exploring NVIDIA DRIVE to enable self-driving cars. And our GPU-accelerated data center platform continues to make great strides in some of today’s most important computing initiatives - cloud-based virtualization and high performance computing applications like deep learning.

[0001045810-15-000131:8k_2_02:13]
“Visual computing continues to grow in importance, making our growth opportunities more exciting than ever,” he said.

[0001045810-15-000131:8k_2_02:14]
Capital Return

[0001045810-15-000131:8k_2_02:15]
During the second quarter, NVIDIA paid $52 million in cash dividends and $400 million in share repurchases - returning an aggregate of $452 million to shareholders. In the year’s first half, the company returned an aggregate of $551 million to shareholders.

[0001045810-15-000131:8k_2_02:16]
NVIDIA will pay its next quarterly cash dividend of $0.0975 per share on September 11, 2015, to all shareholders of record on August 20, 2015.

[0001045810-15-000131:8k_2_02:17]
| GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q2 FY16 | Q1 FY16 | Q2 FY15 | Q/Q | Y/Y |
| Revenue | $1,153 | $1,151 | $1,103 | -- | up 5% |
| Gross margin | 55.0% | 56.7% | 56.1% | down 170 bps | down 110 bps |
| Operating expenses | $558 | $477 | $456 | up 17% | up 22% |
| Net income | $26 | $134 | $128 | down 81% | down 80% |
| Diluted earnings per share | $0.05 | $0.24 | $0.22 | down 79% | down 77% |

[0001045810-15-000131:8k_2_02:18]
| Non-GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q2 FY16 | Q1 FY16 | Q2 FY15 | Q/Q | Y/Y |
| Revenue | $1,153 | $1,151 | $1,103 | -- | up 5% |
| Gross margin | 56.6% | 56.9% | 56.4% | down 30 bps | up 20 bps |
| Operating expenses | $421 | $425 | $412 | down 1% | up 2% |
| Net income | $190 | $187 | $173 | up 2% | up 10% |
| Diluted earnings per share | $0.34 | $0.33 | $0.30 | up 3% | up 13% |

[0001045810-15-000131:8k_2_02:19]
NVIDIA’s outlook for the third quarter of fiscal 2016 is as follows:

[0001045810-15-000131:8k_2_02:20]
| • | Revenue is expected to be $1.18 billion, plus or minus two percent. |

[0001045810-15-000131:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 56.2 percent and 56.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-15-000131:8k_2_02:22]
| • | GAAP operating expenses are expected to be approximately $484 million. Non-GAAP operating expenses are expected to be approximately $435 million. |

[0001045810-15-000131:8k_2_02:23]
| • | GAAP and non-GAAP tax rates for the third quarter of fiscal 2016 are expected to be 22 percent and 20 percent, respectively, plus or minus one percent. |

[0001045810-15-000131:8k_2_02:24]
| • | The above GAAP outlook amounts exclude additional restructuring charges, which are expected to be in the range of $15 million to $25 million, in the second half of fiscal 2016. |

[0001045810-15-000131:8k_2_02:25]
| • | Capital expenditures are expected to be approximately $25 million to $35 million. |

[0001045810-15-000131:8k_2_02:26]
Second Quarter Fiscal 2016 Highlights

[0001045810-15-000131:8k_2_02:27]
During the second quarter, NVIDIA achieved progress in each of its platforms.

[0001045810-15-000131:8k_2_02:28]
Gaming:

[0001045810-15-000131:8k_2_02:29]
| • | Continued strong demand for GeForce® GTX™ GPUs, driven by advanced new games and growth in competitive e-sports, which now have an estimated 130 million viewers. |

[0001045810-15-000131:8k_2_02:30]
| • | Unveiled the flagship GeForce GTX 980 Ti GPU, with the power to drive 4K and VR gaming. |

[0001045810-15-000131:8k_2_02:31]
| • | Increased users of the GeForce Experience™ PC gaming platform to 65 million, from 38 million a year earlier. |

[0001045810-15-000131:8k_2_02:32]
| • | Launched the NVIDIA SHIELD Android TV device, the most advanced smart TV platform, which connects TVs to a world of entertainment apps and services. |

[0001045810-15-000131:8k_2_02:33]
Enterprise Graphics & Virtualization:

[0001045810-15-000131:8k_2_02:34]
| • | Continued strong momentum for NVIDIA GRID™ graphics virtualization, which more than tripled its customer base to over 300 enterprises from a year earlier. |

[0001045810-15-000131:8k_2_02:35]
HPC & Cloud:

[0001045810-15-000131:8k_2_02:36]
| • | Engaged with more than 3,300 companies exploring the use of deep learning in areas such as speech recognition, image analysis and translation capabilities. |

[0001045810-15-000131:8k_2_02:37]
| • | Shipped cuDNN 3.0, which doubles the performance of deep learning training on GPUs and enables the training of more sophisticated neural networks. cuDNN has been downloaded by more than 9,000 researchers worldwide. |

[0001045810-15-000131:8k_2_02:38]
Auto:

[0001045810-15-000131:8k_2_02:39]
| • | Working with more than 50 companies to use the NVIDIA DRIVE™ PX platform in their autonomous driving efforts. |

[0001045810-15-000131:8k_2_02:40]
CFO Commentary

[0001045810-15-000131:8k_2_02:41]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-15-000131:8k_2_02:42]
Conference Call and Webcast Information

[0001045810-15-000131:8k_2_02:43]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2016 financial results and current financial prospects today at 2 p.m. Pacific Time (5 p.m. Eastern Time). To listen to the conference call, dial (303) 223-4372; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its third quarter fiscal 2016.

[0001045810-15-000131:8k_2_02:44]
Non-GAAP Measures

[0001045810-15-000131:8k_2_02:45]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, product warranty charge, acquisition-related costs, restructuring and other charges, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-15-000131:8k_2_02:46]
To Keep Current on NVIDIA:

[0001045810-15-000131:8k_2_02:47]
| • | Keep up with the NVIDIA Blog, and follow us on Facebook, Google+, Twitter, LinkedIn and Instagram. |

[0001045810-15-000131:8k_2_02:48]
| • | View NVIDIA videos on YouTube and images on Flickr. |

[0001045810-15-000131:8k_2_02:49]
| • | Use the Pulse news reader to subscribe to the NVIDIA Daily News feed. |

[0001045810-15-000131:8k_2_02:50]
About NVIDIA

[0001045810-15-000131:8k_2_02:51]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-15-000131:8k_2_02:52]
###

[0001045810-15-000131:8k_2_02:53]
For further information, contact:

[0001045810-15-000131:8k_2_02:54]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-15-000131:8k_2_02:55]
Certain statements in this press release including, but not limited to statements as to: the company’s success in creating specialized visual computing platforms targeted at important growth markets; the company’s gaming platforms being fueled by growth in multiple vectors; increasing worldwide fan engagement in e-sports; the company’s GPU-accelerated datacenter platform making great strides in important computing initiatives; visual computing continuing to grow in importance; the company’s next quarterly cash dividend; the company’s financial outlook for the third quarter of fiscal 2016; the company’s tax rates for the third quarter of fiscal 2016; strong demand for GeForce GTX GPUs; the benefits of GeForce GTX 980Ti; strong momentum for GRID graphics virtualization; and the performance of cuDNN 3.0 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended April 26, 2015. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-15-000131:8k_2_02:56]
© 2015 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce Experience, GTX, Icera, NVIDIA DRIVE, NVIDIA GRID, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-15-000131:8k_2_02:57]
NVIDIA CORPORATION

[0001045810-15-000131:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-15-000131:8k_2_02:59]
(In millions, except per share data)

[0001045810-15-000131:8k_2_02:60]
(Unaudited)

[0001045810-15-000131:8k_2_02:61]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue | $ | 1,153 |  |  | $ | 1,103 |  |  | $ | 2,304 |  |  | $ | 2,206 |  |
| Cost of revenue | 519 |  |  | 484 |  |  | 1,018 |  |  | 983 |  |
| Gross profit | 634 |  |  | 619 |  |  | 1,286 |  |  | 1,223 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 320 |  |  | 337 |  |  | 658 |  |  | 672 |  |
| Sales, general and administrative | 149 |  |  | 119 |  |  | 289 |  |  | 237 |  |
| Restructuring and other charges | 89 |  |  | — |  |  | 89 |  |  | — |  |
| Total operating expenses | 558 |  |  | 456 |  |  | 1,036 |  |  | 909 |  |
| Operating income | 76 |  |  | 163 |  |  | 250 |  |  | 314 |  |
| Interest income | 9 |  |  | 7 |  |  | 18 |  |  | 13 |  |
| Interest expense | (12 | ) |  | (12 | ) |  | (22 | ) |  | (23 | ) |
| Other income (expense), net | (1 | ) |  | (3 | ) |  | (2 | ) |  | 14 |  |
| Income before income tax expense | 72 |  |  | 155 |  |  | 244 |  |  | 318 |  |
| Income tax expense | 46 |  |  | 27 |  |  | 84 |  |  | 53 |  |
| Net income | $ | 26 |  |  | $ | 128 |  |  | $ | 160 |  |  | $ | 265 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.05 |  |  | $ | 0.23 |  |  | $ | 0.29 |  |  | $ | 0.47 |  |
| Diluted | $ | 0.05 |  |  | $ | 0.22 |  |  | $ | 0.28 |  |  | $ | 0.46 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 541 |  |  | 558 |  |  | 545 |  |  | 559 |  |
| Diluted | 556 |  |  | 571 |  |  | 563 |  |  | 571 |  |

[0001045810-15-000131:8k_2_02:62]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | July 26, |  | January 25, |
|  |  |  | 2015 |  | 2015 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,505 |  |  | $ | 4,623 |  |
|  | Accounts receivable, net |  | 514 |  |  | 474 |  |
|  | Inventories |  | 441 |  |  | 483 |  |
|  | Prepaid expenses and other current assets |  | 148 |  |  | 133 |  |
|  | Total current assets |  | 5,608 |  |  | 5,713 |  |
| Property and equipment, net |  | 497 |  |  | 557 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 190 |  |  | 222 |  |
| Other assets |  | 66 |  |  | 91 |  |
|  | Total assets |  | $ | 6,979 |  |  | $ | 7,201 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 277 |  |  | $ | 293 |  |
|  | Accrued and other current liabilities |  | 659 |  |  | 603 |  |
|  | Total current liabilities |  | 936 |  |  | 896 |  |
| Long-term debt |  | 1,399 |  |  | 1,384 |  |
| Other long-term liabilities |  | 447 |  |  | 489 |  |
| Capital lease obligations, long-term |  | 12 |  |  | 14 |  |
| Shareholders' equity |  | 4,185 |  |  | 4,418 |  |
|  | Total liabilities and shareholders' equity |  | $ | 6,979 |  |  | $ | 7,201 |  |

[0001045810-15-000131:8k_2_02:63]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | April 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP gross profit |  | $ | 634 |  |  | $ | 653 |  |  | $ | 619 |  |  | $ | 1,286 |  |  | $ | 1,223 |  |
| GAAP gross margin |  | 55.0 | % |  | 56.7 | % |  | 56.1 | % |  | 55.8 | % |  | 55.5 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 3 |  |  | 2 |  |  | 3 |  |  | 6 |  |  | 6 |  |
| Product warranty charge (B) |  | 15 |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 652 |  |  | $ | 655 |  |  | $ | 622 |  |  | $ | 1,307 |  |  | $ | 1,229 |  |
| Non-GAAP gross margin |  | 56.6 | % |  | 56.9 | % |  | 56.4 | % |  | 56.7 | % |  | 55.7 | % |
| GAAP operating expenses |  | $ | 558 |  |  | $ | 477 |  |  | $ | 456 |  |  | $ | 1,036 |  |  | $ | 909 |  |
| Stock-based compensation expense included in operating expense (A) |  | (44 | ) |  | (43 | ) |  | (35 | ) |  | (87 | ) |  | (68 | ) |
| Acquisition-related costs (C) |  | (4 | ) |  | (9 | ) |  | (9 | ) |  | (13 | ) |  | (19 | ) |
| Restructuring and other charges |  | (89 | ) |  | — |  |  | — |  |  | (89 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 421 |  |  | $ | 425 |  |  | $ | 412 |  |  | $ | 847 |  |  | $ | 822 |  |
| GAAP other income (expense), net | $ | (4 | ) |  | $ | (4 | ) |  | $ | (8 | ) |  | $ | (6 | ) |  | $ | 4 |  |
| Gains and losses from non-affiliated investments |  | — |  |  | — |  |  | 3 |  |  | — |  |  | (14 | ) |
| Interest expense related to amortization of debt discount |  | 7 |  |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Non-GAAP other income, net | $ | 3 |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | 8 |  |  | $ | 4 |  |
| GAAP net income |  | $ | 26 |  |  | $ | 134 |  |  | $ | 128 |  |  | $ | 160 |  |  | $ | 265 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 162 |  |  | 63 |  |  | 57 |  |  | 225 |  |  | 91 |  |
| Income tax impact of non-GAAP adjustments |  | 2 |  |  | (10 | ) |  | (12 | ) |  | (8 | ) |  | (17 | ) |
| Non-GAAP net income |  | $ | 190 |  |  | $ | 187 |  |  | $ | 173 |  |  | $ | 377 |  |  | $ | 339 |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.05 |  |  | $ | 0.24 |  |  | $ | 0.22 |  |  | $ | 0.28 |  |  | $ | 0.46 |  |
| Non-GAAP |  | $ | 0.34 |  |  | $ | 0.33 |  |  | $ | 0.30 |  |  | $ | 0.68 |  |  | $ | 0.59 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 556 |  |  | 568 |  |  | 571 |  |  | 563 |  |  | 571 |  |
| Anti-dilution impact from note hedge (D) |  | (4 | ) |  | (6 | ) |  | — |  |  | (5 | ) |  | — |  |
| Non-GAAP |  | 552 |  |  | 562 |  |  | 571 |  |  | 558 |  |  | 571 |  |

[0001045810-15-000131:8k_2_02:64]
| Metrics: |  |  |  |  |  |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 163 |  |  | $ | 246 |  |  | $ | 96 |  |  | $ | 409 |  |  | $ | 247 |  |
| Purchase of property and equipment and intangible assets |  | (24 | ) |  | (30 | ) |  | (22 | ) |  | (54 | ) |  | (51 | ) |
| Free cash flow |  | $ | 139 |  |  | $ | 216 |  |  | $ | 74 |  |  | $ | 355 |  |  | $ | 196 |  |

[0001045810-15-000131:8k_2_02:65]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | April 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of revenue |  | $ | 3 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 6 |  |  | $ | 6 |  |
| Research and development |  | $ | 27 |  |  | $ | 27 |  |  | $ | 21 |  |  | $ | 54 |  |  | $ | 42 |  |
| Sales, general and administrative |  | $ | 17 |  |  | $ | 16 |  |  | $ | 14 |  |  | $ | 33 |  |  | $ | 26 |  |
| (B) Represents warranty charge associated with product recall. |
| (C) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (D) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-15-000131:8k_2_02:66]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2016 Outlook |
| GAAP gross margin |  | 56.2 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 56.5 | % |
|  |  |  | Q3 FY2016 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 484 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (49 | ) |
| Non-GAAP operating expenses |  | $ | 435 |  |
