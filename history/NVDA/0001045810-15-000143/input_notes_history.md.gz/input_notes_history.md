# NVDA note change history — 0001045810-15-000097 → 0001045810-15-000143


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2015-08-19):
[0001045810-15-000143:note_history:1]
Operating Lease Financing Arrangement

- added (2015-08-19):
[0001045810-15-000143:note_history:2]
In the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement.  As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99  year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

- added (2015-08-19):
[0001045810-15-000143:note_history:3]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

- added (2015-08-19):
[0001045810-15-000143:note_history:4]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by any of our subsidiaries.

- added (2015-08-19):
[0001045810-15-000143:note_history:5]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

- added (2015-08-19):
[0001045810-15-000143:note_history:6]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

- changed (2015-08-19):
[0001045810-15-000143:note_history:7]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.  On April 15, 2015, we filed an opposition to Plaintiffs’ petition and the petition was denied on May 26, 2015.  The case is now over.
  (was, 2015-05-20, similarity 0.9731):
[0001045810-15-000097:note_history:7]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.  On April 15, 2015, we filed an opposition to Plaintiffs’ petition.

- added (2015-08-19):
[0001045810-15-000143:note_history:8]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the seven patents at issue.  In June 2015, NVIDIA moved to terminate all asserted claims on four patents, which motions have not yet been acted upon.  Certain asserted claims of the three remaining patents pending before the ITC were tried at a hearing on June 22-26, 2015. The post-hearing briefing was concluded on July 24, 2015, and the parties expect a decision on October 9, 2015.

- changed (2015-08-19):
[0001045810-15-000143:note_history:9]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, and then on April 10, 2015, Samsung filed amended, longer complaints, but which continued to assert the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction preventing it from infringing certain patents and was dismissed from the case with prejudice.  A Markman hearing was held on June 29, 2015 and trial is set to begin in January 2016.  Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015.
  (was, 2015-05-20, similarity 0.7468):
[0001045810-15-000097:note_history:9]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, and then on April 10, 2015, Samsung filed amended, longer complaints, but which continued to assert the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement. On May 19, 2015, the court severed NVIDIA's counter-claims from the main action and set a trial date on those counter-claims for June 2016. On the same day, NVIDIA voluntarily dismissed its counter-claims from the case. Trial on Samsung’s claims is currently set to begin on January 11, 2016.

- changed (2015-08-19):
[0001045810-15-000143:note_history:10]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents.  Samsung seeks to permanently bar several products purportedly relying on these allegedly infringed patents in the United States.  On December 23, 2014, the ITC initiated an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case.  A hearing on Samsung’s three remaining patents began on August 18, 2015.
  (was, 2015-05-20, similarity 0.8455):
[0001045810-15-000097:note_history:10]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents.  Samsung seeks to permanently bar several products purportedly relying on these allegedly infringed patents in the United States.  On December 23, 2014, the ITC initiated an investigation of Samsung’s claims. A hearing on Samsung’s patents is scheduled to begin on August 18, 2015.

- changed (2015-08-19):
[0001045810-15-000143:note_history:11]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed ten requests for inter partes review on eight of Samsung’s asserted patents.  Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA.  The United States Patent and Trademark Office has not yet decided whether to institute review as to any of the patents.
  (was, 2015-05-20, similarity 0.9664):
[0001045810-15-000097:note_history:11]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed three requests for inter partes review on three of Samsung’s asserted patents.  Samsung has filed three requests for inter partes review on three patents asserted by NVIDIA.  The United States Patent and Trademark Office has not yet decided whether to institute review as to any of the patents.

- added (2015-08-19):
[0001045810-15-000143:note_history:12]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 26, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2015-08-19):
[0001045810-15-000097:note_history:13]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones,  tablets and smart TVs containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the patents at issue.  The hearing on NVIDIA’s patents in the ITC action is currently scheduled to begin on June 22, 2015.

- removed (2015-08-19):
[0001045810-15-000097:note_history:14]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 26, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-19):
[0001045810-15-000143:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 was a 52-week year. The second quarters of fiscal years 2016 and 2015 were both 13-week quarters.
  (was, 2015-05-20, similarity 0.7351):
[0001045810-15-000097:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 is a 52-week year. The first quarters of fiscal years 2016 and 2015 are both 13-week quarters.

- added (2015-08-19):
[0001045810-15-000143:note_history:16]
Restructuring and Other Charges

- added (2015-08-19):
[0001045810-15-000143:note_history:17]
Our restructuring and other charges primarily comprise of employee severance and related costs, write-down of assets, and other exit costs. The severance and related costs could include one-time termination benefits as well as certain statutory termination benefits or employee terminations under ongoing benefit arrangements. One-time termination benefits are recognized as a liability at estimated fair value when the approved plan of termination has been communicated to employees, unless employees must provide future service, in which case the benefits are recognized ratably over the future service period. Ongoing termination benefits arrangements are recognized as a liability at estimated fair value when the amount of such benefits becomes estimable and payment is probable. Any contract termination costs are recognized at estimated fair value when we terminate the contract in accordance with the contract terms. Other associated costs are recognized in the period the liability is incurred.

- changed (2015-08-19):
[0001045810-15-000143:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2015-05-20, similarity 0.9799):
[0001045810-15-000097:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- added (2015-08-19):
[0001045810-15-000143:note_history:19]
In July 2015, the Financial Accounting Standards Board, or FASB, issued an accounting standard update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements.

- changed (2015-08-19):
[0001045810-15-000143:note_history:20]
In April 2015, the FASB issued a new accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.
  (was, 2015-05-20, similarity 0.937):
[0001045810-15-000097:note_history:20]
In April 2015, the Financial Accounting Standards Board, or FASB, issued a new accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this standard update is not expected to have a material impact on our consolidated financial statements.

- changed (2015-08-19):
[0001045810-15-000143:note_history:21]
In May 2014, the FASB issued a new accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.
  (was, 2015-05-20, similarity 0.8301):
[0001045810-15-000097:note_history:21]
In May 2014, the FASB issued a new accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On April 29, 2015, the FASB issued a proposed accounting standards update that would defer the effective date of this new revenue recognition standard by one year, but also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). Comments on the proposal are due by May 29, 2015. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-19):
[0001045810-15-000143:note_history:22]
As of July 26, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the carrying value of the Notes would be classified as a current liability and the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.
  (was, 2015-05-20, similarity 0.9085):
[0001045810-15-000097:note_history:22]
As of April 26, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

- added (2015-08-19):
[0001045810-15-000143:note_history:23]
|  |  | July 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (101 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,399 |  |  | $ | 1,384 |  |

- changed (2015-08-19):
[0001045810-15-000143:note_history:24]
(1) As of July 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.4 years.
  (was, 2015-05-20, similarity 0.9659):
[0001045810-15-000097:note_history:24]
(1) As of April 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.6 years.

- added (2015-08-19):
[0001045810-15-000143:note_history:25]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- removed (2015-08-19):
[0001045810-15-000097:note_history:26]
|  |  | April 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (109 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,391 |  |  | $ | 1,384 |  |

- removed (2015-08-19):
[0001045810-15-000097:note_history:27]
|  |  | Three Months Ended |
|  |  | April 26, |  | April 27, |
|  |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-08-19):
[0001045810-15-000143:note_history:28]
|  |  | July 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (101 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,399 |  |  | $ | 1,384 |  |

- changed (2015-08-19):
[0001045810-15-000143:note_history:29]
(1) As of July 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.4 years.
  (was, 2015-05-20, similarity 0.9659):
[0001045810-15-000097:note_history:29]
(1) As of April 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.6 years.

- added (2015-08-19):
[0001045810-15-000143:note_history:30]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- removed (2015-08-19):
[0001045810-15-000097:note_history:31]
|  |  | April 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (109 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,391 |  |  | $ | 1,384 |  |

- removed (2015-08-19):
[0001045810-15-000097:note_history:32]
|  |  | Three Months Ended |
|  |  | April 26, |  | April 27, |
|  |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-08-19):
[0001045810-15-000097:note_history:33]
Subsequent Events

- removed (2015-08-19):
[0001045810-15-000097:note_history:34]
On May 5, 2015, we announced our intent to wind-down our Icera modem operations and that we are open to a sale of the technology or operations. We estimate restructuring charges primarily during fiscal year 2016, in the range of $100 million to $125 million, consisting of severance and other employee termination benefits, tax expense items, and other costs associated with the wind-down, if we are unable to sell the Icera modem operations.

- removed (2015-08-19):
[0001045810-15-000097:note_history:35]
On May 11, 2015, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we made an upfront payment of $400 million to purchase shares of our common stock and received an initial delivery of 14 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
