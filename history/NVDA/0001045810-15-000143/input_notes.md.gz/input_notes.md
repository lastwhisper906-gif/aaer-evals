# NVDA notes — 0001045810-15-000143


## nvda:BalanceSheetComponentsTextBlock

[0001045810-15-000143:notes:1]
[same as prior period, unchanged from 0001045810-15-000097:notes:2]

[0001045810-15-000143:notes:2]
[same as prior period, unchanged from 0001045810-15-000097:notes:3]

[0001045810-15-000143:notes:3]
|  | July 26, |  | January 25, |
|  | 2015 |  | 2015 |
| Inventories: | (In millions) |
| Raw materials | $ | 139 |  |  | $ | 157 |  |
| Work in-process | 107 |  |  | 92 |  |
| Finished goods | 195 |  |  | 234 |  |
| Total inventories | $ | 441 |  |  | $ | 483 |  |

[0001045810-15-000143:notes:4]
At July 26, 2015, we had outstanding inventory purchase obligations totaling $487 million.

[0001045810-15-000143:notes:5]
|  | July 26, |  | January 25, |
|  | 2015 |  | 2015 |
| Accrued and Other Current Liabilities: | (In millions) |
| Unearned revenue (1) | $ | 321 |  |  | $ | 296 |  |
| Customer related liabilities (2) | 130 |  |  | 143 |  |
| Accrued payroll and related expenses | 111 |  |  | 112 |  |
| Warranty accrual (3) | 28 |  |  | 8 |  |
| Professional service fees | 29 |  |  | 17 |  |
| Accrued restructuring and other charges (4) | 18 |  |  | — |  |
| Coupon interest on Notes | 3 |  |  | 3 |  |
| Taxes payable | 3 |  |  | 3 |  |
| Facilities related liabilities | 1 |  |  | 8 |  |
| Other | 15 |  |  | 13 |  |
| Total accrued and other current liabilities | $ | 659 |  |  | $ | 603 |  |

[0001045810-15-000143:notes:6]
| (1) | Unearned revenue primarily includes deferred revenue. |

[0001045810-15-000143:notes:7]
| (2) | Customer related liabilities primarily includes accrued customer programs. Please refer to Note 1 of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, for discussion regarding the nature of accrued customer programs and their accounting treatment related to our revenue recognition policies and estimates. |

[0001045810-15-000143:notes:8]
[same as prior period, unchanged from 0001045810-15-000097:notes:9]

[0001045810-15-000143:notes:9]
| (4) | Please refer to Note 14 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the restructuring and other charges accrual. |

[0001045810-15-000143:notes:10]
|  | July 26, |  | January 25, |
|  | 2015 |  | 2015 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 292 |  |  | $ | 232 |  |
| Income taxes payable | 124 |  |  | 121 |  |
| Asset retirement obligation | 7 |  |  | 7 |  |
| Deferred revenue (1) | 1 |  |  | 108 |  |
| Other | 23 |  |  | 21 |  |
| Total other long-term liabilities | $ | 447 |  |  | $ | 489 |  |

[0001045810-15-000143:notes:11]
(1)  Consists primarily of consideration received in advance of our performance obligations under the patent cross licensing agreement that we entered into with Intel Corporation in January 2011. The decrease in deferred revenue, long-term, is a result of revenue recognized during the six months ended July 26, 2015.


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-15-000143:notes:12]
|  | July 26, |  | January 25, |
|  | 2015 |  | 2015 |
|  | (In millions) |
| Aggregated unearned stock-based compensation expense | $288 |  | $291 |
| Estimated weighted average amortization period | (In years) |
| Stock options | 1.5 |  | 1.8 |
| RSUs, PSUs and market-based PSUs | 2.6 |  | 2.8 |
| ESPP | 0.7 |  | 0.5 |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-15-000143:notes:13]
|  | July 26, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,972 |  |  | $ | 1 |  |  | $ | (3 | ) |  | $ | 1,970 |  |
| Debt securities of U.S. government agencies | 893 |  |  | 1 |  |  | (1 | ) |  | 893 |  |
| Asset-backed securities | 489 |  |  | — |  |  | (1 | ) |  | 488 |  |
| Debt securities issued by U.S. Treasury | 385 |  |  | — |  |  | — |  |  | 385 |  |
| Mortgage-backed securities issued by U.S. government-sponsored enterprises | 261 |  |  | 4 |  |  | — |  |  | 265 |  |
| Foreign government bonds | 75 |  |  | — |  |  | — |  |  | 75 |  |
| Money market funds | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Total | $ | 4,105 |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | 4,106 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 36 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 4,070 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,106 |  |

[0001045810-15-000143:notes:14]
|  | January 25, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,185 |  |  | $ | 2 |  |  | $ | (1 | ) |  | $ | 2,186 |  |
| Debt securities of U.S. government agencies | 750 |  |  | 1 |  |  | (1 | ) |  | 750 |  |
| Asset-backed securities | 453 |  |  | — |  |  | — |  |  | 453 |  |
| Debt securities issued by U.S. Treasury | 534 |  |  | 3 |  |  | — |  |  | 537 |  |
| Mortgage-backed securities issued by U.S. government-sponsored enterprises | 274 |  |  | 5 |  |  | (1 | ) |  | 278 |  |
| Foreign government bonds | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Money market funds | 132 |  |  | — |  |  | — |  |  | 132 |  |
| Total | $ | 4,413 |  |  | $ | 11 |  |  | $ | (3 | ) |  | $ | 4,421 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 295 |  |
| Marketable securities |  |  |  |  |  |  | 4,126 |  |
| Total |  |  |  |  |  |  | $ | 4,421 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-15-000143:notes:15]
Commitments and Contingencies

[0001045810-15-000143:notes:16]
Operating Lease Financing Arrangement

[0001045810-15-000143:notes:17]
In the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement.  As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99  year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-15-000143:notes:18]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-15-000143:notes:19]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by any of our subsidiaries.

[0001045810-15-000143:notes:20]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-15-000143:notes:21]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-15-000143:notes:22]
Securities Cases

[0001045810-15-000143:notes:23]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, or the Securities Exchange Act.

[0001045810-15-000143:notes:24]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.  On April 15, 2015, we filed an opposition to Plaintiffs’ petition and the petition was denied on May 26, 2015.  The case is now over.

[0001045810-15-000143:notes:25]
Patent Infringement Cases

[0001045810-15-000143:notes:26]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the seven patents at issue.  In June 2015, NVIDIA moved to terminate all asserted claims on four patents, which motions have not yet been acted upon.  Certain asserted claims of the three remaining patents pending before the ITC were tried at a hearing on June 22-26, 2015. The post-hearing briefing was concluded on July 24, 2015, and the parties expect a decision on October 9, 2015.

[0001045810-15-000143:notes:27]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action and NVIDIA did not oppose the motion. The court granted the motion to stay on October 23, 2014.

[0001045810-15-000143:notes:28]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, and then on April 10, 2015, Samsung filed amended, longer complaints, but which continued to assert the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction preventing it from infringing certain patents and was dismissed from the case with prejudice.  A Markman hearing was held on June 29, 2015 and trial is set to begin in January 2016.  Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015.

[0001045810-15-000143:notes:29]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents.  Samsung seeks to permanently bar several products purportedly relying on these allegedly infringed patents in the United States.  On December 23, 2014, the ITC initiated an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case.  A hearing on Samsung’s three remaining patents began on August 18, 2015.

[0001045810-15-000143:notes:30]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed ten requests for inter partes review on eight of Samsung’s asserted patents.  Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA.  The United States Patent and Trademark Office has not yet decided whether to institute review as to any of the patents.

[0001045810-15-000143:notes:31]
Accounting for Loss Contingencies

[0001045810-15-000143:notes:32]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 26, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-15-000143:notes:33]
[same as prior period, unchanged from 0001045810-15-000097:notes:27]

[0001045810-15-000143:notes:34]
[same as prior period, unchanged from 0001045810-15-000097:notes:28]


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001045810-15-000143:notes:35]
Restructuring and Other Charges

[0001045810-15-000143:notes:36]
Our restructuring and other charges primarily comprise of employee severance and related costs, write-down of assets, and other exit costs. The severance and related costs could include one-time termination benefits as well as certain statutory termination benefits or employee terminations under ongoing benefit arrangements. One-time termination benefits are recognized as a liability at estimated fair value when the approved plan of termination has been communicated to employees, unless employees must provide future service, in which case the benefits are recognized ratably over the future service period. Ongoing termination benefits arrangements are recognized as a liability at estimated fair value when the amount of such benefits becomes estimable and payment is probable. Any contract termination costs are recognized at estimated fair value when we terminate the contract in accordance with the contract terms. Other associated costs are recognized in the period the liability is incurred.


## us-gaap:DebtDisclosureTextBlock

[0001045810-15-000143:notes:37]
Long-Term Debt

[0001045810-15-000143:notes:38]
1.00 % Convertible Senior Notes Due 2018

[0001045810-15-000143:notes:39]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-15-000143:notes:40]
As of July 26, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the carrying value of the Notes would be classified as a current liability and the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

[0001045810-15-000143:notes:41]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-15-000143:notes:42]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-15-000143:notes:43]
|  |  | July 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (101 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,399 |  |  | $ | 1,384 |  |

[0001045810-15-000143:notes:44]
(1) As of July 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.4 years.

[0001045810-15-000143:notes:45]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-15-000143:notes:46]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-15-000143:notes:47]
[same as prior period, unchanged from 0001045810-15-000097:notes:39]

[0001045810-15-000143:notes:48]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-15-000143:notes:49]
[same as prior period, unchanged from 0001045810-15-000097:notes:41]

[0001045810-15-000143:notes:50]
[same as prior period, unchanged from 0001045810-15-000097:notes:42]

[0001045810-15-000143:notes:51]
[same as prior period, unchanged from 0001045810-15-000097:notes:43]

[0001045810-15-000143:notes:52]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, 2015 |  | July 27, 2014 |  | July 26, 2015 |  | July 27, 2014 |
|  | (In millions) |
| Cost of revenue | $ | 3 |  |  | $ | 3 |  |  | $ | 6 |  |  | $ | 6 |  |
| Research and development | 27 |  |  | 21 |  |  | 54 |  |  | 42 |  |
| Sales, general and administrative | 17 |  |  | 14 |  |  | 33 |  |  | 26 |  |
| Total | $ | 47 |  |  | $ | 38 |  |  | $ | 93 |  |  | $ | 74 |  |

[0001045810-15-000143:notes:53]
[same as prior period, unchanged from 0001045810-15-000097:notes:45]

[0001045810-15-000143:notes:54]
[same as prior period, unchanged from 0001045810-15-000097:notes:46]

[0001045810-15-000143:notes:55]
|  | Awards Outstanding |  | Weighted Average Exercise Price |
| Stock Options | (In millions) |  | (Per share) |
| Balances, January 25, 2015 | 21 |  |  | $14.61 |
| Granted | — |  |  | — |  |
| Exercised | (4 | ) |  | $14.16 |
| Cancelled | — |  |  | — |  |
| Balances, July 26, 2015 | 17 |  |  | $14.61 |

[0001045810-15-000143:notes:56]
|  | Awards Outstanding |  | Weighted Average Grant-Date Fair Value |
| RSUs, PSUs and Market-based PSUs | (In millions) |  | (Per share) |
| Balances, January 25, 2015 | 23 |  |  | $15.94 |
| Granted (1) (2) | 4 |  |  | $21.65 |
| Vested | (4 | ) |  | $15.04 |
| Cancelled | (1 | ) |  | $15.99 |
| Balances, July 26, 2015 | 22 |  |  | $17.12 |

[0001045810-15-000143:notes:57]
[same as prior period, unchanged from 0001045810-15-000097:notes:49]

[0001045810-15-000143:notes:58]
[same as prior period, unchanged from 0001045810-15-000097:notes:50]

[0001045810-15-000143:notes:59]
Of the estimated total grant-date fair value, the stock-based compensation expense related to the equity awards that are not expected to vest was $2 million and $8 million for the three and six months ended July 26, 2015, respectively, and $2 million and $12 million for three and six months ended July 27, 2014, respectively.

[0001045810-15-000143:notes:60]
The following summarizes aggregated unearned stock-based compensation expense and estimated weighted average amortization period as of July 26, 2015 and January 25, 2015:


## us-gaap:EarningsPerShareTextBlock

[0001045810-15-000143:notes:61]
[same as prior period, unchanged from 0001045810-15-000097:notes:53]

[0001045810-15-000143:notes:62]
[same as prior period, unchanged from 0001045810-15-000097:notes:54]

[0001045810-15-000143:notes:63]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 26 |  |  | $ | 128 |  |  | $ | 160 |  |  | $ | 265 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 541 |  |  | 558 |  |  | 545 |  |  | 559 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Equity awards outstanding | 11 |  |  | 13 |  |  | 13 |  |  | 12 |  |
| Assumed conversion of 1% Convertible Senior Notes Due 2018 | 4 |  |  | — |  |  | 5 |  |  | — |  |
| Denominator for diluted net income per share, weighted average shares | 556 |  |  | 571 |  |  | 563 |  |  | 571 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic net income per share | $ | 0.05 |  |  | $ | 0.23 |  |  | $ | 0.29 |  |  | $ | 0.47 |  |
| Diluted net income per share | $ | 0.05 |  |  | $ | 0.22 |  |  | $ | 0.28 |  |  | $ | 0.46 |  |
| Potentially dilutive equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 1 |  |  | 4 |  |  | 4 |  |  | 8 |  |

[0001045810-15-000143:notes:64]
The 1.00% Convertible Senior Notes, or the Notes, are included in the calculation of diluted net income per share if their inclusion is dilutive. The Notes will generally have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the conversion price of $20.16 per share. For the three and six months ended July 26, 2015, our average stock price for the reporting periods exceeded the conversion price, causing the Notes to have a dilutive impact for these periods.

[0001045810-15-000143:notes:65]
[same as prior period, unchanged from 0001045810-15-000097:notes:57]

[0001045810-15-000143:notes:66]
The denominator for diluted net income per share will not include any effect from the warrants, which we entered into concurrently with the issuance of the Notes, unless our average stock price for the reporting period exceeds the strike price of $27.13 per share.

[0001045810-15-000143:notes:67]
[same as prior period, unchanged from 0001045810-15-000097:notes:59]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001045810-15-000143:notes:68]
|  |  |  | Fair Value Measurement as of July 26, 2015 Using |
|  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |
|  | July 26, 2015 |  | (Level 1) |  | (Level 2) |
|  | (In millions) |
| Corporate debt securities (1) | $ | 1,970 |  |  | $ | — |  |  | $ | 1,970 |  |
| Debt securities of U.S. government agencies (2) | 893 |  |  | — |  |  | 893 |  |
| Asset-backed securities (2) | 488 |  |  | — |  |  | 488 |  |
| Debt securities issued by U.S. Treasury (2) | 385 |  |  | — |  |  | 385 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (2) | 265 |  |  | — |  |  | 265 |  |
| Foreign government bonds (2) | 75 |  |  | — |  |  | 75 |  |
| Money market funds (3) | 30 |  |  | 30 |  |  | — |  |
| Total cash equivalents and marketable securities | $ | 4,106 |  |  | $ | 30 |  |  | $ | 4,076 |  |

[0001045810-15-000143:notes:69]
| (1) | Included $6 million in cash equivalents and $1,964 million in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000143:notes:70]
| (2) | Included in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000143:notes:71]
| (3) | Included in cash equivalents on the Condensed Consolidated Balance Sheet |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-15-000143:notes:72]
[same as prior period, unchanged from 0001045810-15-000097:notes:65]

[0001045810-15-000143:notes:73]
[same as prior period, unchanged from 0001045810-15-000097:notes:66]

[0001045810-15-000143:notes:74]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.  There were no significant transfers between Levels 1 and 2 assets for the three and six months ended July 26, 2015.

[0001045810-15-000143:notes:75]
[same as prior period, unchanged from 0001045810-15-000097:notes:68]

[0001045810-15-000143:notes:76]
| (3) | Included in cash equivalents on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000143:notes:77]
[same as prior period, unchanged from 0001045810-15-000097:notes:70]

[0001045810-15-000143:notes:78]
We issued $1.50 billion of Notes in December 2013. The Notes are carried at their original issuance value, net of unamortized debt discount, and are not marked to market each period. The estimated fair value of the Notes was $1.72 billion and $1.68 billion as of July 26, 2015 and January 25, 2015, respectively. The estimated fair value of the Notes was determined on the basis of market prices observable for similar instruments and is considered Level 2 in the fair value hierarchy. Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the Notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-15-000143:notes:79]
[same as prior period, unchanged from 0001045810-15-000097:notes:72]

[0001045810-15-000143:notes:80]
We recognized income tax expense of $46 million and $84 million for the three and six months ended July 26, 2015, respectively, and $27 million and $53 million for the three and six months ended July 27, 2014, respectively. Income tax expense as a percentage of income before tax, or our effective tax rate, was 64.0% and 34.3% for the three and six months ended July 26, 2015, respectively, and 17.2% and 16.8% for the three and six months ended July 27, 2014, respectively.

[0001045810-15-000143:notes:81]
Our income tax expense for the three months ended July 26, 2015 included a charge of $27 million for the write-down of a deferred tax asset related to our Icera modem operations, partially offset by a $13 million tax benefit related to the restructuring and other charges.

[0001045810-15-000143:notes:82]
The increase in our effective tax rate in the three months ended July 26, 2015 as compared to the same period in the prior fiscal year was primarily due to the tax related charges in connection with the wind-down of the Icera modem operations, an increase in the amount of earnings subject to U.S. tax, and increase of permanent tax differences related to stock-based compensation in the six months ended July 26, 2015.

[0001045810-15-000143:notes:83]
Our effective tax rate on income before tax for the six months ended July 26, 2015 of 34.3% was lower than the U. S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate. Further, our actual effective tax rate for the six months ended July 26, 2015 of 34.3% differs from our annual projected effective tax rate for this period of 22.2% due to certain discrete items, including the tax related charges attributable to the wind-down of the Icera modem operations, partially offset by tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-15-000143:notes:84]
Our effective tax rate on income before tax for the six months ended July 27, 2014 of 16.8% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. statutory tax.

[0001045810-15-000143:notes:85]
For the six months ended July 26, 2015, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 25, 2015, other than the recognition of tax benefits upon the expiration of statute of limitation in certain non-U.S. jurisdictions in the six months ended July 26, 2015.

[0001045810-15-000143:notes:86]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where it is believed not more-likely-than-not that the position will be sustained upon examination, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 26, 2015, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-15-000143:notes:87]
[same as prior period, unchanged from 0001045810-15-000097:notes:79]

[0001045810-15-000143:notes:88]
[same as prior period, unchanged from 0001045810-15-000097:notes:80]

[0001045810-15-000143:notes:89]
|  | July 26, 2015 |  | January 25, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | Accumulated Amortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (143 | ) |  | $ | 50 |  |  | $ | 189 |  |  | $ | (134 | ) |  | $ | 55 |  |
| Patents and licensed technology | 451 |  |  | (311 | ) |  | 140 |  |  | 449 |  |  | (282 | ) |  | 167 |  |
| Total intangible assets | $ | 644 |  |  | $ | (454 | ) |  | $ | 190 |  |  | $ | 638 |  |  | $ | (416 | ) |  | $ | 222 |  |

[0001045810-15-000143:notes:90]
Amortization expense associated with intangible assets was $19 million and $38 million for the three and six months ended July 26, 2015, respectively, and $19 million and $38 million for the three and six months ended July 27, 2014, respectively. Future amortization expense related to the net carrying amount of intangible assets at July 26, 2015 is estimated to be $35 million for the remainder of fiscal year 2016, $65 million in fiscal year 2017, $50 million in fiscal year 2018, $22 million in fiscal year 2019, $13 million in fiscal year 2020 and a total of $5 million in fiscal year 2021 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-15-000143:notes:91]
|  | July 26, 2015 |  | January 25, 2015 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 1,174 |  |  | $ | 1,174 |  |  | $ | 1,570 |  |  | $ | 1,571 |  |
| Due in 1 - 5 years | 2,812 |  |  | 2,811 |  |  | 2,720 |  |  | 2,726 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 119 |  |  | 121 |  |  | 123 |  |  | 124 |  |
| Total | $ | 4,105 |  |  | $ | 4,106 |  |  | $ | 4,413 |  |  | $ | 4,421 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-15-000143:notes:92]
[same as prior period, unchanged from 0001045810-15-000097:notes:84]

[0001045810-15-000143:notes:93]
[same as prior period, unchanged from 0001045810-15-000097:notes:85]

[0001045810-15-000143:notes:94]
We performed an impairment review of our investment portfolio as of July 26, 2015. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio as of July 26, 2015.

[0001045810-15-000143:notes:95]
The following is a summary of cash equivalents and marketable securities at July 26, 2015 and January 25, 2015:

[0001045810-15-000143:notes:96]
The following table provides the breakdown of the investments with unrealized losses at July 26, 2015:

[0001045810-15-000143:notes:97]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 1,098 |  |  | $ | (3 | ) |  | $ | 40 |  |  | $ | — |  |  | $ | 1,138 |  |  | $ | (3 | ) |
| Debt securities of U.S. government agencies | 504 |  |  | (1 | ) |  | — |  |  | — |  |  | 504 |  |  | (1 | ) |
| Asset-backed securities | 313 |  |  | (1 | ) |  | 23 |  |  | — |  |  | 336 |  |  | (1 | ) |
| Total | $ | 1,915 |  |  | $ | (5 | ) |  | $ | 63 |  |  | $ | — |  |  | $ | 1,978 |  |  | $ | (5 | ) |

[0001045810-15-000143:notes:98]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at July 26, 2015 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-15-000143:notes:99]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale at July 26, 2015 and January 25, 2015 and are shown below by contractual maturity.

[0001045810-15-000143:notes:100]
Net realized gains were not significant for the three months ended July 26, 2015 and for the three and six months ended July 27, 2014. Net realized gains were $3 million for the six months ended July 26, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001045810-15-000143:notes:101]
[same as prior period, unchanged from 0001045810-15-000097:notes:93]

[0001045810-15-000143:notes:102]
[same as prior period, unchanged from 0001045810-15-000097:notes:94]

[0001045810-15-000143:notes:103]
[same as prior period, unchanged from 0001045810-15-000097:notes:95]

[0001045810-15-000143:notes:104]
[same as prior period, unchanged from 0001045810-15-000097:notes:96]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-15-000143:notes:105]
[same as prior period, unchanged from 0001045810-15-000097:notes:97]

[0001045810-15-000143:notes:106]
[same as prior period, unchanged from 0001045810-15-000097:notes:98]

[0001045810-15-000143:notes:107]
[same as prior period, unchanged from 0001045810-15-000097:notes:99]

[0001045810-15-000143:notes:108]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-15-000143:notes:109]
On July 31, 2015, we announced a voluntary recall and replacement of our SHIELD 8-inch tablets that were sold between July 2014 and July 2015. We have determined that the battery in these tablets can overheat, posing a fire hazard. The recall does not affect any other NVIDIA products. During the six months ended July 26, 2015, we recorded a $21 million charge against cost of revenue, including $15 million during our fiscal quarter ended July 26, 2015, to cover anticipated customer warranty, repair, return, replacement and other associated costs.

[0001045810-15-000143:notes:110]
The estimated product warranty liabilities for the three and six months ended July 26, 2015 and July 27, 2014 were as follows:

[0001045810-15-000143:notes:111]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In millions) |
| Balance at beginning of period | $ | 13 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 8 |  |
| Additions | 16 |  |  | 1 |  |  | 22 |  |  | 3 |  |
| Deductions | (1 | ) |  | (1 | ) |  | (2 | ) |  | (3 | ) |
| Balance at end of period | $ | 28 |  |  | $ | 8 |  |  | $ | 28 |  |  | $ | 8 |  |

[0001045810-15-000143:notes:112]
In connection with certain agreements that we have executed in the past, we have at times provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have also on occasion included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability.  As such, we have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-15-000143:notes:113]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, 2015 |  | July 27, 2014 |  | July 26, 2015 |  | July 27, 2014 |
|  | (In millions) |
| Reconciling items included in "All Other" category : |  |  |  |  |  |  |
| Unallocated revenue | $ | 66 |  |  | $ | 66 |  |  | $ | 132 |  |  | $ | 132 |  |
| Unallocated cost of revenue and operating expenses | (67 | ) |  | (42 | ) |  | (124 | ) |  | (85 | ) |
| Stock-based compensation | (47 | ) |  | (38 | ) |  | (93 | ) |  | (74 | ) |
| Acquisition-related costs | (4 | ) |  | (9 | ) |  | (13 | ) |  | (19 | ) |
| Product warranty charge | (15 | ) |  | — |  |  | (15 | ) |  | — |  |
| Restructuring and other charges | (89 | ) |  | — |  |  | (89 | ) |  | — |  |
| Total | $ | (156 | ) |  | $ | (23 | ) |  | $ | (202 | ) |  | $ | (46 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-15-000143:notes:114]
In May 2015, we announced our intent to wind-down our Icera modem operations and that we were open to a sale of the technology or operations. During the three months ended July 26, 2015, we pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations.

[0001045810-15-000143:notes:115]
The results of any remaining ongoing Icera modem operations are reported in the Tegra Processor reporting segment, however, restructuring and other charges associated with the wind-down of the Icera modem operations are separately reported with other non-recurring charges and benefits that our CODM deems to be enterprise in nature. Please refer to Note 13 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our reporting segments.

[0001045810-15-000143:notes:116]
Our operating expenses for the three months ended July 26, 2015 included $89 million of restructuring and other charges. Please refer to Note 4 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding the income tax charges associated with the wind-down of Icera modem operations.

[0001045810-15-000143:notes:117]
|  | Three Months Ended |
|  | July 26, |
|  | 2015 |
|  | (In millions) |
| Employee severance and related costs | $ | 56 |  |
| Tax subsidy impairment | 17 |  |
| Fixed assets impairment | 11 |  |
| Facilities and related costs | 2 |  |
| Other exit costs | 3 |  |
| Balance at July 26, 2015 | $ | 89 |  |

[0001045810-15-000143:notes:118]
We expect to incur additional restructuring charges to operating expense of $15 million to $25 million for the remainder of fiscal year 2016.  These restructuring activities will impact approximately 5% of our global workforce, and we expect them to be substantially completed by the end of fiscal year 2016.  The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities in our Consolidated Balance Sheets as of July 26, 2015:

[0001045810-15-000143:notes:119]
|  | (In millions) |
| Balance at April 26, 2015 | $ | — |  |
| Restructuring and other charges | 89 |  |
| Cash payments | (39 | ) |
| Non-cash charges | (32 | ) |
| Balance at July 26, 2015 | $ | 18 |  |

[0001045810-15-000143:notes:120]
The remaining balance of $18 million as of July 26, 2015 is expected to be paid during the third and fourth quarters of fiscal year 2016.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-15-000143:notes:121]
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 445 |  |  | $ | 331 |  |  | $ | 832 |  |  | $ | 704 |  |
| Other Asia Pacific | 185 |  |  | 151 |  |  | 373 |  |  | 306 |  |
| China | 181 |  |  | 252 |  |  | 354 |  |  | 475 |  |
| United States | 138 |  |  | 206 |  |  | 318 |  |  | 379 |  |
| Europe | 106 |  |  | 80 |  |  | 225 |  |  | 167 |  |
| Other Americas | 98 |  |  | 83 |  |  | 202 |  |  | 175 |  |
| Total revenue | $ | 1,153 |  |  | $ | 1,103 |  |  | $ | 2,304 |  |  | $ | 2,206 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-15-000143:notes:122]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000143:notes:123]
In July 2015, the Financial Accounting Standards Board, or FASB, issued an accounting standard update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements.

[0001045810-15-000143:notes:124]
In April 2015, the FASB issued a new accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-15-000143:notes:125]
In May 2014, the FASB issued a new accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-15-000143:notes:126]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended July 26, 2015 |  |  |  |  |  |  |  |
| Revenue | $ | 959 |  |  | $ | 128 |  |  | $ | 66 |  |  | $ | 1,153 |  |
| Depreciation and amortization expenses | $ | 27 |  |  | $ | 11 |  |  | $ | 11 |  |  | $ | 49 |  |
| Operating income (loss) | $ | 273 |  |  | $ | (41 | ) |  | $ | (156 | ) |  | $ | 76 |  |
| Three Months Ended July 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 878 |  |  | $ | 159 |  |  | $ | 66 |  |  | $ | 1,103 |  |
| Depreciation and amortization expenses | $ | 29 |  |  | $ | 15 |  |  | $ | 12 |  |  | $ | 56 |  |
| Operating income (loss) | $ | 241 |  |  | $ | (55 | ) |  | $ | (23 | ) |  | $ | 163 |  |
| Six Months Ended July 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,899 |  |  | $ | 273 |  |  | $ | 132 |  |  | $ | 2,304 |  |
| Depreciation and amortization expense | $ | 55 |  |  | $ | 26 |  |  | $ | 22 |  |  | $ | 103 |  |
| Operating income (loss) | $ | 551 |  |  | $ | (99 | ) |  | $ | (202 | ) |  | $ | 250 |  |
| Six Months Ended July 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,776 |  |  | $ | 298 |  |  | $ | 132 |  |  | $ | 2,206 |  |
| Depreciation and amortization expense | $ | 59 |  |  | $ | 29 |  |  | $ | 23 |  |  | $ | 111 |  |
| Operating income (loss) | $ | 476 |  |  | $ | (116 | ) |  | $ | (46 | ) |  | $ | 314 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-15-000143:notes:127]
[same as prior period, unchanged from 0001045810-15-000097:notes:109]

[0001045810-15-000143:notes:128]
[same as prior period, unchanged from 0001045810-15-000097:notes:110]

[0001045810-15-000143:notes:129]
[same as prior period, unchanged from 0001045810-15-000097:notes:111]

[0001045810-15-000143:notes:130]
[same as prior period, unchanged from 0001045810-15-000097:notes:112]

[0001045810-15-000143:notes:131]
[same as prior period, unchanged from 0001045810-15-000097:notes:113]

[0001045810-15-000143:notes:132]
We have a single unifying architecture for our GPU and Tegra Processors. This architecture unification leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reporting segments, our CODM assigns 100% of those expenses to the reporting segment that benefits the most.

[0001045810-15-000143:notes:133]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, product warranty charge, restructuring and other charges, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-15-000143:notes:134]
[same as prior period, unchanged from 0001045810-15-000097:notes:116]

[0001045810-15-000143:notes:135]
[same as prior period, unchanged from 0001045810-15-000097:notes:117]

[0001045810-15-000143:notes:136]
Revenue from significant customers, those representing 10% or more of total revenue, aggregated approximately 23% and 21% of our total revenue from two customers for the three months ended July 26, 2015 and July 27, 2014, respectively. Revenue from significant customers, those representing 10% or more of total revenue, aggregated approximately 21% of our total revenue from two customers and 10% of our total revenue from one customer for the six months ended July 26, 2015 and July 27, 2014, respectively.

[0001045810-15-000143:notes:137]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 22% of our accounts receivable balance from one customer at July 26, 2015 and approximately 30% of our accounts receivable balance from two customers at January 25, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-15-000143:notes:138]
[same as prior period, unchanged from 0001045810-15-000097:notes:121]

[0001045810-15-000143:notes:139]
[same as prior period, unchanged from 0001045810-15-000097:notes:122]

[0001045810-15-000143:notes:140]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 was a 52-week year. The second quarters of fiscal years 2016 and 2015 were both 13-week quarters.

[0001045810-15-000143:notes:141]
[same as prior period, unchanged from 0001045810-15-000097:notes:124]

[0001045810-15-000143:notes:142]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-15-000143:notes:143]
[same as prior period, unchanged from 0001045810-15-000097:notes:126]

[0001045810-15-000143:notes:144]
[same as prior period, unchanged from 0001045810-15-000097:notes:127]

[0001045810-15-000143:notes:145]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. In May 2015, the Board extended the previously authorized repurchase program through December 2018 and authorized an additional $1.62 billion under the repurchase program.

[0001045810-15-000143:notes:146]
In May 2015 we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we made an upfront payment of $400 million to purchase shares of our common stock and received an initial delivery of 14 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted net income per share.

[0001045810-15-000143:notes:147]
We accounted for the ASR program as two separate transactions: (i) the 14 million shares of common stock initially delivered to us were accounted for as a treasury stock transaction and (ii) the unsettled contract was determined to be a forward contract indexed to our own common stock. The initial delivery of 14 million shares resulted in an immediate reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted net income per share. We have determined that the forward contract, indexed to our common stock, met all of the applicable criteria for equity classification.  As a result, we recorded $289 million as treasury stock and $111 million, the implied value of the forward contract, as additional paid-in-capital, or APIC, in our Condensed Consolidated Balance Sheets as of July 26, 2015. The remainder of the shares are anticipated to be delivered to us in the third quarter of fiscal year 2016, and at that time, the forward contract will be reclassified from APIC to treasury stock.

[0001045810-15-000143:notes:148]
Through July 26, 2015, we have repurchased an aggregate of 222 million shares under our share repurchase program for a total cost of $3.72 billion. All shares delivered from these repurchases have been placed into treasury stock. As of July 26, 2015, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.60 billion.

[0001045810-15-000143:notes:149]
[same as prior period, unchanged from 0001045810-15-000097:notes:131]

[0001045810-15-000143:notes:150]
During the three and six months ended July 26, 2015, we paid $52 million and $99 million, respectively, in cash dividends to our common shareholders. These dividends were equivalent to $0.0975 and $0.085 per share for the three months ended July 26, 2015 and April 26, 2015, respectively.

[0001045810-15-000143:notes:151]
[same as prior period, unchanged from 0001045810-15-000097:notes:133]

[0001045810-15-000143:notes:152]
[same as prior period, unchanged from 0001045810-15-000097:notes:134]

[0001045810-15-000143:notes:153]
[same as prior period, unchanged from 0001045810-15-000097:notes:135]

[0001045810-15-000143:notes:154]
[same as prior period, unchanged from 0001045810-15-000097:notes:136]
