# NVDA note change history — 0001045810-18-000150 → 0001045810-19-000079


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-05-16):
[0001045810-19-000079:note_history:1]
Inventory Purchase Obligations

- added (2019-05-16):
[0001045810-19-000079:note_history:2]
As of April 28, 2019, we had outstanding inventory purchase obligations totaling $782 million.

- added (2019-05-16):
[0001045810-19-000079:note_history:3]
Capital Purchase Obligations

- added (2019-05-16):
[0001045810-19-000079:note_history:4]
As of April 28, 2019, we had outstanding capital purchase obligations totaling $194 million.

- added (2019-05-16):
[0001045810-19-000079:note_history:5]
Performance Obligations

- added (2019-05-16):
[0001045810-19-000079:note_history:6]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of April 28, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $294 million, of which we expect to recognize approximately 57% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

- added (2019-05-16):
[0001045810-19-000079:note_history:7]
Accrual for Product Warranty Liabilities

- added (2019-05-16):
[0001045810-19-000079:note_history:8]
The estimated amount of product returns and warranty liabilities was $18 million as of both April 28, 2019 and January 27, 2019.

- added (2019-05-16):
[0001045810-19-000079:note_history:9]
In connection with certain agreements that we have entered in the past, we have provided indemnification to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

- added (2019-05-16):
[0001045810-19-000079:note_history:10]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States and Germany.

- added (2019-05-16):
[0001045810-19-000079:note_history:11]
NVIDIA and Polaris entered into an agreement effective April 3, 2019 that settled the litigation between the parties, which had an immaterial impact on our financial results. The agreement includes a license to NVIDIA for certain patents owned by Polaris, as well as options for NVIDIA to renew the license through the life of the patents.

- added (2019-05-16):
[0001045810-19-000079:note_history:12]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA had infringed and was continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint sought unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 1 Patents.

- changed (2019-05-16):
[0001045810-19-000079:note_history:13]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the U.S. International Trade Commission, or USITC, investigation over the ZiiLabs 2 patents.
  (was, 2018-11-15, similarity 0.8635):
[0001045810-18-000150:note_history:13]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the ITC investigation over the ZiiLabs 2 patents.

- added (2019-05-16):
[0001045810-19-000079:note_history:14]
On February 1, 2019, NVIDIA entered into an agreement in which it received a license to the ZiiLabs patents and a dismissal of the ZiiLabs 1 and 2 Patent Lawsuits, which had an immaterial impact on our financial results. The ZiiLabs 1 and 2 district court cases were dismissed pursuant to a stipulation of dismissal filed on February 8, 2019. The Administrative Law Judge issued an Initial Determination on February 12, 2019, granting the motion to terminate the USITC investigation addressing the ZiiLabs 2 patents.

- changed (2019-05-16):
[0001045810-19-000079:note_history:15]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also sought unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 2 Patents.
  (was, 2018-11-15, similarity 0.9868):
[0001045810-18-000150:note_history:15]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

- changed (2019-05-16):
[0001045810-19-000079:note_history:16]
On December 29, 2017, ZiiLabs filed a request with the USITC to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleged that the unlawful importation resulted from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.
  (was, 2018-11-15, similarity 0.9602):
[0001045810-18-000150:note_history:16]
On December 29, 2017, ZiiLabs filed a request with the U.S. International Trade Commission, or USITC, to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

- added (2019-05-16):
[0001045810-19-000079:note_history:17]
On February 1, 2019, NVIDIA entered into an agreement in which it received a license to the ZiiLabs patents and a dismissal of the ZiiLabs 1 and 2 Patent Lawsuits, which had an immaterial impact on our financial results. The ZiiLabs 1 and 2 district court cases were dismissed pursuant to a stipulation of dismissal filed on February 8, 2019. The Administrative Law Judge issued an Initial Determination on February 12, 2019, granting the motion to terminate the USITC investigation addressing the ZiiLabs 2 patents.

- added (2019-05-16):
[0001045810-19-000079:note_history:18]
Securities Class Action and Derivative Lawsuits

- added (2019-05-16):
[0001045810-19-000079:note_history:19]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. The complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between August 10, 2017 and November 15, 2018. The plaintiff also alleges that the NVIDIA officers who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiff seeks class certification, an award of unspecified compensatory damages, an award of equitable/injunctive or other further relief as the Court may deem just and proper. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief.  On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiff and lead counsel.

- added (2019-05-16):
[0001045810-19-000079:note_history:20]
On January 18, 2019, a shareholder, purporting to act on the behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

- added (2019-05-16):
[0001045810-19-000079:note_history:21]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming us and/or our officers and directors as defendants.

- added (2019-05-16):
[0001045810-19-000079:note_history:22]
Litigation Related to Mellanox Merger

- added (2019-05-16):
[0001045810-19-000079:note_history:23]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Securities Exchange Act of 1934 and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but to date, NVIDIA has not been named as a defendant in any of these other lawsuits.

- added (2019-05-16):
[0001045810-19-000079:note_history:24]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of April 28, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.

- removed (2019-05-16):
[0001045810-18-000150:note_history:25]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

- removed (2019-05-16):
[0001045810-18-000150:note_history:26]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.

- removed (2019-05-16):
[0001045810-18-000150:note_history:27]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for four U.S. patents and declined to institute IPRs on two U.S. patents. The USPTO issued a Final Written Decision on the IPR relating to one of the patents on June 19, 2018, finding claims 1-23 and 28 unpatentable but that claims 24-27 were not proved unpatentable.

- removed (2019-05-16):
[0001045810-18-000150:note_history:28]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

- removed (2019-05-16):
[0001045810-18-000150:note_history:29]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. On September 3, 2018, NVIDIA filed a rejoinder with additional noninfringement arguments.

- removed (2019-05-16):
[0001045810-18-000150:note_history:30]
An oral hearing is scheduled for February 21, 2019.

- removed (2019-05-16):
[0001045810-18-000150:note_history:31]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

- removed (2019-05-16):
[0001045810-18-000150:note_history:32]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

- removed (2019-05-16):
[0001045810-18-000150:note_history:33]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. patent.

- removed (2019-05-16):
[0001045810-18-000150:note_history:34]
On February 22, 2018, the Delaware Court stayed the district court action on the ZiiLabs 2 patents pending the resolution of the ITC Investigation over the ZiiLabs 2 patents.

- removed (2019-05-16):
[0001045810-18-000150:note_history:35]
On February 28, 2018, NVIDIA and the other respondents answered the ITC complaint and asserted various defenses including non-infringement and invalidity of the four asserted ZiiLabs 2 patents.

- removed (2019-05-16):
[0001045810-18-000150:note_history:36]
On May 10, 2018, the Administrative Law Judge presiding over the investigation issued an Initial Determination terminating the investigation with respect to one of the patents.  On July 17, 2018, the USITC affirmed this decision on modified grounds.

- removed (2019-05-16):
[0001045810-18-000150:note_history:37]
On October 18, 2018, the Administrative Law Judge currently presiding over the investigation issued an order construing certain claims of the three remaining patents in the investigation.

- removed (2019-05-16):
[0001045810-18-000150:note_history:38]
The hearing in the investigation is currently scheduled to begin January 25, 2019.  The target date for completion of the investigation is September 9, 2019.

- removed (2019-05-16):
[0001045810-18-000150:note_history:39]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 28, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-16):
[0001045810-19-000079:note_history:40]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 27, 2019 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.
  (was, 2018-11-15, similarity 0.9883):
[0001045810-18-000150:note_history:40]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2018 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

- changed (2019-05-16):
[0001045810-19-000079:note_history:41]
Except for the accounting policy for leases, which was updated as a result of adopting a new accounting standard related to leases, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.
  (was, 2018-11-15, similarity 0.9413):
[0001045810-18-000150:note_history:41]
Except for the accounting policy for revenue recognition, which was updated as a result of adopting a new accounting standard related to revenue recognition, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

- added (2019-05-16):
[0001045810-19-000079:note_history:42]
Leases

- added (2019-05-16):
[0001045810-19-000079:note_history:43]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

- added (2019-05-16):
[0001045810-19-000079:note_history:44]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

- added (2019-05-16):
[0001045810-19-000079:note_history:45]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

- added (2019-05-16):
[0001045810-19-000079:note_history:46]
Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

- changed (2019-05-16):
[0001045810-19-000079:note_history:47]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The first quarters of fiscal years 2020 and 2019 were both 13-week quarters.
  (was, 2018-11-15, similarity 0.9839):
[0001045810-18-000150:note_history:47]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The third quarters of fiscal years 2019 and 2018 were both 13-week quarters.

- changed (2019-05-16):
[0001045810-19-000079:note_history:48]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2018-11-15, similarity 0.9994):
[0001045810-18-000150:note_history:48]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- changed (2019-05-16):
[0001045810-19-000079:note_history:49]
Recently Adopted Accounting Pronouncement
  (was, 2018-11-15, similarity 0.988):
[0001045810-18-000150:note_history:49]
Recently Adopted Accounting Pronouncements

- added (2019-05-16):
[0001045810-19-000079:note_history:50]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases under which lease assets and liabilities are recognized on the balance sheet. We adopted this guidance on January 28, 2019 using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet. Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

- added (2019-05-16):
[0001045810-19-000079:note_history:51]
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. The standard will be effective for us beginning in the first quarter of fiscal year 2021, with early adoption permitted. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- removed (2019-05-16):
[0001045810-18-000150:note_history:52]
Revenue Recognition

- removed (2019-05-16):
[0001045810-18-000150:note_history:53]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- removed (2019-05-16):
[0001045810-18-000150:note_history:54]
Product Sales Revenue

- removed (2019-05-16):
[0001045810-18-000150:note_history:55]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

- removed (2019-05-16):
[0001045810-18-000150:note_history:56]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- removed (2019-05-16):
[0001045810-18-000150:note_history:57]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- removed (2019-05-16):
[0001045810-18-000150:note_history:58]
License and Development Arrangements

- removed (2019-05-16):
[0001045810-18-000150:note_history:59]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

- removed (2019-05-16):
[0001045810-18-000150:note_history:60]
Software Licensing

- removed (2019-05-16):
[0001045810-18-000150:note_history:61]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.

- removed (2019-05-16):
[0001045810-18-000150:note_history:62]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We adopted this guidance on January 29, 2018 using the modified retrospective approach. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for additional information.

- removed (2019-05-16):
[0001045810-18-000150:note_history:63]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We are now required to recognize changes in the fair value of our equity investments through net income rather than other comprehensive income. We adopted this guidance in the first quarter of fiscal year 2019 and applied it prospectively. The adoption of this guidance did not have a significant impact on our consolidated financial statements.

- removed (2019-05-16):
[0001045810-18-000150:note_history:64]
In February 2016 and July 2018, the FASB issued accounting standards updates regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The FASB also recently provided a practical expedient transition method to adopt the new lease accounting requirements. We are evaluating the impact of adopting the new lease accounting standards on our consolidated financial statements, systems and processes in conjunction with our review of lease agreements. The updates will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-16):
[0001045810-19-000079:note_history:65]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (12 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,988 |  |  | $ | 1,988 |  |
  (was, 2018-11-15, similarity 0.9836):
[0001045810-18-000150:note_history:65]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 28, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |

- changed (2019-05-16):
[0001045810-19-000079:note_history:66]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 28, 2019, we had not borrowed any amounts under this agreement.
  (was, 2018-11-15, similarity 0.974):
[0001045810-18-000150:note_history:66]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 28, 2018, we had not borrowed any amounts under this agreement.

- changed (2019-05-16):
[0001045810-19-000079:note_history:67]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2019, we had not issued any commercial paper.
  (was, 2018-11-15, similarity 0.9645):
[0001045810-18-000150:note_history:67]
We have a $575 million commercial paper program to support general corporate purposes. As of October 28, 2018, we had not issued any commercial paper.

- removed (2019-05-16):
[0001045810-18-000150:note_history:68]
Convertible Debt

- removed (2019-05-16):
[0001045810-18-000150:note_history:69]
1.00% Convertible Senior Notes Due 2018

- removed (2019-05-16):
[0001045810-18-000150:note_history:70]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. The Convertible Notes will mature on December 1, 2018 and we had $3 million in principal amount outstanding as of October 28, 2018. Effective August 1, 2018, holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date of December 1, 2018 regardless of conversion conditions.

- removed (2019-05-16):
[0001045810-18-000150:note_history:71]
During the third quarter of fiscal year 2019, we paid cash to settle an aggregate of $11 million in principal amount of the Convertible Notes and issued 485 thousand shares of our common stock for the excess conversion value. The related loss on early conversions was not significant. Based on the closing price of our common stock of $198.29 on the last trading day of the third quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $31 million. As of October 28, 2018, the conversion rate was 49.95 shares of common stock per $1,000 principal amount of the Convertible Notes.

- removed (2019-05-16):
[0001045810-18-000150:note_history:72]
Note Hedges

- removed (2019-05-16):
[0001045810-18-000150:note_history:73]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.02 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through October 28, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.50 billion in principal amount of the Convertible Notes.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: title_similarity, score: 0.931

- changed (2019-05-16):
[0001045810-19-000079:note_history:74]
The following is a summary of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019:
  (was, 2018-11-15, similarity 0.9528):
[0001045810-18-000150:note_history:74]
The following is a summary of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018:

- changed (2019-05-16):
[0001045810-19-000079:note_history:75]
|  | April 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,899 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 2,899 |  |  | $ | 1,048 |  |  | $ | 1,851 |  |
| Debt securities of United States government agencies | 1,882 |  |  | — |  |  | (1 | ) |  | 1,881 |  |  | — |  |  | 1,881 |  |
| Debt securities issued by the United States Treasury | 1,833 |  |  | — |  |  | — |  |  | 1,833 |  |  | 932 |  |  | 901 |  |
| Money market funds | 681 |  |  | — |  |  | — |  |  | 681 |  |  | 681 |  |  | — |  |
| Foreign government bonds | 183 |  |  | — |  |  | — |  |  | 183 |  |  | — |  |  | 183 |  |
| Asset-backed securities | 133 |  |  | — |  |  | (1 | ) |  | 132 |  |  | — |  |  | 132 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 81 |  |  | 1 |  |  | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total | $ | 7,692 |  |  | $ | 3 |  |  | $ | (4 | ) |  | $ | 7,691 |  |  | $ | 2,661 |  |  | $ | 5,030 |  |
  (was, 2018-11-15, similarity 0.9709):
[0001045810-18-000150:note_history:75]
|  | October 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,732 |  |  | $ | 1 |  |  | $ | (6 | ) |  | $ | 2,727 |  |  | $ | — |  |  | $ | 2,727 |  |
| Debt securities of United States government agencies | 2,140 |  |  | — |  |  | (5 | ) |  | $ | 2,135 |  |  | — |  |  | 2,135 |  |
| Debt securities issued by the United States Treasury | 1,544 |  |  | — |  |  | (2 | ) |  | 1,542 |  |  | — |  |  | 1,542 |  |
| Money market funds | 602 |  |  | — |  |  | — |  |  | 602 |  |  | 602 |  |  | — |  |
| Foreign government bonds | 191 |  |  | — |  |  | — |  |  | 191 |  |  | — |  |  | 191 |  |
| Asset-backed securities | 178 |  |  | — |  |  | (2 | ) |  | 176 |  |  | — |  |  | 176 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 98 |  |  | 1 |  |  | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 7,485 |  |  | $ | 2 |  |  | $ | (15 | ) |  | $ | 7,472 |  |  | $ | 602 |  |  | $ | 6,870 |  |

- changed (2019-05-16):
[0001045810-19-000079:note_history:76]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |
  (was, 2018-11-15, similarity 0.7934):
[0001045810-18-000150:note_history:76]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

- added (2019-05-16):
[0001045810-19-000079:note_history:77]
The following table provides the breakdown of unrealized losses as of April 28, 2019, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- changed (2019-05-16):
[0001045810-19-000079:note_history:78]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,429 |  |  | $ | — |  |  | $ | 306 |  |  | $ | (1 | ) |  | $ | 1,735 |  |  | $ | (1 | ) |
| Corporate debt securities | 330 |  |  | (1 | ) |  | 453 |  |  | (1 | ) |  | 783 |  |  | (2 | ) |
| Asset-backed securities | — |  |  | — |  |  | 132 |  |  | (1 | ) |  | 132 |  |  | (1 | ) |
| Total | $ | 1,759 |  |  | $ | (1 | ) |  | $ | 891 |  |  | $ | (3 | ) |  | $ | 2,650 |  |  | $ | (4 | ) |
  (was, 2018-11-15, similarity 0.8525):
[0001045810-18-000150:note_history:78]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,584 |  |  | $ | (1 | ) |  | $ | 507 |  |  | $ | (4 | ) |  | $ | 2,091 |  |  | $ | (5 | ) |
| Debt securities issued by the United States Treasury | 1,253 |  |  | — |  |  | 289 |  |  | (2 | ) |  | 1,542 |  |  | (2 | ) |
| Corporate debt securities | 167 |  |  | — |  |  | 794 |  |  | (6 | ) |  | 961 |  |  | (6 | ) |
| Asset-backed securities | — |  |  | — |  |  | 176 |  |  | (2 | ) |  | 176 |  |  | (2 | ) |
| Total | $ | 3,004 |  |  | $ | (1 | ) |  | $ | 1,766 |  |  | $ | (14 | ) |  | $ | 4,770 |  |  | $ | (15 | ) |

- changed (2019-05-16):
[0001045810-19-000079:note_history:79]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019 are shown below by contractual maturity.
  (was, 2018-11-15, similarity 0.9693):
[0001045810-18-000150:note_history:79]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018 are shown below by contractual maturity.

- changed (2019-05-16):
[0001045810-19-000079:note_history:80]
|  | April 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,773 |  |  | $ | 5,770 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 1,896 |  |  | 1,898 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 23 |  |  | 23 |  |  | 22 |  |  | 22 |  |
| Total | $ | 7,692 |  |  | $ | 7,691 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |
  (was, 2018-11-15, similarity 0.9871):
[0001045810-18-000150:note_history:80]
|  | October 28, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,537 |  |  | $ | 5,524 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,923 |  |  | 1,923 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 25 |  |  | 25 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,485 |  |  | $ | 7,472 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |

- removed (2019-05-16):
[0001045810-18-000150:note_history:81]
The following table provides the breakdown of unrealized losses as of October 28, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-16):
[0001045810-19-000079:note_history:82]
The following is a summary of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019:
  (was, 2018-11-15, similarity 0.9528):
[0001045810-18-000150:note_history:82]
The following is a summary of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018:

- changed (2019-05-16):
[0001045810-19-000079:note_history:83]
|  | April 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,899 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 2,899 |  |  | $ | 1,048 |  |  | $ | 1,851 |  |
| Debt securities of United States government agencies | 1,882 |  |  | — |  |  | (1 | ) |  | 1,881 |  |  | — |  |  | 1,881 |  |
| Debt securities issued by the United States Treasury | 1,833 |  |  | — |  |  | — |  |  | 1,833 |  |  | 932 |  |  | 901 |  |
| Money market funds | 681 |  |  | — |  |  | — |  |  | 681 |  |  | 681 |  |  | — |  |
| Foreign government bonds | 183 |  |  | — |  |  | — |  |  | 183 |  |  | — |  |  | 183 |  |
| Asset-backed securities | 133 |  |  | — |  |  | (1 | ) |  | 132 |  |  | — |  |  | 132 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 81 |  |  | 1 |  |  | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total | $ | 7,692 |  |  | $ | 3 |  |  | $ | (4 | ) |  | $ | 7,691 |  |  | $ | 2,661 |  |  | $ | 5,030 |  |
  (was, 2018-11-15, similarity 0.9709):
[0001045810-18-000150:note_history:83]
|  | October 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,732 |  |  | $ | 1 |  |  | $ | (6 | ) |  | $ | 2,727 |  |  | $ | — |  |  | $ | 2,727 |  |
| Debt securities of United States government agencies | 2,140 |  |  | — |  |  | (5 | ) |  | $ | 2,135 |  |  | — |  |  | 2,135 |  |
| Debt securities issued by the United States Treasury | 1,544 |  |  | — |  |  | (2 | ) |  | 1,542 |  |  | — |  |  | 1,542 |  |
| Money market funds | 602 |  |  | — |  |  | — |  |  | 602 |  |  | 602 |  |  | — |  |
| Foreign government bonds | 191 |  |  | — |  |  | — |  |  | 191 |  |  | — |  |  | 191 |  |
| Asset-backed securities | 178 |  |  | — |  |  | (2 | ) |  | 176 |  |  | — |  |  | 176 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 98 |  |  | 1 |  |  | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 7,485 |  |  | $ | 2 |  |  | $ | (15 | ) |  | $ | 7,472 |  |  | $ | 602 |  |  | $ | 6,870 |  |

- changed (2019-05-16):
[0001045810-19-000079:note_history:84]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |
  (was, 2018-11-15, similarity 0.7934):
[0001045810-18-000150:note_history:84]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

- added (2019-05-16):
[0001045810-19-000079:note_history:85]
The following table provides the breakdown of unrealized losses as of April 28, 2019, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- changed (2019-05-16):
[0001045810-19-000079:note_history:86]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,429 |  |  | $ | — |  |  | $ | 306 |  |  | $ | (1 | ) |  | $ | 1,735 |  |  | $ | (1 | ) |
| Corporate debt securities | 330 |  |  | (1 | ) |  | 453 |  |  | (1 | ) |  | 783 |  |  | (2 | ) |
| Asset-backed securities | — |  |  | — |  |  | 132 |  |  | (1 | ) |  | 132 |  |  | (1 | ) |
| Total | $ | 1,759 |  |  | $ | (1 | ) |  | $ | 891 |  |  | $ | (3 | ) |  | $ | 2,650 |  |  | $ | (4 | ) |
  (was, 2018-11-15, similarity 0.8525):
[0001045810-18-000150:note_history:86]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,584 |  |  | $ | (1 | ) |  | $ | 507 |  |  | $ | (4 | ) |  | $ | 2,091 |  |  | $ | (5 | ) |
| Debt securities issued by the United States Treasury | 1,253 |  |  | — |  |  | 289 |  |  | (2 | ) |  | 1,542 |  |  | (2 | ) |
| Corporate debt securities | 167 |  |  | — |  |  | 794 |  |  | (6 | ) |  | 961 |  |  | (6 | ) |
| Asset-backed securities | — |  |  | — |  |  | 176 |  |  | (2 | ) |  | 176 |  |  | (2 | ) |
| Total | $ | 3,004 |  |  | $ | (1 | ) |  | $ | 1,766 |  |  | $ | (14 | ) |  | $ | 4,770 |  |  | $ | (15 | ) |

- changed (2019-05-16):
[0001045810-19-000079:note_history:87]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For the first quarter of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.
  (was, 2018-11-15, similarity 0.9562):
[0001045810-18-000150:note_history:87]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For the third quarter and first nine months of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.

- changed (2019-05-16):
[0001045810-19-000079:note_history:88]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019 are shown below by contractual maturity.
  (was, 2018-11-15, similarity 0.9693):
[0001045810-18-000150:note_history:88]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018 are shown below by contractual maturity.

- changed (2019-05-16):
[0001045810-19-000079:note_history:89]
|  | April 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,773 |  |  | $ | 5,770 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 1,896 |  |  | 1,898 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 23 |  |  | 23 |  |  | 22 |  |  | 22 |  |
| Total | $ | 7,692 |  |  | $ | 7,691 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |
  (was, 2018-11-15, similarity 0.9871):
[0001045810-18-000150:note_history:89]
|  | October 28, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,537 |  |  | $ | 5,524 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,923 |  |  | 1,923 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 25 |  |  | 25 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,485 |  |  | $ | 7,472 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |

- removed (2019-05-16):
[0001045810-18-000150:note_history:90]
The following table provides the breakdown of unrealized losses as of October 28, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-16):
[0001045810-19-000079:note_history:91]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (12 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,988 |  |  | $ | 1,988 |  |
  (was, 2018-11-15, similarity 0.9836):
[0001045810-18-000150:note_history:91]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 28, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |


## nvda:RevenueFromContractwithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-05-16):
[0001045810-18-000150:note_history:92]
Revenue Recognition

- removed (2019-05-16):
[0001045810-18-000150:note_history:93]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- removed (2019-05-16):
[0001045810-18-000150:note_history:94]
Product Sales Revenue

- removed (2019-05-16):
[0001045810-18-000150:note_history:95]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

- removed (2019-05-16):
[0001045810-18-000150:note_history:96]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- removed (2019-05-16):
[0001045810-18-000150:note_history:97]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- removed (2019-05-16):
[0001045810-18-000150:note_history:98]
License and Development Arrangements

- removed (2019-05-16):
[0001045810-18-000150:note_history:99]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

- removed (2019-05-16):
[0001045810-18-000150:note_history:100]
Software Licensing

- removed (2019-05-16):
[0001045810-18-000150:note_history:101]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.
