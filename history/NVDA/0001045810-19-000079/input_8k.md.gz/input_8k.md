# NVDA 8-K — 0001045810-19-000077 filed 2019-05-16

## item codes, every 8-K on or before 2019-05-16

- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2019-05-16

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-19-000077:8k_2_02:1]
EX-99.1
2
q1fy20pr.htm
Q1FY20 PRESS RELEASE

[0001045810-19-000077:8k_2_02:2]
Exhibit

[0001045810-19-000077:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-19-000077:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2020

[0001045810-19-000077:8k_2_02:5]
SANTA CLARA, Calif.-May 16, 2019-NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 28, 2019, of $2.22 billion compared with $3.21 billion a year earlier and $2.21 billion in the previous quarter.

[0001045810-19-000077:8k_2_02:6]
GAAP earnings per diluted share for the quarter were $0.64, compared with $1.98 a year ago and $0.92 in the previous quarter. Non-GAAP earnings per diluted share were $0.88 compared with $2.05 a year earlier and $0.80 in the previous quarter.

[0001045810-19-000077:8k_2_02:7]
“NVIDIA is back on an upward trajectory,” said Jensen Huang, founder and CEO of NVIDIA. “We’ve returned to growth in gaming, with nearly 100 new GeForce Max-Q laptops shipping. And NVIDIA RTX has gained broad industry support, making ray tracing the standard for next-generation gaming.

[0001045810-19-000077:8k_2_02:8]
“Despite the near-term pause in demand from hyperscale customers, the application of AI continues to accelerate. AI adoption is accelerating in the world’s largest industries, moving beyond the cloud to the edge where AI processing has to be instantaneous.  We’re excited about our pending acquisition of Mellanox, which will help us drive data center architecture for high performance computing and AI from the cloud to the edge,” he said.

[0001045810-19-000077:8k_2_02:9]
Capital Return

[0001045810-19-000077:8k_2_02:10]
As previously communicated, NVIDIA intends to return $3.00 billion to shareholders by the end of fiscal 2020, including $700 million in share repurchases made during the fourth quarter of fiscal 2019. In the first quarter of fiscal 2020, the company returned $97 million in quarterly cash dividends.

[0001045810-19-000077:8k_2_02:11]
NVIDIA will pay its next quarterly cash dividend of $0.16 per share on June 21, 2019, to all shareholders of record on May 31, 2019.

[0001045810-19-000077:8k_2_02:12]
Q1 Fiscal 2020 Summary

[0001045810-19-000077:8k_2_02:13]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY20 | Q4 FY19 | Q1 FY19 | Q/Q | Y/Y |
| Revenue | $2,220 | $2,205 | $3,207 | Up 1% | Down 31% |
| Gross margin | 58.4 | % | 54.7 | % | 64.5 | % | Up 370 bps | Down 610 bps |
| Operating expenses | $938 | $913 | $773 | Up 3% | Up 21% |
| Operating income | $358 | $294 | $1,295 | Up 22% | Down 72% |
| Net income | $394 | $567 | $1,244 | Down 31% | Down 68% |
| Diluted earnings per share | $0.64 | $0.92 | $1.98 | Down 30% | Down 68% |

[0001045810-19-000077:8k_2_02:14]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY20 | Q4 FY19 | Q1 FY19 | Q/Q | Y/Y |
| Revenue | $2,220 | $2,205 | $3,207 | Up 1% | Down 31% |
| Gross margin | 59.0 | % | 56.0 | % | 64.7 | % | Up 300 bps | Down 570 bps |
| Operating expenses | $753 | $755 | $648 | -- | Up 16% |
| Operating income | $557 | $479 | $1,428 | Up 16% | Down 61% |
| Net income | $543 | $496 | $1,285 | Up 9% | Down 58% |
| Diluted earnings per share | $0.88 | $0.80 | $2.05 | Up 10% | Down 57% |

[0001045810-19-000077:8k_2_02:15]
NVIDIA’s outlook for the second quarter of fiscal 2020 is as follows:

[0001045810-19-000077:8k_2_02:16]
| • | Revenue is expected to be $2.55 billion, plus or minus 2 percent. |

[0001045810-19-000077:8k_2_02:17]
| • | GAAP and non-GAAP gross margins are expected to be 59.2 percent and 59.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-19-000077:8k_2_02:18]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $985 million and $765 million, respectively. |

[0001045810-19-000077:8k_2_02:19]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $27 million. |

[0001045810-19-000077:8k_2_02:20]
| • | GAAP and non-GAAP tax rates are both expected to be 10 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-19-000077:8k_2_02:21]
Highlights

[0001045810-19-000077:8k_2_02:22]
During the quarter, NVIDIA announced that it reached a definitive agreement to acquire Mellanox Technologies, Ltd. for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion. Once complete, the combination is expected to be immediately accretive to NVIDIA’s non-GAAP gross margin, non-GAAP earnings per share, and free cash flow. The transaction is expected to close by the end of the calendar year.

[0001045810-19-000077:8k_2_02:23]
Since the end of the fourth quarter of fiscal 2019, NVIDIA has achieved progress in these areas:

[0001045810-19-000077:8k_2_02:24]
Data Center

[0001045810-19-000077:8k_2_02:25]
| • | Introduced the NVIDIA® CUDA-X AI™ platform for accelerating data science. |

[0001045810-19-000077:8k_2_02:26]
| • | Announced availability of NVIDIA T4 Tensor Core GPUs from leading OEMs, as well as Amazon Web Services. |

[0001045810-19-000077:8k_2_02:27]
| • | Partnered with top global system builders to create powerful data-science workstations integrating NVIDIA Quadro RTX™ GPUs and NVIDIA CUDA-X AI. |

[0001045810-19-000077:8k_2_02:28]
| • | Launched beta access to NVIDIA Quadro® Virtual Workstation software in the Alibaba Cloud Marketplace. |

[0001045810-19-000077:8k_2_02:29]
| • | Teamed up with the American College of Radiology to use the NVIDIA Clara™ AI toolkit to enable its members across the U.S. to create and use AI for diagnostic radiology in their own facilities. |

[0001045810-19-000077:8k_2_02:30]
Gaming

[0001045810-19-000077:8k_2_02:31]
| • | Introduced the GeForce® GTX® 1660 Ti, GTX 1660 and GTX 1650 gaming GPUs with improved performance and efficiency for today’s most popular games. |

[0001045810-19-000077:8k_2_02:32]
| • | Announced a record number of gaming laptop models based on Turing GPUs from the world’s top makers, bringing the total launched this year to nearly 100. |

[0001045810-19-000077:8k_2_02:33]
| • | Announced that real-time ray tracing is now integrated into Unreal Engine and Unity, the world’s most popular commercial game engines. |

[0001045810-19-000077:8k_2_02:34]
Professional Visualization

[0001045810-19-000077:8k_2_02:35]
| • | Announced expanded adoption of NVIDIA RTX ray-tracing technology by the world’s top 3D application providers. |

[0001045810-19-000077:8k_2_02:36]
| • | Unveiled the NVIDIA Omniverse open-collaboration platform to simplify creative workflows for content creation. |

[0001045810-19-000077:8k_2_02:37]
Automotive

[0001045810-19-000077:8k_2_02:38]
| • | Partnered with Toyota Research Institute-Advanced Development to develop, train and validate self-driving vehicles. |

[0001045810-19-000077:8k_2_02:39]
| • | Unveiled NVIDIA DRIVE™ AP2X, a complete Level 2+ automated driving solution encompassing DRIVE AutoPilot software, DRIVE AGX and DRIVE validation tools. |

[0001045810-19-000077:8k_2_02:40]
| • | Introduced NVIDIA DRIVE AV Safety Force Field to enable safe, comfortable driving experiences. |

[0001045810-19-000077:8k_2_02:41]
| • | Announced availability of the NVIDIA DRIVE Constellation™ autonomous vehicle simulation platform. |

[0001045810-19-000077:8k_2_02:42]
Edge Computing

[0001045810-19-000077:8k_2_02:43]
| • | Launched Jetson Nano™, an AI computer that makes it possible to create millions of small, low-cost, low-power devices. |

[0001045810-19-000077:8k_2_02:44]
| • | Announced free public availability of NVIDIA Isaac SDK™ as a robotics developer toolbox for accelerating innovation and deployment. |

[0001045810-19-000077:8k_2_02:45]
| • | Announced that the NVIDIA Jetson™ AI computer platform now supports Amazon Web Services RoboMaker. |

[0001045810-19-000077:8k_2_02:46]
| • | Teamed up with AWS IoT Greengrass to enable customers to deploy AI and deep learning to millions of connected devices with NVIDIA Jetson. |

[0001045810-19-000077:8k_2_02:47]
| • | Collaborated with Microsoft to make cities smarter by integrating NVIDIA DeepStream Edge AI and Microsoft Azure IoT. |

[0001045810-19-000077:8k_2_02:48]
CFO Commentary

[0001045810-19-000077:8k_2_02:49]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-19-000077:8k_2_02:50]
Conference Call and Webcast Information

[0001045810-19-000077:8k_2_02:51]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2020 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2020.

[0001045810-19-000077:8k_2_02:52]
Non-GAAP Measures

[0001045810-19-000077:8k_2_02:53]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related and other costs, gains from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items, where applicable, and the tax benefit from income tax reform. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchase of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-19-000077:8k_2_02:54]
About NVIDIA

[0001045810-19-000077:8k_2_02:55]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-19-000077:8k_2_02:56]
###

[0001045810-19-000077:8k_2_02:57]
For further information, contact:

[0001045810-19-000077:8k_2_02:58]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-19-000077:8k_2_02:59]
Certain statements in this press release including, but not limited to, statements as to: NVIDIA being back on an upward trajectory; NVIDIA returning to growth in gaming with nearly 100 new GeForce Max-Q laptops shipping; NVIDIA RTX graphics gaining broad industry support, making ray tracing the standard for next-generation gaming; the near term pause in demand from hyperscale customers; AI continuing to accelerate AI adoption accelerating in the world’s largest industries moving beyond the cloud to edge and it needing to be instantaneous; NVIDIA’s excitement about the acquisition of Mellanox and it helping to drive the data center architecture for high-performance computing and AI from the cloud to the edge; NVIDIA’s intended capital return through the end of fiscal 2020; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the second quarter of fiscal 2020; NVIDIA’s expected tax rates for the second quarter of fiscal 2020; our expectation to generate variability from excess tax benefits or deficiencies; the expected accretive financial impact of the Mellanox transaction; the expected closing date of the Mellanox acquisition; the performance, benefits and abilities of our products; the availability of NVIDIA T4 Tensor Core GPUs, NVIDIA Drive Constellation and NVIDIA Isaac SDK; our partnership with top global system builders to create powerful data-science workstations; our partnership with the American College of Radiology enabling its members to create and use AI for diagnostic radiology;  the introduction of GeForce GTX 1660 Ti, GTX 1660 and GTX 1650 and its performance and impact; the number of gaming laptop models using Turing GPUs;  the expanded adoption of NVIDIA RTX ray-tracing technology by the world’s top 3D providers; NVIDIA Omniverse platform simplifying creative workflows for content creation; our partnership with Toyota Research Institute-Advanced Development to develop, train and validate self-driving vehicles; NVIDIA DRIVE AV Safety Force Field enabling safe, comfortable driving experiences; Jetson Nano making it possible to create millions of small, low-cost, low-power devices; our partnership with AWS IoT Greengrass to enable customers to deploy AI and deep learning to millions of connected devices; NVIDIA Jetson AI supporting Amazon Web Services RoboMaker; and our collaboration with Microsoft to make cities smarter are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-19-000077:8k_2_02:60]
© 2019 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, CUDA-X AI, GeForce, GeForce GTX, Jetson, Jetson Nano, NVIDIA AGX, NVIDIA Clara, NVIDIA DRIVE, NVIDIA DRIVE Constellation, NVIDIA Isaac SDK, NVIDIA Omniverse, NVIDIA RTX, Quadro and Quadro RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000077:8k_2_02:61]
NVIDIA CORPORATION

[0001045810-19-000077:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-19-000077:8k_2_02:63]
(In millions, except per share data)

[0001045810-19-000077:8k_2_02:64]
(Unaudited)

[0001045810-19-000077:8k_2_02:65]
|  |  |  | Three Months Ended |
|  |  |  | April 28, |  | April 29, |
|  |  |  | 2019 |  | 2018 |
| Revenue | $ | 2,220 |  |  | $ | 3,207 |  |
| Cost of revenue | 924 |  |  | 1,139 |  |
| Gross profit | 1,296 |  |  | 2,068 |  |
| Operating expenses |  |  |  |
|  | Research and development | 674 |  |  | 542 |  |
|  | Sales, general and administrative | 264 |  |  | 231 |  |
|  |  | Total operating expenses | 938 |  |  | 773 |  |
| Income from operations | 358 |  |  | 1,295 |  |
|  | Interest income | 44 |  |  | 25 |  |
|  | Interest expense | (13 | ) |  | (15 | ) |
|  | Other, net | — |  |  | 6 |  |
|  |  | Total other income (expense) | 31 |  |  | 16 |  |
| Income before income tax | 389 |  |  | 1,311 |  |
| Income tax expense (benefit) | (5 | ) |  | 67 |  |
| Net income | $ | 394 |  |  | $ | 1,244 |  |
| Net income per share: |  |  |  |
|  | Basic | $ | 0.65 |  |  | $ | 2.05 |  |
|  | Diluted | $ | 0.64 |  |  | $ | 1.98 |  |
| Weighted average shares used in per share computation: |  |  |  |
|  | Basic | 607 |  |  | 606 |  |
|  | Diluted | 616 |  |  | 627 |  |

[0001045810-19-000077:8k_2_02:66]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | April 28, |  | January 27, |
|  |  |  |  | 2019 |  | 2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 7,802 |  |  | $ | 7,422 |  |
|  | Accounts receivable, net |  | 1,242 |  |  | 1,424 |  |
|  | Inventories |  | 1,426 |  |  | 1,575 |  |
|  | Prepaid expenses and other current assets |  | 159 |  |  | 136 |  |
|  |  | Total current assets |  | 10,629 |  |  | 10,557 |  |
| Property and equipment, net |  | 1,473 |  |  | 1,404 |  |
| Operating lease assets |  | 536 |  |  | — |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 54 |  |  | 45 |  |
| Deferred income tax assets |  | 601 |  |  | 560 |  |
| Other assets |  | 110 |  |  | 108 |  |
|  |  | Total assets |  | $ | 14,021 |  |  | $ | 13,292 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 368 |  |  | $ | 511 |  |
|  | Accrued and other current liabilities |  | 815 |  |  | 818 |  |
|  |  | Total current liabilities |  | 1,183 |  |  | 1,329 |  |
| Long-term debt |  | 1,988 |  |  | 1,988 |  |
| Long-term operating lease liabilities |  | 486 |  |  | — |  |
| Other long-term liabilities |  | 660 |  |  | 633 |  |
|  |  | Total liabilities |  | 4,317 |  |  | 3,950 |  |
| Shareholders' equity |  | 9,704 |  |  | 9,342 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 14,021 |  |  | $ | 13,292 |  |

[0001045810-19-000077:8k_2_02:67]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |
|  |  |  | April 28, |  | January 27, |  | April 29, |
|  |  |  | 2019 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 1,296 |  |  | $ | 1,207 |  |  | $ | 2,068 |  |
| GAAP gross margin |  | 58.4 | % |  | 54.7 | % |  | 64.5 | % |
|  | Stock-based compensation expense (A) |  | 4 |  |  | 6 |  |  | 8 |  |
|  | Legal settlement costs |  | 10 |  |  | 21 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 1,310 |  |  | $ | 1,234 |  |  | $ | 2,076 |  |
| Non-GAAP gross margin |  | 59.0 | % |  | 56.0 | % |  | 64.7 | % |
| GAAP operating expenses |  | $ | 938 |  |  | $ | 913 |  |  | $ | 773 |  |
|  | Stock-based compensation expense (A) |  | (174 | ) |  | (150 | ) |  | (121 | ) |
|  | Acquisition-related and other costs |  | (10 | ) |  | (1 | ) |  | (2 | ) |
|  | Legal settlement costs |  | (1 | ) |  | (7 | ) |  | (2 | ) |
| Non-GAAP operating expenses |  | $ | 753 |  |  | $ | 755 |  |  | $ | 648 |  |
| GAAP income from operations |  | $ | 358 |  |  | $ | 294 |  |  | $ | 1,295 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 199 |  |  | 185 |  |  | 133 |  |
| Non-GAAP income from operations |  | $ | 557 |  |  | $ | 479 |  |  | $ | 1,428 |  |
| GAAP other income (expense) |  | $ | 31 |  |  | $ | 30 |  |  | $ | 16 |  |
|  | Gains from non-affiliated investments |  | — |  |  | (1 | ) |  | (6 | ) |
|  | Interest expense related to amortization of debt discount |  | — |  |  | — |  |  | 1 |  |
| Non-GAAP other income (expense) |  | $ | 31 |  |  | $ | 29 |  |  | $ | 11 |  |
| GAAP net income |  | $ | 394 |  |  | $ | 567 |  |  | $ | 1,244 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 199 |  |  | 184 |  |  | 128 |  |
|  | Income tax impact of non-GAAP adjustments (B) |  | (50 | ) |  | (25 | ) |  | (87 | ) |
|  | Tax benefit from income tax reform |  | — |  |  | (230 | ) |  | — |  |
| Non-GAAP net income |  | $ | 543 |  |  | $ | 496 |  |  | $ | 1,285 |  |

[0001045810-19-000077:8k_2_02:68]
|  |  |  | Three Months Ended |
|  |  |  | April 28, |  | January 27, |  | April 29, |
|  |  |  | 2019 |  | 2019 |  | 2018 |
| Diluted net income per share |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.64 |  |  | $ | 0.92 |  |  | $ | 1.98 |  |
|  | Non-GAAP |  | $ | 0.88 |  |  | $ | 0.80 |  |  | $ | 2.05 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |
|  | GAAP |  | 616 |  |  | 619 |  |  | 627 |  |
|  | Anti-dilution impact from note hedge |  | — |  |  | — |  |  | (1 | ) |
|  | Non-GAAP |  | 616 |  |  | 619 |  |  | 626 |  |
| GAAP net cash provided by operating activities |  | $ | 720 |  |  | $ | 898 |  |  | $ | 1,445 |  |
|  | Purchase of property and equipment and intangible assets |  | (128 | ) |  | (203 | ) |  | (118 | ) |
| Free cash flow |  | $ | 592 |  |  | $ | 695 |  |  | $ | 1,327 |  |

[0001045810-19-000077:8k_2_02:69]
| (A) Stock-based compensation consists of the following: |  |  |
|  |  |  | Three Months Ended |
|  |  |  | April 28, |  | January 27, |  | April 29, |
|  |  |  | 2019 |  | 2019 |  | 2018 |
|  | Cost of revenue |  | $ | 4 |  |  | $ | 6 |  |  | $ | 8 |  |
|  | Research and development |  | $ | 114 |  |  | $ | 99 |  |  | $ | 74 |  |
|  | Sales, general and administrative |  | $ | 60 |  |  | $ | 51 |  |  | $ | 47 |  |
| (B) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-19-000077:8k_2_02:70]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2020 Outlook |
| GAAP gross margin |  | 59.2 | % |
|  | Impact of stock-based compensation expense |  | 0.3 | % |
| Non-GAAP gross margin |  | 59.5 | % |
|  |  |  | Q2 FY2020 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 985 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (220 | ) |
| Non-GAAP operating expenses |  | $ | 765 |  |
