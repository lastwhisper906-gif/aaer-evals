# NVDA notes — 0001045810-19-000079


## nvda:BalanceSheetComponentsTextBlock

[0001045810-19-000079:notes:1]
[same as prior period, unchanged from 0001045810-18-000150:notes:1]

[0001045810-19-000079:notes:2]
[same as prior period, unchanged from 0001045810-18-000150:notes:2]

[0001045810-19-000079:notes:3]
|  | April 28, |  | January 27, |
|  | 2019 |  | 2019 |
| Inventories: | (In millions) |
| Raw materials | $ | 484 |  |  | $ | 613 |  |
| Work in-process | 189 |  |  | 238 |  |
| Finished goods | 753 |  |  | 724 |  |
| Total inventories | $ | 1,426 |  |  | $ | 1,575 |  |

[0001045810-19-000079:notes:4]
|  | April 28, |  | January 27, |
|  | 2019 |  | 2019 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 263 |  |  | $ | 302 |  |
| Accrued payroll and related expenses | 136 |  |  | 186 |  |
| Taxes payable | 107 |  |  | 91 |  |
| Deferred revenue (1) | 85 |  |  | 92 |  |
| Operating lease liabilities | 80 |  |  | — |  |
| Accrued legal settlement costs | 25 |  |  | 24 |  |
| Licenses payable | 23 |  |  | 12 |  |
| Warranty accrual (2) | 18 |  |  | 18 |  |
| Professional service fees | 10 |  |  | 14 |  |
| Coupon interest on debt obligations | 7 |  |  | 20 |  |
| Accrued royalties | 6 |  |  | 10 |  |
| Other | 55 |  |  | 49 |  |
| Total accrued and other current liabilities | $ | 815 |  |  | $ | 818 |  |

[0001045810-19-000079:notes:5]
| (1) | Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and post contract customer support, or PCS. |

[0001045810-19-000079:notes:6]
| (2) | Refer to Note 13 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding warranties. |

[0001045810-19-000079:notes:7]
|  | April 28, |  | January 27, |
|  | 2019 |  | 2019 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 524 |  |  | $ | 513 |  |
| Deferred revenue (2) | 49 |  |  | 46 |  |
| Licenses payable | 34 |  |  | 1 |  |
| Employee benefits liability | 21 |  |  | 20 |  |
| Deferred income tax liability | 21 |  |  | 19 |  |
| Deferred rent | — |  |  | 21 |  |
| Other | 11 |  |  | 13 |  |
| Total other long-term liabilities | $ | 660 |  |  | $ | 633 |  |

[0001045810-19-000079:notes:8]
| (1) | As of April 28, 2019, represents the long-term portion of the one-time transition tax payable of $351 million, as well as unrecognized tax benefits of $151 million and related interest and penalties of $22 million. |

[0001045810-19-000079:notes:9]
| (2) | Deferred revenue primarily includes deferrals related to PCS. |

[0001045810-19-000079:notes:10]
Deferred Revenue

[0001045810-19-000079:notes:11]
The following table shows the changes in deferred revenue during the first quarter of fiscal years 2020 and 2019.

[0001045810-19-000079:notes:12]
|  | April 28, |  | April 29, |
|  | 2019 |  | 2018 |
|  | (In millions) |
| Balance at beginning of period | $ | 138 |  |  | $ | 63 |  |
| Deferred revenue added during the period | 49 |  |  | 86 |  |
| Revenue recognized during the period | (53 | ) |  | (75 | ) |
| Balance at end of period | $ | 134 |  |  | $ | 74 |  |


## nvda:OtherInformationRelatedtoLeasesTableTextBlock

[0001045810-19-000079:notes:13]
Other information related to leases was as follows:

[0001045810-19-000079:notes:14]
|  | Three Months Ended |
|  | April 28, 2019 |
|  | (In millions) |
| Supplemental cash flows information |  |
| Operating cash flows used for operating leases | $ | 24 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 87 |  |
| Weighted-average remaining lease term - operating leases | 8.9 years |  |
| Weighted-average remaining discount rate - operating leases | 3.73 | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-19-000079:notes:15]
[same as prior period, unchanged from 0001045810-18-000150:notes:28]

[0001045810-19-000079:notes:16]
|  | Three Months Ended |
|  | April 28, |  | April 29, |
|  | 2019 |  | 2018 |
|  | (In millions) |
| Revenue: |  |  |  |
| Gaming | $ | 1,055 |  |  | $ | 1,723 |  |
| Professional Visualization | 266 |  |  | 251 |  |
| Data Center | 634 |  |  | 701 |  |
| Automotive | 166 |  |  | 145 |  |
| OEM and Other | 99 |  |  | 387 |  |
| Total revenue | $ | 2,220 |  |  | $ | 3,207 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001045810-19-000079:notes:17]
[same as prior period, unchanged from 0001045810-18-000150:notes:32]

[0001045810-19-000079:notes:18]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 27, 2019 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-19-000079:notes:19]
Merger Agreement with Mellanox Technologies, Ltd.

[0001045810-19-000079:notes:20]
On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox Technologies Ltd, or Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. The closing of the merger is subject to certain conditions, including the approval by Mellanox shareholders and various regulatory agencies. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-19-000079:notes:21]
Commitments and Contingencies

[0001045810-19-000079:notes:22]
Inventory Purchase Obligations

[0001045810-19-000079:notes:23]
As of April 28, 2019, we had outstanding inventory purchase obligations totaling $782 million.

[0001045810-19-000079:notes:24]
Capital Purchase Obligations

[0001045810-19-000079:notes:25]
As of April 28, 2019, we had outstanding capital purchase obligations totaling $194 million.

[0001045810-19-000079:notes:26]
Performance Obligations

[0001045810-19-000079:notes:27]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of April 28, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $294 million, of which we expect to recognize approximately 57% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-19-000079:notes:28]
Accrual for Product Warranty Liabilities

[0001045810-19-000079:notes:29]
The estimated amount of product returns and warranty liabilities was $18 million as of both April 28, 2019 and January 27, 2019.

[0001045810-19-000079:notes:30]
In connection with certain agreements that we have entered in the past, we have provided indemnification to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-19-000079:notes:31]
Litigation

[0001045810-19-000079:notes:32]
Polaris Innovations Limited

[0001045810-19-000079:notes:33]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States and Germany.

[0001045810-19-000079:notes:34]
NVIDIA and Polaris entered into an agreement effective April 3, 2019 that settled the litigation between the parties, which had an immaterial impact on our financial results. The agreement includes a license to NVIDIA for certain patents owned by Polaris, as well as options for NVIDIA to renew the license through the life of the patents.

[0001045810-19-000079:notes:35]
ZiiLabs 1 Patents Lawsuit

[0001045810-19-000079:notes:36]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA had infringed and was continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint sought unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 1 Patents.

[0001045810-19-000079:notes:37]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the U.S. International Trade Commission, or USITC, investigation over the ZiiLabs 2 patents.

[0001045810-19-000079:notes:38]
On February 1, 2019, NVIDIA entered into an agreement in which it received a license to the ZiiLabs patents and a dismissal of the ZiiLabs 1 and 2 Patent Lawsuits, which had an immaterial impact on our financial results. The ZiiLabs 1 and 2 district court cases were dismissed pursuant to a stipulation of dismissal filed on February 8, 2019. The Administrative Law Judge issued an Initial Determination on February 12, 2019, granting the motion to terminate the USITC investigation addressing the ZiiLabs 2 patents.

[0001045810-19-000079:notes:39]
ZiiLabs 2 Patents Lawsuits

[0001045810-19-000079:notes:40]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also sought unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 2 Patents.

[0001045810-19-000079:notes:41]
On December 29, 2017, ZiiLabs filed a request with the USITC to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleged that the unlawful importation resulted from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

[0001045810-19-000079:notes:42]
Securities Class Action and Derivative Lawsuits

[0001045810-19-000079:notes:43]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. The complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between August 10, 2017 and November 15, 2018. The plaintiff also alleges that the NVIDIA officers who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiff seeks class certification, an award of unspecified compensatory damages, an award of equitable/injunctive or other further relief as the Court may deem just and proper. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief.  On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiff and lead counsel.

[0001045810-19-000079:notes:44]
On January 18, 2019, a shareholder, purporting to act on the behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-19-000079:notes:45]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming us and/or our officers and directors as defendants.

[0001045810-19-000079:notes:46]
Litigation Related to Mellanox Merger

[0001045810-19-000079:notes:47]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Securities Exchange Act of 1934 and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but to date, NVIDIA has not been named as a defendant in any of these other lawsuits.

[0001045810-19-000079:notes:48]
Accounting for Loss Contingencies

[0001045810-19-000079:notes:49]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of April 28, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-19-000079:notes:50]
[same as prior period, unchanged from 0001045810-18-000150:notes:58]

[0001045810-19-000079:notes:51]
[same as prior period, unchanged from 0001045810-18-000150:notes:59]


## us-gaap:DebtDisclosureTextBlock

[0001045810-19-000079:notes:52]
Debt

[0001045810-19-000079:notes:53]
Long-Term Debt

[0001045810-19-000079:notes:54]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-19-000079:notes:55]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-19-000079:notes:56]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-19-000079:notes:57]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-19-000079:notes:58]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (12 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,988 |  |  | $ | 1,988 |  |

[0001045810-19-000079:notes:59]
Revolving Credit Facility

[0001045810-19-000079:notes:60]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 28, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000079:notes:61]
Commercial Paper

[0001045810-19-000079:notes:62]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2019, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-19-000079:notes:63]
The following is a summary of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019:

[0001045810-19-000079:notes:64]
|  | April 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,899 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 2,899 |  |  | $ | 1,048 |  |  | $ | 1,851 |  |
| Debt securities of United States government agencies | 1,882 |  |  | — |  |  | (1 | ) |  | 1,881 |  |  | — |  |  | 1,881 |  |
| Debt securities issued by the United States Treasury | 1,833 |  |  | — |  |  | — |  |  | 1,833 |  |  | 932 |  |  | 901 |  |
| Money market funds | 681 |  |  | — |  |  | — |  |  | 681 |  |  | 681 |  |  | — |  |
| Foreign government bonds | 183 |  |  | — |  |  | — |  |  | 183 |  |  | — |  |  | 183 |  |
| Asset-backed securities | 133 |  |  | — |  |  | (1 | ) |  | 132 |  |  | — |  |  | 132 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 81 |  |  | 1 |  |  | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total | $ | 7,692 |  |  | $ | 3 |  |  | $ | (4 | ) |  | $ | 7,691 |  |  | $ | 2,661 |  |  | $ | 5,030 |  |

[0001045810-19-000079:notes:65]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

[0001045810-19-000079:notes:66]
The following table provides the breakdown of unrealized losses as of April 28, 2019, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-19-000079:notes:67]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,429 |  |  | $ | — |  |  | $ | 306 |  |  | $ | (1 | ) |  | $ | 1,735 |  |  | $ | (1 | ) |
| Corporate debt securities | 330 |  |  | (1 | ) |  | 453 |  |  | (1 | ) |  | 783 |  |  | (2 | ) |
| Asset-backed securities | — |  |  | — |  |  | 132 |  |  | (1 | ) |  | 132 |  |  | (1 | ) |
| Total | $ | 1,759 |  |  | $ | (1 | ) |  | $ | 891 |  |  | $ | (3 | ) |  | $ | 2,650 |  |  | $ | (4 | ) |

[0001045810-19-000079:notes:68]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of April 28, 2019 and January 27, 2019 are shown below by contractual maturity.

[0001045810-19-000079:notes:69]
|  | April 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,773 |  |  | $ | 5,770 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 1,896 |  |  | 1,898 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 23 |  |  | 23 |  |  | 22 |  |  | 22 |  |
| Total | $ | 7,692 |  |  | $ | 7,691 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-19-000079:notes:70]
[same as prior period, unchanged from 0001045810-18-000150:notes:79]

[0001045810-19-000079:notes:71]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of April 28, 2019 and January 27, 2019.

[0001045810-19-000079:notes:72]
[same as prior period, unchanged from 0001045810-18-000150:notes:81]

[0001045810-19-000079:notes:73]
The table below presents the notional value of our foreign currency forward contracts outstanding as of April 28, 2019 and January 27, 2019:

[0001045810-19-000079:notes:74]
|  | April 28, 2019 |  | January 27, 2019 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 411 |  |  | $ | 408 |  |
| Not designated for hedge accounting | $ | 253 |  |  | $ | 241 |  |

[0001045810-19-000079:notes:75]
As of April 28, 2019, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-19-000079:notes:76]
During the first quarter of fiscal years 2020 and 2019, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-19-000079:notes:77]
[same as prior period, unchanged from 0001045810-18-000150:notes:86]

[0001045810-19-000079:notes:78]
[same as prior period, unchanged from 0001045810-18-000150:notes:87]

[0001045810-19-000079:notes:79]
[same as prior period, unchanged from 0001045810-18-000150:notes:88]

[0001045810-19-000079:notes:80]
|  | Three Months Ended |
|  | April 28, 2019 |  | April 29, 2018 |
|  | (In millions) |
| Cost of revenue | $ | 4 |  |  | $ | 8 |  |
| Research and development | 114 |  |  | 74 |  |
| Sales, general and administrative | 60 |  |  | 47 |  |
| Total | $ | 178 |  |  | $ | 129 |  |

[0001045810-19-000079:notes:81]
[same as prior period, unchanged from 0001045810-18-000150:notes:90]

[0001045810-19-000079:notes:82]
[same as prior period, unchanged from 0001045810-18-000150:notes:91]

[0001045810-19-000079:notes:83]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balances, January 27, 2019 | 16 |  |  | $ | 129.92 |  |
| Granted (1) (2) | 6 |  |  | $ | 183.83 |  |
| Vested restricted stock | (3 | ) |  | $ | 53.97 |  |
| Canceled and forfeited | (1 | ) |  | $ | 191.92 |  |
| Balances, April 28, 2019 | 18 |  |  | $ | 159.28 |  |

[0001045810-19-000079:notes:84]
| (1) | Includes the number of PSUs granted that will be issued and eligible to vest if the maximum corporate financial performance goal for fiscal year 2020 is achieved. Depending on the actual level of the corporate performance achievement at the end of fiscal year 2020, the PSUs issued could be up to 0.4 million shares. |

[0001045810-19-000079:notes:85]
| (2) | Includes the number of market-based PSUs granted that will be issued and eligible to vest if the maximum goal for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to those of the companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 60 thousand shares. |

[0001045810-19-000079:notes:86]
Of the total fair value of equity awards granted during the first quarter of fiscal year 2020, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $85 million.

[0001045810-19-000079:notes:87]
As of April 28, 2019, there was $2.27 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.7 years for RSUs, PSUs, and market-based PSUs, and 1.3 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-19-000079:notes:88]
[same as prior period, unchanged from 0001045810-18-000150:notes:96]

[0001045810-19-000079:notes:89]
[same as prior period, unchanged from 0001045810-18-000150:notes:97]

[0001045810-19-000079:notes:90]
|  | Three Months Ended |
|  | April 28, |  | April 29, |
|  | 2019 |  | 2018 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |
| Net income | $ | 394 |  |  | $ | 1,244 |  |
| Denominator: |  |  |  |
| Basic weighted average shares | 607 |  |  | 606 |  |
| Dilutive impact of outstanding securities: |  |  |  |
| Equity awards | 9 |  |  | 20 |  |
| 1.00% Convertible Senior Notes | — |  |  | 1 |  |
| Diluted weighted average shares | 616 |  |  | 627 |  |
| Net income per share: |  |  |  |
| Basic (1) | $ | 0.65 |  |  | $ | 2.05 |  |
| Diluted (2) | $ | 0.64 |  |  | $ | 1.98 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 11 |  |  | 1 |  |

[0001045810-19-000079:notes:91]
[same as prior period, unchanged from 0001045810-18-000150:notes:99]

[0001045810-19-000079:notes:92]
[same as prior period, unchanged from 0001045810-18-000150:notes:100]


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-19-000079:notes:93]
|  |  | Fair Value at |
|  | Pricing Category |  | April 28, 2019 |  | January 27, 2019 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 2,899 |  |  | $ | 2,620 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,881 |  |  | $ | 2,280 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 1,833 |  |  | $ | 1,492 |  |
| Money market funds | Level 1 |  | $ | 681 |  |  | $ | 483 |  |
| Foreign government bonds | Level 2 |  | $ | 183 |  |  | $ | 209 |  |
| Asset-backed securities | Level 2 |  | $ | 132 |  |  | $ | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 82 |  |  | $ | 89 |  |
| Liabilities |  |  |  |  |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 989 |  |  | $ | 978 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 997 |  |  | $ | 961 |  |

[0001045810-19-000079:notes:94]
[same as prior period, unchanged from 0001045810-18-000150:notes:104]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-19-000079:notes:95]
[same as prior period, unchanged from 0001045810-18-000150:notes:105]

[0001045810-19-000079:notes:96]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 financial assets and liabilities for the first quarter of fiscal year 2020. Level 3 financial assets and liabilities are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-19-000079:notes:97]
[same as prior period, unchanged from 0001045810-18-000150:notes:107]

[0001045810-19-000079:notes:98]
We recognized an income tax benefit of $5 million for the first quarter of fiscal year 2020 and income tax expense of $67 million for the first quarter of fiscal year 2019. The income tax benefit as a percentage of income before income tax was 1.3% for the first quarter of fiscal year 2020 and income tax expense as a percentage of income before tax was 5.1% for the first quarter of fiscal year 2019.

[0001045810-19-000079:notes:99]
The decrease in our effective tax rate for the first quarter of fiscal year 2020 as compared to the same period in the prior fiscal year was primarily due to a decrease in the amount of earnings subject to United States tax, and an increase in the impact of tax benefits from stock-based compensation and the U.S. federal research tax credit.

[0001045810-19-000079:notes:100]
Our effective tax rates for the first quarter of fiscal years 2020 and 2019 were (1.3)% and 5.1%, respectively, and were lower than the U.S. federal statutory rate of 21%, due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-19-000079:notes:101]
For the first quarter of fiscal year 2020, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 27, 2019.

[0001045810-19-000079:notes:102]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 28, 2019, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-19-000079:notes:103]
[same as prior period, unchanged from 0001045810-18-000150:notes:115]

[0001045810-19-000079:notes:104]
[same as prior period, unchanged from 0001045810-18-000150:notes:116]

[0001045810-19-000079:notes:105]
|  | April 28, 2019 |  | January 27, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (188 | ) |  | $ | 7 |  |  | $ | 195 |  |  | $ | (188 | ) |  | $ | 7 |  |
| Patents and licensed technology | 507 |  |  | (460 | ) |  | 47 |  |  | 491 |  |  | (453 | ) |  | 38 |  |
| Total intangible assets | $ | 702 |  |  | $ | (648 | ) |  | $ | 54 |  |  | $ | 686 |  |  | $ | (641 | ) |  | $ | 45 |  |

[0001045810-19-000079:notes:106]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during the first quarter of fiscal year 2020. Amortization expense associated with intangible assets was $7 million and $11 million for the first quarter of fiscal years 2020 and 2019, respectively. Future amortization expense related to the net carrying amount of intangible assets as of April 28, 2019 is estimated to be $18 million for the remainder of fiscal year 2020, $17 million in fiscal year 2021, $9 million in fiscal year 2022, $7 million in fiscal year 2023, and $3 million in fiscal year 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-19-000079:notes:107]
Marketable Securities

[0001045810-19-000079:notes:108]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-19-000079:notes:109]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For the first quarter of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001045810-19-000079:notes:110]
Leases

[0001045810-19-000079:notes:111]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

[0001045810-19-000079:notes:112]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0001045810-19-000079:notes:113]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001045810-19-000079:notes:114]
Future minimum lease payments under our non-cancelable operating leases as of April 28, 2019, are as follows:

[0001045810-19-000079:notes:115]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2020 (excluding first quarter of fiscal year 2020) | $ | 77 |  |
| 2021 | 100 |  |
| 2022 | 92 |  |
| 2023 | 79 |  |
| 2024 | 57 |  |
| 2025 and thereafter | 277 |  |
| Total | 682 |  |
| Less imputed interest | 116 |  |
| Present value of net future minimum lease payments | 566 |  |
| Less short-term operating lease liabilities | 80 |  |
| Long-term operating lease liabilities | $ | 486 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-19-000079:notes:116]
New Lease Accounting Standard

[0001045810-19-000079:notes:117]
Method and Impact of Adoption

[0001045810-19-000079:notes:118]
On January 28, 2019, we adopted the new lease accounting standard using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet and not adjusting comparative information for prior periods. In addition, we elected the package of practical expedients permitted under the transition guidance, which allowed us not to reassess (1) whether any expired or existing contracts are or contain leases, (2) lease classification for any expired or existing leases, and (3) initial direct costs for any existing leases.

[0001045810-19-000079:notes:119]
The cumulative-effect adjustment upon adoption of the new lease accounting standard resulted in the recognition of $470 million of operating lease assets and $500 million of operating lease liabilities on our Consolidated Balance Sheet. The difference of $30 million represents deferred rent for leases that existed as of the date of adoption, which was an offset to the opening balance of operating lease assets.

[0001045810-19-000079:notes:120]
Lease Obligations

[0001045810-19-000079:notes:121]
Our lease obligations consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between 2019 and 2035.

[0001045810-19-000079:notes:122]
Future minimum lease payments under our non-cancelable operating leases as of January 27, 2019, based on the previous lease accounting standard, are as follows:

[0001045810-19-000079:notes:123]
|  | Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2020 | $ | 100 |  |
| 2021 | 97 |  |
| 2022 | 90 |  |
| 2023 | 77 |  |
| 2024 | 54 |  |
| 2025 and thereafter | 265 |  |
| Total | $ | 683 |  |

[0001045810-19-000079:notes:124]
Operating lease expense for the first quarter of fiscal years 2020 and 2019 was $27 million and $16 million, respectively. Short-term and variable lease expenses for the first quarter of fiscal year 2020 were not significant.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-19-000079:notes:125]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000079:notes:126]
Recently Adopted Accounting Pronouncement

[0001045810-19-000079:notes:127]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases under which lease assets and liabilities are recognized on the balance sheet. We adopted this guidance on January 28, 2019 using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet. Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-19-000079:notes:128]
Recent Accounting Pronouncement Not Yet Adopted

[0001045810-19-000079:notes:129]
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. The standard will be effective for us beginning in the first quarter of fiscal year 2021, with early adoption permitted. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-19-000079:notes:130]
|  | Three Months Ended |
|  | April 28, 2019 |  | April 29, 2018 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |
| Stock-based compensation expense | $ | (178 | ) |  | $ | (129 | ) |
| Unallocated cost of revenue and operating expenses | (68 | ) |  | (63 | ) |
| Legal settlement costs | (11 | ) |  | (2 | ) |
| Acquisition-related and other costs | (10 | ) |  | (2 | ) |
| Total | $ | (267 | ) |  | $ | (196 | ) |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-19-000079:notes:131]
[same as prior period, unchanged from 0001045810-18-000150:notes:141]

[0001045810-19-000079:notes:132]
|  | Three Months Ended |
|  | April 28, |  | April 29, |
|  | 2019 |  | 2018 |
|  | (In millions) |
| Revenue: |  |  |  |
| Taiwan | $ | 698 |  |  | $ | 967 |  |
| China (including Hong Kong) | 553 |  |  | 754 |  |
| Other Asia Pacific | 422 |  |  | 583 |  |
| Europe | 249 |  |  | 235 |  |
| United States | 165 |  |  | 434 |  |
| Other countries | 133 |  |  | 234 |  |
| Total revenue | $ | 2,220 |  |  | $ | 3,207 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-19-000079:notes:133]
[same as prior period, unchanged from 0001045810-18-000150:notes:143]

[0001045810-19-000079:notes:134]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended April 28, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 2,022 |  |  | $ | 198 |  |  | $ | — |  |  | $ | 2,220 |  |
| Depreciation and amortization expense | $ | 76 |  |  | $ | 12 |  |  | $ | 3 |  |  | $ | 91 |  |
| Operating income (loss) | $ | 669 |  |  | $ | (44 | ) |  | $ | (267 | ) |  | $ | 358 |  |
| Three Months Ended April 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,765 |  |  | $ | 442 |  |  | $ | — |  |  | $ | 3,207 |  |
| Depreciation and amortization expense | $ | 40 |  |  | $ | 10 |  |  | $ | 7 |  |  | $ | 57 |  |
| Operating income (loss) | $ | 1,394 |  |  | $ | 97 |  |  | $ | (196 | ) |  | $ | 1,295 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-19-000079:notes:135]
[same as prior period, unchanged from 0001045810-18-000150:notes:145]

[0001045810-19-000079:notes:136]
[same as prior period, unchanged from 0001045810-18-000150:notes:146]

[0001045810-19-000079:notes:137]
[same as prior period, unchanged from 0001045810-18-000150:notes:147]

[0001045810-19-000079:notes:138]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for artificial intelligence, data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for game consoles and mobile gaming and entertainment devices.

[0001045810-19-000079:notes:139]
[same as prior period, unchanged from 0001045810-18-000150:notes:149]

[0001045810-19-000079:notes:140]
[same as prior period, unchanged from 0001045810-18-000150:notes:150]

[0001045810-19-000079:notes:141]
[same as prior period, unchanged from 0001045810-18-000150:notes:151]

[0001045810-19-000079:notes:142]
[same as prior period, unchanged from 0001045810-18-000150:notes:152]

[0001045810-19-000079:notes:143]
Revenue from significant customers, those representing 10% or more of total revenue, was approximately 11%  of our total revenue from one customer for the first quarter of fiscal year 2020, and aggregated approximately 20% of our total revenue from two customers for the first quarter of fiscal year 2019, and was attributable primarily to the GPU business.

[0001045810-19-000079:notes:144]
Accounts receivable from significant customers, those representing more than 10% of total accounts receivable, aggregated approximately 21% of our accounts receivable balance from one customer as of April 28, 2019, and approximately 19% of our accounts receivable balance from one customer as of January 27, 2019.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-19-000079:notes:145]
[same as prior period, unchanged from 0001045810-18-000150:notes:155]

[0001045810-19-000079:notes:146]
[same as prior period, unchanged from 0001045810-18-000150:notes:156]

[0001045810-19-000079:notes:147]
Except for the accounting policy for leases, which was updated as a result of adopting a new accounting standard related to leases, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.

[0001045810-19-000079:notes:148]
Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-19-000079:notes:149]
[same as prior period, unchanged from 0001045810-18-000150:notes:158]

[0001045810-19-000079:notes:150]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The first quarters of fiscal years 2020 and 2019 were both 13-week quarters.

[0001045810-19-000079:notes:151]
[same as prior period, unchanged from 0001045810-18-000150:notes:160]

[0001045810-19-000079:notes:152]
[same as prior period, unchanged from 0001045810-18-000150:notes:161]

[0001045810-19-000079:notes:153]
[same as prior period, unchanged from 0001045810-18-000150:notes:162]

[0001045810-19-000079:notes:154]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-19-000079:notes:155]
[same as prior period, unchanged from 0001045810-18-000150:notes:164]

[0001045810-19-000079:notes:156]
[same as prior period, unchanged from 0001045810-18-000150:notes:165]

[0001045810-19-000079:notes:157]
[same as prior period, unchanged from 0001045810-18-000150:notes:166]

[0001045810-19-000079:notes:158]
During the first quarter of fiscal year 2020, we paid $97 million in cash dividends to our shareholders.

[0001045810-19-000079:notes:159]
Through April 28, 2019, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of April 28, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000079:notes:160]
[same as prior period, unchanged from 0001045810-18-000150:notes:170]

[0001045810-19-000079:notes:161]
As of April 28, 2019 and January 27, 2019, there were no shares of preferred stock outstanding.

[0001045810-19-000079:notes:162]
[same as prior period, unchanged from 0001045810-18-000150:notes:172]

[0001045810-19-000079:notes:163]
[same as prior period, unchanged from 0001045810-18-000150:notes:173]
