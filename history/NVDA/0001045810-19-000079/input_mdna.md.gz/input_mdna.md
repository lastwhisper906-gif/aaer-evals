# NVDA MD&A — 0001045810-19-000079


## mdna

[0001045810-19-000079:mdna:1]
[same as prior period, unchanged from 0001045810-18-000150:mdna:1]

[0001045810-19-000079:mdna:2]
[same as prior period, unchanged from 0001045810-18-000150:mdna:2]

[0001045810-19-000079:mdna:3]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-19-000079:mdna:4]
NVIDIA, the NVIDIA logo, CUDA, CUDA-X AI, GeForce, GeForce GTX, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Constellation, NVIDIA GRID, NVIDIA Omniverse, NVIDIA RTX, Quadro, Quadro RTX, Tegra and Tesla are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000079:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 6. Selected Financial Data” of our Annual Report on Form 10-K for the fiscal year ended January 27, 2019 and “Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-19-000079:mdna:6]
[same as prior period, unchanged from 0001045810-18-000150:mdna:6]

[0001045810-19-000079:mdna:7]
[same as prior period, unchanged from 0001045810-18-000150:mdna:7]

[0001045810-19-000079:mdna:8]
[same as prior period, unchanged from 0001045810-18-000150:mdna:8]

[0001045810-19-000079:mdna:9]
Our two reportable segments - GPU and Tegra Processor - are based on a single underlying architecture. From our proprietary processors, we have created platforms that address four large markets where our expertise is critical: Gaming, Professional Visualization, Data Center, and Automotive.

[0001045810-19-000079:mdna:10]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for consoles and mobile gaming and entertainment devices.

[0001045810-19-000079:mdna:11]
[same as prior period, unchanged from 0001045810-18-000150:mdna:11]

[0001045810-19-000079:mdna:12]
[same as prior period, unchanged from 0001045810-18-000150:mdna:12]

[0001045810-19-000079:mdna:13]
First Quarter of Fiscal Year 2020 Summary

[0001045810-19-000079:mdna:14]
|  | Three Months Ended |  |  |  |  |
|  | April 28, 2019 |  | January 27, 2019 |  | April 29, 2018 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 2,220 |  |  | $ | 2,205 |  |  | $ | 3,207 |  |  | 1 | % |  | (31 | )% |
| Gross margin | 58.4 | % |  | 54.7 | % |  | 64.5 | % |  | 370 bps |  |  | (610) bps |  |
| Operating expenses | $ | 938 |  |  | $ | 913 |  |  | $ | 773 |  |  | 3 | % |  | 21 | % |
| Income from operations | $ | 358 |  |  | $ | 294 |  |  | $ | 1,295 |  |  | 22 | % |  | (72 | )% |
| Net income | $ | 394 |  |  | $ | 567 |  |  | $ | 1,244 |  |  | (31 | )% |  | (68 | )% |
| Net income per diluted share | $ | 0.64 |  |  | $ | 0.92 |  |  | $ | 1.98 |  |  | (30 | )% |  | (68 | )% |

[0001045810-19-000079:mdna:15]
Revenue for the first quarter of fiscal year 2020 decreased 31% year over year and increased 1% sequentially.

[0001045810-19-000079:mdna:16]
GPU business revenue was $2.02 billion, down 27% from a year earlier and up 2% sequentially. The year-on-year decrease reflects declines in gaming and data center revenue, as well as the absence of $289 million of OEM revenue from cryptocurrency mining processors, or CMP.

[0001045810-19-000079:mdna:17]
Tegra Processor business revenue - which includes automotive, SOC modules for gaming platforms, and embedded edge AI platforms - was $198 million, down 55% from a year ago and down 12% sequentially. The year-on-year decrease primarily reflects a decline in shipments of SOC modules for gaming platforms.

[0001045810-19-000079:mdna:18]
Gaming revenue was $1.05 billion, down 39% from a year ago and up 11% sequentially. The year-on-year decrease primarily reflects a decline in shipments of gaming GPUs and SOC modules for gaming platforms. The sequential increase primarily reflects growth in gaming GPUs. We believe a shortage of Intel processors that is impacting the global PC market will affect our sales of gaming GPUs for laptops in the second quarter of fiscal year 2020.

[0001045810-19-000079:mdna:19]
Professional Visualization revenue was $266 million, up 6% from a year earlier and down 9% sequentially. The year-on-year increase reflects strength across both desktop and mobile workstation products. The sequential decrease largely reflects a seasonal decline.

[0001045810-19-000079:mdna:20]
Data Center revenue was $634 million, down 10% from a year ago and down 7% sequentially, primarily reflecting a slowdown in purchases by certain hyperscale and enterprise customers, partially offset by growth in inference sales. We believe this slowdown in purchases will likely persist into the second quarter of fiscal year 2020.

[0001045810-19-000079:mdna:21]
Automotive revenue of $166 million was up 14% from a year earlier and up 2% sequentially, primarily reflecting growth in AI cockpit modules.

[0001045810-19-000079:mdna:22]
OEM and Other revenue was $99 million, down 74% from a year ago and down 15% sequentially. The year-on-year decrease is primarily due to the absence of $289 million from CMP sales.

[0001045810-19-000079:mdna:23]
Gross margin for the first quarter of fiscal year 2020 was 58.4%, down 610 basis points from a year earlier and up 370 basis points sequentially. The year-on-year decrease reflects lower gaming margins and mix shifts across the portfolio. The sequential increase reflects the absence of approximately $128 million in charges recorded in the fourth quarter of fiscal year 2019 for excess DRAM, boards, and other components.

[0001045810-19-000079:mdna:24]
Operating expenses for the first quarter of fiscal year 2020 were $938 million, up 21% from a year earlier and up 3% sequentially, reflecting primarily employee additions and increases in employee compensation and other related costs, including infrastructure costs.

[0001045810-19-000079:mdna:25]
Income from operations for the first quarter of fiscal year 2020 was $358 million, down 72% from a year earlier and up 22% sequentially. Net income and net income per diluted share for the first quarter of fiscal year 2020 were $394 million and $0.64, respectively, both down 68% from a year earlier. The year-on-year decrease reflects lower revenue and gross margin, and higher operating expenses. The sequential decrease reflects U.S. tax reform benefits recognized in the fourth quarter of fiscal year 2019.

[0001045810-19-000079:mdna:26]
24

[0001045810-19-000079:mdna:27]
As previously communicated, we intend to return $3.00 billion to shareholders by the end of fiscal year 2020, including $700 million in share repurchases made during the fourth quarter of fiscal year 2019. In the first quarter of fiscal year 2020, we returned $97 million in quarterly cash dividends. We intend to return the remaining $2.20 billion by the end of fiscal year 2020, through a combination of share repurchases and cash dividends.

[0001045810-19-000079:mdna:28]
Cash, cash equivalents and marketable securities were $7.80 billion as of April 28, 2019, compared with $7.42 billion as of January 27, 2019. The increase was primarily related to operating income and changes in working capital.

[0001045810-19-000079:mdna:29]
On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox Technologies Ltd, or Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. The closing of the merger is subject to certain conditions, including the approval by Mellanox shareholders and various regulatory agencies. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million.

[0001045810-19-000079:mdna:30]
[same as prior period, unchanged from 0001045810-18-000150:mdna:26]

[0001045810-19-000079:mdna:31]
During the first quarter of fiscal year 2020, we introduced the GeForce GTX 1660 Ti, GTX 1660 and GTX 1650 gaming GPUs with improved performance and efficiency for today’s most popular games; announced a number of gaming laptop models based on Turing GPUs from top makers; and announced that real-time ray tracing is now integrated into Unreal Engine and Unity commercial game engines.

[0001045810-19-000079:mdna:32]
For our professional visualization platform, we announced expanded adoption of NVIDIA RTX ray-tracing technology by top 3D application providers and unveiled the NVIDIA Omniverse open-collaboration platform to simplify creative workflows for content creation.

[0001045810-19-000079:mdna:33]
For our data center platform, we introduced the NVIDIA CUDA-X AI platform for accelerating data science; announced availability of NVIDIA T4 Tensor Core GPUs from leading OEMs and Amazon Web Services; partnered with global system builders to create powerful data-science workstations integrating NVIDIA Quadro RTX GPUs and NVIDIA CUDA-X AI; and launched beta access to NVIDIA Quadro Virtual Workstation software in the Alibaba Cloud Marketplace.

[0001045810-19-000079:mdna:34]
[same as prior period, unchanged from 0001045810-18-000150:mdna:30]

[0001045810-19-000079:mdna:35]
During the first quarter of fiscal year 2020, for the automotive market, we announced that we are partnering with Toyota Research Institute-Advanced Development to develop, train and validate self-driving vehicles; unveiled the NVIDIA DRIVE AP2X automated driving solution, encompassing DRIVE AutoPilot software, DRIVE AGX and DRIVE validation tools;  introduced NVIDIA DRIVE AV Safety Force Field to enable safe, comfortable driving experiences; and announced availability of the NVIDIA DRIVE Constellation autonomous vehicle simulation platform.

[0001045810-19-000079:mdna:36]
[same as prior period, unchanged from 0001045810-18-000150:mdna:34]

[0001045810-19-000079:mdna:37]
[same as prior period, unchanged from 0001045810-18-000150:mdna:35]

[0001045810-19-000079:mdna:38]
[same as prior period, unchanged from 0001045810-18-000150:mdna:37]

[0001045810-19-000079:mdna:39]
[same as prior period, unchanged from 0001045810-18-000150:mdna:38]

[0001045810-19-000079:mdna:40]
|  | Three Months Ended |
|  | April 28, 2019 |  | April 29, 2018 |
| Revenue | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 41.6 |  |  | 35.5 |  |
| Gross profit | 58.4 |  |  | 64.5 |  |
| Operating expenses |  |  |  |  |
| Research and development | 30.4 |  |  | 16.9 |  |
| Sales, general and administrative | 11.9 |  |  | 7.2 |  |
| Total operating expenses | 42.3 |  |  | 24.1 |  |
| Income from operations | 16.1 |  |  | 40.4 |  |
| Interest income | 2.0 |  |  | 0.8 |  |
| Interest expense | (0.6 | ) |  | (0.5 | ) |
| Other, net | — |  |  | 0.2 |  |
| Total other income (expense) | 1.4 |  |  | 0.5 |  |
| Income before income tax | 17.5 |  |  | 40.9 |  |
| Income tax expense (benefit) | (0.2 | ) |  | 2.1 |  |
| Net income | 17.7 | % |  | 38.8 | % |

[0001045810-19-000079:mdna:41]
[same as prior period, unchanged from 0001045810-18-000150:mdna:40]

[0001045810-19-000079:mdna:42]
[same as prior period, unchanged from 0001045810-18-000150:mdna:41]

[0001045810-19-000079:mdna:43]
|  | Three Months Ended |
|  | April 28, 2019 |  | April 29, 2018 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,022 |  |  | $ | 2,765 |  |  | $ | (743 | ) |  | (27 | )% |
| Tegra Processor | 198 |  |  | 442 |  |  | (244 | ) |  | (55 | )% |
| Total | $ | 2,220 |  |  | $ | 3,207 |  |  | $ | (987 | ) |  | (31 | )% |

[0001045810-19-000079:mdna:44]
GPU Business. GPU business revenue decreased by 27% in the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019, which reflects declines in gaming GPU and data center revenue, as well as the absence of $289 million of revenue from cryptocurrency mining processors. GeForce GPU product sales for gaming decreased 28%. Data center revenue, including Tesla, GRID and DGX, decreased 10%, primarily reflecting a slowdown in certain hyperscale and enterprise customer purchases, partially offset by growth in inference sales. Revenue from Quadro GPUs for professional visualization increased 6% due primarily to higher sales across desktop and mobile workstation products. Our PC OEM revenue decreased by 78% primarily driven by the absence of cryptocurrency mining processor sales.

[0001045810-19-000079:mdna:45]
Tegra Processor Business. Tegra Processor business revenue decreased by 55% for the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019. This was driven by a decline in shipments of SOC modules for gaming platforms, which was only partially offset by an increase of 14% in automotive revenue, primarily from growth in AI cockpit modules.

[0001045810-19-000079:mdna:46]
[same as prior period, unchanged from 0001045810-18-000150:mdna:49]

[0001045810-19-000079:mdna:47]
Revenue from sales to customers outside of the United States accounted for 93% and 86% of total revenue for the first quarter of fiscal years 2020 and 2019, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-19-000079:mdna:48]
Revenue from significant customers, those representing 10% or more of total revenue, was approximately 11%  of our total revenue from one customer for the first quarter of fiscal year 2020, and aggregated approximately 20% of our total revenue from two customers for the first quarter of fiscal year 2019, and was attributable primarily to the GPU business.

[0001045810-19-000079:mdna:49]
[same as prior period, unchanged from 0001045810-18-000150:mdna:52]

[0001045810-19-000079:mdna:50]
Our overall gross margin decreased to 58.4% for the first quarter of fiscal year 2020 from 64.5% for the first quarter of fiscal year 2019. The decrease in fiscal year 2020 is primarily due to lower gaming margins and mix shifts across the portfolio.

[0001045810-19-000079:mdna:51]
Inventory provisions totaled $43 million and $33 million for the first quarter of fiscal years 2020 and 2019, respectively. Sales of inventory that was previously written-off or written-down totaled $12 million and $4 million for the first quarter of fiscal years 2020 and 2019, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 1.4% and 0.9% for the first quarter of fiscal years 2020 and 2019, respectively.

[0001045810-19-000079:mdna:52]
[same as prior period, unchanged from 0001045810-18-000150:mdna:56]

[0001045810-19-000079:mdna:53]
GPU Business. The gross margin of our GPU business decreased during the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019, primarily due to lower gaming GPU margins and mix shifts across the portfolio.

[0001045810-19-000079:mdna:54]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased during the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019, primarily due to mix shifts.

[0001045810-19-000079:mdna:55]
[same as prior period, unchanged from 0001045810-18-000150:mdna:60]

[0001045810-19-000079:mdna:56]
|  | Three Months Ended |
|  | April 28, 2019 |  | April 29, 2018 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 674 |  |  | $ | 542 |  |  | $ | 132 |  |  | 24 | % |
| % of net revenue | 30 | % |  | 17 | % |  |  |  |  |
| Sales, general and administrative expenses | 264 |  |  | 231 |  |  | 33 |  |  | 14 | % |
| % of net revenue | 12 | % |  | 7 | % |  |  |  |  |
| Total operating expenses | $ | 938 |  |  | $ | 773 |  |  | $ | 165 |  |  | 21 | % |

[0001045810-19-000079:mdna:57]
[same as prior period, unchanged from 0001045810-18-000150:mdna:62]

[0001045810-19-000079:mdna:58]
Research and development expenses increased by 24% during the first quarter of fiscal year 2020, compared to the first quarter of fiscal year 2019, driven primarily by employee additions, increases in employee compensation and other related costs, including infrastructure costs and stock-based compensation expense.

[0001045810-19-000079:mdna:59]
[same as prior period, unchanged from 0001045810-18-000150:mdna:64]

[0001045810-19-000079:mdna:60]
Sales, general and administrative expenses increased by 14% during the first quarter of fiscal year 2020, compared to the first quarter of fiscal year 2019, driven primarily by costs related to our plans to acquire Mellanox and employee additions, increases in employee compensation and other related costs, including stock-based compensation expense and infrastructure costs.

[0001045810-19-000079:mdna:61]
[same as prior period, unchanged from 0001045810-18-000150:mdna:66]

[0001045810-19-000079:mdna:62]
[same as prior period, unchanged from 0001045810-18-000150:mdna:67]

[0001045810-19-000079:mdna:63]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $44 million and $25 million during the first quarter of fiscal years 2020 and 2019, respectively. The increase in interest income was primarily due to higher average invested balances and higher rates from our floating rate securities and the purchase of new securities.

[0001045810-19-000079:mdna:64]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016. Interest expense was $13 million and $15 million during the first quarters of fiscal years 2020 and 2019, respectively.

[0001045810-19-000079:mdna:65]
[same as prior period, unchanged from 0001045810-18-000150:mdna:70]

[0001045810-19-000079:mdna:66]
Other, net, consists primarily of realized or unrealized gains and losses from non-affiliated investments, and the impact of changes in foreign currency rates. Other, net, was not significant during the first quarter of fiscal years 2020 and 2019.

[0001045810-19-000079:mdna:67]
[same as prior period, unchanged from 0001045810-18-000150:mdna:73]

[0001045810-19-000079:mdna:68]
We recognized income tax benefit of $5 million for the first quarter of fiscal year 2020, and income tax expense of $67 million for the first quarter of fiscal year 2019. Income tax benefit as a percentage of income before income tax was 1.3% for the first quarter of fiscal year 2020, and income tax expense as a percentage of income before tax was 5.1% for the first quarter of fiscal year 2019.

[0001045810-19-000079:mdna:69]
The decrease in our effective tax rate for the first quarter of fiscal year 2020 as compared to the same period in the prior fiscal year was primarily due to a decrease in the amount of earnings subject to United States tax, and an increase in the impact of tax benefits from stock-based compensation and the U.S. federal research tax credit.

[0001045810-19-000079:mdna:70]
Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-19-000079:mdna:71]
[same as prior period, unchanged from 0001045810-18-000150:mdna:77]

[0001045810-19-000079:mdna:72]
|  | April 28, 2019 |  | January 27, 2019 |
|  | (In millions) |
| Cash and cash equivalents | $ | 2,772 |  |  | $ | 782 |  |
| Marketable securities | 5,030 |  |  | 6,640 |  |
| Cash, cash equivalents and marketable securities | $ | 7,802 |  |  | $ | 7,422 |  |

[0001045810-19-000079:mdna:73]
|  | Three Months Ended |
|  | April 28, 2019 |  | April 29, 2018 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 720 |  |  | $ | 1,445 |  |
| Net cash provided by (used in) investing activities | $ | 1,495 |  |  | $ | (3,551 | ) |
| Net cash used in financing activities | $ | (225 | ) |  | $ | (1,131 | ) |

[0001045810-19-000079:mdna:74]
As of April 28, 2019, we had $7.80 billion in cash, cash equivalents and marketable securities, an increase of $380 million from the end of fiscal year 2019. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain limits on our portfolio duration.

[0001045810-19-000079:mdna:75]
Cash provided by operating activities decreased in the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019, due to lower net income, partially offset by changes in working capital.

[0001045810-19-000079:mdna:76]
Cash provided by investing activities increased in the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019, due to lower purchases of marketable securities and higher maturities of marketable securities.

[0001045810-19-000079:mdna:77]
Cash used in financing activities decreased in the first quarter of fiscal year 2020 compared to the first quarter of fiscal year 2019, due to lower share repurchases and lower tax payments related to employee stock plans.

[0001045810-19-000079:mdna:78]
[same as prior period, unchanged from 0001045810-18-000150:mdna:84]

[0001045810-19-000079:mdna:79]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, asset-backed issuers, mortgage-backed securities by government-sponsored enterprises, and foreign government entities. These marketable securities are denominated in United States dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-19-000079:mdna:80]
As a result of the Tax Cuts and Jobs Act, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of April 28, 2019 are available for use in the United States without incurring additional U.S. federal income taxes.

[0001045810-19-000079:mdna:81]
[same as prior period, unchanged from 0001045810-18-000150:mdna:87]

[0001045810-19-000079:mdna:82]
As previously communicated, we intend to return $3.00 billion to shareholders by the end of fiscal year 2020, including $700 million in share repurchases made during the fourth quarter of fiscal year 2019. In the first quarter of fiscal year 2020, we returned $97 million in quarterly cash dividends. We intend to return the remaining $2.20 billion by the end of fiscal year 2020, through a combination of share repurchases and cash dividends. As of April 28, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000079:mdna:83]
[same as prior period, unchanged from 0001045810-18-000150:mdna:89]

[0001045810-19-000079:mdna:84]
[same as prior period, unchanged from 0001045810-18-000150:mdna:90]

[0001045810-19-000079:mdna:85]
[same as prior period, unchanged from 0001045810-18-000150:mdna:91]

[0001045810-19-000079:mdna:86]
Revolving Credit Facility

[0001045810-19-000079:mdna:87]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of April 28, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000079:mdna:88]
[same as prior period, unchanged from 0001045810-18-000150:mdna:96]

[0001045810-19-000079:mdna:89]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2019, we had not issued any commercial paper.

[0001045810-19-000079:mdna:90]
[same as prior period, unchanged from 0001045810-18-000150:mdna:98]

[0001045810-19-000079:mdna:91]
In fiscal year 2019, we began construction on a 750 thousand square foot building on our Santa Clara campus, which is currently targeted for completion in fiscal year 2022. We believe that our existing cash and cash equivalents, marketable securities, anticipated cash flows from operations, and our available revolving credit facility or commercial paper program mentioned above will be sufficient to meet our operating requirements for at least the next twelve months.

[0001045810-19-000079:mdna:92]
[same as prior period, unchanged from 0001045810-18-000150:mdna:100]

[0001045810-19-000079:mdna:93]
As of April 28, 2019, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-19-000079:mdna:94]
[same as prior period, unchanged from 0001045810-18-000150:mdna:102]

[0001045810-19-000079:mdna:95]
There were no material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019 other than our proposed acquisition of Mellanox as described in Note 2 of the Notes to Condensed Consolidated Financial Statements.

[0001045810-19-000079:mdna:96]
Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019 for a description of our contractual obligations.

[0001045810-19-000079:mdna:97]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000079:mdna:98]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
