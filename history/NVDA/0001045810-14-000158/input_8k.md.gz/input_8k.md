# NVDA 8-K — 0001045810-14-000149 filed 2014-08-07

## item codes, every 8-K on or before 2014-08-20

- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2014-08-20

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-14-000149:8k_2_02:1]
EX-99.1
2
q215pr.htm
Q2'15 PRESS RELEASE

[0001045810-14-000149:8k_2_02:2]
Q2'15 PR

[0001045810-14-000149:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-14-000149:8k_2_02:4]
NVIDIA Financial Results for Second Quarter Fiscal 2015

[0001045810-14-000149:8k_2_02:5]
| • | Second quarter revenue of $1.10 billion, up 13 percent from a year earlier |

[0001045810-14-000149:8k_2_02:6]
| • | GAAP diluted EPS of $0.22, up from $0.16 a year earlier; non-GAAP diluted EPS of $0.30, up from $0.23 a year earlier |

[0001045810-14-000149:8k_2_02:7]
| • | Record GAAP gross margin of 56.1 percent; record non-GAAP gross margin of 56.4 percent |

[0001045810-14-000149:8k_2_02:8]
SANTA CLARA, Calif.-Aug. 7, 2014-NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 27, 2014, of $1.10 billion, up 13 percent from $977 million a year earlier and in line with the previous quarter.  Revenue for the first half was up 14 percent to a record $2.21 billion from $1.93 billion a year earlier.

[0001045810-14-000149:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.22, up 38 percent from $0.16 a year earlier and down 8 percent from the previous quarter. Non-GAAP earnings per diluted share were $0.30, up 30 percent from $0.23 a year earlier and up 3 percent from the previous quarter.

[0001045810-14-000149:8k_2_02:10]
“We had a great quarter with strong gains in each of our three growth areas - Gaming, Datacenter & Cloud, and Mobile,” said Jen-Hsun Huang, president and chief executive officer of NVIDIA.  “Our Tesla datacenter business is in high gear, benefiting from strong demand from cloud service providers, and our new SHIELD tablet is generating considerable excitement. ‎ NVIDIA’s accelerating growth stems directly from investments in extending our visual computing leadership to the mobile-cloud revolution."

[0001045810-14-000149:8k_2_02:11]
During the second quarter, NVIDIA paid $47 million in cash dividends and received 6.8 million shares under the $500 million structured repurchase agreement it entered into in the first quarter. During the first quarter, the company had paid $47 million in cash dividends and had received 20.6 million shares under the agreement. As a result, during the first half, NVIDIA has returned $594 million of the $1 billion it intends to return to shareholders in fiscal 2015.

[0001045810-14-000149:8k_2_02:12]
NVIDIA will pay its next quarterly cash dividend of $0.085 per share on Sept. 12, 2014, to all stockholders of record on Aug. 21, 2014.  NVIDIA expects that a portion of this dividend payment may be considered a return of capital for U.S. federal income tax purposes.

[0001045810-14-000149:8k_2_02:13]
| GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q2 FY15 | Q1 FY15 | Q2 FY14 | Q/Q | Y/Y |
| Revenue | $ | 1,103 |  | $ | 1,103 |  | $ | 977 |  | flat | up 13% |
| Gross margin | 56.1 | % | 54.8 | % | 55.8 | % | up 130 bps | up 30 bps |
| Operating expenses | $ | 456 |  | $ | 453 |  | $ | 440 |  | up 1% | up 4% |
| Net income | $ | 128 |  | $ | 137 |  | $ | 96 |  | down 6% | up 33% |
| Diluted earnings per share | $ | 0.22 |  | $ | 0.24 |  | $ | 0.16 |  | down 8% | up 38% |

[0001045810-14-000149:8k_2_02:14]
| Non-GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q2 FY15 | Q1 FY15 | Q2 FY14 | Q/Q | Y/Y |
| Revenue | $ | 1,103 |  | $ | 1,103 |  | $ | 977 |  | flat | up 13% |
| Gross margin | 56.4 | % | 55.1 | % | 56.3 | % | up 130 bps | up 10 bps |
| Operating expenses | $ | 411 |  | $ | 411 |  | $ | 401 |  | flat | up 2% |
| Net income | $ | 173 |  | $ | 166 |  | $ | 133 |  | up 4% | up 30% |
| Diluted earnings per share | $ | 0.30 |  | $ | 0.29 |  | $ | 0.23 |  | up 3% | up 30% |

[0001045810-14-000149:8k_2_02:15]
NVIDIA’s outlook for the third quarter of fiscal 2015 is as follows:

[0001045810-14-000149:8k_2_02:16]
| • | Revenue is expected to be $1.20 billion, plus or minus two percent. |

[0001045810-14-000149:8k_2_02:17]
| • | GAAP and non-GAAP gross margins are expected to be 55.2 percent and 55.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-14-000149:8k_2_02:18]
| • | GAAP operating expenses are expected to be approximately $463 million; non-GAAP operating expenses are expected to be approximately $416 million. |

[0001045810-14-000149:8k_2_02:19]
| • | GAAP and non-GAAP tax rates for the third quarter and annual fiscal 2015 are both expected to be 19 percent, plus or minus one percentage point. This estimate excludes any discrete tax events that may occur during a quarter which, if realized, may increase or decrease NVIDIA’s actual effective tax rates in such quarter. |

[0001045810-14-000149:8k_2_02:20]
| • | Capital expenditures are expected to be approximately $40 million to $50 million. |

[0001045810-14-000149:8k_2_02:21]
Second Quarter Fiscal 2015 Highlights

[0001045810-14-000149:8k_2_02:22]
During the second quarter, NVIDIA:

[0001045810-14-000149:8k_2_02:23]
| • | Extended its leading position in datacenter accelerated computing, with the world’s 15 most efficient supercomputers all running NVIDIA® Tesla® GPUs, according to the latest Green500 list. |

[0001045810-14-000149:8k_2_02:24]
| • | Surpassed 40 million installations in under two years of its GeForce Experience™ client, which provides game-ready drivers and optimal playable settings, and allows gameplay to be streamed and shared. |

[0001045810-14-000149:8k_2_02:25]
| • | Invented the first-ever GPU acceleration technology for Adobe Illustrator CC, with performance up to 10x faster than previously possible. Adobe Illustrator CC is used by more than six million artists and designers worldwide. |

[0001045810-14-000149:8k_2_02:26]
| • | Featured prominently at the Google I/O conference, where Google’s new Android L was previewed. NVIDIA Tegra® K1 is the first processor to support Android L’s advanced gaming capabilities; the first to bring GPU computing to mobile, evident in Google’s Project Tango tablet, which features computer vision capabilities; and among the first to support Android TV. |

[0001045810-14-000149:8k_2_02:27]
| • | Expanded the SHIELD™ family of gaming devices with the launch of the world’s most advanced tablet built for gamers, the SHIELD tablet, along with the SHIELD wireless controller. |

[0001045810-14-000149:8k_2_02:28]
| • | Accelerated the growth of its auto business, as BMW shipped new models, including the i8 and i3 with infotainment systems powered by Tegra. Volkswagen announced that, in addition to the Golf, Tegra will be included in the Passat launching later this year in Europe. |

[0001045810-14-000149:8k_2_02:29]
CFO Commentary

[0001045810-14-000149:8k_2_02:30]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-14-000149:8k_2_02:31]
Conference Call and Webcast Information

[0001045810-14-000149:8k_2_02:32]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2015 financial results and current financial prospects today at 2:00 p.m. Pacific Time (5:00 p.m. Eastern Time). To listen to the conference call, dial (303) 223-2680; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at the NVIDIA investor relations web site http://investor.nvidia.com/ and at  www.streetevents.com. The webcast will be recorded and available for replay until the company's conference call to discuss its financial results for its third quarter fiscal 2015.

[0001045810-14-000149:8k_2_02:33]
Non-GAAP Measures

[0001045810-14-000149:8k_2_02:34]
To supplement NVIDIA’s Condensed Consolidated Statements of Operations and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP other income and expense, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, legal settlements, acquisition-related costs, gains and losses from non-affiliated investments, interest expense related to the amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user's overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and our non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-14-000149:8k_2_02:35]
To Keep Current on NVIDIA:

[0001045810-14-000149:8k_2_02:36]
| • | Keep up with the NVIDIA Blog. |

[0001045810-14-000149:8k_2_02:37]
| • | Like NVIDIA on Facebook. |

[0001045810-14-000149:8k_2_02:38]
| • | Connect with NVIDIA on LinkedIn. |

[0001045810-14-000149:8k_2_02:39]
| • | Follow @NVIDIA on Twitter. |

[0001045810-14-000149:8k_2_02:40]
| • | View NVIDIA videos on YouTube. |

[0001045810-14-000149:8k_2_02:41]
| • | Use the Pulse news reader to subscribe to the NVIDIA Daily News feed. |

[0001045810-14-000149:8k_2_02:42]
About NVIDIA

[0001045810-14-000149:8k_2_02:43]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-14-000149:8k_2_02:44]
Certain statements in this press release including, but not limited to statements as to: strong demand from cloud service providers; the company’s growth stemming directly from investments in extending its visual computing leadership to the mobile-cloud revolution; the $1 billion the company intends to return to shareholders in fiscal 2015; a portion of the company’s dividend payment being considered a return of capital; the company’s financial outlook for the third quarter of fiscal 2015; and the company’s tax rate for the third quarter and fiscal 2015 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended April 27, 2014. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-14-000149:8k_2_02:45]
© 2014 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce Experience, Tegra, Tesla, NVIDIA GRID, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-14-000149:8k_2_02:46]
###

[0001045810-14-000149:8k_2_02:47]
For further information, contact:

[0001045810-14-000149:8k_2_02:48]
| Chris Evenden |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 627-0608 |  | (408) 566-5150 |
| cevenden@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-14-000149:8k_2_02:49]
NVIDIA CORPORATION

[0001045810-14-000149:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-14-000149:8k_2_02:51]
(In thousands, except per share data)

[0001045810-14-000149:8k_2_02:52]
(Unaudited)

[0001045810-14-000149:8k_2_02:53]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenue | $ | 1,102,824 |  |  | $ | 977,238 |  |  | $ | 2,205,611 |  |  | $ | 1,931,977 |  |
| Cost of revenue | 483,850 |  |  | 431,700 |  |  | 982,435 |  |  | 867,871 |  |
| Gross profit | 618,974 |  |  | 545,538 |  |  | 1,223,176 |  |  | 1,064,106 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 337,124 |  |  | 331,738 |  |  | 671,387 |  |  | 658,899 |  |
| Sales, general and administrative | 118,671 |  |  | 108,266 |  |  | 237,251 |  |  | 216,892 |  |
| Total operating expenses | 455,795 |  |  | 440,004 |  |  | 908,638 |  |  | 875,791 |  |
| Operating income | 163,179 |  |  | 105,534 |  |  | 314,538 |  |  | 188,315 |  |
| Interest income | 6,829 |  |  | 3,865 |  |  | 12,539 |  |  | 8,941 |  |
| Interest expense | 11,526 |  |  | 836 |  |  | 22,997 |  |  | 1,689 |  |
| Other income (expense), net | (3,857 | ) |  | 3,257 |  |  | 13,827 |  |  | 4,315 |  |
| Income before income tax expense | 154,625 |  |  | 111,820 |  |  | 317,907 |  |  | 199,882 |  |
| Income tax expense | 26,649 |  |  | 15,372 |  |  | 53,415 |  |  | 25,543 |  |
| Net income | $ | 127,976 |  |  | $ | 96,448 |  |  | $ | 264,492 |  |  | $ | 174,339 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.23 |  |  | $ | 0.16 |  |  | $ | 0.47 |  |  | $ | 0.29 |  |
| Diluted | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | 0.46 |  |  | $ | 0.29 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 558,223 |  |  | 585,345 |  |  | 558,657 |  |  | 601,109 |  |
| Diluted | 570,572 |  |  | 592,006 |  |  | 570,599 |  |  | 606,051 |  |

[0001045810-14-000149:8k_2_02:54]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  | July 27, |  | January 26, |
|  |  |  | 2014 |  | 2014 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,386,054 |  |  | $ | 4,671,810 |  |
|  | Accounts receivable, net |  | 469,625 |  |  | 426,357 |  |
|  | Inventories |  | 387,434 |  |  | 387,765 |  |
|  | Prepaid expenses and other current assets |  | 134,473 |  |  | 138,779 |  |
|  | Total current assets |  | 5,377,586 |  |  | 5,624,711 |  |
| Property and equipment, net |  | 556,911 |  |  | 582,740 |  |
| Goodwill |  | 643,179 |  |  | 643,179 |  |
| Intangible assets, net |  | 260,613 |  |  | 296,012 |  |
| Other assets |  | 95,430 |  |  | 104,252 |  |
|  | Total assets |  | $ | 6,933,719 |  |  | $ | 7,250,894 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 261,627 |  |  | $ | 324,391 |  |
|  | Accrued liabilities and other current liabilities |  | 607,102 |  |  | 621,105 |  |
|  | Total current liabilities |  | 868,729 |  |  | 945,496 |  |
| Long-term debt |  | 1,370,249 |  |  | 1,356,375 |  |
| Other long-term liabilities |  | 374,113 |  |  | 475,125 |  |
| Capital lease obligations, long-term |  | 15,842 |  |  | 17,500 |  |
| Stockholders' equity |  | 4,304,786 |  |  | 4,456,398 |  |
|  | Total liabilities and stockholders' equity |  | $ | 6,933,719 |  |  | $ | 7,250,894 |  |

[0001045810-14-000149:8k_2_02:55]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | April 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP gross profit |  | $ | 618,974 |  |  | $ | 604,202 |  |  | $ | 545,538 |  |  | $ | 1,223,176 |  |  | $ | 1,064,106 |  |
| GAAP gross margin |  | 56.1 | % |  | 54.8 | % |  | 55.8 | % |  | 55.5 | % |  | 55.1 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 2,656 |  |  | 2,919 |  |  | 2,168 |  |  | 5,575 |  |  | 4,821 |  |
| Legal settlement |  | — |  |  | — |  |  | 2,290 |  |  | — |  |  | 2,290 |  |
| Non-GAAP gross profit |  | $ | 621,630 |  |  | $ | 607,121 |  |  | $ | 549,996 |  |  | $ | 1,228,751 |  |  | $ | 1,071,217 |  |
| Non-GAAP gross margin |  | 56.4 | % |  | 55.1 | % |  | 56.3 | % |  | 55.7 | % |  | 55.4 | % |
| GAAP operating expenses |  | $ | 455,795 |  |  | $ | 452,843 |  |  | $ | 440,004 |  |  | $ | 908,638 |  |  | $ | 875,791 |  |
| Stock-based compensation expense included in operating expense (A) |  | (35,759 | ) |  | (32,602 | ) |  | (30,227 | ) |  | (68,361 | ) |  | (60,971 | ) |
| Acquisition-related costs (B) |  | (9,173 | ) |  | (9,441 | ) |  | (8,964 | ) |  | (18,614 | ) |  | (17,825 | ) |
| Non-GAAP operating expenses |  | $ | 410,863 |  |  | $ | 410,800 |  |  | $ | 400,813 |  |  | $ | 821,663 |  |  | $ | 796,995 |  |
| GAAP other income (expense), net | $ | (8,554 | ) |  | $ | 11,923 |  |  | $ | 6,286 |  |  | $ | 3,369 |  |  | $ | 11,567 |  |
| Gains and losses from non-affiliated investments |  | 2,500 |  |  | (16,982 | ) |  | — |  |  | (14,482 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | 6,973 |  |  | 6,901 |  |  | — |  |  | 13,874 |  |  | — |  |
| Non-GAAP other income (expense), net | $ | 919 |  |  | $ | 1,842 |  |  | $ | 6,286 |  |  | $ | 2,761 |  |  | $ | 11,567 |  |
| GAAP net income |  | $ | 127,976 |  |  | $ | 136,516 |  |  | $ | 96,448 |  |  | $ | 264,492 |  |  | $ | 174,339 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 57,061 |  |  | 34,881 |  |  | 43,649 |  |  | 91,942 |  |  | 85,907 |  |
| Income tax impact of non-GAAP adjustments |  | (11,606 | ) |  | (5,342 | ) |  | (6,767 | ) |  | (16,948 | ) |  | (13,115 | ) |
| Non-GAAP net income |  | $ | 173,431 |  |  | $ | 166,055 |  |  | $ | 133,330 |  |  | $ | 339,486 |  |  | $ | 247,131 |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.22 |  |  | $ | 0.24 |  |  | $ | 0.16 |  |  | $ | 0.46 |  |  | $ | 0.29 |  |
| Non-GAAP |  | $ | 0.30 |  |  | $ | 0.29 |  |  | $ | 0.23 |  |  | $ | 0.59 |  |  | $ | 0.41 |  |
| Shares used in diluted net income per share computation |  | 570,572 |  |  | 570,422 |  |  | 592,006 |  |  | 570,599 |  |  | 606,051 |  |
| Metrics: |  |  |  |  |  |  |  |  |  |  |
| GAAP net cash flow provided by operating activities |  | $ | 96,282 |  |  | $ | 151,022 |  |  | $ | 96,469 |  |  | $ | 247,304 |  |  | $ | 272,119 |  |
| Purchase of property and equipment and intangible assets |  | (22,527 | ) |  | (29,068 | ) |  | (84,986 | ) |  | (51,595 | ) |  | (150,653 | ) |
| Free cash flow |  | $ | 73,755 |  |  | $ | 121,954 |  |  | $ | 11,483 |  |  | $ | 195,709 |  |  | $ | 121,466 |  |

[0001045810-14-000149:8k_2_02:56]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | April 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of revenue |  | $ | 2,656 |  |  | $ | 2,919 |  |  | $ | 2,168 |  |  | $ | 5,575 |  |  | $ | 4,821 |  |
| Research and development |  | $ | 21,462 |  |  | $ | 20,494 |  |  | $ | 18,555 |  |  | $ | 41,956 |  |  | $ | 40,490 |  |
| Sales, general and administrative |  | $ | 14,297 |  |  | $ | 12,108 |  |  | $ | 11,672 |  |  | $ | 26,405 |  |  | $ | 20,481 |  |
| (B) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |

[0001045810-14-000149:8k_2_02:57]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2015 Outlook |
| GAAP gross margin |  | 55.2 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 55.5 | % |
|  |  |  | Q3 FY2015 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 463 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (47 | ) |
| Non-GAAP operating expenses |  | $ | 416 |  |
