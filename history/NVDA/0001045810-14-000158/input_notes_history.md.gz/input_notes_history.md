# NVDA note change history — 0001045810-14-000085 → 0001045810-14-000158


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-20):
[0001045810-14-000158:note_history:1]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The hearing on the appeal is currently scheduled for October 8, 2014.
  (was, 2014-05-21, similarity 0.8605):
[0001045810-14-000085:note_history:1]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The appeal is currently pending.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-20):
[0001045810-14-000158:note_history:2]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The second quarters of fiscal years 2015 and 2014 are both 13-week quarters.
  (was, 2014-05-21, similarity 0.9771):
[0001045810-14-000085:note_history:2]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The first quarters of fiscal years 2015 and 2014 are both 13-week quarters.

- added (2014-08-20):
[0001045810-14-000158:note_history:3]
In June 2014, the Financial Accounting Standards Board, or FASB, issued new guidance related to stock-based compensation. The new guidance requires that a performance target that affects vesting, and that could be achieved after the requisite service period is rendered, be treated as a performance condition. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. We currently do not have awards with a performance target where the employee would be eligible to vest in the award regardless of whether the employee is rendering service on the date the performance target is achieved. Therefore, we believe, the adoption of this new accounting guidance will not have an impact on our consolidated financial statements.

- added (2014-08-20):
[0001045810-14-000158:note_history:4]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period.  Early adoption is not permitted.  We may adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.

- changed (2014-08-20):
[0001045810-14-000158:note_history:5]
In July 2013, the FASB issued updated guidance regarding the presentation of unrecognized tax benefits when a net operating loss carry forward, similar tax loss, or tax credit carry forward exists. The guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carry forward, a similar tax loss, or a tax credit carry forward when settlement in this manner is available under the tax law. We adopted this guidance in our interim period ended April 27, 2014. The adoption of this guidance did not impact our consolidated financial statements.
  (was, 2014-05-21, similarity 0.899):
[0001045810-14-000085:note_history:5]
In July 2013, the Financial Accounting Standards Board issued updated guidance regarding the presentation of unrecognized tax benefits when a net operating loss carry forward, similar tax loss, or tax credit carry forward exists. The guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carry forward, a similar tax loss, or a tax credit carry forward when settlement in this manner is available under the tax law. We adopted this guidance in our interim period ended April 27, 2014. The adoption of this guidance did not impact our condensed consolidated financial statements, as the guidance was issued to reduce diversity in practice on presentation of unrecognized tax benefits.

- removed (2014-08-20):
[0001045810-14-000085:note_history:6]
Revenue Recognition

- removed (2014-08-20):
[0001045810-14-000085:note_history:7]
Product Revenue

- removed (2014-08-20):
[0001045810-14-000085:note_history:8]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured. For most sales, we use a binding purchase order and in certain cases we use a contractual agreement as evidence of an arrangement. We consider delivery to occur upon shipment provided title and risk of loss have passed to the customer. At the point of sale, we assess whether the arrangement fee is fixed or determinable and whether collection is reasonably assured. If we determine that collection of a fee is not reasonably assured, we defer the fee and recognize revenue at the time collection becomes reasonably assured, which is generally upon receipt of payment.

- removed (2014-08-20):
[0001045810-14-000085:note_history:9]
Our policy on sales to certain distributors with rights of return is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.

- removed (2014-08-20):
[0001045810-14-000085:note_history:10]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with original equipment manufacturers, or OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. The OEMs are not our direct customers and the quantity and mix of demand they place on contract equipment manufacturers and original design manufacturers may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents approximately 0.5% of total revenue.

- removed (2014-08-20):
[0001045810-14-000085:note_history:11]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed. MDF amounts that have been previously recorded against revenue and subsequently expired unclaimed are reversed to revenue. Such amounts have not been significant.

- removed (2014-08-20):
[0001045810-14-000085:note_history:12]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- removed (2014-08-20):
[0001045810-14-000085:note_history:13]
License and Development Revenue

- removed (2014-08-20):
[0001045810-14-000085:note_history:14]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual direct labor hours incurred to date as a percentage of the estimated total direct labor hours required to complete the project. We periodically evaluate the actual status of each project to ensure that the estimates to complete each contract remain accurate. A provision for estimated losses on contracts is made in the period in which the loss becomes probable and can be reasonably estimated. Costs incurred in advance of revenue recognized are recorded as deferred costs on uncompleted contracts. If the amount billed exceeds the amount of revenue recognized, the excess amount is recorded as deferred revenue. Revenue recognized in any period is dependent on our progress toward completion of projects in progress. Significant management judgment and discretion are used to estimate total direct labor hours. Any changes in or deviations from these estimates could have a material effect on the amount of revenue we recognize in any period.

- removed (2014-08-20):
[0001045810-14-000085:note_history:15]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

- removed (2014-08-20):
[0001045810-14-000085:note_history:16]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties. We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.

- removed (2014-08-20):
[0001045810-14-000085:note_history:17]
Inventories

- removed (2014-08-20):
[0001045810-14-000085:note_history:18]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.

- removed (2014-08-20):
[0001045810-14-000085:note_history:19]
Net Income Per Share

- removed (2014-08-20):
[0001045810-14-000085:note_history:20]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to Condensed Consolidated Financial Statements. The potentially dilutive impact of the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted shares when their conversion features are exercisable. However, unless actually exercised, the note hedges will not be included in the calculation of diluted shares, as their pre-exercised effect would be anti-dilutive under the treasury stock method.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-20):
[0001045810-14-000158:note_history:21]
As of July 27, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.
  (was, 2014-05-21, similarity 0.9898):
[0001045810-14-000085:note_history:21]
As of April 27, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

- changed (2014-08-20):
[0001045810-14-000158:note_history:22]
|  |  | July 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (129,751 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,370,249 |  |  | $ | 1,356,375 |  |
  (was, 2014-05-21, similarity 0.9873):
[0001045810-14-000085:note_history:22]
|  |  | April 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (136,724 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,363,276 |  |  | $ | 1,356,375 |  |

- changed (2014-08-20):
[0001045810-14-000158:note_history:23]
(1)   As of July 27, 2014, the unamortized debt discount will be amortized over a remaining period of 4.4 years.
  (was, 2014-05-21, similarity 0.6948):
[0001045810-14-000085:note_history:23]
(1)   As of April 27, 2014, the remaining period over which the unamortized debt discount will be amortized is 4.6 years.

- changed (2014-08-20):
[0001045810-14-000158:note_history:24]
The following table presents the interest expense for the contractual interest and the accretion of debt discount and issuance costs:
  (was, 2014-05-21, similarity 0.9231):
[0001045810-14-000085:note_history:24]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

- added (2014-08-20):
[0001045810-14-000158:note_history:25]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 7,500 |  |  | $ | — |  |
| Amortization of debt discount |  | 6,973 |  |  | — |  |  | 13,874 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 97 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,772 |  |  | $ | — |  |  | $ | 21,471 |  |  | $ | — |  |

- removed (2014-08-20):
[0001045810-14-000085:note_history:26]
|  |  | Three Months Ended |
|  |  | April 27, 2014 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |
| Amortization of debt discount |  | 6,901 |  |
| Amortization of debt issuance costs |  | 49 |  |
| Total interest expense related to Notes |  | $ | 10,700 |  |

- removed (2014-08-20):
[0001045810-14-000085:note_history:27]
As of April 27, 2014, the fair value of the Notes was $1,692.3 million. The Notes are classified within Level 2 as they are not actively traded in markets.

- removed (2014-08-20):
[0001045810-14-000085:note_history:28]
Note Hedges and Warrants

- removed (2014-08-20):
[0001045810-14-000085:note_history:29]
The net proceeds from the Notes were $1,477.5 million after payment of the initials purchaser's discount.  Concurrently with the offering of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.16 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would pay to the holders of the Notes upon conversion.  We paid $167.1 million for the Note Hedges.

- removed (2014-08-20):
[0001045810-14-000085:note_history:30]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with a strike price to the holders of the Warrants of $27.14 per share. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 74.4 million shares of our common stock. We received $59.1 million for the Warrants transaction.

- removed (2014-08-20):
[0001045810-14-000085:note_history:31]
The $108.0 million net cost of the Note Hedges offset by the proceeds from the Warrants is included as a net reduction to additional paid-in capital in the stockholders’ equity section of our condensed consolidated balance sheets, in accordance with the guidance in ASC 815-40 Derivatives and Hedging-Contracts in Entity's Own Equity.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-20):
[0001045810-14-000158:note_history:32]
|  |  | July 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (129,751 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,370,249 |  |  | $ | 1,356,375 |  |
  (was, 2014-05-21, similarity 0.9873):
[0001045810-14-000085:note_history:32]
|  |  | April 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (136,724 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,363,276 |  |  | $ | 1,356,375 |  |

- changed (2014-08-20):
[0001045810-14-000158:note_history:33]
(1)   As of July 27, 2014, the unamortized debt discount will be amortized over a remaining period of 4.4 years.
  (was, 2014-05-21, similarity 0.6948):
[0001045810-14-000085:note_history:33]
(1)   As of April 27, 2014, the remaining period over which the unamortized debt discount will be amortized is 4.6 years.

- changed (2014-08-20):
[0001045810-14-000158:note_history:34]
The following table presents the interest expense for the contractual interest and the accretion of debt discount and issuance costs:
  (was, 2014-05-21, similarity 0.9231):
[0001045810-14-000085:note_history:34]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

- added (2014-08-20):
[0001045810-14-000158:note_history:35]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 7,500 |  |  | $ | — |  |
| Amortization of debt discount |  | 6,973 |  |  | — |  |  | 13,874 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 97 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,772 |  |  | $ | — |  |  | $ | 21,471 |  |  | $ | — |  |

- removed (2014-08-20):
[0001045810-14-000085:note_history:36]
|  |  | Three Months Ended |
|  |  | April 27, 2014 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |
| Amortization of debt discount |  | 6,901 |  |
| Amortization of debt issuance costs |  | 49 |  |
| Total interest expense related to Notes |  | $ | 10,700 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2014-08-20):
[0001045810-14-000085:note_history:37]
Revenue Recognition

- removed (2014-08-20):
[0001045810-14-000085:note_history:38]
Product Revenue

- removed (2014-08-20):
[0001045810-14-000085:note_history:39]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured. For most sales, we use a binding purchase order and in certain cases we use a contractual agreement as evidence of an arrangement. We consider delivery to occur upon shipment provided title and risk of loss have passed to the customer. At the point of sale, we assess whether the arrangement fee is fixed or determinable and whether collection is reasonably assured. If we determine that collection of a fee is not reasonably assured, we defer the fee and recognize revenue at the time collection becomes reasonably assured, which is generally upon receipt of payment.

- removed (2014-08-20):
[0001045810-14-000085:note_history:40]
Our policy on sales to certain distributors with rights of return is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.

- removed (2014-08-20):
[0001045810-14-000085:note_history:41]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with original equipment manufacturers, or OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. The OEMs are not our direct customers and the quantity and mix of demand they place on contract equipment manufacturers and original design manufacturers may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents approximately 0.5% of total revenue.

- removed (2014-08-20):
[0001045810-14-000085:note_history:42]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed. MDF amounts that have been previously recorded against revenue and subsequently expired unclaimed are reversed to revenue. Such amounts have not been significant.

- removed (2014-08-20):
[0001045810-14-000085:note_history:43]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- removed (2014-08-20):
[0001045810-14-000085:note_history:44]
License and Development Revenue

- removed (2014-08-20):
[0001045810-14-000085:note_history:45]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual direct labor hours incurred to date as a percentage of the estimated total direct labor hours required to complete the project. We periodically evaluate the actual status of each project to ensure that the estimates to complete each contract remain accurate. A provision for estimated losses on contracts is made in the period in which the loss becomes probable and can be reasonably estimated. Costs incurred in advance of revenue recognized are recorded as deferred costs on uncompleted contracts. If the amount billed exceeds the amount of revenue recognized, the excess amount is recorded as deferred revenue. Revenue recognized in any period is dependent on our progress toward completion of projects in progress. Significant management judgment and discretion are used to estimate total direct labor hours. Any changes in or deviations from these estimates could have a material effect on the amount of revenue we recognize in any period.

- removed (2014-08-20):
[0001045810-14-000085:note_history:46]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

- removed (2014-08-20):
[0001045810-14-000085:note_history:47]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties. We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-08-20):
[0001045810-14-000158:note_history:48]
Subsequent Event

- added (2014-08-20):
[0001045810-14-000158:note_history:49]
In August 2014, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we paid $310.0 million to purchase shares of our common stock and received 10.9 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
