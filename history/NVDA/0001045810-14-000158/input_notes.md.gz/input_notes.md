# NVDA notes — 0001045810-14-000158


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001045810-14-000158:notes:1]
|  | July 27, |  | January 26, |
|  | 2014 |  | 2014 |
| Accrued Liabilities and Other: | (In thousands) |
| Deferred revenue, short-term | $ | 265,704 |  |  | $ | 265,616 |  |
| Accrued customer programs (1) | 131,973 |  |  | 157,840 |  |
| Accrued payroll and related expenses | 112,024 |  |  | 109,721 |  |
| Accrued legal settlement (2) | 30,600 |  |  | 30,600 |  |
| Professional service fees | 12,218 |  |  | 13,572 |  |
| Customer advances | 11,329 |  |  | 9,297 |  |
| Office lease related liabilities | 8,549 |  |  | 3,139 |  |
| Warranty accrual (3) | 8,202 |  |  | 7,571 |  |
| Taxes payable, short-term | 5,810 |  |  | 2,378 |  |
| Coupon interest on Notes | 2,542 |  |  | 2,500 |  |
| Other | 18,151 |  |  | 18,871 |  |
| Total accrued liabilities and other | $ | 607,102 |  |  | $ | 621,105 |  |

[0001045810-14-000158:notes:2]
(1)  Please refer to Note 1 of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014, for discussion regarding the nature of accrued customer programs and their accounting treatment related to our revenue recognition policies and estimates.

[0001045810-14-000158:notes:3]
(2)  Please refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the 3dfx litigation.

[0001045810-14-000158:notes:4]
[same as prior period, unchanged from 0001045810-14-000085:notes:4]


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-14-000158:notes:5]
|  | July 27, 2014 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 2,042,721 |  |  | $ | 2,139 |  |  | $ | (1,430 | ) |  | $ | 2,043,430 |  |
| Debt securities of United States government agencies | 700,025 |  |  | 352 |  |  | (216 | ) |  | 700,161 |  |
| Debt securities issued by United States Treasury | 586,484 |  |  | 896 |  |  | (69 | ) |  | 587,311 |  |
| Asset-backed securities | 411,669 |  |  | 169 |  |  | (310 | ) |  | 411,528 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 258,483 |  |  | 4,279 |  |  | (1,340 | ) |  | 261,422 |  |
| Money market funds | 119,491 |  |  | — |  |  | — |  |  | 119,491 |  |
| Total | $ | 4,118,873 |  |  | $ | 7,835 |  |  | $ | (3,365 | ) |  | $ | 4,123,343 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 252,381 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 3,870,962 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,123,343 |  |

[0001045810-14-000158:notes:6]
[same as prior period, unchanged from 0001045810-14-000085:notes:6]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-14-000158:notes:7]
Commitments and Contingencies

[0001045810-14-000158:notes:8]
3dfx

[0001045810-14-000158:notes:9]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx. The transaction closed on April 18, 2001. In October 2002, 3dfx filed for bankruptcy.

[0001045810-14-000158:notes:10]
Following the bankruptcy, in March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us. The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which difference the Trustee estimated to exceed $50.0 million. The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.

[0001045810-14-000158:notes:11]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process.

[0001045810-14-000158:notes:12]
In March 2007, a trial was held regarding certain valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.” This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending. On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment. That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008. The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.

[0001045810-14-000158:notes:13]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The hearing on the appeal is currently scheduled for October 8, 2014.

[0001045810-14-000158:notes:14]
While the conditional settlement reached in November 2005 never progressed through the confirmation process, the Trustee's case still remains pending on appeal. Accordingly, we have not reversed the accrual of $30.6 million - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx - that we recorded during the three months ended October 30, 2005, pending resolution of the appeal of the Trustee's case.

[0001045810-14-000158:notes:15]
Securities Cases

[0001045810-14-000158:notes:16]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934.

[0001045810-14-000158:notes:17]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014 and the appeal is currently under submission.

[0001045810-14-000158:notes:18]
Accounting for Loss Contingencies

[0001045810-14-000158:notes:19]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. With the exception of the 3dfx case, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-14-000158:notes:20]
[same as prior period, unchanged from 0001045810-14-000085:notes:20]

[0001045810-14-000158:notes:21]
[same as prior period, unchanged from 0001045810-14-000085:notes:21]


## us-gaap:DebtDisclosureTextBlock

[0001045810-14-000158:notes:22]
Long-Term Debt

[0001045810-14-000158:notes:23]
1.00 % Convertible Senior Notes Due 2018

[0001045810-14-000158:notes:24]
On December 2, 2013, we issued $1.5 billion of 1.00% convertible senior notes due 2018, or the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-14-000158:notes:25]
Holders may convert their notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter commencing after the fiscal quarter ended on  April 27, 2014 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their notes regardless of the foregoing conditions. Upon conversion, we will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0001045810-14-000158:notes:26]
As of July 27, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

[0001045810-14-000158:notes:27]
In accordance with ASC 470-20 Debt with Conversion and Other Options, all cash-settled convertible debt should be separated into debt and equity components at issuance and be assigned a fair value.   The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-14-000158:notes:28]
The initial debt component of the Notes was valued at $1,351.8 million based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $125.7 million and recorded as a debt discount. This amount, together with the $22.5 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $148.2 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-14-000158:notes:29]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-14-000158:notes:30]
|  |  | July 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (129,751 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,370,249 |  |  | $ | 1,356,375 |  |

[0001045810-14-000158:notes:31]
(1)   As of July 27, 2014, the unamortized debt discount will be amortized over a remaining period of 4.4 years.

[0001045810-14-000158:notes:32]
The following table presents the interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-14-000158:notes:33]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 7,500 |  |  | $ | — |  |
| Amortization of debt discount |  | 6,973 |  |  | — |  |  | 13,874 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 97 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,772 |  |  | $ | — |  |  | $ | 21,471 |  |  | $ | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-14-000158:notes:34]
[same as prior period, unchanged from 0001045810-14-000085:notes:39]

[0001045810-14-000158:notes:35]
[same as prior period, unchanged from 0001045810-14-000085:notes:40]

[0001045810-14-000158:notes:36]
[same as prior period, unchanged from 0001045810-14-000085:notes:41]

[0001045810-14-000158:notes:37]
[same as prior period, unchanged from 0001045810-14-000085:notes:42]

[0001045810-14-000158:notes:38]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, 2014 |  | July 28, 2013 |  | July 27, 2014 |  | July 28, 2013 |
|  | (In thousands) |  | (In thousands) |
| Cost of revenue | $ | 2,656 |  |  | $ | 2,168 |  |  | $ | 5,575 |  |  | $ | 4,821 |  |
| Research and development | 21,462 |  |  | 18,555 |  |  | 41,956 |  |  | 40,490 |  |
| Sales, general and administrative | 14,297 |  |  | 11,672 |  |  | 26,405 |  |  | 20,481 |  |
| Total | $ | 38,415 |  |  | $ | 32,395 |  |  | $ | 73,936 |  |  | $ | 65,792 |  |

[0001045810-14-000158:notes:39]
During the three and six months ended July 27, 2014, we granted 78,129 and 85,929 stock options, respectively, with a total grant-date fair value of $309.4 thousand and $345.3 thousand and a weighted average grant-date fair value of $3.96 and $4.02 per option, respectively. During the three and six months ended July 27, 2014, we granted 0.5 million and 3.7 million of RSUs and PSUs combined, with a total grant-date fair value of $8.4 million and $64.1 million and a weighted average grant-date fair value of $17.68 and $17.20 per share, respectively.  The PSUs were granted during the first quarter of fiscal year 2015 to our CEO and senior management as approved by our Compensation Committee.

[0001045810-14-000158:notes:40]
During the three and six months ended July 28, 2013, we granted 0.5 million and 3.3 million stock options, respectively, with an estimated total grant-date fair value of $1.4 million and $10.1 million and a weighted average grant-date fair value of $2.96 and $3.09 per option, respectively. During the three and six months ended July 28, 2013, we granted 0.7 million and 5.6 million RSUs with an estimated total grant-date fair value of $8.9 million and $66.3 million and a weighted average grant-date fair value of $13.49 and $11.93 per share, respectively.

[0001045810-14-000158:notes:41]
Of the total grant-date fair value, we estimated that the stock-based compensation expense related to the equity awards that were not expected to vest was $1.6 million and $11.5 million for the three and six months ended July 27, 2014, respectively, and  $1.8 million and $13.7 million for the three and six months ended July 28, 2013, respectively.  As of July 27, 2014 and January 26, 2014, the aggregate amount of unearned stock-based compensation expense related to our equity awards was $235.6 million and $241.3 million, respectively, adjusted for estimated forfeitures.  As of July 27, 2014 and January 26, 2014, we expected to recognize the unearned stock-based compensation expense related to stock options over an estimated weighted average amortization period of 2.2 years and 2.5 years, respectively. As of July 27, 2014 and January 26, 2014, we expected to recognize the unearned stock-based compensation expense related to RSUs and PSUs over an estimated weighted average amortization period of 2.6 years and 2.7 years, respectively.

[0001045810-14-000158:notes:42]
[same as prior period, unchanged from 0001045810-14-000085:notes:51]

[0001045810-14-000158:notes:43]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, 2014 |  | July 28, 2013 |  | July 27, 2014 |  | July 28, 2013 |
| Stock Options | (Using a binomial model) |
| Expected life (in years) | 2.5 |  |  | 2.4 - 3.4 |  | 2.5 - 3.2 |  |  | 2.4 - 3.4 |
| Risk-free interest rate | 2.5 | % |  | 1.8% - 2.7% |  | 2.5% - 2.8% |  |  | 1.8% - 2.7% |
| Volatility | 31 | % |  | 30% - 33% |  | 31 | % |  | 30% - 37% |
| Dividend yield | 1.8 | % |  | 2.1% - 2.2% |  | 1.8% - 1.9% |  |  | 2.1% - 2.4% |

[0001045810-14-000158:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, 2014 |  | July 28, 2013 |  | July 27, 2014 |  | July 28, 2013 |
| Employee Stock Purchase Plan | (Using a Black-Scholes model) |
| Expected life (in years) | — |  |  | — |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |
| Risk-free interest rate | — |  |  | — |  |  | 0.1% - 0.3% |  |  | 0.1% - 0.3% |  |
| Volatility | — | % |  | — | % |  | 31 | % |  | 37 | % |
| Dividend yield | — | % |  | — | % |  | 1.9 | % |  | 2.4 | % |

[0001045810-14-000158:notes:45]
[same as prior period, unchanged from 0001045810-14-000085:notes:54]

[0001045810-14-000158:notes:46]
[same as prior period, unchanged from 0001045810-14-000085:notes:55]

[0001045810-14-000158:notes:47]
|  | Options Outstanding |  | Weighted Average Exercise Price |
| Stock Options | (In thousands) |  | (Per share) |
| Balances, January 26, 2014 | 32,504 |  |  | $ | 14.22 |  |
| Granted | 86 |  |  | $ | 18.66 |  |
| Exercised | (6,291 | ) |  | $ | 12.89 |  |
| Cancelled | (942 | ) |  | $ | 18.89 |  |
| Balances, July 27, 2014 | 25,357 |  |  | $ | 14.39 |  |

[0001045810-14-000158:notes:48]
|  | RSUs and PSUs Outstanding |  | Weighted Average Grant-Date Fair Value |
| RSUs and PSUs | (In thousands) |  | (Per share) |
| Balances, January 26, 2014 | 18,852 |  |  | $ | 13.82 |  |
| Granted (1) | 3,729 |  |  | $ | 17.20 |  |
| Vested | (3,319 | ) |  | $ | 13.33 |  |
| Cancelled | (793 | ) |  | $ | 13.98 |  |
| Balances, July 27, 2014 | 18,469 |  |  | $ | 14.58 |  |

[0001045810-14-000158:notes:49]
(1)    Includes the total number of PSUs issuable if the maximum corporate financial performance target level for fiscal year 2015 is achieved. Depending on the actual level of achievement of the corporate performance goal at the end of fiscal year 2015, the range of PSUs issued could range from 1.4 million to 2.5 million shares.


## us-gaap:EarningsPerShareTextBlock

[0001045810-14-000158:notes:50]
Net Income Per Share

[0001045810-14-000158:notes:51]
[same as prior period, unchanged from 0001045810-14-000085:notes:61]

[0001045810-14-000158:notes:52]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 127,976 |  |  | $ | 96,448 |  |  | $ | 264,492 |  |  | $ | 174,339 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 558,223 |  |  | 585,345 |  |  | 558,657 |  |  | 601,109 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Equity awards outstanding | 12,349 |  |  | 6,661 |  |  | 11,942 |  |  | 4,942 |  |
| Denominator for diluted net income per share, weighted average shares | 570,572 |  |  | 592,006 |  |  | 570,599 |  |  | 606,051 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic net income per share | $ | 0.23 |  |  | $ | 0.16 |  |  | $ | 0.47 |  |  | $ | 0.29 |  |
| Diluted net income per share | $ | 0.22 |  |  | $ | 0.16 |  |  | $ | 0.46 |  |  | $ | 0.29 |  |
| Potentially dilutive securities excluded from diluted net income per share because their effect would have been anti-dilutive | 3,987 |  |  | 17,749 |  |  | 7,928 |  |  | 27,039 |  |

[0001045810-14-000158:notes:53]
The denominator for diluted net income per share for the three and six months ended July 27, 2014 did not include any effect from the 1.00% Convertible Senior Notes due 2018, or the Notes. The calculation of the dilution impact is based on the treasury stock method in accordance with Accounting Standards Codification, or ASC 260, Earnings per Share. Commencing after the fiscal quarter ended on April 27, 2014, the Notes will not impact the denominator for diluted net income per share unless the average price of our common stock, as calculated under the terms of the Notes, exceeds the conversion price of $20.16 per share. Likewise, the denominator for diluted net income per share will not include any effect from the warrants that were issued simultaneously with the Notes unless the average price of our common stock, as calculated under the terms of the warrants, exceeds $27.14 per share.

[0001045810-14-000158:notes:54]
The denominator for diluted net income per share for the three and six months ended July 27, 2014 also did not include any effect from the note hedges that were issued simultaneously with the Notes. In future periods, the denominator for diluted net income per share will exclude any effect of the note hedges, unless in the event an actual conversion of any or all of the Notes occurs, the shares that would be delivered to us under the note hedges are designed to neutralize the dilutive effect of the shares that we would issue under the Notes. Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Notes.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001045810-14-000158:notes:55]
|  |  |  | Fair Value Measurement as of July 27, 2014 Using |
|  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |
|  | July 27, 2014 |  | (Level 1) |  | (Level 2) |
|  | (In thousands) |
| Corporate debt securities (1) | $ | 2,043,430 |  |  | $ | — |  |  | $ | 2,043,430 |  |
| Debt securities issued by United States government agencies (2) | 700,161 |  |  | — |  |  | 700,161 |  |
| Debt securities issued by United States Treasury (3) | 587,311 |  |  | — |  |  | 587,311 |  |
| Asset-backed securities (3) | 411,528 |  |  | — |  |  | 411,528 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (3) | 261,422 |  |  | — |  |  | 261,422 |  |
| Money market funds (4) | 119,491 |  |  | 119,491 |  |  | — |  |
| Total cash equivalents and marketable securities | $ | 4,123,343 |  |  | $ | 119,491 |  |  | $ | 4,003,852 |  |

[0001045810-14-000158:notes:56]
| (1) | Includes $96.2 million in cash equivalents and $1.95 billion in marketable securities on the Condensed Consolidated Balance Sheet. |

[0001045810-14-000158:notes:57]
| (2) | Includes $36.7 million in cash equivalents and $663.5 million in marketable securities on the Condensed Consolidated Balance Sheet. |

[0001045810-14-000158:notes:58]
| (3) | Included in marketable securities on the Condensed Consolidated Balance Sheet. |

[0001045810-14-000158:notes:59]
| (4) | Included in cash equivalents on the Condensed Consolidated Balance Sheet |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-14-000158:notes:60]
Fair Value of Financial Assets and Liabilities

[0001045810-14-000158:notes:61]
Financial assets measured at fair value:

[0001045810-14-000158:notes:62]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets.  Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets.  Our available-for-sale securities are classified as having Level 2 inputs.  Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian.  There were no significant transfers between Levels 1 and 2 assets for the three and six months ended July 27, 2014.

[0001045810-14-000158:notes:63]
Financial assets measured at fair value are summarized below:

[0001045810-14-000158:notes:64]
| (4) | Included in cash equivalents on the Condensed Consolidated Balance Sheet. |

[0001045810-14-000158:notes:65]
Financial liabilities measured at fair value:

[0001045810-14-000158:notes:66]
We issued $1.5 billion Notes in December 2013. The Notes are carried at their original issuance value, net of unamortized debt discount, and are not marked to market each period. The estimated fair value of the Notes was $1.63 billion and $1.53 billion as of July 27, 2014 and January 26, 2014, respectively.  The estimated fair value of the Notes was determined on the basis of market prices observable for similar instruments and is considered Level 2 in the fair value hierarchy.  Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the Notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-14-000158:notes:67]
[same as prior period, unchanged from 0001045810-14-000085:notes:72]

[0001045810-14-000158:notes:68]
We recognized income tax expense of $26.6 million and $53.4 million for the three and six months ended July 27, 2014, respectively, and $15.4 million and $25.5 million for the three and six months ended July 28, 2013, respectively. Income tax expense as a percentage of income before taxes, or our effective tax rate, was 17.2% and 16.8% for the three and six months ended July 27, 2014, respectively, and 13.8% and 12.8% for the three and six months ended July 28, 2013, respectively.

[0001045810-14-000158:notes:69]
The increase in our effective tax rate in fiscal year 2015 as compared to the same period in the prior fiscal year was primarily related to the expiration of the U.S. federal research tax credit on December 31, 2013 which resulted in no tax benefit in the six months ended July 27, 2014.

[0001045810-14-000158:notes:70]
Our effective tax rate on income before tax for the first six months of fiscal year 2015 of 16.8% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate.  Further, our effective tax rate for the first six months of fiscal year 2015 of 16.8% differs from our annual projected effective tax rate as of the first six months of fiscal year 2015 of 19.1% due to favorable discrete events that occurred in the first six months of fiscal year 2015 primarily attributable to the tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-14-000158:notes:71]
Our effective tax rate on income before tax for the first six months of fiscal year 2014 of 12.8% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax and the benefit of the U.S. federal research tax credit.

[0001045810-14-000158:notes:72]
For the six months ended July 27, 2014, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties from our fiscal year ended January 26, 2014, other than the recognition of tax benefits upon the expiration of statute of limitation in certain non-U.S. jurisdictions in the six months ended July 27, 2014.

[0001045810-14-000158:notes:73]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where it is believed not more-likely-than-not that the position will be sustained upon examination, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of July 27, 2014, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-14-000158:notes:74]
[same as prior period, unchanged from 0001045810-14-000085:notes:79]

[0001045810-14-000158:notes:75]
[same as prior period, unchanged from 0001045810-14-000085:notes:80]

[0001045810-14-000158:notes:76]
|  | July 27, 2014 |  | January 26, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | Accumulated Amortization |  | Net CarryingAmount |
|  | (In thousands) |
| Acquisition-related intangible assets | $ | 189,239 |  |  | $ | (124,083 | ) |  | $ | 65,156 |  |  | $ | 189,239 |  |  | $ | (114,104 | ) |  | $ | 75,135 |  |
| Patents and licensed technology | 449,204 |  |  | (253,747 | ) |  | 195,457 |  |  | 446,196 |  |  | (225,319 | ) |  | 220,877 |  |
| Total intangible assets | $ | 638,443 |  |  | $ | (377,830 | ) |  | $ | 260,613 |  |  | $ | 635,435 |  |  | $ | (339,423 | ) |  | $ | 296,012 |  |

[0001045810-14-000158:notes:77]
Amortization expense associated with intangible assets for the three and six months ended July 27, 2014 was $19.3 million and $38.4 million, respectively.  Amortization expense associated with intangible assets for the three and six months ended July 28, 2013 was $18.6 million and $36.0 million, respectively. Amortization expense increased compared to the prior year primarily due to the addition of licensed technology, the purchase of certain assets of a business, and the addition of acquired in-process research and development technology that was determined to be complete.  Future amortization expense related to the net carrying amount of intangible assets at July 27, 2014 is estimated to be $40.0 million for the remainder of fiscal year 2015, $71.9 million in fiscal year 2016, $63.7 million in fiscal year 2017, $49.0 million in fiscal year 2018, $20.4 million in fiscal year 2019 and a total of $15.6 million in fiscal year 2020 and beyond.


## us-gaap:InventoryDisclosureTextBlock

[0001045810-14-000158:notes:78]
|  | July 27, |  | January 26, |
|  | 2014 |  | 2014 |
| Inventories: | (In thousands) |
| Raw materials | $ | 126,191 |  |  | $ | 126,896 |  |
| Work in-process | 85,895 |  |  | 94,844 |  |
| Finished goods | 175,348 |  |  | 166,025 |  |
| Total inventories | $ | 387,434 |  |  | $ | 387,765 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-14-000158:notes:79]
|  | July 27, 2014 |  | January 26, 2014 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In thousands) |
| Less than 1 year | $ | 1,296,254 |  |  | $ | 1,296,861 |  |  | $ | 1,883,132 |  |  | $ | 1,883,753 |  |
| Due in 1 - 5 years | 2,665,096 |  |  | 2,667,222 |  |  | 2,114,289 |  |  | 2,117,387 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 157,523 |  |  | 159,260 |  |  | 90,472 |  |  | 91,508 |  |
| Total | $ | 4,118,873 |  |  | $ | 4,123,343 |  |  | $ | 4,087,893 |  |  | $ | 4,092,648 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-14-000158:notes:80]
[same as prior period, unchanged from 0001045810-14-000085:notes:87]

[0001045810-14-000158:notes:81]
[same as prior period, unchanged from 0001045810-14-000085:notes:88]

[0001045810-14-000158:notes:82]
We performed an impairment review of our investment portfolio as of July 27, 2014. Based on our quarterly impairment review and having considered the guidance in the relevant accounting literature, we concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio as of July 27, 2014.

[0001045810-14-000158:notes:83]
The following is a summary of cash equivalents and marketable securities at July 27, 2014 and January 26, 2014:

[0001045810-14-000158:notes:84]
The following table provides the breakdown of the investments with unrealized losses at July 27, 2014:

[0001045810-14-000158:notes:85]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In thousands) |
| Corporate debt securities | $ | 664,945 |  |  | $ | (90 | ) |  | $ | 1,378,485 |  |  | $ | (1,340 | ) |  | $ | 2,043,430 |  |  | $ | (1,430 | ) |
| Debt securities of United States government agencies | 304,481 |  |  | (3 | ) |  | 395,680 |  |  | (213 | ) |  | 700,161 |  |  | (216 | ) |
| Debt securities issued by United States Treasury | 45,045 |  |  | (28 | ) |  | 542,266 |  |  | (41 | ) |  | 587,311 |  |  | (69 | ) |
| Asset-backed securities | 162,899 |  |  | (14 | ) |  | 248,629 |  |  | (296 | ) |  | 411,528 |  |  | (310 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | — |  |  | — |  |  | 261,422 |  |  | (1,340 | ) |  | 261,422 |  |  | (1,340 | ) |
| Total | $ | 1,177,370 |  |  | $ | (135 | ) |  | $ | 2,826,482 |  |  | $ | (3,230 | ) |  | $ | 4,003,852 |  |  | $ | (3,365 | ) |

[0001045810-14-000158:notes:86]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at July 27, 2014 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-14-000158:notes:87]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale at July 27, 2014 and January 26, 2014 and are shown below by contractual maturity.

[0001045810-14-000158:notes:88]
Net realized gains for the three and six months ended July 27, 2014 were not significant. Net realized gains for the three and six months ended July 28, 2013 were $1.6 million and $1.7 million, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001045810-14-000158:notes:89]
[same as prior period, unchanged from 0001045810-14-000085:notes:96]

[0001045810-14-000158:notes:90]
[same as prior period, unchanged from 0001045810-14-000085:notes:97]


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001045810-14-000158:notes:91]
|  | July 27, |  | January 26, |
|  | 2014 |  | 2014 |
| Other Long-Term Liabilities: | (In thousands) |
| Deferred income tax liability | $ | 192,702 |  |  | $ | 157,953 |  |
| Income taxes payable, long-term | 119,661 |  |  | 119,977 |  |
| Deferred revenue, long-term (1) | 40,063 |  |  | 172,199 |  |
| Asset retirement obligation | 7,386 |  |  | 11,056 |  |
| Other long-term liabilities | 14,301 |  |  | 13,940 |  |
| Total other long-term liabilities | $ | 374,113 |  |  | $ | 475,125 |  |

[0001045810-14-000158:notes:92]
(1)    Consists primarily of annual consideration received in advance of our performance obligation under our patent cross licensing agreement with Intel Corporation entered into in January 2011. The decrease in deferred revenue, long-term, is a result of revenue recognized during the six months ended July 27, 2014.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-14-000158:notes:93]
[same as prior period, unchanged from 0001045810-14-000085:notes:100]

[0001045810-14-000158:notes:94]
[same as prior period, unchanged from 0001045810-14-000085:notes:101]

[0001045810-14-000158:notes:95]
[same as prior period, unchanged from 0001045810-14-000085:notes:102]

[0001045810-14-000158:notes:96]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties.  Under limited circumstances, we may offer an extended limited warranty to customers for certain products.  Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product warranty liabilities for the three and six months ended July 27, 2014 and July 28, 2013 were as follows:

[0001045810-14-000158:notes:97]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands) |
| Balance at beginning of period | $ | 8,250 |  |  | $ | 14,833 |  |  | $ | 7,571 |  |  | $ | 14,874 |  |
| Additions | 1,155 |  |  | 3,482 |  |  | 3,189 |  |  | 4,900 |  |
| Deductions | (1,203 | ) |  | (841 | ) |  | (2,558 | ) |  | (2,300 | ) |
| Balance at end of period | $ | 8,202 |  |  | $ | 17,474 |  |  | $ | 8,202 |  |  | $ | 17,474 |  |

[0001045810-14-000158:notes:98]
[same as prior period, unchanged from 0001045810-14-000085:notes:105]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-14-000158:notes:99]
|  | Three Months Ended | Six Months Ended |
|  | July 27, 2014 |  | July 28, 2013 | July 27, 2014 |  | July 28, 2013 |
|  | (In thousands) |
| Reconciling items included in "All Other" category : |  |  |  |  |  |
| Revenue not allocated to reporting segments | $ | 66,000 |  |  | $ | 66,000 |  | $ | 132,000 |  |  | $ | 132,000 |  |
| Unallocated corporate operating expenses | (41,599 | ) |  | (41,171 | ) | (85,035 | ) |  | (85,668 | ) |
| Stock-based compensation | (38,415 | ) |  | (32,395 | ) | (73,936 | ) |  | (65,792 | ) |
| Acquisition-related costs | (9,173 | ) |  | (8,964 | ) | (18,614 | ) |  | (17,825 | ) |
| Other non-recurring expenses | — |  |  | (2,290 | ) | — |  |  | (2,290 | ) |
| Total | $ | (23,187 | ) |  | $ | (18,820 | ) | $ | (45,585 | ) |  | $ | (39,575 | ) |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001045810-14-000158:notes:100]
[same as prior period, unchanged from 0001045810-14-000085:notes:118]


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-14-000158:notes:101]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | (In thousands) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 330,917 |  |  | $ | 319,004 |  |  | $ | 703,776 |  |  | $ | 608,885 |  |
| China | 251,768 |  |  | 184,086 |  |  | 475,230 |  |  | 359,130 |  |
| United States | 206,128 |  |  | 163,796 |  |  | 379,063 |  |  | 349,774 |  |
| Other Asia Pacific | 150,799 |  |  | 165,117 |  |  | 305,649 |  |  | 332,374 |  |
| Other Americas | 83,055 |  |  | 76,531 |  |  | 174,818 |  |  | 141,538 |  |
| Europe | 80,157 |  |  | 68,704 |  |  | 167,075 |  |  | 140,276 |  |
| Total revenue | $ | 1,102,824 |  |  | $ | 977,238 |  |  | $ | 2,205,611 |  |  | $ | 1,931,977 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-14-000158:notes:102]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-14-000158:notes:103]
In June 2014, the Financial Accounting Standards Board, or FASB, issued new guidance related to stock-based compensation. The new guidance requires that a performance target that affects vesting, and that could be achieved after the requisite service period is rendered, be treated as a performance condition. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. We currently do not have awards with a performance target where the employee would be eligible to vest in the award regardless of whether the employee is rendering service on the date the performance target is achieved. Therefore, we believe, the adoption of this new accounting guidance will not have an impact on our consolidated financial statements.

[0001045810-14-000158:notes:104]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period.  Early adoption is not permitted.  We may adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.

[0001045810-14-000158:notes:105]
In July 2013, the FASB issued updated guidance regarding the presentation of unrecognized tax benefits when a net operating loss carry forward, similar tax loss, or tax credit carry forward exists. The guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carry forward, a similar tax loss, or a tax credit carry forward when settlement in this manner is available under the tax law. We adopted this guidance in our interim period ended April 27, 2014. The adoption of this guidance did not impact our consolidated financial statements.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-14-000158:notes:106]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In thousands) |
| Three Months Ended July 27, 2014 |  |  |  |  |  |  |  |
| Revenue | $ | 877,980 |  |  | $ | 158,844 |  |  | $ | 66,000 |  |  | $ | 1,102,824 |  |
| Depreciation and amortization expense | $ | 29,493 |  |  | $ | 14,562 |  |  | $ | 11,552 |  |  | $ | 55,607 |  |
| Operating income (loss) | $ | 240,908 |  |  | $ | (54,542 | ) |  | $ | (23,187 | ) |  | $ | 163,179 |  |
| Three Months Ended July 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 858,613 |  |  | $ | 52,625 |  |  | $ | 66,000 |  |  | $ | 977,238 |  |
| Depreciation and amortization expense | $ | 36,001 |  |  | $ | 15,431 |  |  | $ | 10,408 |  |  | $ | 61,840 |  |
| Operating income (loss) | $ | 207,914 |  |  | $ | (83,560 | ) |  | $ | (18,820 | ) |  | $ | 105,534 |  |
| Six Months Ended July 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,775,343 |  |  | $ | 298,268 |  |  | $ | 132,000 |  |  | $ | 2,205,611 |  |
| Depreciation and amortization expense | $ | 59,017 |  |  | $ | 28,730 |  |  | $ | 22,943 |  |  | $ | 110,690 |  |
| Operating income (loss) | $ | 476,104 |  |  | $ | (115,981 | ) |  | $ | (45,585 | ) |  | $ | 314,538 |  |
| Six Months Ended July 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,644,225 |  |  | $ | 155,752 |  |  | $ | 132,000 |  |  | $ | 1,931,977 |  |
| Depreciation and amortization expense | $ | 71,919 |  |  | $ | 28,953 |  |  | $ | 20,712 |  |  | $ | 121,584 |  |
| Operating income (loss) | $ | 366,440 |  |  | $ | (138,550 | ) |  | $ | (39,575 | ) |  | $ | 188,315 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-14-000158:notes:107]
[same as prior period, unchanged from 0001045810-14-000085:notes:123]

[0001045810-14-000158:notes:108]
[same as prior period, unchanged from 0001045810-14-000085:notes:124]

[0001045810-14-000158:notes:109]
[same as prior period, unchanged from 0001045810-14-000085:notes:125]

[0001045810-14-000158:notes:110]
[same as prior period, unchanged from 0001045810-14-000085:notes:126]

[0001045810-14-000158:notes:111]
[same as prior period, unchanged from 0001045810-14-000085:notes:127]

[0001045810-14-000158:notes:112]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-14-000158:notes:113]
Our CODM does not review any information regarding total assets on a reporting segment basis. We do not have intersegment revenue. The accounting policies for segment reporting are the same as for the Company as a whole.

[0001045810-14-000158:notes:114]
[same as prior period, unchanged from 0001045810-14-000085:notes:130]

[0001045810-14-000158:notes:115]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-14-000158:notes:116]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, |  | July 28, |  | July 27, |  | July 28, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenue: |  |  |  |  |  |  |  |
| Customer A | 11 | % |  | 11 | % |  | 10 | % |  | 11 | % |
| Customer B | 10 | % |  | 12 | % |  | 9 | % |  | 11 | % |

[0001045810-14-000158:notes:117]
Revenue from Customer A was attributable primarily to the GPU business for the three and six months ended July 27, 2014 and to both the GPU and Tegra Processor businesses for the three and six months ended July 28, 2013.  Revenue from Customer B was attributable to the GPU business for all comparative periods presented.

[0001045810-14-000158:notes:118]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:

[0001045810-14-000158:notes:119]
|  | July 27, 2014 |  | January 26, 2014 |
| Accounts Receivable: |  |  |  |
| Customer B | 21 | % |  | 23 | % |
| Customer C | 10 | % |  | 9 | % |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-14-000158:notes:120]
[same as prior period, unchanged from 0001045810-14-000085:notes:133]

[0001045810-14-000158:notes:121]
[same as prior period, unchanged from 0001045810-14-000085:notes:134]

[0001045810-14-000158:notes:122]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The second quarters of fiscal years 2015 and 2014 are both 13-week quarters.

[0001045810-14-000158:notes:123]
[same as prior period, unchanged from 0001045810-14-000085:notes:136]

[0001045810-14-000158:notes:124]
[same as prior period, unchanged from 0001045810-14-000085:notes:137]

[0001045810-14-000158:notes:125]
[same as prior period, unchanged from 0001045810-14-000085:notes:138]

[0001045810-14-000158:notes:126]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-14-000158:notes:127]
[same as prior period, unchanged from 0001045810-14-000085:notes:140]

[0001045810-14-000158:notes:128]
[same as prior period, unchanged from 0001045810-14-000085:notes:141]

[0001045810-14-000158:notes:129]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. Most recently, in November 2013, the Board extended the previously authorized repurchase program through January 2016 and authorized an additional $1.00 billion for an aggregate of $3.70 billion under the repurchase program. Through July 27, 2014, we have repurchased an aggregate of 188.7 million shares under our stock repurchase program for a total cost of $2.95 billion.  As of July 27, 2014, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $748.4 million through January 2016.

[0001045810-14-000158:notes:130]
[same as prior period, unchanged from 0001045810-14-000085:notes:143]

[0001045810-14-000158:notes:131]
In November 2013, we announced the intention to return $1.00 billion to shareholders in fiscal year 2015 in the form of share repurchases and cash dividends. During February 2014, we executed a $500.0 million accelerated share repurchase, or ASR, agreement with an investment bank that was completed in July 2014. Under the ASR, we have repurchased 27.4 million shares in aggregate at an average price of $18.23 per share, of which 20.6 million shares were delivered in the first quarter of fiscal year 2015 and 6.8 million shares were delivered in the second quarter of fiscal year 2015. The shares delivered resulted in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share. As of July 27, 2014, all shares delivered from the ASR have been placed into treasury stock.

[0001045810-14-000158:notes:132]
[same as prior period, unchanged from 0001045810-14-000085:notes:147]

[0001045810-14-000158:notes:133]
During the three and six months ended July 27, 2014, we paid $47.4 million and $94.2 million, respectively, in dividends to our common stockholders. These dividends were equivalent to $0.085 per share on a quarterly basis, or $0.34 per share on an annual basis.

[0001045810-14-000158:notes:134]
[same as prior period, unchanged from 0001045810-14-000085:notes:149]

[0001045810-14-000158:notes:135]
[same as prior period, unchanged from 0001045810-14-000085:notes:150]

[0001045810-14-000158:notes:136]
[same as prior period, unchanged from 0001045810-14-000085:notes:151]

[0001045810-14-000158:notes:137]
[same as prior period, unchanged from 0001045810-14-000085:notes:152]


## us-gaap:SubsequentEventsTextBlock

[0001045810-14-000158:notes:138]
Subsequent Event

[0001045810-14-000158:notes:139]
In August 2014, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we paid $310.0 million to purchase shares of our common stock and received 10.9 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.


## nvda:AssetPurchaseDisclosureTextBlock

[0001045810-14-000158:notes:140]
[same as prior period, unchanged from 0001045810-14-000085:notes:153]

[0001045810-14-000158:notes:141]
[same as prior period, unchanged from 0001045810-14-000085:notes:154]

[0001045810-14-000158:notes:142]
[same as prior period, unchanged from 0001045810-14-000085:notes:155]

[0001045810-14-000158:notes:143]
The 3dfx asset purchase price of $95.0 million and $4.2 million of direct transaction costs were allocated based on fair values presented below. The final allocation of the purchase price of the 3dfx assets is contingent upon the outcome of all of the 3dfx litigation. Please refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for further information regarding this litigation.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-14-000158:notes:144]
[same as prior period, unchanged from 0001045810-14-000085:notes:157]

[0001045810-14-000158:notes:145]
[same as prior period, unchanged from 0001045810-14-000085:notes:158]

[0001045810-14-000158:notes:146]
At July 27, 2014, we had outstanding inventory purchase obligations totaling $486.3 million.
