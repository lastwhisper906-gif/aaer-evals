# NVDA MD&A — 0001045810-14-000158


## mdna

[0001045810-14-000158:mdna:1]
[same as prior period, unchanged from 0001045810-14-000085:mdna:1]

[0001045810-14-000158:mdna:2]
[same as prior period, unchanged from 0001045810-14-000085:mdna:2]

[0001045810-14-000158:mdna:3]
[same as prior period, unchanged from 0001045810-14-000085:mdna:3]

[0001045810-14-000158:mdna:4]
NVIDIA, the NVIDIA logo, GEFORCE, GTX, ICERA, Jetson, Kepler, Maxwell, NVIDIA, NVIDIA GRID, NVLINK, Quadro, SHIELD, Tegra, and Tesla are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-14-000158:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 6. Selected Financial Data” of our Annual Report on Form 10-K for the fiscal year ended January 26, 2014 and “Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-14-000158:mdna:6]
[same as prior period, unchanged from 0001045810-14-000085:mdna:6]

[0001045810-14-000158:mdna:7]
[same as prior period, unchanged from 0001045810-14-000085:mdna:7]

[0001045810-14-000158:mdna:8]
[same as prior period, unchanged from 0001045810-14-000085:mdna:8]

[0001045810-14-000158:mdna:9]
[same as prior period, unchanged from 0001045810-14-000085:mdna:9]

[0001045810-14-000158:mdna:10]
[same as prior period, unchanged from 0001045810-14-000085:mdna:13]

[0001045810-14-000158:mdna:11]
[same as prior period, unchanged from 0001045810-14-000085:mdna:14]

[0001045810-14-000158:mdna:12]
[same as prior period, unchanged from 0001045810-14-000085:mdna:15]

[0001045810-14-000158:mdna:13]
[same as prior period, unchanged from 0001045810-14-000085:mdna:16]

[0001045810-14-000158:mdna:14]
[same as prior period, unchanged from 0001045810-14-000085:mdna:17]

[0001045810-14-000158:mdna:15]
[same as prior period, unchanged from 0001045810-14-000085:mdna:18]

[0001045810-14-000158:mdna:16]
[same as prior period, unchanged from 0001045810-14-000085:mdna:19]

[0001045810-14-000158:mdna:17]
[same as prior period, unchanged from 0001045810-14-000085:mdna:20]

[0001045810-14-000158:mdna:18]
[same as prior period, unchanged from 0001045810-14-000085:mdna:21]

[0001045810-14-000158:mdna:19]
[same as prior period, unchanged from 0001045810-14-000085:mdna:22]

[0001045810-14-000158:mdna:20]
[same as prior period, unchanged from 0001045810-14-000085:mdna:23]

[0001045810-14-000158:mdna:21]
During the second quarter of fiscal year 2015, we extended our reach in data center accelerated computing, with the world’s fifteen most highly efficient supercomputers all utilizing our Tesla GPUs.  We also surpassed forty million installations of our GeForce Experience client, which provides game-ready drivers, optimized play settings, and streaming and sharing of gameplay. We also invented the first GPU acceleration technology for Adobe Illustrator CC.

[0001045810-14-000158:mdna:22]
[same as prior period, unchanged from 0001045810-14-000085:mdna:24]

[0001045810-14-000158:mdna:23]
[same as prior period, unchanged from 0001045810-14-000085:mdna:25]

[0001045810-14-000158:mdna:24]
During the second quarter of fiscal year 2015, our Tegra K1 processor was previewed in Google’s new Android L and Project Tango tablets and was one of the first processors to support Android TV.  We expanded our SHIELD family of gaming devices with the launch of the SHIELD tablet, along with the SHIELD wireless controller.  BMW shipped new models, including the i8 and i3, with infotainment systems powered by NVIDIA, and Volkswagen announced that in addition to the Golf, Tegra will be included in the Passat later this year in Europe.

[0001045810-14-000158:mdna:25]
During the first quarter of fiscal year 2015, we launched Jetson TK1, a development platform aimed at automotive, robotics, defense and embedded applications.

[0001045810-14-000158:mdna:26]
[same as prior period, unchanged from 0001045810-14-000085:mdna:27]

[0001045810-14-000158:mdna:27]
During the first half of fiscal year 2015, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank that was completed in July 2014. Under the terms of this ASR, we paid $500.0 million to purchase shares of our common stock and received an aggregate of 27.4 million shares under this repurchase agreement of which 20.6 million shares were delivered in the first quarter and 6.8 million shares were delivered in the second quarter of fiscal year 2015.  Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding the ASR.  Additionally, we paid $94.2 million in cash dividends during the first half of fiscal year 2015.  As such, in the aggregate for the first half of fiscal year 2015, we returned a total of $594.2 million of our intended capital return of $1.00 billion to shareholders during fiscal year 2015.  Subsequently, in August 2014, we entered into an additional ASR to purchase $310.0 million in shares of our common stock.

[0001045810-14-000158:mdna:28]
[same as prior period, unchanged from 0001045810-14-000085:mdna:29]

[0001045810-14-000158:mdna:29]
[same as prior period, unchanged from 0001045810-14-000085:mdna:30]

[0001045810-14-000158:mdna:30]
[same as prior period, unchanged from 0001045810-14-000085:mdna:31]

[0001045810-14-000158:mdna:31]
[same as prior period, unchanged from 0001045810-14-000085:mdna:32]

[0001045810-14-000158:mdna:32]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-14-000158:mdna:33]
Our CODM does not review any information regarding total assets on a reporting segment basis. We do not have intersegment revenue. The accounting policies for segment reporting are the same as for the Company as a whole. Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding segment information.

[0001045810-14-000158:mdna:34]
[same as prior period, unchanged from 0001045810-14-000085:mdna:35]

[0001045810-14-000158:mdna:35]
[same as prior period, unchanged from 0001045810-14-000085:mdna:36]

[0001045810-14-000158:mdna:36]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | July 27, 2014 |  |  | July 28, 2013 |  |  | July 27, 2014 |  |  | July 28, 2013 |  |
| Revenue | 100.0 |  | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 43.9 |  |  |  | 44.2 |  |  | 44.5 |  |  | 44.9 |  |
| Gross profit | 56.1 |  |  |  | 55.8 |  |  | 55.5 |  |  | 55.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 30.6 |  |  |  | 33.9 |  |  | 30.4 |  |  | 34.1 |  |
| Sales, general and administrative | 10.8 |  |  |  | 11.1 |  |  | 10.8 |  |  | 11.2 |  |
| Total operating expenses | 41.4 |  |  |  | 45.0 |  |  | 41.2 |  |  | 45.3 |  |
| Operating income | 14.7 |  |  |  | 10.8 |  |  | 14.3 |  |  | 9.8 |  |
| Interest income | 0.6 |  |  |  | 0.4 |  |  | 0.6 |  |  | 0.5 |  |
| Interest expense | 1.0 |  |  |  | 0.1 |  |  | 1.0 |  |  | 0.1 |  |
| Other income (expense), net | (0.3 | ) |  |  | 0.3 |  |  | 0.6 |  |  | 0.2 |  |
| Income before income tax expense | 14.0 |  |  |  | 11.4 |  |  | 14.5 |  |  | 10.4 |  |
| Income tax expense | 2.4 |  |  |  | 1.6 |  |  | 2.4 |  |  | 1.3 |  |
| Net income | 11.6 |  | % |  | 9.8 | % |  | 12.1 | % |  | 9.1 | % |

[0001045810-14-000158:mdna:37]
Three and six months ended July 27, 2014 and July 28, 2013

[0001045810-14-000158:mdna:38]
[same as prior period, unchanged from 0001045810-14-000085:mdna:39]

[0001045810-14-000158:mdna:39]
|  | Three Months Ended |  | Six Months Ended |
|  | July 27, 2014 |  | July 28, 2013 |  | $Change |  | %Change |  | July 27, 2014 |  | July 28, 2013 |  | $Change |  | %Change |
|  | (In thousands) |  |  |  | (In thousands) |  |  |
| GPU | $ | 878.0 |  |  | $ | 858.6 |  |  | $ | 19.4 |  |  | 2 | % |  | $ | 1,775.3 |  |  | $ | 1,644.2 |  |  | $ | 131.1 |  |  | 8 | % |
| Tegra Processor | 158.8 |  |  | 52.6 |  |  | 106.2 |  |  | 202 | % |  | 298.3 |  |  | 155.8 |  |  | 142.5 |  |  | 91 | % |
| All Other | 66.0 |  |  | 66.0 |  |  | — |  |  | — | % |  | 132.0 |  |  | 132.0 |  |  | — |  |  | — | % |
| Total | $ | 1,102.8 |  |  | $ | 977.2 |  |  | $ | 125.6 |  |  | 13 | % |  | $ | 2,205.6 |  |  | $ | 1,932.0 |  |  | $ | 273.6 |  |  | 14 | % |

[0001045810-14-000158:mdna:40]
Revenue for the second quarter of fiscal year 2015 increased 13% when compared the second quarter of fiscal year 2014.  Revenue for the first half of fiscal year 2015 increased 14% when compared to the first half of fiscal year 2014.  A discussion of our revenue results for each of our operating segments is as follows:

[0001045810-14-000158:mdna:41]
GPU Business. GPU business revenue increased by 2% in the second quarter of fiscal year 2015 compared to the second quarter of fiscal year 2014. This increase was due primarily to higher revenue from Tesla and GRID products for data center and high performance computing, driven by large project wins and VDI deployments. Quadro revenue also increased, with growth in Kepler-based products for mobile workstations. Revenue from GeForce desktop and notebook GPU products for gaming grew, reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products.  Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-14-000158:mdna:42]
GPU business revenue increased by 8% in the first half of fiscal year 2015 compared to the first half of fiscal year 2014. This increase was due primarily to increased revenue from sales of GeForce GPU products for gaming, reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year. Tesla and GRID product revenues both increased, driven by large project wins and VDI deployments, and Quadro revenue increased due primarily to increased sales of our Kepler-based Quadro products.

[0001045810-14-000158:mdna:43]
Tegra Processor Business. Tegra Processor business revenue increased by 202% in the second quarter of fiscal year 2015 compared to the second quarter of fiscal year 2014, and by 91% in the first half of fiscal year 2015 compared to the first half of fiscal year 2014.  These increases were driven by sales of Tegra products serving smartphones, tablets and automobile infotainment systems.

[0001045810-14-000158:mdna:44]
All Other. We recognized $66.0 million and $132.0 million in revenue from the patent cross licensing arrangement with Intel during the second quarter of fiscal years 2015 and 2014, and the first half of fiscal years 2015 and 2014, respectively.

[0001045810-14-000158:mdna:45]
[same as prior period, unchanged from 0001045810-14-000085:mdna:45]

[0001045810-14-000158:mdna:46]
Revenue from sales to customers outside of the United States and Other Americas accounted for 74% of total revenue for the second quarter and 75% of total revenue for the first half of fiscal year 2015.  Revenue from sales to customers outside of the United States and Other Americas accounted for 75% of total revenue for both the second quarter and the first half of fiscal year 2014.  Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-14-000158:mdna:47]
Revenue from significant customers, those representing 10% or more of total revenue, was 21% of our total revenue from two customers for the second quarter of fiscal year 2015 and 10% of total revenue from one customer for the first half of fiscal year 2015.  Revenue from significant customers was 23% and 22% of our total revenue from two customers for the second quarter and first half of fiscal year 2014, respectively.

[0001045810-14-000158:mdna:48]
[same as prior period, unchanged from 0001045810-14-000085:mdna:48]

[0001045810-14-000158:mdna:49]
[same as prior period, unchanged from 0001045810-14-000085:mdna:49]

[0001045810-14-000158:mdna:50]
[same as prior period, unchanged from 0001045810-14-000085:mdna:50]

[0001045810-14-000158:mdna:51]
Our overall gross margin was 56.1% and 55.8% for the second quarter of fiscal years 2015 and 2014, respectively, and 55.5% and 55.1% for the first half of fiscal years 2015 and 2014, respectively.

[0001045810-14-000158:mdna:52]
Charges to cost of sales for inventory provisions totaled $12.7 million and $10.5 million for the second quarter of fiscal years 2015 and 2014, respectively, unfavorably impacting our gross margin by 1.1% for both periods. Sales of inventory that was previously written-off or written-down totaled $8.8 million and $13.8 million for the second quarter of fiscal years 2015 and 2014, respectively, favorably impacting our gross margin by 0.8% and 1.4%, respectively.  As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.3% unfavorable impact for the second quarter of fiscal year 2015 and a 0.3% favorable impact for the second quarter of fiscal year 2014.

[0001045810-14-000158:mdna:53]
Charges to cost of sales for inventory provisions totaled $22.9 million and $24.1 million for the first half of fiscal years 2015 and 2014, respectively, unfavorably impacting our gross margin by 1.0% and 1.2%, respectively. Sales of inventory that was previously written-off or written-down totaled $13.8 million and $30.9 million for the first half of fiscal years 2015 and 2014, respectively, favorably impacting our gross margin by 0.6% and 1.6%, respectively.  As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.4% unfavorable impact for the first half of fiscal year 2015 and a 0.4% favorable impact for the first half of fiscal year 2014.

[0001045810-14-000158:mdna:54]
[same as prior period, unchanged from 0001045810-14-000085:mdna:53]

[0001045810-14-000158:mdna:55]
GPU Business. The gross margin of our GPU business increased in the second quarter and first half of fiscal year 2015 compared to the second quarter and first half of fiscal year 2014. GPU margins increased primarily due to an increase in unit volume of our high-end GeForce GPU products, which contributed to a richer overall mix of product sales. Additionally, the volume increase of Kepler-based Quadro, Tesla and GRID products also contributed to a richer mix of GPU sales.

[0001045810-14-000158:mdna:56]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased in the second quarter and first half of fiscal year 2015 compared to the second quarter and first half of fiscal year 2014. Tegra Processor margins decreased across most product categories and were also negatively impacted by the decline in license and royalty revenue associated with game consoles compared to the prior year.

[0001045810-14-000158:mdna:57]
[same as prior period, unchanged from 0001045810-14-000085:mdna:56]

[0001045810-14-000158:mdna:58]
|  | Three Months Ended |  | Six Months Ended |  |
|  | July 27, 2014 |  | July 28, 2013 |  | $Change |  | %Change |  | July 27, 2014 |  | July 28, 2013 |  | $Change |  | %Change |  |
|  | (In millions) |  |  |  | ($ in millions) |  |  |  |
| Research and development expenses | $ | 337.1 |  |  | $ | 331.7 |  |  | $ | 5.4 |  |  | 2 | % | $ | 671.4 |  |  | $ | 658.9 |  |  | $ | 12.5 |  |  | 2 | % |
| Sales, general and administrative expenses | 118.7 |  |  | 108.3 |  |  | 10.4 |  |  | 10 | % | 237.3 |  |  | 216.9 |  |  | 20.4 |  |  | 9 | % |
| Total operating expenses | $ | 455.8 |  |  | $ | 440.0 |  |  | $ | 15.8 |  |  | 4 | % | $ | 908.7 |  |  | $ | 875.8 |  |  | $ | 32.9 |  |  | 4 | % |
| Research and development as a percentage of net revenue | 31 |  | % | 34 |  | % |  |  |  |  |  | 30 |  | % | 34 |  | % |  |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 11 |  | % | 11 |  | % |  |  |  |  |  | 11 |  | % | 11 |  | % |  |  |  |  |  |

[0001045810-14-000158:mdna:59]
[same as prior period, unchanged from 0001045810-14-000085:mdna:58]

[0001045810-14-000158:mdna:60]
Research and development expenses increased by 2% during the second quarter of fiscal year 2015 compared to the second quarter of fiscal year 2014. This increase was primarily due to a $10.4 million increase resulting from employee additions, employee compensation increases and related costs. That increase was partially offset by a $4.9 million decrease in engineering development expenses.

[0001045810-14-000158:mdna:61]
Research and development expenses increased by 2% during the first half of fiscal year 2015 compared to the first half of fiscal year 2014. This increase was primarily due to a $24.3 million increase resulting from employee additions, employee compensation increases and related costs due to the growth in hiring of engineering talent. That increase was partially offset by a $11.5 million decrease in engineering development expenses during the first half of fiscal year 2015.

[0001045810-14-000158:mdna:62]
[same as prior period, unchanged from 0001045810-14-000085:mdna:60]

[0001045810-14-000158:mdna:63]
Sales, general and administrative expenses increased by 10% during the second quarter of fiscal year 2015 compared to the second quarter of fiscal year 2014. This increase was primarily due to a $12.7 million increase resulting from employee additions, employee compensation increases and related costs, offset by a $2.3 million decrease in outside professional fees.

[0001045810-14-000158:mdna:64]
Sales, general and administrative expenses increased by 9% during the first half of fiscal year 2015 compared to the first half of fiscal year 2014. This increase was primarily due to a $24.6 million increase resulting from employee additions, employee compensation increases and related costs.  Facilities costs increased $7.4 million, as we expanded our offices internationally and leased an office building within the boundaries of our main Santa Clara campus.  These increases were partially offset by a $9.7 million decrease in outside professional fees as well as more favorable international taxes and government subsidies.

[0001045810-14-000158:mdna:65]
30

[0001045810-14-000158:mdna:66]
[same as prior period, unchanged from 0001045810-14-000085:mdna:62]

[0001045810-14-000158:mdna:67]
[same as prior period, unchanged from 0001045810-14-000085:mdna:63]

[0001045810-14-000158:mdna:68]
Interest income increased by $3.0 million and $3.6 million during the second quarter and first half of fiscal years 2015 and 2014, respectively. The increase was primarily due to higher average cash balances as we invested the proceeds from the convertible notes we issued in December 2013 in interest bearing securities.

[0001045810-14-000158:mdna:69]
Interest expense increased by $10.7 million and $21.3 million during the second quarter and first half of fiscal years 2015 and 2014, respectively. The increase was primarily due to coupon interest and debt discount amortization related to the convertible notes we issued in December 2013.

[0001045810-14-000158:mdna:70]
Other Income (Expense), net

[0001045810-14-000158:mdna:71]
Other income (expense), net consists primarily of realized gains and losses from the sale of marketable securities, sales of investments in non-affiliated companies, and the impact of changes in foreign currency rates.

[0001045810-14-000158:mdna:72]
Other income decreased by $4.0 million during the second quarter of fiscal year 2015 compared to the same period in the prior fiscal year. This decrease was due to lower realized gains from the sale of marketable securities and lower foreign currency translation gains. Other income increased by $12.9 million during the first half of fiscal year 2015 compared to the same period in the prior fiscal year due to a gain from the sale of a non-affiliated investment, offset by lower foreign currency translation gains.

[0001045810-14-000158:mdna:73]
Other expense increased by $3.1 million and $3.4 million during the second quarter and first half of fiscal years 2015 and 2014, respectively. This increase was due to the recognition of a $2.5 million impairment loss in a non-affiliated investment during the second quarter of fiscal year 2015. Additionally, losses from realized foreign exchange translations were greater in the first half of fiscal year 2015.

[0001045810-14-000158:mdna:74]
[same as prior period, unchanged from 0001045810-14-000085:mdna:68]

[0001045810-14-000158:mdna:75]
We recognized income tax expense of $26.6 million and $53.4 million for the second quarter and first half of fiscal year 2015, respectively, and $15.4 million and $25.5 million for the second quarter and first half of fiscal year 2014, respectively. Income tax expense as a percentage of income before taxes, or our effective tax rate, was 17.2% and 16.8% for the second quarter and first half of fiscal year 2015, respectively, and 13.8% and 12.8% for the second quarter and first half of fiscal year 2014, respectively.

[0001045810-14-000158:mdna:76]
The increase in our effective tax rate in fiscal year 2015 as compared to the same period in the prior fiscal year was primarily related to the expiration of the U.S. federal research tax credit on December 31, 2013 which resulted in no tax benefit in the first half of fiscal year 2015.

[0001045810-14-000158:mdna:77]
Our effective tax rate on income before tax for the first half of fiscal year 2015 of 16.8% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate.  Further, our effective tax rate for the first half of fiscal year 2015 of 16.8% differs from our annual projected effective tax rate as of the first half of fiscal year 2015 of 19.1% due to favorable discrete events that occurred in the first half of fiscal year 2015 primarily attributable to the tax benefit recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-14-000158:mdna:78]
Our effective tax rate on income before tax for the first half of fiscal year 2014 of 12.8% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax and the benefit of the U.S. federal research tax credit.

[0001045810-14-000158:mdna:79]
[same as prior period, unchanged from 0001045810-14-000085:mdna:73]

[0001045810-14-000158:mdna:80]
31

[0001045810-14-000158:mdna:81]
[same as prior period, unchanged from 0001045810-14-000085:mdna:74]

[0001045810-14-000158:mdna:82]
|  | As of July 27,2014 |  | As of January 26,2014 |
|  | (In millions) |
| Cash and cash equivalents | $ | 515.1 |  |  | $ | 1,151.6 |  |
| Marketable securities | 3,871.0 |  |  | 3,520.2 |  |
| Cash, cash equivalents, and marketable securities | $ | 4,386.1 |  |  | $ | 4,671.8 |  |

[0001045810-14-000158:mdna:83]
As of July 27, 2014, we had $4.39 billion in cash, cash equivalents and marketable securities, a decrease of $285.8 million from $4.67 billion as of January 26, 2014. This decrease was primarily due to the accelerated share repurchase transaction of $500.0 million that we entered into in February 2014 and $94.2 million in dividends, partially offset by cash generated from operations. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions that are required to follow our investment policy, which requires the purchase of high grade investment securities and the diversification of asset type and includes certain limits on our portfolio duration.

[0001045810-14-000158:mdna:84]
|  | Six Months Ended |
|  | July 27, |  | July 28, |
|  | 2014 |  | 2013 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 247.3 |  |  | $ | 272.1 |  |
| Net cash provided by (used in) investing activities | $ | (393.3 | ) |  | $ | 481.0 |  |
| Net cash used in financing activities | $ | (490.5 | ) |  | $ | (894.6 | ) |

[0001045810-14-000158:mdna:85]
[same as prior period, unchanged from 0001045810-14-000085:mdna:78]

[0001045810-14-000158:mdna:86]
[same as prior period, unchanged from 0001045810-14-000085:mdna:79]

[0001045810-14-000158:mdna:87]
Cash provided by operating activities decreased in the first half of fiscal year 2015, compared to the first half of fiscal year 2014. The decrease was primarily due to higher accounts receivable as a result of higher revenue and lower payables outstanding, partially offset by higher net income resulting from improved gross profit and contained operating expenses.

[0001045810-14-000158:mdna:88]
[same as prior period, unchanged from 0001045810-14-000085:mdna:81]

[0001045810-14-000158:mdna:89]
[same as prior period, unchanged from 0001045810-14-000085:mdna:82]

[0001045810-14-000158:mdna:90]
Investing activities used cash of $393.3 million and provided cash of $481.0 million during the first half of fiscal years 2015 and 2014, respectively. The shift to net cash used in investing activities from cash provided by investing activities was primarily due to higher purchases of marketable securities and fewer sales of marketable securities as we reinvested the proceeds received from the convertible note offering that was completed during December 2013. Offsetting this was a $99.1 million decrease in capital expenditures for the first half of fiscal year 2015, when compared to the first half of fiscal year 2014. The primary reason for net cash provided in the first half of fiscal year 2014 was the result of liquidation of a portion of our investment portfolio to fund the accelerated share repurchase transaction of $750.0 million that was entered into on May 2013.

[0001045810-14-000158:mdna:91]
[same as prior period, unchanged from 0001045810-14-000085:mdna:84]

[0001045810-14-000158:mdna:92]
[same as prior period, unchanged from 0001045810-14-000085:mdna:85]

[0001045810-14-000158:mdna:93]
Cash used in financing activities decreased in the first half of fiscal year 2015, compared to the first half of fiscal year 2014.  This was primarily due an accelerated share repurchase transaction of $500.0 million entered into in February 2014 when compared to $750.0 million in May 2013, partially offset by an increase in proceeds from common stock issued under employee stock plans.

[0001045810-14-000158:mdna:94]
[same as prior period, unchanged from 0001045810-14-000085:mdna:87]

[0001045810-14-000158:mdna:95]
[same as prior period, unchanged from 0001045810-14-000085:mdna:88]

[0001045810-14-000158:mdna:96]
[same as prior period, unchanged from 0001045810-14-000085:mdna:89]

[0001045810-14-000158:mdna:97]
As of July 27, 2014 and January 26, 2014, we had $4.39 billion and $4.67 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of July 27, 2014, we were in compliance with our investment policy.  As of July 27, 2014, our investments in government agencies and government-sponsored enterprises represented 38% of our total investment portfolio, while the financial sector accounted for 33% of our total investment portfolio.  All of our investments are with A/A3 or better rated securities.

[0001045810-14-000158:mdna:98]
We performed an impairment review of our investment portfolio as of July 27, 2014. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and did not record any impairment during the second quarter of fiscal year 2015.

[0001045810-14-000158:mdna:99]
Net realized gains for the second quarter and the first half of fiscal year 2015 were insignificant. Net realized gains for the second quarter and the first half of fiscal year 2014 were $1.6 million and $1.7 million, respectively. As of July 27, 2014, we had a net unrealized gain of $4.5 million, which was comprised of gross unrealized gains of $7.8 million, offset by gross unrealized losses of $3.4 million.  As of January 26, 2014, we had a net unrealized gain of $4.8 million, which was comprised of gross unrealized gains of $7.2 million, offset by $2.4 million of gross unrealized losses.

[0001045810-14-000158:mdna:100]
Our accounts receivable are highly concentrated. Two customers accounted for 31% of our accounts receivable balance at July 27, 2014. We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure.

[0001045810-14-000158:mdna:101]
[same as prior period, unchanged from 0001045810-14-000085:mdna:94]

[0001045810-14-000158:mdna:102]
Dividend payments and any stock repurchases must be made from cash held in the United States.  In the second quarter and first half of fiscal year 2015, we made total cash dividend payments of $47.4 million and $94.2 million, respectively and repurchased $500.0 million of our common stock, utilizing a significant amount of our U.S. cash balance previously taxed as of the end of the second quarter of fiscal year 2015.

[0001045810-14-000158:mdna:103]
[same as prior period, unchanged from 0001045810-14-000085:mdna:96]

[0001045810-14-000158:mdna:104]
Our Board of Directors has authorized us to repurchase up to $3.70 billion of our common stock through January 2016.  As of July 27, 2014, we had repurchased $2.95 billion of that amount, leaving up to $748.4 million available under this authorization through January 2016. We have announced our intention to return $1.0 billion to shareholders in fiscal year 2015 in the form of share repurchases and dividends. As part of our stock repurchase program, during February 2014 we entered into an accelerated share repurchase agreement to purchase $500.0 million in shares of our common stock, which we have completed. Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements or further disclosure regarding the accelerated share repurchase agreement. Subsequently, in August 2014, we entered into an additional ASR to purchase $310.0 million in shares of our common stock.

[0001045810-14-000158:mdna:105]
[same as prior period, unchanged from 0001045810-14-000085:mdna:98]

[0001045810-14-000158:mdna:106]
During the first half of fiscal year 2015, we paid $94.2 million in dividends to our common stockholders. This dividend was equivalent to $0.085 per share on a quarterly basis, or $0.34 per share on an annual basis.  We also declared that we would pay our next quarterly cash dividend of $0.085 per share on September 12, 2014, to all stockholders of record on August 21, 2014.

[0001045810-14-000158:mdna:107]
[same as prior period, unchanged from 0001045810-14-000085:mdna:100]

[0001045810-14-000158:mdna:108]
[same as prior period, unchanged from 0001045810-14-000085:mdna:101]

[0001045810-14-000158:mdna:109]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating, acquisition, stock repurchase, cash dividend and capital requirements for at least the next twelve months. However, there is no assurance that we will not need to raise additional equity or debt financing within this time frame. Additional financing may not be available on favorable terms or at all and may be dilutive to our then-current stockholders. We also may require additional capital for other purposes not presently contemplated.

[0001045810-14-000158:mdna:110]
For additional factors see “Item 1A. Risk Factors - Risks Related to Our Business, Industry and Partners - Our revenue may fluctuate while a majority of our operating expenses are a factor of multi-year investments ahead of when revenue is received, which makes our results difficult to predict and could cause our results to fall short of expectations.”

[0001045810-14-000158:mdna:111]
[same as prior period, unchanged from 0001045810-14-000085:mdna:108]

[0001045810-14-000158:mdna:112]
As of July 27, 2014, we had outstanding inventory purchase obligations totaling $486.3 million. There were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014.

[0001045810-14-000158:mdna:113]
[same as prior period, unchanged from 0001045810-14-000085:mdna:110]

[0001045810-14-000158:mdna:114]
[same as prior period, unchanged from 0001045810-14-000085:mdna:111]

[0001045810-14-000158:mdna:115]
As of July 27, 2014, we had no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001045810-14-000158:mdna:116]
34

[0001045810-14-000158:mdna:117]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-14-000158:mdna:118]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
