# NVDA notes — 0001045810-16-000205


## nvda:BalanceSheetComponentsTextBlock

[0001045810-16-000205:notes:1]
Balance Sheet Components

[0001045810-16-000205:notes:2]
Certain balance sheet components are as follows:

[0001045810-16-000205:notes:3]
|  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 105 |  |  | $ | 157 |  |
| Work in-process | 103 |  |  | 92 |  |
| Finished goods | 210 |  |  | 234 |  |
| Total inventories | $ | 418 |  |  | $ | 483 |  |

[0001045810-16-000205:notes:4]
As of January 31, 2016, we had outstanding inventory purchase obligations totaling $391 million.

[0001045810-16-000205:notes:5]
|  | January 31, 2016 |  | January 25, 2015 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Building | 13 |  |  | 19 |  |  | 25 |
| Test equipment | 354 |  |  | 397 |  |  | 3-5 |
| Software and licenses | 98 |  |  | 113 |  |  | 3-5 |
| Leasehold improvements | 174 |  |  | 174 |  |  | (B) |
| Computer equipment | 155 |  |  | 153 |  |  | 3-5 |
| Office furniture and equipment | 48 |  |  | 49 |  |  | 5 |
| Capital leases | 28 |  |  | 28 |  |  | (B) |
| Construction in process | 12 |  |  | 28 |  |  | (C) |
| Total property and equipment, gross | 1,100 |  |  | 1,179 |  |  |  |
| Accumulated depreciation and amortization | (634 | ) |  | (622 | ) |  |  |
| Total property and equipment, net | $ | 466 |  |  | $ | 557 |  |  |  |

[0001045810-16-000205:notes:6]
(A)  Land is a non-depreciable asset.

[0001045810-16-000205:notes:7]
(B)  Leasehold improvements and capital leases are amortized based on the lesser of either the asset’s estimated useful life or the remaining expected lease term.

[0001045810-16-000205:notes:8]
(C)  Construction in process represents assets that are not in service as of the balance sheet date.

[0001045810-16-000205:notes:9]
Depreciation expense for fiscal years 2016, 2015 and 2014 was $124 million, $143 million and $164 million, respectively.

[0001045810-16-000205:notes:10]
Accumulated amortization of leasehold improvements and capital leases was $155 million and $140 million as of January 31, 2016 and January 25, 2015, respectively. Amortization of leasehold improvements and capital leases is included in depreciation and amortization expense.

[0001045810-16-000205:notes:11]
|  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Accrued Liabilities: |  |  |  |
| Deferred revenue | $ | 322 |  |  | $ | 296 |  |
| Customer related liabilities (1) | 160 |  |  | 143 |  |
| Accrued payroll and related expenses | 79 |  |  | 112 |  |
| Accrued restructuring and other charges (2) | 23 |  |  | — |  |
| Professional service fees | 23 |  |  | 17 |  |
| Warranty accrual (3) | 11 |  |  | 8 |  |
| Coupon interest on Notes | 3 |  |  | 3 |  |
| Taxes payable, short- term | 2 |  |  | 3 |  |
| Facilities related liabilities | 1 |  |  | 8 |  |
| Other | 18 |  |  | 13 |  |
| Total accrued liabilities and other | $ | 642 |  |  | $ | 603 |  |

[0001045810-16-000205:notes:12]
(1)  Customer related liabilities primarily includes accrued customer programs, such as rebates and MDFs.

[0001045810-16-000205:notes:13]
(2)  Please refer to Note 17 of these Notes to the Consolidated Financial Statements for a discussion regarding restructuring and other charges.

[0001045810-16-000205:notes:14]
(3)  Please refer to Note 10 of these Notes to the Consolidated Financial Statements for a discussion regarding warranties.

[0001045810-16-000205:notes:15]
|  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Other Long Term Liabilities: |  |  |  |
| Deferred income tax liability | $ | 301 |  |  | $ | 232 |  |
| Income tax payable | 78 |  |  | 121 |  |
| Deferred revenue (1) | 44 |  |  | 108 |  |
| Interest rate swap (2) | 7 |  |  | — |  |
| Asset retirement obligations | 1 |  |  | 7 |  |
| Other | 22 |  |  | 21 |  |
| Total other long-term liabilities | $ | 453 |  |  | $ | 489 |  |

[0001045810-16-000205:notes:16]
(1)  Consists primarily of consideration received in advance of our performance obligations under the patent cross licensing agreement that we entered into with Intel Corporation in January 2011. The decrease in deferred revenue, long-term, is a result of revenue recognized during fiscal year 2016.

[0001045810-16-000205:notes:17]
(2)  Please refer to Note 9 of these Notes to the Consolidated Financial Statements for a discussion regarding our interest rate swap.


## nvda:ScheduleofRevenuebyMarketsTableTextBlock

[0001045810-16-000205:notes:18]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
| Revenue: | (In millions) |
| Gaming | $ | 2,818 |  |  | $ | 2,058 |  |  | $ | 1,511 |  |
| Professional Visualization | 750 |  |  | 795 |  |  | 789 |  |
| Datacenter | 339 |  |  | 317 |  |  | 199 |  |
| Automotive | 320 |  |  | 183 |  |  | 99 |  |
| OEM & IP | 783 |  |  | 1,329 |  |  | 1,532 |  |
| Total revenue | $ | 5,010 |  |  | $ | 4,682 |  |  | $ | 4,130 |  |


## nvda:ScheduleofaccountsreceivablepercentagesfromsignificantcustomerstextblockTableTextBlock

[0001045810-16-000205:notes:19]
|  | January 31, 2016 |  | January 25, 2015 |
| Accounts Receivable: |  |  |  |
| Customer B | 21 | % |  | 20 | % |
| Customer C | 8 | % |  | 10 | % |


## nvda:SummaryofequityawardsgrantedunderequityincentiveplansTableTextBlock

[0001045810-16-000205:notes:20]
|  | Year Ended |
|  | January 31, |  | January 25, |  | January 26, |
| 2016 |  | 2015 |  | 2014 |
|  | (In millions, except per share data) |
| Stock Options |  |  |  |  |  |
| Awards granted | — |  |  | — |  |  | 6 |  |
| Estimated total grant-date fair value | $ | — |  |  | $ | — |  |  | $ | 21 |  |
| Weighted average grant-date fair value (per share) | $ | — |  |  | $ | — |  |  | $ | 3.47 |  |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 13 |  |  | 13 |  |  | 11 |  |
| Estimated total grant-date fair value | $ | 296 |  |  | $ | 228 |  |  | $ | 145 |  |
| Weighted average grant-date fair value (per share) | $ | 22.01 |  |  | $ | 17.68 |  |  | $ | 13.46 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 6 |  |  | 7 |  |  | 6 |  |
| Weighted average price (per share) | $ | 13.67 |  |  | $ | 10.99 |  |  | $ | 10.79 |  |
| Weighted average grant-date fair value (per share) | $ | 4.53 |  |  | $ | 4.99 |  |  | $ | 5.60 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-16-000205:notes:21]
|  | January 31, |  | January 25, |
|  | 2016 |  | 2015 |
|  | (In millions) |
| Unearned stock-based compensation expense | $ | 381 |  |  | $ | 291 |  |
| Estimated weighted average remaining amortization period | (In years) |
| Stock Options | 1.1 |  |  | 1.8 |  |
| RSUs, PSUs and Market-based PSUs | 2.7 |  |  | 2.8 |  |
| ESPP | 0.7 |  |  | 0.5 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001045810-16-000205:notes:22]
Advertising Expenses

[0001045810-16-000205:notes:23]
We expense advertising costs in the period in which they are incurred. Advertising expenses for fiscal years 2016, 2015 and 2014 were $17 million, $15 million and $13 million, respectively.


## us-gaap:AssetRetirementObligationsAndEnvironmentalCostPolicyTextBlock

[0001045810-16-000205:notes:24]
Accounting for Asset Retirement Obligations

[0001045810-16-000205:notes:25]
We account for asset retirement obligations associated with the retirement of tangible long-lived assets and the associated asset retirement costs. As of January 31, 2016 and January 25, 2015, our asset retirement obligations to return the leasehold improvements at our headquarters facility and certain laboratories at our domestic and international facilities to their original condition upon lease termination were $2 million and $7 million, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-16-000205:notes:26]
|  | January 31, 2016 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,903 |  |  | $ | 1 |  |  | $ | (3 | ) |  | $ | 1,901 |  |
| Debt securities of United States government agencies | 1,170 |  |  | 1 |  |  | (1 | ) |  | 1,170 |  |
| Debt securities issued by United States Treasury | 800 |  |  | 1 |  |  | — |  |  | 801 |  |
| Asset-backed securities | 435 |  |  | — |  |  | — |  |  | 435 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 229 |  |  | 3 |  |  | (1 | ) |  | 231 |  |
| Foreign government bonds | 92 |  |  | — |  |  | — |  |  | 92 |  |
| Money market funds | 43 |  |  | — |  |  | — |  |  | 43 |  |
| Total | $ | 4,672 |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | 4,673 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 232 |  |
| Marketable securities |  |  |  |  |  |  | 4,441 |  |
| Total |  |  |  |  |  |  | $ | 4,673 |  |

[0001045810-16-000205:notes:27]
|  | January 25, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,185 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 2,186 |  |
| Debt securities of United States government agencies | 750 |  |  | — |  |  | — |  |  | 750 |  |
| Debt securities issued by United States Treasury | 534 |  |  | 3 |  |  | — |  |  | 537 |  |
| Asset-backed securities | 453 |  |  | — |  |  | — |  |  | 453 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 274 |  |  | 5 |  |  | (1 | ) |  | 278 |  |
| Money market funds | 132 |  |  | — |  |  | — |  |  | 132 |  |
| Foreign government bonds | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Total | $ | 4,413 |  |  | $ | 11 |  |  | $ | (3 | ) |  | $ | 4,421 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 295 |  |
| Marketable securities |  |  |  |  |  |  | 4,126 |  |
| Total |  |  |  |  |  |  | $ | 4,421 |  |

[0001045810-16-000205:notes:28]
The following table provides the breakdown of the investments with unrealized losses as of January 31, 2016:

[0001045810-16-000205:notes:29]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 950 |  |  | $ | (3 | ) |  | $ | 80 |  |  | $ | — |  |  | $ | 1,030 |  |  | $ | (3 | ) |
| Debt securities issued by United States government agencies | 692 |  |  | (1 | ) |  | — |  |  | — |  |  | 692 |  |  | (1 | ) |
| Mortgage backed securities issued by United States government-sponsored enterprises | 97 |  |  | (1 | ) |  | 31 |  |  | — |  |  | 128 |  |  | (1 | ) |
| Total | $ | 1,739 |  |  | $ | (5 | ) |  | $ | 111 |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | (5 | ) |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001045810-16-000205:notes:30]
Cash and Cash Equivalents

[0001045810-16-000205:notes:31]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. As of January 31, 2016 and January 25, 2015, our cash and cash equivalents were $596 million and $497 million, respectively, including $43 million and $132 million, respectively, invested in money market funds.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-16-000205:notes:32]
Commitments and Contingencies

[0001045810-16-000205:notes:33]
Inventory Purchase Obligations

[0001045810-16-000205:notes:34]
Capital Purchase Obligations

[0001045810-16-000205:notes:35]
As of January 31, 2016, we had outstanding capital purchase obligations totaling $36 million.

[0001045810-16-000205:notes:36]
Lease Obligations

[0001045810-16-000205:notes:37]
Our headquarters complex is located in Santa Clara, California and includes eight buildings that are leased properties. Future minimum lease payments related to headquarters operating leases total $69 million over the remaining terms of the leases, including predetermined rent escalations, and are included in the future minimum lease payment schedule below.

[0001045810-16-000205:notes:38]
In addition to the commitment of our headquarters, we have other domestic and international office facilities under operating leases expiring through fiscal year 2026. We also include non-cancelable obligations under certain software licensing arrangements as operating leases.

[0001045810-16-000205:notes:39]
Future minimum lease payments under our non-cancelable operating leases as of January 31, 2016, are as follows:

[0001045810-16-000205:notes:40]
|  | Future Minimum Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2017 | $ | 75 |  |
| 2018 | 65 |  |
| 2019 | 58 |  |
| 2020 | 35 |  |
| 2021 | 11 |  |
| 2022 and thereafter | 20 |  |
| Total | $ | 264 |  |

[0001045810-16-000205:notes:41]
Rent expense for the years ended January 31, 2016, January 25, 2015 and January 26, 2014 was $45 million, $47 million and $44 million, respectively.

[0001045810-16-000205:notes:42]
Capital lease obligations include building and office equipment lease obligations. The building lease relates to our datacenter in Santa Clara, California. Future minimum lease payments under the building capital lease total $17 million over the remaining lease term, including predetermined rent escalations, and are included in the future minimum lease payment schedule below:

[0001045810-16-000205:notes:43]
|  | Future Capital Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |  |
| 2017 | $ | 5 |  |
| 2018 | 6 |  |
| 2019 | 6 |  |
| Total | $ | 17 |  |
| Present value of minimum lease payments | $ | 14 |  |
| Current portion | $ | 4 |  |
| Long-term portion | $ | 10 |  |

[0001045810-16-000205:notes:44]
Operating Lease Financing Arrangement

[0001045810-16-000205:notes:45]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-16-000205:notes:46]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-16-000205:notes:47]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-16-000205:notes:48]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-16-000205:notes:49]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-16-000205:notes:50]
Litigation

[0001045810-16-000205:notes:51]
Patent Infringement Cases

[0001045810-16-000205:notes:52]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to exclude importation of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures, or the Accused Products. On October 6, 2014, the ITC instituted an investigation of NVIDIA’s claim. In June 2015, NVIDIA moved to terminate all asserted claims on four patents and these motions were granted. The ITC held an evidentiary hearing on certain asserted claims of the three remaining patents from June 22 through June 26, 2015. On October 9, 2015, the ITC Administrative Law Judge, or ALJ, rendered an initial determination that importation of the Samsung Accused Products did not violate U.S. law. NVIDIA petitioned for review of the ALJ’s determination and Samsung and Qualcomm filed contingent petitions for review of the ALJ’s determination. On December 14, 2015, the ITC decided not to review the ALJ’s determination and terminated the Investigation. On February 11, 2016, NVIDIA petitioned the United States Court of Appeals for the Federal Circuit to review the ITC’s decision not to review the ALJ’s determination. The petition is currently pending.

[0001045810-16-000205:notes:53]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm exercised their statutory right to stay the Delaware proceedings in light of the pending ITC action and the court granted the motion to stay on October 23, 2014.

[0001045810-16-000205:notes:54]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung amended its complaint twice, first on December 19, 2014, and then on April 10, 2015, without changing its legal claims. Samsung seeks monetary damages and certain injunctive relief as to some of the asserted patents. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction regarding two of the asserted patents and those patents were dismissed from the case with prejudice. Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015. On October 15, 2015, NVIDIA’s Motion for Entry of Judgment of Noninfringement was granted as to one of Samsung’s patents. On January 6, 2016, the Court dismissed plaintiff Samsung Electronics America, Inc. due to lack of subject matter jurisdiction.  On January 20, 2016, the Court dismissed with prejudice defendants Old Micro, Inc. and Velocity Holdings, LLC. On January 26, 2016, the Court dismissed with prejudice Samsung’s infringement claims as to one of the four remaining patents. Beginning January 26, 2016, a jury trial was held regarding Samsung’s patent infringement claims as to the three remaining patents. On February 1, 2016, the Court declared a mistrial as to two of the three remaining patents as a sanction based on Samsung’s failure to comply with its obligation to produce all materials its experts relied on in forming the experts’ opinions in the case. The trial continued as to the last patent. On February 5, 2016, the jury returned a verdict of non-infringement of that patent, that one of the four claims of that patent was invalid, and that Samsung was not entitled to any damages. The re-trial of Samsung’s infringement claims on the two remaining patents is scheduled to begin May 4, 2016.

[0001045810-16-000205:notes:55]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents and seeking exclusion and cease and desist orders barring importation of NVIDIA products alleged to infringe Samsung’s patents. On December 23, 2014, the ITC instituted an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case. A hearing on Samsung’s three remaining patents was held from August 18 through August 21, 2015. On December 22, 2015, the ALJ issued an Initial Determination, or ID, finding that NVIDIA and the other Respondents infringed the asserted claims of the three remaining asserted patents and had violated Section 337. On January 4, 2016, NVIDIA and the other Respondents filed a Petition for Review of the ALJ’s ID seeking review and reversal of his findings that the asserted claims were valid and infringed and that Section 337 had been violated. On January 4, 2016, the Office of Unfair Import Investigations also filed a Petition for Review of the ALJ’s ID seeking review and reversal of his findings that the asserted claims of one of the patents were valid and infringed and that Section 337 had been violated as to that patent. On February 24, 2016, the ITC determined to review in part the ALJ’s ID and asked for further briefing from the parties as to certain issues and patents. As the ITC did not seek to review the findings of infringement and validity of all three patents, the ITC may issue a limited exclusion order and a cease and desist order under one or more of the patents. The innovations claimed in these patents are minor and insignificant to the performance of our products. Based on our plans to modify certain impacted products and certain distribution operations in the United States, we do not believe that the possible entry of these orders will have a significant impact to our business. The target date for the final determination by the ITC is April 25, 2016, followed by the Presidential Review Period ending June 24, 2016.

[0001045810-16-000205:notes:56]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed eleven requests for inter partes review on eight of Samsung’s asserted patents. Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA, and Qualcomm has filed three additional requests for inter partes review on two patents asserted by NVIDIA. The United States Patent and Trademark Office has, to date, decided to review four patents owned by NVIDIA, and five patents owned by Samsung. The Patent and Trademark Office has declined to review two patents owned by Samsung. All other requests are currently pending.

[0001045810-16-000205:notes:57]
On December 21, 2015, Advanced Silicon Technologies LLC filed a complaint in the United States District Court for the District of Delaware alleging infringement of four patents relating to graphics processing and memory management. Advanced Silicon Technologies seeks monetary damages. On February 22, 2016, the Court granted NVIDIA’s unopposed motion to stay that lawsuit pending final resolution of Advanced Silicon Technologies’ parallel lawsuit in the ITC. On December 28, 2015, Advanced Silicon Technologies LLC filed a complaint in the ITC asserting the same four patents and seeking an exclusion order barring importation of NVIDIA products alleged to infringe those patents. On January 29, 2016, the ITC instituted an investigation of Advanced Silicon Technologies’ claims. NVIDIA responded to the ITC complaint on February 25, 2016. A hearing is scheduled for October 3 through October 7, 2016. An initial determination from the ITC ALJ is due February 2, 2017, and the target date for the final determination by the ITC is June 2, 2017.

[0001045810-16-000205:notes:58]
Accounting for Loss Contingencies

[0001045810-16-000205:notes:59]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of January 31, 2016, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001045810-16-000205:notes:60]
Product Warranties

[0001045810-16-000205:notes:61]
We generally offer limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001045810-16-000205:notes:62]
Stock-based Compensation

[0001045810-16-000205:notes:63]
We estimate the fair value of employee stock options on the date of grant using a binomial model and recognize the expense using a straight-line attribution method over the requisite employee service period. We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs, and we use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for stock options, RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001045810-16-000205:notes:64]
Comprehensive Income

[0001045810-16-000205:notes:65]
Comprehensive income consists of net income and other comprehensive income (loss). Other comprehensive income (loss) components include unrealized gains (losses) on available-for-sale securities and the net change in fair value of our interest rate swap, net of tax.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-16-000205:notes:66]
Principles of Consolidation

[0001045810-16-000205:notes:67]
Our consolidated financial statements include the accounts of NVIDIA Corporation and its wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001045810-16-000205:notes:68]
Restructuring and Other Charges

[0001045810-16-000205:notes:69]
Our restructuring and other charges include employee severance and related costs, the write-down of assets, and other exit costs. The severance and related costs include one-time termination benefits as well as certain statutory termination benefits or employee terminations under ongoing benefit arrangements. One-time termination benefits are recognized as a liability at estimated fair value when the approved plan of termination has been communicated to employees, unless employees must provide future service, in which case the benefits are recognized ratably over the future service period. Ongoing termination benefits arrangements are recognized as a liability at estimated fair value when the amount of such benefits becomes estimable and payment is probable. Any contract termination costs are recognized at estimated fair value when we terminate the contract in accordance with the contract terms. Other associated costs are recognized in the period the liability is incurred.


## us-gaap:DebtDisclosureTextBlock

[0001045810-16-000205:notes:70]
Convertible Debt

[0001045810-16-000205:notes:71]
1.00 % Convertible Senior Notes Due 2018

[0001045810-16-000205:notes:72]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of January 31, 2016, the initial conversion rate has been adjusted to 49.7009 shares of common stock per $1,000 principal amount of Notes (equivalent to an adjusted conversion price of $20.1204 per share of common stock) for dividend increases made to that date.

[0001045810-16-000205:notes:73]
Holders may convert all or any portion of their Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Notes regardless of the foregoing conditions.

[0001045810-16-000205:notes:74]
The price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended January 31, 2016. Therefore, as of January 31, 2016, the conversion threshold had been met and the Notes became convertible at the holders’ option beginning on February 1, 2016 and ending May 1, 2016. As such, the $1.41 billion carrying value of the Notes was classified as a current liability and the $87 million difference between the principal amount and the carrying value of the Notes was reclassified from shareholders’ equity to convertible debt conversion obligation in the mezzanine equity section of our Consolidated Balance Sheet as of January 31, 2016, and will remain there for as long as the Notes are convertible. The determination of whether or not the Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

[0001045810-16-000205:notes:75]
If the notes are converted, we will pay cash up to the aggregate principal amount of the Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Notes being converted. Based on the $29.29 closing price of our common stock on January 29, 2016, the last trading day of fiscal year 2016, the if-converted value of our Notes exceeded their principal amount by approximately $684 million.

[0001045810-16-000205:notes:76]
Concurrently with the issuance of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, structured to offset the potential common stock dilution, and/or offset potential cash payments to settle our excess conversion obligation. Cash-settled convertible debt is separated into debt and equity components at issuance and is assigned a fair value. The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-16-000205:notes:77]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes, represents the total unamortized debt discount of $148 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%. As of January 31, 2016, after reclassifying $87 million from the shareholders’ equity section of our Consolidated Balance Sheet to convertible debt conversion obligation in the mezzanine equity section of our Consolidated Balance Sheet, the remaining carrying value of the equity component in the shareholders’ equity section of our Consolidated Balance Sheet was $39 million.

[0001045810-16-000205:notes:78]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-16-000205:notes:79]
|  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Amount of the equity component | $ | 39 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (87 | ) |  | (116 | ) |
| Net carrying amount | $ | 1,413 |  |  | $ | 1,384 |  |

[0001045810-16-000205:notes:80]
(1) As of January 31, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.8 years.

[0001045810-16-000205:notes:81]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

[0001045810-16-000205:notes:82]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  | (In millions) |  |  |
| Contractual coupon interest expense | $ | 15 |  |  | $ | 15 |  |  | $ | 2 |  |
| Amortization of debt discount | 29 |  |  | 28 |  |  | 5 |  |
| Total interest expense related to Notes | $ | 44 |  |  | $ | 43 |  |  | $ | 7 |  |

[0001045810-16-000205:notes:83]
Note Hedges and Warrants

[0001045810-16-000205:notes:84]
The net proceeds from the Notes were approximately $1.48 billion after payment of the initial purchaser's discount. Concurrently with the offering of the Notes, we entered into Note Hedges with a strike price equal to the initial conversion price of the Notes, or $20.1630 per share. Adjusting for dividends paid through January 31, 2016, the conversion price of the Notes has been adjusted to $20.1204 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Notes upon conversion. We paid $167 million for the Note Hedges.

[0001045810-16-000205:notes:85]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of January 31, 2016, the strike price was adjusted to $27.0851 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary antidilution adjustments, 74 million shares of our common stock. We received $59 million for the Warrants transaction.

[0001045810-16-000205:notes:86]
The $108 million net cost of the Note Hedges offset by the proceeds from the Warrants was included as a net reduction to additional paid-in capital in the shareholders’ equity section of our Consolidated Balance Sheets.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-16-000205:notes:87]
Derivative Financial Instrument

[0001045810-16-000205:notes:88]
In August 2015, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building, which entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments.

[0001045810-16-000205:notes:89]
This interest rate swap, designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are currently recorded in accumulated other comprehensive income (loss) and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur. As of January 31, 2016, accumulated other comprehensive income (loss) includes a $7 million loss due to the decrease in fair value of the interest rate swap.

[0001045810-16-000205:notes:90]
A summary of the notional amount and fair value of the interest rate swap recorded on the Consolidated Balance Sheets at January 31, 2016 and January 25, 2015 is as follows (in millions):

[0001045810-16-000205:notes:91]
|  | Notional Amount |  | Fair Value Asset (Liability) |
|  | January 31, 2016 |  | January 25, 2015 |  | January 31, 2016 |  | January 25, 2015 |
| Cash Flow Hedge |  |  |  |  |  |  |  |
| Interest rate swap | $ | 200 |  |  | $ | — |  |  | $ | (7 | ) |  | $ | — |  |

[0001045810-16-000205:notes:92]
We formally assess, both at inception and on an ongoing basis, whether the interest rate swap is highly effective. For the year ended January 31, 2016, the interest rate swap was determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-16-000205:notes:93]
The effect of the interest rate swap on other comprehensive income (loss), net of tax, is as follows (in millions):

[0001045810-16-000205:notes:94]
|  | January 31, 2016 |  | January 25, 2015 |
| Cash Flow Hedge |  |  |  |
| Gain (loss) on interest rate swap | $ | (4 | ) |  | $ | — |  |

[0001045810-16-000205:notes:95]
Over the next twelve months, we do not expect to reclassify any amount from accumulated other comprehensive income (loss) to income as the underlying operating lease financing payments for our new headquarters building will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-16-000205:notes:96]
Stock-Based Compensation

[0001045810-16-000205:notes:97]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-16-000205:notes:98]
Our consolidated statements of income include stock-based compensation expense, net of amounts capitalized as inventory, as follows:

[0001045810-16-000205:notes:99]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  | (In millions) |
| Cost of revenue | $ | 15 |  |  | $ | 12 |  |  | $ | 11 |  |
| Research and development | 115 |  |  | 88 |  |  | 83 |  |
| Sales, general and administrative | 74 |  |  | 58 |  |  | 42 |  |
| Total | $ | 204 |  |  | $ | 158 |  |  | $ | 136 |  |

[0001045810-16-000205:notes:100]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2016, 2015 and 2014.

[0001045810-16-000205:notes:101]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-16-000205:notes:102]
Beginning fiscal year 2015, we shifted away from granting stock options and toward granting RSUs, PSUs and market-based PSUs to reflect changing market trends for equity incentives at our peer companies. The number of PSUs that will ultimately vest is contingent on the Company’s level of achievement versus the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year.

[0001045810-16-000205:notes:103]
Of the total fair value of equity awards, we estimated that the stock-based compensation expense related to the equity awards that are not expected to vest for fiscal years 2016, 2015 and 2014 was $46 million, $37 million and $30 million, respectively.

[0001045810-16-000205:notes:104]
The fair value of stock options granted under our stock option plans and shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-16-000205:notes:105]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  | (Using a binomial model) |
| Stock Options |  |  |  |  |  |
| Weighted average expected life (in years) | — |  |  | — |  |  | 2.4-3.5 |
| Risk-free interest rate | — |  |  | — |  |  | 1.8%-3.0% |
| Volatility | — |  |  | — |  |  | 28%-37% |
| Dividend yield | — |  |  | — |  |  | 1.9%-2.4% |

[0001045810-16-000205:notes:106]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.5-2.0 |  | 0.5-2.0 |  | 0.5-2.0 |
| Risk-free interest rate | 0.1%-0.7% |  | 0.1%-0.5% |  | 0.1%-0.4% |
| Volatility | 24%-34% |  | 23%-31% |  | 32%-37% |
| Dividend yield | 1.5%-1.8% |  | 1.7%-1.9% |  | 2.0%-2.4% |

[0001045810-16-000205:notes:107]
The expected life of employee stock options is a derived output of our valuation model and is impacted by the underlying assumptions of our company. For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value stock options and ESPP is based upon observed interest rates on Treasury bills appropriate for the expected term of the award. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted subsequent to November 7, 2012, we use the dividend yield at grant date. Our RSU, PSU and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs and market-based PSUs are discounted for the dividend yield.

[0001045810-16-000205:notes:108]
Additionally, for employee stock option, RSU, PSU and market-based PSU awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-16-000205:notes:109]
Equity Incentive Program

[0001045810-16-000205:notes:110]
We grant stock options, RSUs, PSUs, market-based PSUs and stock purchase rights under the following equity incentive plans.

[0001045810-16-000205:notes:111]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-16-000205:notes:112]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, which was subsequently amended and restated in 2012, 2013 and 2014, or the 2007 Plan.

[0001045810-16-000205:notes:113]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock unit, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. Up to 187,767,766 shares of our common stock may be issued pursuant to stock awards granted under the 2007 Plan. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 31, 2016, there were 13,538,400 shares available for future issuance.

[0001045810-16-000205:notes:114]
Stock options previously granted to employees, subject to certain exceptions, vest over a four year period, subject to continued service, with 25% vesting on the anniversary of the hire date in the case of new hires or the anniversary of the date of grant in the case of grants to existing employees and 6.25% vesting at the end of each quarterly period thereafter. Stock options previously granted under the 2007 Plan generally expire ten years from the date of grant.

[0001045810-16-000205:notes:115]
Subject to certain exceptions, RSUs granted to employees vest over a four year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 12.5% vesting semi-annually thereafter until fully vested.

[0001045810-16-000205:notes:116]
PSUs vest on a similar schedule as our RSUs. Market-based PSUs vest 100% on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-16-000205:notes:117]
Unless terminated sooner, the 2007 Plan is scheduled to terminate on March 21, 2022. Our Board may suspend or terminate the 2007 Plan at any time. No awards may be granted under the 2007 Plan while the 2007 Plan is suspended or after it is terminated. The Board may also amend the 2007 Plan at any time. However, if legal, regulatory or listing requirements require shareholder approval, the amendment will not go into effect until the shareholders have approved the amendment.

[0001045810-16-000205:notes:118]
2012 Employee Stock Purchase Plan

[0001045810-16-000205:notes:119]
In 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, which was subsequently amended and restated in 2014, or the 2012 Plan, as the successor to the 1998 Employee Stock Purchase Plan.

[0001045810-16-000205:notes:120]
Up to 65,235,816 shares of our common stock may be issued pursuant to purchases under the 2012 Plan. As of January 31, 2016, we had issued 18,459,901 shares and reserved 46,775,915 shares for future issuance under the 2012 Plan.

[0001045810-16-000205:notes:121]
The 2012 Plan is intended to qualify as an “employee stock purchase plan” under Section 423 of the Internal Revenue Code. Under the current offerings adopted pursuant to the 2012 Plan, each offering period is 24 months, which is divided into four purchase periods of six months.

[0001045810-16-000205:notes:122]
Employees are eligible to participate if they are employed by us or an affiliate of us as designated by the Board. Employees who participate in an offering may have up to 10% of their earnings withheld up to certain limitations and applied on specified dates determined by the Board to the purchase of shares of common stock. The Board may increase this percentage at its discretion, up to 15%. The price of common stock purchased under our ESPP will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the purchase date of each offering period. Employees may end their participation in the ESPP at any time during the offering period, and participation ends automatically on termination of employment with us. In each case, the employee’s contributions are refunded.

[0001045810-16-000205:notes:123]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-16-000205:notes:124]
|  | RSUs, PSUs and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number ofShares |  | WeightedAverageGrant-DateFair Value |  | Number ofShares |  | Weighted Average Exercise PricePer Share |  | WeightedAverageRemaining Contractual Life |  | Aggregate IntrinsicValue (3) |
|  | (In millions, except years and per share data) |
| Balances, January 25, 2015 | 23 |  |  | $ | 15.94 |  |  | 21 |  |  | $ | 14.61 |  |  |  |  |  |
| Granted (1)(2) | 13 |  |  | $ | 22.01 |  |  | — |  |  | $ | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  | (7 | ) |  | $ | 14.60 |  |  |  |  |  |
| Vested restricted stock | (8 | ) |  | $ | 15.56 |  |  | — |  |  | — |  |  |  |  |  |
| Canceled and forfeited | (2 | ) |  | $ | 16.63 |  |  | (1 | ) |  | $ | 17.28 |  |  |  |  |  |
| Balances, January 31, 2016 | 26 |  |  | $ | 19.12 |  |  | 13 |  |  | $ | 14.49 |  |  | 5.9 |  | $ | 197 |  |
| Exercisable as of January 31, 2016 |  |  |  |  | 11 |  |  | $ | 14.51 |  |  | 5.6 |  | $ | 159 |  |
| Vested and expected to vest after January 31, 2016 | 22 |  |  | $ | 19.14 |  |  | 13 |  |  | $ | 14.50 |  |  | 5.8 |  | $ | 191 |  |

[0001045810-16-000205:notes:125]
| (1) | Includes the total number of PSUs that became eligible to vest based on the corporate financial performance level achieved for fiscal year 2016. |

[0001045810-16-000205:notes:126]
| (2) | Includes the market-based PSUs that become eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs that become eligible to vest could range from 0 to 0.4 million shares. We granted market-based PSUs during the first quarter of fiscal year 2016 to our CEO and senior management as approved by our Compensation Committee. |

[0001045810-16-000205:notes:127]
| (3) | The aggregate intrinsic value in the table above represents the total pre-tax intrinsic value for in-the-money options at January 31, 2016, based on the $29.29 closing price of our common stock on January 29, 2016. |

[0001045810-16-000205:notes:128]
As of January 31, 2016 and January 25, 2015, there were 14 million and 25 million shares, respectively, of common stock reserved for future issuance under our equity incentive plans.

[0001045810-16-000205:notes:129]
The total intrinsic value of options exercised was $75 million, $62 million and $14 million for fiscal years 2016, 2015 and 2014, respectively. Upon exercise of an option, we issue new shares of stock. The total fair value of options vested was $17 million, $33 million and $35 million for fiscal years 2016, 2015 and 2014, respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001045810-16-000205:notes:130]
Net Income Per Share

[0001045810-16-000205:notes:131]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to the Consolidated Financial Statements. The potentially dilutive shares resulting from the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted income per share when their inclusion is dilutive. However, unless actually exercised, the note hedges will not be included in the calculation of diluted net income per share, as their pre-exercised effect would be anti-dilutive under the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001045810-16-000205:notes:132]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income per share computations for the periods presented:

[0001045810-16-000205:notes:133]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 614 |  |  | $ | 631 |  |  | $ | 440 |  |
| Denominator: |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 543 |  |  | 552 |  |  | 588 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Equity awards outstanding | 13 |  |  | 11 |  |  | 7 |  |
| Assumed conversion of 1% Convertible Senior Notes Due 2018 | 13 |  |  | — |  |  | — |  |
| Denominator for diluted net income per share, weighted average shares | 569 |  |  | 563 |  |  | 595 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.13 |  |  | $ | 1.14 |  |  | $ | 0.75 |  |
| Diluted | $ | 1.08 |  |  | $ | 1.12 |  |  | $ | 0.74 |  |
| Potentially dilutive securities excluded from income per diluted share because their effect would have been anti-dilutive | 10 |  |  | 12 |  |  | 26 |  |

[0001045810-16-000205:notes:134]
The 1.00% Convertible Senior Notes, or the Notes, are included in the calculation of diluted net income per share if their inclusion is dilutive. The Notes will generally have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.1204 per share. For the fiscal year ended January 31, 2016, our average stock price exceeded the conversion price, causing the Notes to have a dilutive impact for this period.

[0001045810-16-000205:notes:135]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transaction, or the Note Hedges, that we entered into concurrently with the issuance of the Notes, as its effect would be anti-dilutive. In the event an actual conversion of any or all of the Notes occurs, the shares that would be delivered to us under the Note Hedges are designed to neutralize the dilutive effect of the shares that we would issue under the Notes.

[0001045810-16-000205:notes:136]
The denominator for diluted net income per share will not include any effect from the warrants, which we entered into concurrently with the issuance of the Notes, unless our average stock price for the reporting period exceeds the adjusted strike price of $27.0851 per share.

[0001045810-16-000205:notes:137]
Please refer to Note 11 of these Notes to the Consolidated Financial Statements for additional discussion regarding the Notes.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-16-000205:notes:138]
Fair Value of Financial Assets and Liabilities

[0001045810-16-000205:notes:139]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. There were no significant transfers between Levels 1 and 2 assets for the year ended January 31, 2016. Level 3 assets are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances. Most of our cash equivalents and marketable securities are valued based on Level 2 inputs. We did not have any investments classified as Level 3 as of January 31, 2016.

[0001045810-16-000205:notes:140]
|  |  | Fair Value at |
|  | Pricing Category |  | January 31, 2016 |  | January 25, 2015 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and Marketable securities: |  |  |  |  |  |
| Corporate debt securities (1) | Level 2 |  | $ | 1,901 |  |  | $ | 2,186 |  |
| Debt securities of U.S. government agencies (2) | Level 2 |  | $ | 1,170 |  |  | $ | 750 |  |
| Debt securities issued by the U.S. Treasury (3) | Level 2 |  | $ | 801 |  |  | $ | 537 |  |
| Asset-backed securities (4) | Level 2 |  | $ | 435 |  |  | $ | 453 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (3) | Level 2 |  | $ | 231 |  |  | $ | 278 |  |
| Foreign government bonds (3) | Level 2 |  | $ | 92 |  |  | $ | 85 |  |
| Money market funds (5) | Level 1 |  | $ | 43 |  |  | $ | 132 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes Due 2018 (6) | Level 2 |  | $ | 2,273 |  |  | $ | 1,680 |  |
| Other noncurrent liability: |  |  |  |  |  |
| Interest rate swap (7) | Level 2 |  | $ | (7 | ) |  | $ | — |  |

[0001045810-16-000205:notes:141]
| (1) | Includes $51 million and $147 million in cash equivalents as of January 31, 2016 and January 25, 2015, respectively, and $1.85 billion and $2.04 billion in marketable securities as of January 31, 2016 and January 25, 2015, respectively, on the Consolidated Balance Sheets. |

[0001045810-16-000205:notes:142]
| (2) | Includes $90 million and $15 million in cash equivalents as of January 31, 2016 and January 25, 2015, respectively, and $1.08 billion and $735 million in marketable securities as of January 31, 2016 and January 25, 2015, respectively, on the Consolidated Balance Sheets. |

[0001045810-16-000205:notes:143]
| (3) | In marketable securities on the Consolidated Balance Sheets. |

[0001045810-16-000205:notes:144]
| (4) | Includes $435 million and $453 million in marketable securities as of January 31, 2016 and January 25, 2015, respectively, on the Consolidated Balance Sheets. |

[0001045810-16-000205:notes:145]
| (5) | In cash equivalents on the Consolidated Balance Sheets. |

[0001045810-16-000205:notes:146]
| (6) | The Notes are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount, and are not marked to fair value each period. Please refer to Note 11 of these Notes to the Consolidated Financial Statements for additional information on the Notes. |

[0001045810-16-000205:notes:147]
| (7) | Please refer to Note 9 of these Notes to the Consolidated Financial Statements for a discussion regarding our interest rate swap. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001045810-16-000205:notes:148]
Foreign Currency Remeasurement

[0001045810-16-000205:notes:149]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in “Other income, net” in our Consolidated Statements of Income and to date have not been significant.

[0001045810-16-000205:notes:150]
The impact of gain or loss from foreign currency remeasurement included in determining other income, net was not significant for both fiscal year 2016 and 2015, and was a gain of $5 million for fiscal year 2014.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001045810-16-000205:notes:151]
Goodwill

[0001045810-16-000205:notes:152]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist.  For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-16-000205:notes:153]
For those reporting units where a significant change or event has occurred, where potential impairment indicators exist, or for which we have not performed a quantitative assessment recently, we utilize a two-step quantitative assessment to testing goodwill for impairment. The first step tests for possible impairment by applying a fair value-based test by weighing the results from the income approach and the market approach. The second step, if necessary, measures the amount of such impairment by applying fair value-based tests to individual assets and liabilities. Please refer to Note 4 of these Notes to the Consolidated Financial Statements for additional information.

[0001045810-16-000205:notes:154]
Intangible Assets

[0001045810-16-000205:notes:155]
Intangible assets primarily represent rights acquired under technology licenses, patents, acquired intellectual property, trademarks and customer relationships and are subject to an annual impairment test. We currently amortize our intangible assets with definitive lives over periods ranging from one to ten years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-16-000205:notes:156]
The carrying amount of goodwill is as follows:

[0001045810-16-000205:notes:157]
|  | January 31, 2016 |  | January 25, 2015 |
|  | (In millions) |
| Icera | $ | 271 |  |  | $ | 271 |  |
| PortalPlayer | 105 |  |  | 105 |  |
| 3dfx | 50 |  |  | 50 |  |
| Mental Images | 59 |  |  | 59 |  |
| MediaQ | 35 |  |  | 35 |  |
| ULi | 31 |  |  | 31 |  |
| Hybrid Graphics | 28 |  |  | 28 |  |
| Ageia | 19 |  |  | 19 |  |
| Portland Group Inc. | 2 |  |  | 2 |  |
| Other | 18 |  |  | 18 |  |
| Total goodwill | $ | 618 |  |  | $ | 618 |  |

[0001045810-16-000205:notes:158]
The amount of goodwill allocated to our GPU and Tegra Processor segments was $210 million and $408 million, respectively, as of both January 31, 2016 and January 25, 2015. Please refer to Note 16 of these Notes to the Consolidated Financial Statements for further discussion regarding segments.

[0001045810-16-000205:notes:159]
We utilized a two-step quantitative analysis to complete our annual impairment test during the fourth quarter of fiscal year 2016 and concluded that there was no impairment, as the fair value of our reporting units exceeded their carrying values. The first step tests for possible impairment by applying a fair value-based test by weighing the results from the income approach and the market approach. The second step, if necessary, measures the amount of such impairment by applying fair value-based tests to individual assets and liabilities.

[0001045810-16-000205:notes:160]
These income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business. When performing an income approach valuation, we incorporate the use of projected financial information and a discount rate that are developed using market participant based assumptions to our discounted cash flow model. Our estimates of discounted cash flow were based upon, among other things, certain assumptions about our expected future operating performance, such as revenue growth rates, operating margins, risk-adjusted discount rates, and future economic and market conditions. The market method of determining the fair value of our reporting units requires us to use judgment in the selection of appropriate market comparables.


## us-gaap:GuaranteesTextBlock

[0001045810-16-000205:notes:161]
Guarantees

[0001045810-16-000205:notes:162]
U.S. GAAP requires that upon issuance of a guarantee, the guarantor must recognize a liability for the fair value of the obligation it assumes under that guarantee. In addition, U.S. GAAP requires disclosures about the guarantees that an entity has issued, including a tabular reconciliation of the changes of the entity’s product warranty liabilities.

[0001045810-16-000205:notes:163]
Accrual for Product Warranty Liabilities

[0001045810-16-000205:notes:164]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-16-000205:notes:165]
On July 31, 2015, we announced a voluntary recall and replacement of our SHIELD 8-inch tablets that were sold between July 2014 and July 2015. We had determined that the battery in these tablets can overheat, posing a fire hazard. The recall did not affect any other NVIDIA products. During fiscal year 2016, we recorded a $26 million charge against cost of revenue to cover anticipated customer warranty, repair, return, replacement and other associated costs.

[0001045810-16-000205:notes:166]
The estimated product returns and estimated product warranty liabilities for fiscal years 2016, 2015 and 2014 are as follows:

[0001045810-16-000205:notes:167]
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  | (In millions) |
| Balance at beginning of period | $ | 8 |  |  | $ | 8 |  |  | $ | 15 |  |
| Additions | 27 |  |  | 5 |  |  | 7 |  |
| Deductions | (24 | ) |  | (5 | ) |  | (14 | ) |
| Balance at end of period | $ | 11 |  |  | $ | 8 |  |  | $ | 8 |  |

[0001045810-16-000205:notes:168]
In connection with certain agreements that we have executed in the past, we have at times provided indemnities to cover the indemnified party for matters such as tax, product and employee liabilities. We have also on occasion included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. As such, we have not recorded any liability in our Consolidated Financial Statements for such indemnifications.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001045810-16-000205:notes:169]
Impairment of Long-Lived Assets

[0001045810-16-000205:notes:170]
Long-lived assets, such as property and equipment and intangible assets subject to amortization are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset, or asset group may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset, or asset group to estimated undiscounted future cash flows expected to be generated by the asset, or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-16-000205:notes:171]
Income Taxes

[0001045810-16-000205:notes:172]
The income tax expense applicable to income before income taxes consists of the following:

[0001045810-16-000205:notes:173]
|  | Year Ended |
|  | January 31,2016 |  | January 25,2015 |  | January 26,2014 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | (43 | ) |  | $ | 8 |  |  | $ | 8 |  |
| State | 1 |  |  | 1 |  |  | 1 |  |
| Foreign | 25 |  |  | 17 |  |  | 19 |  |
| Total current | (17 | ) |  | 26 |  |  | 28 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | 134 |  |  | 84 |  |  | 17 |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | — |  |  | (1 | ) |  | (2 | ) |
| Total deferred | 134 |  |  | 83 |  |  | 15 |  |
| Charge in lieu of taxes attributable to employer stock option plans | 12 |  |  | 15 |  |  | 27 |  |
| Income tax expense | $ | 129 |  |  | $ | 124 |  |  | $ | 70 |  |

[0001045810-16-000205:notes:174]
Income before income tax consists of the following:

[0001045810-16-000205:notes:175]
|  | Year Ended |
|  | January 31,2016 |  | January 25,2015 |  | January 26,2014 |
|  | (In millions) |
| Domestic | $ | 129 |  |  | $ | 174 |  |  | $ | 79 |  |
| Foreign | 614 |  |  | 581 |  |  | 431 |  |
| Income before income tax | $ | 743 |  |  | $ | 755 |  |  | $ | 510 |  |

[0001045810-16-000205:notes:176]
The income tax expense differs from the amount computed by applying the federal statutory income tax rate of 35% to income before income taxes as follows:

[0001045810-16-000205:notes:177]
|  | Year Ended |
|  | January 31,2016 |  | January 25,2015 |  | January 26,2014 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 260 |  |  | $ | 264 |  |  | $ | 178 |  |
| State income taxes, net of federal tax effect | 1 |  |  | 1 |  |  | 2 |  |
| Foreign tax rate differential | (95 | ) |  | (120 | ) |  | (94 | ) |
| U.S. federal R&D tax credit | (38 | ) |  | (34 | ) |  | (30 | ) |
| Stock-based compensation | 13 |  |  | 4 |  |  | 9 |  |
| Tax expense related to intercompany transaction | 10 |  |  | 10 |  |  | 10 |  |
| Restructuring and expiration of statute of limitations | (21 | ) |  | — |  |  | — |  |
| Other | (1 | ) |  | (1 | ) |  | (5 | ) |
| Income tax expense | $ | 129 |  |  | $ | 124 |  |  | $ | 70 |  |

[0001045810-16-000205:notes:178]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-16-000205:notes:179]
|  | January 31,2016 |  | January 25,2015 |
|  | (In millions) |
| Deferred tax assets: |  |
| Net operating loss carryforwards | $ | 57 |  |  | $ | 72 |  |
| Accruals and reserves, not currently deductible for tax purposes | 58 |  |  | 109 |  |
| Property, equipment and intangible assets | 50 |  |  | 46 |  |
| Research and other tax credit carryforwards | 404 |  |  | 351 |  |
| Stock-based compensation | 29 |  |  | 30 |  |
| Convertible debt | 9 |  |  | 12 |  |
| Gross deferred tax assets | 607 |  |  | 620 |  |
| Less valuation allowance | (272 | ) |  | (261 | ) |
| Total deferred tax assets | 335 |  |  | 359 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (17 | ) |  | (25 | ) |
| Unremitted earnings of foreign subsidiaries | (615 | ) |  | (500 | ) |
| Gross deferred tax liabilities | (632 | ) |  | (525 | ) |
| Net deferred tax liability | $ | (297 | ) |  | $ | (166 | ) |

[0001045810-16-000205:notes:180]
We recognized income tax expense of $129 million, $124 million and $70 million during fiscal years 2016, 2015, and 2014, respectively. Our annual effective tax rate, was 17.3% in fiscal year 2016, 16.5% in fiscal year 2015 and 13.8% in fiscal year 2014. The difference in the effective tax rates amongst the three years was primarily due to an increase in the amount of earnings subject to United States tax in fiscal years 2016 and 2015, partially offset by a net income tax benefit related to the Icera modem restructuring in fiscal year 2016, and a higher percentage of research tax credit benefit in fiscal year 2014.

[0001045810-16-000205:notes:181]
Our effective tax rate for each of the fiscal years was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate is lower than the United States federal statutory tax rate of 35%, favorable recognition in these fiscal years of the U.S. federal research tax credit and favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of the applicable statutes of limitations.

[0001045810-16-000205:notes:182]
As of January 31, 2016 and January 25, 2015 we had a valuation allowance of $272 million and $261 million, respectively,  related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-16-000205:notes:183]
Our deferred tax assets do not include the excess tax benefit related to stock-based compensation that are a component of our federal and state net operating loss and research tax credit carryforwards in the amount of $416 million as of January 31, 2016. Consistent with prior years, the excess tax benefit reflected in our net operating loss and research tax credit carryforwards will be accounted for as a credit to shareholders' equity, if and when realized.

[0001045810-16-000205:notes:184]
As of January 31, 2016, we had federal, state and foreign net operating loss carryforwards of $516 million, $664 million and $289 million, respectively. The federal and state carryforwards will expire beginning in fiscal year 2022 and 2017, respectively. The foreign net operating loss carryforwards of $275 million may be carried forward indefinitely and the remainder of $14 million will begin to expire in fiscal year 2017. As of January 31, 2016, we had federal research tax credit carryforwards of $476 million that will begin to expire in fiscal year 2018. We have state research tax credit carryforwards of $450 million, of which $432 million is attributable to the State of California and may be carried over indefinitely, and $18 million is attributable to various other states and will expire beginning in fiscal year 2017. We have other state tax credit carryforwards of $3 million that will expire in fiscal year 2026 and foreign tax credit carryforwards of $1 million, which may be refunded in fiscal years 2017 through 2020 if not utilized. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, states, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-16-000205:notes:185]
As of January 31, 2016, U.S. federal and state income taxes have not been provided on approximately $2.50 billion of undistributed earnings of non-United States subsidiaries as such earnings are considered to be indefinitely reinvested. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in our foreign subsidiaries as the determination of such amount is not practicable.

[0001045810-16-000205:notes:186]
As of January 31, 2016, we had $230 million of gross unrecognized tax benefits, of which $202 million would affect our effective tax rate if recognized. However, approximately $50 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $202 million of unrecognized tax benefits as of January 31, 2016 consisted of $67 million recorded in non-current income taxes payable and $135 million reflected as a reduction to the related deferred tax assets.

[0001045810-16-000205:notes:187]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-16-000205:notes:188]
|  | January 31,2016 |  | January 25,2015 |  | January 26,2014 |
|  | (In millions) |
| Balance at beginning of period | $ | 254 |  |  | $ | 238 |  |  | $ | 221 |  |
| Increases in tax positions for prior years | — |  |  | — |  |  | — |  |
| Decreases in tax positions for prior years | (1 | ) |  | (1 | ) |  | (1 | ) |
| Increases in tax positions for current year | 28 |  |  | 23 |  |  | 23 |  |
| Lapse in statute of limitations | (51 | ) |  | (6 | ) |  | (5 | ) |
| Balance at end of period | $ | 230 |  |  | $ | 254 |  |  | $ | 238 |  |

[0001045810-16-000205:notes:189]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable, if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-16-000205:notes:190]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 31, 2016, January 25, 2015, and January 26, 2014, we had accrued $11 million, $14 million, and $13 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 31, 2016, non-current income taxes payable of $78 million consisted of unrecognized tax benefits of $67 million and the related interest and penalties of $11 million.

[0001045810-16-000205:notes:191]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 31, 2016, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-16-000205:notes:192]
We are subject to taxation by a number of taxing authorities both in the United States and throughout the world. As of January 31, 2016, the material tax jurisdictions that may be subject to examination include the United States, Taiwan, Canada, China, Germany, Hong Kong, France, Japan, and India for fiscal years 2003 through 2015. As of January 31, 2016, the material tax jurisdictions for which we are currently under examination include the state of California for fiscal years 2011 through 2012, and India, Taiwan, France and Germany for fiscal years 2003 through 2015.


## us-gaap:IncomeTaxPolicyTextBlock

[0001045810-16-000205:notes:193]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-16-000205:notes:194]
United States income tax has not been provided on a portion of earnings of our non-U.S. subsidiaries to the extent that such earnings are considered to be indefinitely reinvested.

[0001045810-16-000205:notes:195]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-16-000205:notes:196]
As of January 31, 2016, we had a valuation allowance of $272 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due, in part, to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-16-000205:notes:197]
We recognize excess tax benefit related to stock-based compensation as a credit to shareholders' equity if and when realized. In determining if and when excess tax benefits have been realized, we have elected to utilize the with-and-without approach with respect to such excess tax benefits. We have also elected to ignore the indirect tax effects of stock-based compensation deductions for financial and accounting reporting purposes, and specifically to recognize the full effect of the research tax credit in income from operations.

[0001045810-16-000205:notes:198]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. Please refer to Note 13 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-16-000205:notes:199]
Amortizable Intangible Assets

[0001045810-16-000205:notes:200]
The components of our amortizable intangible assets are as follows:

[0001045810-16-000205:notes:201]
|  | January 31, 2016 |  | January 25, 2015 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageUseful Life |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageUseful Life |
|  | (In millions) |  | (In years) |  | (In millions) |  | (In years) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (152 | ) |  | $ | 41 |  |  | 7.0 |  | $ | 189 |  |  | $ | (134 | ) |  | $ | 55 |  |  | 6.8 |
| Patents and licensed technology | 462 |  |  | (337 | ) |  | 125 |  |  | 7.0 |  | 449 |  |  | (282 | ) |  | 167 |  |  | 7.2 |
| Total intangible assets | $ | 655 |  |  | $ | (489 | ) |  | $ | 166 |  |  |  |  | $ | 638 |  |  | $ | (416 | ) |  | $ | 222 |  |  |  |

[0001045810-16-000205:notes:202]
Amortization expense associated with intangible assets for fiscal years 2016, 2015 and 2014 was $73 million, $77 million and $73 million, respectively. Future amortization expense for the net carrying amount of intangible assets as of January 31, 2016 is estimated to be $67 million in fiscal year 2017, $52 million in fiscal year 2018, $24 million in fiscal year 2019, $16 million in fiscal year 2020, and $7 million in fiscal year 2021 until fully amortized.


## us-gaap:InventoryPolicyTextBlock

[0001045810-16-000205:notes:203]
Inventories

[0001045810-16-000205:notes:204]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.


## us-gaap:InvestmentPolicyTextBlock

[0001045810-16-000205:notes:205]
Fair Value of Financial Instruments

[0001045810-16-000205:notes:206]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 31, 2016 and January 25, 2015. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains (losses) included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains (losses) are recognized in earnings in the periods of change together with the offsetting losses (gains) on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains (losses) on the derivatives is initially reported as a component of other comprehensive income (loss) and is subsequently recognized in earnings when the hedged exposure is recognized in earnings.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-16-000205:notes:207]
|  | January 31, 2016 |  | January 25, 2015 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 1,619 |  |  | $ | 1,619 |  |  | $ | 1,570 |  |  | $ | 1,570 |  |
| Due in 1 - 5 years | 3,019 |  |  | 3,020 |  |  | 2,720 |  |  | 2,726 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 34 |  |  | 34 |  |  | 123 |  |  | 125 |  |
| Total | $ | 4,672 |  |  | $ | 4,673 |  |  | $ | 4,413 |  |  | $ | 4,421 |  |


## us-gaap:LeasePolicyTextBlock

[0001045810-16-000205:notes:208]
Rent Expense

[0001045810-16-000205:notes:209]
We recognize rent expense on a straight-line basis over the lease period and accrue for rent expense incurred, but not paid.


## us-gaap:LegalCostsPolicyTextBlock

[0001045810-16-000205:notes:210]
Litigation, Investigation and Settlement Costs

[0001045810-16-000205:notes:211]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. We are aggressively defending our current litigation matters. However, there are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If that occurs, our business, financial condition and results of operations could be materially and adversely affected. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-16-000205:notes:212]
Marketable Securities

[0001045810-16-000205:notes:213]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax, and net realized gains and losses recorded in other income, net, on the Consolidated Statements of Income.

[0001045810-16-000205:notes:214]
The following is a summary of cash equivalents and marketable securities as of January 31, 2016 and January 25, 2015:

[0001045810-16-000205:notes:215]
We performed an impairment review of our investment portfolio as of January 31, 2016. Factors considered included general market conditions, the duration and extent to which fair value is below cost, and our intent and ability to hold an investment for a sufficient period of time to allow for recovery in value. We also consider specific adverse conditions related to the financial health of and business outlook for an investee, including industry and sector performance, changes in technology, operational and financing cash flow factors, and changes in an investee’s credit rating. Investments that we identify as having an indicator of impairment are subject to further analysis to determine if the investment was other than temporarily impaired. Based on our quarterly impairment review and having considered the guidance in the relevant accounting literature, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of January 31, 2016.

[0001045810-16-000205:notes:216]
As of January 31, 2016, we had nine investments that were in an unrealized loss position with total unrealized losses amounting to $5 million and with a duration of less than one year. The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities as of January 31, 2016 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-16-000205:notes:217]
Net realized gains were $2 million for both fiscal year 2016 and 2014 and were not significant for fiscal year 2015.  As of January 31, 2016, net unrealized gain was not significant. As of January 25, 2015, we had a net unrealized gain of $8 million, which was comprised of gross unrealized gains of $11 million, offset by $3 million of gross unrealized losses.

[0001045810-16-000205:notes:218]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of January 31, 2016 and January 25, 2015 and are shown below by contractual maturity.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-16-000205:notes:219]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-16-000205:notes:220]
In February 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases. The objective of the update is to increase transparency and comparability among organizations by recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. In addition, the update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements, however, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

[0001045810-16-000205:notes:221]
In November 2015, the FASB issued an accounting standards update to simplify the presentation of deferred income taxes.  The new guidance requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The update is effective for fiscal years beginning after December 15, 2016, including interim periods within that reporting period. Early adoption is permitted and may be applied either prospectively or retrospectively. We adopted this update in the fourth quarter of fiscal year 2016 on a prospective basis. Prior reporting periods were not retrospectively adjusted. The adoption of this guidance had no impact on our Consolidated Statements of Income.

[0001045810-16-000205:notes:222]
In July 2015, the FASB issued an accounting standards update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-16-000205:notes:223]
In April 2015, the FASB issued an accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-16-000205:notes:224]
In April 2015, the FASB issued an accounting standards update that provides clarification on whether a cloud computing arrangement includes a software license. If a software license is included, the customer should account for the license consistent with its accounting for other software licenses. If a software license is not included, the arrangement should be accounted for as a service contract. The update is effective for reporting periods beginning after December 15, 2015, with early adoption permitted. Companies can elect to adopt the standard update prospectively or retrospectively to arrangements entered into, or materially modified, after the effective date. The update will be effective for us beginning in our first quarter of fiscal year 2017. We expect the adoption of this accounting guidance to result in an increase in software license assets and related depreciation expense, and a corresponding decrease in prepaid service contract assets and related service contract expense in our consolidated financial statements.

[0001045810-16-000205:notes:225]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-16-000205:notes:226]
Employee Retirement Plans

[0001045810-16-000205:notes:227]
We have a 401(k) retirement plan covering substantially all of our United States employees. Under the plan, participating employees may defer up to 100% of their pre-tax earnings, subject to the Internal Revenue Service annual contribution limits. Effective January 2013, we began matching a portion of the employee contributions. Our contribution expense in fiscal years 2016, 2015 and 2014 was $8 million, $6 million and $5 million, respectively. We also have defined contribution retirement plans outside of the United States to which we contributed $21 million, $20 million and $16 million for fiscal years 2016, 2015 and 2014, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001045810-16-000205:notes:228]
Property and Equipment

[0001045810-16-000205:notes:229]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to twenty five years. Depreciation expense includes the amortization of assets recorded under capital leases. Leasehold improvements and assets recorded under capital leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001045810-16-000205:notes:230]
Quarterly Summary (Unaudited)

[0001045810-16-000205:notes:231]
The following table sets forth our unaudited consolidated financial results, for the last eight fiscal quarters:

[0001045810-16-000205:notes:232]
|  | Fiscal Year 2016Quarters Ended |
|  | January 31, 2016 |  | October 25, 2015 |  | July 26,2015 |  | April 26, 2015 |
|  | (In millions, except per share data) |
| Statement of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 1,401 |  |  | $ | 1,305 |  |  | $ | 1,153 |  |  | $ | 1,151 |  |
| Cost of revenue | $ | 610 |  |  | $ | 572 |  |  | $ | 519 |  |  | $ | 498 |  |
| Gross profit | $ | 791 |  |  | $ | 733 |  |  | $ | 634 |  |  | $ | 653 |  |
| Net income | $ | 207 |  |  | $ | 247 |  |  | $ | 26 |  |  | $ | 134 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | 0.45 |  |  | $ | 0.05 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.44 |  |  | $ | 0.05 |  |  | $ | 0.24 |  |

[0001045810-16-000205:notes:233]
|  | Fiscal Year 2015Quarters Ended |
|  | January 25, 2015 |  | October 26, 2014 |  | July 27,2014 |  | April 27, 2014 |
|  | (In millions, except per share data) |
| Statement of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 1,251 |  |  | $ | 1,225 |  |  | $ | 1,103 |  |  | $ | 1,103 |  |
| Cost of revenue | $ | 552 |  |  | $ | 548 |  |  | $ | 484 |  |  | $ | 499 |  |
| Gross profit | $ | 699 |  |  | $ | 677 |  |  | $ | 619 |  |  | $ | 604 |  |
| Net income | $ | 193 |  |  | $ | 173 |  |  | $ | 128 |  |  | $ | 137 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.32 |  |  | $ | 0.23 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.31 |  |  | $ | 0.22 |  |  | $ | 0.24 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001045810-16-000205:notes:234]
Accounts Receivable

[0001045810-16-000205:notes:235]
We maintain an allowance for doubtful accounts receivable for estimated losses resulting from the inability of our customers to make required payments. We determine this allowance, which consists of an amount identified for specific customer issues as well as an amount based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-16-000205:notes:236]
In May 2015, we announced our intent to wind down our Icera modem operations and that we were open to a sale of the technology or operations. We pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations in the second quarter of fiscal year 2016.

[0001045810-16-000205:notes:237]
The results of any ongoing Icera modem operations were reported in the Tegra Processor reportable segment during fiscal year 2016 and previous fiscal years, however, restructuring and other charges associated with the wind-down of the Icera modem operations are separately reported with other non-recurring charges and benefits that our CODM deems to be enterprise in nature. Please refer to Note 16 of these Notes to the Consolidated Financial Statements for a discussion regarding our reportable segments.

[0001045810-16-000205:notes:238]
Our operating expenses for fiscal year 2016 included $131 million of restructuring and other charges. During fiscal year 2016, we also recognized an income tax benefit of $49 million from a tax reserve release upon the expiration of applicable statutes of limitations and a $27 million income tax charge for the write-down of a deferred tax asset, both of which related to our Icera modem operations.

[0001045810-16-000205:notes:239]
|  | Year Ended |
|  | January 31, |
|  | 2016 |
|  | (In millions) |
| Employee severance and related costs | $ | 82 |  |
| Fixed assets impairment | 18 |  |
| Tax subsidy impairment | 17 |  |
| Facilities and related costs | 9 |  |
| Other exit costs | 5 |  |
| Restructuring and other charges | $ | 131 |  |

[0001045810-16-000205:notes:240]
We expect to incur additional restructuring charges to operating expense of approximately $1 million to $2 million per quarter for each of the first two quarters of fiscal year 2017, after which we expect the restructuring of Icera operations to be substantially complete. These restructuring activities impacted approximately 5% of our global workforce. The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Consolidated Balance Sheets as of January 31, 2016:

[0001045810-16-000205:notes:241]
|  | January 31, |
|  | 2016 |
|  | (In millions) |
| Balance at beginning of period | $ | — |  |
| Restructuring and other charges | 131 |  |
| Cash payments | (63 | ) |
| Non-cash adjustments | (45 | ) |
| Balance at end of period | $ | 23 |  |

[0001045810-16-000205:notes:242]
The remaining balance of $23 million as of January 31, 2016 is expected to be paid during the first half of fiscal year 2017.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001045810-16-000205:notes:243]
Revenue Recognition

[0001045810-16-000205:notes:244]
Product Revenue

[0001045810-16-000205:notes:245]
We recognize revenue from product sales when persuasive evidence of an arrangement exists, the product has been delivered, the price is fixed or determinable and collection of the related receivable is reasonably assured. For most sales, we use a binding purchase order and in certain cases we use a contractual agreement as evidence of an arrangement. We consider delivery to occur upon shipment provided title and risk of loss have passed to the customer. At the point of sale, we assess whether the arrangement fee is fixed or determinable and whether collection is reasonably assured. If we determine that collection of a fee is not reasonably assured, we defer the fee and recognize revenue at the time collection becomes reasonably assured, which is generally upon receipt of payment.

[0001045810-16-000205:notes:246]
For sales to certain distributors with rights of return for which the level of returns cannot be reasonably estimated, our policy is to defer recognition of revenue and related cost of revenue until the distributors resell the product and, in some cases, when customer return rights lapse.

[0001045810-16-000205:notes:247]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Unclaimed rebates are reversed to revenue.

[0001045810-16-000205:notes:248]
Our customer programs also include marketing development funds, or MDFs.  MDFs represent monies paid to retailers, system builders, original equipment manufacturers, or OEMs, distributors, add-in card partners and other channel partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF programs.

[0001045810-16-000205:notes:249]
We also record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a particular fiscal period exceed historical return rates we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-16-000205:notes:250]
License and Development Revenue

[0001045810-16-000205:notes:251]
For license arrangements that require significant customization of our intellectual property components, we generally recognize the related revenue over the period that services are performed. For most license and service arrangements, we determine progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete the project. A provision for estimated losses on contracts is made in the period in which the loss becomes probable and can be reasonably estimated. Costs incurred in advance of revenue recognized are recorded as deferred costs on uncompleted contracts. If the amount billed exceeds the amount of revenue recognized, the excess amount is recorded as deferred revenue.

[0001045810-16-000205:notes:252]
For license arrangements that do not require significant customization but where we are obligated to provide further deliverables over the term of the license agreement, we record revenue over the life of the license term, with consideration received in advance of the performance period classified as deferred revenue.

[0001045810-16-000205:notes:253]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties.  We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001045810-16-000205:notes:254]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
| Revenue: |  |  |  |  |  |
| Customer A | 11 | % |  | 11 | % |  | 11 | % |
| Customer B | 9 | % |  | 9 | % |  | 10 | % |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001045810-16-000205:notes:255]
|  | January 31, 2016 |  | January 25, 2015 |
| Long-lived assets: | (In millions) |
| United States | $ | 414 |  |  | $ | 467 |  |
| India | 45 |  |  | 48 |  |
| Taiwan | 39 |  |  | 52 |  |
| China | 25 |  |  | 28 |  |
| Europe | 9 |  |  | 52 |  |
| Other Asia Pacific | 1 |  |  | 1 |  |
| Total long-lived assets | $ | 533 |  |  | $ | 648 |  |

[0001045810-16-000205:notes:256]
|  | Year Ended |
|  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
| Revenue: | (In millions) |
| Taiwan | $ | 1,912 |  |  | $ | 1,594 |  |  | $ | 1,321 |  |
| China | 806 |  |  | 922 |  |  | 794 |  |
| Other Asia Pacific | 749 |  |  | 638 |  |  | 675 |  |
| United States | 643 |  |  | 791 |  |  | 727 |  |
| Europe | 482 |  |  | 369 |  |  | 295 |  |
| Other Americas | 418 |  |  | 368 |  |  | 318 |  |
| Total revenue | $ | 5,010 |  |  | $ | 4,682 |  |  | $ | 4,130 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-16-000205:notes:257]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 31, 2016: |  |  |  |  |  |  |  |
| Revenue | $ | 4,187 |  |  | $ | 559 |  |  | $ | 264 |  |  | $ | 5,010 |  |
| Depreciation and amortization expense | $ | 110 |  |  | $ | 43 |  |  | $ | 44 |  |  | $ | 197 |  |
| Operating income (loss) | $ | 1,344 |  |  | $ | (239 | ) |  | $ | (358 | ) |  | $ | 747 |  |
| Year Ended January 25, 2015: |  |  |  |  |  |  |  |
| Revenue | $ | 3,839 |  |  | $ | 579 |  |  | $ | 264 |  |  | $ | 4,682 |  |
| Depreciation and amortization expense | $ | 117 |  |  | $ | 57 |  |  | $ | 46 |  |  | $ | 220 |  |
| Operating income (loss) | $ | 1,113 |  |  | $ | (254 | ) |  | $ | (100 | ) |  | $ | 759 |  |
| Year Ended January 26, 2014: |  |  |  |  |  |  |  |
| Revenue | $ | 3,468 |  |  | $ | 398 |  |  | $ | 264 |  |  | $ | 4,130 |  |
| Depreciation and amortization expense | $ | 147 |  |  | $ | 50 |  |  | $ | 42 |  |  | $ | 239 |  |
| Operating income (loss) | $ | 835 |  |  | $ | (268 | ) |  | $ | (71 | ) |  | $ | 496 |  |

[0001045810-16-000205:notes:258]
|  |  | Year Ended |
|  |  | January 31, 2016 |  | January 25, 2015 |  | January 26, 2014 |
|  |  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |
| Unallocated revenue |  | $ | 264 |  |  | $ | 264 |  |  | $ | 264 |  |
| Unallocated cost of revenue and operating expenses |  | (244 | ) |  | (169 | ) |  | (167 | ) |
| Stock-based compensation |  | (204 | ) |  | (158 | ) |  | (136 | ) |
| Restructuring and other charges |  | (131 | ) |  | — |  |  | — |  |
| Acquisition-related costs |  | (22 | ) |  | (37 | ) |  | (32 | ) |
| Product warranty charges |  | (21 | ) |  | — |  |  | — |  |
| Total |  | $ | (358 | ) |  | $ | (100 | ) |  | $ | (71 | ) |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-16-000205:notes:259]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-16-000205:notes:260]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Year ended January 31, 2016 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3 |  |  | $ | — |  | (1) | $ | (1 | ) | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 14 |  |  | $ | 9 |  | (2) | $ | (14 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 261 |  |  | $ | 11 |  | (3) | $ | — |  |  | $ | 272 |  |
| Year ended January 25, 2015 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1 |  |  | $ | 3 |  | (1) | $ | (1 | ) | (1) | $ | 3 |  |
| Sales return allowance |  | $ | 14 |  |  | $ | 12 |  | (2) | $ | (12 | ) | (4) | $ | 14 |  |
| Deferred tax valuation allowance |  | $ | 244 |  |  | $ | 17 |  | (3) | $ | — |  |  | $ | 261 |  |
| Year ended January 26, 2014 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | — |  | (1) | $ | (1 | ) | (1) | $ | 1 |  |
| Sales return allowance |  | $ | 15 |  |  | $ | 16 |  | (2) | $ | (17 | ) | (4) | $ | 14 |  |
| Deferred tax valuation allowance |  | $ | 225 |  |  | $ | 19 |  | (3) | $ | — |  |  | $ | 244 |  |

[0001045810-16-000205:notes:261]
(1)  Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end.

[0001045810-16-000205:notes:262]
(2)  Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue.

[0001045810-16-000205:notes:263]
(3)  Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions.

[0001045810-16-000205:notes:264]
(4)  Represents sales returns.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-16-000205:notes:265]
Segment Information

[0001045810-16-000205:notes:266]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-16-000205:notes:267]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-16-000205:notes:268]
Our GPU product brands are aimed at specialized markets include GeForce for gamers; Quadro for designers; Tesla for researchers and analysts focused on artificial intelligence, deep learning and big-data; and GRID for cloud-based visual computing users. We also integrate our GPUs into powerful mobile system-on-a-chip (SOC) processors, which drive supercomputing capabilities for tablets and online gaming and entertainment devices, as well as autonomous robots, drones and cars. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs with audio, video and input/output capabilities.

[0001045810-16-000205:notes:269]
We have a single unifying architecture for our GPU and Tegra Processors. This architecture unification leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-16-000205:notes:270]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, product warranty charge, restructuring and other charges, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-16-000205:notes:271]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for NVIDIA as a whole. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-16-000205:notes:272]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-16-000205:notes:273]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-16-000205:notes:274]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and deposits and other assets, and exclude goodwill and intangible assets.

[0001045810-16-000205:notes:275]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-16-000205:notes:276]
Revenue from both customers was attributable to the GPU business.

[0001045810-16-000205:notes:277]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-16-000205:notes:278]
Organization and Summary of Significant Accounting Policies

[0001045810-16-000205:notes:279]
Our Company

[0001045810-16-000205:notes:280]
NVIDIA is dedicated to advancing visual computing. NVIDIA has transformed into a specialized platform company that targets four large markets - Gaming, Professional Visualization, Datacenter and Automotive - where visual computing is essential and valued.

[0001045810-16-000205:notes:281]
Our two reportable segments - GPU and Tegra Processor - are based on a single underlying graphics architecture. From our proprietary processors, we have created platforms that address the four large markets where our visual computing expertise is critically important. We are focused on delivering value through PC, mobile and cloud architectures. Our vertical integration enables us to bring together hardware, system software, programmable algorithms, systems and services to create unique value for the markets we serve.

[0001045810-16-000205:notes:282]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla for researchers and analysts focused on artificial intelligence, deep learning and big-data; and GRID for cloud-based visual computing users. We also integrate our GPUs into powerful mobile system-on-a-chip (SOC) processors, which drive supercomputing capabilities for tablets and online gaming and entertainment devices, as well as autonomous robots, drones and cars. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs with audio, video and input/output capabilities.

[0001045810-16-000205:notes:283]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-16-000205:notes:284]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries, except where it is made clear that the term means only the parent company.

[0001045810-16-000205:notes:285]
Fiscal Year

[0001045810-16-000205:notes:286]
We operate on a 52- or a 53-week year, ending on the last Sunday in January. Fiscal year 2016 was a 53-week year with the extra week in the fiscal fourth quarter and fiscal years 2015 and 2014 were 52-week years.

[0001045810-16-000205:notes:287]
Use of Estimates

[0001045810-16-000205:notes:288]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States, or U.S. GAAP, requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-16-000205:notes:289]
Marketable securities consist primarily of highly liquid investments with maturities of greater than three months when purchased. We generally classify our marketable securities at the date of acquisition as available-for-sale. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax. The fair value of interest-bearing securities includes accrued interest. Any unrealized losses which are considered to be other-than-temporary impairments are recorded in the other income and expense section of our Consolidated Statements of Income. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income and expense section of our Consolidated Statements of Income.

[0001045810-16-000205:notes:290]
All of our available-for-sale investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary, or have other indicators of impairments. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is not more likely than not that we will not be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings while loss related to all other factors is recorded in accumulated other comprehensive income (loss).

[0001045810-16-000205:notes:291]
Concentration of Credit Risk

[0001045810-16-000205:notes:292]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, accounts receivable, note hedge and interest rate swap. Our investment policy requires the purchase of high grade investment securities, the diversification of asset type and includes certain limits on our portfolio duration. All marketable securities are held in our name, managed by several investment managers and held by one major financial institution under a custodial arrangement. Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 21% of our accounts receivable balance from one customer as of January 31, 2016 and 30% of our account receivable balance from two customers as of January 25, 2015. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-16-000205:notes:293]
Shareholders’ Equity

[0001045810-16-000205:notes:294]
Share Repurchase Program

[0001045810-16-000205:notes:295]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. In May 2015, the Board extended the previously authorized repurchase program through December 2018 and authorized an additional $1.62 billion under the repurchase program.

[0001045810-16-000205:notes:296]
During fiscal year 2016, we repurchased a total of 25 million shares for $587 million and paid $213 million in cash dividends to our shareholders, equivalent to $0.085 per share for the three months ended April 26, 2015, $0.0975 per share for the six months ended October 25, 2015, and $0.115 per share for the three months ended January 31, 2016. As a result, we returned $800 million to shareholders during fiscal year 2016 in the form of share repurchases and dividend payments.

[0001045810-16-000205:notes:297]
Through January 31, 2016, we have repurchased an aggregate of 231 million shares under our share repurchase program for a total of $3.85 billion. All shares delivered from these repurchases have been placed into treasury stock. As of January 31, 2016, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.47 billion.

[0001045810-16-000205:notes:298]
We intend to return approximately $1.00 billion to our shareholders in fiscal year 2017 through a combination of share repurchases and cash dividends. We also declared on February 17, 2016 that we would pay our next quarterly cash dividend of $0.115 per share on March 23, 2016, to all shareholders of record on March 2, 2016.

[0001045810-16-000205:notes:299]
In addition to our Board authorized share repurchases, we withhold common stock shares associated with net share settlements to cover tax withholding obligations upon the vesting of RSU and PSU awards under our equity incentive program. During fiscal year 2016, we withheld approximately 3 million shares at a total cost of $66 million through net share settlements. Please refer to Note 2 of these Notes to the Consolidated Financial Statements for further information regarding stock-based compensation related to equity awards granted under our equity incentive programs.

[0001045810-16-000205:notes:300]
Convertible Preferred Stock

[0001045810-16-000205:notes:301]
As of January 31, 2016 and January 25, 2015, there were no shares of preferred stock outstanding.

[0001045810-16-000205:notes:302]
Common Stock

[0001045810-16-000205:notes:303]
We are authorized to issue up to 2.00 billion shares of our common stock at $0.001 per share par value.
