# NVDA 8-K — 0001045810-16-000189 filed 2016-02-17

## item codes, every 8-K on or before 2016-03-17

- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2016-03-17

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-16-000189:8k_2_02:1]
EX-99.1
2
q416pr.htm
Q4'16 PRESS RELEASE

[0001045810-16-000189:8k_2_02:2]
Exhibit

[0001045810-16-000189:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-16-000189:8k_2_02:4]
NVIDIA Announces Financial Results for the Fourth Quarter and Fiscal 2016

[0001045810-16-000189:8k_2_02:5]
| • | Record quarterly revenue of $1.40 billion, up 12 percent from a year earlier |

[0001045810-16-000189:8k_2_02:6]
| • | Record full-year revenue of $5.01 billion, up 7 percent from fiscal 2015 |

[0001045810-16-000189:8k_2_02:7]
| • | Growth across all market platforms - Gaming, Professional Visualization, Datacenter, Automotive |

[0001045810-16-000189:8k_2_02:8]
| • | Sharply growing customer engagements in deep learning |

[0001045810-16-000189:8k_2_02:9]
SANTA CLARA, Calif.-Feb. 17, 2016-NVIDIA (NASDAQ: NVDA) today reported record revenue for the fourth quarter ended January 31, 2016, of $1.40 billion, up 12 percent from $1.25 billion a year earlier, and up 7 percent from $1.30 billion in the previous quarter.

[0001045810-16-000189:8k_2_02:10]
Revenue for fiscal 2016 was a record $5.01 billion, up 7 percent from $4.68 billion a year earlier.

[0001045810-16-000189:8k_2_02:11]
GAAP earnings per diluted share for the quarter were $0.35, inclusive of a restructuring charge of $0.04 per diluted share.  Non-GAAP earnings per diluted share were $0.52, up 21 percent from $0.43 a year earlier and up 13 percent from $0.46 in the previous quarter.

[0001045810-16-000189:8k_2_02:12]
GAAP earnings per diluted share for the full year were $1.08, inclusive of restructuring charges of $0.15 per diluted share.  Non-GAAP earnings per diluted share were $1.67, up 18 percent from $1.42 a year earlier.

[0001045810-16-000189:8k_2_02:13]
“We had another record quarter, capping a record year,” said Jen-Hsun Huang, co-founder and chief executive officer, NVIDIA. “Our strategy is to create specialized accelerated computing platforms for large growth markets that demand the 10x boost in performance we offer.  Each platform leverages our focused investment in building the world’s most advanced GPU technology.

[0001045810-16-000189:8k_2_02:14]
“NVIDIA is at the center of four exciting growth opportunities - PC gaming, VR, deep learning, and self-driving cars. We are especially excited about deep learning, a breakthrough in artificial intelligence algorithms that takes advantage of our GPU’s ability to process data simultaneously.

[0001045810-16-000189:8k_2_02:15]
“Deep learning is a new computing model that teaches computers to find patterns and make predictions, extracting powerful insights from massive quantities of data. We are working with thousands of companies that are applying the power of deep learning in fields ranging from life sciences and financial services to the Internet of Things,” he said.

[0001045810-16-000189:8k_2_02:16]
Capital Return

[0001045810-16-000189:8k_2_02:17]
During the fourth quarter, NVIDIA paid $62 million in cash dividends and received 4.3 million shares in connection with an accelerated share repurchase agreement that it had entered into in the quarter.  During fiscal 2016,  the company returned to shareholders $800 million in quarterly cash dividends and share repurchases.

[0001045810-16-000189:8k_2_02:18]
For fiscal 2017, NVIDIA intends to return approximately $1.0 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-16-000189:8k_2_02:19]
NVIDIA will pay its next quarterly cash dividend of $0.115 per share on March 23, 2016, to all shareholders of record on March 2, 2016.

[0001045810-16-000189:8k_2_02:20]
Q4 FY2016 Summary

[0001045810-16-000189:8k_2_02:21]
| GAAP |
| ($ in millions except earnings per share) | Q4 FY16 | Q3 FY16 | Q4 FY15 | Q/Q | Y/Y |
| Revenue | $1,401 | $1,305 | $1,251 | up 7% | up 12% |  |
| Gross margin | 56.5% | 56.3% | 55.9% | up 20 bps | up 60 bps |  |
| Operating expenses | $539 | $489 | $468 | up 10% | up 15% |  |
| Operating income | $252 | $245 | $231 | up 3% | up 9% |  |
| Net income | $207 | $246 | $193 | down 16% | up 7% |  |
| Diluted earnings per share | $0.35 | $0.44 | $0.35 | down 20% | — |  |

[0001045810-16-000189:8k_2_02:22]
| Non-GAAP |
| ($ in millions except earnings per share) | Q4 FY16 | Q3 FY16 | Q4 FY15 | Q/Q | Y/Y |
| Revenue | $1,401 | $1,305 | $1,251 | up 7% | up 12% |
| Gross margin | 57.2% | 56.5% | 56.2% | up 70 bps | up 100 bps |
| Operating expenses | $445 | $430 | $420 | up 3% | up 6% |
| Operating income | $356 | $308 | $283 | up 16% | up 26% |
| Net income | $297 | $255 | $241 | up 16% | up 23% |
| Diluted earnings per share | $0.52 | $0.46 | $0.43 | up 13% | up 21% |

[0001045810-16-000189:8k_2_02:23]
FY2016 Summary

[0001045810-16-000189:8k_2_02:24]
| GAAP |
| ($ in millions except earnings per share) | FY16 | FY15 | Y/Y |
| Revenue | $5,010 | $4,682 | up 7% |
| Gross margin | 56.1% | 55.5% | up 60 bps |
| Operating expenses | $2,064 | $1,840 | up 12% |
| Operating income | $747 | $759 | down 2% |
| Net income | $614 | $631 | down 3% |
| Diluted earnings per share | $1.08 | $1.12 | down 4% |

[0001045810-16-000189:8k_2_02:25]
| Non-GAAP |
| ($ in millions except earnings per share) | FY16 | FY15 | Y/Y |
| Revenue | $5,010 | $4,682 | up 7% |
| Gross margin | 56.8% | 55.8% | up 100 bps |
| Operating expenses | $1,721 | $1,657 | up 4% |
| Operating income | $1,125 | $954 | up 18% |
| Net income | $929 | $801 | up 16% |
| Diluted earnings per share | $1.67 | $1.42 | up 18% |

[0001045810-16-000189:8k_2_02:26]
NVIDIA’s outlook for the first quarter of fiscal 2017 is as follows:

[0001045810-16-000189:8k_2_02:27]
| • | Revenue is expected to be $1.26 billion, plus or minus two percent. |

[0001045810-16-000189:8k_2_02:28]
| • | GAAP and non-GAAP gross margins are expected to be 57.2 percent and 57.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-16-000189:8k_2_02:29]
| • | GAAP operating expenses are expected to be approximately $500 million. Non-GAAP operating expenses are expected to be approximately $445 million. |

[0001045810-16-000189:8k_2_02:30]
| • | GAAP and non-GAAP tax rates for the first quarter of fiscal 2017 are both expected to be 19 percent, plus or minus one percent. |

[0001045810-16-000189:8k_2_02:31]
| • | Capital expenditures are expected to be approximately $35 million to $45 million. |

[0001045810-16-000189:8k_2_02:32]
Fourth Quarter Fiscal 2016 Highlights

[0001045810-16-000189:8k_2_02:33]
During the fourth quarter, NVIDIA achieved progress in each of its platforms.

[0001045810-16-000189:8k_2_02:34]
Gaming:

[0001045810-16-000189:8k_2_02:35]
| • | Announced the GeForce® GTX VR Ready program - in conjunction with PC companies, notebook makers and add-in card providers - to help users discover systems that will provide great virtual reality experiences. |

[0001045810-16-000189:8k_2_02:36]
| • | Released NVIDIA GameWorks™ VR, a software development kit for developers of VR software and headsets for gaming. |

[0001045810-16-000189:8k_2_02:37]
Professional Visualization:

[0001045810-16-000189:8k_2_02:38]
| • | Rolled out NVIDIA® Iray® plugins for Autodesk Maya and Autodesk 3ds Max, which enable users of these applications to create designs incorporating real-world lights and materials faster and more easily than before. |

[0001045810-16-000189:8k_2_02:39]
| • | Released NVIDIA DesignWorks™ VR, a software development kit for developers of VR software and headsets for enterprise. |

[0001045810-16-000189:8k_2_02:40]
Datacenter:

[0001045810-16-000189:8k_2_02:41]
| • | Introduced an end-to-end hyperscale datacenter deep learning platform - consisting of two accelerators, the NVIDIA Tesla® M40 and NVIDIA Tesla M4 - that lets web-services companies accelerate deep learning workloads. |

[0001045810-16-000189:8k_2_02:42]
| • | Revealed new breakthroughs from leading web-services groups using NVIDIA GPUs: |

[0001045810-16-000189:8k_2_02:43]
| ◦ | Facebook is using the NVIDIA Tesla accelerated computing platform to power Big Sur, its next-generation computing system for machine learning applications. |

[0001045810-16-000189:8k_2_02:44]
| ◦ | Alibaba’s AliCloud cloud computing business is working with NVIDIA to promote China’s first GPU-accelerated, cloud-based, high performance computing platform. |

[0001045810-16-000189:8k_2_02:45]
| ◦ | IBM is adding support for NVIDIA GPU accelerators to its Watson cognitive computing platform. |

[0001045810-16-000189:8k_2_02:46]
| ◦ | Google is open-sourcing its TensorFlow deep-learning framework, which can be accelerated on GPUs. |

[0001045810-16-000189:8k_2_02:47]
| ◦ | Microsoft’s Computational Network Toolkit was integrated with Azure GPU Lab, enabling neural nets for speech recognition that are up to 10x faster than their predecessors. |

[0001045810-16-000189:8k_2_02:48]
Auto:

[0001045810-16-000189:8k_2_02:49]
| • | Launched NVIDIA DRIVE™ PX 2, a powerful engine for in-vehicle artificial intelligence. |

[0001045810-16-000189:8k_2_02:50]
| • | Announced that Volvo will use DRIVE PX 2 to power a fleet of 100 Volvo XC90 SUVs that will appear on the road next year in the car manufacturer’s Drive Me autonomous-car pilot program. |

[0001045810-16-000189:8k_2_02:51]
CFO Commentary

[0001045810-16-000189:8k_2_02:52]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-16-000189:8k_2_02:53]
Conference Call and Webcast Information

[0001045810-16-000189:8k_2_02:54]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2016 financial results and current financial prospects today at 2 p.m. Pacific Time (5 p.m. Eastern Time). To listen to the conference call, dial (212) 231-2927; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its first quarter of fiscal 2017.

[0001045810-16-000189:8k_2_02:55]
Non-GAAP Measures

[0001045810-16-000189:8k_2_02:56]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, per diluted share impact of restructuring and other charges, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, product warranty charge, acquisition-related costs, restructuring and other charges, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Per diluted share impact of restructuring and other charges is calculated as restructuring and other charges, net of income tax, divided by GAAP diluted shares. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-16-000189:8k_2_02:57]
Keep Current on NVIDIA

[0001045810-16-000189:8k_2_02:58]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-16-000189:8k_2_02:59]
About NVIDIA

[0001045810-16-000189:8k_2_02:60]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. With a singular focus on this field, the company offers specialized platforms for the gaming, professional visualization, datacenter and automotive markets. Its products, services and software power amazing new experiences in virtual reality, artificial intelligence and autonomous cars. More information at http://nvidianews.nvidia.com.

[0001045810-16-000189:8k_2_02:61]
###

[0001045810-16-000189:8k_2_02:62]
For further information, contact:

[0001045810-16-000189:8k_2_02:63]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-16-000189:8k_2_02:64]
Certain statements in this press release including, but not limited to statements as to: the company’s strategy of creating specialized accelerated computing platforms for large growth markets; the 10x boost in performance the company offers; the company being at the center of four exciting growth opportunities; the impact of deep learning; the company’s intended fiscal 2017 capital return; the company’s next quarterly cash dividend; the company’s financial outlook for the first quarter of fiscal 2017; the company’s tax rates for the first quarter of fiscal 2017; the impact of the GeForce GTX VR Ready program; the benefits of NVIDIA Iray plugins; the impact of the company’s hyperscale datacenter deep learning platform; breakthroughs from web-services groups leveraging NVIDIA GPUs and Volvo’s use of DRIVE PX 2 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended October 25, 2015. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-16-000189:8k_2_02:65]
© 2016 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Tesla, Iray, NVIDIA DesignWorks, NVIDIA DRIVE, NVIDIA GameWorks, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-16-000189:8k_2_02:66]
NVIDIA CORPORATION

[0001045810-16-000189:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-16-000189:8k_2_02:68]
(In millions, except per share data)

[0001045810-16-000189:8k_2_02:69]
(Unaudited)

[0001045810-16-000189:8k_2_02:70]
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 31, |  | January 25, |  | January 31, |  | January 25, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue | $ | 1,401 |  |  | $ | 1,251 |  |  | $ | 5,010 |  |  | $ | 4,682 |  |
| Cost of revenue | 610 |  |  | 552 |  |  | 2,199 |  |  | 2,083 |  |
| Gross profit | 791 |  |  | 699 |  |  | 2,811 |  |  | 2,599 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 344 |  |  | 348 |  |  | 1,331 |  |  | 1,360 |  |
| Sales, general and administrative | 161 |  |  | 120 |  |  | 602 |  |  | 480 |  |
| Restructuring and other charges | 34 |  |  | — |  |  | 131 |  |  | — |  |
| Total operating expenses | 539 |  |  | 468 |  |  | 2,064 |  |  | 1,840 |  |
| Operating income | 252 |  |  | 231 |  |  | 747 |  |  | 759 |  |
| Interest income | 11 |  |  | 8 |  |  | 39 |  |  | 28 |  |
| Interest expense | (12 | ) |  | (12 | ) |  | (47 | ) |  | (46 | ) |
| Other income, net | 2 |  |  | 1 |  |  | 4 |  |  | 14 |  |
| Income before income tax expense | 253 |  |  | 228 |  |  | 743 |  |  | 755 |  |
| Income tax expense | 46 |  |  | 35 |  |  | 129 |  |  | 124 |  |
| Net income | $ | 207 |  |  | $ | 193 |  |  | $ | 614 |  |  | $ | 631 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | 0.35 |  |  | $ | 1.13 |  |  | $ | 1.14 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.35 |  |  | $ | 1.08 |  |  | $ | 1.12 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 539 |  |  | 544 |  |  | 543 |  |  | 552 |  |
| Diluted | 593 |  |  | 557 |  |  | 569 |  |  | 563 |  |

[0001045810-16-000189:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | January 31, |  | January 25, |
|  |  |  | 2016 |  | 2015 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 5,037 |  |  | $ | 4,623 |  |
|  | Accounts receivable, net |  | 505 |  |  | 474 |  |
|  | Inventories |  | 418 |  |  | 483 |  |
|  | Prepaid expenses and other current assets |  | 93 |  |  | 133 |  |
|  | Total current assets |  | 6,053 |  |  | 5,713 |  |
| Property and equipment, net |  | 466 |  |  | 557 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 166 |  |  | 222 |  |
| Other assets |  | 67 |  |  | 91 |  |
|  | Total assets |  | $ | 7,370 |  |  | $ | 7,201 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 296 |  |  | $ | 293 |  |
|  | Accrued and other current liabilities |  | 642 |  |  | 603 |  |
|  | Convertible short-term debt |  | 1,413 |  |  | — |  |
|  | Total current liabilities |  | 2,351 |  |  | 896 |  |
| Convertible long-term debt |  | — |  |  | 1,384 |  |
| Other long-term liabilities |  | 453 |  |  | 489 |  |
| Capital lease obligations, long-term |  | 10 |  |  | 14 |  |
|  | Total liabilities |  | 2,814 |  |  | 2,783 |  |
| Convertible debt conversion obligation |  | 87 |  |  | — |  |
| Shareholders' equity |  | 4,469 |  |  | 4,418 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 7,370 |  |  | $ | 7,201 |  |

[0001045810-16-000189:8k_2_02:72]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 31, |  | October 25, |  | January 25, |  | January 31, |  | January 25, |
|  |  | 2016 |  | 2015 |  | 2015 |  | 2016 |  | 2015 |
| GAAP gross profit |  | $ | 791 |  |  | $ | 734 |  |  | $ | 699 |  |  | $ | 2,811 |  |  | $ | 2,599 |  |
| GAAP gross margin |  | 56.5 | % |  | 56.3 | % |  | 55.9 | % |  | 56.1 | % |  | 55.5 | % |
| Stock-based compensation expense (A) |  | 5 |  |  | 4 |  |  | 4 |  |  | 15 |  |  | 12 |  |
| Product warranty charge (B) |  | 5 |  |  | — |  |  | — |  |  | 20 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 801 |  |  | $ | 738 |  |  | $ | 703 |  |  | $ | 2,846 |  |  | $ | 2,611 |  |
| Non-GAAP gross margin |  | 57.2 | % |  | 56.5 | % |  | 56.2 | % |  | 56.8 | % |  | 55.8 | % |
| GAAP operating expenses |  | $ | 539 |  |  | $ | 489 |  |  | $ | 468 |  |  | $ | 2,064 |  |  | $ | 1,840 |  |
| Stock-based compensation expense (A) |  | (56 | ) |  | (47 | ) |  | (39 | ) |  | (190 | ) |  | (146 | ) |
| Acquisition-related costs (C) |  | (4 | ) |  | (4 | ) |  | (9 | ) |  | (22 | ) |  | (37 | ) |
| Restructuring and other charges |  | (34 | ) |  | (8 | ) |  | — |  |  | (131 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 445 |  |  | $ | 430 |  |  | $ | 420 |  |  | $ | 1,721 |  |  | $ | 1,657 |  |
| GAAP operating income |  | $ | 252 |  |  | $ | 245 |  |  | $ | 231 |  |  | $ | 747 |  |  | $ | 759 |  |
| Total impact of non-GAAP adjustments to operating income |  | 104 |  |  | 63 |  |  | 52 |  |  | 378 |  |  | 195 |  |
| Non-GAAP operating income |  | $ | 356 |  |  | $ | 308 |  |  | $ | 283 |  |  | $ | 1,125 |  |  | $ | 954 |  |
| GAAP other income (expense), net |  | $ | 1 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | (4 | ) |  | $ | (4 | ) |
| Gains from non-affiliated investments |  | — |  |  | (4 | ) |  | — |  |  | (5 | ) |  | (15 | ) |
| Interest expense related to amortization of debt discount |  | 7 |  |  | 7 |  |  | 7 |  |  | 29 |  |  | 28 |  |
| Non-GAAP other income, net |  | $ | 8 |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | 20 |  |  | $ | 9 |  |
| GAAP net income |  | $ | 207 |  |  | $ | 246 |  |  | $ | 193 |  |  | $ | 614 |  |  | $ | 631 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 111 |  |  | 66 |  |  | 59 |  |  | 402 |  |  | 208 |  |
| Income tax impact of non-GAAP adjustments |  | (21 | ) |  | (57 | ) |  | (11 | ) |  | (87 | ) |  | (38 | ) |
| Non-GAAP net income |  | $ | 297 |  |  | $ | 255 |  |  | $ | 241 |  |  | $ | 929 |  |  | $ | 801 |  |

[0001045810-16-000189:8k_2_02:73]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 31, |  | October 25, |  | January 25, |  | January 31, |  | January 25, |
|  |  | 2016 |  | 2015 |  | 2015 |  | 2016 |  | 2015 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.35 |  |  | $ | 0.44 |  |  | $ | 0.35 |  |  | $ | 1.08 |  |  | $ | 1.12 |  |
| Non-GAAP |  | $ | 0.52 |  |  | $ | 0.46 |  |  | $ | 0.43 |  |  | $ | 1.67 |  |  | $ | 1.42 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 593 |  |  | 565 |  |  | 557 |  |  | 569 |  |  | 563 |  |
| Anti-dilution impact from note hedge (D) |  | (26 | ) |  | (10 | ) |  | — |  |  | (13 | ) |  | — |  |
| Non-GAAP |  | 567 |  |  | 555 |  |  | 557 |  |  | 556 |  |  | 563 |  |
| Metrics: |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  | $ | 34 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |
| Income tax impact of restructuring and other charges |  | (9 | ) |  | (50 | ) |  | — |  |  | (45 | ) |  | — |  |
| Restructuring and other charges, net of income tax |  | $ | 25 |  |  | $ | (42 | ) |  | $ | — |  |  | $ | 86 |  |  | $ | — |  |
| GAAP diluted shares |  | 593 |  |  | 565 |  |  | — |  |  | 569 |  |  | — |  |
| Per diluted share impact of restructuring and other charges |  | $ | 0.04 |  |  | $ | (0.07 | ) |  | $ | — |  |  | $ | 0.15 |  |  | $ | — |  |
| GAAP net cash provided by operating activities |  | $ | 510 |  |  | $ | 255 |  |  | $ | 443 |  |  | $ | 1,175 |  |  | $ | 906 |  |
| Purchase of property and equipment and intangible assets |  | (15 | ) |  | (16 | ) |  | (31 | ) |  | (86 | ) |  | (123 | ) |
| Free cash flow |  | $ | 495 |  |  | $ | 239 |  |  | $ | 412 |  |  | $ | 1,089 |  |  | $ | 783 |  |

[0001045810-16-000189:8k_2_02:74]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 31, |  | October 25, |  | January 25, |  | January 31, |  | January 25, |
|  |  | 2016 |  | 2015 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenue |  | $ | 5 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 15 |  |  | $ | 12 |  |
| Research and development |  | $ | 33 |  |  | $ | 28 |  |  | $ | 23 |  |  | $ | 115 |  |  | $ | 88 |  |
| Sales, general and administrative |  | $ | 22 |  |  | $ | 19 |  |  | $ | 15 |  |  | $ | 74 |  |  | $ | 57 |  |
| (B) Represents warranty charge associated with a product recall. |
| (C) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (D) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under U.S. GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-16-000189:8k_2_02:75]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2017 Outlook |
| GAAP gross margin |  | 57.2 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 57.5 | % |
|  |  |  | Q1 FY2017 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 500 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (55 | ) |
| Non-GAAP operating expenses |  | $ | 445 |  |
