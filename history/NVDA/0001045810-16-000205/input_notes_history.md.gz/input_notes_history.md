# NVDA note change history — 0001045810-15-000143 → 0001045810-15-000173


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-18):
[0001045810-15-000173:note_history:1]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.
  (was, 2015-08-19, similarity 0.9689):
[0001045810-15-000143:note_history:1]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by any of our subsidiaries.

- changed (2015-11-18):
[0001045810-15-000173:note_history:2]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.
  (was, 2015-08-19, similarity 0.9938):
[0001045810-15-000143:note_history:2]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

- added (2015-11-18):
[0001045810-15-000173:note_history:3]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to exclude importation of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures, or the Accused Products. On October 6, 2014, the ITC instituted an investigation of NVIDIA’s claim. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the seven patents at issue. In June 2015, NVIDIA moved to terminate all asserted claims on four patents and these motions were granted. The ITC held an evidentiary hearing on certain asserted claims of the three remaining patents from June 22 through June 26, 2015. On October 9, 2015, the ITC Administrative Law Judge rendered an initial determination that importation of the Samsung Accused Products did not violate U.S. law. NVIDIA is currently seeking review of the decision by the full commission of the ITC. The commission will decide whether to review parts of the initial determination on or before December 14, 2015 and the target date for the final decision is February 10, 2016.

- added (2015-11-18):
[0001045810-15-000173:note_history:4]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm exercised their statutory right to stay the Delaware proceedings in light of the pending ITC action and the court granted the motion to stay on October 23, 2014.

- added (2015-11-18):
[0001045810-15-000173:note_history:5]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung amended its complaint twice, first on December 19, 2014, and then on April 10, 2015, without changing its legal claims. Samsung seeks monetary damages and certain injunctive relief as to some of the asserted patents. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction preventing it from infringing two of the asserted patents and those patents were dismissed from the case with prejudice. Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015. On October 15, 2015, NVIDIA’s Motion for Entry of Judgment of Noninfringement was granted as to one of Samsung’s patents. Five patents currently asserted against NVIDIA remain and a jury trial is currently scheduled to begin January 19, 2016.

- added (2015-11-18):
[0001045810-15-000173:note_history:6]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents and seeking an exclusion order barring importation of NVIDIA products alleged to infringe Samsung’s patents. On December 23, 2014, the ITC instituted an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case. A hearing on Samsung’s three remaining patents was held from August 18 through August 21, 2015. Post-hearing briefing is complete and the Administrative Law Judge is scheduled to issue his initial determination by December 22, 2015. The target date for the final determination by the ITC is April 22, 2016.

- changed (2015-11-18):
[0001045810-15-000173:note_history:7]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed eleven requests for inter partes review on eight of Samsung’s asserted patents. Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA, and Qualcomm has filed three additional requests for inter partes review on two patents asserted by NVIDIA. The United States Patent and Trademark Office has, to date, decided to review three patents owned by NVIDIA, and three patents owned by Samsung. All other requests are currently pending.
  (was, 2015-08-19, similarity 0.6352):
[0001045810-15-000143:note_history:7]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed ten requests for inter partes review on eight of Samsung’s asserted patents.  Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA.  The United States Patent and Trademark Office has not yet decided whether to institute review as to any of the patents.

- changed (2015-11-18):
[0001045810-15-000173:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 25, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2015-08-19, similarity 0.9932):
[0001045810-15-000143:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 26, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2015-11-18):
[0001045810-15-000143:note_history:9]
Securities Cases

- removed (2015-11-18):
[0001045810-15-000143:note_history:10]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, or the Securities Exchange Act.

- removed (2015-11-18):
[0001045810-15-000143:note_history:11]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.  On April 15, 2015, we filed an opposition to Plaintiffs’ petition and the petition was denied on May 26, 2015.  The case is now over.

- removed (2015-11-18):
[0001045810-15-000143:note_history:12]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the seven patents at issue.  In June 2015, NVIDIA moved to terminate all asserted claims on four patents, which motions have not yet been acted upon.  Certain asserted claims of the three remaining patents pending before the ITC were tried at a hearing on June 22-26, 2015. The post-hearing briefing was concluded on July 24, 2015, and the parties expect a decision on October 9, 2015.

- removed (2015-11-18):
[0001045810-15-000143:note_history:13]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action and NVIDIA did not oppose the motion. The court granted the motion to stay on October 23, 2014.

- removed (2015-11-18):
[0001045810-15-000143:note_history:14]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, and then on April 10, 2015, Samsung filed amended, longer complaints, but which continued to assert the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction preventing it from infringing certain patents and was dismissed from the case with prejudice.  A Markman hearing was held on June 29, 2015 and trial is set to begin in January 2016.  Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015.

- removed (2015-11-18):
[0001045810-15-000143:note_history:15]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents.  Samsung seeks to permanently bar several products purportedly relying on these allegedly infringed patents in the United States.  On December 23, 2014, the ITC initiated an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case.  A hearing on Samsung’s three remaining patents began on August 18, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-18):
[0001045810-15-000173:note_history:16]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.
  (was, 2015-08-19, similarity 0.9944):
[0001045810-15-000143:note_history:16]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-18):
[0001045810-15-000173:note_history:17]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.
  (was, 2015-08-19, similarity 0.9944):
[0001045810-15-000143:note_history:17]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

- changed (2015-11-18):
[0001045810-15-000173:note_history:18]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 was a 52-week year. The third quarters of fiscal years 2016 and 2015 were both 13-week quarters.
  (was, 2015-08-19, similarity 0.7458):
[0001045810-15-000143:note_history:18]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 was a 52-week year. The second quarters of fiscal years 2016 and 2015 were both 13-week quarters.

- changed (2015-11-18):
[0001045810-15-000173:note_history:19]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All material inter-company balances and transactions have been eliminated in consolidation.
  (was, 2015-08-19, similarity 0.9862):
[0001045810-15-000143:note_history:19]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and its wholly-owned subsidiaries. All material inter-company balances and transactions have been eliminated in consolidation.

- changed (2015-11-18):
[0001045810-15-000173:note_history:20]
In July 2015, the Financial Accounting Standards Board, or FASB, issued an accounting standards update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements.
  (was, 2015-08-19, similarity 0.9986):
[0001045810-15-000143:note_history:20]
In July 2015, the Financial Accounting Standards Board, or FASB, issued an accounting standard update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements.

- changed (2015-11-18):
[0001045810-15-000173:note_history:21]
In April 2015, the FASB issued an accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.
  (was, 2015-08-19, similarity 0.997):
[0001045810-15-000143:note_history:21]
In April 2015, the FASB issued a new accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

- added (2015-11-18):
[0001045810-15-000173:note_history:22]
In April 2015, the FASB issued an accounting standards update that provides clarification on whether a cloud computing arrangement includes a software license. If a software license is included, the customer should account for the license consistent with its accounting for other software licenses. If a software license is not included, the arrangement should be accounted for as a service contract. The update is effective for reporting periods beginning after December 15, 2015, with early adoption permitted. Companies can elect to adopt the standard update prospectively or retrospectively to arrangements entered into, or materially modified, after the effective date. The update will be effective for us beginning in our first quarter of fiscal year 2017. We expect the adoption of this accounting guidance to result in an increase in software license assets and related depreciation expense, and a corresponding decrease in prepaid service contract assets and related service contract expense in our consolidated financial statements.

- changed (2015-11-18):
[0001045810-15-000173:note_history:23]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.
  (was, 2015-08-19, similarity 0.9973):
[0001045810-15-000143:note_history:23]
In May 2014, the FASB issued a new accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-18):
[0001045810-15-000173:note_history:24]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted earlier in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock), subject to adjustment as described in the indenture governing the Notes.
  (was, 2015-08-19, similarity 0.9869):
[0001045810-15-000143:note_history:24]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

- changed (2015-11-18):
[0001045810-15-000173:note_history:25]
As of October 25, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the carrying value of the Notes would be classified as a current liability and the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.
  (was, 2015-08-19, similarity 0.9895):
[0001045810-15-000143:note_history:25]
As of July 26, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the carrying value of the Notes would be classified as a current liability and the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

- changed (2015-11-18):
[0001045810-15-000173:note_history:26]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method and an interest rate of 3.15%.
  (was, 2015-08-19, similarity 0.9946):
[0001045810-15-000143:note_history:26]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

- added (2015-11-18):
[0001045810-15-000173:note_history:27]
|  |  | October 25, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (94 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,406 |  |  | $ | 1,384 |  |

- changed (2015-11-18):
[0001045810-15-000173:note_history:28]
(1) As of October 25, 2015, the unamortized debt discount will be amortized over a remaining period of 3.1 years.
  (was, 2015-08-19, similarity 0.9469):
[0001045810-15-000143:note_history:28]
(1) As of July 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.4 years.

- changed (2015-11-18):
[0001045810-15-000173:note_history:29]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 22 |  |  | 21 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 33 |  |  | $ | 32 |  |
  (was, 2015-08-19, similarity 0.8884):
[0001045810-15-000143:note_history:29]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- removed (2015-11-18):
[0001045810-15-000143:note_history:30]
|  |  | July 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (101 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,399 |  |  | $ | 1,384 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-11-18):
[0001045810-15-000173:note_history:31]
|  |  | October 25, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (94 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,406 |  |  | $ | 1,384 |  |

- changed (2015-11-18):
[0001045810-15-000173:note_history:32]
(1) As of October 25, 2015, the unamortized debt discount will be amortized over a remaining period of 3.1 years.
  (was, 2015-08-19, similarity 0.9469):
[0001045810-15-000143:note_history:32]
(1) As of July 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.4 years.

- changed (2015-11-18):
[0001045810-15-000173:note_history:33]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 22 |  |  | 21 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 33 |  |  | $ | 32 |  |
  (was, 2015-08-19, similarity 0.8884):
[0001045810-15-000143:note_history:33]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | July 26, |  | July 27, |  | July 26, |  | July 27, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |

- removed (2015-11-18):
[0001045810-15-000143:note_history:34]
|  |  | July 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (101 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,399 |  |  | $ | 1,384 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-11-18):
[0001045810-15-000173:note_history:35]
Subsequent Event

- added (2015-11-18):
[0001045810-15-000173:note_history:36]
On November 9, 2015, as part of our stock repurchase program, we entered into an ASR with an investment bank, under which we made an upfront payment of $135 million to purchase shares of our common stock and received an initial delivery of 3 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
