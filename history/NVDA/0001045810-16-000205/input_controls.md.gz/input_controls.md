# NVDA 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001045810-16-000205:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001045810-16-000205:item_9a:2]
Controls and Procedures

[0001045810-16-000205:item_9a:3]
Disclosure Controls and Procedures

[0001045810-16-000205:item_9a:4]
Based on their evaluation as of January 31, 2016, our management, including our Chief Executive Officer and Chief Financial Officer, has concluded that our disclosure controls and procedures (as defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended, or the Exchange Act) were effective to provide reasonable assurance.

[0001045810-16-000205:item_9a:5]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001045810-16-000205:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 31, 2016 based on the criteria set forth in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under the criteria set forth in Internal Control — Integrated Framework, our management concluded that our internal control over financial reporting was effective as of January 31, 2016.

[0001045810-16-000205:item_9a:7]
The effectiveness of our internal control over financial reporting as of January 31, 2016 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in its report which is included herein.

[0001045810-16-000205:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001045810-16-000205:item_9a:9]
There were no changes in our internal control over financial reporting during our last fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001045810-16-000205:item_9a:10]
Inherent Limitations on Effectiveness of Controls

[0001045810-16-000205:item_9a:11]
Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.
