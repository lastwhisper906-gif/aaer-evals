# NVDA notes — 0001045810-15-000173


## nvda:BalanceSheetComponentsTextBlock

[0001045810-15-000173:notes:1]
[same as prior period, unchanged from 0001045810-15-000143:notes:1]

[0001045810-15-000173:notes:2]
[same as prior period, unchanged from 0001045810-15-000143:notes:2]

[0001045810-15-000173:notes:3]
|  | October 25, |  | January 25, |
|  | 2015 |  | 2015 |
| Inventories: | (In millions) |
| Raw materials | $ | 117 |  |  | $ | 157 |  |
| Work in-process | 91 |  |  | 92 |  |
| Finished goods | 217 |  |  | 234 |  |
| Total inventories | $ | 425 |  |  | $ | 483 |  |

[0001045810-15-000173:notes:4]
At October 25, 2015, we had outstanding inventory purchase obligations totaling $442 million.

[0001045810-15-000173:notes:5]
|  | October 25, |  | January 25, |
|  | 2015 |  | 2015 |
| Accrued and Other Current Liabilities: | (In millions) |
| Unearned revenue (1) | $ | 229 |  |  | $ | 296 |  |
| Customer related liabilities (2) | 151 |  |  | 143 |  |
| Accrued payroll and related expenses | 98 |  |  | 112 |  |
| Professional service fees | 24 |  |  | 17 |  |
| Accrued restructuring and other charges (3) | 15 |  |  | — |  |
| Warranty accrual (4) | 13 |  |  | 8 |  |
| Taxes payable | 7 |  |  | 3 |  |
| Coupon interest on Notes | 6 |  |  | 3 |  |
| Facilities related liabilities | 1 |  |  | 8 |  |
| Other | 16 |  |  | 13 |  |
| Total accrued and other current liabilities | $ | 560 |  |  | $ | 603 |  |

[0001045810-15-000173:notes:6]
[same as prior period, unchanged from 0001045810-15-000143:notes:6]

[0001045810-15-000173:notes:7]
| (2) | Customer related liabilities primarily includes accrued customer programs. Please refer to Note 1 of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, for a discussion regarding the nature of accrued customer programs and their accounting treatment related to our revenue recognition policies and estimates. |

[0001045810-15-000173:notes:8]
| (3) | Please refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding the accrued restructuring and other charges. |

[0001045810-15-000173:notes:9]
| (4) | Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding the warranty accrual. |

[0001045810-15-000173:notes:10]
|  | October 25, |  | January 25, |
|  | 2015 |  | 2015 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 325 |  |  | $ | 232 |  |
| Income taxes payable | 76 |  |  | 121 |  |
| Asset retirement obligation | 7 |  |  | 7 |  |
| Interest rate swap (1) | 3 |  |  | — |  |
| Deferred revenue (2) | 1 |  |  | 108 |  |
| Other | 25 |  |  | 21 |  |
| Total other long-term liabilities | $ | 437 |  |  | $ | 489 |  |

[0001045810-15-000173:notes:11]
| (1) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |

[0001045810-15-000173:notes:12]
(2)  Consists primarily of consideration received in advance of our performance obligations under the patent cross licensing agreement that we entered into with Intel Corporation in January 2011. The decrease in deferred revenue, long-term, is a result of revenue recognized during the nine months ended October 25, 2015.


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-15-000173:notes:13]
|  | October 25, |  | January 25, |
|  | 2015 |  | 2015 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $420 |  | $291 |
| Estimated weighted average amortization period | (In years) |
| Stock options | 1.3 |  | 1.8 |
| RSUs, PSUs and market-based PSUs | 3.0 |  | 2.8 |
| ESPP | 0.8 |  | 0.5 |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-15-000173:notes:14]
|  | October 25, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 1,975 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 1,975 |  |
| Debt securities of U.S. government agencies | 994 |  |  | 1 |  |  | — |  |  | 995 |  |
| Debt securities issued by the U.S. Treasury | 554 |  |  | 1 |  |  | — |  |  | 555 |  |
| Asset-backed securities | 472 |  |  | — |  |  | — |  |  | 472 |  |
| Mortgage-backed securities issued by U.S. government-sponsored enterprises | 240 |  |  | 4 |  |  | (1 | ) |  | 243 |  |
| Foreign government bonds | 83 |  |  | — |  |  | — |  |  | 83 |  |
| Money market funds | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Total | $ | 4,348 |  |  | $ | 8 |  |  | $ | (3 | ) |  | $ | 4,353 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 96 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 4,257 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,353 |  |

[0001045810-15-000173:notes:15]
|  | January 25, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,185 |  |  | $ | 2 |  |  | $ | (1 | ) |  | $ | 2,186 |  |
| Debt securities of U.S. government agencies | 750 |  |  | 1 |  |  | (1 | ) |  | 750 |  |
| Debt securities issued by the U.S. Treasury | 534 |  |  | 3 |  |  | — |  |  | 537 |  |
| Asset-backed securities | 453 |  |  | — |  |  | — |  |  | 453 |  |
| Mortgage-backed securities issued by U.S. government-sponsored enterprises | 274 |  |  | 5 |  |  | (1 | ) |  | 278 |  |
| Foreign government bonds | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Money market funds | 132 |  |  | — |  |  | — |  |  | 132 |  |
| Total | $ | 4,413 |  |  | $ | 11 |  |  | $ | (3 | ) |  | $ | 4,421 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 295 |  |
| Marketable securities |  |  |  |  |  |  | 4,126 |  |
| Total |  |  |  |  |  |  | $ | 4,421 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-15-000173:notes:16]
Commitments and Contingencies

[0001045810-15-000173:notes:17]
Operating Lease Financing Arrangement

[0001045810-15-000173:notes:18]
In the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-15-000173:notes:19]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-15-000173:notes:20]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-15-000173:notes:21]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-15-000173:notes:22]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-15-000173:notes:23]
Patent Infringement Cases

[0001045810-15-000173:notes:24]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to exclude importation of Samsung Galaxy mobile phones and tablets and other consumer electronics and display devices containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures, or the Accused Products. On October 6, 2014, the ITC instituted an investigation of NVIDIA’s claim. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the seven patents at issue. In June 2015, NVIDIA moved to terminate all asserted claims on four patents and these motions were granted. The ITC held an evidentiary hearing on certain asserted claims of the three remaining patents from June 22 through June 26, 2015. On October 9, 2015, the ITC Administrative Law Judge rendered an initial determination that importation of the Samsung Accused Products did not violate U.S. law. NVIDIA is currently seeking review of the decision by the full commission of the ITC. The commission will decide whether to review parts of the initial determination on or before December 14, 2015 and the target date for the final decision is February 10, 2016.

[0001045810-15-000173:notes:25]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm exercised their statutory right to stay the Delaware proceedings in light of the pending ITC action and the court granted the motion to stay on October 23, 2014.

[0001045810-15-000173:notes:26]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung amended its complaint twice, first on December 19, 2014, and then on April 10, 2015, without changing its legal claims. Samsung seeks monetary damages and certain injunctive relief as to some of the asserted patents. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement and its motion was granted on May 19, 2015. NVIDIA voluntarily withdrew its counter-claims on May 19, 2015. On June 17, 2015, Velocity Micro, Inc. voluntarily agreed to a permanent injunction preventing it from infringing two of the asserted patents and those patents were dismissed from the case with prejudice. Samsung’s false advertising claim was dismissed with prejudice on July 30, 2015. On October 15, 2015, NVIDIA’s Motion for Entry of Judgment of Noninfringement was granted as to one of Samsung’s patents. Five patents currently asserted against NVIDIA remain and a jury trial is currently scheduled to begin January 19, 2016.

[0001045810-15-000173:notes:27]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents and seeking an exclusion order barring importation of NVIDIA products alleged to infringe Samsung’s patents. On December 23, 2014, the ITC instituted an investigation of Samsung’s claims. On June 5, 2015, Samsung withdrew one patent from the case. A hearing on Samsung’s three remaining patents was held from August 18 through August 21, 2015. Post-hearing briefing is complete and the Administrative Law Judge is scheduled to issue his initial determination by December 22, 2015. The target date for the final determination by the ITC is April 22, 2016.

[0001045810-15-000173:notes:28]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed eleven requests for inter partes review on eight of Samsung’s asserted patents. Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA, and Qualcomm has filed three additional requests for inter partes review on two patents asserted by NVIDIA. The United States Patent and Trademark Office has, to date, decided to review three patents owned by NVIDIA, and three patents owned by Samsung. All other requests are currently pending.

[0001045810-15-000173:notes:29]
Accounting for Loss Contingencies

[0001045810-15-000173:notes:30]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 25, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-15-000173:notes:31]
[same as prior period, unchanged from 0001045810-15-000143:notes:33]

[0001045810-15-000173:notes:32]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All material inter-company balances and transactions have been eliminated in consolidation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001045810-15-000173:notes:33]
[same as prior period, unchanged from 0001045810-15-000143:notes:35]

[0001045810-15-000173:notes:34]
[same as prior period, unchanged from 0001045810-15-000143:notes:36]


## us-gaap:DebtDisclosureTextBlock

[0001045810-15-000173:notes:35]
Long-Term Debt

[0001045810-15-000173:notes:36]
1.00 % Convertible Senior Notes Due 2018

[0001045810-15-000173:notes:37]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless repurchased or converted earlier in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.5958 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.1630 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-15-000173:notes:38]
As of October 25, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the carrying value of the Notes would be classified as a current liability and the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

[0001045810-15-000173:notes:39]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method and an interest rate of 3.15%.

[0001045810-15-000173:notes:40]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-15-000173:notes:41]
|  |  | October 25, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (94 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,406 |  |  | $ | 1,384 |  |

[0001045810-15-000173:notes:42]
(1) As of October 25, 2015, the unamortized debt discount will be amortized over a remaining period of 3.1 years.

[0001045810-15-000173:notes:43]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-15-000173:notes:44]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |  | 22 |  |  | 21 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |  | $ | 33 |  |  | $ | 32 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-15-000173:notes:45]
Derivative Financial Instrument

[0001045810-15-000173:notes:46]
In August 2015, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building, which entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments.

[0001045810-15-000173:notes:47]
This interest rate swap is designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are recorded in accumulated other comprehensive income and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur.

[0001045810-15-000173:notes:48]
A summary of the notional amount and fair value of the interest rate swap recorded on the Condensed Consolidated Balance Sheets at October 25, 2015 and January 25, 2015 is as follows (in millions):

[0001045810-15-000173:notes:49]
|  | Notional Amount |  | Fair Value Asset (Liability) |
|  | October 25, 2015 |  | January 25, 2015 |  | October 25, 2015 |  | January 25, 2015 |
| Cash Flow Hedge |  |  |  |  |  |  |  |
| Interest rate swap | $ | 200 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |

[0001045810-15-000173:notes:50]
We formally assess, both at inception and on an ongoing basis, whether the interest rate swap is highly effective. For the three and nine months ended October 25, 2015, the interest rate swap was determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-15-000173:notes:51]
The effect of the interest rate swap on other comprehensive income is as follows (in millions):

[0001045810-15-000173:notes:52]
|  | October 25, 2015 |  | January 25, 2015 |
| Cash Flow Hedge |  |  |  |
| Gain (loss) on interest rate swap | $ | (3 | ) |  | $ | — |  |

[0001045810-15-000173:notes:53]
Over the next twelve months, we do not expect to reclassify any amount from accumulated other comprehensive income or loss to income as the underlying operating lease financing payments for our new headquarters building will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-15-000173:notes:54]
[same as prior period, unchanged from 0001045810-15-000143:notes:47]

[0001045810-15-000173:notes:55]
[same as prior period, unchanged from 0001045810-15-000143:notes:48]

[0001045810-15-000173:notes:56]
[same as prior period, unchanged from 0001045810-15-000143:notes:49]

[0001045810-15-000173:notes:57]
[same as prior period, unchanged from 0001045810-15-000143:notes:50]

[0001045810-15-000173:notes:58]
[same as prior period, unchanged from 0001045810-15-000143:notes:51]

[0001045810-15-000173:notes:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, 2015 |  | October 26, 2014 |  | October 25, 2015 |  | October 26, 2014 |
|  | (In millions) |
| Cost of revenue | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 8 |  |
| Research and development | 28 |  |  | 22 |  |  | 82 |  |  | 65 |  |
| Sales, general and administrative | 19 |  |  | 16 |  |  | 53 |  |  | 42 |  |
| Total | $ | 51 |  |  | $ | 42 |  |  | $ | 145 |  |  | $ | 115 |  |

[0001045810-15-000173:notes:60]
[same as prior period, unchanged from 0001045810-15-000143:notes:53]

[0001045810-15-000173:notes:61]
[same as prior period, unchanged from 0001045810-15-000143:notes:54]

[0001045810-15-000173:notes:62]
|  | Awards Outstanding |  | Weighted Average Exercise Price |
| Stock Options | (In millions) |  | (Per share) |
| Balances, January 25, 2015 | 21 |  |  | $14.61 |
| Granted | — |  |  | — |  |
| Exercised | (6 | ) |  | $14.48 |
| Cancelled | — |  |  | — |  |
| Balances, October 25, 2015 | 15 |  |  | $14.55 |

[0001045810-15-000173:notes:63]
|  | Awards Outstanding |  | Weighted Average Grant-Date Fair Value |
| RSUs, PSUs and Market-based PSUs | (In millions) |  | (Per share) |
| Balances, January 25, 2015 | 23 |  |  | $15.94 |
| Granted (1) (2) | 13 |  |  | $21.61 |
| Vested | (8 | ) |  | $15.53 |
| Cancelled | (2 | ) |  | $16.40 |
| Balances, October 25, 2015 | 26 |  |  | $18.84 |

[0001045810-15-000173:notes:64]
| (1) | Includes the total PSUs that become eligible to vest if the corporate financial performance maximum target level for fiscal year 2016 is achieved. Using an estimate for the level of achievement of the corporate performance target at the end of fiscal year 2016, we are estimating PSUs that become eligible to vest for fiscal year 2016 performance to be in the range of 0 to 2 million shares. We granted PSUs during the first quarter of fiscal year 2016 to our CEO and senior management as approved by our Compensation Committee. |

[0001045810-15-000173:notes:65]
| (2) | Includes the market-based PSUs that become eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs that become eligible to vest could range from 0 to 0.4 million shares. We granted market-based PSUs during the first quarter of fiscal year 2016 to our CEO and senior management as approved by our Compensation Committee. |

[0001045810-15-000173:notes:66]
Of the total fair value of equity awards granted during the three and nine months ended October 25, 2015, the stock-based compensation expense related to equity awards that are not expected to vest was $34 million and $43 million, respectively. Of the total fair value of equity awards granted during the three and nine months ended October 26, 2014, the stock-based compensation expense related to equity awards that are not expected to vest was $28 million and $35 million, respectively.

[0001045810-15-000173:notes:67]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of October 25, 2015 and January 25, 2015:


## us-gaap:EarningsPerShareTextBlock

[0001045810-15-000173:notes:68]
[same as prior period, unchanged from 0001045810-15-000143:notes:61]

[0001045810-15-000173:notes:69]
[same as prior period, unchanged from 0001045810-15-000143:notes:62]

[0001045810-15-000173:notes:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 246 |  |  | $ | 173 |  |  | $ | 406 |  |  | $ | 437 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 542 |  |  | 548 |  |  | 544 |  |  | 555 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Equity awards outstanding | 13 |  |  | 10 |  |  | 13 |  |  | 11 |  |
| Assumed conversion of 1% Convertible Senior Notes Due 2018 | 10 |  |  | — |  |  | 6 |  |  | — |  |
| Denominator for diluted net income per share, weighted average shares | 565 |  |  | 558 |  |  | 563 |  |  | 566 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic net income per share | $ | 0.45 |  |  | $ | 0.32 |  |  | $ | 0.75 |  |  | $ | 0.79 |  |
| Diluted net income per share | $ | 0.44 |  |  | $ | 0.31 |  |  | $ | 0.72 |  |  | $ | 0.77 |  |
| Potentially dilutive equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 9 |  |  | 11 |  |  | 13 |  |  | 16 |  |

[0001045810-15-000173:notes:71]
The 1.00% Convertible Senior Notes, or the Notes, are included in the calculation of diluted net income per share if their inclusion is dilutive. The Notes will generally have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the conversion price of $20.1630 per share. For the three and nine months ended October 25, 2015, our average stock price for the reporting periods exceeded the conversion price, causing the Notes to have a dilutive impact for these periods.

[0001045810-15-000173:notes:72]
[same as prior period, unchanged from 0001045810-15-000143:notes:65]

[0001045810-15-000173:notes:73]
The denominator for diluted net income per share will not include any effect from the warrants, which we entered into concurrently with the issuance of the Notes, unless our average stock price for the reporting period exceeds the strike price of $27.1119 per share.

[0001045810-15-000173:notes:74]
Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Notes.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-15-000173:notes:75]
|  |  | Fair Value at |
|  | Pricing Category |  | October 25, 2015 |  | January 25, 2015 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and Marketable securities |  |  |  |  |  |
| Corporate debt securities (1) | Level 2 |  | $ | 1,975 |  |  | $ | 2,186 |  |
| Debt securities of U.S. government agencies (2) | Level 2 |  | $ | 995 |  |  | $ | 750 |  |
| Debt securities issued by the U.S. Treasury (3) | Level 2 |  | $ | 555 |  |  | $ | 537 |  |
| Asset-backed securities (4) | Level 2 |  | $ | 472 |  |  | $ | 453 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (3) | Level 2 |  | $ | 243 |  |  | $ | 278 |  |
| Foreign government bonds (3) | Level 2 |  | $ | 83 |  |  | $ | 85 |  |
| Money market funds (5) | Level 1 |  | $ | 30 |  |  | $ | 132 |  |
| Liabilities |  |  |  |  |  |
| Other noncurrent liabilities |  |  |  |  |  |
| Interest rate swap (6) | Level 2 |  | $ | 3 |  |  | $ | — |  |
| 1.00% Convertible Senior Notes Due 2018 (7) | Level 2 |  | $ | 2,198 |  |  | $ | 1,680 |  |

[0001045810-15-000173:notes:76]
| (1) | Includes $51 million and $147 million in cash equivalents as of October 25, 2015 and January 25, 2015, respectively, and $1.9 billion and $2.0 billion in marketable securities as of October 25, 2015 and January 25, 2015, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000173:notes:77]
| (2) | Includes $14 million and $15 million in cash equivalents as of October 25, 2015 and January 25, 2015, respectively, and $981 million and $735 million in marketable securities as of October 25, 2015 and January 25, 2015, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000173:notes:78]
| (3) | In marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000173:notes:79]
| (4) | Includes $1 million in cash equivalents as of October 25, 2015 and $471 million and $453 million in marketable securities as of October 25, 2015 and January 25, 2015, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000173:notes:80]
| (5) | In cash equivalents on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000173:notes:81]
| (6) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |

[0001045810-15-000173:notes:82]
(7)   The Notes are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount, and are not marked to fair value each period. See Note 11 for additional information on the Notes.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-15-000173:notes:83]
[same as prior period, unchanged from 0001045810-15-000143:notes:72]

[0001045810-15-000173:notes:84]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy. There were no significant transfers between Levels 1 and 2 assets for the three and nine months ended October 25, 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-15-000173:notes:85]
[same as prior period, unchanged from 0001045810-15-000143:notes:79]

[0001045810-15-000173:notes:86]
We recognized income tax benefit of $1 million for the three months ended October 25, 2015 and income tax expense of $83 million, $36 million and $90 million for the nine months ended October 25, 2015 and three and nine months ended October 26, 2014, respectively. Income tax benefit as a percentage of income before tax was 0.5% for the three months ended October 25, 2015 and income tax expense as a percentage of income before tax was 16.9%, 17.3% and 17.0% for the nine months ended October 25, 2015 and three and nine months ended October 26, 2014, respectively.

[0001045810-15-000173:notes:87]
Our income tax benefit for the three months ended October 25, 2015 included a tax benefit of $49 million from a tax reserve release related to our Icera modem operations upon the expiration of applicable statutes of limitations. In addition to this benefit, our income tax expense for the nine months ended October 25, 2015 also included a $27 million charge for the write-down of a deferred tax asset related to our Icera modem operations, partially offset by the tax benefit related to restructuring and other charges.

[0001045810-15-000173:notes:88]
The decrease in our effective tax rate in the three months ended October 25, 2015 as compared to the same period in the prior fiscal year was primarily due to the favorable impact of the benefit from the expiration of the applicable statutes of limitations, partially offset by an increase in the amount of earnings subject to U.S. tax.

[0001045810-15-000173:notes:89]
Our effective tax rate for the nine months ended October 25, 2015 of 16.9% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, and certain discrete events including the tax benefit recognized upon the expiration of the applicable statutes of limitations and other tax benefits related to the Icera modem operations, partially offset by the write-down of a deferred tax asset related to Icera.

[0001045810-15-000173:notes:90]
Our effective tax rate for the nine months ended October 26, 2014 of 17.0% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate and favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of applicable statutes of limitations.

[0001045810-15-000173:notes:91]
For the nine months ended October 25, 2015, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions.  Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 25, 2015, other than the aforementioned recognition of tax benefits upon the expiration of applicable statutes of limitations in the nine months ended October 25, 2015.

[0001045810-15-000173:notes:92]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon examination, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 25, 2015, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-15-000173:notes:93]
[same as prior period, unchanged from 0001045810-15-000143:notes:87]

[0001045810-15-000173:notes:94]
[same as prior period, unchanged from 0001045810-15-000143:notes:88]

[0001045810-15-000173:notes:95]
|  | October 25, 2015 |  | January 25, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | Accumulated Amortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (148 | ) |  | $ | 45 |  |  | $ | 189 |  |  | $ | (134 | ) |  | $ | 55 |  |
| Patents and licensed technology | 451 |  |  | (324 | ) |  | 127 |  |  | 449 |  |  | (282 | ) |  | 167 |  |
| Total intangible assets | $ | 644 |  |  | $ | (472 | ) |  | $ | 172 |  |  | $ | 638 |  |  | $ | (416 | ) |  | $ | 222 |  |

[0001045810-15-000173:notes:96]
Amortization expense associated with intangible assets was $18 million and $56 million for the three and nine months ended October 25, 2015, respectively, and $19 million and $58 million for the three and nine months ended October 26, 2014, respectively. Future amortization expense related to the net carrying amount of intangible assets at October 25, 2015 is estimated to be $19 million for the remainder of fiscal year 2016, $63 million in fiscal year 2017, $50 million in fiscal year 2018, $22 million in fiscal year 2019, $13 million in fiscal year 2020 and a total of $5 million in fiscal year 2021 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-15-000173:notes:97]
|  | October 25, 2015 |  | January 25, 2015 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 1,453 |  |  | $ | 1,454 |  |  | $ | 1,570 |  |  | $ | 1,571 |  |
| Due in 1 - 5 years | 2,811 |  |  | 2,815 |  |  | 2,720 |  |  | 2,726 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 84 |  |  | 84 |  |  | 123 |  |  | 124 |  |
| Total | $ | 4,348 |  |  | $ | 4,353 |  |  | $ | 4,413 |  |  | $ | 4,421 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-15-000173:notes:98]
[same as prior period, unchanged from 0001045810-15-000143:notes:92]

[0001045810-15-000173:notes:99]
[same as prior period, unchanged from 0001045810-15-000143:notes:93]

[0001045810-15-000173:notes:100]
We performed an impairment review of our investment portfolio as of October 25, 2015. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio as of October 25, 2015.

[0001045810-15-000173:notes:101]
The following is a summary of cash equivalents and marketable securities at October 25, 2015 and January 25, 2015:

[0001045810-15-000173:notes:102]
The following table provides the breakdown of the investments with unrealized losses at October 25, 2015:

[0001045810-15-000173:notes:103]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 798 |  |  | $ | (2 | ) |  | $ | 54 |  |  | $ | — |  |  | $ | 852 |  |  | $ | (2 | ) |
| Mortgage-backed securities issued by U.S. government-sponsored enterprises | 73 |  |  | (1 | ) |  | 26 |  |  | — |  |  | 99 |  |  | (1 | ) |
| Total | $ | 871 |  |  | $ | (3 | ) |  | $ | 80 |  |  | $ | — |  |  | $ | 951 |  |  | $ | (3 | ) |

[0001045810-15-000173:notes:104]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at October 25, 2015 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-15-000173:notes:105]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale at October 25, 2015 and January 25, 2015 and are shown below by contractual maturity:

[0001045810-15-000173:notes:106]
Net realized gains were not significant for the three months ended October 25, 2015 and for the three and nine months ended October 26, 2014. Net realized gains were $3 million for the nine months ended October 25, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001045810-15-000173:notes:107]
[same as prior period, unchanged from 0001045810-15-000143:notes:101]

[0001045810-15-000173:notes:108]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

[0001045810-15-000173:notes:109]
[same as prior period, unchanged from 0001045810-15-000143:notes:103]

[0001045810-15-000173:notes:110]
[same as prior period, unchanged from 0001045810-15-000143:notes:104]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-15-000173:notes:111]
[same as prior period, unchanged from 0001045810-15-000143:notes:105]

[0001045810-15-000173:notes:112]
[same as prior period, unchanged from 0001045810-15-000143:notes:106]

[0001045810-15-000173:notes:113]
[same as prior period, unchanged from 0001045810-15-000143:notes:107]

[0001045810-15-000173:notes:114]
[same as prior period, unchanged from 0001045810-15-000143:notes:108]

[0001045810-15-000173:notes:115]
On July 31, 2015, we announced a voluntary recall and replacement of our SHIELD 8-inch tablets that were sold between July 2014 and July 2015. We have determined that the battery in these tablets can overheat, posing a fire hazard. The recall does not affect any other NVIDIA products. During the nine months ended October 25, 2015, we recorded a $21 million charge against cost of revenue to cover anticipated customer warranty, repair, return, replacement and other associated costs.

[0001045810-15-000173:notes:116]
The estimated product warranty liabilities for the three and nine months ended October 25, 2015 and October 26, 2014 were as follows:

[0001045810-15-000173:notes:117]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In millions) |
| Balance at beginning of period | $ | 28 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 8 |  |
| Additions | — |  |  | 1 |  |  | 22 |  |  | 4 |  |
| Deductions | (15 | ) |  | (2 | ) |  | (17 | ) |  | (5 | ) |
| Balance at end of period | $ | 13 |  |  | $ | 7 |  |  | $ | 13 |  |  | $ | 7 |  |

[0001045810-15-000173:notes:118]
In connection with certain agreements that we have entered into in the past, we have at times provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have also on occasion included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability.  As such, we have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-15-000173:notes:119]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, 2015 |  | October 26, 2014 |  | October 25, 2015 |  | October 26, 2014 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |
| Unallocated revenue | $ | 66 |  |  | $ | 66 |  |  | $ | 198 |  |  | $ | 198 |  |
| Unallocated cost of revenue and operating expenses | (60 | ) |  | (42 | ) |  | (181 | ) |  | (128 | ) |
| Stock-based compensation | (51 | ) |  | (42 | ) |  | (145 | ) |  | (115 | ) |
| Acquisition-related costs | (4 | ) |  | (10 | ) |  | (18 | ) |  | (28 | ) |
| Product warranty charge | — |  |  | — |  |  | (15 | ) |  | — |  |
| Restructuring and other charges | (8 | ) |  | — |  |  | (97 | ) |  | — |  |
| Total | $ | (57 | ) |  | $ | (28 | ) |  | $ | (258 | ) |  | $ | (73 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-15-000173:notes:120]
In May 2015, we announced our intent to wind-down our Icera modem operations and that we were open to a sale of the technology or operations. We pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations in the second quarter of fiscal year 2016.

[0001045810-15-000173:notes:121]
The results of any remaining ongoing Icera modem operations are reported in the Tegra Processor reporting segment, however, restructuring and other charges associated with the wind-down of the Icera modem operations are separately reported with other non-recurring charges and benefits that our CODM deems to be enterprise in nature. Please refer to Note 14 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our reporting segments.

[0001045810-15-000173:notes:122]
Our operating expenses for the three and nine months ended October 25, 2015 included $8 million and $97 million, respectively, of restructuring and other charges. Please refer to Note 4 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding the income tax charges associated with the wind-down of Icera modem operations.

[0001045810-15-000173:notes:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 25, |
|  | 2015 |  | 2015 |
|  | (In millions) |
| Employee severance and related costs | $ | 2 |  |  | $ | 58 |  |
| Tax subsidy impairment | — |  |  | 17 |  |
| Fixed assets impairment | 3 |  |  | 14 |  |
| Facilities and related costs | 2 |  |  | 4 |  |
| Other exit costs | 1 |  |  | 4 |  |
| Restructuring and other charges | $ | 8 |  |  | $ | 97 |  |

[0001045810-15-000173:notes:124]
We expect to incur additional restructuring charges to operating expense of $25 million to $35 million in the fourth quarter of fiscal year 2016. These restructuring activities will impact approximately 5% of our global workforce, and we expect them to be substantially completed by the end of fiscal year 2016. The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Consolidated Balance Sheets as of October 25, 2015:

[0001045810-15-000173:notes:125]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 25, |
|  | 2015 |  | 2015 |
|  | (In millions) |
| Balance at beginning of period | $ | 18 |  |  | $ | — |  |
| Restructuring and other charges | 8 |  |  | 97 |  |
| Cash payments | (7 | ) |  | (46 | ) |
| Non-cash adjustments | (4 | ) |  | (36 | ) |
| Balance at end of period | $ | 15 |  |  | $ | 15 |  |

[0001045810-15-000173:notes:126]
The remaining balance of $15 million as of October 25, 2015 is expected to be paid during the fourth quarter of fiscal year 2016.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-15-000173:notes:127]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 515 |  |  | $ | 406 |  |  | $ | 1,348 |  |  | $ | 1,109 |  |
| China | 229 |  |  | 238 |  |  | 583 |  |  | 714 |  |
| Other Asia Pacific | 181 |  |  | 170 |  |  | 554 |  |  | 475 |  |
| United States | 156 |  |  | 215 |  |  | 474 |  |  | 595 |  |
| Europe | 116 |  |  | 96 |  |  | 341 |  |  | 263 |  |
| Other Americas | 108 |  |  | 100 |  |  | 309 |  |  | 275 |  |
| Total revenue | $ | 1,305 |  |  | $ | 1,225 |  |  | $ | 3,609 |  |  | $ | 3,431 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-15-000173:notes:128]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000173:notes:129]
In July 2015, the Financial Accounting Standards Board, or FASB, issued an accounting standards update for the subsequent measurement of inventory. The amended guidance requires entities to measure inventory at the lower of cost or net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The requirement would replace the current lower of cost or market evaluation. The update is effective for us beginning in our first quarter of fiscal year 2018, with early adoption permitted to be applied prospectively. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements.

[0001045810-15-000173:notes:130]
In April 2015, the FASB issued an accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-15-000173:notes:131]
In April 2015, the FASB issued an accounting standards update that provides clarification on whether a cloud computing arrangement includes a software license. If a software license is included, the customer should account for the license consistent with its accounting for other software licenses. If a software license is not included, the arrangement should be accounted for as a service contract. The update is effective for reporting periods beginning after December 15, 2015, with early adoption permitted. Companies can elect to adopt the standard update prospectively or retrospectively to arrangements entered into, or materially modified, after the effective date. The update will be effective for us beginning in our first quarter of fiscal year 2017. We expect the adoption of this accounting guidance to result in an increase in software license assets and related depreciation expense, and a corresponding decrease in prepaid service contract assets and related service contract expense in our consolidated financial statements.

[0001045810-15-000173:notes:132]
In May 2014, the FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On July 9, 2015, the FASB voted to defer the effective date by one year, such that the new standard will be effective for us beginning in our first quarter of fiscal year 2019. The FASB will also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-15-000173:notes:133]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 25, 2015 |  |  |  |  |  |  |  |
| Revenue | $ | 1,110 |  |  | $ | 129 |  |  | $ | 66 |  |  | $ | 1,305 |  |
| Depreciation and amortization expenses | $ | 26 |  |  | $ | 11 |  |  | $ | 11 |  |  | $ | 48 |  |
| Operating income (loss) | $ | 367 |  |  | $ | (65 | ) |  | $ | (57 | ) |  | $ | 245 |  |
| Three Months Ended October 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 991 |  |  | $ | 168 |  |  | $ | 66 |  |  | $ | 1,225 |  |
| Depreciation and amortization expenses | $ | 29 |  |  | $ | 15 |  |  | $ | 12 |  |  | $ | 56 |  |
| Operating income (loss) | $ | 294 |  |  | $ | (53 | ) |  | $ | (28 | ) |  | $ | 213 |  |
| Nine Months Ended October 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 3,009 |  |  | $ | 402 |  |  | $ | 198 |  |  | $ | 3,609 |  |
| Depreciation and amortization expense | $ | 81 |  |  | $ | 36 |  |  | $ | 34 |  |  | $ | 151 |  |
| Operating income (loss) | $ | 917 |  |  | $ | (164 | ) |  | $ | (258 | ) |  | $ | 495 |  |
| Nine Months Ended October 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,767 |  |  | $ | 466 |  |  | $ | 198 |  |  | $ | 3,431 |  |
| Depreciation and amortization expense | $ | 88 |  |  | $ | 43 |  |  | $ | 35 |  |  | $ | 166 |  |
| Operating income (loss) | $ | 770 |  |  | $ | (169 | ) |  | $ | (73 | ) |  | $ | 528 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-15-000173:notes:134]
[same as prior period, unchanged from 0001045810-15-000143:notes:127]

[0001045810-15-000173:notes:135]
[same as prior period, unchanged from 0001045810-15-000143:notes:128]

[0001045810-15-000173:notes:136]
[same as prior period, unchanged from 0001045810-15-000143:notes:129]

[0001045810-15-000173:notes:137]
[same as prior period, unchanged from 0001045810-15-000143:notes:130]

[0001045810-15-000173:notes:138]
[same as prior period, unchanged from 0001045810-15-000143:notes:131]

[0001045810-15-000173:notes:139]
[same as prior period, unchanged from 0001045810-15-000143:notes:132]

[0001045810-15-000173:notes:140]
[same as prior period, unchanged from 0001045810-15-000143:notes:133]

[0001045810-15-000173:notes:141]
[same as prior period, unchanged from 0001045810-15-000143:notes:134]

[0001045810-15-000173:notes:142]
[same as prior period, unchanged from 0001045810-15-000143:notes:135]

[0001045810-15-000173:notes:143]
Revenue from significant customers, those representing 10% or more of total revenue, aggregated approximately 10% of our total revenue from one customer for the three months ended October 25, 2015 and October 26, 2014. Revenue from significant customers, those representing 10% or more of total revenue, aggregated approximately 11% and 10% of our total revenue from one customer for the nine months ended October 25, 2015 and October 26, 2014, respectively.

[0001045810-15-000173:notes:144]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 19% of our accounts receivable balance from one customer at October 25, 2015 and approximately 30% of our accounts receivable balance from two customers at January 25, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-15-000173:notes:145]
[same as prior period, unchanged from 0001045810-15-000143:notes:138]

[0001045810-15-000173:notes:146]
[same as prior period, unchanged from 0001045810-15-000143:notes:139]

[0001045810-15-000173:notes:147]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 was a 52-week year. The third quarters of fiscal years 2016 and 2015 were both 13-week quarters.

[0001045810-15-000173:notes:148]
[same as prior period, unchanged from 0001045810-15-000143:notes:141]

[0001045810-15-000173:notes:149]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-15-000173:notes:150]
[same as prior period, unchanged from 0001045810-15-000143:notes:143]

[0001045810-15-000173:notes:151]
[same as prior period, unchanged from 0001045810-15-000143:notes:144]

[0001045810-15-000173:notes:152]
[same as prior period, unchanged from 0001045810-15-000143:notes:145]

[0001045810-15-000173:notes:153]
In May 2015 we entered into a $400 million accelerated share repurchase, or ASR, agreement with an investment bank that was completed in October 2015. Under the ASR, we repurchased 18 million shares at an average price of $21.63 per share, of which 14 million shares were delivered in the second quarter of fiscal year 2016 and 4 million shares were delivered in the third quarter of fiscal year 2016. The shares delivered resulted in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.

[0001045810-15-000173:notes:154]
Through October 25, 2015, we have repurchased an aggregate of 226 million shares under our share repurchase program for a total cost of $3.72 billion. All shares delivered from these repurchases have been placed into treasury stock. As of October 25, 2015, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.60 billion.

[0001045810-15-000173:notes:155]
[same as prior period, unchanged from 0001045810-15-000143:notes:149]

[0001045810-15-000173:notes:156]
During the three and nine months ended October 25, 2015, we paid $53 million and $152 million, respectively, in cash dividends to our common shareholders. These dividends were equivalent to $0.0975 per share for the six months ended October 25, 2015 and $0.085 per share for the three months ended April 26, 2015.

[0001045810-15-000173:notes:157]
[same as prior period, unchanged from 0001045810-15-000143:notes:151]

[0001045810-15-000173:notes:158]
[same as prior period, unchanged from 0001045810-15-000143:notes:152]

[0001045810-15-000173:notes:159]
[same as prior period, unchanged from 0001045810-15-000143:notes:153]

[0001045810-15-000173:notes:160]
[same as prior period, unchanged from 0001045810-15-000143:notes:154]


## us-gaap:SubsequentEventsTextBlock

[0001045810-15-000173:notes:161]
Subsequent Event

[0001045810-15-000173:notes:162]
On November 9, 2015, as part of our stock repurchase program, we entered into an ASR with an investment bank, under which we made an upfront payment of $135 million to purchase shares of our common stock and received an initial delivery of 3 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
