# NVDA MD&A — 0001045810-15-000173


## mdna

[0001045810-15-000173:mdna:1]
[same as prior period, unchanged from 0001045810-15-000143:mdna:1]

[0001045810-15-000173:mdna:2]
[same as prior period, unchanged from 0001045810-15-000143:mdna:2]

[0001045810-15-000173:mdna:3]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and our subsidiaries, except where it is made clear that the term means only the parent company.

[0001045810-15-000173:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce Experience, GeForce NOW, ICERA, Iray, Maxwell, NVIDIA DRIVE, NVIDIA GRID, NVIDIA SHIELD, Pascal, Quadro, SHIELD, Tegra, Tesla, and TITAN are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-15-000173:mdna:5]
[same as prior period, unchanged from 0001045810-15-000143:mdna:5]

[0001045810-15-000173:mdna:6]
26

[0001045810-15-000173:mdna:7]
[same as prior period, unchanged from 0001045810-15-000143:mdna:6]

[0001045810-15-000173:mdna:8]
[same as prior period, unchanged from 0001045810-15-000143:mdna:7]

[0001045810-15-000173:mdna:9]
[same as prior period, unchanged from 0001045810-15-000143:mdna:8]

[0001045810-15-000173:mdna:10]
Our business model involves creating NVIDIA-branded products and services, and offering our processors to original equipment manufacturers, or OEMs. NVIDIA’s products and services are built on three computing platforms - PC, Datacenter/Cloud, and Mobile, and address primarily four large markets: Gaming, Professional Visualization, Datacenter, and Automotive.

[0001045810-15-000173:mdna:11]
[same as prior period, unchanged from 0001045810-15-000143:mdna:10]

[0001045810-15-000173:mdna:12]
[same as prior period, unchanged from 0001045810-15-000143:mdna:11]

[0001045810-15-000173:mdna:13]
[same as prior period, unchanged from 0001045810-15-000143:mdna:13]

[0001045810-15-000173:mdna:14]
[same as prior period, unchanged from 0001045810-15-000143:mdna:14]

[0001045810-15-000173:mdna:15]
[same as prior period, unchanged from 0001045810-15-000143:mdna:15]

[0001045810-15-000173:mdna:16]
[same as prior period, unchanged from 0001045810-15-000143:mdna:16]

[0001045810-15-000173:mdna:17]
During the third quarter of fiscal year 2016, we unveiled our next generation virtualized graphics platform - NVIDIA GRID 2.0, which delivers graphics-intensive applications to connected devices. We also announced that Microsoft Azure is the first cloud-services provider to integrate NVIDIA GRID 2.0 capabilities to enable GPU-acceleration in the cloud. During the quarter, we launched the GeForce GTX 950 GPU and enabled a new category of enthusiast-class gaming notebooks with the launch of GTX 980 for notebook. We also introduced NVIDIA GameWorks VR, a software development kit that enables professional designers to bring virtual reality to applications and creates more immersive gameplay on virtual reality-ready desktops and notebooks.  Additionally, we announced that the Swiss Federal Office of Meteorology and Climatology was the first major national weather service to use a GPU-accelerated supercomputer to improve daily forecasts.

[0001045810-15-000173:mdna:18]
[same as prior period, unchanged from 0001045810-15-000143:mdna:17]

[0001045810-15-000173:mdna:19]
[same as prior period, unchanged from 0001045810-15-000143:mdna:18]

[0001045810-15-000173:mdna:20]
[same as prior period, unchanged from 0001045810-15-000143:mdna:19]

[0001045810-15-000173:mdna:21]
During the third quarter of fiscal year 2016, we were featured in new production vehicles and concept cars with NVIDIA-powered digital cockpits, including Mercedes-Benz, Audi, Porsche, Bentley and Honda, at the International Auto Show in Frankfurt, Germany.  We also furthered our partnership with Tesla Motors, which introduced the Model X equipped with an NVIDIA-powered infotainment system and digital instrument cluster. Additionally, we launched GeForce NOW, which allows players to stream video games from the cloud to their SHIELD devices, and we extended sales of our SHIELD Android TV device to key European markets.

[0001045810-15-000173:mdna:22]
27

[0001045810-15-000173:mdna:23]
During the second quarter of fiscal year 2016, we launched the NVIDIA SHIELD Android TV device. For the automotive market, we are partnering with more than 50 companies to use our NVIDIA DRIVE PX platform - a car computer that utilizes deep learning to enable self-driving capabilities - previously announced in the first quarter of fiscal year 2016, in their autonomous driving efforts.

[0001045810-15-000173:mdna:24]
[same as prior period, unchanged from 0001045810-15-000143:mdna:21]

[0001045810-15-000173:mdna:25]
In May 2015 we entered into a $400 million accelerated share repurchase, or ASR, agreement with an investment bank that was completed in October 2015. Under the ASR, we repurchased 18 million shares at an average price of $21.63 per share, of which 14 million shares were delivered in the second quarter of fiscal year 2016 and 4 million shares were delivered in the third quarter of fiscal year 2016. Additionally, we paid $53 million in cash dividends during the third quarter of fiscal year 2016. For the first nine months of fiscal year 2016, we returned a total of $604 million of capital to shareholders. Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding the ASR.

[0001045810-15-000173:mdna:26]
On November 5, 2015, we announced an 18% increase in the quarterly cash dividend to $0.115 per share from $0.0975 per share. We will pay our next quarterly cash dividend of $0.115 per share on December 14, 2015, to all shareholders of record on November 20, 2015. Further, we announced our intention to return approximately $1.0 billion to shareholders in fiscal year 2017 through quarterly cash dividends and share repurchases.

[0001045810-15-000173:mdna:27]
Litigation

[0001045810-15-000173:mdna:28]
In September 2014, we filed lawsuits against Qualcomm, Inc. and various Samsung entities in the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for using our GPU patents without a license. The ITC action was heard in June 2015 and sought to permanently exclude importation of several Samsung products that rely on our patents in the United States, or the Accused Products. In October 2015, the ITC Administrative Law Judge rendered an initial determination that importation of the Samsung Accused Products did not violate U.S. law. We are currently seeking review of the decision by the full commission of the ITC. The commission will decide whether to review parts of the initial determination on or before December 14, 2015 and the target date for the final decision is February 10, 2016. The Delaware case has been stayed during the pendency of the ITC action.

[0001045810-15-000173:mdna:29]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. That complaint and subsequent amended complaints allege that we infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. We have answered the most recent complaint and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted by Samsung. After the court severed our counter-claims from the main action, we voluntarily dismissed our counter-claims from the case. In June 2015, Velocity Micro voluntarily agreed to a permanent injunction preventing it from infringing two of the asserted patents and those patents were dismissed from the case with prejudice. Samsung’s false advertising claim was dismissed with prejudice in July 2015. On October 15, 2015, NVIDIA’s Motion for Entry of Judgment of Noninfringement was granted as to one of Samsung’s patents. Five patents currently asserted against NVIDIA remain and a jury trial is currently scheduled to begin January 19, 2016.

[0001045810-15-000173:mdna:30]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents and seeking an exclusion order barring importation of NVIDIA products alleged to infringe Samsung’s patents. On June 5, 2015, Samsung withdrew one patent from the case, and a hearing on Samsung’s three remaining patents was held from August 18 through August 21, 2015. The Administrative Law Judge is scheduled to issue his initial determination by December 22, 2015. The target date for the final determination by the ITC is April 22, 2016.

[0001045810-15-000173:mdna:31]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed eleven requests for inter partes review on eight of Samsung’s asserted patents. Samsung has filed six requests for inter partes review on six patents asserted by NVIDIA, and Qualcomm has filed three additional requests for inter partes review on two patents asserted by NVIDIA. The United States Patent and Trademark Office has, to date, decided to review three patents owned by NVIDIA, and three patents owned by Samsung. All other requests are currently pending.

[0001045810-15-000173:mdna:32]
Please refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000173:mdna:33]
[same as prior period, unchanged from 0001045810-15-000143:mdna:50]

[0001045810-15-000173:mdna:34]
[same as prior period, unchanged from 0001045810-15-000143:mdna:31]

[0001045810-15-000173:mdna:35]
In May 2015, we announced our intent to wind-down our Icera modem operations and that we were open to a sale of the technology or operations. We pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations in the second quarter of fiscal year 2016.

[0001045810-15-000173:mdna:36]
Our operating expenses for the third quarter and first nine months of fiscal year 2016 included $8 million and $97 million, respectively, of restructuring and other charges. We expect to incur additional restructuring charges to operating expense of $25 million to $35 million in the fourth quarter of fiscal year 2016. These restructuring activities will impact approximately 5% of our global workforce, and we expect them to be substantially completed by the end of fiscal year 2016. Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000173:mdna:37]
[same as prior period, unchanged from 0001045810-15-000143:mdna:36]

[0001045810-15-000173:mdna:38]
[same as prior period, unchanged from 0001045810-15-000143:mdna:37]

[0001045810-15-000173:mdna:39]
[same as prior period, unchanged from 0001045810-15-000143:mdna:38]

[0001045810-15-000173:mdna:40]
[same as prior period, unchanged from 0001045810-15-000143:mdna:39]

[0001045810-15-000173:mdna:41]
[same as prior period, unchanged from 0001045810-15-000143:mdna:40]

[0001045810-15-000173:mdna:42]
[same as prior period, unchanged from 0001045810-15-000143:mdna:41]

[0001045810-15-000173:mdna:43]
Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding segment information.

[0001045810-15-000173:mdna:44]
[same as prior period, unchanged from 0001045810-15-000143:mdna:64]

[0001045810-15-000173:mdna:45]
[same as prior period, unchanged from 0001045810-15-000143:mdna:43]

[0001045810-15-000173:mdna:46]
[same as prior period, unchanged from 0001045810-15-000143:mdna:44]

[0001045810-15-000173:mdna:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, 2015 |  | October 26, 2014 |  | October 25, 2015 |  | October 26, 2014 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 43.8 |  |  | 44.8 |  |  | 44.0 |  |  | 44.6 |  |
| Gross profit | 56.2 |  |  | 55.2 |  |  | 56.0 |  |  | 55.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 25.2 |  |  | 27.8 |  |  | 27.3 |  |  | 29.5 |  |
| Sales, general and administrative | 11.6 |  |  | 10.1 |  |  | 12.2 |  |  | 10.5 |  |
| Restructuring and other charges | 0.6 |  |  | — |  |  | 2.7 |  |  | — |  |
| Total operating expenses | 37.4 |  |  | 37.9 |  |  | 42.2 |  |  | 40.0 |  |
| Operating income | 18.9 |  |  | 17.3 |  |  | 13.8 |  |  | 15.4 |  |
| Interest income | 0.7 |  |  | 0.6 |  |  | 0.8 |  |  | 0.6 |  |
| Interest expense | (0.9 | ) |  | (0.9 | ) |  | (1.0 | ) |  | (1.0 | ) |
| Other income, net | 0.2 |  |  | — |  |  | — |  |  | 0.4 |  |
| Income before income tax | 18.9 |  |  | 17.0 |  |  | 13.6 |  |  | 15.4 |  |
| Income tax expense (benefit) | (0.1 | ) |  | 2.9 |  |  | 2.3 |  |  | 2.6 |  |
| Net income | 19.0 | % |  | 14.1 | % |  | 11.3 | % |  | 12.8 | % |

[0001045810-15-000173:mdna:48]
[same as prior period, unchanged from 0001045810-15-000143:mdna:46]

[0001045810-15-000173:mdna:49]
NVIDIA’s products and services are built for three computing platforms - PC, Datacenter/Cloud, and Mobile. In the first nine months of fiscal year 2016, approximately 75% of our revenue stemmed from products and services associated with the PC computing platform, of which GPUs for gaming and professional visualization markets comprised over 85% while PC OEM represented less than 15%.

[0001045810-15-000173:mdna:50]
[same as prior period, unchanged from 0001045810-15-000143:mdna:51]

[0001045810-15-000173:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, 2015 |  | October 26, 2014 |  | $Change |  | %Change |  | October 25, 2015 |  | October 26, 2014 |  | $Change |  | %Change |
|  | (In millions) |  |  |  | (In millions) |  |  |
| GPU | $ | 1,110 |  |  | $ | 991 |  |  | $ | 119 |  |  | 12 | % |  | $ | 3,009 |  |  | $ | 2,767 |  |  | $ | 242 |  |  | 9 | % |
| Tegra Processor | 129 |  |  | 168 |  |  | (39 | ) |  | (23 | ) |  | 402 |  |  | 466 |  |  | (64 | ) |  | (14 | ) |
| All Other | 66 |  |  | 66 |  |  | — |  |  | — |  |  | 198 |  |  | 198 |  |  | — |  |  | — |  |
| Total | $ | 1,305 |  |  | $ | 1,225 |  |  | $ | 80 |  |  | 7 | % |  | $ | 3,609 |  |  | $ | 3,431 |  |  | $ | 178 |  |  | 5 | % |

[0001045810-15-000173:mdna:52]
Revenue for the third quarter of fiscal year 2016 increased by 7% when compared to the third quarter of fiscal year 2015. Revenue for the first nine months of fiscal year 2016 increased 5% when compared to the first nine months of fiscal year 2015.

[0001045810-15-000173:mdna:53]
GPU Business. GPU business revenue increased by 12% in the third quarter of fiscal year 2016 compared to the third quarter of fiscal year 2015. This increase was due primarily to growth in revenue from high-end GeForce GPUs for gaming, which increased 40% fueled by continued strength in PC gaming. Revenue from Tesla GPUs for Datacenter decreased, reflecting variability in project purchasing. Revenue from Quadro GPUs for professional visualization declined due to weakness in the overall workstation market. Revenue from GeForce GPU products for mainstream PC OEMs declined year-over-year compared to the third quarter of fiscal year 2015, reflecting the decline in overall consumer PCs.

[0001045810-15-000173:mdna:54]
GPU business revenue increased by 9% in the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased over 30% reflecting a combination of continued strength in PC gaming and increased sales of our Maxwell-based GPU products. Revenue from Tesla GPUs for Datacenter increased, driven by strong demand from cloud service providers. Revenue from Quadro GPUs for professional visualization declined due to weakness in the overall workstation market. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-15-000173:mdna:55]
Tegra Processor Business. Tegra Processor business revenue decreased by 23% in the third quarter of fiscal year 2016 compared to the third quarter of fiscal year 2015. This decrease was driven by a decline in sales of Tegra products for OEM smartphones and tablets of over 80%, partially offset by an increase in sales of Tegra products for automotive infotainment systems of over 50%, plus increases in revenue from development services and sales of SHIELD devices.

[0001045810-15-000173:mdna:56]
Tegra Processor business revenue decreased by 14% in the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. This decrease was driven by a decline in sales of Tegra products for OEM smartphones and tablets of almost 90%, partially offset by an increase in sales of Tegra products serving automotive systems of over 75%. Revenue also grew from development services and sales of SHIELD devices.

[0001045810-15-000173:mdna:57]
All Other. We recognized $66 million in revenue during the third quarter of both fiscal years 2016 and 2015 and $198 million in revenue during the first nine months of both fiscal years 2016 and 2015, from the patent cross licensing arrangement with Intel.

[0001045810-15-000173:mdna:58]
[same as prior period, unchanged from 0001045810-15-000143:mdna:57]

[0001045810-15-000173:mdna:59]
Revenue from sales to customers outside of the United States and Other Americas accounted for 80% of total revenue for the third quarter and 78% of total revenue for the first nine months of fiscal year 2016. Revenue from sales to customers outside of the United States and Other Americas accounted for 74% of total revenue for the third quarter and 75% of total revenue for the first nine months of fiscal year 2015. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-15-000173:mdna:60]
We generated revenue from significant customers, those representing 10% or more of total revenue. Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding significant customers.

[0001045810-15-000173:mdna:61]
[same as prior period, unchanged from 0001045810-15-000143:mdna:60]

[0001045810-15-000173:mdna:62]
[same as prior period, unchanged from 0001045810-15-000143:mdna:61]

[0001045810-15-000173:mdna:63]
Gross margin is the percentage of gross profit to revenue. Our gross margin can vary in any period depending on the mix of types of products sold. Product mix is difficult to estimate with accuracy.  Therefore, if we experience product transition challenges, including the introduction of NVIDIA-branded products such as SHIELD devices, if we achieve significant revenue growth in lower margin product lines or if we are unable to earn as much revenue as we expect from higher margin product lines, our gross margin may be negatively impacted.

[0001045810-15-000173:mdna:64]
Our overall gross margin was 56.3% and 55.2% for the third quarter of fiscal years 2016 and 2015, respectively, and 56.0% and 55.4% for the first nine months of fiscal years 2016 and 2015, respectively.

[0001045810-15-000173:mdna:65]
Charges to cost of sales for inventory provisions totaled $40 million and $13 million for the third quarter of fiscal years 2016 and 2015, respectively, unfavorably impacting our gross margin by 3.1% and 1.0%, respectively. Sales of inventory that was previously written-off or written-down totaled $6 million and $12 million for the third quarter of fiscal years 2016 and 2015, respectively, favorably impacting our gross margin by 0.5% and 1.0%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 2.6% unfavorable impact for the third quarter of fiscal year 2016 and a 0.2% unfavorable impact for the third quarter of fiscal year 2015.

[0001045810-15-000173:mdna:66]
Charges to cost of sales for inventory provisions totaled $71 million and $36 million for the first nine months of fiscal years 2016 and 2015, respectively, unfavorably impacting our gross margin by 2.0% and 1.0%, respectively. Sales of inventory that was previously written-off or written-down totaled $26 million and $26 million for the first nine months of fiscal years 2016 and 2015, respectively, favorably impacting our gross margin by 0.7% and 0.8%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 1.3% unfavorable impact for the first nine months of fiscal year 2016 and a 0.2% unfavorable impact for the first nine months of fiscal year 2015.

[0001045810-15-000173:mdna:67]
[same as prior period, unchanged from 0001045810-15-000143:mdna:67]

[0001045810-15-000173:mdna:68]
GPU Business. The gross margin of our GPU business increased in the third quarter and first nine months of fiscal year 2016 compared to the third quarter and first nine months of fiscal year 2015, respectively. GPU margins increased primarily due to a richer product mix resulting from stronger sales of our GeForce GPU products for gaming and lower sales of GeForce GPU products for mainstream PC OEMs.

[0001045810-15-000173:mdna:69]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased in the third quarter and first nine months of fiscal year 2016 compared to the third quarter and first nine months of fiscal year 2015, respectively. The decrease in Tegra margins was due to inventory provisions we recorded during the third quarter of fiscal year 2016 related primarily to older generation Tegra products, the warranty charge we recorded during the first six months of fiscal year 2016 associated with the SHIELD 8-inch tablet product recall, and a less rich product mix during the comparative fiscal year 2016 periods resulting from higher automotive and SHIELD product sales and lower sales of OEM smartphone and tablet products.

[0001045810-15-000173:mdna:70]
[same as prior period, unchanged from 0001045810-15-000143:mdna:70]

[0001045810-15-000173:mdna:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, 2015 |  | October 26, 2014 |  | $Change |  | %Change |  | October 25, 2015 |  | October 26, 2014 |  | $Change |  | %Change |
|  | (In millions) |  |  |  | (In millions) |  |  |
| Research and development expenses | $ | 329 |  |  | $ | 340 |  |  | $ | (11 | ) |  | (3 | )% |  | $ | 987 |  |  | $ | 1,011 |  |  | $ | (24 | ) |  | (2 | )% |
| Sales, general and administrative expenses | 152 |  |  | 123 |  |  | 29 |  |  | 24 |  |  | 441 |  |  | 361 |  |  | 80 |  |  | 22 |  |
| Restructuring and other charges | 8 |  |  | — |  |  | 8 |  |  | 100 |  |  | 97 |  |  | — |  |  | 97 |  |  | 100 |  |
| Total operating expenses | $ | 489 |  |  | $ | 463 |  |  | $ | 26 |  |  | 6 | % |  | $ | 1,525 |  |  | $ | 1,372 |  |  | $ | 153 |  |  | 11 | % |
| Research and development as a percentage of net revenue | 25 | % |  | 28 | % |  |  |  |  |  |  |  | 27 | % |  | 29 | % |  |  |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 12 | % |  | 10 | % |  |  |  |  |  |  |  | 12 | % |  | 11 | % |  |  |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | 1 | % |  | — | % |  |  |  |  |  | 3 | % |  | — | % |  |  |  |  |

[0001045810-15-000173:mdna:72]
[same as prior period, unchanged from 0001045810-15-000143:mdna:72]

[0001045810-15-000173:mdna:73]
Research and development expenses decreased by 3% during the third quarter of fiscal year 2016 compared to the third quarter of fiscal year 2015 and decreased by 2% during the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. These decreases were primarily driven by the wind-down of Icera modem operations and other organization efficiencies, partially offset by increases in employee compensation and related costs, including stock-based compensation expense.

[0001045810-15-000173:mdna:74]
[same as prior period, unchanged from 0001045810-15-000143:mdna:75]

[0001045810-15-000173:mdna:75]
Sales, general and administrative expenses increased by 24% during the third quarter of fiscal year 2016 compared to the third quarter of fiscal year 2015. Outside professional fees increased, primarily due to $15 million of legal fees associated with our litigation against Samsung and Qualcomm. Compensation and benefits increased by $8 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense.

[0001045810-15-000173:mdna:76]
Sales, general and administrative expenses increased by 22% during the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. Outside professional fees increased, primarily due to $55 million of legal fees associated with our litigation against Samsung and Qualcomm. Compensation and benefits increased by $23 million resulting from employee additions, employee compensation increases and related costs, including stock-based compensation expense.

[0001045810-15-000173:mdna:77]
[same as prior period, unchanged from 0001045810-15-000143:mdna:78]

[0001045810-15-000173:mdna:78]
In May 2015, we announced our intent to wind-down our Icera modem operations and that we were open to a sale of the technology or operations. We pursued the sale of Icera’s technology and operations but were unable to identify a viable buyer with genuine interest. As a result, we began the wind-down of Icera modem operations in the second quarter of fiscal year 2016. The wind-down of Icera modem operations allows for continued investment in strategic growth areas including our growth initiatives of deep learning, self-driving cars, and gaming.

[0001045810-15-000173:mdna:79]
Our operating expenses for the third quarter and first nine months of fiscal year 2016 included $8 million and $97 million, respectively, of restructuring and other charges, as follows:

[0001045810-15-000173:mdna:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 25, |
|  | 2015 |  | 2015 |
|  | (In millions) |
| Employee severance and related costs | $ | 2 |  |  | $ | 58 |  |
| Tax subsidy impairment | — |  |  | 17 |  |
| Fixed assets impairment | 3 |  |  | 14 |  |
| Facilities and related costs | 2 |  |  | 4 |  |
| Other exit costs | 1 |  |  | 4 |  |
| Restructuring and other charges | $ | 8 |  |  | $ | 97 |  |

[0001045810-15-000173:mdna:81]
We expect to incur additional restructuring charges to operating expense of $25 million to $35 million in the fourth quarter of fiscal year 2016. These restructuring activities will impact approximately 5% of our global workforce, and we expect them to be substantially completed by the end of fiscal year 2016. Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000173:mdna:82]
[same as prior period, unchanged from 0001045810-15-000143:mdna:83]

[0001045810-15-000173:mdna:83]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest expense is primarily comprised of coupon interest and debt discount amortization related to the convertible notes issued in December 2013. Interest income was $9 million and $7 million during the third quarter of fiscal years 2016 and 2015, respectively. Interest income was $28 million and $20 million during the first nine months of fiscal years 2016 and 2015, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields. Interest expense was $12 million and $35 million during the third quarter and first nine months of fiscal year 2016, respectively, relatively comparable to $11 million and $35 million during the third quarter and first nine months of fiscal year 2015, respectively.

[0001045810-15-000173:mdna:84]
Other Income, net

[0001045810-15-000173:mdna:85]
Other income, net consists primarily of realized gains and losses from the sale of marketable securities, sales of investments in non-affiliated companies, and the impact of changes in foreign currency rates. During the third quarter of fiscal year 2016, we recorded other income, net, of $3 million. Other income, net was insignificant for the third quarter of fiscal year 2015. During the first nine months of fiscal years 2016 and 2015 we recorded other income, net, of $1 million and $14 million, respectively. Other income in the first nine months of fiscal year 2015 included a $17 million gain from the sale of a non-affiliated investment.

[0001045810-15-000173:mdna:86]
[same as prior period, unchanged from 0001045810-15-000143:mdna:88]

[0001045810-15-000173:mdna:87]
We recognized income tax benefit of $1 million for the third quarter of fiscal year 2016 and income tax expense of $83 million, $36 million and $90 million for the first nine months of fiscal year 2016 and third quarter and first nine months of fiscal year 2015, respectively. Income tax benefit as a percentage of income before tax was 0.5% for the third quarter of fiscal year 2016 and income tax expense as a percentage of income before tax was 16.9%, 17.3% and 17.0% for the first nine months of fiscal year 2016 and third quarter and first nine months of fiscal year 2015, respectively.

[0001045810-15-000173:mdna:88]
Our income tax benefit for the third quarter of fiscal year 2016 included a tax benefit of $49 million from a tax reserve release related to our Icera modem operations upon the expiration of applicable statutes of limitations. In addition to this benefit, our income tax expense for the first nine months of fiscal year 2016 also included a $27 million charge for the write-down of a deferred tax asset related to our Icera modem operations, partially offset by the tax benefit related to restructuring and other charges.

[0001045810-15-000173:mdna:89]
The decrease in our effective tax rate in the third quarter of fiscal year 2016 as compared to the same period in the prior fiscal year was primarily due to the favorable impact of the benefit from the expiration of the applicable statutes of limitations, partially offset by an increase in the amount of earnings subject to U.S. tax.

[0001045810-15-000173:mdna:90]
Our effective tax rate for the first nine months of fiscal year 2016 of 16.9% was lower than the U. S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, and certain discrete events including the tax benefit recognized upon the expiration of the applicable statutes of limitations and other tax benefits related to the Icera modem operations, partially offset by the write-down of a deferred tax asset related to Icera.

[0001045810-15-000173:mdna:91]
Our effective tax rate for the first nine months of fiscal year 2015 of 17.0% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax and favorable discrete events primarily attributable to the tax benefit recognized upon the expiration of applicable statutes of limitations.

[0001045810-15-000173:mdna:92]
Our effective tax rates for both the third quarter and first nine months of fiscal years 2016 and 2015 do not include the benefit of the U.S. federal research tax credit as it was expired during these periods. The U.S. federal research tax credit was reenacted in the fourth quarter of fiscal year 2015 while reenactment is uncertain for fiscal year 2016.

[0001045810-15-000173:mdna:93]
[same as prior period, unchanged from 0001045810-15-000143:mdna:95]

[0001045810-15-000173:mdna:94]
[same as prior period, unchanged from 0001045810-15-000143:mdna:96]

[0001045810-15-000173:mdna:95]
|  | As of |
|  | October 25, 2015 |  | January 25, 2015 |
|  | (In millions) |
| Cash and cash equivalents | $ | 471 |  |  | $ | 497 |  |
| Marketable securities | 4,257 |  |  | 4,126 |  |
| Cash, cash equivalents, and marketable securities | $ | 4,728 |  |  | $ | 4,623 |  |

[0001045810-15-000173:mdna:96]
As of October 25, 2015, we had $4.73 billion in cash, cash equivalents and marketable securities, an increase of $105 million from $4.62 billion as of January 25, 2015. This increase was primarily due to the cash generated by operations, partially offset by share repurchases totaling $452 million and $152 million of dividends we paid during the first nine months of fiscal year 2016.

[0001045810-15-000173:mdna:97]
|  | Nine Months Ended |
|  | October 25, 2015 |  | October 26, 2014 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 664 |  |  | $ | 463 |  |
| Net cash used in investing activities | $ | (187 | ) |  | $ | (409 | ) |
| Net cash used in financing activities | $ | (503 | ) |  | $ | (811 | ) |

[0001045810-15-000173:mdna:98]
Cash provided by operating activities increased in the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. The increase was primarily due to changes in working capital, partially offset by a decline in net income.

[0001045810-15-000173:mdna:99]
Cash used in investing activities decreased in the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. The decrease was primarily due to higher proceeds from sales and maturities of marketable securities.

[0001045810-15-000173:mdna:100]
Cash used in financing activities decreased in the first nine months of fiscal year 2016 compared to the first nine months of fiscal year 2015. The decrease was primarily due to the lower amount of stock repurchases in the current year.

[0001045810-15-000173:mdna:101]
[same as prior period, unchanged from 0001045810-15-000143:mdna:103]

[0001045810-15-000173:mdna:102]
Our primary source of liquidity is cash generated by our operations. Our investment portfolio consists principally of cash and cash equivalents, debt securities of corporations and the United States government and its agencies, asset-backed securities, mortgage-backed securities issued by government-sponsored enterprises, money market funds and foreign government bonds. These investments are denominated in United States dollars. As of October 25, 2015, we did not have any investments in auction-rate preferred securities.

[0001045810-15-000173:mdna:103]
[same as prior period, unchanged from 0001045810-15-000143:mdna:105]

[0001045810-15-000173:mdna:104]
As of October 25, 2015 and January 25, 2015, we had $4.73 billion and $4.62 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of October 25, 2015, we were in compliance with our investment policy. As of October 25, 2015, our investments in government agencies and government-sponsored enterprises represented 41% of our total investment portfolio, while the financial sector accounted for 25% of our total investment portfolio.  All of our investments are in A/A3 or better rated securities.

[0001045810-15-000173:mdna:105]
Our cash balances are held in numerous locations throughout the world, including substantial amounts held outside of the United States. Most of the amounts held outside the United States may be repatriated to the United States.  However, if we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal income tax at rate of 35% less utilization of any net operating loss carryforwards, and further offset by any applicable research and foreign tax credits, plus any state income taxes on such income. Repatriation of some foreign balances may be restricted by local laws.

[0001045810-15-000173:mdna:106]
Dividend payments and any share repurchases must be made from cash held in the United States. In the third quarter and first nine months of fiscal year 2016, we made total cash dividend payments of $53 million and $152 million, respectively, and repurchased $111 million and $452 million of our common stock in the third quarter and first nine months of fiscal year 2016, respectively, utilizing U.S. cash previously taxed as of October 25, 2015.

[0001045810-15-000173:mdna:107]
In the second quarter of fiscal year 2016, we began the wind-down of Icera modem operations. Our operating expenses for the third quarter and first nine months of fiscal year 2016 included $8 million and $97 million, respectively, of restructuring and other charges. We expect to incur additional restructuring charges to operating expense of $25 million to $35 million in the fourth quarter of fiscal year 2016.  Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-15-000173:mdna:108]
[same as prior period, unchanged from 0001045810-15-000143:mdna:111]

[0001045810-15-000173:mdna:109]
In May 2015 we entered into a $400 million ASR agreement with an investment bank that was completed in October 2015. Under the ASR, we repurchased 18 million shares at an average price of $21.63 per share, of which 14 million shares were delivered in the second quarter of fiscal year 2016 and 4 million shares were delivered in the third quarter of fiscal year 2016. Additionally, we paid $53 million in cash dividends during the third quarter of fiscal year 2016.

[0001045810-15-000173:mdna:110]
On November 5, 2015, we announced an 18% increase in the quarterly cash dividend to $0.115 per share from $0.0975 per share. We will pay our next quarterly cash dividend of $0.115 per share on December 14, 2015, to all shareholders of record on November 20, 2015. We intend to return $800 million to shareholders in fiscal year 2016 through quarterly cash dividends and share repurchases, of which $604 million has been returned in the first nine months of fiscal year 2016.

[0001045810-15-000173:mdna:111]
[same as prior period, unchanged from 0001045810-15-000143:mdna:113]

[0001045810-15-000173:mdna:112]
[same as prior period, unchanged from 0001045810-15-000143:mdna:114]

[0001045810-15-000173:mdna:113]
We believe that our existing cash, cash equivalents and marketable securities balances and anticipated cash flows from operations will be sufficient to meet our operating, acquisition, share repurchase, cash dividend and capital requirements for at least the next twelve months. However, there is no assurance that we will not need to raise additional equity or debt financing within this time frame. Additional financing may not be available on favorable terms or at all and may be dilutive to our then-current shareholders. We also may require additional capital for other purposes not presently contemplated.

[0001045810-15-000173:mdna:114]
During the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. This headquarters building is being financed as an operating lease arrangement. Under the terms of this financing arrangement, costs incurred by us that are associated with the construction will be reimbursed by the banks.

[0001045810-15-000173:mdna:115]
[same as prior period, unchanged from 0001045810-15-000143:mdna:117]

[0001045810-15-000173:mdna:116]
During the second quarter of fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. The banks have committed to fund up to $380 million of costs relating to construction. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks. During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. Please refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for a discussion regarding our operating lease financing arrangement.

[0001045810-15-000173:mdna:117]
[same as prior period, unchanged from 0001045810-15-000143:mdna:119]

[0001045810-15-000173:mdna:118]
As of October 25, 2015, we had outstanding inventory purchase obligations totaling $442 million. Other than the off-balance sheet arrangement described above, there were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

[0001045810-15-000173:mdna:119]
[same as prior period, unchanged from 0001045810-15-000143:mdna:121]

[0001045810-15-000173:mdna:120]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000173:mdna:121]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
