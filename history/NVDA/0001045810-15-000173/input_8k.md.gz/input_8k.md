# NVDA 8-K — 0001045810-15-000165 filed 2015-11-05

## item codes, every 8-K on or before 2015-11-18

- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2015-11-18

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-15-000165:8k_2_02:1]
EX-99.1
2
q316pr.htm
Q3'16 PRESS RELEASE

[0001045810-15-000165:8k_2_02:2]
Exhibit

[0001045810-15-000165:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-15-000165:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2016

[0001045810-15-000165:8k_2_02:5]
| • | Record revenue of $1.305 billion, up 7 percent from a year ago, up 13 percent sequentially |

[0001045810-15-000165:8k_2_02:6]
| • | GAAP operating income of $245 million, up 15 percent from a year ago |

[0001045810-15-000165:8k_2_02:7]
| • | Quarterly cash dividend raised 18 percent to $0.115 per share. Company to return $1 billion to shareholders in fiscal 2017 |

[0001045810-15-000165:8k_2_02:8]
SANTA CLARA, Calif.-Nov. 5, 2015-NVIDIA (NASDAQ: NVDA) today reported record revenue for the third quarter ended October 25, 2015, of $1.305 billion, up 7 percent from $1.225 billion a year earlier, and up 13 percent from $1.153 billion in the previous quarter.

[0001045810-15-000165:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.44, up 42 percent from $0.31 a year earlier and up from $0.05 in the previous quarter. Non-GAAP earnings per diluted share were $0.46, up 18 percent from $0.39 a year earlier, and up 35 percent from $0.34 in the previous quarter.

[0001045810-15-000165:8k_2_02:10]
“Our record revenue highlights NVIDIA’s position at the center of forces that are reshaping our industry,” said Jen-Hsun Huang, co-founder and chief executive officer, NVIDIA. “Virtual reality, deep learning, cloud computing and autonomous driving are developing with incredible speed, and we are playing an important role in all of them.

[0001045810-15-000165:8k_2_02:11]
“We continue to make great headway in our strategy of creating specialized visual computing platforms targeted at important growth markets. The opportunities ahead of us have never been more promising,” he said.

[0001045810-15-000165:8k_2_02:12]
Capital Return

[0001045810-15-000165:8k_2_02:13]
During the third quarter, NVIDIA paid $53 million in cash dividends and received an additional 4.6 million shares at the close of the accelerated share repurchase agreement that it had entered into in the previous quarter. As a result, the company has returned an aggregate of $604 million to shareholders in the first nine months of the fiscal year. The company intends to return $800 million to shareholders in fiscal 2016.

[0001045810-15-000165:8k_2_02:14]
For fiscal 2017, NVIDIA intends to return approximately $1.0 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-15-000165:8k_2_02:15]
The company announced an 18 percent increase in its quarterly cash dividend to $0.115 per share from $0.0975 per share. NVIDIA will pay this next quarterly cash dividend on December 14, 2015, to all shareholders of record on November 20, 2015.

[0001045810-15-000165:8k_2_02:16]
| GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q3 FY16 | Q2 FY16 | Q3 FY15 | Q/Q | Y/Y |
| Revenue | $1,305 | $1,153 | $1,225 | up 13% | up 7% |
| Gross margin | 56.3% | 55.0% | 55.2% | up 130 bps | up 110 bps |
| Operating expenses | $489 | $558 | $463 | down 12% | up 6% |
| Operating income | $245 | $76 | $213 | up 222% | up 15% |
| Net income | $246 | $26 | $173 | up 846% | up 42% |
| Diluted earnings per share | $0.44 | $0.05 | $0.31 | up 780% | up 42% |

[0001045810-15-000165:8k_2_02:17]
| Non-GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q3 FY16 | Q2 FY16 | Q3 FY15 | Q/Q | Y/Y |
| Revenue | $1,305 | $1,153 | $1,225 | up 13% | up 7% |
| Gross margin | 56.5% | 56.6% | 55.5% | down 10 bps | up 100 bps |
| Operating expenses | $430 | $421 | $415 | up 2% | up 4% |
| Operating income | $308 | $231 | $264 | up 33% | up 17% |
| Net income | $255 | $190 | $220 | up 34% | up 16% |
| Diluted earnings per share | $0.46 | $0.34 | $0.39 | up 35% | up 18% |

[0001045810-15-000165:8k_2_02:18]
NVIDIA’s outlook for the fourth quarter of fiscal 2016 is as follows:

[0001045810-15-000165:8k_2_02:19]
| • | Revenue is expected to be $1.30 billion, plus or minus two percent. |

[0001045810-15-000165:8k_2_02:20]
| • | GAAP and non-GAAP gross margins are expected to be 56.7 percent and 57.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-15-000165:8k_2_02:21]
| • | GAAP operating expenses are expected to be approximately $503 million. Non-GAAP operating expenses are expected to be approximately $445 million. |

[0001045810-15-000165:8k_2_02:22]
| • | GAAP and non-GAAP tax rates for the fourth quarter of fiscal 2016 are expected to be 20 percent, plus or minus one percent. |

[0001045810-15-000165:8k_2_02:23]
| • | The above GAAP outlook amounts exclude restructuring charges, which are expected to be in the range of $25 million to $35 million, in the fourth quarter of fiscal 2016. |

[0001045810-15-000165:8k_2_02:24]
| • | Capital expenditures are expected to be approximately $20 million to $30 million. |

[0001045810-15-000165:8k_2_02:25]
Third Quarter Fiscal 2016 Highlights

[0001045810-15-000165:8k_2_02:26]
During the third quarter, NVIDIA achieved progress in each of its platforms.

[0001045810-15-000165:8k_2_02:27]
Gaming:

[0001045810-15-000165:8k_2_02:28]
| • | Introduced the GeForce® GTX 950 GPU, designed to play the latest games with processing power that rivals any console. |

[0001045810-15-000165:8k_2_02:29]
| • | Introduced NVIDIA GameWorks™ VR, a software development kit for creating gaming experiences on virtual reality-ready desktops and notebooks. |

[0001045810-15-000165:8k_2_02:30]
| • | Launched GeForce NOW™, allowing players to instantly stream titles from the cloud to their SHIELD device. |

[0001045810-15-000165:8k_2_02:31]
| • | Extended SHIELD™ Android TV into key European markets. |

[0001045810-15-000165:8k_2_02:32]
Professional Visualization:

[0001045810-15-000165:8k_2_02:33]
| • | Enabled professional designers to bring virtual reality to applications, with the launch of NVIDIA DesignWorks™ VR. |

[0001045810-15-000165:8k_2_02:34]
Datacenter:

[0001045810-15-000165:8k_2_02:35]
| • | Unveiled the next generation of its virtualized graphics platform, NVIDIA GRID™ 2.0, which delivers even the most graphics-intensive applications to any connected device. |

[0001045810-15-000165:8k_2_02:36]
| • | Announced that Microsoft Azure will be the first cloud-services provider to offer GRID 2.0 capabilities, as well as accelerated computing. |

[0001045810-15-000165:8k_2_02:37]
| • | Revealed that the Swiss Federal Office of Meteorology and Climatology is the first major national weather service to use a GPU-accelerated supercomputer to improve daily forecasts. |

[0001045810-15-000165:8k_2_02:38]
Auto:

[0001045810-15-000165:8k_2_02:39]
| • | Featured in new production vehicles and concept cars with NVIDIA-powered digital cockpits from Mercedes-Benz, Audi, Porsche, Bentley and Honda at the International Auto Show in Frankfurt. |

[0001045810-15-000165:8k_2_02:40]
| • | Furthered its partnership with Tesla Motors, which introduced the Model X, equipped with an NVIDIA-powered infotainment system and digital instrument cluster. |

[0001045810-15-000165:8k_2_02:41]
CFO Commentary

[0001045810-15-000165:8k_2_02:42]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-15-000165:8k_2_02:43]
Conference Call and Webcast Information

[0001045810-15-000165:8k_2_02:44]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2016 financial results and current financial prospects today at 2 p.m. Pacific Time (5 p.m. Eastern Time). To listen to the conference call, dial (303) 223-2699; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its fourth quarter and fiscal 2016.

[0001045810-15-000165:8k_2_02:45]
Non-GAAP Measures

[0001045810-15-000165:8k_2_02:46]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, product warranty charge, acquisition-related costs, restructuring and other charges, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-15-000165:8k_2_02:47]
Keep Current on NVIDIA

[0001045810-15-000165:8k_2_02:48]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-15-000165:8k_2_02:49]
About NVIDIA

[0001045810-15-000165:8k_2_02:50]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-15-000165:8k_2_02:51]
###

[0001045810-15-000165:8k_2_02:52]
For further information, contact:

[0001045810-15-000165:8k_2_02:53]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-15-000165:8k_2_02:54]
Certain statements in this press release including, but not limited to statements as to: the company’s position and role in virtual reality, deep learning, cloud computing and autonomous driving; the company making great headway in its strategy; the company’s next quarterly cash dividend; the company’s intended fiscal 2016 and 2017 capital returns; the company’s financial outlook for the fourth quarter of fiscal 2016; the company’s tax rates for the fourth quarter of fiscal 2016; and Microsoft Azure’s offering of GRID 2.0 capabilities and accelerated computing are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended July 26, 2015. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-15-000165:8k_2_02:55]
© 2015 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, NVIDIA DesignWorks, NVIDIA GameWorks, NVIDIA GRID, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-15-000165:8k_2_02:56]
NVIDIA CORPORATION

[0001045810-15-000165:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-15-000165:8k_2_02:58]
(In millions, except per share data)

[0001045810-15-000165:8k_2_02:59]
(Unaudited)

[0001045810-15-000165:8k_2_02:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, |  | October 26, |  | October 25, |  | October 26, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue | $ | 1,305 |  |  | $ | 1,225 |  |  | $ | 3,609 |  |  | $ | 3,431 |  |
| Cost of revenue | 571 |  |  | 549 |  |  | 1,589 |  |  | 1,531 |  |
| Gross profit | 734 |  |  | 676 |  |  | 2,020 |  |  | 1,900 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 329 |  |  | 340 |  |  | 987 |  |  | 1,011 |  |
| Sales, general and administrative | 152 |  |  | 123 |  |  | 441 |  |  | 361 |  |
| Restructuring and other charges | 8 |  |  | — |  |  | 97 |  |  | — |  |
| Total operating expenses | 489 |  |  | 463 |  |  | 1,525 |  |  | 1,372 |  |
| Operating income | 245 |  |  | 213 |  |  | 495 |  |  | 528 |  |
| Interest income | 9 |  |  | 7 |  |  | 28 |  |  | 20 |  |
| Interest expense | (12 | ) |  | (11 | ) |  | (35 | ) |  | (35 | ) |
| Other income, net | 3 |  |  | — |  |  | 1 |  |  | 14 |  |
| Income before income tax expense | 245 |  |  | 209 |  |  | 489 |  |  | 527 |  |
| Income tax expense (benefit) | (1 | ) |  | 36 |  |  | 83 |  |  | 90 |  |
| Net income | $ | 246 |  |  | $ | 173 |  |  | $ | 406 |  |  | $ | 437 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.45 |  |  | $ | 0.32 |  |  | $ | 0.75 |  |  | $ | 0.79 |  |
| Diluted | $ | 0.44 |  |  | $ | 0.31 |  |  | $ | 0.72 |  |  | $ | 0.77 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 542 |  |  | 548 |  |  | 544 |  |  | 555 |  |
| Diluted | 565 |  |  | 558 |  |  | 563 |  |  | 566 |  |

[0001045810-15-000165:8k_2_02:61]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | October 25, |  | January 25, |
|  |  |  | 2015 |  | 2015 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,728 |  |  | $ | 4,623 |  |
|  | Accounts receivable, net |  | 536 |  |  | 474 |  |
|  | Inventories |  | 425 |  |  | 483 |  |
|  | Prepaid expenses and other current assets |  | 145 |  |  | 133 |  |
|  | Total current assets |  | 5,834 |  |  | 5,713 |  |
| Property and equipment, net |  | 477 |  |  | 557 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 172 |  |  | 222 |  |
| Other assets |  | 73 |  |  | 91 |  |
|  | Total assets |  | $ | 7,174 |  |  | $ | 7,201 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 295 |  |  | $ | 293 |  |
|  | Accrued and other current liabilities |  | 560 |  |  | 603 |  |
|  | Total current liabilities |  | 855 |  |  | 896 |  |
| Long-term debt |  | 1,406 |  |  | 1,384 |  |
| Other long-term liabilities |  | 437 |  |  | 489 |  |
| Capital lease obligations, long-term |  | 11 |  |  | 14 |  |
| Shareholders' equity |  | 4,465 |  |  | 4,418 |  |
|  | Total liabilities and shareholders' equity |  | $ | 7,174 |  |  | $ | 7,201 |  |

[0001045810-15-000165:8k_2_02:62]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | July 26, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP gross profit |  | $ | 734 |  |  | $ | 634 |  |  | $ | 676 |  |  | $ | 2,020 |  |  | $ | 1,900 |  |
| GAAP gross margin |  | 56.3 | % |  | 55.0 | % |  | 55.2 | % |  | 56.0 | % |  | 55.4 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 4 |  |  | 3 |  |  | 4 |  |  | 10 |  |  | 8 |  |
| Product warranty charge (B) |  | — |  |  | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 738 |  |  | $ | 652 |  |  | $ | 680 |  |  | $ | 2,045 |  |  | $ | 1,908 |  |
| Non-GAAP gross margin |  | 56.5 | % |  | 56.6 | % |  | 55.5 | % |  | 56.7 | % |  | 55.6 | % |
| GAAP operating expenses |  | $ | 489 |  |  | $ | 558 |  |  | $ | 463 |  |  | $ | 1,525 |  |  | $ | 1,372 |  |
| Stock-based compensation expense included in operating expense (A) |  | (47 | ) |  | (44 | ) |  | (38 | ) |  | (134 | ) |  | (107 | ) |
| Acquisition-related costs (C) |  | (4 | ) |  | (4 | ) |  | (10 | ) |  | (18 | ) |  | (28 | ) |
| Restructuring and other charges |  | (8 | ) |  | (89 | ) |  | — |  |  | (97 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 430 |  |  | $ | 421 |  |  | $ | 415 |  |  | $ | 1,276 |  |  | $ | 1,237 |  |
| GAAP operating income |  | $ | 245 |  |  | $ | 76 |  |  | $ | 213 |  |  | $ | 495 |  |  | $ | 528 |  |
| Total impact of non-GAAP adjustments to operating income |  | 63 |  |  | 155 |  |  | 51 |  |  | 274 |  |  | 143 |  |
| Non-GAAP operating income |  | $ | 308 |  |  | $ | 231 |  |  | $ | 264 |  |  | $ | 769 |  |  | $ | 671 |  |
| GAAP other income (expense), net |  | $ | — |  |  | $ | (4 | ) |  | $ | (4 | ) |  | $ | (6 | ) |  | $ | (1 | ) |
| Gains from non-affiliated investments |  | (4 | ) |  | — |  |  | — |  |  | (4 | ) |  | (14 | ) |
| Interest expense related to amortization of debt discount |  | 7 |  |  | 7 |  |  | 7 |  |  | 21 |  |  | 21 |  |
| Non-GAAP other income, net |  | $ | 3 |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 6 |  |
| GAAP net income |  | $ | 246 |  |  | $ | 26 |  |  | $ | 173 |  |  | $ | 406 |  |  | $ | 437 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 66 |  |  | 163 |  |  | 58 |  |  | 291 |  |  | 150 |  |
| Income tax impact of non-GAAP adjustments |  | (57 | ) |  | 1 |  |  | (11 | ) |  | (65 | ) |  | (27 | ) |
| Non-GAAP net income |  | $ | 255 |  |  | $ | 190 |  |  | $ | 220 |  |  | $ | 632 |  |  | $ | 560 |  |

[0001045810-15-000165:8k_2_02:63]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | July 26, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.44 |  |  | $ | 0.05 |  |  | $ | 0.31 |  |  | $ | 0.72 |  |  | $ | 0.77 |  |
| Non-GAAP |  | $ | 0.46 |  |  | $ | 0.34 |  |  | $ | 0.39 |  |  | $ | 1.13 |  |  | $ | 0.99 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 565 |  |  | 556 |  |  | 558 |  |  | 563 |  |  | 566 |  |
| Anti-dilution impact from note hedge (D) |  | (10 | ) |  | (4 | ) |  | — |  |  | (6 | ) |  | — |  |
| Non-GAAP |  | 555 |  |  | 552 |  |  | 558 |  |  | 557 |  |  | 566 |  |
| Metrics: |  |  |  |  |  |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 255 |  |  | $ | 163 |  |  | $ | 216 |  |  | $ | 664 |  |  | $ | 463 |  |
| Purchase of property and equipment and intangible assets |  | (16 | ) |  | (24 | ) |  | (40 | ) |  | (71 | ) |  | (91 | ) |
| Free cash flow |  | $ | 239 |  |  | $ | 139 |  |  | $ | 176 |  |  | $ | 593 |  |  | $ | 372 |  |

[0001045810-15-000165:8k_2_02:64]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 25, |  | July 26, |  | October 26, |  | October 25, |  | October 26, |
|  |  | 2015 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of revenue |  | $ | 4 |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 8 |  |
| Research and development |  | $ | 28 |  |  | $ | 27 |  |  | $ | 22 |  |  | $ | 82 |  |  | $ | 65 |  |
| Sales, general and administrative |  | $ | 19 |  |  | $ | 17 |  |  | $ | 16 |  |  | $ | 53 |  |  | $ | 42 |  |
| (B) Represents warranty charge associated with product recall. |
| (C) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (D) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-15-000165:8k_2_02:65]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2016 Outlook |
| GAAP gross margin |  | 56.7 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 57.0 | % |
|  |  |  | Q4 FY2016 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 503 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (58 | ) |
| Non-GAAP operating expenses |  | $ | 445 |  |
