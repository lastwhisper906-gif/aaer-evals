# NVDA note change history — 0001045810-16-000353 → 0001045810-17-000075


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0001045810-17-000075:note_history:1]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring in December 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.
  (was, 2016-11-22, similarity 0.9694):
[0001045810-16-000353:note_history:1]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

- added (2017-05-23):
[0001045810-17-000075:note_history:2]
We have been overseeing the construction of the headquarters building. The banks committed to fund up to $380 million of costs relating to construction. Advances have been made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest is capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

- changed (2017-05-23):
[0001045810-17-000075:note_history:3]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to the financial covenant to maintain a maximum total leverage ratio not to exceed 3.5 to 1.0. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.
  (was, 2016-11-22, similarity 0.8774):
[0001045810-16-000353:note_history:3]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

- added (2017-05-23):
[0001045810-17-000075:note_history:4]
Litigation

- added (2017-05-23):
[0001045810-17-000075:note_history:5]
Polaris Innovations Limited

- added (2017-05-23):
[0001045810-17-000075:note_history:6]
On May 16, 2016, Polaris Innovations Limited, a non-practicing entity and wholly-owned subsidiary of Wi-LAN Inc., filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe on six of its U.S. patents related generally to control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA.

- added (2017-05-23):
[0001045810-17-000075:note_history:7]
On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents. On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and transferred the case to the Northern District of California. A trial date has not yet been set.

- added (2017-05-23):
[0001045810-17-000075:note_history:8]
On December 7, 2016, NVIDIA filed an inter partes review request with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. An institution decision is expected in both of these matters in June 2017. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. If instituted, the USPTO will conduct a trial on the validity of each of these patents.

- added (2017-05-23):
[0001045810-17-000075:note_history:9]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. NVIDIA has retained counsel in Germany to defend this case. A trial date has not yet been set. On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. Polaris has not yet responded to these actions.

- added (2017-05-23):
[0001045810-17-000075:note_history:10]
On May 9, 2017, NVIDIA filed a Motion to Stay the action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  If the motion is granted, the action will be suspended until the inter partes reviews are finally resolved.

- added (2017-05-23):
[0001045810-17-000075:note_history:11]
While there can be no assurance of favorable outcomes, we believe the claims made by other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 30, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2017-05-23):
[0001045810-16-000353:note_history:12]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

- removed (2017-05-23):
[0001045810-16-000353:note_history:13]
Patent Infringement Cases

- removed (2017-05-23):
[0001045810-16-000353:note_history:14]
In September 2014, NVIDIA filed complaints against Qualcomm, Inc. and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing. In November 2014, Samsung filed complaints against NVIDIA in the ITC and the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed certain patents.

- removed (2017-05-23):
[0001045810-16-000353:note_history:15]
NVIDIA and Samsung, and NVIDIA and Qualcomm, also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office.

- removed (2017-05-23):
[0001045810-16-000353:note_history:16]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941. On June 16, 2016, the ITC granted the joint motion and terminated the ITC investigation. The parties have also moved to dismiss all pending inter partes reviews. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party. On June 28, 2016, NVIDIA and Samsung executed a settlement agreement based on the April 28, 2016 memorandum of understanding.

- removed (2017-05-23):
[0001045810-16-000353:note_history:17]
NVIDIA’s dismissals on May 11, 2016 and May 12, 2016 also terminated its claims against Qualcomm.

- removed (2017-05-23):
[0001045810-16-000353:note_history:18]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. On June 1, 2016, the ITC issued a Notice determining not to review the Administrative Law Judge’s determination, thereby finalizing termination of the investigation as to NVIDIA. Pursuant to the license agreement, $10 million was recorded as a charge to cost of revenue during the three months ended May 1, 2016.

- removed (2017-05-23):
[0001045810-16-000353:note_history:19]
We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-05-23):
[0001045810-17-000075:note_history:20]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The first quarter of fiscal years 2018 and 2017 were both 13-week quarters.

- added (2017-05-23):
[0001045810-17-000075:note_history:21]
In October 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which requires the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs.  We elected to early adopt this new guidance in the first quarter of fiscal year 2018, which required us to reflect any adjustments as of January 30, 2017. Upon adoption of this guidance, we recorded a cumulative-effect adjustment as of the first day of fiscal year 2018 to decrease retained earnings by $28 million, with a corresponding decrease to prepaid taxes that had not been previously recognized in income tax expense.

- changed (2017-05-23):
[0001045810-17-000075:note_history:22]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.
  (was, 2016-11-22, similarity 0.9944):
[0001045810-16-000353:note_history:22]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.

- added (2017-05-23):
[0001045810-17-000075:note_history:23]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.

- removed (2017-05-23):
[0001045810-16-000353:note_history:24]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The third quarter of fiscal years 2017 and 2016 were both 13-week quarters.

- removed (2017-05-23):
[0001045810-16-000353:note_history:25]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting. Among other elements, the new guidance eliminates additional paid in capital, or APIC, pools and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The new standard is effective for us beginning in our first quarter of fiscal year 2018 with early adoption permitted. We elected to early adopt this new guidance in the third quarter of fiscal year 2017, which required us to reflect any adjustments as of February 1, 2016.

- removed (2017-05-23):
[0001045810-16-000353:note_history:26]
Early adoption of this guidance resulted in the following:

- removed (2017-05-23):
[0001045810-16-000353:note_history:27]
| • | We recorded excess tax benefits within income tax expense, rather than in APIC, of $12 million, $8 million and $42 million for the first, second and third quarters of fiscal year 2017, respectively. |

- removed (2017-05-23):
[0001045810-16-000353:note_history:28]
| • | We recorded a cumulative-effect adjustment as of February 1, 2016 to increase retained earnings by $353 million, with a corresponding increase to deferred tax assets, to recognize the net operating loss and federal research tax credit carryforwards attributable to excess tax benefits on stock-based compensation that had not been previously recognized in APIC. |

- removed (2017-05-23):
[0001045810-16-000353:note_history:29]
| • | The excess tax benefits are now included in net operating cash rather than net financing cash in our Condensed Consolidated Statements of Cash Flows. We elected to apply this change in presentation prospectively and thus prior periods have not been adjusted. |

- removed (2017-05-23):
[0001045810-16-000353:note_history:30]
We elected not to change our policy on accounting for forfeitures, although the new guidance provides an option for us to account for forfeitures as they occur, and thus continued to estimate forfeitures expected to occur to determine the amount of compensation cost to be recognized in each period.

- removed (2017-05-23):
[0001045810-16-000353:note_history:31]
The adoption of this new guidance impacted our previously reported quarterly results for fiscal year 2017 as follows:

- removed (2017-05-23):
[0001045810-16-000353:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | May 1, 2016 |  | July 31, 2016 |
|  | As reported |  | As adjusted |  | As reported |  | As adjusted |  | As reported |  | As adjusted |
|  | (In millions, except per share data) |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | $ | 64 |  |  | $ | 56 |  |  | $ | 45 |  |  | $ | 33 |  |  | $ | 109 |  |  | $ | 89 |  |
| Net income | $ | 253 |  |  | $ | 261 |  |  | $ | 196 |  |  | $ | 208 |  |  | $ | 449 |  |  | $ | 469 |  |
| Basic net income per share | $ | 0.47 |  |  | $ | 0.49 |  |  | $ | 0.36 |  |  | $ | 0.39 |  |  | $ | 0.84 |  |  | $ | 0.88 |  |
| Diluted net income per share | $ | 0.40 |  |  | $ | 0.41 |  |  | $ | 0.33 |  |  | $ | 0.35 |  |  | $ | 0.73 |  |  | $ | 0.76 |  |
| Weighted average shares used in diluted net income per share computation | 631 |  |  | 634 |  |  | 597 |  |  | 599 |  |  | 617 |  |  | 620 |  |
| Condensed Consolidated Statements of Cash Flows: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 184 |  |  | $ | 201 |  |  | $ | 309 |  |  | $ | 318 |  |  | $ | 493 |  |  | $ | 519 |  |
| Net cash used in financing activities | $ | (35 | ) |  | $ | (52 | ) |  | $ | (534 | ) |  | $ | (545 | ) |  | $ | (570 | ) |  | $ | (597 | ) |

- removed (2017-05-23):
[0001045810-16-000353:note_history:33]
In October 2016, the FASB issued an accounting standards update that requires the recognition of income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

- removed (2017-05-23):
[0001045810-16-000353:note_history:34]
In August 2016, the FASB issued an accounting standards update that clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not expected to have a material impact on our consolidated financial statements.

- removed (2017-05-23):
[0001045810-16-000353:note_history:35]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. The new standard will be effective for us beginning in our first quarter of fiscal year 2019, although we are permitted to adopt the standard one year earlier. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption, or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0001045810-17-000075:note_history:36]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 222 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (7 | ) |  | (31 | ) |
| Net carrying amount | $ | 215 |  |  | $ | 796 |  |
  (was, 2016-11-22, similarity 0.9589):
[0001045810-16-000353:note_history:36]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,056 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (45 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,011 |  |  | $ | 1,413 |  |

- changed (2017-05-23):
[0001045810-17-000075:note_history:37]
(1) As of April 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.6 years.
  (was, 2016-11-22, similarity 0.9554):
[0001045810-16-000353:note_history:37]
(1) As of October 30, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.1 years.

- changed (2017-05-23):
[0001045810-17-000075:note_history:38]
|  |  | Three Months Ended |
|  |  | April 30, |  | May 1, |
|  |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |
| Amortization of debt discount |  | 1 |  |  | 8 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 12 |  |
  (was, 2016-11-22, similarity 0.7232):
[0001045810-16-000353:note_history:38]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 5 |  |  | 7 |  |  | 20 |  |  | 22 |  |
| Total interest expense related to Convertible Notes |  | $ | 8 |  |  | $ | 11 |  |  | $ | 30 |  |  | $ | 33 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0001045810-17-000075:note_history:39]
1.00% Convertible Senior Notes Due 2018
  (was, 2016-11-22, similarity 0.9851):
[0001045810-16-000353:note_history:39]
1.00 % Convertible Senior Notes Due 2018

- added (2017-05-23):
[0001045810-17-000075:note_history:40]
During the first quarter of fiscal year 2018, we paid cash to settle an aggregate of $605 million in principal amount of the Convertible Notes and had $222 million in principal amount outstanding as of April 30, 2017. We also issued 24 million shares of our common stock for the excess conversion value and recognized a loss of $14 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $104.30 on the last trading day of the first quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of April 30, 2017 exceeded their principal amount by approximately $933 million. As of April 30, 2017, the conversion rate was 49.8598 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0562 per share of common stock).

- added (2017-05-23):
[0001045810-17-000075:note_history:41]
Through the first quarter of fiscal year 2018, we settled an aggregate of $1.28 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $136 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the second quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

- added (2017-05-23):
[0001045810-17-000075:note_history:42]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continue to be convertible at the holders’ option through July 30, 2017.

- added (2017-05-23):
[0001045810-17-000075:note_history:43]
We separately accounted for the liability and equity components of the Convertible Notes at issuance, since our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

- added (2017-05-23):
[0001045810-17-000075:note_history:44]
As of April 30, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

- changed (2017-05-23):
[0001045810-17-000075:note_history:45]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 222 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (7 | ) |  | (31 | ) |
| Net carrying amount | $ | 215 |  |  | $ | 796 |  |
  (was, 2016-11-22, similarity 0.9589):
[0001045810-16-000353:note_history:45]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,056 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (45 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,011 |  |  | $ | 1,413 |  |

- changed (2017-05-23):
[0001045810-17-000075:note_history:46]
(1) As of April 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.6 years.
  (was, 2016-11-22, similarity 0.9554):
[0001045810-16-000353:note_history:46]
(1) As of October 30, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.1 years.

- changed (2017-05-23):
[0001045810-17-000075:note_history:47]
|  |  | Three Months Ended |
|  |  | April 30, |  | May 1, |
|  |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |
| Amortization of debt discount |  | 1 |  |  | 8 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 12 |  |
  (was, 2016-11-22, similarity 0.7232):
[0001045810-16-000353:note_history:47]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 5 |  |  | 7 |  |  | 20 |  |  | 22 |  |
| Total interest expense related to Convertible Notes |  | $ | 8 |  |  | $ | 11 |  |  | $ | 30 |  |  | $ | 33 |  |

- changed (2017-05-23):
[0001045810-17-000075:note_history:48]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges. The Note Hedges have an adjusted strike price of $20.0562 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. During the first quarter of fiscal year 2018, we had received 24 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $605 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $136 million in principal amount that is expected to settle during the second quarter of fiscal year 2018.
  (was, 2016-11-22, similarity 0.6761):
[0001045810-16-000353:note_history:48]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Convertible Notes, or $20.1630 per share. Adjusting for dividends paid through October 30, 2016, the strike price of the Note Hedges has been adjusted to $20.0780 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through October 30, 2016, we had received 15 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of an aggregate of $444 million in principal amount of the Convertible Notes.

- added (2017-05-23):
[0001045810-17-000075:note_history:49]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an adjusted strike price of $26.9988 per share. In the fourth quarter of fiscal year 2017, we contracted with a counterparty bank to terminate 63 million of the 75 million warrants outstanding and issued 48 million shares of our common stock related to the terminated Warrants.

- changed (2017-05-23):
[0001045810-17-000075:note_history:50]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026 (collectively, the Notes). Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.
  (was, 2016-11-22, similarity 0.7629):
[0001045810-16-000353:note_history:50]
On September 16, 2016, we issued $1.00 billion of 2.20% notes due September 16, 2021 and $1.00 billion of 3.20% notes due September 16, 2026 (collectively, the Notes). Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2.20% Notes Due 2021 on or after August 16, 2021, or for redemptions of the 3.20% Notes Due 2026 on or after June 16, 2026.

- added (2017-05-23):
[0001045810-17-000075:note_history:51]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |

- removed (2017-05-23):
[0001045810-16-000353:note_history:52]
On December 2, 2013, we issued $1.50 billion of 1.00% convertible senior notes, or the Convertible Notes, due 2018. The Convertible Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Convertible Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Convertible Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of October 30, 2016, the conversion rate has been adjusted to 49.8058 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0780 per share of common stock) for dividend increases.

- removed (2017-05-23):
[0001045810-16-000353:note_history:53]
We separately accounted for the liability and equity components of the Convertible Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

- removed (2017-05-23):
[0001045810-16-000353:note_history:54]
The initial debt component of the Convertible Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Convertible Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method using an interest rate of 3.15%.

- removed (2017-05-23):
[0001045810-16-000353:note_history:55]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Convertible Notes regardless of the foregoing conditions.

- removed (2017-05-23):
[0001045810-16-000353:note_history:56]
The Convertible Notes first became convertible as of February 1, 2016. As of October 30, 2016, the Convertible Notes continued to be convertible at the holders’ option through January 29, 2017 as the price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended October 30, 2016. As such, the $1,011 million carrying value of the Convertible Notes continued to be classified as a current liability and the $45 million difference between the principal amount and the carrying value of the Convertible Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Convertible Notes are convertible. The determination of whether or not the Convertible Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Convertible Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

- removed (2017-05-23):
[0001045810-16-000353:note_history:57]
Upon conversion of the Convertible Notes, we will pay cash up to the aggregate principal amount of the Convertible Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Convertible Notes being converted. Based on the closing price of our common stock on October 28, 2016 (the last trading day of the third quarter of fiscal year 2017) of $70.56, the if-converted value of our Convertible Notes exceeded their principal amount by approximately $2.66 billion.

- removed (2017-05-23):
[0001045810-16-000353:note_history:58]
During both the three and nine months ended October 30, 2016, we paid cash to settle $444 million in principal amount, issued 15 million shares of our common stock with respect to the conversion obligation in excess of the principal amount, and recognized a loss of $15 million on early conversions, of the Convertible Notes. Further, we received additional conversion notices for an aggregate of $229 million in principal amount of the Convertible Notes during the third quarter of fiscal year 2017. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2017.

- removed (2017-05-23):
[0001045810-16-000353:note_history:59]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of October 30, 2016, the strike price was adjusted to $27.0281 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 75 million shares of our common stock. As of October 30, 2016, the Warrants had not been exercised and remained outstanding. The value of the Warrants was initially recorded in equity and continues to be classified as equity.

- removed (2017-05-23):
[0001045810-16-000353:note_history:60]
The net proceeds from the Notes were $1.99 billion, after deducting debt discount and issuance costs. We intend to use the net proceeds from the Notes to prefund the repayment of the principal amount of our Convertible Notes and for general corporate purposes such as dividend payments or share repurchases.

- removed (2017-05-23):
[0001045810-16-000353:note_history:61]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30,2016 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.9 |  | 2.38% |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.9 |  | 3.31% |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (18 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,982 |  |

- removed (2017-05-23):
[0001045810-16-000353:note_history:62]
Revolving Credit Facility

- removed (2017-05-23):
[0001045810-16-000353:note_history:63]
On October 7, 2016, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021, on which all outstanding obligations would be due and payable. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of October 30, 2016, we had not borrowed any amounts under the Credit Agreement.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-05-23):
[0001045810-17-000075:note_history:64]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |

- removed (2017-05-23):
[0001045810-16-000353:note_history:65]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30,2016 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.9 |  | 2.38% |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.9 |  | 3.31% |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (18 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,982 |  |
