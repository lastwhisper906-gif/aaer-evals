# NVDA notes — 0001045810-17-000075


## nvda:BalanceSheetComponentsTextBlock

[0001045810-17-000075:notes:1]
[same as prior period, unchanged from 0001045810-16-000353:notes:1]

[0001045810-17-000075:notes:2]
[same as prior period, unchanged from 0001045810-16-000353:notes:2]

[0001045810-17-000075:notes:3]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
| Inventories: | (In millions) |
| Raw materials | $ | 375 |  |  | $ | 252 |  |
| Work in-process | 137 |  |  | 176 |  |
| Finished goods | 309 |  |  | 366 |  |
| Total inventories | $ | 821 |  |  | $ | 794 |  |

[0001045810-17-000075:notes:4]
As of April 30, 2017, we had outstanding inventory purchase obligations totaling $799 million.

[0001045810-17-000075:notes:5]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer related liabilities (1) | $ | 220 |  |  | $ | 197 |  |
| Accrued payroll and related expenses | 71 |  |  | 137 |  |
| Deferred revenue (2) | 46 |  |  | 85 |  |
| Professional service fees | 15 |  |  | 13 |  |
| Accrued restructuring and other charges (3) | 11 |  |  | 13 |  |
| Taxes payable | 10 |  |  | 4 |  |
| Accrued royalties | 8 |  |  | 7 |  |
| Coupon interest on debt obligations | 7 |  |  | 21 |  |
| Warranty accrual (4) | 7 |  |  | 8 |  |
| Contributions payable | 5 |  |  | 4 |  |
| Leases payable | 5 |  |  | 4 |  |
| Other | 15 |  |  | 14 |  |
| Total accrued and other current liabilities | $ | 420 |  |  | $ | 507 |  |

[0001045810-17-000075:notes:6]
[same as prior period, unchanged from 0001045810-16-000353:notes:6]

[0001045810-17-000075:notes:7]
| (2) | Deferred revenue primarily includes customer advances and deferrals related to license and service arrangements. The balance decreased as we recognized the remaining revenue under our patent license agreement with Intel during the first quarter of fiscal year 2018. |

[0001045810-17-000075:notes:8]
| (3) | Please refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding restructuring and other charges. |

[0001045810-17-000075:notes:9]
| (4) | Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding warranties. |

[0001045810-17-000075:notes:10]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 159 |  |  | $ | 141 |  |
| Income tax payable | 101 |  |  | 96 |  |
| Contributions payable | 11 |  |  | 10 |  |
| Deferred revenue | 5 |  |  | 4 |  |
| Other | 24 |  |  | 20 |  |
| Total other long-term liabilities | $ | 300 |  |  | $ | 271 |  |


## nvda:ScheduleofAccountReceivablefromMajorCustomersTableTextBlock

[0001045810-17-000075:notes:11]
|  |  | April 30, |  | January 29, |
|  |  | 2017 |  | 2017 |
| Accounts Receivable: |  |  |  |  |
| Customer A |  | 16 | % |  | 19 | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-17-000075:notes:12]
|  | Three Months Ended |
|  | April 30, |  | May 1, |
|  | 2017 |  | 2016 |
|  | (In millions) |
| Revenue: |  |  |  |
| Gaming | $ | 1,027 |  |  | $ | 687 |  |
| Professional Visualization | 205 |  |  | 189 |  |
| Datacenter | 409 |  |  | 143 |  |
| Automotive | 140 |  |  | 113 |  |
| OEM & IP | 156 |  |  | 173 |  |
| Total revenue | $ | 1,937 |  |  | $ | 1,305 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-17-000075:notes:13]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 708 |  |  | $ | 627 |  |
| Estimated weighted average remaining amortization period | (In years) |
| Stock options | 0.4 |  |  | 0.5 |  |
| RSUs, PSUs, and market-based PSUs | 2.6 |  |  | 2.6 |  |
| ESPP | 0.6 |  |  | 0.6 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-17-000075:notes:14]
|  | April 30, 2017 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 1,866 |  |  | $ | 1 |  |  | $ | (7 | ) |  | $ | 1,860 |  |  | $ | — |  |  | $ | 1,860 |  |
| Debt securities of United States government agencies | 1,067 |  |  | — |  |  | (5 | ) |  | 1,062 |  |  | — |  |  | 1,062 |  |
| Debt securities issued by the United States Treasury | 683 |  |  | — |  |  | (2 | ) |  | 681 |  |  | — |  |  | 681 |  |
| Asset-backed securities | 381 |  |  | — |  |  | (1 | ) |  | 380 |  |  | — |  |  | 380 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 169 |  |  | 2 |  |  | (1 | ) |  | 170 |  |  | — |  |  | 170 |  |
| Foreign government bonds | 64 |  |  | — |  |  | — |  |  | 64 |  |  | — |  |  | 64 |  |
| Money market funds | 41 |  |  | — |  |  | — |  |  | 41 |  |  | 41 |  |  | — |  |
| Total | $ | 4,271 |  |  | $ | 3 |  |  | $ | (16 | ) |  | $ | 4,258 |  |  | $ | 41 |  |  | $ | 4,217 |  |

[0001045810-17-000075:notes:15]
|  | January 29, 2017 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,397 |  |  | $ | 1 |  |  | $ | (10 | ) |  | $ | 2,388 |  |  | $ | 33 |  |  | $ | 2,355 |  |
| Debt securities of United States government agencies | 1,193 |  |  | — |  |  | (5 | ) |  | 1,188 |  |  | 27 |  |  | 1,161 |  |
| Debt securities issued by the United States Treasury | 852 |  |  | — |  |  | (2 | ) |  | 850 |  |  | 55 |  |  | 795 |  |
| Asset-backed securities | 490 |  |  | — |  |  | (1 | ) |  | 489 |  |  | — |  |  | 489 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 161 |  |  | 2 |  |  | (1 | ) |  | 162 |  |  | — |  |  | 162 |  |
| Foreign government bonds | 70 |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Money market funds | 321 |  |  | — |  |  | — |  |  | 321 |  |  | 321 |  |  | — |  |
| Total | $ | 5,484 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 5,468 |  |  | $ | 436 |  |  | $ | 5,032 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-17-000075:notes:16]
[same as prior period, unchanged from 0001045810-16-000353:notes:18]

[0001045810-17-000075:notes:17]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 29, 2017 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017.

[0001045810-17-000075:notes:18]
[same as prior period, unchanged from 0001045810-16-000353:notes:20]

[0001045810-17-000075:notes:19]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-17-000075:notes:20]
Commitments and Contingencies

[0001045810-17-000075:notes:21]
Operating Lease Financing Arrangement

[0001045810-17-000075:notes:22]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-17-000075:notes:23]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring in December 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-17-000075:notes:24]
We have been overseeing the construction of the headquarters building. The banks committed to fund up to $380 million of costs relating to construction. Advances have been made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest is capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-17-000075:notes:25]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-17-000075:notes:26]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to the financial covenant to maintain a maximum total leverage ratio not to exceed 3.5 to 1.0. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-17-000075:notes:27]
Litigation

[0001045810-17-000075:notes:28]
Polaris Innovations Limited

[0001045810-17-000075:notes:29]
On May 16, 2016, Polaris Innovations Limited, a non-practicing entity and wholly-owned subsidiary of Wi-LAN Inc., filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe on six of its U.S. patents related generally to control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA.

[0001045810-17-000075:notes:30]
On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents. On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and transferred the case to the Northern District of California. A trial date has not yet been set.

[0001045810-17-000075:notes:31]
On December 7, 2016, NVIDIA filed an inter partes review request with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. An institution decision is expected in both of these matters in June 2017. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. If instituted, the USPTO will conduct a trial on the validity of each of these patents.

[0001045810-17-000075:notes:32]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. NVIDIA has retained counsel in Germany to defend this case. A trial date has not yet been set. On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. Polaris has not yet responded to these actions.

[0001045810-17-000075:notes:33]
On May 9, 2017, NVIDIA filed a Motion to Stay the action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  If the motion is granted, the action will be suspended until the inter partes reviews are finally resolved.

[0001045810-17-000075:notes:34]
Accounting for Loss Contingencies

[0001045810-17-000075:notes:35]
While there can be no assurance of favorable outcomes, we believe the claims made by other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 30, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-17-000075:notes:36]
[same as prior period, unchanged from 0001045810-16-000353:notes:37]

[0001045810-17-000075:notes:37]
[same as prior period, unchanged from 0001045810-16-000353:notes:38]


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-17-000075:notes:38]
The following table presents the carrying value of the Convertible Notes:

[0001045810-17-000075:notes:39]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 222 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (7 | ) |  | (31 | ) |
| Net carrying amount | $ | 215 |  |  | $ | 796 |  |

[0001045810-17-000075:notes:40]
(1) As of April 30, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.6 years.

[0001045810-17-000075:notes:41]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

[0001045810-17-000075:notes:42]
|  |  | Three Months Ended |
|  |  | April 30, |  | May 1, |
|  |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 4 |  |
| Amortization of debt discount |  | 1 |  |  | 8 |  |
| Total interest expense related to Convertible Notes |  | $ | 1 |  |  | $ | 12 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-17-000075:notes:43]
Debt

[0001045810-17-000075:notes:44]
Convertible Debt

[0001045810-17-000075:notes:45]
1.00% Convertible Senior Notes Due 2018

[0001045810-17-000075:notes:46]
During the first quarter of fiscal year 2018, we paid cash to settle an aggregate of $605 million in principal amount of the Convertible Notes and had $222 million in principal amount outstanding as of April 30, 2017. We also issued 24 million shares of our common stock for the excess conversion value and recognized a loss of $14 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $104.30 on the last trading day of the first quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of April 30, 2017 exceeded their principal amount by approximately $933 million. As of April 30, 2017, the conversion rate was 49.8598 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0562 per share of common stock).

[0001045810-17-000075:notes:47]
Through the first quarter of fiscal year 2018, we settled an aggregate of $1.28 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $136 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the second quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

[0001045810-17-000075:notes:48]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition was met, the Convertible Notes first became convertible at the holders' option beginning on the first day of fiscal year 2017 and continue to be convertible at the holders’ option through July 30, 2017.

[0001045810-17-000075:notes:49]
We separately accounted for the liability and equity components of the Convertible Notes at issuance, since our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

[0001045810-17-000075:notes:50]
As of April 30, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

[0001045810-17-000075:notes:51]
Note Hedges and Warrants

[0001045810-17-000075:notes:52]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges. The Note Hedges have an adjusted strike price of $20.0562 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. During the first quarter of fiscal year 2018, we had received 24 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $605 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $136 million in principal amount that is expected to settle during the second quarter of fiscal year 2018.

[0001045810-17-000075:notes:53]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an adjusted strike price of $26.9988 per share. In the fourth quarter of fiscal year 2017, we contracted with a counterparty bank to terminate 63 million of the 75 million warrants outstanding and issued 48 million shares of our common stock related to the terminated Warrants.

[0001045810-17-000075:notes:54]
Long-Term Debt

[0001045810-17-000075:notes:55]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-17-000075:notes:56]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026 (collectively, the Notes). Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-17-000075:notes:57]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-17-000075:notes:58]
The carrying value of our long-term debt and the associated interest rates were as follows:

[0001045810-17-000075:notes:59]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (16 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,984 |  |  | $ | 1,983 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-17-000075:notes:60]
[same as prior period, unchanged from 0001045810-16-000353:notes:66]

[0001045810-17-000075:notes:61]
In fiscal year 2016, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building that entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments. This interest rate swap is designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are recorded in accumulated other comprehensive income (loss) and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur.

[0001045810-17-000075:notes:62]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income (loss) and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts as of April 30, 2017 was not significant.

[0001045810-17-000075:notes:63]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than our reporting currency. These foreign currency forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded as a component of total other income (expense) and offsets the change in fair value of the foreign currency denominated monetary assets and liabilities, which is also recorded in total other income (expense).

[0001045810-17-000075:notes:64]
The table below presents the notional value of our foreign currency forward contracts:

[0001045810-17-000075:notes:65]
|  | Three Months Ended |
|  | April 30, 2017 |  | May 1, 2016 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 74 |  |  | $ | 35 |  |
| Not designated for hedge accounting | $ | 51 |  |  | $ | — |  |

[0001045810-17-000075:notes:66]
[same as prior period, unchanged from 0001045810-16-000353:notes:70]

[0001045810-17-000075:notes:67]
As of April 30, 2017, the maturities of the designated foreign currency forward contracts were three months or less.

[0001045810-17-000075:notes:68]
We formally assess, both at inception and on an ongoing basis, whether derivative financial instruments designated for hedge accounting treatment are highly effective. For the first quarter of fiscal years 2018 and 2017, all derivative financial instruments designated for hedge accounting treatment were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-17-000075:notes:69]
During the first quarter of fiscal years 2018 and 2017, net change in unrealized gains (losses) on derivative financial instruments designated for hedge accounting treatment were not significant.

[0001045810-17-000075:notes:70]
We expect to realize all gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months. However, we do not expect to reclassify any amount from accumulated other comprehensive income (loss) into earnings related to the interest rate swap as its settlement for the operating lease financing expense will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-17-000075:notes:71]
[same as prior period, unchanged from 0001045810-16-000353:notes:75]

[0001045810-17-000075:notes:72]
[same as prior period, unchanged from 0001045810-16-000353:notes:76]

[0001045810-17-000075:notes:73]
[same as prior period, unchanged from 0001045810-16-000353:notes:77]

[0001045810-17-000075:notes:74]
|  | Three Months Ended |
|  | April 30, 2017 |  | May 1, 2016 |
|  | (In millions) |
| Cost of revenue | $ | 4 |  |  | $ | 4 |  |
| Research and development | 41 |  |  | 29 |  |
| Sales, general and administrative | 31 |  |  | 20 |  |
| Total | $ | 76 |  |  | $ | 53 |  |

[0001045810-17-000075:notes:75]
[same as prior period, unchanged from 0001045810-16-000353:notes:79]

[0001045810-17-000075:notes:76]
The following is a summary of equity award transactions under our equity incentive plans:

[0001045810-17-000075:notes:77]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted Average Exercise Price Per Share |
|  | (In millions, except per share data) |
| Balances, January 29, 2017 | 27 |  |  | $ | 32.84 |  |  | 7 |  |  | $ | 14.47 |  |
| Granted (1) (2) | 2 |  |  | $ | 99.23 |  |  | — |  |  | $ | — |  |
| Exercised | — |  |  | $ | — |  |  | (1 | ) |  | $ | 14.73 |  |
| Vested restricted stock | (5 | ) |  | $ | 20.82 |  |  | — |  |  | $ | — |  |
| Canceled and forfeited | — |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balances, April 30, 2017 | 24 |  |  | $ | 40.90 |  |  | 6 |  |  | $ | 14.43 |  |

[0001045810-17-000075:notes:78]
| (1) | Includes PSUs that will be issued and eligible to vest if the corporate financial performance maximum target level for fiscal year 2018 is achieved. Depending on the actual level of achievement of the corporate performance target at the end of fiscal year 2018, the PSUs issued could be up to 0.6 million shares. |

[0001045810-17-000075:notes:79]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs issued could be up to 0.1 million shares. |

[0001045810-17-000075:notes:80]
Of the total fair value of equity awards granted during the first quarter of fiscal years 2018 and 2017, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $27 million and $10 million, respectively.

[0001045810-17-000075:notes:81]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of April 30, 2017 and January 29, 2017:


## us-gaap:EarningsPerShareTextBlock

[0001045810-17-000075:notes:82]
[same as prior period, unchanged from 0001045810-16-000353:notes:86]

[0001045810-17-000075:notes:83]
[same as prior period, unchanged from 0001045810-16-000353:notes:87]

[0001045810-17-000075:notes:84]
|  | Three Months Ended |
|  | April 30, |  | May 1, |
|  | 2017 |  | 2016 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |
| Net income | $ | 507 |  |  | $ | 208 |  |
| Denominator: |  |  |  |
| Basic weighted average shares | 592 |  |  | 537 |  |
| Dilutive impact of outstanding securities: |  |  |  |
| Equity awards | 26 |  |  | 20 |  |
| 1% Convertible Senior Notes | 14 |  |  | 29 |  |
| Warrants issued with the 1% Convertible Senior Notes | 9 |  |  | 13 |  |
| Diluted weighted average shares | 641 |  |  | 599 |  |
| Net income per share: |  |  |  |
| Basic (1) | $ | 0.86 |  |  | $ | 0.39 |  |
| Diluted (2) | $ | 0.79 |  |  | $ | 0.35 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 2 |  |  | 3 |  |

[0001045810-17-000075:notes:85]
[same as prior period, unchanged from 0001045810-16-000353:notes:89]

[0001045810-17-000075:notes:86]
[same as prior period, unchanged from 0001045810-16-000353:notes:90]

[0001045810-17-000075:notes:87]
The 1.00% Convertible Senior Notes, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0562 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share. The Warrants have a dilutive impact on net income per share if our average stock price for the quarter exceeds the adjusted strike price of $26.9988 per share.

[0001045810-17-000075:notes:88]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transactions, or the Note Hedges, that we entered into concurrently with the issuance of the Convertible Notes, as this effect would be anti-dilutive. In the event of conversion of the Convertible Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Convertible Notes.

[0001045810-17-000075:notes:89]
In the fourth quarter of fiscal year 2017, we contracted with a counterparty bank to terminate 63 million of the 75 million Warrants outstanding. In consideration for the termination of these Warrants, we delivered a total of 48 million shares of common stock to the counterparty bank.

[0001045810-17-000075:notes:90]
For the first quarter of fiscal years 2018 and 2017, our average stock price was $105.22 and $32.63, respectively, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Convertible Notes and the Warrants to have a dilutive impact for these periods.

[0001045810-17-000075:notes:91]
Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Convertible Notes, Note Hedges, and Warrants.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-17-000075:notes:92]
|  |  | Fair Value at |
|  | Pricing Category |  | April 30, 2017 |  | January 29, 2017 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 1,860 |  |  | $ | 2,388 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,062 |  |  | $ | 1,188 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 681 |  |  | $ | 850 |  |
| Asset-backed securities | Level 2 |  | $ | 380 |  |  | $ | 489 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 170 |  |  | $ | 162 |  |
| Foreign government bonds | Level 2 |  | $ | 64 |  |  | $ | 70 |  |
| Money market funds | Level 1 |  | $ | 41 |  |  | $ | 321 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 1,149 |  |  | $ | 4,474 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 987 |  |  | $ | 975 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 979 |  |  | $ | 961 |  |
| Interest rate swap (2) | Level 2 |  | $ | 3 |  |  | $ | 2 |  |

[0001045810-17-000075:notes:93]
| (1) | The remaining 1.00% Convertible Notes, 2.20% Notes Due 2021, and 3.20% Notes Due 2026 are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. See Note 11 of these Notes to Condensed Consolidated Financial Statements for additional information. |

[0001045810-17-000075:notes:94]
| (2) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-17-000075:notes:95]
[same as prior period, unchanged from 0001045810-16-000353:notes:101]

[0001045810-17-000075:notes:96]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review the fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 assets for the first quarter of fiscal year 2018. We did not have any investments classified as Level 3 as of April 30, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-17-000075:notes:97]
[same as prior period, unchanged from 0001045810-16-000353:notes:103]

[0001045810-17-000075:notes:98]
We recognized income tax expense of $29 million and $33 million for the first quarter of fiscal years 2018 and 2017, respectively.  Income tax expense as a percentage of income before income tax was 5.5% and 13.7% for the first quarter of fiscal years 2018 and 2017, respectively.

[0001045810-17-000075:notes:99]
The decrease in our effective tax rate in the first quarter of fiscal year 2018 as compared to the same period in the prior fiscal year primarily reflects the recognition of tax benefits related to stock-based compensation and a proportional decrease in the amount of earnings subject to United States tax in the first quarter of fiscal year 2018.

[0001045810-17-000075:notes:100]
Our effective tax rate for the first quarter of fiscal year 2018 of 5.5% and fiscal year 2017 of 13.7% was lower than the U.S. federal statutory rate of 35% due primarily to tax benefits related to stock-based compensation, income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, and the benefit of the U.S. federal research tax credit.

[0001045810-17-000075:notes:101]
For the first quarter of fiscal year 2018, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 29, 2017.

[0001045810-17-000075:notes:102]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 30, 2017, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-17-000075:notes:103]
[same as prior period, unchanged from 0001045810-16-000353:notes:109]

[0001045810-17-000075:notes:104]
[same as prior period, unchanged from 0001045810-16-000353:notes:110]

[0001045810-17-000075:notes:105]
|  | April 30, 2017 |  | January 29, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (171 | ) |  | $ | 22 |  |  | $ | 193 |  |  | $ | (167 | ) |  | $ | 26 |  |
| Patents and licensed technology | 469 |  |  | (401 | ) |  | 68 |  |  | 468 |  |  | (390 | ) |  | 78 |  |
| Total intangible assets | $ | 662 |  |  | $ | (572 | ) |  | $ | 90 |  |  | $ | 661 |  |  | $ | (557 | ) |  | $ | 104 |  |

[0001045810-17-000075:notes:106]
Amortization expense associated with intangible assets was $15 million and $17 million for the first quarter of fiscal years 2018 and 2017, respectively. Future amortization expense related to the net carrying amount of intangible assets as of April 30, 2017 is estimated to be $40 million for the remainder of fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $7 million in fiscal year 2021, and $1 million in fiscal year 2022 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-17-000075:notes:107]
|  | April 30, 2017 |  | January 29, 2017 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 1,353 |  |  | $ | 1,353 |  |  | $ | 2,209 |  |  | $ | 2,209 |  |
| Due in 1 - 5 years | 2,853 |  |  | 2,840 |  |  | 3,210 |  |  | 3,194 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 65 |  |  | 65 |  |  | 65 |  |  | 65 |  |
| Total | $ | 4,271 |  |  | $ | 4,258 |  |  | $ | 5,484 |  |  | $ | 5,468 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-17-000075:notes:108]
[same as prior period, unchanged from 0001045810-16-000353:notes:114]

[0001045810-17-000075:notes:109]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income (loss), a component of shareholders’ equity, net of tax, and net realized gains and losses recorded in total other income (expense) on the Condensed Consolidated Statements of Income.

[0001045810-17-000075:notes:110]
We performed an impairment review of our investment portfolio as of April 30, 2017. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of April 30, 2017.

[0001045810-17-000075:notes:111]
The following is a summary of cash equivalents and marketable securities as of April 30, 2017 and January 29, 2017:

[0001045810-17-000075:notes:112]
The following table provides the breakdown of unrealized losses as of April 30, 2017, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-17-000075:notes:113]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 1,390 |  |  | $ | (7 | ) |  | $ | 18 |  |  | $ | — |  |  | $ | 1,408 |  |  | $ | (7 | ) |
| Debt securities issued by United States government agencies | 984 |  |  | (5 | ) |  | 17 |  |  | — |  |  | 1,001 |  |  | (5 | ) |
| Debt securities issued by the United States Treasury | 669 |  |  | (2 | ) |  | — |  |  | — |  |  | 669 |  |  | (2 | ) |
| Asset-backed securities | 355 |  |  | (1 | ) |  | — |  |  | — |  |  | 355 |  |  | (1 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 51 |  |  | — |  |  | 36 |  |  | (1 | ) |  | 87 |  |  | (1 | ) |
|  | $ | 3,449 |  |  | $ | (15 | ) |  | $ | 71 |  |  | $ | (1 | ) |  | $ | 3,520 |  |  | $ | (16 | ) |

[0001045810-17-000075:notes:114]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities as of April 30, 2017 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity. Net realized gains and losses were not significant for the first quarter of fiscal years 2018 and 2017.

[0001045810-17-000075:notes:115]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of April 30, 2017 and January 29, 2017 and are shown below by contractual maturity:


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-17-000075:notes:116]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000075:notes:117]
Recently Adopted Accounting Pronouncement

[0001045810-17-000075:notes:118]
In October 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which requires the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs.  We elected to early adopt this new guidance in the first quarter of fiscal year 2018, which required us to reflect any adjustments as of January 30, 2017. Upon adoption of this guidance, we recorded a cumulative-effect adjustment as of the first day of fiscal year 2018 to decrease retained earnings by $28 million, with a corresponding decrease to prepaid taxes that had not been previously recognized in income tax expense.

[0001045810-17-000075:notes:119]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-17-000075:notes:120]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

[0001045810-17-000075:notes:121]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-17-000075:notes:122]
[same as prior period, unchanged from 0001045810-16-000353:notes:138]

[0001045810-17-000075:notes:123]
[same as prior period, unchanged from 0001045810-16-000353:notes:139]

[0001045810-17-000075:notes:124]
[same as prior period, unchanged from 0001045810-16-000353:notes:140]

[0001045810-17-000075:notes:125]
[same as prior period, unchanged from 0001045810-16-000353:notes:141]

[0001045810-17-000075:notes:126]
The estimated product returns and estimated product warranty liabilities as of April 30, 2017 and January 29, 2017 were as follows:

[0001045810-17-000075:notes:127]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 8 |  |  | $ | 11 |  |
| Additions | — |  |  | 2 |  |
| Deductions | (1 | ) |  | (5 | ) |
| Balance at end of period | $ | 7 |  |  | $ | 8 |  |

[0001045810-17-000075:notes:128]
[same as prior period, unchanged from 0001045810-16-000353:notes:145]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-17-000075:notes:129]
|  | Three Months Ended |
|  | April 30, 2017 |  | May 1, 2016 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |
| Unallocated revenue | $ | 43 |  |  | $ | 66 |  |
| Stock-based compensation expense | (76 | ) |  | (53 | ) |
| Unallocated cost of revenue and operating expenses | (56 | ) |  | (54 | ) |
| Acquisition-related costs | (4 | ) |  | (4 | ) |
| Contributions | (2 | ) |  | (3 | ) |
| Legal settlement costs | — |  |  | (16 | ) |
| Restructuring and other charges | — |  |  | (1 | ) |
| Total | $ | (95 | ) |  | $ | (65 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-17-000075:notes:130]
[same as prior period, unchanged from 0001045810-16-000353:notes:147]

[0001045810-17-000075:notes:131]
In fiscal year 2016, we began the wind-down of our Icera operations. No restructuring charges were recorded during the first quarter of fiscal year 2018.

[0001045810-17-000075:notes:132]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Condensed Consolidated Balance Sheets as of April 30, 2017 and January 29, 2017:

[0001045810-17-000075:notes:133]
|  | April 30, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 13 |  |  | $ | 23 |  |
| Restructuring and other charges | — |  |  | 3 |  |
| Cash payments | (2 | ) |  | (13 | ) |
| Balance at end of period | $ | 11 |  |  | $ | 13 |  |

[0001045810-17-000075:notes:134]
The majority of the remaining balance of $11 million as of April 30, 2017 is expected to be paid during fiscal year 2018.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-17-000075:notes:135]
|  | Three Months Ended |
|  | April 30, |  | May 1, |
|  | 2017 |  | 2016 |
|  | (In millions) |
| Revenue: |  |  |  |
| Taiwan | $ | 602 |  |  | $ | 445 |  |
| Other Asia Pacific | 377 |  |  | 160 |  |
| United States | 353 |  |  | 194 |  |
| China | 330 |  |  | 247 |  |
| Europe | 182 |  |  | 156 |  |
| Other Americas | 93 |  |  | 103 |  |
| Total revenue | $ | 1,937 |  |  | $ | 1,305 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-17-000075:notes:136]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended April 30, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 1,562 |  |  | $ | 332 |  |  | $ | 43 |  |  | $ | 1,937 |  |
| Depreciation and amortization expense | $ | 28 |  |  | $ | 9 |  |  | $ | 10 |  |  | $ | 47 |  |
| Operating income (loss) | $ | 602 |  |  | $ | 47 |  |  | $ | (95 | ) |  | $ | 554 |  |
| Three Months Ended May 1, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,079 |  |  | $ | 160 |  |  | $ | 66 |  |  | $ | 1,305 |  |
| Depreciation and amortization expense | $ | 28 |  |  | $ | 7 |  |  | $ | 10 |  |  | $ | 45 |  |
| Operating income (loss) | $ | 348 |  |  | $ | (38 | ) |  | $ | (65 | ) |  | $ | 245 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-17-000075:notes:137]
[same as prior period, unchanged from 0001045810-16-000353:notes:155]

[0001045810-17-000075:notes:138]
[same as prior period, unchanged from 0001045810-16-000353:notes:156]

[0001045810-17-000075:notes:139]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-17-000075:notes:140]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for mobile gaming and entertainment devices, as well as autonomous robots, drones and cars.

[0001045810-17-000075:notes:141]
[same as prior period, unchanged from 0001045810-16-000353:notes:159]

[0001045810-17-000075:notes:142]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, unallocated cost of revenue and operating expenses, acquisition-related costs, contributions, legal settlement costs, restructuring and other charges, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-17-000075:notes:143]
[same as prior period, unchanged from 0001045810-16-000353:notes:161]

[0001045810-17-000075:notes:144]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-17-000075:notes:145]
[same as prior period, unchanged from 0001045810-16-000353:notes:163]

[0001045810-17-000075:notes:146]
[same as prior period, unchanged from 0001045810-16-000353:notes:166]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-17-000075:notes:147]
[same as prior period, unchanged from 0001045810-16-000353:notes:167]

[0001045810-17-000075:notes:148]
[same as prior period, unchanged from 0001045810-16-000353:notes:168]

[0001045810-17-000075:notes:149]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The first quarter of fiscal years 2018 and 2017 were both 13-week quarters.

[0001045810-17-000075:notes:150]
[same as prior period, unchanged from 0001045810-16-000353:notes:170]

[0001045810-17-000075:notes:151]
[same as prior period, unchanged from 0001045810-16-000353:notes:171]

[0001045810-17-000075:notes:152]
[same as prior period, unchanged from 0001045810-16-000353:notes:172]

[0001045810-17-000075:notes:153]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-17-000075:notes:154]
[same as prior period, unchanged from 0001045810-16-000353:notes:174]

[0001045810-17-000075:notes:155]
[same as prior period, unchanged from 0001045810-16-000353:notes:175]

[0001045810-17-000075:notes:156]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. Through April 30, 2017, we have repurchased an aggregate of 245 million shares under our share repurchase program for a total cost of $4.59 billion. All shares delivered from these repurchases have been placed into treasury stock. As of April 30, 2017, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $2.73 billion through December 2020.

[0001045810-17-000075:notes:157]
During the first quarter of fiscal year 2018, we paid $82 million in cash dividends to our shareholders, equivalent to $0.14 per share.

[0001045810-17-000075:notes:158]
[same as prior period, unchanged from 0001045810-16-000353:notes:181]

[0001045810-17-000075:notes:159]
As of April 30, 2017 and January 29, 2017, there were no shares of preferred stock outstanding.

[0001045810-17-000075:notes:160]
[same as prior period, unchanged from 0001045810-16-000353:notes:183]

[0001045810-17-000075:notes:161]
[same as prior period, unchanged from 0001045810-16-000353:notes:184]
