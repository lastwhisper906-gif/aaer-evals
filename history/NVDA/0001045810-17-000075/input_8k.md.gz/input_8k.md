# NVDA 8-K — 0001045810-17-000068 filed 2017-05-09

## item codes, every 8-K on or before 2017-05-23

- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2017-05-23

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-17-000068:8k_2_02:1]
EX-99.1
2
q1fy18pr.htm
Q1FY18 PRESS RELEASE

[0001045810-17-000068:8k_2_02:2]
Exhibit

[0001045810-17-000068:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-17-000068:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2018

[0001045810-17-000068:8k_2_02:5]
| • | Revenue of $1.94 billion, up 48 percent from a year ago |

[0001045810-17-000068:8k_2_02:6]
| • | GAAP EPS of $0.79, up 126 percent from a year ago |

[0001045810-17-000068:8k_2_02:7]
| • | Non-GAAP EPS of $0.85, up 85 percent from a year ago |

[0001045810-17-000068:8k_2_02:8]
| • | Broad growth across all platforms |

[0001045810-17-000068:8k_2_02:9]
SANTA CLARA, Calif.-May 9, 2017-NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 30, 2017, of $1.94 billion, up 48 percent from $1.30 billion a year earlier, and down 11 percent from $2.17 billion in the previous quarter.

[0001045810-17-000068:8k_2_02:10]
GAAP earnings per diluted share for the quarter were $0.79, up 126 percent from $0.35 a year ago and down 20 percent from $0.99 in the previous quarter. Non-GAAP earnings per diluted share were $0.85, up 85 percent from $0.46 a year earlier and down 25 percent from $1.13 in the previous quarter.

[0001045810-17-000068:8k_2_02:11]
“The AI revolution is moving fast and continuing to accelerate,” said Jensen Huang, founder and chief executive officer of NVIDIA. “NVIDIA’s GPU deep learning platform is the instrument of choice for researchers, internet giants and startups as they invent the future.

[0001045810-17-000068:8k_2_02:12]
“Our Datacenter GPU computing business nearly tripled from last year, as more of the world’s computer scientists engage deep learning. One industry after another is awakening to the power of GPU deep learning and AI, the most important technology force of our time,” he said.

[0001045810-17-000068:8k_2_02:13]
Capital Return

[0001045810-17-000068:8k_2_02:14]
For fiscal 2018, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. During the first quarter of fiscal 2018, NVIDIA paid $82 million in cash dividends.

[0001045810-17-000068:8k_2_02:15]
NVIDIA will pay its next quarterly cash dividend of $0.14 per share on June 14, 2017, to all shareholders of record on May 23, 2017.

[0001045810-17-000068:8k_2_02:16]
Q1 FY2018 Summary

[0001045810-17-000068:8k_2_02:17]
| GAAP |
| ($ in millions except earnings per share) | Q1 FY18 | Q4 FY17 | Q1 FY17 | Q/Q | Y/Y |
| Revenue | $1,937 | $2,173 | $1,305 | down 11% | up 48% |
| Gross margin | 59.4% | 60.0% | 57.5% | down 60 bps | up 190 bps |
| Operating expenses | $596 | $570 | $506 | up 5% | up 18% |
| Operating income | $554 | $733 | $245 | down 24% | up 126% |
| Net income | $507 | $655 | $208 | down 23% | up 144% |
| Diluted earnings per share | $0.79 | $0.99 | $0.35 | down 20% | up 126% |

[0001045810-17-000068:8k_2_02:18]
| Non-GAAP |
| ($ in millions except earnings per share) | Q1 FY18 | Q4 FY17 | Q1 FY17 | Q/Q | Y/Y |
| Revenue | $1,937 | $2,173 | $1,305 | down 11% | up 48% |
| Gross margin | 59.6% | 60.2% | 58.6% | down 60 bps | up 100 bps |
| Operating expenses | $517 | $498 | $443 | up 4% | up 17% |
| Operating income | $637 | $809 | $322 | down 21% | up 98% |
| Net income | $533 | $704 | $263 | down 24% | up 103% |
| Diluted earnings per share | $0.85 | $1.13 | $0.46 | down 25% | up 85% |

[0001045810-17-000068:8k_2_02:19]
NVIDIA’s outlook for the second quarter of fiscal 2018 is as follows:

[0001045810-17-000068:8k_2_02:20]
| • | Revenue is expected to be $1.95 billion, plus or minus two percent. |

[0001045810-17-000068:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 58.4 percent and 58.6 percent, respectively, plus or minus 50 basis points. |

[0001045810-17-000068:8k_2_02:22]
| • | GAAP operating expenses are expected to be approximately $605 million. Non-GAAP operating expenses are expected to be approximately $530 million. |

[0001045810-17-000068:8k_2_02:23]
| • | GAAP other income and expense is expected to be an expense of approximately $8 million, inclusive of additional charges from early conversions of convertible notes. Non-GAAP other income and expense is expected to be an expense of approximately $3 million. |

[0001045810-17-000068:8k_2_02:24]
| • | GAAP and non-GAAP tax rates for the second quarter of fiscal 2018 are both expected to be 17 percent, plus or minus one percent, excluding any discrete items. |

[0001045810-17-000068:8k_2_02:25]
| • | Weighted average shares used in the GAAP and non-GAAP diluted EPS calculations are dependent on the weighted average stock price during the quarter. |

[0001045810-17-000068:8k_2_02:26]
| • | Capital expenditures are expected to be approximately $55 million to $65 million. |

[0001045810-17-000068:8k_2_02:27]
First Quarter Fiscal 2018 Highlights

[0001045810-17-000068:8k_2_02:28]
During the first quarter, NVIDIA achieved broad progress.

[0001045810-17-000068:8k_2_02:29]
Gaming:

[0001045810-17-000068:8k_2_02:30]
| • | Announced GeForce® GTX 1080 Ti, the world’s fastest gaming GPU. |

[0001045810-17-000068:8k_2_02:31]
| • | Announced TITAN Xp for enthusiasts and researchers requiring extreme performance. |

[0001045810-17-000068:8k_2_02:32]
Datacenter:

[0001045810-17-000068:8k_2_02:33]
| • | Announced with Microsoft that it is bringing NVIDIA® Tesla® P100 and P40 GPUs to the Azure cloud. |

[0001045810-17-000068:8k_2_02:34]
| • | Announced that NVIDIA Tesla accelerators designed for datacenter AI capabilities were added to Google Cloud, Tencent Cloud, IBM Cloud, and Baidu Cloud. |

[0001045810-17-000068:8k_2_02:35]
| • | Announced that Tokyo Institute of Technology will use NVIDIA’s accelerated computing platform to create Japan’s fastest AI supercomputer, TSUBAME3.0. |

[0001045810-17-000068:8k_2_02:36]
| • | Announced that Fujitsu is using 24 NVIDIA DGX-1™ AI systems to build a new AI supercomputer for RIKEN, Japan’s largest research center. |

[0001045810-17-000068:8k_2_02:37]
| • | Announced together with Facebook the Caffe2 deep learning framework and Big Basin servers with Tesla P100 GPUs. |

[0001045810-17-000068:8k_2_02:38]
| • | Announced plans to train 100,000 developers this year, a 10x increase over 2016, through the NVIDIA Deep Learning Institute. |

[0001045810-17-000068:8k_2_02:39]
| • | Announced NVIDIA Jetson™ TX2, a high-performance, low-power computer platform for delivering AI at the edge, with deep learning and computer vision capabilities for robots, drones and smart cameras. |

[0001045810-17-000068:8k_2_02:40]
Automotive:

[0001045810-17-000068:8k_2_02:41]
| • | Announced with Bosch, the world’s largest auto supplier, plans to create a new Bosch-branded AI self-driving car computer. |

[0001045810-17-000068:8k_2_02:42]
| • | Announced a collaboration with PACCAR, one of the world's largest truck makers with brands including Peterbilt, Kenworth and DAF, to develop solutions for autonomous trucks. |

[0001045810-17-000068:8k_2_02:43]
CFO Commentary

[0001045810-17-000068:8k_2_02:44]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-17-000068:8k_2_02:45]
Conference Call and Webcast Information

[0001045810-17-000068:8k_2_02:46]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2018 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 4018413. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its second quarter of fiscal 2018.

[0001045810-17-000068:8k_2_02:47]
Non-GAAP Measures

[0001045810-17-000068:8k_2_02:48]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, revenue excluding Intel license,  and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, loss on early debt conversions, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-17-000068:8k_2_02:49]
Keep Current on NVIDIA

[0001045810-17-000068:8k_2_02:50]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-17-000068:8k_2_02:51]
About NVIDIA

[0001045810-17-000068:8k_2_02:52]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-17-000068:8k_2_02:53]
###

[0001045810-17-000068:8k_2_02:54]
For further information, contact:

[0001045810-17-000068:8k_2_02:55]
| Shawn Simmons |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-5784 |  | (408) 566-5150 |
| ssimmons@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-17-000068:8k_2_02:56]
Certain statements in this press release including, but not limited to statements as to: the AI revolution continuing to accelerate; AI being the most important technology force of our time; the company’s intended capital return for fiscal 2018; the company’s next quarterly cash dividend; the company’s financial outlook for the second quarter of fiscal 2018; the company’s tax rates for the second quarter of fiscal 2018; and the impact and benefits of NVIDIA Tesla GPUs, NVIDIA’s accelerated computing platform, NVIDIA DGX-1 AI systems, NVIDIA Jetson TX2, and partnerships with Bosch and PACCAR; and intended training of 100,000 developers this year through the NVIDIA Deep Learning Institute are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-K for the fiscal period ended January 29, 2017. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-17-000068:8k_2_02:57]
© 2017 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Tesla, NVIDIA DGX-1 and Jetson are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-17-000068:8k_2_02:58]
NVIDIA CORPORATION

[0001045810-17-000068:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-17-000068:8k_2_02:60]
(In millions, except per share data)

[0001045810-17-000068:8k_2_02:61]
(Unaudited)

[0001045810-17-000068:8k_2_02:62]
|  | Three Months Ended |
|  | April 30, |  | May 1, |
|  | 2017 |  | 2016 |
| Revenue | $ | 1,937 |  |  | $ | 1,305 |  |
| Cost of revenue | 787 |  |  | 554 |  |
| Gross profit | 1,150 |  |  | 751 |  |
| Operating expenses |  |  |  |
| Research and development | 411 |  |  | 346 |  |
| Sales, general and administrative | 185 |  |  | 159 |  |
| Restructuring and other charges | — |  |  | 1 |  |
| Total operating expenses | 596 |  |  | 506 |  |
| Income from operations | 554 |  |  | 245 |  |
| Interest income | 16 |  |  | 12 |  |
| Interest expense | (16 | ) |  | (12 | ) |
| Other, net | (18 | ) |  | (4 | ) |
| Total other income (expense) | (18 | ) |  | (4 | ) |
| Income before income tax expense | 536 |  |  | 241 |  |
| Income tax expense | 29 |  |  | 33 |  |
| Net income | $ | 507 |  |  | $ | 208 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.86 |  |  | $ | 0.39 |  |
| Diluted | $ | 0.79 |  |  | $ | 0.35 |  |
| Weighted average shares used in per share computation: |  |  |  |
| Basic | 592 |  |  | 537 |  |
| Diluted | 641 |  |  | 599 |  |

[0001045810-17-000068:8k_2_02:63]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | April 30, |  | January 29, |
|  |  |  | 2017 |  | 2017 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 6,206 |  |  | $ | 6,798 |  |
|  | Accounts receivable, net |  | 976 |  |  | 826 |  |
|  | Inventories |  | 821 |  |  | 794 |  |
|  | Prepaid expenses and other current assets |  | 113 |  |  | 118 |  |
|  | Total current assets |  | 8,116 |  |  | 8,536 |  |
| Property and equipment, net |  | 539 |  |  | 521 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 90 |  |  | 104 |  |
| Other assets |  | 47 |  |  | 62 |  |
|  | Total assets |  | $ | 9,410 |  |  | $ | 9,841 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 348 |  |  | $ | 485 |  |
|  | Accrued and other current liabilities |  | 420 |  |  | 507 |  |
|  | Convertible short-term debt |  | 215 |  |  | 796 |  |
|  | Total current liabilities |  | 983 |  |  | 1,788 |  |
| Long-term debt |  | 1,984 |  |  | 1,983 |  |
| Other long-term liabilities |  | 300 |  |  | 271 |  |
| Capital lease obligations, long-term |  | 4 |  |  | 6 |  |
|  | Total liabilities |  | 3,271 |  |  | 4,048 |  |
| Convertible debt conversion obligation |  | 7 |  |  | 31 |  |
| Shareholders' equity |  | 6,132 |  |  | 5,762 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 9,410 |  |  | $ | 9,841 |  |

[0001045810-17-000068:8k_2_02:64]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |
|  |  | April 30, |  | January 29, |  | May 1, |
|  |  | 2017 |  | 2017 |  | 2016 |
| GAAP gross profit |  | $ | 1,150 |  |  | $ | 1,303 |  |  | $ | 751 |  |
| GAAP gross margin |  | 59.4 | % |  | 60.0 | % |  | 57.5 | % |
| Stock-based compensation expense (A) |  | 4 |  |  | 4 |  |  | 4 |  |
| Legal settlement costs |  | — |  |  | — |  |  | 10 |  |
| Non-GAAP gross profit |  | $ | 1,154 |  |  | $ | 1,307 |  |  | $ | 765 |  |
| Non-GAAP gross margin |  | 59.6 | % |  | 60.2 | % |  | 58.6 | % |
| GAAP operating expenses |  | $ | 596 |  |  | $ | 570 |  |  | $ | 506 |  |
| Stock-based compensation expense (A) |  | (73 | ) |  | (68 | ) |  | (49 | ) |
| Legal settlement costs |  | — |  |  | — |  |  | (6 | ) |
| Acquisition-related costs (B) |  | (4 | ) |  | (4 | ) |  | (4 | ) |
| Contributions |  | (2 | ) |  | — |  |  | (3 | ) |
| Restructuring and other charges |  | — |  |  | — |  |  | (1 | ) |
| Non-GAAP operating expenses |  | $ | 517 |  |  | $ | 498 |  |  | $ | 443 |  |
| GAAP income from operations |  | $ | 554 |  |  | $ | 733 |  |  | $ | 245 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 83 |  |  | 76 |  |  | 77 |  |
| Non-GAAP income from operations |  | $ | 637 |  |  | $ | 809 |  |  | $ | 322 |  |
| GAAP other income (expense) |  | $ | (18 | ) |  | $ | (7 | ) |  | $ | (4 | ) |
| Gains from non-affiliated investments |  | — |  |  | (1 | ) |  | (3 | ) |
| Interest expense related to amortization of debt discount |  | 2 |  |  | 4 |  |  | 7 |  |
| Loss on early debt conversions |  | 14 |  |  | 6 |  |  | — |  |
| Non-GAAP other income (expense) |  | $ | (2 | ) |  | $ | 2 |  |  | $ | — |  |
| GAAP net income |  | $ | 507 |  |  | $ | 655 |  |  | $ | 208 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 99 |  |  | 85 |  |  | 81 |  |
| Income tax impact of non-GAAP adjustments |  | (73 | ) |  | (36 | ) |  | (26 | ) |
| Non-GAAP net income |  | $ | 533 |  |  | $ | 704 |  |  | $ | 263 |  |

[0001045810-17-000068:8k_2_02:65]
|  |  | Three Months Ended |
|  |  | April 30, |  | January 29, |  | May 1, |
|  |  | 2017 |  | 2017 |  | 2016 |
| Diluted net income per share |  |  |  |  |  |  |
| GAAP |  | $ | 0.79 |  |  | $ | 0.99 |  |  | $ | 0.35 |  |
| Non-GAAP |  | $ | 0.85 |  |  | $ | 1.13 |  |  | $ | 0.46 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |
| GAAP |  | 641 |  |  | 660 |  |  | 599 |  |
| Anti-dilution impact from note hedge (C) |  | (14 | ) |  | (36 | ) |  | (29 | ) |
| Non-GAAP |  | 627 |  |  | 624 |  |  | 570 |  |
| GAAP revenue |  | $ | 1,937 |  |  | $ | 2,173 |  |  | $ | 1,305 |  |
| Revenue from Intel license |  | (43 | ) |  | (66 | ) |  | (66 | ) |
| Revenue excluding Intel license |  | $ | 1,894 |  |  | $ | 2,107 |  |  | $ | 1,239 |  |
| GAAP net cash provided by operating activities |  | $ | 282 |  |  | $ | 721 |  |  | $ | 318 |  |
| Purchase of property and equipment and intangible assets |  | (53 | ) |  | (52 | ) |  | (55 | ) |
| Free cash flow |  | $ | 229 |  |  | $ | 669 |  |  | $ | 263 |  |

[0001045810-17-000068:8k_2_02:66]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |
|  |  | Three Months Ended |
|  |  | April 30, |  | January 29, |  | May 1, |
|  |  | 2017 |  | 2017 |  | 2016 |
| Cost of revenue |  | $ | 4 |  |  | $ | 4 |  |  | $ | 4 |  |
| Research and development |  | $ | 41 |  |  | $ | 40 |  |  | $ | 29 |  |
| Sales, general and administrative |  | $ | 31 |  |  | $ | 27 |  |  | $ | 20 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-17-000068:8k_2_02:67]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2018 Outlook |
| GAAP gross margin |  | 58.4 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 58.6 | % |
|  |  |  | Q2 FY2018 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 605 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (75 | ) |
| Non-GAAP operating expenses |  | $ | 530 |  |
|  |  |  | Q2 FY2018 Outlook |
|  |  |  | (In millions) |
| GAAP other income (expense) |  | $ | (8 | ) |
|  | Loss on early debt conversions and interest expense related to amortization of debt discount |  | 5 |  |
| Non-GAAP other income (expense) |  | $ | (3 | ) |
