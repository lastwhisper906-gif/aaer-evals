# NVDA notes — 0001045810-21-000131


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-21-000131:notes:1]
[same as prior period, unchanged from 0001045810-21-000064:notes:1]

[0001045810-21-000131:notes:2]
[same as prior period, unchanged from 0001045810-21-000064:notes:2]

[0001045810-21-000131:notes:3]
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock in the form of a stock dividend, or the Stock Split, which was conditioned upon obtaining stockholder approval to increase the number of our authorized shares of common stock from 2 billion to 4 billion. On June 3, 2021, at the 2021 Annual Meeting of Stockholders, our stockholders approved the amendment to our Amended and Restated Certificate of Incorporation to increase the number of authorized shares of common stock to 4 billion. As a result, each stockholder of record at the close of business on June 21, 2021 received a dividend of three additional shares of common stock for every share held on the record date, distributed after the close of trading on July 19, 2021. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the Stock Split.

[0001045810-21-000131:notes:4]
[same as prior period, unchanged from 0001045810-21-000064:notes:3]

[0001045810-21-000131:notes:5]
[same as prior period, unchanged from 0001045810-21-000064:notes:4]

[0001045810-21-000131:notes:6]
[same as prior period, unchanged from 0001045810-21-000064:notes:5]

[0001045810-21-000131:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The second quarters of fiscal years 2022 and 2021 were both 13-week quarters.

[0001045810-21-000131:notes:8]
[same as prior period, unchanged from 0001045810-21-000064:notes:7]

[0001045810-21-000131:notes:9]
[same as prior period, unchanged from 0001045810-21-000064:notes:8]

[0001045810-21-000131:notes:10]
[same as prior period, unchanged from 0001045810-21-000064:notes:9]

[0001045810-21-000131:notes:11]
[same as prior period, unchanged from 0001045810-21-000064:notes:10]

[0001045810-21-000131:notes:12]
[same as prior period, unchanged from 0001045810-21-000064:notes:11]

[0001045810-21-000131:notes:13]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-21-000131:notes:14]
[same as prior period, unchanged from 0001045810-21-000064:notes:13]

[0001045810-21-000131:notes:15]
On September 13, 2020, we entered into a Share Purchase Agreement, or the Purchase Agreement, with Arm Limited, or Arm, and SoftBank Group Capital Limited and SVF Holdco (UK) Limited, or together, SoftBank, for us to acquire, from SoftBank, all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid $2 billion in cash at signing, or the Signing Consideration, and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 177.5 million shares of our common stock, which had an aggregate value of $21.5 billion as of the date of the Purchase Agreement. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial targets are achieved, SoftBank can elect to receive either up to an additional $5 billion in cash or up to an additional 41.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and the expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. We are working through the regulatory process in the United States, the United Kingdom, the European Union, China and other jurisdictions. Although some Arm licensees have expressed concerns or objected to the transaction, and discussions with regulators are taking longer than initially thought, we are confident in the deal rationale and that regulators should recognize the benefits of the acquisition to Arm, its licensees, and the industry. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The Signing Consideration was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement.

[0001045810-21-000131:notes:16]
[same as prior period, unchanged from 0001045810-21-000064:notes:16]

[0001045810-21-000131:notes:17]
[same as prior period, unchanged from 0001045810-21-000064:notes:17]

[0001045810-21-000131:notes:18]
[same as prior period, unchanged from 0001045810-21-000064:notes:18]

[0001045810-21-000131:notes:19]
[same as prior period, unchanged from 0001045810-21-000064:notes:19]

[0001045810-21-000131:notes:20]
|  | Pro Forma |
|  | Three Months Ended |  | Six Months Ended |
|  | July 26, 2020 |  | July 26, 2020 |
|  | (In millions) |
| Revenue | $ | 3,866 |  |  | $ | 7,375 |  |
| Net income | $ | 964 |  |  | $ | 1,883 |  |

[0001045810-21-000131:notes:21]
[same as prior period, unchanged from 0001045810-21-000064:notes:21]

[0001045810-21-000131:notes:22]
The pro forma results reflect the inventory step-up expense of $161 million in the first half of fiscal year 2020 and was excluded from the pro forma results for the second quarter and first half of fiscal year 2021. There were no other material nonrecurring adjustments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-21-000131:notes:23]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2022 and 2035.

[0001045810-21-000131:notes:24]
Future minimum lease payments under our non-cancelable operating leases as of August 1, 2021, are as follows:

[0001045810-21-000131:notes:25]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 (excluding first half of fiscal year 2022) | $ | 81 |  |
| 2023 | 156 |  |
| 2024 | 139 |  |
| 2025 | 119 |  |
| 2026 | 111 |  |
| 2027 and thereafter | 355 |  |
| Total | 961 |  |
| Less imputed interest | 113 |  |
| Present value of net future minimum lease payments | 848 |  |
| Less short-term operating lease liabilities | 132 |  |
| Long-term operating lease liabilities | $ | 716 |  |

[0001045810-21-000131:notes:26]
Operating lease expenses were $42 million and $35 million for the second quarter of fiscal years 2022 and 2021, respectively, and $81 million and $67 million for the first half of fiscal years 2022 and 2021, respectively. Short-term and variable lease expenses for the second quarter and first half of fiscal years 2022 and 2021 were not significant.

[0001045810-21-000131:notes:27]
[same as prior period, unchanged from 0001045810-21-000064:notes:25]

[0001045810-21-000131:notes:28]
|  | Six Months Ended |
|  | August 1, 2021 |  | July 26, 2020 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 75 |  |  | $ | 66 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 164 |  |  | $ | 138 |  |

[0001045810-21-000131:notes:29]
As of August 1, 2021, our operating leases had a weighted average remaining lease term of 7.6 years and a weighted average discount rate of 2.84%. As of January 31, 2021, our operating leases had a weighted average remaining lease term of 7.6 years and a weighted average discount rate of 2.87%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-21-000131:notes:30]
[same as prior period, unchanged from 0001045810-21-000064:notes:28]

[0001045810-21-000131:notes:31]
[same as prior period, unchanged from 0001045810-21-000064:notes:29]

[0001045810-21-000131:notes:32]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1,2021 |  | July 26,2020 |  | August 1,2021 |  | July 26,2020 |
|  | (In millions) |
| Cost of revenue | $ | 32 |  |  | $ | 14 |  |  | $ | 57 |  |  | $ | 35 |  |
| Research and development | 297 |  |  | 228 |  |  | 573 |  |  | 362 |  |
| Sales, general and administrative | 136 |  |  | 132 |  |  | 264 |  |  | 201 |  |
| Total | $ | 465 |  |  | $ | 374 |  |  | $ | 894 |  |  | $ | 598 |  |

[0001045810-21-000131:notes:33]
[same as prior period, unchanged from 0001045810-21-000064:notes:31]

[0001045810-21-000131:notes:34]
[same as prior period, unchanged from 0001045810-21-000064:notes:32]

[0001045810-21-000131:notes:35]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 31, 2021 | 59 |  |  | $ | 66.17 |  |  |  |  |  |
| Granted | 15 |  |  | $ | 181.65 |  |  |  |  |  |
| Vested restricted stock | (17) |  |  | $ | 62.20 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 70.78 |  |  |  |  |  |
| Balances, August 1, 2021 | 56 |  |  | $ | 100.01 |  |  |  |  |  |

[0001045810-21-000131:notes:36]
As of August 1, 2021, there was $5.35 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.7 years for RSUs, PSUs, and market-based PSUs, and 1 year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-21-000131:notes:37]
[same as prior period, unchanged from 0001045810-21-000064:notes:35]

[0001045810-21-000131:notes:38]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, |  | July 26, |  | August 1, |  | July 26, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 2,374 |  |  | $ | 622 |  |  | $ | 4,285 |  |  | $ | 1,539 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,493 |  |  | 2,464 |  |  | 2,489 |  |  | 2,460 |  |
| Dilutive impact of outstanding equity awards | 39 |  |  | 40 |  |  | 40 |  |  | 36 |  |
| Diluted weighted average shares | 2,532 |  |  | 2,504 |  |  | 2,529 |  |  | 2,496 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.95 |  |  | $ | 0.25 |  |  | $ | 1.72 |  |  | $ | 0.63 |  |
| Diluted (2) | $ | 0.94 |  |  | $ | 0.25 |  |  | $ | 1.69 |  |  | $ | 0.62 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 13 |  |  | — |  |  | 15 |  |  | 24 |  |

[0001045810-21-000131:notes:39]
[same as prior period, unchanged from 0001045810-21-000064:notes:37]

[0001045810-21-000131:notes:40]
[same as prior period, unchanged from 0001045810-21-000064:notes:38]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-21-000131:notes:41]
Income Taxes
We recognized an income tax expense of $20 million and $153 million for the second quarter and first half of fiscal year 2022, respectively, and an income tax benefit of $13 million and an income tax expense of $52 million for the second quarter and first half of fiscal year 2021, respectively. The income tax expense as a percentage of income before income tax was 0.9% and 3.4% for the second quarter and first half of fiscal year 2022, respectively, and 3.3% for the first half of fiscal year 2021. The income tax benefit as a percentage of income before income tax was 2.0% for the second quarter of fiscal year 2021.

[0001045810-21-000131:notes:42]
On June 28, 2021, we simplified our corporate structure by repatriating the economic rights of certain non-U.S. intellectual property to the United States via domestication of a foreign subsidiary, or the Domestication. The Domestication more closely aligns our corporate structure to our operating structure in accordance with the Organization for Economic Cooperation and Development’s Base Erosion and Profit Shifting conclusions and changes to U.S. and European tax laws. The impact of the Domestication, which is regarded as a change in tax status, resulted in a discrete benefit primarily from re-valuing certain deferred tax assets, net of deferred tax liabilities, of $252 million in the second quarter of fiscal year 2022.

[0001045810-21-000131:notes:43]
The increase in our effective tax rate for the second quarter and first half of fiscal year 2022 as compared to the same periods of fiscal year 2021 was primarily due to a decreased impact of tax benefits from stock-based compensation and the U.S. federal research tax credit, and an increase in the amount of earnings subject to U.S. tax, partially offset by the discrete benefit of the Domestication.

[0001045810-21-000131:notes:44]
Our effective tax rate for the first half of fiscal year 2021 was lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that is subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-21-000131:notes:45]
Our effective tax rate for the first half of fiscal year 2022 was lower than the U.S. federal statutory rate of 21% due to the discrete benefit of the Domestication, tax benefits related to the foreign-derived intangible income deduction, income

[0001045810-21-000131:notes:46]
earned in jurisdictions that is subject to taxes lower than the U.S. federal statutory tax rate, and tax benefits related to the U.S. federal research tax credit and stock-based compensation.

[0001045810-21-000131:notes:47]
As of August 1, 2021, we intend to indefinitely reinvest approximately $1.6 billion and $231 million of cumulative undistributed earnings held by certain subsidiaries in Israel and the United Kingdom, respectively. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to these investments as the determination of such amount is not practicable.

[0001045810-21-000131:notes:48]
For the first half of fiscal year 2022, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 31, 2021.
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of August 1, 2021, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-21-000131:notes:49]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-21-000131:notes:50]
The following is a summary of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021:

[0001045810-21-000131:notes:51]
|  | August 1, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,610 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 8,611 |  |  | $ | 1,825 |  |  | $ | 6,786 |  |
| Debt securities issued by the United States Treasury | 5,079 |  |  | 1 |  |  | — |  |  | 5,080 |  |  | 1,311 |  |  | 3,769 |  |
| Debt securities issued by United States government agencies | 2,371 |  |  | 1 |  |  | — |  |  | 2,372 |  |  | 60 |  |  | 2,312 |  |
| Money market funds | 2,097 |  |  | — |  |  | — |  |  | 2,097 |  |  | 2,097 |  |  | — |  |
| Certificates of deposit | 962 |  |  | — |  |  | — |  |  | 962 |  |  | 44 |  |  | 918 |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,360 |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | 19,363 |  |  | $ | 5,337 |  |  | $ | 14,026 |  |

[0001045810-21-000131:notes:52]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

[0001045810-21-000131:notes:53]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-21-000131:notes:54]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021 are shown below by contractual maturity.

[0001045810-21-000131:notes:55]
|  | August 1, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,390 |  |  | $ | 17,391 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 1,970 |  |  | 1,972 |  |  | 566 |  |  | 568 |  |
| Total | $ | 19,360 |  |  | $ | 19,363 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-21-000131:notes:56]
Fair Value of Financial Assets and LiabilitiesThe fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-21-000131:notes:57]
|  |  | Fair Value at |
|  | Pricing Category |  | August 1, 2021 |  | January 31, 2021 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 2,097 |  |  | $ | 313 |  |
| Corporate debt securities | Level 2 |  | $ | 8,611 |  |  | $ | 4,444 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 5,080 |  |  | $ | 2,846 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 2,372 |  |  | $ | 2,976 |  |
| Certificates of deposit | Level 2 |  | $ | 962 |  |  | $ | 705 |  |
| Foreign government bonds | Level 2 |  | $ | 241 |  |  | $ | 67 |  |
| Prepaid expenses and other current assets: |  |  |  |  |  |
| Publicly-held equity security (1) | Level 1 |  | $ | 128 |  |  | $ | — |  |
| Other assets: |  |  |  |  |  |
| Investment in non-affiliated entities (2) | Level 3 |  | $ | 147 |  |  | $ | 144 |  |
| Liabilities (3) |  |  |  |  |  |
| 2.20% Notes Due 2021 | Level 2 |  | $ | 1,001 |  |  | $ | 1,011 |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,251 |  |  | $ | — |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,254 |  |  | $ | — |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 1,106 |  |  | $ | 1,124 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,261 |  |  | $ | — |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,640 |  |  | $ | 1,654 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,271 |  |  | $ | — |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 1,152 |  |  | $ | 1,152 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 2,320 |  |  | $ | 2,308 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 603 |  |  | $ | 602 |  |

[0001045810-21-000131:notes:58]
(1)    Investment in a publicly-traded equity security subject to short-term selling restrictions. An unrealized loss on the investment of $6 million was recorded in other income (expense), net in the second quarter of fiscal year 2022 and an unrealized gain of $118 million was recorded in other income (expense), net in the first half of fiscal year 2022.

[0001045810-21-000131:notes:59]
(2)    Investment in private non-affiliated entities is recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of August 1, 2021 has not been significant.
(3)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for additional information


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-21-000131:notes:60]
(2)    Investment in private non-affiliated entities is recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of August 1, 2021 has not been significant.

[0001045810-21-000131:notes:61]
(3)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-21-000131:notes:62]
[same as prior period, unchanged from 0001045810-21-000064:notes:59]

[0001045810-21-000131:notes:63]
|  | August 1, 2021 |  | January 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,277 |  |  | $ | (1,030) |  |  | $ | 2,247 |  |  | $ | 3,280 |  |  | $ | (774) |  |  | $ | 2,506 |  |
| Patents and licensed technology | 709 |  |  | (478) |  |  | 231 |  |  | 706 |  |  | (475) |  |  | 231 |  |
| Total intangible assets | $ | 3,986 |  |  | $ | (1,508) |  |  | $ | 2,478 |  |  | $ | 3,986 |  |  | $ | (1,249) |  |  | $ | 2,737 |  |

[0001045810-21-000131:notes:64]
(1)    As of August 1, 2021, acquisition-related intangible assets include the fair value of a Mellanox in-process research and development, or IPR&D, project of $630 million, which has not yet commenced amortization.

[0001045810-21-000131:notes:65]
Amortization expense associated with intangible assets was $138 million and $275 million for the second quarter and first half of fiscal year 2022, respectively, and $284 million and $291 million for the second quarter and first half of fiscal year 2021, respectively. Future amortization expense related to the net carrying amount of intangible assets, excluding IPR&D, as of August 1, 2021 is estimated to be $275 million for the remainder of fiscal year 2022, $547 million in fiscal year 2023, $424 million in fiscal year 2024, $371 million in fiscal year 2025, $99 million in fiscal year 2026, and $132 million in fiscal year 2027 and thereafter.
There were no changes to the carrying amount of goodwill during the second quarter and first half of fiscal year 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-21-000131:notes:66]
[same as prior period, unchanged from 0001045810-21-000064:notes:63]

[0001045810-21-000131:notes:67]
|  | August 1, |  | January 31, |
|  | 2021 |  | 2021 |
| Inventories: | (In millions) |
| Raw materials | $ | 825 |  |  | $ | 632 |  |
| Work in-process | 553 |  |  | 457 |  |
| Finished goods | 736 |  |  | 737 |  |
| Total inventories | $ | 2,114 |  |  | $ | 1,826 |  |

[0001045810-21-000131:notes:68]
|  | August 1, |  | January 31, |
|  | 2021 |  | 2021 |
| Prepaid expenses and other current assets: | (In millions) |
| Prepaid expenses | $ | 195 |  |  | $ | 142 |  |
| Publicly-held equity security | 128 |  |  | — |  |
| Other | 129 |  |  | 97 |  |
| Total prepaid expenses and other current assets | $ | 452 |  |  | $ | 239 |  |

[0001045810-21-000131:notes:69]
|  | August 1, |  | January 31, |
|  | 2021 |  | 2021 |
| Other assets: | (In millions) |
| Advanced consideration for acquisition | $ | 1,357 |  |  | $ | 1,357 |  |
| Prepaid royalties | 422 |  |  | 440 |  |
| Investment in non-affiliated entities | 147 |  |  | 144 |  |
| Deposits | 77 |  |  | 136 |  |
| Other | 47 |  |  | 67 |  |
| Total other assets | $ | 2,050 |  |  | $ | 2,144 |  |

[0001045810-21-000131:notes:70]
|  | August 1, |  | January 31, |
|  | 2021 |  | 2021 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 745 |  |  | $ | 630 |  |
| Accrued payroll and related expenses | 387 |  |  | 297 |  |
| Deferred revenue (1) | 301 |  |  | 288 |  |
| Operating leases | 132 |  |  | 121 |  |
| Licenses and royalties | 102 |  |  | 128 |  |
| Coupon interest on debt obligations | 81 |  |  | 74 |  |
| Taxes payable | 64 |  |  | 61 |  |
| Product warranty and return provisions | 45 |  |  | 39 |  |
| Professional service fees | 32 |  |  | 26 |  |
| Other | 85 |  |  | 61 |  |
| Total accrued and other current liabilities | $ | 1,974 |  |  | $ | 1,725 |  |

[0001045810-21-000131:notes:71]
[same as prior period, unchanged from 0001045810-21-000064:notes:68]

[0001045810-21-000131:notes:72]
|  | August 1, |  | January 31, |
|  | 2021 |  | 2021 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 897 |  |  | $ | 836 |  |
| Deferred income tax | 229 |  |  | 241 |  |
| Deferred revenue (2) | 189 |  |  | 163 |  |
| Employee benefits | 37 |  |  | 33 |  |
| Licenses payable | 33 |  |  | 56 |  |
| Other | 11 |  |  | 46 |  |
| Total other long-term liabilities | $ | 1,396 |  |  | $ | 1,375 |  |

[0001045810-21-000131:notes:73]
(1)    As of August 1, 2021, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, unrecognized tax benefits of $435 million, related interest and penalties of $52 million, and other foreign long-term tax payable of $159 million.

[0001045810-21-000131:notes:74]
[same as prior period, unchanged from 0001045810-21-000064:notes:71]

[0001045810-21-000131:notes:75]
[same as prior period, unchanged from 0001045810-21-000064:notes:72]

[0001045810-21-000131:notes:76]
The following table shows the changes in deferred revenue during the first half of fiscal years 2022 and 2021:

[0001045810-21-000131:notes:77]
|  | August 1, |  | July 26, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Balance at beginning of period | $ | 451 |  |  | $ | 201 |  |
| Deferred revenue added during the period | 401 |  |  | 213 |  |
| Addition due to business combinations | — |  |  | 75 |  |
| Revenue recognized during the period | (362) |  |  | (147) |  |
| Balance at end of period | $ | 490 |  |  | $ | 342 |  |

[0001045810-21-000131:notes:78]
Revenue related to remaining performance obligations represents the remaining contracted license, development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of August 1, 2021, the amount of our remaining performance obligations that has not been recognized as revenue was $646 million, of which we expect to recognize approximately 50% as revenue over the next 12 months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-21-000131:notes:79]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of August 1, 2021 and January 31, 2021.

[0001045810-21-000131:notes:80]
[same as prior period, unchanged from 0001045810-21-000064:notes:77]

[0001045810-21-000131:notes:81]
The table below presents the notional value of our foreign currency forward contracts outstanding as of August 1, 2021 and January 31, 2021:

[0001045810-21-000131:notes:82]
|  | August 1,2021 |  | January 31,2021 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 902 |  |  | $ | 840 |  |
| Not designated for hedge accounting | $ | 423 |  |  | $ | 441 |  |

[0001045810-21-000131:notes:83]
As of August 1, 2021, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next 12 months was not significant.

[0001045810-21-000131:notes:84]
During the first half of fiscal years 2022 and 2021, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-21-000131:notes:85]
Debt
Long-Term Debt

[0001045810-21-000131:notes:86]
In June 2021, we issued $1.25 billion of the 0.309% Notes Due 2023, $1.25 billion of the 0.584% Notes Due 2024, $1.25 billion of the 1.55% Notes Due 2028, and $1.25 billion of the 2.00% Notes Due 2031, or collectively, the June 2021 Notes. Interest on the 0.584% Notes Due 2024 is payable on June 14 and December 14 of each year, beginning on December 14, 2021. Interest on all other series of the June 2021 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2021. We may redeem the June 2021 Notes for cash prior to maturity, upon at least 10 but no more than 60 days prior notice, at redemption prices that include accrued and unpaid interest and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2023 on or after June 15, 2022, the Notes Due 2024 on or after June 14, 2023, the Notes Due 2028 on or after April 15, 2028, or the Notes Due 2031 on or after March 15, 2031.  The net proceeds from the June 2021 Notes were $4.98 billion, after deducting debt discount and issuance costs.

[0001045810-21-000131:notes:87]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year.

[0001045810-21-000131:notes:88]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021.

[0001045810-21-000131:notes:89]
The September 2016 Notes, the March 2020 Notes, and the June 2021 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-21-000131:notes:90]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-21-000131:notes:91]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | August 1, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.9 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.9 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 5.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.9 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.9 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (57) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 11,943 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,943 |  |  | $ | 5,964 |  |

[0001045810-21-000131:notes:92]
As of August 1, 2021, we were in compliance with the required covenants under the Notes.

[0001045810-21-000131:notes:93]
Credit Facilities

[0001045810-21-000131:notes:94]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of August 1, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.

[0001045810-21-000131:notes:95]
We have a $575 million commercial paper program to support general corporate purposes. As of August 1, 2021, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-21-000131:notes:96]
Commitments and Contingencies
Purchase Obligations

[0001045810-21-000131:notes:97]
As of August 1, 2021, we had outstanding inventory purchase and long-term supply commitment obligations totaling $4.79 billion, of which $4.59 billion is expected to occur over the next 12 months and the remaining balance over 36 months. Other purchase obligations totaling $565 million are primarily expected to occur over the next 18 months.

[0001045810-21-000131:notes:98]
Accrual for Product Warranty Liabilities

[0001045810-21-000131:notes:99]
The estimated amount of product warranty liabilities was $31 million and $22 million as of August 1, 2021 and January 31, 2021, respectively, and the activities related to the warranty liabilities were not significant.

[0001045810-21-000131:notes:100]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-21-000131:notes:101]
Litigation

[0001045810-21-000131:notes:102]
Securities Class Action and Derivative Lawsuits

[0001045810-21-000131:notes:103]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On August 11, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.

[0001045810-21-000131:notes:104]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-21-000131:notes:105]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of

[0001045810-21-000131:notes:106]
cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-21-000131:notes:107]
Accounting for Loss Contingencies

[0001045810-21-000131:notes:108]
As of August 1, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-21-000131:notes:109]
[same as prior period, unchanged from 0001045810-21-000064:notes:105]

[0001045810-21-000131:notes:110]
[same as prior period, unchanged from 0001045810-21-000064:notes:106]

[0001045810-21-000131:notes:111]
Through August 1, 2021, we have repurchased an aggregate of 1.04 billion shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of August 1, 2021, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-21-000131:notes:112]
During the second quarter and first half of fiscal year 2022, we paid $100 million and $198 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-21-000131:notes:113]
[same as prior period, unchanged from 0001045810-21-000064:notes:109]

[0001045810-21-000131:notes:114]
[same as prior period, unchanged from 0001045810-21-000064:notes:110]

[0001045810-21-000131:notes:115]
[same as prior period, unchanged from 0001045810-21-000064:notes:111]

[0001045810-21-000131:notes:116]
[same as prior period, unchanged from 0001045810-21-000064:notes:112]

[0001045810-21-000131:notes:117]
[same as prior period, unchanged from 0001045810-21-000064:notes:113]

[0001045810-21-000131:notes:118]
[same as prior period, unchanged from 0001045810-21-000064:notes:114]

[0001045810-21-000131:notes:119]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended August 1, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 3,907 |  |  | $ | 2,600 |  |  | $ | — |  |  | $ | 6,507 |  |
| Operating income (loss) | $ | 2,127 |  |  | $ | 1,034 |  |  | $ | (717) |  |  | $ | 2,444 |  |
| Three Months Ended July 26, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 2,085 |  |  | $ | 1,781 |  |  | $ | — |  |  | $ | 3,866 |  |
| Operating income (loss) | $ | 911 |  |  | $ | 691 |  |  | $ | (951) |  |  | $ | 651 |  |
| Six Months Ended August 1, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 7,358 |  |  | $ | 4,810 |  |  | $ | — |  |  | $ | 12,168 |  |
| Operating income (loss) | $ | 3,913 |  |  | $ | 1,895 |  |  | $ | (1,408) |  |  | $ | 4,400 |  |
| Six Months Ended July 26, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 3,991 |  |  | $ | 2,955 |  |  | $ | — |  |  | $ | 6,946 |  |
| Operating income (loss) | $ | 1,747 |  |  | $ | 1,142 |  |  | $ | (1,262) |  |  | $ | 1,627 |  |

[0001045810-21-000131:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1,2021 |  | July 26,2020 |  | August 1,2021 |  | July 26,2020 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (465) |  |  | $ | (374) |  |  | $ | (894) |  |  | $ | (598) |  |
| Acquisition-related and other costs | (158) |  |  | (474) |  |  | (325) |  |  | (479) |  |
| Unallocated cost of revenue and operating expenses | (90) |  |  | (86) |  |  | (180) |  |  | (168) |  |
| IP-related costs | (4) |  |  | (17) |  |  | (9) |  |  | (17) |  |
| Total | $ | (717) |  |  | $ | (951) |  |  | $ | (1,408) |  |  | $ | (1,262) |  |

[0001045810-21-000131:notes:121]
[same as prior period, unchanged from 0001045810-21-000064:notes:117]

[0001045810-21-000131:notes:122]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, |  | July 26, |  | August 1, |  | July 26, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 1,961 |  |  | $ | 954 |  |  | $ | 3,745 |  |  | $ | 1,766 |  |
| China (including Hong Kong) | 1,720 |  |  | 855 |  |  | 3,111 |  |  | 1,614 |  |
| Other Asia Pacific | 1,047 |  |  | 698 |  |  | 2,048 |  |  | 1,305 |  |
| United States | 996 |  |  | 944 |  |  | 1,764 |  |  | 1,441 |  |
| Europe | 429 |  |  | 240 |  |  | 810 |  |  | 494 |  |
| Other countries | 354 |  |  | 175 |  |  | 690 |  |  | 326 |  |
| Total revenue | $ | 6,507 |  |  | $ | 3,866 |  |  | $ | 12,168 |  |  | $ | 6,946 |  |

[0001045810-21-000131:notes:123]
[same as prior period, unchanged from 0001045810-21-000064:notes:119]

[0001045810-21-000131:notes:124]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, |  | July 26, |  | August 1, |  | July 26, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 3,061 |  |  | $ | 1,654 |  |  | $ | 5,821 |  |  | $ | 2,993 |  |
| Data Center | 2,366 |  |  | 1,752 |  |  | 4,414 |  |  | 2,893 |  |
| Professional Visualization | 519 |  |  | 203 |  |  | 891 |  |  | 510 |  |
| Automotive | 152 |  |  | 111 |  |  | 306 |  |  | 266 |  |
| OEM and Other | 409 |  |  | 146 |  |  | 736 |  |  | 284 |  |
| Total revenue | $ | 6,507 |  |  | $ | 3,866 |  |  | $ | 12,168 |  |  | $ | 6,946 |  |

[0001045810-21-000131:notes:125]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal years 2022 or 2021.

[0001045810-21-000131:notes:126]
One customer represented 13% and 16% of our accounts receivable balance as of August 1, 2021 and January 31, 2021, respectively.
