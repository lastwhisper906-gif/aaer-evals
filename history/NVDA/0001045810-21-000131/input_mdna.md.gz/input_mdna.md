# NVDA MD&A — 0001045810-21-000131


## mdna

[0001045810-21-000131:mdna:1]
[same as prior period, unchanged from 0001045810-21-000064:mdna:1]

[0001045810-21-000131:mdna:2]
[same as prior period, unchanged from 0001045810-21-000064:mdna:2]

[0001045810-21-000131:mdna:3]
[same as prior period, unchanged from 0001045810-21-000064:mdna:3]

[0001045810-21-000131:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, Mellanox, NVIDIA Base Command, NVIDIA DRIVE, NVIDIA Fleet Command, NVIDIA Omniverse, NVIDIA RTX, Quadro, Quadro RTX and Tensor RT are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000131:mdna:5]
[same as prior period, unchanged from 0001045810-21-000064:mdna:5]

[0001045810-21-000131:mdna:6]
[same as prior period, unchanged from 0001045810-21-000064:mdna:6]

[0001045810-21-000131:mdna:7]
[same as prior period, unchanged from 0001045810-21-000064:mdna:7]

[0001045810-21-000131:mdna:8]
[same as prior period, unchanged from 0001045810-21-000064:mdna:8]

[0001045810-21-000131:mdna:9]
[same as prior period, unchanged from 0001045810-21-000064:mdna:9]

[0001045810-21-000131:mdna:10]
[same as prior period, unchanged from 0001045810-21-000064:mdna:10]

[0001045810-21-000131:mdna:11]
[same as prior period, unchanged from 0001045810-21-000064:mdna:11]

[0001045810-21-000131:mdna:12]
[same as prior period, unchanged from 0001045810-21-000064:mdna:12]

[0001045810-21-000131:mdna:13]
On September 13, 2020, we entered into a Purchase Agreement with Arm and SoftBank for us to acquire, from SoftBank, all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid the Signing Consideration and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 177.5 million shares of our

[0001045810-21-000131:mdna:14]
[same as prior period, unchanged from 0001045810-21-000064:mdna:23]

[0001045810-21-000131:mdna:15]
common stock, which had an aggregate value of $21.5 billion as of the date of the Purchase Agreement. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial performance targets are achieved, Softbank can elect to receive either up to an additional $5 billion in cash or up to an additional 41.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and the expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. We are working through the regulatory process in the United States, the United Kingdom, the European Union, China and other jurisdictions. Although some Arm licensees have expressed concerns or objected to the transaction, and discussions with regulators are taking longer than initially thought, we are confident in the deal rationale and that regulators should recognize the benefits of the acquisition to Arm, its licensees, and the industry. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The Signing Consideration was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement.

[0001045810-21-000131:mdna:16]
[same as prior period, unchanged from 0001045810-21-000064:mdna:15]

[0001045810-21-000131:mdna:17]
Demand for our products is based on many factors, including our product introductions and transitions, competitor announcements, and competing technologies, all of which can impact the timing and amount of our revenue. For example, our GPUs for gaming are capable of digital currency mining. Demand and use of GPUs for cryptocurrency has fluctuated in the past and is likely to continue to change quickly. Volatility in the cryptocurrency market, including changes in the prices of cryptocurrencies, can impact demand for our products and our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the pending Ethereum 2.0 standard may also create increased aftermarket resales of our GPUs, impact retail prices for our GPUs, increase returns of our products in the distribution channel, and may reduce demand for our new GPUs. Government cryptocurrency policies and regulations may also impact the demand for our products. We have introduced Low Hash Rate, or LHR, GeForce GPUs with limited Ethereum mining capability and increased the supply of CMP in an effort to direct GeForce to gamers and CMP to miners. During the second quarter of fiscal year 2022, over 80% of our Ampere architecture-based GeForce GPU shipments in the quarter were LHR GPUs. Additionally, consumer behavior during the COVID-19 pandemic has made it more difficult for us to estimate future demand, and these challenges may be more pronounced or volatile in the future on both a global and regional basis if and when the effects of the pandemic subside. In estimating demand and evaluating trends, we make multiple assumptions, any of which may prove to be incorrect.

[0001045810-21-000131:mdna:18]
[same as prior period, unchanged from 0001045810-21-000064:mdna:17]

[0001045810-21-000131:mdna:19]
Our products are manufactured based on estimates of customers’ future demand and our manufacturing lead times are very long. We sell many of our products through a channel model, and our channel customers sell to retailers, distributors, and/or end customers. As a result, the decisions made by our channel partners, retailers, and distributors in response to changing market conditions and the changing demand for our products could impact our financial results. To have shorter shipment lead times and quicker delivery schedules for our customers, we may build inventory for anticipated periods of growth which do not occur, may build inventory anticipating demand that does not materialize, or may build inventory to serve what we believe is pent-up demand. We may remain supply-constrained beyond the end of the second half of fiscal year 2022. We have placed non-cancellable inventory orders for certain products in advance of our normal lead times, paid premiums and provided deposits to secure normal and incremental future supply and capacity and may need to continue to do so in the future.

[0001045810-21-000131:mdna:20]
[same as prior period, unchanged from 0001045810-21-000064:mdna:19]

[0001045810-21-000131:mdna:21]
[same as prior period, unchanged from 0001045810-21-000064:mdna:20]

[0001045810-21-000131:mdna:22]
The COVID-19 pandemic continues to evolve and affect our business and financial results. During the second quarter of fiscal 2022, our Gaming and Data Center market platforms have benefited from stronger demand as people continue to work, learn, and play from home. As our own offices begin to reopen, we expect to incur incremental expenses as we resume onsite services and related in-office costs.

[0001045810-21-000131:mdna:23]
25

[0001045810-21-000131:mdna:24]
[same as prior period, unchanged from 0001045810-21-000064:mdna:22]

[0001045810-21-000131:mdna:25]
[same as prior period, unchanged from 0001045810-21-000064:mdna:24]

[0001045810-21-000131:mdna:26]
Second Quarter of Fiscal Year 2022 Summary

[0001045810-21-000131:mdna:27]
|  | Three Months Ended |  |  |  |  |
|  | August 1, 2021 |  | May 2, 2021 |  | July 26, 2020 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 6,507 |  |  | $ | 5,661 |  |  | $ | 3,866 |  |  | 15 | % |  | 68 | % |
| Gross margin | 64.8 | % |  | 64.1 | % |  | 58.8 | % |  | 70 bps |  | 600 bps |
| Operating expenses | $ | 1,771 |  |  | $ | 1,673 |  |  | $ | 1,624 |  |  | 6 | % |  | 9 | % |
| Income from operations | $ | 2,444 |  |  | $ | 1,956 |  |  | $ | 651 |  |  | 25 | % |  | 275 | % |
| Net income | $ | 2,374 |  |  | $ | 1,912 |  |  | $ | 622 |  |  | 24 | % |  | 282 | % |
| Net income per diluted share | $ | 0.94 |  |  | $ | 0.76 |  |  | $ | 0.25 |  |  | 24 | % |  | 276 | % |

[0001045810-21-000131:mdna:28]
[same as prior period, unchanged from 0001045810-21-000064:mdna:27]

[0001045810-21-000131:mdna:29]
Revenue for the second quarter of fiscal year 2022 was $6.51 billion, up 68% from a year earlier.

[0001045810-21-000131:mdna:30]
Gaming revenue was up 85% from a year ago and up 11% sequentially, reflecting higher sales in GeForce GPUs and game-console SOCs. We continued to benefit from strong sales of our GeForce RTX 30 Series based on the NVIDIA Ampere architecture. We have introduced LHR GeForce GPUs with limited Ethereum mining capability and increased the supply of CMP in an effort to direct GeForce to gamers and CMP to miners. Over 80% of our Ampere architecture-based GeForce GPU shipments in the quarter were LHR GPUs. CMP is included in OEM.

[0001045810-21-000131:mdna:31]
Data Center revenue was up 35% from a year ago and up 16% sequentially. The year-on-year growth was led by the ramp of NVIDIA Ampere architecture products into vertical industries and hyperscale customers, including strong growth in inference. Sequentially, growth stemmed from both compute and networking products, led by hyperscale customers.

[0001045810-21-000131:mdna:32]
Professional Visualization revenue was up 156% from a year earlier and up 40% sequentially, driven by the ramp of NVIDIA Ampere architecture GPUs, with growth led by desktop workstation GPUs.

[0001045810-21-000131:mdna:33]
Automotive revenue was up 37% from a year earlier and down 1% sequentially.  The year-on-year increase was due to the recovery in automotive demand which was impacted by the pandemic in the prior year.

[0001045810-21-000131:mdna:34]
OEM and Other revenue was up 180% from a year ago and up 25% sequentially, primarily reflecting growth in CMP, which generated revenue of $266 million.

[0001045810-21-000131:mdna:35]
GAAP gross margin for the second quarter was up 600 basis points from a year earlier, primarily due to a non-recurring inventory step-up expense of $161 million related to the Mellanox acquisition in the second quarter of fiscal year 2021. GAAP gross margin was up 70 basis points sequentially.

[0001045810-21-000131:mdna:36]
Operating expenses for the second quarter were up 9% from a year earlier and up 6% sequentially. The year-on-year and sequential increases were primarily driven by compensation-related costs largely relating to employee growth. The year-on-year increase also reflects growth of infrastructure costs.

[0001045810-21-000131:mdna:37]
26

[0001045810-21-000131:mdna:38]
Income from operations was $2.44 billion, up 275% from a year earlier and up 25% sequentially. Net income was $2.37 billion. Net income per diluted share was $0.94, up 276% from a year earlier and up 24% sequentially.

[0001045810-21-000131:mdna:39]
Cash, cash equivalents and marketable securities were $19.65 billion, up from $10.98 billion a year earlier and up from $12.67 billion in the prior quarter. The year-on-year and sequential increases reflect $5 billion of debt issuance proceeds and operating cash flow generation.

[0001045810-21-000131:mdna:40]
We paid $100 million in quarterly cash dividends in the second quarter.

[0001045810-21-000131:mdna:41]
[same as prior period, unchanged from 0001045810-21-000064:mdna:40]

[0001045810-21-000131:mdna:42]
During the second quarter of fiscal year 2022, in our Gaming platform, we introduced GeForce RTX 3080 Ti and GeForce RTX 3070 Ti; announced that NVIDIA RTX is featured in 130+ games and applications; announced that NVIDIA Reflex is supported in 20 games, including top e-sports titles; and announced that GeForce NOW gives members access to more than 1,000 PC games.

[0001045810-21-000131:mdna:43]
In our Data Center platform, we unveiled NVIDIA Base Command and Fleet Command; established the AI LaunchPad hybrid-cloud partner program to offer enterprises instant access to NVIDIA AI infrastructure and software; and announced that NVIDIA technology supports 342 supercomputers on the latest TOP500 list, including 70% of all new systems and 8 of the top 10, and powers 35 of the top 40 greenest systems.

[0001045810-21-000131:mdna:44]
In our Professional Visualization platform, we expanded NVIDIA Omniverse through new integrations with Blender and Adobe, and launched the NVIDIA RTX A2000.

[0001045810-21-000131:mdna:45]
In our Automotive platform, we announced design wins with robotaxi startup AutoX and autonomous trucking platform startup Embark, and collaborated with autonomous trucking company Plus on plans to provide Amazon with at least 1,000 self-driving systems, which are powered by NVIDIA DRIVE.

[0001045810-21-000131:mdna:46]
[same as prior period, unchanged from 0001045810-21-000064:mdna:45]

[0001045810-21-000131:mdna:47]
[same as prior period, unchanged from 0001045810-21-000064:mdna:46]

[0001045810-21-000131:mdna:48]
[same as prior period, unchanged from 0001045810-21-000064:mdna:47]

[0001045810-21-000131:mdna:49]
[same as prior period, unchanged from 0001045810-21-000064:mdna:48]

[0001045810-21-000131:mdna:50]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1,2021 |  | July 26,2020 |  | August 1,2021 |  | July 26,2020 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 35.2 |  |  | 41.2 |  |  | 35.5 |  |  | 38.4 |  |
| Gross profit | 64.8 |  |  | 58.8 |  |  | 64.5 |  |  | 61.6 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 19.1 |  |  | 25.8 |  |  | 19.7 |  |  | 24.9 |  |
| Sales, general and administrative | 8.1 |  |  | 16.2 |  |  | 8.6 |  |  | 13.3 |  |
| Total operating expenses | 27.2 |  |  | 42.0 |  |  | 28.3 |  |  | 38.2 |  |
| Income from operations | 37.6 |  |  | 16.8 |  |  | 36.2 |  |  | 23.4 |  |
| Interest income | 0.1 |  |  | 0.3 |  |  | 0.1 |  |  | 0.6 |  |
| Interest expense | (0.9) |  |  | (1.4) |  |  | (0.9) |  |  | (1.1) |  |
| Other, net | 0.1 |  |  | — |  |  | 1.1 |  |  | — |  |
| Other income (expense), net | (0.7) |  |  | (1.1) |  |  | 0.3 |  |  | (0.5) |  |
| Income before income tax | 36.9 |  |  | 15.7 |  |  | 36.5 |  |  | 22.9 |  |
| Income tax expense (benefit) | 0.3 |  |  | (0.3) |  |  | 1.3 |  |  | 0.7 |  |
| Net income | 36.6 | % |  | 16.0 | % |  | 35.2 | % |  | 22.2 | % |

[0001045810-21-000131:mdna:51]
[same as prior period, unchanged from 0001045810-21-000064:mdna:50]

[0001045810-21-000131:mdna:52]
[same as prior period, unchanged from 0001045810-21-000064:mdna:51]

[0001045810-21-000131:mdna:53]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1,2021 |  | July 26,2020 |  | $Change |  | %Change |  | August 1,2021 |  | July 26,2020 |  | $Change |  | %Change |
|  | ($ in millions) |
| Graphics | $ | 3,907 |  |  | $ | 2,085 |  |  | $ | 1,822 |  |  | 87 | % |  | $ | 7,358 |  |  | $ | 3,991 |  |  | $ | 3,367 |  |  | 84 | % |
| Compute & Networking | 2,600 |  |  | 1,781 |  |  | 819 |  |  | 46 | % |  | 4,810 |  |  | 2,955 |  |  | 1,855 |  |  | 63 | % |
| Total | $ | 6,507 |  |  | $ | 3,866 |  |  | $ | 2,641 |  |  | 68 | % |  | $ | 12,168 |  |  | $ | 6,946 |  |  | $ | 5,222 |  |  | 75 | % |

[0001045810-21-000131:mdna:54]
Graphics - Graphics segment revenue increased 87% in the second quarter of fiscal year 2022 compared to the second quarter of fiscal year 2021 and 84% in the first half of fiscal year 2022 compared to the first half of fiscal year 2021, reflecting growth in GeForce GPUs which benefited from the introduction of new products of our GeForce RTX 30 Series for both desktop and laptops based on the NVIDIA Ampere architecture. Additionally, revenue increased from higher sales of NVIDIA RTX workstations and game console SOCs.

[0001045810-21-000131:mdna:55]
Compute & Networking - Compute & Networking segment revenue increased 46% for the second quarter of fiscal year 2022 compared to the second quarter of fiscal year 2021 and 63% in the first half of fiscal year 2022 compared to the first half of fiscal year 2021. Revenue increased due to the ramp of NVIDIA Ampere GPU architecture products into vertical industries and hyperscale customers, including growth in inference. The addition of CMP products for cryptocurrency mining also drove revenue growth. The increase in the first half of fiscal year 2022 also reflects the addition of Mellanox, which we acquired on April 27, 2020.

[0001045810-21-000131:mdna:56]
28

[0001045810-21-000131:mdna:57]
[same as prior period, unchanged from 0001045810-21-000064:mdna:55]

[0001045810-21-000131:mdna:58]
Revenue from sales to customers outside of the United States accounted for 85% and 86% of total revenue for the second quarter and first half of fiscal year 2022, respectively, and 76% and 79% of total revenue for the second quarter and first half of fiscal year 2021, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-21-000131:mdna:59]
No customer represented 10% or more of total revenue for the second quarter and first half of fiscal years 2022 or 2021.

[0001045810-21-000131:mdna:60]
[same as prior period, unchanged from 0001045810-21-000064:mdna:58]

[0001045810-21-000131:mdna:61]
Our overall gross margin increased to 64.8% and 64.5% for the second quarter and first half of fiscal year 2022, respectively, from 58.8% and 61.6% for the second quarter and first half of fiscal year 2021, respectively. These increases are primarily due to the absence of a non-recurring inventory step-up expense of $161 million related to the Mellanox acquisition and higher ASPs within desktop GeForce GPUs with continued growth in high-end Ampere architecture products, partially offset by a mix shift within the Compute & Networking segment.

[0001045810-21-000131:mdna:62]
Inventory provisions totaled $73 million and $45 million for the second quarter of fiscal years 2022 and 2021, respectively. Sales of inventory that was previously written-off or -down totaled $20 million and $49 million for the second quarter of fiscal years 2022 and 2021, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.8% and insignificant in the second quarter of fiscal years 2022 and 2021, respectively.

[0001045810-21-000131:mdna:63]
Inventory provisions totaled $131 million and $81 million for the first half of fiscal years 2022 and 2021, respectively. Sales of inventory that was previously written-off or -down totaled $41 million and $88 million for the first half of fiscal years 2022 and 2021, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.7% and insignificant in the first half of fiscal years 2022 and 2021, respectively.

[0001045810-21-000131:mdna:64]
[same as prior period, unchanged from 0001045810-21-000064:mdna:61]

[0001045810-21-000131:mdna:65]
Graphics - The gross margin of our Graphics segment increased during the second quarter and first half of fiscal year 2022 compared to the second quarter and first half of fiscal year 2021, primarily driven by higher ASPs within desktop GeForce GPUs with continued growth in high-end Ampere architecture products.

[0001045810-21-000131:mdna:66]
Compute & Networking - The gross margin of our Compute & Networking segment decreased during the second quarter and first half of fiscal year 2022 compared to the second quarter and first half of fiscal year 2021, primarily driven by a shift in product mix.

[0001045810-21-000131:mdna:67]
[same as prior period, unchanged from 0001045810-21-000064:mdna:64]

[0001045810-21-000131:mdna:68]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1,2021 |  | July 26,2020 |  | $Change |  | %Change |  | August 1,2021 |  | July 26,2020 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 1,245 |  |  | $ | 997 |  |  | $ | 248 |  |  | 25 | % |  | $ | 2,398 |  |  | $ | 1,732 |  |  | $ | 666 |  |  | 38 | % |
| % of net revenue | 19 | % |  | 26 | % |  |  |  |  |  | 20 | % |  | 25 | % |  |  |  |  |
| Sales, general and administrative expenses | 526 |  |  | 627 |  |  | (101) |  |  | (16) | % |  | 1,046 |  |  | 920 |  |  | 126 |  |  | 14 | % |
| % of net revenue | 8 | % |  | 16 | % |  |  |  |  |  | 9 | % |  | 13 | % |  |  |  |  |
| Total operating expenses | $ | 1,771 |  |  | $ | 1,624 |  |  | $ | 147 |  |  | 9 | % |  | $ | 3,444 |  |  | $ | 2,652 |  |  | $ | 792 |  |  | 30 | % |

[0001045810-21-000131:mdna:69]
[same as prior period, unchanged from 0001045810-21-000064:mdna:66]

[0001045810-21-000131:mdna:70]
Research and development expenses increased by 25% during the second quarter of fiscal year 2022 compared to the second quarter of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation and infrastructure costs.

[0001045810-21-000131:mdna:71]
Research and development expenses increased by 38% during the first half of fiscal year 2022 compared to the first half of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation and infrastructure costs, and the acquisition of Mellanox.

[0001045810-21-000131:mdna:72]
[same as prior period, unchanged from 0001045810-21-000064:mdna:68]

[0001045810-21-000131:mdna:73]
Sales, general and administrative expenses decreased by 16% during the second quarter of fiscal year 2022 compared to the second quarter of fiscal year 2021, primarily driven by lower amortization of intangible assets, partially offset by the impact of employee additions and higher employee compensation, including stock-based compensation, and costs related to the pending acquisition of Arm.

[0001045810-21-000131:mdna:74]
Sales, general and administrative expenses increased by 14% during the first half of fiscal year 2022 compared to the first half of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation, the acquisition of Mellanox, and costs related to the pending acquisition of Arm, partially offset by lower amortization of intangible assets.

[0001045810-21-000131:mdna:75]
[same as prior period, unchanged from 0001045810-21-000064:mdna:70]

[0001045810-21-000131:mdna:76]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $6 million and $13 million during the second quarter of fiscal years 2022 and 2021, respectively, and $13 million and $44 million during the first half of fiscal years 2022 and 2021, respectively. The decrease in interest income was primarily due to lower interest rates earned on our investments.

[0001045810-21-000131:mdna:77]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our September 2016 Notes, March 2020 Notes, and June 2021 Notes. Interest expense was $60 million and $54 million during the second quarter of fiscal years 2022 and 2021, respectively, and $113 million and $78 million during the first half of fiscal years 2022 and 2021, respectively.

[0001045810-21-000131:mdna:78]
Other, net, consists primarily of realized or unrealized gains and losses from non-affiliated and equity investments and the impact of changes in foreign currency rates. Other, net, was an income of $4 million and $138 million during the second quarter and first half of fiscal year 2022, respectively, and not significant during the second quarter and first half of fiscal year 2021. The increase during the first half of fiscal year 2022 was primarily due to an unrealized gain from an equity investment. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information regarding our equity investment.

[0001045810-21-000131:mdna:79]
[same as prior period, unchanged from 0001045810-21-000064:mdna:75]

[0001045810-21-000131:mdna:80]
We recognized an income tax expense of $20 million and $153 million for the second quarter and first half of fiscal year 2022, respectively, and an income tax benefit of $13 million and an income tax expense of $52 million for the second quarter and first half of fiscal year 2021, respectively. The income tax expense as a percentage of income before income tax was 0.9% and 3.4% for the second quarter and first half of fiscal year 2022, respectively, and 3.3% for the first half of fiscal year 2021. The income tax benefit as a percentage of income before income tax was 2.0% for the second quarter of fiscal year 2021.

[0001045810-21-000131:mdna:81]
The increase in our effective tax rate for the second quarter and first half of fiscal year 2022 as compared to the same periods of fiscal year 2021 was primarily due to a decreased impact of tax benefits from stock-based compensation and the U.S. federal research tax credit, and an increase in the amount of earnings subject to U.S. tax, partially offset by the discrete benefit of the Domestication. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information, including the Domestication.

[0001045810-21-000131:mdna:82]
[same as prior period, unchanged from 0001045810-21-000064:mdna:79]

[0001045810-21-000131:mdna:83]
|  | August 1, 2021 |  | January 31, 2021 |
|  | (In millions) |
| Cash and cash equivalents | $ | 5,628 |  |  | $ | 847 |  |
| Marketable securities | 14,026 |  |  | 10,714 |  |
| Cash, cash equivalents and marketable securities | $ | 19,654 |  |  | $ | 11,561 |  |

[0001045810-21-000131:mdna:84]
30

[0001045810-21-000131:mdna:85]
|  | Six Months Ended |
|  | August 1, 2021 |  | July 26, 2020 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 4,556 |  |  | $ | 2,476 |  |
| Net cash used in investing activities | $ | (3,805) |  |  | $ | (14,545) |  |
| Net cash provided by financing activities | $ | 4,030 |  |  | $ | 4,447 |  |

[0001045810-21-000131:mdna:86]
As of August 1, 2021, we had $19.65 billion in cash, cash equivalents and marketable securities, an increase of $8.09 billion from the end of fiscal year 2021. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-21-000131:mdna:87]
Cash provided by operating activities increased in the first half of fiscal year 2022 compared to the first half of fiscal year 2021, due to higher net income, partially offset by changes in working capital. Changes in working capital include increases in outstanding trade receivables due to higher revenue and decreased shipment linearity.

[0001045810-21-000131:mdna:88]
Cash used in investing activities decreased in the first half of fiscal year 2022 compared to cash used in the first half of fiscal year 2021, primarily driven by the acquisition of Mellanox in the second quarter of fiscal year 2021 and higher sales and maturities of marketable securities, partially offset by higher purchases of marketable securities and higher purchases of property and equipment and intangible assets.

[0001045810-21-000131:mdna:89]
Cash provided by financing activities decreased in the first half of fiscal year 2022 compared to cash provided in the first half of fiscal year 2021, which primarily reflects higher payments related to tax on restricted stock units.

[0001045810-21-000131:mdna:90]
[same as prior period, unchanged from 0001045810-21-000064:mdna:86]

[0001045810-21-000131:mdna:91]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of August 1, 2021, we had $19.65 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of certificates of deposits and debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next 12 months, and for the foreseeable future, including our proposed acquisition of Arm and current and future obligations to secure normal and incremental supply and capacity. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance our future capital requirements.

[0001045810-21-000131:mdna:92]
We have approximately $1.8 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S. Other than that, substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of August 1, 2021 are available for use in the U.S. without incurring additional U.S. federal income taxes. Following the Domestication, we expect to fully utilize our accumulated U.S. federal research tax credits during fiscal year 2022, resulting in higher cash tax payments starting in fiscal year 2023.

[0001045810-21-000131:mdna:93]
[same as prior period, unchanged from 0001045810-21-000064:mdna:90]

[0001045810-21-000131:mdna:94]
In the first half of fiscal year 2022, we paid $198 million in quarterly cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to the continuing determination by our Board of Directors that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-21-000131:mdna:95]
As of August 1, 2021, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022. We did not repurchase any shares during the first half of fiscal year 2022.

[0001045810-21-000131:mdna:96]
[same as prior period, unchanged from 0001045810-21-000064:mdna:93]

[0001045810-21-000131:mdna:97]
As of August 1, 2021, we had outstanding:

[0001045810-21-000131:mdna:98]
•$1.00 billion of Notes Due 2021;

[0001045810-21-000131:mdna:99]
•$1.25 billion of Notes Due 2023;

[0001045810-21-000131:mdna:100]
•$1.25 billion of Notes Due 2024;

[0001045810-21-000131:mdna:101]
•$1.00 billion of Notes Due 2026;

[0001045810-21-000131:mdna:102]
•$1.25 billion of Notes Due 2028;

[0001045810-21-000131:mdna:103]
•$1.50 billion of Notes Due 2030;

[0001045810-21-000131:mdna:104]
•$1.25 billion of Notes Due 2031;

[0001045810-21-000131:mdna:105]
•$1.00 billion of Notes Due 2040;

[0001045810-21-000131:mdna:106]
•$2.00 billion of Notes Due 2050; and

[0001045810-21-000131:mdna:107]
•$500 million of Notes Due 2060.

[0001045810-21-000131:mdna:108]
On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021.

[0001045810-21-000131:mdna:109]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of August 1, 2021, we had not borrowed any amounts under this agreement. The Credit Agreement expires October 2021.

[0001045810-21-000131:mdna:110]
We have a $575 million commercial paper program to support general corporate purposes. As of August 1, 2021, we had not issued any commercial paper.

[0001045810-21-000131:mdna:111]
[same as prior period, unchanged from 0001045810-21-000064:mdna:98]

[0001045810-21-000131:mdna:112]
[same as prior period, unchanged from 0001045810-21-000064:mdna:99]

[0001045810-21-000131:mdna:113]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-21-000131:mdna:114]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
