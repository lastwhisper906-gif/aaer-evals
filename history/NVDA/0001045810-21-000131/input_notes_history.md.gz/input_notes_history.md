# NVDA note change history — 0001045810-21-000064 → 0001045810-21-000131


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-08-20):
[0001045810-21-000131:note_history:1]
As of August 1, 2021, we had outstanding inventory purchase and long-term supply commitment obligations totaling $4.79 billion, of which $4.59 billion is expected to occur over the next 12 months and the remaining balance over 36 months. Other purchase obligations totaling $565 million are primarily expected to occur over the next 18 months.

- added (2021-08-20):
[0001045810-21-000131:note_history:2]
The estimated amount of product warranty liabilities was $31 million and $22 million as of August 1, 2021 and January 31, 2021, respectively, and the activities related to the warranty liabilities were not significant.

- changed (2021-08-20):
[0001045810-21-000131:note_history:3]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.
  (was, 2021-05-26, similarity 0.9712):
[0001045810-21-000064:note_history:3]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

- changed (2021-08-20):
[0001045810-21-000131:note_history:4]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On August 11, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.
  (was, 2021-05-26, similarity 0.9737):
[0001045810-21-000064:note_history:4]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed a notice of appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.

- changed (2021-08-20):
[0001045810-21-000131:note_history:5]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of
  (was, 2021-05-26, similarity 0.8709):
[0001045810-21-000064:note_history:5]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2021-08-20):
[0001045810-21-000131:note_history:6]
cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- changed (2021-08-20):
[0001045810-21-000131:note_history:7]
As of August 1, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2021-05-26, similarity 0.9931):
[0001045810-21-000064:note_history:7]
As of May 2, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2021-08-20):
[0001045810-21-000064:note_history:8]
As of May 2, 2021, we had outstanding inventory purchase obligations totaling $3.46 billion which are expected to occur over the next 12 months, and other purchase obligations totaling $396 million, which are primarily expected to occur over the next 18 months.

- removed (2021-08-20):
[0001045810-21-000064:note_history:9]
The estimated amount of product warranty liabilities was $30 million and $22 million as of May 2, 2021 and January 31, 2021, respectively, and the activities related to the warranty liabilities were not significant.

- removed (2021-08-20):
[0001045810-21-000064:note_history:10]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-08-20):
[0001045810-21-000131:note_history:11]
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock in the form of a stock dividend, or the Stock Split, which was conditioned upon obtaining stockholder approval to increase the number of our authorized shares of common stock from 2 billion to 4 billion. On June 3, 2021, at the 2021 Annual Meeting of Stockholders, our stockholders approved the amendment to our Amended and Restated Certificate of Incorporation to increase the number of authorized shares of common stock to 4 billion. As a result, each stockholder of record at the close of business on June 21, 2021 received a dividend of three additional shares of common stock for every share held on the record date, distributed after the close of trading on July 19, 2021. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the Stock Split.

- changed (2021-08-20):
[0001045810-21-000131:note_history:12]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The second quarters of fiscal years 2022 and 2021 were both 13-week quarters.
  (was, 2021-05-26, similarity 0.7411):
[0001045810-21-000064:note_history:12]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The first quarters of fiscal years 2022 and 2021 were both 13-week quarters.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-08-20):
[0001045810-21-000131:note_history:13]
In June 2021, we issued $1.25 billion of the 0.309% Notes Due 2023, $1.25 billion of the 0.584% Notes Due 2024, $1.25 billion of the 1.55% Notes Due 2028, and $1.25 billion of the 2.00% Notes Due 2031, or collectively, the June 2021 Notes. Interest on the 0.584% Notes Due 2024 is payable on June 14 and December 14 of each year, beginning on December 14, 2021. Interest on all other series of the June 2021 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2021. We may redeem the June 2021 Notes for cash prior to maturity, upon at least 10 but no more than 60 days prior notice, at redemption prices that include accrued and unpaid interest and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2023 on or after June 15, 2022, the Notes Due 2024 on or after June 14, 2023, the Notes Due 2028 on or after April 15, 2028, or the Notes Due 2031 on or after March 15, 2031.  The net proceeds from the June 2021 Notes were $4.98 billion, after deducting debt discount and issuance costs.

- changed (2021-08-20):
[0001045810-21-000131:note_history:14]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021.
  (was, 2021-05-26, similarity 0.8853):
[0001045810-21-000064:note_history:14]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year.

- added (2021-08-20):
[0001045810-21-000131:note_history:15]
The September 2016 Notes, the March 2020 Notes, and the June 2021 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

- changed (2021-08-20):
[0001045810-21-000131:note_history:16]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | August 1, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.9 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.9 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 5.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.9 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.9 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (57) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 11,943 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,943 |  |  | $ | 5,964 |  |
  (was, 2021-05-26, similarity 0.8026):
[0001045810-21-000064:note_history:16]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 2, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 8.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 3.50% Notes Due 2040 |  | 18.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (37) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 6,963 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 5,964 |  |  | $ | 5,964 |  |

- changed (2021-08-20):
[0001045810-21-000131:note_history:17]
As of August 1, 2021, we were in compliance with the required covenants under the Notes.
  (was, 2021-05-26, similarity 0.9571):
[0001045810-21-000064:note_history:17]
As of May 2, 2021, we were in compliance with the required covenants under the Notes.

- changed (2021-08-20):
[0001045810-21-000131:note_history:18]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of August 1, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.
  (was, 2021-05-26, similarity 0.9859):
[0001045810-21-000064:note_history:18]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of May 2, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.

- changed (2021-08-20):
[0001045810-21-000131:note_history:19]
We have a $575 million commercial paper program to support general corporate purposes. As of August 1, 2021, we had not issued any commercial paper.
  (was, 2021-05-26, similarity 0.9749):
[0001045810-21-000064:note_history:19]
We have a $575 million commercial paper program to support general corporate purposes. As of May 2, 2021, we had not issued any commercial paper.

- removed (2021-08-20):
[0001045810-21-000064:note_history:20]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-20):
[0001045810-21-000131:note_history:21]
The following is a summary of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021:
  (was, 2021-05-26, similarity 0.9665):
[0001045810-21-000064:note_history:21]
The following is a summary of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021:

- added (2021-08-20):
[0001045810-21-000131:note_history:22]
|  | August 1, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,610 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 8,611 |  |  | $ | 1,825 |  |  | $ | 6,786 |  |
| Debt securities issued by the United States Treasury | 5,079 |  |  | 1 |  |  | — |  |  | 5,080 |  |  | 1,311 |  |  | 3,769 |  |
| Debt securities issued by United States government agencies | 2,371 |  |  | 1 |  |  | — |  |  | 2,372 |  |  | 60 |  |  | 2,312 |  |
| Money market funds | 2,097 |  |  | — |  |  | — |  |  | 2,097 |  |  | 2,097 |  |  | — |  |
| Certificates of deposit | 962 |  |  | — |  |  | — |  |  | 962 |  |  | 44 |  |  | 918 |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,360 |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | 19,363 |  |  | $ | 5,337 |  |  | $ | 14,026 |  |

- removed (2021-08-20):
[0001045810-21-000064:note_history:23]
|  | May 2, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,240 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 5,242 |  |  | $ | 323 |  |  | $ | 4,919 |  |
| Debt securities issued by United States government agencies | 3,045 |  |  | 1 |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Debt securities issued by the United States Treasury | 2,820 |  |  | 1 |  |  | — |  |  | 2,821 |  |  | — |  |  | 2,821 |  |
| Certificates of deposit | 884 |  |  | — |  |  | — |  |  | 884 |  |  | 48 |  |  | 836 |  |
| Money market funds | 319 |  |  | — |  |  | — |  |  | 319 |  |  | 319 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 12,375 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12,379 |  |  | $ | 690 |  |  | $ | 11,689 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-20):
[0001045810-21-000131:note_history:24]
The following is a summary of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021:
  (was, 2021-05-26, similarity 0.9665):
[0001045810-21-000064:note_history:24]
The following is a summary of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021:

- added (2021-08-20):
[0001045810-21-000131:note_history:25]
|  | August 1, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,610 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 8,611 |  |  | $ | 1,825 |  |  | $ | 6,786 |  |
| Debt securities issued by the United States Treasury | 5,079 |  |  | 1 |  |  | — |  |  | 5,080 |  |  | 1,311 |  |  | 3,769 |  |
| Debt securities issued by United States government agencies | 2,371 |  |  | 1 |  |  | — |  |  | 2,372 |  |  | 60 |  |  | 2,312 |  |
| Money market funds | 2,097 |  |  | — |  |  | — |  |  | 2,097 |  |  | 2,097 |  |  | — |  |
| Certificates of deposit | 962 |  |  | — |  |  | — |  |  | 962 |  |  | 44 |  |  | 918 |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,360 |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | 19,363 |  |  | $ | 5,337 |  |  | $ | 14,026 |  |

- changed (2021-08-20):
[0001045810-21-000131:note_history:26]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of August 1, 2021 and January 31, 2021 are shown below by contractual maturity.
  (was, 2021-05-26, similarity 0.9783):
[0001045810-21-000064:note_history:26]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 2, 2021 and January 31, 2021 are shown below by contractual maturity.

- added (2021-08-20):
[0001045810-21-000131:note_history:27]
|  | August 1, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,390 |  |  | $ | 17,391 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 1,970 |  |  | 1,972 |  |  | 566 |  |  | 568 |  |
| Total | $ | 19,360 |  |  | $ | 19,363 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |

- removed (2021-08-20):
[0001045810-21-000064:note_history:28]
|  | May 2, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 5,240 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 5,242 |  |  | $ | 323 |  |  | $ | 4,919 |  |
| Debt securities issued by United States government agencies | 3,045 |  |  | 1 |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Debt securities issued by the United States Treasury | 2,820 |  |  | 1 |  |  | — |  |  | 2,821 |  |  | — |  |  | 2,821 |  |
| Certificates of deposit | 884 |  |  | — |  |  | — |  |  | 884 |  |  | 48 |  |  | 836 |  |
| Money market funds | 319 |  |  | — |  |  | — |  |  | 319 |  |  | 319 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 12,375 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12,379 |  |  | $ | 690 |  |  | $ | 11,689 |  |

- removed (2021-08-20):
[0001045810-21-000064:note_history:29]
|  | May 2, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,499 |  |  | $ | 11,502 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 876 |  |  | 877 |  |  | 566 |  |  | 568 |  |
| Total | $ | 12,375 |  |  | $ | 12,379 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-20):
[0001045810-21-000131:note_history:30]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | August 1, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.9 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.9 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 5.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.9 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.9 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (57) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 11,943 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,943 |  |  | $ | 5,964 |  |
  (was, 2021-05-26, similarity 0.8026):
[0001045810-21-000064:note_history:30]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 2, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 8.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 3.50% Notes Due 2040 |  | 18.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (37) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 6,963 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 5,964 |  |  | $ | 5,964 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-08-20):
[0001045810-21-000064:note_history:31]
Subsequent Event
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock in the form of a stock dividend, conditioned on obtaining stockholder approval at our 2021 Annual Meeting of Stockholders to be held on June 3, 2021, of an amendment to our Amended and Restated Certificate of Incorporation to increase the number of authorized shares of common stock from 2 billion to 4 billion. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the four-for-one stock split as if it had been effective for all periods presented:

- removed (2021-08-20):
[0001045810-21-000064:note_history:32]
|  |  |  | Pro Forma (Unaudited) |  |  |  |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |  |  |
|  |  |  |  |  | May 2, |  | April 26, |  | January 31, |  | January 26, |  | January 27, |  |  |  |  |
|  |  |  |  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2019 |  |  |  |  |
|  |  |  |  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  |  |  |  | $ | 1,912 |  |  | $ | 917 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |  | $ | 4,141 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares |  |  |  |  | 2,484 |  |  | 2,456 |  |  | 2,468 |  |  | 2,436 |  |  | 2,432 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards |  |  |  |  | 44 |  |  | 32 |  |  | 44 |  |  | 36 |  |  | 68 |  |  |  |  |  |
| Diluted weighted average shares |  |  |  |  | 2,528 |  |  | 2,488 |  |  | 2,512 |  |  | 2,472 |  |  | 2,500 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic (1) |  |  |  |  | $ | 0.77 |  |  | $ | 0.37 |  |  | $ | 1.76 |  |  | $ | 1.15 |  |  | $ | 1.70 |  |  |  |  |  |
| Diluted (2) |  |  |  |  | $ | 0.76 |  |  | $ | 0.37 |  |  | $ | 1.72 |  |  | $ | 1.13 |  |  | $ | 1.66 |  |  |  |  |  |

- removed (2021-08-20):
[0001045810-21-000064:note_history:33]
(1)    Calculated as net income divided by basic weighted average shares.

- removed (2021-08-20):
[0001045810-21-000064:note_history:34]
(2)    Calculated as net income divided by diluted weighted average shares.
