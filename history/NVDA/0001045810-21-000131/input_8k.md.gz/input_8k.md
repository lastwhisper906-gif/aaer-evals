# NVDA 8-K — 0001045810-21-000128 filed 2021-08-18

## item codes, every 8-K on or before 2021-08-20

- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2021-08-20

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-21-000128:8k_2_02:1]
EX-99.1
2
q2fy22pr.htm
Q2FY22 PRESS RELEASE

[0001045810-21-000128:8k_2_02:2]
Document

[0001045810-21-000128:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-21-000128:8k_2_02:4]
NVIDIA Announces Financial Results for Second Quarter Fiscal 2022

[0001045810-21-000128:8k_2_02:5]
•Record revenue of $6.51 billion, up 68 percent from a year earlier

[0001045810-21-000128:8k_2_02:6]
•Record Gaming revenue of $3.06 billion, up 85 percent from a year earlier

[0001045810-21-000128:8k_2_02:7]
•Record Data Center revenue of $2.37 billion, up 35 percent from a year earlier

[0001045810-21-000128:8k_2_02:8]
SANTA CLARA, Calif.-Aug. 18, 2021- NVIDIA (NASDAQ: NVDA) today reported record revenue for the second quarter ended August 1, 2021, of $6.51 billion, up 68 percent from a year earlier and up 15 percent from the previous quarter, with record revenue from the company’s Gaming, Data Center and Professional Visualization platforms.

[0001045810-21-000128:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.94, up 276 percent from a year ago and up 24 percent from the previous quarter. Non-GAAP earnings per diluted share were $1.04, up 89 percent from a year ago and up 14 percent from the previous quarter.

[0001045810-21-000128:8k_2_02:10]
“NVIDIA’s pioneering work in accelerated computing continues to advance graphics, scientific computing and AI,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-21-000128:8k_2_02:11]
“Enabled by the NVIDIA platform, developers are creating the most impactful technologies of our time – from natural language understanding and recommender systems, to autonomous vehicles and logistic centers, to digital biology and climate science, to metaverse worlds that obey the laws of physics.

[0001045810-21-000128:8k_2_02:12]
“This quarter, we launched NVIDIA Base Command and Fleet Command to develop, deploy, scale and orchestrate the AI workloads that run on the NVIDIA AI Enterprise software suite. With our new enterprise software, wide range of NVIDIA-powered systems and global network of system and integration partners, we can accelerate the world’s largest industries racing to benefit from the transformative power of AI.

[0001045810-21-000128:8k_2_02:13]
“We are thrilled to have launched NVIDIA Omniverse, a simulation platform nearly five years in the making that runs physically realistic virtual worlds and connects to other digital platforms. We imagine engineers, designers and even autonomous machines connecting to Omniverse to create digital twins and industrial metaverses,” he said.

[0001045810-21-000128:8k_2_02:14]
NVIDIA paid quarterly cash dividends of $100 million in the second quarter. It will pay its next quarterly cash dividend of $0.04 per share on September 23, 2021, to all shareholders of record on September 1, 2021.

[0001045810-21-000128:8k_2_02:15]
On July 19, 2021, the company completed a four-for-one split of its common stock in the form of a stock dividend to shareholders of record as of June 21, 2021. All share and per share amounts presented have been retroactively adjusted to reflect the stock split.

[0001045810-21-000128:8k_2_02:16]
Q2 Fiscal 2022 Summary

[0001045810-21-000128:8k_2_02:17]
| GAAP |
| ($ in millions, except earnings per share) | Q2 FY22 | Q1 FY22 | Q2 FY21 | Q/Q | Y/Y |
| Revenue | $6,507 | $5,661 | $3,866 | Up 15% | Up 68% |
| Gross margin | 64.8 | % | 64.1 | % | 58.8 | % | Up 70 bps | Up 600 bps |
| Operating expenses | $1,771 | $1,673 | $1,624 | Up 6% | Up 9% |
| Operating income | $2,444 | $1,956 | $651 | Up 25% | Up 275% |
| Net income | $2,374 | $1,912 | $622 | Up 24% | Up 282% |
| Diluted earnings per share | $0.94 | $0.76 | $0.25 | Up 24% | Up 276% |

[0001045810-21-000128:8k_2_02:18]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q2 FY22 | Q1 FY22 | Q2 FY21 | Q/Q | Y/Y |
| Revenue | $6,507 | $5,661 | $3,866 | Up 15% | Up 68% |
| Gross margin | 66.7 | % | 66.2 | % | 66.0 | % | Up 50 bps | Up 70 bps |
| Operating expenses | $1,266 | $1,189 | $1,035 | Up 6% | Up 22% |
| Operating income | $3,071 | $2,557 | $1,516 | Up 20% | Up 103% |
| Net income | $2,623 | $2,313 | $1,366 | Up 13% | Up 92% |
| Diluted earnings per share | $1.04 | $0.91 | $0.55 | Up 14% | Up 89% |

[0001045810-21-000128:8k_2_02:19]
NVIDIA’s outlook for the third quarter of fiscal 2022 is as follows:

[0001045810-21-000128:8k_2_02:20]
•Revenue is expected to be $6.80 billion, plus or minus 2 percent.

[0001045810-21-000128:8k_2_02:21]
•GAAP and non-GAAP gross margins are expected to be 65.2 percent and 67.0 percent, respectively, plus or minus 50 basis points.

[0001045810-21-000128:8k_2_02:22]
•GAAP and non-GAAP operating expenses are expected to be approximately $1.96 billion and $1.37 billion, respectively.

[0001045810-21-000128:8k_2_02:23]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $60 million, excluding gains and losses on equity securities.

[0001045810-21-000128:8k_2_02:24]
•GAAP and non-GAAP tax rates are both expected to be 11 percent, plus or minus 1 percent, excluding any discrete items such as excess tax benefits or deficiencies related to stock-based compensation.

[0001045810-21-000128:8k_2_02:25]
Highlights

[0001045810-21-000128:8k_2_02:26]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-21-000128:8k_2_02:27]
Gaming

[0001045810-21-000128:8k_2_02:28]
•Second-quarter revenue was a record $3.06 billion, up 85 percent from a year earlier and up 11 percent from the previous quarter.

[0001045810-21-000128:8k_2_02:29]
•Introduced GeForce RTX® 3080 Ti and GeForce RTX 3070 Ti, delivering up to 50 percent more performance over the previous generation.

[0001045810-21-000128:8k_2_02:30]
•Announced that NVIDIA RTX™ is featured in 130+ games and applications, including Red Dead Redemption 2, F1 2021 and Minecraft RTX, in China, as well as Adobe Photoshop and Premiere Pro.

[0001045810-21-000128:8k_2_02:31]
•Announced that NVIDIA Reflex, which reduces gaming latency, is supported in 20 games, including top e-sports titles.

[0001045810-21-000128:8k_2_02:32]
•Announced that GeForce RTX technologies are available for Arm platforms, with demos of Wolfenstein: Youngblood and The Bistro.

[0001045810-21-000128:8k_2_02:33]
•Announced that GeForce NOW™ gives members access to more than 1,000 PC games, more than any other cloud-gaming service.

[0001045810-21-000128:8k_2_02:34]
Data Center

[0001045810-21-000128:8k_2_02:35]
•Second-quarter revenue was a record $2.37 billion, up 35 percent from a year earlier and up 16 percent from the previous quarter.

[0001045810-21-000128:8k_2_02:36]
•Unveiled NVIDIA Base Command™ and Fleet Command™ – software platforms optimized for NVIDIA-powered systems running NVIDIA AI software – to develop, deploy, and manage AI applications across the enterprise and the industrial edge.

[0001045810-21-000128:8k_2_02:37]
•Announced NVIDIA AI LaunchPad, a program delivered by hybrid-cloud providers giving enterprises instant AI infrastructure, with Equinix as the first partner.

[0001045810-21-000128:8k_2_02:38]
•Launched TensorRT™ 8, the latest generation of NVIDIA’s AI inference software, delivering record-setting speed for natural language processing and other AI applications.

[0001045810-21-000128:8k_2_02:39]
•Announced NVIDIA® technology supports 342 supercomputers on the latest TOP500 list, including 70 percent of all new systems and 8 of the top 10, and powers 35 of the top 40 greenest systems.

[0001045810-21-000128:8k_2_02:40]
•Announced NVIDIA is powering major new supercomputers, including: Perlmutter, the world’s fastest AI supercomputer, at the U.S. National Energy Research Scientific Computing Center; Cambridge-1, the U.K.’s most powerful supercomputer; Tesla’s new training system; and Petrobras’ Dragão supercomputer, Latin America’s fastest.

[0001045810-21-000128:8k_2_02:41]
•Extended the Arm ecosystem with the NVIDIA Arm HPC Developer Kit, with applicants for early access from 70+ leading organizations.

[0001045810-21-000128:8k_2_02:42]
•Set performance records across all eight AI training benchmarks for commercially available systems in the latest MLPerf results, delivering up to 3.5x more performance than last year’s scores.

[0001045810-21-000128:8k_2_02:43]
•Announced there are now more than 55 NVIDIA-Certified Systems™ offered by the world’s leading server makers supporting NVIDIA AI Enterprise software, with many powered by NVIDIA BlueField®-2 DPUs and NVIDIA DOCA™.

[0001045810-21-000128:8k_2_02:44]
•Supported Microsoft Azure’s general availability of NVIDIA A100 GPU VMs, their most powerful virtual machines for supercomputer-class AI and HPC workloads.

[0001045810-21-000128:8k_2_02:45]
•Worked with Google Cloud to establish the first AI-on-5G Innovation Lab, helping to accelerate the creation of smart cities, smart factories and other 5G and AI applications.

[0001045810-21-000128:8k_2_02:46]
•Powered Palo Alto Networks’ virtual next-generation firewall – the industry’s first running on DPUs – with NVIDIA BlueField-2, enabling up to 5x acceleration and maximizing data center security.

[0001045810-21-000128:8k_2_02:47]
Professional Visualization

[0001045810-21-000128:8k_2_02:48]
•Second-quarter revenue was a record $519 million, up 156 percent from a year earlier and up 40 percent from the previous quarter.

[0001045810-21-000128:8k_2_02:49]
•Expanded NVIDIA Omniverse™, the world’s first 3D, real-time simulation and collaboration platform, through new integrations with Blender and Adobe, applications used by millions of users.

[0001045810-21-000128:8k_2_02:50]
•Launched the NVIDIA RTX A2000, which brings RTX to the volume segment of the desktop workstation market and enables a range of new form factors from backs of displays to edge devices.

[0001045810-21-000128:8k_2_02:51]
Automotive

[0001045810-21-000128:8k_2_02:52]
•Second-quarter revenue was $152 million, up 37 percent from a year earlier and down 1 percent from the previous quarter.

[0001045810-21-000128:8k_2_02:53]
•Announced that self-driving startup AutoX’s Gen5 robotaxi platform uses NVIDIA DRIVE® to achieve level 4 autonomy.

[0001045810-21-000128:8k_2_02:54]
•Collaborated with autonomous trucking company Plus on plans to provide Amazon with at least 1,000 self-driving systems, which are powered by NVIDIA DRIVE.

[0001045810-21-000128:8k_2_02:55]
•Announced that autonomous trucking platform startup Embark is using NVIDIA DRIVE to create systems for Freightliner, Navistar International, PACCAR and Volvo.

[0001045810-21-000128:8k_2_02:56]
CFO Commentary

[0001045810-21-000128:8k_2_02:57]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-21-000128:8k_2_02:58]
Conference Call and Webcast Information

[0001045810-21-000128:8k_2_02:59]
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2022.

[0001045810-21-000128:8k_2_02:60]
Non-GAAP Measures

[0001045810-21-000128:8k_2_02:61]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, IP-related costs, gains and losses from non-affiliated investments, mark to market adjustments of our publicly traded equity securities, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable, and domestication tax benefit. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-21-000128:8k_2_02:62]
About NVIDIA

[0001045810-21-000128:8k_2_02:63]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market and has redefined modern computer graphics, high performance computing and artificial intelligence. The company’s pioneering work in accelerated computing and AI is reshaping trillion-dollar industries, such as transportation, healthcare and manufacturing, and fueling the growth of many others. More information at https://nvidianews.nvidia.com/.

[0001045810-21-000128:8k_2_02:64]
###

[0001045810-21-000128:8k_2_02:65]
For further information, contact:

[0001045810-21-000128:8k_2_02:66]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-21-000128:8k_2_02:67]
Certain statements in this press release including, but not limited to, statements as to: NVIDIA’s pioneering work in accelerated computing and its impacts; NVIDIA’s platform enabling developers to create the most impactful technologies of our time; NVIDIA accelerating the world’s largest industries racing to benefit from the transformative power of AI; the benefits, performance and abilities of our products and technologies, including NVIDIA Base Command, Fleet Command, NVIDIA Omniverse, GeForce RTX 3080 Ti and 3070 Ti, NVIDIA Reflex, GeForce NOW, NVIDIA AI LaunchPad, TensorRT 8, NVIDIA A100 GPU VMs, NVIDIA BlueField-2, NVIDIA RTX A2000, and NVIDIA DRIVE; our ability to bring the power of AI to the world’s largest industries with our global network of system partners and new enterprise software and subscriptions; engineers, designers and autonomous machines connecting to Omniverse to create digital twins and industrial metaverses; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the third quarter of fiscal 2022; NVIDIA’s expected tax rates for the third quarter of fiscal 2022; and the impact of the first AI-on-5G Innovation Lab are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-21-000128:8k_2_02:68]
© 2021 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, BlueField, Fleet Command, GeForce NOW, GeForce RTX, NVIDIA Base Command, NVIDIA DOCA, NVIDIA DRIVE, NVIDIA Omniverse, NVIDIA RTX, GeForce NOW, GeForce RTX and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000128:8k_2_02:69]
NVIDIA CORPORATION

[0001045810-21-000128:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-21-000128:8k_2_02:71]
(In millions, except per share data)

[0001045810-21-000128:8k_2_02:72]
(Unaudited)

[0001045810-21-000128:8k_2_02:73]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | August 1, |  | July 26, |  | August 1, |  | July 26, |
|  |  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue | $ | 6,507 |  |  | $ | 3,866 |  |  | $ | 12,168 |  |  | $ | 6,946 |  |
| Cost of revenue | 2,292 |  |  | 1,591 |  |  | 4,324 |  |  | 2,667 |  |
| Gross profit | 4,215 |  |  | 2,275 |  |  | 7,844 |  |  | 4,279 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,245 |  |  | 997 |  |  | 2,398 |  |  | 1,732 |  |
|  | Sales, general and administrative | 526 |  |  | 627 |  |  | 1,046 |  |  | 920 |  |
|  |  | Total operating expenses | 1,771 |  |  | 1,624 |  |  | 3,444 |  |  | 2,652 |  |
| Income from operations | 2,444 |  |  | 651 |  |  | 4,400 |  |  | 1,627 |  |
|  | Interest income | 6 |  |  | 13 |  |  | 13 |  |  | 44 |  |
|  | Interest expense | (60) |  |  | (54) |  |  | (113) |  |  | (78) |  |
|  | Other, net | 4 |  |  | (1) |  |  | 138 |  |  | (2) |  |
|  |  | Other income (expense), net | (50) |  |  | (42) |  |  | 38 |  |  | (36) |  |
| Income before income tax | 2,394 |  |  | 609 |  |  | 4,438 |  |  | 1,591 |  |
| Income tax expense (benefit) | 20 |  |  | (13) |  |  | 153 |  |  | 52 |  |
| Net income | $ | 2,374 |  |  | $ | 622 |  |  | $ | 4,285 |  |  | $ | 1,539 |  |
| Net income per share (A): |  |  |  |  |  |  |  |
|  | Basic | $ | 0.95 |  |  | $ | 0.25 |  |  | $ | 1.72 |  |  | $ | 0.63 |  |
|  | Diluted | $ | 0.94 |  |  | $ | 0.25 |  |  | $ | 1.69 |  |  | $ | 0.62 |  |
| Weighted average shares used in per share computation (A): |  |  |  |  |  |  |  |
|  | Basic | 2,493 |  |  | 2,464 |  |  | 2,489 |  |  | 2,460 |  |
|  | Diluted | 2,532 |  |  | 2,504 |  |  | 2,529 |  |  | 2,496 |  |

[0001045810-21-000128:8k_2_02:74]
(A) Reflects a four-for-one stock split on July 19, 2021.

[0001045810-21-000128:8k_2_02:75]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | August 1, |  | January 31, |
|  |  |  |  | 2021 |  | 2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 19,654 |  |  | $ | 11,561 |  |
|  | Accounts receivable, net |  | 3,586 |  |  | 2,429 |  |
|  | Inventories |  | 2,114 |  |  | 1,826 |  |
|  | Prepaid expenses and other current assets |  | 452 |  |  | 239 |  |
|  |  | Total current assets |  | 25,806 |  |  | 16,055 |  |
| Property and equipment, net |  | 2,364 |  |  | 2,149 |  |
| Operating lease assets |  | 801 |  |  | 707 |  |
| Goodwill |  | 4,193 |  |  | 4,193 |  |
| Intangible assets, net |  | 2,478 |  |  | 2,737 |  |
| Deferred income tax assets |  | 958 |  |  | 806 |  |
| Other assets |  | 2,050 |  |  | 2,144 |  |
|  |  | Total assets |  | $ | 38,650 |  |  | $ | 28,791 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,474 |  |  | $ | 1,201 |  |
|  | Accrued and other current liabilities |  | 1,974 |  |  | 1,725 |  |
|  | Short-term debt |  | 1,000 |  |  | 999 |  |
|  |  | Total current liabilities |  | 4,448 |  |  | 3,925 |  |
| Long-term debt |  | 10,943 |  |  | 5,964 |  |
| Long-term operating lease liabilities |  | 716 |  |  | 634 |  |
| Other long-term liabilities |  | 1,396 |  |  | 1,375 |  |
|  |  | Total liabilities |  | 17,503 |  |  | 11,898 |  |
| Shareholders' equity |  | 21,147 |  |  | 16,893 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 38,650 |  |  | $ | 28,791 |  |

[0001045810-21-000128:8k_2_02:76]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, |  | July 26, |  | August 1, |  | July 26, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,374 |  |  | $ | 622 |  |  | $ | 4,285 |  |  | $ | 1,539 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 465 |  |  | 374 |  |  | 894 |  |  | 598 |  |
| Depreciation and amortization | 286 |  |  | 404 |  |  | 567 |  |  | 511 |  |
| Deferred income taxes | (185) |  |  | (80) |  |  | (161) |  |  | (64) |  |
| (Gains) losses on investments in non affiliates, net | 1 |  |  | 2 |  |  | (133) |  |  | 5 |  |
| Other | 18 |  |  | (10) |  |  | 16 |  |  | (10) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (563) |  |  | 44 |  |  | (1,157) |  |  | (205) |  |
| Inventories | (123) |  |  | 54 |  |  | (282) |  |  | (97) |  |
| Prepaid expenses and other assets | 16 |  |  | 42 |  |  | 18 |  |  | 34 |  |
| Accounts payable | 209 |  |  | (8) |  |  | 279 |  |  | 63 |  |
| Accrued and other current liabilities | 133 |  |  | 112 |  |  | 132 |  |  | 81 |  |
| Other long-term liabilities | 51 |  |  | 10 |  |  | 98 |  |  | 21 |  |
| Net cash provided by operating activities | 2,682 |  |  | 1,566 |  |  | 4,556 |  |  | 2,476 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,096 |  |  | 1,032 |  |  | 5,236 |  |  | 1,032 |  |
| Proceeds from sales of marketable securities | 347 |  |  | 258 |  |  | 705 |  |  | 259 |  |
| Purchases of marketable securities | (4,798) |  |  | (7,425) |  |  | (9,268) |  |  | (8,286) |  |
| Purchases related to property and equipment and intangible assets | (183) |  |  | (217) |  |  | (481) |  |  | (372) |  |
| Investments and other, net | 5 |  |  | — |  |  | 3 |  |  | (7) |  |
| Acquisitions, net of cash acquired | — |  |  | (7,137) |  |  | — |  |  | (7,171) |  |
| Net cash used in investing activities | (2,533) |  |  | (13,489) |  |  | (3,805) |  |  | (14,545) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Issuance of debt, net of issuance costs | 4,985 |  |  | (8) |  |  | 4,985 |  |  | 4,971 |  |
| Proceeds related to employee stock plans | 2 |  |  | 6 |  |  | 128 |  |  | 94 |  |
| Payments related to tax on restricted stock units | (365) |  |  | (196) |  |  | (843) |  |  | (418) |  |
| Dividends paid | (100) |  |  | (99) |  |  | (198) |  |  | (197) |  |
| Principal payments on property and equipment | (21) |  |  | — |  |  | (40) |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | (3) |  |
| Net cash provided by (used in) financing activities | 4,501 |  |  | (297) |  |  | 4,030 |  |  | 4,447 |  |
| Change in cash and cash equivalents | 4,650 |  |  | (12,220) |  |  | 4,781 |  |  | (7,622) |  |
| Cash and cash equivalents at beginning of period | 978 |  |  | 15,494 |  |  | 847 |  |  | 10,896 |  |
| Cash and cash equivalents at end of period | $ | 5,628 |  |  | $ | 3,274 |  |  | $ | 5,628 |  |  | $ | 3,274 |  |

[0001045810-21-000128:8k_2_02:77]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | August 1, |  | May 2, |  | July 26, |  | August 1, |  | July 26, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP gross profit |  | $ | 4,215 |  |  | $ | 3,629 |  |  | $ | 2,275 |  |  | $ | 7,844 |  |  | $ | 4,279 |  |
| GAAP gross margin |  | 64.8 | % |  | 64.1 | % |  | 58.8 | % |  | 64.5 | % |  | 61.6 | % |
|  | Acquisition-related and other costs (A) |  | 86 |  |  | 87 |  |  | 245 |  |  | 173 |  |  | 246 |  |
|  | Stock-based compensation expense (B) |  | 32 |  |  | 25 |  |  | 14 |  |  | 57 |  |  | 35 |  |
|  | IP-related costs |  | 4 |  |  | 5 |  |  | 17 |  |  | 9 |  |  | 17 |  |
| Non-GAAP gross profit |  | $ | 4,337 |  |  | $ | 3,746 |  |  | $ | 2,551 |  |  | $ | 8,083 |  |  | $ | 4,577 |  |
| Non-GAAP gross margin |  | 66.7 | % |  | 66.2 | % |  | 66.0 | % |  | 66.4 | % |  | 65.9 | % |
| GAAP operating expenses |  | $ | 1,771 |  |  | $ | 1,673 |  |  | $ | 1,624 |  |  | $ | 3,444 |  |  | $ | 2,652 |  |
|  | Stock-based compensation expense (B) |  | (433) |  |  | (404) |  |  | (360) |  |  | (837) |  |  | (563) |  |
|  | Acquisition-related and other costs (A) |  | (72) |  |  | (80) |  |  | (229) |  |  | (152) |  |  | (233) |  |
| Non-GAAP operating expenses |  | $ | 1,266 |  |  | $ | 1,189 |  |  | $ | 1,035 |  |  | $ | 2,455 |  |  | $ | 1,856 |  |
| GAAP income from operations |  | $ | 2,444 |  |  | $ | 1,956 |  |  | $ | 651 |  |  | $ | 4,400 |  |  | $ | 1,627 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 627 |  |  | 601 |  |  | 865 |  |  | 1,228 |  |  | 1,094 |  |
| Non-GAAP income from operations |  | $ | 3,071 |  |  | $ | 2,557 |  |  | $ | 1,516 |  |  | $ | 5,628 |  |  | $ | 2,721 |  |
| GAAP other income (expense), net |  | $ | (50) |  |  | $ | 88 |  |  | $ | (42) |  |  | $ | 38 |  |  | $ | (36) |  |
|  | (Gains) losses from non-affiliated investments |  | — |  |  | (134) |  |  | 2 |  |  | (133) |  |  | 5 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Non-GAAP other income (expense), net |  | $ | (49) |  |  | $ | (45) |  |  | $ | (39) |  |  | $ | (93) |  |  | $ | (30) |  |
| GAAP net income |  | $ | 2,374 |  |  | $ | 1,912 |  |  | $ | 622 |  |  | $ | 4,285 |  |  | $ | 1,539 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 628 |  |  | 468 |  |  | 868 |  |  | 1,097 |  |  | 1,100 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (127) |  |  | (67) |  |  | (124) |  |  | (194) |  |  | (153) |  |
|  | Domestication tax benefit |  | (252) |  |  | — |  |  | — |  |  | (252) |  |  | — |  |
| Non-GAAP net income |  | $ | 2,623 |  |  | $ | 2,313 |  |  | $ | 1,366 |  |  | $ | 4,936 |  |  | $ | 2,486 |  |

[0001045810-21-000128:8k_2_02:78]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | August 1, |  | May 2, |  | July 26, |  | August 1, |  | July 26, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Diluted net income per share (D) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.94 |  |  | $ | 0.76 |  |  | $ | 0.25 |  |  | $ | 1.69 |  |  | $ | 0.62 |  |
|  | Non-GAAP |  | $ | 1.04 |  |  | $ | 0.91 |  |  | $ | 0.55 |  |  | $ | 1.95 |  |  | $ | 1.00 |  |
| Weighted average shares used in diluted net income per share computation (D) |  | 2,532 |  |  | 2,528 |  |  | 2,504 |  |  | 2,529 |  |  | 2,496 |  |
| GAAP net cash provided by operating activities |  | $ | 2,682 |  |  | $ | 1,874 |  |  | $ | 1,566 |  |  | $ | 4,556 |  |  | $ | 2,476 |  |
|  | Purchases related to property and equipment and intangible assets |  | (183) |  |  | (298) |  |  | (217) |  |  | (481) |  |  | (372) |  |
|  | Principal payments on property and equipment |  | (21) |  |  | (19) |  |  | — |  |  | (40) |  |  | — |  |
| Free cash flow |  | $ | 2,478 |  |  | $ | 1,557 |  |  | $ | 1,349 |  |  | $ | 4,035 |  |  | $ | 2,104 |  |

[0001045810-21-000128:8k_2_02:79]
| (A) Acquisition-related and other costs primarily include amortization of intangible assets, inventory step-up, transaction costs, and certain compensation charges presented as follows: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | August 1, |  | May 2, |  | July 26, |  | August 1, |  | July 26, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Cost of revenue |  | $ | 86 |  |  | $ | 87 |  |  | $ | 245 |  |  | $ | 173 |  |  | $ | 246 |  |
|  | Research and development |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | 5 |  |
|  | Sales, general and administrative |  | $ | 71 |  |  | $ | 79 |  |  | $ | 226 |  |  | $ | 148 |  |  | $ | 228 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | August 1, |  | May 2, |  | July 26, |  | August 1, |  | July 26, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Cost of revenue |  | $ | 32 |  |  | $ | 25 |  |  | $ | 14 |  |  | $ | 57 |  |  | $ | 35 |  |
|  | Research and development |  | $ | 297 |  |  | $ | 276 |  |  | $ | 228 |  |  | $ | 573 |  |  | $ | 362 |  |
|  | Sales, general and administrative |  | $ | 136 |  |  | $ | 128 |  |  | $ | 132 |  |  | $ | 264 |  |  | $ | 201 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (D) Reflects a four-for-one stock split on July 19, 2021. |

[0001045810-21-000128:8k_2_02:80]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q3 FY2022 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 65.2 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 1.8 | % |
| Non-GAAP gross margin |  | 67.0 | % |
| GAAP operating expenses |  | $ | 1,960 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (590) |  |
| Non-GAAP operating expenses |  | $ | 1,370 |  |
