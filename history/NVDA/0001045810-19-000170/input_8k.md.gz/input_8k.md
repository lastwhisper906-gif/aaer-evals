# NVDA 8-K — 0001045810-19-000168 filed 2019-11-14

## item codes, every 8-K on or before 2019-11-14

- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2019-11-14

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-19-000168:8k_2_02:1]
EX-99.2
3
q3fy20cfocommentary.htm
Q3FY20 CFO COMMENTARY

[0001045810-19-000168:8k_2_02:2]
Exhibit

[0001045810-19-000168:8k_2_02:3]
CFO Commentary on Third Quarter Fiscal 2020 Results

[0001045810-19-000168:8k_2_02:4]
Q3 Fiscal 2020 Summary

[0001045810-19-000168:8k_2_02:5]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY20 | Q2 FY20 | Q3 FY19 | Q/Q | Y/Y |
| Revenue | $3,014 | $2,579 | $3,181 | Up 17% | Down 5% |
| Gross margin | 63.6 | % | 59.8 | % | 60.4 | % | Up 380 bps | Up 320 bps |
| Operating expenses | $989 | $970 | $863 | Up 2% | Up 15% |
| Operating income | $927 | $571 | $1,058 | Up 62% | Down 12% |
| Net income | $899 | $552 | $1,230 | Up 63% | Down 27% |
| Diluted earnings per share | $1.45 | $0.90 | $1.97 | Up 61% | Down 26% |

[0001045810-19-000168:8k_2_02:6]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY20 | Q2 FY20 | Q3 FY19 | Q/Q | Y/Y |
| Revenue | $3,014 | $2,579 | $3,181 | Up 17% | Down 5% |
| Gross margin | 64.1 | % | 60.1 | % | 61.0 | % | Up 400 bps | Up 310 bps |
| Operating expenses | $774 | $749 | $730 | Up 3% | Up 6% |
| Operating income | $1,156 | $802 | $1,210 | Up 44% | Down 4% |
| Net income | $1,103 | $762 | $1,151 | Up 45% | Down 4% |
| Diluted earnings per share | $1.78 | $1.24 | $1.84 | Up 44% | Down 3% |

[0001045810-19-000168:8k_2_02:7]
| Revenue by Reportable Segments |
| ($ in millions) | Q3 FY20 | Q2 FY20 | Q3 FY19 | Q/Q | Y/Y |
| GPU Business | $2,565 | $2,104 | $2,774 | Up 22% | Down 8% |
| Tegra Processor Business | 449 | 475 | 407 | Down 5% | Up 10% |
| Total | $3,014 | $2,579 | $3,181 | Up 17% | Down 5% |

[0001045810-19-000168:8k_2_02:8]
| Revenue by Market Platform |
| ($ in millions) | Q3 FY20 | Q2 FY20 | Q3 FY19 | Q/Q | Y/Y |
| Gaming | $1,659 | $1,313 | $1,764 | Up 26% | Down 6% |
| Professional Visualization | 324 | 291 | 305 | Up 11% | Up 6% |
| Data Center | 726 | 655 | 792 | Up 11% | Down 8% |
| Automotive | 162 | 209 | 172 | Down 22% | Down 6% |
| OEM and Other | 143 | 111 | 148 | Up 29% | Down 3% |
| Total | $3,014 | $2,579 | $3,181 | Up 17% | Down 5% |

[0001045810-19-000168:8k_2_02:9]
Revenue

[0001045810-19-000168:8k_2_02:10]
Revenue was $3.01 billion, down 5 percent from a year earlier and up 17 percent sequentially.

[0001045810-19-000168:8k_2_02:11]
GPU business revenue was $2.56 billion, down 8 percent from a year earlier and up 22 percent sequentially.

[0001045810-19-000168:8k_2_02:12]
Tegra™ Processor business revenue - which includes Automotive, SoC modules for gaming platforms, and embedded edge AI platforms - was $449 million, up 10 percent from a year ago and down 5 percent sequentially.

[0001045810-19-000168:8k_2_02:13]
From a market platforms perspective, Gaming revenue was $1.66 billion, down 6 percent from a year ago and up 26 percent sequentially.  The year-on-year decrease reflects lower sales of GeForce® desktop GPUs from the prior year, which included the launch of Turing-based GeForce GPUs, partially offset by growth in GeForce notebook GPUs and SoC modules for gaming platforms.  The sequential increase reflects growth primarily from GeForce desktop and notebook GPUs.

[0001045810-19-000168:8k_2_02:14]
Professional Visualization revenue was a record $324 million, up 6 percent from a year earlier and up 11 percent sequentially.  The year-on-year and sequential growth reflect strength in mobile workstation products.

[0001045810-19-000168:8k_2_02:15]
Data Center revenue was $726 million, down 8 percent from a year ago and up 11 percent sequentially.  The year-on-year decline reflects lower enterprise revenue due to a different mix of products including lower DGX™ sales, partially offset by an increase in hyperscale demand.  The sequential increase was driven by hyperscale demand.

[0001045810-19-000168:8k_2_02:16]
Automotive revenue was $162 million, down 6 percent from a year earlier and down 22 percent sequentially.  The year-on-year decrease reflects lower revenue from legacy infotainment modules and autonomous vehicle solutions, partially offset by growth in AI cockpit solutions. The sequential decrease reflects a large non-recurring development services agreement closed in the prior quarter.

[0001045810-19-000168:8k_2_02:17]
OEM and Other revenue was $143 million, down 3 percent from a year ago and up 29 percent sequentially.  The sequential increase was primarily due to growth in entry-level GPUs for notebook PCs.

[0001045810-19-000168:8k_2_02:18]
Gross Margin

[0001045810-19-000168:8k_2_02:19]
GAAP gross margin for the third quarter was 63.6 percent, up 320 basis points from a year earlier and up 380 basis points sequentially.  The year-on-year and sequential increases are primarily driven by improved margins on GeForce GPUs for gaming reflecting the sale of previously written-off components and lower component costs.  The sequential increase also reflects higher average selling prices for GeForce GPUs.  Non-GAAP gross margin was 64.1 percent.

[0001045810-19-000168:8k_2_02:20]
Expenses

[0001045810-19-000168:8k_2_02:21]
GAAP operating expenses were $989 million, including $215 million in stock-based compensation and other charges, up 15 percent from a year earlier and up 2 percent sequentially.  The year-on-year and sequential growth primarily reflect employee additions and increases in employee compensation and other related costs, including stock-based compensation and infrastructure costs.  Non-GAAP operating expenses were $774 million, up 6 percent from a year earlier and up 3 percent sequentially.

[0001045810-19-000168:8k_2_02:22]
Operating Income

[0001045810-19-000168:8k_2_02:23]
GAAP operating income was $927 million, down 12 percent from a year earlier and up 62 percent sequentially.  Non-GAAP operating income was $1.16 billion, down 4 percent from a year earlier and up 44 percent sequentially.

[0001045810-19-000168:8k_2_02:24]
Other Income & Expense and Income Tax

[0001045810-19-000168:8k_2_02:25]
| GAAP |
| ($ in millions) | Q3 FY20 | Q2 FY20 | Q3 FY19 |
| Interest income | $45 | $47 | $37 |
| Interest expense | (13) | (13) | (15) |
| Other, net | -- | 1 | 1 |
| Total | $32 | $35 | $23 |

[0001045810-19-000168:8k_2_02:26]
| Non-GAAP |
| ($ in millions) | Q3 FY20 | Q2 FY20 | Q3 FY19 |
| Interest income | $45 | $47 | $37 |
| Interest expense | (12) | (13) | (15) |
| Other, net | -- | 1 | (1) |
| Total | $33 | $35 | $21 |

[0001045810-19-000168:8k_2_02:27]
GAAP other income and expense, or OI&E, includes interest earned on cash and investments, interest expense associated with corporate bonds, and other gains and losses. Non-GAAP OI&E excludes the portion of interest expense from the amortization of the debt discount and the gains or losses from certain investments.

[0001045810-19-000168:8k_2_02:28]
GAAP effective tax rate was 6.3 percent, inclusive of excess tax benefits related to stock-based compensation.  Non-GAAP effective tax rate was 7.3 percent.

[0001045810-19-000168:8k_2_02:29]
Net Income and EPS

[0001045810-19-000168:8k_2_02:30]
GAAP net income was $899 million and non-GAAP net income was $1.10 billion.  GAAP earnings per diluted share were $1.45, down 26 percent from a year earlier and up 61 percent sequentially.  The year-on-year decrease reflects lower revenue and higher operating expenses.  The sequential increase primarily reflects higher revenue and gross margin.  Non-GAAP earnings per diluted share were $1.78, down 3 percent from a year earlier and up 44 percent sequentially.

[0001045810-19-000168:8k_2_02:31]
Capital Return

[0001045810-19-000168:8k_2_02:32]
| Capital Return |
| (in millions) | FY13 | FY14 | FY15 | FY16 | FY17 | FY18 | FY19 | YTD FY20 |
| Dividends | $47 | $181 | $186 | $213 | $261 | $341 | $371 | $292 |
| Share repurchases: |  |  |  |  |  |  |  |  |
| $ | $100 | $887 | $814 | $587 | $739 | $909 | $1,578 | $-- |
| Shares | 8 | 62 | 44 | 25 | 15 | 6 | 9 | -- |

[0001045810-19-000168:8k_2_02:33]
We will return to repurchasing our stock after closing the acquisition of Mellanox Technologies, Ltd.  Although discussions with the European Union and China regulatory bodies are progressing and closing the acquisition is possible by the end of this calendar year, we believe the closing will likely occur in the early part of calendar 2020.

[0001045810-19-000168:8k_2_02:34]
Balance Sheet and Cash Flow

[0001045810-19-000168:8k_2_02:35]
Cash, cash equivalents and marketable securities at the end of the third quarter were $9.77 billion, up from $8.47 billion in the prior quarter.  This increase primarily reflects growth in operating cash flow.

[0001045810-19-000168:8k_2_02:36]
Accounts receivable at the end of the quarter was $1.46 billion compared with $1.56 billion in the prior quarter and $2.22 billion a year earlier.  DSO at quarter-end was 44 days, down from 55 days in the prior quarter and down from 63 days a year earlier.

[0001045810-19-000168:8k_2_02:37]
Inventory at the end of the quarter was $1.05 billion, down from $1.20 billion in the prior quarter and down from $1.42 billion a year earlier.  Outstanding inventory purchase obligations at the end of the quarter were $980 million, up from $757 million in the prior quarter and down from $1.56 billion a year earlier.  DSI at quarter-end was 87 days, down from 106 days in the prior quarter and down from 102 days a year earlier.

[0001045810-19-000168:8k_2_02:38]
Cash flow from operating activities was a record $1.64 billion in the third quarter, up from $936 million in the prior quarter, and up from $487 million a year earlier.  The sequential increase reflects growth in operating income and changes in working capital driven by a reduction in DSO.  The year-on-year increase reflects change in working capital driven by a reduction in DSO and timing of inventory purchases.

[0001045810-19-000168:8k_2_02:39]
Free cash flow was $1.54 billion in the third quarter, compared with $823 million in the previous quarter and $337 million a year earlier.

[0001045810-19-000168:8k_2_02:40]
Depreciation and amortization expense amounted to $92 million for the third quarter.  Capital expenditures were $104 million for the third quarter.

[0001045810-19-000168:8k_2_02:41]
Fourth Quarter of Fiscal 2020 Outlook

[0001045810-19-000168:8k_2_02:42]
Our outlook for the fourth quarter of fiscal 2020 does not include any contribution from the pending acquisition of Mellanox and is as follows:

[0001045810-19-000168:8k_2_02:43]
| • | Revenue is expected to be $2.95 billion, plus or minus 2 percent. We expect strong sequential growth in Data Center, offset by a seasonal decline in GeForce notebook GPUs and SoC modules for gaming platforms. |

[0001045810-19-000168:8k_2_02:44]
| • | GAAP and non-GAAP gross margins are expected to be 64.1 percent and 64.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-19-000168:8k_2_02:45]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $1.02 billion and $805 million, respectively. |

[0001045810-19-000168:8k_2_02:46]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $25 million. |

[0001045810-19-000168:8k_2_02:47]
| • | GAAP and non-GAAP tax rates are both expected to be 9 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-19-000168:8k_2_02:48]
| • | Capital expenditures are expected to be approximately $130 million to $150 million. |

[0001045810-19-000168:8k_2_02:49]
______________

[0001045810-19-000168:8k_2_02:50]
For further information, contact:

[0001045810-19-000168:8k_2_02:51]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-19-000168:8k_2_02:52]
Non-GAAP Measures

[0001045810-19-000168:8k_2_02:53]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, restructuring and other, acquisition-related and other costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user's overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-19-000168:8k_2_02:54]
Certain statements in this CFO Commentary including, but not limited to, statements as to: NVIDIA returning to repurchasing our stock after closing the acquisition of Mellanox; the status of the regulatory approval process and the timing of closing for the Mellanox acquisition; our financial outlook for the fourth quarter of fiscal 2020; our expectation of strong sequential growth in Data Center, offset by a seasonal decline in notebook and SoC modules for gaming platforms, in the fourth quarter of fiscal 2020; our expected tax rates for the fourth quarter of fiscal 2020; our expectation to generate variability from excess tax benefits or deficiencies; and our expected capital expenditures for the fourth quarter of fiscal 2020 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-19-000168:8k_2_02:55]
# # #

[0001045810-19-000168:8k_2_02:56]
© 2019 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, DGX, GeForce, NVIDIA Turing and Tegra are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000168:8k_2_02:57]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 28, |  | October 27, |  | October 28, |
|  |  |  | 2019 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 1,916 |  |  | $ | 1,541 |  |  | $ | 1,921 |  |  | $ | 4,753 |  |  | $ | 5,964 |  |
| GAAP gross margin |  | 63.6 | % |  | 59.8 | % |  | 60.4 | % |  | 60.8 | % |  | 62.7 | % |
|  | Stock-based compensation expense (A) |  | 15 |  |  | 8 |  |  | 5 |  |  | 27 |  |  | 21 |  |
|  | Legal settlement costs |  | — |  |  | 2 |  |  | 14 |  |  | 11 |  |  | 14 |  |
| Non-GAAP gross profit |  | $ | 1,931 |  |  | $ | 1,551 |  |  | $ | 1,940 |  |  | $ | 4,791 |  |  | $ | 5,999 |  |
| Non-GAAP gross margin |  | 64.1 | % |  | 60.1 | % |  | 61.0 | % |  | 61.3 | % |  | 63.1 | % |
| GAAP operating expenses |  | $ | 989 |  |  | $ | 970 |  |  | $ | 863 |  |  | $ | 2,897 |  |  | $ | 2,454 |  |
|  | Stock-based compensation expense (A) |  | (208 | ) |  | (216 | ) |  | (135 | ) |  | (597 | ) |  | (379 | ) |
|  | Acquisition-related and other costs |  | (7 | ) |  | (5 | ) |  | (1 | ) |  | (22 | ) |  | (5 | ) |
|  | Legal settlement costs |  | — |  |  | — |  |  | (1 | ) |  | (2 | ) |  | (3 | ) |
|  | Restructuring and other |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Non-GAAP operating expenses |  | $ | 774 |  |  | $ | 749 |  |  | $ | 730 |  |  | $ | 2,276 |  |  | $ | 2,071 |  |
| GAAP income from operations |  | $ | 927 |  |  | $ | 571 |  |  | $ | 1,058 |  |  | $ | 1,856 |  |  | $ | 3,510 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 229 |  |  | 231 |  |  | 152 |  |  | 659 |  |  | 418 |  |
| Non-GAAP income from operations |  | $ | 1,156 |  |  | $ | 802 |  |  | $ | 1,210 |  |  | $ | 2,515 |  |  | $ | 3,928 |  |
| GAAP other income (expense) |  | $ | 32 |  |  | $ | 35 |  |  | $ | 23 |  |  | $ | 98 |  |  | $ | 62 |  |
|  | Losses (Gains) from non-affiliated investments |  | — |  |  | — |  |  | (2 | ) |  | 1 |  |  | (11 | ) |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Non-GAAP other income (expense) |  | $ | 33 |  |  | $ | 35 |  |  | $ | 21 |  |  | $ | 100 |  |  | $ | 52 |  |
| GAAP net income |  | $ | 899 |  |  | $ | 552 |  |  | $ | 1,230 |  |  | $ | 1,845 |  |  | $ | 3,575 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 230 |  |  | 231 |  |  | 150 |  |  | 660 |  |  | 409 |  |
|  | Income tax impact of non-GAAP adjustments (B) |  | (26 | ) |  | (21 | ) |  | (91 | ) |  | (97 | ) |  | (199 | ) |
|  | Tax benefit from income tax reform |  | — |  |  | — |  |  | (138 | ) |  | — |  |  | (138 | ) |
| Non-GAAP net income |  | $ | 1,103 |  |  | $ | 762 |  |  | $ | 1,151 |  |  | $ | 2,408 |  |  | $ | 3,647 |  |

[0001045810-19-000168:8k_2_02:58]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 28, |  | October 27, |  | October 28, |
|  |  |  | 2019 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 1.45 |  |  | $ | 0.90 |  |  | $ | 1.97 |  |  | $ | 2.99 |  |  | $ | 5.71 |  |
|  | Non-GAAP |  | $ | 1.78 |  |  | $ | 1.24 |  |  | $ | 1.84 |  |  | $ | 3.90 |  |  | $ | 5.83 |  |
| Weighted average shares used in diluted net income per share computation |  | 618 |  |  | 616 |  |  | 625 |  |  | 617 |  |  | 626 |  |
| GAAP net cash provided by operating activities |  | $ | 1,640 |  |  | $ | 936 |  |  | $ | 487 |  |  | $ | 3,296 |  |  | $ | 2,845 |  |
|  | Purchase of property and equipment and intangible assets |  | (104 | ) |  | (113 | ) |  | (150 | ) |  | (344 | ) |  | (397 | ) |
| Free cash flow |  | $ | 1,536 |  |  | $ | 823 |  |  | $ | 337 |  |  | $ | 2,952 |  |  | $ | 2,448 |  |

[0001045810-19-000168:8k_2_02:59]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 28, |  | October 27, |  | October 28, |
|  |  |  | 2019 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Cost of revenue |  | $ | 15 |  |  | $ | 8 |  |  | $ | 5 |  |  | $ | 27 |  |  | $ | 21 |  |
|  | Research and development |  | $ | 141 |  |  | $ | 145 |  |  | $ | 88 |  |  | $ | 400 |  |  | $ | 237 |  |
|  | Sales, general and administrative |  | $ | 67 |  |  | $ | 71 |  |  | $ | 47 |  |  | $ | 197 |  |  | $ | 142 |  |
| (B) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-19-000168:8k_2_02:60]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2020 Outlook |
| GAAP gross margin |  | 64.1 | % |
|  | Impact of stock-based compensation expense |  | 0.4 | % |
| Non-GAAP gross margin |  | 64.5 | % |
|  |  |  | Q4 FY2020 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 1,015 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (210 | ) |
| Non-GAAP operating expenses |  | $ | 805 |  |
