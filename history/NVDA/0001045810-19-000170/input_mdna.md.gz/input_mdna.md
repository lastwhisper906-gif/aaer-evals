# NVDA MD&A — 0001045810-19-000170


## mdna

[0001045810-19-000170:mdna:1]
[same as prior period, unchanged from 0001045810-19-000144:mdna:1]

[0001045810-19-000170:mdna:2]
[same as prior period, unchanged from 0001045810-19-000144:mdna:2]

[0001045810-19-000170:mdna:3]
[same as prior period, unchanged from 0001045810-19-000144:mdna:3]

[0001045810-19-000170:mdna:4]
NVIDIA, the NVIDIA logo, CUDA, CUDA-X AI, GeForce, GeForce GTX, GeForce NOW, GeForce RTX, NVIDIA DGX, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA DRIVE Constellation, NVIDIA Omniverse, NVIDIA RTX, NVIDIA SHIELD, Quadro, Quadro RTX, Tegra and Tesla are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000170:mdna:5]
[same as prior period, unchanged from 0001045810-19-000144:mdna:5]

[0001045810-19-000170:mdna:6]
[same as prior period, unchanged from 0001045810-19-000144:mdna:6]

[0001045810-19-000170:mdna:7]
[same as prior period, unchanged from 0001045810-19-000144:mdna:7]

[0001045810-19-000170:mdna:8]
[same as prior period, unchanged from 0001045810-19-000144:mdna:8]

[0001045810-19-000170:mdna:9]
[same as prior period, unchanged from 0001045810-19-000144:mdna:9]

[0001045810-19-000170:mdna:10]
[same as prior period, unchanged from 0001045810-19-000144:mdna:10]

[0001045810-19-000170:mdna:11]
[same as prior period, unchanged from 0001045810-19-000144:mdna:11]

[0001045810-19-000170:mdna:12]
[same as prior period, unchanged from 0001045810-19-000144:mdna:12]

[0001045810-19-000170:mdna:13]
Third Quarter of Fiscal Year 2020 Summary

[0001045810-19-000170:mdna:14]
|  | Three Months Ended |  |  |  |  |
|  | October 27, 2019 |  | July 28, 2019 |  | October 28, 2018 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 3,014 |  |  | $ | 2,579 |  |  | $ | 3,181 |  |  | 17 | % |  | (5 | )% |
| Gross margin | 63.6 | % |  | 59.8 | % |  | 60.4 | % |  | 380 bps |  |  | 320 bps |  |
| Operating expenses | $ | 989 |  |  | $ | 970 |  |  | $ | 863 |  |  | 2 | % |  | 15 | % |
| Income from operations | $ | 927 |  |  | $ | 571 |  |  | $ | 1,058 |  |  | 62 | % |  | (12 | )% |
| Net income | $ | 899 |  |  | $ | 552 |  |  | $ | 1,230 |  |  | 63 | % |  | (27 | )% |
| Net income per diluted share | $ | 1.45 |  |  | $ | 0.90 |  |  | $ | 1.97 |  |  | 61 | % |  | (26 | )% |

[0001045810-19-000170:mdna:15]
GPU business revenue was $2.56 billion, down 8% from a year earlier and up 22% sequentially.

[0001045810-19-000170:mdna:16]
Tegra Processor business revenue - which includes Automotive, SOC modules for gaming platforms, and embedded edge AI platforms - was $449 million, up 10% from a year ago and down 5% sequentially.

[0001045810-19-000170:mdna:17]
From a market platforms perspective, Gaming revenue was $1.66 billion, down 6% from a year ago and up 26% sequentially. The year-on-year decrease reflects lower sales of GeForce desktop GPUs from the prior year which included the launch of Turing-based GeForce GPUs, partially offset by growth in GeForce notebook GPUs and SOC modules for gaming platforms. The sequential increase reflects growth primarily from GeForce desktop and notebook GPUs.

[0001045810-19-000170:mdna:18]
Professional Visualization revenue was $324 million, up 6% from a year earlier and up 11% sequentially. The year-on-year and sequential growth reflect strength in mobile workstation products.

[0001045810-19-000170:mdna:19]
Data Center revenue was $726 million, down 8% from a year ago and up 11% sequentially. The year-on-year decline reflects lower enterprise revenue due to a different mix of products including lower DGX sales, partially offset by an increase in hyperscale demand. The sequential increase was driven by hyperscale demand.

[0001045810-19-000170:mdna:20]
Automotive revenue of $162 million was down 6% from a year earlier and down 22% sequentially. The year-on-year decrease reflects lower revenue from legacy infotainment modules and autonomous vehicle solutions, partially offset by growth in AI cockpit solutions. The sequential decrease reflects a large non-recurring development services agreement closed in the prior quarter.

[0001045810-19-000170:mdna:21]
OEM and Other revenue was $143 million, down 3% from a year ago and up 29% sequentially. The sequential increase was primarily due to growth in entry-level GPUs for notebooks PCs.

[0001045810-19-000170:mdna:22]
Gross margin for the third quarter of fiscal year 2020 was 63.6%, up 320 basis points from a year earlier and up 380 basis points sequentially.  The year-on-year and sequential increases are primarily driven by improved margins on GeForce GPUs for gaming reflecting the sale of previously written-off components and lower component costs. The sequential increase also reflects higher average selling prices for GeForce GPUs.

[0001045810-19-000170:mdna:23]
Operating expenses for the third quarter of fiscal year 2020 were $989 million, up 15% from a year earlier and up 2% sequentially, reflecting primarily employee additions and increases in employee compensation and other related costs, including stock-based compensation expense and infrastructure costs.

[0001045810-19-000170:mdna:24]
Income from operations for the third quarter of fiscal year 2020 was $927 million, down 12% from a year earlier and up 62% sequentially. Net income and net income per diluted share for the third quarter of fiscal year 2020 were $899 million and $1.45, respectively, down 27% and 26%, respectively, from a year earlier, and up 63% and 61%, respectively, sequentially. The year-on-year decrease reflects lower revenue and higher operating expenses. The sequential increase reflects higher revenue and gross margin.

[0001045810-19-000170:mdna:25]
On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox Technologies, Ltd., or Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. In June 2019, Mellanox shareholders approved the acquisition. The closing of the acquisition is subject to approval by

[0001045810-19-000170:mdna:26]
regulatory agencies. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million. We have received regulatory approval in the United States and Mexico and are engaged with regulators in Europe and China. Although discussions with the European Union and China regulatory bodies are progressing and closing the acquisition is possible by the end of this calendar year, we believe the closing will likely occur in the early part of calendar 2020.

[0001045810-19-000170:mdna:27]
We previously communicated our intent to return $3.00 billion to shareholders by the end of fiscal year 2020, including $700 million in share repurchases made during the fourth quarter of fiscal year 2019. In the first nine months of fiscal year 2020, we returned $292 million in quarterly cash dividends. We intend to return the remaining $2.01 billion through a combination of share repurchases and cash dividends. We do not expect to repurchase shares prior to the close of the acquisition of Mellanox.

[0001045810-19-000170:mdna:28]
Cash, cash equivalents and marketable securities were $9.77 billion as of October 27, 2019, compared with $7.42 billion as of January 27, 2019. The increase was primarily related to growth in operating cash flow.

[0001045810-19-000170:mdna:29]
[same as prior period, unchanged from 0001045810-19-000144:mdna:30]

[0001045810-19-000170:mdna:30]
During the third quarter of fiscal year 2020, in our Gaming platform, we announced SUPER versions of GeForce GTX GPUs, with GeForce GTX 1650 SUPER and GeForce GTX 1660 SUPER; introduced the RTX Broadcast Engine, which uses the AI capabilities of GeForce RTX GPUs to enable virtual greenscreens, filters, and AR effects in livestreaming; announced two new models of SHIELD TV streaming media player; and expanded the reach of GeForce NOW game streaming.

[0001045810-19-000170:mdna:31]
In our Professional Visualization platform, we announced that a number of creative and design applications are now accelerated by RTX ray tracing.

[0001045810-19-000170:mdna:32]
In our Data Center platform, we launched the NVIDIA EGX Intelligent Edge Computing Platform to bring accelerated AI to retail, manufacturing, telecommunications, logistics, and other industries; announced a collaboration to integrate Microsoft Azure with EGX; entered the 5G telecom market, enabling telcos to build high performing, efficient, virtualized 5G radio access networks using GPUs; announced collaboration to deliver software-defined 5G RAN; won the first inference benchmark, MLPerf Inference 0.5, measuring AI workload performance in data centers and at the edge; partnered with VMware to accelerate VMware Cloud on AWS using NVIDIA T4 GPUs; and announced that the United States Postal Service will use NVIDA AI technology.

[0001045810-19-000170:mdna:33]
[same as prior period, unchanged from 0001045810-19-000144:mdna:31]

[0001045810-19-000170:mdna:34]
[same as prior period, unchanged from 0001045810-19-000144:mdna:32]

[0001045810-19-000170:mdna:35]
[same as prior period, unchanged from 0001045810-19-000144:mdna:33]

[0001045810-19-000170:mdna:36]
[same as prior period, unchanged from 0001045810-19-000144:mdna:34]

[0001045810-19-000170:mdna:37]
[same as prior period, unchanged from 0001045810-19-000144:mdna:35]

[0001045810-19-000170:mdna:38]
[same as prior period, unchanged from 0001045810-19-000144:mdna:36]

[0001045810-19-000170:mdna:39]
24

[0001045810-19-000170:mdna:40]
[same as prior period, unchanged from 0001045810-19-000144:mdna:37]

[0001045810-19-000170:mdna:41]
During the third quarter of fiscal year 2020, we launched Xavier NX, an AI supercomputer for robotic and embedded computing devices at the edge.

[0001045810-19-000170:mdna:42]
[same as prior period, unchanged from 0001045810-19-000144:mdna:38]

[0001045810-19-000170:mdna:43]
[same as prior period, unchanged from 0001045810-19-000144:mdna:39]

[0001045810-19-000170:mdna:44]
[same as prior period, unchanged from 0001045810-19-000144:mdna:40]

[0001045810-19-000170:mdna:45]
[same as prior period, unchanged from 0001045810-19-000144:mdna:41]

[0001045810-19-000170:mdna:46]
[same as prior period, unchanged from 0001045810-19-000144:mdna:42]

[0001045810-19-000170:mdna:47]
[same as prior period, unchanged from 0001045810-19-000144:mdna:43]

[0001045810-19-000170:mdna:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, 2019 |  | October 28, 2018 |  | October 27, 2019 |  | October 28, 2018 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 36.4 |  |  | 39.6 |  |  | 39.2 |  |  | 37.3 |  |
| Gross profit | 63.6 |  |  | 60.4 |  |  | 60.8 |  |  | 62.7 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Research and development | 23.6 |  |  | 19.0 |  |  | 26.8 |  |  | 18.2 |  |
| Sales, general and administrative | 9.2 |  |  | 8.1 |  |  | 10.3 |  |  | 7.6 |  |
| Total operating expenses | 32.8 |  |  | 27.1 |  |  | 37.1 |  |  | 25.8 |  |
| Income from operations | 30.8 |  |  | 33.3 |  |  | 23.7 |  |  | 36.9 |  |
| Interest income | 1.5 |  |  | 1.2 |  |  | 1.8 |  |  | 1.0 |  |
| Interest expense | (0.4 | ) |  | (0.5 | ) |  | (0.5 | ) |  | (0.5 | ) |
| Other, net | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Total other income (expense) | 1.1 |  |  | 0.7 |  |  | 1.3 |  |  | 0.6 |  |
| Income before income tax | 31.9 |  |  | 34.0 |  |  | 25.0 |  |  | 37.5 |  |
| Income tax expense (benefit) | 2.0 |  |  | (4.7 | ) |  | 1.4 |  |  | — |  |
| Net income | 29.9 | % |  | 38.7 | % |  | 23.6 | % |  | 37.5 | % |

[0001045810-19-000170:mdna:49]
[same as prior period, unchanged from 0001045810-19-000144:mdna:45]

[0001045810-19-000170:mdna:50]
[same as prior period, unchanged from 0001045810-19-000144:mdna:46]

[0001045810-19-000170:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, 2019 |  | October 28, 2018 |  | $Change |  | %Change |  | October 27, 2019 |  | October 28, 2018 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,565 |  |  | $ | 2,774 |  |  | $ | (209 | ) |  | (8 | )% |  | $ | 6,691 |  |  | $ | 8,195 |  |  | $ | (1,504 | ) |  | (18 | )% |
| Tegra Processor | 449 |  |  | 407 |  |  | 42 |  |  | 10 | % |  | 1,122 |  |  | 1,316 |  |  | (194 | ) |  | (15 | )% |
| Total | $ | 3,014 |  |  | $ | 3,181 |  |  | $ | (167 | ) |  | (5 | )% |  | $ | 7,813 |  |  | $ | 9,511 |  |  | $ | (1,698 | ) |  | (18 | )% |

[0001045810-19-000170:mdna:52]
GPU Business. GPU business revenue decreased by 8% in the third quarter of fiscal year 2020 compared to the third quarter of fiscal year 2019, which reflects declines in GPUs sold for gaming and Data Center revenue. GeForce GPU product sales for gaming decreased 10%, reflecting a decline in shipments of desktop GPUs partially offset by revenue growth in notebook GPUs. Data Center revenue, which includes Tesla, GRID and DGX, decreased 8%, primarily reflecting a decline in enterprise revenue due to a different mix of products including lower DGX sales, offset by an increase in hyperscale revenue. Revenue from Quadro GPUs for professional visualization increased 6%, primarily reflecting strength across mobile workstation products.

[0001045810-19-000170:mdna:53]
GPU business revenue decreased by 18% in the first nine months of fiscal year 2020 compared to the first nine months of fiscal year 2019, which reflects declines in GPUs sold for gaming and Data Center revenue. GeForce GPU product sales for gaming decreased 22%, reflecting a decline in shipments of desktop GPUs partially offset by growth in notebook GPUs. Data Center revenue, which includes Tesla, GRID and DGX, decreased 11%, primarily reflecting a decline in hyperscale revenue partially offset by enterprise revenue growth driven by expanding AI workloads. Revenue from Quadro GPUs for professional visualization increased 5% due primarily reflecting strength across mobile workstation products. Our PC OEM revenue decreased by 46% primarily driven by the absence of cryptocurrency mining processor GPU sales.

[0001045810-19-000170:mdna:54]
Tegra Processor Business. Tegra Processor business revenue increased by 10% for the third quarter of fiscal year 2020 compared to the third quarter of fiscal year 2019. This was driven by an increase in revenue from SOC modules for gaming platforms, which was partially offset by a decline of 6% in Automotive revenue. The decrease in Automotive revenue reflected slowdown of infotainment modules and autonomous vehicle solutions partially offset by growth in AI cockpit solutions.

[0001045810-19-000170:mdna:55]
Tegra Processor business revenue decreased by 15% for the first nine months of fiscal year 2020 compared to the first nine months of fiscal year 2019. This was driven by a decline in revenue from SOC modules for gaming platforms, which was partially offset by an increase of 12% in Automotive revenue. Growth in Automotive revenue primarily reflects growth in AI cockpit solutions and autonomous vehicle solutions.

[0001045810-19-000170:mdna:56]
[same as prior period, unchanged from 0001045810-19-000144:mdna:53]

[0001045810-19-000170:mdna:57]
Revenue from sales to customers outside of the United States accounted for 92% of total revenue for the third quarter and first nine months of fiscal year 2020. Revenue from sales to customers outside of the United States accounted for 87% of total revenue for the third quarter and first nine months of fiscal year 2019. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-19-000170:mdna:58]
One customer represented approximately 10% of our total revenue for the third quarter and approximately 11% of our total revenue for the first nine months of fiscal year 2020, and was attributable primarily to the GPU business. No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal year 2019.

[0001045810-19-000170:mdna:59]
[same as prior period, unchanged from 0001045810-19-000144:mdna:56]

[0001045810-19-000170:mdna:60]
Our overall gross margin increased to 63.6% for the third quarter of fiscal year 2020 from 60.4% for the third quarter of fiscal year 2019 are primarily driven by improved margins on GeForce GPUs for gaming reflecting the sale of previously written-off components and lower component costs. Our overall gross margin decreased to 60.8% for the first nine months of fiscal year 2020 from 62.7% for the first nine months of fiscal year 2019 reflecting product transitions and product mix  offset by the sale of previously written off components associated with GeForce GPUs for gaming.

[0001045810-19-000170:mdna:61]
Inventory provisions totaled $42 million and $70 million for the third quarter of fiscal years 2020 and 2019, respectively. Sales of inventory that was previously written-off or written-down totaled $78 million and $13 million for the third quarter of fiscal years 2020 and 2019, respectively. As a result, the overall net effect on our gross margin was a favorable impact of 1.2% and unfavorable impact of 1.8% for the third quarter of fiscal years 2020 and 2019, respectively.

[0001045810-19-000170:mdna:62]
Inventory provisions totaled $114 million and $124 million for the first nine months of fiscal years 2020 and 2019, respectively. Sales of inventory that was previously written-off or written-down totaled $109 million and $29 million for the first nine months of fiscal years 2020 and 2019, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.1% and 1.0% for the first nine months of fiscal years 2020 and 2019, respectively.

[0001045810-19-000170:mdna:63]
[same as prior period, unchanged from 0001045810-19-000144:mdna:60]

[0001045810-19-000170:mdna:64]
GPU Business. The gross margin of our GPU business increased during the third quarter of fiscal year 2020 compared to the third quarter of fiscal year 2019, reflecting the sale of previously written off components. For the first nine months of fiscal year 2020 compared to the first nine months of fiscal year 2019, gross margin decreased primarily reflecting product transitions and product mix offset by the sale of previously written off components.

[0001045810-19-000170:mdna:65]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased during the third quarter of fiscal year 2020 compared to the third quarter of fiscal year 2019, primarily driven by higher OEM product costs and product mix. For the first nine months of fiscal year 2020 compared to the first nine months of fiscal year 2019, gross margin decreased primarily due to product mix.

[0001045810-19-000170:mdna:66]
[same as prior period, unchanged from 0001045810-19-000144:mdna:63]

[0001045810-19-000170:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, 2019 |  | October 28, 2018 |  | $Change |  | %Change |  | October 27, 2019 |  | October 28, 2018 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| Research and development expenses | $ | 712 |  |  | $ | 605 |  |  | $ | 107 |  |  | 18 | % |  | $ | 2,091 |  |  | $ | 1,729 |  |  | $ | 362 |  |  | 21 | % |
| % of net revenue | 24 | % |  | 19 | % |  |  |  |  |  | 27 | % |  | 18 | % |  |  |  |  |
| Sales, general and administrative expenses | 277 |  |  | 258 |  |  | 19 |  |  | 7 | % |  | 806 |  |  | 725 |  |  | 81 |  |  | 11 | % |
| % of net revenue | 9 | % |  | 8 | % |  |  |  |  |  | 10 | % |  | 8 | % |  |  |  |  |
| Total operating expenses | $ | 989 |  |  | $ | 863 |  |  | $ | 126 |  |  | 15 | % |  | $ | 2,897 |  |  | $ | 2,454 |  |  | $ | 443 |  |  | 18 | % |

[0001045810-19-000170:mdna:68]
[same as prior period, unchanged from 0001045810-19-000144:mdna:65]

[0001045810-19-000170:mdna:69]
Research and development expenses increased by 18% and 21% during the third quarter and first nine months of fiscal year 2020, compared to the third quarter and first nine months of fiscal year 2019, respectively, driven primarily by employee additions, increases in employee compensation and other related costs, including infrastructure costs and stock-based compensation expense.

[0001045810-19-000170:mdna:70]
[same as prior period, unchanged from 0001045810-19-000144:mdna:67]

[0001045810-19-000170:mdna:71]
Sales, general and administrative expenses increased by 7% during the third quarter of fiscal year 2020, compared to the third quarter of fiscal year 2019, driven primarily by employee additions, increases in employee compensation and other related costs, including stock-based compensation expense and infrastructure costs.

[0001045810-19-000170:mdna:72]
Sales, general and administrative expenses increased by 11% during the first nine months of fiscal year 2020, compared to the first nine months of fiscal year 2019, driven primarily by costs related to employee additions, increases in employee compensation and other related costs, including stock-based compensation expense and infrastructure costs, and costs related to our plans to acquire Mellanox.

[0001045810-19-000170:mdna:73]
[same as prior period, unchanged from 0001045810-19-000144:mdna:70]

[0001045810-19-000170:mdna:74]
[same as prior period, unchanged from 0001045810-19-000144:mdna:71]

[0001045810-19-000170:mdna:75]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $45 million and $37 million during the third quarter of fiscal years 2020 and 2019, respectively, and $137 million and $94 million during the first nine months of fiscal years 2020 and 2019, respectively. The increase in interest income was primarily due to higher average invested balances.

[0001045810-19-000170:mdna:76]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016. Interest expense was $13 million and $15 million during the third quarters of fiscal years 2020 and 2019, respectively, and $39 million and $44 million during the first nine months of fiscal years 2020 and 2019, respectively.

[0001045810-19-000170:mdna:77]
[same as prior period, unchanged from 0001045810-19-000144:mdna:76]

[0001045810-19-000170:mdna:78]
We recognized an income tax expense of $60 million and $109 million for the third quarter and first nine months of fiscal year 2020, respectively, and an income tax benefit of $149 million and $3 million for the third quarter and first nine months of fiscal year 2019, respectively. The income tax expense as a percentage of income before income tax was 6.3% and 5.6% for the third quarter and first nine months of fiscal year 2020, respectively, and income tax benefit as a percentage of income before income tax was 13.8% and nominal for the third quarter and first nine months of fiscal year 2019, respectively.

[0001045810-19-000170:mdna:79]
[same as prior period, unchanged from 0001045810-19-000144:mdna:78]

[0001045810-19-000170:mdna:80]
The increase in our effective tax rate for the third quarter and first nine months of fiscal year 2020 as compared to the third quarter and first nine months of fiscal year 2019 was primarily due to a decrease of tax benefits from stock-based compensation and an absence of the tax benefit related to the reduction in our provisional U.S. tax reform transition tax amount.

[0001045810-19-000170:mdna:81]
[same as prior period, unchanged from 0001045810-19-000144:mdna:80]

[0001045810-19-000170:mdna:82]
[same as prior period, unchanged from 0001045810-19-000144:mdna:81]

[0001045810-19-000170:mdna:83]
|  | October 27, 2019 |  | January 27, 2019 |
|  | (In millions) |
| Cash and cash equivalents | $ | 9,765 |  |  | $ | 782 |  |
| Marketable securities | 4 |  |  | 6,640 |  |
| Cash, cash equivalents and marketable securities | $ | 9,769 |  |  | $ | 7,422 |  |

[0001045810-19-000170:mdna:84]
|  | Nine Months Ended |
|  | October 27, 2019 |  | October 28, 2018 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 3,296 |  |  | $ | 2,845 |  |
| Net cash provided by (used in) investing activities | $ | 6,296 |  |  | $ | (4,137 | ) |
| Net cash used in financing activities | $ | (609 | ) |  | $ | (1,989 | ) |

[0001045810-19-000170:mdna:85]
As of October 27, 2019, we had $9.77 billion in cash, cash equivalents and marketable securities, an increase of $2.35 billion from the end of fiscal year 2019. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain limits on our portfolio duration.

[0001045810-19-000170:mdna:86]
Cash provided by operating activities increased in the first nine months of fiscal year 2020 compared to the first nine months of fiscal year 2019, due to changes in working capital driven by a reduction in days sales outstanding and a reduction in inventory. These increases were partially offset by lower net income.

[0001045810-19-000170:mdna:87]
Cash provided by investing activities increased in the first nine months of fiscal year 2020 compared to cash used in the first nine months of fiscal year 2019, due to lower purchases of marketable securities and higher maturities and sales of marketable securities in preparation for the acquisition of Mellanox.

[0001045810-19-000170:mdna:88]
Cash used in financing activities decreased in the first nine months of fiscal year 2020 compared to the first nine months of fiscal year 2019, due to lower share repurchases and lower tax payments related to employee stock plans.

[0001045810-19-000170:mdna:89]
[same as prior period, unchanged from 0001045810-19-000144:mdna:88]

[0001045810-19-000170:mdna:90]
[same as prior period, unchanged from 0001045810-19-000144:mdna:89]

[0001045810-19-000170:mdna:91]
As a result of the Tax Cuts and Jobs Act, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of October 27, 2019 are available for use in the United States without incurring additional U.S. federal income taxes.

[0001045810-19-000170:mdna:92]
[same as prior period, unchanged from 0001045810-19-000144:mdna:91]

[0001045810-19-000170:mdna:93]
We previously communicated our intent to return $3.00 billion to shareholders by the end of fiscal year 2020, including $700 million in share repurchases made during the fourth quarter of fiscal year 2019. In the first nine months of fiscal year 2020, we returned $292 million in quarterly cash dividends. We intend to return the remaining $2.01 billion through a combination of share repurchases and cash dividends. We do not expect to repurchase shares prior to the close of the acquisition of Mellanox. As of October 27, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000170:mdna:94]
[same as prior period, unchanged from 0001045810-19-000144:mdna:93]

[0001045810-19-000170:mdna:95]
[same as prior period, unchanged from 0001045810-19-000144:mdna:94]

[0001045810-19-000170:mdna:96]
[same as prior period, unchanged from 0001045810-19-000144:mdna:95]

[0001045810-19-000170:mdna:97]
Revolving Credit Facility

[0001045810-19-000170:mdna:98]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 27, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000170:mdna:99]
[same as prior period, unchanged from 0001045810-19-000144:mdna:98]

[0001045810-19-000170:mdna:100]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2019, we had not issued any commercial paper.

[0001045810-19-000170:mdna:101]
[same as prior period, unchanged from 0001045810-19-000144:mdna:100]

[0001045810-19-000170:mdna:102]
In fiscal year 2019, we began construction on a 750 thousand square foot building on our Santa Clara campus, which is currently targeted for completion in fiscal year 2022. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months.

[0001045810-19-000170:mdna:103]
[same as prior period, unchanged from 0001045810-19-000144:mdna:102]

[0001045810-19-000170:mdna:104]
As of October 27, 2019, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-19-000170:mdna:105]
[same as prior period, unchanged from 0001045810-19-000144:mdna:104]

[0001045810-19-000170:mdna:106]
[same as prior period, unchanged from 0001045810-19-000144:mdna:105]

[0001045810-19-000170:mdna:107]
[same as prior period, unchanged from 0001045810-19-000144:mdna:106]

[0001045810-19-000170:mdna:108]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000170:mdna:109]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
