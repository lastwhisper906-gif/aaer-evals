# NVDA note change history — 0001045810-19-000144 → 0001045810-19-000170


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-14):
[0001045810-19-000170:note_history:1]
Commitments and Contingencies
Purchase Obligations
  (was, 2019-08-15, similarity 0.9091):
[0001045810-19-000144:note_history:1]
Commitments and Contingencies
Inventory Purchase Obligations

- changed (2019-11-14):
[0001045810-19-000170:note_history:2]
As of October 27, 2019, we had outstanding inventory purchase obligations totaling $980 million and other purchase obligations totaling $138 million.
  (was, 2019-08-15, similarity 0.7232):
[0001045810-19-000144:note_history:2]
As of July 28, 2019, we had outstanding inventory purchase obligations totaling $757 million.

- added (2019-11-14):
[0001045810-19-000170:note_history:3]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of October 27, 2019, the amount of our remaining performance

- changed (2019-11-14):
[0001045810-19-000170:note_history:4]
obligations that has not been recognized as revenue was $395 million, of which we expect to recognize approximately 47% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.
  (was, 2019-08-15, similarity 0.7456):
[0001045810-19-000144:note_history:4]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of July 28, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $418 million, of which we expect to recognize approximately 48% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

- changed (2019-11-14):
[0001045810-19-000170:note_history:5]
The estimated amount of product returns and warranty liabilities was $17 million and $18 million as of October 27, 2019 and January 27, 2019, respectively, and the activity related to the warranty liabilities were not significant.
  (was, 2019-08-15, similarity 0.7584):
[0001045810-19-000144:note_history:5]
The estimated amount of product returns and warranty liabilities was $17 million and $18 million as of July 28, 2019 and January 27, 2019, respectively.

- changed (2019-11-14):
[0001045810-19-000170:note_history:6]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.
  (was, 2019-08-15, similarity 0.9913):
[0001045810-19-000144:note_history:6]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

- changed (2019-11-14):
[0001045810-19-000170:note_history:7]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.
  (was, 2019-08-15, similarity 0.9988):
[0001045810-19-000144:note_history:7]
On January 18, 2019, a shareholder, purporting to act on the behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

- added (2019-11-14):
[0001045810-19-000170:note_history:8]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and

- added (2019-11-14):
[0001045810-19-000170:note_history:9]
the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- changed (2019-11-14):
[0001045810-19-000170:note_history:10]
Litigation Related to Acquisition of Mellanox
  (was, 2019-08-15, similarity 0.7317):
[0001045810-19-000144:note_history:10]
Litigation Related to Mellanox Merger

- changed (2019-11-14):
[0001045810-19-000170:note_history:11]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Exchange Act and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but NVIDIA was not named as a defendant in any of these other lawsuits.  As of October 14, 2019, all stockholder lawsuits relating to NVIDIA’s pending acquisition of Mellanox, including the Stein lawsuit, had been voluntarily dismissed by the respective plaintiffs.
  (was, 2019-08-15, similarity 0.8476):
[0001045810-19-000144:note_history:11]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Securities Exchange Act of 1934 and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but to date, NVIDIA has not been named as a defendant in any of these other lawsuits.

- changed (2019-11-14):
[0001045810-19-000170:note_history:12]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of October 27, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.
  (was, 2019-08-15, similarity 0.9916):
[0001045810-19-000144:note_history:12]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of July 28, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.

- removed (2019-11-14):
[0001045810-19-000144:note_history:13]
Capital Purchase Obligations

- removed (2019-11-14):
[0001045810-19-000144:note_history:14]
As of July 28, 2019, we had outstanding capital purchase obligations totaling $133 million.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-14):
[0001045810-19-000170:note_history:15]
Except for adopting a new accounting standard related to leases, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.
  (was, 2019-08-15, similarity 0.9117):
[0001045810-19-000144:note_history:15]
Except for the accounting policy for leases, which was updated as a result of adopting a new accounting standard related to leases, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.

- changed (2019-11-14):
[0001045810-19-000170:note_history:16]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The third quarters of fiscal years 2020 and 2019 were both 13-week quarters.
  (was, 2019-08-15, similarity 0.9759):
[0001045810-19-000144:note_history:16]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The second quarters of fiscal years 2020 and 2019 were both 13-week quarters.

- added (2019-11-14):
[0001045810-19-000170:note_history:17]
Recent Accounting Pronouncement Not Yet Adopted
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. We expect to adopt the standard using the modified retrospective transition method beginning in the first quarter of fiscal year 2021. While we are still evaluating the impact of this standard on our Consolidated Financial Statements, we do not currently believe it will have a material impact upon adoption.

- removed (2019-11-14):
[0001045810-19-000144:note_history:18]
Recent Accounting Pronouncement Not Yet Adopted

- removed (2019-11-14):
[0001045810-19-000144:note_history:19]
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. The standard will be effective for us beginning in the first quarter of fiscal year 2021, with early adoption permitted. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-14):
[0001045810-19-000170:note_history:20]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 27, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 1.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (10 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,990 |  |  | $ | 1,988 |  |
  (was, 2019-08-15, similarity 0.9849):
[0001045810-19-000144:note_history:20]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (11 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,989 |  |  | $ | 1,988 |  |

- changed (2019-11-14):
[0001045810-19-000170:note_history:21]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 27, 2019, we had not borrowed any amounts under this agreement.
  (was, 2019-08-15, similarity 0.9067):
[0001045810-19-000144:note_history:21]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 28, 2019, we had not borrowed any amounts under this agreement.

- changed (2019-11-14):
[0001045810-19-000170:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2019, we had not issued any commercial paper.
  (was, 2019-08-15, similarity 0.9609):
[0001045810-19-000144:note_history:22]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2019, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-14):
[0001045810-19-000170:note_history:23]
The following is a summary of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019:
  (was, 2019-08-15, similarity 0.9479):
[0001045810-19-000144:note_history:23]
The following is a summary of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019:

- added (2019-11-14):
[0001045810-19-000170:note_history:24]
|  | October 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 5,883 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,883 |  |  | $ | 5,883 |  |  | $ | — |  |
| Corporate debt securities | 1,293 |  |  | — |  |  | — |  |  | 1,293 |  |  | 1,293 |  |  | — |  |
| Debt securities of United States government agencies | 1,204 |  |  | — |  |  | — |  |  | 1,204 |  |  | 1,204 |  |  | — |  |
| Money market funds | 1,070 |  |  | — |  |  | — |  |  | 1,070 |  |  | 1,070 |  |  | — |  |
| Foreign government debt securities | 178 |  |  | — |  |  | — |  |  | 178 |  |  | 178 |  |  | — |  |
| Certificates of deposit | 25 |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |  | — |  |
| Asset-backed securities | 4 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total | $ | 9,657 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,657 |  |  | $ | 9,653 |  |  | $ | 4 |  |

- changed (2019-11-14):
[0001045810-19-000170:note_history:25]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019 are shown below by contractual maturity.
  (was, 2019-08-15, similarity 0.9662):
[0001045810-19-000144:note_history:25]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019 are shown below by contractual maturity.

- changed (2019-11-14):
[0001045810-19-000170:note_history:26]
|  | October 27, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | — |  |  | — |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | — |  |  | — |  |  | 22 |  |  | 22 |  |
| Total | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |
  (was, 2019-08-15, similarity 0.6509):
[0001045810-19-000144:note_history:26]
|  | July 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 8,255 |  |  | $ | 8,255 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 112 |  |  | 113 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 4 |  |  | 4 |  |  | 22 |  |  | 22 |  |
| Total | $ | 8,371 |  |  | $ | 8,372 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |

- removed (2019-11-14):
[0001045810-19-000144:note_history:27]
|  | July 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 2,868 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,868 |  |  | $ | 2,868 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 2,161 |  |  | — |  |  | — |  |  | 2,161 |  |  | 1,833 |  |  | 328 |  |
| Corporate debt securities | 2,103 |  |  | 1 |  |  | — |  |  | 2,104 |  |  | 1,282 |  |  | 822 |  |
| Debt securities of United States government agencies | 1,120 |  |  | — |  |  | — |  |  | 1,120 |  |  | 995 |  |  | 125 |  |
| Foreign government debt securities | 45 |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Asset-backed securities | 44 |  |  | — |  |  | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Certificates of deposit | 24 |  |  | — |  |  | — |  |  | 24 |  |  | 24 |  |  | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 6 |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total | $ | 8,371 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 8,372 |  |  | $ | 7,002 |  |  | $ | 1,370 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-14):
[0001045810-19-000170:note_history:28]
The following is a summary of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019:
  (was, 2019-08-15, similarity 0.9479):
[0001045810-19-000144:note_history:28]
The following is a summary of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019:

- added (2019-11-14):
[0001045810-19-000170:note_history:29]
|  | October 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 5,883 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,883 |  |  | $ | 5,883 |  |  | $ | — |  |
| Corporate debt securities | 1,293 |  |  | — |  |  | — |  |  | 1,293 |  |  | 1,293 |  |  | — |  |
| Debt securities of United States government agencies | 1,204 |  |  | — |  |  | — |  |  | 1,204 |  |  | 1,204 |  |  | — |  |
| Money market funds | 1,070 |  |  | — |  |  | — |  |  | 1,070 |  |  | 1,070 |  |  | — |  |
| Foreign government debt securities | 178 |  |  | — |  |  | — |  |  | 178 |  |  | 178 |  |  | — |  |
| Certificates of deposit | 25 |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |  | — |  |
| Asset-backed securities | 4 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total | $ | 9,657 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,657 |  |  | $ | 9,653 |  |  | $ | 4 |  |

- changed (2019-11-14):
[0001045810-19-000170:note_history:30]
For the third quarter and first nine months of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.
  (was, 2019-08-15, similarity 0.9321):
[0001045810-19-000144:note_history:30]
For the second quarter and first half of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.

- changed (2019-11-14):
[0001045810-19-000170:note_history:31]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019 are shown below by contractual maturity.
  (was, 2019-08-15, similarity 0.9662):
[0001045810-19-000144:note_history:31]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 28, 2019 and January 27, 2019 are shown below by contractual maturity.

- changed (2019-11-14):
[0001045810-19-000170:note_history:32]
|  | October 27, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | — |  |  | — |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | — |  |  | — |  |  | 22 |  |  | 22 |  |
| Total | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |
  (was, 2019-08-15, similarity 0.6509):
[0001045810-19-000144:note_history:32]
|  | July 28, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 8,255 |  |  | $ | 8,255 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | 112 |  |  | 113 |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 4 |  |  | 4 |  |  | 22 |  |  | 22 |  |
| Total | $ | 8,371 |  |  | $ | 8,372 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |

- removed (2019-11-14):
[0001045810-19-000144:note_history:33]
|  | July 28, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 2,868 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,868 |  |  | $ | 2,868 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 2,161 |  |  | — |  |  | — |  |  | 2,161 |  |  | 1,833 |  |  | 328 |  |
| Corporate debt securities | 2,103 |  |  | 1 |  |  | — |  |  | 2,104 |  |  | 1,282 |  |  | 822 |  |
| Debt securities of United States government agencies | 1,120 |  |  | — |  |  | — |  |  | 1,120 |  |  | 995 |  |  | 125 |  |
| Foreign government debt securities | 45 |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Asset-backed securities | 44 |  |  | — |  |  | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Certificates of deposit | 24 |  |  | — |  |  | — |  |  | 24 |  |  | 24 |  |  | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 6 |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total | $ | 8,371 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 8,372 |  |  | $ | 7,002 |  |  | $ | 1,370 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-14):
[0001045810-19-000170:note_history:34]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 27, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 1.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (10 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,990 |  |  | $ | 1,988 |  |
  (was, 2019-08-15, similarity 0.9849):
[0001045810-19-000144:note_history:34]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 28, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (11 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,989 |  |  | $ | 1,988 |  |
