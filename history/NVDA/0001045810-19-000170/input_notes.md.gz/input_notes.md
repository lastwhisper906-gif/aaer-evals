# NVDA notes — 0001045810-19-000170


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-19-000170:notes:1]
[same as prior period, unchanged from 0001045810-19-000144:notes:1]

[0001045810-19-000170:notes:2]
[same as prior period, unchanged from 0001045810-19-000144:notes:2]

[0001045810-19-000170:notes:3]
[same as prior period, unchanged from 0001045810-19-000144:notes:3]

[0001045810-19-000170:notes:4]
Except for adopting a new accounting standard related to leases, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 27, 2019.

[0001045810-19-000170:notes:5]
[same as prior period, unchanged from 0001045810-19-000144:notes:5]

[0001045810-19-000170:notes:6]
[same as prior period, unchanged from 0001045810-19-000144:notes:6]

[0001045810-19-000170:notes:7]
[same as prior period, unchanged from 0001045810-19-000144:notes:7]

[0001045810-19-000170:notes:8]
[same as prior period, unchanged from 0001045810-19-000144:notes:8]

[0001045810-19-000170:notes:9]
[same as prior period, unchanged from 0001045810-19-000144:notes:9]

[0001045810-19-000170:notes:10]
[same as prior period, unchanged from 0001045810-19-000144:notes:10]

[0001045810-19-000170:notes:11]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020 and 2019 are both 52-week years. The third quarters of fiscal years 2020 and 2019 were both 13-week quarters.

[0001045810-19-000170:notes:12]
[same as prior period, unchanged from 0001045810-19-000144:notes:12]

[0001045810-19-000170:notes:13]
[same as prior period, unchanged from 0001045810-19-000144:notes:13]

[0001045810-19-000170:notes:14]
[same as prior period, unchanged from 0001045810-19-000144:notes:14]

[0001045810-19-000170:notes:15]
[same as prior period, unchanged from 0001045810-19-000144:notes:15]

[0001045810-19-000170:notes:16]
[same as prior period, unchanged from 0001045810-19-000144:notes:16]

[0001045810-19-000170:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and

[0001045810-19-000170:notes:18]
other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-19-000170:notes:19]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000170:notes:20]
Recently Adopted Accounting Pronouncement

[0001045810-19-000170:notes:21]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases under which lease assets and liabilities are recognized on the balance sheet. We adopted this guidance on January 28, 2019 using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet. Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-19-000170:notes:22]
Recent Accounting Pronouncement Not Yet Adopted
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. We expect to adopt the standard using the modified retrospective transition method beginning in the first quarter of fiscal year 2021. While we are still evaluating the impact of this standard on our Consolidated Financial Statements, we do not currently believe it will have a material impact upon adoption.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-19-000170:notes:23]
Acquisition of Mellanox Technologies, Ltd.On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox Technologies Ltd., or Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. In June 2019, Mellanox shareholders approved the acquisition. The closing of the acquisition is subject to approval by regulatory agencies. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million. We have received regulatory approval in the United States and Mexico and are engaged with regulators in Europe and China. Although discussions with the European Union and China regulatory bodies are progressing and closing the acquisition is possible by the end of this calendar year, we believe the closing will likely occur in the early part of calendar 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-19-000170:notes:24]
[same as prior period, unchanged from 0001045810-19-000144:notes:25]

[0001045810-19-000170:notes:25]
[same as prior period, unchanged from 0001045810-19-000144:notes:26]

[0001045810-19-000170:notes:26]
[same as prior period, unchanged from 0001045810-19-000144:notes:27]

[0001045810-19-000170:notes:27]
[same as prior period, unchanged from 0001045810-19-000144:notes:28]

[0001045810-19-000170:notes:28]
[same as prior period, unchanged from 0001045810-19-000144:notes:29]

[0001045810-19-000170:notes:29]
Future minimum lease payments under our non-cancelable operating leases as of October 27, 2019, are as follows:

[0001045810-19-000170:notes:30]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2020 (excluding first nine months of fiscal year 2020) | $ | 28 |  |
| 2021 | 112 |  |
| 2022 | 104 |  |
| 2023 | 83 |  |
| 2024 | 60 |  |
| 2025 and thereafter | 282 |  |
| Total | 669 |  |
| Less imputed interest | 111 |  |
| Present value of net future minimum lease payments | 558 |  |
| Less short-term operating lease liabilities | 89 |  |
| Long-term operating lease liabilities | $ | 469 |  |

[0001045810-19-000170:notes:31]
In addition to our existing operating lease obligations, we have entered into an operating lease that will commence in fiscal year 2021 with a lease term of 7 years for $62 million.

[0001045810-19-000170:notes:32]
[same as prior period, unchanged from 0001045810-19-000144:notes:32]

[0001045810-19-000170:notes:33]
[same as prior period, unchanged from 0001045810-19-000144:notes:33]

[0001045810-19-000170:notes:34]
Operating lease expense for the third quarter and first nine months of fiscal year 2020 was $28 million and $83 million, respectively. Operating lease expense for the third quarter and first nine months of fiscal year 2019 was $22 million and $58 million, respectively. Short-term and variable lease expenses for the third quarter and first nine months of fiscal year 2020 were not significant.

[0001045810-19-000170:notes:35]
[same as prior period, unchanged from 0001045810-19-000144:notes:35]

[0001045810-19-000170:notes:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, 2019 |  | October 27, 2019 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 28 |  |  | $ | 78 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 14 |  |  | $ | 122 |  |

[0001045810-19-000170:notes:37]
As of October 27, 2019, our operating leases had a weighted average remaining lease term of 8.5 years and a weighted average discount rate of 3.68%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-19-000170:notes:38]
[same as prior period, unchanged from 0001045810-19-000144:notes:38]

[0001045810-19-000170:notes:39]
[same as prior period, unchanged from 0001045810-19-000144:notes:39]

[0001045810-19-000170:notes:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, 2019 |  | October 28, 2018 |  | October 27, 2019 |  | October 28, 2018 |
|  | (In millions) |
| Cost of revenue | $ | 15 |  |  | $ | 5 |  |  | $ | 27 |  |  | $ | 21 |  |
| Research and development | 141 |  |  | 88 |  |  | 400 |  |  | 237 |  |
| Sales, general and administrative | 67 |  |  | 47 |  |  | 197 |  |  | 142 |  |
| Total | $ | 223 |  |  | $ | 140 |  |  | $ | 624 |  |  | $ | 400 |  |

[0001045810-19-000170:notes:41]
[same as prior period, unchanged from 0001045810-19-000144:notes:41]

[0001045810-19-000170:notes:42]
[same as prior period, unchanged from 0001045810-19-000144:notes:42]

[0001045810-19-000170:notes:43]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balances, January 27, 2019 | 16 |  |  | $ | 129.92 |  |
| Granted (1) (2) | 7 |  |  | $ | 182.62 |  |
| Vested restricted stock | (7 | ) |  | $ | 85.22 |  |
| Canceled and forfeited | (1 | ) |  | $ | 186.34 |  |
| Balances, October 27, 2019 | 15 |  |  | $ | 173.01 |  |

[0001045810-19-000170:notes:44]
[same as prior period, unchanged from 0001045810-19-000144:notes:44]

[0001045810-19-000170:notes:45]
[same as prior period, unchanged from 0001045810-19-000144:notes:45]

[0001045810-19-000170:notes:46]
As of October 27, 2019, there was $1.95 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and 1.0 year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-19-000170:notes:47]
[same as prior period, unchanged from 0001045810-19-000144:notes:47]

[0001045810-19-000170:notes:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, |  | October 28, |  | October 27, |  | October 28, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 899 |  |  | $ | 1,230 |  |  | $ | 1,845 |  |  | $ | 3,575 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 610 |  |  | 609 |  |  | 609 |  |  | 608 |  |
| Dilutive impact of outstanding equity awards | 8 |  |  | 16 |  |  | 8 |  |  | 18 |  |
| Diluted weighted average shares | 618 |  |  | 625 |  |  | 617 |  |  | 626 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.47 |  |  | $ | 2.02 |  |  | $ | 3.03 |  |  | $ | 5.88 |  |
| Diluted (2) | $ | 1.45 |  |  | $ | 1.97 |  |  | $ | 2.99 |  |  | $ | 5.71 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 5 |  |  | 3 |  |  | 11 |  |  | 4 |  |

[0001045810-19-000170:notes:49]
[same as prior period, unchanged from 0001045810-19-000144:notes:49]

[0001045810-19-000170:notes:50]
[same as prior period, unchanged from 0001045810-19-000144:notes:50]

[0001045810-19-000170:notes:51]
[same as prior period, unchanged from 0001045810-19-000144:notes:51]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-19-000170:notes:52]
Income Taxes
We recognized an income tax expense of $60 million and $109 million for the third quarter and first nine months of fiscal year 2020, respectively, and an income tax benefit of $149 million and $3 million for the third quarter and first nine months of fiscal year 2019, respectively. The income tax expense as a percentage of income before income tax was 6.3% and 5.6% for the third quarter and first nine months of fiscal year 2020, respectively, and income tax benefit as a percentage of income before income tax was 13.8% and nominal for the third quarter and first nine months of fiscal year 2019, respectively.

[0001045810-19-000170:notes:53]
The increase in our effective tax rate for the third quarter and first nine months of fiscal year 2020 as compared to the third quarter and first nine months of fiscal year 2019 was primarily due to a decrease of tax benefits from stock-based compensation and an absence of the tax benefit related to the reduction in our provisional U.S. tax reform transition tax amount.

[0001045810-19-000170:notes:54]
Our effective tax rates for the first nine months of fiscal years 2020 and 2019 were 5.6% and nominal, respectively, and were lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, the benefit of the U.S. federal research tax credit, and for fiscal year 2019, the reduction in our provisional U.S. tax reform transition tax amount.

[0001045810-19-000170:notes:55]
For the first nine months of fiscal year 2020, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 27, 2019.

[0001045810-19-000170:notes:56]
[same as prior period, unchanged from 0001045810-19-000144:notes:56]

[0001045810-19-000170:notes:57]
resolved with the respective tax authorities. As of October 27, 2019, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-19-000170:notes:58]
Marketable Securities 
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-19-000170:notes:59]
The following is a summary of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019:

[0001045810-19-000170:notes:60]
|  | October 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 5,883 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,883 |  |  | $ | 5,883 |  |  | $ | — |  |
| Corporate debt securities | 1,293 |  |  | — |  |  | — |  |  | 1,293 |  |  | 1,293 |  |  | — |  |
| Debt securities of United States government agencies | 1,204 |  |  | — |  |  | — |  |  | 1,204 |  |  | 1,204 |  |  | — |  |
| Money market funds | 1,070 |  |  | — |  |  | — |  |  | 1,070 |  |  | 1,070 |  |  | — |  |
| Foreign government debt securities | 178 |  |  | — |  |  | — |  |  | 178 |  |  | 178 |  |  | — |  |
| Certificates of deposit | 25 |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |  | — |  |
| Asset-backed securities | 4 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total | $ | 9,657 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,657 |  |  | $ | 9,653 |  |  | $ | 4 |  |

[0001045810-19-000170:notes:61]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government debt securities | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

[0001045810-19-000170:notes:62]
For the third quarter and first nine months of fiscal years 2020 and 2019, there were no other-than-temporary impairment losses and net realized gains were not significant.

[0001045810-19-000170:notes:63]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 27, 2019 and January 27, 2019 are shown below by contractual maturity.

[0001045810-19-000170:notes:64]
|  | October 27, 2019 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | — |  |  | — |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | — |  |  | — |  |  | 22 |  |  | 22 |  |
| Total | $ | 9,657 |  |  | $ | 9,657 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-19-000170:notes:65]
[same as prior period, unchanged from 0001045810-19-000144:notes:65]

[0001045810-19-000170:notes:66]
|  |  | Fair Value at |
|  | Pricing Category |  | October 27, 2019 |  | January 27, 2019 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 5,883 |  |  | $ | 1,492 |  |
| Corporate debt securities | Level 2 |  | $ | 1,293 |  |  | $ | 2,620 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,204 |  |  | $ | 2,280 |  |
| Money market funds | Level 1 |  | $ | 1,070 |  |  | $ | 483 |  |
| Foreign government debt securities | Level 2 |  | $ | 178 |  |  | $ | 209 |  |
| Certificates of deposit | Level 2 |  | $ | 25 |  |  | $ | — |  |
| Asset-backed securities | Level 2 |  | $ | 4 |  |  | $ | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | — |  |  | $ | 89 |  |
| Liabilities |  |  |  |  |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 1,003 |  |  | $ | 978 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 1,051 |  |  | $ | 961 |  |

[0001045810-19-000170:notes:67]
(1)     These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance   costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-19-000170:notes:68]
[same as prior period, unchanged from 0001045810-19-000144:notes:69]

[0001045810-19-000170:notes:69]
|  | October 27, 2019 |  | January 27, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (191 | ) |  | $ | 4 |  |  | $ | 195 |  |  | $ | (188 | ) |  | $ | 7 |  |
| Patents and licensed technology | 508 |  |  | (469 | ) |  | 39 |  |  | 491 |  |  | (453 | ) |  | 38 |  |
| Total intangible assets | $ | 703 |  |  | $ | (660 | ) |  | $ | 43 |  |  | $ | 686 |  |  | $ | (641 | ) |  | $ | 45 |  |

[0001045810-19-000170:notes:70]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during the first nine months of fiscal year 2020. Amortization expense associated with intangible assets was $6 million and $19 million for the third quarter and first nine months of fiscal year 2020, respectively, and $7 million and $24 million for the third quarter and first nine months of fiscal year 2019, respectively. Future amortization expense related to the net carrying amount of intangible assets as of October 27, 2019 is estimated to be $6 million for the remainder of fiscal year 2020, $16 million in fiscal year 2021, $9 million in fiscal year 2022, $7 million in fiscal year 2023, and $5 million in fiscal year 2024.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-19-000170:notes:71]
[same as prior period, unchanged from 0001045810-19-000144:notes:72]

[0001045810-19-000170:notes:72]
|  | October 27, |  | January 27, |
|  | 2019 |  | 2019 |
| Inventories: | (In millions) |
| Raw materials | $ | 255 |  |  | $ | 613 |  |
| Work in-process | 265 |  |  | 238 |  |
| Finished goods | 527 |  |  | 724 |  |
| Total inventories | $ | 1,047 |  |  | $ | 1,575 |  |

[0001045810-19-000170:notes:73]
|  | October 27, |  | January 27, |
|  | 2019 |  | 2019 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 353 |  |  | $ | 302 |  |
| Accrued payroll and related expenses | 155 |  |  | 186 |  |
| Deferred revenue (1) | 119 |  |  | 92 |  |
| Operating lease liabilities | 89 |  |  | — |  |
| Taxes payable | 52 |  |  | 91 |  |
| Licenses payable | 18 |  |  | 12 |  |
| Professional service fee | 18 |  |  | 14 |  |
| Other | 80 |  |  | 121 |  |
| Total accrued and other current liabilities | $ | 884 |  |  | $ | 818 |  |

[0001045810-19-000170:notes:74]
[same as prior period, unchanged from 0001045810-19-000144:notes:75]

[0001045810-19-000170:notes:75]
|  | October 27, |  | January 27, |
|  | 2019 |  | 2019 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 511 |  |  | $ | 513 |  |
| Deferred revenue (2) | 57 |  |  | 46 |  |
| Deferred income tax liability | 25 |  |  | 19 |  |
| Licenses payable | 22 |  |  | 1 |  |
| Employee benefits liability | 22 |  |  | 20 |  |
| Deferred rent | — |  |  | 21 |  |
| Other | 25 |  |  | 13 |  |
| Total other long-term liabilities | $ | 662 |  |  | $ | 633 |  |

[0001045810-19-000170:notes:76]
| (1) | As of October 27, 2019, represents the long-term portion of the one-time transition tax payable of $317 million, as well as unrecognized tax benefits of $168 million and related interest and penalties of $26 million. |

[0001045810-19-000170:notes:77]
[same as prior period, unchanged from 0001045810-19-000144:notes:78]

[0001045810-19-000170:notes:78]
[same as prior period, unchanged from 0001045810-19-000144:notes:79]

[0001045810-19-000170:notes:79]
The following table shows the changes in deferred revenue during the first nine months of fiscal years 2020 and 2019.

[0001045810-19-000170:notes:80]
|  | October 27, |  | October 28, |
|  | 2019 |  | 2018 |
|  | (In millions) |
| Balance, January 27, 2019 | $ | 138 |  |  | $ | 63 |  |
| Deferred revenue added during the period | 237 |  |  | 271 |  |
| Revenue recognized during the period | (199 | ) |  | (214 | ) |
| Balance, October 27, 2019 | $ | 176 |  |  | $ | 120 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-19-000170:notes:81]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of October 27, 2019 and January 27, 2019.

[0001045810-19-000170:notes:82]
[same as prior period, unchanged from 0001045810-19-000144:notes:83]

[0001045810-19-000170:notes:83]
The table below presents the notional value of our foreign currency forward contracts outstanding as of October 27, 2019 and January 27, 2019:

[0001045810-19-000170:notes:84]
|  | October 27, 2019 |  | January 27, 2019 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 421 |  |  | $ | 408 |  |
| Not designated for hedge accounting | $ | 258 |  |  | $ | 241 |  |

[0001045810-19-000170:notes:85]
As of October 27, 2019, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-19-000170:notes:86]
During the third quarter and first nine months of fiscal years 2020 and 2019, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-19-000170:notes:87]
Debt
Long-Term Debt

[0001045810-19-000170:notes:88]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-19-000170:notes:89]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-19-000170:notes:90]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-19-000170:notes:91]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-19-000170:notes:92]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 27, 2019 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 1.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (10 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,990 |  |  | $ | 1,988 |  |

[0001045810-19-000170:notes:93]
Revolving Credit Facility

[0001045810-19-000170:notes:94]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 27, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000170:notes:95]
Commercial Paper

[0001045810-19-000170:notes:96]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2019, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-19-000170:notes:97]
Commitments and Contingencies
Purchase Obligations

[0001045810-19-000170:notes:98]
As of October 27, 2019, we had outstanding inventory purchase obligations totaling $980 million and other purchase obligations totaling $138 million.

[0001045810-19-000170:notes:99]
Performance Obligations

[0001045810-19-000170:notes:100]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of October 27, 2019, the amount of our remaining performance

[0001045810-19-000170:notes:101]
obligations that has not been recognized as revenue was $395 million, of which we expect to recognize approximately 47% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-19-000170:notes:102]
Accrual for Product Warranty Liabilities

[0001045810-19-000170:notes:103]
The estimated amount of product returns and warranty liabilities was $17 million and $18 million as of October 27, 2019 and January 27, 2019, respectively, and the activity related to the warranty liabilities were not significant.

[0001045810-19-000170:notes:104]
In connection with certain agreements that we have entered in the past, we have provided indemnification to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-19-000170:notes:105]
Litigation

[0001045810-19-000170:notes:106]
Securities Class Action and Derivative Lawsuits

[0001045810-19-000170:notes:107]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

[0001045810-19-000170:notes:108]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-19-000170:notes:109]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and

[0001045810-19-000170:notes:110]
the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-19-000170:notes:111]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-19-000170:notes:112]
Litigation Related to Acquisition of Mellanox

[0001045810-19-000170:notes:113]
On May 3, 2019, an alleged stockholder of Mellanox filed a putative class action lawsuit alleging that the proxy statement filed by Mellanox in connection with the stockholder vote on NVIDIA’s pending acquisition of Mellanox violates Sections 14(a) and 20(a) of the Exchange Act and asserting claims under those statutes against Mellanox and its board of directors as well as NVIDIA. The complaint, which is captioned Stein v. Mellanox Technologies, Ltd., et al., Case No. 19-2428 (United States District Court, Northern District of California), seeks declaratory and injunctive relief and unspecified damages. A number of other alleged Mellanox stockholders have filed substantially similar lawsuits against Mellanox and its directors in the United States District Court for the Northern District of California and in the United States District Court for the Southern District of New York, but NVIDIA was not named as a defendant in any of these other lawsuits.  As of October 14, 2019, all stockholder lawsuits relating to NVIDIA’s pending acquisition of Mellanox, including the Stein lawsuit, had been voluntarily dismissed by the respective plaintiffs.

[0001045810-19-000170:notes:114]
Accounting for Loss Contingencies

[0001045810-19-000170:notes:115]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of October 27, 2019, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-19-000170:notes:116]
[same as prior period, unchanged from 0001045810-19-000144:notes:116]

[0001045810-19-000170:notes:117]
[same as prior period, unchanged from 0001045810-19-000144:notes:117]

[0001045810-19-000170:notes:118]
During the third quarter and first nine months of fiscal year 2020, we paid $98 million and $292 million, respectively, in cash dividends to our shareholders.

[0001045810-19-000170:notes:119]
Through October 27, 2019, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of October 27, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000170:notes:120]
[same as prior period, unchanged from 0001045810-19-000144:notes:120]

[0001045810-19-000170:notes:121]
As of October 27, 2019 and January 27, 2019, there were no shares of preferred stock outstanding.

[0001045810-19-000170:notes:122]
[same as prior period, unchanged from 0001045810-19-000144:notes:122]

[0001045810-19-000170:notes:123]
[same as prior period, unchanged from 0001045810-19-000144:notes:123]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-19-000170:notes:124]
[same as prior period, unchanged from 0001045810-19-000144:notes:124]

[0001045810-19-000170:notes:125]
[same as prior period, unchanged from 0001045810-19-000144:notes:125]

[0001045810-19-000170:notes:126]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for artificial intelligence, data scientists and big data researchers; and GRID for cloud-based visual computing users.

[0001045810-19-000170:notes:127]
Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for game consoles and mobile gaming and entertainment devices.

[0001045810-19-000170:notes:128]
Under the single unifying architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-19-000170:notes:129]
[same as prior period, unchanged from 0001045810-19-000144:notes:129]

[0001045810-19-000170:notes:130]
[same as prior period, unchanged from 0001045810-19-000144:notes:130]

[0001045810-19-000170:notes:131]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 27, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 2,565 |  |  | $ | 449 |  |  | $ | — |  |  | $ | 3,014 |  |
| Depreciation and amortization expense | $ | 78 |  |  | $ | 10 |  |  | $ | 4 |  |  | $ | 92 |  |
| Operating income (loss) | $ | 1,135 |  |  | $ | 85 |  |  | $ | (293 | ) |  | $ | 927 |  |
| Three Months Ended October 28, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,774 |  |  | $ | 407 |  |  | $ | — |  |  | $ | 3,181 |  |
| Depreciation and amortization expense | $ | 51 |  |  | $ | 13 |  |  | $ | 4 |  |  | $ | 68 |  |
| Operating income (loss) | $ | 1,214 |  |  | $ | 72 |  |  | $ | (228 | ) |  | $ | 1,058 |  |
| Nine Months Ended October 27, 2019 |  |  |  |  |  |  |  |
| Revenue | $ | 6,691 |  |  | $ | 1,122 |  |  | $ | — |  |  | $ | 7,813 |  |
| Depreciation and amortization expense | $ | 230 |  |  | $ | 34 |  |  | $ | 11 |  |  | $ | 275 |  |
| Operating income (loss) | $ | 2,550 |  |  | $ | 163 |  |  | $ | (857 | ) |  | $ | 1,856 |  |
| Nine Months Ended October 28, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 8,195 |  |  | $ | 1,316 |  |  | $ | — |  |  | $ | 9,511 |  |
| Depreciation and amortization expense | $ | 134 |  |  | $ | 35 |  |  | $ | 15 |  |  | $ | 184 |  |
| Operating income (loss) | $ | 3,867 |  |  | $ | 266 |  |  | $ | (623 | ) |  | $ | 3,510 |  |

[0001045810-19-000170:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, 2019 |  | October 28, 2018 |  | October 27, 2019 |  | October 28, 2018 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (223 | ) |  | $ | (140 | ) |  | $ | (624 | ) |  | $ | (400 | ) |
| Unallocated cost of revenue and operating expenses | (63 | ) |  | (76 | ) |  | (198 | ) |  | (205 | ) |
| Acquisition-related and other costs | (7 | ) |  | 3 |  |  | (22 | ) |  | (1 | ) |
| Legal settlement costs | — |  |  | (15 | ) |  | (13 | ) |  | (17 | ) |
| Total | $ | (293 | ) |  | $ | (228 | ) |  | $ | (857 | ) |  | $ | (623 | ) |

[0001045810-19-000170:notes:133]
[same as prior period, unchanged from 0001045810-19-000144:notes:133]

[0001045810-19-000170:notes:134]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, |  | October 28, |  | October 27, |  | October 28, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 838 |  |  | $ | 929 |  |  | $ | 2,171 |  |  | $ | 2,739 |  |
| Other Asia Pacific | 805 |  |  | 742 |  |  | 1,983 |  |  | 2,001 |  |
| China (including Hong Kong) | 758 |  |  | 704 |  |  | 1,894 |  |  | 2,218 |  |
| United States | 236 |  |  | 407 |  |  | 589 |  |  | 1,254 |  |
| Europe | 216 |  |  | 230 |  |  | 753 |  |  | 699 |  |
| Other countries | 161 |  |  | 169 |  |  | 423 |  |  | 600 |  |
| Total revenue | $ | 3,014 |  |  | $ | 3,181 |  |  | $ | 7,813 |  |  | $ | 9,511 |  |

[0001045810-19-000170:notes:135]
[same as prior period, unchanged from 0001045810-19-000144:notes:135]

[0001045810-19-000170:notes:136]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, |  | October 28, |  | October 27, |  | October 28, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,659 |  |  | $ | 1,764 |  |  | $ | 4,027 |  |  | $ | 5,292 |  |
| Professional Visualization | 324 |  |  | 305 |  |  | 881 |  |  | 837 |  |
| Data Center | 726 |  |  | 792 |  |  | 2,015 |  |  | 2,253 |  |
| Automotive | 162 |  |  | 172 |  |  | 537 |  |  | 478 |  |
| OEM and Other | 143 |  |  | 148 |  |  | 353 |  |  | 651 |  |
| Total revenue | $ | 3,014 |  |  | $ | 3,181 |  |  | $ | 7,813 |  |  | $ | 9,511 |  |

[0001045810-19-000170:notes:137]
One customer represented approximately 10% of our total revenue for the third quarter and approximately 11% of our total revenue for the first nine months of fiscal year 2020, and was attributable primarily to the GPU business. No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal year 2019.

[0001045810-19-000170:notes:138]
One customer represented approximately 24% of our accounts receivable balance as of October 27, 2019, and one customer represented approximately 19% of our accounts receivable balance as of January 27, 2019.
