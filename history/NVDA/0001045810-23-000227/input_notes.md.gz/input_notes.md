# NVDA notes — 0001045810-23-000227


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-23-000227:notes:1]
[same as prior period, unchanged from 0001045810-23-000175:notes:1]

[0001045810-23-000227:notes:2]
[same as prior period, unchanged from 0001045810-23-000175:notes:2]

[0001045810-23-000227:notes:3]
[same as prior period, unchanged from 0001045810-23-000175:notes:3]

[0001045810-23-000227:notes:4]
[same as prior period, unchanged from 0001045810-23-000175:notes:4]

[0001045810-23-000227:notes:5]
[same as prior period, unchanged from 0001045810-23-000175:notes:5]

[0001045810-23-000227:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The third quarters of fiscal years 2024 and 2023 were both 13-week quarters.

[0001045810-23-000227:notes:7]
[same as prior period, unchanged from 0001045810-23-000175:notes:7]

[0001045810-23-000227:notes:8]
[same as prior period, unchanged from 0001045810-23-000175:notes:8]

[0001045810-23-000227:notes:9]
[same as prior period, unchanged from 0001045810-23-000175:notes:9]

[0001045810-23-000227:notes:10]
[same as prior period, unchanged from 0001045810-23-000175:notes:10]

[0001045810-23-000227:notes:11]
[same as prior period, unchanged from 0001045810-23-000175:notes:11]

[0001045810-23-000227:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-23-000227:notes:13]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the estimated effect of this change for the three months ended October 29, 2023 was a benefit of $17 million and $24 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $41 million and net income of $36 million after tax, or $0.01 per both basic and diluted share. The estimated effect of this change for the first nine months of fiscal year 2024 was a benefit of $24 million and $83 million 
for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $107 million and net income of $91 million after tax, or $0.04 per both basic and diluted share.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-23-000227:notes:14]
Business Combination
Termination of the Arm Share Purchase Agreement

[0001045810-23-000227:notes:15]
In February 2022, NVIDIA and SoftBank Group Corp, or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited, or Arm, from SoftBank. The parties agreed to terminate due to significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-23-000227:notes:16]
[same as prior period, unchanged from 0001045810-23-000175:notes:15]

[0001045810-23-000227:notes:17]
Future minimum lease payments under our non-cancelable operating leases as of October 29, 2023 are as follows:

[0001045810-23-000227:notes:18]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first nine months of fiscal year 2024) | $ | 84 |  |
| 2025 | 269 |  |
| 2026 | 248 |  |
| 2027 | 233 |  |
| 2028 | 220 |  |
| 2029 and thereafter | 454 |  |
| Total | 1,508 |  |
| Less imputed interest | 187 |  |
| Present value of net future minimum lease payments | 1,321 |  |
| Less short-term operating lease liabilities | 230 |  |
| Long-term operating lease liabilities | $ | 1,091 |  |

[0001045810-23-000227:notes:19]
In addition, we have operating leases, primarily for our data centers, that are expected to commence between the fourth quarter of fiscal year 2024 and fiscal year 2025 with lease terms of 3 to 10 years for $924 million.

[0001045810-23-000227:notes:20]
Operating lease expenses were $69 million and $49 million for the third quarter of fiscal years 2024 and 2023, respectively, and $195 million and $139 million for the first nine months of fiscal years 2024 and 2023, respectively. Short-term and variable lease expenses for the third quarter and first nine months of fiscal years 2024 and 2023 were not significant.

[0001045810-23-000227:notes:21]
[same as prior period, unchanged from 0001045810-23-000175:notes:20]

[0001045810-23-000227:notes:22]
|  | Nine Months Ended |
|  | October 29, 2023 |  | October 30, 2022 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 200 |  |  | $ | 134 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 439 |  |  | $ | 213 |  |

[0001045810-23-000227:notes:23]
As of October 29, 2023, our operating leases had a weighted average remaining lease term of 6.3 years and a weighted average discount rate of 3.64%. As of January 29, 2023, our operating leases had a weighted average remaining lease term of 6.8 years and a weighted average discount rate of 3.21%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-23-000227:notes:24]
[same as prior period, unchanged from 0001045810-23-000175:notes:23]

[0001045810-23-000227:notes:25]
[same as prior period, unchanged from 0001045810-23-000175:notes:24]

[0001045810-23-000227:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
|  | (In millions) |
| Cost of revenue | $ | 38 |  |  | $ | 32 |  |  | $ | 96 |  |  | $ | 108 |  |
| Research and development | 701 |  |  | 530 |  |  | 1,826 |  |  | 1,365 |  |
| Sales, general and administrative | 240 |  |  | 183 |  |  | 633 |  |  | 498 |  |
| Total | $ | 979 |  |  | $ | 745 |  |  | $ | 2,555 |  |  | $ | 1,971 |  |

[0001045810-23-000227:notes:27]
[same as prior period, unchanged from 0001045810-23-000175:notes:26]

[0001045810-23-000227:notes:28]
[same as prior period, unchanged from 0001045810-23-000175:notes:27]

[0001045810-23-000227:notes:29]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 29, 2023 | 45 |  |  | $ | 158.45 |  |  |  |  |  |
| Granted | 13 |  |  | $ | 364.52 |  |  |  |  |  |
| Vested | (16) |  |  | $ | 141.02 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 201.49 |  |  |  |  |  |
| Balances, October 29, 2023 | 41 |  |  | $ | 230.11 |  |  |  |  |  |

[0001045810-23-000227:notes:30]
As of October 29, 2023, there was $9.03 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and 11 months for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-23-000227:notes:31]
[same as prior period, unchanged from 0001045810-23-000175:notes:30]

[0001045810-23-000227:notes:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 9,243 |  |  | $ | 680 |  |  | $ | 17,475 |  |  | $ | 2,954 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,468 |  |  | 2,483 |  |  | 2,470 |  |  | 2,495 |  |
| Dilutive impact of outstanding equity awards | 26 |  |  | 16 |  |  | 24 |  |  | 22 |  |
| Diluted weighted average shares | 2,494 |  |  | 2,499 |  |  | 2,494 |  |  | 2,517 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 3.75 |  |  | $ | 0.27 |  |  | $ | 7.07 |  |  | $ | 1.18 |  |
| Diluted (2) | $ | 3.71 |  |  | $ | 0.27 |  |  | $ | 7.01 |  |  | $ | 1.17 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 1 |  |  | 36 |  |  | 14 |  |  | 29 |  |

[0001045810-23-000227:notes:33]
[same as prior period, unchanged from 0001045810-23-000175:notes:32]

[0001045810-23-000227:notes:34]
[same as prior period, unchanged from 0001045810-23-000175:notes:33]

[0001045810-23-000227:notes:35]
Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Any anti-dilutive effect of equity awards outstanding is not included in the computation of diluted net income per share.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-23-000227:notes:36]
Income Taxes
Income tax was an expense of $1.28 billion and $2.24 billion for the third quarter and first nine months of fiscal year 2024, respectively, and a benefit of $67 million and $61 million for the third quarter and first nine months of fiscal year 2023, respectively. Income tax as a percentage of income before income tax was an expense of 12.2% and 11.3% for the third quarter and first nine months of fiscal year 2024, respectively, and a benefit of 10.9% and 2.1% for the third quarter and first nine months of fiscal year 2023, respectively.

[0001045810-23-000227:notes:37]
During the third quarter of fiscal year 2024, the Internal Revenue Service, or IRS, audit of our federal income tax returns for fiscal years 2018 and 2019 was resolved. We recognized a non-cash net benefit of $145 million, related to this IRS audit resolution, for effectively settled positions. This benefit consists of a reduction in unrecognized tax benefits of $236 million and related accrued interest of $17 million, net of federal benefit partially offset by additional cash tax payments and reductions in tax attribute carryforwards of $108 million.

[0001045810-23-000227:notes:38]
The effective tax rate increased due to a decreased impact of tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit, relative to the increase in income before income tax. The increase in the effective tax rate was partially offset by a benefit due to the IRS audit resolution.

[0001045810-23-000227:notes:39]
Our effective tax rates for the first nine months of fiscal years 2024 and 2023 were lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation and the U.S. federal research tax credit. Our effective tax rate for the first nine months of fiscal year 2024 was additionally benefited by the IRS audit resolution.
Other than the IRS audit resolution, for the first nine months of fiscal year 2024, there were no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 29, 2023. While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 29, 2023, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-23-000227:notes:40]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-23-000227:notes:41]
The following is a summary of cash equivalents and marketable securities:

[0001045810-23-000227:notes:42]
|  | October 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,937 |  |  | $ | 1 |  |  | $ | (20) |  |  | $ | 6,918 |  |  | $ | 1,714 |  |  | $ | 5,204 |  |
| Debt securities issued by the U.S. Treasury | 5,075 |  |  | 1 |  |  | (24) |  |  | 5,052 |  |  | — |  |  | 5,052 |  |
| Money market funds | 3,190 |  |  | — |  |  | — |  |  | 3,190 |  |  | 3,190 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,316 |  |  | — |  |  | (5) |  |  | 2,311 |  |  | 100 |  |  | 2,211 |  |
| Certificates of deposit | 418 |  |  | — |  |  | — |  |  | 418 |  |  | 198 |  |  | 220 |  |
| Foreign government bonds | 175 |  |  | — |  |  | — |  |  | 175 |  |  | 100 |  |  | 75 |  |
| Total | $ | 18,111 |  |  | $ | 2 |  |  | $ | (49) |  |  | $ | 18,064 |  |  | $ | 5,302 |  |  | $ | 12,762 |  |

[0001045810-23-000227:notes:43]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

[0001045810-23-000227:notes:44]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-23-000227:notes:45]
|  | October 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Corporate debt securities | $ | 2,773 |  |  | $ | (16) |  |  | $ | 852 |  |  | $ | (4) |  |  | $ | 3,625 |  |  | $ | (20) |  |
| Debt securities issued by the U.S. Treasury | 2,098 |  |  | (12) |  |  | 1,371 |  |  | (12) |  |  | 3,469 |  |  | (24) |  |
| Debt securities issued by U.S. government agencies | 1,447 |  |  | (5) |  |  | — |  |  | — |  |  | 1,447 |  |  | (5) |  |
| Total | $ | 6,318 |  |  | $ | (33) |  |  | $ | 2,223 |  |  | $ | (16) |  |  | $ | 8,541 |  |  | $ | (49) |  |

[0001045810-23-000227:notes:46]
|  | January 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 2,444 |  |  | $ | (21) |  |  | $ | 1,172 |  |  | $ | (23) |  |  | $ | 3,616 |  |  | $ | (44) |  |
| Corporate debt securities | 1,188 |  |  | (7) |  |  | 696 |  |  | (5) |  |  | 1,884 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,307 |  |  | (2) |  |  | — |  |  | — |  |  | 1,307 |  |  | (2) |  |
| Total | $ | 4,939 |  |  | $ | (30) |  |  | $ | 1,868 |  |  | $ | (28) |  |  | $ | 6,807 |  |  | $ | (58) |  |

[0001045810-23-000227:notes:47]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

[0001045810-23-000227:notes:48]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-23-000227:notes:49]
|  | October 29, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,405 |  |  | $ | 11,388 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 6,706 |  |  | 6,676 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 18,111 |  |  | $ | 18,064 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-23-000227:notes:50]
[same as prior period, unchanged from 0001045810-23-000175:notes:50]

[0001045810-23-000227:notes:51]
|  |  | Fair Value at |
|  | Pricing Category |  | October 29, 2023 |  | January 29, 2023 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 3,190 |  |  | $ | 1,777 |  |
| Corporate debt securities | Level 2 |  | $ | 6,918 |  |  | $ | 4,797 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 5,052 |  |  | $ | 4,142 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,311 |  |  | $ | 1,834 |  |
| Certificates of deposit | Level 2 |  | $ | 418 |  |  | $ | 365 |  |
| Foreign government bonds | Level 2 |  | $ | 175 |  |  | $ | 140 |  |
| Other assets (Investments in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities | Level 1 |  | $ | 153 |  |  | $ | 11 |  |
| Privately-held equity securities | Level 3 |  | $ | 1,019 |  |  | $ | 288 |  |
| Liabilities (1) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | — |  |  | $ | 1,230 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,212 |  |  | $ | 1,185 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 945 |  |  | $ | 966 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,060 |  |  | $ | 1,099 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,289 |  |  | $ | 1,364 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 981 |  |  | $ | 1,044 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 756 |  |  | $ | 870 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,388 |  |  | $ | 1,637 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 342 |  |  | $ | 410 |  |

[0001045810-23-000227:notes:52]
[same as prior period, unchanged from 0001045810-23-000175:notes:52]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-23-000227:notes:53]
Amortizable Intangible Assets and Goodwill
The components of our amortizable intangible assets are as follows:

[0001045810-23-000227:notes:54]
|  | October 29, 2023 |  | January 29, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 2,642 |  |  | $ | (1,584) |  |  | $ | 1,058 |  |  | $ | 3,093 |  |  | $ | (1,614) |  |  | $ | 1,479 |  |
| Patents and licensed technology | 450 |  |  | (257) |  |  | 193 |  |  | 446 |  |  | (249) |  |  | 197 |  |
| Total intangible assets | $ | 3,092 |  |  | $ | (1,841) |  |  | $ | 1,251 |  |  | $ | 3,539 |  |  | $ | (1,863) |  |  | $ | 1,676 |  |

[0001045810-23-000227:notes:55]
Amortization expense associated with intangible assets was $144 million and $471 million for the third quarter and first nine months of fiscal year 2024, respectively, and $181 million and $518 million for the third quarter and first nine months of fiscal year 2023, respectively.

[0001045810-23-000227:notes:56]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of October 29, 2023:

[0001045810-23-000227:notes:57]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first nine months of fiscal year 2024) | $ | 143 |  |
| 2025 | 554 |  |
| 2026 | 259 |  |
| 2027 | 149 |  |
| 2028 | 37 |  |
| 2029 and thereafter | 109 |  |
| Total | $ | 1,251 |  |

[0001045810-23-000227:notes:58]
In the first nine months of fiscal year 2024, goodwill increased by $58 million from an acquisition, and was assigned to our Compute & Networking segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-23-000227:notes:59]
Balance Sheet Components 
Two customers each accounted for 11% of our accounts receivable balance as of October 29, 2023. Two customers accounted for 14% and 11% of our accounts receivable balance as of January 29, 2023.

[0001045810-23-000227:notes:60]
Certain balance sheet components are as follows:

[0001045810-23-000227:notes:61]
|  | October 29, |  | January 29, |
|  | 2023 |  | 2023 |
| Inventories (1): | (In millions) |
| Raw materials | $ | 1,663 |  |  | $ | 2,430 |  |
| Work in-process | 1,338 |  |  | 466 |  |
| Finished goods | 1,778 |  |  | 2,263 |  |
| Total inventories | $ | 4,779 |  |  | $ | 5,159 |  |

[0001045810-23-000227:notes:62]
(1)    During the third quarter of fiscal years 2024 and 2023, we recorded an inventory provision of approximately $208 million and $354 million, respectively, in cost of revenue.

[0001045810-23-000227:notes:63]
|  | October 29, |  | January 29, |
|  | 2023 |  | 2023 |
| Other Assets: | (In millions) |
| Prepaid supply and capacity agreements (1) | $ | 2,927 |  |  | $ | 2,989 |  |
| Investments in non-affiliated entities | 1,172 |  |  | 299 |  |
| Prepaid royalties | 369 |  |  | 387 |  |
| Prepaid cloud services | 60 |  |  | 23 |  |
| Other | 139 |  |  | 122 |  |
| Total other assets | $ | 4,667 |  |  | $ | 3,820 |  |

[0001045810-23-000227:notes:64]
(1)    As of October 29, 2023 and January 29, 2023, there were an additional $743 million and $458 million of short-term prepaid supply and capacity agreements included in Prepaid expenses and other current assets, respectively.

[0001045810-23-000227:notes:65]
|  | October 29, |  | January 29, |
|  | 2023 |  | 2023 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 1,771 |  |  | $ | 1,196 |  |
| Excess inventory purchase obligations (1) | 1,280 |  |  | 954 |  |
| Accrued payroll and related expenses | 516 |  |  | 530 |  |
| Deferred revenue (2) | 513 |  |  | 354 |  |
| Taxes payable | 420 |  |  | 467 |  |
| Product warranty and return provisions | 299 |  |  | 108 |  |
| Operating leases | 230 |  |  | 176 |  |
| Licenses and royalties | 150 |  |  | 149 |  |
| Unsettled share repurchases | 117 |  |  | — |  |
| Other | 176 |  |  | 186 |  |
| Total accrued and other current liabilities | $ | 5,472 |  |  | $ | 4,120 |  |

[0001045810-23-000227:notes:66]
(1)    During the third quarter of fiscal years 2024 and 2023, we recorded an expense of approximately $473 million and $348 million, respectively, in cost of revenue for inventory purchase obligations in excess of our current demand projections, supplier charges and for penalties related to cancellations and underutilization.

[0001045810-23-000227:notes:67]
[same as prior period, unchanged from 0001045810-23-000175:notes:66]

[0001045810-23-000227:notes:68]
|  | October 29, |  | January 29, |
|  | 2023 |  | 2023 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,206 |  |  | $ | 1,204 |  |
| Deferred revenue (2) | 425 |  |  | 218 |  |
| Deferred income tax | 424 |  |  | 247 |  |
| Licenses payable | 113 |  |  | 181 |  |
| Other | 66 |  |  | 63 |  |
| Total other long-term liabilities | $ | 2,234 |  |  | $ | 1,913 |  |

[0001045810-23-000227:notes:69]
[same as prior period, unchanged from 0001045810-23-000175:notes:68]

[0001045810-23-000227:notes:70]
[same as prior period, unchanged from 0001045810-23-000175:notes:69]

[0001045810-23-000227:notes:71]
[same as prior period, unchanged from 0001045810-23-000175:notes:70]

[0001045810-23-000227:notes:72]
The following table shows the changes in deferred revenue during the first nine months of fiscal years 2024 and 2023:

[0001045810-23-000227:notes:73]
|  | October 29, |  | October 30, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 572 |  |  | $ | 502 |  |
| Deferred revenue additions during the period | 1,269 |  |  | 577 |  |
| Revenue recognized during the period | (903) |  |  | (528) |  |
| Balance at end of period | $ | 938 |  |  | $ | 551 |  |

[0001045810-23-000227:notes:74]
Revenue allocated to remaining performance obligations, which includes deferred revenue and amounts that will be invoiced and recognized as revenue in future periods, was $896 million as of October 29, 2023. We expect to recognize approximately 42% of this revenue over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-23-000227:notes:75]
[same as prior period, unchanged from 0001045810-23-000175:notes:74]

[0001045810-23-000227:notes:76]
[same as prior period, unchanged from 0001045810-23-000175:notes:75]

[0001045810-23-000227:notes:77]
[same as prior period, unchanged from 0001045810-23-000175:notes:76]

[0001045810-23-000227:notes:78]
|  | October 29,2023 |  | January 29,2023 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,148 |  |  | $ | 1,128 |  |
| Non-designated hedges | $ | 365 |  |  | $ | 366 |  |

[0001045810-23-000227:notes:79]
The unrealized gains and losses or fair value of our foreign currency forward contracts was not significant as of October 29, 2023 and January 29, 2023.

[0001045810-23-000227:notes:80]
As of October 29, 2023, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-23-000227:notes:81]
During the first nine months of fiscal years 2024 and 2023, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-23-000227:notes:82]
Debt
Long-Term Debt

[0001045810-23-000227:notes:83]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:

[0001045810-23-000227:notes:84]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (44) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,706 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,457 |  |  | $ | 9,703 |  |

[0001045810-23-000227:notes:85]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-23-000227:notes:86]
On June 15, 2023, we repaid the 0.309% Notes Due 2023.

[0001045810-23-000227:notes:87]
As of October 29, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-23-000227:notes:88]
Commercial Paper

[0001045810-23-000227:notes:89]
We have a $575 million commercial paper program to support general corporate purposes. As of October 29, 2023, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-23-000227:notes:90]
Commitments and Contingencies
Purchase Obligations

[0001045810-23-000227:notes:91]
Our purchase obligations reflect our commitments to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-23-000227:notes:92]
As of October 29, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $17.11 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of

[0001045810-23-000227:notes:93]
cancellation. Other non-inventory purchase obligations were $4.43 billion, which includes $3.60 billion of multi-year cloud service agreements, primarily to support our research and development efforts.

[0001045810-23-000227:notes:94]
Total future purchase commitments as of October 29, 2023 are as follows:

[0001045810-23-000227:notes:95]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first nine months of fiscal year 2024) | $ | 6,499 |  |
| 2025 | 11,861 |  |
| 2026 | 1,128 |  |
| 2027 | 1,038 |  |
| 2028 | 660 |  |
| 2029 and thereafter | 354 |  |
| Total | $ | 21,540 |  |

[0001045810-23-000227:notes:96]
Accrual for Product Warranty Liabilities

[0001045810-23-000227:notes:97]
The estimated amount of product warranty liabilities was $142 million and $82 million as of October 29, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

[0001045810-23-000227:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2023 |  | October 30, 2022 |  | October 29, 2023 |  | October 30, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 115 |  |  | $ | 168 |  |  | $ | 82 |  |  | $ | 46 |  |
| Additions | 50 |  |  | 3 |  |  | 105 |  |  | 141 |  |
| Utilization | (23) |  |  | (67) |  |  | (45) |  |  | (83) |  |
| Balance at end of period | $ | 142 |  |  | $ | 104 |  |  | $ | 142 |  |  | $ | 104 |  |

[0001045810-23-000227:notes:99]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-23-000227:notes:100]
Litigation

[0001045810-23-000227:notes:101]
Securities Class Action and Derivative Lawsuits

[0001045810-23-000227:notes:102]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment

[0001045810-23-000227:notes:103]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023.

[0001045810-23-000227:notes:104]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties will meet and confer regarding the next steps in this derivative matter. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-23-000227:notes:105]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties will meet and confer regarding the next steps in these derivative matters. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-23-000227:notes:106]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures.

[0001045810-23-000227:notes:107]
Accounting for Loss Contingencies

[0001045810-23-000227:notes:108]
As of October 29, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-23-000227:notes:109]
[same as prior period, unchanged from 0001045810-23-000175:notes:107]

[0001045810-23-000227:notes:110]
During the third quarter and first nine months of fiscal year 2024, we repurchased 8.3 million and 15.9 million shares of our common stock for $3.72 billion and $7.01 billion, respectively. During the third quarter and first nine months of fiscal year 2023, we repurchased 28 million and 56 million shares of our common stock for

[0001045810-23-000227:notes:111]
$3.65 billion and $8.99 billion, respectively. In August 2023, our Board of Directors approved an increase to our share repurchase program of an additional $25.00 billion, without expiration. As of October 29, 2023, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $25.24 billion. From October 30, 2023 through November 17, 2023, we repurchased 0.8 million shares for $366 million pursuant to a Rule 10b5-1 trading plan. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-23-000227:notes:112]
During the third quarter and first nine months of fiscal year 2024, we paid $99 million and $296 million in cash dividends to our shareholders, respectively. During the third quarter and first nine months of fiscal year 2023, we paid $100 million and $300 million in cash dividends to our shareholders, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-23-000227:notes:113]
[same as prior period, unchanged from 0001045810-23-000175:notes:110]

[0001045810-23-000227:notes:114]
The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive artificial intelligence, or AI, Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and DGX Cloud.

[0001045810-23-000227:notes:115]
[same as prior period, unchanged from 0001045810-23-000175:notes:112]

[0001045810-23-000227:notes:116]
[same as prior period, unchanged from 0001045810-23-000175:notes:113]

[0001045810-23-000227:notes:117]
The “All Other” category includes the expenses that our CODM does not assign to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related and other costs, intellectual property related, or IP-related costs, acquisition termination cost, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-23-000227:notes:118]
[same as prior period, unchanged from 0001045810-23-000175:notes:115]

[0001045810-23-000227:notes:119]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 29, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 14,645 |  |  | $ | 3,475 |  |  | $ | — |  |  | $ | 18,120 |  |
| Operating income (loss) | $ | 10,262 |  |  | $ | 1,493 |  |  | $ | (1,338) |  |  | $ | 10,417 |  |
| Three Months Ended October 30, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 3,816 |  |  | $ | 2,115 |  |  | $ | — |  |  | $ | 5,931 |  |
| Operating income (loss) | $ | 1,086 |  |  | $ | 606 |  |  | $ | (1,091) |  |  | $ | 601 |  |
| Nine Months Ended October 29, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 29,507 |  |  | $ | 9,312 |  |  | $ | — |  |  | $ | 38,819 |  |
| Operating income (loss) | $ | 19,149 |  |  | $ | 3,751 |  |  | $ | (3,542) |  |  | $ | 19,358 |  |
| Nine Months Ended October 30, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 11,395 |  |  | $ | 9,528 |  |  | $ | — |  |  | $ | 20,923 |  |
| Operating income (loss) | $ | 3,509 |  |  | $ | 3,739 |  |  | $ | (4,280) |  |  | $ | 2,968 |  |

[0001045810-23-000227:notes:120]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (979) |  |  | $ | (745) |  |  | $ | (2,555) |  |  | $ | (1,971) |  |
| Unallocated cost of revenue and operating expenses | (198) |  |  | (156) |  |  | (515) |  |  | (432) |  |
| Acquisition-related and other costs | (135) |  |  | (174) |  |  | (446) |  |  | (499) |  |
| IP-related costs | (26) |  |  | — |  |  | (36) |  |  | — |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | (1,353) |  |
| Other | — |  |  | (16) |  |  | 10 |  |  | (25) |  |
| Total | $ | (1,338) |  |  | $ | (1,091) |  |  | $ | (3,542) |  |  | $ | (4,280) |  |

[0001045810-23-000227:notes:121]
Revenue by geographic region is designated based upon the billing location of the customer. Revenue by Geographic areas were as follows:

[0001045810-23-000227:notes:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 6,302 |  |  | $ | 2,148 |  |  | $ | 14,730 |  |  | $ | 6,069 |  |
| Taiwan | 4,333 |  |  | 1,153 |  |  | 8,968 |  |  | 5,134 |  |
| China (including Hong Kong) | 4,030 |  |  | 1,148 |  |  | 8,360 |  |  | 4,831 |  |
| Singapore | 2,702 |  |  | 536 |  |  | 4,506 |  |  | 1,963 |  |
| Other countries | 753 |  |  | 946 |  |  | 2,255 |  |  | 2,926 |  |
| Total revenue | $ | 18,120 |  |  | $ | 5,931 |  |  | $ | 38,819 |  |  | $ | 20,923 |  |

[0001045810-23-000227:notes:123]
Revenue from sales to customers outside of the United States accounted for 65% and 62% of total revenue for the third quarter and first nine months of fiscal year 2024, respectively, and 64% and 71% of total revenue for the third quarter and first nine months of fiscal year 2023, respectively. The increase in revenue to the United States for the third quarter and first nine months of fiscal year 2024 was primarily due to higher U.S.-based Data Center end demand.

[0001045810-23-000227:notes:124]
Sales to one customer, or Customer A, represented 12% of total revenue for the third quarter of fiscal year 2024, and sales to a second customer, or Customer B, represented 11% of total revenue for the first nine months of fiscal year 2024, both of which were attributable to the Compute & Networking segment.

[0001045810-23-000227:notes:125]
In the first nine months of fiscal year 2023, there were no customers with 10% or more of total revenue. In the third quarter of fiscal year 2023, one customer represented 10% of total revenue, primarily attributable to the Compute & Networking segment.

[0001045810-23-000227:notes:126]
[same as prior period, unchanged from 0001045810-23-000175:notes:124]

[0001045810-23-000227:notes:127]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 14,514 |  |  | $ | 3,833 |  |  | $ | 29,121 |  |  | $ | 11,389 |  |
| Gaming | 2,856 |  |  | 1,574 |  |  | 7,582 |  |  | 7,236 |  |
| Professional Visualization | 416 |  |  | 200 |  |  | 1,090 |  |  | 1,318 |  |
| Automotive | 261 |  |  | 251 |  |  | 810 |  |  | 609 |  |
| OEM and Other | 73 |  |  | 73 |  |  | 216 |  |  | 371 |  |
| Total revenue | $ | 18,120 |  |  | $ | 5,931 |  |  | $ | 38,819 |  |  | $ | 20,923 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-23-000227:notes:128]
On August 27, 2023, Debora Shoquist, Executive Vice President, Operations, adopted a trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale through November 29, 2024 of up to 81,500 shares of our common stock.

[0001045810-23-000227:notes:129]
On October 6, 2023, Donald Robertson, Vice President and Chief Accounting Officer, adopted a trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale through December 18, 2025 of up to 3,500 shares of our common stock.
