# NVDA MD&A — 0001045810-23-000227


## mdna

[0001045810-23-000227:mdna:1]
[same as prior period, unchanged from 0001045810-23-000175:mdna:1]

[0001045810-23-000227:mdna:2]
[same as prior period, unchanged from 0001045810-23-000175:mdna:2]

[0001045810-23-000227:mdna:3]
[same as prior period, unchanged from 0001045810-23-000175:mdna:3]

[0001045810-23-000227:mdna:4]
© 2023 NVIDIA Corporation. All rights reserved.

[0001045810-23-000227:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in this Quarterly Report on Form 10-Q, our Annual Report on Form 10-K for the fiscal year ended January 29, 2023, and our Quarterly Reports on Form 10-Q for the fiscal quarters ended April 30, 2023 and July 30, 2023 under the heading “Risk Factors” of such reports, and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase or sell shares of our common stock.

[0001045810-23-000227:mdna:6]
[same as prior period, unchanged from 0001045810-23-000175:mdna:5]

[0001045810-23-000227:mdna:7]
[same as prior period, unchanged from 0001045810-23-000175:mdna:6]

[0001045810-23-000227:mdna:8]
[same as prior period, unchanged from 0001045810-23-000175:mdna:7]

[0001045810-23-000227:mdna:9]
[same as prior period, unchanged from 0001045810-23-000175:mdna:8]

[0001045810-23-000227:mdna:10]
[same as prior period, unchanged from 0001045810-23-000175:mdna:9]

[0001045810-23-000227:mdna:11]
[same as prior period, unchanged from 0001045810-23-000175:mdna:10]

[0001045810-23-000227:mdna:12]
[same as prior period, unchanged from 0001045810-23-000175:mdna:11]

[0001045810-23-000227:mdna:13]
Demand for our data center systems and products has surged over the last three quarters and our demand visibility extends into next year. To meet this expected demand, we have increased our purchase obligations with existing suppliers, added new suppliers and entered into prepaid supply and capacity agreements. These increased purchase volumes, the number of suppliers, and the integration of new suppliers into our supply chain may create more supply chain complexity and execution risk. We expect to continue to enter into supplier and capacity arrangements and expect our supply to increase each quarter through next year. We may incur inventory provisions or impairments if our inventory or supply or capacity commitments exceed demand for our products or demand declines.

[0001045810-23-000227:mdna:14]
We build finished products and maintain inventory in advance of anticipated demand. While we have entered into long-term supply and capacity commitments, we may not be able to secure sufficient commitments for capacity to address our business needs, or our long-term demand expectations may change. These risks may increase as we shorten our product development cycles or enter new lines of business, which may require us to integrate new suppliers into our supply chain, creating additional supply chain complexity.

[0001045810-23-000227:mdna:15]
Product transitions are complex as we often ship both new and prior architecture products simultaneously and we and our channel partners prepare to ship and support new products. Due to our product introduction cycles, we are almost always in various stages of transitioning the architecture of our Data Center, Professional Visualization, and Gaming products. We will have a broader and faster Data Center product launch cadence to meet a growing and diverse set of AI opportunities. The increased frequency of these transitions may magnify the challenges associated with managing our supply and demand due to long manufacturing lead times. Qualification time for new products, customers anticipating product transitions and channel partners reducing channel inventory of prior architectures ahead of new product introductions can create reductions or volatility in our revenue. In addition, the bring up of new product architectures is complex due to functionality challenges and quality concerns not identified in manufacturing testing. These product quality issues may incur costs, increase our warranty costs, and delay further production of our architecture. Deployment of new products to customers creates additional challenges due to the complexity of our technologies, which has impacted and may in the future impact the timing of customer purchases or otherwise impact our demand. While we have managed prior product transitions and have previously sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and we may incur additional costs.

[0001045810-23-000227:mdna:16]
[same as prior period, unchanged from 0001045810-23-000175:mdna:15]

[0001045810-23-000227:mdna:17]
[same as prior period, unchanged from 0001045810-23-000175:mdna:16]

[0001045810-23-000227:mdna:18]
During the third quarter of fiscal year 2023, the U.S. government, or the USG, announced licensing requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits.

[0001045810-23-000227:mdna:19]
During the second quarter of fiscal year 2024, the USG informed us of an additional licensing requirement for a subset of A100 and H100 products destined to certain customers and other regions, including some countries in the Middle East.

[0001045810-23-000227:mdna:20]
On October 17, 2023, the USG announced new and updated licensing requirements effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products. These licensing requirements did not have a meaningful impact on our revenue in the third quarter of fiscal year 2024 as they were announced near the end of the fiscal quarter and we had additional demand from customers outside of the named country groups. Our sales to China and other affected destinations, derived from products that are now subject to licensing requirements, have consistently contributed approximately 20-25% of Data Center revenue over the past few quarters. We expect that our sales to these destinations will decline significantly in the fourth quarter of fiscal year 2024, though we believe the decline will be more than offset by strong growth in other regions.

[0001045810-23-000227:mdna:21]
We are working to expand our Data Center product portfolio to offer new regulation-compliant solutions, including those for which the USG does not wish to have any advance notice before each shipment. To the

[0001045810-23-000227:mdna:22]
extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer but have no assurance that the USG will grant such a license, or that the USG will act on the license application in a timely manner or at all.

[0001045810-23-000227:mdna:23]
Our competitive position has been harmed, and our competitive position and future results may be further harmed over the long-term, if there are further changes in the USG’s export controls. Given the increasing strategic importance of AI and rising geopolitical tensions, the USG has changed and may again change the export control rules at any time and further subject a wider range of our products to export restrictions and licensing requirements, negatively impacting our business and financial results. In the event of such change, we may be unable to sell our inventory of such products and may be unable to develop replacement products not subject to the licensing requirements, effectively excluding us from all or part of the China market, as well as other impacted markets, including the Middle East. Our sales to China will decrease significantly in the fourth quarter of fiscal year 2024.

[0001045810-23-000227:mdna:24]
While we work to enhance the resiliency and redundancy of our supply chain, which is currently concentrated in the Asia-Pacific, including China, Hong Kong, Korea and Taiwan, new and existing export controls or changes to existing export controls could limit alternative manufacturing locations and negatively impact our business.

[0001045810-23-000227:mdna:25]
[same as prior period, unchanged from 0001045810-23-000175:mdna:20]

[0001045810-23-000227:mdna:26]
Macroeconomic factors, including inflation, increased interest rates, capital market volatility, global supply chain constraints and global economic and geopolitical developments, may have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors can also impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Our product and solution pricing strategy generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-23-000227:mdna:27]
Israel

[0001045810-23-000227:mdna:28]
We are monitoring the impact of the geopolitical conflict in and around Israel on our operations, including the health and safety of our approximately 3,400 employees in the region who primarily support the research and development, operations, and sales and marketing of our networking products. Our operating expenses in the third quarter of fiscal year 2024 include expenses for financial support to impacted employees and charitable activity. We believe our global supply chain for our networking products has not experienced any significant impact. Further, in connection with the conflict, a significant number and percentage of our employees have been called-up for active military duty in Israel. Accordingly, some of our employees in Israel may be absent for an extended and indeterminate period, which may cause disruption to our product development or operations. In the third quarter of fiscal year 2024, we did not experience any significant impact or expense to our business; however, if the conflict is extended, it could impact future product development, operations, and revenue or create other uncertainty for our business.

[0001045810-23-000227:mdna:29]
Third Quarter of Fiscal Year 2024 Summary

[0001045810-23-000227:mdna:30]
|  | Three Months Ended |  |  |  |  |
|  | October 29, 2023 |  | July 30, 2023 |  | October 30, 2022 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 18,120 |  |  | $ | 13,507 |  |  | $ | 5,931 |  |  | 34 | % |  | 206 | % |
| Gross margin | 74.0 | % |  | 70.1 | % |  | 53.6 | % |  | 3.9 pts |  | 20.4 pts |
| Operating expenses | $ | 2,983 |  |  | $ | 2,662 |  |  | $ | 2,576 |  |  | 12 | % |  | 16 | % |
| Operating income | $ | 10,417 |  |  | $ | 6,800 |  |  | $ | 601 |  |  | 53 | % |  | 1,633 | % |
| Net income | $ | 9,243 |  |  | $ | 6,188 |  |  | $ | 680 |  |  | 49 | % |  | 1,259 | % |
| Net income per diluted share | $ | 3.71 |  |  | $ | 2.48 |  |  | $ | 0.27 |  |  | 50 | % |  | 1,274 | % |

[0001045810-23-000227:mdna:31]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and

[0001045810-23-000227:mdna:32]
services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

[0001045810-23-000227:mdna:33]
Revenue for the third quarter of fiscal year 2024 was $18.12 billion, up 206% from a year ago and up 34% sequentially.

[0001045810-23-000227:mdna:34]
Data Center revenue was up 279% from a year ago and up 41% sequentially. Strong sales of the NVIDIA HGX platform were driven by global demand for the training and inferencing of large language models, recommendation engines, and generative AI applications. Data Center compute grew 324% from a year ago and 38% sequentially, largely reflecting the strong ramp of our Hopper GPU architecture-based HGX platform from cloud service providers, or CSPs, including GPU-specialized CSPs; consumer internet companies; and enterprises. Our sales of Ampere GPU architecture-based Data Center products were significant but declined sequentially, as we approach the tail end of this architecture. We recognized initial revenue on the ramp of our L40S GPU and the GH200 Grace Hopper Superchip for a broad range of customers. CSPs drove roughly half of Data Center revenue, while consumer internet companies and enterprises comprised approximately the other half. Networking was up 155% from a year ago and up 52% sequentially, almost entirely due to strong growth in InfiniBand infrastructure to support our HGX platform.

[0001045810-23-000227:mdna:35]
Gaming revenue was up 81% from a year ago and up 15% sequentially. Strong year-on-year growth reflects higher sell-in to partners following normalization of channel inventory levels. Sequential growth reflects strong demand for our GeForce RTX 40 Series GPUs for back-to-school and the start of the holiday season.

[0001045810-23-000227:mdna:36]
Professional Visualization revenue was up 108% from a year ago and up 10% sequentially. The year-on-year increase reflects higher sell-in to partners following normalization of channel inventory levels. The sequential increase was primarily due to stronger enterprise workstation demand and the ramp of notebook workstations based on the Ada Lovelace GPU architecture.

[0001045810-23-000227:mdna:37]
Automotive revenue was up 4% from a year ago and up 3% sequentially. The year-on-year increase primarily reflects growth in sales of auto cockpit solutions and self-driving platforms. The sequential increase was driven by sales of self-driving platforms.

[0001045810-23-000227:mdna:38]
Gross margin increased significantly from a year ago and sequentially, driven by improved product mix from Data Center revenue growth and lower net inventory provisions and related charges.

[0001045810-23-000227:mdna:39]
In the third quarter of fiscal year 2024, provisions for inventory and related charges were $681 million. Sales of previously reserved inventory or settlements of excess inventory purchase obligations resulted in a provision release of $239 million, primarily from Ampere GPU architecture products. The net inventory provisions were $442 million and the unfavorable effect on our gross margin was 2.4 percentage points.

[0001045810-23-000227:mdna:40]
In the third quarter of fiscal year 2023, provisions for inventory and related charges were $702 million. Sales of previously reserved inventory or settlements of excess inventory purchase obligations resulted in a provision release of $21 million. The net inventory provisions were $681 million and the unfavorable effect on our gross margin was 11.5 percentage points.

[0001045810-23-000227:mdna:41]
Operating expenses were up 16% from a year ago and up 12% sequentially, driven by compensation and benefits, including stock-based compensation, primarily reflecting growth in employees and compensation increases.

[0001045810-23-000227:mdna:42]
[same as prior period, unchanged from 0001045810-23-000175:mdna:32]

[0001045810-23-000227:mdna:43]
Data Center revenue for the third quarter of fiscal year 2024 was $14.51 billion, up 279% from a year ago and up 41% from the previous quarter. We announced NVIDIA HGX H200 with the H200 Tensor Core GPU; introduced an AI foundry service, first available on Microsoft Azure; announced that the NVIDIA Spectrum-X will be integrated into servers from Dell Technologies, Hewlett Packard Enterprise and Lenovo in the first quarter of next year; announced that NVIDIA GH200 Grace Hopper Superchips will power more than 40 new supercomputers and began shipping in the third quarter of fiscal year 2024; and partnered with a range of leading companies on AI initiatives, including Amdocs, Dropbox, Foxconn, Genentech (member of Roche Group), Infosys, Lenovo, Reliance Industries, Scaleway, and Tata Group.

[0001045810-23-000227:mdna:44]
Gaming revenue for the third quarter of fiscal year 2024 was $2.86 billion, up 81% from a year ago and up 15% from the previous quarter. We launched DLSS 3.5 Ray Reconstruction; released TensorRT-LLM for Windows; added 56 DLSS games and over 15 Reflex games; and surpassed 1,700 games on GeForce NOW.

[0001045810-23-000227:mdna:45]
Professional Visualization revenue for the third quarter of fiscal year 2024 was $416 million, up 108% from a year ago and up 10% from the previous quarter. We announced a new line of desktop workstations with NVIDIA RTX 6000 Ada Generation GPUs and NVIDIA ConnectX smart interface cards.

[0001045810-23-000227:mdna:46]
Automotive revenue for the third quarter of fiscal year 2024 was $261 million, up 4% from a year ago and up 3% from the previous quarter. We furthered our collaboration with Foxconn to develop next-generation electric vehicles.

[0001045810-23-000227:mdna:47]
[same as prior period, unchanged from 0001045810-23-000175:mdna:38]

[0001045810-23-000227:mdna:48]
[same as prior period, unchanged from 0001045810-23-000175:mdna:39]

[0001045810-23-000227:mdna:49]
[same as prior period, unchanged from 0001045810-23-000175:mdna:40]

[0001045810-23-000227:mdna:50]
[same as prior period, unchanged from 0001045810-23-000175:mdna:41]

[0001045810-23-000227:mdna:51]
[same as prior period, unchanged from 0001045810-23-000175:mdna:42]

[0001045810-23-000227:mdna:52]
[same as prior period, unchanged from 0001045810-23-000175:mdna:43]

[0001045810-23-000227:mdna:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 26.0 |  |  | 46.4 |  |  | 29.1 |  |  | 44.9 |  |
| Gross profit | 74.0 |  |  | 53.6 |  |  | 70.9 |  |  | 55.1 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 12.7 |  |  | 32.8 |  |  | 16.0 |  |  | 25.7 |  |
| Sales, general and administrative | 3.8 |  |  | 10.6 |  |  | 5.0 |  |  | 8.7 |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | 6.5 |  |
| Total operating expenses | 16.5 |  |  | 43.4 |  |  | 21.0 |  |  | 40.9 |  |
| Operating income | 57.5 |  |  | 10.2 |  |  | 49.9 |  |  | 14.2 |  |
| Interest income | 1.3 |  |  | 1.5 |  |  | 1.5 |  |  | 0.7 |  |
| Interest expense | (0.3) |  |  | (1.1) |  |  | (0.5) |  |  | (0.9) |  |
| Other, net | (0.4) |  |  | (0.2) |  |  | (0.1) |  |  | (0.1) |  |
| Other income (expense), net | 0.6 |  |  | 0.2 |  |  | 0.9 |  |  | (0.3) |  |
| Income before income tax | 58.1 |  |  | 10.4 |  |  | 50.8 |  |  | 13.9 |  |
| Income tax expense (benefit) | 7.1 |  |  | (1.1) |  |  | 5.8 |  |  | (0.3) |  |
| Net income | 51.0 | % |  | 11.5 | % |  | 45.0 | % |  | 14.2 | % |

[0001045810-23-000227:mdna:54]
[same as prior period, unchanged from 0001045810-23-000175:mdna:45]

[0001045810-23-000227:mdna:55]
Revenue for the third quarter and first nine months of fiscal year 2024 was $18.12 billion and $38.82 billion, up 206% and 86%, respectively.

[0001045810-23-000227:mdna:56]
[same as prior period, unchanged from 0001045810-23-000175:mdna:47]

[0001045810-23-000227:mdna:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | $Change |  | %Change |  | October 29,2023 |  | October 30,2022 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 14,645 |  |  | $ | 3,816 |  |  | $ | 10,829 |  |  | 284 | % |  | $ | 29,507 |  |  | $ | 11,395 |  |  | $ | 18,112 |  |  | 159 | % |
| Graphics | 3,475 |  |  | 2,115 |  |  | 1,360 |  |  | 64 | % |  | 9,312 |  |  | 9,528 |  |  | (216) |  |  | (2) | % |
| Total | $ | 18,120 |  |  | $ | 5,931 |  |  | $ | 12,189 |  |  | 206 | % |  | $ | 38,819 |  |  | $ | 20,923 |  |  | $ | 17,896 |  |  | 86 | % |

[0001045810-23-000227:mdna:58]
Compute & Networking - The increase in the third quarter and first nine months of fiscal year 2024 compared to the third quarter and first nine months of fiscal year 2023 was due to higher Data Center revenue. Compute GPUs grew 369% year-on-year and 193% compared to the first nine months of fiscal year 2023 led by strong demand for the NVIDIA HGX platform driven by global demand for the training and inferencing of large language models, recommendation engines and inferencing of generative AI applications. Networking was up 155% year-on-year and 99% compared to the first nine months of last year, almost entirely due to strong growth in InfiniBand infrastructure to support our HGX platform.

[0001045810-23-000227:mdna:59]
Graphics - The increase in the third quarter of fiscal year 2024 compared to the third quarter of fiscal year 2023 reflects growth in Gaming GPUs reflecting higher sell-in to partners following normalization of channel inventory levels earlier this year. The decrease in the first nine months of fiscal year 2024 compared to the first nine months of fiscal year 2023 primarily reflects 57% lower enterprise graphics and 14% lower Professional Visualization GPUs, partially offset by 7% growth in Gaming GPUs, following normalization of channel inventory levels earlier this year.

[0001045810-23-000227:mdna:60]
[same as prior period, unchanged from 0001045810-23-000175:mdna:51]

[0001045810-23-000227:mdna:61]
Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to end customers, or End Customers, such as CSPs, enterprises, and gamers in a different location. Revenue from sales to customers outside of the United States accounted for 65% and 62% of total revenue for the third quarter and first nine months of fiscal year 2024, respectively, and 64% and 71% of total revenue for the third quarter and first nine months of fiscal year 2023, respectively.

[0001045810-23-000227:mdna:62]
Our customers include original equipment manufacturers, original device manufacturers, system builders, system integrators, add-in board manufacturers, retailers/distributors, automotive manufacturers, tier-1 automotive suppliers, and other enterprises.

[0001045810-23-000227:mdna:63]
Sales to Customer A represented 12% of total revenue for the third quarter of fiscal year 2024, and sales to Customer B represented 11% of total revenue for the first nine months of fiscal year 2024, both of which were attributable to the Compute & Networking segment.

[0001045810-23-000227:mdna:64]
Our customers sell to End Customers. Our End Customers often do not purchase directly from us but purchase through multiple original equipment manufacturers, original device manufacturers, system integrators, distributors, and other channel partners. Our sales to Customer A and Customer B were largely in support of two End Customers. One End Customer is estimated to have represented approximately 15% and 17% of total revenue for the third quarter and first nine months of fiscal year 2024, respectively. A second End Customer is estimated to have represented approximately 13% and 10% of total revenue for the third quarter and first nine months of fiscal year 2024, respectively. Both of these End Customers were primarily attributable to our Compute & Networking segment.

[0001045810-23-000227:mdna:65]
Our estimated Compute & Networking End Customer demand is expected to remain concentrated.

[0001045810-23-000227:mdna:66]
In the first nine months of fiscal year 2023, there were no customers with 10% or more of total revenue. In the third quarter of fiscal year 2023, one customer represented 10% of total revenue, primarily attributable to the Compute & Networking segment.

[0001045810-23-000227:mdna:67]
[same as prior period, unchanged from 0001045810-23-000175:mdna:55]

[0001045810-23-000227:mdna:68]
Our overall gross margin increased to 74.0% and 70.9% for the third quarter and first nine months of fiscal year 2024, respectively, from 53.6% and 55.1% for the third quarter and first nine months of fiscal year 2023,

[0001045810-23-000227:mdna:69]
respectively. The year over year increase in the third quarter and first nine months of fiscal year 2024 was primarily due to improved product mix from Data Center revenue growth of 279% and 156%, respectively, and lower net inventory provisions and related charges.

[0001045810-23-000227:mdna:70]
Provisions for inventory and excess inventory purchase obligations totaled $681 million and $1.39 billion for the third quarter and first nine months of fiscal year 2024, respectively. Sales of previously reserved inventory or settlements of excess inventory purchase obligations resulted in a provision release of $239 million and $372 million, primarily from Ampere GPU architecture products, for the third quarter and first nine months of fiscal year 2024, respectively. The net effect on our gross margin was an unfavorable impact of 2.4% and 2.6% in the third quarter and first nine months of fiscal year 2024.

[0001045810-23-000227:mdna:71]
Provisions for inventory and excess inventory purchase obligations totaled $702 million and $2.01 billion for the third quarter and first nine months of fiscal year 2023, respectively. Sales of previously reserved inventory or settlements of excess inventory purchase obligations resulted in a provision release of $21 million and $59 million for the third quarter and first nine months of fiscal year 2023, respectively. The net effect on our gross margin was an unfavorable impact of 11.5% and 9.3% in the third quarter and first nine months of fiscal year 2023, respectively.

[0001045810-23-000227:mdna:72]
[same as prior period, unchanged from 0001045810-23-000175:mdna:59]

[0001045810-23-000227:mdna:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | $Change |  | %Change |  | October 29,2023 |  | October 30,2022 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 2,294 |  |  | $ | 1,945 |  |  | $ | 349 |  |  | 18 | % |  | $ | 6,210 |  |  | $ | 5,387 |  |  | $ | 823 |  |  | 15 | % |
| % of net revenue | 12.7 | % |  | 32.8 | % |  |  |  |  |  | 16.0 | % |  | 25.7 | % |  |  |  |  |
| Sales, general and administrative expenses | 689 |  |  | 631 |  |  | 58 |  |  | 9 | % |  | 1,942 |  |  | 1,815 |  |  | 127 |  |  | 7 | % |
| % of net revenue | 3.8 | % |  | 10.6 | % |  |  |  |  |  | 5.0 | % |  | 8.7 | % |  |  |  |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | 1,353 |  |  | (1,353) |  |  | (100) | % |
| % of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | 6.5 | % |  |  |  |  |
| Total operating expenses | $ | 2,983 |  |  | $ | 2,576 |  |  | $ | 407 |  |  | 16 | % |  | $ | 8,152 |  |  | $ | 8,555 |  |  | $ | (403) |  |  | (5) | % |
| % of net revenue | 16.5 | % |  | 43.4 | % |  |  |  |  |  | 21.0 | % |  | 40.9 | % |  |  |  |  |

[0001045810-23-000227:mdna:74]
The increases in research and development expenses and sales, general and administrative expenses for the third quarter and first nine months of fiscal year 2024 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-23-000227:mdna:75]
Acquisition Termination Cost

[0001045810-23-000227:mdna:76]
[same as prior period, unchanged from 0001045810-23-000175:mdna:63]

[0001045810-23-000227:mdna:77]
[same as prior period, unchanged from 0001045810-23-000175:mdna:64]

[0001045810-23-000227:mdna:78]
Operating income for the third quarter and first nine months of fiscal year 2024 was $10.42 billion and $19.36 billion, respectively, up 1,633% and 552% from a year ago, respectively.

[0001045810-23-000227:mdna:79]
Operating Income by Reportable Segments

[0001045810-23-000227:mdna:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | $Change |  | %Change |  | October 29,2023 |  | October 30,2022 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 10,262 |  |  | $ | 1,086 |  |  | $ | 9,176 |  |  | 845 | % |  | $ | 19,149 |  |  | $ | 3,509 |  |  | $ | 15,640 |  |  | 446 | % |
| Graphics | 1,493 |  |  | 606 |  |  | 887 |  |  | 146 | % |  | 3,751 |  |  | 3,739 |  |  | 12 |  |  | — | % |
| All Other | (1,338) |  |  | (1,091) |  |  | (247) |  |  | 23 | % |  | (3,542) |  |  | (4,280) |  |  | 738 |  |  | (17) | % |
| Total | $ | 10,417 |  |  | $ | 601 |  |  | $ | 9,816 |  |  | 1,633 | % |  | $ | 19,358 |  |  | $ | 2,968 |  |  | $ | 16,390 |  |  | 552 | % |

[0001045810-23-000227:mdna:81]
Compute & Networking – Segment operating income increased during the third quarter and first nine months of fiscal year 2024 compared to the third quarter and first nine months of fiscal year 2023 primarily due to growth in revenue.

[0001045810-23-000227:mdna:82]
Graphics - Segment operating income increased during the third quarter of fiscal year 2024 compared to the third quarter of fiscal year 2023 due to growth in revenue. Segment operating income was flat during the first nine months of fiscal year 2024 compared to the first nine months of fiscal year 2023 due to a decline in revenue of $216 million, offset by lower provisions for inventory and excess inventory purchase obligations of $337 million in fiscal year 2024.

[0001045810-23-000227:mdna:83]
All Other expenses increased during the third quarter of fiscal year 2024 compared to the third quarter of fiscal year 2023 due to higher stock-based compensation expense. All Other expenses decreased during the first nine months of fiscal year 2024 compared to the first nine months of fiscal year 2023 due to an acquisition termination cost of $1.35 billion related to the Arm transaction in the prior year, partially offset by higher stock-based compensation expense of $584 million.

[0001045810-23-000227:mdna:84]
[same as prior period, unchanged from 0001045810-23-000175:mdna:72]

[0001045810-23-000227:mdna:85]
|  | Three Months Ended | Nine Months Ended |
|  | October 29,2023 |  | October 30,2022 |  | $Change |  | October 29,2023 |  | October 30,2022 |  | $Change |
|  | ($ in millions) |
| Interest income | $ | 234 |  |  | $ | 88 |  |  | $ | 146 |  |  | $ | 572 |  |  | $ | 152 |  |  | $ | 420 |  |
| Interest expense | (63) |  |  | (65) |  |  | 2 |  |  | (194) |  |  | (198) |  |  | 4 |  |
| Other, net | (66) |  |  | (11) |  |  | (55) |  |  | (24) |  |  | (29) |  |  | 5 |  |
| Other income (expense), net | $ | 105 |  |  | $ | 12 |  |  | $ | 93 |  |  | $ | 354 |  |  | $ | (75) |  |  | $ | 429 |  |

[0001045810-23-000227:mdna:86]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. The increase in interest income was due to higher yields.

[0001045810-23-000227:mdna:87]
Interest expense is comprised of coupon interest and debt discount amortization related to our notes.

[0001045810-23-000227:mdna:88]
Other, net, consists of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. The loss in Other, net, in the third quarter of fiscal year 2024 was driven by mark-to-market losses from publicly traded equity investments.

[0001045810-23-000227:mdna:89]
[same as prior period, unchanged from 0001045810-23-000175:mdna:77]

[0001045810-23-000227:mdna:90]
Income tax was an expense of $1.28 billion and $2.24 billion for the third quarter and first nine months of fiscal year 2024, respectively, and a benefit of $67 million and $61 million for the third quarter and first nine months of fiscal year 2023, respectively. Income tax as a percentage of income before income tax was an expense of 12.2% and 11.3% for the third quarter and first nine months of fiscal year 2024, respectively, and a benefit of 10.9% and 2.1% for the third quarter and first nine months of fiscal year 2023, respectively.

[0001045810-23-000227:mdna:91]
The effective tax rate increased due to a decreased impact of tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit, relative to the increase in income before income tax. The increase in the effective tax rate was partially offset by a benefit due to the IRS audit resolution.

[0001045810-23-000227:mdna:92]
[same as prior period, unchanged from 0001045810-23-000175:mdna:80]

[0001045810-23-000227:mdna:93]
|  | October 29, 2023 |  | January 29, 2023 |
|  | (In millions) |
| Cash and cash equivalents | $ | 5,519 |  |  | $ | 3,389 |  |
| Marketable securities | 12,762 |  |  | 9,907 |  |
| Cash, cash equivalents and marketable securities | $ | 18,281 |  |  | $ | 13,296 |  |

[0001045810-23-000227:mdna:94]
|  | Nine Months Ended |
|  | October 29, 2023 |  | October 30, 2022 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 16,591 |  |  | $ | 3,393 |  |
| Net cash provided by (used in) investing activities | $ | (4,457) |  |  | $ | 7,378 |  |
| Net cash used in financing activities | $ | (10,004) |  |  | $ | (9,961) |  |

[0001045810-23-000227:mdna:95]
As of October 29, 2023, we had $18.28 billion in cash, cash equivalents, and marketable securities, an increase of $4.99 billion from the end of fiscal year 2023. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-23-000227:mdna:96]
Cash provided by operating activities increased in the first nine months of fiscal year 2024 compared to the first nine months of fiscal year 2023, due to growth in revenue, partially offset by higher accounts receivable balance and taxes paid. Accounts receivable balance in the third quarter of fiscal year 2024 reflected approximately $570 million from customer payments received ahead of the invoice due date.

[0001045810-23-000227:mdna:97]
Cash provided by investing activities decreased in the first nine months of fiscal year 2024 compared to the first nine months of fiscal year 2023, primarily driven by lower marketable securities maturities.

[0001045810-23-000227:mdna:98]
Cash used in financing activities increased in the first nine months of fiscal year 2024 compared to the first nine months of fiscal year 2023, due to a debt repayment in the second quarter of fiscal year 2024 and higher tax payments related to RSUs, partially offset by lower share repurchases.

[0001045810-23-000227:mdna:99]
[same as prior period, unchanged from 0001045810-23-000175:mdna:87]

[0001045810-23-000227:mdna:100]
Our primary sources of liquidity are our cash, cash equivalents, and marketable securities, and the cash generated by our operations. As of October 29, 2023, we had $18.28 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of debt securities issued by the USG and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our debt obligations, future supply obligations and vendor and supplier prepayments. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-23-000227:mdna:101]
Except for approximately $1.38 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of October 29, 2023 are available for use in the U.S. without incurring additional U.S. federal income taxes. We

[0001045810-23-000227:mdna:102]
paid $4.35 billion in cash taxes in the third quarter of fiscal year 2024, largely for previously deferred federal income tax payments related to the disaster relief made available by the IRS for certain California taxpayers.

[0001045810-23-000227:mdna:103]
[same as prior period, unchanged from 0001045810-23-000175:mdna:91]

[0001045810-23-000227:mdna:104]
During the third quarter and first nine months of fiscal year 2024, we returned $3.72 billion and $7.01 billion, respectively, in share repurchases and $99 million and $296 million, respectively, in cash dividends.

[0001045810-23-000227:mdna:105]
[same as prior period, unchanged from 0001045810-23-000175:mdna:93]

[0001045810-23-000227:mdna:106]
On August 21, 2023, our Board of Directors approved an increase to our share repurchase program of an additional $25.00 billion, without expiration. As of October 29, 2023, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $25.24 billion. From October 30, 2023 through November 17, 2023, we repurchased 0.8 million shares for $366 million pursuant to a Rule 10b5-1 trading plan. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities. We plan to continue share repurchases this fiscal year.

[0001045810-23-000227:mdna:107]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. This provision has not had a material effect on our consolidated financial statements.

[0001045810-23-000227:mdna:108]
[same as prior period, unchanged from 0001045810-23-000175:mdna:96]

[0001045810-23-000227:mdna:109]
Our aggregate debt maturities as of October 29, 2023, by year payable, are as follows:

[0001045810-23-000227:mdna:110]
|  |  | October 29, 2023 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,250 |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 2,750 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (44) |  |
| Net carrying amount |  | 9,706 |  |
| Less short-term portion |  | (1,249) |  |
| Total long-term portion |  | $ | 8,457 |  |

[0001045810-23-000227:mdna:111]
We have a $575 million commercial paper program to support general corporate purposes. As of October 29, 2023, we had not issued any commercial paper.

[0001045810-23-000227:mdna:112]
[same as prior period, unchanged from 0001045810-23-000175:mdna:100]

[0001045810-23-000227:mdna:113]
We have unrecognized tax benefits of $1.10 billion, which includes related interest and penalties of $115 million recorded in non-current income tax payable as of October 29, 2023. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-23-000227:mdna:114]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023 for a description of our contractual obligations. For a description of our operating lease obligations, long-term debt, and purchase obligations, refer to Note 3, Note 12, and Note 13 of the Notes to Condensed Consolidated Financial Statements, respectively.

[0001045810-23-000227:mdna:115]
34

[0001045810-23-000227:mdna:116]
[same as prior period, unchanged from 0001045810-23-000175:mdna:103]

[0001045810-23-000227:mdna:117]
[same as prior period, unchanged from 0001045810-23-000175:mdna:104]

[0001045810-23-000227:mdna:118]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-23-000227:mdna:119]
There has been no adoption of any new and recently issued accounting pronouncements.
