# NVDA 8-K — 0001045810-23-000225 filed 2023-11-21

## item codes, every 8-K on or before 2023-11-21

- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2023-11-21

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-23-000225:8k_2_02:1]
EX-99.1
2
q3fy24pr.htm
Q3FY24 PRESS RELEASE

[0001045810-23-000225:8k_2_02:2]
Document

[0001045810-23-000225:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-23-000225:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2024

[0001045810-23-000225:8k_2_02:5]
•Record revenue of $18.12 billion, up 34% from Q2, up 206% from year ago

[0001045810-23-000225:8k_2_02:6]
•Record Data Center revenue of $14.51 billion, up 41% from Q2, up 279% from year ago

[0001045810-23-000225:8k_2_02:7]
SANTA CLARA, Calif.—Nov. 21, 2023―NVIDIA (NASDAQ: NVDA) today reported revenue for the third quarter ended October 29, 2023, of $18.12 billion, up 206% from a year ago and up 34% from the previous quarter.

[0001045810-23-000225:8k_2_02:8]
GAAP earnings per diluted share for the quarter were $3.71, up more than 12x from a year ago and up 50% from the previous quarter. Non-GAAP earnings per diluted share were $4.02, up nearly 6x from a year ago and up 49% from the previous quarter.

[0001045810-23-000225:8k_2_02:9]
“Our strong growth reflects the broad industry platform transition from general-purpose to accelerated computing and generative AI,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-23-000225:8k_2_02:10]
“Large language model startups, consumer internet companies and global cloud service providers were the first movers, and the next waves are starting to build. Nations and regional CSPs are investing in AI clouds to serve local demand, enterprise software companies are adding AI copilots and assistants to their platforms, and enterprises are creating custom AI to automate the world’s largest industries.

[0001045810-23-000225:8k_2_02:11]
“NVIDIA GPUs, CPUs, networking, AI foundry services and NVIDIA AI Enterprise software are all growth engines in full throttle. The era of generative AI is taking off,” he said.

[0001045810-23-000225:8k_2_02:12]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on December 28, 2023, to all shareholders of record on December 6, 2023.

[0001045810-23-000225:8k_2_02:13]
Q3 Fiscal 2024 Summary

[0001045810-23-000225:8k_2_02:14]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY24 | Q2 FY24 | Q3 FY23 | Q/Q | Y/Y |
| Revenue | $18,120 | $13,507 | $5,931 | Up 34% | Up 206% |
| Gross margin | 74.0 | % | 70.1 | % | 53.6 | % | Up 3.9 pts | Up 20.4 pts |
| Operating expenses | $2,983 | $2,662 | $2,576 | Up 12% | Up 16% |
| Operating income | $10,417 | $6,800 | $601 | Up 53% | Up 1,633% |
| Net income | $9,243 | $6,188 | $680 | Up 49% | Up 1,259% |
| Diluted earnings per share | $3.71 | $2.48 | $0.27 | Up 50% | Up 1,274% |

[0001045810-23-000225:8k_2_02:15]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY24 | Q2 FY24 | Q3 FY23 | Q/Q | Y/Y |
| Revenue | $18,120 | $13,507 | $5,931 | Up 34% | Up 206% |
| Gross margin | 75.0 | % | 71.2 | % | 56.1 | % | Up 3.8 pts | Up 18.9 pts |
| Operating expenses | $2,026 | $1,838 | $1,793 | Up 10% | Up 13% |
| Operating income | $11,557 | $7,776 | $1,536 | Up 49% | Up 652% |
| Net income | $10,020 | $6,740 | $1,456 | Up 49% | Up 588% |
| Diluted earnings per share | $4.02 | $2.70 | $0.58 | Up 49% | Up 593% |

[0001045810-23-000225:8k_2_02:16]
Outlook

[0001045810-23-000225:8k_2_02:17]
NVIDIA’s outlook for the fourth quarter of fiscal 2024 is as follows:

[0001045810-23-000225:8k_2_02:18]
•Revenue is expected to be $20.00 billion, plus or minus 2%.

[0001045810-23-000225:8k_2_02:19]
•GAAP and non-GAAP gross margins are expected to be 74.5% and 75.5%, respectively, plus or minus 50 basis points.

[0001045810-23-000225:8k_2_02:20]
•GAAP and non-GAAP operating expenses are expected to be approximately $3.17 billion and $2.20 billion, respectively.

[0001045810-23-000225:8k_2_02:21]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $200 million, excluding gains and losses from non-affiliated investments.

[0001045810-23-000225:8k_2_02:22]
•GAAP and non-GAAP tax rates are expected to be 15.0%, plus or minus 1%, excluding any discrete items.

[0001045810-23-000225:8k_2_02:23]
Highlights

[0001045810-23-000225:8k_2_02:24]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-23-000225:8k_2_02:25]
Data Center

[0001045810-23-000225:8k_2_02:26]
•Third-quarter revenue was a record $14.51 billion, up 41% from the previous quarter and up 279% from a year ago.

[0001045810-23-000225:8k_2_02:27]
•Announced NVIDIA HGX™ H200 with the new NVIDIA H200 Tensor Core GPU, the first GPU with HBM3e memory, with systems expected to be available in the second quarter of next year.

[0001045810-23-000225:8k_2_02:28]
•Introduced an AI foundry service — with NVIDIA AI Foundation Models, NVIDIA NeMo™ framework and NVIDIA DGX™ Cloud AI supercomputing — to accelerate the development and tuning of custom generative AI applications, first available on Microsoft Azure, with SAP and Amdocs among the first customers.

[0001045810-23-000225:8k_2_02:29]
•Announced that the NVIDIA Spectrum-X™ Ethernet networking platform for AI will be integrated into servers from Dell Technologies, Hewlett Packard Enterprise and Lenovo in the first quarter of next year.

[0001045810-23-000225:8k_2_02:30]
•Announced that NVIDIA GH200 Grace Hopper Superchips, including a new quad configuration, will power more than 40 new supercomputers, including the JUPITER system at Jülich Supercomputing Centre and Isambard-AI at the University of Bristol.

[0001045810-23-000225:8k_2_02:31]
•Made advances with global cloud service providers:

[0001045810-23-000225:8k_2_02:32]
◦Google Cloud Platform made generally available new A3 instances powered by NVIDIA H100 Tensor Core GPUs and NVIDIA AI Enterprise software in Google Cloud Marketplace.

[0001045810-23-000225:8k_2_02:33]
◦Microsoft Azure will be offering customers access to NVIDIA Omniverse™ Cloud Services for accelerating automotive digitalization, as well as new instances featuring NVL H100 Tensor Core GPUs and H100 with confidential computing, with H200 GPUs coming next year.

[0001045810-23-000225:8k_2_02:34]
◦Oracle Cloud Infrastructure made NVIDIA DGX Cloud and NVIDIA AI Enterprise software available in Oracle Cloud Marketplace.

[0001045810-23-000225:8k_2_02:35]
•Partnered with a range of leading companies on AI initiatives, including Amdocs, Dropbox, Foxconn, Genentech (member of Roche Group), Infosys, Lenovo, Reliance Industries, Scaleway and Tata Group.

[0001045810-23-000225:8k_2_02:36]
•Announced record-setting performance in the latest two sets of MLPerf benchmarks for inference and training, with the NVIDIA Eos AI supercomputer training a GPT-3 model 3x faster than the previous record.

[0001045810-23-000225:8k_2_02:37]
•Announced growing worldwide support for the NVIDIA® CUDA® Quantum platform, including new efforts in Israel, the Netherlands, the U.K. and the U.S.

[0001045810-23-000225:8k_2_02:38]
Gaming

[0001045810-23-000225:8k_2_02:39]
•Third-quarter revenue was $2.86 billion, up 15% from the previous quarter and up 81% from a year ago.

[0001045810-23-000225:8k_2_02:40]
•Launched DLSS 3.5 Ray Reconstruction, which creates high-quality ray-traced images for intensive ray-traced games and apps, including Alan Wake 2 and Cyberpunk 2077.

[0001045810-23-000225:8k_2_02:41]
•Released TensorRT-LLM™ for Windows, speeding on-device LLM inference by up to 4x.

[0001045810-23-000225:8k_2_02:42]
•Added 56 DLSS games and over 15 Reflex games, bringing the total number of RTX games and applications to over 475.

[0001045810-23-000225:8k_2_02:43]
•Surpassed 1,700 games on GeForce NOW™, including launches of Alan Wake 2, Baldur’s Gate 3, Cyberpunk 2077: Phantom Liberty, Forza Motorsport and Starfield.

[0001045810-23-000225:8k_2_02:44]
Professional Visualization

[0001045810-23-000225:8k_2_02:45]
•Third-quarter revenue was $416 million, up 10% from the previous quarter and up 108% from a year ago.

[0001045810-23-000225:8k_2_02:46]
•Announced that Mercedes-Benz is using NVIDIA Omniverse to create digital twins to help plan, design, build and operate its manufacturing and assembly facilities around the world.

[0001045810-23-000225:8k_2_02:47]
•Announced a new line of desktop workstations with NVIDIA RTX™ 6000 Ada Generation GPUs and NVIDIA ConnectX® smart interface cards for training smaller AI models, fine-tuning models and running inference locally.

[0001045810-23-000225:8k_2_02:48]
Automotive

[0001045810-23-000225:8k_2_02:49]
•Third-quarter revenue was $261 million, up 3% from the previous quarter and up 4% from a year ago.

[0001045810-23-000225:8k_2_02:50]
•Furthered its collaboration with Foxconn to develop next-generation electric vehicles for the global market, using the next-generation NVIDIA DRIVE Hyperion™ platform and NVIDIA DRIVE Thor™ system-on-a-chip.

[0001045810-23-000225:8k_2_02:51]
CFO Commentary

[0001045810-23-000225:8k_2_02:52]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-23-000225:8k_2_02:53]
Conference Call and Webcast Information

[0001045810-23-000225:8k_2_02:54]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2024 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal 2024.

[0001045810-23-000225:8k_2_02:55]
Non-GAAP Measures

[0001045810-23-000225:8k_2_02:56]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP

[0001045810-23-000225:8k_2_02:57]
operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, IP-related costs, other, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-23-000225:8k_2_02:58]
About NVIDIA

[0001045810-23-000225:8k_2_02:59]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and is fueling industrial digitalization across markets. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-23-000225:8k_2_02:60]
###

[0001045810-23-000225:8k_2_02:61]
For further information, contact:

[0001045810-23-000225:8k_2_02:62]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-23-000225:8k_2_02:63]
Certain statements in this press release including, but not limited to, statements as to: the broad industry platform transition from general-purpose to accelerated computing and generative AI and the next waves starting to build; nations and regional CSPs investing in AI clouds to serve local demand, enterprise software companies adding AI copilots and assistants to their platforms, and enterprises creating custom AI to automate the world’s largest industries; NVIDIA GPUs, CPUs, networking, AI foundry services and NVIDIA AI Enterprise software as growth engines for generative AI; the era of generative AI taking off; the NVIDIA AI foundry service accelerating the development and tuning of custom generative AI applications; the usage of NVIDIA GH200 Superchips in supercomputers globally; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook and expected tax rates for the fourth quarter of fiscal 2024; the benefits, impact, performance, features and availability of NVIDIA’s products and technologies, including the NVIDIA HGX H200, NVIDIA H200 Tensor Core GPU, NVIDIA AI Foundation Models, NVIDIA NeMo, NVIDIA GH200 Grace Hopper Superchip, NVIDIA AI Enterprise, NVIDIA Omniverse, NVIDIA Spectrum-X, NVIDIA RTX workstations, NVIDIA RTX 6000 Ada GPU, NVIDIA Omniverse Enterprise software, NVIDIA H100 Tensor Core GPU, NVIDIA DGX Cloud AI, GeForce NOW, NVIDIA CUDA Quantum platform, DLSS, DLSS 3.5 Ray Reconstruction, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Thor, TensorRT-LLM, NVIDIA ConnectX; the benefits and impact of NVIDIA’s partnerships with Amdocs, Dropbox, Foxconn, Genentech, Infosys, Lenovo, Reliance Industries, Scaleway and Tata Group; growing support for NVIDIA CUDA Quantum platform; and the usage of NVIDIA Omniverse by Mercedes-Benz are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; and unexpected loss of performance of our products or technologies when integrated into systems, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking

[0001045810-23-000225:8k_2_02:64]
statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-23-000225:8k_2_02:65]
© 2023 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce NOW, NVIDIA CUDA, NVIDIA DGX, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Thor, NVIDIA Grace Hopper, NVIDIA HGX, NVIDIA NeMo, NVIDIA Omniverse, NVIDIA RTX, NVIDIA Spectrum-X and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-23-000225:8k_2_02:66]
NVIDIA CORPORATION

[0001045810-23-000225:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-23-000225:8k_2_02:68]
(In millions, except per share data)

[0001045810-23-000225:8k_2_02:69]
(Unaudited)

[0001045810-23-000225:8k_2_02:70]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 29, 2023 |  | October 30, 2022 |  | October 29, 2023 |  | October 30, 2022 |
| Revenue | $ | 18,120 |  |  | $ | 5,931 |  |  | $ | 38,819 |  |  | $ | 20,923 |  |
| Cost of revenue | 4,720 |  |  | 2,754 |  |  | 11,309 |  |  | 9,400 |  |
| Gross profit | 13,400 |  |  | 3,177 |  |  | 27,510 |  |  | 11,523 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 2,294 |  |  | 1,945 |  |  | 6,210 |  |  | 5,387 |  |
|  | Sales, general and administrative | 689 |  |  | 631 |  |  | 1,942 |  |  | 1,815 |  |
|  | Acquisition termination cost | — |  |  | — |  |  | — |  |  | 1,353 |  |
|  |  | Total operating expenses | 2,983 |  |  | 2,576 |  |  | 8,152 |  |  | 8,555 |  |
| Operating income | 10,417 |  |  | 601 |  |  | 19,358 |  |  | 2,968 |  |
|  | Interest income | 234 |  |  | 88 |  |  | 572 |  |  | 152 |  |
|  | Interest expense | (63) |  |  | (65) |  |  | (194) |  |  | (198) |  |
|  | Other, net | (66) |  |  | (11) |  |  | (24) |  |  | (29) |  |
|  |  | Other income (expense), net | 105 |  |  | 12 |  |  | 354 |  |  | (75) |  |
| Income before income tax | 10,522 |  |  | 613 |  |  | 19,712 |  |  | 2,893 |  |
| Income tax expense (benefit) | 1,279 |  |  | (67) |  |  | 2,237 |  |  | (61) |  |
| Net income | $ | 9,243 |  |  | $ | 680 |  |  | $ | 17,475 |  |  | $ | 2,954 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 3.75 |  |  | $ | 0.27 |  |  | $ | 7.07 |  |  | $ | 1.18 |  |
|  | Diluted | $ | 3.71 |  |  | $ | 0.27 |  |  | $ | 7.01 |  |  | $ | 1.17 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,468 |  |  | 2,483 |  |  | 2,470 |  |  | 2,495 |  |
|  | Diluted | 2,494 |  |  | 2,499 |  |  | 2,494 |  |  | 2,517 |  |

[0001045810-23-000225:8k_2_02:71]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | October 29, 2023 |  | January 29, 2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 18,281 |  |  | $ | 13,296 |  |
|  | Accounts receivable, net |  | 8,309 |  |  | 3,827 |  |
|  | Inventories |  | 4,779 |  |  | 5,159 |  |
|  | Prepaid expenses and other current assets |  | 1,289 |  |  | 791 |  |
|  |  | Total current assets |  | 32,658 |  |  | 23,073 |  |
| Property and equipment, net |  | 3,844 |  |  | 3,807 |  |
| Operating lease assets |  | 1,316 |  |  | 1,038 |  |
| Goodwill |  | 4,430 |  |  | 4,372 |  |
| Intangible assets, net |  | 1,251 |  |  | 1,676 |  |
| Deferred income tax assets |  | 5,982 |  |  | 3,396 |  |
| Other assets |  | 4,667 |  |  | 3,820 |  |
|  |  | Total assets |  | $ | 54,148 |  |  | $ | 41,182 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 2,380 |  |  | $ | 1,193 |  |
|  | Accrued and other current liabilities |  | 5,472 |  |  | 4,120 |  |
|  | Short-term debt |  | 1,249 |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 9,101 |  |  | 6,563 |  |
| Long-term debt |  | 8,457 |  |  | 9,703 |  |
| Long-term operating lease liabilities |  | 1,091 |  |  | 902 |  |
| Other long-term liabilities |  | 2,234 |  |  | 1,913 |  |
|  |  | Total liabilities |  | 20,883 |  |  | 19,081 |  |
| Shareholders' equity |  | 33,265 |  |  | 22,101 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 54,148 |  |  | $ | 41,182 |  |

[0001045810-23-000225:8k_2_02:72]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 9,243 |  |  | $ | 680 |  |  | $ | 17,475 |  |  | $ | 2,954 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock based compensation expense | 979 |  |  | 745 |  |  | 2,555 |  |  | 1,971 |  |
| Depreciation and amortization | 372 |  |  | 406 |  |  | 1,121 |  |  | 1,118 |  |
| Losses on investments in non-affiliates, net | 69 |  |  | 11 |  |  | 24 |  |  | 35 |  |
| Deferred income taxes | (529) |  |  | (532) |  |  | (2,411) |  |  | (1,517) |  |
| Acquisition termination cost | — |  |  | — |  |  | — |  |  | 1,353 |  |
| Other | (66) |  |  | (45) |  |  | (170) |  |  | (27) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (1,243) |  |  | 410 |  |  | (4,482) |  |  | (258) |  |
| Inventories | (457) |  |  | (563) |  |  | 405 |  |  | (1,848) |  |
| Prepaid expenses and other assets | 254 |  |  | 247 |  |  | (337) |  |  | (1,307) |  |
| Accounts payable | 461 |  |  | (917) |  |  | 1,250 |  |  | (358) |  |
| Accrued liabilities and other current liabilities | (1,722) |  |  | (92) |  |  | 953 |  |  | 1,175 |  |
| Other long-term liabilities | (28) |  |  | 42 |  |  | 208 |  |  | 102 |  |
| Net cash provided by operating activities | 7,333 |  |  | 392 |  |  | 16,591 |  |  | 3,393 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,891 |  |  | 5,809 |  |  | 8,001 |  |  | 16,792 |  |
| Proceeds from sales of marketable securities | — |  |  | 75 |  |  | — |  |  | 1,806 |  |
| Purchases of marketable securities | (5,345) |  |  | (2,188) |  |  | (10,688) |  |  | (9,764) |  |
| Purchase related to property and equipment and intangible assets | (278) |  |  | (530) |  |  | (815) |  |  | (1,324) |  |
| Acquisitions, net of cash acquired | — |  |  | — |  |  | (83) |  |  | (49) |  |
| Investments in non-affiliates and other, net | (437) |  |  | (18) |  |  | (872) |  |  | (83) |  |
| Net cash provided by (used in) investing activities | (3,169) |  |  | 3,148 |  |  | (4,457) |  |  | 7,378 |  |

[0001045810-23-000225:8k_2_02:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 156 |  |  | 143 |  |  | 403 |  |  | 349 |  |
| Payments related to repurchases of common stock | (3,806) |  |  | (3,485) |  |  | (6,874) |  |  | (8,826) |  |
| Repayment of debt | — |  |  | — |  |  | (1,250) |  |  | — |  |
| Payments related to tax on restricted stock units | (764) |  |  | (294) |  |  | (1,942) |  |  | (1,131) |  |
| Dividends paid | (99) |  |  | (100) |  |  | (296) |  |  | (300) |  |
| Principal payments on property and equipment and intangible assets | (13) |  |  | (18) |  |  | (44) |  |  | (54) |  |
| Other | (1) |  |  | 1 |  |  | (1) |  |  | 1 |  |
| Net cash used in financing activities | (4,527) |  |  | (3,753) |  |  | (10,004) |  |  | (9,961) |  |
| Change in cash, cash equivalents, and restricted cash | (363) |  |  | (213) |  |  | 2,130 |  |  | 810 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 5,882 |  |  | 3,013 |  |  | 3,389 |  |  | 1,990 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 5,519 |  |  | $ | 2,800 |  |  | $ | 5,519 |  |  | $ | 2,800 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 4,348 |  |  | $ | 264 |  |  | $ | 4,676 |  |  | $ | 1,372 |  |

[0001045810-23-000225:8k_2_02:74]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP gross profit |  | $ | 13,400 |  |  | $ | 9,462 |  |  | $ | 3,177 |  |  | $ | 27,510 |  |  | $ | 11,523 |  |
| GAAP gross margin |  | 74.0 | % |  | 70.1 | % |  | 53.6 | % |  | 70.9 | % |  | 55.1 | % |
|  | Acquisition-related and other costs (A) |  | 119 |  |  | 119 |  |  | 120 |  |  | 358 |  |  | 335 |  |
|  | Stock-based compensation expense (B) |  | 38 |  |  | 31 |  |  | 32 |  |  | 96 |  |  | 108 |  |
|  | IP-related costs |  | 26 |  |  | 2 |  |  | — |  |  | 36 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 13,583 |  |  | $ | 9,614 |  |  | $ | 3,329 |  |  | $ | 28,000 |  |  | $ | 11,966 |  |
| Non-GAAP gross margin |  | 75.0 | % |  | 71.2 | % |  | 56.1 | % |  | 72.1 | % |  | 57.2 | % |
| GAAP operating expenses |  | $ | 2,983 |  |  | $ | 2,662 |  |  | $ | 2,576 |  |  | $ | 8,152 |  |  | $ | 8,555 |  |
|  | Stock-based compensation expense (B) |  | (941) |  |  | (811) |  |  | (713) |  |  | (2,459) |  |  | (1,863) |  |
|  | Acquisition-related and other costs (A) |  | (16) |  |  | (18) |  |  | (54) |  |  | (88) |  |  | (164) |  |
|  | Acquisition termination cost |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,353) |  |
|  | Other (C) |  | — |  |  | 5 |  |  | (16) |  |  | 10 |  |  | (25) |  |
| Non-GAAP operating expenses |  | $ | 2,026 |  |  | $ | 1,838 |  |  | $ | 1,793 |  |  | $ | 5,615 |  |  | $ | 5,150 |  |
| GAAP operating income |  | $ | 10,417 |  |  | $ | 6,800 |  |  | $ | 601 |  |  | $ | 19,358 |  |  | $ | 2,968 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,140 |  |  | 976 |  |  | 935 |  |  | 3,027 |  |  | 3,848 |  |
| Non-GAAP operating income |  | $ | 11,557 |  |  | $ | 7,776 |  |  | $ | 1,536 |  |  | $ | 22,385 |  |  | $ | 6,816 |  |
| GAAP other income (expense), net |  | $ | 105 |  |  | $ | 181 |  |  | $ | 12 |  |  | $ | 354 |  |  | $ | (75) |  |
|  | (Gains) losses from non-affiliated investments |  | 69 |  |  | (62) |  |  | 11 |  |  | 23 |  |  | 36 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Non-GAAP other income (expense), net |  | $ | 175 |  |  | $ | 120 |  |  | $ | 24 |  |  | $ | 380 |  |  | $ | (36) |  |
| GAAP net income |  | $ | 9,243 |  |  | $ | 6,188 |  |  | $ | 680 |  |  | $ | 17,475 |  |  | $ | 2,954 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 1,210 |  |  | 915 |  |  | 947 |  |  | 3,053 |  |  | 3,887 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (433) |  |  | (363) |  |  | (171) |  |  | (1,055) |  |  | (649) |  |
| Non-GAAP net income |  | $ | 10,020 |  |  | $ | 6,740 |  |  | $ | 1,456 |  |  | $ | 19,473 |  |  | $ | 6,192 |  |

[0001045810-23-000225:8k_2_02:75]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 3.71 |  |  | $ | 2.48 |  |  | $ | 0.27 |  |  | $ | 7.01 |  |  | $ | 1.17 |  |
|  | Non-GAAP |  | $ | 4.02 |  |  | $ | 2.70 |  |  | $ | 0.58 |  |  | $ | 7.81 |  |  | $ | 2.46 |  |
| Weighted average shares used in diluted net income per share computation |  | 2,494 |  |  | 2,499 |  |  | 2,499 |  |  | 2,494 |  |  | 2,517 |  |
| GAAP net cash provided by operating activities |  | $ | 7,333 |  |  | $ | 6,348 |  |  | $ | 392 |  |  | $ | 16,591 |  |  | $ | 3,393 |  |
|  | Purchases related to property and equipment and intangible assets |  | (278) |  |  | (289) |  |  | (530) |  |  | (815) |  |  | (1,324) |  |
|  | Principal payments on property and equipment and intangible assets |  | (13) |  |  | (11) |  |  | (18) |  |  | (44) |  |  | (54) |  |
| Free cash flow |  | $ | 7,042 |  |  | $ | 6,048 |  |  | $ | (156) |  |  | $ | 15,732 |  |  | $ | 2,015 |  |

[0001045810-23-000225:8k_2_02:76]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets and transaction costs, and are included in the following line items: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Cost of revenue |  | $ | 119 |  |  | $ | 119 |  |  | $ | 120 |  |  | $ | 358 |  |  | $ | 335 |  |
|  | Research and development |  | $ | 12 |  |  | $ | 12 |  |  | $ | 10 |  |  | $ | 37 |  |  | $ | 29 |  |
|  | Sales, general and administrative |  | $ | 4 |  |  | $ | 6 |  |  | $ | 44 |  |  | $ | 51 |  |  | $ | 135 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  |  | 2023 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | Cost of revenue |  | $ | 38 |  |  | $ | 31 |  |  | $ | 32 |  |  | $ | 96 |  |  | $ | 108 |  |
|  | Research and development |  | $ | 701 |  |  | $ | 600 |  |  | $ | 530 |  |  | $ | 1,826 |  |  | $ | 1,365 |  |
|  | Sales, general and administrative |  | $ | 240 |  |  | $ | 211 |  |  | $ | 183 |  |  | $ | 633 |  |  | $ | 498 |  |
| (C) Other consists of costs related to Russia branch office closure, assets held for sale related adjustments, legal settlement costs, and contributions. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-23-000225:8k_2_02:77]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2024 |
|  |  |  | Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 74.5 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 1.0 | % |
| Non-GAAP gross margin |  | 75.5 | % |
| GAAP operating expenses |  | $ | 3,165 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (965) |  |
| Non-GAAP operating expenses |  | $ | 2,200 |  |
