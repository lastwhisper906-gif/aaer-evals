# NVDA MD&A — 0001045810-24-000316


## mdna

[0001045810-24-000316:mdna:1]
[same as prior period, unchanged from 0001045810-24-000264:mdna:1]

[0001045810-24-000316:mdna:2]
[same as prior period, unchanged from 0001045810-24-000264:mdna:2]

[0001045810-24-000316:mdna:3]
[same as prior period, unchanged from 0001045810-24-000264:mdna:3]

[0001045810-24-000316:mdna:4]
[same as prior period, unchanged from 0001045810-24-000264:mdna:4]

[0001045810-24-000316:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 28, 2024 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase, hold, or sell shares of our common stock.

[0001045810-24-000316:mdna:6]
[same as prior period, unchanged from 0001045810-24-000264:mdna:6]

[0001045810-24-000316:mdna:7]
[same as prior period, unchanged from 0001045810-24-000264:mdna:7]

[0001045810-24-000316:mdna:8]
[same as prior period, unchanged from 0001045810-24-000264:mdna:8]

[0001045810-24-000316:mdna:9]
[same as prior period, unchanged from 0001045810-24-000264:mdna:9]

[0001045810-24-000316:mdna:10]
[same as prior period, unchanged from 0001045810-24-000264:mdna:10]

[0001045810-24-000316:mdna:11]
[same as prior period, unchanged from 0001045810-24-000264:mdna:11]

[0001045810-24-000316:mdna:12]
Revenue growth in the third quarter of fiscal year 2025 was driven by data center compute and networking platforms for accelerated computing and AI solutions. Demand for the Hopper architecture is strong and our H200 offering grew significantly in the quarter. We completed a successful mask change for Blackwell, our next Data Center architecture, that improved production yields. Blackwell production shipments are scheduled to begin in the fourth quarter of fiscal year 2025 and will continue to ramp into fiscal year 2026. We will be shipping both Hopper and Blackwell systems in the fourth quarter of fiscal year 2025 and beyond. Both Hopper and Blackwell systems have certain supply constraints, and the demand for Blackwell is expected to exceed supply for several quarters in fiscal year 2026.

[0001045810-24-000316:mdna:13]
Demand estimates for our products, applications, and services can be incorrect and create volatility in our revenue or supply levels. We may not be able to generate significant revenue from them. Advancements in accelerated computing and generative AI models, along with the growth in model complexity and scale, have driven increased demand for our Data Center systems.

[0001045810-24-000316:mdna:14]
[same as prior period, unchanged from 0001045810-24-000264:mdna:14]

[0001045810-24-000316:mdna:15]
[same as prior period, unchanged from 0001045810-24-000264:mdna:15]

[0001045810-24-000316:mdna:16]
[same as prior period, unchanged from 0001045810-24-000264:mdna:16]

[0001045810-24-000316:mdna:17]
Product transitions are complex and we often ship both new and prior architecture products simultaneously as our channel partners prepare to ship and support new products. We may be in various stages of transitioning the architectures of our Data Center, Gaming, Professional Visualization and Automotive products. The computing industry is experiencing a broader and faster launch cadence of accelerated computing platforms to meet a growing and diverse set of AI opportunities. We have introduced a new architecture cadence of our Data Center solutions where we seek to complete a new computing architecture each year and we are providing a greater variety of Data Center offerings. The increased frequency of these transitions and the larger number of products and product configurations may magnify the challenges associated with managing our supply and demand which may create volatility in our revenue. The increased frequency and complexity of newly introduced products could result in quality or production issues that could increase inventory provisions, warranty, or other costs or result in product delays. We incur significant engineering development resources for new products, and changes to our product roadmap may impact our ability to develop other products or adequately manage our supply chain cost. Customers may delay purchasing existing products as we increase the frequency of new products or may not be able to adopt our new products as fast as forecasted, both impacting the timing of our revenue and supply chain cost. While we have managed prior product transitions and have sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and may cause us to incur additional costs.

[0001045810-24-000316:mdna:18]
[same as prior period, unchanged from 0001045810-24-000264:mdna:18]

[0001045810-24-000316:mdna:19]
[same as prior period, unchanged from 0001045810-24-000264:mdna:19]

[0001045810-24-000316:mdna:20]
[same as prior period, unchanged from 0001045810-24-000264:mdna:20]

[0001045810-24-000316:mdna:21]
In October 2023, the USG announced new and updated licensing requirements that became effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including, but not limited to, the A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products (removing the grace period granted by the official rule). Our upcoming Blackwell systems, such as GB200 NVL 72 and NVL 36 as well as B200 will also be subject to these requirements and therefore require a license for any shipment to certain entities and to China and Country Groups D1, D4 and D5, excluding Israel. To date, we have not received licenses to ship these restricted products to China. Additionally, we understand that partners and customers have also not received a license to ship these restricted products.

[0001045810-24-000316:mdna:22]
We expanded our Data Center product portfolio to offer new solutions, including those for which the USG does not require a license or advance notice before each shipment. We ramped new products designed specifically for China that do not require an export control license. Our Data Center revenue in China grew sequentially in the third quarter of fiscal year 2025. As a percentage of total Data Center revenue, it remains below levels seen prior to the imposition of export controls in October 2023. To the extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer but have no assurance that the USG will grant such a license, or that the USG will act on the license application in a timely manner or at all.

[0001045810-24-000316:mdna:23]
Our competitive position has been harmed, and our competitive position and future results may be further harmed in the long term, if there are further changes in the USG’s export controls. Given the increasing strategic importance of AI and rising geopolitical tensions, the USG has changed and may again change the export control rules at any time and further subject a wider range of our products to export restrictions and licensing requirements, negatively impacting our business and financial results. In the event of such change, we may be unable to sell our inventory of such products and may be unable to develop replacement products not subject to the licensing requirements, effectively excluding us from all or part of the China market, as well as other impacted markets, including the Middle East. In addition to export controls, the USG may impose restrictions on the import and sale of products that incorporate technologies developed or manufactured in whole or in part in China. For example, the USG is considering restrictions on the import and sale of certain automotive products in the United States, which if adopted and interpreted broadly, could impact our ability to develop and supply solutions for our automotive customers.

[0001045810-24-000316:mdna:24]
While we work to enhance the resiliency and redundancy of our supply chain, which is currently concentrated in the Asia-Pacific region, new and existing export controls or changes to existing export controls could limit alternative

[0001045810-24-000316:mdna:25]
manufacturing locations and negatively impact our business. Refer to “Item 1A. Risk Factors” for a discussion of this potential impact.

[0001045810-24-000316:mdna:26]
[same as prior period, unchanged from 0001045810-24-000264:mdna:25]

[0001045810-24-000316:mdna:27]
[same as prior period, unchanged from 0001045810-24-000264:mdna:26]

[0001045810-24-000316:mdna:28]
[same as prior period, unchanged from 0001045810-24-000264:mdna:27]

[0001045810-24-000316:mdna:29]
We are monitoring the impact of the geopolitical conflict in and around Israel on our operations, including the health and safety of our approximately 4,300 employees in the region who primarily support the research and development, operations, and sales and marketing of our networking products. Our global supply chain for our networking products has not experienced any significant impact. A substantial number of our employees in the region have been called-up for active military duty in Israel. Some employees in Israel have been on active military duty for an extended period and may continue to be absent, which may cause disruption to our product development or operations. We have not experienced significant impact or expense to our business; however, if the conflict is further extended or expanded, it could impact future product development, operations, and revenue or create other uncertainty for our business.

[0001045810-24-000316:mdna:30]
Third Quarter of Fiscal Year 2025 Summary

[0001045810-24-000316:mdna:31]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Oct 27, 2024 |  | Jul 28, 2024 |  | Oct 29, 2023 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 35,082 |  |  | $ | 30,040 |  |  | $ | 18,120 |  |  | 17 | % |  | 94 | % |
| Gross margin | 74.6 | % |  | 75.1 | % |  | 74.0 | % |  | (0.5) pts |  | 0.6 pts |
| Operating expenses | $ | 4,287 |  |  | $ | 3,932 |  |  | $ | 2,983 |  |  | 9 | % |  | 44 | % |
| Operating income | $ | 21,869 |  |  | $ | 18,642 |  |  | $ | 10,417 |  |  | 17 | % |  | 110 | % |
| Net income | $ | 19,309 |  |  | $ | 16,599 |  |  | $ | 9,243 |  |  | 16 | % |  | 109 | % |
| Net income per diluted share | $ | 0.78 |  |  | $ | 0.67 |  |  | $ | 0.37 |  |  | 16 | % |  | 111 | % |

[0001045810-24-000316:mdna:32]
[same as prior period, unchanged from 0001045810-24-000264:mdna:31]

[0001045810-24-000316:mdna:33]
Revenue was $35.1 billion, up 94% from a year ago and up 17% sequentially.

[0001045810-24-000316:mdna:34]
Data Center revenue was up 112% from a year ago and up 17% sequentially. The strong year-on-year and sequential growth was driven by demand for our Hopper computing platform for training and inferencing of large language models, recommendation engines, and generative AI applications. Cloud service providers represented approximately 50% of our Data Center revenue, and the remainder was represented by consumer internet and enterprise companies. Strong year-on-year growth was driven by all customer types from both compute and networking. Demand for the Hopper architecture is strong and our H200 offering grew significantly in the quarter. Data Center compute revenue was $27.6 billion, up 132% from a year ago and up 22% sequentially. Networking revenue was $3.1 billion, up 20% from a year ago driven by Ethernet for AI, which includes Spectrum-X end-to-end ethernet platform. Areas of sequential revenue growth include InfiniBand and Ethernet switches, SmartNICs, and BlueField DPUs. Though networking revenue was sequentially down 15%, networking demand is strong and growing.

[0001045810-24-000316:mdna:35]
Gaming revenue was up 15% from a year ago and up 14% sequentially. These increases were driven by sales of our GeForce RTX 40 Series GPUs and game console SoCs.

[0001045810-24-000316:mdna:36]
Professional Visualization revenue was up 17% from a year ago and up 7% sequentially. These increases were driven by the continued ramp of RTX GPU workstations based on our Ada architecture.

[0001045810-24-000316:mdna:37]
Automotive revenue was up 72% from a year ago and up 30% sequentially. These increases were driven by our self-driving platforms.

[0001045810-24-000316:mdna:38]
Gross margin increased from a year ago due to a higher mix of Data Center revenue. Sequentially, gross margin decreased primarily driven by a mix shift from H100 systems to more complex and higher cost systems within Data Center.

[0001045810-24-000316:mdna:39]
Operating expenses were up 44% from a year ago and up 9% sequentially, driven by higher compensation and benefits expenses due to employee growth and compensation increases.

[0001045810-24-000316:mdna:40]
[same as prior period, unchanged from 0001045810-24-000264:mdna:45]

[0001045810-24-000316:mdna:41]
[same as prior period, unchanged from 0001045810-24-000264:mdna:46]

[0001045810-24-000316:mdna:42]
[same as prior period, unchanged from 0001045810-24-000264:mdna:47]

[0001045810-24-000316:mdna:43]
[same as prior period, unchanged from 0001045810-24-000264:mdna:48]

[0001045810-24-000316:mdna:44]
[same as prior period, unchanged from 0001045810-24-000264:mdna:49]

[0001045810-24-000316:mdna:45]
[same as prior period, unchanged from 0001045810-24-000264:mdna:50]

[0001045810-24-000316:mdna:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 25.4 |  |  | 26.0 |  |  | 24.2 |  |  | 29.1 |  |
| Gross profit | 74.6 |  |  | 74.0 |  |  | 75.8 |  |  | 70.9 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 9.7 |  |  | 12.7 |  |  | 10.1 |  |  | 16.0 |  |
| Sales, general and administrative | 2.6 |  |  | 3.8 |  |  | 2.8 |  |  | 5.0 |  |
| Total operating expenses | 12.3 |  |  | 16.5 |  |  | 12.9 |  |  | 21.0 |  |
| Operating income | 62.3 |  |  | 57.5 |  |  | 62.9 |  |  | 49.9 |  |
| Interest income | 1.3 |  |  | 1.3 |  |  | 1.4 |  |  | 1.5 |  |
| Interest expense | (0.2) |  |  | (0.3) |  |  | (0.2) |  |  | (0.5) |  |
| Other, net | 0.1 |  |  | (0.4) |  |  | 0.3 |  |  | (0.1) |  |
| Other income (expense), net | 1.2 |  |  | 0.6 |  |  | 1.5 |  |  | 0.9 |  |
| Income before income tax | 63.5 |  |  | 58.1 |  |  | 64.4 |  |  | 50.8 |  |
| Income tax expense | 8.6 |  |  | 7.1 |  |  | 8.8 |  |  | 5.8 |  |
| Net income | 54.9 | % |  | 51.0 | % |  | 55.6 | % |  | 45.0 | % |

[0001045810-24-000316:mdna:47]
[same as prior period, unchanged from 0001045810-24-000264:mdna:52]

[0001045810-24-000316:mdna:48]
[same as prior period, unchanged from 0001045810-24-000264:mdna:53]

[0001045810-24-000316:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | %Change |  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 31,036 |  |  | $ | 14,645 |  |  | $ | 16,391 |  |  | 112 | % |  | $ | 80,157 |  |  | $ | 29,507 |  |  | $ | 50,650 |  |  | 172 | % |
| Graphics | 4,046 |  |  | 3,475 |  |  | 571 |  |  | 16 | % |  | 11,009 |  |  | 9,312 |  |  | 1,697 |  |  | 18 | % |
| Total | $ | 35,082 |  |  | $ | 18,120 |  |  | $ | 16,962 |  |  | 94 | % |  | $ | 91,166 |  |  | $ | 38,819 |  |  | $ | 52,347 |  |  | 135 | % |

[0001045810-24-000316:mdna:50]
[same as prior period, unchanged from 0001045810-24-000264:mdna:55]

[0001045810-24-000316:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | %Change |  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 22,081 |  |  | $ | 10,262 |  |  | $ | 11,819 |  |  | 115 | % |  | $ | 57,977 |  |  | $ | 19,149 |  |  | $ | 38,828 |  |  | 203 | % |
| Graphics | 1,502 |  |  | 1,493 |  |  | 9 |  |  | 1 | % |  | $ | 4,111 |  |  | 3,751 |  |  | 360 |  |  | 10 | % |
| All Other | (1,714) |  |  | (1,338) |  |  | (376) |  |  | 28 | % |  | $ | (4,669) |  |  | (3,542) |  |  | (1,127) |  |  | 32 | % |
| Total | $ | 21,869 |  |  | $ | 10,417 |  |  | $ | 11,452 |  |  | 110 | % |  | $ | 57,419 |  |  | $ | 19,358 |  |  | $ | 38,061 |  |  | 197 | % |

[0001045810-24-000316:mdna:52]
Compute & Networking revenue – The year over year increase in the third quarter and first nine months of fiscal year 2025 was due to strength in Data Center computing for accelerated computing and AI solutions. Revenue from Data Center computing grew 133% year-on-year and 195% compared to the first nine months of fiscal year 2024 driven by demand for our Hopper computing platform for training and inferencing of large language models, recommendation engines, and generative AI applications. Networking was up 20% year-on-year and 90% compared to the first nine months of fiscal year 2024 driven by Ethernet for AI revenue, which includes Spectrum-X end-to-end ethernet platform.

[0001045810-24-000316:mdna:53]
Graphics revenue – The year over year increase in the third quarter and first nine months of fiscal year 2025 was led by higher sales of our GeForce RTX 40 Series GPUs.

[0001045810-24-000316:mdna:54]
Reportable segment operating income – The year over year increase in Compute & Networking segment operating income in the third quarter and first nine months of fiscal year 2025 was primarily driven by growth in data center revenue. The year over year increase in Graphics segment operating income in the third quarter of fiscal year 2025 was primarily driven by growth in revenue, partially offset by an increase of 52% in segment operating expense. The year over year increase in Graphics segment operating income in the first nine months of fiscal year 2025 was primarily driven by growth in revenue.

[0001045810-24-000316:mdna:55]
All Other operating loss – The year over year increase in the third quarter and first nine months of fiscal year 2025 was due to an increase in stock-based compensation expense reflecting employee growth and compensation increases.

[0001045810-24-000316:mdna:56]
[same as prior period, unchanged from 0001045810-24-000264:mdna:62]

[0001045810-24-000316:mdna:57]
Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to indirect customers, such as enterprises and gamers in a different location. Revenue from sales to customers outside of the United States accounted for 58% and 65% of total revenue for the third quarter, and 55% and 62% of total revenue for the first nine months, of fiscal years 2025 and 2024, respectively.

[0001045810-24-000316:mdna:58]
[same as prior period, unchanged from 0001045810-24-000264:mdna:64]

[0001045810-24-000316:mdna:59]
[same as prior period, unchanged from 0001045810-24-000264:mdna:65]

[0001045810-24-000316:mdna:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 27, 2024 |
| Customer A | 12 | % |  | * |
| Customer B | 12 | % |  | 11 | % |
| Customer C | 12 | % |  | 11 | % |
| Customer D | * |  | 12 | % |

[0001045810-24-000316:mdna:61]
[same as prior period, unchanged from 0001045810-24-000264:mdna:67]

[0001045810-24-000316:mdna:62]
The customer references of A-D above may represent different customers than those reported in a previous period.

[0001045810-24-000316:mdna:63]
For the third quarter and first nine months of fiscal year 2025, an indirect customer which primarily purchases our products through system integrators and distributors, including through Customer C, is estimated to represent 10% or more of total revenue, attributable to the Compute & Networking segment.

[0001045810-24-000316:mdna:64]
[same as prior period, unchanged from 0001045810-24-000264:mdna:58]

[0001045810-24-000316:mdna:65]
[same as prior period, unchanged from 0001045810-24-000264:mdna:70]

[0001045810-24-000316:mdna:66]
[same as prior period, unchanged from 0001045810-24-000264:mdna:71]

[0001045810-24-000316:mdna:67]
[same as prior period, unchanged from 0001045810-24-000264:mdna:72]

[0001045810-24-000316:mdna:68]
[same as prior period, unchanged from 0001045810-24-000264:mdna:73]

[0001045810-24-000316:mdna:69]
Gross margins increased to 74.6% for the third quarter of fiscal year 2025 compared to 74.0% for the third quarter of fiscal year 2024, due to a higher mix of Data Center revenue. Gross margins increased to 75.8% for the first nine months of fiscal year 2025 compared to 70.9% for the first nine months of fiscal year 2024, primarily due to higher mix of Data Center revenue.

[0001045810-24-000316:mdna:70]
Provisions for inventory and excess inventory purchase obligations totaled $865 million and $2.2 billion for the third quarter and first nine months of fiscal year 2025, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $106 million and $305 million for the third quarter and first nine months of fiscal year 2025, respectively. The net effect on our gross margin was an unfavorable impact of 2.2% and 2.0% in the third quarter and first nine months of fiscal year 2025, respectively.

[0001045810-24-000316:mdna:71]
Provisions for inventory and excess inventory purchase obligations totaled $681 million and $1.4 billion for the third quarter and first nine months of fiscal year 2024, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $239 million and $372 million for the third quarter and first nine months of fiscal year 2024, respectively. The net effect on our gross margin was an unfavorable impact of 2.4% and 2.6% in the third quarter and first nine months of fiscal year 2024, respectively.

[0001045810-24-000316:mdna:72]
[same as prior period, unchanged from 0001045810-24-000264:mdna:80]

[0001045810-24-000316:mdna:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | %Change |  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 3,390 |  |  | $ | 2,294 |  |  | $ | 1,096 |  |  | 48 | % |  | $ | 9,200 |  |  | $ | 6,210 |  |  | $ | 2,990 |  |  | 48 | % |
| % of net revenue | 9.7 | % |  | 12.7 | % |  |  |  |  |  | 10.1 | % |  | 16.0 | % |  |  |  |  |
| Sales, general and administrative expenses | 897 |  |  | 689 |  |  | 208 |  |  | 30 | % |  | 2,516 |  |  | 1,942 |  |  | 574 |  |  | 30 | % |
| % of net revenue | 2.6 | % |  | 3.8 | % |  |  |  |  |  | 2.8 | % |  | 5.0 | % |  |  |  |  |
| Total operating expenses | $ | 4,287 |  |  | $ | 2,983 |  |  | $ | 1,304 |  |  | 44 | % |  | $ | 11,716 |  |  | $ | 8,152 |  |  | $ | 3,564 |  |  | 44 | % |
| % of net revenue | 12.3 | % |  | 16.5 | % |  |  |  |  |  | 12.9 | % |  | 21.0 | % |  |  |  |  |

[0001045810-24-000316:mdna:74]
The increases in research and development expenses for the third quarter and first nine months of fiscal year 2025 were driven by a 29% and 32% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, a 107% and 113% increase in compute and infrastructure, and a 317% and 209% increase in engineering development costs for new product introductions, respectively.

[0001045810-24-000316:mdna:75]
The increases in sales, general and administrative expenses for the third quarter and first nine months of fiscal year 2025 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-24-000316:mdna:76]
[same as prior period, unchanged from 0001045810-24-000264:mdna:85]

[0001045810-24-000316:mdna:77]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |  | Oct 27, 2024 |  | Oct 29, 2023 |  | $Change |
|  | ($ in millions) |
| Interest income | $ | 472 |  |  | $ | 234 |  |  | $ | 238 |  |  | $ | 1,275 |  |  | $ | 572 |  |  | $ | 703 |  |
| Interest expense | (61) |  |  | (63) |  |  | 2 |  |  | (186) |  |  | (194) |  |  | 8 |  |
| Other, net | 36 |  |  | (66) |  |  | 102 |  |  | 301 |  |  | (24) |  |  | 325 |  |
| Other income (expense), net | $ | 447 |  |  | $ | 105 |  |  | $ | 342 |  |  | $ | 1,390 |  |  | $ | 354 |  |  | $ | 1,036 |  |

[0001045810-24-000316:mdna:78]
The increases in interest income for the third quarter and first nine months of fiscal year 2025 was primarily due to growth in cash, cash equivalents, and publicly-held debt security balances.

[0001045810-24-000316:mdna:79]
[same as prior period, unchanged from 0001045810-24-000264:mdna:88]

[0001045810-24-000316:mdna:80]
Other, net consists of realized or unrealized gains and losses from investments in privately-held equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other, net, compared to the third quarter and first nine months of fiscal year 2024, was primarily driven by an increase in fair value of our privately-held and publicly-held equity securities. Refer to Note 6 and 7 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding our investments in privately-held and publicly-held equity securities.

[0001045810-24-000316:mdna:81]
[same as prior period, unchanged from 0001045810-24-000264:mdna:90]

[0001045810-24-000316:mdna:82]
Income tax expense was $3.0 billion and $1.3 billion for the third quarter, and $8.0 billion and $2.2 billion for the first nine months, of fiscal years 2025 and 2024, respectively. The income tax expense as a percentage of income before income tax was 13.5% and 12.2% for the third quarter, and 13.6% and 11.3% for the first nine months, of fiscal years 2025 and 2024, respectively.

[0001045810-24-000316:mdna:83]
The effective tax rate increased primarily due to a lower percentage of tax benefits from the foreign-derived intangible income deduction relative to the increase in income before income tax and a discrete benefit in fiscal year 2024 due to an IRS audit resolution.

[0001045810-24-000316:mdna:84]
Given our current and possible future earnings, we believe that we may release the valuation allowance associated with certain state deferred tax assets in the near term, which would decrease our income tax expense for the period the release is recorded. The timing and amount of the valuation allowance release could vary based on our assessment of all available information.

[0001045810-24-000316:mdna:85]
[same as prior period, unchanged from 0001045810-24-000264:mdna:94]

[0001045810-24-000316:mdna:86]
[same as prior period, unchanged from 0001045810-24-000264:mdna:95]

[0001045810-24-000316:mdna:87]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | (In millions) |
| Cash and cash equivalents | $ | 9,107 |  |  | $ | 7,280 |  |
| Marketable securities | 29,380 |  |  | 18,704 |  |
| Cash, cash equivalents and marketable securities | $ | 38,487 |  |  | $ | 25,984 |  |

[0001045810-24-000316:mdna:88]
|  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 47,460 |  |  | $ | 16,591 |  |
| Net cash used in investing activities | $ | (13,223) |  |  | $ | (4,457) |  |
| Net cash used in financing activities | $ | (32,410) |  |  | $ | (10,004) |  |

[0001045810-24-000316:mdna:89]
[same as prior period, unchanged from 0001045810-24-000264:mdna:98]

[0001045810-24-000316:mdna:90]
30

[0001045810-24-000316:mdna:91]
Cash provided by operating activities increased in the first nine months of fiscal year 2025 compared to the first nine months of fiscal year 2024 due to growth in revenue, partially offset by advanced payments on supply agreements. Our accounts receivable balance at the end of the first nine months of fiscal year 2025 reflects the strong revenue growth, partially offset by $1.7 billion from customer payments received prior to the invoice due date.

[0001045810-24-000316:mdna:92]
Cash used in investing activities increased in the first nine months of fiscal year 2025 compared to the first nine months of fiscal year 2024, primarily driven by net purchases of marketable securities, and purchase of land, property and equipment.

[0001045810-24-000316:mdna:93]
Cash used in financing activities increased in the first nine months of fiscal year 2025 compared to the first nine months of fiscal year 2024, mainly due to higher share repurchases and higher tax payments related to RSUs.

[0001045810-24-000316:mdna:94]
[same as prior period, unchanged from 0001045810-24-000264:mdna:102]

[0001045810-24-000316:mdna:95]
Our primary sources of liquidity include cash, cash equivalents, and marketable securities, and the cash generated by our operations. As of October 27, 2024, we had $38.5 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations and share repurchases. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-24-000316:mdna:96]
[same as prior period, unchanged from 0001045810-24-000264:mdna:104]

[0001045810-24-000316:mdna:97]
Except for approximately $1.4 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents, and marketable securities held outside the U.S. as of October 27, 2024 are available for use in the U.S. without incurring additional U.S. federal income taxes.

[0001045810-24-000316:mdna:98]
[same as prior period, unchanged from 0001045810-24-000264:mdna:106]

[0001045810-24-000316:mdna:99]
[same as prior period, unchanged from 0001045810-24-000264:mdna:107]

[0001045810-24-000316:mdna:100]
We paid cash dividends to our shareholders of $245 million and $589 million during the third quarter and first nine months of fiscal year 2025, respectively.

[0001045810-24-000316:mdna:101]
[same as prior period, unchanged from 0001045810-24-000264:mdna:109]

[0001045810-24-000316:mdna:102]
We repurchased 92 million and 254 million shares of our common stock for $11.1 billion and $26.2 billion during the third quarter and first nine months of fiscal year 2025, respectively. On August 26, 2024, our Board of Directors approved an additional $50 billion to our share repurchase authorization, without expiration. As of October 27, 2024, we were authorized, subject to certain specifications, to repurchase up to $46.4 billion of our common stock. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities. We plan to continue share repurchases this fiscal year.

[0001045810-24-000316:mdna:103]
From October 28, 2024 through November 15, 2024, we repurchased 19 million shares for $2.7 billion pursuant to a pre-established trading plan.

[0001045810-24-000316:mdna:104]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for the third quarter and first nine months of fiscal year 2025.

[0001045810-24-000316:mdna:105]
[same as prior period, unchanged from 0001045810-24-000264:mdna:114]

[0001045810-24-000316:mdna:106]
Our aggregate debt maturities as of October 27, 2024, by year payable, are as follows:

[0001045810-24-000316:mdna:107]
|  |  | Oct 27, 2024 |
|  |  | (In millions) |
| Due in one year |  | $ | — |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 2,750 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (38) |  |
| Net long-term carrying amount |  | $ | 8,462 |  |

[0001045810-24-000316:mdna:108]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2024, we had no commercial paper outstanding.

[0001045810-24-000316:mdna:109]
[same as prior period, unchanged from 0001045810-24-000264:mdna:118]

[0001045810-24-000316:mdna:110]
[same as prior period, unchanged from 0001045810-24-000264:mdna:119]

[0001045810-24-000316:mdna:111]
Unrecognized tax benefits were $1.9 billion, which includes related interest and penalties of $215 million recorded in non-current income tax payable as of October 27, 2024. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-24-000316:mdna:112]
[same as prior period, unchanged from 0001045810-24-000264:mdna:122]

[0001045810-24-000316:mdna:113]
[same as prior period, unchanged from 0001045810-24-000264:mdna:123]

[0001045810-24-000316:mdna:114]
[same as prior period, unchanged from 0001045810-24-000264:mdna:124]

[0001045810-24-000316:mdna:115]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-24-000316:mdna:116]
There has been no adoption of any new and recently issued accounting pronouncements.
