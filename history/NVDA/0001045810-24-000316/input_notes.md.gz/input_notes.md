# NVDA notes — 0001045810-24-000316


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-24-000316:notes:1]
[same as prior period, unchanged from 0001045810-24-000264:notes:1]

[0001045810-24-000316:notes:2]
[same as prior period, unchanged from 0001045810-24-000264:notes:2]

[0001045810-24-000316:notes:3]
[same as prior period, unchanged from 0001045810-24-000264:notes:3]

[0001045810-24-000316:notes:4]
[same as prior period, unchanged from 0001045810-24-000264:notes:4]

[0001045810-24-000316:notes:5]
[same as prior period, unchanged from 0001045810-24-000264:notes:5]

[0001045810-24-000316:notes:6]
[same as prior period, unchanged from 0001045810-24-000264:notes:6]

[0001045810-24-000316:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The third quarters of fiscal years 2025 and 2024 were both 13-week quarters.

[0001045810-24-000316:notes:8]
[same as prior period, unchanged from 0001045810-24-000264:notes:8]

[0001045810-24-000316:notes:9]
[same as prior period, unchanged from 0001045810-24-000264:notes:9]

[0001045810-24-000316:notes:10]
[same as prior period, unchanged from 0001045810-24-000264:notes:10]

[0001045810-24-000316:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, other contingencies, property, plant, and equipment, revenue recognition, and stock-based compensation. These estimates are based on historical facts and other assumptions that we believe are reasonable.

[0001045810-24-000316:notes:12]
Recently Issued Accounting Pronouncements

[0001045810-24-000316:notes:13]
[same as prior period, unchanged from 0001045810-24-000264:notes:13]

[0001045810-24-000316:notes:14]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of significant expenses in operating segments. We expect to adopt this standard in our fiscal year 2025 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

[0001045810-24-000316:notes:15]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. We expect to adopt this standard in our fiscal year 2026 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

[0001045810-24-000316:notes:16]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory,

[0001045810-24-000316:notes:17]
employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We expect to adopt this standard in our fiscal year 2028 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-24-000316:notes:18]
Leases
Our lease obligations primarily consist of operating leases for our headquarters' campus and domestic and international offices and data centers, with lease periods expiring between fiscal years 2025 and 2036.

[0001045810-24-000316:notes:19]
Future minimum lease obligations under our non-cancelable lease agreements as of October 27, 2024 were as follows:

[0001045810-24-000316:notes:20]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding the first nine months of fiscal year 2025) | $ | 78 |  |
| 2026 | 336 |  |
| 2027 | 340 |  |
| 2028 | 320 |  |
| 2029 | 288 |  |
| 2030 and thereafter | 667 |  |
| Total | 2,029 |  |
| Less imputed interest | 266 |  |
| Present value of net future minimum lease payments | 1,763 |  |
| Less short-term operating lease liabilities | 273 |  |
| Long-term operating lease liabilities | $ | 1,490 |  |

[0001045810-24-000316:notes:21]
Between the fourth quarter of fiscal year 2025 and fiscal year 2027, we expect to commence leases with future obligations of $4.2 billion primarily of data center and office operating leases, with lease terms of 1.5 to 15.5 years.

[0001045810-24-000316:notes:22]
Operating lease expenses were $92 million and $69 million for the third quarter, and $258 million and $195 million for the first nine months, of fiscal years 2025 and 2024, respectively. Short-term and variable lease expenses for the third quarter and first nine months of fiscal years 2025 and 2024 were not significant.

[0001045810-24-000316:notes:23]
[same as prior period, unchanged from 0001045810-24-000264:notes:21]

[0001045810-24-000316:notes:24]
|  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 227 |  |  | $ | 200 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 679 |  |  | $ | 439 |  |

[0001045810-24-000316:notes:25]
As of October 27, 2024, our operating leases have a weighted average remaining lease term of 6.5 years and a weighted average discount rate of 4.15%. As of January 28, 2024, our operating leases had a weighted average remaining lease term of 6.1 years and a weighted average discount rate of 3.76%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-24-000316:notes:26]
Stock-Based Compensation
Stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units, or PSUs, that are based on our corporate financial performance targets, market-based PSUs that are performance stock units based on our performance compared to market performance, and the employee stock purchase plan, or ESPP.

[0001045810-24-000316:notes:27]
[same as prior period, unchanged from 0001045810-24-000264:notes:25]

[0001045810-24-000316:notes:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Cost of revenue | $ | 50 |  |  | $ | 38 |  |  | $ | 125 |  |  | $ | 96 |  |
| Research and development | 910 |  |  | 701 |  |  | 2,469 |  |  | 1,826 |  |
| Sales, general and administrative | 292 |  |  | 240 |  |  | 822 |  |  | 633 |  |
| Total | $ | 1,252 |  |  | $ | 979 |  |  | $ | 3,416 |  |  | $ | 2,555 |  |

[0001045810-24-000316:notes:29]
[same as prior period, unchanged from 0001045810-24-000264:notes:27]

[0001045810-24-000316:notes:30]
[same as prior period, unchanged from 0001045810-24-000264:notes:28]

[0001045810-24-000316:notes:31]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balance as of Jan 28, 2024 | 367 |  |  | $ | 24.59 |  |  |  |  |  |
| Granted | 84 |  |  | $ | 84.70 |  |  |  |  |  |
| Vested | (135) |  |  | $ | 23.03 |  |  |  |  |  |
| Canceled and forfeited | (8) |  |  | $ | 31.23 |  |  |  |  |  |
| Balance as of Oct 27, 2024 | 308 |  |  | $ | 41.45 |  |  |  |  |  |

[0001045810-24-000316:notes:32]
As of October 27, 2024, aggregate unearned stock-based compensation expense was $12.4 billion, which is expected to be recognized over a weighted average period of 2.3 years for RSUs, PSUs, and market-based PSUs, and one year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-24-000316:notes:33]
[same as prior period, unchanged from 0001045810-24-000264:notes:31]

[0001045810-24-000316:notes:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 19,309 |  |  | $ | 9,243 |  |  | $ | 50,789 |  |  | $ | 17,475 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,533 |  |  | 24,680 |  |  | 24,577 |  |  | 24,700 |  |
| Dilutive impact of outstanding equity awards | 241 |  |  | 260 |  |  | 260 |  |  | 240 |  |
| Diluted weighted average shares | 24,774 |  |  | 24,940 |  |  | 24,837 |  |  | 24,940 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.79 |  |  | $ | 0.37 |  |  | $ | 2.07 |  |  | $ | 0.71 |  |
| Diluted (2) | $ | 0.78 |  |  | $ | 0.37 |  |  | $ | 2.04 |  |  | $ | 0.70 |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 9 |  |  | 10 |  |  | 72 |  |  | 140 |  |

[0001045810-24-000316:notes:35]
(1)    Net income divided by basic weighted average shares.

[0001045810-24-000316:notes:36]
(2)    Net income divided by diluted weighted average shares.

[0001045810-24-000316:notes:37]
Diluted net income per share was computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-24-000316:notes:38]
Income Taxes
Income tax expense was $3.0 billion and $1.3 billion for the third quarter, and $8.0 billion and $2.2 billion for the first nine months, of fiscal years 2025 and 2024, respectively. The income tax expense as a percentage of income before income

[0001045810-24-000316:notes:39]
tax was 13.5% and 12.2% for the third quarter, and 13.6% and 11.3% for the first nine months, of fiscal years 2025 and 2024, respectively.

[0001045810-24-000316:notes:40]
The effective tax rate increased primarily due to a lower percentage of tax benefits from the foreign-derived intangible income deduction relative to the increase in income before income tax and a discrete benefit in fiscal year 2024 due to an IRS audit resolution.

[0001045810-24-000316:notes:41]
Effective tax rates for the first nine months of fiscal years 2025 and 2024 were lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, the U.S. federal research tax credit, and income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate.

[0001045810-24-000316:notes:42]
Given our current and possible future earnings, we believe that we may release the valuation allowance associated with certain state deferred tax assets in the near term, which would decrease our income tax expense for the period the release is recorded. The timing and amount of the valuation allowance release could vary based on our assessment of all available information.

[0001045810-24-000316:notes:43]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 27, 2024, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-24-000316:notes:44]
Cash Equivalents and Marketable Securities 
The following is a summary of cash equivalents and marketable securities:

[0001045810-24-000316:notes:45]
|  | Oct 27, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,629 |  |  | $ | 72 |  |  | $ | (12) |  |  | $ | 14,689 |  |  | $ | 1,795 |  |  | $ | 12,894 |  |
| Corporate debt securities | 14,221 |  |  | 74 |  |  | (17) |  |  | 14,278 |  |  | 1,154 |  |  | 13,124 |  |
| Money market funds | 5,147 |  |  | — |  |  | — |  |  | 5,147 |  |  | 5,147 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 3,542 |  |  | 11 |  |  | (4) |  |  | 3,549 |  |  | 759 |  |  | 2,790 |  |
| Certificates of deposit | 142 |  |  | — |  |  | — |  |  | 142 |  |  | 42 |  |  | 100 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 37,681 |  |  | 157 |  |  | (33) |  |  | 37,805 |  |  | 8,897 |  |  | 28,908 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 472 |  |  | — |  |  | 472 |  |
| Total | $ | 37,681 |  |  | $ | 157 |  |  | $ | (33) |  |  | $ | 38,277 |  |  | $ | 8,897 |  |  | $ | 29,380 |  |

[0001045810-24-000316:notes:46]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. Beginning in the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

[0001045810-24-000316:notes:47]
Net unrealized gains on investments in publicly-held equity securities were not significant and $195 million for the third quarter and first nine months of fiscal year 2025, respectively. Net unrealized gains on investments in publicly-held equity securities were not significant for the third quarter and first nine months of fiscal year 2024.

[0001045810-24-000316:notes:48]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total debt securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

[0001045810-24-000316:notes:49]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-24-000316:notes:50]
|  | Oct 27, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Corporate debt securities | $ | 2,967 |  |  | $ | (17) |  |  | $ | 105 |  |  | $ | — |  |  | $ | 3,072 |  |  | $ | (17) |  |
| Debt securities issued by the U.S. Treasury | 2,562 |  |  | (12) |  |  | 532 |  |  | — |  |  | 3,094 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,134 |  |  | (4) |  |  | 21 |  |  | — |  |  | 1,155 |  |  | (4) |  |
| Total | $ | 6,663 |  |  | $ | (33) |  |  | $ | 658 |  |  | $ | — |  |  | $ | 7,321 |  |  | $ | (33) |  |

[0001045810-24-000316:notes:51]
|  | Jan 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 3,343 |  |  | $ | (5) |  |  | $ | 1,078 |  |  | $ | (5) |  |  | $ | 4,421 |  |  | $ | (10) |  |
| Corporate debt securities | 1,306 |  |  | (3) |  |  | 618 |  |  | (2) |  |  | 1,924 |  |  | (5) |  |
| Debt securities issued by U.S. government agencies | 670 |  |  | (1) |  |  | — |  |  | — |  |  | 670 |  |  | (1) |  |
| Total | $ | 5,319 |  |  | $ | (9) |  |  | $ | 1,696 |  |  | $ | (7) |  |  | $ | 7,015 |  |  | $ | (16) |  |

[0001045810-24-000316:notes:52]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-24-000316:notes:53]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-24-000316:notes:54]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,695 |  |  | $ | 17,715 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 19,986 |  |  | 20,090 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 37,681 |  |  | $ | 37,805 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-24-000316:notes:55]
[same as prior period, unchanged from 0001045810-24-000264:notes:52]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-24-000316:notes:56]
[same as prior period, unchanged from 0001045810-24-000264:notes:53]

[0001045810-24-000316:notes:57]
|  | Pricing Category |  | Fair Value at |
|  |  | Oct 27, 2024 |  | Jan 28, 2024 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 5,147 |  |  | $ | 3,031 |  |
| Publicly-held equity securities | Level 1 |  | $ | 472 |  |  | $ | — |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 14,689 |  |  | $ | 9,524 |  |
| Corporate debt securities | Level 2 |  | $ | 14,278 |  |  | $ | 10,152 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 3,549 |  |  | $ | 2,333 |  |
| Certificates of deposit | Level 2 |  | $ | 142 |  |  | $ | 510 |  |
| Foreign government bonds | Level 2 |  | $ | — |  |  | $ | 174 |  |
| Other assets (Investments in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities | Level 1 |  | $ | — |  |  | $ | 225 |  |
| Liabilities (1) |  |  |  |  |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | — |  |  | $ | 1,228 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 982 |  |  | $ | 970 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,139 |  |  | $ | 1,115 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,391 |  |  | $ | 1,367 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,079 |  |  | $ | 1,057 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 847 |  |  | $ | 851 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,556 |  |  | $ | 1,604 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 388 |  |  | $ | 403 |  |

[0001045810-24-000316:notes:58]
(1)    Liabilities are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs.

[0001045810-24-000316:notes:59]
[same as prior period, unchanged from 0001045810-24-000264:notes:56]

[0001045810-24-000316:notes:60]
Our investments in non-affiliated entities include non-marketable equity securities, which are primarily investments in privately held companies. Beginning in the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

[0001045810-24-000316:notes:61]
[same as prior period, unchanged from 0001045810-24-000264:notes:58]

[0001045810-24-000316:notes:62]
Adjustments to the carrying value of our non-marketable equity securities during the third quarter and first nine months of fiscal years 2025 and 2024 were as follows:

[0001045810-24-000316:notes:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,819 |  |  | $ | 676 |  |  | $ | 1,321 |  |  | $ | 288 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 409 |  |  | 341 |  |  | 830 |  |  | 743 |  |
| Unrealized gains | 23 |  |  | 3 |  |  | 115 |  |  | 3 |  |
| Impairments and unrealized losses | (14) |  |  | (1) |  |  | (29) |  |  | (15) |  |
| Balance at end of period | $ | 2,237 |  |  | $ | 1,019 |  |  | $ | 2,237 |  |  | $ | 1,019 |  |

[0001045810-24-000316:notes:64]
Non-marketable equity securities had cumulative gross unrealized gains of $374 million and cumulative gross losses and impairments of $74 million as of October 27, 2024.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-24-000316:notes:65]
[same as prior period, unchanged from 0001045810-24-000264:notes:62]

[0001045810-24-000316:notes:66]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 2,785 |  |  | $ | (2,117) |  |  | $ | 668 |  |  | $ | 2,642 |  |  | $ | (1,720) |  |  | $ | 922 |  |
| Patents and licensed technology | 444 |  |  | (274) |  |  | 170 |  |  | 449 |  |  | (259) |  |  | 190 |  |
| Total intangible assets | $ | 3,229 |  |  | $ | (2,391) |  |  | $ | 838 |  |  | $ | 3,091 |  |  | $ | (1,979) |  |  | $ | 1,112 |  |

[0001045810-24-000316:notes:67]
Amortization expense associated with intangible assets was $149 million and $144 million for the third quarter, and $438 million and $471 million for the first nine months, of fiscal years 2025 and 2024, respectively.

[0001045810-24-000316:notes:68]
The following table outlines the estimated amortization expense related to the net carrying amount of intangible assets as of October 27, 2024:

[0001045810-24-000316:notes:69]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding the first nine months of fiscal year 2025) | $ | 150 |  |
| 2026 | 317 |  |
| 2027 | 203 |  |
| 2028 | 57 |  |
| 2029 | 10 |  |
| 2030 and thereafter | 101 |  |
| Total | $ | 838 |  |

[0001045810-24-000316:notes:70]
In the first nine months of fiscal year 2025, goodwill increased by $294 million from business combinations assigned to our Compute & Networking reporting unit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-24-000316:notes:71]
Balance Sheet Components 
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, original device manufacturers, or ODMs, original equipment manufacturers, or OEMs, and system integrators. Four direct customers accounted for 18%, 13%, 11% and 11% of our accounts receivable balance as of October 27, 2024. Two direct customers accounted for 24% and 11% of our accounts receivable balance as of January 28, 2024.

[0001045810-24-000316:notes:72]
[same as prior period, unchanged from 0001045810-24-000264:notes:69]

[0001045810-24-000316:notes:73]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
| Inventories: | (In millions) |
| Raw materials | $ | 1,846 |  |  | $ | 1,719 |  |
| Work in process | 2,881 |  |  | 1,505 |  |
| Finished goods | 2,927 |  |  | 2,058 |  |
| Total inventories (1) | $ | 7,654 |  |  | $ | 5,282 |  |

[0001045810-24-000316:notes:74]
(1)    We recorded an inventory provision of $322 million and $208 million for the third quarter, and $876 million and $657 million for the first nine months, of fiscal years 2025 and 2024, respectively, in cost of revenue.

[0001045810-24-000316:notes:75]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
| Other Assets (Long Term): | (In millions) |
| Investments in non-affiliated entities | $ | 2,237 |  |  | $ | 1,546 |  |
| Prepaid supply and capacity agreements (1) | 2,041 |  |  | 2,458 |  |
| Income tax receivable | 568 |  |  | — |  |
| Prepaid royalties | 346 |  |  | 364 |  |
| Other | 245 |  |  | 132 |  |
| Total other assets | $ | 5,437 |  |  | $ | 4,500 |  |

[0001045810-24-000316:notes:76]
(1)    Prepaid supply and capacity agreements of $3.2 billion and $2.5 billion were included in Prepaid expenses and other current assets as of October 27, 2024 and January 28, 2024, respectively.

[0001045810-24-000316:notes:77]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 4,740 |  |  | $ | 2,081 |  |
| Excess inventory purchase obligations (1) | 1,728 |  |  | 1,655 |  |
| Taxes payable | 1,356 |  |  | 296 |  |
| Product warranty and return provisions | 1,107 |  |  | 415 |  |
| Deferred revenue (2) | 752 |  |  | 764 |  |
| Accrued payroll and related expenses | 677 |  |  | 675 |  |
| Operating leases | 273 |  |  | 228 |  |
| Unsettled share repurchases | 180 |  |  | 187 |  |
| Licenses and royalties | 148 |  |  | 182 |  |
| Other | 165 |  |  | 199 |  |
| Total accrued and other current liabilities | $ | 11,126 |  |  | $ | 6,682 |  |

[0001045810-24-000316:notes:78]
(1)    We recorded $543 million and $473 million for the third quarter, and $1.3 billion and $734 million for the first nine months, of fiscal years 2025 and 2024, respectively, in cost of revenue.

[0001045810-24-000316:notes:79]
(2)    Includes customer advances and unearned revenue related to hardware support, software support, cloud services, and license and development arrangements. The balance as of October 27, 2024 and January 28, 2024 included $101 million and $233 million of customer advances, respectively.

[0001045810-24-000316:notes:80]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,945 |  |  | $ | 1,361 |  |
| Deferred revenue (2) | 833 |  |  | 573 |  |
| Deferred income tax | 790 |  |  | 462 |  |
| Other | 115 |  |  | 145 |  |
| Total other long-term liabilities | $ | 3,683 |  |  | $ | 2,541 |  |

[0001045810-24-000316:notes:81]
[same as prior period, unchanged from 0001045810-24-000264:notes:78]

[0001045810-24-000316:notes:82]
(2)    Includes unearned revenue related to hardware support, software support and cloud services.

[0001045810-24-000316:notes:83]
[same as prior period, unchanged from 0001045810-24-000264:notes:80]

[0001045810-24-000316:notes:84]
The following table shows the changes in short- and long-term deferred revenue during the first nine months of fiscal years 2025 and 2024:

[0001045810-24-000316:notes:85]
|  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,337 |  |  | $ | 572 |  |
| Deferred revenue additions | 2,115 |  |  | 1,269 |  |
| Revenue recognized | (1,867) |  |  | (903) |  |
| Balance at end of period | $ | 1,585 |  |  | $ | 938 |  |

[0001045810-24-000316:notes:86]
We recognized revenue of $585 million and $256 million in the first nine months of fiscal years 2025 and 2024, respectively, that were included in the prior year end deferred revenue balances.

[0001045810-24-000316:notes:87]
As of October 27, 2024, revenue related to remaining performance obligations from contracts greater than one year in length was $1.6 billion, which includes $1.4 billion from deferred revenue and $187 million which has not yet been billed nor recognized as revenue. Approximately 37% of revenue from contracts greater than one year in length will be recognized over the next twelve months.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-24-000316:notes:88]
Derivative Financial Instruments
We utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. The foreign currency forward contracts for operating expenses are designated as cash flow hedges. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur.

[0001045810-24-000316:notes:89]
We also entered into foreign currency forward contracts mitigating the impact of foreign currency movements on monetary assets and liabilities. For our foreign currency contracts for assets and liabilities, the change in fair value of these non-designated contracts was recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which was also recorded in other income or expense.

[0001045810-24-000316:notes:90]
[same as prior period, unchanged from 0001045810-24-000264:notes:87]

[0001045810-24-000316:notes:91]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,360 |  |  | $ | 1,168 |  |
| Non-designated hedges | $ | 728 |  |  | $ | 597 |  |

[0001045810-24-000316:notes:92]
The unrealized gains and losses or fair value of our foreign currency contracts were not significant as of October 27, 2024 and January 28, 2024.

[0001045810-24-000316:notes:93]
As of October 27, 2024, all designated foreign currency contracts mature within 18 months and any unrealized gains and losses were not significant.

[0001045810-24-000316:notes:94]
During the first nine months of fiscal years 2025 and 2024, the impact of derivative financial instruments designated for cash flow hedges was not significant and the instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-24-000316:notes:95]
Debt
Long-Term Debt

[0001045810-24-000316:notes:96]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 27, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 1.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (38) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,462 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,462 |  |  | $ | 8,459 |  |

[0001045810-24-000316:notes:97]
(1) We repaid the 0.584% Notes Due 2024 in the second quarter of fiscal year 2025.

[0001045810-24-000316:notes:98]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes is calendar year.

[0001045810-24-000316:notes:99]
As of October 27, 2024, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-24-000316:notes:100]
Commercial Paper

[0001045810-24-000316:notes:101]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2024, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-24-000316:notes:102]
Commitments and Contingencies
Purchase Obligations

[0001045810-24-000316:notes:103]
Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-24-000316:notes:104]
As of October 27, 2024, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $28.9 billion, an increase from the prior year primarily due to commitments for Blackwell capacity and components. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $13.2 billion, including $11.3 billion of multi-year cloud service agreements. We expect our cloud service agreements to primarily be used to support our research and development efforts, as well as our DGX Cloud offerings.

[0001045810-24-000316:notes:105]
Total future purchase commitments as of October 27, 2024 are as follows:

[0001045810-24-000316:notes:106]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding the first nine months of fiscal year 2025) | $ | 14,178 |  |
| 2026 | 18,895 |  |
| 2027 | 3,381 |  |
| 2028 | 2,979 |  |
| 2029 | 1,990 |  |
| 2030 and thereafter | 621 |  |
| Total | $ | 42,044 |  |

[0001045810-24-000316:notes:107]
Accrual for Product Warranty Liabilities

[0001045810-24-000316:notes:108]
The estimated amount of product warranty liabilities was $1.0 billion and $306 million as of October 27, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-24-000316:notes:109]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 741 |  |  | $ | 115 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 304 |  |  | 50 |  |  | 775 |  |  | 105 |  |
| Utilization | (36) |  |  | (23) |  |  | (72) |  |  | (45) |  |
| Balance at end of period | $ | 1,009 |  |  | $ | 142 |  |  | $ | 1,009 |  |  | $ | 142 |  |

[0001045810-24-000316:notes:110]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-24-000316:notes:111]
Litigation

[0001045810-24-000316:notes:112]
Securities Class Action and Derivative Lawsuits

[0001045810-24-000316:notes:113]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. Briefing concluded on October 25, 2024 and the Supreme Court heard oral arguments on November 13, 2024.

[0001045810-24-000316:notes:114]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The stay remains in place. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-24-000316:notes:115]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-24-000316:notes:116]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-24-000316:notes:117]
Accounting for Loss Contingencies

[0001045810-24-000316:notes:118]
As of October 27, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-24-000316:notes:119]
[same as prior period, unchanged from 0001045810-24-000264:notes:116]

[0001045810-24-000316:notes:120]
We repurchased 92 million and 83 million shares of our common stock for $11.1 billion and $3.7 billion during the third quarter, and 254 million and 159 million shares of our common stock for $26.2 billion and $7 billion during the first nine months, of fiscal years 2025 and 2024, respectively. On August 26, 2024, our Board of Directors approved an additional $50 billion to our share repurchase authorization, without expiration. As of October 27, 2024, we were authorized, subject to certain specifications, to repurchase up to $46.4 billion of our common stock. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-24-000316:notes:121]
From October 28, 2024 through November 15, 2024, we repurchased 19 million shares for $2.7 billion pursuant to a pre-established trading plan.

[0001045810-24-000316:notes:122]
We paid cash dividends to our shareholders of $245 million and $99 million during the third quarter, and $589 million and $296 million during the first nine months, of fiscal years 2025 and 2024, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-24-000316:notes:123]
[same as prior period, unchanged from 0001045810-24-000264:notes:121]

[0001045810-24-000316:notes:124]
[same as prior period, unchanged from 0001045810-24-000264:notes:122]

[0001045810-24-000316:notes:125]
[same as prior period, unchanged from 0001045810-24-000264:notes:123]

[0001045810-24-000316:notes:126]
[same as prior period, unchanged from 0001045810-24-000264:notes:124]

[0001045810-24-000316:notes:127]
[same as prior period, unchanged from 0001045810-24-000264:notes:125]

[0001045810-24-000316:notes:128]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expenses directly attributable to each reportable segment are included in operating results for each segment. However, our CODM does not review depreciation and amortization expense by operating segment and, therefore, it is not separately presented. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-24-000316:notes:129]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended Oct 27, 2024 |  |  |  |  |  |  |  |
| Revenue | $ | 31,036 |  |  | $ | 4,046 |  |  | $ | — |  |  | $ | 35,082 |  |
| Operating income (loss) | $ | 22,081 |  |  | $ | 1,502 |  |  | $ | (1,714) |  |  | $ | 21,869 |  |
| Three Months Ended Oct 29, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 14,645 |  |  | $ | 3,475 |  |  | $ | — |  |  | $ | 18,120 |  |
| Operating income (loss) | $ | 10,262 |  |  | $ | 1,493 |  |  | $ | (1,338) |  |  | $ | 10,417 |  |
| Nine Months Ended Oct 27, 2024 |  |  |  |  |  |  |  |
| Revenue | $ | 80,157 |  |  | $ | 11,009 |  |  | $ | — |  |  | $ | 91,166 |  |
| Operating income (loss) | $ | 57,977 |  |  | $ | 4,111 |  |  | $ | (4,669) |  |  | $ | 57,419 |  |
| Nine Months Ended Oct 29, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 29,507 |  |  | $ | 9,312 |  |  | $ | — |  |  | $ | 38,819 |  |
| Operating income (loss) | $ | 19,149 |  |  | $ | 3,751 |  |  | $ | (3,542) |  |  | $ | 19,358 |  |

[0001045810-24-000316:notes:130]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (1,252) |  |  | $ | (979) |  |  | $ | (3,416) |  |  | $ | (2,555) |  |
| Unallocated cost of revenue and operating expenses | (307) |  |  | (198) |  |  | (816) |  |  | (515) |  |
| Acquisition-related and other costs | (155) |  |  | (135) |  |  | (441) |  |  | (446) |  |
| Other | — |  |  | (26) |  |  | 4 |  |  | (26) |  |
| Total | $ | (1,714) |  |  | $ | (1,338) |  |  | $ | (4,669) |  |  | $ | (3,542) |  |

[0001045810-24-000316:notes:131]
Revenue by geographic area is based upon the billing location of the customer. The end customer and shipping location may be different from our customer’s billing location. For example, most shipments associated with Singapore revenue were to locations other than Singapore and shipments to Singapore were insignificant. Revenue by geographic area was as follows:

[0001045810-24-000316:notes:132]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 14,800 |  |  | $ | 6,302 |  |  | $ | 41,318 |  |  | $ | 14,730 |  |
| Singapore | 7,697 |  |  | 2,702 |  |  | 17,356 |  |  | 4,506 |  |
| China (including Hong Kong) | 5,416 |  |  | 4,030 |  |  | 11,574 |  |  | 8,360 |  |
| Taiwan | 5,153 |  |  | 4,333 |  |  | 15,266 |  |  | 8,968 |  |
| Other countries | 2,016 |  |  | 753 |  |  | 5,652 |  |  | 2,255 |  |
| Total revenue | $ | 35,082 |  |  | $ | 18,120 |  |  | $ | 91,166 |  |  | $ | 38,819 |  |

[0001045810-24-000316:notes:133]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, ODMs, OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. We also have indirect customers, who purchase products through our direct customers; indirect customers include cloud service providers, consumer internet companies, enterprises, and public sector entities.

[0001045810-24-000316:notes:134]
[same as prior period, unchanged from 0001045810-24-000264:notes:132]

[0001045810-24-000316:notes:135]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 27, 2024 |
| Customer A | 12 | % |  | * |
| Customer B | 12 | % |  | 11 | % |
| Customer C | 12 | % |  | 11 | % |
| Customer D | * |  | 12 | % |

[0001045810-24-000316:notes:136]
[same as prior period, unchanged from 0001045810-24-000264:notes:134]

[0001045810-24-000316:notes:137]
The customer references of A-D above may represent different customers than those reported in a previous period.

[0001045810-24-000316:notes:138]
Sales to one direct customer represented 12% of total revenue for the third quarter of fiscal year 2024, and sales to a second direct customer represented 11% of total revenue for the first nine months of fiscal year 2024, both of which were attributable to the Compute & Networking segment.

[0001045810-24-000316:notes:139]
[same as prior period, unchanged from 0001045810-24-000264:notes:136]

[0001045810-24-000316:notes:140]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 30,771 |  |  | $ | 14,514 |  |  | $ | 79,606 |  |  | $ | 29,121 |  |
| Compute | 27,644 |  |  | 11,908 |  |  | 69,640 |  |  | 23,877 |  |
| Networking | 3,127 |  |  | 2,606 |  |  | 9,966 |  |  | 5,244 |  |
| Gaming | 3,279 |  |  | 2,856 |  |  | 8,806 |  |  | 7,582 |  |
| Professional Visualization | 486 |  |  | 416 |  |  | 1,367 |  |  | 1,090 |  |
| Automotive | 449 |  |  | 261 |  |  | 1,124 |  |  | 810 |  |
| OEM and Other | 97 |  |  | 73 |  |  | 263 |  |  | 216 |  |
| Total revenue | $ | 35,082 |  |  | $ | 18,120 |  |  | $ | 91,166 |  |  | $ | 38,819 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-24-000316:notes:141]
On September 27, 2024, Aarti Shah, a member of our Board of Directors, adopted a Rule 10b5-1 Trading Arrangement for the sale of up to 29,000 shares of our common stock through March 31, 2026.

[0001045810-24-000316:notes:142]
On September 30, 2024, Ajay K. Puri, Executive Vice President, Worldwide Field Operations, adopted a Rule 10b5-1 Trading Arrangement for the sale of up to 204,890 shares of our common stock through December 30, 2025.
