# NVDA 8-K — 0001045810-24-000315 filed 2024-11-20

## item codes, every 8-K on or before 2024-11-20

- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2024-11-20

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-24-000315:8k_2_02:1]
EX-99.1
2
q3fy25pr.htm
EX-99.1

[0001045810-24-000315:8k_2_02:2]
Document

[0001045810-24-000315:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-24-000315:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2025

[0001045810-24-000315:8k_2_02:5]
•Record quarterly revenue of $35.1 billion, up 17% from Q2 and up 94% from a year ago

[0001045810-24-000315:8k_2_02:6]
•Record quarterly Data Center revenue of $30.8 billion, up 17% from Q2 and up 112% from a year ago

[0001045810-24-000315:8k_2_02:7]
SANTA CLARA, Calif.—Nov. 20, 2024―NVIDIA (NASDAQ: NVDA) today reported revenue for the third quarter ended October 27, 2024, of $35.1 billion, up 17% from the previous quarter and up 94% from a year ago.

[0001045810-24-000315:8k_2_02:8]
For the quarter, GAAP earnings per diluted share was $0.78, up 16% from the previous quarter and up 111% from a year ago. Non-GAAP earnings per diluted share was $0.81, up 19% from the previous quarter and up 103% from a year ago.

[0001045810-24-000315:8k_2_02:9]
“The age of AI is in full steam, propelling a global shift to NVIDIA computing,” said Jensen Huang, founder and CEO of NVIDIA. “Demand for Hopper and anticipation for Blackwell — in full production — are incredible as foundation model makers scale pretraining, post-training and inference.

[0001045810-24-000315:8k_2_02:10]
“AI is transforming every industry, company and country. Enterprises are adopting agentic AI to revolutionize workflows. Industrial robotics investments are surging with breakthroughs in physical AI. And countries have awakened to the importance of developing their national AI and infrastructure,” he said.

[0001045810-24-000315:8k_2_02:11]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on December 27, 2024, to all shareholders of record on December 5, 2024.

[0001045810-24-000315:8k_2_02:12]
Q3 Fiscal 2025 Summary

[0001045810-24-000315:8k_2_02:13]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY25 | Q2 FY25 | Q3 FY24 | Q/Q | Y/Y |
| Revenue | $35,082 | $30,040 | $18,120 | Up 17% | Up 94% |
| Gross margin | 74.6 | % | 75.1 | % | 74.0 | % | Down 0.5 pts | Up 0.6 pts |
| Operating expenses | $4,287 | $3,932 | $2,983 | Up 9% | Up 44% |
| Operating income | $21,869 | $18,642 | $10,417 | Up 17% | Up 110% |
| Net income | $19,309 | $16,599 | $9,243 | Up 16% | Up 109% |
| Diluted earnings per share* | $0.78 | $0.67 | $0.37 | Up 16% | Up 111% |

[0001045810-24-000315:8k_2_02:14]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY25 | Q2 FY25 | Q3 FY24 | Q/Q | Y/Y |
| Revenue | $35,082 | $30,040 | $18,120 | Up 17% | Up 94% |
| Gross margin | 75.0 | % | 75.7 | % | 75.0 | % | Down 0.7 pts | -- |
| Operating expenses | $3,046 | $2,792 | $2,026 | Up 9% | Up 50% |
| Operating income | $23,276 | $19,937 | $11,557 | Up 17% | Up 101% |
| Net income | $20,010 | $16,952 | $10,020 | Up 18% | Up 100% |
| Diluted earnings per share* | $0.81 | $0.68 | $0.40 | Up 19% | Up 103% |

[0001045810-24-000315:8k_2_02:15]
*All per share amounts presented herein have been retroactively adjusted to reflect the ten-for-one stock split, which was effective June 7, 2024.

[0001045810-24-000315:8k_2_02:16]
Outlook

[0001045810-24-000315:8k_2_02:17]
NVIDIA’s outlook for the fourth quarter of fiscal 2025 is as follows:

[0001045810-24-000315:8k_2_02:18]
•Revenue is expected to be $37.5 billion, plus or minus 2%.

[0001045810-24-000315:8k_2_02:19]
•GAAP and non-GAAP gross margins are expected to be 73.0% and 73.5%, respectively, plus or minus 50 basis points.

[0001045810-24-000315:8k_2_02:20]
•GAAP and non-GAAP operating expenses are expected to be approximately $4.8 billion and $3.4 billion, respectively.

[0001045810-24-000315:8k_2_02:21]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $400 million, excluding gains and losses from non-affiliated investments and publicly-held equity securities.

[0001045810-24-000315:8k_2_02:22]
•GAAP and non-GAAP tax rates are expected to be 16.5%, plus or minus 1%, excluding any discrete items.

[0001045810-24-000315:8k_2_02:23]
Highlights

[0001045810-24-000315:8k_2_02:24]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-24-000315:8k_2_02:25]
Data Center

[0001045810-24-000315:8k_2_02:26]
•Third-quarter revenue was a record $30.8 billion, up 17% from the previous quarter and up 112% from a year ago.

[0001045810-24-000315:8k_2_02:27]
•Announced the availability of NVIDIA Hopper H200-powered instances in several cloud services, including AWS, CoreWeave and Microsoft Azure, with Google Cloud and Oracle Cloud Infrastructure coming soon.

[0001045810-24-000315:8k_2_02:28]
•Launched Denmark’s largest sovereign AI supercomputer, an NVIDIA® DGX SuperPOD™ driven by 1,528 NVIDIA H100 Tensor Core GPUs and interconnected using NVIDIA Quantum-2 InfiniBand networking.

[0001045810-24-000315:8k_2_02:29]
•Introduced the NVIDIA AI Aerial platform for telecommunications providers and began working with T-Mobile, Ericsson and Nokia to accelerate the commercialization of AI-RAN.

[0001045810-24-000315:8k_2_02:30]
•Announced that SoftBank Corp. is building Japan’s most powerful AI supercomputer with the NVIDIA Blackwell platform and has successfully piloted the world’s first combined AI and 5G telecom network using NVIDIA AI Aerial.

[0001045810-24-000315:8k_2_02:31]
•Revealed that cloud leaders in India, Japan and Indonesia are building AI infrastructure with NVIDIA accelerated computing, while consulting leaders are helping speed AI adoption across industries with NVIDIA AI Enterprise software.

[0001045810-24-000315:8k_2_02:32]
•Accelerated xAI’s Colossus supercomputer cluster, using 100,000 NVIDIA Hopper GPUs, with the NVIDIA Spectrum-X™ Ethernet networking platform.

[0001045810-24-000315:8k_2_02:33]
•Unveiled a partnership with Foxconn to build Taiwan’s fastest AI supercomputer with NVIDIA Blackwell.

[0001045810-24-000315:8k_2_02:34]
•Announced that Blackwell debuted on MLPerf Training, completed all tests and delivered up to 2.2x performance gains on large language model benchmarks.

[0001045810-24-000315:8k_2_02:35]
•Contributed foundational elements of the NVIDIA Blackwell design to the Open Compute Project and broadened NVIDIA Spectrum-X support for OCP standards.

[0001045810-24-000315:8k_2_02:36]
•Revealed that U.S. technology companies including Accenture, Deloitte and Google Cloud are tapping NVIDIA AI software to create custom AI applications, transforming industries worldwide.

[0001045810-24-000315:8k_2_02:37]
•Announced the expansion of a partnership with Lenovo to launch new hybrid AI solutions and systems optimized to run NVIDIA AI Enterprise software.

[0001045810-24-000315:8k_2_02:38]
Gaming and AI PC

[0001045810-24-000315:8k_2_02:39]
•Third-quarter Gaming revenue was $3.3 billion, up 14% from the previous quarter and up 15% from a year ago.

[0001045810-24-000315:8k_2_02:40]
•Celebrated the 25th anniversary of GeForce® 256, the world’s first GPU, which marked a breakthrough for gaming and laid the foundation for an AI-driven future.

[0001045810-24-000315:8k_2_02:41]
•Demonstrated NVIDIA ACE and digital human technologies in Mecha BREAK, featuring the Minitron 4B model for better in-game character responses, at Gamescom.

[0001045810-24-000315:8k_2_02:42]
•Introduced 20 GeForce RTX and DLSS titles, including Indiana Jones and the Great Circle and Dragon Age: The Veilguard.

[0001045810-24-000315:8k_2_02:43]
•Began shipping new RTX AI PCs with 321 AI trillion operations per second of performance from ASUS and MSI, with Microsoft Copilot+ capabilities anticipated next quarter.

[0001045810-24-000315:8k_2_02:44]
Professional Visualization

[0001045810-24-000315:8k_2_02:45]
•Third-quarter revenue was $486 million, up 7% from the previous quarter and up 17% from a year ago.

[0001045810-24-000315:8k_2_02:46]
•Announced that Foxconn is using digital twins and industrial AI built on NVIDIA Omniverse™ to bring online faster three factories used to manufacture NVIDIA GB200 Grace Blackwell Superchips.

[0001045810-24-000315:8k_2_02:47]
•Revealed that leading industrial manufacturers in India, including Reliance and Ola Motors, and Japan, including Toyota, Yaskawa, and Seven and I Holdings, are using NVIDIA AI and Omniverse to automate workflows and drive more efficient operations.

[0001045810-24-000315:8k_2_02:48]
•Unveiled NVIDIA Holoscan for Media, an AI-enabled, software-defined platform that allows live media and video pipelines to run on the same infrastructure as AI, enhancing production delivery.

[0001045810-24-000315:8k_2_02:49]
Automotive and Robotics

[0001045810-24-000315:8k_2_02:50]
•Third-quarter Automotive revenue was $449 million, up 30% from the previous quarter and up 72% from a year ago.

[0001045810-24-000315:8k_2_02:51]
•Revealed that Volvo is releasing a new electric SUV built on NVIDIA accelerated computing.

[0001045810-24-000315:8k_2_02:52]
•Introduced Project GR00T AI and simulation tools for robot learning and humanoid development, and new generative AI tools and perception workflows for robotics developers.

[0001045810-24-000315:8k_2_02:53]
•Announced that Japanese and Indian companies including Toyota and Ola Motors are using NVIDIA Isaac™ and Omniverse to build the next wave of physical AI.

[0001045810-24-000315:8k_2_02:54]
CFO Commentary

[0001045810-24-000315:8k_2_02:55]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-24-000315:8k_2_02:56]
Conference Call and Webcast Information

[0001045810-24-000315:8k_2_02:57]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2025 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal 2025.

[0001045810-24-000315:8k_2_02:58]
Non-GAAP Measures

[0001045810-24-000315:8k_2_02:59]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains and losses from non-affiliated investments and publicly-held equity securities, net, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-24-000315:8k_2_02:60]
About NVIDIA

[0001045810-24-000315:8k_2_02:61]
NVIDIA (NASDAQ: NVDA) is the world leader in accelerated computing.

[0001045810-24-000315:8k_2_02:62]
###

[0001045810-24-000315:8k_2_02:63]
For further information, contact:

[0001045810-24-000315:8k_2_02:64]
| Stewart Stecker |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sstecker@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-24-000315:8k_2_02:65]
Certain statements in this press release including, but not limited to, statements as to: the age of AI in full steam, propelling a global shift to NVIDIA computing; demand for Hopper and anticipation for Blackwell — in full production — being incredible as foundation model makers scale pretraining, post-training and inference; AI transforming every industry, company and country; enterprises adopting agentic AI to revolutionize workflows; industrial robotics investments surging with breakthroughs in physical AI; countries awakening to the importance of developing their national AI and infrastructure; NVIDIA’s next quarterly cash dividend; and NVIDIA’s financial outlook and expected tax rates for the fourth quarter of fiscal 2025 are risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; and unexpected loss of performance of our products or technologies when integrated into systems, as well as other factors detailed from time to time in the most

[0001045810-24-000315:8k_2_02:66]
recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-24-000315:8k_2_02:67]
© 2024 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, NVIDIA DGX SuperPOD, NVIDIA Isaac, NVIDIA Omniverse and NVIDIA Spectrum-X are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-24-000315:8k_2_02:68]
NVIDIA CORPORATION

[0001045810-24-000315:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-24-000315:8k_2_02:70]
(In millions, except per share data)

[0001045810-24-000315:8k_2_02:71]
(Unaudited)

[0001045810-24-000315:8k_2_02:72]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | October 29, |  | October 27, |  | October 29, |
|  |  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue | $ | 35,082 |  |  | $ | 18,120 |  |  | $ | 91,166 |  |  | $ | 38,819 |  |
| Cost of revenue | 8,926 |  |  | 4,720 |  |  | 22,031 |  |  | 11,309 |  |
| Gross profit | 26,156 |  |  | 13,400 |  |  | 69,135 |  |  | 27,510 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 3,390 |  |  | 2,294 |  |  | 9,200 |  |  | 6,210 |  |
|  | Sales, general and administrative | 897 |  |  | 689 |  |  | 2,516 |  |  | 1,942 |  |
|  |  | Total operating expenses | 4,287 |  |  | 2,983 |  |  | 11,716 |  |  | 8,152 |  |
| Operating income | 21,869 |  |  | 10,417 |  |  | 57,419 |  |  | 19,358 |  |
|  | Interest income | 472 |  |  | 234 |  |  | 1,275 |  |  | 572 |  |
|  | Interest expense | (61) |  |  | (63) |  |  | (186) |  |  | (194) |  |
|  | Other, net | 36 |  |  | (66) |  |  | 301 |  |  | (24) |  |
|  |  | Other income (expense), net | 447 |  |  | 105 |  |  | 1,390 |  |  | 354 |  |
| Income before income tax | 22,316 |  |  | 10,522 |  |  | 58,809 |  |  | 19,712 |  |
| Income tax expense | 3,007 |  |  | 1,279 |  |  | 8,020 |  |  | 2,237 |  |
| Net income | $ | 19,309 |  |  | $ | 9,243 |  |  | $ | 50,789 |  |  | $ | 17,475 |  |
| Net income per share (A): |  |  |  |  |  |  |  |
|  | Basic | $ | 0.79 |  |  | $ | 0.37 |  |  | $ | 2.07 |  |  | $ | 0.71 |  |
|  | Diluted | $ | 0.78 |  |  | $ | 0.37 |  |  | $ | 2.04 |  |  | $ | 0.70 |  |
| Weighted average shares used in per share computation (A): |
|  | Basic | 24,533 |  |  | 24,680 |  |  | 24,577 |  |  | 24,700 |  |
|  | Diluted | 24,774 |  |  | 24,940 |  |  | 24,837 |  |  | 24,940 |  |

[0001045810-24-000315:8k_2_02:73]
(A) Reflects a ten-for-one stock split on June 7, 2024.

[0001045810-24-000315:8k_2_02:74]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | October 27, |  | January 28, |
|  |  |  |  | 2024 |  | 2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 38,487 |  |  | $ | 25,984 |  |
|  | Accounts receivable, net |  | 17,693 |  |  | 9,999 |  |
|  | Inventories |  | 7,654 |  |  | 5,282 |  |
|  | Prepaid expenses and other current assets |  | 3,806 |  |  | 3,080 |  |
|  |  | Total current assets |  | 67,640 |  |  | 44,345 |  |
| Property and equipment, net |  | 5,343 |  |  | 3,914 |  |
| Operating lease assets |  | 1,755 |  |  | 1,346 |  |
| Goodwill |  | 4,724 |  |  | 4,430 |  |
| Intangible assets, net |  | 838 |  |  | 1,112 |  |
| Deferred income tax assets |  | 10,276 |  |  | 6,081 |  |
| Other assets |  | 5,437 |  |  | 4,500 |  |
|  |  | Total assets |  | $ | 96,013 |  |  | $ | 65,728 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 5,353 |  |  | $ | 2,699 |  |
|  | Accrued and other current liabilities |  | 11,126 |  |  | 6,682 |  |
|  | Short-term debt |  | — |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 16,479 |  |  | 10,631 |  |
| Long-term debt |  | 8,462 |  |  | 8,459 |  |
| Long-term operating lease liabilities |  | 1,490 |  |  | 1,119 |  |
| Other long-term liabilities |  | 3,683 |  |  | 2,541 |  |
|  |  | Total liabilities |  | 30,114 |  |  | 22,750 |  |
| Shareholders' equity |  | 65,899 |  |  | 42,978 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 96,013 |  |  | $ | 65,728 |  |

[0001045810-24-000315:8k_2_02:75]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, |  | October 29, |  | October 27, |  | October 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 19,309 |  |  | $ | 9,243 |  |  | $ | 50,789 |  |  | $ | 17,475 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,252 |  |  | 979 |  |  | 3,416 |  |  | 2,555 |  |
| Depreciation and amortization | 478 |  |  | 372 |  |  | 1,321 |  |  | 1,121 |  |
| (Gains) losses on investments in non-affiliated entities and publicly-held equity securities, net | (37) |  |  | 69 |  |  | (302) |  |  | 24 |  |
| Deferred income taxes | (602) |  |  | (529) |  |  | (3,879) |  |  | (2,411) |  |
| Other | (79) |  |  | (66) |  |  | (365) |  |  | (170) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (3,561) |  |  | (1,243) |  |  | (7,694) |  |  | (4,482) |  |
| Inventories | (978) |  |  | (457) |  |  | (2,357) |  |  | 405 |  |
| Prepaid expenses and other assets | (714) |  |  | 254 |  |  | (726) |  |  | (337) |  |
| Accounts payable | 1,689 |  |  | 461 |  |  | 2,490 |  |  | 1,250 |  |
| Accrued and other current liabilities | 606 |  |  | (1,722) |  |  | 3,918 |  |  | 953 |  |
| Other long-term liabilities | 266 |  |  | (28) |  |  | 849 |  |  | 208 |  |
| Net cash provided by operating activities | 17,629 |  |  | 7,333 |  |  | 47,460 |  |  | 16,591 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 1,386 |  |  | 2,891 |  |  | 9,485 |  |  | 8,001 |  |
| Proceeds from sales of marketable securities | 154 |  |  | — |  |  | 318 |  |  | — |  |
| Purchases of marketable securities | (4,518) |  |  | (5,345) |  |  | (19,565) |  |  | (10,688) |  |
| Purchase related to property and equipment and intangible assets | (813) |  |  | (278) |  |  | (2,159) |  |  | (815) |  |
| Acquisitions, net of cash acquired | (147) |  |  | — |  |  | (465) |  |  | (83) |  |
| Purchases of investments in non-affiliated entities | (473) |  |  | (441) |  |  | (1,008) |  |  | (897) |  |
| Proceeds from sales of investments in non-affiliated entities | 66 |  |  | — |  |  | 171 |  |  | — |  |
| Other | — |  |  | 4 |  |  | — |  |  | 25 |  |
| Net cash used in investing activities | (4,345) |  |  | (3,169) |  |  | (13,223) |  |  | (4,457) |  |

[0001045810-24-000315:8k_2_02:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 27, |  | October 29, |  | October 27, |  | October 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 204 |  |  | 156 |  |  | 489 |  |  | 403 |  |
| Payments related to repurchases of common stock | (10,998) |  |  | (3,806) |  |  | (25,895) |  |  | (6,874) |  |
| Repayment of debt | — |  |  | — |  |  | (1,250) |  |  | (1,250) |  |
| Payments related to tax on restricted stock units | (1,680) |  |  | (764) |  |  | (5,068) |  |  | (1,942) |  |
| Dividends paid | (245) |  |  | (99) |  |  | (589) |  |  | (296) |  |
| Principal payments on property and equipment and intangible assets | (29) |  |  | (13) |  |  | (97) |  |  | (44) |  |
| Other | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Net cash used in financing activities | (12,748) |  |  | (4,527) |  |  | (32,410) |  |  | (10,004) |  |
| Change in cash, cash equivalents, and restricted cash | 536 |  |  | (363) |  |  | 1,827 |  |  | 2,130 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 8,571 |  |  | 5,882 |  |  | 7,280 |  |  | 3,389 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 9,107 |  |  | $ | 5,519 |  |  | $ | 9,107 |  |  | $ | 5,519 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 3,540 |  |  | $ | 4,348 |  |  | $ | 10,989 |  |  | $ | 4,676 |  |

[0001045810-24-000315:8k_2_02:77]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 29, |  | October 27, |  | October 29, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| GAAP gross profit |  | $ | 26,156 |  |  | $ | 22,574 |  |  | $ | 13,400 |  |  | $ | 69,135 |  |  | $ | 27,510 |  |
| GAAP gross margin |  | 74.6 | % |  | 75.1 | % |  | 74.0 | % |  | 75.8 | % |  | 70.9 | % |
|  | Acquisition-related and other costs (A) |  | 116 |  |  | 118 |  |  | 119 |  |  | 355 |  |  | 358 |  |
|  | Stock-based compensation expense (B) |  | 50 |  |  | 40 |  |  | 38 |  |  | 125 |  |  | 96 |  |
|  | Other (C) |  | — |  |  | (3) |  |  | 26 |  |  | (4) |  |  | 36 |  |
| Non-GAAP gross profit |  | $ | 26,322 |  |  | $ | 22,729 |  |  | $ | 13,583 |  |  | $ | 69,611 |  |  | $ | 28,000 |  |
| Non-GAAP gross margin |  | 75.0 | % |  | 75.7 | % |  | 75.0 | % |  | 76.4 | % |  | 72.1 | % |
| GAAP operating expenses |  | $ | 4,287 |  |  | $ | 3,932 |  |  | $ | 2,983 |  |  | $ | 11,716 |  |  | $ | 8,152 |  |
|  | Stock-based compensation expense (B) |  | (1,202) |  |  | (1,114) |  |  | (941) |  |  | (3,291) |  |  | (2,459) |  |
|  | Acquisition-related and other costs (A) |  | (39) |  |  | (26) |  |  | (16) |  |  | (86) |  |  | (88) |  |
|  | Other (C) |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Non-GAAP operating expenses |  | $ | 3,046 |  |  | $ | 2,792 |  |  | $ | 2,026 |  |  | $ | 8,339 |  |  | $ | 5,615 |  |
| GAAP operating income |  | $ | 21,869 |  |  | $ | 18,642 |  |  | $ | 10,417 |  |  | $ | 57,419 |  |  | $ | 19,358 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,407 |  |  | 1,295 |  |  | 1,140 |  |  | 3,853 |  |  | 3,027 |  |
| Non-GAAP operating income |  | $ | 23,276 |  |  | $ | 19,937 |  |  | $ | 11,557 |  |  | $ | 61,272 |  |  | $ | 22,385 |  |
| GAAP other income (expense), net |  | $ | 447 |  |  | $ | 572 |  |  | $ | 105 |  |  | $ | 1,390 |  |  | $ | 354 |  |
|  | (Gains) losses from non-affiliated investments and publicly-held equity securities, net |  | (37) |  |  | (193) |  |  | 69 |  |  | (302) |  |  | 23 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Non-GAAP other income (expense), net |  | $ | 411 |  |  | $ | 380 |  |  | $ | 175 |  |  | $ | 1,091 |  |  | $ | 380 |  |
| GAAP net income |  | $ | 19,309 |  |  | $ | 16,599 |  |  | $ | 9,243 |  |  | $ | 50,789 |  |  | $ | 17,475 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 1,371 |  |  | 1,103 |  |  | 1,210 |  |  | 3,554 |  |  | 3,053 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (670) |  |  | (750) |  |  | (433) |  |  | (2,144) |  |  | (1,055) |  |
| Non-GAAP net income |  | $ | 20,010 |  |  | $ | 16,952 |  |  | $ | 10,020 |  |  | $ | 52,199 |  |  | $ | 19,473 |  |

[0001045810-24-000315:8k_2_02:78]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 29, |  | October 27, |  | October 29, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Diluted net income per share (E) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.78 |  |  | $ | 0.67 |  |  | $ | 0.37 |  |  | $ | 2.04 |  |  | $ | 0.70 |  |
|  | Non-GAAP |  | $ | 0.81 |  |  | $ | 0.68 |  |  | $ | 0.40 |  |  | $ | 2.10 |  |  | $ | 0.78 |  |
| Weighted average shares used in diluted net income per share computation (E) |  | 24,774 |  |  | 24,848 |  |  | 24,940 |  |  | 24,837 |  |  | 24,940 |  |
| GAAP net cash provided by operating activities |  | $ | 17,629 |  |  | $ | 14,489 |  |  | $ | 7,333 |  |  | $ | 47,460 |  |  | $ | 16,591 |  |
|  | Purchases related to property and equipment and intangible assets |  | (813) |  |  | (977) |  |  | (278) |  |  | (2,159) |  |  | (815) |  |
|  | Principal payments on property and equipment and intangible assets |  | (29) |  |  | (29) |  |  | (13) |  |  | (97) |  |  | (44) |  |
| Free cash flow |  | $ | 16,787 |  |  | $ | 13,483 |  |  | $ | 7,042 |  |  | $ | 45,204 |  |  | $ | 15,732 |  |

[0001045810-24-000315:8k_2_02:79]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 29, |  | October 27, |  | October 29, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Cost of revenue |  | $ | 116 |  |  | $ | 118 |  |  | $ | 119 |  |  | $ | 355 |  |  | $ | 358 |  |
|  | Research and development |  | $ | 23 |  |  | $ | 17 |  |  | $ | 12 |  |  | $ | 52 |  |  | $ | 37 |  |
|  | Sales, general and administrative |  | $ | 16 |  |  | $ | 9 |  |  | $ | 4 |  |  | $ | 34 |  |  | $ | 51 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 27, |  | July 28, |  | October 29, |  | October 27, |  | October 29, |
|  |  |  | 2024 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | Cost of revenue |  | $ | 50 |  |  | $ | 40 |  |  | $ | 38 |  |  | $ | 125 |  |  | $ | 96 |  |
|  | Research and development |  | $ | 910 |  |  | $ | 832 |  |  | $ | 701 |  |  | $ | 2,469 |  |  | $ | 1,826 |  |
|  | Sales, general and administrative |  | $ | 292 |  |  | $ | 282 |  |  | $ | 240 |  |  | $ | 822 |  |  | $ | 633 |  |
| (C) Other consists of IP-related costs and assets held for sale related adjustments |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (E) Reflects a ten-for-one stock split on June 7, 2024 |

[0001045810-24-000315:8k_2_02:80]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2025 |
|  |  |  | Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 73.0 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.5 | % |
| Non-GAAP gross margin |  | 73.5 | % |
| GAAP operating expenses |  | $ | 4,750 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,350) |  |
| Non-GAAP operating expenses |  | $ | 3,400 |  |
