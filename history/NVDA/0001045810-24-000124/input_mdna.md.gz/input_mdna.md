# NVDA MD&A — 0001045810-24-000124


## mdna

[0001045810-24-000124:mdna:1]
Item 2. Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001045810-24-000124:mdna:2]
[same as prior period, unchanged from 0001045810-23-000227:mdna:2]

[0001045810-24-000124:mdna:3]
[same as prior period, unchanged from 0001045810-23-000227:mdna:3]

[0001045810-24-000124:mdna:4]
© 2024 NVIDIA Corporation. All rights reserved.

[0001045810-24-000124:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 28, 2024 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase, hold, or sell shares of our common stock.

[0001045810-24-000124:mdna:6]
[same as prior period, unchanged from 0001045810-23-000227:mdna:6]

[0001045810-24-000124:mdna:7]
[same as prior period, unchanged from 0001045810-23-000227:mdna:7]

[0001045810-24-000124:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, metaverse and 3D internet applications. Our two operating segments are "Compute & Networking" and "Graphics," as described in Note 14 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001045810-24-000124:mdna:9]
[same as prior period, unchanged from 0001045810-23-000227:mdna:10]

[0001045810-24-000124:mdna:10]
[same as prior period, unchanged from 0001045810-23-000227:mdna:11]

[0001045810-24-000124:mdna:11]
[same as prior period, unchanged from 0001045810-23-000227:mdna:12]

[0001045810-24-000124:mdna:12]
Our overall revenue, driven by data center compute, continued to grow through the first quarter of fiscal year 2025. We continue to gather customer demand indications across several product transitions. We have demand visibility for our data center products, including the recently announced Blackwell GPU architecture. We have previously increased our supply and capacity purchases with existing suppliers with planned receipts later this year. We continue to add new vendors and have entered and may continue to enter into prepaid manufacturing and capacity agreements to supply both current and future products. The increased purchase volumes and number of suppliers and integration of new vendors into our supply chain may create more complexity and execution risk. Our purchase commitments and obligations for inventory and manufacturing capacity at the end of the first quarter of fiscal year 2025 continued to be impacted by shortening lead times for certain components. We may incur inventory provisions or impairments if our inventory or supply or capacity commitments exceed demand for our products or demand declines. While supply for H100 continued to improve, we are still constrained on H200. Our next generation data center architecture, Blackwell, is in production, and we plan on shipping customer samples in the second quarter. We expect to ramp customer shipments of Blackwell in the second half of the fiscal year. We believe the initial demand for Blackwell is well ahead of the projected supply for this fiscal year. We expect supply constraints for our Blackwell offerings will continue into next year.

[0001045810-24-000124:mdna:13]
Product transitions are complex as we often ship both new and prior architecture products simultaneously and we and our channel partners prepare to ship and support new products. Due to our product introduction cycles, we are almost always in various stages of transitioning the architectures of our Data Center, Gaming, and Professional Visualization products. We have begun a broader and faster Data Center product launch cadence to meet a growing and diverse set of

[0001045810-24-000124:mdna:14]
23

[0001045810-24-000124:mdna:15]
AI opportunities. The increased frequency of these transitions may magnify the challenges associated with managing our supply and demand due to manufacturing lead times. Qualification time for new products, customers anticipating product transitions and channel partners reducing channel inventory of prior architectures ahead of new product introductions can reduce or create volatility in our revenue. The increasing frequency and complexity of newly introduced products could result in quality or production issues that could increase inventory provisions, warranty, or other costs or result in product delays. Deployment of new products to customers creates additional challenges due to the complexity of our technologies, which has impacted and may in the future impact the timing of customer purchases or otherwise impact our demand. While we have managed prior product transitions and have sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and may cause us to incur additional costs.

[0001045810-24-000124:mdna:16]
We build technology and introduce products for new and innovative use cases and applications such as our NVIDIA DGX Cloud services, our Omniverse platform, LLMs, and generative AI models. Our demand estimates for new use cases, applications, and services can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate significant revenue from these use cases, applications, and services. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for Data Center, the long-term trajectory is unknown.

[0001045810-24-000124:mdna:17]
[same as prior period, unchanged from 0001045810-23-000227:mdna:17]

[0001045810-24-000124:mdna:18]
In August 2022, the U.S. government, or the USG, announced licensing requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits.

[0001045810-24-000124:mdna:19]
In July 2023, the USG informed us of an additional licensing requirement for a subset of A100 and H100 products destined to certain customers and other regions, including some countries in the Middle East.

[0001045810-24-000124:mdna:20]
In October 2023, the USG announced new and updated licensing requirements that became effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products. We have not received licenses to ship these restricted products to China.

[0001045810-24-000124:mdna:21]
We expanded our Data Center product portfolio to offer new solutions, including those for which the USG does not require a license or advance notice before each shipment. We ramped new products designed specifically for China that do not require an export control license. Our Data Center revenue in China is down significantly from the level prior to the imposition of new export control restrictions in October 2023. To the extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer but have no assurance that the USG will grant such a license, or that the USG will act on the license application in a timely manner or at all.

[0001045810-24-000124:mdna:22]
Our competitive position has been harmed, and our competitive position and future results may be further harmed in the long term, if there are further changes in the USG’s export controls. Given the increasing strategic importance of AI and rising geopolitical tensions, the USG has changed and may again change the export control rules at any time and further subject a wider range of our products to export restrictions and licensing requirements, negatively impacting our business and financial results. In the event of such change, we may be unable to sell our inventory of such products and may be unable to develop replacement products not subject to the licensing requirements, effectively excluding us from all or part of the China market, as well as other impacted markets, including the Middle East.

[0001045810-24-000124:mdna:23]
While we work to enhance the resiliency and redundancy of our supply chain, which is currently concentrated in the Asia-Pacific region, new and existing export controls or changes to existing export controls could limit alternative manufacturing locations and negatively impact our business. Refer to “Item 1A. Risk Factors” for a discussion of this potential impact.

[0001045810-24-000124:mdna:24]
[same as prior period, unchanged from 0001045810-23-000227:mdna:25]

[0001045810-24-000124:mdna:25]
Macroeconomic factors, including inflation, increased interest rates, capital market volatility, global supply chain constraints and global economic and geopolitical developments, may have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors can also impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Our product and solution pricing generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-24-000124:mdna:26]
24

[0001045810-24-000124:mdna:27]
Israel and Hamas Conflict

[0001045810-24-000124:mdna:28]
We are monitoring the impact of the geopolitical conflict in and around Israel on our operations, including the health and safety of our approximately 4,000 employees in the region who primarily support the research and development, operations, and sales and marketing of our networking products. Our global supply chain for our networking products has not experienced any significant impact. A substantial number of our employees in the region have been called-up for active military duty in Israel. Some of our employees in Israel have been on active military duty for an extended period and they or others may continue to be absent, which may cause disruption to our product development or operations. We have not experienced significant impact or expense to our business; however, if the conflict is further extended, it could impact future product development, operations, and revenue or create other uncertainty for our business.

[0001045810-24-000124:mdna:29]
First Quarter of Fiscal Year 2025 Summary

[0001045810-24-000124:mdna:30]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Apr 28, 2024 |  | Jan 28, 2024 |  | Apr 30, 2023 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 26,044 |  |  | $ | 22,103 |  |  | $ | 7,192 |  |  | 18 | % |  | 262 | % |
| Gross margin | 78.4 | % |  | 76.0 | % |  | 64.6 | % |  | 2.4 pts |  | 13.8 pts |
| Operating expenses | $ | 3,497 |  |  | $ | 3,176 |  |  | $ | 2,508 |  |  | 10 | % |  | 39 | % |
| Operating income | $ | 16,909 |  |  | $ | 13,615 |  |  | $ | 2,140 |  |  | 24 | % |  | 690 | % |
| Net income | $ | 14,881 |  |  | $ | 12,285 |  |  | $ | 2,043 |  |  | 21 | % |  | 628 | % |
| Net income per diluted share | $ | 5.98 |  |  | $ | 4.93 |  |  | $ | 0.82 |  |  | 21 | % |  | 629 | % |

[0001045810-24-000124:mdna:31]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

[0001045810-24-000124:mdna:32]
Revenue was $26.0 billion, up 262% from a year ago and up 18% sequentially.

[0001045810-24-000124:mdna:33]
Data Center revenue was up 427% from a year ago and up 23% sequentially. Data Center compute revenue was $19.4 billion, up 478% from a year ago and up 29% sequentially. These increases reflect higher shipments of the NVIDIA Hopper GPU computing platform used for training and inferencing with large language models, recommendation engines, and generative AI applications. Networking revenue was $3.2 billion, up 242% from a year ago on strong growth of InfiniBand end-to-end solutions, and down 5% sequentially due to the timing of supply. Strong sequential Data Center growth was driven by all customer types, led by Enterprise and Consumer Internet companies. Large cloud providers continued to drive strong growth as they deploy and ramp NVIDIA AI infrastructure at scale, representing mid-40% of our Data Center revenue.

[0001045810-24-000124:mdna:34]
Gaming revenue was up 18% from a year ago and down 8% sequentially. The year-on-year increase primarily reflects higher demand. The sequential decrease reflects seasonally lower GPU sales for laptops.

[0001045810-24-000124:mdna:35]
Professional Visualization revenue was up 45% from a year ago and down 8% sequentially. The year-on-year increase primarily reflects higher sell-in to partners following the normalization of channel inventory levels. The sequential decrease was primarily due to desktop workstation GPUs.

[0001045810-24-000124:mdna:36]
Automotive revenue was up 11% from a year ago and up 17% sequentially. The year-on-year increase was driven primarily by self-driving platforms. The sequential increase was driven by AI Cockpit solutions and self-driving platforms.

[0001045810-24-000124:mdna:37]
Gross margin for the first quarter increased significantly from a year ago on strong Data Center revenue growth primarily driven by our Hopper GPU computing platform. Sequentially, gross margin benefited from lower inventory charges.

[0001045810-24-000124:mdna:38]
Operating expenses were up 39% from a year ago and up 10% sequentially. The increases were primarily driven by compensation and benefits, reflecting growth in employees and compensation.

[0001045810-24-000124:mdna:39]
[same as prior period, unchanged from 0001045810-23-000227:mdna:42]

[0001045810-24-000124:mdna:40]
Data Center revenue for the first quarter of fiscal year 2025 was $22.6 billion, up 427% from a year ago and up 23% from the previous quarter. In our trailing 4 quarters, we estimate that inference drove about 40% of our Data Center revenue. We unveiled the NVIDIA Blackwell platform, our next-generation GPU architecture for the new era of AI computing at trillion-parameter scale and the Blackwell-powered DGX SuperPOD for generative AI supercomputing. Joining Blackwell will be NVIDIA Quantum InfiniBand and Spectrum Ethernet switches designed for massive-scale AI. We also announced NVIDIA AI Enterprise 5.0 with NVIDIA NIM Inference Microservices — to speed enterprise app development. We announced that nine new supercomputers worldwide are using Grace Hopper Superchips to ignite a new era of AI supercomputing.

[0001045810-24-000124:mdna:41]
Gaming revenue for the first quarter of fiscal year 2025 was $2.6 billion, up 18% from a year ago and down 8% from the previous quarter. We introduced generative AI for digital humans, NVIDIA ACE for speech and animation, and new RTX technologies; and added support for new models.

[0001045810-24-000124:mdna:42]
Professional Visualization revenue for the first quarter of fiscal year 2025 was $427 million, up 45% from a year ago and down 8% from the previous quarter. We introduced NVIDIA RTX 500 and 1000 professional Ada generation laptop GPUs; unveiled NVIDIA RTX A400 and A1000 GPUs for desktop workstations, based on the NVIDIA Ampere architecture; and introduced NVIDIA Omniverse Cloud APIs to power industrial digital twin software tools.

[0001045810-24-000124:mdna:43]
Automotive revenue for the first quarter of fiscal year 2025 was $329 million, up 11% from a year ago and up 17% from the previous quarter. We revealed U.S. and China electric vehicle makers Lucid and IM Motors are using the NVIDIA DRIVE Orin platform; and announced BYD, XPENG, GAC's AION Hyper, Nuro and others will adopt its successor, NVIDIA DRIVE Thor.

[0001045810-24-000124:mdna:44]
[same as prior period, unchanged from 0001045810-23-000227:mdna:47]

[0001045810-24-000124:mdna:45]
Refer to Note 14 of the Notes to the Condensed Consolidated Financial Statements for disclosure regarding segment information.

[0001045810-24-000124:mdna:46]
[same as prior period, unchanged from 0001045810-23-000227:mdna:49]

[0001045810-24-000124:mdna:47]
Refer to Part II, Item 7, "Critical Accounting Policies and Estimates" of our Annual Report on Form 10-K for the fiscal year ended January 28, 2024. There have been no material changes to our Critical Accounting Policies and Estimates.

[0001045810-24-000124:mdna:48]
[same as prior period, unchanged from 0001045810-23-000227:mdna:51]

[0001045810-24-000124:mdna:49]
[same as prior period, unchanged from 0001045810-23-000227:mdna:52]

[0001045810-24-000124:mdna:50]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 21.6 |  |  | 35.4 |  |  |  |  |  |
| Gross profit | 78.4 |  |  | 64.6 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 10.4 |  |  | 26.1 |  |  |  |  |  |
| Sales, general and administrative | 3.0 |  |  | 8.8 |  |  |  |  |  |
| Total operating expenses | 13.4 |  |  | 34.9 |  |  |  |  |  |
| Operating income | 65.0 |  |  | 29.7 |  |  |  |  |  |
| Interest income | 1.4 |  |  | 2.1 |  |  |  |  |  |
| Interest expense | (0.2) |  |  | (0.9) |  |  |  |  |  |
| Other, net | 0.3 |  |  | (0.2) |  |  |  |  |  |
| Other income (expense), net | 1.5 |  |  | 1.0 |  |  |  |  |  |
| Income before income tax | 66.5 |  |  | 30.7 |  |  |  |  |  |
| Income tax expense | 9.2 |  |  | 2.3 |  |  |  |  |  |
| Net income | 57.3 | % |  | 28.4 | % |  |  |  |  |

[0001045810-24-000124:mdna:51]
[same as prior period, unchanged from 0001045810-23-000227:mdna:54]

[0001045810-24-000124:mdna:52]
[same as prior period, unchanged from 0001045810-23-000227:mdna:56]

[0001045810-24-000124:mdna:53]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Compute & Networking | $ | 22,675 |  |  | $ | 4,460 |  |  | $ | 18,215 |  |  | 408 | % |  |  |  |  |  |  |  |  |
| Graphics | 3,369 |  |  | 2,732 |  |  | 637 |  |  | 23 | % |  |  |  |  |  |  |  |  |
| Total | $ | 26,044 |  |  | $ | 7,192 |  |  | $ | 18,852 |  |  | 262 | % |  |  |  |  |  |  |  |  |

[0001045810-24-000124:mdna:54]
[same as prior period, unchanged from 0001045810-23-000227:mdna:79]

[0001045810-24-000124:mdna:55]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Compute & Networking | $ | 17,047 |  |  | $ | 2,160 |  |  | $ | 14,887 |  |  | 689 | % |  |  |  |  |  |  |  |  |
| Graphics | 1,241 |  |  | 1,046 |  |  | 195 |  |  | 19 | % |  |  |  |  |  |  |  |  |
| All Other | (1,379) |  |  | (1,066) |  |  | (313) |  |  | 29 | % |  |  |  |  |  |  |  |  |
| Total | $ | 16,909 |  |  | $ | 2,140 |  |  | $ | 14,769 |  |  | 690 | % |  |  |  |  |  |  |  |  |

[0001045810-24-000124:mdna:56]
Compute & Networking revenue – The year-on-year increase was due to higher Data Center revenue. Compute GPU grew 497%, due to higher shipments of the NVIDIA Hopper GPU computing platform used for training and inferencing with large language models, recommendation engines, and generative AI applications. Networking was up 242% on strong growth of InfiniBand end-to-end solutions.

[0001045810-24-000124:mdna:57]
Graphics revenue – The year-on-year increase of 18% was led by higher demand for Gaming.

[0001045810-24-000124:mdna:58]
Reportable segment operating income – The year-on-year increase in Compute & Networking and Graphics operating income was driven by higher revenue.

[0001045810-24-000124:mdna:59]
All Other operating loss – The year-on-year increase was due to an increase in stock-based compensation expense.

[0001045810-24-000124:mdna:60]
[same as prior period, unchanged from 0001045810-23-000227:mdna:60]

[0001045810-24-000124:mdna:61]
Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to end customers, such as enterprises and gamers in a different location. Revenue from sales to customers outside of the United States accounted for 48% and 67% of total revenue for the first quarter of fiscal years 2025 and 2024, respectively.

[0001045810-24-000124:mdna:62]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as original equipment manufacturers, or OEMs, original device manufacturers, or ODMs, system integrators, add-in board manufacturers, and distributors. We also have indirect customers, who purchase products through our direct customers; indirect customers include public cloud providers, consumer internet companies, enterprises, startups, and public sector entities.

[0001045810-24-000124:mdna:63]
Sales to one direct customer, Customer A, represented 13% of total revenue and sales to a second direct customer, Customer B, represented 11% of total revenue for the first quarter of fiscal year 2025, both of which were attributable to the Compute & Networking segment.

[0001045810-24-000124:mdna:64]
There was no direct customer that represented 10% or more of total revenue for the first quarter of fiscal year 2024.

[0001045810-24-000124:mdna:65]
Two indirect customers each represented 10% or more of total revenue for the first quarter of fiscal year 2025; one of these indirect customers purchased our products primarily through direct Customer B. Both were attributable to the Compute & Networking segment.

[0001045810-24-000124:mdna:66]
Gross Profit and Gross Margin

[0001045810-24-000124:mdna:67]
Gross profit consists of total net revenue less cost of revenue.

[0001045810-24-000124:mdna:68]
Our overall gross margin increased to 78.4% for the first quarter of fiscal year 2025 from 64.6% for the first quarter of fiscal year 2024. The year over year increase was primarily due to strong Data Center revenue growth of 427%.

[0001045810-24-000124:mdna:69]
Provisions for inventory and excess inventory purchase obligations totaled $393 million and $134 million for the first quarter of fiscal years 2025 and 2024, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $114 million and $50 million for the first quarter of fiscal years 2025 and 2024, respectively. The net effect on our gross margin was an unfavorable impact of 1.1% and 1.2% in the first quarter of fiscal years 2025 and 2024, respectively.

[0001045810-24-000124:mdna:70]
For fiscal year 2025, we expect gross margins to be in the mid-70% range.

[0001045810-24-000124:mdna:71]
[same as prior period, unchanged from 0001045810-23-000227:mdna:72]

[0001045810-24-000124:mdna:72]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Research and development expenses | $ | 2,720 |  |  | $ | 1,875 |  |  | $ | 845 |  |  | 45 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 10.4 | % |  | 26.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales, general and administrative expenses | 777 |  |  | 633 |  |  | 144 |  |  | 23 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 3.0 | % |  | 8.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 3,497 |  |  | $ | 2,508 |  |  | $ | 989 |  |  | 39 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 13.4 | % |  | 34.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001045810-24-000124:mdna:73]
The increases in research and development expenses for the first quarter of fiscal year 2025 were primarily driven by a $482 million increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, and a $242 million increase in compute and infrastructure investments.

[0001045810-24-000124:mdna:74]
The increase in sales, general and administrative expenses for the first quarter of fiscal year 2025 was primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-24-000124:mdna:75]
For fiscal year 2025, we expect operating expenses to grow in the low-40% range.

[0001045810-24-000124:mdna:76]
[same as prior period, unchanged from 0001045810-23-000227:mdna:84]

[0001045810-24-000124:mdna:77]
|  | Three Months Ended |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | $Change |  |  |  |  |  |  |
|  | ($ in millions) |
| Interest income | $ | 359 |  |  | $ | 150 |  |  | $ | 209 |  |  |  |  |  |  |  |
| Interest expense | (64) |  |  | (66) |  |  | 2 |  |  |  |  |  |  |  |
| Other, net | 75 |  |  | (15) |  |  | 90 |  |  |  |  |  |  |  |
| Other income (expense), net | $ | 370 |  |  | $ | 69 |  |  | $ | 301 |  |  |  |  |  |  |  |

[0001045810-24-000124:mdna:78]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. The increase in interest income was due to stronger yields on higher cash balances.

[0001045810-24-000124:mdna:79]
[same as prior period, unchanged from 0001045810-23-000227:mdna:87]

[0001045810-24-000124:mdna:80]
Other, net consists of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. The change in Other, net, compared to the first quarter of fiscal year 2024 was driven by changes in value from our investments in non-affiliated entities. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding our investments in non-affiliated entities.

[0001045810-24-000124:mdna:81]
[same as prior period, unchanged from 0001045810-23-000227:mdna:89]

[0001045810-24-000124:mdna:82]
We recognized income tax expense of $2.4 billion and $166 million for the first quarter of fiscal years 2025 and 2024, respectively. Income tax expense as a percentage of income before income tax was 13.9% and 7.5% for the first quarter of fiscal years 2025 and 2024, respectively.

[0001045810-24-000124:mdna:83]
The effective tax rate increased primarily due to a decreased effect of tax benefits from the foreign-derived intangible income deduction and stock-based compensation relative to the increase in income before income tax.

[0001045810-24-000124:mdna:84]
Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-24-000124:mdna:85]
[same as prior period, unchanged from 0001045810-23-000227:mdna:92]

[0001045810-24-000124:mdna:86]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | (In millions) |
| Cash and cash equivalents | $ | 7,587 |  |  | $ | 7,280 |  |
| Marketable securities | 23,851 |  |  | 18,704 |  |
| Cash, cash equivalents and marketable securities | $ | 31,438 |  |  | $ | 25,984 |  |

[0001045810-24-000124:mdna:87]
|  | Three Months Ended |
|  | Apr 28, 2024 |  | Apr 30, 2023 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 15,345 |  |  | $ | 2,911 |  |
| Net cash used in investing activities | $ | (5,693) |  |  | $ | (841) |  |
| Net cash used in financing activities | $ | (9,345) |  |  | $ | (380) |  |

[0001045810-24-000124:mdna:88]
Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-24-000124:mdna:89]
Cash provided by operating activities increased in the first quarter of fiscal year 2025 compared to the first quarter of fiscal year 2024 due to growth in revenue. Our accounts receivable balance in the first quarter of fiscal year 2025 reflected $429 million from customer payments received prior to next quarter's invoice due date.

[0001045810-24-000124:mdna:90]
Cash used in investing activities increased in the first quarter of fiscal year 2025 compared to the first quarter of fiscal year 2024, primarily driven by higher purchases of marketable securities, partially offset by higher maturities of marketable securities.

[0001045810-24-000124:mdna:91]
Cash used in financing activities increased in the first quarter of fiscal year 2025 compared to the first quarter of fiscal year 2024, mainly due to higher share repurchases and higher tax payments related to RSUs.

[0001045810-24-000124:mdna:92]
[same as prior period, unchanged from 0001045810-23-000227:mdna:99]

[0001045810-24-000124:mdna:93]
Our primary sources of liquidity include cash, cash equivalents, and marketable securities, and the cash generated by our operations. As of April 28, 2024, we had $31.4 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations, $1.3 billion of debt repayment due in the second quarter of fiscal year 2025, and share repurchases. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-24-000124:mdna:94]
Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. Our corporate debt securities are publicly traded with generally no restrictions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-24-000124:mdna:95]
Except for approximately $1.4 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. as of April 28, 2024 are available for use in the U.S. without incurring additional U.S. federal income taxes. We did not make any estimated federal or state tax payments in the first quarter and expect our cash taxes to substantially increase in the second quarter as we will make two federal and state estimated tax payments.

[0001045810-24-000124:mdna:96]
[same as prior period, unchanged from 0001045810-23-000227:mdna:103]

[0001045810-24-000124:mdna:97]
During the first quarter of fiscal year 2025, we paid $98 million in quarterly cash dividends.

[0001045810-24-000124:mdna:98]
Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-24-000124:mdna:99]
On May 22, 2024, we announced an increase in our quarterly cash dividend by 150% from $0.04 per share to $0.10 per share of common stock. The increased dividend is equivalent to $0.01 per share on a post-forward stock split basis, and will be paid on June 28, 2024, to all shareholders of record on June 11, 2024. Refer to Note 15 of the Notes to Condensed

[0001045810-24-000124:mdna:100]
29

[0001045810-24-000124:mdna:101]
Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for further information regarding the forward stock split.

[0001045810-24-000124:mdna:102]
During the first quarter of fiscal year 2025, we repurchased 9.9 million shares of our common stock for $8.0 billion. As of April 28, 2024, we were authorized, subject to certain specifications, to repurchase up to $14.5 billion of additional shares of our common stock. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities. We plan to continue share repurchases this fiscal year.

[0001045810-24-000124:mdna:103]
From April 29, 2024 through May 24, 2024, we repurchased 2.3 million shares for $2.1 billion pursuant to a Rule 10b5-1 trading plan.

[0001045810-24-000124:mdna:104]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax was not material for the first quarter of fiscal year 2025.

[0001045810-24-000124:mdna:105]
Outstanding Indebtedness and Commercial Paper Program

[0001045810-24-000124:mdna:106]
Our aggregate debt maturities as of April 28, 2024, by year payable, are as follows:

[0001045810-24-000124:mdna:107]
|  |  | Apr 28, 2024 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,250 |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 2,750 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (40) |  |
| Net carrying amount |  | 9,710 |  |
| Less short-term portion |  | (1,250) |  |
| Total long-term portion |  | $ | 8,460 |  |

[0001045810-24-000124:mdna:108]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2024, no commercial paper was outstanding.

[0001045810-24-000124:mdna:109]
Refer to Note 11 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for further discussion.

[0001045810-24-000124:mdna:110]
[same as prior period, unchanged from 0001045810-23-000227:mdna:112]

[0001045810-24-000124:mdna:111]
Unrecognized tax benefits were $1.4 billion, which includes related interest and penalties of $161 million recorded in non-current income tax payable as of April 28, 2024. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-24-000124:mdna:112]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024 for a description of our contractual obligations. For a description of our operating lease obligations, long-term debt, and purchase obligations, refer to Notes 2, 11, and 12 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q, respectively.

[0001045810-24-000124:mdna:113]
[same as prior period, unchanged from 0001045810-23-000227:mdna:116]

[0001045810-24-000124:mdna:114]
[same as prior period, unchanged from 0001045810-23-000227:mdna:117]

[0001045810-24-000124:mdna:115]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-24-000124:mdna:116]
There has been no adoption of any new and recently issued accounting pronouncements.
