# NVDA notes — 0001045810-24-000124


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-24-000124:notes:1]
[same as prior period, unchanged from 0001045810-23-000227:notes:1]

[0001045810-24-000124:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2024 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024.

[0001045810-24-000124:notes:3]
[same as prior period, unchanged from 0001045810-23-000227:notes:3]

[0001045810-24-000124:notes:4]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024.

[0001045810-24-000124:notes:5]
[same as prior period, unchanged from 0001045810-23-000227:notes:5]

[0001045810-24-000124:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The first quarters of fiscal years 2025 and 2024 were both 13-week quarters.

[0001045810-24-000124:notes:7]
[same as prior period, unchanged from 0001045810-23-000227:notes:9]

[0001045810-24-000124:notes:8]
[same as prior period, unchanged from 0001045810-23-000227:notes:10]

[0001045810-24-000124:notes:9]
[same as prior period, unchanged from 0001045810-23-000227:notes:11]

[0001045810-24-000124:notes:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories and product purchase commitments, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-24-000124:notes:11]
Recently Issued Accounting Pronouncements

[0001045810-24-000124:notes:12]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-24-000124:notes:13]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard to provide for additional disclosures about significant expenses in operating segments. The standard is effective for our annual reporting starting with fiscal year 2025 and for interim period reporting starting in fiscal year 2026 retrospectively. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

[0001045810-24-000124:notes:14]
In December 2023, the FASB issued a new accounting standard which provides for new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-24-000124:notes:15]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2025 and 2035.

[0001045810-24-000124:notes:16]
Future minimum lease payments under our non-cancelable operating leases as of April 28, 2024 were as follows:

[0001045810-24-000124:notes:17]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first quarter of fiscal year 2025) | $ | 221 |  |
| 2026 | 306 |  |
| 2027 | 290 |  |
| 2028 | 270 |  |
| 2029 | 236 |  |
| 2030 and thereafter | 410 |  |
| Total | 1,733 |  |
| Less imputed interest | 206 |  |
| Present value of net future minimum lease payments | 1,527 |  |
| Less short-term operating lease liabilities | 246 |  |
| Long-term operating lease liabilities | $ | 1,281 |  |

[0001045810-24-000124:notes:18]
In addition, we have operating leases, primarily for our data centers, that are expected to commence during fiscal year 2025 with lease terms of 2 to 11 years for $923 million.

[0001045810-24-000124:notes:19]
Operating lease expenses were $80 million and $59 million for the first quarter of fiscal years 2025 and 2024, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2025 and 2024 were not significant.

[0001045810-24-000124:notes:20]
[same as prior period, unchanged from 0001045810-23-000227:notes:21]

[0001045810-24-000124:notes:21]
|  | Three Months Ended |
|  | Apr 28, 2024 |  | Apr 30, 2023 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 69 |  |  | $ | 61 |  |
| Operating lease assets obtained in exchange for lease obligations | 250 |  |  | 106 |  |

[0001045810-24-000124:notes:22]
As of April 28, 2024, our operating leases had a weighted average remaining lease term of 6.3 years and a weighted average discount rate of 3.89%. As of January 28, 2024, our operating leases had a weighted average remaining lease term of 6.1 years and a weighted average discount rate of 3.76%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-24-000124:notes:23]
[same as prior period, unchanged from 0001045810-23-000227:notes:24]

[0001045810-24-000124:notes:24]
Our Condensed Consolidated Statements of Income include stock-based compensation expense, net of amounts capitalized into inventory and subsequently recognized to cost of revenue, as follows:

[0001045810-24-000124:notes:25]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Cost of revenue | $ | 36 |  |  | $ | 27 |  |  |  |  |  |
| Research and development | 727 |  |  | 524 |  |  |  |  |  |
| Sales, general and administrative | 248 |  |  | 184 |  |  |  |  |  |
| Total | $ | 1,011 |  |  | $ | 735 |  |  |  |  |  |

[0001045810-24-000124:notes:26]
[same as prior period, unchanged from 0001045810-23-000227:notes:27]

[0001045810-24-000124:notes:27]
[same as prior period, unchanged from 0001045810-23-000227:notes:28]

[0001045810-24-000124:notes:28]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, Jan 28, 2024 | 37 |  |  | $ | 245.94 |  |  |  |  |  |
| Granted | 7 |  |  | $ | 801.79 |  |  |  |  |  |
| Vested | (6) |  |  | $ | 176.59 |  |  |  |  |  |
| Balances, Apr 28, 2024 | 38 |  |  | $ | 361.45 |  |  |  |  |  |

[0001045810-24-000124:notes:29]
As of April 28, 2024, there was $13.2 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and 0.8 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-24-000124:notes:30]
[same as prior period, unchanged from 0001045810-23-000227:notes:31]

[0001045810-24-000124:notes:31]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 14,881 |  |  | $ | 2,043 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,462 |  |  | 2,470 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 27 |  |  | 20 |  |  |  |  |  |
| Diluted weighted average shares | 2,489 |  |  | 2,490 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 6.04 |  |  | $ | 0.83 |  |  |  |  |  |
| Diluted (2) | $ | 5.98 |  |  | $ | 0.82 |  |  |  |  |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 6 |  |  | 4 |  |  |  |  |  |

[0001045810-24-000124:notes:32]
[same as prior period, unchanged from 0001045810-23-000227:notes:33]

[0001045810-24-000124:notes:33]
[same as prior period, unchanged from 0001045810-23-000227:notes:34]

[0001045810-24-000124:notes:34]
[same as prior period, unchanged from 0001045810-23-000227:notes:35]


## us-gaap:ScheduleOfWeightedAverageNumberOfSharesTableTextBlock

[0001045810-24-000124:notes:35]
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-24-000124:notes:36]
(2)    Calculated as net income divided by diluted weighted average shares.
The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the Stock Split as if it had been effective for all periods presented:

[0001045810-24-000124:notes:37]
|  | Pro Forma (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 14,881 |  |  | $ | 2,043 |  |  | $ | 29,760 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,620 |  |  | 24,700 |  |  | 24,690 |  |  | 24,870 |  |  | 24,960 |  |
| Dilutive impact of outstanding equity awards | 270 |  |  | 200 |  |  | 250 |  |  | 200 |  |  | 390 |  |
| Diluted weighted average shares | 24,890 |  |  | 24,900 |  |  | 24,940 |  |  | 25,070 |  |  | 25,350 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.60 |  |  | $ | 0.08 |  |  | $ | 1.21 |  |  | $ | 0.18 |  |  | $ | 0.39 |  |
| Diluted (2) | $ | 0.60 |  |  | $ | 0.08 |  |  | $ | 1.19 |  |  | $ | 0.17 |  |  | $ | 0.38 |  |

[0001045810-24-000124:notes:38]
(1)       Calculated as net income divided by basic weighted average shares.

[0001045810-24-000124:notes:39]
(2)       Calculated as net income divided by diluted weighted average shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-24-000124:notes:40]
Income Taxes
Income tax expense was $2.4 billion and $166 million for the first quarter of fiscal years 2025 and 2024, respectively. Income tax expense as a percentage of income before income tax was 13.9% and 7.5% for the first quarter of fiscal years 2025 and 2024, respectively.

[0001045810-24-000124:notes:41]
The effective tax rate increased primarily due to a decreased effect of tax benefits from the foreign-derived intangible income deduction and stock-based compensation relative to the increase in income before income tax.

[0001045810-24-000124:notes:42]
Our effective tax rates for the first quarter of fiscal years 2025 and 2024 were lower than the U.S. federal statutory rate of 21% due to tax benefits from stock-based compensation, the foreign-derived intangible income deduction, income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit. 
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 28, 2024, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-24-000124:notes:43]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to publicly held debt securities are classified as “available-for-sale” debt securities.

[0001045810-24-000124:notes:44]
The following is a summary of cash equivalents and marketable securities:

[0001045810-24-000124:notes:45]
|  | Apr 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 11,397 |  |  | $ | 3 |  |  | $ | (43) |  |  | $ | 11,357 |  |  | $ | 733 |  |  | $ | 10,624 |  |
| Debt securities issued by the U.S. Treasury | 11,314 |  |  | — |  |  | (62) |  |  | 11,252 |  |  | 886 |  |  | 10,366 |  |
| Money market funds | 5,374 |  |  | — |  |  | — |  |  | 5,374 |  |  | 5,374 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,826 |  |  | — |  |  | (7) |  |  | 2,819 |  |  | 189 |  |  | 2,630 |  |
| Certificates of deposit | 286 |  |  | — |  |  | — |  |  | 286 |  |  | 69 |  |  | 217 |  |
| Foreign government bonds | 14 |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 31,211 |  |  | $ | 3 |  |  | $ | (112) |  |  | $ | 31,102 |  |  | $ | 7,251 |  |  | $ | 23,851 |  |

[0001045810-24-000124:notes:46]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

[0001045810-24-000124:notes:47]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-24-000124:notes:48]
|  | Apr 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 9,720 |  |  | $ | (60) |  |  | $ | 756 |  |  | $ | (2) |  |  | $ | 10,476 |  |  | $ | (62) |  |
| Corporate debt securities | 6,943 |  |  | (42) |  |  | 188 |  |  | (1) |  |  | 7,131 |  |  | (43) |  |
| Debt securities issued by U.S. government agencies | 2,391 |  |  | (7) |  |  | — |  |  | — |  |  | 2,391 |  |  | (7) |  |
| Total | $ | 19,054 |  |  | $ | (109) |  |  | $ | 944 |  |  | $ | (3) |  |  | $ | 19,998 |  |  | $ | (112) |  |

[0001045810-24-000124:notes:49]
|  | Jan 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 3,343 |  |  | $ | (5) |  |  | $ | 1,078 |  |  | $ | (5) |  |  | $ | 4,421 |  |  | $ | (10) |  |
| Corporate debt securities | 1,306 |  |  | (3) |  |  | 618 |  |  | (2) |  |  | 1,924 |  |  | (5) |  |
| Debt securities issued by U.S. government agencies | 670 |  |  | (1) |  |  | — |  |  | — |  |  | 670 |  |  | (1) |  |
| Total | $ | 5,319 |  |  | $ | (9) |  |  | $ | 1,696 |  |  | $ | (7) |  |  | $ | 7,015 |  |  | $ | (16) |  |

[0001045810-24-000124:notes:50]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

[0001045810-24-000124:notes:51]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-24-000124:notes:52]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,811 |  |  | $ | 16,800 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 14,400 |  |  | 14,302 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 31,211 |  |  | $ | 31,102 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-24-000124:notes:53]
Fair Value of Financial Assets and Liabilities and Investments in Non-Affiliated Entities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-24-000124:notes:54]
|  | Pricing Category |  | Fair Value at |
|  |  | Apr 28, 2024 |  | Jan 28, 2024 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 5,374 |  |  | $ | 3,031 |  |
| Corporate debt securities | Level 2 |  | $ | 11,357 |  |  | $ | 10,152 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 11,252 |  |  | $ | 9,524 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,819 |  |  | $ | 2,333 |  |
| Certificates of deposit | Level 2 |  | $ | 286 |  |  | $ | 510 |  |
| Foreign government bonds | Level 2 |  | $ | 14 |  |  | $ | 174 |  |
| Other assets (Investments in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities | Level 1 |  | $ | 287 |  |  | $ | 225 |  |
| Liabilities (1) |  |  |  |  |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,242 |  |  | $ | 1,228 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 960 |  |  | $ | 970 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,096 |  |  | $ | 1,115 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,331 |  |  | $ | 1,367 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,026 |  |  | $ | 1,057 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 805 |  |  | $ | 851 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,487 |  |  | $ | 1,604 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 368 |  |  | $ | 403 |  |

[0001045810-24-000124:notes:55]
[same as prior period, unchanged from 0001045810-23-000227:notes:52]

[0001045810-24-000124:notes:56]
Investments in Non-Affiliated Entities

[0001045810-24-000124:notes:57]
Our investments in non-affiliated entities include marketable equity securities, which are publicly traded, and non-marketable equity securities, which are primarily investments in privately held companies.

[0001045810-24-000124:notes:58]
Our marketable equity securities have readily determinable fair values and are recorded in long-term other assets on our Condensed Consolidated Balance Sheets at fair value with changes in fair value recorded in Other income and expense, net on our Condensed Consolidated Statements of Income. Marketable equity securities totaled $287 million and $225 million as of April 28, 2024 and January 28, 2024, respectively. The net unrealized and realized gains and losses of investments in marketable securities were not significant for the first quarter of fiscal years 2025 and 2024.

[0001045810-24-000124:notes:59]
Our non-marketable equity securities are recorded in long-term other assets on our Condensed Consolidated Balance Sheets and valued under the measurement alternative. The carrying value of our non-marketable equity securities totaled $1.5 billion and $1.3 billion as of April 28, 2024 and January 28, 2024, respectively. Gains and losses on these investments, realized and unrealized, are recognized in Other income and expense, net on our Condensed Consolidated Statements of Income.

[0001045810-24-000124:notes:60]
Adjustments to the carrying value of our non-marketable equity securities during the first quarter of fiscal years 2025 and 2024 were as follows:

[0001045810-24-000124:notes:61]
|  | Apr 28, 2024 |  | Apr 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,321 |  |  | $ | 288 |  |
| Adjustments related to non-marketable equity securities: |  |  |  |
| Net additions | 127 |  |  | 221 |  |
| Unrealized gains | 15 |  |  | — |  |
| Impairments and unrealized losses | — |  |  | (13) |  |
| Balance at end of period | $ | 1,463 |  |  | $ | 496 |  |

[0001045810-24-000124:notes:62]
The following table summarizes the cumulative gross unrealized gains, losses and impairments related to non-marketable equity securities:

[0001045810-24-000124:notes:63]
|  | Apr 28, 2024 |
|  | (In millions) |
| Cumulative gross unrealized gains | $ | 285 |  |
| Cumulative gross impairments and unrealized losses | (45) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-24-000124:notes:64]
[same as prior period, unchanged from 0001045810-23-000227:notes:53]

[0001045810-24-000124:notes:65]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 2,648 |  |  | $ | (1,844) |  |  | $ | 804 |  |  | $ | 2,642 |  |  | $ | (1,720) |  |  | $ | 922 |  |
| Patents and licensed technology | 442 |  |  | (260) |  |  | 182 |  |  | 449 |  |  | (259) |  |  | 190 |  |
| Total intangible assets | $ | 3,090 |  |  | $ | (2,104) |  |  | $ | 986 |  |  | $ | 3,091 |  |  | $ | (1,979) |  |  | $ | 1,112 |  |

[0001045810-24-000124:notes:66]
Amortization expense associated with intangible assets was $143 million and $181 million for the first quarter of fiscal year 2025 and 2024, respectively.

[0001045810-24-000124:notes:67]
The following table outlines the estimated amortization expense related to the net carrying amount of intangible assets as of April 28, 2024:

[0001045810-24-000124:notes:68]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first quarter of fiscal year 2025) | $ | 418 |  |
| 2026 | 267 |  |
| 2027 | 155 |  |
| 2028 | 37 |  |
| 2029 | 9 |  |
| 2030 and thereafter | 100 |  |
| Total | $ | 986 |  |

[0001045810-24-000124:notes:69]
In the first quarter of fiscal year 2025, goodwill increased by $23 million from business combinations, and was assigned to our Compute & Networking segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-24-000124:notes:70]
Balance Sheet Components 
Two customers accounted for 16% and 15% of our accounts receivable balance as of April 28, 2024. Two customers accounted for 24% and 11% of our accounts receivable balance as of January 28, 2024.

[0001045810-24-000124:notes:71]
[same as prior period, unchanged from 0001045810-23-000227:notes:60]

[0001045810-24-000124:notes:72]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
| Inventories (1): | (In millions) |
| Raw materials | $ | 1,991 |  |  | $ | 1,719 |  |
| Work in process | 1,625 |  |  | 1,505 |  |
| Finished goods | 2,248 |  |  | 2,058 |  |
| Total inventories | $ | 5,864 |  |  | $ | 5,282 |  |

[0001045810-24-000124:notes:73]
(1)    During the first quarter of fiscal years 2025 and 2024, we recorded an inventory provision of $210 million and $105 million, respectively, in cost of revenue.

[0001045810-24-000124:notes:74]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
| Other Assets: | (In millions) |
| Prepaid supply and capacity agreements (1) | $ | 2,232 |  |  | $ | 2,458 |  |
| Investments in non-affiliated entities | 1,750 |  |  | 1,546 |  |
| Prepaid royalties | 358 |  |  | 364 |  |
| Other | 228 |  |  | 132 |  |
| Total other assets | $ | 4,568 |  |  | $ | 4,500 |  |

[0001045810-24-000124:notes:75]
(1)    As of April 28, 2024 and January 28, 2024, there were an additional $3.3 billion and $2.5 billion of short-term prepaid supply and capacity agreements included in Prepaid expenses and other current assets, respectively.

[0001045810-24-000124:notes:76]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
| Accrued and Other Current Liabilities: | (In millions) |
| Taxes payable (1) | $ | 3,881 |  |  | $ | 296 |  |
| Customer program accruals | 2,744 |  |  | 2,081 |  |
| Excess inventory purchase obligations (2) | 1,684 |  |  | 1,655 |  |
| Deferred revenue (3) | 845 |  |  | 764 |  |
| Product warranty and return provisions | 643 |  |  | 415 |  |
| Accrued payroll and related expenses | 639 |  |  | 675 |  |
| Unsettled share repurchases | 262 |  |  | 187 |  |
| Operating leases | 246 |  |  | 228 |  |
| Licenses and royalties | 164 |  |  | 182 |  |
| Other | 150 |  |  | 199 |  |
| Total accrued and other current liabilities | $ | 11,258 |  |  | $ | 6,682 |  |

[0001045810-24-000124:notes:77]
(1)    We did not make any estimated federal or state tax payments in the first quarter and expect our cash taxes to substantially increase in the second quarter as we will make two federal and state estimated tax payments.

[0001045810-24-000124:notes:78]
(2)    During the first quarter of fiscal years 2025 and 2024, we recorded an expense of approximately $183 million and $29 million, respectively, in cost of revenue for inventory purchase obligations in excess of our current demand projections, supplier charges, and penalties related to cancellations and underutilization.

[0001045810-24-000124:notes:79]
(3)    Deferred revenue primarily includes customer advances and deferrals related to hardware support, software support, cloud services, and license and development arrangements. $274 million and $233 million of the balance in the first quarter of fiscal year 2025 and in fiscal year 2024, respectively, were related to customer advances.

[0001045810-24-000124:notes:80]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,553 |  |  | $ | 1,361 |  |
| Deferred revenue (2) | 704 |  |  | 573 |  |
| Deferred income tax | 583 |  |  | 462 |  |
| Licenses payable | 60 |  |  | 80 |  |
| Other | 66 |  |  | 65 |  |
| Total other long-term liabilities | $ | 2,966 |  |  | $ | 2,541 |  |

[0001045810-24-000124:notes:81]
[same as prior period, unchanged from 0001045810-23-000227:notes:69]

[0001045810-24-000124:notes:82]
(2)    Deferred revenue primarily includes deferrals related to hardware support and software support.

[0001045810-24-000124:notes:83]
[same as prior period, unchanged from 0001045810-23-000227:notes:71]

[0001045810-24-000124:notes:84]
The following table shows the changes in short and long term deferred revenue during the first quarter of fiscal years 2025 and 2024:

[0001045810-24-000124:notes:85]
|  | Apr 28, 2024 |  | Apr 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,337 |  |  | $ | 572 |  |
| Deferred revenue additions during the period | 553 |  |  | 287 |  |
| Revenue recognized during the period | (341) |  |  | (262) |  |
| Balance at end of period | $ | 1,549 |  |  | $ | 597 |  |

[0001045810-24-000124:notes:86]
We recognized $188 million in revenue in the first quarter of fiscal year 2025 from deferred revenue as of January 28, 2024.

[0001045810-24-000124:notes:87]
Revenue allocated to remaining performance obligations, which includes deferred revenue and amounts that will be invoiced and recognized as revenue in future periods, was $1.3 billion as of April 28, 2024. We expect to recognize approximately 38% of this revenue over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-24-000124:notes:88]
[same as prior period, unchanged from 0001045810-23-000227:notes:75]

[0001045810-24-000124:notes:89]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities. The change in fair value of these non-designated contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-24-000124:notes:90]
The table below presents the notional value of our foreign currency contracts outstanding:

[0001045810-24-000124:notes:91]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,198 |  |  | $ | 1,168 |  |
| Non-designated hedges | $ | 704 |  |  | $ | 597 |  |

[0001045810-24-000124:notes:92]
The unrealized gains and losses or fair value of our foreign currency contracts was not significant as of April 28, 2024 and January 28, 2024.

[0001045810-24-000124:notes:93]
As of April 28, 2024, all designated foreign currency contracts mature within 18 months. The expected realized gains and losses deferred to accumulated other comprehensive income or loss related to foreign currency contracts was not significant.

[0001045810-24-000124:notes:94]
During the first quarter of fiscal years 2025 and 2024, the impact of derivative financial instruments designated for hedge accounting treatment in other comprehensive income or loss was not significant and the instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-24-000124:notes:95]
Debt
Long-Term Debt

[0001045810-24-000124:notes:96]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 |  | 0.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 9,710 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,460 |  |  | $ | 8,459 |  |

[0001045810-24-000124:notes:97]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes are calendar year.

[0001045810-24-000124:notes:98]
As of April 28, 2024, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-24-000124:notes:99]
Commercial Paper

[0001045810-24-000124:notes:100]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2024, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-24-000124:notes:101]
Commitments and Contingencies
Purchase Obligations

[0001045810-24-000124:notes:102]
Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-24-000124:notes:103]
As of April 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $18.8 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. These changes may result in costs incurred through the date of cancellation. Other non-inventory purchase obligations were $10.6 billion, including $8.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

[0001045810-24-000124:notes:104]
Total future purchase commitments as of April 28, 2024 are as follows:

[0001045810-24-000124:notes:105]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first quarter of fiscal year 2025) | $ | 19,306 |  |
| 2026 | 3,438 |  |
| 2027 | 2,573 |  |
| 2028 | 2,222 |  |
| 2029 | 1,585 |  |
| 2030 and thereafter | 249 |  |
| Total | $ | 29,373 |  |

[0001045810-24-000124:notes:106]
In addition to the purchase commitments included in the table above, at the end of the first quarter of fiscal year 2025, we had commitments of approximately $1.2 billion to complete business combinations, subject to closing conditions, and acquire land and buildings.

[0001045810-24-000124:notes:107]
Accrual for Product Warranty Liabilities

[0001045810-24-000124:notes:108]
The estimated amount of product warranty liabilities was $532 million and $306 million as of April 28, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-24-000124:notes:109]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 306 |  |  | $ | 82 |  |  |  |  |  |
| Additions | 234 |  |  | 13 |  |  |  |  |  |
| Utilization | (8) |  |  | (18) |  |  |  |  |  |
| Balance at end of period | $ | 532 |  |  | $ | 77 |  |  |  |  |  |

[0001045810-24-000124:notes:110]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-24-000124:notes:111]
Litigation

[0001045810-24-000124:notes:112]
Securities Class Action and Derivative Lawsuits

[0001045810-24-000124:notes:113]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. Four amicus briefs in support of NVIDIA’s petition were filed on April 5, 2024.

[0001045810-24-000124:notes:114]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The stay remains in place. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-24-000124:notes:115]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-24-000124:notes:116]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-24-000124:notes:117]
Accounting for Loss Contingencies

[0001045810-24-000124:notes:118]
As of April 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-24-000124:notes:119]
[same as prior period, unchanged from 0001045810-23-000227:notes:109]

[0001045810-24-000124:notes:120]
During the first quarter of fiscal year 2025, we repurchased 9.9 million shares of our common stock for $8.0 billion. We did not repurchase any shares during the first quarter of fiscal year 2024. As of April 28, 2024, we were authorized, subject to certain specifications, to repurchase up to $14.5 billion additional shares of our common stock. Our share repurchase program aims to offset dilution from shares issued to employees. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-24-000124:notes:121]
From April 29, 2024 through May 24, 2024, we repurchased 2.3 million shares for $2.1 billion pursuant to a Rule 10b5-1 trading plan.

[0001045810-24-000124:notes:122]
During the first quarter of fiscal years 2025 and 2024, we paid $98 million and $99 million in cash dividends to our shareholders, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-24-000124:notes:123]
Segment Information
Our Chief Executive Officer is our chief operating decision maker, or CODM, and reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance.

[0001045810-24-000124:notes:124]
[same as prior period, unchanged from 0001045810-23-000227:notes:114]

[0001045810-24-000124:notes:125]
[same as prior period, unchanged from 0001045810-23-000227:notes:115]

[0001045810-24-000124:notes:126]
Operating results by segment include costs or expenses directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

[0001045810-24-000124:notes:127]
The “All Other” category includes the expenses that our CODM does not assign to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related and other costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-24-000124:notes:128]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expenses directly attributable to each reportable segment are included in operating results for each segment. However, our CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-24-000124:notes:129]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended Apr 28, 2024 |  |  |  |  |  |  |  |
| Revenue | $ | 22,675 |  |  | $ | 3,369 |  |  | $ | — |  |  | $ | 26,044 |  |
| Operating income (loss) | $ | 17,047 |  |  | $ | 1,241 |  |  | $ | (1,379) |  |  | $ | 16,909 |  |
| Three Months Ended Apr 30, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 4,460 |  |  | $ | 2,732 |  |  | $ | — |  |  | $ | 7,192 |  |
| Operating income (loss) | $ | 2,160 |  |  | $ | 1,046 |  |  | $ | (1,066) |  |  | $ | 2,140 |  |

[0001045810-24-000124:notes:130]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (1,011) |  |  | $ | (735) |  |  |  |  |  |
| Unallocated cost of revenue and operating expenses | (229) |  |  | (154) |  |  |  |  |  |
| Acquisition-related and other costs | (140) |  |  | (173) |  |  |  |  |  |
| Other | 1 |  |  | (4) |  |  |  |  |  |
| Total | $ | (1,379) |  |  | $ | (1,066) |  |  |  |  |  |

[0001045810-24-000124:notes:131]
Revenue by geographic areas is based upon the billing location of the customer. End customer and shipping location may be different from our customer’s billing location. For example, most of the shipments associated with Singapore revenue went to either the United States or Taiwan in the first quarter of fiscal year 2025. Shipments to Singapore were insignificant. Revenue by geographic areas was as follows:

[0001045810-24-000124:notes:132]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 13,496 |  |  | $ | 2,385 |  |  |  |  |  |
| Taiwan | 4,373 |  |  | 1,796 |  |  |  |  |  |
| Singapore | 4,037 |  |  | 762 |  |  |  |  |  |
| China (including Hong Kong) | 2,491 |  |  | 1,590 |  |  |  |  |  |
| Other countries | 1,647 |  |  | 659 |  |  |  |  |  |
| Total revenue | $ | 26,044 |  |  | $ | 7,192 |  |  |  |  |  |

[0001045810-24-000124:notes:133]
The increase in revenue to the United States for the first quarter of fiscal year 2025 was primarily due to higher U.S.-based Compute & Networking segment demand.

[0001045810-24-000124:notes:134]
Sales to one direct customer, Customer A, represented 13% of total revenue and sales to a second direct customer, Customer B, represented 11% of total revenue for the first quarter of fiscal year 2025, both of which were attributable to the Compute & Networking segment. No customer represented 10% or more of total revenue for the first quarter of fiscal year 2024.

[0001045810-24-000124:notes:135]
[same as prior period, unchanged from 0001045810-23-000227:notes:126]

[0001045810-24-000124:notes:136]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 22,563 |  |  | $ | 4,284 |  |  |  |  |  |
| Compute | 19,392 |  |  | 3,357 |  |  |  |  |  |
| Networking | 3,171 |  |  | 927 |  |  |  |  |  |
| Gaming | 2,647 |  |  | 2,240 |  |  |  |  |  |
| Professional Visualization | 427 |  |  | 295 |  |  |  |  |  |
| Automotive | 329 |  |  | 296 |  |  |  |  |  |
| OEM and Other | 78 |  |  | 77 |  |  |  |  |  |
| Total revenue | $ | 26,044 |  |  | $ | 7,192 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001045810-24-000124:notes:137]
Subsequent Events
On May 22, 2024, we announced a ten-for-one forward stock split, or the Stock Split, of our issued common stock to be effected through the filing of an amendment to our Restated Certificate of Incorporation, or the Amendment, with the Secretary of the State of Delaware. The Amendment will result in a proportionate increase in the number of shares of authorized common stock. As a result of the Stock Split, each record holder of common stock as of the close of market on June 6, 2024 will receive nine additional shares of common stock, to be distributed after the close of market on June 7, 2024. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the Stock Split as if it had been effective for all periods presented:

[0001045810-24-000124:notes:138]
On May 22, 2024, we also announced an increase in our quarterly cash dividend by 150% from $0.04 per share to $0.10 per share of common stock. The increased dividend is equivalent to $0.01 per share on a post-Stock Split basis and will be paid on June 28, 2024, to all shareholders of record on June 11, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-24-000124:notes:139]
On March 4, 2024, Debora Shoquist, Executive Vice President, Operations, adopted a Rule 10b5-1 Trading Arrangement for the sale of up to 41,140 shares of our common stock through June 2, 2025.

[0001045810-24-000124:notes:140]
On March 14, 2024, Jen-Hsun Huang, President and Chief Executive Officer, adopted a Rule 10b5-1 Trading Arrangement for the sale of up to 600,000 shares of our common stock through March 31, 2025.

[0001045810-24-000124:notes:141]
On March 22, 2024, Colette M. Kress, Executive Vice President and Chief Financial Officer, adopted a Rule 10b5-1 Trading Arrangement for the sale of up to 50,000 shares of our common stock through May 15, 2025.

[0001045810-24-000124:notes:142]
On April 12, 2024, Ajay K. Puri, Executive Vice President, Worldwide Field Operations, adopted a Rule 10b5-1 Trading Arrangement for the sale of up to 100,832 shares of our common stock through July 11, 2025.
