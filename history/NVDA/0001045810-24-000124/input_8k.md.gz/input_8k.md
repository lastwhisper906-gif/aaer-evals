# NVDA 8-K — 0001045810-24-000113 filed 2024-05-22

## item codes, every 8-K on or before 2024-05-29

- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2024-05-29

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-24-000113:8k_2_02:1]
EX-99.1
2
q1fy25pr.htm
Q1FY25 PRESS RELEASE

[0001045810-24-000113:8k_2_02:2]
Document

[0001045810-24-000113:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-24-000113:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2025

[0001045810-24-000113:8k_2_02:5]
•Record quarterly revenue of $26.0 billion, up 18% from Q4 and up 262% from a year ago

[0001045810-24-000113:8k_2_02:6]
•Record quarterly Data Center revenue of $22.6 billion, up 23% from Q4 and up 427% from a year ago

[0001045810-24-000113:8k_2_02:7]
•Ten-for-one forward stock split effective June 7, 2024

[0001045810-24-000113:8k_2_02:8]
•Quarterly cash dividend raised 150% to $0.01 per share on a post-split basis

[0001045810-24-000113:8k_2_02:9]
SANTA CLARA, Calif.—May 22, 2024―NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 28, 2024, of $26.0 billion, up 18% from the previous quarter and up 262% from a year ago.

[0001045810-24-000113:8k_2_02:10]
For the quarter, GAAP earnings per diluted share was $5.98, up 21% from the previous quarter and up 629% from a year ago. Non-GAAP earnings per diluted share was $6.12, up 19% from the previous quarter and up 461% from a year ago.

[0001045810-24-000113:8k_2_02:11]
“The next industrial revolution has begun — companies and countries are partnering with NVIDIA to shift the trillion-dollar traditional data centers to accelerated computing and build a new type of data center — AI factories — to produce a new commodity: artificial intelligence,” said Jensen Huang, founder and CEO of NVIDIA. “AI will bring significant productivity gains to nearly every industry and help companies be more cost- and energy-efficient, while expanding revenue opportunities.

[0001045810-24-000113:8k_2_02:12]
“Our data center growth was fueled by strong and accelerating demand for generative AI training and inference on the Hopper platform. Beyond cloud service providers, generative AI has expanded to consumer internet companies, and enterprise, sovereign AI, automotive and healthcare customers, creating multiple multibillion-dollar vertical markets.

[0001045810-24-000113:8k_2_02:13]
“We are poised for our next wave of growth. The Blackwell platform is in full production and forms the foundation for trillion-parameter-scale generative AI. Spectrum-X opens a brand-new market for us to bring large-scale AI to Ethernet-only data centers. And NVIDIA NIM is our new software offering that delivers enterprise-grade, optimized generative AI to run on CUDA everywhere — from the cloud to on-prem data centers and RTX AI PCs — through our expansive network of ecosystem partners.”

[0001045810-24-000113:8k_2_02:14]
NVIDIA also announced a ten-for-one forward stock split of NVIDIA’s issued common stock to make stock ownership more accessible to employees and investors. The split will be effected through an amendment to NVIDIA’s Restated Certificate of Incorporation, which will result in a proportionate increase in the number of shares of authorized common stock. Each record holder of common stock as of the close of market on Thursday, June 6, 2024, will receive nine additional shares of common stock, to be distributed after the close of market on Friday, June 7, 2024. Trading is expected to commence on a split-adjusted basis at market open on Monday, June 10, 2024.

[0001045810-24-000113:8k_2_02:15]
NVIDIA is increasing its quarterly cash dividend by 150% from $0.04 per share to $0.10 per share of common stock. The increased dividend is equivalent to $0.01 per share on a post-split basis and will be paid on Friday, June 28, 2024, to all shareholders of record on Tuesday, June 11, 2024.

[0001045810-24-000113:8k_2_02:16]
Q1 Fiscal 2025 Summary

[0001045810-24-000113:8k_2_02:17]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY25 | Q4 FY24 | Q1 FY24 | Q/Q | Y/Y |
| Revenue | $26,044 | $22,103 | $7,192 | Up 18% | Up 262% |
| Gross margin | 78.4 | % | 76.0 | % | 64.6 | % | Up 2.4 pts | Up 13.8 pts |
| Operating expenses | $3,497 | $3,176 | $2,508 | Up 10% | Up 39% |
| Operating income | $16,909 | $13,615 | $2,140 | Up 24% | Up 690% |
| Net income | $14,881 | $12,285 | $2,043 | Up 21% | Up 628% |
| Diluted earnings per share | $5.98 | $4.93 | $0.82 | Up 21% | Up 629% |

[0001045810-24-000113:8k_2_02:18]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY25 | Q4 FY24 | Q1 FY24 | Q/Q | Y/Y |
| Revenue | $26,044 | $22,103 | $7,192 | Up 18% | Up 262% |
| Gross margin | 78.9 | % | 76.7 | % | 66.8 | % | Up 2.2 pts | Up 12.1 pts |
| Operating expenses | $2,501 | $2,210 | $1,750 | Up 13% | Up 43% |
| Operating income | $18,059 | $14,749 | $3,052 | Up 22% | Up 492% |
| Net income | $15,238 | $12,839 | $2,713 | Up 19% | Up 462% |
| Diluted earnings per share | $6.12 | $5.16 | $1.09 | Up 19% | Up 461% |

[0001045810-24-000113:8k_2_02:19]
Outlook

[0001045810-24-000113:8k_2_02:20]
NVIDIA’s outlook for the second quarter of fiscal 2025 is as follows:

[0001045810-24-000113:8k_2_02:21]
•Revenue is expected to be $28.0 billion, plus or minus 2%.

[0001045810-24-000113:8k_2_02:22]
•GAAP and non-GAAP gross margins are expected to be 74.8% and 75.5%, respectively, plus or minus 50 basis points. For the full year, gross margins are expected to be in the mid-70% range.

[0001045810-24-000113:8k_2_02:23]
•GAAP and non-GAAP operating expenses are expected to be approximately $4.0 billion and $2.8 billion, respectively. Full-year operating expenses are expected to grow in the low-40% range.

[0001045810-24-000113:8k_2_02:24]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $300 million, excluding gains and losses from non-affiliated investments.

[0001045810-24-000113:8k_2_02:25]
•GAAP and non-GAAP tax rates are expected to be 17%, plus or minus 1%, excluding any discrete items.

[0001045810-24-000113:8k_2_02:26]
Highlights

[0001045810-24-000113:8k_2_02:27]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-24-000113:8k_2_02:28]
Data Center

[0001045810-24-000113:8k_2_02:29]
•First-quarter revenue was a record $22.6 billion, up 23% from the previous quarter and up 427% from a year ago.

[0001045810-24-000113:8k_2_02:30]
•Unveiled the NVIDIA Blackwell platform to fuel a new era of AI computing at trillion-parameter scale and the Blackwell-powered DGX SuperPOD™ for generative AI supercomputing.

[0001045810-24-000113:8k_2_02:31]
•Announced NVIDIA Quantum and NVIDIA Spectrum™ X800 series switches for InfiniBand and Ethernet, respectively, optimized for trillion-parameter GPU computing and AI infrastructure.

[0001045810-24-000113:8k_2_02:32]
•Launched NVIDIA AI Enterprise 5.0 with NVIDIA NIM inference microservices to speed enterprise app development.

[0001045810-24-000113:8k_2_02:33]
•Announced TSMC and Synopsys are going into production with NVIDIA cuLitho to accelerate computational lithography, the semiconductor manufacturing industry’s most compute-intensive workload.

[0001045810-24-000113:8k_2_02:34]
•Announced that nine new supercomputers worldwide are using Grace Hopper Superchips to ignite new era of AI supercomputing.

[0001045810-24-000113:8k_2_02:35]
•Unveiled that Grace Hopper Superchips power the top three machines on the Green500 list of the world’s most energy-efficient supercomputers.

[0001045810-24-000113:8k_2_02:36]
•Expanded collaborations with AWS, Google Cloud, Microsoft and Oracle to advance generative AI innovation.

[0001045810-24-000113:8k_2_02:37]
•Worked with Johnson & Johnson MedTech to bring AI capabilities to support surgery.

[0001045810-24-000113:8k_2_02:38]
Gaming and AI PC

[0001045810-24-000113:8k_2_02:39]
•First-quarter Gaming revenue was $2.6 billion, down 8% from the previous quarter and up 18% from a year ago.

[0001045810-24-000113:8k_2_02:40]
•Introduced new AI gaming technologies at GDC for NVIDIA ACE and Neural Graphics.

[0001045810-24-000113:8k_2_02:41]
•Unveiled new AI performance optimizations and integrations for Windows to deliver maximum performance on NVIDIA GeForce RTX AI PCs and workstations.

[0001045810-24-000113:8k_2_02:42]
•Announced more blockbuster games that will incorporate RTX technology, including Star Wars Outlaws and Black Myth Wukong.

[0001045810-24-000113:8k_2_02:43]
•Added support for new models, including Google’s Gemma, for ChatRTX, which brings chatbot capabilities to RTX-powered Windows PCs and workstations.

[0001045810-24-000113:8k_2_02:44]
Professional Visualization

[0001045810-24-000113:8k_2_02:45]
•First-quarter revenue was $427 million, down 8% from the previous quarter and up 45% from a year ago.

[0001045810-24-000113:8k_2_02:46]
•Introduced NVIDIA RTX™ 500 and 1000 professional Ada generation laptop GPUs for AI-enhanced workflows.

[0001045810-24-000113:8k_2_02:47]
•Unveiled  NVIDIA RTX A400 and A1000 GPUs for desktop workstations, based on the NVIDIA Ampere architecture, to bring AI to design and productivity workflows.

[0001045810-24-000113:8k_2_02:48]
•Introduced NVIDIA Omniverse™ Cloud APIs to power industrial digital twin software tools, including an expanded Siemens partnership, and a new framework for the Apple Vision Pro.

[0001045810-24-000113:8k_2_02:49]
•Announced the adoption of the new Earth-2 cloud APIs by The Weather Company and the Central Weather Administration of Taiwan for high-resolution global climate simulations.

[0001045810-24-000113:8k_2_02:50]
Automotive and Robotics

[0001045810-24-000113:8k_2_02:51]
•First-quarter Automotive revenue was $329 million, up 17% from the previous quarter and up 11% from a year ago.

[0001045810-24-000113:8k_2_02:52]
•Announced BYD, XPENG, GAC’s AION Hyper, Nuro and others have chosen the next-generation NVIDIA DRIVE Thor™ platform, which now features Blackwell GPU architecture, to power their next-generation consumer and commercial electric vehicle fleets.

[0001045810-24-000113:8k_2_02:53]
•Revealed U.S. and China electric vehicle makers Lucid and IM Motors are using the NVIDIA DRIVE Orin™ platform for vehicle models targeting the European market.

[0001045810-24-000113:8k_2_02:54]
•Announced an array of partners are using NVIDIA generative AI technologies to transform in-vehicle experiences.

[0001045810-24-000113:8k_2_02:55]
•Introduced the Project GR00T foundation model for humanoid robots and major Isaac robotics platform updates.

[0001045810-24-000113:8k_2_02:56]
CFO Commentary

[0001045810-24-000113:8k_2_02:57]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-24-000113:8k_2_02:58]
Conference Call and Webcast Information

[0001045810-24-000113:8k_2_02:59]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2025 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2025.

[0001045810-24-000113:8k_2_02:60]
Non-GAAP Measures

[0001045810-24-000113:8k_2_02:61]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-24-000113:8k_2_02:62]
About NVIDIA

[0001045810-24-000113:8k_2_02:63]
NVIDIA (NASDAQ: NVDA) is the world leader in accelerated computing.

[0001045810-24-000113:8k_2_02:64]
###

[0001045810-24-000113:8k_2_02:65]
For further information, contact:

[0001045810-24-000113:8k_2_02:66]
| Simona Jankowski |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-24-000113:8k_2_02:67]
Certain statements in this press release including, but not limited to, statements as to: companies and countries building AI factories with NVIDIA accelerated computing to produce artificial intelligence; accelerating demand for generative AI training and inference on the Hopper platform; the expanding reach of generative AI; generative AI expanding to consumer internet companies, and enterprise, sovereign AI, automotive, and healthcare customers, creating multiple multibillion-dollar vertical markets; NVIDIA being poised for the next wave of growth; the Blackwell platform in full production and forming the foundation for trillion-parameter-scale generative AI; Spectrum-X opening a brand-new market for NVIDIA to bring large-scale AI to Ethernet-only data centers; NVIDIA NIM as NVIDIA’s new software offering that delivers enterprise-grade, optimized generative AI run on CUDA everywhere — from the cloud, to on-prem data centers and RTX AI PCs — through NVIDIA’s expansive network of ecosystem partners; NVIDIA's forward stock split; NVIDIA’s next quarterly cash dividend; gross margins being in the mid-70% range for the full year; full-year operating expenses growing in the low-40% range; and NVIDIA’s financial outlook and expected tax rates for the second quarter of fiscal 2025 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; and unexpected loss of performance of our products or technologies when integrated into systems, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-24-000113:8k_2_02:68]
© 2024 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce NOW, NVIDIA DGX SuperPOD, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA DRIVE Thor, NVIDIA RTX and NVIDIA Spectrum are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-24-000113:8k_2_02:69]
NVIDIA CORPORATION

[0001045810-24-000113:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-24-000113:8k_2_02:71]
(In millions, except per share data)

[0001045810-24-000113:8k_2_02:72]
(Unaudited)

[0001045810-24-000113:8k_2_02:73]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 28, |  | April 30, |  |  |  |  |
|  |  |  | 2024 |  | 2023 |  |  |  |  |
| Revenue | $ | 26,044 |  |  | $ | 7,192 |  |  |  |  |  |
| Cost of revenue | 5,638 |  |  | 2,544 |  |  |  |  |  |
| Gross profit | 20,406 |  |  | 4,648 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 2,720 |  |  | 1,875 |  |  |  |  |  |
|  | Sales, general and administrative | 777 |  |  | 633 |  |  |  |  |  |
|  |  | Total operating expenses | 3,497 |  |  | 2,508 |  |  |  |  |  |
| Operating income | 16,909 |  |  | 2,140 |  |  |  |  |  |
|  | Interest income | 359 |  |  | 150 |  |  |  |  |  |
|  | Interest expense | (64) |  |  | (66) |  |  |  |  |  |
|  | Other, net | 75 |  |  | (15) |  |  |  |  |  |
|  |  | Other income (expense), net | 370 |  |  | 69 |  |  |  |  |  |
| Income before income tax | 17,279 |  |  | 2,209 |  |  |  |  |  |
| Income tax expense | 2,398 |  |  | 166 |  |  |  |  |  |
| Net income | $ | 14,881 |  |  | $ | 2,043 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 6.04 |  |  | $ | 0.83 |  |  |  |  |  |
|  | Diluted | $ | 5.98 |  |  | $ | 0.82 |  |  |  |  |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,462 |  |  | 2,470 |  |  |  |  |  |
|  | Diluted | 2,489 |  |  | 2,490 |  |  |  |  |  |

[0001045810-24-000113:8k_2_02:74]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | April 28, |  | January 28, |
|  |  |  |  | 2024 |  | 2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 31,438 |  |  | $ | 25,984 |  |
|  | Accounts receivable, net |  | 12,365 |  |  | 9,999 |  |
|  | Inventories |  | 5,864 |  |  | 5,282 |  |
|  | Prepaid expenses and other current assets |  | 4,062 |  |  | 3,080 |  |
|  |  | Total current assets |  | 53,729 |  |  | 44,345 |  |
| Property and equipment, net |  | 4,006 |  |  | 3,914 |  |
| Operating lease assets |  | 1,532 |  |  | 1,346 |  |
| Goodwill |  | 4,453 |  |  | 4,430 |  |
| Intangible assets, net |  | 986 |  |  | 1,112 |  |
| Deferred income tax assets |  | 7,798 |  |  | 6,081 |  |
| Other assets |  | 4,568 |  |  | 4,500 |  |
|  |  | Total assets |  | $ | 77,072 |  |  | $ | 65,728 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 2,715 |  |  | $ | 2,699 |  |
|  | Accrued and other current liabilities |  | 11,258 |  |  | 6,682 |  |
|  | Short-term debt |  | 1,250 |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 15,223 |  |  | 10,631 |  |
| Long-term debt |  | 8,460 |  |  | 8,459 |  |
| Long-term operating lease liabilities |  | 1,281 |  |  | 1,119 |  |
| Other long-term liabilities |  | 2,966 |  |  | 2,541 |  |
|  |  | Total liabilities |  | 27,930 |  |  | 22,750 |  |
| Shareholders' equity |  | 49,142 |  |  | 42,978 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 77,072 |  |  | $ | 65,728 |  |

[0001045810-24-000113:8k_2_02:75]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | April 28, |  | April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 14,881 |  |  | $ | 2,043 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,011 |  |  | 735 |  |  |  |  |  |
| Depreciation and amortization | 410 |  |  | 384 |  |  |  |  |  |
| Realized and unrealized (gains) losses on investments in non-affiliated entities, net | (69) |  |  | 14 |  |  |  |  |  |
| Deferred income taxes | (1,577) |  |  | (1,135) |  |  |  |  |  |
| Other | (145) |  |  | (34) |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (2,366) |  |  | (252) |  |  |  |  |  |
| Inventories | (577) |  |  | 566 |  |  |  |  |  |
| Prepaid expenses and other assets | (726) |  |  | (215) |  |  |  |  |  |
| Accounts payable | (22) |  |  | 11 |  |  |  |  |  |
| Accrued and other current liabilities | 4,202 |  |  | 689 |  |  |  |  |  |
| Other long-term liabilities | 323 |  |  | 105 |  |  |  |  |  |
| Net cash provided by operating activities | 15,345 |  |  | 2,911 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 4,004 |  |  | 2,512 |  |  |  |  |  |
| Proceeds from sales of marketable securities | 149 |  |  | — |  |  |  |  |  |
| Purchases of marketable securities | (9,303) |  |  | (2,801) |  |  |  |  |  |
| Purchase related to property and equipment and intangible assets | (369) |  |  | (248) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (39) |  |  | (83) |  |  |  |  |  |
| Investments in non-affiliated entities | (135) |  |  | (221) |  |  |  |  |  |
| Net cash used in investing activities | (5,693) |  |  | (841) |  |  |  |  |  |

[0001045810-24-000113:8k_2_02:76]
|  | Three Months Ended |  |  |
|  | April 28, |  | April 30, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 285 |  |  | 246 |  |  |  |  |  |
| Payments related to repurchases of common stock | (7,740) |  |  | — |  |  |  |  |  |
| Payments related to tax on restricted stock units | (1,752) |  |  | (507) |  |  |  |  |  |
| Dividends paid | (98) |  |  | (99) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (40) |  |  | (20) |  |  |  |  |  |
| Net cash used in financing activities | (9,345) |  |  | (380) |  |  |  |  |  |
| Change in cash and cash equivalents | 307 |  |  | 1,690 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 7,280 |  |  | 3,389 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 7,587 |  |  | $ | 5,079 |  |  |  |  |  |

[0001045810-24-000113:8k_2_02:77]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 28, |  | January 28, |  | April 30, |  |  |  |  |
|  |  |  | 2024 |  | 2024 |  | 2023 |  |  |  |  |
| GAAP gross profit |  | $ | 20,406 |  |  | $ | 16,791 |  |  | $ | 4,648 |  |  |  |  |  |
| GAAP gross margin |  | 78.4 | % |  | 76.0 | % |  | 64.6 | % |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | 119 |  |  | 119 |  |  | 119 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | 36 |  |  | 45 |  |  | 27 |  |  |  |  |  |
|  | Other (C) |  | (1) |  |  | 4 |  |  | 8 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 20,560 |  |  | $ | 16,959 |  |  | $ | 4,802 |  |  |  |  |  |
| Non-GAAP gross margin |  | 78.9 | % |  | 76.7 | % |  | 66.8 | % |  |  |  |  |
| GAAP operating expenses |  | $ | 3,497 |  |  | $ | 3,176 |  |  | $ | 2,508 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | (975) |  |  | (948) |  |  | (708) |  |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | (21) |  |  | (18) |  |  | (54) |  |  |  |  |  |
|  | Other (C) |  | — |  |  | — |  |  | 4 |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 2,501 |  |  | $ | 2,210 |  |  | $ | 1,750 |  |  |  |  |  |
| GAAP operating income |  | $ | 16,909 |  |  | $ | 13,615 |  |  | $ | 2,140 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,150 |  |  | 1,134 |  |  | 912 |  |  |  |  |  |
| Non-GAAP operating income |  | $ | 18,059 |  |  | $ | 14,749 |  |  | $ | 3,052 |  |  |  |  |  |
| GAAP other income (expense), net |  | $ | 370 |  |  | $ | 491 |  |  | $ | 69 |  |  |  |  |  |
|  | (Gains) losses from non-affiliated investments |  | (69) |  |  | (260) |  |  | 14 |  |  |  |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  |  |  |  |
| Non-GAAP other income (expense), net |  | $ | 302 |  |  | $ | 232 |  |  | $ | 84 |  |  |  |  |  |
| GAAP net income |  | $ | 14,881 |  |  | $ | 12,285 |  |  | $ | 2,043 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 1,082 |  |  | 875 |  |  | 927 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (725) |  |  | (321) |  |  | (257) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 15,238 |  |  | $ | 12,839 |  |  | $ | 2,713 |  |  |  |  |  |

[0001045810-24-000113:8k_2_02:78]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 28, |  | January 28, |  | April 30, |  |  |  |  |
|  |  |  | 2024 |  | 2024 |  | 2023 |  |  |  |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 5.98 |  |  | $ | 4.93 |  |  | $ | 0.82 |  |  |  |  |  |
|  | Non-GAAP |  | $ | 6.12 |  |  | $ | 5.16 |  |  | $ | 1.09 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation |  | 2,489 |  |  | 2,490 |  |  | 2,490 |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 15,345 |  |  | $ | 11,499 |  |  | $ | 2,911 |  |  |  |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (369) |  |  | (253) |  |  | (248) |  |  |  |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (40) |  |  | (29) |  |  | (20) |  |  |  |  |  |
| Free cash flow |  | $ | 14,936 |  |  | $ | 11,217 |  |  | $ | 2,643 |  |  |  |  |  |

[0001045810-24-000113:8k_2_02:79]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets and transaction costs, and are included in the following line items: |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 28, |  | January 28, |  | April 30, |  |  |  |  |
|  |  |  | 2024 |  | 2024 |  | 2023 |  |  |  |  |
|  | Cost of revenue |  | $ | 119 |  |  | $ | 119 |  |  | $ | 119 |  |  |  |  |  |
|  | Research and development |  | $ | 12 |  |  | $ | 12 |  |  | $ | 12 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 8 |  |  | $ | 6 |  |  | $ | 42 |  |  |  |  |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 28, |  | January 28, |  | April 30, |  |  |  |  |
|  |  |  | 2024 |  | 2024 |  | 2023 |  |  |  |  |
|  | Cost of revenue |  | $ | 36 |  |  | $ | 45 |  |  | $ | 27 |  |  |  |  |  |
|  | Research and development |  | $ | 727 |  |  | $ | 706 |  |  | $ | 524 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 248 |  |  | $ | 242 |  |  | $ | 184 |  |  |  |  |  |
| (C) Other consists of IP-related costs and assets held for sale related adjustments. |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-24-000113:8k_2_02:80]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2025 |
|  |  |  | Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 74.8 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.7 | % |
| Non-GAAP gross margin |  | 75.5 | % |
| GAAP operating expenses |  | $ | 3,950 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,150) |  |
| Non-GAAP operating expenses |  | $ | 2,800 |  |
