# NVDA note change history — 0001045810-23-000227 → 0001045810-24-000124


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-29):
[0001045810-24-000124:note_history:1]
Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.
  (was, 2023-11-21, similarity 0.998):
[0001045810-23-000227:note_history:1]
Our purchase obligations reflect our commitments to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

- added (2024-05-29):
[0001045810-24-000124:note_history:2]
As of April 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $18.8 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. These changes may result in costs incurred through the date of cancellation. Other non-inventory purchase obligations were $10.6 billion, including $8.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

- changed (2024-05-29):
[0001045810-24-000124:note_history:3]
Total future purchase commitments as of April 28, 2024 are as follows:
  (was, 2023-11-21, similarity 0.9242):
[0001045810-23-000227:note_history:3]
Total future purchase commitments as of October 29, 2023 are as follows:

- changed (2024-05-29):
[0001045810-24-000124:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first quarter of fiscal year 2025) | $ | 19,306 |  |
| 2026 | 3,438 |  |
| 2027 | 2,573 |  |
| 2028 | 2,222 |  |
| 2029 | 1,585 |  |
| 2030 and thereafter | 249 |  |
| Total | $ | 29,373 |  |
  (was, 2023-11-21, similarity 0.9575):
[0001045810-23-000227:note_history:4]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first nine months of fiscal year 2024) | $ | 6,499 |  |
| 2025 | 11,861 |  |
| 2026 | 1,128 |  |
| 2027 | 1,038 |  |
| 2028 | 660 |  |
| 2029 and thereafter | 354 |  |
| Total | $ | 21,540 |  |

- added (2024-05-29):
[0001045810-24-000124:note_history:5]
In addition to the purchase commitments included in the table above, at the end of the first quarter of fiscal year 2025, we had commitments of approximately $1.2 billion to complete business combinations, subject to closing conditions, and acquire land and buildings.

- changed (2024-05-29):
[0001045810-24-000124:note_history:6]
The estimated amount of product warranty liabilities was $532 million and $306 million as of April 28, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:
  (was, 2023-11-21, similarity 0.9505):
[0001045810-23-000227:note_history:6]
The estimated amount of product warranty liabilities was $142 million and $82 million as of October 29, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

- added (2024-05-29):
[0001045810-24-000124:note_history:7]
|  | Three Months Ended |  |  |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 306 |  |  | $ | 82 |  |  |  |  |  |
| Additions | 234 |  |  | 13 |  |  |  |  |  |
| Utilization | (8) |  |  | (18) |  |  |  |  |  |
| Balance at end of period | $ | 532 |  |  | $ | 77 |  |  |  |  |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:8]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. Four amicus briefs in support of NVIDIA’s petition were filed on April 5, 2024.
  (was, 2023-11-21, similarity 0.7115):
[0001045810-23-000227:note_history:8]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment

- changed (2024-05-29):
[0001045810-24-000124:note_history:9]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The stay remains in place. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.
  (was, 2023-11-21, similarity 0.9195):
[0001045810-23-000227:note_history:9]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties will meet and confer regarding the next steps in this derivative matter. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

- changed (2024-05-29):
[0001045810-24-000124:note_history:10]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2023-11-21, similarity 0.9179):
[0001045810-23-000227:note_history:10]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. Following the Ninth Circuit’s denial of NVIDIA’s petition for rehearing on November 15, 2023, the parties will meet and confer regarding the next steps in these derivative matters. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- changed (2024-05-29):
[0001045810-24-000124:note_history:11]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.
  (was, 2023-11-21, similarity 0.9169):
[0001045810-23-000227:note_history:11]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures.

- changed (2024-05-29):
[0001045810-24-000124:note_history:12]
As of April 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2023-11-21, similarity 0.8823):
[0001045810-23-000227:note_history:12]
As of October 29, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2024-05-29):
[0001045810-23-000227:note_history:13]
As of October 29, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $17.11 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of

- removed (2024-05-29):
[0001045810-23-000227:note_history:14]
cancellation. Other non-inventory purchase obligations were $4.43 billion, which includes $3.60 billion of multi-year cloud service agreements, primarily to support our research and development efforts.

- removed (2024-05-29):
[0001045810-23-000227:note_history:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2023 |  | October 30, 2022 |  | October 29, 2023 |  | October 30, 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 115 |  |  | $ | 168 |  |  | $ | 82 |  |  | $ | 46 |  |
| Additions | 50 |  |  | 3 |  |  | 105 |  |  | 141 |  |
| Utilization | (23) |  |  | (67) |  |  | (45) |  |  | (83) |  |
| Balance at end of period | $ | 142 |  |  | $ | 104 |  |  | $ | 142 |  |  | $ | 104 |  |

- removed (2024-05-29):
[0001045810-23-000227:note_history:16]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-29):
[0001045810-24-000124:note_history:17]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The first quarters of fiscal years 2025 and 2024 were both 13-week quarters.
  (was, 2023-11-21, similarity 0.9839):
[0001045810-23-000227:note_history:17]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The third quarters of fiscal years 2024 and 2023 were both 13-week quarters.

- changed (2024-05-29):
[0001045810-24-000124:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories and product purchase commitments, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2023-11-21, similarity 0.9626):
[0001045810-23-000227:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- added (2024-05-29):
[0001045810-24-000124:note_history:19]
Recently Issued Accounting Pronouncements

- added (2024-05-29):
[0001045810-24-000124:note_history:20]
Recent Accounting Pronouncements Not Yet Adopted

- added (2024-05-29):
[0001045810-24-000124:note_history:21]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard to provide for additional disclosures about significant expenses in operating segments. The standard is effective for our annual reporting starting with fiscal year 2025 and for interim period reporting starting in fiscal year 2026 retrospectively. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- added (2024-05-29):
[0001045810-24-000124:note_history:22]
In December 2023, the FASB issued a new accounting standard which provides for new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- removed (2024-05-29):
[0001045810-23-000227:note_history:23]
Reclassifications

- removed (2024-05-29):
[0001045810-23-000227:note_history:24]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

- removed (2024-05-29):
[0001045810-23-000227:note_history:25]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the estimated effect of this change for the three months ended October 29, 2023 was a benefit of $17 million and $24 million for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $41 million and net income of $36 million after tax, or $0.01 per both basic and diluted share. The estimated effect of this change for the first nine months of fiscal year 2024 was a benefit of $24 million and $83 million 
for cost of revenue and operating expenses, respectively, which resulted in an increase in operating income of $107 million and net income of $91 million after tax, or $0.04 per both basic and diluted share.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-29):
[0001045810-24-000124:note_history:26]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 |  | 0.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 9,710 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,460 |  |  | $ | 8,459 |  |
  (was, 2023-11-21, similarity 0.9059):
[0001045810-23-000227:note_history:26]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (44) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,706 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,457 |  |  | $ | 9,703 |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:27]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes are calendar year.
  (was, 2023-11-21, similarity 0.8148):
[0001045810-23-000227:note_history:27]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

- changed (2024-05-29):
[0001045810-24-000124:note_history:28]
As of April 28, 2024, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2023-11-21, similarity 0.9618):
[0001045810-23-000227:note_history:28]
As of October 29, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2024-05-29):
[0001045810-24-000124:note_history:29]
We have a $575 million commercial paper program to support general corporate purposes. As of April 28, 2024, we had no commercial paper outstanding.
  (was, 2023-11-21, similarity 0.8794):
[0001045810-23-000227:note_history:29]
We have a $575 million commercial paper program to support general corporate purposes. As of October 29, 2023, we had not issued any commercial paper.

- removed (2024-05-29):
[0001045810-23-000227:note_history:30]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:

- removed (2024-05-29):
[0001045810-23-000227:note_history:31]
On June 15, 2023, we repaid the 0.309% Notes Due 2023.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-29):
[0001045810-24-000124:note_history:32]
|  | Apr 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 11,397 |  |  | $ | 3 |  |  | $ | (43) |  |  | $ | 11,357 |  |  | $ | 733 |  |  | $ | 10,624 |  |
| Debt securities issued by the U.S. Treasury | 11,314 |  |  | — |  |  | (62) |  |  | 11,252 |  |  | 886 |  |  | 10,366 |  |
| Money market funds | 5,374 |  |  | — |  |  | — |  |  | 5,374 |  |  | 5,374 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,826 |  |  | — |  |  | (7) |  |  | 2,819 |  |  | 189 |  |  | 2,630 |  |
| Certificates of deposit | 286 |  |  | — |  |  | — |  |  | 286 |  |  | 69 |  |  | 217 |  |
| Foreign government bonds | 14 |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 31,211 |  |  | $ | 3 |  |  | $ | (112) |  |  | $ | 31,102 |  |  | $ | 7,251 |  |  | $ | 23,851 |  |
  (was, 2023-11-21, similarity 0.9912):
[0001045810-23-000227:note_history:32]
|  | October 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,937 |  |  | $ | 1 |  |  | $ | (20) |  |  | $ | 6,918 |  |  | $ | 1,714 |  |  | $ | 5,204 |  |
| Debt securities issued by the U.S. Treasury | 5,075 |  |  | 1 |  |  | (24) |  |  | 5,052 |  |  | — |  |  | 5,052 |  |
| Money market funds | 3,190 |  |  | — |  |  | — |  |  | 3,190 |  |  | 3,190 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,316 |  |  | — |  |  | (5) |  |  | 2,311 |  |  | 100 |  |  | 2,211 |  |
| Certificates of deposit | 418 |  |  | — |  |  | — |  |  | 418 |  |  | 198 |  |  | 220 |  |
| Foreign government bonds | 175 |  |  | — |  |  | — |  |  | 175 |  |  | 100 |  |  | 75 |  |
| Total | $ | 18,111 |  |  | $ | 2 |  |  | $ | (49) |  |  | $ | 18,064 |  |  | $ | 5,302 |  |  | $ | 12,762 |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:33]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |
  (was, 2023-11-21, similarity 0.8799):
[0001045810-23-000227:note_history:33]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:34]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,811 |  |  | $ | 16,800 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 14,400 |  |  | 14,302 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 31,211 |  |  | $ | 31,102 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |
  (was, 2023-11-21, similarity 0.9811):
[0001045810-23-000227:note_history:34]
|  | October 29, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,405 |  |  | $ | 11,388 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 6,706 |  |  | 6,676 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 18,111 |  |  | $ | 18,064 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-29):
[0001045810-24-000124:note_history:35]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to publicly held debt securities are classified as “available-for-sale” debt securities.
  (was, 2023-11-21, similarity 0.9609):
[0001045810-23-000227:note_history:35]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

- changed (2024-05-29):
[0001045810-24-000124:note_history:36]
|  | Apr 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 11,397 |  |  | $ | 3 |  |  | $ | (43) |  |  | $ | 11,357 |  |  | $ | 733 |  |  | $ | 10,624 |  |
| Debt securities issued by the U.S. Treasury | 11,314 |  |  | — |  |  | (62) |  |  | 11,252 |  |  | 886 |  |  | 10,366 |  |
| Money market funds | 5,374 |  |  | — |  |  | — |  |  | 5,374 |  |  | 5,374 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,826 |  |  | — |  |  | (7) |  |  | 2,819 |  |  | 189 |  |  | 2,630 |  |
| Certificates of deposit | 286 |  |  | — |  |  | — |  |  | 286 |  |  | 69 |  |  | 217 |  |
| Foreign government bonds | 14 |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 31,211 |  |  | $ | 3 |  |  | $ | (112) |  |  | $ | 31,102 |  |  | $ | 7,251 |  |  | $ | 23,851 |  |
  (was, 2023-11-21, similarity 0.9912):
[0001045810-23-000227:note_history:36]
|  | October 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,937 |  |  | $ | 1 |  |  | $ | (20) |  |  | $ | 6,918 |  |  | $ | 1,714 |  |  | $ | 5,204 |  |
| Debt securities issued by the U.S. Treasury | 5,075 |  |  | 1 |  |  | (24) |  |  | 5,052 |  |  | — |  |  | 5,052 |  |
| Money market funds | 3,190 |  |  | — |  |  | — |  |  | 3,190 |  |  | 3,190 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,316 |  |  | — |  |  | (5) |  |  | 2,311 |  |  | 100 |  |  | 2,211 |  |
| Certificates of deposit | 418 |  |  | — |  |  | — |  |  | 418 |  |  | 198 |  |  | 220 |  |
| Foreign government bonds | 175 |  |  | — |  |  | — |  |  | 175 |  |  | 100 |  |  | 75 |  |
| Total | $ | 18,111 |  |  | $ | 2 |  |  | $ | (49) |  |  | $ | 18,064 |  |  | $ | 5,302 |  |  | $ | 12,762 |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:37]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |
  (was, 2023-11-21, similarity 0.8799):
[0001045810-23-000227:note_history:37]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:38]
|  | Apr 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 9,720 |  |  | $ | (60) |  |  | $ | 756 |  |  | $ | (2) |  |  | $ | 10,476 |  |  | $ | (62) |  |
| Corporate debt securities | 6,943 |  |  | (42) |  |  | 188 |  |  | (1) |  |  | 7,131 |  |  | (43) |  |
| Debt securities issued by U.S. government agencies | 2,391 |  |  | (7) |  |  | — |  |  | — |  |  | 2,391 |  |  | (7) |  |
| Total | $ | 19,054 |  |  | $ | (109) |  |  | $ | 944 |  |  | $ | (3) |  |  | $ | 19,998 |  |  | $ | (112) |  |
  (was, 2023-11-21, similarity 0.9923):
[0001045810-23-000227:note_history:38]
|  | January 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 2,444 |  |  | $ | (21) |  |  | $ | 1,172 |  |  | $ | (23) |  |  | $ | 3,616 |  |  | $ | (44) |  |
| Corporate debt securities | 1,188 |  |  | (7) |  |  | 696 |  |  | (5) |  |  | 1,884 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,307 |  |  | (2) |  |  | — |  |  | — |  |  | 1,307 |  |  | (2) |  |
| Total | $ | 4,939 |  |  | $ | (30) |  |  | $ | 1,868 |  |  | $ | (28) |  |  | $ | 6,807 |  |  | $ | (58) |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:39]
|  | Jan 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 3,343 |  |  | $ | (5) |  |  | $ | 1,078 |  |  | $ | (5) |  |  | $ | 4,421 |  |  | $ | (10) |  |
| Corporate debt securities | 1,306 |  |  | (3) |  |  | 618 |  |  | (2) |  |  | 1,924 |  |  | (5) |  |
| Debt securities issued by U.S. government agencies | 670 |  |  | (1) |  |  | — |  |  | — |  |  | 670 |  |  | (1) |  |
| Total | $ | 5,319 |  |  | $ | (9) |  |  | $ | 1,696 |  |  | $ | (7) |  |  | $ | 7,015 |  |  | $ | (16) |  |
  (was, 2023-11-21, similarity 0.8282):
[0001045810-23-000227:note_history:39]
|  | October 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Corporate debt securities | $ | 2,773 |  |  | $ | (16) |  |  | $ | 852 |  |  | $ | (4) |  |  | $ | 3,625 |  |  | $ | (20) |  |
| Debt securities issued by the U.S. Treasury | 2,098 |  |  | (12) |  |  | 1,371 |  |  | (12) |  |  | 3,469 |  |  | (24) |  |
| Debt securities issued by U.S. government agencies | 1,447 |  |  | (5) |  |  | — |  |  | — |  |  | 1,447 |  |  | (5) |  |
| Total | $ | 6,318 |  |  | $ | (33) |  |  | $ | 2,223 |  |  | $ | (16) |  |  | $ | 8,541 |  |  | $ | (49) |  |

- changed (2024-05-29):
[0001045810-24-000124:note_history:40]
|  | Apr 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,811 |  |  | $ | 16,800 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 14,400 |  |  | 14,302 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 31,211 |  |  | $ | 31,102 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |
  (was, 2023-11-21, similarity 0.9811):
[0001045810-23-000227:note_history:40]
|  | October 29, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 11,405 |  |  | $ | 11,388 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 6,706 |  |  | 6,676 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 18,111 |  |  | $ | 18,064 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-29):
[0001045810-24-000124:note_history:41]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 |  | 0.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (40) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 9,710 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,460 |  |  | $ | 8,459 |  |
  (was, 2023-11-21, similarity 0.9059):
[0001045810-23-000227:note_history:41]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | — |  | 0.41% |  | $ | — |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 0.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 4.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 7.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (44) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 9,706 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,457 |  |  | $ | 9,703 |  |

- removed (2024-05-29):
[0001045810-23-000227:note_history:42]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-05-29):
[0001045810-24-000124:note_history:43]
Subsequent Events
On May 22, 2024, we announced a ten-for-one forward stock split, or the Stock Split, of our issued common stock to be effected through the filing of an amendment to our Restated Certificate of Incorporation, or the Amendment, with the Secretary of the State of Delaware. The Amendment will result in a proportionate increase in the number of shares of authorized common stock. As a result of the Stock Split, each record holder of common stock as of the close of market on June 6, 2024 will receive nine additional shares of common stock, to be distributed after the close of market on June 7, 2024. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the Stock Split as if it had been effective for all periods presented:

- added (2024-05-29):
[0001045810-24-000124:note_history:44]
|  | Pro Forma (Unaudited) |
|  | Three Months Ended |  | Year Ended |
|  | Apr 28, 2024 |  | Apr 30, 2023 |  | Jan 28, 2024 |  | Jan 29, 2023 |  | Jan 30, 2022 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 14,881 |  |  | $ | 2,043 |  |  | $ | 29,760 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,620 |  |  | 24,700 |  |  | 24,690 |  |  | 24,870 |  |  | 24,960 |  |
| Dilutive impact of outstanding equity awards | 270 |  |  | 200 |  |  | 250 |  |  | 200 |  |  | 390 |  |
| Diluted weighted average shares | 24,890 |  |  | 24,900 |  |  | 24,940 |  |  | 25,070 |  |  | 25,350 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.60 |  |  | $ | 0.08 |  |  | $ | 1.21 |  |  | $ | 0.18 |  |  | $ | 0.39 |  |
| Diluted (2) | $ | 0.60 |  |  | $ | 0.08 |  |  | $ | 1.19 |  |  | $ | 0.17 |  |  | $ | 0.38 |  |

- added (2024-05-29):
[0001045810-24-000124:note_history:45]
(1)       Calculated as net income divided by basic weighted average shares.

- added (2024-05-29):
[0001045810-24-000124:note_history:46]
(2)       Calculated as net income divided by diluted weighted average shares.

- added (2024-05-29):
[0001045810-24-000124:note_history:47]
On May 22, 2024, we also announced an increase in our quarterly cash dividend by 150% from $0.04 per share to $0.10 per share of common stock. The increased dividend is equivalent to $0.01 per share on a post-Stock Split basis and will be paid on June 28, 2024, to all shareholders of record on June 11, 2024.
