# NVDA notes — 0001045810-17-000172


## nvda:BalanceSheetComponentsTextBlock

[0001045810-17-000172:notes:1]
[same as prior period, unchanged from 0001045810-17-000123:notes:1]

[0001045810-17-000172:notes:2]
[same as prior period, unchanged from 0001045810-17-000123:notes:2]

[0001045810-17-000172:notes:3]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
| Inventories: | (In millions) |
| Raw materials | $ | 219 |  |  | $ | 252 |  |
| Work in-process | 235 |  |  | 176 |  |
| Finished goods | 403 |  |  | 366 |  |
| Total inventories | $ | 857 |  |  | $ | 794 |  |

[0001045810-17-000172:notes:4]
As of October 29, 2017, we had outstanding inventory purchase obligations totaling $1.16 billion.

[0001045810-17-000172:notes:5]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer related liabilities (1) | $ | 177 |  |  | $ | 197 |  |
| Accrued payroll and related expenses | 153 |  |  | 137 |  |
| Deferred revenue (2) | 65 |  |  | 85 |  |
| Warranty accrual (3) | 18 |  |  | 8 |  |
| Accrued royalties | 16 |  |  | 7 |  |
| Professional service fees | 13 |  |  | 13 |  |
| Taxes payable | 11 |  |  | 4 |  |
| Accrued restructuring and other charges (4) | 8 |  |  | 13 |  |
| Coupon interest on debt obligations | 7 |  |  | 21 |  |
| Leases payable | 5 |  |  | 4 |  |
| Contributions payable | 4 |  |  | 4 |  |
| Other | 16 |  |  | 14 |  |
| Total accrued and other current liabilities | $ | 493 |  |  | $ | 507 |  |

[0001045810-17-000172:notes:6]
[same as prior period, unchanged from 0001045810-17-000123:notes:6]

[0001045810-17-000172:notes:7]
[same as prior period, unchanged from 0001045810-17-000123:notes:7]

[0001045810-17-000172:notes:8]
[same as prior period, unchanged from 0001045810-17-000123:notes:8]

[0001045810-17-000172:notes:9]
[same as prior period, unchanged from 0001045810-17-000123:notes:9]

[0001045810-17-000172:notes:10]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 295 |  |  | $ | 141 |  |
| Income tax payable | 116 |  |  | 96 |  |
| Contributions payable | 12 |  |  | 9 |  |
| Employee benefits liability | 11 |  |  | 10 |  |
| Deferred revenue | 10 |  |  | 4 |  |
| Deferred rent | 8 |  |  | 6 |  |
| Licenses payable | 7 |  |  | 1 |  |
| Other | 5 |  |  | 4 |  |
| Total other long-term liabilities | $ | 464 |  |  | $ | 271 |  |


## nvda:ScheduleofAccountReceivablefromMajorCustomersTableTextBlock

[0001045810-17-000172:notes:11]
|  |  | October 29, |  | January 29, |
|  |  | 2017 |  | 2017 |
| Accounts Receivable: |  |  |  |  |
| Customer A |  | 17 | % |  | 19 | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-17-000172:notes:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,561 |  |  | $ | 1,244 |  |  | $ | 3,774 |  |  | $ | 2,712 |  |
| Professional Visualization | 239 |  |  | 207 |  |  | 679 |  |  | 610 |  |
| Datacenter | 501 |  |  | 240 |  |  | 1,326 |  |  | 534 |  |
| Automotive | 144 |  |  | 127 |  |  | 426 |  |  | 359 |  |
| OEM & IP | 191 |  |  | 186 |  |  | 598 |  |  | 522 |  |
| Total revenue | $ | 2,636 |  |  | $ | 2,004 |  |  | $ | 6,803 |  |  | $ | 4,737 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-17-000172:notes:13]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 1,153 |  |  | $ | 627 |  |
| Estimated weighted average remaining amortization period | (In years) |
| Stock options | — |  |  | 0.5 |  |
| RSUs, PSUs, and market-based PSUs | 2.5 |  |  | 2.6 |  |
| ESPP | 0.7 |  |  | 0.6 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-17-000172:notes:14]
|  | October 29, 2017 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 1,515 |  |  | $ | — |  |  | $ | (5 | ) |  | $ | 1,510 |  |  | $ | — |  |  | $ | 1,510 |  |
| Debt securities of United States government agencies | 907 |  |  | — |  |  | (5 | ) |  | 902 |  |  | — |  |  | 902 |  |
| Debt securities issued by the United States Treasury | 638 |  |  | — |  |  | (3 | ) |  | 635 |  |  | — |  |  | 635 |  |
| Asset-backed securities | 289 |  |  | — |  |  | (1 | ) |  | 288 |  |  | — |  |  | 288 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 140 |  |  | 2 |  |  | (1 | ) |  | 141 |  |  | — |  |  | 141 |  |
| Foreign government bonds | 42 |  |  | — |  |  | — |  |  | 42 |  |  | — |  |  | 42 |  |
| Money market funds | 2,609 |  |  | — |  |  | — |  |  | 2,609 |  |  | 2,609 |  |  | — |  |
| Total | $ | 6,140 |  |  | $ | 2 |  |  | $ | (15 | ) |  | $ | 6,127 |  |  | $ | 2,609 |  |  | $ | 3,518 |  |

[0001045810-17-000172:notes:15]
[same as prior period, unchanged from 0001045810-17-000123:notes:15]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-17-000172:notes:16]
[same as prior period, unchanged from 0001045810-17-000123:notes:16]

[0001045810-17-000172:notes:17]
[same as prior period, unchanged from 0001045810-17-000123:notes:17]

[0001045810-17-000172:notes:18]
[same as prior period, unchanged from 0001045810-17-000123:notes:18]

[0001045810-17-000172:notes:19]
[same as prior period, unchanged from 0001045810-17-000123:notes:19]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-17-000172:notes:20]
Commitments and Contingencies

[0001045810-17-000172:notes:21]
Operating Lease Financing Arrangement

[0001045810-17-000172:notes:22]
In November 2017, subsequent to the end of the third quarter of fiscal year 2018, we exercised the option to terminate the off-balance sheet, build-to-suit operating lease financing arrangement related to our new Santa Clara campus building. In the fourth quarter of fiscal year 2018, we expect to refinance and purchase the property for approximately $350 million.

[0001045810-17-000172:notes:23]
Litigation

[0001045810-17-000172:notes:24]
Polaris Innovations Limited

[0001045810-17-000172:notes:25]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-17-000172:notes:26]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California. The California Court has not set a trial date.

[0001045810-17-000172:notes:27]
On December 7, 2016, NVIDIA filed a petition for inter partes review with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. On May 30, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 6,532,505, another patent asserted by Polaris. On June 22, 2017, the USPTO instituted inter partes review of U.S Patent No. 7,886,122. On June 23, 2017, the USPTO denied institution of inter partes review of U.S. Patent No. 7,124,325. On July 25, 2017, NVIDIA filed inter partes requests with the USPTO challenging the validity of U.S. Patent No. 8,207,976, another patent asserted by Polaris. Also on July 25, 2017, NVIDIA filed inter partes requests with the USPTO for U.S. Patent No. 8,161,344 challenging the validity of further claims and an additional inter partes request for U.S. Patent No. 7,124,325. All of the patents that Polaris has asserted in the U.S. litigation are now subject to requests for inter partes review, with institution decisions forthcoming.

[0001045810-17-000172:notes:28]
On May 9, 2017, NVIDIA filed a Motion to Stay the California action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  On June 15, 2017, the Motion to Stay was granted. The action has now been stayed until December 14, 2017 pending the institution of the inter partes review of these patents.

[0001045810-17-000172:notes:29]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. An oral hearing has been scheduled for February 21, 2019.

[0001045810-17-000172:notes:30]
On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. On June 12, 2017, NVIDIA was notified that the nullity actions against EP1428225 and DE 1020066043668 were served on Polaris and that Polaris has filed a formal response opposing each nullity complaint. On July 14, 2017, the German Patent Court acknowledged receipt of a nullity action filed by NVIDIA challenging the validity of DE 10223167. On September 13, 2017, NVIDIA was notified that the nullity action against DE10223167 was served on Polaris. Polaris has not yet responded to this action.

[0001045810-17-000172:notes:31]
Accounting for Loss Contingencies

[0001045810-17-000172:notes:32]
While there can be no assurance of favorable outcomes, we believe the claims made by the other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 29, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-17-000172:notes:33]
[same as prior period, unchanged from 0001045810-17-000123:notes:37]

[0001045810-17-000172:notes:34]
[same as prior period, unchanged from 0001045810-17-000123:notes:38]


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-17-000172:notes:35]
The following table presents the carrying value of the Convertible Notes:

[0001045810-17-000172:notes:36]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 24 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (1 | ) |  | (31 | ) |
| Net carrying amount | $ | 23 |  |  | $ | 796 |  |

[0001045810-17-000172:notes:37]
(1) As of October 29, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.1 years.

[0001045810-17-000172:notes:38]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

[0001045810-17-000172:notes:39]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 10 |  |
| Amortization of debt discount |  | — |  |  | 5 |  |  | 2 |  |  | 20 |  |
| Total interest expense related to Convertible Notes |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 30 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-17-000172:notes:40]
Debt

[0001045810-17-000172:notes:41]
Convertible Debt

[0001045810-17-000172:notes:42]
1.00% Convertible Senior Notes Due 2018

[0001045810-17-000172:notes:43]
During the third quarter of fiscal year 2018, we paid cash to settle an aggregate of $62 million in principal amount of the Convertible Notes and had $24 million in principal amount outstanding as of October 29, 2017. We also issued 3 million shares of our common stock for the excess conversion value and recognized a loss of $1 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $201.86 on the last trading day of the third quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of October 29, 2017 exceeded their principal amount by approximately $217 million. As of October 29, 2017, the conversion rate was 49.8977 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0410 per share of common stock).

[0001045810-17-000172:notes:44]
Through the third quarter of fiscal year 2018, we settled an aggregate of $1.48 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $8 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

[0001045810-17-000172:notes:45]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances, determined on a quarterly basis.  All outstanding Convertible Notes are convertible at the holders’ option through January 28, 2018.

[0001045810-17-000172:notes:46]
We separately accounted for the liability and equity components of the Convertible Notes at issuance, since our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

[0001045810-17-000172:notes:47]
As of October 29, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

[0001045810-17-000172:notes:48]
Note Hedges and Warrants

[0001045810-17-000172:notes:49]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. During the third quarter of fiscal year 2018, we had received 3 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $62 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $8 million in principal amount that is expected to settle during the fourth quarter of fiscal year 2018.

[0001045810-17-000172:notes:50]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction. All outstanding Warrants were terminated by the second quarter of fiscal year 2018.

[0001045810-17-000172:notes:51]
Long-Term Debt

[0001045810-17-000172:notes:52]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-17-000172:notes:53]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-17-000172:notes:54]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-17-000172:notes:55]
The carrying value of our long-term debt and the associated interest rates were as follows:

[0001045810-17-000172:notes:56]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (15 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,985 |  |  | $ | 1,983 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-17-000172:notes:57]
[same as prior period, unchanged from 0001045810-17-000123:notes:62]

[0001045810-17-000172:notes:58]
In fiscal year 2016, we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new Santa Clara campus building. In November 2017, subsequent to the end of the third quarter of fiscal year 2018, we exercised the option to terminate the operating lease financing arrangement and purchase the property, which we expect to occur during the fourth quarter of fiscal year 2018. As a result, the interest rate swap would also terminate, which we expect to result in an immaterial loss upon termination.

[0001045810-17-000172:notes:59]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income (loss) and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of October 29, 2017 and January 29, 2017.

[0001045810-17-000172:notes:60]
[same as prior period, unchanged from 0001045810-17-000123:notes:65]

[0001045810-17-000172:notes:61]
The table below presents the notional value of our foreign currency forward contracts as of October 29, 2017 and January 29, 2017:

[0001045810-17-000172:notes:62]
|  | October 29, 2017 |  | January 29, 2017 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 93 |  |  | $ | 67 |  |
| Not designated for hedge accounting | $ | 74 |  |  | $ | 32 |  |

[0001045810-17-000172:notes:63]
[same as prior period, unchanged from 0001045810-17-000123:notes:68]

[0001045810-17-000172:notes:64]
As of October 29, 2017, the maturities of the designated foreign currency forward contracts were three months or less. We expect to realize all gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months.

[0001045810-17-000172:notes:65]
We formally assess, both at inception and on an ongoing basis, whether derivative financial instruments designated for hedge accounting treatment are highly effective. For the third quarter and first nine months of fiscal years 2018 and 2017, all derivative financial instruments designated for hedge accounting treatment were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-17-000172:notes:66]
The net change in unrealized gains (losses) on derivative financial instruments designated for hedge accounting treatment was not significant for the third quarter and first nine months of fiscal years 2018 and 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-17-000172:notes:67]
[same as prior period, unchanged from 0001045810-17-000123:notes:72]

[0001045810-17-000172:notes:68]
[same as prior period, unchanged from 0001045810-17-000123:notes:73]

[0001045810-17-000172:notes:69]
[same as prior period, unchanged from 0001045810-17-000123:notes:74]

[0001045810-17-000172:notes:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2017 |  | October 30, 2016 |  | October 29, 2017 |  | October 30, 2016 |
|  | (In millions) |
| Cost of revenue | $ | 6 |  |  | $ | 2 |  |  | $ | 14 |  |  | $ | 10 |  |
| Research and development | 61 |  |  | 36 |  |  | 146 |  |  | 95 |  |
| Sales, general and administrative | 40 |  |  | 27 |  |  | 105 |  |  | 71 |  |
| Total | $ | 107 |  |  | $ | 65 |  |  | $ | 265 |  |  | $ | 176 |  |

[0001045810-17-000172:notes:71]
[same as prior period, unchanged from 0001045810-17-000123:notes:76]

[0001045810-17-000172:notes:72]
[same as prior period, unchanged from 0001045810-17-000123:notes:77]

[0001045810-17-000172:notes:73]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted Average Exercise Price Per Share |
|  | (In millions, except per share data) |
| Balances, January 29, 2017 | 27 |  |  | $ | 32.84 |  |  | 7 |  |  | $ | 14.47 |  |
| Granted (1) (2) | 6 |  |  | $ | 142.34 |  |  | — |  |  | $ | — |  |
| Exercised | — |  |  | $ | — |  |  | (2 | ) |  | $ | 14.46 |  |
| Vested | (10 | ) |  | $ | 26.88 |  |  | — |  |  | $ | — |  |
| Balances, October 29, 2017 | 23 |  |  | $ | 64.42 |  |  | 5 |  |  | $ | 14.47 |  |

[0001045810-17-000172:notes:74]
[same as prior period, unchanged from 0001045810-17-000123:notes:79]

[0001045810-17-000172:notes:75]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 0.1 million shares. |

[0001045810-17-000172:notes:76]
Of the total fair value of equity awards granted during the third quarter and first nine months of fiscal year 2018, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $105 million and $144 million, respectively. Of the total fair value of equity awards granted during the third quarter and first nine months of fiscal year 2017, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $72 million and $89 million, respectively.

[0001045810-17-000172:notes:77]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of October 29, 2017 and January 29, 2017:


## us-gaap:EarningsPerShareTextBlock

[0001045810-17-000172:notes:78]
[same as prior period, unchanged from 0001045810-17-000123:notes:83]

[0001045810-17-000172:notes:79]
[same as prior period, unchanged from 0001045810-17-000123:notes:84]

[0001045810-17-000172:notes:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 838 |  |  | $ | 542 |  |  | $ | 1,928 |  |  | $ | 1,012 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 603 |  |  | 538 |  |  | 597 |  |  | 536 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards | 23 |  |  | 27 |  |  | 24 |  |  | 25 |  |
| 1.00% Convertible Senior Notes | 2 |  |  | 45 |  |  | 7 |  |  | 42 |  |
| Warrants issued with the 1.00% Convertible Senior Notes | — |  |  | 43 |  |  | 5 |  |  | 33 |  |
| Diluted weighted average shares | 628 |  |  | 653 |  |  | 633 |  |  | 636 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.39 |  |  | $ | 1.01 |  |  | $ | 3.23 |  |  | $ | 1.89 |  |
| Diluted (2) | $ | 1.33 |  |  | $ | 0.83 |  |  | $ | 3.05 |  |  | $ | 1.59 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 3 |  |  | 7 |  |  | 4 |  |  | 9 |  |

[0001045810-17-000172:notes:81]
[same as prior period, unchanged from 0001045810-17-000123:notes:86]

[0001045810-17-000172:notes:82]
[same as prior period, unchanged from 0001045810-17-000123:notes:87]

[0001045810-17-000172:notes:83]
The 1.00% Convertible Senior Notes, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0410 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share.

[0001045810-17-000172:notes:84]
For the third quarter and first nine months of fiscal year 2018, our average stock price was $176.20 and $142.18, respectively, which exceeded the adjusted conversion price, causing the Convertible Notes to have a dilutive impact for these periods. Our average stock price for the first nine months of fiscal year 2018 also exceeded the adjusted strike price, causing the Warrants to have a dilutive impact. All outstanding Warrants were terminated by the second quarter of fiscal year 2018.

[0001045810-17-000172:notes:85]
[same as prior period, unchanged from 0001045810-17-000123:notes:90]

[0001045810-17-000172:notes:86]
[same as prior period, unchanged from 0001045810-17-000123:notes:92]


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-17-000172:notes:87]
|  |  | Fair Value at |
|  | Pricing Category |  | October 29, 2017 |  | January 29, 2017 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 1,510 |  |  | $ | 2,388 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 902 |  |  | $ | 1,188 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 635 |  |  | $ | 850 |  |
| Asset-backed securities | Level 2 |  | $ | 288 |  |  | $ | 489 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 141 |  |  | $ | 162 |  |
| Foreign government bonds | Level 2 |  | $ | 42 |  |  | $ | 70 |  |
| Money market funds | Level 1 |  | $ | 2,609 |  |  | $ | 321 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 245 |  |  | $ | 4,474 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 996 |  |  | $ | 975 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 1,007 |  |  | $ | 961 |  |
| Interest rate swap (2) | Level 2 |  | $ | 3 |  |  | $ | 2 |  |

[0001045810-17-000172:notes:88]
| (1) | The remaining 1.00% Convertible Senior Notes, 2.20% Notes Due 2021, and 3.20% Notes Due 2026 are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. See Note 11 of these Notes to Condensed Consolidated Financial Statements for additional information. |

[0001045810-17-000172:notes:89]
[same as prior period, unchanged from 0001045810-17-000123:notes:95]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-17-000172:notes:90]
[same as prior period, unchanged from 0001045810-17-000123:notes:96]

[0001045810-17-000172:notes:91]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review the fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 assets for the third quarter of fiscal year 2018. We did not have any investments classified as Level 3 as of October 29, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-17-000172:notes:92]
[same as prior period, unchanged from 0001045810-17-000123:notes:98]

[0001045810-17-000172:notes:93]
We recognized income tax expense of $58 million and $189 million for the third quarter and first nine months of fiscal year 2018, respectively, and $79 million and $168 million for the third quarter and first nine months of fiscal year 2017, respectively. Income tax expense as a percentage of income before income tax for the third quarter and first nine months of fiscal year 2018 was 6.5% and 8.9%, respectively, and 12.8% and 14.2% for the third quarter and first nine months of fiscal year 2017, respectively.

[0001045810-17-000172:notes:94]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2018 as compared to the same periods in the prior fiscal year primarily reflects the recognition of greater tax benefits related to stock-based compensation and a proportional decrease in the amount of earnings subject to United States tax.

[0001045810-17-000172:notes:95]
Our effective tax rates for the first nine months of fiscal years 2018 and 2017 of 8.9% and 14.2%, respectively, were lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-17-000172:notes:96]
For the first nine months of fiscal year 2018, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 29, 2017.

[0001045810-17-000172:notes:97]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 29, 2017, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-17-000172:notes:98]
[same as prior period, unchanged from 0001045810-17-000123:notes:104]

[0001045810-17-000172:notes:99]
[same as prior period, unchanged from 0001045810-17-000123:notes:105]

[0001045810-17-000172:notes:100]
|  | October 29, 2017 |  | January 29, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (178 | ) |  | $ | 15 |  |  | $ | 193 |  |  | $ | (167 | ) |  | $ | 26 |  |
| Patents and licensed technology | 469 |  |  | (421 | ) |  | 48 |  |  | 468 |  |  | (390 | ) |  | 78 |  |
| Total intangible assets | $ | 662 |  |  | $ | (599 | ) |  | $ | 63 |  |  | $ | 661 |  |  | $ | (557 | ) |  | $ | 104 |  |

[0001045810-17-000172:notes:101]
Amortization expense associated with intangible assets was $13 million and $42 million for the third quarter and first nine months of fiscal year 2018, respectively, and $18 million and $53 million for the third quarter and first nine months of fiscal year 2017, respectively. Future amortization expense related to the net carrying amount of intangible assets as of October 29, 2017 is estimated to be $12 million for the remainder of fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $8 million in fiscal year 2021, and $1 million in fiscal year 2022 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-17-000172:notes:102]
|  | October 29, 2017 |  | January 29, 2017 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 4,074 |  |  | $ | 4,072 |  |  | $ | 2,209 |  |  | $ | 2,209 |  |
| Due in 1 - 5 years | 2,024 |  |  | 2,013 |  |  | 3,210 |  |  | 3,194 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 42 |  |  | 42 |  |  | 65 |  |  | 65 |  |
| Total | $ | 6,140 |  |  | $ | 6,127 |  |  | $ | 5,484 |  |  | $ | 5,468 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-17-000172:notes:103]
[same as prior period, unchanged from 0001045810-17-000123:notes:109]

[0001045810-17-000172:notes:104]
[same as prior period, unchanged from 0001045810-17-000123:notes:110]

[0001045810-17-000172:notes:105]
We performed an impairment review of our investment portfolio as of October 29, 2017. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of October 29, 2017.

[0001045810-17-000172:notes:106]
The following is a summary of cash equivalents and marketable securities as of October 29, 2017 and January 29, 2017:

[0001045810-17-000172:notes:107]
The following table provides the breakdown of unrealized losses as of October 29, 2017, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-17-000172:notes:108]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 867 |  |  | $ | (3 | ) |  | $ | 407 |  |  | $ | (2 | ) |  | $ | 1,274 |  |  | $ | (5 | ) |
| Debt securities issued by United States government agencies | 666 |  |  | (3 | ) |  | 236 |  |  | (2 | ) |  | 902 |  |  | (5 | ) |
| Debt securities issued by the United States Treasury | 509 |  |  | (2 | ) |  | 126 |  |  | (1 | ) |  | 635 |  |  | (3 | ) |
| Asset-backed securities | 233 |  |  | (1 | ) |  | 44 |  |  | — |  |  | 277 |  |  | (1 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 26 |  |  | — |  |  | 36 |  |  | (1 | ) |  | 62 |  |  | (1 | ) |
|  | $ | 2,301 |  |  | $ | (9 | ) |  | $ | 849 |  |  | $ | (6 | ) |  | $ | 3,150 |  |  | $ | (15 | ) |

[0001045810-17-000172:notes:109]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities as of October 29, 2017 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity. Net realized gains and losses were not significant for the third quarter and first nine months of fiscal years 2018 and 2017.

[0001045810-17-000172:notes:110]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of October 29, 2017 and January 29, 2017 and are shown below by contractual maturity:


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-17-000172:notes:111]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000172:notes:112]
Recently Adopted Accounting Pronouncement

[0001045810-17-000172:notes:113]
In October 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which requires the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We elected to early adopt this new guidance in the first quarter of fiscal year 2018, which required us to reflect any adjustments as of January 30, 2017. Upon adoption of this guidance, we recorded a cumulative-effect adjustment as of the first day of fiscal year 2018 to decrease retained earnings by $28 million, with a corresponding decrease to prepaid taxes that had not been previously recognized in income tax expense.

[0001045810-17-000172:notes:114]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-17-000172:notes:115]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. Most prominent among the amendments is the requirement for changes in the fair value of our equity investments, with certain exceptions, to be recognized through net income rather than other comprehensive income. The update will be effective for us beginning in our first quarter of fiscal year 2019. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.

[0001045810-17-000172:notes:116]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

[0001045810-17-000172:notes:117]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. Given the scope of work required to implement the recognition and disclosure requirements under the new guidance, we have made progress in and continue to assess changes in policies, processes, systems and controls necessary to meet the additional requirements of the guidance. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-17-000172:notes:118]
[same as prior period, unchanged from 0001045810-17-000123:notes:123]

[0001045810-17-000172:notes:119]
[same as prior period, unchanged from 0001045810-17-000123:notes:124]

[0001045810-17-000172:notes:120]
[same as prior period, unchanged from 0001045810-17-000123:notes:125]

[0001045810-17-000172:notes:121]
[same as prior period, unchanged from 0001045810-17-000123:notes:126]

[0001045810-17-000172:notes:122]
The estimated product returns and estimated product warranty liabilities as of October 29, 2017 and January 29, 2017 were as follows:

[0001045810-17-000172:notes:123]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 8 |  |  | $ | 11 |  |
| Additions | 13 |  |  | 2 |  |
| Deductions | (3 | ) |  | (5 | ) |
| Balance at end of period | $ | 18 |  |  | $ | 8 |  |

[0001045810-17-000172:notes:124]
[same as prior period, unchanged from 0001045810-17-000123:notes:129]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-17-000172:notes:125]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2017 |  | October 30, 2016 |  | October 29, 2017 |  | October 30, 2016 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | 66 |  |  | $ | 43 |  |  | $ | 198 |  |
| Stock-based compensation expense | (107 | ) |  | (65 | ) |  | (265 | ) |  | (176 | ) |
| Unallocated cost of revenue and operating expenses | (61 | ) |  | (53 | ) |  | (176 | ) |  | (156 | ) |
| Acquisition-related costs | (3 | ) |  | (4 | ) |  | (11 | ) |  | (12 | ) |
| Restructuring and other charges | — |  |  | — |  |  | — |  |  | (3 | ) |
| Contributions | — |  |  | — |  |  | (2 | ) |  | (4 | ) |
| Legal settlement costs | — |  |  | — |  |  | — |  |  | (16 | ) |
| Total | $ | (171 | ) |  | $ | (56 | ) |  | $ | (411 | ) |  | $ | (169 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-17-000172:notes:126]
[same as prior period, unchanged from 0001045810-17-000123:notes:131]

[0001045810-17-000172:notes:127]
In fiscal year 2016, we began the wind-down of our Icera operations. No restructuring charges were recorded during the third quarter and first nine months of fiscal year 2018.

[0001045810-17-000172:notes:128]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Condensed Consolidated Balance Sheets as of October 29, 2017 and January 29, 2017:

[0001045810-17-000172:notes:129]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 13 |  |  | $ | 23 |  |
| Restructuring and other charges | — |  |  | 3 |  |
| Cash payments | (5 | ) |  | (13 | ) |
| Balance at end of period | $ | 8 |  |  | $ | 13 |  |

[0001045810-17-000172:notes:130]
The majority of the remaining balance of $8 million as of October 29, 2017 is expected to be paid during the next twelve months.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-17-000172:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 864 |  |  | $ | 747 |  |  | $ | 2,140 |  |  | $ | 1,696 |  |
| Other Asia Pacific | 612 |  |  | 309 |  |  | 1,409 |  |  | 660 |  |
| China | 515 |  |  | 341 |  |  | 1,325 |  |  | 845 |  |
| United States | 263 |  |  | 282 |  |  | 894 |  |  | 682 |  |
| Other Americas | 187 |  |  | 154 |  |  | 480 |  |  | 360 |  |
| Europe | 195 |  |  | 171 |  |  | 555 |  |  | 494 |  |
| Total revenue | $ | 2,636 |  |  | $ | 2,004 |  |  | $ | 6,803 |  |  | $ | 4,737 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-17-000172:notes:132]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 29, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 2,217 |  |  | $ | 419 |  |  | $ | — |  |  | $ | 2,636 |  |
| Depreciation and amortization expense | $ | 32 |  |  | $ | 9 |  |  | $ | 9 |  |  | $ | 50 |  |
| Operating income (loss) | $ | 978 |  |  | $ | 88 |  |  | $ | (171 | ) |  | $ | 895 |  |
| Three Months Ended October 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,697 |  |  | $ | 241 |  |  | $ | 66 |  |  | $ | 2,004 |  |
| Depreciation and amortization expense | $ | 30 |  |  | $ | 8 |  |  | $ | 10 |  |  | $ | 48 |  |
| Operating income (loss) | $ | 678 |  |  | $ | 17 |  |  | $ | (56 | ) |  | $ | 639 |  |
| Nine Months Ended October 29, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 5,676 |  |  | $ | 1,084 |  |  | $ | 43 |  |  | $ | 6,803 |  |
| Depreciation and amortization expense | $ | 88 |  |  | $ | 27 |  |  | $ | 30 |  |  | $ | 145 |  |
| Operating income (loss) | $ | 2,342 |  |  | $ | 206 |  |  | $ | (411 | ) |  | $ | 2,137 |  |
| Nine Months Ended October 30, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 3,972 |  |  | $ | 567 |  |  | $ | 198 |  |  | $ | 4,737 |  |
| Depreciation and amortization expense | $ | 87 |  |  | $ | 22 |  |  | $ | 31 |  |  | $ | 140 |  |
| Operating income (loss) | $ | 1,405 |  |  | $ | (35 | ) |  | $ | (169 | ) |  | $ | 1,201 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-17-000172:notes:133]
[same as prior period, unchanged from 0001045810-17-000123:notes:138]

[0001045810-17-000172:notes:134]
[same as prior period, unchanged from 0001045810-17-000123:notes:139]

[0001045810-17-000172:notes:135]
[same as prior period, unchanged from 0001045810-17-000123:notes:140]

[0001045810-17-000172:notes:136]
[same as prior period, unchanged from 0001045810-17-000123:notes:141]

[0001045810-17-000172:notes:137]
[same as prior period, unchanged from 0001045810-17-000123:notes:142]

[0001045810-17-000172:notes:138]
[same as prior period, unchanged from 0001045810-17-000123:notes:143]

[0001045810-17-000172:notes:139]
[same as prior period, unchanged from 0001045810-17-000123:notes:144]

[0001045810-17-000172:notes:140]
[same as prior period, unchanged from 0001045810-17-000123:notes:145]

[0001045810-17-000172:notes:141]
[same as prior period, unchanged from 0001045810-17-000123:notes:146]

[0001045810-17-000172:notes:142]
[same as prior period, unchanged from 0001045810-17-000123:notes:147]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-17-000172:notes:143]
[same as prior period, unchanged from 0001045810-17-000123:notes:148]

[0001045810-17-000172:notes:144]
[same as prior period, unchanged from 0001045810-17-000123:notes:149]

[0001045810-17-000172:notes:145]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The third quarter of fiscal years 2018 and 2017 were both 13-week quarters.

[0001045810-17-000172:notes:146]
[same as prior period, unchanged from 0001045810-17-000123:notes:151]

[0001045810-17-000172:notes:147]
[same as prior period, unchanged from 0001045810-17-000123:notes:152]

[0001045810-17-000172:notes:148]
[same as prior period, unchanged from 0001045810-17-000123:notes:153]

[0001045810-17-000172:notes:149]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-17-000172:notes:150]
[same as prior period, unchanged from 0001045810-17-000123:notes:155]

[0001045810-17-000172:notes:151]
[same as prior period, unchanged from 0001045810-17-000123:notes:156]

[0001045810-17-000172:notes:152]
[same as prior period, unchanged from 0001045810-17-000123:notes:157]

[0001045810-17-000172:notes:153]
During the third quarter and first nine months of fiscal year 2018, we repurchased a total of 1 million shares and 6 million shares, respectively, for $151 million and $909 million, respectively. During the third quarter and first nine months of fiscal year 2018, we also made cash dividend payments to our shareholders of $84 million and $250 million, respectively.

[0001045810-17-000172:notes:154]
Through October 29, 2017, we have repurchased an aggregate of 251 million shares under our share repurchase program for a total cost of $5.50 billion since the inception of the program. All shares delivered from these repurchases have been placed into treasury stock. As of October 29, 2017, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.82 billion through December 2020.

[0001045810-17-000172:notes:155]
In November 2017, we declared an increase in our quarterly cash dividend to $0.15 per share from $0.14 per share, to be paid with our next quarterly cash dividend on December 15, 2017, to all shareholders of record on November 24, 2017.

[0001045810-17-000172:notes:156]
[same as prior period, unchanged from 0001045810-17-000123:notes:160]

[0001045810-17-000172:notes:157]
As of October 29, 2017 and January 29, 2017, there were no shares of preferred stock outstanding.

[0001045810-17-000172:notes:158]
[same as prior period, unchanged from 0001045810-17-000123:notes:162]

[0001045810-17-000172:notes:159]
[same as prior period, unchanged from 0001045810-17-000123:notes:163]
