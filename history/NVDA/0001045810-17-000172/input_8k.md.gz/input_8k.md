# NVDA 8-K — 0001045810-17-000164 filed 2017-11-09

## item codes, every 8-K on or before 2017-11-21

- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2017-11-21

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-17-000164:8k_2_02:1]
EX-99.1
2
q3fy18pr.htm
Q3FY18 PRESS RELEASE

[0001045810-17-000164:8k_2_02:2]
Exhibit

[0001045810-17-000164:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-17-000164:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2018

[0001045810-17-000164:8k_2_02:5]
| • | Record revenue of $2.64 billion, up 32 percent from a year ago |

[0001045810-17-000164:8k_2_02:6]
| • | Record GAAP EPS of $1.33, up 60 percent from a year ago |

[0001045810-17-000164:8k_2_02:7]
| • | Growth across all platforms |

[0001045810-17-000164:8k_2_02:8]
| • | Quarterly cash dividend raised 7 percent to $0.15 per share. Company intends to return $1.25 billion to shareholders in fiscal 2019 |

[0001045810-17-000164:8k_2_02:9]
SANTA CLARA, Calif.-November 9, 2017-NVIDIA (NASDAQ: NVDA) today reported record revenue for the third quarter ended October 29, 2017, of $2.64 billion, up 32 percent from $2.00 billion a year earlier, and up 18 percent from $2.23 billion in the previous quarter, with growth across all its platforms.

[0001045810-17-000164:8k_2_02:10]
GAAP earnings per diluted share for the quarter were a record $1.33, up 60 percent from $0.83 a year ago and up 45 percent from $0.92 in the previous quarter. Non-GAAP earnings per diluted share were $1.33, also a record, up 41 percent from $0.94 a year earlier and up 32 percent from $1.01 in the previous quarter.

[0001045810-17-000164:8k_2_02:11]
“We had a great quarter across all of our growth drivers,” said Jensen Huang, founder and chief executive officer of NVIDIA. “Industries across the world are accelerating their adoption of AI.

[0001045810-17-000164:8k_2_02:12]
“Our Volta GPU has been embraced by every major internet and cloud service provider and computer maker. Our new TensorRT inference acceleration platform opens us to growth in hyperscale datacenters. GeForce and Nintendo Switch are tapped into the strongest growth dynamics of gaming. And our new DRIVE PX Pegasus for robotaxis has been adopted by companies around the world. We are well positioned for continued growth,” he said.

[0001045810-17-000164:8k_2_02:13]
Capital Return

[0001045810-17-000164:8k_2_02:14]
During the first nine months of fiscal 2018, NVIDIA returned to shareholders $909 million in share repurchases and $250 million in cash dividends. As a result, the company returned an aggregate of $1.16 billion to shareholders in the first nine months of the fiscal year. The company intends to return $1.25 billion to shareholders in fiscal 2018.

[0001045810-17-000164:8k_2_02:15]
For fiscal 2019, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. The company announced a 7 percent increase in its quarterly cash dividend to $0.15 per share from $0.14 per share, to be paid with its next quarterly cash dividend on December 15, 2017, to all shareholders of record on November 24, 2017.

[0001045810-17-000164:8k_2_02:16]
Q3 FY2018 Summary

[0001045810-17-000164:8k_2_02:17]
| GAAP |
| ($ in millions except earnings per share) | Q3 FY18 | Q2 FY18 | Q3 FY17 | Q/Q | Y/Y |
| Revenue | $2,636 | $2,230 | $2,004 | Up 18% | Up 32% |
| Gross margin | 59.5% | 58.4% | 59.0% | Up 110 bps | Up 50 bps |
| Operating expenses | $674 | $614 | $544 | Up 10% | Up 24% |
| Operating income | $895 | $688 | $639 | Up 30% | Up 40% |
| Net income | $838 | $583 | $542 | Up 44% | Up 55% |
| Diluted earnings per share | $1.33 | $0.92 | $0.83 | Up 45% | Up 60% |

[0001045810-17-000164:8k_2_02:18]
| Non-GAAP |
| ($ in millions except earnings per share) | Q3 FY18 | Q2 FY18 | Q3 FY17 | Q/Q | Y/Y |
| Revenue | $2,636 | $2,230 | $2,004 | Up 18% | Up 32% |
| Gross margin | 59.7% | 58.6% | 59.2% | Up 110 bps | Up 50 bps |
| Operating expenses | $570 | $533 | $478 | Up 7% | Up 19% |
| Operating income | $1,005 | $773 | $708 | Up 30% | Up 42% |
| Net income | $833 | $638 | $570 | Up 31% | Up 46% |
| Diluted earnings per share | $1.33 | $1.01 | $0.94 | Up 32% | Up 41% |

[0001045810-17-000164:8k_2_02:19]
NVIDIA’s outlook for the fourth quarter of fiscal 2018 is as follows:

[0001045810-17-000164:8k_2_02:20]
| • | Revenue is expected to be $2.65 billion, plus or minus two percent. |

[0001045810-17-000164:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 59.7 percent and 60.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-17-000164:8k_2_02:22]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $722 million and $600 million, respectively. |

[0001045810-17-000164:8k_2_02:23]
| • | GAAP and non-GAAP other income and expense are both expected to be nominal. |

[0001045810-17-000164:8k_2_02:24]
| • | GAAP and non-GAAP tax rates are both expected to be 17.5 percent, plus or minus one percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which the company expects to generate variability on a quarter by quarter basis. |

[0001045810-17-000164:8k_2_02:25]
Third Quarter Fiscal 2018 Highlights

[0001045810-17-000164:8k_2_02:26]
During the third quarter, NVIDIA achieved progress in these areas:

[0001045810-17-000164:8k_2_02:27]
Datacenter

[0001045810-17-000164:8k_2_02:28]
| • | Set records for attendance at its GPU Technology Conferences for developers in Beijing, Munich, Tel Aviv, Taipei and Washington. |

[0001045810-17-000164:8k_2_02:29]
| • | Announced that Alibaba, Baidu and Tencent will adopt NVIDIA® Volta GPUs for accelerating AI across enterprise and consumer applications, joining Amazon, Facebook, Google and Microsoft. |

[0001045810-17-000164:8k_2_02:30]
| • | Added NVIDIA Tesla® P100 GPU accelerators to Oracle Cloud. |

[0001045810-17-000164:8k_2_02:31]
| • | Launched the NVIDIA GPU Cloud container registry with fully optimized software stacks to accelerate deep learning for developers worldwide. |

[0001045810-17-000164:8k_2_02:32]
| • | Announced that Huawei, Inspur and Lenovo will use NVIDIA Volta HGX architecture to build AI systems for datacenters. |

[0001045810-17-000164:8k_2_02:33]
| • | Shared news that Dell EMC, Hewlett Packard Enterprise, IBM and Supermicro unveiled servers based on NVIDIA Tesla V100 GPU accelerators. |

[0001045810-17-000164:8k_2_02:34]
| • | Launched the NVIDIA TensorRT™ 3 AI inference acceleration platform, opening up new growth in hyperscale datacenters. |

[0001045810-17-000164:8k_2_02:35]
Gaming

[0001045810-17-000164:8k_2_02:36]
| • | Released the GeForce® GTX 1070 Ti GPU, designed to handle the graphical demands of DirectX 12, HDR and immersive VR. |

[0001045810-17-000164:8k_2_02:37]
| • | Announced collaborations to bring NVIDIA GameWorks™ technology to top fall games, including PlayerUnknown’s Battlegrounds, FINAL FANTASY XV and Shadow of War. |

[0001045810-17-000164:8k_2_02:38]
Professional Visualization

[0001045810-17-000164:8k_2_02:39]
| • | Released the NVIDIA VRWorks™ 360 Video SDK, enabling production houses to live stream high-quality, 360-degree, stereo video. |

[0001045810-17-000164:8k_2_02:40]
| • | Opened early access to NVIDIA Holodeck™, providing a virtual collaboration space using highly realistic, physically simulated VR. |

[0001045810-17-000164:8k_2_02:41]
| • | Launched the Quadro® Virtual Data Center Workstation, with virtualization software that turns GPU-accelerated servers into powerful workstations. |

[0001045810-17-000164:8k_2_02:42]
Automotive

[0001045810-17-000164:8k_2_02:43]
| • | Announced NVIDIA DRIVE™ PX Pegasus, the world's first auto-grade AI computer designed to enable a new class of driverless robotaxis without steering wheels, pedals or mirrors. |

[0001045810-17-000164:8k_2_02:44]
Autonomous Machines/AI Edge Computing

[0001045810-17-000164:8k_2_02:45]
| • | Added Alibaba and Huawei as partners for the NVIDIA Metropolis AI Smart Cities platform. |

[0001045810-17-000164:8k_2_02:46]
| • | Announced it is collaborating with China’s JD.com’s X lab to use NVIDIA Jetson™ to create autonomous machines that bring AI to logistics and delivery. |

[0001045810-17-000164:8k_2_02:47]
CFO Commentary

[0001045810-17-000164:8k_2_02:48]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-17-000164:8k_2_02:49]
Conference Call and Webcast Information

[0001045810-17-000164:8k_2_02:50]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2018 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 96232617. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal 2018.

[0001045810-17-000164:8k_2_02:51]
Non-GAAP Measures

[0001045810-17-000164:8k_2_02:52]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, loss on early debt conversions, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-17-000164:8k_2_02:53]
Keep Current on NVIDIA

[0001045810-17-000164:8k_2_02:54]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-17-000164:8k_2_02:55]
About NVIDIA

[0001045810-17-000164:8k_2_02:56]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-17-000164:8k_2_02:57]
###

[0001045810-17-000164:8k_2_02:58]
For further information, contact:

[0001045810-17-000164:8k_2_02:59]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6474 |  | (408) 566-5150 |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-17-000164:8k_2_02:60]
Certain statements in this press release including, but not limited to statements as to:  industries across the world accelerating their adoption of AI; the use of Volta GPUs; the benefits of the TensorRT inference acceleration platform; tapping into strong growth dynamics in gaming through GeForce and Nintendo Switch; DRIVE PX Pegasus being adopted; the company’s intended capital return for fiscal 2018 and fiscal 2019; the company’s next quarterly cash dividend; the company’s financial outlook for the fourth quarter of fiscal 2018; the company’s tax rates for the fourth quarter of fiscal year 2018; the impact and benefits of the adoption of Volta GPUs, TensorRT 3 AI inference software, the GPU cloud container registry, GeForce GTX 1070 Ti GPU, VRWorks 360 Video SDK, Holodeck, Quadro Virtual Data Center Workstation, DRIVE PX Pegasus, and collaboration with JD.com’s X lab and use of Jetson; use of Volta HGX architecture; and collaborations to bring NVIDIA GameWorks technology to top fall games are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended July 30, 2017. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-17-000164:8k_2_02:61]
© 2017 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Quadro, Tesla, Jetson, NVIDIA DRIVE, NVIDIA GameWorks, NVIDIA Holodeck, NVIDIA VRWorks and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-17-000164:8k_2_02:62]
NVIDIA CORPORATION

[0001045810-17-000164:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-17-000164:8k_2_02:64]
(In millions, except per share data)

[0001045810-17-000164:8k_2_02:65]
(Unaudited)

[0001045810-17-000164:8k_2_02:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue | $ | 2,636 |  |  | $ | 2,004 |  |  | $ | 6,803 |  |  | $ | 4,737 |  |
| Cost of revenue | 1,067 |  |  | 821 |  |  | 2,782 |  |  | 1,977 |  |
| Gross profit | 1,569 |  |  | 1,183 |  |  | 4,021 |  |  | 2,760 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 462 |  |  | 373 |  |  | 1,290 |  |  | 1,069 |  |
| Sales, general and administrative | 212 |  |  | 171 |  |  | 594 |  |  | 487 |  |
| Restructuring and other charges | — |  |  | — |  |  | — |  |  | 3 |  |
| Total operating expenses | 674 |  |  | 544 |  |  | 1,884 |  |  | 1,559 |  |
| Income from operations | 895 |  |  | 639 |  |  | 2,137 |  |  | 1,201 |  |
| Interest income | 17 |  |  | 14 |  |  | 48 |  |  | 37 |  |
| Interest expense | (15 | ) |  | (16 | ) |  | (46 | ) |  | (39 | ) |
| Other, net | (1 | ) |  | (16 | ) |  | (22 | ) |  | (19 | ) |
| Total other income (expense) | 1 |  |  | (18 | ) |  | (20 | ) |  | (21 | ) |
| Income before income tax expense | 896 |  |  | 621 |  |  | 2,117 |  |  | 1,180 |  |
| Income tax expense | 58 |  |  | 79 |  |  | 189 |  |  | 168 |  |
| Net income | $ | 838 |  |  | $ | 542 |  |  | $ | 1,928 |  |  | $ | 1,012 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.39 |  |  | $ | 1.01 |  |  | $ | 3.23 |  |  | $ | 1.89 |  |
| Diluted | $ | 1.33 |  |  | $ | 0.83 |  |  | $ | 3.05 |  |  | $ | 1.59 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 603 |  |  | 538 |  |  | 597 |  |  | 536 |  |
| Diluted | 628 |  |  | 653 |  |  | 633 |  |  | 636 |  |

[0001045810-17-000164:8k_2_02:67]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | October 29, |  | January 29, |
|  |  |  | 2017 |  | 2017 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 6,320 |  |  | $ | 6,798 |  |
|  | Accounts receivable, net |  | 1,167 |  |  | 826 |  |
|  | Inventories |  | 857 |  |  | 794 |  |
|  | Prepaid expenses and other current assets |  | 135 |  |  | 118 |  |
|  | Total current assets |  | 8,479 |  |  | 8,536 |  |
| Property and equipment, net |  | 600 |  |  | 521 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 63 |  |  | 104 |  |
| Other assets |  | 70 |  |  | 62 |  |
|  | Total assets |  | $ | 9,830 |  |  | $ | 9,841 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 511 |  |  | $ | 485 |  |
|  | Accrued and other current liabilities |  | 493 |  |  | 507 |  |
|  | Convertible short-term debt |  | 23 |  |  | 796 |  |
|  | Total current liabilities |  | 1,027 |  |  | 1,788 |  |
| Long-term debt |  | 1,985 |  |  | 1,983 |  |
| Other long-term liabilities |  | 464 |  |  | 271 |  |
| Capital lease obligations, long-term |  | 1 |  |  | 6 |  |
|  | Total liabilities |  | 3,477 |  |  | 4,048 |  |
| Convertible debt conversion obligation |  | 1 |  |  | 31 |  |
| Shareholders' equity |  | 6,352 |  |  | 5,762 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 9,830 |  |  | $ | 9,841 |  |

[0001045810-17-000164:8k_2_02:68]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| GAAP gross profit |  | $ | 1,569 |  |  | $ | 1,302 |  |  | $ | 1,183 |  |  | $ | 4,021 |  |  | $ | 2,760 |  |
| GAAP gross margin |  | 59.5 | % |  | 58.4 | % |  | 59.0 | % |  | 59.1 | % |  | 58.3 | % |
| Stock-based compensation expense (A) |  | 6 |  |  | 4 |  |  | 3 |  |  | 14 |  |  | 11 |  |
| Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Non-GAAP gross profit |  | $ | 1,575 |  |  | $ | 1,306 |  |  | $ | 1,186 |  |  | $ | 4,035 |  |  | $ | 2,781 |  |
| Non-GAAP gross margin |  | 59.7 | % |  | 58.6 | % |  | 59.2 | % |  | 59.3 | % |  | 58.7 | % |
| GAAP operating expenses |  | $ | 674 |  |  | $ | 614 |  |  | $ | 544 |  |  | $ | 1,884 |  |  | $ | 1,559 |  |
| Stock-based compensation expense (A) |  | (101 | ) |  | (77 | ) |  | (62 | ) |  | (251 | ) |  | (166 | ) |
| Legal settlement costs |  | — |  |  | — |  |  | — |  |  | — |  |  | (6 | ) |
| Acquisition-related costs (B) |  | (3 | ) |  | (4 | ) |  | (4 | ) |  | (11 | ) |  | (12 | ) |
| Contributions |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | (4 | ) |
| Restructuring and other charges |  | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Non-GAAP operating expenses |  | $ | 570 |  |  | $ | 533 |  |  | $ | 478 |  |  | $ | 1,620 |  |  | $ | 1,368 |  |
| GAAP income from operations |  | $ | 895 |  |  | $ | 688 |  |  | $ | 639 |  |  | $ | 2,137 |  |  | $ | 1,201 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 110 |  |  | 85 |  |  | 69 |  |  | 278 |  |  | 211 |  |
| Non-GAAP income from operations |  | $ | 1,005 |  |  | $ | 773 |  |  | $ | 708 |  |  | $ | 2,415 |  |  | $ | 1,412 |  |
| GAAP other income (expense) |  | $ | 1 |  |  | $ | (4 | ) |  | $ | (18 | ) |  | $ | (20 | ) |  | $ | (21 | ) |
| Gains from non-affiliated investments |  | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Interest expense related to amortization of debt discount |  | — |  |  | 1 |  |  | 6 |  |  | 3 |  |  | 20 |  |
| Loss on early debt conversions |  | 1 |  |  | 3 |  |  | 15 |  |  | 19 |  |  | 15 |  |
| Non-GAAP other income (expense) |  | $ | 2 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | 11 |  |
| GAAP net income |  | $ | 838 |  |  | $ | 583 |  |  | $ | 542 |  |  | $ | 1,928 |  |  | $ | 1,012 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 111 |  |  | 89 |  |  | 90 |  |  | 300 |  |  | 243 |  |
| Income tax impact of non-GAAP adjustments (C) |  | (116 | ) |  | (34 | ) |  | (62 | ) |  | (224 | ) |  | (108 | ) |
| Non-GAAP net income |  | $ | 833 |  |  | $ | 638 |  |  | $ | 570 |  |  | $ | 2,004 |  |  | $ | 1,147 |  |

[0001045810-17-000164:8k_2_02:69]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 1.33 |  |  | $ | 0.92 |  |  | $ | 0.83 |  |  | $ | 3.05 |  |  | $ | 1.59 |  |
| Non-GAAP |  | $ | 1.33 |  |  | $ | 1.01 |  |  | $ | 0.94 |  |  | $ | 3.20 |  |  | $ | 1.93 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 628 |  |  | 633 |  |  | 653 |  |  | 633 |  |  | 636 |  |
| Anti-dilution impact from note hedge (D) |  | (2 | ) |  | (4 | ) |  | (45 | ) |  | (7 | ) |  | (42 | ) |
| Non-GAAP |  | 626 |  |  | 629 |  |  | 608 |  |  | 626 |  |  | 594 |  |
| GAAP net cash provided by operating activities |  | $ | 1,157 |  |  | $ | 705 |  |  | $ | 432 |  |  | $ | 2,144 |  |  | $ | 951 |  |
| Purchase of property and equipment and intangible assets |  | (69 | ) |  | (55 | ) |  | (38 | ) |  | (178 | ) |  | (125 | ) |
| Free cash flow |  | $ | 1,088 |  |  | $ | 650 |  |  | $ | 394 |  |  | $ | 1,966 |  |  | $ | 826 |  |

[0001045810-17-000164:8k_2_02:70]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | July 30, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenue |  | $ | 6 |  |  | $ | 4 |  |  | $ | 3 |  |  | $ | 14 |  |  | $ | 11 |  |
| Research and development |  | $ | 61 |  |  | $ | 44 |  |  | $ | 35 |  |  | $ | 146 |  |  | $ | 95 |  |
| Sales, general and administrative |  | $ | 40 |  |  | $ | 33 |  |  | $ | 27 |  |  | $ | 105 |  |  | $ | 71 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (D) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-17-000164:8k_2_02:71]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2018 Outlook |
| GAAP gross margin |  | 59.7 | % |
|  | Impact of stock-based compensation expense |  | 0.3 | % |
| Non-GAAP gross margin |  | 60.0 | % |
|  |  |  | Q4 FY2018 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 722 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (122 | ) |
| Non-GAAP operating expenses |  | $ | 600 |  |
