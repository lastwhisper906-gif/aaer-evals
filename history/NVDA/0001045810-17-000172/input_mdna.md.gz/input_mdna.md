# NVDA MD&A — 0001045810-17-000172


## mdna

[0001045810-17-000172:mdna:1]
[same as prior period, unchanged from 0001045810-17-000123:mdna:1]

[0001045810-17-000172:mdna:2]
[same as prior period, unchanged from 0001045810-17-000123:mdna:2]

[0001045810-17-000172:mdna:3]
[same as prior period, unchanged from 0001045810-17-000123:mdna:3]

[0001045810-17-000172:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, Jetson, NVIDIA DGX, NVIDIA DRIVE, NVIDIA GameWorks, NVIDIA GRID, NVIDIA Holodeck, NVIDIA VRWorks, OptiX, Pascal and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. MAXQ® is the registered trademark of Maxim Integrated Products, Inc. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-17-000172:mdna:5]
[same as prior period, unchanged from 0001045810-17-000123:mdna:5]

[0001045810-17-000172:mdna:6]
22

[0001045810-17-000172:mdna:7]
[same as prior period, unchanged from 0001045810-17-000123:mdna:6]

[0001045810-17-000172:mdna:8]
[same as prior period, unchanged from 0001045810-17-000123:mdna:7]

[0001045810-17-000172:mdna:9]
[same as prior period, unchanged from 0001045810-17-000123:mdna:8]

[0001045810-17-000172:mdna:10]
[same as prior period, unchanged from 0001045810-17-000123:mdna:9]

[0001045810-17-000172:mdna:11]
[same as prior period, unchanged from 0001045810-17-000123:mdna:10]

[0001045810-17-000172:mdna:12]
[same as prior period, unchanged from 0001045810-17-000123:mdna:11]

[0001045810-17-000172:mdna:13]
[same as prior period, unchanged from 0001045810-17-000123:mdna:12]

[0001045810-17-000172:mdna:14]
Third Quarter of Fiscal Year 2018 Summary

[0001045810-17-000172:mdna:15]
|  | Three Months Ended |  |  |  |  |
|  | October 29, 2017 |  | July 30, 2017 |  | October 30, 2016 |  | Q/Q |  | Y/Y |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 2,636 |  |  | $ | 2,230 |  |  | $ | 2,004 |  |  | 18 | % |  | 32 | % |
| Gross margin | 59.5 | % |  | 58.4 | % |  | 59.0 | % |  | 110 bps |  |  | 50 bps |  |
| Operating expenses | $ | 674 |  |  | $ | 614 |  |  | $ | 544 |  |  | 10 | % |  | 24 | % |
| Income from operations | $ | 895 |  |  | $ | 688 |  |  | $ | 639 |  |  | 30 | % |  | 40 | % |
| Net income | $ | 838 |  |  | $ | 583 |  |  | $ | 542 |  |  | 44 | % |  | 55 | % |
| Net income per diluted share | $ | 1.33 |  |  | $ | 0.92 |  |  | $ | 0.83 |  |  | 45 | % |  | 60 | % |

[0001045810-17-000172:mdna:16]
Revenue for the third quarter of fiscal year 2018 increased 32% year over year and 18% sequentially. Growth was driven by GPUs for gaming, datacenter, and professional visualization, as well as Tegra processors.

[0001045810-17-000172:mdna:17]
GPU business revenue was $2.22 billion, up 31% from a year earlier and up 17% sequentially, with strength across all platforms, including gaming, datacenter, and professional visualization. GeForce GPU gaming revenue of $1.56 billion was led by continued strong adoption of Pascal-based GeForce GTX gaming platforms. Datacenter revenue (including Tesla, NVIDIA GRID and DGX) was $501 million, up 109% year on year and up 20% sequentially, reflecting shipments of our Volta GPU architecture.  Datacenter growth was fueled by strong demand by hyperscale and cloud customers for deep learning training and accelerated GPU computing, as well as demand for HPC, DGX AI supercomputing, and GRID virtualization platforms. Professional visualization revenue grew 15% year over year and 2% sequentially to $239 million, led by high-end mobile platforms.

[0001045810-17-000172:mdna:18]
Tegra processor business revenue was $419 million, up 74% from a year ago and up 26% sequentially. Tegra processor business revenue includes system-on-a-chip (SOCs) modules for the Nintendo Switch gaming console and development services.  Also included was automotive revenue of $144 million, which was up 13% from a year earlier and up 1% sequentially, incorporating infotainment modules, production DRIVE PX platforms, and development agreements for self-driving cars.

[0001045810-17-000172:mdna:19]
Revenue from our patent license agreement with Intel concluded in the first quarter of fiscal year 2018.

[0001045810-17-000172:mdna:20]
Gross margin for the third quarter of fiscal year 2018 was 59.5%, increasing from the prior year and the previous quarter due to strong growth in datacenter revenue and the mix within our GeForce gaming GPUs.

[0001045810-17-000172:mdna:21]
23

[0001045810-17-000172:mdna:22]
Operating expenses for the third quarter of fiscal year 2018 were $674 million, up 24% from a year earlier and up 10% sequentially, reflecting increased headcount and related costs for our growth initiatives - gaming, artificial intelligence, and autonomous driving.

[0001045810-17-000172:mdna:23]
Income from operations for the third quarter of fiscal year 2018 was $895 million, up 40% from a year earlier and up 30% sequentially. Net income and net income per diluted share for the third quarter of fiscal year 2018 were $838 million and $1.33, respectively, up 55% and 60%, respectively, from a year earlier, fueled by strong revenue growth and improved gross and operating margins.

[0001045810-17-000172:mdna:24]
During the first nine months of fiscal year 2018, we returned to shareholders $909 million in share repurchases and $250 million in cash dividends. For fiscal year 2018, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. For fiscal year 2019, we also intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. In November 2017, we declared an increase in our quarterly cash dividend to $0.15 per share from $0.14 per share, to be paid with our next quarterly cash dividend on December 15, 2017, to all shareholders of record on November 24, 2017.

[0001045810-17-000172:mdna:25]
Cash, cash equivalents and marketable securities were $6.32 billion as of October 29, 2017, compared with $5.88 billion at the end of the prior quarter. The sequential increase was primarily related to the increase in operating income, as well as strong collections of outstanding accounts receivable.

[0001045810-17-000172:mdna:26]
[same as prior period, unchanged from 0001045810-17-000123:mdna:25]

[0001045810-17-000172:mdna:27]
During the third quarter of fiscal year 2018, we released the GeForce GTX 1070 Ti GPU and announced collaborations to bring NVIDIA GameWorks technology to top fall games, including PlayerUnknown’s Battlegrounds, FINAL FANTASY XV, Shadow of War, and Destiny 2. For our datacenter platform, we held GPU Technology Conferences in Beijing, Munich, Tel Aviv, Taipei and Washington, announced that Alibaba, Baidu and Tencent will adopt NVIDIA Volta GPUs for accelerating AI, and that Oracle had added NVIDIA Tesla P100 GPU accelerators to Oracle Cloud. We also launched the NVIDIA GPU Cloud container registry to accelerate deep learning for developers, announced that Huawei, Inspur and Lenovo will use the NVIDIA Volta HGX architecture to build AI systems for datacenters, shared news that Dell EMC, Hewlett Packard Enterprise, IBM and Supermicro had unveiled servers based on NVIDIA Tesla V100 GPU accelerators, and launched the NVIDIA TensorRT 3 AI inference acceleration platform. For our professional visualization platform, we opened early access to NVIDIA Holodeck, and launched the Quadro Virtual Data Center Workstation.

[0001045810-17-000172:mdna:28]
[same as prior period, unchanged from 0001045810-17-000123:mdna:26]

[0001045810-17-000172:mdna:29]
[same as prior period, unchanged from 0001045810-17-000123:mdna:27]

[0001045810-17-000172:mdna:30]
[same as prior period, unchanged from 0001045810-17-000123:mdna:28]

[0001045810-17-000172:mdna:31]
During the third quarter of fiscal year 2018, we announced NVIDIA DRIVE PX Pegasus, an auto-grade AI computer designed to enable driverless robotaxis without steering wheels, pedals or mirrors, we added Alibaba and Huawei as partners for the NVIDIA Metropolis AI Smart Cities platform, and we announced that we are collaborating with China’s JD.com’s X lab to use NVIDIA Jetson to create autonomous machines that bring AI to logistics and delivery.

[0001045810-17-000172:mdna:32]
[same as prior period, unchanged from 0001045810-17-000123:mdna:18]

[0001045810-17-000172:mdna:33]
[same as prior period, unchanged from 0001045810-17-000123:mdna:29]

[0001045810-17-000172:mdna:34]
[same as prior period, unchanged from 0001045810-17-000123:mdna:30]

[0001045810-17-000172:mdna:35]
[same as prior period, unchanged from 0001045810-17-000123:mdna:32]

[0001045810-17-000172:mdna:36]
[same as prior period, unchanged from 0001045810-17-000123:mdna:33]

[0001045810-17-000172:mdna:37]
[same as prior period, unchanged from 0001045810-17-000123:mdna:34]

[0001045810-17-000172:mdna:38]
[same as prior period, unchanged from 0001045810-17-000123:mdna:35]

[0001045810-17-000172:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2017 |  | October 30, 2016 |  | October 29, 2017 |  | October 30, 2016 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 40.5 |  |  | 41.0 |  |  | 40.9 |  |  | 41.7 |  |
| Gross profit | 59.5 |  |  | 59.0 |  |  | 59.1 |  |  | 58.3 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 17.5 |  |  | 18.6 |  |  | 19.0 |  |  | 22.6 |  |
| Sales, general and administrative | 8.0 |  |  | 8.5 |  |  | 8.7 |  |  | 10.3 |  |
| Restructuring and other charges | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Total operating expenses | 25.5 |  |  | 27.1 |  |  | 27.7 |  |  | 33.0 |  |
| Income from operations | 34.0 |  |  | 31.9 |  |  | 31.4 |  |  | 25.3 |  |
| Interest income | 0.6 |  |  | 0.7 |  |  | 0.7 |  |  | 0.8 |  |
| Interest expense | (0.6 | ) |  | (0.8 | ) |  | (0.7 | ) |  | (0.8 | ) |
| Other, net | — |  |  | (0.8 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Total other income (expense) | — |  |  | (0.9 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Income before income tax expense | 34.0 |  |  | 31.0 |  |  | 31.1 |  |  | 24.9 |  |
| Income tax expense | 2.2 |  |  | 3.9 |  |  | 2.8 |  |  | 3.5 |  |
| Net income | 31.8 | % |  | 27.1 | % |  | 28.3 | % |  | 21.4 | % |

[0001045810-17-000172:mdna:40]
[same as prior period, unchanged from 0001045810-17-000123:mdna:31]

[0001045810-17-000172:mdna:41]
[same as prior period, unchanged from 0001045810-17-000123:mdna:37]

[0001045810-17-000172:mdna:42]
[same as prior period, unchanged from 0001045810-17-000123:mdna:38]

[0001045810-17-000172:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2017 |  | October 30, 2016 |  | $Change |  | %Change |  | October 29, 2017 |  | October 30, 2016 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,217 |  |  | $ | 1,697 |  |  | $ | 520 |  |  | 31 | % |  | $ | 5,676 |  |  | $ | 3,972 |  |  | $ | 1,704 |  |  | 43 | % |
| Tegra Processor | 419 |  |  | 241 |  |  | 178 |  |  | 74 | % |  | 1,084 |  |  | 567 |  |  | 517 |  |  | 91 | % |
| All Other | — |  |  | 66 |  |  | (66 | ) |  | (100 | )% |  | 43 |  |  | 198 |  |  | (155 | ) |  | (78 | )% |
| Total | $ | 2,636 |  |  | $ | 2,004 |  |  | $ | 632 |  |  | 32 | % |  | $ | 6,803 |  |  | $ | 4,737 |  |  | $ | 2,066 |  |  | 44 | % |

[0001045810-17-000172:mdna:44]
GPU Business. GPU business revenue increased by 31% for the third quarter of fiscal year 2018 compared to the third quarter of fiscal year 2017. This increase was due primarily to increased revenue from sales of GeForce GPU products for gaming, which increased over 10%, reflecting continued strong demand for our Pascal-based GPU products. Datacenter revenue, including Tesla, GRID and DGX, increased 109%, reflecting strong demand from hyperscale and cloud customers for deep learning training and accelerated GPU computing, as well as demand for high performance computing, DGX AI supercomputing and GRID virtualization platforms. Revenue from Quadro GPUs for professional visualization increased 15% due primarily to higher sales in both high-end desktop and overall mobile workstation products. Our PC OEM revenue increased by over 90% due primarily to strong demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-17-000172:mdna:45]
GPU business revenue increased by 43% in the first nine months of fiscal year 2018 compared to the first nine months of fiscal year 2017. This increase was due primarily to increased revenue from sales of GeForce GPU products for gaming, which increased over 20%, reflecting continued strong demand for our Pascal-based GPU products. Datacenter revenue, including Tesla, GRID and DGX, increased over 140%, reflecting strong demand from hyperscale and cloud customers for deep learning training and accelerated GPU computing, as well as demand for high performance computing, DGX AI supercomputing and GRID virtualization platforms. Revenue from Quadro GPUs for professional visualization increased over 10% due primarily to higher sales in both desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs increased by over 90% due primarily to strong demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-17-000172:mdna:46]
Tegra Processor Business. Tegra Processor business revenue increased by 74% for the third quarter of fiscal year 2018 compared to the third quarter of fiscal year 2017. This was driven by an increase of over 240% in revenue from gaming development platforms and services, and an increase of 13% in automotive revenue, primarily from infotainment modules, DRIVE PX platforms and development agreements for self-driving cars.

[0001045810-17-000172:mdna:47]
Tegra Processor business revenue increased by 91% in the first nine months of fiscal year 2018 compared to the first nine months of fiscal year 2017. This was driven by an increase of over 420% in revenue from gaming development platforms and services, and an increase of over 15% in automotive revenue, primarily from infotainment modules, DRIVE PX platforms and development agreements for self-driving cars.

[0001045810-17-000172:mdna:48]
All Other. Our patent license agreement with Intel concluded in the first quarter of fiscal year 2018. For the first nine months of fiscal year 2018, we recognized related revenue of $43 million, down from $198 million for the first nine months of fiscal year 2017.

[0001045810-17-000172:mdna:49]
[same as prior period, unchanged from 0001045810-17-000123:mdna:46]

[0001045810-17-000172:mdna:50]
Revenue from sales to customers outside of the United States and Other Americas accounted for 83% and 80% of total revenue for the third quarter and first nine months of fiscal year 2018, respectively. Revenue from sales to customers outside of the United States and Other Americas accounted for 78% of total revenue for both the third quarter and first nine months of fiscal year 2017. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-17-000172:mdna:51]
[same as prior period, unchanged from 0001045810-17-000123:mdna:48]

[0001045810-17-000172:mdna:52]
Our overall gross margin increased to 59.5% for the third quarter of fiscal year 2018 from 59.0% for the third quarter of fiscal year 2017, and increased to 59.1% for the first nine months of fiscal year 2018 from 58.3% for the first nine months of fiscal year 2017. These increases were primarily due to the growth in GPU business revenue from our Datacenter platforms and increased sales of GeForce GTX products for gaming. These increases were partially offset by the absence of licensing revenue from Intel.

[0001045810-17-000172:mdna:53]
Inventory provision costs totaled $14 million and $13 million for the third quarter of fiscal years 2018 and 2017, respectively, unfavorably impacting our gross margin by 0.5% and 0.7%, respectively. Sales of inventory that was previously written-off or written-down totaled $6 million and $19 million for the third quarter of fiscal years 2018 and 2017, respectively, favorably impacting our gross margin by 0.2% and 0.9%, respectively. As a result, the overall net effect on our gross margin from charges for inventory provision costs and sales of items previously written-off or written-down was nominal for the third quarter of fiscal years 2018 and 2017.

[0001045810-17-000172:mdna:54]
Inventory provision costs totaled $30 million and $40 million for the first nine months of fiscal years 2018 and 2017, respectively, unfavorably impacting our gross margin by 0.4% and 0.9%, respectively. Sales of inventory that was previously written-off or written-down totaled $29 million and $39 million for the first nine months of fiscal years 2018 and 2017, respectively, favorably impacting our gross margin by 0.4% and 0.8%, respectively. As a result, the overall net effect on our gross margin from charges for inventory provision costs and sales of items previously written-off or written-down was nominal for the first nine months of fiscal years 2018 and 2017.

[0001045810-17-000172:mdna:55]
[same as prior period, unchanged from 0001045810-17-000123:mdna:52]

[0001045810-17-000172:mdna:56]
GPU Business. The gross margin of our GPU business increased during the third quarter and first nine months of fiscal year 2018 compared to the third quarter and first nine months of fiscal year 2017. GPU margins increased due to strong sales of our GeForce GTX gaming products and revenue growth in Datacenter driven by strong demand for Tesla products by hyperscale and cloud customers for deep learning training and accelerated GPU computing, DGX AI supercomputing and GRID virtualization platforms.

[0001045810-17-000172:mdna:57]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the third quarter and first nine months of fiscal year 2018 compared to the third quarter and first nine months of fiscal year 2017. The increase in Tegra margins was primarily due to revenue growth in gaming development platforms and automotive.

[0001045810-17-000172:mdna:58]
[same as prior period, unchanged from 0001045810-17-000123:mdna:55]

[0001045810-17-000172:mdna:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2017 |  | October 30, 2016 |  | $Change |  | %Change |  | October 29, 2017 |  | October 30, 2016 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 462 |  |  | $ | 373 |  |  | $ | 89 |  |  | 24 | % |  | $ | 1,290 |  |  | $ | 1,069 |  |  | $ | 221 |  |  | 21 | % |
| Sales, general and administrative expenses | 212 |  |  | 171 |  |  | 41 |  |  | 24 | % |  | 594 |  |  | 487 |  |  | 107 |  |  | 22 | % |
| Restructuring and other charges | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | 3 |  |  | (3 | ) |  | (100 | )% |
| Total operating expenses | $ | 674 |  |  | $ | 544 |  |  | $ | 130 |  |  | 24 | % |  | $ | 1,884 |  |  | $ | 1,559 |  |  | $ | 325 |  |  | 21 | % |
| Research and development expenses as a percentage of net revenue | 18 | % |  | 19 | % |  |  |  |  |  |  |  | 19 | % |  | 23 | % |  |  |  |  |
| Sales, general and administrative expenses as a percentage of net revenue | 8 | % |  | 9 | % |  |  |  |  |  |  |  | 9 | % |  | 10 | % |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001045810-17-000172:mdna:60]
[same as prior period, unchanged from 0001045810-17-000123:mdna:57]

[0001045810-17-000172:mdna:61]
Research and development expenses increased by 24% and 21% during the third quarter and first nine months of fiscal year 2018, respectively, compared to the third quarter and first nine months of fiscal year 2017, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-17-000172:mdna:62]
[same as prior period, unchanged from 0001045810-17-000123:mdna:59]

[0001045810-17-000172:mdna:63]
Sales, general and administrative expenses increased by 24% during the third quarter of fiscal year 2018 compared to the third quarter of fiscal year 2017, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-17-000172:mdna:64]
Sales, general and administrative expenses increased by 22% during the first nine months of fiscal year 2018 compared to the first nine months of fiscal year 2017, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense. Offsetting these increases was a decrease in outside professional fees of $11 million resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-17-000172:mdna:65]
[same as prior period, unchanged from 0001045810-17-000123:mdna:62]

[0001045810-17-000172:mdna:66]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera operations. No restructuring charges were recorded during the third quarter and first nine months of fiscal year 2018. Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-17-000172:mdna:67]
[same as prior period, unchanged from 0001045810-17-000123:mdna:64]

[0001045810-17-000172:mdna:68]
[same as prior period, unchanged from 0001045810-17-000123:mdna:65]

[0001045810-17-000172:mdna:69]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $17 million and $14 million during the third quarter of fiscal years 2018 and 2017, respectively, and $48 million and $37 million during the first nine months of fiscal years 2018 and 2017, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-17-000172:mdna:70]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016, and the Convertible Notes issued in December 2013. Interest expense was $15 million and $16 million during the third quarter of fiscal years 2018 and 2017, respectively, and $46 million and $39 million during the first nine months of fiscal years 2018 and 2017, respectively.

[0001045810-17-000172:mdna:71]
[same as prior period, unchanged from 0001045810-17-000123:mdna:68]

[0001045810-17-000172:mdna:72]
Other, net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, losses on early debt conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Other, net, was not significant during the third quarter of fiscal year 2018. Other, net, was an expense of $22 million during the first nine months of fiscal year 2018, consisting primarily of $19 million of losses recognized from early conversions of the Convertible Notes. Other, net, was an expense of $16 million and $19 million during the third quarter and first nine months of fiscal year 2017, consisting primarily of $15 million of losses recognized from early conversions of the Convertible Notes during the third quarter of fiscal year 2017.

[0001045810-17-000172:mdna:73]
[same as prior period, unchanged from 0001045810-17-000123:mdna:70]

[0001045810-17-000172:mdna:74]
We recognized income tax expense of $58 million and $189 million for the third quarter and first nine months of fiscal year 2018, respectively, and $79 million and $168 million for the third quarter and first nine months of fiscal year 2017, respectively. Income tax expense as a percentage of income before income tax was 6.5% and 8.9% for the third quarter and first nine months of fiscal year 2018, respectively, and 12.8% and 14.2% for the third quarter and first nine months of fiscal year 2017, respectively.

[0001045810-17-000172:mdna:75]
The decrease in our effective tax rate in the third quarter and first nine months of fiscal year 2018 as compared to the same periods in the prior fiscal year primarily reflects the recognition of greater tax benefits related to stock-based compensation and a proportional decrease in the amount of earnings subject to United States tax.

[0001045810-17-000172:mdna:76]
[same as prior period, unchanged from 0001045810-17-000123:mdna:73]

[0001045810-17-000172:mdna:77]
[same as prior period, unchanged from 0001045810-17-000123:mdna:74]

[0001045810-17-000172:mdna:78]
|  | October 29, 2017 |  | January 29, 2017 |
|  | (In millions) |
| Cash and cash equivalents | $ | 2,802 |  |  | $ | 1,766 |  |
| Marketable securities | 3,518 |  |  | 5,032 |  |
| Cash, cash equivalents and marketable securities | $ | 6,320 |  |  | $ | 6,798 |  |

[0001045810-17-000172:mdna:79]
|  | Nine Months Ended |
|  | October 29, 2017 |  | October 30, 2016 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 2,144 |  |  | $ | 951 |  |
| Net cash provided by (used in) investing activities | $ | 1,302 |  |  | $ | (420 | ) |
| Net cash provided by (used in) financing activities | $ | (2,410 | ) |  | $ | 813 |  |

[0001045810-17-000172:mdna:80]
As of October 29, 2017, we had $6.32 billion in cash, cash equivalents and marketable securities, a decrease of $478 million from the end of fiscal year 2017. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions. Our portfolio managers are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-17-000172:mdna:81]
Cash provided by operating activities increased in the first nine months of fiscal year 2018 compared to the first nine months of fiscal year 2017, primarily due to higher net income and changes in working capital.

[0001045810-17-000172:mdna:82]
Cash provided by investing activities increased in the first nine months of fiscal year 2018 compared to the first nine months of fiscal year 2017, primarily due to lower purchases of marketable securities.

[0001045810-17-000172:mdna:83]
Cash used in financing activities increased in the first nine months of fiscal year 2018 compared to the first nine months of fiscal year 2017, primarily due to cash provided in the first nine months of fiscal year 2017 from the issuance of $2.00 billion of Notes as well as higher repayments of Convertible Notes, higher payments toward share repurchases and tax payments related to employee stock plans in the first nine months of fiscal year 2018.

[0001045810-17-000172:mdna:84]
[same as prior period, unchanged from 0001045810-17-000123:mdna:81]

[0001045810-17-000172:mdna:85]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of October 29, 2017 and January 29, 2017, we had $6.32 billion and $6.80 billion, respectively, in cash, cash equivalents and marketable securities. Our marketable securities consist principally of debt securities of corporations and United States government and its agencies, asset-backed securities, mortgage-backed securities issued by government-sponsored enterprises, money market funds and foreign government bonds. These investments are denominated in United States dollars. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of October 29, 2017, we were in compliance with our investment policy. As of October 29, 2017, our investments in government agencies and government-sponsored enterprises represented 27% of our total investment portfolio, while the financial sector accounted for 15% of our total investment portfolio.  All of our investments are in A/A3 or better rated securities.

[0001045810-17-000172:mdna:86]
[same as prior period, unchanged from 0001045810-17-000123:mdna:83]

[0001045810-17-000172:mdna:87]
[same as prior period, unchanged from 0001045810-17-000123:mdna:84]

[0001045810-17-000172:mdna:88]
[same as prior period, unchanged from 0001045810-17-000123:mdna:85]

[0001045810-17-000172:mdna:89]
Dividend payments and share repurchases must be made from cash held in the United States. During the third quarter and first nine months of fiscal year 2018, we repurchased a total of 1 million shares and 6 million shares, respectively, for $151 million and $909 million, respectively. During the third quarter and first nine months of fiscal year 2018, we also made cash dividend payments to our shareholders of $84 million and $250 million, respectively.

[0001045810-17-000172:mdna:90]
We intend to return $1.25 billion to our shareholders in fiscal year 2018 through a combination of share repurchases and cash dividends. In November 2017, we declared an increase in our quarterly cash dividend to $0.15 per share from $0.14 per share, to be paid with our next quarterly cash dividend on December 15, 2017, to all shareholders of record on November 24, 2017. For fiscal year 2019, we also intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-17-000172:mdna:91]
Our cash dividend program and the payment of future cash dividends under that program are subject to our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-17-000172:mdna:92]
[same as prior period, unchanged from 0001045810-17-000123:mdna:89]

[0001045810-17-000172:mdna:93]
As of October 29, 2017, we had $24 million of Convertible Notes outstanding, of which $8 million are expected to be settled in the fourth quarter of fiscal year 2018. Please refer to Note 11 of the Notes to the Condensed Consolidated Financial Statements for further discussion.

[0001045810-17-000172:mdna:94]
30

[0001045810-17-000172:mdna:95]
[same as prior period, unchanged from 0001045810-17-000123:mdna:91]

[0001045810-17-000172:mdna:96]
[same as prior period, unchanged from 0001045810-17-000123:mdna:92]

[0001045810-17-000172:mdna:97]
[same as prior period, unchanged from 0001045810-17-000123:mdna:93]

[0001045810-17-000172:mdna:98]
In the fourth quarter of fiscal year 2018, we plan to refinance the operating lease financing arrangement related to our new Santa Clara campus building and purchase the property for approximately $350 million. Please refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for a discussion regarding our operating lease financing arrangement.

[0001045810-17-000172:mdna:99]
[same as prior period, unchanged from 0001045810-17-000123:mdna:95]

[0001045810-17-000172:mdna:100]
As of October 29, 2017, we had outstanding inventory purchase obligations totaling $1.16 billion. Except as described above with respect to the Convertible Notes and the Notes, and the plan to purchase our Santa Clara campus building, there were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017.

[0001045810-17-000172:mdna:101]
[same as prior period, unchanged from 0001045810-17-000123:mdna:97]

[0001045810-17-000172:mdna:102]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-17-000172:mdna:103]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
