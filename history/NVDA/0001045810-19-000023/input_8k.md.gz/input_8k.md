# NVDA 8-K — 0001045810-19-000007 filed 2019-02-14

## item codes, every 8-K on or before 2019-02-21

- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2019-02-21

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-19-000007:8k_2_02:1]
EX-99.1
2
q4fy19pr.htm
Q4FY19 PRESS RELEASE

[0001045810-19-000007:8k_2_02:2]
Exhibit

[0001045810-19-000007:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-19-000007:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2019

[0001045810-19-000007:8k_2_02:5]
| • | Quarterly revenue of $2.21 billion, down 24 percent from a year ago |

[0001045810-19-000007:8k_2_02:6]
| • | Record full-year revenue of $11.72 billion, up 21 percent from a year ago |

[0001045810-19-000007:8k_2_02:7]
| • | Record full-year revenue from Gaming, Datacenter, Professional Visualization and Automotive |

[0001045810-19-000007:8k_2_02:8]
SANTA CLARA, Calif.-Feb. 14, 2019-NVIDIA (NASDAQ: NVDA) today reported revenue for the fourth quarter ended Jan. 27, 2019, of $2.21 billion, down 24 percent from $2.91 billion a year earlier, and down 31 percent from $3.18 billion in the previous quarter.

[0001045810-19-000007:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.92, down 48 percent from $1.78 a year ago and down 53 percent from $1.97 in the previous quarter. Non-GAAP earnings per diluted share were $0.80, down 53 percent from $1.72 a year earlier and down 57 percent from $1.84 in the previous quarter.

[0001045810-19-000007:8k_2_02:10]
For fiscal 2019, revenue was $11.72 billion, up 21 percent from $9.71 billion a year earlier. GAAP earnings per diluted share were $6.63, up 38 percent from $4.82 a year earlier. Non-GAAP earnings per diluted share were $6.64, up 35 percent from $4.92 a year earlier.

[0001045810-19-000007:8k_2_02:11]
“This was a turbulent close to what had been a great year,” said Jensen Huang, founder and CEO of NVIDIA. “The combination of post-crypto excess channel inventory and recent deteriorating end-market conditions drove a disappointing quarter.

[0001045810-19-000007:8k_2_02:12]
“Despite this setback, NVIDIA’s fundamental position and the markets we serve are strong. The accelerated computing platform we pioneered is central to some of world’s most important and fastest growing industries - from artificial intelligence to autonomous vehicles to robotics. We fully expect to return to sustained growth,” he said.

[0001045810-19-000007:8k_2_02:13]
Capital Return

[0001045810-19-000007:8k_2_02:14]
In fiscal 2019, NVIDIA returned $1.95 billion to shareholders through a combination of $1.58 billion in share repurchases and $371 million in quarterly cash dividends.

[0001045810-19-000007:8k_2_02:15]
Of the $3.00 billion NVIDIA intends to return to shareholders by the end of fiscal 2020, $700 million in share repurchases were completed in the fourth quarter of fiscal 2019. The company intends to return the remaining $2.30 billion by the end of fiscal 2020, through a combination of share repurchases and cash dividends.

[0001045810-19-000007:8k_2_02:16]
NVIDIA will pay its next quarterly cash dividend of $0.16 per share on March 22, 2019, to all shareholders of record on March 1, 2019.

[0001045810-19-000007:8k_2_02:17]
Q4 Fiscal 2019 Summary

[0001045810-19-000007:8k_2_02:18]
| GAAP |
| ($ in millions except earnings per share) | Q4 FY19 | Q3 FY19 | Q4 FY18 | Q/Q | Y/Y |
| Revenue | $2,205 | $3,181 | $2,911 | Down 31% | Down 24% |
| Gross margin | 54.7% | 60.4% | 61.9% | Down 570 bps | Down 720 bps |
| Operating expenses | $913 | $863 | $728 | Up 6% | Up 25% |
| Operating income | $294 | $1,058 | $1,073 | Down 72% | Down 73% |
| Net income | $567 | $1,230 | $1,118 | Down 54% | Down 49% |
| Diluted earnings per share | $0.92 | $1.97 | $1.78 | Down 53% | Down 48% |

[0001045810-19-000007:8k_2_02:19]
| Non-GAAP |
| ($ in millions except earnings per share) | Q4 FY19 | Q3 FY19 | Q4 FY18 | Q/Q | Y/Y |
| Revenue | $2,205 | $3,181 | $2,911 | Down 31% | Down 24% |
| Gross margin | 56.0% | 61.0% | 62.1% | Down 500 bps | Down 610 bps |
| Operating expenses | $755 | $730 | $607 | Up 3% | Up 24% |
| Operating income | $479 | $1,210 | $1,202 | Down 60% | Down 60% |
| Net income | $496 | $1,151 | $1,081 | Down 57% | Down 54% |
| Diluted earnings per share | $0.80 | $1.84 | $1.72 | Down 57% | Down 53% |

[0001045810-19-000007:8k_2_02:20]
Fiscal 2019 Summary

[0001045810-19-000007:8k_2_02:21]
| GAAP |
| ($ in millions except earnings per share) | FY19 | FY18 | Y/Y |
| Revenue | $11,716 | $9,714 | Up 21% |
| Gross margin | 61.2% | 59.9% | Up 130 bps |
| Operating expenses | $3,367 | $2,612 | Up 29% |
| Operating income | $3,804 | $3,210 | Up 19% |
| Net income | $4,141 | $3,047 | Up 36% |
| Diluted earnings per share | $6.63 | $4.82 | Up 38% |

[0001045810-19-000007:8k_2_02:22]
| Non-GAAP |
| ($ in millions except earnings per share) | FY19 | FY18 | Y/Y |
| Revenue | $11,716 | $9,714 | Up 21% |
| Gross margin | 61.7% | 60.2% | Up 150 bps |
| Operating expenses | $2,826 | $2,227 | Up 27% |
| Operating income | $4,407 | $3,617 | Up 22% |
| Net income | $4,143 | $3,085 | Up 34% |
| Diluted earnings per share | $6.64 | $4.92 | Up 35% |

[0001045810-19-000007:8k_2_02:23]
NVIDIA’s outlook for the first quarter of fiscal 2020 is as follows:

[0001045810-19-000007:8k_2_02:24]
| • | Revenue is expected to be $2.20 billion, plus or minus 2 percent. |

[0001045810-19-000007:8k_2_02:25]
| • | GAAP and non-GAAP gross margins are expected to be 58.8 percent and 59.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-19-000007:8k_2_02:26]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $930 million and $755 million, respectively. |

[0001045810-19-000007:8k_2_02:27]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $20 million. |

[0001045810-19-000007:8k_2_02:28]
| • | GAAP and non-GAAP tax rates are both expected to be 10 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-19-000007:8k_2_02:29]
For fiscal 2020, revenue is expected to be flat to down slightly.

[0001045810-19-000007:8k_2_02:30]
Latest Highlights

[0001045810-19-000007:8k_2_02:31]
Since the end of the third quarter, NVIDIA has achieved progress in these areas:

[0001045810-19-000007:8k_2_02:32]
Datacenter

[0001045810-19-000007:8k_2_02:33]
| • | Announced that the NVIDIA® T4 GPU launched in public beta on Google Cloud Platform, with availability in the U.S., Europe, Brazil, India, Japan, and Singapore. |

[0001045810-19-000007:8k_2_02:34]
| • | Set six records in AI performance with the release of MLPerf, the industry’s first objective set of AI benchmarks. |

[0001045810-19-000007:8k_2_02:35]
| • | Announced with Google the integration of NVIDIA’s RAPIDS™ GPU-accelerated data science libraries with Kubeflow Pipelines, a Kubernetes-based platform for deploying and managing machine learning workloads in hyperscale datacenters. |

[0001045810-19-000007:8k_2_02:36]
Gaming

[0001045810-19-000007:8k_2_02:37]
| • | Launched the GeForce RTX™ 2060 GPU, putting exceptional performance and graphics enhanced by ray tracing and AI within reach of tens of millions of gamers. |

[0001045810-19-000007:8k_2_02:38]
| • | Unveiled a record 40+ new gaming laptops in over 100 configurations powered by NVIDIA GeForce RTX GPUs. |

[0001045810-19-000007:8k_2_02:39]
| • | Expanded its G-SYNC™ ecosystem with G-SYNC-compatible monitors, tested and driver-optimized by NVIDIA. |

[0001045810-19-000007:8k_2_02:40]
| • | Announced that Battlefield V, the first real-time ray tracing game, will add DLSS AI super-sampling technology; that the highly anticipated game Anthem will integrate DLSS; and that Justice, one of China’s most popular MMO games, will add ray tracing and DLSS. |

[0001045810-19-000007:8k_2_02:41]
Professional Visualization

[0001045810-19-000007:8k_2_02:42]
| • | Introduced Quadro RTX™ 4000, bringing real-time ray tracing to millions of midrange workstation users. |

[0001045810-19-000007:8k_2_02:43]
| • | Announced the NVIDIA CUDA®-accelerated REDCODE RAW decode SDK, in collaboration with RED Digital Cinema, enabling developers and studios to edit 8K video in real time without the need for additional video processors. |

[0001045810-19-000007:8k_2_02:44]
Automotive

[0001045810-19-000007:8k_2_02:45]
| • | Introduced NVIDIA DRIVE™ AutoPilot, the world’s first commercially available Level 2+ automated driving system, with Tier 1 suppliers Continental and ZF announcing the availability of Level 2+ solutions based on NVIDIA DRIVE in 2020. |

[0001045810-19-000007:8k_2_02:46]
| • | Announced with Mercedes-Benz that it will create a centralized computing architecture for the automaker’s next-generation vehicles, enabling them to be software-defined AI cars. |

[0001045810-19-000007:8k_2_02:47]
Edge Computing

[0001045810-19-000007:8k_2_02:48]
| • | Launched the NVIDIA Jetson AGX Xavier™, a palm-sized module delivering 32 TOPS to help build the next generation of autonomous machines. |

[0001045810-19-000007:8k_2_02:49]
| • | Opened its AI and Robotics Research Lab in Seattle. |

[0001045810-19-000007:8k_2_02:50]
CFO Commentary

[0001045810-19-000007:8k_2_02:51]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-19-000007:8k_2_02:52]
Conference Call and Webcast Information

[0001045810-19-000007:8k_2_02:53]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2019 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2020.

[0001045810-19-000007:8k_2_02:54]
Non-GAAP Measures

[0001045810-19-000007:8k_2_02:55]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related and other costs, gains from non-affiliated investments, interest expense related to amortization of debt discount, debt-related costs, the associated tax impact of these items, where applicable, and the tax benefit from income tax reform. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-19-000007:8k_2_02:56]
About NVIDIA

[0001045810-19-000007:8k_2_02:57]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-19-000007:8k_2_02:58]
###

[0001045810-19-000007:8k_2_02:59]
For further information, contact:

[0001045810-19-000007:8k_2_02:60]
| Simona Jankowski |  | Hector Marinez |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | hmarinez@nvidia.com |

[0001045810-19-000007:8k_2_02:61]
Certain statements in this press release including, but not limited to, statements as to: the turbulent close to our year and the causes of a disappointing quarter, including post-crypto excess channel inventory and recent deteriorating end-market conditions; NVIDIA’s fundamental position and the markets we serve being strong; NVIDIA’s accelerated computing platform being central to some of the world’s most important and fastest-growing industries; our expectation to return to sustained growth; NVIDIA’s intended capital return through the end of fiscal 2020; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the first quarter of fiscal 2020; NVIDIA’s financial outlook for fiscal 2020; NVIDIA’s expected tax rates for the first quarter of fiscal 2020; our expectation to generate variability from excess tax benefits or deficiencies related to stock-based compensation; the launch and availability of NVIDIA T4 GPUs; GeForce RTX 2060 giving tens of millions of gamers performance and graphics enhanced by ray tracing and AI; the number of laptops and configurations powered by GeForce RTX GPUs; the expansion of the G-SYNC ecosystem; Battlefield V, Anthem and Justice integrating DLSS; Quadro RTX 4000 bringing real-time ray tracing to millions of midrange workstation users; the performance, benefits and abilities of RAPIDS, GeForce RTX 2060, NVIDIA CUDA-accelerated REDCODE RAW decode SDK, NVIDIA Jetson AGX Xavier and NVIDIA DRIVE AutoPilot; the availability of Level 2+ solutions based on NVIDIA DRIVE from Tier 1 suppliers; and our work with Mercedes-Benz to create a centralized computing architecture for its vehicles are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-19-000007:8k_2_02:62]
© 2019 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Quadro, CUDA, GeForce RTX, G-SYNC, Jetson AGX Xavier, NVIDIA DRIVE, Quadro RTX and RAPIDS are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-19-000007:8k_2_02:63]
NVIDIA CORPORATION

[0001045810-19-000007:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-19-000007:8k_2_02:65]
(In millions, except per share data)

[0001045810-19-000007:8k_2_02:66]
(Unaudited)

[0001045810-19-000007:8k_2_02:67]
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 27, |  | January 28, |  | January 27, |  | January 28, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue | $ | 2,205 |  |  | $ | 2,911 |  |  | $ | 11,716 |  |  | $ | 9,714 |  |
| Cost of revenue | 998 |  |  | 1,110 |  |  | 4,545 |  |  | 3,892 |  |
| Gross profit | 1,207 |  |  | 1,801 |  |  | 7,171 |  |  | 5,822 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 647 |  |  | 508 |  |  | 2,376 |  |  | 1,797 |  |
| Sales, general and administrative | 266 |  |  | 220 |  |  | 991 |  |  | 815 |  |
| Total operating expenses | 913 |  |  | 728 |  |  | 3,367 |  |  | 2,612 |  |
| Income from operations | 294 |  |  | 1,073 |  |  | 3,804 |  |  | 3,210 |  |
| Interest income | 42 |  |  | 20 |  |  | 136 |  |  | 69 |  |
| Interest expense | (14 | ) |  | (15 | ) |  | (58 | ) |  | (61 | ) |
| Other, net | 2 |  |  | — |  |  | 14 |  |  | (22 | ) |
| Total other income (expense) | 30 |  |  | 5 |  |  | 92 |  |  | (14 | ) |
| Income before income tax | 324 |  |  | 1,078 |  |  | 3,896 |  |  | 3,196 |  |
| Income tax expense (benefit) | (243 | ) |  | (40 | ) |  | (245 | ) |  | 149 |  |
| Net income | $ | 567 |  |  | $ | 1,118 |  |  | $ | 4,141 |  |  | $ | 3,047 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.93 |  |  | $ | 1.84 |  |  | $ | 6.81 |  |  | $ | 5.09 |  |
| Diluted | $ | 0.92 |  |  | $ | 1.78 |  |  | $ | 6.63 |  |  | $ | 4.82 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 609 |  |  | 606 |  |  | 608 |  |  | 599 |  |
| Diluted | 619 |  |  | 628 |  |  | 625 |  |  | 632 |  |

[0001045810-19-000007:8k_2_02:68]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | January 27, |  | January 28, |
|  |  |  | 2019 |  | 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 7,422 |  |  | $ | 7,108 |  |
|  | Accounts receivable, net |  | 1,424 |  |  | 1,265 |  |
|  | Inventories |  | 1,575 |  |  | 796 |  |
|  | Prepaid expenses and other current assets |  | 136 |  |  | 86 |  |
|  | Total current assets |  | 10,557 |  |  | 9,255 |  |
| Property and equipment, net |  | 1,404 |  |  | 997 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 45 |  |  | 52 |  |
| Other assets |  | 668 |  |  | 319 |  |
|  | Total assets |  | $ | 13,292 |  |  | $ | 11,241 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 511 |  |  | $ | 596 |  |
|  | Accrued and other current liabilities |  | 818 |  |  | 542 |  |
|  | Convertible short-term debt |  | — |  |  | 15 |  |
|  | Total current liabilities |  | 1,329 |  |  | 1,153 |  |
| Long-term debt |  | 1,988 |  |  | 1,985 |  |
| Other long-term liabilities |  | 633 |  |  | 632 |  |
|  | Total liabilities |  | 3,950 |  |  | 3,770 |  |
| Shareholders' equity |  | 9,342 |  |  | 7,471 |  |
|  | Total liabilities and shareholders' equity |  | $ | 13,292 |  |  | $ | 11,241 |  |

[0001045810-19-000007:8k_2_02:69]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 27, |  | October 28, |  | January 28, |  | January 27, |  | January 28, |
|  |  | 2019 |  | 2018 |  | 2018 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 1,207 |  |  | $ | 1,921 |  |  | $ | 1,801 |  |  | $ | 7,171 |  |  | $ | 5,822 |  |
| GAAP gross margin |  | 54.7 | % |  | 60.4 | % |  | 61.9 | % |  | 61.2 | % |  | 59.9 | % |
| Stock-based compensation expense (A) |  | 6 |  |  | 5 |  |  | 7 |  |  | 27 |  |  | 21 |  |
| Legal settlement costs |  | 21 |  |  | 14 |  |  | 1 |  |  | 35 |  |  | 1 |  |
| Non-GAAP gross profit |  | $ | 1,234 |  |  | $ | 1,940 |  |  | $ | 1,809 |  |  | $ | 7,233 |  |  | $ | 5,844 |  |
| Non-GAAP gross margin |  | 56.0 | % |  | 61.0 | % |  | 62.1 | % |  | 61.7 | % |  | 60.2 | % |
| GAAP operating expenses |  | $ | 913 |  |  | $ | 863 |  |  | $ | 728 |  |  | $ | 3,367 |  |  | $ | 2,612 |  |
| Stock-based compensation expense (A) |  | (150 | ) |  | (135 | ) |  | (119 | ) |  | (530 | ) |  | (370 | ) |
| Acquisition-related and other costs |  | (1 | ) |  | 3 |  |  | (2 | ) |  | (2 | ) |  | (15 | ) |
| Legal settlement costs |  | (7 | ) |  | (1 | ) |  | — |  |  | (9 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 755 |  |  | $ | 730 |  |  | $ | 607 |  |  | $ | 2,826 |  |  | $ | 2,227 |  |
| GAAP income from operations |  | $ | 294 |  |  | $ | 1,058 |  |  | $ | 1,073 |  |  | $ | 3,804 |  |  | $ | 3,210 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 185 |  |  | 152 |  |  | 129 |  |  | 603 |  |  | 407 |  |
| Non-GAAP income from operations |  | $ | 479 |  |  | $ | 1,210 |  |  | $ | 1,202 |  |  | $ | 4,407 |  |  | $ | 3,617 |  |
| GAAP other income (expense) |  | $ | 30 |  |  | $ | 23 |  |  | $ | 5 |  |  | $ | 92 |  |  | $ | (14 | ) |
| Gains from non-affiliated investments |  | (1 | ) |  | (2 | ) |  | (2 | ) |  | (12 | ) |  | (2 | ) |
| Interest expense related to amortization of debt discount |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 3 |  |
| Debt-related costs |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 20 |  |
| Non-GAAP other income (expense) |  | $ | 29 |  |  | $ | 21 |  |  | $ | 5 |  |  | $ | 82 |  |  | $ | 7 |  |
| GAAP net income |  | $ | 567 |  |  | $ | 1,230 |  |  | $ | 1,118 |  |  | $ | 4,141 |  |  | $ | 3,047 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 184 |  |  | 150 |  |  | 129 |  |  | 593 |  |  | 428 |  |
| Income tax impact of non-GAAP adjustments (B) |  | (25 | ) |  | (91 | ) |  | (33 | ) |  | (223 | ) |  | (257 | ) |
| Tax benefit from income tax reform |  | (230 | ) |  | (138 | ) |  | (133 | ) |  | (368 | ) |  | (133 | ) |
| Non-GAAP net income |  | $ | 496 |  |  | $ | 1,151 |  |  | $ | 1,081 |  |  | $ | 4,143 |  |  | $ | 3,085 |  |

[0001045810-19-000007:8k_2_02:70]
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 27, |  | October 28, |  | January 28, |  | January 27, |  | January 28, |
|  |  | 2019 |  | 2018 |  | 2018 |  | 2019 |  | 2018 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.92 |  |  | $ | 1.97 |  |  | $ | 1.78 |  |  | $ | 6.63 |  |  | $ | 4.82 |  |
| Non-GAAP |  | $ | 0.80 |  |  | $ | 1.84 |  |  | $ | 1.72 |  |  | $ | 6.64 |  |  | $ | 4.92 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 619 |  |  | 625 |  |  | 628 |  |  | 625 |  |  | 632 |  |
| Anti-dilution impact from note hedge |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |  | (5 | ) |
| Non-GAAP |  | 619 |  |  | 625 |  |  | 627 |  |  | 624 |  |  | 627 |  |
| GAAP net cash provided by operating activities |  | $ | 898 |  |  | $ | 487 |  |  | $ | 1,358 |  |  | $ | 3,743 |  |  | $ | 3,502 |  |
| Purchase of property and equipment and intangible assets |  | (203 | ) |  | (150 | ) |  | (416 | ) |  | (600 | ) |  | (593 | ) |
| Free cash flow |  | $ | 695 |  |  | $ | 337 |  |  | $ | 942 |  |  | $ | 3,143 |  |  | $ | 2,909 |  |

[0001045810-19-000007:8k_2_02:71]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | January 27, |  | October 28, |  | January 28, |  | January 27, |  | January 28, |
|  |  | 2019 |  | 2018 |  | 2018 |  | 2019 |  | 2018 |
| Cost of revenue |  | $ | 6 |  |  | $ | 5 |  |  | $ | 7 |  |  | $ | 27 |  |  | $ | 21 |  |
| Research and development |  | $ | 99 |  |  | $ | 88 |  |  | $ | 73 |  |  | $ | 336 |  |  | $ | 219 |  |
| Sales, general and administrative |  | $ | 51 |  |  | $ | 47 |  |  | $ | 46 |  |  | $ | 194 |  |  | $ | 151 |  |
| (B) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-19-000007:8k_2_02:72]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2020 Outlook |
| GAAP gross margin |  | 58.8% |  |
|  | Impact of stock-based compensation expense |  | 0.2% |  |
| Non-GAAP gross margin |  | 59.0% |  |
|  |  |  | Q1 FY2020 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 930 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (175 | ) |
| Non-GAAP operating expenses |  | $ | 755 |  |
