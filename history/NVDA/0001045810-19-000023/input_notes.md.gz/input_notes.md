# NVDA notes — 0001045810-19-000023


## nvda:ScheduleofRevenuebyMarketsTableTextBlock

[0001045810-19-000023:notes:1]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-19-000023:notes:2]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
| Revenue: | (In millions) |
| Gaming | $ | 6,246 |  |  | $ | 5,513 |  |  | $ | 4,060 |  |
| Professional Visualization | 1,130 |  |  | 934 |  |  | 835 |  |
| Datacenter | 2,932 |  |  | 1,932 |  |  | 830 |  |
| Automotive | 641 |  |  | 558 |  |  | 487 |  |
| OEM & IP | 767 |  |  | 777 |  |  | 698 |  |
| Total revenue | $ | 11,716 |  |  | $ | 9,714 |  |  | $ | 6,910 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-19-000023:notes:3]
|  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 1,580 |  |  | $ | 1,091 |  |
| Estimated weighted average remaining amortization period | (In years) |
| RSUs, PSUs and market-based PSUs | 2.2 |  |  | 2.3 |  |
| ESPP | 0.8 |  |  | 0.7 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-19-000023:notes:4]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-19-000023:notes:5]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2019 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | (2 | ) | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 21 |  | (2) | $ | (22 | ) | (4) | $ | 8 |  |
| Deferred tax valuation allowance |  | $ | 469 |  |  | $ | 93 |  | (3) | $ | — |  |  | $ | 562 |  |
| Fiscal year 2018 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3 |  |  | $ | 1 |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 10 |  |  | $ | 15 |  | (2) | $ | (16 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 353 |  |  | $ | 116 |  | (3) | $ | — |  |  | $ | 469 |  |
| Fiscal year 2017 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | 1 |  | (1) | $ | — |  | (1) | $ | 3 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 9 |  | (2) | $ | (8 | ) | (4) | $ | 10 |  |
| Deferred tax valuation allowance |  | $ | 272 |  |  | $ | 81 |  | (3) | $ | — |  |  | $ | 353 |  |

[0001045810-19-000023:notes:6]
| (1) | Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end. |

[0001045810-19-000023:notes:7]
| (2) | Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue. |

[0001045810-19-000023:notes:8]
| (3) | Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information. |

[0001045810-19-000023:notes:9]
| (4) | Represents sales returns. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001045810-19-000023:notes:10]
Advertising Expenses

[0001045810-19-000023:notes:11]
We expense advertising costs in the period in which they are incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001045810-19-000023:notes:12]
Cash and Cash Equivalents

[0001045810-19-000023:notes:13]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-19-000023:notes:14]
Commitments and Contingencies

[0001045810-19-000023:notes:15]
Inventory Purchase Obligations

[0001045810-19-000023:notes:16]
As of January 27, 2019, we had outstanding inventory purchase obligations totaling $912 million.

[0001045810-19-000023:notes:17]
Capital Purchase Obligations

[0001045810-19-000023:notes:18]
As of January 27, 2019, we had outstanding capital purchase obligations totaling $258 million.

[0001045810-19-000023:notes:19]
Lease Obligations

[0001045810-19-000023:notes:20]
Our headquarters complex is located in Santa Clara, California and includes ten buildings that are leased properties. Future minimum lease payments related to headquarters operating leases total $326 million over the remaining terms of the leases, including predetermined rent escalations, and are included in the future minimum lease payment schedule below.

[0001045810-19-000023:notes:21]
Additionally, we have other domestic and international office facilities, including datacenter space, under operating leases expiring through fiscal year 2035.

[0001045810-19-000023:notes:22]
Future minimum lease payments under our non-cancelable operating leases as of January 27, 2019, are as follows:

[0001045810-19-000023:notes:23]
|  | Future Minimum Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2020 | $ | 100 |  |
| 2021 | 97 |  |
| 2022 | 90 |  |
| 2023 | 77 |  |
| 2024 | 54 |  |
| 2025 and thereafter | 265 |  |
| Total | $ | 683 |  |

[0001045810-19-000023:notes:24]
Rent expense for fiscal years 2019, 2018, and 2017 was $80 million, $54 million, and $46 million, respectively.

[0001045810-19-000023:notes:25]
Accrual for Product Warranty Liabilities

[0001045810-19-000023:notes:26]
The estimated amount of product returns and warranty liabilities was $18 million and $15 million as of January 27, 2019 and January 28, 2018, respectively.

[0001045810-19-000023:notes:27]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.

[0001045810-19-000023:notes:28]
Litigation

[0001045810-19-000023:notes:29]
Polaris Innovations Limited

[0001045810-19-000023:notes:30]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-19-000023:notes:31]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.

[0001045810-19-000023:notes:32]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for four U.S. patents and declined to institute IPRs on two U.S. patents. On June 19, 2018, the USPTO issued a Final Written Decision on one IPR, finding claims 1-23 and 28 unpatentable but that claims 24-27 were not proved unpatentable. On November 20, 2018, the USPTO issued Final Written Decisions on two IPRs, finding claims 1, 4, 8-12, 16, 18, 43, 45, and 48-51 unpatentable but that claims 2-3, 5, 14, 17, 19-23, 26-31, and 44 were not proved unpatentable.  On December 4, 2018, the USPTO issued a Final Written Decision on one IPR, finding all claims unpatentable. On December 19, 2018, the USPTO issued a Final Written Decision on one IPR, finding claims 1-14 unpatentable.

[0001045810-19-000023:notes:33]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

[0001045810-19-000023:notes:34]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. On September 3, 2018, NVIDIA filed a rejoinder with additional noninfringement arguments. On December 4, 2018, NVIDIA filed a further rejoinder with additional noninfringement, nullity, and FRAND arguments.

[0001045810-19-000023:notes:35]
An oral hearing is scheduled for February 21, 2019.

[0001045810-19-000023:notes:36]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

[0001045810-19-000023:notes:37]
ZiiLabs 1 Patents Lawsuit

[0001045810-19-000023:notes:38]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

[0001045810-19-000023:notes:39]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. patent.

[0001045810-19-000023:notes:40]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the U.S. International Trade Commission, or USITC, investigation over the ZiiLabs 2 patents.

[0001045810-19-000023:notes:41]
On February 1, 2019, NVIDIA entered into an immaterial agreement in which it receives a license to the ZiiLabs patents and a dismissal of the ZiiLabs 1 and 2 Patent Lawsuits. The ZiiLabs 1 and 2 district court cases were dismissed pursuant to a stipulation of dismissal filed on February 8, 2019.  The Administrative Law Judge issued an Initial Determination on February 12, 2019, granting the motion to terminate the USITC investigation addressing the ZiiLabs 2 patents.

[0001045810-19-000023:notes:42]
ZiiLabs 2 Patents Lawsuits

[0001045810-19-000023:notes:43]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or indirect infringement of the ZiiLabs 2 Patents.

[0001045810-19-000023:notes:44]
On February 22, 2018, the Delaware Court stayed the district court action on the ZiiLabs 2 patents pending the resolution of the USITC Investigation over the ZiiLabs 2 patents.

[0001045810-19-000023:notes:45]
On December 29, 2017, ZiiLabs filed a request with the USITC to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

[0001045810-19-000023:notes:46]
On February 28, 2018, NVIDIA and the other respondents answered the USITC complaint and asserted various defenses including non-infringement and invalidity of the four asserted ZiiLabs 2 patents.

[0001045810-19-000023:notes:47]
On May 10, 2018, the Administrative Law Judge then presiding over the investigation issued an Initial Determination terminating the investigation with respect to one of the patents. On July 17, 2018, the USITC affirmed this decision on modified grounds.

[0001045810-19-000023:notes:48]
On October 18, 2018, the Administrative Law Judge currently presiding over the investigation issued an order construing certain claims of the three remaining patents in the investigation.

[0001045810-19-000023:notes:49]
The hearing in the investigation is currently scheduled to begin on April 8, 2019. The target date for completion of the investigation is September 9, 2019.

[0001045810-19-000023:notes:50]
Securities Class Action and Derivative Lawsuits

[0001045810-19-000023:notes:51]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. The complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between August 10, 2017 and November 15, 2018. The plaintiff also alleges that the NVIDIA officers who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiff seeks class certification, an award of unspecified compensatory damages, an award of equitable/injunctive or other further relief as the Court may deem just and proper. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. The two cases have been related and are before the same judge. A stipulation to consolidate the Iron Workers and Oto actions is pending before the Court. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel.

[0001045810-19-000023:notes:52]
On January 18, 2019, a shareholder, purporting to act on the behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief.

[0001045810-19-000023:notes:53]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming us and/or our officers and directors as defendants.

[0001045810-19-000023:notes:54]
Accounting for Loss Contingencies

[0001045810-19-000023:notes:55]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of January 27, 2019, with the exception of immaterial amounts, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001045810-19-000023:notes:56]
Product Warranties

[0001045810-19-000023:notes:57]
We generally offer a limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001045810-19-000023:notes:58]
Stock-based Compensation

[0001045810-19-000023:notes:59]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, we estimate forfeitures annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-19-000023:notes:60]
Principles of Consolidation

[0001045810-19-000023:notes:61]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001045810-19-000023:notes:62]
The following table shows the changes in deferred revenue during fiscal year 2019:

[0001045810-19-000023:notes:63]
|  | January 27, 2019 |
|  | (in millions) |
| Balance as of January 28, 2018 | $ | 68 |  |
| Adjustment to retained earnings upon adoption of new revenue standard | (5 | ) |
| Balance as of January 29, 2018 | 63 |  |
| Deferred revenue added during the period | 344 |  |
| Revenue recognized during the period | (269 | ) |
| Balance as of January 27, 2019 | $ | 138 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-19-000023:notes:64]
Debt

[0001045810-19-000023:notes:65]
Long-Term Debt

[0001045810-19-000023:notes:66]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-19-000023:notes:67]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or  collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-19-000023:notes:68]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-19-000023:notes:69]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-19-000023:notes:70]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | January 27, 2019 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.6 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (12 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,988 |  |  | $ | 1,985 |  |

[0001045810-19-000023:notes:71]
Convertible Debt

[0001045810-19-000023:notes:72]
1.00% Convertible Senior Notes Due 2018

[0001045810-19-000023:notes:73]
In fiscal year 2014, we issued $1.50 billion of Convertible Notes. During fiscal year 2019, we paid cash to settle an aggregate of $16 million in principal amount of the Convertible Notes and issued 714 thousand shares of our common stock for the excess conversion value. The related loss on early conversions was not significant. As of January 27, 2019, there were no Convertible Notes outstanding.

[0001045810-19-000023:notes:74]
Note Hedges

[0001045810-19-000023:notes:75]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. Through January 27, 2019, we had received 57 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.50 billion in principal amount of the Convertible Notes.  As of January 27, 2019, there were no Note Hedges outstanding.

[0001045810-19-000023:notes:76]
Revolving Credit Facility

[0001045810-19-000023:notes:77]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of January 27, 2019, we had not borrowed any amounts under this agreement.

[0001045810-19-000023:notes:78]
Commercial Paper

[0001045810-19-000023:notes:79]
We have a $575 million commercial paper program to support general corporate purposes. As of January 27, 2019, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-19-000023:notes:80]
The following is a summary of cash equivalents and marketable securities as of January 27, 2019 and January 28, 2018:

[0001045810-19-000023:notes:81]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities of United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

[0001045810-19-000023:notes:82]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |

[0001045810-19-000023:notes:83]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of January 27, 2019 and January 28, 2018 are shown below by contractual maturity.

[0001045810-19-000023:notes:84]
|  | January 27, 2019 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 5,042 |  |  | $ | 5,034 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 2,271 |  |  | 2,268 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 22 |  |  | 22 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,335 |  |  | $ | 7,324 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |

[0001045810-19-000023:notes:85]
The following table provides the breakdown of unrealized losses as of January 27, 2019, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-19-000023:notes:86]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,674 |  |  | $ | (1 | ) |  | $ | 401 |  |  | $ | (3 | ) |  | $ | 2,075 |  |  | $ | (4 | ) |
| Corporate debt securities | 915 |  |  | (3 | ) |  | 649 |  |  | (3 | ) |  | 1,564 |  |  | (6 | ) |
| Debt securities issued by the United States Treasury | 1,015 |  |  | — |  |  | 161 |  |  | (1 | ) |  | 1,176 |  |  | (1 | ) |
| Asset-backed securities | — |  |  | — |  |  | 151 |  |  | (1 | ) |  | 151 |  |  | (1 | ) |
| Total | $ | 3,604 |  |  | $ | (4 | ) |  | $ | 1,362 |  |  | $ | (8 | ) |  | $ | 4,966 |  |  | $ | (12 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-19-000023:notes:87]
Derivative Financial Instruments

[0001045810-19-000023:notes:88]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of January 27, 2019 and January 28, 2018.

[0001045810-19-000023:notes:89]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-19-000023:notes:90]
The table below presents the notional value of our foreign currency forward contracts outstanding as of January 27, 2019 and January 28, 2018:

[0001045810-19-000023:notes:91]
|  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 408 |  |  | $ | 104 |  |
| Not designated for hedge accounting | $ | 241 |  |  | $ | 94 |  |

[0001045810-19-000023:notes:92]
As of January 27, 2019, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-19-000023:notes:93]
During fiscal years 2019 and 2018, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-19-000023:notes:94]
Stock-Based Compensation

[0001045810-19-000023:notes:95]
Our stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our ESPP.

[0001045810-19-000023:notes:96]
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts allocated to inventory, as follows:

[0001045810-19-000023:notes:97]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Cost of revenue | $ | 27 |  |  | $ | 21 |  |  | $ | 15 |  |
| Research and development | 336 |  |  | 219 |  |  | 134 |  |
| Sales, general and administrative | 194 |  |  | 151 |  |  | 98 |  |
| Total | $ | 557 |  |  | $ | 391 |  |  | $ | 247 |  |

[0001045810-19-000023:notes:98]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2019, 2018, and 2017.

[0001045810-19-000023:notes:99]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-19-000023:notes:100]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 4 |  |  | 6 |  |  | 12 |  |
| Estimated total grant-date fair value | $ | 1,109 |  |  | $ | 929 |  |  | $ | 591 |  |
| Weighted average grant-date fair value (per share) | $ | 258.26 |  |  | $ | 145.91 |  |  | $ | 50.57 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 1 |  |  | 5 |  |  | 4 |  |
| Weighted average price (per share) | $ | 107.48 |  |  | $ | 21.24 |  |  | $ | 18.51 |  |
| Weighted average grant-date fair value (per share) | $ | 38.51 |  |  | $ | 7.12 |  |  | $ | 5.80 |  |

[0001045810-19-000023:notes:101]
Beginning fiscal year 2015, we shifted away from granting stock options and toward granting RSUs, PSUs and market-based PSUs to reflect changing market trends for equity incentives at our peer companies. The number of PSUs that will ultimately vest is contingent on the Company’s level of achievement versus the corporate financial performance target established by our Compensation Committee in the beginning of each fiscal year.

[0001045810-19-000023:notes:102]
Of the total fair value of equity awards, we estimated that the stock-based compensation expense related to the equity awards that are not expected to vest for fiscal year 2019 was $88 million.

[0001045810-19-000023:notes:103]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-19-000023:notes:104]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.1-2.0 |  | 0.5-2.0 |  | 0.5-2.0 |
| Risk-free interest rate | 1.6%-2.8% |  | 0.8%-1.4% |  | 0.5%-0.9% |
| Volatility | 24%-75% |  | 40%-54% |  | 30%-39% |
| Dividend yield | 0.3%-0.4% |  | 0.3%-0.5% |  | 0.7%-1.4% |

[0001045810-19-000023:notes:105]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-19-000023:notes:106]
Additionally, for RSU, PSU, and market-based PSU awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-19-000023:notes:107]
Equity Incentive Program

[0001045810-19-000023:notes:108]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans.

[0001045810-19-000023:notes:109]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-19-000023:notes:110]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, as most recently amended and restated, the 2007 Plan.

[0001045810-19-000023:notes:111]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock units, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. Up to 230 million shares of our common stock may be issued pursuant to stock awards granted under the 2007 Plan. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 27, 2019, there were 35 million shares available for future issuance.

[0001045810-19-000023:notes:112]
Stock options previously granted to employees, subject to certain exceptions, vest over a four-year period, subject to continued service, with 25% vesting on the anniversary of the hire date in the case of new hires or the anniversary of the date of grant in the case of grants to existing employees and 6.25% vesting quarterly thereafter. These stock options generally expire ten years from the date of grant.

[0001045810-19-000023:notes:113]
Subject to certain exceptions, RSUs and PSUs granted to employees vest over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and (i) for grants made prior to May 18, 2016, 12.5% vesting semi-annually thereafter, and (ii) for grants made on or after May 18, 2016, 6.25% vesting quarterly thereafter. Market-based PSUs vest 100% on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-19-000023:notes:114]
Unless terminated sooner, the 2007 Plan is scheduled to terminate on March 21, 2022. Our Board may suspend or terminate the 2007 Plan at any time. No awards may be granted under the 2007 Plan while the 2007 Plan is suspended or after it is terminated. The Board may also amend the 2007 Plan at any time. However, if legal, regulatory or listing requirements require shareholder approval, the amendment will not go into effect until the shareholders have approved the amendment.

[0001045810-19-000023:notes:115]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-19-000023:notes:116]
In 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, as most recently amended and restated, the 2012 Plan, as the successor to the 1998 Employee Stock Purchase Plan.

[0001045810-19-000023:notes:117]
Up to 89 million shares of our common stock may be issued pursuant to purchases under the 2012 Plan. As of January 27, 2019, we had issued 29 million shares and reserved 60 million shares for future issuance under the 2012 Plan.

[0001045810-19-000023:notes:118]
The 2012 Plan is intended to qualify as an “employee stock purchase plan” under Section 423 of the Internal Revenue Code. Under the current offerings adopted pursuant to the 2012 Plan, each offering period is approximately 24 months, which is generally divided into four purchase periods of six months.

[0001045810-19-000023:notes:119]
Employees are eligible to participate if they are employed by us or an affiliate of us as designated by the Board. Employees who participate in an offering may have up to 10% of their earnings withheld up to certain limitations and applied on specified dates determined by the Board to the purchase of shares of common stock. The Board may increase this percentage at its discretion, up to 15%. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the fair market value on each purchase date within the offering. Employees may end their participation in the 2012 Plan at any time during the offering period, and participation ends automatically on termination of employment with us. In each case, the employee’s contributions are refunded.

[0001045810-19-000023:notes:120]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-19-000023:notes:121]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
|  | (In millions, except years and per share data) |
| Balances, January 28, 2018 | 22 |  |  | $ | 66.72 |  |
| Granted (1)(2) | 4 |  |  | $ | 258.26 |  |
| Vested restricted stock | (10 | ) |  | $ | 52.56 |  |
| Canceled and forfeited | — |  |  | $ | — |  |
| Balances, January 27, 2019 | 16 |  |  | $ | 129.92 |  |
| Vested and expected to vest after January 27, 2019 | 13 |  |  | $ | 129.44 |  |

[0001045810-19-000023:notes:122]
| (1) | Includes PSUs that will be issued and eligible to vest based on the corporate financial performance level achieved for fiscal year 2019. |

[0001045810-19-000023:notes:123]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 45 thousand shares. |

[0001045810-19-000023:notes:124]
As of January 27, 2019 and January 28, 2018, there were 35 million and 16 million shares, respectively, of common stock reserved for future issuance under our equity incentive plans.

[0001045810-19-000023:notes:125]
The total intrinsic value of options exercised was $180 million, $318 million, and $246 million for fiscal years 2019, 2018, and 2017, respectively. Upon exercise of an option, we issue new shares of stock.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001045810-19-000023:notes:126]
Net Income Per Share

[0001045810-19-000023:notes:127]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of equity awards outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that required us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our Convertible Notes, Note Hedges, and related Warrants contained various conversion features, which are further described in Note 11 of these Notes to the Consolidated Financial Statements. The potentially dilutive shares resulting from the Convertible Notes and Warrants under the treasury stock method were included in the calculation of diluted income per share when their inclusion was dilutive. However, the Note Hedges were not included in the calculation of diluted net income per share unless actually exercised, as their pre-exercised effect would have been anti-dilutive under the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001045810-19-000023:notes:128]
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-19-000023:notes:129]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 4,141 |  |  | $ | 3,047 |  |  | $ | 1,666 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 608 |  |  | 599 |  |  | 541 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |
| Equity awards | 17 |  |  | 24 |  |  | 26 |  |
| 1.00% Convertible Senior Notes | — |  |  | 5 |  |  | 44 |  |
| Warrants issued with the 1.00% Convertible Senior Notes | — |  |  | 4 |  |  | 38 |  |
| Diluted weighted average shares | 625 |  |  | 632 |  |  | 649 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 6.81 |  |  | $ | 5.09 |  |  | $ | 3.08 |  |
| Diluted (2) | $ | 6.63 |  |  | $ | 4.82 |  |  | $ | 2.57 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 5 |  |  | 4 |  |  | 8 |  |

[0001045810-19-000023:notes:130]
| (1) | Calculated as net income divided by basic weighted average shares. |

[0001045810-19-000023:notes:131]
| (2) | Calculated as net income divided by diluted weighted average shares. |

[0001045810-19-000023:notes:132]
The 1.00% Convertible Senior Notes Due 2018, or the Convertible Notes, were included in the calculation of diluted net income per share. The Convertible Notes had a dilutive impact on net income per share if our average stock price for the reporting period exceeded the adjusted conversion price of $20.02 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding were also included in the calculation of diluted net income per share. As of January 27, 2019, there were no Convertible Notes or Warrants outstanding.

[0001045810-19-000023:notes:133]
Refer to Note 11 of these Notes to the Consolidated Financial Statements for additional discussion regarding the Convertible Notes, Note Hedges, and Warrants.


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-19-000023:notes:134]
Fair Value of Financial Assets and Liabilities

[0001045810-19-000023:notes:135]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 financial assets and liabilities for fiscal year 2019. Level 3 financial assets and liabilities are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances.

[0001045810-19-000023:notes:136]
|  |  | Fair Value at |
|  | Pricing Category |  | January 27, 2019 |  | January 28, 2018 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 2,620 |  |  | $ | 1,295 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 2,280 |  |  | $ | 815 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 1,492 |  |  | $ | 573 |  |
| Money market funds | Level 1 |  | $ | 483 |  |  | $ | 3,789 |  |
| Foreign government bonds | Level 2 |  | $ | 209 |  |  | $ | 41 |  |
| Asset-backed securities | Level 2 |  | $ | 151 |  |  | $ | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 89 |  |  | $ | 130 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | — |  |  | $ | 189 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 978 |  |  | $ | 982 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 961 |  |  | $ | 986 |  |

[0001045810-19-000023:notes:137]
| (1) | These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 11 of these Notes to the Consolidated Financial Statements for additional information. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001045810-19-000023:notes:138]
Foreign Currency Remeasurement

[0001045810-19-000023:notes:139]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in other income or expense in our Consolidated Statements of Income and to date have not been significant.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001045810-19-000023:notes:140]
Goodwill

[0001045810-19-000023:notes:141]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist.  For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-19-000023:notes:142]
Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting units.

[0001045810-19-000023:notes:143]
Our quantitative impairment test considers both the income approach and the market approach to estimate a reporting unit’s fair value. The income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business. Refer to Note 5 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-19-000023:notes:144]
The carrying amount of goodwill was $618 million, and the amount of goodwill allocated to our GPU and Tegra Processor reporting units was $210 million and $408 million, respectively, as of both January 27, 2019 and January 28, 2018. There were no changes to the carrying amount of goodwill during fiscal years 2019 and 2018. During the fourth quarters of fiscal years 2019, 2018, and 2017, we completed our annual impairment tests and concluded that goodwill was not impaired in any of these years.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001045810-19-000023:notes:145]
Intangible Assets and Other Long-Lived Assets

[0001045810-19-000023:notes:146]
Intangible assets primarily represent rights acquired under technology licenses, patents, acquired intellectual property, trademarks and customer relationships. We currently amortize our intangible assets with definitive lives over periods ranging from three to ten years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.

[0001045810-19-000023:notes:147]
Long-lived assets, such as property and equipment and intangible assets subject to amortization are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset, or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-19-000023:notes:148]
Income Taxes

[0001045810-19-000023:notes:149]
The income tax expense (benefit) applicable to income before income taxes consists of the following:

[0001045810-19-000023:notes:150]
|  | Year Ended |
|  | January 27,2019 |  | January 28,2018 |  | January 29,2017 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 1 |  |  | $ | 464 |  |  | $ | 7 |  |
| State | — |  |  | 1 |  |  | 1 |  |
| Foreign | 69 |  |  | 43 |  |  | 34 |  |
| Total current | 70 |  |  | 508 |  |  | 42 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | (315 | ) |  | (376 | ) |  | 199 |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | — |  |  | 17 |  |  | (2 | ) |
| Total deferred | (315 | ) |  | (359 | ) |  | 197 |  |
| Income tax expense (benefit) | $ | (245 | ) |  | $ | 149 |  |  | $ | 239 |  |

[0001045810-19-000023:notes:151]
Income before income tax consists of the following:

[0001045810-19-000023:notes:152]
|  | Year Ended |
|  | January 27,2019 |  | January 28,2018 |  | January 29,2017 |
|  | (In millions) |
| Domestic (1) | $ | 1,843 |  |  | $ | 1,600 |  |  | $ | 600 |  |
| Foreign | 2,053 |  |  | 1,596 |  |  | 1,305 |  |
| Income before income tax | $ | 3,896 |  |  | $ | 3,196 |  |  | $ | 1,905 |  |

[0001045810-19-000023:notes:153]
| (1) | The increase in domestic income is primarily due to jurisdictional allocation of stock-based compensation charges. |

[0001045810-19-000023:notes:154]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21%, 33.9%, and 35% for fiscal years 2019, 2018, and 2017, respectively, to income before income taxes as follows:

[0001045810-19-000023:notes:155]
|  | Year Ended |
|  | January 27,2019 |  | January 28,2018 |  | January 29,2017 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 818 |  |  | $ | 1,084 |  |  | $ | 667 |  |
| Expense (benefit) resulting from: |  |  |  |  |  |
| State income taxes, net of federal tax effect | 23 |  |  | 10 |  |  | 4 |  |
| Foreign tax rate differential | (412 | ) |  | (545 | ) |  | (315 | ) |
| Stock-based compensation | (191 | ) |  | (181 | ) |  | (70 | ) |
| Tax Cuts and Jobs Act of 2017 | (368 | ) |  | (133 | ) |  | — |  |
| U.S. federal R&D tax credit | (141 | ) |  | (87 | ) |  | (52 | ) |
| Other | 26 |  |  | 1 |  |  | 5 |  |
| Income tax expense (benefit) | $ | (245 | ) |  | $ | 149 |  |  | $ | 239 |  |

[0001045810-19-000023:notes:156]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-19-000023:notes:157]
|  | January 27,2019 |  | January 28,2018 |
|  | (In millions) |
| Deferred tax assets: |  |
| Net operating loss carryforwards | $ | 70 |  |  | $ | 67 |  |
| Accruals and reserves, not currently deductible for tax purposes | 41 |  |  | 24 |  |
| Property, equipment and intangible assets | 2 |  |  | 32 |  |
| Research and other tax credit carryforwards | 626 |  |  | 579 |  |
| Stock-based compensation | 25 |  |  | 24 |  |
| GILTI deferred tax assets | 376 |  |  | — |  |
| Gross deferred tax assets | 1,140 |  |  | 726 |  |
| Less valuation allowance | (562 | ) |  | (469 | ) |
| Total deferred tax assets | 578 |  |  | 257 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (2 | ) |  | (4 | ) |
| Unremitted earnings of foreign subsidiaries | (35 | ) |  | (26 | ) |
| Gross deferred tax liabilities | (37 | ) |  | (30 | ) |
| Net deferred tax asset (1) | $ | 541 |  |  | $ | 227 |  |

[0001045810-19-000023:notes:158]
(1)  Net deferred tax asset includes long-term deferred tax assets of $560 million and $245 million and long-term deferred tax liabilities of $19 million and $18 million for fiscal years 2019 and 2018, respectively. Long-term deferred tax assets are included in Other assets and long-term deferred tax liabilities are included in Other long-term liabilities on our Consolidated Balance Sheets.

[0001045810-19-000023:notes:159]
We recognized an income tax benefit of $245 million for fiscal year 2019, and income tax expense of $149 million and $239 million for fiscal years 2018, and 2017, respectively. Our annual effective tax rate was (6.3)%, 4.7%, and 12.5% for fiscal years 2019, 2018, and 2017, respectively.

[0001045810-19-000023:notes:160]
In December 2017, the TCJA was enacted into law. The TCJA significantly changed U.S. tax law, including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, a requirement for companies to pay a one-time transition tax on the earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes (global intangible low-taxed income, or GILTI) on certain foreign-source earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us in the fourth quarter of fiscal year 2018, while other provisions impacted us beginning in fiscal year 2019.

[0001045810-19-000023:notes:161]
In fiscal year 2018 and the first nine months of fiscal year 2019, we recorded provisional amounts for certain enactment-date effects of the TCJA by applying the SEC guidance in SAB 118 because we had not yet completed our accounting for these effects.  As of January 27, 2019, we completed our accounting for all of the enactment-date income tax effects of the TCJA and recognized a reduction of $368 million to the provisional amount recorded at January 28, 2018 as a component of income tax expense (benefit).  This adjustment primarily relates to the effects of electing to account for GILTI in deferred taxes, as described below. Our final tax benefit from the TCJA was $501 million.

[0001045810-19-000023:notes:162]
The one-time transition tax is based on the post-1986 earnings and profits, or E&P, of our foreign subsidiaries. We had previously accrued deferred taxes on a portion of these same earnings. We recorded a provisional one-time transition tax liability of $971 million at January 28, 2018. Upon further analysis of the TCJA and Notices and regulations issued by the US Department of the Treasury and Internal Revenue Service, we finalized our calculations of the transition tax liability during fiscal year 2019.  For fiscal year 2019, we increased our transition tax provisional amount by $33 million.

[0001045810-19-000023:notes:163]
As a result of the reduction of the corporate income tax rate to 21%, companies were required to remeasure their deferred tax assets and liabilities as of the date of enactment. As a result, at January 28, 2018 we had recorded a provisional income tax expense of $43 million on the write-down of our deferred tax balance.  Upon further analysis of certain aspects of the TJCA, including immediate expensing of qualified capital expenditures and refinement of our calculations, we reduced our provisional tax expense amount by $20 million.

[0001045810-19-000023:notes:164]
The TCJA subjects a U.S. corporation to tax on its GILTI. Under U.S. GAAP, we can make an accounting policy election to either treat taxes due on the GILTI as a current period expense or factor such amounts into our measurement of deferred taxes.  Because we were still evaluating the GILTI provisions as of January 28, 2018, we recorded no GILTI-related deferred balances.  After further evaluation, we elected to account for GILTI deferred taxes.  In fiscal year 2019, we recorded additional deferred tax assets as a net $370 million income tax benefit related to GILTI in deferred taxes.

[0001045810-19-000023:notes:165]
The decrease in the effective tax rate in fiscal year 2019 as compared to fiscal years 2018 and 2017 was primarily due to a decrease in the U.S. statutory tax rate from 33.9% to 21%, the finalization of the enactment-date income tax effects of the TCJA, higher U.S federal research tax credits and excess tax benefits related to stock-based compensation in fiscal year 2019.

[0001045810-19-000023:notes:166]
The decrease in the effective tax rate in fiscal year 2018 as compared to fiscal year 2017 was primarily due to the provisional impact of the tax law changes and recognition of excess tax benefits related to stock-based compensation.

[0001045810-19-000023:notes:167]
Our effective tax rate for fiscal year 2019 was lower than the U.S. federal statutory rate of 21% due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, the finalization of the enactment-date income tax effects of the TCJA,  favorable recognition of the U.S. federal research tax credits, and excess tax benefits related to stock-based compensation.

[0001045810-19-000023:notes:168]
Our effective tax rate for fiscal years 2018 and 2017 was lower than the blended U.S. federal statutory rate of 33.9% for fiscal year 2018 and 35% for fiscal year 2017 due primarily to income earned in jurisdictions, including British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition of U.S. federal research tax credits, the provisional impact of the tax law changes in 2018, and excess tax benefits related to stock-based compensation.

[0001045810-19-000023:notes:169]
As of January 27, 2019 and January 28, 2018, we had a valuation allowance of $562 million and $469 million, respectively, related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-19-000023:notes:170]
As of January 27, 2019, we had federal, state and foreign net operating loss carryforwards of $72 million, $291 million and $290 million, respectively. The federal and state carryforwards will expire beginning in fiscal year 2023 and 2020, respectively. The foreign net operating loss carryforwards of $290 million may be carried forward indefinitely. As of January 27, 2019, we had federal research tax credit carryforwards of $347 million that will begin to expire in fiscal year 2037. We have state research tax credit carryforwards of $718 million, of which $687 million is attributable to the State of California and may be carried over indefinitely, and $31 million is attributable to various other states and will expire beginning in fiscal year 2020. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, states, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-19-000023:notes:171]
As of January 27, 2019, we had $477 million of gross unrecognized tax benefits, of which $432 million would affect our effective tax rate if recognized. However, approximately $82 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $432 million of unrecognized tax benefits as of January 27, 2019 consisted of $142 million recorded in non-current income taxes payable and $290 million reflected as a reduction to the related deferred tax assets.

[0001045810-19-000023:notes:172]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-19-000023:notes:173]
|  | January 27,2019 |  | January 28,2018 |  | January 29,2017 |
|  | (In millions) |
| Balance at beginning of period | $ | 447 |  |  | $ | 224 |  |  | $ | 230 |  |
| Increases in tax positions for prior years | 52 |  |  | 7 |  |  | 3 |  |
| Decreases in tax positions for prior years | (141 | ) |  | (1 | ) |  | — |  |
| Increases in tax positions for current year | 129 |  |  | 222 |  |  | 46 |  |
| Settlements | — |  |  | — |  |  | (48 | ) |
| Lapse in statute of limitations | (10 | ) |  | (5 | ) |  | (7 | ) |
| Balance at end of period | $ | 477 |  |  | $ | 447 |  |  | $ | 224 |  |

[0001045810-19-000023:notes:174]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-19-000023:notes:175]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 27, 2019, January 28, 2018, and January 29, 2017, we had accrued $21 million, $15 million, and $13 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 27, 2019, unrecognized tax benefits of $142 million and the related interest and penalties of $21 million are included in non-current income taxes payable.

[0001045810-19-000023:notes:176]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 27, 2019, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-19-000023:notes:177]
We are subject to taxation by a number of taxing authorities both in the United States and throughout the world. As of January 27, 2019, the significant tax jurisdictions that may be subject to examination include the United States, Hong Kong, Taiwan, China, United Kingdom, Germany, and India for fiscal years 2003 through 2018. As of January 27, 2019, the significant tax jurisdictions for which we are currently under examination include India, Taiwan, China and UK for fiscal years 2003 through 2018.


## us-gaap:IncomeTaxPolicyTextBlock

[0001045810-19-000023:notes:178]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-19-000023:notes:179]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-19-000023:notes:180]
As of January 27, 2019, we had a valuation allowance of $562 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due to projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-19-000023:notes:181]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-19-000023:notes:182]
The Tax Cuts and Jobs Act, or TCJA, which was enacted in December 2017, significantly changes U.S. tax law, including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, a requirement for companies to pay a one-time transition tax on the earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes (global intangible low-taxed income, or GILTI) on certain foreign-source earnings. As a fiscal year-end taxpayer, certain provisions of the TCJA began to impact us in the fourth quarter of fiscal year 2018, while other provisions impacted us beginning in fiscal year 2019. The Securities and Exchange Commission, or the SEC, had provided guidance in Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (SAB 118), which allowed companies to record provisional amounts during a measurement period up to one year from the enactment date. As of January 27, 2019, we completed our accounting for all of the enactment-date income tax effects of the TCJA and elected to account for GILTI in deferred taxes. Refer to Note 13 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-19-000023:notes:183]
Amortizable Intangible Assets

[0001045810-19-000023:notes:184]
The components of our amortizable intangible assets are as follows:

[0001045810-19-000023:notes:185]
|  | January 27, 2019 |  | January 28, 2018 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (188 | ) |  | $ | 7 |  |  | $ | 195 |  |  | $ | (180 | ) |  | $ | 15 |  |
| Patents and licensed technology | 491 |  |  | (453 | ) |  | 38 |  |  | 469 |  |  | (432 | ) |  | 37 |  |
| Total intangible assets | $ | 686 |  |  | $ | (641 | ) |  | $ | 45 |  |  | $ | 664 |  |  | $ | (612 | ) |  | $ | 52 |  |

[0001045810-19-000023:notes:186]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during fiscal year 2019. Amortization expense associated with intangible assets for fiscal years 2019, 2018, and 2017 was $29 million, $55 million, and $68 million, respectively. Future amortization expense related to the net carrying amount of intangible assets as of January 27, 2019 is estimated to be $21 million in fiscal year 2020, $12 million in fiscal year 2021, $5 million in fiscal year 2022, and $5 million in fiscal year 2023, and $2 million in fiscal year 2024.


## us-gaap:InventoryPolicyTextBlock

[0001045810-19-000023:notes:187]
Inventories

[0001045810-19-000023:notes:188]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or net realizable value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.


## us-gaap:InvestmentPolicyTextBlock

[0001045810-19-000023:notes:189]
Fair Value of Financial Instruments

[0001045810-19-000023:notes:190]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 27, 2019 and January 28, 2018. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains or losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains or losses are recognized in earnings in the periods of change together with the offsetting losses or gains on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings.  For derivative instruments not designated for hedge accounting, changes in fair value are recognized in earnings.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-19-000023:notes:191]
Marketable Securities

[0001045810-19-000023:notes:192]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-19-000023:notes:193]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For fiscal years 2019, 2018, and 2017, there were no other-than-temporary impairment losses and net realized gains were not significant.


## us-gaap:LegalCostsPolicyTextBlock

[0001045810-19-000023:notes:194]
Litigation, Investigation and Settlement Costs

[0001045810-19-000023:notes:195]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001045810-19-000023:notes:196]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and deposits and other assets, and exclude goodwill and intangible assets.

[0001045810-19-000023:notes:197]
|  | January 27, 2019 |  | January 28, 2018 |
| Long-lived assets: | (In millions) |
| United States | $ | 1,266 |  |  | $ | 928 |  |
| Taiwan | 137 |  |  | 58 |  |
| India | 44 |  |  | 40 |  |
| China (including Hong Kong) | 38 |  |  | 33 |  |
| Europe | 26 |  |  | 11 |  |
| Other Asia Pacific | 1 |  |  | 1 |  |
| Total long-lived assets | $ | 1,512 |  |  | $ | 1,071 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-19-000023:notes:198]
New Revenue Accounting Standard

[0001045810-19-000023:notes:199]
Method and Impact of Adoption

[0001045810-19-000023:notes:200]
On January 29, 2018, we adopted the new revenue accounting standard using the modified retrospective method and applied it to contracts that were not completed as of that date. Upon adoption, we recognized the cumulative effect of the new standard as a $7 million increase to opening retained earnings, net of tax. Comparative information for prior periods has not been adjusted. The impact of the new standard on our consolidated financial statements for fiscal year 2019 was not significant.

[0001045810-19-000023:notes:201]
Deferred Revenue and Performance Obligations

[0001045810-19-000023:notes:202]
Deferred revenue is comprised mainly of customer advances and deferrals related to license and development arrangements and PCS related to software licensing. The following table shows the changes in deferred revenue during fiscal year 2019:

[0001045810-19-000023:notes:203]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of January 27, 2019, the amount of our remaining performance obligations that has not been recognized as revenue was $305 million, of which we expect to recognize approximately 50% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-19-000023:notes:204]
Refer to Note 16 of these Notes to the Consolidated Financial Statements for additional information, including disaggregated revenue disclosures.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-19-000023:notes:205]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-19-000023:notes:206]
Recently Adopted Accounting Pronouncements

[0001045810-19-000023:notes:207]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We adopted this guidance on January 29, 2018 using the modified retrospective approach. Refer to Note 2 of these Notes to the Consolidated Financial Statements for additional information.

[0001045810-19-000023:notes:208]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We are now required to recognize changes in the fair value of our equity investments through net income rather than other comprehensive income. We adopted this guidance in the first quarter of fiscal year 2019 and applied it prospectively. The adoption of this guidance did not have a significant impact on our Consolidated Financial Statements.

[0001045810-19-000023:notes:209]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-19-000023:notes:210]
The FASB issued an accounting standards update regarding the accounting for leases under which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. We will adopt this guidance using the optional transition method at the beginning of fiscal year 2020 and will not restate comparative prior periods. Additionally, we will elect the package of practical expedients as permitted by the guidance. We are in the process of finalizing changes to our systems and processes in conjunction with our review of lease agreements and currently expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheet of approximately $500 million.

[0001045810-19-000023:notes:211]
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. The standard will be effective for us beginning in the first quarter of fiscal year 2021, with early adoption permitted. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001045810-19-000023:notes:212]
|  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Other Long-Term Liabilities: |  |  |  |
| Income tax payable (1) | $ | 513 |  |  | $ | 559 |  |
| Deferred revenue (2) | 46 |  |  | 15 |  |
| Deferred rent | 21 |  |  | 9 |  |
| Employee benefits liability | 20 |  |  | 12 |  |
| Deferred income tax liability | 19 |  |  | 18 |  |
| Other | 14 |  |  | 19 |  |
| Total other long-term liabilities | $ | 633 |  |  | $ | 632 |  |

[0001045810-19-000023:notes:213]
| (1) | As of January 27, 2019, represents the long-term portion of the one-time transition tax payable of $350 million, as well as unrecognized tax benefits of $142 million and related interest and penalties of $21 million. |

[0001045810-19-000023:notes:214]
| (2) | Deferred revenue primarily includes deferrals related to license and development arrangements and PCS. |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-19-000023:notes:215]
Employee Retirement Plans

[0001045810-19-000023:notes:216]
We have a 401(k) retirement plan covering substantially all of our U.S. employees. Under the plan, participating employees may defer up to 80% of their pre-tax earnings, subject to the Internal Revenue Service annual contribution limits and we match a portion of the employee contributions. Our contribution expense for fiscal years 2019, 2018, and 2017 was $39 million, $23 million, and $12 million, respectively. We also have defined contribution retirement plans outside of the United States to which we contributed $31 million, $25 million, and $23 million for fiscal years 2019, 2018, and 2017, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001045810-19-000023:notes:217]
Property and Equipment

[0001045810-19-000023:notes:218]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization of assets recorded under capital leases. Leasehold improvements and assets recorded under capital leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001045810-19-000023:notes:219]
|  | January 27, 2019 |  | January 28, 2018 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Building | 339 |  |  | 348 |  |  | 25-30 |
| Test equipment | 516 |  |  | 462 |  |  | 3-5 |
| Computer equipment | 522 |  |  | 285 |  |  | 3-5 |
| Leasehold improvements | 263 |  |  | 198 |  |  | (B) |
| Software and licenses | 109 |  |  | 88 |  |  | 3-5 |
| Office furniture and equipment | 69 |  |  | 79 |  |  | 5 |
| Capital leases | 28 |  |  | 28 |  |  | (B) |
| Construction in process | 107 |  |  | 31 |  |  | (C) |
| Total property and equipment, gross | 2,171 |  |  | 1,737 |  |  |  |
| Accumulated depreciation and amortization | (767 | ) |  | (740 | ) |  |  |
| Total property and equipment, net | $ | 1,404 |  |  | $ | 997 |  |  |  |

[0001045810-19-000023:notes:220]
| (A) | Land is a non-depreciable asset. |

[0001045810-19-000023:notes:221]
| (B) | Leasehold improvements and capital leases are amortized based on the lesser of either the asset’s estimated useful life or the remaining expected lease term. |

[0001045810-19-000023:notes:222]
| (C) | Construction in process represents assets that are not available for their intended use as of the balance sheet date. |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001045810-19-000023:notes:223]
Quarterly Summary (Unaudited)

[0001045810-19-000023:notes:224]
The following table sets forth our unaudited consolidated financial results, for the last eight fiscal quarters:

[0001045810-19-000023:notes:225]
|  | Fiscal Year 2019Quarters Ended |
|  | January 27, 2019 |  | October 28, 2018 |  | July 29, 2018 |  | April 29, 2018 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 2,205 |  |  | $ | 3,181 |  |  | $ | 3,123 |  |  | $ | 3,207 |  |
| Cost of revenue | $ | 998 |  |  | $ | 1,260 |  |  | $ | 1,148 |  |  | $ | 1,139 |  |
| Gross profit | $ | 1,207 |  |  | $ | 1,921 |  |  | $ | 1,975 |  |  | $ | 2,068 |  |
| Net income (1) | $ | 567 |  |  | $ | 1,230 |  |  | $ | 1,101 |  |  | $ | 1,244 |  |
| Net income per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 0.93 |  |  | $ | 2.02 |  |  | $ | 1.81 |  |  | $ | 2.05 |  |
| Diluted | $ | 0.92 |  |  | $ | 1.97 |  |  | $ | 1.76 |  |  | $ | 1.98 |  |

[0001045810-19-000023:notes:226]
| (1) | In the third and fourth quarters of fiscal year 2019, we recorded U.S. tax reform benefits of $138 million and $230 million, respectively, associated with the completion of our accounting for the enactment-date income tax effects of the TCJA. Refer to Note 13 of these Notes to the Consolidated Financial Statements for a discussion regarding the U.S. tax reform. |

[0001045810-19-000023:notes:227]
|  | Fiscal Year 2018Quarters Ended |
|  | January 28, 2018 |  | October 28, 2017 |  | July 29,2017 |  | April 29, 2017 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 2,911 |  |  | $ | 2,636 |  |  | $ | 2,230 |  |  | $ | 1,937 |  |
| Cost of revenue | $ | 1,110 |  |  | $ | 1,067 |  |  | $ | 928 |  |  | $ | 787 |  |
| Gross profit | $ | 1,801 |  |  | $ | 1,569 |  |  | $ | 1,302 |  |  | $ | 1,150 |  |
| Net income (1) | $ | 1,118 |  |  | $ | 838 |  |  | $ | 583 |  |  | $ | 507 |  |
| Net income per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 1.84 |  |  | $ | 1.39 |  |  | $ | 0.98 |  |  | $ | 0.86 |  |
| Diluted | $ | 1.78 |  |  | $ | 1.33 |  |  | $ | 0.92 |  |  | $ | 0.79 |  |

[0001045810-19-000023:notes:228]
| (1) | In the fourth quarter of fiscal year 2018, we recorded a U.S. tax reform provisional net tax benefit of $133 million associated with the one-time transition tax on our historical foreign earnings and the adjustment of deferred tax balances to the lower corporate tax rate. Refer to Note 13 of these Notes to the Consolidated Financial Statements for a discussion regarding the U.S. tax reform. |


## us-gaap:ReceivablesPolicyTextBlock

[0001045810-19-000023:notes:229]
Accounts Receivable

[0001045810-19-000023:notes:230]
We maintain an allowance for doubtful accounts receivable for estimated losses resulting from the inability of our customers to make required payments. We determine this allowance by identifying amounts for specific customer issues as well as amounts based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001045810-19-000023:notes:231]
Revenue Recognition

[0001045810-19-000023:notes:232]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-19-000023:notes:233]
Product Sales Revenue

[0001045810-19-000023:notes:234]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-19-000023:notes:235]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-19-000023:notes:236]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-19-000023:notes:237]
License and Development Arrangements

[0001045810-19-000023:notes:238]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-19-000023:notes:239]
Software Licensing

[0001045810-19-000023:notes:240]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001045810-19-000023:notes:241]
|  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Accrued and Other Current Liabilities: |  |  |  |
| Customer program accruals | $ | 302 |  |  | $ | 181 |  |
| Accrued payroll and related expenses | 186 |  |  | 172 |  |
| Deferred revenue (1) | 92 |  |  | 53 |  |
| Taxes payable | 91 |  |  | 33 |  |
| Accrued legal settlement costs | 24 |  |  | — |  |
| Coupon interest on debt obligations | 20 |  |  | 20 |  |
| Warranty accrual (2) | 18 |  |  | 15 |  |
| Professional service fees | 14 |  |  | 15 |  |
| Accrued royalties | 10 |  |  | 17 |  |
| Other | 61 |  |  | 36 |  |
| Total accrued and other current liabilities | $ | 818 |  |  | $ | 542 |  |

[0001045810-19-000023:notes:242]
| (1) | Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and PCS. |

[0001045810-19-000023:notes:243]
| (2) | Refer to Note 12 of these Notes to the Consolidated Financial Statements for a discussion regarding warranties. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001045810-19-000023:notes:244]
|  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 613 |  |  | $ | 227 |  |
| Work in-process | 238 |  |  | 192 |  |
| Finished goods | 724 |  |  | 377 |  |
| Total inventories | $ | 1,575 |  |  | $ | 796 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001045810-19-000023:notes:245]
The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-19-000023:notes:246]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
| Revenue: | (In millions) |
| Taiwan | $ | 3,360 |  |  | $ | 2,991 |  |  | $ | 2,546 |  |
| China (including Hong Kong) | 2,801 |  |  | 1,896 |  |  | 1,305 |  |
| Other Asia Pacific | 2,368 |  |  | 2,066 |  |  | 1,010 |  |
| United States | 1,506 |  |  | 1,274 |  |  | 904 |  |
| Europe | 914 |  |  | 768 |  |  | 659 |  |
| Other countries | 767 |  |  | 719 |  |  | 486 |  |
| Total revenue | $ | 11,716 |  |  | $ | 9,714 |  |  | $ | 6,910 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-19-000023:notes:247]
The table below presents details of our reportable segments and the “All Other” category.

[0001045810-19-000023:notes:248]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 27, 2019: |  |  |  |  |  |  |  |
| Revenue | $ | 10,175 |  |  | $ | 1,541 |  |  | $ | — |  |  | $ | 11,716 |  |
| Depreciation and amortization expense | $ | 197 |  |  | $ | 47 |  |  | $ | 18 |  |  | $ | 262 |  |
| Operating income (loss) | $ | 4,443 |  |  | $ | 241 |  |  | $ | (880 | ) |  | $ | 3,804 |  |
| Year Ended January 28, 2018: |  |  |  |  |  |  |  |
| Revenue | $ | 8,137 |  |  | $ | 1,534 |  |  | $ | 43 |  |  | $ | 9,714 |  |
| Depreciation and amortization expense | $ | 123 |  |  | $ | 37 |  |  | $ | 39 |  |  | $ | 199 |  |
| Operating income (loss) | $ | 3,507 |  |  | $ | 303 |  |  | $ | (600 | ) |  | $ | 3,210 |  |
| Year Ended January 29, 2017: |  |  |  |  |  |  |  |
| Revenue | $ | 5,822 |  |  | $ | 824 |  |  | $ | 264 |  |  | $ | 6,910 |  |
| Depreciation and amortization expense | $ | 116 |  |  | $ | 29 |  |  | $ | 42 |  |  | $ | 187 |  |
| Operating income (loss) | $ | 2,180 |  |  | $ | (9 | ) |  | $ | (237 | ) |  | $ | 1,934 |  |

[0001045810-19-000023:notes:249]
|  | Year Ended |
|  | January 27, 2019 |  | January 28, 2018 |  | January 29, 2017 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | 43 |  |  | $ | 264 |  |
| Stock-based compensation expense | (557 | ) |  | (391 | ) |  | (247 | ) |
| Unallocated cost of revenue and operating expenses | (277 | ) |  | (237 | ) |  | (215 | ) |
| Legal settlement costs | (44 | ) |  | — |  |  | (16 | ) |
| Acquisition-related and other costs | (2 | ) |  | (15 | ) |  | (23 | ) |
| Total | $ | (880 | ) |  | $ | (600 | ) |  | $ | (237 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-19-000023:notes:250]
Segment Information

[0001045810-19-000023:notes:251]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-19-000023:notes:252]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-19-000023:notes:253]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for game consoles and mobile gaming and entertainment devices.

[0001045810-19-000023:notes:254]
Under the single unifying architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-19-000023:notes:255]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, contributions, restructuring and other charges, product warranty charge, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-19-000023:notes:256]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-19-000023:notes:257]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-19-000023:notes:258]
No customer represented 10% or more of total revenue for fiscal years 2019 and 2018. In fiscal year 2017, we had one customer that represented 12% of our total revenue. The revenue was attributable to the GPU business.

[0001045810-19-000023:notes:259]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 19% of our accounts receivable balance from one customer as of January 27, 2019, and approximately 28% of our accounts receivable balance from two customers as of January 28, 2018.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-19-000023:notes:260]
Organization and Summary of Significant Accounting Policies

[0001045810-19-000023:notes:261]
Our Company

[0001045810-19-000023:notes:262]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-19-000023:notes:263]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-19-000023:notes:264]
Fiscal Year

[0001045810-19-000023:notes:265]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019, 2018 and 2017 were 52-week years.

[0001045810-19-000023:notes:266]
Reclassifications

[0001045810-19-000023:notes:267]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-19-000023:notes:268]
Use of Estimates

[0001045810-19-000023:notes:269]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-19-000023:notes:270]
We expense advertising costs in the period in which they are incurred. Advertising expenses for fiscal years 2019, 2018, and 2017 were $21 million, $25 million, and $17 million, respectively.

[0001045810-19-000023:notes:271]
Marketable securities consist of highly liquid debt investments with maturities of greater than three months when purchased. We generally classify our marketable securities at the date of acquisition as available-for-sale. These debt securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. The fair value of interest-bearing debt securities includes accrued interest. Any unrealized losses which are considered to be other-than-temporary impairments are recorded in the other income or expense, net, section of our Consolidated Statements of Income. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income or expense, net, section of our Consolidated Statements of Income.

[0001045810-19-000023:notes:272]
All of our available-for-sale debt investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary or have other indicators of impairments. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is not more likely than not that we will not be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings while loss related to all other factors is recorded in accumulated other comprehensive income or loss.

[0001045810-19-000023:notes:273]
Concentration of Credit Risk

[0001045810-19-000023:notes:274]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio duration. Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, aggregated approximately 19% of our accounts receivable balance from one customer as of January 27, 2019 and 28% of our account receivable balance from two customers as of January 28, 2018. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-19-000023:notes:275]
Shareholders’ Equity

[0001045810-19-000023:notes:276]
Capital Return Program

[0001045810-19-000023:notes:277]
Beginning August 2004, our Board of Directors authorized us to repurchase our stock.

[0001045810-19-000023:notes:278]
During fiscal year 2019, we repurchased a total of 9 million shares for $1.58 billion and also paid $371 million in cash dividends to our shareholders.

[0001045810-19-000023:notes:279]
Through January 27, 2019, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. In November 2018, our board of directors authorized an additional $7.00 billion under our share repurchase program. As of January 27, 2019, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-19-000023:notes:280]
Preferred Stock

[0001045810-19-000023:notes:281]
As of January 27, 2019 and January 28, 2018, there were no shares of preferred stock outstanding.

[0001045810-19-000023:notes:282]
Common Stock

[0001045810-19-000023:notes:283]
We are authorized to issue up to 2.00 billion shares of our common stock at $0.001 per share par value.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-19-000023:notes:284]
Balance Sheet Components

[0001045810-19-000023:notes:285]
Certain balance sheet components are as follows:

[0001045810-19-000023:notes:286]
Depreciation expense for fiscal years 2019, 2018, and 2017 was $233 million, $144 million, and $118 million, respectively.

[0001045810-19-000023:notes:287]
Accumulated amortization of leasehold improvements and capital leases was $189 million and $178 million as of January 27, 2019 and January 28, 2018, respectively.
