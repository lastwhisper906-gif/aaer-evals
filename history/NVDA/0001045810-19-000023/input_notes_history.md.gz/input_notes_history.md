# NVDA note change history — 0001045810-18-000114 → 0001045810-18-000150


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:1]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. On September 3, 2018, NVIDIA filed a rejoinder with additional noninfringement arguments.
  (was, 2018-08-16, similarity 0.9008):
[0001045810-18-000114:note_history:1]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.

- added (2018-11-15):
[0001045810-18-000150:note_history:2]
On October 18, 2018, the Administrative Law Judge currently presiding over the investigation issued an order construing certain claims of the three remaining patents in the investigation.

- added (2018-11-15):
[0001045810-18-000150:note_history:3]
The hearing in the investigation is currently scheduled to begin January 25, 2019.  The target date for completion of the investigation is September 9, 2019.

- changed (2018-11-15):
[0001045810-18-000150:note_history:4]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 28, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2018-08-16, similarity 0.9933):
[0001045810-18-000114:note_history:4]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of July 29, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:5]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.
  (was, 2018-08-16, similarity 0.9988):
[0001045810-18-000114:note_history:5]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.

- changed (2018-11-15):
[0001045810-18-000150:note_history:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The third quarters of fiscal years 2019 and 2018 were both 13-week quarters.
  (was, 2018-08-16, similarity 0.9759):
[0001045810-18-000114:note_history:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The second quarters of fiscal years 2019 and 2018 were both 13-week quarters.


## nvda:DebtSecuritiesAvailableforsaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:7]
The following is a summary of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018:
  (was, 2018-08-16, similarity 0.9479):
[0001045810-18-000114:note_history:7]
The following is a summary of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018:

- changed (2018-11-15):
[0001045810-18-000150:note_history:8]
|  | October 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,732 |  |  | $ | 1 |  |  | $ | (6 | ) |  | $ | 2,727 |  |  | $ | — |  |  | $ | 2,727 |  |
| Debt securities of United States government agencies | 2,140 |  |  | — |  |  | (5 | ) |  | $ | 2,135 |  |  | — |  |  | 2,135 |  |
| Debt securities issued by the United States Treasury | 1,544 |  |  | — |  |  | (2 | ) |  | 1,542 |  |  | — |  |  | 1,542 |  |
| Money market funds | 602 |  |  | — |  |  | — |  |  | 602 |  |  | 602 |  |  | — |  |
| Foreign government bonds | 191 |  |  | — |  |  | — |  |  | 191 |  |  | — |  |  | 191 |  |
| Asset-backed securities | 178 |  |  | — |  |  | (2 | ) |  | 176 |  |  | — |  |  | 176 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 98 |  |  | 1 |  |  | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 7,485 |  |  | $ | 2 |  |  | $ | (15 | ) |  | $ | 7,472 |  |  | $ | 602 |  |  | $ | 6,870 |  |
  (was, 2018-08-16, similarity 0.7994):
[0001045810-18-000114:note_history:8]
|  | July 29, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,491 |  |  | $ | 1 |  |  | $ | (8 | ) |  | $ | 2,484 |  |  | $ | — |  |  | $ | 2,484 |  |
| Debt securities issued by the United States Treasury | 2,412 |  |  | — |  |  | (2 | ) |  | 2,410 |  |  | — |  |  | 2,410 |  |
| Debt securities of United States government agencies | 1,993 |  |  | — |  |  | (6 | ) |  | 1,987 |  |  | — |  |  | 1,987 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Asset-backed securities | 206 |  |  | — |  |  | (2 | ) |  | 204 |  |  | — |  |  | 204 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 107 |  |  | 2 |  |  | (1 | ) |  | 108 |  |  | — |  |  | 108 |  |
| Foreign government bonds | 32 |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total | $ | 7,724 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 7,708 |  |  | $ | 483 |  |  | $ | 7,225 |  |

- changed (2018-11-15):
[0001045810-18-000150:note_history:9]
The following table provides the breakdown of unrealized losses as of October 28, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:
  (was, 2018-08-16, similarity 0.9726):
[0001045810-18-000114:note_history:9]
The following table provides the breakdown of unrealized losses as of July 29, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- changed (2018-11-15):
[0001045810-18-000150:note_history:10]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,584 |  |  | $ | (1 | ) |  | $ | 507 |  |  | $ | (4 | ) |  | $ | 2,091 |  |  | $ | (5 | ) |
| Debt securities issued by the United States Treasury | 1,253 |  |  | — |  |  | 289 |  |  | (2 | ) |  | 1,542 |  |  | (2 | ) |
| Corporate debt securities | 167 |  |  | — |  |  | 794 |  |  | (6 | ) |  | 961 |  |  | (6 | ) |
| Asset-backed securities | — |  |  | — |  |  | 176 |  |  | (2 | ) |  | 176 |  |  | (2 | ) |
| Total | $ | 3,004 |  |  | $ | (1 | ) |  | $ | 1,766 |  |  | $ | (14 | ) |  | $ | 4,770 |  |  | $ | (15 | ) |
  (was, 2018-08-16, similarity 0.722):
[0001045810-18-000114:note_history:10]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 925 |  |  | $ | (1 | ) |  | $ | 559 |  |  | $ | (5 | ) |  | $ | 1,484 |  |  | $ | (6 | ) |
| Debt securities issued by the United States Treasury | 754 |  |  | — |  |  | 410 |  |  | (2 | ) |  | 1,164 |  |  | (2 | ) |
| Corporate debt securities | 310 |  |  | (1 | ) |  | 742 |  |  | (7 | ) |  | 1,052 |  |  | (8 | ) |
| Asset-backed securities | 49 |  |  | (1 | ) |  | 155 |  |  | (1 | ) |  | 204 |  |  | (2 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 15 |  |  | — |  |  | 31 |  |  | (1 | ) |  | 46 |  |  | (1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |  | — |  |
|  | $ | 2,053 |  |  | $ | (3 | ) |  | $ | 1,928 |  |  | $ | (16 | ) |  | $ | 3,981 |  |  | $ | (19 | ) |

- changed (2018-11-15):
[0001045810-18-000150:note_history:11]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018 are shown below by contractual maturity.
  (was, 2018-08-16, similarity 0.9662):
[0001045810-18-000114:note_history:11]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018 are shown below by contractual maturity.

- changed (2018-11-15):
[0001045810-18-000150:note_history:12]
|  | October 28, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,537 |  |  | $ | 5,524 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,923 |  |  | 1,923 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 25 |  |  | 25 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,485 |  |  | $ | 7,472 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |
  (was, 2018-08-16, similarity 0.9882):
[0001045810-18-000114:note_history:12]
|  | July 29, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,991 |  |  | $ | 5,981 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,705 |  |  | 1,699 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 28 |  |  | 28 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,724 |  |  | $ | 7,708 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:13]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.
  (was, 2018-08-16, similarity 0.9925):
[0001045810-18-000114:note_history:13]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

- changed (2018-11-15):
[0001045810-18-000150:note_history:14]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 28, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |
  (was, 2018-08-16, similarity 0.9849):
[0001045810-18-000114:note_history:14]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |

- changed (2018-11-15):
[0001045810-18-000150:note_history:15]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. The Convertible Notes will mature on December 1, 2018 and we had $3 million in principal amount outstanding as of October 28, 2018. Effective August 1, 2018, holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date of December 1, 2018 regardless of conversion conditions.
  (was, 2018-08-16, similarity 0.777):
[0001045810-18-000114:note_history:15]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through the second quarter of fiscal year 2019, we had settled an aggregate of $1.49 billion of the Convertible Notes. The Convertible Notes will mature on December 1, 2018 and we had $14 million in principal amount outstanding as of July 29, 2018. Effective August 1, 2018, holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date of December 1, 2018 regardless of conversion conditions.

- added (2018-11-15):
[0001045810-18-000150:note_history:16]
During the third quarter of fiscal year 2019, we paid cash to settle an aggregate of $11 million in principal amount of the Convertible Notes and issued 485 thousand shares of our common stock for the excess conversion value. The related loss on early conversions was not significant. Based on the closing price of our common stock of $198.29 on the last trading day of the third quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $31 million. As of October 28, 2018, the conversion rate was 49.95 shares of common stock per $1,000 principal amount of the Convertible Notes.

- changed (2018-11-15):
[0001045810-18-000150:note_history:17]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.02 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through October 28, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.50 billion in principal amount of the Convertible Notes.
  (was, 2018-08-16, similarity 0.9903):
[0001045810-18-000114:note_history:17]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.02 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through July 29, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.49 billion in principal amount of the Convertible Notes.

- changed (2018-11-15):
[0001045810-18-000150:note_history:18]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 28, 2018, we had not borrowed any amounts under this agreement.
  (was, 2018-08-16, similarity 0.9067):
[0001045810-18-000114:note_history:18]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of July 29, 2018, we had not borrowed any amounts under this agreement.

- changed (2018-11-15):
[0001045810-18-000150:note_history:19]
We have a $575 million commercial paper program to support general corporate purposes. As of October 28, 2018, we had not issued any commercial paper.
  (was, 2018-08-16, similarity 0.9609):
[0001045810-18-000114:note_history:19]
We have a $575 million commercial paper program to support general corporate purposes. As of July 29, 2018, we had not issued any commercial paper.

- removed (2018-11-15):
[0001045810-18-000114:note_history:20]
During the second quarter of fiscal year 2019, we paid cash to settle an insignificant amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $11 million in principal amount of the Convertible Notes which are expected to be settled in the third quarter of fiscal year 2019. During the second quarter of fiscal year 2019, we also issued one thousand shares of our common stock for the excess conversion value and the related loss on early conversions was not significant. Based on the closing price of our common stock of $252.02 on the last trading day of the second quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $162 million. As of July 29, 2018, the conversion rate was 49.94 shares of common stock per $1,000 principal amount of the Convertible Notes.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:21]
The following is a summary of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018:
  (was, 2018-08-16, similarity 0.9479):
[0001045810-18-000114:note_history:21]
The following is a summary of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018:

- changed (2018-11-15):
[0001045810-18-000150:note_history:22]
|  | October 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,732 |  |  | $ | 1 |  |  | $ | (6 | ) |  | $ | 2,727 |  |  | $ | — |  |  | $ | 2,727 |  |
| Debt securities of United States government agencies | 2,140 |  |  | — |  |  | (5 | ) |  | $ | 2,135 |  |  | — |  |  | 2,135 |  |
| Debt securities issued by the United States Treasury | 1,544 |  |  | — |  |  | (2 | ) |  | 1,542 |  |  | — |  |  | 1,542 |  |
| Money market funds | 602 |  |  | — |  |  | — |  |  | 602 |  |  | 602 |  |  | — |  |
| Foreign government bonds | 191 |  |  | — |  |  | — |  |  | 191 |  |  | — |  |  | 191 |  |
| Asset-backed securities | 178 |  |  | — |  |  | (2 | ) |  | 176 |  |  | — |  |  | 176 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 98 |  |  | 1 |  |  | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 7,485 |  |  | $ | 2 |  |  | $ | (15 | ) |  | $ | 7,472 |  |  | $ | 602 |  |  | $ | 6,870 |  |
  (was, 2018-08-16, similarity 0.7994):
[0001045810-18-000114:note_history:22]
|  | July 29, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,491 |  |  | $ | 1 |  |  | $ | (8 | ) |  | $ | 2,484 |  |  | $ | — |  |  | $ | 2,484 |  |
| Debt securities issued by the United States Treasury | 2,412 |  |  | — |  |  | (2 | ) |  | 2,410 |  |  | — |  |  | 2,410 |  |
| Debt securities of United States government agencies | 1,993 |  |  | — |  |  | (6 | ) |  | 1,987 |  |  | — |  |  | 1,987 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Asset-backed securities | 206 |  |  | — |  |  | (2 | ) |  | 204 |  |  | — |  |  | 204 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 107 |  |  | 2 |  |  | (1 | ) |  | 108 |  |  | — |  |  | 108 |  |
| Foreign government bonds | 32 |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total | $ | 7,724 |  |  | $ | 3 |  |  | $ | (19 | ) |  | $ | 7,708 |  |  | $ | 483 |  |  | $ | 7,225 |  |

- changed (2018-11-15):
[0001045810-18-000150:note_history:23]
The following table provides the breakdown of unrealized losses as of October 28, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:
  (was, 2018-08-16, similarity 0.9726):
[0001045810-18-000114:note_history:23]
The following table provides the breakdown of unrealized losses as of July 29, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- changed (2018-11-15):
[0001045810-18-000150:note_history:24]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,584 |  |  | $ | (1 | ) |  | $ | 507 |  |  | $ | (4 | ) |  | $ | 2,091 |  |  | $ | (5 | ) |
| Debt securities issued by the United States Treasury | 1,253 |  |  | — |  |  | 289 |  |  | (2 | ) |  | 1,542 |  |  | (2 | ) |
| Corporate debt securities | 167 |  |  | — |  |  | 794 |  |  | (6 | ) |  | 961 |  |  | (6 | ) |
| Asset-backed securities | — |  |  | — |  |  | 176 |  |  | (2 | ) |  | 176 |  |  | (2 | ) |
| Total | $ | 3,004 |  |  | $ | (1 | ) |  | $ | 1,766 |  |  | $ | (14 | ) |  | $ | 4,770 |  |  | $ | (15 | ) |
  (was, 2018-08-16, similarity 0.722):
[0001045810-18-000114:note_history:24]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 925 |  |  | $ | (1 | ) |  | $ | 559 |  |  | $ | (5 | ) |  | $ | 1,484 |  |  | $ | (6 | ) |
| Debt securities issued by the United States Treasury | 754 |  |  | — |  |  | 410 |  |  | (2 | ) |  | 1,164 |  |  | (2 | ) |
| Corporate debt securities | 310 |  |  | (1 | ) |  | 742 |  |  | (7 | ) |  | 1,052 |  |  | (8 | ) |
| Asset-backed securities | 49 |  |  | (1 | ) |  | 155 |  |  | (1 | ) |  | 204 |  |  | (2 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 15 |  |  | — |  |  | 31 |  |  | (1 | ) |  | 46 |  |  | (1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |  | — |  |
|  | $ | 2,053 |  |  | $ | (3 | ) |  | $ | 1,928 |  |  | $ | (16 | ) |  | $ | 3,981 |  |  | $ | (19 | ) |

- added (2018-11-15):
[0001045810-18-000150:note_history:25]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For the third quarter and first nine months of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.

- changed (2018-11-15):
[0001045810-18-000150:note_history:26]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018 are shown below by contractual maturity.
  (was, 2018-08-16, similarity 0.9662):
[0001045810-18-000114:note_history:26]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 29, 2018 and January 28, 2018 are shown below by contractual maturity.

- changed (2018-11-15):
[0001045810-18-000150:note_history:27]
|  | October 28, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,537 |  |  | $ | 5,524 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,923 |  |  | 1,923 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 25 |  |  | 25 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,485 |  |  | $ | 7,472 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |
  (was, 2018-08-16, similarity 0.9882):
[0001045810-18-000114:note_history:27]
|  | July 29, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,991 |  |  | $ | 5,981 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,705 |  |  | 1,699 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 28 |  |  | 28 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,724 |  |  | $ | 7,708 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |

- removed (2018-11-15):
[0001045810-18-000114:note_history:28]
The gross unrealized losses related to fixed income securities were primarily due to changes in interest rates, which we believe are temporary in nature. We have the intent and ability to hold our investments until maturity. For the second quarter and first half of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:29]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 28, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |
  (was, 2018-08-16, similarity 0.9849):
[0001045810-18-000114:note_history:29]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.1 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |


## nvda:RevenueFromContractwithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-15):
[0001045810-18-000150:note_history:30]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.
  (was, 2018-08-16, similarity 0.9988):
[0001045810-18-000114:note_history:30]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.
