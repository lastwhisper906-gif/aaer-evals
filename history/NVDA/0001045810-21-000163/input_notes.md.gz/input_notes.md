# NVDA notes — 0001045810-21-000163


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-21-000163:notes:1]
[same as prior period, unchanged from 0001045810-21-000131:notes:1]

[0001045810-21-000163:notes:2]
[same as prior period, unchanged from 0001045810-21-000131:notes:2]

[0001045810-21-000163:notes:3]
[same as prior period, unchanged from 0001045810-21-000131:notes:3]

[0001045810-21-000163:notes:4]
[same as prior period, unchanged from 0001045810-21-000131:notes:4]

[0001045810-21-000163:notes:5]
[same as prior period, unchanged from 0001045810-21-000131:notes:5]

[0001045810-21-000163:notes:6]
[same as prior period, unchanged from 0001045810-21-000131:notes:6]

[0001045810-21-000163:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The third quarters of fiscal years 2022 and 2021 were both 13-week quarters.

[0001045810-21-000163:notes:8]
[same as prior period, unchanged from 0001045810-21-000131:notes:8]

[0001045810-21-000163:notes:9]
[same as prior period, unchanged from 0001045810-21-000131:notes:9]

[0001045810-21-000163:notes:10]
[same as prior period, unchanged from 0001045810-21-000131:notes:10]

[0001045810-21-000163:notes:11]
[same as prior period, unchanged from 0001045810-21-000131:notes:11]

[0001045810-21-000163:notes:12]
[same as prior period, unchanged from 0001045810-21-000131:notes:12]

[0001045810-21-000163:notes:13]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-21-000163:notes:14]
Adoption of New and Recently Issued Accounting Pronouncement

[0001045810-21-000163:notes:15]
Recently Adopted Accounting Pronouncement

[0001045810-21-000163:notes:16]
In October 2021, the Financial Accounting Standards Board issued a new accounting standard to require that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers. We early adopted this accounting standard in the third quarter of fiscal year 2022 and the impact was immaterial.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-21-000163:notes:17]
[same as prior period, unchanged from 0001045810-21-000131:notes:14]

[0001045810-21-000163:notes:18]
On September 13, 2020, we entered into a Share Purchase Agreement, or the Purchase Agreement, with Arm Limited, or Arm, and SoftBank Group Capital Limited and SVF Holdco (UK) Limited, or together, SoftBank, to acquire, from SoftBank, all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid $2 billion in cash at signing, or the Signing Consideration, and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 177.5 million shares of our common stock, which had an aggregate value of $21.5 billion as of the date of the Purchase Agreement, and was valued at $56.2 billion as of November 18, 2021. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial targets are achieved, SoftBank can elect to receive either up to an additional $5 billion in cash or up to an additional 41.3 million shares of our common stock, which was valued at $13.1 billion as of November 18, 2021. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The Signing Consideration was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The Signing Consideration was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. The Purchase Agreement can be terminated by either party if the transaction has not closed by September 2022, subject to certain qualifications. If the transaction does not close due to failure to receive regulatory approval, and all other covenants have been met, we will not be refunded $1.25 billion of the advanced consideration for the acquisition we paid at signing.

[0001045810-21-000163:notes:19]
The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and the expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities.

[0001045810-21-000163:notes:20]
We are seeking regulatory approval in the United States, the United Kingdom, the European Union, China and other jurisdictions. Regulators at the United States Federal Trade Commission, or the FTC, have expressed concerns regarding the transaction, and we are engaged in discussions with the FTC regarding remedies to address those concerns. The transaction has been under the review of China’s antitrust authority, pending the formal case initiation. Regulators in the United Kingdom and the European Union declined to approve the transaction in Phase 1 of their review processes, expressed numerous concerns, began a more in-depth Phase 2 review on the transaction’s impact on competition, and, in the United Kingdom, a Phase 2 review of the impact on the United Kingdom’s national security interests. Although regulators and some Arm licensees have expressed concerns or objected to the transaction, we continue to believe in the merits and benefits of the acquisition to Arm, its licensees, and the industry.

[0001045810-21-000163:notes:21]
[same as prior period, unchanged from 0001045810-21-000131:notes:16]

[0001045810-21-000163:notes:22]
[same as prior period, unchanged from 0001045810-21-000131:notes:17]

[0001045810-21-000163:notes:23]
[same as prior period, unchanged from 0001045810-21-000131:notes:18]

[0001045810-21-000163:notes:24]
[same as prior period, unchanged from 0001045810-21-000131:notes:19]

[0001045810-21-000163:notes:25]
|  | Pro Forma |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 25, 2020 |  | October 25, 2020 |
|  | (In millions) |
| Revenue | $ | 4,726 |  |  | $ | 12,101 |  |
| Net income | $ | 1,388 |  |  | $ | 3,267 |  |

[0001045810-21-000163:notes:26]
The unaudited pro forma information includes adjustments related to amortization of acquired intangible assets, adjustments to stock-based compensation expense, fair value of acquired inventory, and transaction costs. The unaudited pro forma information presented above is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition occurred at the beginning of fiscal year 2020 or of the results of our future operations of the combined businesses. 
The pro forma results exclude the inventory step-up expense of $161 million for the first nine months of fiscal year 2021. There were no other material nonrecurring adjustments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-21-000163:notes:27]
[same as prior period, unchanged from 0001045810-21-000131:notes:23]

[0001045810-21-000163:notes:28]
Future minimum lease payments under our non-cancelable operating leases as of October 31, 2021, are as follows:

[0001045810-21-000163:notes:29]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 (excluding first nine months of fiscal year 2022) | $ | 43 |  |
| 2023 | 169 |  |
| 2024 | 152 |  |
| 2025 | 128 |  |
| 2026 | 118 |  |
| 2027 and thereafter | 385 |  |
| Total | 995 |  |
| Less imputed interest | 112 |  |
| Present value of net future minimum lease payments | 883 |  |
| Less short-term operating lease liabilities | 140 |  |
| Long-term operating lease liabilities | $ | 743 |  |

[0001045810-21-000163:notes:30]
In addition to our existing operating lease obligations, we have operating leases that are expected to commence between the fourth quarter of fiscal year 2022 and fiscal year 2023 with lease terms of 7 years for $132 million.

[0001045810-21-000163:notes:31]
Operating lease expenses were $44 million and $37 million for the third quarter of fiscal years 2022 and 2021, respectively, and $125 million and $104 million for the first nine months of fiscal years 2022 and 2021, respectively.

[0001045810-21-000163:notes:32]
Short-term and variable lease expenses for the third quarter and first nine months of fiscal years 2022 and 2021 were not significant.

[0001045810-21-000163:notes:33]
[same as prior period, unchanged from 0001045810-21-000131:notes:27]

[0001045810-21-000163:notes:34]
|  | Nine Months Ended |
|  | October 31, 2021 |  | October 25, 2020 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 114 |  |  | $ | 103 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 230 |  |  | $ | 147 |  |

[0001045810-21-000163:notes:35]
As of October 31, 2021, our operating leases had a weighted average remaining lease term of 7.3 years and a weighted average discount rate of 2.54%. As of January 31, 2021, our operating leases had a weighted average remaining lease term of 7.6 years and a weighted average discount rate of 2.87%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-21-000163:notes:36]
[same as prior period, unchanged from 0001045810-21-000131:notes:30]

[0001045810-21-000163:notes:37]
[same as prior period, unchanged from 0001045810-21-000131:notes:31]

[0001045810-21-000163:notes:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31,2021 |  | October 25,2020 |  | October 31,2021 |  | October 25,2020 |
|  | (In millions) |
| Cost of revenue | $ | 44 |  |  | $ | 28 |  |  | $ | 102 |  |  | $ | 62 |  |
| Research and development | 363 |  |  | 232 |  |  | 935 |  |  | 594 |  |
| Sales, general and administrative | 152 |  |  | 123 |  |  | 416 |  |  | 325 |  |
| Total | $ | 559 |  |  | $ | 383 |  |  | $ | 1,453 |  |  | $ | 981 |  |

[0001045810-21-000163:notes:39]
[same as prior period, unchanged from 0001045810-21-000131:notes:33]

[0001045810-21-000163:notes:40]
[same as prior period, unchanged from 0001045810-21-000131:notes:34]

[0001045810-21-000163:notes:41]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 31, 2021 | 59 |  |  | $ | 66.17 |  |  |  |  |  |
| Granted | 17 |  |  | $ | 184.63 |  |  |  |  |  |
| Vested restricted stock | (23) |  |  | $ | 62.39 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 80.50 |  |  |  |  |  |
| Balances, October 31, 2021 | 52 |  |  | $ | 107.42 |  |  |  |  |  |

[0001045810-21-000163:notes:42]
As of October 31, 2021, there was $5.16 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and 1 year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-21-000163:notes:43]
[same as prior period, unchanged from 0001045810-21-000131:notes:37]

[0001045810-21-000163:notes:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, |  | October 25, |  | October 31, |  | October 25, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 2,464 |  |  | $ | 1,336 |  |  | $ | 6,749 |  |  | $ | 2,875 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,499 |  |  | 2,472 |  |  | 2,493 |  |  | 2,464 |  |
| Dilutive impact of outstanding equity awards | 39 |  |  | 48 |  |  | 39 |  |  | 40 |  |
| Diluted weighted average shares | 2,538 |  |  | 2,520 |  |  | 2,532 |  |  | 2,504 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.99 |  |  | $ | 0.54 |  |  | $ | 2.71 |  |  | $ | 1.17 |  |
| Diluted (2) | $ | 0.97 |  |  | $ | 0.53 |  |  | $ | 2.67 |  |  | $ | 1.15 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 2 |  |  | — |  |  | 21 |  |  | 32 |  |

[0001045810-21-000163:notes:45]
[same as prior period, unchanged from 0001045810-21-000131:notes:39]

[0001045810-21-000163:notes:46]
[same as prior period, unchanged from 0001045810-21-000131:notes:40]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-21-000163:notes:47]
Income Taxes
We recognized an income tax expense of $174 million and $327 million for the third quarter and first nine months of fiscal year 2022, respectively, and an income tax expense of $12 million and $64 million for the third quarter and first nine months of fiscal year 2021, respectively. The income tax expense as a percentage of income before income tax was 6.6% and 4.6% for the third quarter and first nine months of fiscal year 2022, respectively, and 0.9% and 2.2% for the third quarter and first nine months of fiscal year 2021, respectively.

[0001045810-21-000163:notes:48]
[same as prior period, unchanged from 0001045810-21-000131:notes:42]

[0001045810-21-000163:notes:49]
The increase in our effective tax rate for the third quarter and first nine months of fiscal year 2022 as compared to the same periods of fiscal year 2021 was primarily due to an increase in the amount of earnings subject to U.S. tax, and a decreased impact of tax benefits from stock-based compensation and the U.S. federal research tax credit, partially offset, for the first nine months, by the discrete benefit of the Domestication.

[0001045810-21-000163:notes:50]
Our effective tax rate for the first nine months of fiscal year 2021 was lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit, and tax benefits related to stock-based compensation.

[0001045810-21-000163:notes:51]
Our effective tax rate for the first nine months of fiscal year 2022 was lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, the discrete benefit of the Domestication, and tax benefits related to stock-based compensation and the U.S. federal research tax credit.

[0001045810-21-000163:notes:52]
As of October 31, 2021, we intend to indefinitely reinvest approximately $1.7 billion and $231 million of cumulative undistributed earnings held by certain subsidiaries in Israel and the United Kingdom, respectively. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to these investments as the determination of such amount is not practicable.

[0001045810-21-000163:notes:53]
For the first nine months of fiscal year 2022, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 31, 2021.
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 31, 2021, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-21-000163:notes:54]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-21-000163:notes:55]
The following is a summary of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021:

[0001045810-21-000163:notes:56]
|  | October 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,179 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 9,180 |  |  | $ | 135 |  |  | $ | 9,045 |  |
| Debt securities issued by the United States Treasury | 4,887 |  |  | — |  |  | (2) |  |  | 4,885 |  |  | 195 |  |  | 4,690 |  |
| Debt securities issued by United States government agencies | 2,861 |  |  | — |  |  | — |  |  | 2,861 |  |  | 307 |  |  | 2,554 |  |
| Certificates of deposit | 1,512 |  |  | — |  |  | — |  |  | 1,512 |  |  | 32 |  |  | 1,480 |  |
| Money market funds | 360 |  |  | — |  |  | — |  |  | 360 |  |  | 360 |  |  | — |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,040 |  |  | $ | 2 |  |  | $ | (3) |  |  | $ | 19,039 |  |  | $ | 1,029 |  |  | $ | 18,010 |  |

[0001045810-21-000163:notes:57]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

[0001045810-21-000163:notes:58]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-21-000163:notes:59]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021 are shown below by contractual maturity.

[0001045810-21-000163:notes:60]
|  | October 31, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,243 |  |  | $ | 16,244 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 2,797 |  |  | 2,795 |  |  | 566 |  |  | 568 |  |
| Total | $ | 19,040 |  |  | $ | 19,039 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-21-000163:notes:61]
[same as prior period, unchanged from 0001045810-21-000131:notes:56]

[0001045810-21-000163:notes:62]
|  |  | Fair Value at |
|  | Pricing Category |  | October 31, 2021 |  | January 31, 2021 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 360 |  |  | $ | 313 |  |
| Corporate debt securities | Level 2 |  | $ | 9,180 |  |  | $ | 4,444 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 4,885 |  |  | $ | 2,846 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 2,861 |  |  | $ | 2,976 |  |
| Certificates of deposit | Level 2 |  | $ | 1,512 |  |  | $ | 705 |  |
| Foreign government bonds | Level 2 |  | $ | 241 |  |  | $ | 67 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity security (1) | Level 1 |  | $ | 136 |  |  | $ | — |  |
| Privately-held equity securities | Level 3 |  | $ | 172 |  |  | $ | 144 |  |
| Liabilities (2) |  |  |  |  |  |
| 2.20% Notes Due 2021 | Level 2 |  | $ | — |  |  | $ | 1,011 |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,247 |  |  | $ | — |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,244 |  |  | $ | — |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 1,086 |  |  | $ | 1,124 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,233 |  |  | $ | — |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,597 |  |  | $ | 1,654 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,239 |  |  | $ | — |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 1,118 |  |  | $ | 1,152 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 2,285 |  |  | $ | 2,308 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 594 |  |  | $ | 602 |  |

[0001045810-21-000163:notes:63]
(1)    Unrealized gains of $8 million and $126 million from an investment in a publicly-traded equity security were recorded in other income (expense), net, in the third quarter and first nine months of fiscal year 2022, respectively.

[0001045810-21-000163:notes:64]
(2)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-21-000163:notes:65]
[same as prior period, unchanged from 0001045810-21-000131:notes:62]

[0001045810-21-000163:notes:66]
|  | October 31, 2021 |  | January 31, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,396 |  |  | $ | (1,166) |  |  | $ | 2,230 |  |  | $ | 3,280 |  |  | $ | (774) |  |  | $ | 2,506 |  |
| Patents and licensed technology | 709 |  |  | (485) |  |  | 224 |  |  | 706 |  |  | (475) |  |  | 231 |  |
| Total intangible assets | $ | 4,105 |  |  | $ | (1,651) |  |  | $ | 2,454 |  |  | $ | 3,986 |  |  | $ | (1,249) |  |  | $ | 2,737 |  |

[0001045810-21-000163:notes:67]
(1)    As of October 31, 2021, acquisition-related intangible assets include the fair value of a Mellanox in-process research and development project of $630 million, which has not yet commenced amortization.

[0001045810-21-000163:notes:68]
Amortization expense associated with intangible assets was $143 million and $418 million for the third quarter and first nine months of fiscal year 2022, respectively, and $174 million and $465 million for the third quarter and first nine months of fiscal year 2021, respectively. Future amortization expense related to the net carrying amount of intangible assets, excluding in-process research and development, as of October 31, 2021 is estimated to be $145 million for the remainder of fiscal year 2022, $576 million in fiscal year 2023, $453 million in fiscal year 2024, $400 million in fiscal year 2025, $117 million in fiscal year 2026, and $133 million in fiscal year 2027 and thereafter.
In both the third quarter and first nine months of fiscal year 2022, goodwill increased by $109 million and intangible assets increased by $119 million from acquisitions. We assigned $96 million of the increase in goodwill to our Compute & Networking segment and assigned $13 million of the increase to our Graphics segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-21-000163:notes:69]
[same as prior period, unchanged from 0001045810-21-000131:notes:66]

[0001045810-21-000163:notes:70]
|  | October 31, |  | January 31, |
|  | 2021 |  | 2021 |
| Inventories: | (In millions) |
| Raw materials | $ | 755 |  |  | $ | 632 |  |
| Work in-process | 538 |  |  | 457 |  |
| Finished goods | 940 |  |  | 737 |  |
| Total inventories | $ | 2,233 |  |  | $ | 1,826 |  |

[0001045810-21-000163:notes:71]
|  | October 31, |  | January 31, |
|  | 2021 |  | 2021 |
| Other assets: | (In millions) |
| Prepaid supply agreements | $ | 1,606 |  |  | $ | — |  |
| Advanced consideration for acquisition | 1,357 |  |  | 1,357 |  |
| Prepaid royalties | 416 |  |  | 440 |  |
| Investment in non-affiliated entities | 308 |  |  | 144 |  |
| Deposits | 22 |  |  | 136 |  |
| Other | 52 |  |  | 67 |  |
| Total other assets | $ | 3,761 |  |  | $ | 2,144 |  |

[0001045810-21-000163:notes:72]
|  | October 31, |  | January 31, |
|  | 2021 |  | 2021 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 857 |  |  | $ | 630 |  |
| Deferred revenue (1) | 298 |  |  | 288 |  |
| Accrued payroll and related expenses | 295 |  |  | 297 |  |
| Operating leases | 140 |  |  | 121 |  |
| Licenses and royalties | 108 |  |  | 128 |  |
| Product warranty and return provisions | 45 |  |  | 39 |  |
| Coupon interest on debt obligations | 37 |  |  | 74 |  |
| Taxes payable | 36 |  |  | 61 |  |
| Professional service fees | 30 |  |  | 26 |  |
| Other | 102 |  |  | 61 |  |
| Total accrued and other current liabilities | $ | 1,948 |  |  | $ | 1,725 |  |

[0001045810-21-000163:notes:73]
[same as prior period, unchanged from 0001045810-21-000131:notes:71]

[0001045810-21-000163:notes:74]
|  | October 31, |  | January 31, |
|  | 2021 |  | 2021 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,051 |  |  | $ | 836 |  |
| Deferred income tax | 225 |  |  | 241 |  |
| Deferred revenue (2) | 191 |  |  | 163 |  |
| Employee benefits | 38 |  |  | 33 |  |
| Licenses payable | 21 |  |  | 56 |  |
| Other | 9 |  |  | 46 |  |
| Total other long-term liabilities | $ | 1,535 |  |  | $ | 1,375 |  |

[0001045810-21-000163:notes:75]
(1)    As of October 31, 2021, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, unrecognized tax benefits of $578 million, related interest and penalties of $60 million, and other foreign long-term tax payable of $162 million.

[0001045810-21-000163:notes:76]
[same as prior period, unchanged from 0001045810-21-000131:notes:74]

[0001045810-21-000163:notes:77]
[same as prior period, unchanged from 0001045810-21-000131:notes:75]

[0001045810-21-000163:notes:78]
The following table shows the changes in deferred revenue during the first nine months of fiscal years 2022 and 2021:

[0001045810-21-000163:notes:79]
|  | October 31, |  | October 25, |
|  | 2021 |  | 2020 |
|  | (In millions) |
| Balance at beginning of period | $ | 451 |  |  | $ | 201 |  |
| Deferred revenue added during the period | 621 |  |  | 361 |  |
| Addition due to business combinations | — |  |  | 75 |  |
| Revenue recognized during the period | (583) |  |  | (255) |  |
| Balance at end of period | $ | 489 |  |  | $ | 382 |  |

[0001045810-21-000163:notes:80]
Revenue related to remaining performance obligations represents the contracted license, development arrangements and PCS that has not been recognized. This includes deferred revenue currently recorded and amounts that will be invoiced in future periods. As of October 31, 2021, $620 million of revenue related to performance obligations had not been recognized, of which we expect to recognize approximately 49% over the next 12 months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-21-000163:notes:81]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of October 31, 2021 and January 31, 2021.

[0001045810-21-000163:notes:82]
[same as prior period, unchanged from 0001045810-21-000131:notes:80]

[0001045810-21-000163:notes:83]
The table below presents the notional value of our foreign currency forward contracts outstanding as of October 31, 2021 and January 31, 2021:

[0001045810-21-000163:notes:84]
|  | October 31,2021 |  | January 31,2021 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 949 |  |  | $ | 840 |  |
| Not designated for hedge accounting | $ | 430 |  |  | $ | 441 |  |

[0001045810-21-000163:notes:85]
As of October 31, 2021, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next 12 months was not significant.

[0001045810-21-000163:notes:86]
During the first nine months of fiscal years 2022 and 2021, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant.


## us-gaap:DebtDisclosureTextBlock

[0001045810-21-000163:notes:87]
Debt
Long-Term Debt

[0001045810-21-000163:notes:88]
In June 2021, we issued $1.25 billion of the 0.309% Notes Due 2023, $1.25 billion of the 0.584% Notes Due 2024, $1.25 billion of the 1.55% Notes Due 2028, and $1.25 billion of the 2.00% Notes Due 2031, or collectively, the June 2021 Notes. Interest on the 0.584% Notes Due 2024 is payable on June 14 and December 14 of each year, beginning on

[0001045810-21-000163:notes:89]
December 14, 2021. Interest on all other series of the June 2021 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2021. We may redeem the June 2021 Notes for cash prior to maturity. However, no make-whole premium will be paid for redemptions of the Notes Due 2023 on or after June 15, 2022, the Notes Due 2024 on or after June 14, 2023, the Notes Due 2028 on or after April 15, 2028, or the Notes Due 2031 on or after March 15, 2031. The net proceeds from the June 2021 Notes were $4.98 billion, after deducting debt discount and issuance costs.

[0001045810-21-000163:notes:90]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year.

[0001045810-21-000163:notes:91]
On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021. Interest on the $1.00 billion of the 3.20% Notes Due 2026, or September 2016 Notes, is payable on March 16 and September 16 of each year.

[0001045810-21-000163:notes:92]
The September 2016 Notes, the March 2020 Notes, and the June 2021 Notes, or collectively, the Notes, are our unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-21-000163:notes:93]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-21-000163:notes:94]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 31, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | — |  | 2.38% |  | $ | — |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.6 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.6 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 4.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.6 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.6 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (56) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 10,944 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,944 |  |  | $ | 5,964 |  |

[0001045810-21-000163:notes:95]
As of October 31, 2021, we were in compliance with the required covenants under the Notes.

[0001045810-21-000163:notes:96]
Commercial Paper

[0001045810-21-000163:notes:97]
We have a $575 million commercial paper program to support general corporate purposes. As of October 31, 2021, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-21-000163:notes:98]
Commitments and Contingencies
Purchase Obligations

[0001045810-21-000163:notes:99]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-21-000163:notes:100]
We recently entered into several long-term supply agreements, under which we have made advance payments and have $1.79 billion remaining unpaid. As of October 31, 2021, we had outstanding inventory purchase and long-term supply obligations totaling $6.90 billion, inclusive of the $1.79 billion, and other purchase obligations totaling $935 million.

[0001045810-21-000163:notes:101]
Total future unconditional purchase commitments as of October 31, 2021, are as follows:

[0001045810-21-000163:notes:102]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 (excluding first nine months of fiscal year 2022) | $ | 2,944 |  |
| 2023 | 4,637 |  |
| 2024 | 172 |  |
| 2025 | 52 |  |
| 2026 | 28 |  |
| Total | $ | 7,833 |  |

[0001045810-21-000163:notes:103]
Accrual for Product Warranty Liabilities

[0001045810-21-000163:notes:104]
The estimated amount of product warranty liabilities was $32 million and $22 million as of October 31, 2021 and January 31, 2021, respectively, and the activities were not significant.

[0001045810-21-000163:notes:105]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-21-000163:notes:106]
Litigation

[0001045810-21-000163:notes:107]
Securities Class Action and Derivative Lawsuits

[0001045810-21-000163:notes:108]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On August 11, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.

[0001045810-21-000163:notes:109]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-21-000163:notes:110]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-

[0001045810-21-000163:notes:111]
cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-21-000163:notes:112]
Accounting for Loss Contingencies

[0001045810-21-000163:notes:113]
As of October 31, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-21-000163:notes:114]
[same as prior period, unchanged from 0001045810-21-000131:notes:109]

[0001045810-21-000163:notes:115]
[same as prior period, unchanged from 0001045810-21-000131:notes:110]

[0001045810-21-000163:notes:116]
Through October 31, 2021, we have repurchased an aggregate of 1.04 billion shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of October 31, 2021, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022.

[0001045810-21-000163:notes:117]
During the third quarter and first nine months of fiscal year 2022, we paid $100 million and $298 million in cash dividends to our shareholders, respectively. During the third quarter and first nine months of fiscal year 2021, we paid $99 million and $296 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-21-000163:notes:118]
[same as prior period, unchanged from 0001045810-21-000131:notes:113]

[0001045810-21-000163:notes:119]
[same as prior period, unchanged from 0001045810-21-000131:notes:114]

[0001045810-21-000163:notes:120]
Our Compute & Networking segment includes Data Center platforms and systems for artificial intelligence, or AI, high performance computing, or HPC, and accelerated computing; networking and interconnect solutions; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; cryptocurrency mining processors, or CMP; and Jetson for robotics and other embedded platforms.

[0001045810-21-000163:notes:121]
[same as prior period, unchanged from 0001045810-21-000131:notes:116]

[0001045810-21-000163:notes:122]
[same as prior period, unchanged from 0001045810-21-000131:notes:117]

[0001045810-21-000163:notes:123]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the

[0001045810-21-000163:notes:124]
same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-21-000163:notes:125]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 31, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 4,092 |  |  | $ | 3,011 |  |  | $ | — |  |  | $ | 7,103 |  |
| Operating income (loss) | $ | 2,160 |  |  | $ | 1,332 |  |  | $ | (821) |  |  | $ | 2,671 |  |
| Three Months Ended October 25, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 2,787 |  |  | $ | 1,939 |  |  | $ | — |  |  | $ | 4,726 |  |
| Operating income (loss) | $ | 1,345 |  |  | $ | 738 |  |  | $ | (685) |  |  | $ | 1,398 |  |
| Nine Months Ended October 31, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 11,450 |  |  | $ | 7,821 |  |  | $ | — |  |  | $ | 19,271 |  |
| Operating income (loss) | $ | 6,073 |  |  | $ | 3,227 |  |  | $ | (2,229) |  |  | $ | 7,071 |  |
| Nine Months Ended October 25, 2020 |  |  |  |  |  |  |  |
| Revenue | $ | 6,778 |  |  | $ | 4,894 |  |  | $ | — |  |  | $ | 11,672 |  |
| Operating income (loss) | $ | 3,092 |  |  | $ | 1,880 |  |  | $ | (1,947) |  |  | $ | 3,025 |  |

[0001045810-21-000163:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31,2021 |  | October 25,2020 |  | October 31,2021 |  | October 25,2020 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (559) |  |  | $ | (383) |  |  | $ | (1,453) |  |  | $ | (981) |  |
| Acquisition-related and other costs | (156) |  |  | (192) |  |  | (482) |  |  | (669) |  |
| Unallocated cost of revenue and operating expenses | (106) |  |  | (89) |  |  | (286) |  |  | (259) |  |
| IP-related costs | — |  |  | (21) |  |  | (8) |  |  | (38) |  |
| Total | $ | (821) |  |  | $ | (685) |  |  | $ | (2,229) |  |  | $ | (1,947) |  |

[0001045810-21-000163:notes:127]
[same as prior period, unchanged from 0001045810-21-000131:notes:121]

[0001045810-21-000163:notes:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, |  | October 25, |  | October 31, |  | October 25, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 2,187 |  |  | $ | 1,296 |  |  | $ | 5,932 |  |  | $ | 3,062 |  |
| China (including Hong Kong) | 2,017 |  |  | 1,113 |  |  | 5,128 |  |  | 2,727 |  |
| Other Asia Pacific | 1,067 |  |  | 955 |  |  | 3,115 |  |  | 2,260 |  |
| United States | 1,126 |  |  | 890 |  |  | 2,890 |  |  | 2,331 |  |
| Europe | 340 |  |  | 247 |  |  | 1,150 |  |  | 741 |  |
| Other countries | 366 |  |  | 225 |  |  | 1,056 |  |  | 551 |  |
| Total revenue | $ | 7,103 |  |  | $ | 4,726 |  |  | $ | 19,271 |  |  | $ | 11,672 |  |

[0001045810-21-000163:notes:129]
[same as prior period, unchanged from 0001045810-21-000131:notes:123]

[0001045810-21-000163:notes:130]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, |  | October 25, |  | October 31, |  | October 25, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 3,221 |  |  | $ | 2,271 |  |  | $ | 9,042 |  |  | $ | 5,264 |  |
| Data Center | 2,936 |  |  | 1,900 |  |  | 7,350 |  |  | 4,793 |  |
| Professional Visualization | 577 |  |  | 236 |  |  | 1,468 |  |  | 746 |  |
| Automotive | 135 |  |  | 125 |  |  | 441 |  |  | 391 |  |
| OEM and Other | 234 |  |  | 194 |  |  | 970 |  |  | 478 |  |
| Total revenue | $ | 7,103 |  |  | $ | 4,726 |  |  | $ | 19,271 |  |  | $ | 11,672 |  |

[0001045810-21-000163:notes:131]
No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal years 2022 or 2021.

[0001045810-21-000163:notes:132]
One customer represented 14% and 16% of our accounts receivable balance as of October 31, 2021 and January 31, 2021, respectively.
