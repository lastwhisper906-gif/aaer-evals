# NVDA MD&A — 0001045810-21-000163


## mdna

[0001045810-21-000163:mdna:1]
[same as prior period, unchanged from 0001045810-21-000131:mdna:1]

[0001045810-21-000163:mdna:2]
[same as prior period, unchanged from 0001045810-21-000131:mdna:2]

[0001045810-21-000163:mdna:3]
[same as prior period, unchanged from 0001045810-21-000131:mdna:3]

[0001045810-21-000163:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, Mellanox, NVIDIA AI Enterprise, NVIDIA Clara, NVIDIA DRIVE Orin,  NVIDIA Jetson AGX Orin, NVIDIA Omniverse, NVIDIA ReOpt, NVIDIA RTX, NVIDIA Triton Inference Server and Quadro, are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000163:mdna:5]
[same as prior period, unchanged from 0001045810-21-000131:mdna:5]

[0001045810-21-000163:mdna:6]
[same as prior period, unchanged from 0001045810-21-000131:mdna:6]

[0001045810-21-000163:mdna:7]
[same as prior period, unchanged from 0001045810-21-000131:mdna:7]

[0001045810-21-000163:mdna:8]
[same as prior period, unchanged from 0001045810-21-000131:mdna:8]

[0001045810-21-000163:mdna:9]
[same as prior period, unchanged from 0001045810-21-000131:mdna:9]

[0001045810-21-000163:mdna:10]
[same as prior period, unchanged from 0001045810-21-000131:mdna:10]

[0001045810-21-000163:mdna:11]
[same as prior period, unchanged from 0001045810-21-000131:mdna:11]

[0001045810-21-000163:mdna:12]
[same as prior period, unchanged from 0001045810-21-000131:mdna:12]

[0001045810-21-000163:mdna:13]
On September 13, 2020, we entered into the Purchase Agreement with Arm and SoftBank to acquire, from SoftBank, all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid the Signing Consideration, and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 177.5 million shares of our common

[0001045810-21-000163:mdna:14]
[same as prior period, unchanged from 0001045810-21-000131:mdna:14]

[0001045810-21-000163:mdna:15]
stock, which had an aggregate value of $21.5 billion as of the date of the Purchase Agreement, and was valued at $56.2 billion as of November 18, 2021. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial targets are achieved, SoftBank can elect to receive either up to an additional $5 billion in cash or up to an additional 41.3 million shares of our common stock, which was valued at $13.1 billion as of November 18, 2021. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The Signing Consideration was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The Signing Consideration was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. The Purchase Agreement can be terminated by either party if the transaction has not closed by September 2022, subject to certain qualifications. If the transaction does not close due to failure to receive regulatory approval, and all other covenants have been met, we will not be refunded $1.25 billion of the advanced consideration for the acquisition we paid at signing.

[0001045810-21-000163:mdna:16]
The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and the expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities.

[0001045810-21-000163:mdna:17]
We are seeking regulatory approval in the United States, the United Kingdom, the European Union, China and other jurisdictions. Regulators at the FTC have expressed concerns regarding the transaction, and we are engaged in discussions with the FTC regarding remedies to address those concerns. The transaction has been under the review of China’s antitrust authority, pending the formal case initiation. Regulators in the United Kingdom and the European Union declined to approve the transaction in Phase 1 of their review processes, expressed numerous concerns, began a more in-depth Phase 2 review on the transaction’s impact on competition, and, in the United Kingdom, a Phase 2 review of the impact on the United Kingdom’s national security interests. Although regulators and some Arm licensees have expressed concerns or objected to the transaction, we continue to believe in the merits and benefits of the acquisition to Arm, its licensees, and the industry.

[0001045810-21-000163:mdna:18]
[same as prior period, unchanged from 0001045810-21-000131:mdna:16]

[0001045810-21-000163:mdna:19]
Demand for our products is based on many factors, including our product introductions, time to market, transitions, competitor product releases and announcements, and competing technologies, all of which can impact the timing and volume of our revenue. GPUs have many use cases including their intended marketed use case. GPUs can be used for cryptocurrency mining, though we do not have visibility into how much of our GPU usage is for cryptocurrency mining nor the future demand for GPUs to mine cryptocurrency. Volatility in the cryptocurrency market, including new compute technologies, price changes in cryptocurrencies, changes in government cryptocurrency policies and regulations, and new cryptocurrency standards can impact cryptocurrency demand, and further impact demand for our products and our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the pending Ethereum 2.0 standard may decrease the usage of GPUs for Ethereum mining and may also create increased aftermarket resale of our GPUs, impact retail prices for our GPUs, increase returns of our products in the distribution channel, and may reduce demand for our new GPUs. We have introduced Lite Hash Rate, or LHR, GeForce GPUs with limited Ethereum mining capability. During the third quarter of fiscal year 2022, nearly all our desktop Ampere architecture GeForce GPU shipments were LHR in our effort to direct GeForce to gamers. There have been aftermarket attempts to increase the Ethereum mining capability of our LHR cards. Additionally, consumer and enterprise behavior during the COVID-19 pandemic has made it more difficult for us to estimate future demand, and these challenges may be more pronounced or volatile in the future on both a global and regional basis if and when the effects of the pandemic subside. In estimating demand and evaluating trends, we make multiple assumptions, any of which may prove to be incorrect.

[0001045810-21-000163:mdna:20]
[same as prior period, unchanged from 0001045810-21-000131:mdna:18]

[0001045810-21-000163:mdna:21]
Our products are manufactured based on estimates of customers’ future demand and our manufacturing lead times are very long. This could lead to a significant mismatch between supply and demand, giving rise to product shortages or excess inventory, and make our demand forecast more uncertain. We sell many of our products through a channel model, and our channel customers sell to retailers, distributors, and/or end customers. As a result, the decisions made by our channel partners, retailers, and distributors in response to changing market conditions and the changing demand for our products could impact our ability to properly forecast demand. To have shorter shipment lead times and quicker delivery schedules for our customers, we may build finished products and maintain inventory for anticipated periods of growth which do not occur, anticipating demand that does not materialize, or for what we believe is pent-up demand. We expect to remain supply-constrained into fiscal year 2023. We have placed non-cancellable inventory orders for certain

[0001045810-21-000163:mdna:22]
[same as prior period, unchanged from 0001045810-21-000131:mdna:23]

[0001045810-21-000163:mdna:23]
products in advance of our normal lead times, paid premiums and provided deposits to secure normal and incremental future supply and capacity and may need to continue to do so in the future. Ordering product in advance of our normal lead times to secure supply in a constrained environment may trigger excess inventory or other charges if there is a partial or complete reduction in long term demand for our products or if such demand is served by our competitors. Given our long lead times on inventory purchasing, demand may be perishable or may disappear.

[0001045810-21-000163:mdna:24]
[same as prior period, unchanged from 0001045810-21-000131:mdna:20]

[0001045810-21-000163:mdna:25]
[same as prior period, unchanged from 0001045810-21-000131:mdna:21]

[0001045810-21-000163:mdna:26]
The COVID-19 pandemic continues to evolve and affect our business and financial results. During the third quarter of fiscal year 2022, our Gaming, Data Center and Professional Visualization market platforms have benefited from stronger demand as people continue to work, learn, and play from home. As our own offices begin to reopen, we expect to incur incremental expenses as we resume onsite services and related in-office costs.

[0001045810-21-000163:mdna:27]
As the COVID-19 pandemic continues, the timing and overall demand from customers and the availability of supply chain, rising inflation, logistical services and component supply may have a material net negative impact on our business and financial results.

[0001045810-21-000163:mdna:28]
We believe our existing balances of cash, cash equivalents and marketable securities, along with commercial paper arrangements, will be sufficient to satisfy our working capital needs, capital asset purchases, dividends, debt repayments and other liquidity requirements associated with our existing operations.

[0001045810-21-000163:mdna:29]
Third Quarter of Fiscal Year 2022 Summary

[0001045810-21-000163:mdna:30]
|  | Three Months Ended |  |  |  |  |
|  | October 31, 2021 |  | August 1, 2021 |  | October 25, 2020 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 7,103 |  |  | $ | 6,507 |  |  | $ | 4,726 |  |  | 9 | % |  | 50 | % |
| Gross margin | 65.2 | % |  | 64.8 | % |  | 62.6 | % |  | 40 bps |  | 260 bps |
| Operating expenses | $ | 1,960 |  |  | $ | 1,771 |  |  | $ | 1,562 |  |  | 11 | % |  | 25 | % |
| Income from operations | $ | 2,671 |  |  | $ | 2,444 |  |  | $ | 1,398 |  |  | 9 | % |  | 91 | % |
| Net income | $ | 2,464 |  |  | $ | 2,374 |  |  | $ | 1,336 |  |  | 4 | % |  | 84 | % |
| Net income per diluted share | $ | 0.97 |  |  | $ | 0.94 |  |  | $ | 0.53 |  |  | 3 | % |  | 83 | % |

[0001045810-21-000163:mdna:31]
[same as prior period, unchanged from 0001045810-21-000131:mdna:28]

[0001045810-21-000163:mdna:32]
Revenue for the third quarter of fiscal year 2022 was $7.10 billion, up 50% from a year earlier.

[0001045810-21-000163:mdna:33]
Gaming revenue was up 42% from a year ago and up 5% sequentially, reflecting higher sales of GeForce GPUs. We benefited from strong demand for our NVIDIA Ampere architecture products leading into the holiday season. Nearly all our desktop Ampere architecture GeForce GPU shipments are LHR in our effort to direct GeForce to gamers.

[0001045810-21-000163:mdna:34]
Data Center revenue was up 55% from a year ago and up 24% sequentially, driven by sales of NVIDIA Ampere architecture products to hyperscale customers for cloud computing and workloads such as natural language processing and deep recommender models, as well as to vertical industries.

[0001045810-21-000163:mdna:35]
Professional Visualization revenue was up 144% from a year earlier and up 11% sequentially, driven by NVIDIA Ampere architecture products, with growth in desktop and notebook workstation GPUs as enterprises deploy systems to support hybrid work environments.

[0001045810-21-000163:mdna:36]
Automotive revenue was up 8% from a year earlier and down 11% sequentially. The year-on-year growth was due to the ramp of self-driving programs, while the sequential decline was related to automotive makers’ supply constraints.

[0001045810-21-000163:mdna:37]
OEM and Other revenue was up 21% from a year ago and down 43% sequentially. The year-on-year growth reflects CMP revenue of $105 million this quarter. The sequential decline primarily reflects lower CMP revenue.

[0001045810-21-000163:mdna:38]
GAAP gross margin for the third quarter was up 260 basis points from a year earlier, primarily due to a higher-end mix within desktop and notebook GeForce GPUs. The year-on-year increase also benefited from a reduced impact of acquisition-related costs. Sequentially, gross margin was up 40 basis points primarily due to growth in Data Center, partially offset by a mix shift in Gaming.

[0001045810-21-000163:mdna:39]
Operating expenses for the third quarter were up 25% from a year earlier and up 11% sequentially. The year-on-year increase was primarily driven by compensation-related costs relating to employee growth and higher infrastructure costs. The sequential increase was primarily driven by development materials and employee growth.

[0001045810-21-000163:mdna:40]
Income from operations was $2.67 billion, up 91% from a year earlier and up 9% sequentially. Net income was $2.46 billion. Net income per diluted share was $0.97, up 83% from a year earlier and up 3% sequentially.

[0001045810-21-000163:mdna:41]
Cash, cash equivalents and marketable securities were $19.30 billion, up from $10.14 billion a year earlier and down from $19.65 billion in the prior quarter. The year-on-year increase reflects $5 billion of debt issuance proceeds and operating cash flow generation. The sequential decrease primarily reflects prepayments for long-term supply, $1 billion of debt maturity and business acquisitions.

[0001045810-21-000163:mdna:42]
We paid $100 million in quarterly cash dividends in the third quarter.

[0001045810-21-000163:mdna:43]
[same as prior period, unchanged from 0001045810-21-000131:mdna:41]

[0001045810-21-000163:mdna:44]
At our recent GTC conference, we announced general availability of NVIDIA Omniverse Enterprise; 65 new and updated software development kits, including NVIDIA Riva, Modulus, ReOpt, Morpheus, cuNumeric, and Clara Holoscan; tools for developing and deploying large language models, including NVIDIA NeMo Megatron; new capabilities in the open source NVIDIA Triton Inference Server software; the NVIDIA Quantum-2 400Gbps switch and end-to-end networking platform; and NVIDIA Jetson AGX Orin for edge AI and autonomous machines.

[0001045810-21-000163:mdna:45]
Additionally, in our Gaming platform during the third quarter of fiscal year 2022, we announced RTX capabilities coming to blockbuster titles; announced new RTX-accelerated AI features in Adobe applications; and introduced a new high-performance membership tier to GeForce NOW.

[0001045810-21-000163:mdna:46]
In our Data Center platform, we announced plans to build Earth-2, an AI supercomputer dedicated to addressing the global climate change crisis; announced the availability of NVIDIA AI Enterprise; expanded NVIDIA LaunchPad; and announced further collaboration with VMware to develop an AI-ready enterprise platform based on VMware vSphere with Tanzu.

[0001045810-21-000163:mdna:47]
In our Professional Visualization platform, we announced the general availability of NVIDIA Omniverse Enterprise.

[0001045810-21-000163:mdna:48]
In our Automotive platform, we announced that NVIDIA DRIVE Orin is being used by autonomous truck company Kodiak Robotics, automaker Lotus, autonomous driving-solutions provider QCraft and EV startup WM Motor.

[0001045810-21-000163:mdna:49]
[same as prior period, unchanged from 0001045810-21-000131:mdna:46]

[0001045810-21-000163:mdna:50]
[same as prior period, unchanged from 0001045810-21-000131:mdna:47]

[0001045810-21-000163:mdna:51]
[same as prior period, unchanged from 0001045810-21-000131:mdna:48]

[0001045810-21-000163:mdna:52]
[same as prior period, unchanged from 0001045810-21-000131:mdna:49]

[0001045810-21-000163:mdna:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31,2021 |  | October 25,2020 |  | October 31,2021 |  | October 25,2020 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 34.8 |  |  | 37.4 |  |  | 35.3 |  |  | 38.0 |  |
| Gross profit | 65.2 |  |  | 62.6 |  |  | 64.7 |  |  | 62.0 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 19.8 |  |  | 22.2 |  |  | 19.7 |  |  | 23.8 |  |
| Sales, general and administrative | 7.8 |  |  | 10.9 |  |  | 8.3 |  |  | 12.3 |  |
| Total operating expenses | 27.6 |  |  | 33.1 |  |  | 28.0 |  |  | 36.1 |  |
| Income from operations | 37.6 |  |  | 29.5 |  |  | 36.7 |  |  | 25.9 |  |
| Interest income | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.4 |  |
| Interest expense | (0.9) |  |  | (1.1) |  |  | (0.9) |  |  | (1.1) |  |
| Other, net | 0.3 |  |  | (0.1) |  |  | 0.8 |  |  | — |  |
| Other income (expense), net | (0.5) |  |  | (1.1) |  |  | — |  |  | (0.7) |  |
| Income before income tax | 37.1 |  |  | 28.4 |  |  | 36.7 |  |  | 25.2 |  |
| Income tax expense | 2.4 |  |  | 0.3 |  |  | 1.7 |  |  | 0.5 |  |
| Net income | 34.7 | % |  | 28.1 | % |  | 35.0 | % |  | 24.7 | % |

[0001045810-21-000163:mdna:54]
[same as prior period, unchanged from 0001045810-21-000131:mdna:51]

[0001045810-21-000163:mdna:55]
[same as prior period, unchanged from 0001045810-21-000131:mdna:52]

[0001045810-21-000163:mdna:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31,2021 |  | October 25,2020 |  | $Change |  | %Change |  | October 31,2021 |  | October 25,2020 |  | $Change |  | %Change |
|  | ($ in millions) |
| Graphics | $ | 4,092 |  |  | $ | 2,787 |  |  | $ | 1,305 |  |  | 47 | % |  | $ | 11,450 |  |  | $ | 6,778 |  |  | $ | 4,672 |  |  | 69 | % |
| Compute & Networking | 3,011 |  |  | 1,939 |  |  | 1,072 |  |  | 55 | % |  | 7,821 |  |  | 4,894 |  |  | 2,927 |  |  | 60 | % |
| Total | $ | 7,103 |  |  | $ | 4,726 |  |  | $ | 2,377 |  |  | 50 | % |  | $ | 19,271 |  |  | $ | 11,672 |  |  | $ | 7,599 |  |  | 65 | % |

[0001045810-21-000163:mdna:57]
Graphics - Graphics segment revenue increased 47% in the third quarter of fiscal year 2022 compared to the third quarter of fiscal year 2021 and 69% in the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021, reflecting strong demand for our NVIDIA Ampere architecture products. Additionally, revenue increased from growth in desktop and mobile workstation GPUs.

[0001045810-21-000163:mdna:58]
Compute & Networking - Compute & Networking segment revenue increased 55% for the third quarter of fiscal year 2022 compared to the third quarter of fiscal year 2021 and 60% in the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021. Year-on-year growth in the third quarter was driven by sales of NVIDIA Ampere architecture products to vertical industries, and to hyperscale customers for cloud computing and workloads such as natural language processing and deep recommender models. The increase in the first nine months of fiscal year 2022 also reflects the addition of Mellanox, which we acquired on April 27, 2020, and CMP products.

[0001045810-21-000163:mdna:59]
[same as prior period, unchanged from 0001045810-21-000131:mdna:57]

[0001045810-21-000163:mdna:60]
Revenue from sales to customers outside of the United States accounted for 84% and 85% of total revenue for the third quarter and first nine months of fiscal year 2022, respectively, and 81% and 80% of total revenue for the third quarter

[0001045810-21-000163:mdna:61]
[same as prior period, unchanged from 0001045810-21-000131:mdna:56]

[0001045810-21-000163:mdna:62]
and first nine months of fiscal year 2021, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-21-000163:mdna:63]
No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal years 2022 or 2021.

[0001045810-21-000163:mdna:64]
[same as prior period, unchanged from 0001045810-21-000131:mdna:60]

[0001045810-21-000163:mdna:65]
Our overall gross margin increased to 65.2% and 64.7% for the third quarter and first nine months of fiscal year 2022, respectively, from 62.6% and 62.0% for the third quarter and first nine months of fiscal year 2021, respectively. The year-on-year increase in the third quarter was primarily due to a higher-end mix within desktop and notebook GeForce GPUs, reflecting strong demand for our Ampere architecture. The increase in the first nine months was primarily due to a higher-end mix within desktop and notebook GeForce GPUs, partially offset by a mix shift within the Compute & Networking segment. These increases also benefited from a reduced impact of acquisition-related costs.

[0001045810-21-000163:mdna:66]
Inventory provisions totaled $107 million and $15 million for the third quarter of fiscal years 2022 and 2021, respectively. Sales of inventory that was previously written-off or -down totaled $48 million and $29 million for the third quarter of fiscal years 2022 and 2021, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.8% and a favorable impact of 0.3% in the third quarter of fiscal years 2022 and 2021, respectively.

[0001045810-21-000163:mdna:67]
Inventory provisions totaled $238 million and $96 million for the first nine months of fiscal years 2022 and 2021, respectively. Sales of inventory that was previously written-off or -down totaled $89 million and $116 million for the first nine months of fiscal years 2022 and 2021, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.8% and a favorable impact of 0.2% in the first nine months of fiscal years 2022 and 2021, respectively.

[0001045810-21-000163:mdna:68]
[same as prior period, unchanged from 0001045810-21-000131:mdna:64]

[0001045810-21-000163:mdna:69]
Graphics - The gross margin of our Graphics segment increased during the third quarter and first nine months of fiscal year 2022 compared to the third quarter and first nine months of fiscal year 2021, primarily due to a higher-end mix within desktop and notebook GeForce GPUs.

[0001045810-21-000163:mdna:70]
Compute & Networking - The gross margin of our Compute & Networking segment increased during the third quarter of fiscal year 2022 compared to the third quarter of fiscal year 2021 due to higher average selling prices of our compute products, partially offset by product mix. The gross margin of our Compute & Networking segment decreased during the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021, primarily due to a shift in product mix, partially offset by higher average selling prices of our compute products and a reduced contribution from Automotive solutions.

[0001045810-21-000163:mdna:71]
[same as prior period, unchanged from 0001045810-21-000131:mdna:67]

[0001045810-21-000163:mdna:72]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31,2021 |  | October 25,2020 |  | $Change |  | %Change |  | October 31,2021 |  | October 25,2020 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 1,403 |  |  | $ | 1,047 |  |  | $ | 356 |  |  | 34 | % |  | $ | 3,802 |  |  | $ | 2,778 |  |  | $ | 1,024 |  |  | 37 | % |
| % of net revenue | 20 | % |  | 22 | % |  |  |  |  |  | 20 | % |  | 24 | % |  |  |  |  |
| Sales, general and administrative expenses | 557 |  |  | 515 |  |  | 42 |  |  | 8 | % |  | 1,603 |  |  | 1,437 |  |  | 166 |  |  | 12 | % |
| % of net revenue | 8 | % |  | 11 | % |  |  |  |  |  | 8 | % |  | 12 | % |  |  |  |  |
| Total operating expenses | $ | 1,960 |  |  | $ | 1,562 |  |  | $ | 398 |  |  | 25 | % |  | $ | 5,405 |  |  | $ | 4,215 |  |  | $ | 1,190 |  |  | 28 | % |

[0001045810-21-000163:mdna:73]
[same as prior period, unchanged from 0001045810-21-000131:mdna:69]

[0001045810-21-000163:mdna:74]
Research and development expenses increased by 34% during the third quarter of fiscal year 2022 compared to the third quarter of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation, and infrastructure costs.

[0001045810-21-000163:mdna:75]
Research and development expenses increased by 37% during the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation, infrastructure costs, and the acquisition of Mellanox.

[0001045810-21-000163:mdna:76]
[same as prior period, unchanged from 0001045810-21-000131:mdna:72]

[0001045810-21-000163:mdna:77]
Sales, general and administrative expenses increased by 8% during the third quarter of fiscal year 2022 compared to the third quarter of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation, partially offset by lower amortization of intangible assets.

[0001045810-21-000163:mdna:78]
Sales, general and administrative expenses increased by 12% during the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021, primarily driven by employee additions and higher employee compensation, including stock-based compensation, the acquisition of Mellanox, partially offset by lower amortization of intangible assets.

[0001045810-21-000163:mdna:79]
[same as prior period, unchanged from 0001045810-21-000131:mdna:75]

[0001045810-21-000163:mdna:80]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $7 million for both the third quarters of fiscal years 2022 and 2021, and $20 million and $50 million during the first nine months of fiscal years 2022 and 2021, respectively. The decrease in interest income was primarily due to lower interest rates earned on our investments.

[0001045810-21-000163:mdna:81]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our September 2016 Notes, March 2020 Notes, and June 2021 Notes. Interest expense was $62 million and $53 million during the third quarter of fiscal years 2022 and 2021, respectively, and $175 million and $131 million during the first nine months of fiscal years 2022 and 2021, respectively.

[0001045810-21-000163:mdna:82]
Other, net, consists primarily of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. Other, net, was an income of $22 million and $160 million during the third quarter and first nine months of fiscal year 2022, respectively, and not significant during the third quarter and first nine months of fiscal year 2021. The increase during the third quarter and first nine months of fiscal year 2022 was primarily due to unrealized gains from our investments in non-affiliated entities. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information regarding our investments in non-affiliated entities.

[0001045810-21-000163:mdna:83]
[same as prior period, unchanged from 0001045810-21-000131:mdna:79]

[0001045810-21-000163:mdna:84]
We recognized an income tax expense of $174 million and $327 million for the third quarter and first nine months of fiscal year 2022, respectively, and an income tax expense of $12 million and $64 million for the third quarter and first nine months of fiscal year 2021, respectively. The income tax expense as a percentage of income before income tax was 6.6% and 4.6% for the third quarter and first nine months of fiscal year 2022, respectively, and 0.9% and 2.2% for the third quarter and first nine months of fiscal year 2021, respectively.

[0001045810-21-000163:mdna:85]
The increase in our effective tax rate for the third quarter and first nine months of fiscal year 2022 as compared to the same periods of fiscal year 2021 was primarily due to an increase in the amount of earnings subject to U.S. tax, and a decreased impact of tax benefits from stock-based compensation and the U.S. federal research tax credit, partially offset, for the first nine months, by the discrete benefit of the Domestication. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information, including the Domestication.

[0001045810-21-000163:mdna:86]
[same as prior period, unchanged from 0001045810-21-000131:mdna:82]

[0001045810-21-000163:mdna:87]
|  | October 31, 2021 |  | January 31, 2021 |
|  | (In millions) |
| Cash and cash equivalents | $ | 1,288 |  |  | $ | 847 |  |
| Marketable securities | 18,010 |  |  | 10,714 |  |
| Cash, cash equivalents and marketable securities | $ | 19,298 |  |  | $ | 11,561 |  |

[0001045810-21-000163:mdna:88]
|  | Nine Months Ended |
|  | October 31, 2021 |  | October 25, 2020 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 6,075 |  |  | $ | 3,755 |  |
| Net cash used in investing activities | $ | (8,244) |  |  | $ | (16,546) |  |
| Net cash provided by financing activities | $ | 2,610 |  |  | $ | 4,146 |  |

[0001045810-21-000163:mdna:89]
As of October 31, 2021, we had $19.30 billion in cash, cash equivalents and marketable securities, an increase of $7.74 billion from the end of fiscal year 2021. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-21-000163:mdna:90]
Cash provided by operating activities increased in the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021, due to higher net income, partially offset by changes in working capital. Changes in working capital were primarily driven by prepayments of $1.65 billion for long-term supply agreements and increases in trade receivables due to higher revenue.

[0001045810-21-000163:mdna:91]
Cash used in investing activities decreased in the first nine months of fiscal year 2022 compared to cash used in the first nine months of fiscal year 2021, primarily driven by the acquisition of Mellanox in the second quarter of fiscal year 2021, and higher marketable securities sales and maturities, partially offset by higher purchases of marketable securities.

[0001045810-21-000163:mdna:92]
Cash provided by financing activities decreased in the first nine months of fiscal year 2022 compared to cash provided in the first nine months of fiscal year 2021, which primarily reflects a debt repayment in the third quarter of fiscal year 2022 and higher tax payments on restricted stock units.

[0001045810-21-000163:mdna:93]
[same as prior period, unchanged from 0001045810-21-000131:mdna:90]

[0001045810-21-000163:mdna:94]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of October 31, 2021, we had $19.30 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of certificates of deposits and debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next 12 months, and for the foreseeable future, including our proposed acquisition of Arm and current and future obligations to secure normal and incremental supply. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance our future capital requirements.

[0001045810-21-000163:mdna:95]
We have approximately $1.9 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S. Other than that, substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of October 31, 2021 are available for use in the U.S. without incurring additional U.S. federal income taxes. Following the Domestication, we expect to fully utilize our accumulated U.S. federal research tax credits during fiscal year 2022, resulting in higher cash tax payments starting in fiscal year 2023.

[0001045810-21-000163:mdna:96]
[same as prior period, unchanged from 0001045810-21-000131:mdna:93]

[0001045810-21-000163:mdna:97]
In the first nine months of fiscal year 2022, we paid $298 million in quarterly cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to the continuing determination by our Board of Directors that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-21-000163:mdna:98]
As of October 31, 2021, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.24 billion through December 2022. We did not repurchase any shares during the first nine months of fiscal year 2022.

[0001045810-21-000163:mdna:99]
Outstanding Indebtedness and Commercial Paper

[0001045810-21-000163:mdna:100]
As of October 31, 2021, we had outstanding:

[0001045810-21-000163:mdna:101]
[same as prior period, unchanged from 0001045810-21-000131:mdna:99]

[0001045810-21-000163:mdna:102]
[same as prior period, unchanged from 0001045810-21-000131:mdna:100]

[0001045810-21-000163:mdna:103]
[same as prior period, unchanged from 0001045810-21-000131:mdna:101]

[0001045810-21-000163:mdna:104]
[same as prior period, unchanged from 0001045810-21-000131:mdna:102]

[0001045810-21-000163:mdna:105]
[same as prior period, unchanged from 0001045810-21-000131:mdna:103]

[0001045810-21-000163:mdna:106]
[same as prior period, unchanged from 0001045810-21-000131:mdna:104]

[0001045810-21-000163:mdna:107]
[same as prior period, unchanged from 0001045810-21-000131:mdna:105]

[0001045810-21-000163:mdna:108]
[same as prior period, unchanged from 0001045810-21-000131:mdna:106]

[0001045810-21-000163:mdna:109]
[same as prior period, unchanged from 0001045810-21-000131:mdna:107]

[0001045810-21-000163:mdna:110]
[same as prior period, unchanged from 0001045810-21-000131:mdna:108]

[0001045810-21-000163:mdna:111]
We have a $575 million commercial paper program to support general corporate purposes. As of October 31, 2021, we had not issued any commercial paper.

[0001045810-21-000163:mdna:112]
[same as prior period, unchanged from 0001045810-21-000131:mdna:111]

[0001045810-21-000163:mdna:113]
We have $163 million of long-term tax liabilities related to tax basis differences in Mellanox and unrecognized tax benefits of $638 million, which includes related interest and penalties of $60 million recorded in non-current income tax payable as of October 31, 2021. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-21-000163:mdna:114]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 31, 2021 for a description of our contractual obligations. For a description of our operating lease obligations, long-term debt, and purchase obligations, refer to Note 3, Note 12, and Note 13 of the Notes to Condensed Consolidated Financial Statements, respectively.

[0001045810-21-000163:mdna:115]
Climate Change

[0001045810-21-000163:mdna:116]
In the area of sustainability, we continue to address our climate impact across our product lifecycle and to assess relevant risks, including current and emerging regulations and market impacts. We undertake efforts to reduce greenhouse gas emissions, water usage and waste in our data centers, labs and offices, including sourcing a portion of our global electricity from renewable energy. Our investments include sustainability features when opening new offices and new construction to incorporate green building standards, such as our LEED Gold headquarters in Santa Clara, California, and energy-efficient systems and technologies in our data centers. We focus on energy efficiency in our processor design and utilize recyclable packaging to minimize our environmental footprint. To date, there has been no material impact to our results of operations associated with global sustainability regulations, compliance, or costs from sourcing renewable energy. We have announced plans to build the world’s most powerful AI supercomputer, Earth-2, dedicated to predicting climate change.

[0001045810-21-000163:mdna:117]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-21-000163:mdna:118]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of a new and recently issued accounting pronouncement.
