# NVDA 8-K — 0001045810-21-000160 filed 2021-11-17

## item codes, every 8-K on or before 2021-11-22

- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2021-11-22

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-21-000160:8k_2_02:1]
EX-99.1
2
q3fy22pr.htm
Q3FY22 PRESS RELEASE

[0001045810-21-000160:8k_2_02:2]
Document

[0001045810-21-000160:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-21-000160:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2022

[0001045810-21-000160:8k_2_02:5]
•Record revenue of $7.10 billion, up 50 percent from a year earlier

[0001045810-21-000160:8k_2_02:6]
•Record Data Center revenue of $2.94 billion, up 55 percent from a year earlier

[0001045810-21-000160:8k_2_02:7]
•Record Gaming revenue of $3.22 billion, up 42 percent from a year earlier

[0001045810-21-000160:8k_2_02:8]
SANTA CLARA, Calif.-Nov. 17, 2021- NVIDIA (NASDAQ: NVDA) today reported record revenue for the third quarter ended October 31, 2021, of $7.10 billion, up 50 percent from a year earlier and up 9 percent from the previous quarter, with record revenue from the company’s Gaming, Data Center and Professional Visualization market platforms.

[0001045810-21-000160:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.97, up 83 percent from a year ago and up 3 percent from the previous quarter. Non-GAAP earnings per diluted share were $1.17, up 60 percent from a year ago and up 13 percent from the previous quarter.

[0001045810-21-000160:8k_2_02:10]
“The third quarter was outstanding, with record revenue,” said Jensen Huang, founder and CEO of NVIDIA. “Demand for NVIDIA AI is surging, driven by hyperscale and cloud scale-out, and broadening adoption by more than 25,000 companies. NVIDIA RTX has reinvented computer graphics with ray tracing and AI, and is the ideal upgrade for the large, growing market of gamers and creators, as well as designers and professionals building home workstations.

[0001045810-21-000160:8k_2_02:11]
“Our GTC event series showcases the expanding universe of NVIDIA accelerated computing. Last week’s event was our most successful yet, highlighting diverse applications, including supply-chain logistics, cybersecurity, natural language processing, quantum computing research, robotics, self-driving cars, climate science and digital biology.

[0001045810-21-000160:8k_2_02:12]
“Omniverse was a major theme at GTC. We showed what is possible when we can jump into virtual worlds. Omniverse will be used from collaborative design, customer service avatars and video conferencing, to digital twins of factories, processing plants, even entire cities. Omniverse brings together NVIDIA’s expertise in AI, simulation, graphics and computing infrastructure. This is the tip of the iceberg of what’s to come,” he said.

[0001045810-21-000160:8k_2_02:13]
NVIDIA paid quarterly cash dividends of $100 million in the third quarter. It will pay its next quarterly cash dividend of $0.04 per share on December 23, 2021, to all shareholders of record on December 2, 2021.

[0001045810-21-000160:8k_2_02:14]
Q3 Fiscal 2022 Summary

[0001045810-21-000160:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q3 FY22 | Q2 FY22 | Q3 FY21 | Q/Q | Y/Y |
| Revenue | $7,103 | $6,507 | $4,726 | Up 9% | Up 50% |
| Gross margin | 65.2 | % | 64.8 | % | 62.6 | % | Up 40 bps | Up 260 bps |
| Operating expenses | $1,960 | $1,771 | $1,562 | Up 11% | Up 25% |
| Operating income | $2,671 | $2,444 | $1,398 | Up 9% | Up 91% |
| Net income | $2,464 | $2,374 | $1,336 | Up 4% | Up 84% |
| Diluted earnings per share* | $0.97 | $0.94 | $0.53 | Up 3% | Up 83% |

[0001045810-21-000160:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q3 FY22 | Q2 FY22 | Q3 FY21 | Q/Q | Y/Y |
| Revenue | $7,103 | $6,507 | $4,726 | Up 9% | Up 50% |
| Gross margin | 67.0 | % | 66.7 | % | 65.5 | % | Up 30 bps | Up 150 bps |
| Operating expenses | $1,375 | $1,266 | $1,101 | Up 9% | Up 25% |
| Operating income | $3,386 | $3,071 | $1,993 | Up 10% | Up 70% |
| Net income | $2,973 | $2,623 | $1,834 | Up 13% | Up 62% |
| Diluted earnings per share* | $1.17 | $1.04 | $0.73 | Up 13% | Up 60% |

[0001045810-21-000160:8k_2_02:17]
*All per share amounts presented herein have been retroactively adjusted to reflect the four-for-one stock split which was effective July 19, 2021.

[0001045810-21-000160:8k_2_02:18]
NVIDIA’s outlook for the fourth quarter of fiscal 2022 is as follows:

[0001045810-21-000160:8k_2_02:19]
•Revenue is expected to be $7.40 billion, plus or minus 2 percent.

[0001045810-21-000160:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 65.3 percent and 67.0 percent, respectively, plus or minus 50 basis points.

[0001045810-21-000160:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.02 billion and $1.43 billion, respectively.

[0001045810-21-000160:8k_2_02:22]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $60 million, excluding gains and losses from non-affiliated investments.

[0001045810-21-000160:8k_2_02:23]
•GAAP and non-GAAP tax rates are both expected to be 11 percent, plus or minus 1 percent, excluding any discrete items such as excess tax benefits or deficiencies related to stock-based compensation.

[0001045810-21-000160:8k_2_02:24]
Highlights

[0001045810-21-000160:8k_2_02:25]
At last week’s GTC, NVIDIA announced the following:

[0001045810-21-000160:8k_2_02:26]
AI Software

[0001045810-21-000160:8k_2_02:27]
•65 new and updated software development kits -- bringing improved features and capabilities to data scientists, researchers and developers -- including NVIDIA Modulus, a framework for developing physics-ML models, NVIDIA ReOpt, an accelerated solver that optimizes vehicle route planning and logistics, and NVIDIA cuNumeric, which brings accelerated computing to the large and growing Python NumPy ecosystem.

[0001045810-21-000160:8k_2_02:28]
•Tools for developing and deploying large language models: NVIDIA NeMo Megatron, for training models with trillions of parameters; the Megatron 530B customizable LLM that can be trained for new domains and languages; and NVIDIA Triton Inference Server™ with multi-GPU, multinode distributed inference functionality.

[0001045810-21-000160:8k_2_02:29]
•New capabilities in the open source NVIDIA Triton Inference Server software, which provides cross-platform inference on all AI models and frameworks, and NVIDIA TensorRT™, which optimizes AI models.

[0001045810-21-000160:8k_2_02:30]
•Zero-trust cybersecurity platform – comprising NVIDIA BlueField DPUs, NVIDIA DOCA and NVIDIA Morpheus cybersecurity platform – allowing the cybersecurity industry to build solutions that defend customer data centers in real time.

[0001045810-21-000160:8k_2_02:31]
•NVIDIA Riva Custom Voice, a feature in NVIDIA Riva AI software that makes custom text-to-speech practical for companies; NVIDIA Riva Enterprise will be commercially available for enterprises early next year, with applicability to a wide range of applications such as virtual assistants and video conferencing.

[0001045810-21-000160:8k_2_02:32]
Omniverse

[0001045810-21-000160:8k_2_02:33]
•NVIDIA Omniverse Avatar, a platform for generating interactive AI avatars, which connects the company’s technologies in speech AI, computer vision, natural language understanding, recommendation engines and simulation technologies.

[0001045810-21-000160:8k_2_02:34]
•NVIDIA Omniverse Replicator, a synthetic-data-generation engine that produces physically simulated synthetic data for training deep neural networks.

[0001045810-21-000160:8k_2_02:35]
Networking

[0001045810-21-000160:8k_2_02:36]
•NVIDIA Quantum-2, a 400Gbps InfiniBand end-to-end networking platform, with the extreme performance, broad accessibility and strong security needed by cloud computing providers and supercomputing centers.

[0001045810-21-000160:8k_2_02:37]
Automotive/Robotics/Healthcare

[0001045810-21-000160:8k_2_02:38]
•NVIDIA DRIVE Concierge and DRIVE Chauffeur, AI platforms built with NVIDIA DRIVE Orin, which are intelligent technologies that transform the digital experience inside the car with Omniverse Avatar, enabling safe autonomous driving on highways and urban streets.

[0001045810-21-000160:8k_2_02:39]
•NVIDIA DRIVE Hyperion 8, a computer architecture and sensor set for self-driving systems.

[0001045810-21-000160:8k_2_02:40]
•NVIDIA Jetson AGX Orin™, the world’s smallest, most powerful and energy-efficient AI supercomputer for robotics, autonomous machines, medical devices and more.

[0001045810-21-000160:8k_2_02:41]
•NVIDIA Clara Holoscan, an AI computing platform for medical-device makers to adopt software-as-a-service offerings with upgradable, scalable and end-to-end processing of streamed data.

[0001045810-21-000160:8k_2_02:42]
Additionally, the company achieved progress since its previous earnings announcement in these areas:

[0001045810-21-000160:8k_2_02:43]
Gaming

[0001045810-21-000160:8k_2_02:44]
•Third-quarter revenue was a record $3.22 billion, up 42 percent from a year earlier and up 5 percent from the previous quarter.

[0001045810-21-000160:8k_2_02:45]
•Announced RTX capabilities coming to blockbuster titles like Marvel’s Guardians of the Galaxy, Battlefield 2042 and Dying Light 2, as well as Sony Interactive and Santa Monica Studio’s God of War.

[0001045810-21-000160:8k_2_02:46]
•Announced new RTX-accelerated AI features in Adobe applications at the Adobe MAX creativity conference, supported by the latest Studio Driver, and new Studio systems from partners, including Microsoft, HP and Asus.

[0001045810-21-000160:8k_2_02:47]
•Enhanced GeForce NOW™ with a new high-performance membership tier providing access to GeForce RTX™ 3080-class gaming, and with the introduction of more Electronic Arts hit games, including Battlefield 1 Revolution, Mirror’s Edge Catalyst, Unravel Two and Dragon Age: Inquisition.

[0001045810-21-000160:8k_2_02:48]
Data Center

[0001045810-21-000160:8k_2_02:49]
•Third-quarter revenue was a record $2.94 billion, up 55 percent from a year earlier and up 24 percent from the previous quarter.

[0001045810-21-000160:8k_2_02:50]
•Announced plans to build Earth-2, an AI supercomputer dedicated to addressing the global climate change crisis.

[0001045810-21-000160:8k_2_02:51]
•Announced the general availability of NVIDIA AI Enterprise, a comprehensive software suite of AI tools and frameworks that enables the hundreds of thousands of companies running VMware vSphere to virtualize AI workloads on NVIDIA-Certified Systems™.

[0001045810-21-000160:8k_2_02:52]
•Expanded NVIDIA LaunchPad, which provides immediate access to optimized software running on accelerated infrastructure, from North America to nine global locations.

[0001045810-21-000160:8k_2_02:53]
•Described a collaboration involving NVIDIA Megatron-LM and Microsoft DeepSpeed to create an efficient, scalable, 3D parallel system capable of combining data, pipeline and tensor-slicing-based parallelism.

[0001045810-21-000160:8k_2_02:54]
•Announced further collaboration with VMware, supporting trials of VMware vSphere with Tanzu on the NVIDIA AI Enterprise platform.

[0001045810-21-000160:8k_2_02:55]
•Shared news that the largest GPU-based supercomputer at the U.S. Department of Energy’s Argonne National Laboratory, Polaris, will run on NVIDIA’s accelerated computing platform, and be able to achieve almost 1.4 exaflops of AI performance.

[0001045810-21-000160:8k_2_02:56]
Professional Visualization

[0001045810-21-000160:8k_2_02:57]
•Third-quarter revenue was a record $577 million, up 144 percent from a year earlier and up 11 percent from the previous quarter.

[0001045810-21-000160:8k_2_02:58]
•Announced NVIDIA Omniverse Enterprise is in general availability, with the addition of AR, VR and multi-GPU rendering, as well as announced adoption by Bentley Systems and Esri for digital-twin applications.

[0001045810-21-000160:8k_2_02:59]
Automotive

[0001045810-21-000160:8k_2_02:60]
•Third-quarter revenue was $135 million, up 8 percent from a year earlier and down 11 percent from the previous quarter.

[0001045810-21-000160:8k_2_02:61]
•Announced that NVIDIA DRIVE Orin is being used by autonomous truck company Kodiak Robotics, automaker Lotus, autonomous driving-solutions provider QCraft and EV startup WM Motor.

[0001045810-21-000160:8k_2_02:62]
CFO Commentary

[0001045810-21-000160:8k_2_02:63]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-21-000160:8k_2_02:64]
Conference Call and Webcast Information

[0001045810-21-000160:8k_2_02:65]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal year 2022.

[0001045810-21-000160:8k_2_02:66]
Non-GAAP Measures

[0001045810-21-000160:8k_2_02:67]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, IP-related costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable, and domestication tax benefit. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the

[0001045810-21-000160:8k_2_02:68]
presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-21-000160:8k_2_02:69]
About NVIDIA

[0001045810-21-000160:8k_2_02:70]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market and has redefined modern computer graphics, high performance computing and artificial intelligence. The company’s pioneering work in accelerated computing and AI is reshaping trillion-dollar industries, such as transportation, healthcare and manufacturing, and fueling the growth of many others. More information at https://nvidianews.nvidia.com/.

[0001045810-21-000160:8k_2_02:71]
###

[0001045810-21-000160:8k_2_02:72]
For further information, contact:

[0001045810-21-000160:8k_2_02:73]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-21-000160:8k_2_02:74]
Certain statements in this press release including, but not limited to, statements as to: demand for AI surging and its broadening adoption; the growing market of gamers and creators, as well as designers and professionals building home workstations; the expanding universe of NVIDIA accelerated computing; the uses of Omniverse and it bringing together NVIDIA’s expertise in AI, simulation, graphics, and computing infrastructure; the benefits, performance and abilities of our products and technologies, including NVIDIA Modulus, NVIDIA ReOpt, NVIDIA cuNumeric, NVIDIA NeMo Megatron, NVIDIA Triton Inference Server, NVIDIA TensorRT, NVIDIA’s zero-trust cybersecurity platform, NVIDIA Riva, NVIDIA Riva Enterprise, NVIDIA Omniverse Avatar, NVIDIA Omniverse Replicator, NVIDIA Quantum-2, NVIDIA DRIVE Concierge and DRIVE Chauffeur, NVIDIA DRIVE Hyperion 8, NVIDIA Jetson AGX Orin, Clara Holoscan, NVIDIA AI Enterprise, NVIDIA LaunchPad, the collaboration between NVIDIA Megatron-LM and Microsoft DeepSpeed, the collaboration with VMware, and NVIDIA Omniverse Enterprise; plans to run Polaris on NVIDIA’s accelerated computing platform; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the fourth quarter of fiscal 2022; and NVIDIA’s expected tax rates for the fourth quarter of fiscal 2022 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-21-000160:8k_2_02:75]
© 2021 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, BlueField, GeForce NOW, GeForce RTX, NVIDIA Clara, NVIDIA DOCA, NVIDIA DRIVE, NVIDIA Jetson AGX Orin, NVIDIA Omniverse, NVIDIA ReOpt, NVIDIA RTX, NVIDIA Triton Interface Server, NVIDIA-Certified Systems, GeForce NOW, GeForce RTX and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000160:8k_2_02:76]
NVIDIA CORPORATION

[0001045810-21-000160:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-21-000160:8k_2_02:78]
(In millions, except per share data)

[0001045810-21-000160:8k_2_02:79]
(Unaudited)

[0001045810-21-000160:8k_2_02:80]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 31, |  | October 25, |  | October 31, |  | October 25, |
|  |  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue | $ | 7,103 |  |  | $ | 4,726 |  |  | $ | 19,271 |  |  | $ | 11,672 |  |
| Cost of revenue | 2,472 |  |  | 1,766 |  |  | 6,795 |  |  | 4,432 |  |
| Gross profit | 4,631 |  |  | 2,960 |  |  | 12,476 |  |  | 7,240 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,403 |  |  | 1,047 |  |  | 3,802 |  |  | 2,778 |  |
|  | Sales, general and administrative | 557 |  |  | 515 |  |  | 1,603 |  |  | 1,437 |  |
|  |  | Total operating expenses | 1,960 |  |  | 1,562 |  |  | 5,405 |  |  | 4,215 |  |
| Income from operations | 2,671 |  |  | 1,398 |  |  | 7,071 |  |  | 3,025 |  |
|  | Interest income | 7 |  |  | 7 |  |  | 20 |  |  | 50 |  |
|  | Interest expense | (62) |  |  | (53) |  |  | (175) |  |  | (131) |  |
|  | Other, net | 22 |  |  | (4) |  |  | 160 |  |  | (5) |  |
|  |  | Other income (expense), net | (33) |  |  | (50) |  |  | 5 |  |  | (86) |  |
| Income before income tax | 2,638 |  |  | 1,348 |  |  | 7,076 |  |  | 2,939 |  |
| Income tax expense | 174 |  |  | 12 |  |  | 327 |  |  | 64 |  |
| Net income | $ | 2,464 |  |  | $ | 1,336 |  |  | $ | 6,749 |  |  | $ | 2,875 |  |
| Net income per share (A): |  |  |  |  |  |  |  |
|  | Basic | $ | 0.99 |  |  | $ | 0.54 |  |  | $ | 2.71 |  |  | $ | 1.17 |  |
|  | Diluted | $ | 0.97 |  |  | $ | 0.53 |  |  | $ | 2.67 |  |  | $ | 1.15 |  |
| Weighted average shares used in per share computation (A): |  |  |  |  |  |  |  |
|  | Basic | 2,499 |  |  | 2,472 |  |  | 2,493 |  |  | 2,464 |  |
|  | Diluted | 2,538 |  |  | 2,520 |  |  | 2,532 |  |  | 2,504 |  |

[0001045810-21-000160:8k_2_02:81]
(A) Reflects a four-for-one stock split on July 19, 2021.

[0001045810-21-000160:8k_2_02:82]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | October 31, |  | January 31, |
|  |  |  |  | 2021 |  | 2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 19,298 |  |  | $ | 11,561 |  |
|  | Accounts receivable, net |  | 3,954 |  |  | 2,429 |  |
|  | Inventories |  | 2,233 |  |  | 1,826 |  |
|  | Prepaid expenses and other current assets |  | 321 |  |  | 239 |  |
|  |  | Total current assets |  | 25,806 |  |  | 16,055 |  |
| Property and equipment, net |  | 2,509 |  |  | 2,149 |  |
| Operating lease assets |  | 830 |  |  | 707 |  |
| Goodwill |  | 4,302 |  |  | 4,193 |  |
| Intangible assets, net |  | 2,454 |  |  | 2,737 |  |
| Deferred income tax assets |  | 970 |  |  | 806 |  |
| Other assets |  | 3,761 |  |  | 2,144 |  |
|  |  | Total assets |  | $ | 40,632 |  |  | $ | 28,791 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,664 |  |  | $ | 1,201 |  |
|  | Accrued and other current liabilities |  | 1,948 |  |  | 1,725 |  |
|  | Short-term debt |  | — |  |  | 999 |  |
|  |  | Total current liabilities |  | 3,612 |  |  | 3,925 |  |
| Long-term debt |  | 10,944 |  |  | 5,964 |  |
| Long-term operating lease liabilities |  | 743 |  |  | 634 |  |
| Other long-term liabilities |  | 1,535 |  |  | 1,375 |  |
|  |  | Total liabilities |  | 16,834 |  |  | 11,898 |  |
| Shareholders' equity |  | 23,798 |  |  | 16,893 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 40,632 |  |  | $ | 28,791 |  |

[0001045810-21-000160:8k_2_02:83]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, |  | October 25, |  | October 31, |  | October 25, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,464 |  |  | $ | 1,336 |  |  | $ | 6,749 |  |  | $ | 2,875 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 559 |  |  | 383 |  |  | 1,453 |  |  | 981 |  |
| Depreciation and amortization | 298 |  |  | 299 |  |  | 865 |  |  | 810 |  |
| Deferred income taxes | (21) |  |  | (53) |  |  | (182) |  |  | (117) |  |
| (Gains) losses on investments in non affiliates, net | (20) |  |  | — |  |  | (152) |  |  | — |  |
| Other | 10 |  |  | 2 |  |  | 25 |  |  | (2) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (366) |  |  | (463) |  |  | (1,523) |  |  | (667) |  |
| Inventories | (118) |  |  | (93) |  |  | (400) |  |  | (190) |  |
| Prepaid expenses and other assets | (1,575) |  |  | (443) |  |  | (1,557) |  |  | (409) |  |
| Accounts payable | 195 |  |  | 225 |  |  | 474 |  |  | 289 |  |
| Accrued and other current liabilities | (62) |  |  | 31 |  |  | 70 |  |  | 111 |  |
| Other long-term liabilities | 155 |  |  | 55 |  |  | 253 |  |  | 74 |  |
| Net cash provided by operating activities | 1,519 |  |  | 1,279 |  |  | 6,075 |  |  | 3,755 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,545 |  |  | 4,133 |  |  | 7,780 |  |  | 5,165 |  |
| Proceeds from sales of marketable securities | 211 |  |  | 243 |  |  | 916 |  |  | 502 |  |
| Purchases of marketable securities | (6,752) |  |  | (4,554) |  |  | (16,020) |  |  | (12,840) |  |
| Purchases related to property and equipment and intangible assets | (221) |  |  | (473) |  |  | (703) |  |  | (845) |  |
| Acquisitions, net of cash acquired | (203) |  |  | (1,353) |  |  | (203) |  |  | (8,524) |  |
| Investments and other, net | (18) |  |  | 3 |  |  | (14) |  |  | (4) |  |
| Net cash used in investing activities | (4,438) |  |  | (2,001) |  |  | (8,244) |  |  | (16,546) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Issuance of debt, net of issuance costs | (8) |  |  | — |  |  | 4,977 |  |  | 4,971 |  |
| Proceeds related to employee stock plans | 149 |  |  | 96 |  |  | 277 |  |  | 190 |  |
| Repayment of debt | (1,000) |  |  | — |  |  | (1,000) |  |  | — |  |
| Payments related to tax on restricted stock units | (440) |  |  | (298) |  |  | (1,282) |  |  | (716) |  |
| Dividends paid | (100) |  |  | (99) |  |  | (298) |  |  | (296) |  |
| Principal payments on property and equipment | (22) |  |  | — |  |  | (62) |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | (3) |  |
| Net cash provided by (used in) financing activities | (1,421) |  |  | (301) |  |  | 2,610 |  |  | 4,146 |  |
| Change in cash and cash equivalents | (4,340) |  |  | (1,023) |  |  | 441 |  |  | (8,645) |  |
| Cash and cash equivalents at beginning of period | 5,628 |  |  | 3,274 |  |  | 847 |  |  | 10,896 |  |
| Cash and cash equivalents at end of period | $ | 1,288 |  |  | $ | 2,251 |  |  | $ | 1,288 |  |  | $ | 2,251 |  |

[0001045810-21-000160:8k_2_02:84]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 31, |  | August 1, |  | October 25, |  | October 31, |  | October 25, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP gross profit |  | $ | 4,631 |  |  | $ | 4,215 |  |  | $ | 2,960 |  |  | $ | 12,476 |  |  | $ | 7,240 |  |
| GAAP gross margin |  | 65.2 | % |  | 64.8 | % |  | 62.6 | % |  | 64.7 | % |  | 62.0 | % |
|  | Acquisition-related and other costs (A) |  | 86 |  |  | 86 |  |  | 86 |  |  | 258 |  |  | 331 |  |
|  | Stock-based compensation expense (B) |  | 44 |  |  | 32 |  |  | 28 |  |  | 102 |  |  | 62 |  |
|  | IP-related costs |  | — |  |  | 4 |  |  | 21 |  |  | 8 |  |  | 38 |  |
| Non-GAAP gross profit |  | $ | 4,761 |  |  | $ | 4,337 |  |  | $ | 3,095 |  |  | $ | 12,844 |  |  | $ | 7,671 |  |
| Non-GAAP gross margin |  | 67.0 | % |  | 66.7 | % |  | 65.5 | % |  | 66.6 | % |  | 65.7 | % |
| GAAP operating expenses |  | $ | 1,960 |  |  | $ | 1,771 |  |  | $ | 1,562 |  |  | $ | 5,405 |  |  | $ | 4,215 |  |
|  | Stock-based compensation expense (B) |  | (515) |  |  | (433) |  |  | (355) |  |  | (1,351) |  |  | (919) |  |
|  | Acquisition-related and other costs (A) |  | (70) |  |  | (72) |  |  | (106) |  |  | (224) |  |  | (338) |  |
| Non-GAAP operating expenses |  | $ | 1,375 |  |  | $ | 1,266 |  |  | $ | 1,101 |  |  | $ | 3,830 |  |  | $ | 2,958 |  |
| GAAP income from operations |  | $ | 2,671 |  |  | $ | 2,444 |  |  | $ | 1,398 |  |  | $ | 7,071 |  |  | $ | 3,025 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 715 |  |  | 627 |  |  | 595 |  |  | 1,943 |  |  | 1,689 |  |
| Non-GAAP income from operations |  | $ | 3,386 |  |  | $ | 3,071 |  |  | $ | 1,993 |  |  | $ | 9,014 |  |  | $ | 4,714 |  |
| GAAP other income (expense), net |  | $ | (33) |  |  | $ | (50) |  |  | $ | (50) |  |  | $ | 5 |  |  | $ | (86) |  |
|  | (Gains) losses from non-affiliated investments |  | (20) |  |  | — |  |  | 4 |  |  | (153) |  |  | 9 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Non-GAAP other income (expense), net |  | $ | (52) |  |  | $ | (49) |  |  | $ | (45) |  |  | $ | (145) |  |  | $ | (76) |  |
| GAAP net income |  | $ | 2,464 |  |  | $ | 2,374 |  |  | $ | 1,336 |  |  | $ | 6,749 |  |  | $ | 2,875 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 696 |  |  | 628 |  |  | 600 |  |  | 1,793 |  |  | 1,699 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (187) |  |  | (127) |  |  | (102) |  |  | (381) |  |  | (255) |  |
|  | Domestication tax benefit |  | — |  |  | (252) |  |  | — |  |  | (252) |  |  | — |  |
| Non-GAAP net income |  | $ | 2,973 |  |  | $ | 2,623 |  |  | $ | 1,834 |  |  | $ | 7,909 |  |  | $ | 4,319 |  |

[0001045810-21-000160:8k_2_02:85]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 31, |  | August 1, |  | October 25, |  | October 31, |  | October 25, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Diluted net income per share (D) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.97 |  |  | $ | 0.94 |  |  | $ | 0.53 |  |  | $ | 2.67 |  |  | $ | 1.15 |  |
|  | Non-GAAP |  | $ | 1.17 |  |  | $ | 1.04 |  |  | $ | 0.73 |  |  | $ | 3.12 |  |  | $ | 1.72 |  |
| Weighted average shares used in diluted net income per share computation (D) |  | 2,538 |  |  | 2,532 |  |  | 2,520 |  |  | 2,532 |  |  | 2,504 |  |
| GAAP net cash provided by operating activities |  | $ | 1,519 |  |  | $ | 2,682 |  |  | $ | 1,279 |  |  | $ | 6,075 |  |  | $ | 3,755 |  |
|  | Purchases related to property and equipment and intangible assets |  | (221) |  |  | (183) |  |  | (473) |  |  | (703) |  |  | (845) |  |
|  | Principal payments on property and equipment |  | (22) |  |  | (21) |  |  | — |  |  | (62) |  |  | — |  |
| Free cash flow |  | $ | 1,276 |  |  | $ | 2,478 |  |  | $ | 806 |  |  | $ | 5,310 |  |  | $ | 2,910 |  |

[0001045810-21-000160:8k_2_02:86]
| (A) Acquisition-related and other costs primarily include amortization of intangible assets, inventory step-up, transaction costs, and certain compensation charges presented as follows: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 31, |  | August 1, |  | October 25, |  | October 31, |  | October 25, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Cost of revenue |  | $ | 86 |  |  | $ | 86 |  |  | $ | 86 |  |  | $ | 258 |  |  | $ | 331 |  |
|  | Research and development |  | $ | 7 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 10 |  |  | $ | 7 |  |
|  | Sales, general and administrative |  | $ | 63 |  |  | $ | 71 |  |  | $ | 104 |  |  | $ | 214 |  |  | $ | 331 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | October 31, |  | August 1, |  | October 25, |  | October 31, |  | October 25, |
|  |  |  | 2021 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | Cost of revenue |  | $ | 44 |  |  | $ | 32 |  |  | $ | 28 |  |  | $ | 102 |  |  | $ | 62 |  |
|  | Research and development |  | $ | 363 |  |  | $ | 297 |  |  | $ | 232 |  |  | $ | 935 |  |  | $ | 594 |  |
|  | Sales, general and administrative |  | $ | 152 |  |  | $ | 136 |  |  | $ | 123 |  |  | $ | 416 |  |  | $ | 325 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (D) Reflects a four-for-one stock split on July 19, 2021. |

[0001045810-21-000160:8k_2_02:87]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2022 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 65.3 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 1.7 | % |
| Non-GAAP gross margin |  | 67.0 | % |
| GAAP operating expenses |  | $ | 2,015 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (585) |  |
| Non-GAAP operating expenses |  | $ | 1,430 |  |
