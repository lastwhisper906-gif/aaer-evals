# NVDA note change history — 0001045810-22-000147 → 0001045810-22-000166


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-11-18):
[0001045810-22-000166:note_history:1]
We have entered into several long-term supply agreements, under which we have made advance payments and have $917 million remaining unpaid. As of October 30, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $7.02 billion, inclusive of the $917 million. Other non-inventory purchase obligations of $2.75 billion include $1.59 billion of multi-year cloud service agreements.

- changed (2022-11-18):
[0001045810-22-000166:note_history:2]
Total gross future unconditional purchase commitments as of October 30, 2022 are as follows:
  (was, 2022-08-31, similarity 0.9357):
[0001045810-22-000147:note_history:2]
Total gross future unconditional purchase commitments as of July 31, 2022, are as follows:

- changed (2022-11-18):
[0001045810-22-000166:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first nine months of fiscal year 2023) | $ | 4,234 |  |
| 2024 | 3,362 |  |
| 2025 | 798 |  |
| 2026 | 504 |  |
| 2027 | 464 |  |
| 2028 and thereafter | 410 |  |
| Total | $ | 9,772 |  |
  (was, 2022-08-31, similarity 0.9691):
[0001045810-22-000147:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first half of fiscal year 2023) | $ | 7,108 |  |
| 2024 | 2,730 |  |
| 2025 | 295 |  |
| 2026 | 49 |  |
| 2027 | 71 |  |
| 2028 and thereafter | 331 |  |
| Total | $ | 10,584 |  |

- added (2022-11-18):
[0001045810-22-000166:note_history:4]
The estimated amount of product warranty liabilities was $104 million and $46 million as of October 30, 2022 and January 30, 2022, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

- added (2022-11-18):
[0001045810-22-000166:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 168 |  |  | $ | 31 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions | 3 |  | 5 |  | 141 |  | 20 |
| Utilization | (67) |  |  | (4) |  |  | (83) |  |  | (10) |  |
| Balance at end of period | $ | 104 |  |  | $ | 32 |  |  | $ | 104 |  |  | $ | 32 |  |

- added (2022-11-18):
[0001045810-22-000166:note_history:6]
In the third quarter of fiscal year 2023, we recognized a warranty-related benefit of approximately $70 million in cost of revenue due to favorable product recovery.

- changed (2022-11-18):
[0001045810-22-000166:note_history:7]
As of October 30, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2022-08-31, similarity 0.9916):
[0001045810-22-000147:note_history:7]
As of July 31, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2022-11-18):
[0001045810-22-000147:note_history:8]
We have entered into several long-term supply agreements, under which we have made advance payments and have $929 million remaining unpaid. As of July 31, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.22 billion, inclusive of the $929 million. We also had other purchase obligations totaling $1.36 billion.

- removed (2022-11-18):
[0001045810-22-000147:note_history:9]
The estimated amount of product warranty liabilities was $168 million and $46 million as of July 31, 2022 and January 30, 2022, respectively. In the second quarter of fiscal year 2023, we recorded $122 million in product warranty liabilities primarily related to a defect identified in a third-party component embedded in certain Data Center products. The estimated product returns and estimated product warranty activity consisted of the following:

- removed (2022-11-18):
[0001045810-22-000147:note_history:10]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 55 |  |  | $ | 30 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions | 122 |  |  | 4 |  |  | 138 |  |  | 15 |  |
| Deductions | (9) |  |  | (3) |  |  | (16) |  |  | (6) |  |
| Balance at end of period | $ | 168 |  |  | $ | 31 |  |  | $ | 168 |  |  | $ | 31 |  |

- removed (2022-11-18):
[0001045810-22-000147:note_history:11]
Settlement

- removed (2022-11-18):
[0001045810-22-000147:note_history:12]
In May 2022, NVIDIA entered into a settlement with the SEC relating to MD&A disclosures in our Forms 10-Q for the second and third quarters of fiscal year 2018 concerning the impact of cryptocurrency mining on year-over-year growth in revenue for our gaming specialized market during those periods. As part of the settlement, without admitting or denying the findings in the administrative order issued by the SEC, NVIDIA agreed to cease-and-desist from violating certain federal securities laws and paid a $5.5 million civil penalty.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001045810-22-000166:note_history:13]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The third quarters of fiscal years 2023 and 2022 were both 13-week quarters.
  (was, 2022-08-31, similarity 0.9759):
[0001045810-22-000147:note_history:13]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The second quarters of fiscal years 2023 and 2022 were both 13-week quarters.

- added (2022-11-18):
[0001045810-22-000166:note_history:14]
Prior period intangible asset gross carrying amount and accumulated amortization in Note 9 have been adjusted to write off immaterial fully amortized intangible assets as of January 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001045810-22-000166:note_history:15]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.6 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (50) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | 10,950 |  |  | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,701 |  |  | $ | 10,946 |  |
  (was, 2022-08-31, similarity 0.9828):
[0001045810-22-000147:note_history:15]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 31, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.9 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (51) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,949 |  |  | $ | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,700 |  |  | $ | 10,946 |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:16]
As of October 30, 2022, we have complied with the required covenants under the notes.
  (was, 2022-08-31, similarity 0.929):
[0001045810-22-000147:note_history:16]
As of July 31, 2022, we have complied with the required covenants under the notes.

- changed (2022-11-18):
[0001045810-22-000166:note_history:17]
We have a $575 million commercial paper program to support general corporate purposes. As of October 30, 2022, we had not issued any commercial paper.
  (was, 2022-08-31, similarity 0.9609):
[0001045810-22-000147:note_history:17]
We have a $575 million commercial paper program to support general corporate purposes. As of July 31, 2022, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001045810-22-000166:note_history:18]
The following is a summary of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022:
  (was, 2022-08-31, similarity 0.9479):
[0001045810-22-000147:note_history:18]
The following is a summary of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022:

- changed (2022-11-18):
[0001045810-22-000166:note_history:19]
|  | October 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,221 |  |  | $ | — |  |  | $ | (19) |  |  | $ | 4,202 |  |  | $ | 239 |  |  | $ | 3,963 |  |
| Debt securities issued by the U.S. Treasury | 4,176 |  |  | 1 |  |  | (60) |  |  | 4,117 |  |  | 1 |  |  | 4,116 |  |
| Debt securities issued by U.S. government agencies | 2,259 |  |  | — |  |  | (4) |  |  | 2,255 |  |  | 344 |  |  | 1,911 |  |
| Certificates of deposit | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 58 |  |  | 258 |  |
| Money market funds | 1,843 |  |  | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |  | — |  |
| Foreign government bonds | 99 |  |  | — |  |  | — |  |  | 99 |  |  | 4 |  |  | 95 |  |
| Total | $ | 12,914 |  |  | $ | 1 |  |  | $ | (83) |  |  | $ | 12,832 |  |  | $ | 2,489 |  |  | $ | 10,343 |  |
  (was, 2022-08-31, similarity 0.9731):
[0001045810-22-000147:note_history:19]
|  | July 31, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,016 |  |  | $ | — |  |  | $ | (18) |  |  | $ | 7,998 |  |  | $ | 1,115 |  |  | $ | 6,883 |  |
| Debt securities issued by the United States Treasury | 4,068 |  |  | 1 |  |  | (39) |  |  | 4,030 |  |  | 108 |  |  | 3,922 |  |
| Debt securities issued by United States government agencies | 3,056 |  |  | — |  |  | (2) |  |  | 3,054 |  |  | 564 |  |  | 2,490 |  |
| Certificates of deposit | 856 |  |  | — |  |  | — |  |  | 856 |  |  | 128 |  |  | 728 |  |
| Money market funds | 639 |  |  | — |  |  | — |  |  | 639 |  |  | 639 |  |  | — |  |
| Foreign government bonds | 15 |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |
| Total | $ | 16,650 |  |  | $ | 1 |  |  | $ | (59) |  |  | $ | 16,592 |  |  | $ | 2,569 |  |  | $ | 14,023 |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:20]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the U.S. Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by U.S. government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |
  (was, 2022-08-31, similarity 0.9812):
[0001045810-22-000147:note_history:20]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:21]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022 are shown below by contractual maturity.
  (was, 2022-08-31, similarity 0.9662):
[0001045810-22-000147:note_history:21]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022 are shown below by contractual maturity.

- added (2022-11-18):
[0001045810-22-000166:note_history:22]
|  | October 30, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 8,985 |  |  | $ | 8,952 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 3,929 |  |  | 3,880 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 12,914 |  |  | $ | 12,832 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2022-11-18):
[0001045810-22-000147:note_history:23]
|  | July 31, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,628 |  |  | $ | 12,607 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,022 |  |  | 3,985 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 16,650 |  |  | $ | 16,592 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001045810-22-000166:note_history:24]
The following is a summary of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022:
  (was, 2022-08-31, similarity 0.9479):
[0001045810-22-000147:note_history:24]
The following is a summary of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022:

- changed (2022-11-18):
[0001045810-22-000166:note_history:25]
|  | October 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,221 |  |  | $ | — |  |  | $ | (19) |  |  | $ | 4,202 |  |  | $ | 239 |  |  | $ | 3,963 |  |
| Debt securities issued by the U.S. Treasury | 4,176 |  |  | 1 |  |  | (60) |  |  | 4,117 |  |  | 1 |  |  | 4,116 |  |
| Debt securities issued by U.S. government agencies | 2,259 |  |  | — |  |  | (4) |  |  | 2,255 |  |  | 344 |  |  | 1,911 |  |
| Certificates of deposit | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 58 |  |  | 258 |  |
| Money market funds | 1,843 |  |  | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |  | — |  |
| Foreign government bonds | 99 |  |  | — |  |  | — |  |  | 99 |  |  | 4 |  |  | 95 |  |
| Total | $ | 12,914 |  |  | $ | 1 |  |  | $ | (83) |  |  | $ | 12,832 |  |  | $ | 2,489 |  |  | $ | 10,343 |  |
  (was, 2022-08-31, similarity 0.9731):
[0001045810-22-000147:note_history:25]
|  | July 31, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 8,016 |  |  | $ | — |  |  | $ | (18) |  |  | $ | 7,998 |  |  | $ | 1,115 |  |  | $ | 6,883 |  |
| Debt securities issued by the United States Treasury | 4,068 |  |  | 1 |  |  | (39) |  |  | 4,030 |  |  | 108 |  |  | 3,922 |  |
| Debt securities issued by United States government agencies | 3,056 |  |  | — |  |  | (2) |  |  | 3,054 |  |  | 564 |  |  | 2,490 |  |
| Certificates of deposit | 856 |  |  | — |  |  | — |  |  | 856 |  |  | 128 |  |  | 728 |  |
| Money market funds | 639 |  |  | — |  |  | — |  |  | 639 |  |  | 639 |  |  | — |  |
| Foreign government bonds | 15 |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |
| Total | $ | 16,650 |  |  | $ | 1 |  |  | $ | (59) |  |  | $ | 16,592 |  |  | $ | 2,569 |  |  | $ | 14,023 |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:26]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the U.S. Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by U.S. government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |
  (was, 2022-08-31, similarity 0.9812):
[0001045810-22-000147:note_history:26]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:27]
|  | October 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the U.S. Treasury | $ | 1,928 |  |  | $ | (35) |  |  | $ | 1,051 |  |  | $ | (24) |  |  | $ | 2,979 |  |  | $ | (59) |  |
| Debt securities issued by U.S. government agencies | 1,888 |  |  | (4) |  |  | — |  |  | — |  |  | 1,888 |  |  | (4) |  |
| Corporate debt securities | 1,786 |  |  | (18) |  |  | 208 |  |  | (2) |  |  | 1,994 |  |  | (20) |  |
| Total | $ | 5,602 |  |  | $ | (57) |  |  | $ | 1,259 |  |  | $ | (26) |  |  | $ | 6,861 |  |  | $ | (83) |  |
  (was, 2022-08-31, similarity 0.9474):
[0001045810-22-000147:note_history:27]
|  | July 31, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 2,793 |  |  | $ | (39) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,793 |  |  | $ | (39) |  |
| Debt securities issued by United States government agencies | 2,312 |  |  | (2) |  |  | — |  |  | — |  |  | 2,312 |  |  | (2) |  |
| Corporate debt securities | 1,925 |  |  | (17) |  |  | 105 |  |  | (1) |  |  | 2,030 |  |  | (18) |  |
| Total | $ | 7,030 |  |  | $ | (58) |  |  | $ | 105 |  |  | $ | (1) |  |  | $ | 7,135 |  |  | $ | (59) |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:28]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the U.S. Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |
  (was, 2022-08-31, similarity 0.9862):
[0001045810-22-000147:note_history:28]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

- changed (2022-11-18):
[0001045810-22-000166:note_history:29]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.
  (was, 2022-08-31, similarity 0.9481):
[0001045810-22-000147:note_history:29]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and unrealized gains and losses were not significant for all periods presented.

- changed (2022-11-18):
[0001045810-22-000166:note_history:30]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022 are shown below by contractual maturity.
  (was, 2022-08-31, similarity 0.9662):
[0001045810-22-000147:note_history:30]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of July 31, 2022 and January 30, 2022 are shown below by contractual maturity.

- added (2022-11-18):
[0001045810-22-000166:note_history:31]
|  | October 30, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 8,985 |  |  | $ | 8,952 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 3,929 |  |  | 3,880 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 12,914 |  |  | $ | 12,832 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2022-11-18):
[0001045810-22-000147:note_history:32]
|  | July 31, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,628 |  |  | $ | 12,607 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,022 |  |  | 3,985 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 16,650 |  |  | $ | 16,592 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-18):
[0001045810-22-000166:note_history:33]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.6 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (50) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | 10,950 |  |  | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,701 |  |  | $ | 10,946 |  |
  (was, 2022-08-31, similarity 0.9828):
[0001045810-22-000147:note_history:33]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | July 31, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.9 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.9 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (51) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,949 |  |  | $ | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,700 |  |  | $ | 10,946 |  |
