# NVDA 8-K — 0001045810-23-000014 filed 2023-02-22

## item codes, every 8-K on or before 2023-02-24

- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2023-02-24

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-23-000014:8k_2_02:1]
EX-99.1
2
q4fy23pr.htm
Q4FY23 PRESS RELEASE

[0001045810-23-000014:8k_2_02:2]
Document

[0001045810-23-000014:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-23-000014:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2023

[0001045810-23-000014:8k_2_02:5]
•Quarterly revenue of $6.05 billion, down 21% from a year ago

[0001045810-23-000014:8k_2_02:6]
•Fiscal-year revenue of $27.0 billion, flat from a year ago

[0001045810-23-000014:8k_2_02:7]
•Quarterly and annual return to shareholders of $1.15 billion and $10.44 billion, respectively

[0001045810-23-000014:8k_2_02:8]
SANTA CLARA, Calif.-Feb. 22, 2023- NVIDIA (NASDAQ: NVDA) today reported revenue for the fourth quarter ended January 29, 2023, of $6.05 billion, down 21% from a year ago and up 2% from the previous quarter.

[0001045810-23-000014:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.57, down 52% from a year ago and up 111% from the previous quarter. Non-GAAP earnings per diluted share were $0.88, down 33% from a year ago and up 52% from the previous quarter.

[0001045810-23-000014:8k_2_02:10]
For fiscal 2023, revenue was $26.97 billion, flat from a year ago. GAAP earnings per diluted share were $1.74, down 55% from a year ago. Non-GAAP earnings per diluted share were $3.34, down 25% from a year ago.

[0001045810-23-000014:8k_2_02:11]
"AI is at an inflection point, setting up for broad adoption reaching into every industry,” said Jensen Huang, founder and CEO of NVIDIA. “From startups to major enterprises, we are seeing accelerated interest in the versatility and capabilities of generative AI.

[0001045810-23-000014:8k_2_02:12]
“We are set to help customers take advantage of breakthroughs in generative AI and large language models. Our new AI supercomputer, with H100 and its Transformer Engine and Quantum-2 networking fabric, is in full production.

[0001045810-23-000014:8k_2_02:13]
“Gaming is recovering from the post-pandemic downturn, with gamers enthusiastically embracing the new Ada architecture GPUs with AI neural rendering,” he said.

[0001045810-23-000014:8k_2_02:14]
NVIDIA AI Cloud Service Offerings

[0001045810-23-000014:8k_2_02:15]
NVIDIA is partnering with leading cloud service providers to offer AI-as-a-service that provides enterprises access to NVIDIA’s world-leading AI platform.

[0001045810-23-000014:8k_2_02:16]
Customers will be able to engage each layer of NVIDIA AI – the AI supercomputer, acceleration libraries software or pretrained generative AI models – as a cloud service.

[0001045810-23-000014:8k_2_02:17]
Using their browser, they will be able to engage an NVIDIA DGX™ AI supercomputer through the NVIDIA DGX Cloud, which is already offered on Oracle Cloud Infrastructure, with Microsoft Azure, Google Cloud Platform and others expected soon. At the AI platform software layer, they will be able to access NVIDIA AI Enterprise for training and deploying large language models or other AI workloads. And at the AI-model-as-a-service layer, NVIDIA will offer its NeMo™ and BioNeMo™ customizable AI models to enterprise customers who want to build proprietary generative AI models and services for their businesses.

[0001045810-23-000014:8k_2_02:18]
Further details will be shared at the company’s GTC developer conference, taking place virtually March 20-23.

[0001045810-23-000014:8k_2_02:19]
Return to Shareholders

[0001045810-23-000014:8k_2_02:20]
During the fourth quarter of fiscal 2023, NVIDIA returned to shareholders $1.15 billion in share repurchases and cash dividends, bringing the return in the fiscal year to $10.44 billion.

[0001045810-23-000014:8k_2_02:21]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on March 29, 2023, to all shareholders of record on March 8, 2023.

[0001045810-23-000014:8k_2_02:22]
Q4 Fiscal 2023 Summary

[0001045810-23-000014:8k_2_02:23]
| GAAP |
| ($ in millions, except earnings per share) | Q4 FY23 | Q3 FY23 | Q4 FY22 | Q/Q | Y/Y |
| Revenue | $6,051 | $5,931 | $7,643 | Up 2% | Down 21% |
| Gross margin | 63.3 | % | 53.6 | % | 65.4 | % | Up 9.7 pts | Down 2.1 pts |
| Operating expenses | $2,576 | $2,576 | $2,029 | -- | Up 27% |
| Operating income | $1,257 | $601 | $2,970 | Up 109% | Down 58% |
| Net income | $1,414 | $680 | $3,003 | Up 108% | Down 53% |
| Diluted earnings per share | $0.57 | $0.27 | $1.18 | Up 111% | Down 52% |

[0001045810-23-000014:8k_2_02:24]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q4 FY23 | Q3 FY23 | Q4 FY22 | Q/Q | Y/Y |
| Revenue | $6,051 | $5,931 | $7,643 | Up 2% | Down 21% |
| Gross margin | 66.1 | % | 56.1 | % | 67.0 | % | Up 10.0 pts | Down 0.9 pts |
| Operating expenses | $1,775 | $1,793 | $1,447 | Down 1% | Up 23% |
| Operating income | $2,224 | $1,536 | $3,677 | Up 45% | Down 40% |
| Net income | $2,174 | $1,456 | $3,350 | Up 49% | Down 35% |
| Diluted earnings per share | $0.88 | $0.58 | $1.32 | Up 52% | Down 33% |

[0001045810-23-000014:8k_2_02:25]
Fiscal 2023 Summary

[0001045810-23-000014:8k_2_02:26]
| GAAP |
| ($ in millions, except earnings per share) | FY23 | FY22 | Y/Y |
| Revenue | $26,974 | $26,914 | -- |
| Gross margin | 56.9 | % | 64.9 | % | Down 8.0 pts |
| Operating expenses | $11,132 | $7,434 | Up 50% |
| Operating income | $4,224 | $10,041 | Down 58% |
| Net income | $4,368 | $9,752 | Down 55% |
| Diluted earnings per share | $1.74 | $3.85 | Down 55% |

[0001045810-23-000014:8k_2_02:27]
| Non-GAAP |
| ($ in millions, except earnings per share) | FY23 | FY22 | Y/Y |
| Revenue | $26,974 | $26,914 | -- |
| Gross margin | 59.2 | % | 66.8 | % | Down 7.6 pts |
| Operating expenses | $6,925 | $5,279 | Up 31% |
| Operating income | $9,040 | $12,690 | Down 29% |
| Net income | $8,366 | $11,259 | Down 26% |
| Diluted earnings per share | $3.34 | $4.44 | Down 25% |

[0001045810-23-000014:8k_2_02:28]
Outlook

[0001045810-23-000014:8k_2_02:29]
NVIDIA’s outlook for the first quarter of fiscal 2024 is as follows:

[0001045810-23-000014:8k_2_02:30]
•Revenue is expected to be $6.50 billion, plus or minus 2%.

[0001045810-23-000014:8k_2_02:31]
•GAAP and non-GAAP gross margins are expected to be 64.1% and 66.5%, respectively, plus or minus 50 basis points.

[0001045810-23-000014:8k_2_02:32]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.53 billion and $1.78 billion, respectively.

[0001045810-23-000014:8k_2_02:33]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $50 million, excluding gains and losses from non-affiliated investments.

[0001045810-23-000014:8k_2_02:34]
•GAAP and non-GAAP tax rates are expected to be 13.0%, plus or minus 1%, excluding any discrete items.

[0001045810-23-000014:8k_2_02:35]
Highlights

[0001045810-23-000014:8k_2_02:36]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-23-000014:8k_2_02:37]
Data Center

[0001045810-23-000014:8k_2_02:38]
•Fourth-quarter revenue was $3.62 billion, up 11% from a year ago and down 6% from the previous quarter. Fiscal-year revenue rose 41% to a record $15.01 billion.

[0001045810-23-000014:8k_2_02:39]
•Announced a partnership with Deutsche Bank to extend the use of AI in the financial-services sector.

[0001045810-23-000014:8k_2_02:40]
•Launched, together with Dell Technologies, 15 next-generation Dell PowerEdge systems available with NVIDIA® acceleration, enabling enterprises to use AI to efficiently transform their business.

[0001045810-23-000014:8k_2_02:41]
•Announced that NVIDIA A100 Tensor Core GPUs showed unrivaled throughput and top latency in the latest STAC-ML benchmarks for financial services.

[0001045810-23-000014:8k_2_02:42]
Gaming

[0001045810-23-000014:8k_2_02:43]
•Fourth-quarter revenue was $1.83 billion, down 46% from a year ago and up 16% from the previous quarter. Fiscal-year revenue was down 27% to $9.07 billion.

[0001045810-23-000014:8k_2_02:44]
•Unveiled the GeForce RTX™ 40 Series for laptops, providing the company’s largest-ever generational leap in performance and power efficiency.

[0001045810-23-000014:8k_2_02:45]
•Launched the GeForce RTX 4070 Ti, which is faster than the GeForce RTX 3090 Ti, featuring NVIDIA Ada Lovelace architecture and NVIDIA DLSS 3 technology.

[0001045810-23-000014:8k_2_02:46]
•Announced that DLSS 3 is available on, or coming soon to, more than 50 games and apps — including Cyberpunk 2077, Portal with RTX and Marvel’s Spider-Man: Miles Morales.

[0001045810-23-000014:8k_2_02:47]
•Launched the GeForce NOW™ Ultimate membership tier, delivering GeForce RTX 4080-class performance with NVIDIA Reflex, full ray tracing and DLSS 3.

[0001045810-23-000014:8k_2_02:48]
•Signed a 10-year agreement with Microsoft to bring the Xbox PC game lineup, including Minecraft, Halo and Flight Simulator, to GeForce NOW. Following the close of Microsoft’s Activision acquisition, GeForce NOW will add titles like Call of Duty and Overwatch.

[0001045810-23-000014:8k_2_02:49]
Professional Visualization

[0001045810-23-000014:8k_2_02:50]
•Fourth-quarter revenue was $226 million, down 65% from a year ago and up 13% from the previous quarter. Fiscal-year revenue was down 27% to $1.54 billion.

[0001045810-23-000014:8k_2_02:51]
•Enhanced NVIDIA Omniverse™ Enterprise’s capabilities to help teams build connected 3D pipelines and develop large-scale 3D works through increased performance, generational leaps in real-time RTX ray and path tracing, and streamlined workflows.

[0001045810-23-000014:8k_2_02:52]
•Announced a collaboration with Lockheed Martin to build a digital twin of global weather conditions, enabling the U.S. National Oceanic and Atmospheric Administration to better monitor global environmental conditions, including extreme weather events.

[0001045810-23-000014:8k_2_02:53]
•Shared news that Mercedes-Benz is taking the next step to digitalize its production process, using NVIDIA Omniverse to design and plan manufacturing and assembly facilities.

[0001045810-23-000014:8k_2_02:54]
Automotive and Embedded

[0001045810-23-000014:8k_2_02:55]
•Fourth-quarter revenue was a record $294 million, up 135% from a year ago and up 17% from the previous quarter. Fiscal-year revenue rose 60% to a record $903 million.

[0001045810-23-000014:8k_2_02:56]
•Announced a strategic partnership with Foxconn to develop automated and autonomous vehicle platforms based on NVIDIA DRIVE Orin™ and DRIVE Hyperion™.

[0001045810-23-000014:8k_2_02:57]
•Released major updates to the NVIDIA Isaac Sim™ robotics simulation tool, including AI capabilities and cloud access, enabling the building and testing of virtual robots in realistic environments.

[0001045810-23-000014:8k_2_02:58]
CFO Commentary

[0001045810-23-000014:8k_2_02:59]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-23-000014:8k_2_02:60]
Conference Call and Webcast Information

[0001045810-23-000014:8k_2_02:61]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2023 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2024.

[0001045810-23-000014:8k_2_02:62]
Non-GAAP Measures

[0001045810-23-000014:8k_2_02:63]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, contributions, IP-related costs, legal settlement costs, restructuring costs and other, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable, foreign tax benefit and domestication tax adjustments. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-23-000014:8k_2_02:64]
About NVIDIA

[0001045810-23-000014:8k_2_02:65]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and is fueling the creation of the metaverse. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-23-000014:8k_2_02:66]
###

[0001045810-23-000014:8k_2_02:67]
For further information, contact:

[0001045810-23-000014:8k_2_02:68]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-23-000014:8k_2_02:69]
Certain statements in this press release including, but not limited to, statements as to: AI being at an inflection point, setting up for broad adoption reaching into every industry; seeing accelerated interest in the versatility and capabilities of generative AI; NVIDIA being set to help customers take advantage of breakthroughs in generative AI and large language models; NVIDIA’s new AI supercomputer being in full production; gaming recovering from the post-pandemic downturn; gamers enthusiastically embracing the new Ada architecture GPUs with AI neural rendering; partnering with leading cloud service providers to offer NVIDIA AI cloud service; customers being able to engage each layer of NVIDIA AI – the AI supercomputer, acceleration libraries software or pretrained generative AI models – as a cloud service; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook and expected tax rates for the first quarter of fiscal 2024; the benefits, impact, performance, and availability of our products and technologies, including NVIDIA AI as a cloud service, the GeForce RTX 40 Series, GeForce RTX 4070 Ti, DLSS 3, GeForce RTX 3090 Ti, NVIDIA Ada Lovelace, GeForce NOW Ultimate membership tier, GeForce RTX 4080, NVIDIA Reflex, NVIDIA Omniverse Enterprise, NVIDIA DRIVE Orin and DRIVE Hyperion, and NVIDIA Isaac Sim; and the benefits and impact of our collaborations with Deutsche Bank, Dell Technologies, Lockheed Martin, Microsoft, Mercedes-Benz and Foxconn are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-23-000014:8k_2_02:70]
© 2023 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, NVIDIA BioNeMo, NVIDIA DRIVE, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Orin, NVIDIA Isaac Sim, NVIDIA NeMo and NVIDIA Omniverse are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-23-000014:8k_2_02:71]
NVIDIA CORPORATION

[0001045810-23-000014:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-23-000014:8k_2_02:73]
(In millions, except per share data)

[0001045810-23-000014:8k_2_02:74]
(Unaudited)

[0001045810-23-000014:8k_2_02:75]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 29, |  | January 30, |  | January 29, |  | January 30, |
|  |  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue | $ | 6,051 |  |  | $ | 7,643 |  |  | $ | 26,974 |  |  | $ | 26,914 |  |
| Cost of revenue | 2,218 |  |  | 2,644 |  |  | 11,618 |  |  | 9,439 |  |
| Gross profit | 3,833 |  |  | 4,999 |  |  | 15,356 |  |  | 17,475 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,951 |  |  | 1,466 |  |  | 7,339 |  |  | 5,268 |  |
|  | Sales, general and administrative | 625 |  |  | 563 |  |  | 2,440 |  |  | 2,166 |  |
|  | Acquisition termination cost | — |  |  | — |  |  | 1,353 |  |  | — |  |
|  |  | Total operating expenses | 2,576 |  |  | 2,029 |  |  | 11,132 |  |  | 7,434 |  |
| Income from operations | 1,257 |  |  | 2,970 |  |  | 4,224 |  |  | 10,041 |  |
|  | Interest income | 115 |  |  | 9 |  |  | 267 |  |  | 29 |  |
|  | Interest expense | (65) |  |  | (61) |  |  | (262) |  |  | (236) |  |
|  | Other, net | (18) |  |  | (53) |  |  | (48) |  |  | 107 |  |
|  |  | Other income (expense), net | 32 |  |  | (105) |  |  | (43) |  |  | (100) |  |
| Income before income tax | 1,289 |  |  | 2,865 |  |  | 4,181 |  |  | 9,941 |  |
| Income tax expense (benefit) | (125) |  |  | (138) |  |  | (187) |  |  | 189 |  |
| Net income | $ | 1,414 |  |  | $ | 3,003 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.57 |  |  | $ | 1.20 |  |  | $ | 1.76 |  |  | $ | 3.91 |  |
|  | Diluted | $ | 0.57 |  |  | $ | 1.18 |  |  | $ | 1.74 |  |  | $ | 3.85 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,464 |  |  | 2,504 |  |  | 2,487 |  |  | 2,496 |  |
|  | Diluted | 2,477 |  |  | 2,545 |  |  | 2,507 |  |  | 2,535 |  |

[0001045810-23-000014:8k_2_02:76]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | January 29, |  | January 30, |
|  |  |  |  | 2023 |  | 2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 13,296 |  |  | $ | 21,208 |  |
|  | Accounts receivable, net |  | 3,827 |  |  | 4,650 |  |
|  | Inventories |  | 5,159 |  |  | 2,605 |  |
|  | Prepaid expenses and other current assets |  | 791 |  |  | 366 |  |
|  |  | Total current assets |  | 23,073 |  |  | 28,829 |  |
| Property and equipment, net |  | 3,807 |  |  | 2,778 |  |
| Operating lease assets |  | 1,038 |  |  | 829 |  |
| Goodwill |  | 4,372 |  |  | 4,349 |  |
| Intangible assets, net |  | 1,676 |  |  | 2,339 |  |
| Deferred income tax assets |  | 3,396 |  |  | 1,222 |  |
| Other assets |  | 3,820 |  |  | 3,841 |  |
|  |  | Total assets |  | $ | 41,182 |  |  | $ | 44,187 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,193 |  |  | $ | 1,783 |  |
|  | Accrued and other current liabilities |  | 4,120 |  |  | 2,552 |  |
|  | Short-term debt |  | 1,250 |  |  | — |  |
|  |  | Total current liabilities |  | 6,563 |  |  | 4,335 |  |
| Long-term debt |  | 9,703 |  |  | 10,946 |  |
| Long-term operating lease liabilities |  | 902 |  |  | 741 |  |
| Other long-term liabilities |  | 1,913 |  |  | 1,553 |  |
|  |  | Total liabilities |  | 19,081 |  |  | 17,575 |  |
| Shareholders' equity |  | 22,101 |  |  | 26,612 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 41,182 |  |  | $ | 44,187 |  |

[0001045810-23-000014:8k_2_02:77]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 29, |  | January 30, |  | January 29, |  | January 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,414 |  |  | $ | 3,003 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock based compensation expense | 738 |  |  | 551 |  |  | 2,709 |  |  | 2,004 |  |
| Depreciation and amortization | 426 |  |  | 309 |  |  | 1,544 |  |  | 1,174 |  |
| (Gain) losses on investments in non affiliates, net | 10 |  |  | 53 |  |  | 45 |  |  | (100) |  |
| Deferred income taxes | (647) |  |  | (225) |  |  | (2,164) |  |  | (406) |  |
| Acquisition termination cost | — |  |  | — |  |  | 1,353 |  |  | — |  |
| Other | 20 |  |  | 21 |  |  | (7) |  |  | 47 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | 1,081 |  |  | (692) |  |  | 822 |  |  | (2,215) |  |
| Inventories | (706) |  |  | (374) |  |  | (2,554) |  |  | (774) |  |
| Prepaid expenses and other assets | (210) |  |  | (158) |  |  | (1,517) |  |  | (1,715) |  |
| Accounts payable | (193) |  |  | 183 |  |  | (551) |  |  | 568 |  |
| Accrued liabilities and other current liabilities | 166 |  |  | 423 |  |  | 1,341 |  |  | 581 |  |
| Other long-term liabilities | 150 |  |  | (61) |  |  | 252 |  |  | 192 |  |
| Net cash provided by operating activities | 2,249 |  |  | 3,033 |  |  | 5,641 |  |  | 9,108 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,633 |  |  | 7,417 |  |  | 19,425 |  |  | 15,197 |  |
| Proceeds from sales of marketable securities | — |  |  | 107 |  |  | 1,806 |  |  | 1,023 |  |
| Purchases of marketable securities | (2,133) |  |  | (8,767) |  |  | (11,897) |  |  | (24,787) |  |
| Purchase related to property and equipment and intangible assets | (509) |  |  | (273) |  |  | (1,833) |  |  | (976) |  |
| Acquisitions, net of cash acquired | — |  |  | (60) |  |  | (49) |  |  | (263) |  |
| Investments and other, net | 5 |  |  | (11) |  |  | (77) |  |  | (24) |  |
| Net cash provided by (used in) investing activities | (4) |  |  | (1,587) |  |  | 7,375 |  |  | (9,830) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 5 |  |  | 4 |  |  | 355 |  |  | 281 |  |
| Payments related to repurchases of common stock | (1,212) |  |  | — |  |  | (10,039) |  |  | — |  |
| Payments related to tax on restricted stock units | (344) |  |  | (622) |  |  | (1,475) |  |  | (1,904) |  |
| Dividends paid | (98) |  |  | (100) |  |  | (398) |  |  | (399) |  |
| Principal payments on property and equipment and intangible assets | (4) |  |  | (21) |  |  | (58) |  |  | (83) |  |
| Issuance of debt, net of issuance costs | — |  |  | — |  |  | — |  |  | 4,977 |  |
| Repayment of debt | — |  |  | — |  |  | — |  |  | (1,000) |  |
| Other | (3) |  |  | (5) |  |  | (2) |  |  | (7) |  |
| Net cash provided by (used in) financing activities | (1,656) |  |  | (744) |  |  | (11,617) |  |  | 1,865 |  |
| Change in cash and cash equivalents | 589 |  |  | 702 |  |  | 1,399 |  |  | 1,143 |  |
| Cash and cash equivalents at beginning of period | 2,800 |  |  | 1,288 |  |  | 1,990 |  |  | 847 |  |
| Cash and cash equivalents at end of period | $ | 3,389 |  |  | $ | 1,990 |  |  | $ | 3,389 |  |  | $ | 1,990 |  |

[0001045810-23-000014:8k_2_02:78]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 29, |  | October 30 |  | January 30, |  | January 29, |  | January 30, |
|  |  |  | 2023 |  | 2022 |  | 2022 |  | 2023 |  | 2022 |
| GAAP gross profit |  | $ | 3,833 |  |  | $ | 3,177 |  |  | $ | 4,999 |  |  | $ | 15,356 |  |  | $ | 17,475 |  |
| GAAP gross margin |  | 63.3 | % |  | 53.6 | % |  | 65.4 | % |  | 56.9 | % |  | 64.9 | % |
|  | Acquisition-related and other costs (A) |  | 120 |  |  | 120 |  |  | 86 |  |  | 455 |  |  | 344 |  |
|  | Stock-based compensation expense (B) |  | 30 |  |  | 32 |  |  | 39 |  |  | 138 |  |  | 141 |  |
|  | IP-related costs |  | 16 |  |  | — |  |  | — |  |  | 16 |  |  | 9 |  |
| Non-GAAP gross profit |  | $ | 3,999 |  |  | $ | 3,329 |  |  | $ | 5,124 |  |  | $ | 15,965 |  |  | $ | 17,969 |  |
| Non-GAAP gross margin |  | 66.1 | % |  | 56.1 | % |  | 67.0 | % |  | 59.2 | % |  | 66.8 | % |
| GAAP operating expenses |  | $ | 2,576 |  |  | $ | 2,576 |  |  | $ | 2,029 |  |  | $ | 11,132 |  |  | $ | 7,434 |  |
|  | Stock-based compensation expense (B) |  | (709) |  |  | (713) |  |  | (512) |  |  | (2,572) |  |  | (1,863) |  |
|  | Acquisition-related and other costs (A) |  | (54) |  |  | (54) |  |  | (70) |  |  | (219) |  |  | (292) |  |
|  | Restructuring costs and other |  | (38) |  |  | (16) |  |  | — |  |  | (54) |  |  | — |  |
|  | Acquisition termination cost |  | — |  |  | — |  |  | — |  |  | (1,353) |  |  | — |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | — |  |  | (7) |  |  | — |  |
|  | Contributions |  | — |  |  | — |  |  | — |  |  | (2) |  |  | — |  |
| Non-GAAP operating expenses |  | $ | 1,775 |  |  | $ | 1,793 |  |  | $ | 1,447 |  |  | $ | 6,925 |  |  | $ | 5,279 |  |
| GAAP income from operations |  | $ | 1,257 |  |  | $ | 601 |  |  | $ | 2,970 |  |  | $ | 4,224 |  |  | $ | 10,041 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 967 |  |  | 935 |  |  | 707 |  |  | 4,816 |  |  | 2,649 |  |
| Non-GAAP income from operations |  | $ | 2,224 |  |  | $ | 1,536 |  |  | $ | 3,677 |  |  | $ | 9,040 |  |  | $ | 12,690 |  |
| GAAP other income (expense), net |  | $ | 32 |  |  | $ | 12 |  |  | $ | (105) |  |  | $ | (43) |  |  | $ | (100) |  |
|  | (Gains) losses from non-affiliated investments |  | 10 |  |  | 11 |  |  | 53 |  |  | 45 |  |  | (99) |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | — |  |  | 5 |  |  | 3 |  |
| Non-GAAP other income (expense), net |  | $ | 43 |  |  | $ | 24 |  |  | $ | (52) |  |  | $ | 7 |  |  | $ | (196) |  |
| GAAP net income |  | $ | 1,414 |  |  | $ | 680 |  |  | $ | 3,003 |  |  | $ | 4,368 |  |  | $ | 9,752 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 978 |  |  | 947 |  |  | 760 |  |  | 4,865 |  |  | 2,553 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (218) |  |  | (171) |  |  | (330) |  |  | (867) |  |  | (712) |  |
|  | Domestication tax adjustments |  | — |  |  | — |  |  | 7 |  |  | — |  |  | (244) |  |
|  | Foreign tax benefit |  | — |  |  | — |  |  | (90) |  |  | — |  |  | (90) |  |
| Non-GAAP net income |  | $ | 2,174 |  |  | $ | 1,456 |  |  | $ | 3,350 |  |  | $ | 8,366 |  |  | $ | 11,259 |  |

[0001045810-23-000014:8k_2_02:79]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 29, |  | October 30 |  | January 30, |  | January 29, |  | January 30, |
|  |  |  | 2023 |  | 2022 |  | 2022 |  | 2023 |  | 2022 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.57 |  |  | $ | 0.27 |  |  | $ | 1.18 |  |  | $ | 1.74 |  |  | $ | 3.85 |  |
|  | Non-GAAP |  | $ | 0.88 |  |  | $ | 0.58 |  |  | $ | 1.32 |  |  | $ | 3.34 |  |  | $ | 4.44 |  |
| Weighted average shares used in diluted net income per share computation |  | 2,477 |  |  | 2,499 |  |  | 2,545 |  |  | 2,507 |  |  | 2,535 |  |
| GAAP net cash provided by operating activities |  | $ | 2,249 |  |  | $ | 392 |  |  | $ | 3,033 |  |  | $ | 5,641 |  |  | $ | 9,108 |  |
|  | Purchases related to property and equipment and intangible assets |  | (509) |  |  | (530) |  |  | (273) |  |  | (1,833) |  |  | (976) |  |
|  | Principal payments on property and equipment and intangible assets |  | (4) |  |  | (18) |  |  | (21) |  |  | (58) |  |  | (83) |  |
| Free cash flow |  | $ | 1,736 |  |  | $ | (156) |  |  | $ | 2,739 |  |  | $ | 3,750 |  |  | $ | 8,049 |  |

[0001045810-23-000014:8k_2_02:80]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 29, |  | October 30 |  | January 30, |  | January 29, |  | January 30, |
|  |  |  | 2023 |  | 2022 |  | 2022 |  | 2023 |  | 2022 |
|  | Cost of revenue |  | $ | 120 |  |  | $ | 120 |  |  | $ | 86 |  |  | $ | 455 |  |  | $ | 344 |  |
|  | Research and development |  | $ | 10 |  |  | $ | 10 |  |  | $ | 9 |  |  | $ | 39 |  |  | $ | 19 |  |
|  | Sales, general and administrative |  | $ | 44 |  |  | $ | 44 |  |  | $ | 61 |  |  | $ | 180 |  |  | $ | 273 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 29, |  | October 30 |  | January 30, |  | January 29, |  | January 30, |
|  |  |  | 2023 |  | 2022 |  | 2022 |  | 2023 |  | 2022 |
|  | Cost of revenue |  | $ | 30 |  |  | $ | 32 |  |  | $ | 39 |  |  | $ | 138 |  |  | $ | 141 |  |
|  | Research and development |  | $ | 527 |  |  | $ | 530 |  |  | $ | 362 |  |  | $ | 1,892 |  |  | $ | 1,298 |  |
|  | Sales, general and administrative |  | $ | 182 |  |  | $ | 183 |  |  | $ | 150 |  |  | $ | 680 |  |  | $ | 565 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-23-000014:8k_2_02:81]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2024 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 64.1 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 2.4 | % |
| Non-GAAP gross margin |  | 66.5 | % |
| GAAP operating expenses |  | $ | 2,525 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (750) |  |
| Non-GAAP operating expenses |  | $ | 1,775 |  |
