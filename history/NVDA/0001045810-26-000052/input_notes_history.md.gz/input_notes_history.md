# NVDA note change history — 0001045810-25-000230 → 0001045810-26-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-05-20):
[0001045810-26-000052:note_history:1]
Manufacturing, supply, and capacity commitments reflect data center-scale production and longer future ordering horizons across current and future product architectures. We enter into agreements with our supply vendors that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Changes to these agreements may result in additional costs. As of April 26, 2026, these commitments were $119 billion for which $95 billion will be paid in the remainder of fiscal year 2027 and the remaining balance will be paid in fiscal years 2028 through 2031.

- added (2026-05-20):
[0001045810-26-000052:note_history:2]
Multi-year cloud service agreement commitments as of April 26, 2026, were $30 billion for which $6 billion, $7 billion, $7 billion, $5 billion, $3 billion, and $2 billion will be paid in the remainder of fiscal year 2027, each fiscal year from 2028 through 2031, and fiscal year 2032 and thereafter, respectively. Cloud service capacity may be reduced or terminated. Cloud service agreements will be primarily used to support our research and development efforts.

- added (2026-05-20):
[0001045810-26-000052:note_history:3]
Other vendor commitments were $6 billion as of April 26, 2026, of which the majority will be paid through fiscal year 2027.

- added (2026-05-20):
[0001045810-26-000052:note_history:4]
The estimated amount of product warranty liabilities was $2.9 billion and $2.8 billion as of April 26, 2026 and January 25, 2026, respectively. The estimated product returns and product warranty activity consisted of the following:

- added (2026-05-20):
[0001045810-26-000052:note_history:5]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Balance at beginning of period | $ | 2,807 |  |  | $ | 1,290 |  |  |  |  |  |
| Additions | 330 |  |  | 870 |  |  |  |  |  |
| Utilization | (189) |  |  | (80) |  |  |  |  |  |
| Balance at end of period | $ | 2,948 |  |  | $ | 2,080 |  |  |  |  |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:6]
For the first quarter of fiscal years 2027 and 2026, the additions in product warranty liabilities primarily related to our Compute & Networking segment.

- changed (2026-05-20):
[0001045810-26-000052:note_history:7]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings. On March 25, 2026, the district court granted plaintiffs’ motion for class certification and certified a class of investors consisting of all persons or entities who purchased or otherwise acquired NVIDIA common stock between August 10, 2017, and November 15, 2018, inclusive, excluding certain persons and entities, such as NVIDIA’s officers and directors, and members of their immediate families, among others. On April 8, 2026, NVIDIA filed a petition with the Ninth Circuit for permission to appeal the district court’s order pursuant to Federal Rule of Civil Procedure 23(f).
  (was, 2025-11-19, similarity 0.792):
[0001045810-25-000230:note_history:7]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

- added (2026-05-20):
[0001045810-26-000052:note_history:8]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-

- changed (2026-05-20):
[0001045810-26-000052:note_history:9]
cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2025-11-19, similarity 0.6338):
[0001045810-25-000230:note_history:9]
Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- changed (2026-05-20):
[0001045810-26-000052:note_history:10]
As of April 26, 2026, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.
  (was, 2025-11-19, similarity 0.9937):
[0001045810-25-000230:note_history:10]
As of October 26, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.

- removed (2026-05-20):
[0001045810-25-000230:note_history:11]
Manufacturing production, long-term supply and capacity, and other related commitments reflect long lead and cycle times for our current and future product architectures. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. As of October 26, 2025, these commitments were $50.3 billion, of which substantially all will be paid through fiscal year 2027.

- removed (2026-05-20):
[0001045810-25-000230:note_history:12]
Multi-year cloud service agreement commitments as of October 26, 2025, were $26 billion for which $1 billion, $6 billion, $6 billion, $5 billion, $4 billion, and $4 billion will be paid in fiscal years 2026 (fourth quarter), 2027, 2028, 2029, 2030, and 2031 & thereafter, respectively. Some cloud service capacity may be reduced, terminated or sold to others by the CSPs, in which case our commitments will be reduced. We expect cloud service agreements to be used to support our research and development efforts and DGX Cloud offerings.
nvestment commitments are $6.5 billion as of October 26, 2025, including $5 billion in Intel Corporation which is subject to regulatory approval. In the third quarter of fiscal year 2026, we entered into a letter of intent with an opportunity to invest in OpenAI. In November 2025, we entered into an agreement, subject to certain closing conditions, to invest up to $10 billion in Anthropic.
Other commitments were $2.1 billion as of October 26, 2025, of which the majority will be paid through fiscal year 2027.

- removed (2026-05-20):
[0001045810-25-000230:note_history:13]
The estimated product warranty activity consisted of the following:

- removed (2026-05-20):
[0001045810-25-000230:note_history:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 26, 2025 |  | Oct 27, 2024 |  | Oct 26, 2025 |  | Oct 27, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,144 |  |  | $ | 741 |  |  | $ | 1,290 |  |  | $ | 306 |  |
| Additions | 1,074 |  |  | 304 |  |  | 2,164 |  |  | 775 |  |
| Utilization | (511) |  |  | (36) |  |  | (747) |  |  | (72) |  |
| Balance at end of period | $ | 2,707 |  |  | $ | 1,009 |  |  | $ | 2,707 |  |  | $ | 1,009 |  |

- removed (2026-05-20):
[0001045810-25-000230:note_history:15]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-20):
[0001045810-26-000052:note_history:16]
Certain prior fiscal year balances have been reclassified to conform to the current period presentation.
  (was, 2025-11-19, similarity 0.8756):
[0001045810-25-000230:note_history:16]
Certain balances from the prior fiscal year have been reclassified to conform to the current period presentation.

- changed (2026-05-20):
[0001045810-26-000052:note_history:17]
Fiscal year 2027 is a 53-week year and fiscal year 2026 was a 52-week year, both ending on the last Sunday in January. The first quarters of fiscal years 2027 and 2026 were both 13-week quarters. The fourth quarter of fiscal year 2027 will be a 14-week quarter.
  (was, 2025-11-19, similarity 0.6837):
[0001045810-25-000230:note_history:17]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The third quarters of fiscal years 2026 and 2025 were both 13-week quarters.

- changed (2026-05-20):
[0001045810-26-000052:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates.
  (was, 2025-11-19, similarity 0.6044):
[0001045810-25-000230:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, non-marketable equity securities, other contingencies, property, plant, and equipment, restructuring and other charges, revenue recognition, and stock-based compensation. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- changed (2026-05-20):
[0001045810-26-000052:note_history:19]
In November 2024, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.
  (was, 2025-11-19, similarity 0.9613):
[0001045810-25-000230:note_history:19]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.

- removed (2026-05-20):
[0001045810-25-000230:note_history:20]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in the fiscal year 2026 annual report.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-20):
[0001045810-26-000052:note_history:21]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  |  |
|  |  |  |  | Apr 26, 2026 |  | Jan 25, 2026 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 3.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 13.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 23.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (30) |  |  | (32) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,470 |  |  | $ | 8,468 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 7,470 |  |  | $ | 7,469 |  |
  (was, 2025-11-19, similarity 0.9645):
[0001045810-25-000230:note_history:21]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 26, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.9 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (33) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,467 |  |  | $ | 8,463 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 7,468 |  |  | $ | 8,463 |  |

- changed (2026-05-20):
[0001045810-26-000052:note_history:22]
As of April 26, 2026 and January 25, 2026, the estimated fair value of debt was $7.4 billion and $7.5 billion, respectively. The estimated fair values are based on Level 2 inputs.
  (was, 2025-11-19, similarity 0.9697):
[0001045810-25-000230:note_history:22]
As of October 26, 2025 and January 26, 2025, the estimated fair value of debt was $7.6 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

- changed (2026-05-20):
[0001045810-26-000052:note_history:23]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity dates of the notes are stated by calendar year.
  (was, 2025-11-19, similarity 0.876):
[0001045810-25-000230:note_history:23]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity of the notes is calendar year.

- changed (2026-05-20):
[0001045810-26-000052:note_history:24]
As of April 26, 2026, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2025-11-19, similarity 0.9587):
[0001045810-25-000230:note_history:24]
As of October 26, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

- added (2026-05-20):
[0001045810-26-000052:note_history:25]
As of April 26, 2026, our commercial paper program had a capacity of $25.0 billion, with no amounts outstanding.

- removed (2026-05-20):
[0001045810-25-000230:note_history:26]
Short-term Debt

- removed (2026-05-20):
[0001045810-25-000230:note_history:27]
As of October 26, 2025, short-term debt was $999 million.

- removed (2026-05-20):
[0001045810-25-000230:note_history:28]
We have a $575 million commercial paper program to support general corporate purposes. As of October 26, 2025 and January 26, 2025, we had no commercial paper outstanding.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-20):
[0001045810-26-000052:note_history:29]
|  | Apr 26, 2026 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,883 |  |  | $ | 43 |  |  | $ | (8) |  |  | $ | 21,918 |  |  | $ | 470 |  |  | $ | 21,448 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,092 |  |  | 48 |  |  | (8) |  |  | 15,132 |  |  | 1,533 |  |  | 13,599 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,009 |  |  | 2 |  |  | (1) |  |  | 2,010 |  |  | — |  |  | 2,010 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 | 132 |  |  | — |  |  | — |  |  | 132 |  |  | 132 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 | 10,212 |  |  | — |  |  | — |  |  | 10,212 |  |  | 10,212 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 29,887 |  |  | — |  |  | — |  |  | 21,023 |  |  | 8,864 |  |
| Publicly-held equity securities (1) (3) | Level 2 |  |  |  |  |  |  | 9,214 |  |  | — |  |  | — |  |  | 9,214 |  |  | — |  |
| Total |  | $ | 49,368 |  |  | $ | 94 |  |  | $ | (17) |  |  | $ | 88,546 |  |  | $ | 12,347 |  |  | $ | 37,098 |  |  | $ | 30,237 |  |  | $ | 8,864 |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:30]
(1)    The balance as of April 26, 2026 included $27.4 billion of investments, which are subject to short-term lock-up restrictions on the ability to sell.

- added (2026-05-20):
[0001045810-26-000052:note_history:31]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $8.9 billion as of April 26, 2026, was included in Other assets.

- added (2026-05-20):
[0001045810-26-000052:note_history:32]
(3)    The publicly-held equity securities classified in Level 2 include investments in warrants and preferred stock convertible to common stock in public companies.

- added (2026-05-20):
[0001045810-26-000052:note_history:33]
|  | Jan 25, 2026 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,635 |  |  | $ | 77 |  |  | $ | (3) |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,410 |  |  | 92 |  |  | (3) |  |  | 15,499 |  |  | 345 |  |  | 15,154 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,157 |  |  | 4 |  |  | — |  |  | 2,161 |  |  | — |  |  | 2,161 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 | 110 |  |  | — |  |  | — |  |  | 110 |  |  | 110 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 | 7,830 |  |  | — |  |  | — |  |  | 7,830 |  |  | 7,830 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 17,726 |  |  | — |  |  | — |  |  | 12,886 |  |  | 4,840 |  |
| Total |  | $ | 47,182 |  |  | $ | 174 |  |  | $ | (6) |  |  | $ | 65,076 |  |  | $ | 8,285 |  |  | $ | 39,065 |  |  | $ | 12,886 |  |  | $ | 4,840 |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:34]
(1)    The balance as of January 25, 2026 included $10.5 billion of investments that are subject to short-term lock-up restrictions on the ability to sell.

- added (2026-05-20):
[0001045810-26-000052:note_history:35]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $4.8 billion as of January 25, 2026, was included in Other assets.

- changed (2026-05-20):
[0001045810-26-000052:note_history:36]
The estimated fair values of debt securities included in cash equivalents and marketable debt securities are shown below by contractual maturity.
  (was, 2025-11-19, similarity 0.9789):
[0001045810-25-000230:note_history:36]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

- changed (2026-05-20):
[0001045810-26-000052:note_history:37]
|  | Apr 26, 2026 |
|  | (In millions) |
| Less than one year | $ | 24,307 |  |
| Due in 1 - 5 years | 14,926 |  |
| Total | $ | 39,233 |  |
  (was, 2025-11-19, similarity 0.9739):
[0001045810-25-000230:note_history:37]
|  | Oct 26, 2025 |
|  | (In millions) |
| Less than one year | $ | 21,848 |  |
| Due in 1 - 5 years | 33,104 |  |
| Total | $ | 54,952 |  |

- removed (2026-05-20):
[0001045810-25-000230:note_history:38]
|  | Oct 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 22,032 |  |  | $ | 188 |  |  | $ | — |  |  | $ | 22,220 |  |  | $ | 665 |  |  | $ | 21,555 |  |
| Corporate debt securities | Level 2 | 21,588 |  |  | 172 |  |  | (1) |  |  | 21,759 |  |  | 320 |  |  | 21,439 |  |
| Money market funds | Level 1 | 8,610 |  |  | — |  |  | — |  |  | 8,610 |  |  | 8,610 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,206 |  |  | 12 |  |  | — |  |  | 2,218 |  |  | — |  |  | 2,218 |  |
| Certificates of deposit | Level 2 | 104 |  |  | — |  |  | — |  |  | 104 |  |  | 104 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 54,580 |  |  | 373 |  |  | (1) |  |  | 54,952 |  |  | 9,699 |  |  | 45,253 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,869 |  |  | — |  |  | 3,869 |  |
| Total |  | $ | 54,580 |  |  | $ | 373 |  |  | $ | (1) |  |  | $ | 58,821 |  |  | $ | 9,699 |  |  | $ | 49,122 |  |

- removed (2026-05-20):
[0001045810-25-000230:note_history:39]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading.

- removed (2026-05-20):
[0001045810-25-000230:note_history:40]
|  | Jan 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-20):
[0001045810-26-000052:note_history:41]
Cash Equivalents and Marketable Securities
Cash equivalents and marketable securities including debt and equity securities are measured at fair value using quoted prices in active markets for identical assets (Level 1) or for similar assets or use of other observable inputs (Level 2).

- added (2026-05-20):
[0001045810-26-000052:note_history:42]
The following is a summary of cash equivalents and marketable securities:

- added (2026-05-20):
[0001045810-26-000052:note_history:43]
|  | Apr 26, 2026 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,883 |  |  | $ | 43 |  |  | $ | (8) |  |  | $ | 21,918 |  |  | $ | 470 |  |  | $ | 21,448 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,092 |  |  | 48 |  |  | (8) |  |  | 15,132 |  |  | 1,533 |  |  | 13,599 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,009 |  |  | 2 |  |  | (1) |  |  | 2,010 |  |  | — |  |  | 2,010 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 | 132 |  |  | — |  |  | — |  |  | 132 |  |  | 132 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 | 10,212 |  |  | — |  |  | — |  |  | 10,212 |  |  | 10,212 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 29,887 |  |  | — |  |  | — |  |  | 21,023 |  |  | 8,864 |  |
| Publicly-held equity securities (1) (3) | Level 2 |  |  |  |  |  |  | 9,214 |  |  | — |  |  | — |  |  | 9,214 |  |  | — |  |
| Total |  | $ | 49,368 |  |  | $ | 94 |  |  | $ | (17) |  |  | $ | 88,546 |  |  | $ | 12,347 |  |  | $ | 37,098 |  |  | $ | 30,237 |  |  | $ | 8,864 |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:44]
(1)    The balance as of April 26, 2026 included $27.4 billion of investments, which are subject to short-term lock-up restrictions on the ability to sell.

- added (2026-05-20):
[0001045810-26-000052:note_history:45]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $8.9 billion as of April 26, 2026, was included in Other assets.

- added (2026-05-20):
[0001045810-26-000052:note_history:46]
(3)    The publicly-held equity securities classified in Level 2 include investments in warrants and preferred stock convertible to common stock in public companies.

- added (2026-05-20):
[0001045810-26-000052:note_history:47]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $13.4 billion for the first quarter of fiscal year 2027. Net unrealized losses on investments in publicly-held equity securities held at period end were $222 million for the first quarter of fiscal year 2026. Unrealized gains and losses are recognized in Other income (expense), net, in the Condensed Consolidated Statements of Income.

- added (2026-05-20):
[0001045810-26-000052:note_history:48]
|  | Jan 25, 2026 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,635 |  |  | $ | 77 |  |  | $ | (3) |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,410 |  |  | 92 |  |  | (3) |  |  | 15,499 |  |  | 345 |  |  | 15,154 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,157 |  |  | 4 |  |  | — |  |  | 2,161 |  |  | — |  |  | 2,161 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 | 110 |  |  | — |  |  | — |  |  | 110 |  |  | 110 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 | 7,830 |  |  | — |  |  | — |  |  | 7,830 |  |  | 7,830 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 17,726 |  |  | — |  |  | — |  |  | 12,886 |  |  | 4,840 |  |
| Total |  | $ | 47,182 |  |  | $ | 174 |  |  | $ | (6) |  |  | $ | 65,076 |  |  | $ | 8,285 |  |  | $ | 39,065 |  |  | $ | 12,886 |  |  | $ | 4,840 |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:49]
(1)    The balance as of January 25, 2026 included $10.5 billion of investments that are subject to short-term lock-up restrictions on the ability to sell.

- added (2026-05-20):
[0001045810-26-000052:note_history:50]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $4.8 billion as of January 25, 2026, was included in Other assets.

- changed (2026-05-20):
[0001045810-26-000052:note_history:51]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
|  | Less than 12 months |  | Less than 12 months |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 12,238 |  |  | $ | (8) |  |  | $ | 10,666 |  |  | $ | (3) |  |
| Corporate debt securities | 2,658 |  |  | (8) |  |  | 1,332 |  |  | (3) |  |
| Debt securities issued by U.S. government agencies | 1,291 |  |  | (1) |  |  | 1,134 |  |  | — |  |
| Total | $ | 16,187 |  |  | $ | (17) |  |  | $ | 13,132 |  |  | $ | (6) |  |
  (was, 2025-11-19, similarity 0.7504):
[0001045810-25-000230:note_history:51]
|  | Oct 26, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,223 |  |  | $ | — |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 899 |  |  | (1) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 75 |  |  | — |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 2,197 |  |  | $ | (1) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

- changed (2026-05-20):
[0001045810-26-000052:note_history:52]
The estimated fair values of debt securities included in cash equivalents and marketable debt securities are shown below by contractual maturity.
  (was, 2025-11-19, similarity 0.9789):
[0001045810-25-000230:note_history:52]
The estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

- changed (2026-05-20):
[0001045810-26-000052:note_history:53]
|  | Apr 26, 2026 |
|  | (In millions) |
| Less than one year | $ | 24,307 |  |
| Due in 1 - 5 years | 14,926 |  |
| Total | $ | 39,233 |  |
  (was, 2025-11-19, similarity 0.9739):
[0001045810-25-000230:note_history:53]
|  | Oct 26, 2025 |
|  | (In millions) |
| Less than one year | $ | 21,848 |  |
| Due in 1 - 5 years | 33,104 |  |
| Total | $ | 54,952 |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:54]
Non-marketable Securities
Non-marketable Equity Securities

- added (2026-05-20):
[0001045810-26-000052:note_history:55]
Our non-marketable equity securities are primarily in privately-held companies carried at cost less impairment, and adjusted for observable price changes. We value investments using observable comparable transactions and other inputs including volatility, expected time to liquidity, the risk-free rate, and security-specific rights and obligations.

- added (2026-05-20):
[0001045810-26-000052:note_history:56]
Adjustments to the carrying value of privately-held securities:

- added (2026-05-20):
[0001045810-26-000052:note_history:57]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Balance at beginning of period | $ | 22,251 |  |  | $ | 3,387 |  |  |  |  |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 17,899 |  |  | 649 |  |  |  |  |  |
| Unrealized gains (1) | 2,603 |  |  | 63 |  |  |  |  |  |
| Reclassification (2) | (389) |  |  | (843) |  |  |  |  |  |
| Impairments and unrealized losses | (28) |  |  | (16) |  |  |  |  |  |
| Balance at end of period | $ | 42,336 |  |  | $ | 3,240 |  |  |  |  |  |

- added (2026-05-20):
[0001045810-26-000052:note_history:58]
(1)    Unrealized gains are recognized in Other income (expense), net, in the Condensed Consolidated Statements of Income.

- changed (2026-05-20):
[0001045810-26-000052:note_history:59]
(2)    Includes primarily reclassifications to marketable securities following public market trading.
  (was, 2025-11-19, similarity 0.6367):
[0001045810-25-000230:note_history:59]
(1)    In the first quarter of fiscal year 2026, one investment was reclassified from non-marketable equity securities to marketable securities following public market trading.

- added (2026-05-20):
[0001045810-26-000052:note_history:60]
Non-marketable equity securities had cumulative gross unrealized gains of $5.3 billion and $396 million, and cumulative gross unrealized losses and impairments of $199 million and $110 million as of April 26, 2026 and April 27, 2025, respectively.

- added (2026-05-20):
[0001045810-26-000052:note_history:61]
Equity Method Investments

- added (2026-05-20):
[0001045810-26-000052:note_history:62]
We have $1.0 billion of investments in infrastructure funds accounted for using the equity method as of April 26, 2026. Our maximum loss exposure under these investments, including invested and future committed amounts, was $2.3 billion as of April 26, 2026.

- added (2026-05-20):
[0001045810-26-000052:note_history:63]
Investment Commitments

- added (2026-05-20):
[0001045810-26-000052:note_history:64]
Total Investment commitments were $27 billion as of April 26, 2026, subject to certain contingencies, which we expect will be made through the remainder of fiscal year 2027.

- removed (2026-05-20):
[0001045810-25-000230:note_history:65]
Cash Equivalents and Marketable Securities
The fair values of our financial assets are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis. The following is a summary of cash equivalents and marketable securities:

- removed (2026-05-20):
[0001045810-25-000230:note_history:66]
|  | Oct 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 22,032 |  |  | $ | 188 |  |  | $ | — |  |  | $ | 22,220 |  |  | $ | 665 |  |  | $ | 21,555 |  |
| Corporate debt securities | Level 2 | 21,588 |  |  | 172 |  |  | (1) |  |  | 21,759 |  |  | 320 |  |  | 21,439 |  |
| Money market funds | Level 1 | 8,610 |  |  | — |  |  | — |  |  | 8,610 |  |  | 8,610 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,206 |  |  | 12 |  |  | — |  |  | 2,218 |  |  | — |  |  | 2,218 |  |
| Certificates of deposit | Level 2 | 104 |  |  | — |  |  | — |  |  | 104 |  |  | 104 |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 54,580 |  |  | 373 |  |  | (1) |  |  | 54,952 |  |  | 9,699 |  |  | 45,253 |  |
| Publicly-held equity securities (1) | Level 1 |  |  |  |  |  |  | 3,869 |  |  | — |  |  | 3,869 |  |
| Total |  | $ | 54,580 |  |  | $ | 373 |  |  | $ | (1) |  |  | $ | 58,821 |  |  | $ | 9,699 |  |  | $ | 49,122 |  |

- removed (2026-05-20):
[0001045810-25-000230:note_history:67]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $670 million and $2.4 billion for the third quarter and first nine months of fiscal year 2026, respectively. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for the third quarter and first nine months of fiscal year 2025.

- removed (2026-05-20):
[0001045810-25-000230:note_history:68]
|  | Jan 26, 2025 |
|  | Pricing Category | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  |  | (In millions) |
| Corporate debt securities | Level 2 | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | Level 2 | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | Level 1 | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | Level 2 | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | Level 2 | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income |  | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities | Level 1 |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total |  | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

- removed (2026-05-20):
[0001045810-25-000230:note_history:69]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater, with balances of $337 million and $213 million as of October 26, 2025 and January 26, 2025, respectively, were not significant.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-20):
[0001045810-26-000052:note_history:70]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  |  |
|  |  |  |  | Apr 26, 2026 |  | Jan 25, 2026 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 3.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 13.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 23.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (30) |  |  | (32) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,470 |  |  | $ | 8,468 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 7,470 |  |  | $ | 7,469 |  |
  (was, 2025-11-19, similarity 0.9645):
[0001045810-25-000230:note_history:70]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 26, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.9 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (33) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,467 |  |  | $ | 8,463 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 7,468 |  |  | $ | 8,463 |  |
