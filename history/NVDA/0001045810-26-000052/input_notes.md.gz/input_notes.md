# NVDA notes — 0001045810-26-000052


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-26-000052:notes:1]
[same as prior period, unchanged from 0001045810-25-000230:notes:1]

[0001045810-26-000052:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2026 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair presentation of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026.

[0001045810-26-000052:notes:3]
Certain prior fiscal year balances have been reclassified to conform to the current period presentation.

[0001045810-26-000052:notes:4]
[same as prior period, unchanged from 0001045810-25-000230:notes:4]

[0001045810-26-000052:notes:5]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026.

[0001045810-26-000052:notes:6]
[same as prior period, unchanged from 0001045810-25-000230:notes:6]

[0001045810-26-000052:notes:7]
Fiscal year 2027 is a 53-week year and fiscal year 2026 was a 52-week year, both ending on the last Sunday in January. The first quarters of fiscal years 2027 and 2026 were both 13-week quarters. The fourth quarter of fiscal year 2027 will be a 14-week quarter.

[0001045810-26-000052:notes:8]
[same as prior period, unchanged from 0001045810-25-000230:notes:8]

[0001045810-26-000052:notes:9]
[same as prior period, unchanged from 0001045810-25-000230:notes:9]

[0001045810-26-000052:notes:10]
[same as prior period, unchanged from 0001045810-25-000230:notes:10]

[0001045810-26-000052:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates.

[0001045810-26-000052:notes:12]
Recently Issued Accounting Pronouncements

[0001045810-26-000052:notes:13]
[same as prior period, unchanged from 0001045810-25-000230:notes:13]

[0001045810-26-000052:notes:14]
In November 2024, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in the fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-26-000052:notes:15]
Stock-Based Compensation
We recognize stock-based compensation expense from grants of restricted stock units, or RSUs, performance stock units, or PSUs, and market-based PSUs, and issuances under our employee stock purchase plan, or ESPP.

[0001045810-26-000052:notes:16]
Condensed Consolidated Statements of Income include stock-based compensation expense as follows:

[0001045810-26-000052:notes:17]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Cost of revenue | $ | 68 |  |  | $ | 64 |  |  |  |  |  |
| Research and development | 1,459 |  |  | 1,063 |  |  |  |  |  |
| Sales, general and administrative | 401 |  |  | 347 |  |  |  |  |  |
| Total | $ | 1,928 |  |  | $ | 1,474 |  |  |  |  |  |

[0001045810-26-000052:notes:18]
[same as prior period, unchanged from 0001045810-25-000230:notes:19]

[0001045810-26-000052:notes:19]
[same as prior period, unchanged from 0001045810-25-000230:notes:20]

[0001045810-26-000052:notes:20]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balance as of Jan 25, 2026 | 189 |  |  | $ | 81.51 |  |
| Granted | 44 |  |  | $ | 181.73 |  |
| Vested | (31) |  |  | $ | 48.04 |  |
| Canceled and forfeited | (2) |  |  | $ | 95.82 |  |
| Balance as of Apr 26, 2026 | 200 |  |  | $ | 108.92 |  |

[0001045810-26-000052:notes:21]
As of April 26, 2026, aggregate unearned stock-based compensation expense was $20.8 billion, which is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and one year for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-26-000052:notes:22]
[same as prior period, unchanged from 0001045810-25-000230:notes:23]

[0001045810-26-000052:notes:23]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions, except per share data) |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 58,321 |  |  | $ | 18,775 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,286 |  |  | 24,441 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 105 |  |  | 170 |  |  |  |  |  |
| Diluted weighted average shares | 24,391 |  |  | 24,611 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 2.40 |  |  | $ | 0.77 |  |  |  |  |  |
| Diluted (2) | $ | 2.39 |  |  | $ | 0.76 |  |  |  |  |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 47 |  |  | 62 |  |  |  |  |  |

[0001045810-26-000052:notes:24]
[same as prior period, unchanged from 0001045810-25-000230:notes:25]

[0001045810-26-000052:notes:25]
[same as prior period, unchanged from 0001045810-25-000230:notes:26]

[0001045810-26-000052:notes:26]
[same as prior period, unchanged from 0001045810-25-000230:notes:27]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-26-000052:notes:27]
[same as prior period, unchanged from 0001045810-25-000230:notes:52]

[0001045810-26-000052:notes:28]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 5,658 |  |  | $ | (2,759) |  |  | $ | 2,899 |  |  | $ | 5,656 |  |  | $ | (2,580) |  |  | $ | 3,076 |  |
| Patents and licensed technology | 525 |  |  | (304) |  |  | 221 |  |  | 528 |  |  | (298) |  |  | 230 |  |
| Total intangible assets | $ | 6,183 |  |  | $ | (3,063) |  |  | $ | 3,120 |  |  | $ | 6,184 |  |  | $ | (2,878) |  |  | $ | 3,306 |  |

[0001045810-26-000052:notes:29]
Amortization expense associated with intangible assets was $232 million and $159 million for the first quarter of fiscal years 2027 and 2026, respectively.

[0001045810-26-000052:notes:30]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of April 26, 2026:

[0001045810-26-000052:notes:31]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2027 (excluding the first quarter of fiscal year 2027) | $ | 689 |  |
| 2028 | 754 |  |
| 2029 | 610 |  |
| 2030 | 516 |  |
| 2031 | 468 |  |
| 2032 and thereafter | 83 |  |
| Total | $ | 3,120 |  |

[0001045810-26-000052:notes:32]
In the first quarter of fiscal year 2027, goodwill increased by $62 million from acquisitions and was allocated to our Compute & Networking reporting unit.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-26-000052:notes:33]
Cash Equivalents and Marketable Securities
Cash equivalents and marketable securities including debt and equity securities are measured at fair value using quoted prices in active markets for identical assets (Level 1) or for similar assets or use of other observable inputs (Level 2).

[0001045810-26-000052:notes:34]
The following is a summary of cash equivalents and marketable securities:

[0001045810-26-000052:notes:35]
|  | Apr 26, 2026 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,883 |  |  | $ | 43 |  |  | $ | (8) |  |  | $ | 21,918 |  |  | $ | 470 |  |  | $ | 21,448 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,092 |  |  | 48 |  |  | (8) |  |  | 15,132 |  |  | 1,533 |  |  | 13,599 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,009 |  |  | 2 |  |  | (1) |  |  | 2,010 |  |  | — |  |  | 2,010 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 | 132 |  |  | — |  |  | — |  |  | 132 |  |  | 132 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 | 10,212 |  |  | — |  |  | — |  |  | 10,212 |  |  | 10,212 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 29,887 |  |  | — |  |  | — |  |  | 21,023 |  |  | 8,864 |  |
| Publicly-held equity securities (1) (3) | Level 2 |  |  |  |  |  |  | 9,214 |  |  | — |  |  | — |  |  | 9,214 |  |  | — |  |
| Total |  | $ | 49,368 |  |  | $ | 94 |  |  | $ | (17) |  |  | $ | 88,546 |  |  | $ | 12,347 |  |  | $ | 37,098 |  |  | $ | 30,237 |  |  | $ | 8,864 |  |

[0001045810-26-000052:notes:36]
(1)    The balance as of April 26, 2026 included $27.4 billion of investments, which are subject to short-term lock-up restrictions on the ability to sell.

[0001045810-26-000052:notes:37]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $8.9 billion as of April 26, 2026, was included in Other assets.

[0001045810-26-000052:notes:38]
(3)    The publicly-held equity securities classified in Level 2 include investments in warrants and preferred stock convertible to common stock in public companies.

[0001045810-26-000052:notes:39]
Publicly-held equity securities are subject to market price volatility. Net unrealized gains on investments in publicly-held equity securities held at period end were $13.4 billion for the first quarter of fiscal year 2027. Net unrealized losses on investments in publicly-held equity securities held at period end were $222 million for the first quarter of fiscal year 2026. Unrealized gains and losses are recognized in Other income (expense), net, in the Condensed Consolidated Statements of Income.

[0001045810-26-000052:notes:40]
|  | Jan 25, 2026 |
|  | Pricing Category | Cost or AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Debt Securities |  | Marketable Equity Securities |  | Other Assets |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | Level 2 | $ | 21,635 |  |  | $ | 77 |  |  | $ | (3) |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | 21,709 |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | Level 2 | 15,410 |  |  | 92 |  |  | (3) |  |  | 15,499 |  |  | 345 |  |  | 15,154 |  |  | — |  |  | — |  |
| Debt securities issued by U.S. government agencies | Level 2 | 2,157 |  |  | 4 |  |  | — |  |  | 2,161 |  |  | — |  |  | 2,161 |  |  | — |  |  | — |  |
| Certificates of deposit | Level 2 | 110 |  |  | — |  |  | — |  |  | 110 |  |  | 110 |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | Level 2 | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | — |  |
| Money market funds | Level 1 | 7,830 |  |  | — |  |  | — |  |  | 7,830 |  |  | 7,830 |  |  | — |  |  | — |  |  | — |  |
| Publicly-held equity securities (1) (2) | Level 1 |  |  |  |  |  |  | 17,726 |  |  | — |  |  | — |  |  | 12,886 |  |  | 4,840 |  |
| Total |  | $ | 47,182 |  |  | $ | 174 |  |  | $ | (6) |  |  | $ | 65,076 |  |  | $ | 8,285 |  |  | $ | 39,065 |  |  | $ | 12,886 |  |  | $ | 4,840 |  |

[0001045810-26-000052:notes:41]
(1)    The balance as of January 25, 2026 included $10.5 billion of investments that are subject to short-term lock-up restrictions on the ability to sell.

[0001045810-26-000052:notes:42]
(2)    The long-term portion of publicly-held equity securities, which are subject to lock-up restrictions through December 2027 of $4.8 billion as of January 25, 2026, was included in Other assets.

[0001045810-26-000052:notes:43]
The following table provides the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-26-000052:notes:44]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
|  | Less than 12 months |  | Less than 12 months |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 12,238 |  |  | $ | (8) |  |  | $ | 10,666 |  |  | $ | (3) |  |
| Corporate debt securities | 2,658 |  |  | (8) |  |  | 1,332 |  |  | (3) |  |
| Debt securities issued by U.S. government agencies | 1,291 |  |  | (1) |  |  | 1,134 |  |  | — |  |
| Total | $ | 16,187 |  |  | $ | (17) |  |  | $ | 13,132 |  |  | $ | (6) |  |

[0001045810-26-000052:notes:45]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-26-000052:notes:46]
The estimated fair values of debt securities included in cash equivalents and marketable debt securities are shown below by contractual maturity.

[0001045810-26-000052:notes:47]
|  | Apr 26, 2026 |
|  | (In millions) |
| Less than one year | $ | 24,307 |  |
| Due in 1 - 5 years | 14,926 |  |
| Total | $ | 39,233 |  |

[0001045810-26-000052:notes:48]
Non-marketable Securities
Non-marketable Equity Securities

[0001045810-26-000052:notes:49]
Our non-marketable equity securities are primarily in privately-held companies carried at cost less impairment, and adjusted for observable price changes. We value investments using observable comparable transactions and other inputs including volatility, expected time to liquidity, the risk-free rate, and security-specific rights and obligations.

[0001045810-26-000052:notes:50]
Adjustments to the carrying value of privately-held securities:

[0001045810-26-000052:notes:51]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Balance at beginning of period | $ | 22,251 |  |  | $ | 3,387 |  |  |  |  |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 17,899 |  |  | 649 |  |  |  |  |  |
| Unrealized gains (1) | 2,603 |  |  | 63 |  |  |  |  |  |
| Reclassification (2) | (389) |  |  | (843) |  |  |  |  |  |
| Impairments and unrealized losses | (28) |  |  | (16) |  |  |  |  |  |
| Balance at end of period | $ | 42,336 |  |  | $ | 3,240 |  |  |  |  |  |

[0001045810-26-000052:notes:52]
(1)    Unrealized gains are recognized in Other income (expense), net, in the Condensed Consolidated Statements of Income.

[0001045810-26-000052:notes:53]
(2)    Includes primarily reclassifications to marketable securities following public market trading.

[0001045810-26-000052:notes:54]
Non-marketable equity securities had cumulative gross unrealized gains of $5.3 billion and $396 million, and cumulative gross unrealized losses and impairments of $199 million and $110 million as of April 26, 2026 and April 27, 2025, respectively.

[0001045810-26-000052:notes:55]
Equity Method Investments

[0001045810-26-000052:notes:56]
We have $1.0 billion of investments in infrastructure funds accounted for using the equity method as of April 26, 2026. Our maximum loss exposure under these investments, including invested and future committed amounts, was $2.3 billion as of April 26, 2026.

[0001045810-26-000052:notes:57]
Investment Commitments

[0001045810-26-000052:notes:58]
Total Investment commitments were $27 billion as of April 26, 2026, subject to certain contingencies, which we expect will be made through the remainder of fiscal year 2027.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-26-000052:notes:59]
Balance Sheet Components
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, or AIBs, distributors, original design manufacturers, or ODMs, original equipment manufacturers, or OEMs, cloud service providers, or CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. Three direct customers accounted for 30%, 18%, and 16% of our accounts receivable balance as of April 26, 2026. Three direct customers accounted for 25%, 18%, and 13% of our accounts receivable balance as of January 25, 2026.

[0001045810-26-000052:notes:60]
Certain balance sheet components were as follows:

[0001045810-26-000052:notes:61]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
| Inventories: | (In millions) |
| Raw materials | $ | 6,647 |  |  | $ | 3,807 |  |
| Work in process | 9,949 |  |  | 8,822 |  |
| Finished goods | 9,201 |  |  | 8,774 |  |
| Total inventories (1) | $ | 25,797 |  |  | $ | 21,403 |  |

[0001045810-26-000052:notes:62]
(1)    We recorded inventory provisions of $0.8 billion and $2.3 billion for the first quarter of fiscal years 2027 and 2026, respectively, in Cost of revenue.

[0001045810-26-000052:notes:63]
[same as prior period, unchanged from 0001045810-25-000230:notes:62]

[0001045810-26-000052:notes:64]
Property, equipment and intangible assets acquired but not paid for the first quarter of fiscal years 2027 and 2026 were $1.1 billion and $408 million, respectively.

[0001045810-26-000052:notes:65]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
| Accrued and Other Current Liabilities: | (In millions) |
| Taxes payable | $ | 10,638 |  |  | $ | 2,669 |  |
| Customer program accruals | 4,182 |  |  | 5,318 |  |
| Accrued purchase consideration (1) | 3,957 |  |  | 3,921 |  |
| Excess inventory purchase obligations (2) | 3,121 |  |  | 2,739 |  |
| Product warranty | 2,948 |  |  | 2,807 |  |
| Deferred revenue (3) | 1,714 |  |  | 1,379 |  |
| Accrued payroll and related expenses | 1,033 |  |  | 1,146 |  |
| Other | 2,194 |  |  | 1,373 |  |
| Total accrued and other current liabilities | $ | 29,787 |  |  | $ | 21,352 |  |

[0001045810-26-000052:notes:66]
(1)    Related to the Groq, Inc. non-exclusive license agreement.

[0001045810-26-000052:notes:67]
(2)    We recorded $0.3 billion and $3.0 billion for the first quarter of fiscal years 2027 and 2026, respectively, in Cost of revenue.

[0001045810-26-000052:notes:68]
(3)    Includes customer advances and unearned revenue related to hardware and software support, cloud services, and license and development arrangements. The balance as of April 26, 2026 and January 25, 2026 included $297 million and $160 million of customer advances, respectively.

[0001045810-26-000052:notes:69]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 4,830 |  |  | $ | 3,958 |  |
| Deferred income tax | 1,798 |  |  | 1,774 |  |
| Deferred revenue (2) | 1,403 |  |  | 1,193 |  |
| Other | 737 |  |  | 381 |  |
| Total other long-term liabilities | $ | 8,768 |  |  | $ | 7,306 |  |

[0001045810-26-000052:notes:70]
[same as prior period, unchanged from 0001045810-25-000230:notes:70]

[0001045810-26-000052:notes:71]
[same as prior period, unchanged from 0001045810-25-000230:notes:71]

[0001045810-26-000052:notes:72]
[same as prior period, unchanged from 0001045810-25-000230:notes:72]

[0001045810-26-000052:notes:73]
The following table shows the changes in short- and long-term deferred revenue during the first quarter of fiscal years 2027 and 2026:

[0001045810-26-000052:notes:74]
|  | Three Months Ended |
|  | Apr 26, 2026 |  | Apr 27, 2025 |
|  | (In millions) |
| Balance at beginning of period | $ | 2,572 |  |  | $ | 1,813 |  |
| Deferred revenue additions (1) | 2,530 |  |  | 6,493 |  |
| Revenue recognized (2) | (1,985) |  |  | (6,228) |  |
| Balance at end of period | $ | 3,117 |  |  | $ | 2,078 |  |

[0001045810-26-000052:notes:75]
(1)    Includes $1.7 billion and $6.2 billion of customer advances for the first quarter of fiscal years 2027 and 2026, respectively.

[0001045810-26-000052:notes:76]
(2)    Includes $1.6 billion and $6.0 billion related to customer advances for the first quarter of fiscal years 2027 and 2026, respectively.

[0001045810-26-000052:notes:77]
We recognized revenue of $451 million and $265 million in the first quarter of fiscal years 2027 and 2026, respectively, that was included in the prior year-end deferred revenue balance.

[0001045810-26-000052:notes:78]
As of April 26, 2026, revenue related to remaining performance obligations from contracts greater than one year in length was $2.6 billion, which includes $2.3 billion from deferred revenue and $304 million, which has not yet been billed or

[0001045810-26-000052:notes:79]
recognized as revenue. Approximately 40% of revenue from contracts greater than one year in length will be recognized over the next twelve months.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-26-000052:notes:80]
[same as prior period, unchanged from 0001045810-25-000230:notes:80]

[0001045810-26-000052:notes:81]
We primarily utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These foreign currency forward contracts for operating expenses are designated as accounting hedges. Gains or losses on the contracts are recorded in Accumulated other comprehensive income or loss and reclassified to Operating expenses when the related operating expenses are recognized in earnings. During the first quarter of fiscal years 2027 and 2026, the impact of foreign currency forward contracts designated as accounting hedges on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.

[0001045810-26-000052:notes:82]
We also entered into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities. For our foreign currency contracts for assets and liabilities, the change in fair value of these non-designated contracts was recorded in Other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which was also recorded in Other income (expense), net.

[0001045810-26-000052:notes:83]
[same as prior period, unchanged from 0001045810-25-000230:notes:83]

[0001045810-26-000052:notes:84]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
|  | (In millions) |
| Designated as accounting hedges | $ | 2,114 |  |  | $ | 1,765 |  |
| Not designated as accounting hedges | $ | 1,850 |  |  | $ | 2,332 |  |

[0001045810-26-000052:notes:85]
The fair values of our foreign currency contracts were not significant as of April 26, 2026 and January 25, 2026.

[0001045810-26-000052:notes:86]
As of April 26, 2026, all foreign currency contracts mature within 18 months. The expected realized gains and losses deferred into Accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months were not significant.

[0001045810-26-000052:notes:87]
[same as prior period, unchanged from 0001045810-25-000230:notes:87]

[0001045810-26-000052:notes:88]
In fiscal year 2026, we entered into agreements to guarantee partners’ facility lease obligations in the event of their default in exchange for warrants. The maximum gross exposure under all agreements is $3.5 billion, which is reduced as the partners make payments to the lessors over terms ranging from 5 to 7 years. The partners have placed $712 million in escrow to mitigate our potential exposure. The guarantees, classified as credit derivatives with changes in fair value recognized in Other income (expense), net, were not material.


## us-gaap:DebtDisclosureTextBlock

[0001045810-26-000052:notes:89]
Debt

[0001045810-26-000052:notes:90]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  |  |
|  |  |  |  | Apr 26, 2026 |  | Jan 25, 2026 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 0.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 2.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 3.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 5.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 13.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 23.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 34.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (30) |  |  | (32) |  |
| Net carrying amount |  |  |  |  |  | $ | 8,470 |  |  | $ | 8,468 |  |
| Less short-term portion |  |  |  |  |  | (1,000) |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 7,470 |  |  | $ | 7,469 |  |

[0001045810-26-000052:notes:91]
As of April 26, 2026 and January 25, 2026, the estimated fair value of debt was $7.4 billion and $7.5 billion, respectively. The estimated fair values are based on Level 2 inputs.

[0001045810-26-000052:notes:92]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity dates of the notes are stated by calendar year.

[0001045810-26-000052:notes:93]
As of April 26, 2026, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-26-000052:notes:94]
As of April 26, 2026, our commercial paper program had a capacity of $25.0 billion, with no amounts outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-26-000052:notes:95]
Commitments and Contingencies
Commitments

[0001045810-26-000052:notes:96]
Manufacturing, supply, and capacity commitments reflect data center-scale production and longer future ordering horizons across current and future product architectures. We enter into agreements with our supply vendors that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Changes to these agreements may result in additional costs. As of April 26, 2026, these commitments were $119 billion for which $95 billion will be paid in the remainder of fiscal year 2027 and the remaining balance will be paid in fiscal years 2028 through 2031.

[0001045810-26-000052:notes:97]
Multi-year cloud service agreement commitments as of April 26, 2026, were $30 billion for which $6 billion, $7 billion, $7 billion, $5 billion, $3 billion, and $2 billion will be paid in the remainder of fiscal year 2027, each fiscal year from 2028 through 2031, and fiscal year 2032 and thereafter, respectively. Cloud service capacity may be reduced or terminated. Cloud service agreements will be primarily used to support our research and development efforts.

[0001045810-26-000052:notes:98]
Other vendor commitments were $6 billion as of April 26, 2026, of which the majority will be paid through fiscal year 2027.

[0001045810-26-000052:notes:99]
Accrual for Product Warranty Liabilities

[0001045810-26-000052:notes:100]
The estimated amount of product warranty liabilities was $2.9 billion and $2.8 billion as of April 26, 2026 and January 25, 2026, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-26-000052:notes:101]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Balance at beginning of period | $ | 2,807 |  |  | $ | 1,290 |  |  |  |  |  |
| Additions | 330 |  |  | 870 |  |  |  |  |  |
| Utilization | (189) |  |  | (80) |  |  |  |  |  |
| Balance at end of period | $ | 2,948 |  |  | $ | 2,080 |  |  |  |  |  |

[0001045810-26-000052:notes:102]
For the first quarter of fiscal years 2027 and 2026, the additions in product warranty liabilities primarily related to our Compute & Networking segment.

[0001045810-26-000052:notes:103]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-26-000052:notes:104]
Litigation

[0001045810-26-000052:notes:105]
Securities Class Action and Derivative Lawsuits

[0001045810-26-000052:notes:106]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings. On March 25, 2026, the district court granted plaintiffs’ motion for class certification and certified a class of investors consisting of all persons or entities who purchased or otherwise acquired NVIDIA common stock between August 10, 2017, and November 15, 2018, inclusive, excluding certain persons and entities, such as NVIDIA’s officers and directors, and members of their immediate families, among others. On April 8, 2026, NVIDIA filed a petition with the Ninth Circuit for permission to appeal the district court’s order pursuant to Federal Rule of Civil Procedure 23(f).

[0001045810-26-000052:notes:107]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-26-000052:notes:108]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-

[0001045810-26-000052:notes:109]
cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On March 7, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Securities Litigation action, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-26-000052:notes:110]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. On August 11, 2025, the court granted the parties’ stipulation to voluntarily dismiss with prejudice plaintiff City of Westland Police and Fire Retirement System. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-26-000052:notes:111]
Accounting for Loss Contingencies

[0001045810-26-000052:notes:112]
As of April 26, 2026, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business, as well as regulatory and government inquiries and investigations, and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these matters will not have a material adverse effect on our operating results, liquidity or financial position. These matters are subject to inherent uncertainties and if the ultimate outcome is unfavorable, there exists the possibility of a material adverse impact on our operating results, liquidity or financial position in the period the outcome becomes estimable and probable.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-26-000052:notes:113]
Income Taxes
Income tax expense was $11.6 billion and $3.1 billion for the first quarter of fiscal years 2027 and 2026, respectively. Income tax as a percentage of income before income tax was 16.6% and 14.3% for the first quarter of fiscal years 2027 and 2026, respectively.

[0001045810-26-000052:notes:114]
The effective tax rate increased primarily due to a lower percentage of tax benefits from stock-based compensation relative to the increase in income before income tax.

[0001045810-26-000052:notes:115]
Our effective tax rates for the first quarter of fiscal years 2027 and 2026 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from foreign-derived deduction eligible income, income earned in jurisdictions that were subject to taxes at rates lower than the U.S. federal statutory tax rate, stock-based compensation, and the U.S. federal research tax credit.

[0001045810-26-000052:notes:116]
[same as prior period, unchanged from 0001045810-25-000230:notes:33]

[0001045810-26-000052:notes:117]
[same as prior period, unchanged from 0001045810-25-000230:notes:34]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-26-000052:notes:118]
Shareholders’ Equity
Capital Return Program

[0001045810-26-000052:notes:119]
We repurchased 108 million and 126 million shares of our common stock for $20.2 billion and $14.5 billion during the first quarter of fiscal years 2027 and 2026, respectively. As of April 26, 2026, we were authorized, subject to certain specifications, to repurchase up to $38.5 billion of our common stock.

[0001045810-26-000052:notes:120]
On May 18, 2026, our Board of Directors approved an additional $80.0 billion in share repurchase authorization, without expiration.

[0001045810-26-000052:notes:121]
We paid cash dividends to our shareholders of $243 million and $244 million during the first quarter of fiscal years 2027 and 2026, respectively. On May 18, 2026, we increased our quarterly cash dividend from $0.01 per share to $0.25 per share to all shareholders of record on June 4, 2026. Our quarterly cash dividend will be paid on June 26, 2026.
The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-26-000052:notes:122]
[same as prior period, unchanged from 0001045810-25-000230:notes:117]

[0001045810-26-000052:notes:123]
The Compute & Networking segment includes our Data Center accelerated computing and networking platforms and AI solutions and software, and automotive platforms and autonomous and electric vehicle solutions including software.

[0001045810-26-000052:notes:124]
The Graphics segment includes GeForce GPUs for gaming and PCs, and Quadro/NVIDIA RTX GPUs for enterprise workstation graphics.

[0001045810-26-000052:notes:125]
[same as prior period, unchanged from 0001045810-25-000230:notes:120]

[0001045810-26-000052:notes:126]
[same as prior period, unchanged from 0001045810-25-000230:notes:121]

[0001045810-26-000052:notes:127]
|  | Compute & Networking |  | Graphics |  | Total |
|  | (In millions) |
| Three Months Ended Apr 26, 2026 |  |  |  |  |  |
| Revenue | $ | 74,550 |  |  | $ | 7,065 |  |  | $ | 81,615 |  |
| Other segment items (1) | 21,215 |  |  | 4,124 |  |  | 25,339 |  |
| Operating income | $ | 53,335 |  |  | $ | 2,941 |  |  | $ | 56,276 |  |
| Three Months Ended Apr 27, 2025 |  |  |  |  |  |
| Revenue | $ | 39,589 |  |  | $ | 4,473 |  |  | $ | 44,062 |  |
| Other segment items (1) | 17,535 |  |  | 2,833 |  |  | 20,368 |  |
| Operating income | $ | 22,054 |  |  | $ | 1,640 |  |  | $ | 23,694 |  |

[0001045810-26-000052:notes:128]
[same as prior period, unchanged from 0001045810-25-000230:notes:123]

[0001045810-26-000052:notes:129]
Depreciation and amortization expense attributable to our Compute & Networking segment was $526 million and $296 million for the first quarter of fiscal years 2027 and 2026, respectively. Depreciation and amortization expense attributable to our Graphics segment was $194 million and $109 million for the first quarter of fiscal years 2027 and 2026, respectively. Acquisition-related intangible amortization expense is not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance.

[0001045810-26-000052:notes:130]
Reconciliation of segment operating income to consolidated income before income tax for the first quarter of fiscal years 2027 and 2026 was as follows:

[0001045810-26-000052:notes:131]
|  | Three Months Ended |  |  |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |  |  |
|  | (In millions) |  |  |  |  |  |  |
| Segment operating income | $ | 56,276 |  |  | $ | 23,694 |  |  |  |  |  |  |  |
| Stock-based compensation expense | (1,928) |  |  | (1,474) |  |  |  |  |  |  |  |
| Unallocated operating expenses | (565) |  |  | (419) |  |  |  |  |  |  |  |
| Acquisition-related and other costs | (247) |  |  | (163) |  |  |  |  |  |  |  |
| Interest income | 540 |  |  | 515 |  |  |  |  |  |  |  |
| Interest expense | (102) |  |  | (63) |  |  |  |  |  |  |  |
| Other income (expense), net | 15,929 |  |  | (180) |  |  |  |  |  |  |  |
| Consolidated income before income tax | $ | 69,903 |  |  | $ | 21,910 |  |  |  |  |  |  |  |

[0001045810-26-000052:notes:132]
[same as prior period, unchanged from 0001045810-25-000230:notes:127]

[0001045810-26-000052:notes:133]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Geographic Revenue based upon Customer Headquarters Location: |  |  |  |  |  |  |  |
| United States | $ | 63,769 |  |  | $ | 25,685 |  |  |  |  |  |
| Taiwan | 12,006 |  |  | 7,648 |  |  |  |  |  |
| China (including Hong Kong) | 4,550 |  |  | 9,659 |  |  |  |  |  |
| Other | 1,290 |  |  | 1,070 |  |  |  |  |  |
| Total revenue | $ | 81,615 |  |  | $ | 44,062 |  |  |  |  |  |

[0001045810-26-000052:notes:134]
Revenue from sales to customers headquartered outside of the United States accounted for 22% of total revenue for the first quarter of fiscal year 2027 and 42% of total revenue for the first quarter of fiscal year 2026
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, AI Clouds, AI model makers, enterprises, and public sector entities. Our revenue is concentrated among a limited number of direct and indirect customers and this trend may continue.

[0001045810-26-000052:notes:135]
For the first quarter of fiscal year 2027, three direct customers represented 21%, 17%, and 16% of total revenue, all of which was primarily attributable to the Compute & Networking segment.

[0001045810-26-000052:notes:136]
For the first quarter of fiscal year 2026, sales to two direct customers represented 16% and 14% of total revenue, which were attributable to the Compute & Networking segment.

[0001045810-26-000052:notes:137]
In the first quarter of fiscal year 2027, we changed our presentation of revenue by market platform, and the comparable period has been recast as follows:

[0001045810-26-000052:notes:138]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
|  | (In millions) |  |  |  |  |
| Revenue by Market Platform |  |  |  |  |  |  |  |
| Data Center | $ | 75,246 |  |  | $ | 39,112 |  |  |  |  |  |
| Hyperscale | 37,869 |  |  | 17,599 |  |  |  |  |  |
| AI Clouds, Industrial, & Enterprise | 37,377 |  |  | 21,513 |  |  |  |  |  |
| Edge Computing | 6,369 |  |  | 4,950 |  |  |  |  |  |
| Total revenue | $ | 81,615 |  |  | $ | 44,062 |  |  |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-26-000052:notes:139]
[same as prior period, unchanged from 0001045810-25-000230:notes:137]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-26-000052:notes:140]
Leases
Our lease obligations primarily consist of operating leases for our data centers and offices, with lease periods expiring between fiscal years 2027 and 2075.

[0001045810-26-000052:notes:141]
Future minimum lease obligations under our non-cancelable lease agreements as of April 26, 2026 were as follows:

[0001045810-26-000052:notes:142]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2027 (excluding the first quarter of fiscal 2027) | $ | 460 |  |
| 2028 | 626 |  |
| 2029 | 602 |  |
| 2030 | 530 |  |
| 2031 | 462 |  |
| 2032 and thereafter | 2,924 |  |
| Total | 5,604 |  |
| Less imputed interest | 1,260 |  |
| Present value of net future minimum lease payments | 4,344 |  |
| Less short-term operating lease liabilities | 466 |  |
| Long-term operating lease liabilities | $ | 3,878 |  |

[0001045810-26-000052:notes:143]
Between the second quarter of fiscal year 2027 and fiscal year 2033, we expect to commence leases with future obligations of $32.4 billion, primarily for data center leases to support our research and development efforts, with lease terms of 3 to 20 years.

[0001045810-26-000052:notes:144]
Operating lease costs were $171 million and $101 million for the first quarter of fiscal years 2027 and 2026, respectively. Short-term, variable, and finance lease costs for the first quarter of fiscal years 2027 and 2026 were not significant.

[0001045810-26-000052:notes:145]
[same as prior period, unchanged from 0001045810-25-000230:notes:143]

[0001045810-26-000052:notes:146]
|  | Three Months Ended |
|  | Apr 26, 2026 |  | Apr 27, 2025 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 185 |  |  | $ | 96 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 1,516 |  |  | $ | 98 |  |

[0001045810-26-000052:notes:147]
As of April 26, 2026, our operating leases have a weighted average remaining lease term of 10.4 years and a weighted average discount rate of 4.61%. As of January 25, 2026, our operating leases had a weighted average remaining lease term of 8.8 years and a weighted average discount rate of 4.38%.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-26-000052:notes:148]
| Name |  | Title of Director or Officer |  | Action |  | Date |  | Total Shares of Common Stock to be Sold |  | Expiration Date |
| Tench Coxe |  | Director |  | Adoption |  | 3/19/2026 |  | 8,000,000* |  | 10/30/2027 |
| Colette M. Kress |  | Executive Vice President and Chief Financial Officer |  | Termination |  | 4/10/2026 |  | 500,000** |  | N/A |

[0001045810-26-000052:notes:149]
* The Rule 10b5-1 Trading Arrangement is solely for gifts to charitable donor-advised funds.

[0001045810-26-000052:notes:150]
** The Rule 10b5-1 Trading Arrangement was adopted on December 18, 2025, for sales through March 23, 2027. No shares were sold under the Rule 10b5-1 Trading Arrangement prior to termination.
