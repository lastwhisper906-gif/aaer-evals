# NVDA MD&A — 0001045810-26-000052


## mdna

[0001045810-26-000052:mdna:1]
[same as prior period, unchanged from 0001045810-25-000230:mdna:1]

[0001045810-26-000052:mdna:2]
[same as prior period, unchanged from 0001045810-25-000230:mdna:2]

[0001045810-26-000052:mdna:3]
[same as prior period, unchanged from 0001045810-25-000230:mdna:3]

[0001045810-26-000052:mdna:4]
In addition, statements that “we believe” and similar statements reflect our beliefs and opinions on the relevant subject. These statements are based upon information available to us as of the filing date of this Quarterly Report on Form 10-Q, and while we believe such information forms a reasonable basis for such statements, such information may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain, and investors are cautioned not to unduly rely upon these statements.

[0001045810-26-000052:mdna:5]
© 2026 NVIDIA Corporation. All rights reserved.

[0001045810-26-000052:mdna:6]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 25, 2026 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase, hold, or sell shares of our common stock.

[0001045810-26-000052:mdna:7]
[same as prior period, unchanged from 0001045810-25-000230:mdna:6]

[0001045810-26-000052:mdna:8]
[same as prior period, unchanged from 0001045810-25-000230:mdna:7]

[0001045810-26-000052:mdna:9]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, and digital twin applications. NVIDIA is now a data center-scale AI infrastructure company reshaping all industries.

[0001045810-26-000052:mdna:10]
Our two operating segments are “Compute & Networking” and “Graphics.” Refer to Note 13 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-26-000052:mdna:11]
[same as prior period, unchanged from 0001045810-25-000230:mdna:10]

[0001045810-26-000052:mdna:12]
[same as prior period, unchanged from 0001045810-25-000230:mdna:11]

[0001045810-26-000052:mdna:13]
Revenue growth in the first quarter was driven by data center products for accelerated computing and AI solutions. Blackwell continued to account for the majority of our system shipments.

[0001045810-26-000052:mdna:14]
The availability of data centers, energy, and capital to support the buildout of NVIDIA AI infrastructure by our customers and partners is crucial, and any shortage of these or other necessary resources could impact our future revenue and financial performance. Expanding energy capacity to meet demand is a complex, multi-year process that involves significant regulatory, technical, and construction challenges. In addition, access to capital can be particularly constrained for less-capitalized companies, which may face difficulties securing financing for large-scale infrastructure projects. These limitations could delay customer and partner deployments or reduce the scale of accelerated computing and AI adoption.

[0001045810-26-000052:mdna:15]
We expect our Rubin platform to start shipping in the second half of fiscal year 2027. The complexity of bringing up our product architecture and sophisticated system configurations has caused and may in the future cause delays in production and create challenges in managing supply and demand. This could further result in revenue volatility, quality issues, increased inventory provisions, decreases in product yields and higher material costs, and/or increased warranty costs. Customers may postpone purchasing new architectures or may adopt new technologies more gradually than anticipated, affecting our revenue timing and supply chain expenses.

[0001045810-26-000052:mdna:16]
Beginning in February 2026, the U.S. government, or USG, granted licenses that allow us to ship small amounts of H200 products to specific China-based customers. To date, we have not generated any revenue under the H200 licensing program, and do not yet know whether any imports will be allowed into China. The license requires that the H200s go through an inspection process in the United States prior to any shipment to the customer. As a result, any H200 shipped under the new licensing program will be subject to a 25% tariff upon importation into the United States.

[0001045810-26-000052:mdna:17]
The recent rise in high-quality, open-source foundation models is making advanced AI capabilities broadly accessible. Open-source AI is dependent on developer adoption, and if deployed on our competitors’ platforms, it could reduce demand for our products and services.

[0001045810-26-000052:mdna:18]
We have made, and expect to continue making, investments in our ecosystem to enhance our growth opportunities, cultivate our ecosystem, and strengthen our competitive position. In the first quarter of fiscal year 2027, we made the following investments:

[0001045810-26-000052:mdna:19]
•$18.6 billion in private companies and infrastructure funds. Some of these investments include AI model makers that may indirectly purchase or use our products in the cloud.

[0001045810-26-000052:mdna:20]
•We made investments in publicly-held equity securities where the value may fluctuate significantly and could adversely affect our financial results.

[0001045810-26-000052:mdna:21]
Our global supply chain for our networking products, including our Israel operations of approximately 5,900 employees supporting research and development, operations, and sales and marketing, has not been significantly impacted by the conflict in the Middle East. If the conflict escalates or extends, it could affect future product development, supply chain, and revenue, and create business uncertainty.

[0001045810-26-000052:mdna:22]
Macroeconomic factors, including tariffs, inflation, interest changes, capital market volatility, global supply chain constraints, and global economic and geopolitical developments and conflicts, have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors impact our supply chain and manufacturing costs, employee wages, costs for capital equipment, the value of our investments, revenue, and competitive position. Our product and solution pricing generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-26-000052:mdna:23]
Refer to Part II, Item 1A, "Risk Factors" for a discussion of these factors and other risks.

[0001045810-26-000052:mdna:24]
First Quarter of Fiscal Year 2027 Summary

[0001045810-26-000052:mdna:25]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Apr 26, 2026 |  | Jan 25, 2026 |  | Apr 27, 2025 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 81,615 |  |  | $ | 68,127 |  |  | $ | 44,062 |  |  | 20 | % |  | 85 | % |
| Gross margin | 74.9 | % |  | 75.0 | % |  | 60.5 | % |  | (0.1) | pts |  | 14.4 | pts |
| Operating expenses | $ | 7,621 |  |  | $ | 6,794 |  |  | $ | 5,030 |  |  | 12 | % |  | 52 | % |
| Operating income | $ | 53,536 |  |  | $ | 44,299 |  |  | $ | 21,638 |  |  | 21 | % |  | 147 | % |
| Net income | $ | 58,321 |  |  | $ | 42,960 |  |  | $ | 18,775 |  |  | 36 | % |  | 211 | % |
| Net income per diluted share | $ | 2.39 |  |  | $ | 1.76 |  |  | $ | 0.76 |  |  | 36 | % |  | 214 | % |

[0001045810-26-000052:mdna:26]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value.

[0001045810-26-000052:mdna:27]
Following the rapid evolution in our businesses, we are transitioning to a new reporting framework that better reflects our current and future growth drivers.

[0001045810-26-000052:mdna:28]
We will have two market platforms – Data Center and Edge Computing.

[0001045810-26-000052:mdna:29]
Within Data Center, we will report two sub-markets, Hyperscale and ACIE which incorporates AI Clouds, Industrial, and Enterprise. Hyperscale will include revenue from the public clouds and the world’s largest consumer internet companies,

[0001045810-26-000052:mdna:30]
while ACIE addresses our growth opportunity in diverse AI purpose-built data centers and AI factories across industries and countries.

[0001045810-26-000052:mdna:31]
Edge Computing highlights devices for agentic and physical AI including PCs, game consoles, workstations, AI-RAN base stations, robotics and automotive.

[0001045810-26-000052:mdna:32]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Apr 26, 2026 |  | Jan 25, 2026 |  | Apr 27, 2025 |  |  |
|  | ($ in millions) |  |  |  |  |
| Revenue by Market Platform (1) |  |  |  |  |  |  |  |  |  |
| Data Center | $ | 75,246 |  |  | $ | 62,314 |  |  | $ | 39,112 |  |  | 21 | % |  | 92 | % |
| Hyperscale | 37,869 |  |  | 33,814 |  |  | 17,599 |  |  | 12 | % |  | 115 | % |
| AI Clouds, Industrial, & Enterprise | 37,377 |  |  | 28,500 |  |  | 21,513 |  |  | 31 | % |  | 74 | % |
| Edge Computing | 6,369 |  |  | 5,813 |  |  | 4,950 |  |  | 10 | % |  | 29 | % |
| Total revenue | $ | 81,615 |  |  | $ | 68,127 |  |  | $ | 44,062 |  |  | 20 | % |  | 85 | % |

[0001045810-26-000052:mdna:33]
(1)    In the first quarter of fiscal year 2027, we changed our presentation of revenue by market platform and the comparable periods have been recast.

[0001045810-26-000052:mdna:34]
Revenue was $81.6 billion, up 85% from a year ago and up 20% sequentially.

[0001045810-26-000052:mdna:35]
Data Center revenue was $75.2 billion, up 92% from a year ago and up 21% sequentially, driven by the ramp of our Blackwell 300 products and demand for our InfiniBand, Spectrum-X Ethernet, and NVLink solutions. Hyperscaler revenue increased sequentially and remained at approximately 50% of Data Center revenue, while the remaining 50% came from a continued diversification of customers, including AI Clouds, industrial, enterprise, and sovereign customers. No shipments of Data Center Hopper products to China occurred during the quarter, compared with $4.6 billion in the first quarter of fiscal year 2026.

[0001045810-26-000052:mdna:36]
Edge Computing revenue for the first quarter was $6.4 billion, up 29% from a year ago and up 10% sequentially. The increases were driven by robust Blackwell workstation demand, partially offset by slower consumer PC demand that was tempered by elevated memory and systems prices.

[0001045810-26-000052:mdna:37]
Gross margin increased from a year ago on lower inventory provisions, primarily due to the prior year's $4.5 billion charge associated with H20 excess inventory and purchase obligations. Gross margin was approximately flat sequentially as our Blackwell architecture remains the majority of our revenue.

[0001045810-26-000052:mdna:38]
Operating expenses were up 52% from a year ago and up 12% sequentially. The increases were primarily driven by higher compensation and benefits expense due to employee growth and compensation increases, compute and infrastructure costs, and engineering development materials for new product developments.

[0001045810-26-000052:mdna:39]
[same as prior period, unchanged from 0001045810-25-000230:mdna:34]

[0001045810-26-000052:mdna:40]
[same as prior period, unchanged from 0001045810-25-000230:mdna:35]

[0001045810-26-000052:mdna:41]
[same as prior period, unchanged from 0001045810-25-000230:mdna:36]

[0001045810-26-000052:mdna:42]
Refer to Part II, Item 7, "Critical Accounting Policies and Estimates" of our Annual Report on Form 10-K for the fiscal year ended January 25, 2026. There have been no material changes to our Critical Accounting Policies and Estimates.

[0001045810-26-000052:mdna:43]
25

[0001045810-26-000052:mdna:44]
[same as prior period, unchanged from 0001045810-25-000230:mdna:38]

[0001045810-26-000052:mdna:45]
[same as prior period, unchanged from 0001045810-25-000230:mdna:39]

[0001045810-26-000052:mdna:46]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 25.1 |  |  | 39.5 |  |  |  |  |  |
| Gross profit | 74.9 |  |  | 60.5 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 7.7 |  |  | 9.1 |  |  |  |  |  |
| Sales, general and administrative | 1.6 |  |  | 2.4 |  |  |  |  |  |
| Total operating expenses | 9.3 |  |  | 11.5 |  |  |  |  |  |
| Operating income | 65.6 |  |  | 49.0 |  |  |  |  |  |
| Interest income | 0.7 |  |  | 1.2 |  |  |  |  |  |
| Interest expense | (0.1) |  |  | (0.1) |  |  |  |  |  |
| Other income (expense), net | 19.5 |  |  | (0.4) |  |  |  |  |  |
| Total other income, net | 20.1 |  |  | 0.7 |  |  |  |  |  |
| Income before income tax | 85.7 |  |  | 49.7 |  |  |  |  |  |
| Income tax expense | 14.2 |  |  | 7.1 |  |  |  |  |  |
| Net income | 71.5 | % |  | 42.6 | % |  |  |  |  |

[0001045810-26-000052:mdna:47]
Reportable Segments

[0001045810-26-000052:mdna:48]
[same as prior period, unchanged from 0001045810-25-000230:mdna:42]

[0001045810-26-000052:mdna:49]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Compute & Networking | $ | 74,550 |  |  | $ | 39,589 |  |  | $ | 34,961 |  |  | 88 | % |  |  |  |  |  |  |  |  |
| Graphics | 7,065 |  |  | 4,473 |  |  | 2,592 |  |  | 58 | % |  |  |  |  |  |  |  |  |
| Total | $ | 81,615 |  |  | $ | 44,062 |  |  | $ | 37,553 |  |  | 85 | % |  |  |  |  |  |  |  |  |

[0001045810-26-000052:mdna:50]
[same as prior period, unchanged from 0001045810-25-000230:mdna:44]

[0001045810-26-000052:mdna:51]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Compute & Networking | $ | 53,335 |  |  | $ | 22,054 |  |  | $ | 31,281 |  |  | 142 | % |  |  |  |  |  |  |  |  |
| Graphics | 2,941 |  |  | 1,640 |  |  | 1,301 |  |  | 79 | % |  |  |  |  |  |  |  |  |
| Total | $ | 56,276 |  |  | $ | 23,694 |  |  | $ | 32,582 |  |  | 138 | % |  |  |  |  |  |  |  |  |

[0001045810-26-000052:mdna:52]
Compute & Networking revenue – The year-over-year increase in the first quarter of fiscal year 2027 was due to growth in Data Center products, driven by the ramp of our Blackwell systems and demand for our InfiniBand, Spectrum-X Ethernet, and NVLink solutions.

[0001045810-26-000052:mdna:53]
Graphics revenue – The year-over-year increase in the first quarter of fiscal year 2027 was driven by sales of our Blackwell architecture.

[0001045810-26-000052:mdna:54]
Reportable segment operating income – The year-over-year increase in Compute & Networking segment operating income in the first quarter of fiscal year 2027 was driven by the growth in revenue and the non-recurrence of a $4.5 billion charge associated with H20 excess inventory and purchase obligations in the first quarter of fiscal year 2026. The year-over-year increase in Graphics segment operating income in the first quarter of fiscal year 2027 was driven by the growth in revenue.

[0001045810-26-000052:mdna:55]
[same as prior period, unchanged from 0001045810-25-000230:mdna:49]

[0001045810-26-000052:mdna:56]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, CSPs, AI model makers, and system integrators. Certain direct customers may use either internal resources or third-party system integrators to complete their build. We refer to indirect customers as those who purchase products through our direct customers; indirect customers include CSPs, AI Clouds, AI model makers, enterprises, and public sector entities. Our revenue is concentrated among a limited number of direct and indirect customers and this trend may continue.

[0001045810-26-000052:mdna:57]
Direct Customers – For the first quarter of fiscal year 2027, three direct customers represented 21%, 17%, and 16% of total revenue, all of which was primarily attributable to the Compute & Networking segment.

[0001045810-26-000052:mdna:58]
For the first quarter of fiscal year 2026, sales to two direct customers represented 16% and 14% of total revenue, which were attributable to the Compute & Networking segment.

[0001045810-26-000052:mdna:59]
[same as prior period, unchanged from 0001045810-25-000230:mdna:53]

[0001045810-26-000052:mdna:60]
We generate a significant amount of our revenue from a limited number of indirect customers, some individually representing 10% or more of our revenue. Certain companies purchase cloud and related services through various direct and indirect customers. We estimate that one AI research and deployment company contributed to a meaningful amount of our revenue by purchasing cloud services from our customers in the first quarter of fiscal year 2027.

[0001045810-26-000052:mdna:61]
Revenue by geographic region is designated based on the location of the headquarters of direct customers. The end customer and shipping location may be different from our customers' headquarters location. Revenue from sales to customers headquartered outside of the United States accounted for 22% of total revenue for the first quarter of fiscal year 2027 and 42% of total revenue for the first quarter of fiscal year 2026.

[0001045810-26-000052:mdna:62]
[same as prior period, unchanged from 0001045810-25-000230:mdna:56]

[0001045810-26-000052:mdna:63]
Gross profit consists of total net revenue less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions, memory and component costs, tariffs, and shipping costs. Cost of revenue also includes acquisition-related intangible amortization expense, IP-related costs, and stock-based compensation related to personnel associated with manufacturing operations.

[0001045810-26-000052:mdna:64]
Gross margin increased to 74.9% for the first quarter of fiscal year 2027 compared to 60.5% for the first quarter of fiscal year 2026, primarily due to the prior year's $4.5 billion charge associated with H20 excess inventory and purchase obligations.

[0001045810-26-000052:mdna:65]
Provisions for inventory and excess inventory purchase obligations totaled $1.1 billion and $5.3 billion for the first quarter of fiscal years 2027 and 2026, respectively. The first quarter of fiscal year 2026 includes $4.5 billion associated with H20 excess inventory and purchase obligations. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $103 million and $436 million for the first quarter of fiscal years 2027 and 2026, respectively. The net effect on our gross margin was an unfavorable impact of 1.2% and 11.0% in the first quarter of fiscal years 2027 and 2026, respectively.

[0001045810-26-000052:mdna:66]
[same as prior period, unchanged from 0001045810-25-000230:mdna:61]

[0001045810-26-000052:mdna:67]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Research and development | $ | 6,321 |  |  | $ | 3,989 |  |  | $ | 2,332 |  |  | 58 | % |  |  |  |  |  |  |  |  |
| Sales, general and administrative | 1,300 |  |  | 1,041 |  |  | 259 |  |  | 25 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 7,621 |  |  | $ | 5,030 |  |  | $ | 2,591 |  |  | 52 | % |  |  |  |  |  |  |  |  |

[0001045810-26-000052:mdna:68]
The increase in research and development expenses for the first quarter of fiscal year 2027 was primarily driven by a 112% increase in compute and infrastructure, a 31% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, and a 204% increase in engineering development materials for new product introductions.

[0001045810-26-000052:mdna:69]
The increase in sales, general and administrative expenses for the first quarter of fiscal year 2027 was primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-26-000052:mdna:70]
[same as prior period, unchanged from 0001045810-25-000230:mdna:65]

[0001045810-26-000052:mdna:71]
|  | Three Months Ended |  |  |
|  | Apr 26, 2026 |  | Apr 27, 2025 |  | $Change |  |  |  |  |  |  |
|  | ($ in millions) |
| Interest income | $ | 540 |  |  | $ | 515 |  |  | $ | 25 |  |  |  |  |  |  |  |
| Interest expense | (102) |  |  | (63) |  |  | (39) |  |  |  |  |  |  |  |
| Other income (expense), net | 15,929 |  |  | (180) |  |  | 16,109 |  |  |  |  |  |  |  |
| Total other income, net | $ | 16,367 |  |  | $ | 272 |  |  | $ | 16,095 |  |  |  |  |  |  |  |

[0001045810-26-000052:mdna:72]
Total other income, net primarily consists of realized or unrealized gains and losses from investments in non-marketable securities and publicly-held equity securities. The change in Other income (expense), net compared to the first quarter of fiscal year 2026, was primarily driven by unrealized gains on investments in publicly-held equity securities of $13.4 billion and non-marketable equity securities of $2.6 billion.

[0001045810-26-000052:mdna:73]
[same as prior period, unchanged from 0001045810-25-000230:mdna:70]

[0001045810-26-000052:mdna:74]
Income tax expense was $11.6 billion and $3.1 billion for the first quarter of fiscal years 2027 and 2026, respectively. Income tax as a percentage of income before income tax was 16.6% and 14.3% for the first quarter of fiscal years 2027 and 2026, respectively.

[0001045810-26-000052:mdna:75]
The effective tax rate increased primarily due to a lower percentage of tax benefits from stock-based compensation relative to the increase in income before income tax.

[0001045810-26-000052:mdna:76]
Our effective tax rates for the first quarter of fiscal years 2027 and 2026 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from foreign-derived deduction eligible income, income earned in jurisdictions that were subject to taxes at rates lower than the U.S. federal statutory tax rate, stock-based compensation, and the U.S. federal research tax credit.

[0001045810-26-000052:mdna:77]
Refer to Note 11 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-26-000052:mdna:78]
[same as prior period, unchanged from 0001045810-25-000230:mdna:77]

[0001045810-26-000052:mdna:79]
|  | Apr 26, 2026 |  | Jan 25, 2026 |
|  | (In millions) |
| Cash and cash equivalents | $ | 13,237 |  |  | $ | 10,605 |  |
| Marketable debt securities | 37,098 |  |  | 39,065 |  |
| Cash, cash equivalents, and marketable debt securities | $ | 50,335 |  |  | $ | 49,670 |  |

[0001045810-26-000052:mdna:80]
|  | Three Months Ended |
|  | Apr 26, 2026 |  | Apr 27, 2025 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 50,344 |  |  | $ | 27,414 |  |
| Net cash used in investing activities | $ | (26,429) |  |  | $ | (5,216) |  |
| Net cash used in financing activities | $ | (21,283) |  |  | $ | (15,553) |  |

[0001045810-26-000052:mdna:81]
Our fixed income security investments include highly rated, diversified investment types and credit exposures with shorter maturities.

[0001045810-26-000052:mdna:82]
Cash provided by operating activities increased in the first quarter of fiscal year 2027 compared to the first quarter of fiscal year 2026 due to higher revenue.

[0001045810-26-000052:mdna:83]
Cash used in investing activities increased in the first quarter of fiscal year 2027 compared to the first quarter of fiscal year 2026, primarily driven by higher purchases of equity investment securities.

[0001045810-26-000052:mdna:84]
Cash used in financing activities increased in the first quarter of fiscal year 2027 compared to the first quarter of fiscal year 2026, mainly due to higher share repurchases.

[0001045810-26-000052:mdna:85]
[same as prior period, unchanged from 0001045810-25-000230:mdna:84]

[0001045810-26-000052:mdna:86]
Our primary sources of liquidity include cash, cash equivalents, marketable debt and equity securities, and cash generated by our operations. As of April 26, 2026, we had $50.3 billion in cash, cash equivalents, and marketable debt securities as well as $30.2 billion of marketable equity securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and for the foreseeable future, including our future obligations. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements and commitments.

[0001045810-26-000052:mdna:87]
Our marketable securities consist of publicly-held equity securities, debt securities issued by the U.S. government and its agencies, highly-rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly-rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-26-000052:mdna:88]
Except for approximately $1.7 billion of cash, cash equivalents, and marketable debt securities held outside of the U.S., for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents, and marketable debt securities held outside the U.S. at the end of the first quarter of fiscal year 2027 are available for use in the U.S. without incurring additional U.S. federal income taxes. We made no federal income tax payments in the first quarter of fiscal year 2027, whereas our second quarter of fiscal year 2027 is scheduled to include two payments.

[0001045810-26-000052:mdna:89]
[same as prior period, unchanged from 0001045810-25-000230:mdna:88]

[0001045810-26-000052:mdna:90]
In the first quarter of fiscal year 2027, we repurchased 108 million shares of our common stock for $20.2 billion. As of April 26, 2026, we were authorized, subject to certain specifications, to repurchase up to $38.5 billion of our common stock.

[0001045810-26-000052:mdna:91]
On May 18, 2026, our Board of Directors approved an additional $80.0 billion in share repurchase authorization, without expiration.

[0001045810-26-000052:mdna:92]
We may execute repurchases from time to time, subject to market conditions, operating requirements and other investment opportunities, in the open market, in privately-negotiated transactions, pursuant to a Rule 10b5-1 trading plan or in structured share repurchase agreements in compliance with Rule 10b-18 of the Exchange Act. Our share repurchase program may be suspended at any time at our discretion.

[0001045810-26-000052:mdna:93]
We paid cash dividends to our shareholders of $243 million during the first quarter of fiscal year 2027. On May 18, 2026, we increased our quarterly cash dividend from $0.01 per share to $0.25 per share to all shareholders of record on June 4, 2026. Our quarterly cash dividend will be paid on June 26, 2026.

[0001045810-26-000052:mdna:94]
The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.

[0001045810-26-000052:mdna:95]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not significant for the first quarter of fiscal year 2027.

[0001045810-26-000052:mdna:96]
29

[0001045810-26-000052:mdna:97]
[same as prior period, unchanged from 0001045810-25-000230:mdna:94]

[0001045810-26-000052:mdna:98]
Our aggregate debt maturities as of April 26, 2026, by year payable, were as follows:

[0001045810-26-000052:mdna:99]
|  |  | Apr 26, 2026 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,000 |  |
| Due in one to five years |  | 2,750 |  |
| Due in five to ten years |  | 1,250 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (30) |  |
| Net carrying amount |  | $ | 8,470 |  |
| Less short-term portion |  | (1,000) |  |
| Total long-term portion |  | $ | 7,470 |  |

[0001045810-26-000052:mdna:100]
We have a commercial paper program to support general corporate purposes, pursuant to which we may issue unsecured paper notes, from time to time or all at once, up to $25.0 billion. As of April 26, 2026, no commercial paper was outstanding.

[0001045810-26-000052:mdna:101]
Refer to Note 9 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for further discussion.

[0001045810-26-000052:mdna:102]
[same as prior period, unchanged from 0001045810-25-000230:mdna:99]

[0001045810-26-000052:mdna:103]
For descriptions of our facility lease guarantees, long-term debt, purchase commitments, and operating lease obligations, refer to Note 8, Note 9, Note 10, and Note 14 of the Notes to the Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q, respectively.

[0001045810-26-000052:mdna:104]
We expect to continue investing in our ecosystem. Refer to Note 6 and Item 1A. Risk Factors for additional information regarding our investments.

[0001045810-26-000052:mdna:105]
Unrecognized tax benefits were $4.5 billion, which includes related interest and penalties of $439 million, and were recorded in non-current income tax payable as of April 26, 2026. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2023 and 2024. Refer to Note 11 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001045810-26-000052:mdna:106]
Other than the contractual obligations described in Notes 6 and 10, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 25, 2026 for a description of our contractual obligations. For a description of our facility lease guarantees, long-term debt, purchase obligations, and operating lease obligations, refer to Notes 8, 9, 10, and 14 of the Notes to the Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q, respectively.

[0001045810-26-000052:mdna:107]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-26-000052:mdna:108]
There has been no adoption of any new and recently issued accounting pronouncements.
