# NVDA 8-K — 0001045810-26-000051 filed 2026-05-20

## item codes, every 8-K on or before 2026-05-20

- 2026-05-20 0001045810-26-000051 — 2.02, 9.01
- 2026-05-08 0001045810-26-000028 — 5.02
- 2026-04-27 0001045810-26-000026 — 5.02
- 2026-03-06 0001045810-26-000024 — 5.02, 9.01
- 2026-02-25 0001045810-26-000019 — 2.02, 9.01
- 2026-01-23 0001045810-26-000003 — 5.02
- 2025-11-19 0001045810-25-000228 — 2.02, 9.01
- 2025-08-27 0001045810-25-000207 — 2.02, 9.01
- 2025-08-05 0001045810-25-000197 — 5.02
- 2025-07-01 0001045810-25-000179 — 5.07
- 2025-05-28 0001045810-25-000115 — 2.02, 9.01
- 2025-04-15 0001045810-25-000082 — 8.01
- 2025-03-07 0001045810-25-000039 — 5.02
- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2026-05-20

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-26-000051:8k_2_02:1]
EX-99.1
2
q1fy27pr.htm
EX-99.1

[0001045810-26-000051:8k_2_02:2]
Document

[0001045810-26-000051:8k_2_02:3]
NVIDIA Announces Financial Results for First Quarter Fiscal 2027

[0001045810-26-000051:8k_2_02:4]
•Record revenue of $81.6 billion, up 85% from a year ago

[0001045810-26-000051:8k_2_02:5]
•Record Data Center revenue of $75.2 billion, up 92% from a year ago

[0001045810-26-000051:8k_2_02:6]
•NVIDIA announces $80.0 billion additional share repurchase authorization and increases its quarterly cash dividend from $0.01 per share to $0.25 per share

[0001045810-26-000051:8k_2_02:7]
SANTA CLARA, Calif.—May 20, 2026―NVIDIA (NASDAQ: NVDA) today reported record revenue for the first quarter ended April 26, 2026, of $81.6 billion, up 20% from the previous quarter and up 85% from a year ago.

[0001045810-26-000051:8k_2_02:8]
For the quarter, GAAP and non-GAAP gross margins were 74.9% and 75.0%, respectively.

[0001045810-26-000051:8k_2_02:9]
For the quarter, GAAP and non-GAAP earnings per diluted share were $2.39 and $1.87, respectively.

[0001045810-26-000051:8k_2_02:10]
“The buildout of AI factories — the largest infrastructure expansion in human history — is accelerating at extraordinary speed,” said Jensen Huang, founder and CEO of NVIDIA. “Agentic AI has arrived, doing productive work, generating real value and scaling rapidly across companies and industries. NVIDIA is uniquely positioned at the center of this transformation as the only platform that runs in every cloud, powers every frontier and open source model, and scales everywhere AI is produced — from hyperscale data centers to the edge.”

[0001045810-26-000051:8k_2_02:11]
During the first quarter of fiscal 2027, NVIDIA returned a record level of approximately $20.0 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the first quarter, the company had $38.5 billion remaining under its share repurchase authorization. On May 18, 2026, the Board of Directors approved an additional $80.0 billion to the Company’s share repurchase authorization, without expiration. NVIDIA is increasing its quarterly cash dividend from $0.01 per share to $0.25 per share of common stock, which will be paid on June 26, 2026, to all shareholders of record on June 4, 2026.

[0001045810-26-000051:8k_2_02:12]
NVIDIA is transitioning to a new reporting framework that better reflects its current and future growth drivers. NVIDIA will have two market platforms — Data Center and Edge Computing. Within Data Center, NVIDIA will report two sub-markets, Hyperscale and ACIE, which incorporates AI Clouds, Industrial and Enterprise. Hyperscale will include revenue from the public clouds and the world’s largest consumer internet companies, while ACIE addresses NVIDIA’s growth opportunity in diverse AI purpose-built data centers and AI factories across industries and countries. Edge Computing highlights data processing devices for agentic and physical AI including PCs, game consoles, workstations, AI-RAN base stations, robotics and automotive.

[0001045810-26-000051:8k_2_02:13]
Under the previous sub-markets, Data Center compute revenue was a record $60.4 billion, up 77% from a year ago and up 18% sequentially. Data Center networking revenue was a record $14.8 billion, up 199% from a year ago and up 35% sequentially.

[0001045810-26-000051:8k_2_02:14]
Q1 Fiscal 2027 Summary

[0001045810-26-000051:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY27 | Q4 FY26 | Q1 FY26 | Q/Q | Y/Y |
| Revenue | $81,615 | $68,127 | $44,062 | 20 | % | 85 | % |
| Gross margin | 74.9 | % | 75.0 | % | 60.5 | % | (0.1) pts | 14.4 pts |
| Operating expenses | $7,621 | $6,794 | $5,030 | 12 | % | 52 | % |
| Operating income | $53,536 | $44,299 | $21,638 | 21 | % | 147 | % |
| Net income | $58,321 | $42,960 | $18,775 | 36 | % | 211 | % |
| Diluted earnings per share | $2.39 | $1.76 | $0.76 | 36 | % | 214 | % |

[0001045810-26-000051:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY27 | Q4 FY26 | Q1 FY26 | Q/Q | Y/Y |
| Revenue | $81,615 | $68,127 | $44,062 | 20 | % | 85 | % |
| Gross margin | 75.0 | % | 75.1 | % | 60.8 | % | (0.1) pts | 14.2 pts |
| Operating expenses | $7,449 | $6,666 | $4,993 | 12 | % | 49 | % |
| Operating income | $53,783 | $44,474 | $21,801 | 21 | % | 147 | % |
| Net income | $45,548 | $38,969 | $19,094 | 17 | % | 139 | % |
| Diluted earnings per share | $1.87 | $1.59 | $0.78 | 18 | % | 140 | % |

[0001045810-26-000051:8k_2_02:17]
Outlook

[0001045810-26-000051:8k_2_02:18]
NVIDIA’s outlook for the second quarter of fiscal 2027 is as follows:

[0001045810-26-000051:8k_2_02:19]
•Revenue is expected to be $91.0 billion, plus or minus 2%. NVIDIA is not assuming any Data Center compute revenue from China in its outlook.

[0001045810-26-000051:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 74.9% and 75.0%, respectively, plus or minus 50 basis points.

[0001045810-26-000051:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $8.5 billion and $8.3 billion, respectively.

[0001045810-26-000051:8k_2_02:22]
For the full year fiscal 2027, NVIDIA expects GAAP and non-GAAP tax rates to be between 16.0% and 18.0%, excluding any discrete items and material changes to NVIDIA’s tax environment.

[0001045810-26-000051:8k_2_02:23]
Highlights

[0001045810-26-000051:8k_2_02:24]
Data Center

[0001045810-26-000051:8k_2_02:25]
•First-quarter revenue was a record $75.2 billion, up 21% from the previous quarter and up 92% from a year ago.

[0001045810-26-000051:8k_2_02:26]
•Announced the NVIDIA Vera Rubin platform, including the NVIDIA Vera CPU, the world’s first processor purpose-built for agentic AI, and NVIDIA BlueField®-4 STX, accelerated storage infrastructure for agentic AI factories.

[0001045810-26-000051:8k_2_02:27]
•Entered production with NVIDIA Dynamo 1.0, open source software that boosts generative and agentic inference on NVIDIA Blackwell GPUs by up to 7x, with widespread global adoption.

[0001045810-26-000051:8k_2_02:28]
•Announced NVIDIA NemoClaw™ for the OpenClaw agent platform, NVIDIA OpenShell™ with privacy and security controls for autonomous AI agents, and NVIDIA Agent Toolkit, an open source platform for building autonomous enterprise AI agents.

[0001045810-26-000051:8k_2_02:29]
•Advanced open AI model development with new NVIDIA Nemotron™, NVIDIA BioNeMo™ and NVIDIA Ising models, and the launch of the NVIDIA Nemotron Coalition.

[0001045810-26-000051:8k_2_02:30]
•Expanded collaboration with Google Cloud to advance agentic and physical AI, including new NVIDIA Vera Rubin-powered A5X instances and a preview of Google Gemini models on Google Distributed Cloud running on NVIDIA Blackwell and Blackwell Ultra GPUs.

[0001045810-26-000051:8k_2_02:31]
•Expanded the AI ecosystem through a strategic partnership with Marvell via NVIDIA NVLink Fusion™, and collaboration on silicon photonics technology.

[0001045810-26-000051:8k_2_02:32]
•Announced multi-year strategic agreements with Coherent, Corning and Lumentum to accelerate innovation in advanced optics technologies.

[0001045810-26-000051:8k_2_02:33]
•Announced the NVIDIA RTX PRO™ 4500 Blackwell Server Edition GPU.

[0001045810-26-000051:8k_2_02:34]
Edge Computing

[0001045810-26-000051:8k_2_02:35]
•First-quarter Edge Computing revenue was $6.4 billion, up 10% from the previous quarter and up 29% from a year ago.

[0001045810-26-000051:8k_2_02:36]
•Released NVIDIA DLSS 4.5 Dynamic Multi Frame Generation and previewed the next generation of DLSS 3D-guided neural rendering model, DLSS 5, NVIDIA’s most significant graphics breakthrough since ray tracing in 2018.

[0001045810-26-000051:8k_2_02:37]
•Accelerated and optimized key local agentic models, including Gemma 4, Qwen, Mistral and NVIDIA Nemotron for NVIDIA RTX™ and edge devices.

[0001045810-26-000051:8k_2_02:38]
•Announced the NVIDIA Alpamayo 1.5 open model and NVIDIA Omniverse NuRec technologies that enable autonomous driving systems at scale.

[0001045810-26-000051:8k_2_02:39]
•Expanded partnership with Hyundai Motor Company and Kia for next-generation autonomous driving built on the NVIDIA DRIVE Hyperion™ platform, and expanded partnership with Uber to launch a fleet of autonomous vehicles powered by full-stack NVIDIA DRIVE AV software.

[0001045810-26-000051:8k_2_02:40]
•Announced that BYD, Geely, Isuzu and Nissan are building level 4-ready vehicles on the NVIDIA DRIVE Hyperion platform, and introduced NVIDIA Halos OS, a unified safety architecture for AI-driven vehicles.

[0001045810-26-000051:8k_2_02:41]
•Announced new NVIDIA Cosmos™ and NVIDIA Isaac™ GR00T N models, new Isaac simulation frameworks, the general availability of NVIDIA IGX Thor™ and physical AI leaders building on NVIDIA technology.

[0001045810-26-000051:8k_2_02:42]
•Partnered with global industrial software leaders to accelerate AI-driven design, engineering and manufacturing using NVIDIA CUDA-X™, NVIDIA Omniverse™ and accelerated computing.

[0001045810-26-000051:8k_2_02:43]
•Announced collaboration with T-Mobile and Nokia to integrate physical AI applications on AI-RAN-ready infrastructure, as well as a commitment with global telecom leaders to build 6G wireless networks on AI-native, open and secure platforms.

[0001045810-26-000051:8k_2_02:44]
CFO Commentary

[0001045810-26-000051:8k_2_02:45]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-26-000051:8k_2_02:46]
Conference Call and Webcast Information

[0001045810-26-000051:8k_2_02:47]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2027 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2027.

[0001045810-26-000051:8k_2_02:48]
Non-GAAP Measures

[0001045810-26-000051:8k_2_02:49]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition-related and other costs, other, gains/losses from equity securities, net, certain other income and expense, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures no longer exclude stock-based compensation expense. The historical non-GAAP financial information presented has been updated to include stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the users’ overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-26-000051:8k_2_02:50]
About NVIDIA

[0001045810-26-000051:8k_2_02:51]
NVIDIA (NASDAQ: NVDA) is the world leader in AI and accelerated computing.

[0001045810-26-000051:8k_2_02:52]
###

[0001045810-26-000051:8k_2_02:53]
For further information, contact:

[0001045810-26-000051:8k_2_02:54]
| Toshiya Hari |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| toshiyah@nvidia.com |  | press@nvidia.com |

[0001045810-26-000051:8k_2_02:55]
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, BlueField, Cosmos, NemoClaw, Nemotron, NVIDIA Isaac, BioNeMo, CUDA-X, NVIDIA DRIVE Hyperion, NVIDIA IGX Thor, NVIDIA Omniverse, NVIDIA OpenShell, NVIDIA RTX PRO, NVIDIA RTX, and NVLink Fusion are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-26-000051:8k_2_02:56]
NVIDIA CORPORATION

[0001045810-26-000051:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-26-000051:8k_2_02:58]
(In millions, except per share data)

[0001045810-26-000051:8k_2_02:59]
(Unaudited)

[0001045810-26-000051:8k_2_02:60]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 26, |  | April 27, |  |  |  |  |
|  |  |  | 2026 |  | 2025 |  |  |  |  |
| Revenue | $ | 81,615 |  |  | $ | 44,062 |  |  |  |  |  |
| Cost of revenue | 20,458 |  |  | 17,394 |  |  |  |  |  |
| Gross profit | 61,157 |  |  | 26,668 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 6,321 |  |  | 3,989 |  |  |  |  |  |
|  | Sales, general and administrative | 1,300 |  |  | 1,041 |  |  |  |  |  |
|  |  | Total operating expenses | 7,621 |  |  | 5,030 |  |  |  |  |  |
| Operating income | 53,536 |  |  | 21,638 |  |  |  |  |  |
|  | Interest income | 540 |  |  | 515 |  |  |  |  |  |
|  | Interest expense | (102) |  |  | (63) |  |  |  |  |  |
|  | Other income (expense), net | 15,929 |  |  | (180) |  |  |  |  |  |
|  |  | Total other income, net | 16,367 |  |  | 272 |  |  |  |  |  |
| Income before income tax | 69,903 |  |  | 21,910 |  |  |  |  |  |
| Income tax expense | 11,582 |  |  | 3,135 |  |  |  |  |  |
| Net income | $ | 58,321 |  |  | $ | 18,775 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 2.40 |  |  | $ | 0.77 |  |  |  |  |  |
|  | Diluted | $ | 2.39 |  |  | $ | 0.76 |  |  |  |  |  |
| Weighted average shares used in per share computation: |
|  | Basic | 24,286 |  |  | 24,441 |  |  |  |  |  |
|  | Diluted | 24,391 |  |  | 24,611 |  |  |  |  |  |

[0001045810-26-000051:8k_2_02:61]
| NVIDIA CORPORATION |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  |  | April 26, |  | January 25, |  |
|  |  |  | 2026 |  | 2026 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash and cash equivalents | $ | 13,237 |  |  | $ | 10,605 |  |  |
|  | Marketable debt securities | 37,098 |  |  | 39,065 |  |  |
|  | Marketable equity securities | 30,237 |  |  | 12,886 |  |  |
|  | Accounts receivable, net | 40,710 |  |  | 38,466 |  |  |
|  | Inventories | 25,797 |  |  | 21,403 |  |  |
|  | Prepaid expenses and other current assets | 3,916 |  |  | 3,180 |  |  |
|  |  | Total current assets | 150,995 |  |  | 125,605 |  |  |
| Property and equipment, net | 12,403 |  |  | 10,383 |  |  |
| Operating lease assets | 4,258 |  |  | 2,867 |  |  |
| Goodwill | 20,894 |  |  | 20,832 |  |  |
| Intangible assets, net | 3,120 |  |  | 3,306 |  |  |
| Deferred income tax assets | 11,707 |  |  | 13,258 |  |  |
| Non-marketable securities | 43,364 |  |  | 22,251 |  |  |
| Other assets | 12,733 |  |  | 8,301 |  |  |
|  |  | Total assets | $ | 259,474 |  |  | $ | 206,803 |  |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable | $ | 13,097 |  |  | $ | 9,812 |  |  |
|  | Accrued and other current liabilities | 29,787 |  |  | 21,352 |  |  |
|  | Short-term debt | 1,000 |  |  | 999 |  |  |
|  |  | Total current liabilities | 43,884 |  |  | 32,163 |  |  |
| Long-term debt | 7,470 |  |  | 7,469 |  |  |
| Long-term operating lease liabilities | 3,878 |  |  | 2,572 |  |  |
| Other long-term liabilities | 8,768 |  |  | 7,306 |  |  |
|  |  | Total liabilities | 64,000 |  |  | 49,510 |  |  |
| Shareholders' equity | 195,474 |  |  | 157,293 |  |  |
|  |  | Total liabilities and shareholders' equity | $ | 259,474 |  |  | $ | 206,803 |  |  |

[0001045810-26-000051:8k_2_02:62]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  |  |  |  |
|  | April 26, |  | April 27, |  |  |  |  |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 58,321 |  |  | $ | 18,775 |  |  |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,928 |  |  | 1,474 |  |  |  |  |  |  |  |  |  |
| Deferred income taxes | 1,584 |  |  | (2,177) |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization | 997 |  |  | 611 |  |  |  |  |  |  |  |  |  |
| (Gains) losses from equity securities, net | (15,936) |  |  | 175 |  |  |  |  |  |  |  |  |  |
| Other | (94) |  |  | (98) |  |  |  |  |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | (2,243) |  |  | 933 |  |  |  |  |  |  |  |  |  |
| Inventories | (4,420) |  |  | (1,258) |  |  |  |  |  |  |  |  |  |
| Prepaid expenses and other assets | (983) |  |  | 560 |  |  |  |  |  |  |  |  |  |
| Accounts payable | 2,210 |  |  | 941 |  |  |  |  |  |  |  |  |  |
| Accrued and other current liabilities | 7,763 |  |  | 7,128 |  |  |  |  |  |  |  |  |  |
| Other long-term liabilities | 1,217 |  |  | 350 |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | 50,344 |  |  | 27,414 |  |  |  |  |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable debt securities | 1,946 |  |  | 3,122 |  |  |  |  |  |  |  |  |  |
| Proceeds from sales of non-marketable securities | 26 |  |  | — |  |  |  |  |  |  |  |  |  |
| Proceeds from sales of marketable debt securities | 25 |  |  | 467 |  |  |  |  |  |  |  |  |  |
| Purchases of non-marketable securities | (18,582) |  |  | (649) |  |  |  |  |  |  |  |  |  |
| Purchases of marketable debt and equity securities | (8,000) |  |  | (6,546) |  |  |  |  |  |  |  |  |  |
| Purchases related to property and equipment and intangible assets | (1,757) |  |  | (1,227) |  |  |  |  |  |  |  |  |  |
| Acquisitions, net of cash acquired | (87) |  |  | (383) |  |  |  |  |  |  |  |  |  |
| Net cash used in investing activities | (26,429) |  |  | (5,216) |  |  |  |  |  |  |  |  |  |

[0001045810-26-000051:8k_2_02:63]
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 515 |  |  | 370 |  |  |  |  |  |  |  |  |  |
| Payments related to repurchases of common stock | (19,312) |  |  | (14,095) |  |  |  |  |  |  |  |  |  |
| Payments related to employee stock plan taxes | (2,129) |  |  | (1,532) |  |  |  |  |  |  |  |  |  |
| Dividends paid | (243) |  |  | (244) |  |  |  |  |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (33) |  |  | (52) |  |  |  |  |  |  |  |  |  |
| Other | (81) |  |  | — |  |  |  |  |  |  |  |  |  |
| Net cash used in financing activities | (21,283) |  |  | (15,553) |  |  |  |  |  |  |  |  |  |
| Change in cash and cash equivalents | 2,632 |  |  | 6,645 |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 10,605 |  |  | 8,589 |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 13,237 |  |  | $ | 15,234 |  |  |  |  |  |  |  |  |  |

[0001045810-26-000051:8k_2_02:64]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | ($ In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 26, |  | January 25, |  | April 27, |  |  |  |  |
|  |  |  | 2026 |  | 2026 |  | 2025 |  |  |  |  |
| GAAP cost of revenue |  | $ | 20,458 |  |  | $ | 17,034 |  |  | $ | 17,394 |  |  |  |  |  |
| GAAP gross profit |  | $ | 61,157 |  |  | $ | 51,093 |  |  | $ | 26,668 |  |  |  |  |  |
| GAAP gross margin |  | 74.9 | % |  | 75.0 | % |  | 60.5 | % |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | 47 |  |  | 48 |  |  | 123 |  |  |  |  |  |
|  | Other |  | 28 |  |  | (1) |  |  | 3 |  |  |  |  |  |
| Non-GAAP cost of revenue |  | $ | 20,383 |  |  | $ | 16,987 |  |  | $ | 17,268 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 61,232 |  |  | $ | 51,140 |  |  | $ | 26,794 |  |  |  |  |  |
| Non-GAAP gross margin* |  | 75.0 | % |  | 75.1 | % |  | 60.8 | % |  |  |  |  |
| GAAP operating expenses |  | $ | 7,621 |  |  | $ | 6,794 |  |  | $ | 5,030 |  |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | (172) |  |  | (90) |  |  | (37) |  |  |  |  |  |
|  | Other |  | — |  |  | (38) |  |  | — |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 7,449 |  |  | $ | 6,666 |  |  | $ | 4,993 |  |  |  |  |  |
| GAAP operating income |  | $ | 53,536 |  |  | $ | 44,299 |  |  | $ | 21,638 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 247 |  |  | 175 |  |  | 163 |  |  |  |  |  |
| Non-GAAP operating income* |  | $ | 53,783 |  |  | $ | 44,474 |  |  | $ | 21,801 |  |  |  |  |  |
| GAAP total other income, net |  | $ | 16,367 |  |  | $ | 6,098 |  |  | $ | 272 |  |  |  |  |  |
|  | (Gains) losses from equity securities, net |  | (15,936) |  |  | (5,491) |  |  | 175 |  |  |  |  |  |
|  | Other (B) |  | 26 |  |  | 13 |  |  | 1 |  |  |  |  |  |
| Non-GAAP total other income, net |  | $ | 457 |  |  | $ | 620 |  |  | $ | 448 |  |  |  |  |  |
| GAAP net income |  | $ | 58,321 |  |  | $ | 42,960 |  |  | $ | 18,775 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | (15,663) |  |  | (5,303) |  |  | 339 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments |  | 2,890 |  |  | 1,312 |  |  | (20) |  |  |  |  |  |
| Non-GAAP net income* |  | $ | 45,548 |  |  | $ | 38,969 |  |  | $ | 19,094 |  |  |  |  |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 2.39 |  |  | $ | 1.76 |  |  | $ | 0.76 |  |  |  |  |  |
|  | Non-GAAP* |  | $ | 1.87 |  |  | $ | 1.59 |  |  | $ | 0.78 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation |  | 24,391 |  |  | 24,432 |  |  | 24,611 |  |  |  |  |  |

[0001045810-26-000051:8k_2_02:65]
| GAAP net cash provided by operating activities |  | $ | 50,344 |  |  | $ | 36,190 |  |  | $ | 27,414 |  |  |  |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (1,757) |  |  | (1,284) |  |  | (1,227) |  |  |  |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (33) |  |  | (4) |  |  | (52) |  |  |  |  |  |
| Free cash flow |  | $ | 48,554 |  |  | $ | 34,902 |  |  | $ | 26,135 |  |  |  |  |  |
| *Includes H20 charges/(releases), net, which was $4.5 billion for the first quarter of fiscal 2026, insignificant for the fourth quarter of fiscal 2026, and none for the first quarter of fiscal 2027. |

[0001045810-26-000051:8k_2_02:66]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |  |
|  |  |  | Three Months Ended |  |  |  |
|  |  |  | April 26, |  | January 25, |  | April 27, |  |  |  |  |  |
|  |  |  | 2026 |  | 2026 |  | 2025 |  |  |  |  |  |
|  | Cost of revenue |  | $ | 47 |  |  | $ | 48 |  |  | $ | 123 |  |  |  |  |  |  |
|  | Research and development |  | $ | 167 |  |  | $ | 83 |  |  | $ | 28 |  |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 5 |  |  | $ | 7 |  |  | $ | 9 |  |  |  |  |  |  |
| (B) Comprised of interest expense related to acquisition consideration discount to be paid in the future, dividend income on equity securities, share of net (earnings)/losses related to equity method investments, and amortization of debt discount. |  |

[0001045810-26-000051:8k_2_02:67]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2027 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 74.9 | % |
|  | Impact of acquisition-related costs and other costs |  | 0.1 | % |
| Non-GAAP gross margin |  | 75.0 | % |
| GAAP operating expenses |  | $ | 8,500 |  |
|  | Acquisition-related costs and other costs |  | (200) |  |
| Non-GAAP operating expenses |  | $ | 8,300 |  |
