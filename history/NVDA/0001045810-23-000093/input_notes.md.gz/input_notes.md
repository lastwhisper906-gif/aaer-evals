# NVDA notes — 0001045810-23-000093


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-23-000093:notes:1]
[same as prior period, unchanged from 0001045810-22-000166:notes:1]

[0001045810-23-000093:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 29, 2023 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023.

[0001045810-23-000093:notes:3]
[same as prior period, unchanged from 0001045810-22-000166:notes:3]

[0001045810-23-000093:notes:4]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023.

[0001045810-23-000093:notes:5]
[same as prior period, unchanged from 0001045810-22-000166:notes:5]

[0001045810-23-000093:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The first quarters of fiscal years 2024 and 2023 were both 13-week quarters.

[0001045810-23-000093:notes:7]
[same as prior period, unchanged from 0001045810-22-000166:notes:7]

[0001045810-23-000093:notes:8]
[same as prior period, unchanged from 0001045810-22-000166:notes:8]

[0001045810-23-000093:notes:9]
[same as prior period, unchanged from 0001045810-22-000166:notes:10]

[0001045810-23-000093:notes:10]
[same as prior period, unchanged from 0001045810-22-000166:notes:11]

[0001045810-23-000093:notes:11]
Use of Estimates

[0001045810-23-000093:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-23-000093:notes:13]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the effect of this change in estimate for the three months ended April 30, 2023, was a benefit of $2 million and $31 million for cost of revenue and operating expenses, respectively. This resulted in an increase in operating income of $33 million and net income of $28 million after tax, or $0.01 per both basic and diluted share.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-23-000093:notes:14]
Business CombinationTermination of the Arm Share Purchase AgreementIn February 2022, NVIDIA and SoftBank Group Corp, or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited, or Arm, from SoftBank. The parties agreed to terminate due to significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-23-000093:notes:15]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2024 and 2035.

[0001045810-23-000093:notes:16]
Future minimum lease payments under our non-cancelable operating leases as of April 30, 2023 are as follows:

[0001045810-23-000093:notes:17]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first quarter) | $ | 178 |  |
| 2025 | 218 |  |
| 2026 | 196 |  |
| 2027 | 180 |  |
| 2028 | 159 |  |
| 2029 and thereafter | 357 |  |
| Total | 1,288 |  |
| Less imputed interest | 162 |  |
| Present value of net future minimum lease payments | 1,126 |  |
| Less short-term operating lease liabilities | 187 |  |
| Long-term operating lease liabilities | $ | 939 |  |

[0001045810-23-000093:notes:18]
In addition, we have operating leases, primarily for our data centers, that are expected to commence between the second quarter of fiscal year 2024 and fiscal year 2025 with lease terms of 2 to 8 years for $361 million.

[0001045810-23-000093:notes:19]
Operating lease expenses were $59 million and $44 million for the first quarter of fiscal years 2024 and 2023, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2024 and 2023 were not significant.

[0001045810-23-000093:notes:20]
[same as prior period, unchanged from 0001045810-22-000166:notes:19]

[0001045810-23-000093:notes:21]
|  | Three Months Ended |
|  | April 30, 2023 |  | May 1, 2022 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 61 |  |  | $ | 45 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 106 |  |  | $ | 62 |  |

[0001045810-23-000093:notes:22]
As of April 30, 2023, our operating leases had a weighted average remaining lease term of 6.6 years and a weighted average discount rate of 3.33%. As of January 29, 2023, our operating leases had a weighted average remaining lease term of 6.8 years and a weighted average discount rate of 3.21%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-23-000093:notes:23]
[same as prior period, unchanged from 0001045810-22-000166:notes:22]

[0001045810-23-000093:notes:24]
[same as prior period, unchanged from 0001045810-22-000166:notes:23]

[0001045810-23-000093:notes:25]
|  | Three Months Ended |  |  |
|  | April 30,2023 |  | May 1,2022 |  |  |  |  |
|  | (In millions) |
| Cost of revenue | $ | 27 |  |  | $ | 38 |  |  |  |  |  |
| Research and development | 524 |  |  | 384 |  |  |  |  |  |
| Sales, general and administrative | 184 |  |  | 156 |  |  |  |  |  |
| Total | $ | 735 |  |  | $ | 578 |  |  |  |  |  |

[0001045810-23-000093:notes:26]
[same as prior period, unchanged from 0001045810-22-000166:notes:25]

[0001045810-23-000093:notes:27]
[same as prior period, unchanged from 0001045810-22-000166:notes:26]

[0001045810-23-000093:notes:28]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 29, 2023 | 45 |  |  | $ | 158.45 |  |  |  |  |  |
| Granted | 2 |  |  | $ | 226.08 |  |  |  |  |  |
| Vested restricted stock | (6) |  |  | $ | 115.99 |  |  |  |  |  |
| Canceled and forfeited | (1) |  |  | $ | 199.37 |  |  |  |  |  |
| Balances, April 30, 2023 | 40 |  |  | $ | 167.07 |  |  |  |  |  |

[0001045810-23-000093:notes:29]
As of April 30, 2023, there was $6.55 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.5 years for RSUs, PSUs, and market-based PSUs, and 1.1 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-23-000093:notes:30]
[same as prior period, unchanged from 0001045810-22-000166:notes:29]

[0001045810-23-000093:notes:31]
|  | Three Months Ended |  |  |
|  | April 30, |  | May 1, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 2,043 |  |  | $ | 1,618 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,470 |  |  | 2,506 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 20 |  |  | 31 |  |  |  |  |  |
| Diluted weighted average shares | 2,490 |  |  | 2,537 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.83 |  |  | $ | 0.65 |  |  |  |  |  |
| Diluted (2) | $ | 0.82 |  |  | $ | 0.64 |  |  |  |  |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 4 |  |  | 3 |  |  |  |  |  |

[0001045810-23-000093:notes:32]
[same as prior period, unchanged from 0001045810-22-000166:notes:31]

[0001045810-23-000093:notes:33]
[same as prior period, unchanged from 0001045810-22-000166:notes:32]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-23-000093:notes:34]
Income Taxes
Income tax expense was $166 million and $187 million for the first quarter of fiscal years 2024 and 2023, respectively. The income tax expense as a percentage of income before income tax was 7.5% and 10.3% for the first quarter of fiscal years 2024 and 2023, respectively.

[0001045810-23-000093:notes:35]
The decrease in the effective tax rate was primarily due to the tax impact of the Arm acquisition termination cost recorded in the first quarter of fiscal year 2023, which did not result in a tax benefit, and the increased impact of tax benefits from stock-based compensation, partially offset by decreased tax benefits impact from the foreign-derived intangible income deduction and the U.S. federal research tax credit.

[0001045810-23-000093:notes:36]
Our effective tax rates for the first quarter of fiscal years 2024 and 2023 were lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation and the U.S. federal research tax credit.

[0001045810-23-000093:notes:37]
For the first quarter of fiscal year 2024, there were no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 29, 2023.

[0001045810-23-000093:notes:38]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 30, 2023, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-23-000093:notes:39]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-23-000093:notes:40]
The following is a summary of cash equivalents and marketable securities:

[0001045810-23-000093:notes:41]
|  | April 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,723 |  |  | $ | 4 |  |  | $ | (11) |  |  | $ | 6,716 |  |  | $ | 2,535 |  |  | $ | 4,181 |  |
| Debt securities issued by the U.S. Treasury | 3,996 |  |  | 2 |  |  | (31) |  |  | 3,967 |  |  | 421 |  |  | 3,546 |  |
| Debt securities issued by U.S. government agencies | 2,442 |  |  | 1 |  |  | (1) |  |  | 2,442 |  |  | 199 |  |  | 2,243 |  |
| Money market funds | 1,502 |  |  | — |  |  | — |  |  | 1,502 |  |  | 1,502 |  |  | — |  |
| Certificates of deposit | 395 |  |  | — |  |  | — |  |  | 395 |  |  | 173 |  |  | 222 |  |
| Foreign government bonds | 49 |  |  | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Total | $ | 15,107 |  |  | $ | 7 |  |  | $ | (43) |  |  | $ | 15,071 |  |  | $ | 4,830 |  |  | $ | 10,241 |  |

[0001045810-23-000093:notes:42]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

[0001045810-23-000093:notes:43]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-23-000093:notes:44]
|  | April 30, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,601 |  |  | $ | (11) |  |  | $ | 1,106 |  |  | $ | (20) |  |  | $ | 2,707 |  |  | $ | (31) |  |
| Debt securities issued by U.S. government agencies | 1,259 |  |  | (1) |  |  | — |  |  | — |  |  | 1,259 |  |  | (1) |  |
| Corporate debt securities | 945 |  |  | (4) |  |  | 838 |  |  | (7) |  |  | 1,783 |  |  | (11) |  |
| Total | $ | 3,805 |  |  | $ | (16) |  |  | $ | 1,944 |  |  | $ | (27) |  |  | $ | 5,749 |  |  | $ | (43) |  |

[0001045810-23-000093:notes:45]
|  | January 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 2,444 |  |  | $ | (21) |  |  | $ | 1,172 |  |  | $ | (23) |  |  | $ | 3,616 |  |  | $ | (44) |  |
| Corporate debt securities | 1,188 |  |  | (7) |  |  | 696 |  |  | (5) |  |  | 1,884 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,307 |  |  | (2) |  |  | — |  |  | — |  |  | 1,307 |  |  | (2) |  |
| Total | $ | 4,939 |  |  | $ | (30) |  |  | $ | 1,868 |  |  | $ | (28) |  |  | $ | 6,807 |  |  | $ | (58) |  |

[0001045810-23-000093:notes:46]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

[0001045810-23-000093:notes:47]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-23-000093:notes:48]
|  | April 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,654 |  |  | $ | 12,625 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 2,453 |  |  | 2,446 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,107 |  |  | $ | 15,071 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-23-000093:notes:49]
[same as prior period, unchanged from 0001045810-22-000166:notes:48]

[0001045810-23-000093:notes:50]
|  |  | Fair Value at |
|  | Pricing Category |  | April 30, 2023 |  | January 29, 2023 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 1,502 |  |  | $ | 1,777 |  |
| Corporate debt securities | Level 2 |  | $ | 6,716 |  |  | $ | 4,797 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 3,967 |  |  | $ | 4,142 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,442 |  |  | $ | 1,834 |  |
| Certificates of deposit | Level 2 |  | $ | 395 |  |  | $ | 365 |  |
| Foreign government bonds | Level 2 |  | $ | 49 |  |  | $ | 140 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities (1) | Level 1 |  | $ | 9 |  |  | $ | 11 |  |
| Privately-held equity securities | Level 3 |  | $ | 496 |  |  | $ | 288 |  |
| Liabilities (2) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,243 |  |  | $ | 1,230 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,197 |  |  | $ | 1,185 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 976 |  |  | $ | 966 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,112 |  |  | $ | 1,099 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,375 |  |  | $ | 1,364 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,062 |  |  | $ | 1,044 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 862 |  |  | $ | 870 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,633 |  |  | $ | 1,637 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 403 |  |  | $ | 410 |  |

[0001045810-23-000093:notes:51]
(1)    Unrealized losses of $14 million and $24 million from investments in publicly-traded equity securities were recorded in other income (expense), net, in the first quarter of fiscal years 2024 and 2023, respectively.

[0001045810-23-000093:notes:52]
[same as prior period, unchanged from 0001045810-22-000166:notes:51]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-23-000093:notes:53]
[same as prior period, unchanged from 0001045810-22-000166:notes:52]

[0001045810-23-000093:notes:54]
|  | April 30, 2023 |  | January 29, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 3,112 |  |  | $ | (1,780) |  |  | $ | 1,332 |  |  | $ | 3,093 |  |  | $ | (1,614) |  |  | $ | 1,479 |  |
| Patents and licensed technology | 460 |  |  | (251) |  |  | 209 |  |  | 446 |  |  | (249) |  |  | 197 |  |
| Total intangible assets | $ | 3,572 |  |  | $ | (2,031) |  |  | $ | 1,541 |  |  | $ | 3,539 |  |  | $ | (1,863) |  |  | $ | 1,676 |  |

[0001045810-23-000093:notes:55]
Amortization expense associated with intangible assets was $181 million and $155 million for the first quarter of fiscal years 2024 and 2023, respectively.

[0001045810-23-000093:notes:56]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of April 30, 2023:

[0001045810-23-000093:notes:57]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first quarter) | $ | 433 |  |
| 2025 | 554 |  |
| 2026 | 259 |  |
| 2027 | 149 |  |
| 2028 | 37 |  |
| 2029 and thereafter | 109 |  |
| Total | $ | 1,541 |  |

[0001045810-23-000093:notes:58]
In the first quarter of fiscal year 2024, goodwill increased by $58 million from an acquisition, and was assigned to our Compute & Networking segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-23-000093:notes:59]
[same as prior period, unchanged from 0001045810-22-000166:notes:56]

[0001045810-23-000093:notes:60]
|  | April 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Inventories: | (In millions) |
| Raw materials | $ | 1,809 |  |  | $ | 2,430 |  |
| Work in-process | 930 |  |  | 466 |  |
| Finished goods | 1,872 |  |  | 2,263 |  |
| Total inventories | $ | 4,611 |  |  | $ | 5,159 |  |

[0001045810-23-000093:notes:61]
|  | April 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Other Assets: | (In millions) |
| Prepaid supply and capacity agreements | $ | 3,002 |  |  | $ | 2,989 |  |
| Investment in non-affiliated entities | 505 |  |  | 299 |  |
| Prepaid royalties | 381 |  |  | 387 |  |
| Prepaid cloud services | 171 |  |  | 23 |  |
| Other | 145 |  |  | 122 |  |
| Total other assets | $ | 4,204 |  |  | $ | 3,820 |  |

[0001045810-23-000093:notes:62]
|  | April 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Accrued and Other Current Liabilities: | (In millions) |
| Taxes payable | $ | 1,544 |  |  | $ | 467 |  |
| Customer program accruals | 1,245 |  |  | 1,196 |  |
| Excess inventory purchase obligations | 786 |  |  | 954 |  |
| Deferred revenue (1) | 367 |  |  | 354 |  |
| Accrued payroll and related expenses | 320 |  |  | 530 |  |
| Operating leases | 187 |  |  | 176 |  |
| Licenses and royalties | 143 |  |  | 149 |  |
| Product warranty and return provisions | 112 |  |  | 108 |  |
| Other | 165 |  |  | 186 |  |
| Total accrued and other current liabilities | $ | 4,869 |  |  | $ | 4,120 |  |

[0001045810-23-000093:notes:63]
[same as prior period, unchanged from 0001045810-22-000166:notes:61]

[0001045810-23-000093:notes:64]
|  | April 30, |  | January 29, |
|  | 2023 |  | 2023 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,300 |  |  | $ | 1,204 |  |
| Deferred income tax | 290 |  |  | 247 |  |
| Deferred revenue (2) | 230 |  |  | 218 |  |
| Licenses payable | 155 |  |  | 181 |  |
| Other | 62 |  |  | 63 |  |
| Total other long-term liabilities | $ | 2,037 |  |  | $ | 1,913 |  |

[0001045810-23-000093:notes:65]
(1)    Income tax payable is comprised of the long-term portion of the one-time transition tax payable, unrecognized tax benefits, and related interest and penalties.

[0001045810-23-000093:notes:66]
[same as prior period, unchanged from 0001045810-22-000166:notes:64]

[0001045810-23-000093:notes:67]
[same as prior period, unchanged from 0001045810-22-000166:notes:65]

[0001045810-23-000093:notes:68]
The following table shows the changes in deferred revenue during the first quarter of fiscal years 2024 and 2023:

[0001045810-23-000093:notes:69]
|  | April 30, |  | May 1, |
|  | 2023 |  | 2022 |
|  | (In millions) |
| Balance at beginning of period | $ | 572 |  |  | $ | 502 |  |
| Deferred revenue additions during the period | 287 |  |  | 212 |  |
| Revenue recognized during the period | (262) |  |  | (177) |  |
| Balance at end of period | $ | 597 |  |  | $ | 537 |  |

[0001045810-23-000093:notes:70]
Revenue allocated to remaining performance obligations, which includes deferred revenue and amounts that will be invoiced and recognized as revenue in future periods, was $639 million as of April 30, 2023. We expect to recognize approximately 46% of this revenue over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-23-000093:notes:71]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur.

[0001045810-23-000093:notes:72]
[same as prior period, unchanged from 0001045810-22-000166:notes:70]

[0001045810-23-000093:notes:73]
The table below presents the notional value of our foreign currency forward contracts outstanding:

[0001045810-23-000093:notes:74]
|  | April 30,2023 |  | January 29,2023 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,142 |  |  | $ | 1,128 |  |
| Non-designated hedges | $ | 350 |  |  | $ | 366 |  |

[0001045810-23-000093:notes:75]
The unrealized gains and losses or fair value of our foreign currency forward contracts was not significant as of April 30, 2023 and January 29, 2023.

[0001045810-23-000093:notes:76]
As of April 30, 2023, all designated foreign currency forward contracts mature within 18 months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-23-000093:notes:77]
During the first quarter of fiscal years 2024 and 2023, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.


## us-gaap:DebtDisclosureTextBlock

[0001045810-23-000093:notes:78]
Debt
Long-Term Debt

[0001045810-23-000093:notes:79]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:

[0001045810-23-000093:notes:80]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (46) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 10,954 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 9,704 |  |  | $ | 9,703 |  |

[0001045810-23-000093:notes:81]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-23-000093:notes:82]
As of April 30, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-23-000093:notes:83]
Commercial Paper

[0001045810-23-000093:notes:84]
We have a $575 million commercial paper program to support general corporate purposes. As of April 30, 2023, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-23-000093:notes:85]
Commitments and Contingencies
Purchase Obligations

[0001045810-23-000093:notes:86]
Our purchase obligations reflect our commitments to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-23-000093:notes:87]
As of April 30, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $7.27 billion. During the normal course of business, to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of cancellation.

[0001045810-23-000093:notes:88]
Other non-inventory purchase obligations of $3.26 billion include $2.43 billion of multi-year cloud service agreements.

[0001045810-23-000093:notes:89]
Total future purchase commitments as of April 30, 2023 are as follows:

[0001045810-23-000093:notes:90]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first quarter) | $ | 6,667 |  |
| 2025 | 1,816 |  |
| 2026 | 753 |  |
| 2027 | 704 |  |
| 2028 | 332 |  |
| 2029 and thereafter | 255 |  |
| Total | $ | 10,527 |  |

[0001045810-23-000093:notes:91]
Accrual for Product Warranty Liabilities

[0001045810-23-000093:notes:92]
The estimated amount of product warranty liabilities was $77 million and $82 million as of April 30, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

[0001045810-23-000093:notes:93]
|  | Three Months Ended |  |  |
|  | April 30, 2023 |  | May 1, 2022 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 82 |  |  | $ | 46 |  |  |  |  |  |
| Additions | 13 |  | 16 |  |  |  |  |
| Utilization | (18) |  |  | (7) |  |  |  |  |  |
| Balance at end of period | $ | 77 |  |  | $ | 55 |  |  |  |  |  |

[0001045810-23-000093:notes:94]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-23-000093:notes:95]
Litigation

[0001045810-23-000093:notes:96]
Securities Class Action and Derivative Lawsuits

[0001045810-23-000093:notes:97]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment

[0001045810-23-000093:notes:98]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

[0001045810-23-000093:notes:99]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-23-000093:notes:100]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-23-000093:notes:101]
Accounting for Loss Contingencies

[0001045810-23-000093:notes:102]
As of April 30, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-23-000093:notes:103]
[same as prior period, unchanged from 0001045810-22-000166:notes:98]

[0001045810-23-000093:notes:104]
Since the inception of our share repurchase program through April 30, 2023, we have repurchased an aggregate of 1.10 billion shares for a total cost of $17.12 billion. As of April 30, 2023, we were authorized, subject to certain specifications, to repurchase an additional $7.23 billion of shares through December 2023. We did not repurchase any shares during the first quarter of fiscal year 2024.

[0001045810-23-000093:notes:105]
During the first quarter of fiscal years 2024 and 2023, we paid $99 million and $100 million in cash dividends to our shareholders, respectively. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-23-000093:notes:106]
[same as prior period, unchanged from 0001045810-22-000166:notes:101]

[0001045810-23-000093:notes:107]
The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive artificial intelligence, or AI, Cockpit, autonomous driving development agreements, and

[0001045810-23-000093:notes:108]
autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and cryptocurrency mining processors, or CMP.

[0001045810-23-000093:notes:109]
The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; virtual GPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating metaverse and 3D internet applications.

[0001045810-23-000093:notes:110]
[same as prior period, unchanged from 0001045810-22-000166:notes:105]

[0001045810-23-000093:notes:111]
The “All Other” category includes the expenses that our CODM does not assign to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, acquisition-related and other costs, corporate infrastructure and support costs, acquisition termination cost, intellectual property related, or IP-related and legal settlement costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-23-000093:notes:112]
[same as prior period, unchanged from 0001045810-22-000166:notes:107]

[0001045810-23-000093:notes:113]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended April 30, 2023 |  |  |  |  |  |  |  |
| Revenue | $ | 4,460 |  |  | $ | 2,732 |  |  | $ | — |  |  | $ | 7,192 |  |
| Operating income (loss) | $ | 2,160 |  |  | $ | 1,046 |  |  | $ | (1,066) |  |  | $ | 2,140 |  |
| Three Months Ended May 1, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 3,672 |  |  | $ | 4,616 |  |  | $ | — |  |  | $ | 8,288 |  |
| Operating income (loss) | $ | 1,606 |  |  | $ | 2,476 |  |  | $ | (2,214) |  |  | $ | 1,868 |  |

[0001045810-23-000093:notes:114]
|  | Three Months Ended |  |  |
|  | April 30,2023 |  | May 1,2022 |  |  |  |  |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (735) |  |  | $ | (578) |  |  |  |  |  |
| Acquisition-related and other costs | (173) |  |  | (149) |  |  |  |  |  |
| Unallocated cost of revenue and operating expenses | (154) |  |  | (127) |  |  |  |  |  |
| IP-related and legal settlement costs | (8) |  |  | (7) |  |  |  |  |  |
| Acquisition termination cost | — |  |  | (1,353) |  |  |  |  |  |
| Other | 4 |  |  | — |  |  |  |  |  |
| Total | $ | (1,066) |  |  | $ | (2,214) |  |  |  |  |  |

[0001045810-23-000093:notes:115]
[same as prior period, unchanged from 0001045810-22-000166:notes:110]

[0001045810-23-000093:notes:116]
|  | Three Months Ended |  |  |
|  | April 30, |  | May 1, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| United States | $ | 2,385 |  |  | $ | 1,932 |  |  |  |  |  |
| Taiwan | 1,796 |  |  | 2,777 |  |  |  |  |  |
| China (including Hong Kong) | 1,590 |  |  | 2,081 |  |  |  |  |  |
| Singapore | 762 |  | 454 |  |  |  |  |
| Other countries | 659 |  |  | 1,044 |  |  |  |  |  |
| Total revenue | $ | 7,192 |  |  | $ | 8,288 |  |  |  |  |  |

[0001045810-23-000093:notes:117]
No customer represented 10% or more of total revenue for the first quarter of fiscal years 2024 and 2023.

[0001045810-23-000093:notes:118]
Two customers accounted for 12% and 10% of our accounts receivable balance as of April 30, 2023. Two customers accounted for 14% and 11% of our accounts receivable balance as of January 29, 2023.

[0001045810-23-000093:notes:119]
[same as prior period, unchanged from 0001045810-22-000166:notes:112]

[0001045810-23-000093:notes:120]
|  | Three Months Ended |  |  |
|  | April 30, |  | May 1, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Data Center | $ | 4,284 |  |  | $ | 3,750 |  |  |  |  |  |
| Gaming | 2,240 |  |  | 3,620 |  |  |  |  |  |
| Professional Visualization | 295 |  |  | 622 |  |  |  |  |  |
| Automotive | 296 |  |  | 138 |  |  |  |  |  |
| OEM and Other | 77 |  |  | 158 |  |  |  |  |  |
| Total revenue | $ | 7,192 |  |  | $ | 8,288 |  |  |  |  |  |
