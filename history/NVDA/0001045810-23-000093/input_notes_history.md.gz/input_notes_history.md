# NVDA note change history — 0001045810-22-000166 → 0001045810-23-000093


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-05-26):
[0001045810-23-000093:note_history:1]
Our purchase obligations reflect our commitments to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

- added (2023-05-26):
[0001045810-23-000093:note_history:2]
As of April 30, 2023, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $7.27 billion. During the normal course of business, to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers that allow them to procure inventory based upon criteria as defined by us, and in certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed, but these changes may result in the payment of costs incurred through the date of cancellation.

- added (2023-05-26):
[0001045810-23-000093:note_history:3]
Other non-inventory purchase obligations of $3.26 billion include $2.43 billion of multi-year cloud service agreements.

- changed (2023-05-26):
[0001045810-23-000093:note_history:4]
Total future purchase commitments as of April 30, 2023 are as follows:
  (was, 2022-11-18, similarity 0.8026):
[0001045810-22-000166:note_history:4]
Total gross future unconditional purchase commitments as of October 30, 2022 are as follows:

- changed (2023-05-26):
[0001045810-23-000093:note_history:5]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2024 (excluding first quarter) | $ | 6,667 |  |
| 2025 | 1,816 |  |
| 2026 | 753 |  |
| 2027 | 704 |  |
| 2028 | 332 |  |
| 2029 and thereafter | 255 |  |
| Total | $ | 10,527 |  |
  (was, 2022-11-18, similarity 0.914):
[0001045810-22-000166:note_history:5]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first nine months of fiscal year 2023) | $ | 4,234 |  |
| 2024 | 3,362 |  |
| 2025 | 798 |  |
| 2026 | 504 |  |
| 2027 | 464 |  |
| 2028 and thereafter | 410 |  |
| Total | $ | 9,772 |  |

- changed (2023-05-26):
[0001045810-23-000093:note_history:6]
The estimated amount of product warranty liabilities was $77 million and $82 million as of April 30, 2023 and January 29, 2023, respectively. The estimated product returns and estimated product warranty activity consisted of the following:
  (was, 2022-11-18, similarity 0.9736):
[0001045810-22-000166:note_history:6]
The estimated amount of product warranty liabilities was $104 million and $46 million as of October 30, 2022 and January 30, 2022, respectively. The estimated product returns and estimated product warranty activity consisted of the following:

- added (2023-05-26):
[0001045810-23-000093:note_history:7]
|  | Three Months Ended |  |  |
|  | April 30, 2023 |  | May 1, 2022 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 82 |  |  | $ | 46 |  |  |  |  |  |
| Additions | 13 |  | 16 |  |  |  |  |
| Utilization | (18) |  |  | (7) |  |  |  |  |  |
| Balance at end of period | $ | 77 |  |  | $ | 55 |  |  |  |  |  |

- added (2023-05-26):
[0001045810-23-000093:note_history:8]
Litigation

- changed (2023-05-26):
[0001045810-23-000093:note_history:9]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment
  (was, 2022-11-18, similarity 0.9509):
[0001045810-22-000166:note_history:9]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

- added (2023-05-26):
[0001045810-23-000093:note_history:10]
in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

- changed (2023-05-26):
[0001045810-23-000093:note_history:11]
As of April 30, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2022-11-18, similarity 0.9909):
[0001045810-22-000166:note_history:11]
As of October 30, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2023-05-26):
[0001045810-22-000166:note_history:12]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

- removed (2023-05-26):
[0001045810-22-000166:note_history:13]
We have entered into several long-term supply agreements, under which we have made advance payments and have $917 million remaining unpaid. As of October 30, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $7.02 billion, inclusive of the $917 million. Other non-inventory purchase obligations of $2.75 billion include $1.59 billion of multi-year cloud service agreements.

- removed (2023-05-26):
[0001045810-22-000166:note_history:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 168 |  |  | $ | 31 |  |  | $ | 46 |  |  | $ | 22 |  |
| Additions | 3 |  | 5 |  | 141 |  | 20 |
| Utilization | (67) |  |  | (4) |  |  | (83) |  |  | (10) |  |
| Balance at end of period | $ | 104 |  |  | $ | 32 |  |  | $ | 104 |  |  | $ | 32 |  |

- removed (2023-05-26):
[0001045810-22-000166:note_history:15]
In the third quarter of fiscal year 2023, we recognized a warranty-related benefit of approximately $70 million in cost of revenue due to favorable product recovery.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-26):
[0001045810-23-000093:note_history:16]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2024 and 2023 are both 52-week years. The first quarters of fiscal years 2024 and 2023 were both 13-week quarters.
  (was, 2022-11-18, similarity 0.9839):
[0001045810-22-000166:note_history:16]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The third quarters of fiscal years 2023 and 2022 were both 13-week quarters.

- added (2023-05-26):
[0001045810-23-000093:note_history:17]
Use of Estimates

- added (2023-05-26):
[0001045810-23-000093:note_history:18]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, property, plant, and equipment, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- added (2023-05-26):
[0001045810-23-000093:note_history:19]
In February 2023, we completed an assessment of the useful lives of our property, plant, and equipment. Based on advances in technology and usage rate, we increased the estimated useful life of a majority of our server, storage, and network equipment from three to a range of four to five years, and our assembly and test equipment from five to seven years. This change in accounting estimate became effective at the beginning of fiscal year 2024. Based on the carrying amounts of a majority of our server, storage, network, and assembly and test equipment, net, in use as of the end of fiscal year 2023, the effect of this change in estimate for the three months ended April 30, 2023, was a benefit of $2 million and $31 million for cost of revenue and operating expenses, respectively. This resulted in an increase in operating income of $33 million and net income of $28 million after tax, or $0.01 per both basic and diluted share.

- removed (2023-05-26):
[0001045810-22-000166:note_history:20]
Prior period intangible asset gross carrying amount and accumulated amortization in Note 9 have been adjusted to write off immaterial fully amortized intangible assets as of January 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-26):
[0001045810-23-000093:note_history:21]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:
  (was, 2022-11-18, similarity 0.843):
[0001045810-22-000166:note_history:21]
The carrying values of our outstanding notes and their associated interest rates were as follows:

- changed (2023-05-26):
[0001045810-23-000093:note_history:22]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (46) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 10,954 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 9,704 |  |  | $ | 9,703 |  |
  (was, 2022-11-18, similarity 0.9905):
[0001045810-22-000166:note_history:22]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.6 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (50) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | 10,950 |  |  | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,701 |  |  | $ | 10,946 |  |

- changed (2023-05-26):
[0001045810-23-000093:note_history:23]
As of April 30, 2023, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2022-11-18, similarity 0.6603):
[0001045810-22-000166:note_history:23]
As of October 30, 2022, we have complied with the required covenants under the notes.

- changed (2023-05-26):
[0001045810-23-000093:note_history:24]
We have a $575 million commercial paper program to support general corporate purposes. As of April 30, 2023, we had not issued any commercial paper.
  (was, 2022-11-18, similarity 0.9645):
[0001045810-22-000166:note_history:24]
We have a $575 million commercial paper program to support general corporate purposes. As of October 30, 2022, we had not issued any commercial paper.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-26):
[0001045810-23-000093:note_history:25]
The following is a summary of cash equivalents and marketable securities:
  (was, 2022-11-18, similarity 0.8111):
[0001045810-22-000166:note_history:25]
The following is a summary of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022:

- changed (2023-05-26):
[0001045810-23-000093:note_history:26]
|  | April 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,723 |  |  | $ | 4 |  |  | $ | (11) |  |  | $ | 6,716 |  |  | $ | 2,535 |  |  | $ | 4,181 |  |
| Debt securities issued by the U.S. Treasury | 3,996 |  |  | 2 |  |  | (31) |  |  | 3,967 |  |  | 421 |  |  | 3,546 |  |
| Debt securities issued by U.S. government agencies | 2,442 |  |  | 1 |  |  | (1) |  |  | 2,442 |  |  | 199 |  |  | 2,243 |  |
| Money market funds | 1,502 |  |  | — |  |  | — |  |  | 1,502 |  |  | 1,502 |  |  | — |  |
| Certificates of deposit | 395 |  |  | — |  |  | — |  |  | 395 |  |  | 173 |  |  | 222 |  |
| Foreign government bonds | 49 |  |  | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Total | $ | 15,107 |  |  | $ | 7 |  |  | $ | (43) |  |  | $ | 15,071 |  |  | $ | 4,830 |  |  | $ | 10,241 |  |
  (was, 2022-11-18, similarity 0.6162):
[0001045810-22-000166:note_history:26]
|  | October 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,221 |  |  | $ | — |  |  | $ | (19) |  |  | $ | 4,202 |  |  | $ | 239 |  |  | $ | 3,963 |  |
| Debt securities issued by the U.S. Treasury | 4,176 |  |  | 1 |  |  | (60) |  |  | 4,117 |  |  | 1 |  |  | 4,116 |  |
| Debt securities issued by U.S. government agencies | 2,259 |  |  | — |  |  | (4) |  |  | 2,255 |  |  | 344 |  |  | 1,911 |  |
| Certificates of deposit | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 58 |  |  | 258 |  |
| Money market funds | 1,843 |  |  | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |  | — |  |
| Foreign government bonds | 99 |  |  | — |  |  | — |  |  | 99 |  |  | 4 |  |  | 95 |  |
| Total | $ | 12,914 |  |  | $ | 1 |  |  | $ | (83) |  |  | $ | 12,832 |  |  | $ | 2,489 |  |  | $ | 10,343 |  |

- added (2023-05-26):
[0001045810-23-000093:note_history:27]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

- changed (2023-05-26):
[0001045810-23-000093:note_history:28]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.
  (was, 2022-11-18, similarity 0.8844):
[0001045810-22-000166:note_history:28]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022 are shown below by contractual maturity.

- changed (2023-05-26):
[0001045810-23-000093:note_history:29]
|  | April 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,654 |  |  | $ | 12,625 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 2,453 |  |  | 2,446 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,107 |  |  | $ | 15,071 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |
  (was, 2022-11-18, similarity 0.9812):
[0001045810-22-000166:note_history:29]
|  | October 30, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 8,985 |  |  | $ | 8,952 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 3,929 |  |  | 3,880 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 12,914 |  |  | $ | 12,832 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2023-05-26):
[0001045810-22-000166:note_history:30]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the U.S. Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by U.S. government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-26):
[0001045810-23-000093:note_history:31]
The following is a summary of cash equivalents and marketable securities:
  (was, 2022-11-18, similarity 0.8111):
[0001045810-22-000166:note_history:31]
The following is a summary of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022:

- changed (2023-05-26):
[0001045810-23-000093:note_history:32]
|  | April 30, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 6,723 |  |  | $ | 4 |  |  | $ | (11) |  |  | $ | 6,716 |  |  | $ | 2,535 |  |  | $ | 4,181 |  |
| Debt securities issued by the U.S. Treasury | 3,996 |  |  | 2 |  |  | (31) |  |  | 3,967 |  |  | 421 |  |  | 3,546 |  |
| Debt securities issued by U.S. government agencies | 2,442 |  |  | 1 |  |  | (1) |  |  | 2,442 |  |  | 199 |  |  | 2,243 |  |
| Money market funds | 1,502 |  |  | — |  |  | — |  |  | 1,502 |  |  | 1,502 |  |  | — |  |
| Certificates of deposit | 395 |  |  | — |  |  | — |  |  | 395 |  |  | 173 |  |  | 222 |  |
| Foreign government bonds | 49 |  |  | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Total | $ | 15,107 |  |  | $ | 7 |  |  | $ | (43) |  |  | $ | 15,071 |  |  | $ | 4,830 |  |  | $ | 10,241 |  |
  (was, 2022-11-18, similarity 0.6162):
[0001045810-22-000166:note_history:32]
|  | October 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,221 |  |  | $ | — |  |  | $ | (19) |  |  | $ | 4,202 |  |  | $ | 239 |  |  | $ | 3,963 |  |
| Debt securities issued by the U.S. Treasury | 4,176 |  |  | 1 |  |  | (60) |  |  | 4,117 |  |  | 1 |  |  | 4,116 |  |
| Debt securities issued by U.S. government agencies | 2,259 |  |  | — |  |  | (4) |  |  | 2,255 |  |  | 344 |  |  | 1,911 |  |
| Certificates of deposit | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 58 |  |  | 258 |  |
| Money market funds | 1,843 |  |  | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |  | — |  |
| Foreign government bonds | 99 |  |  | — |  |  | — |  |  | 99 |  |  | 4 |  |  | 95 |  |
| Total | $ | 12,914 |  |  | $ | 1 |  |  | $ | (83) |  |  | $ | 12,832 |  |  | $ | 2,489 |  |  | $ | 10,343 |  |

- added (2023-05-26):
[0001045810-23-000093:note_history:33]
|  | January 29, 2023 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,809 |  |  | $ | — |  |  | $ | (12) |  |  | $ | 4,797 |  |  | $ | 1,087 |  |  | $ | 3,710 |  |
| Debt securities issued by the U.S. Treasury | 4,185 |  |  | 1 |  |  | (44) |  |  | 4,142 |  |  | — |  |  | 4,142 |  |
| Debt securities issued by U.S. government agencies | 1,836 |  |  | — |  |  | (2) |  |  | 1,834 |  |  | 50 |  |  | 1,784 |  |
| Money market funds | 1,777 |  |  | — |  |  | — |  |  | 1,777 |  |  | 1,777 |  |  | — |  |
| Certificates of deposit | 365 |  |  | — |  |  | — |  |  | 365 |  |  | 134 |  |  | 231 |  |
| Foreign government bonds | 140 |  |  | — |  |  | — |  |  | 140 |  |  | 100 |  |  | 40 |  |
| Total | $ | 13,112 |  |  | $ | 1 |  |  | $ | (58) |  |  | $ | 13,055 |  |  | $ | 3,148 |  |  | $ | 9,907 |  |

- changed (2023-05-26):
[0001045810-23-000093:note_history:34]
|  | April 30, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 1,601 |  |  | $ | (11) |  |  | $ | 1,106 |  |  | $ | (20) |  |  | $ | 2,707 |  |  | $ | (31) |  |
| Debt securities issued by U.S. government agencies | 1,259 |  |  | (1) |  |  | — |  |  | — |  |  | 1,259 |  |  | (1) |  |
| Corporate debt securities | 945 |  |  | (4) |  |  | 838 |  |  | (7) |  |  | 1,783 |  |  | (11) |  |
| Total | $ | 3,805 |  |  | $ | (16) |  |  | $ | 1,944 |  |  | $ | (27) |  |  | $ | 5,749 |  |  | $ | (43) |  |
  (was, 2022-11-18, similarity 0.9892):
[0001045810-22-000166:note_history:34]
|  | October 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the U.S. Treasury | $ | 1,928 |  |  | $ | (35) |  |  | $ | 1,051 |  |  | $ | (24) |  |  | $ | 2,979 |  |  | $ | (59) |  |
| Debt securities issued by U.S. government agencies | 1,888 |  |  | (4) |  |  | — |  |  | — |  |  | 1,888 |  |  | (4) |  |
| Corporate debt securities | 1,786 |  |  | (18) |  |  | 208 |  |  | (2) |  |  | 1,994 |  |  | (20) |  |
| Total | $ | 5,602 |  |  | $ | (57) |  |  | $ | 1,259 |  |  | $ | (26) |  |  | $ | 6,861 |  |  | $ | (83) |  |

- changed (2023-05-26):
[0001045810-23-000093:note_history:35]
|  | January 29, 2023 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 2,444 |  |  | $ | (21) |  |  | $ | 1,172 |  |  | $ | (23) |  |  | $ | 3,616 |  |  | $ | (44) |  |
| Corporate debt securities | 1,188 |  |  | (7) |  |  | 696 |  |  | (5) |  |  | 1,884 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,307 |  |  | (2) |  |  | — |  |  | — |  |  | 1,307 |  |  | (2) |  |
| Total | $ | 4,939 |  |  | $ | (30) |  |  | $ | 1,868 |  |  | $ | (28) |  |  | $ | 6,807 |  |  | $ | (58) |  |
  (was, 2022-11-18, similarity 0.7296):
[0001045810-22-000166:note_history:35]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the U.S. Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

- changed (2023-05-26):
[0001045810-23-000093:note_history:36]
The amortized cost and estimated fair value of cash equivalents and marketable securities are shown below by contractual maturity.
  (was, 2022-11-18, similarity 0.8844):
[0001045810-22-000166:note_history:36]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 30, 2022 and January 30, 2022 are shown below by contractual maturity.

- changed (2023-05-26):
[0001045810-23-000093:note_history:37]
|  | April 30, 2023 |  | January 29, 2023 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 12,654 |  |  | $ | 12,625 |  |  | $ | 9,738 |  |  | $ | 9,708 |  |
| Due in 1 - 5 years | 2,453 |  |  | 2,446 |  |  | 3,374 |  |  | 3,347 |  |
| Total | $ | 15,107 |  |  | $ | 15,071 |  |  | $ | 13,112 |  |  | $ | 13,055 |  |
  (was, 2022-11-18, similarity 0.9812):
[0001045810-22-000166:note_history:37]
|  | October 30, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 8,985 |  |  | $ | 8,952 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 3,929 |  |  | 3,880 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 12,914 |  |  | $ | 12,832 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2023-05-26):
[0001045810-22-000166:note_history:38]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the U.S. Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by U.S. government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-26):
[0001045810-23-000093:note_history:39]
The carrying value of our outstanding notes, the calendar year of maturity, and the associated interest rates were as follows:
  (was, 2022-11-18, similarity 0.843):
[0001045810-22-000166:note_history:39]
The carrying values of our outstanding notes and their associated interest rates were as follows:

- changed (2023-05-26):
[0001045810-23-000093:note_history:40]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 30, 2023 |  | January 29, 2023 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 6.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 16.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 26.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 36.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (46) |  |  | (47) |  |
| Net carrying amount |  |  |  |  |  | 10,954 |  |  | 10,953 |  |
| Less short-term portion |  |  |  |  |  | (1,250) |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 9,704 |  |  | $ | 9,703 |  |
  (was, 2022-11-18, similarity 0.9905):
[0001045810-22-000166:note_history:40]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 0.6 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 1.6 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 3.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 5.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 8.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (50) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | 10,950 |  |  | 10,946 |  |
| Less short-term portion |  |  |  |  |  | (1,249) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 9,701 |  |  | $ | 10,946 |  |
