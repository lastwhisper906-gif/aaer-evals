# NVDA 8-K — 0001045810-23-000087 filed 2023-05-24

## item codes, every 8-K on or before 2023-05-26

- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2023-05-26

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-23-000087:8k_2_02:1]
EX-99.1
2
q1fy24pr.htm
Q1FY24 PRESS RELEASE

[0001045810-23-000087:8k_2_02:2]
Document

[0001045810-23-000087:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-23-000087:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2024

[0001045810-23-000087:8k_2_02:5]
•Quarterly revenue of $7.19 billion, up 19% from previous quarter

[0001045810-23-000087:8k_2_02:6]
•Record Data Center revenue of $4.28 billion

[0001045810-23-000087:8k_2_02:7]
•Second quarter fiscal 2024 revenue outlook of $11.00 billion

[0001045810-23-000087:8k_2_02:8]
SANTA CLARA, Calif.-May 24, 2023- NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 30, 2023, of $7.19 billion, down 13% from a year ago and up 19% from the previous quarter.

[0001045810-23-000087:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $0.82, up 28% from a year ago and up 44% from the previous quarter. Non-GAAP earnings per diluted share were $1.09, down 20% from a year ago and up 24% from the previous quarter.

[0001045810-23-000087:8k_2_02:10]
“The computer industry is going through two simultaneous transitions — accelerated computing and generative AI,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-23-000087:8k_2_02:11]
“A trillion dollars of installed global data center infrastructure will transition from general purpose to accelerated computing as companies race to apply generative AI into every product, service and business process.

[0001045810-23-000087:8k_2_02:12]
“Our entire data center family of products — H100, Grace CPU, Grace Hopper Superchip, NVLink, Quantum 400 InfiniBand and BlueField-3 DPU — is in production. We are significantly increasing our supply to meet surging demand for them,” he said.

[0001045810-23-000087:8k_2_02:13]
During the first quarter of fiscal 2024, NVIDIA returned to shareholders $99 million in cash dividends.

[0001045810-23-000087:8k_2_02:14]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on June 30, 2023, to all shareholders of record on June 8, 2023.

[0001045810-23-000087:8k_2_02:15]
Q1 Fiscal 2024 Summary

[0001045810-23-000087:8k_2_02:16]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY24 | Q4 FY23 | Q1 FY23 | Q/Q | Y/Y |
| Revenue | $7,192 | $6,051 | $8,288 | Up 19% | Down 13% |
| Gross margin | 64.6 | % | 63.3 | % | 65.5 | % | Up 1.3 pts | Down 0.9 pts |
| Operating expenses | $2,508 | $2,576 | $3,563 | Down 3% | Down 30% |
| Operating income | $2,140 | $1,257 | $1,868 | Up 70% | Up 15% |
| Net income | $2,043 | $1,414 | $1,618 | Up 44% | Up 26% |
| Diluted earnings per share | $0.82 | $0.57 | $0.64 | Up 44% | Up 28% |

[0001045810-23-000087:8k_2_02:17]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY24 | Q4 FY23 | Q1 FY23 | Q/Q | Y/Y |
| Revenue | $7,192 | $6,051 | $8,288 | Up 19% | Down 13% |
| Gross margin | 66.8 | % | 66.1 | % | 67.1 | % | Up 0.7 pts | Down 0.3 pts |
| Operating expenses | $1,750 | $1,775 | $1,608 | Down 1% | Up 9% |
| Operating income | $3,052 | $2,224 | $3,955 | Up 37% | Down 23% |
| Net income | $2,713 | $2,174 | $3,443 | Up 25% | Down 21% |
| Diluted earnings per share | $1.09 | $0.88 | $1.36 | Up 24% | Down 20% |

[0001045810-23-000087:8k_2_02:18]
Outlook

[0001045810-23-000087:8k_2_02:19]
NVIDIA’s outlook for the second quarter of fiscal 2024 is as follows:

[0001045810-23-000087:8k_2_02:20]
•Revenue is expected to be $11.00 billion, plus or minus 2%.

[0001045810-23-000087:8k_2_02:21]
•GAAP and non-GAAP gross margins are expected to be 68.6% and 70.0%, respectively, plus or minus 50 basis points.

[0001045810-23-000087:8k_2_02:22]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.71 billion and $1.90 billion, respectively.

[0001045810-23-000087:8k_2_02:23]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $90 million, excluding gains and losses from non-affiliated investments.

[0001045810-23-000087:8k_2_02:24]
•GAAP and non-GAAP tax rates are expected to be 14.0%, plus or minus 1%, excluding any discrete items.

[0001045810-23-000087:8k_2_02:25]
Highlights

[0001045810-23-000087:8k_2_02:26]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-23-000087:8k_2_02:27]
Data Center

[0001045810-23-000087:8k_2_02:28]
•First-quarter revenue was a record $4.28 billion, up 14% from a year ago and up 18% from the previous quarter.

[0001045810-23-000087:8k_2_02:29]
•Launched four inference platforms that combine the company’s full-stack inference software with the latest NVIDIA Ada, NVIDIA Hopper™ and NVIDIA Grace Hopper™ processors.

[0001045810-23-000087:8k_2_02:30]
•Announced that Google Cloud is the first cloud provider offering the new NVIDIA L4 Tensor Core GPU to accelerate generative AI applications.

[0001045810-23-000087:8k_2_02:31]
•Introduced NVIDIA AI Foundations to help businesses create and operate custom large language models and generative AI models trained with their own proprietary data for domain-specific tasks.

[0001045810-23-000087:8k_2_02:32]
•Unveiled the NVIDIA cuLitho software library for computational lithography to accelerate the design and manufacturing of next-gen semiconductors.

[0001045810-23-000087:8k_2_02:33]
•Expanded its partners offering new products and services based on the NVIDIA H100 Tensor Core GPU — including Amazon Web Services, Google Cloud, Microsoft Azure and Oracle Cloud Infrastructure.

[0001045810-23-000087:8k_2_02:34]
•Partnered with ServiceNow to build generative AI across enterprise IT.

[0001045810-23-000087:8k_2_02:35]
•Announced a collaboration with Medtronic to build an AI platform for medical devices.

[0001045810-23-000087:8k_2_02:36]
•Joined with Dell Technologies in Project Helix to deliver full-stack solutions to help enterprises build and deploy trustworthy generative AI applications.

[0001045810-23-000087:8k_2_02:37]
•Announced it is integrating NVIDIA AI Enterprise software into Microsoft’s Azure Machine Learning to help enterprises accelerate their AI initiatives.

[0001045810-23-000087:8k_2_02:38]
Gaming

[0001045810-23-000087:8k_2_02:39]
•First-quarter revenue was $2.24 billion, down 38% from a year ago and up 22% from the previous quarter.

[0001045810-23-000087:8k_2_02:40]
•Announced the GeForce RTX™ 4060 family of GPUs, bringing the advancements of NVIDIA Ada Lovelace architecture and DLSS, starting at $299.

[0001045810-23-000087:8k_2_02:41]
•Launched the GeForce RTX 4070 GPU based on the Ada architecture, which enables DLSS 3, real-time ray-tracing and the ability to run most modern games at over 100 frames per second at 1440p resolution.

[0001045810-23-000087:8k_2_02:42]
•Added 36 DLSS gaming titles, bringing the total number of games and apps to 300.

[0001045810-23-000087:8k_2_02:43]
•Made path tracing available for the first time on a major gaming title through collaboration with CD PROJEKT RED on an update to Cyberpunk 2077.

[0001045810-23-000087:8k_2_02:44]
•Expanded GeForce NOW’s game titles to more than 1,600, including the first Microsoft Xbox game, Gears 5.

[0001045810-23-000087:8k_2_02:45]
Professional Visualization

[0001045810-23-000087:8k_2_02:46]
•First-quarter revenue was $295 million, down 53% from a year ago and up 31% from the previous quarter.

[0001045810-23-000087:8k_2_02:47]
•Announced NVIDIA Omniverse™ Cloud, a fully managed service running in Microsoft Azure, for the development and deployment of industrial metaverse applications.

[0001045810-23-000087:8k_2_02:48]
•Expanded its collaboration with Microsoft to connect Microsoft 365 applications with Omniverse.

[0001045810-23-000087:8k_2_02:49]
•Announced six new NVIDIA RTX™ GPUs for mobile and desktop workstations based on the Ada architecture.

[0001045810-23-000087:8k_2_02:50]
Automotive

[0001045810-23-000087:8k_2_02:51]
•First-quarter revenue was a record $296 million, up 114% from a year ago and up 1% from the previous quarter.

[0001045810-23-000087:8k_2_02:52]
•Announced that its automotive design win pipeline has grown to $14 billion over the next six years, up from $11 billion a year ago.

[0001045810-23-000087:8k_2_02:53]
•Announced that the world’s leading electric vehicle maker BYD will extend its use of NVIDIA DRIVE Orin™ across new models.

[0001045810-23-000087:8k_2_02:54]
CFO Commentary

[0001045810-23-000087:8k_2_02:55]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-23-000087:8k_2_02:56]
Conference Call and Webcast Information

[0001045810-23-000087:8k_2_02:57]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2024 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2024.

[0001045810-23-000087:8k_2_02:58]
Non-GAAP Measures

[0001045810-23-000087:8k_2_02:59]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, IP-related costs, legal settlement costs,

[0001045810-23-000087:8k_2_02:60]
other, losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-23-000087:8k_2_02:61]
About NVIDIA

[0001045810-23-000087:8k_2_02:62]
Since its founding in 1993, NVIDIA (NASDAQ: NVDA) has been a pioneer in accelerated computing. The company’s invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined computer graphics, ignited the era of modern AI and is fueling the creation of the industrial metaverse. NVIDIA is now a full-stack computing company with data-center-scale offerings that are reshaping industry. More information at https://nvidianews.nvidia.com/.

[0001045810-23-000087:8k_2_02:63]
###

[0001045810-23-000087:8k_2_02:64]
For further information, contact:

[0001045810-23-000087:8k_2_02:65]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-23-000087:8k_2_02:66]
Certain statements in this press release including, but not limited to, statements as to: the computer industry going through two simultaneous transitions – accelerated computing and generative AI; installed global data center infrastructure transitioning from general purpose to accelerated computing as companies race to apply generative AI into every product, service and business process; NVIDIA’s entire data center family of products being in production; NVIDIA significantly increasing supply to meet surging demand; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook and expected tax rates for the second quarter of fiscal 2024; the benefits, impact, performance, features and availability of our products and technologies, including NVIDIA Ada, NVIDIA Hopper, NVIDIA Grace Hopper CPU, NVIDIA L4 Tensor Core GPU, NVIDIA AI Foundations, NVIDIA cuLitho software library, NVIDIA H100 Tensor Core GPU, NVIDIA AI Enterprise, GeForce RTX GPUs, DLSS 3, GeForce NOW, NVIDIA Omniverse Cloud, Omniverse, NVIDIA RTX GPUs, and NVIDIA DRIVE Orin; and the benefits and impact of our collaborations, including with Google Cloud, Amazon Web Services, Microsoft Azure, Oracle Cloud Infrastructure, ServiceNow, Medtronic, Dell Technologies, CD PROJEKT RED, Microsoft, and BYD are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-23-000087:8k_2_02:67]
© 2023 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, NVIDIA DRIVE Orin, NVIDIA Grace Hopper, NVIDIA Hopper, NVIDIA Omniverse, and NVIDIA RTX are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-23-000087:8k_2_02:68]
NVIDIA CORPORATION

[0001045810-23-000087:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-23-000087:8k_2_02:70]
(In millions, except per share data)

[0001045810-23-000087:8k_2_02:71]
(Unaudited)

[0001045810-23-000087:8k_2_02:72]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 30, |  | May 1, |  |  |  |  |
|  |  |  | 2023 |  | 2022 |  |  |  |  |
| Revenue | $ | 7,192 |  |  | $ | 8,288 |  |  |  |  |  |
| Cost of revenue | 2,544 |  |  | 2,857 |  |  |  |  |  |
| Gross profit | 4,648 |  |  | 5,431 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,875 |  |  | 1,618 |  |  |  |  |  |
|  | Sales, general and administrative | 633 |  |  | 592 |  |  |  |  |  |
|  | Acquisition termination cost | — |  |  | 1,353 |  |  |  |  |  |
|  |  | Total operating expenses | 2,508 |  |  | 3,563 |  |  |  |  |  |
| Income from operations | 2,140 |  |  | 1,868 |  |  |  |  |  |
|  | Interest income | 150 |  |  | 18 |  |  |  |  |  |
|  | Interest expense | (66) |  |  | (68) |  |  |  |  |  |
|  | Other, net | (15) |  |  | (13) |  |  |  |  |  |
|  |  | Other income (expense), net | 69 |  |  | (63) |  |  |  |  |  |
| Income before income tax | 2,209 |  |  | 1,805 |  |  |  |  |  |
| Income tax expense | 166 |  |  | 187 |  |  |  |  |  |
| Net income | $ | 2,043 |  |  | $ | 1,618 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.83 |  |  | $ | 0.65 |  |  |  |  |  |
|  | Diluted | $ | 0.82 |  |  | $ | 0.64 |  |  |  |  |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 2,470 |  |  | 2,506 |  |  |  |  |  |
|  | Diluted | 2,490 |  |  | 2,537 |  |  |  |  |  |

[0001045810-23-000087:8k_2_02:73]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | April 30, |  | January 29, |
|  |  |  |  | 2023 |  | 2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 15,320 |  |  | $ | 13,296 |  |
|  | Accounts receivable, net |  | 4,080 |  |  | 3,827 |  |
|  | Inventories |  | 4,611 |  |  | 5,159 |  |
|  | Prepaid expenses and other current assets |  | 872 |  |  | 791 |  |
|  |  | Total current assets |  | 24,883 |  |  | 23,073 |  |
| Property and equipment, net |  | 3,740 |  |  | 3,807 |  |
| Operating lease assets |  | 1,094 |  |  | 1,038 |  |
| Goodwill |  | 4,430 |  |  | 4,372 |  |
| Intangible assets, net |  | 1,541 |  |  | 1,676 |  |
| Deferred income tax assets |  | 4,568 |  |  | 3,396 |  |
| Other assets |  | 4,204 |  |  | 3,820 |  |
|  |  | Total assets |  | $ | 44,460 |  |  | $ | 41,182 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,141 |  |  | $ | 1,193 |  |
|  | Accrued and other current liabilities |  | 4,869 |  |  | 4,120 |  |
|  | Short-term debt |  | 1,250 |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 7,260 |  |  | 6,563 |  |
| Long-term debt |  | 9,704 |  |  | 9,703 |  |
| Long-term operating lease liabilities |  | 939 |  |  | 902 |  |
| Other long-term liabilities |  | 2,037 |  |  | 1,913 |  |
|  |  | Total liabilities |  | 19,940 |  |  | 19,081 |  |
| Shareholders' equity |  | 24,520 |  |  | 22,101 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 44,460 |  |  | $ | 41,182 |  |

[0001045810-23-000087:8k_2_02:74]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | April 30, |  | May 1, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 2,043 |  |  | $ | 1,618 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock based compensation expense | 735 |  |  | 578 |  |  |  |  |  |
| Depreciation and amortization | 384 |  |  | 334 |  |  |  |  |  |
| Losses on investments in non affiliates, net | 14 |  |  | 17 |  |  |  |  |  |
| Deferred income taxes | (1,135) |  |  | (542) |  |  |  |  |  |
| Acquisition termination cost | — |  |  | 1,353 |  |  |  |  |  |
| Other | (34) |  |  | 23 |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (252) |  |  | (788) |  |  |  |  |  |
| Inventories | 566 |  |  | (560) |  |  |  |  |  |
| Prepaid expenses and other assets | (215) |  |  | (1,261) |  |  |  |  |  |
| Accounts payable | 11 |  |  | 255 |  |  |  |  |  |
| Accrued liabilities and other current liabilities | 689 |  |  | 634 |  |  |  |  |  |
| Other long-term liabilities | 105 |  |  | 70 |  |  |  |  |  |
| Net cash provided by operating activities | 2,911 |  |  | 1,731 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 2,512 |  |  | 5,947 |  |  |  |  |  |
| Proceeds from sales of marketable securities | — |  |  | 1,029 |  |  |  |  |  |
| Purchases of marketable securities | (2,801) |  |  | (3,932) |  |  |  |  |  |
| Purchase related to property and equipment and intangible assets | (248) |  |  | (361) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (83) |  |  | (36) |  |  |  |  |  |
| Investments and other, net | (221) |  |  | (35) |  |  |  |  |  |
| Net cash provided by (used in) investing activities | (841) |  |  | 2,612 |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 246 |  |  | 204 |  |  |  |  |  |
| Payments related to tax on restricted stock units | (507) |  |  | (532) |  |  |  |  |  |
| Dividends paid | (99) |  |  | (100) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (20) |  |  | (22) |  |  |  |  |  |
| Payments related to repurchases of common stock | — |  |  | (1,996) |  |  |  |  |  |
| Net cash provided by (used in) financing activities | (380) |  |  | (2,446) |  |  |  |  |  |
| Change in cash and cash equivalents | 1,690 |  |  | 1,897 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 3,389 |  |  | 1,990 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 5,079 |  |  | $ | 3,887 |  |  |  |  |  |

[0001045810-23-000087:8k_2_02:75]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 30, |  | January 29, |  | May 1, |  |  |  |  |
|  |  |  | 2023 |  | 2023 |  | 2022 |  |  |  |  |
| GAAP gross profit |  | $ | 4,648 |  |  | $ | 3,833 |  |  | $ | 5,431 |  |  |  |  |  |
| GAAP gross margin |  | 64.6 | % |  | 63.3 | % |  | 65.5 | % |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | 119 |  |  | 120 |  |  | 94 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | 27 |  |  | 30 |  |  | 38 |  |  |  |  |  |
|  | IP-related costs |  | 8 |  |  | 16 |  |  | — |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 4,802 |  |  | $ | 3,999 |  |  | $ | 5,563 |  |  |  |  |  |
| Non-GAAP gross margin |  | 66.8 | % |  | 66.1 | % |  | 67.1 | % |  |  |  |  |
| GAAP operating expenses |  | $ | 2,508 |  |  | $ | 2,576 |  |  | $ | 3,563 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | (708) |  |  | (709) |  |  | (540) |  |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | (54) |  |  | (54) |  |  | (55) |  |  |  |  |  |
|  | Acquisition termination cost |  | — |  |  | — |  |  | (1,353) |  |  |  |  |  |
|  | Legal settlement costs |  | — |  |  | — |  |  | (7) |  |  |  |  |  |
|  | Other (C) |  | 4 |  |  | (38) |  |  | — |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 1,750 |  |  | $ | 1,775 |  |  | $ | 1,608 |  |  |  |  |  |
| GAAP income from operations |  | $ | 2,140 |  |  | $ | 1,257 |  |  | $ | 1,868 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 912 |  |  | 967 |  |  | 2,087 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 3,052 |  |  | $ | 2,224 |  |  | $ | 3,955 |  |  |  |  |  |
| GAAP other income (expense), net |  | $ | 69 |  |  | $ | 32 |  |  | $ | (63) |  |  |  |  |  |
|  | Losses from non-affiliated investments |  | 14 |  |  | 10 |  |  | 17 |  |  |  |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  |  |  |  |
| Non-GAAP other income (expense), net |  | $ | 84 |  |  | $ | 43 |  |  | $ | (45) |  |  |  |  |  |
| GAAP net income |  | $ | 2,043 |  |  | $ | 1,414 |  |  | $ | 1,618 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 927 |  |  | 978 |  |  | 2,105 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (257) |  |  | (218) |  |  | (280) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 2,713 |  |  | $ | 2,174 |  |  | $ | 3,443 |  |  |  |  |  |

[0001045810-23-000087:8k_2_02:76]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 30, |  | January 29, |  | May 1, |  |  |  |  |
|  |  |  | 2023 |  | 2023 |  | 2022 |  |  |  |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.82 |  |  | $ | 0.57 |  |  | $ | 0.64 |  |  |  |  |  |
|  | Non-GAAP |  | $ | 1.09 |  |  | $ | 0.88 |  |  | $ | 1.36 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation |  | 2,490 |  |  | 2,477 |  |  | 2,537 |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 2,911 |  |  | $ | 2,249 |  |  | $ | 1,731 |  |  |  |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (248) |  |  | (509) |  |  | (361) |  |  |  |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (20) |  |  | (4) |  |  | (22) |  |  |  |  |  |
| Free cash flow |  | $ | 2,643 |  |  | $ | 1,736 |  |  | $ | 1,348 |  |  |  |  |  |

[0001045810-23-000087:8k_2_02:77]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |  |  |  |  |  |
|  |  |  | Three Months Ended |  |  |  |
|  |  |  | April 30, |  | January 29, |  | May 1, |  |  |  |  |  |
|  |  |  | 2023 |  | 2023 |  | 2022 |  |  |  |  |  |
|  | Cost of revenue |  | $ | 119 |  |  | $ | 120 |  |  | $ | 94 |  |  |  |  |  |  |
|  | Research and development |  | $ | 12 |  |  | $ | 10 |  |  | $ | 9 |  |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 42 |  |  | $ | 44 |  |  | $ | 46 |  |  |  |  |  |  |
| (B) Stock-based compensation consists of the following: |  |  |  |  |  |
|  |  |  | Three Months Ended |  |  |  |
|  |  |  | April 30, |  | January 29, |  | May 1, |  |  |  |  |  |
|  |  |  | 2023 |  | 2023 |  | 2022 |  |  |  |  |  |
|  | Cost of revenue |  | $ | 27 |  |  | $ | 30 |  |  | $ | 38 |  |  |  |  |  |  |
|  | Research and development |  | $ | 524 |  |  | $ | 527 |  |  | $ | 384 |  |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 184 |  |  | $ | 182 |  |  | $ | 156 |  |  |  |  |  |  |
| (C) Other consists of assets held for sale related adjustments. |  |  |  |  |  |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |  |  |  |  |

[0001045810-23-000087:8k_2_02:78]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2024 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 68.6 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 1.4 | % |
| Non-GAAP gross margin |  | 70.0 | % |
| GAAP operating expenses |  | $ | 2,710 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (810) |  |
| Non-GAAP operating expenses |  | $ | 1,900 |  |
