# NVDA MD&A — 0001045810-23-000093


## mdna

[0001045810-23-000093:mdna:1]
[same as prior period, unchanged from 0001045810-22-000166:mdna:1]

[0001045810-23-000093:mdna:2]
[same as prior period, unchanged from 0001045810-22-000166:mdna:2]

[0001045810-23-000093:mdna:3]
[same as prior period, unchanged from 0001045810-22-000166:mdna:3]

[0001045810-23-000093:mdna:4]
© 2023 NVIDIA Corporation. All rights reserved. The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 29, 2023 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase or sell shares of our common stock.

[0001045810-23-000093:mdna:5]
[same as prior period, unchanged from 0001045810-22-000166:mdna:6]

[0001045810-23-000093:mdna:6]
[same as prior period, unchanged from 0001045810-22-000166:mdna:7]

[0001045810-23-000093:mdna:7]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, metaverse and 3D internet applications.

[0001045810-23-000093:mdna:8]
[same as prior period, unchanged from 0001045810-22-000166:mdna:9]

[0001045810-23-000093:mdna:9]
[same as prior period, unchanged from 0001045810-22-000166:mdna:10]

[0001045810-23-000093:mdna:10]
[same as prior period, unchanged from 0001045810-22-000166:mdna:11]

[0001045810-23-000093:mdna:11]
Supply, Products Transitions, and New Products and Business Models

[0001045810-23-000093:mdna:12]
Our supply, which includes inventory on hand, purchase obligations and prepaid supply and capacity agreements, has grown significantly due to recent supply chain conditions and long lead times, complexity of our products, and changes in demand. We have entered and expect to continue to enter into supplier and capacity prepayment arrangements. We have procured substantially higher Data Center supply for the second half compared to the first half of fiscal year 2024. We may incur inventory provisions or impairments if our inventory or supply or capacity commitments are misaligned with demand for our products.

[0001045810-23-000093:mdna:13]
Product transitions are complex as we often ship both new and prior architecture products simultaneously and we and our channel partners prepare to ship and support new products. We are currently transitioning the architecture of our Data Center, Professional Visualization, and Gaming products. Qualification time for

[0001045810-23-000093:mdna:14]
new products, customers anticipating product transitions and channel partners reducing channel inventory of prior architectures ahead of new product introductions can create reductions or volatility in our revenue. In addition, the bring up of new product architectures is complex due to functionality challenges and quality concerns not identified in manufacturing testing. These product quality issues may incur costs, increase our warranty costs, and delay further production of our architecture. While we have managed prior product transitions and have previously sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and we may incur additional costs.

[0001045810-23-000093:mdna:15]
We build technology and products for use cases and applications that may be new or may not yet exist such as our Omniverse platform, third-party large language models and generative AI models. Our demand estimates for these use cases and applications can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate significant revenue from these use cases and applications. New technologies such as generative AI models have emerged, and while they have driven increased demand for compute infrastructure, the long-term trajectory is unknown.

[0001045810-23-000093:mdna:16]
NVIDIA AI Cloud Service Offerings

[0001045810-23-000093:mdna:17]
We offer enterprise customers NVIDIA AI cloud services directly and through our network of partners. Examples of these services include NVIDIA DGX Cloud, which includes cloud-based infrastructure and software for training and deploying AI models, and NVIDIA AI Foundations for customizable pretrained AI models. We have partnered with cloud service providers to host these services in their data centers.

[0001045810-23-000093:mdna:18]
We entered and may continue to enter into multi-year cloud service agreements to support these offerings and our research and development activities. The timing and availability of these cloud services has changed and may continue to change, impacting revenue, expenses and development timelines. We also offer or plan to offer standalone software solutions including NVIDIA AI Enterprise, NVIDIA Omniverse, NVIDIA DRIVE, and several other software solutions.

[0001045810-23-000093:mdna:19]
Global Trade

[0001045810-23-000093:mdna:20]
During the third quarter of fiscal year 2023, the U.S. government, or the USG, announced license requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits. Following the 2022 export controls, we transitioned some operations, including certain testing, validation, and supply and distribution operations out of China and Hong Kong. We have sold alternative products in China not subject to the license requirements, such as our A800 or H800 offerings.

[0001045810-23-000093:mdna:21]
Management of these new license and other requirements is complicated and time consuming. Our results and competitive position may be harmed and we may be effectively excluded from all or part of the China market if there are further changes in the USG’s export controls, if customers in China do not want to purchase our alternative product offerings, if customers purchase product from competitors, if customers develop their own internal solution, if the USG does not grant licenses in a timely manner or denies licenses to significant customers, or if we incur significant transition costs. Any new control that impacts a wide range of our products would likely have a disproportionate impact on NVIDIA and may disadvantage us against certain of our competitors that sell chips that are outside the scope of such control. In addition to USG export controls, the Chinese government may also impose restrictions that impact our ability to sell our products.

[0001045810-23-000093:mdna:22]
New export controls or changes to existing controls could negatively impact our business, revenue or supply chain. While we work through the resiliency and redundancy of our supply chain, it is currently concentrated in the Asia-Pacific, including China, Hong Kong, Korea and Taiwan, and changes to trade requirements may negatively impact our business.

[0001045810-23-000093:mdna:23]
First Quarter of Fiscal Year 2024 Summary

[0001045810-23-000093:mdna:24]
|  | Three Months Ended |  |  |  |  |
|  | April 30, 2023 |  | January 29, 2023 |  | May 1, 2022 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 7,192 |  |  | $ | 6,051 |  |  | $ | 8,288 |  |  | 19 | % |  | (13) | % |
| Gross margin | 64.6 | % |  | 63.3 | % |  | 65.5 | % |  | 1.3 pts |  | (0.9) pts |
| Operating expenses | $ | 2,508 |  |  | $ | 2,576 |  |  | $ | 3,563 |  |  | (3) | % |  | (30) | % |
| Income from operations | $ | 2,140 |  |  | $ | 1,257 |  |  | $ | 1,868 |  |  | 70 | % |  | 15 | % |
| Net income | $ | 2,043 |  |  | $ | 1,414 |  |  | $ | 1,618 |  |  | 44 | % |  | 26 | % |
| Net income per diluted share | $ | 0.82 |  |  | $ | 0.57 |  |  | $ | 0.64 |  |  | 44 | % |  | 28 | % |

[0001045810-23-000093:mdna:25]
[same as prior period, unchanged from 0001045810-22-000166:mdna:35]

[0001045810-23-000093:mdna:26]
Revenue for the first quarter of fiscal year 2024 was $7.19 billion, down 13% from a year ago and up 19% sequentially.

[0001045810-23-000093:mdna:27]
Data Center revenue was up 14% from a year ago and up 18% sequentially, led by growing demand for generative AI and large language models using GPUs based on our NVIDIA Hopper and Ampere architectures. The revenue growth reflects strong demand from large consumer internet companies and cloud service providers. Enterprise demand for GPU platforms was strong, although general purpose networking solutions declined both sequentially and from a year ago.

[0001045810-23-000093:mdna:28]
Gaming revenue was down 38% from a year ago and up 22% sequentially. The year-on-year decrease reflects weaker demand due to the macroeconomic slowdown and lower shipments to normalize channel inventory levels. The sequential increase was driven by the ramp of our new GeForce RTX 40 Series GPUs for desktops and laptops based on the Ada Lovelace architecture.

[0001045810-23-000093:mdna:29]
Professional Visualization revenue was down 53% from a year ago and up 31% sequentially. The year-on-year decrease reflects lower sell-in to partners to help reduce channel inventory levels. The sequential increase was driven by higher demand for desktop and mobile workstation GPUs.

[0001045810-23-000093:mdna:30]
Automotive revenue was up 114% from a year ago and up 1% sequentially. The year-on-year increase reflects growth in sales of self-driving platforms and AI cockpit solutions.

[0001045810-23-000093:mdna:31]
OEM and Other revenue was down 51% from a year ago and down 8% sequentially. These decreases were primarily driven by lower entry level notebook GPU sales.

[0001045810-23-000093:mdna:32]
Gross margin declined from a year earlier and increased sequentially. The year-on-year decline reflects lower Gaming margins and a higher contribution from Automotive, partially offset by higher Data Center margins. The sequential increase reflects lower costs in Gaming and higher Data Center margins as we ramp our Hopper architecture.

[0001045810-23-000093:mdna:33]
Operating expenses were down 30% from a year ago and down 3% sequentially. The prior year included a termination charge of $1.35 billion for the proposed Arm acquisition, and the prior quarter included fixed asset write-downs.

[0001045810-23-000093:mdna:34]
Cash, cash equivalents and marketable securities were $15.32 billion, down from $20.34 billion a year ago and up from $13.30 billion a quarter ago. The year-on-year decrease reflects $8.04 billion in stock repurchases, partially offset by operating cash flow generation. The sequential increase reflects operating cash flow generation.

[0001045810-23-000093:mdna:35]
During the first quarter of fiscal year 2024, we returned $99 million to shareholders in the form of cash dividends. As of the end of the first quarter of fiscal year 2024, we had $7.23 billion remaining under our share repurchase authorization through December 2023.

[0001045810-23-000093:mdna:36]
[same as prior period, unchanged from 0001045810-22-000166:mdna:48]

[0001045810-23-000093:mdna:37]
Data Center revenue for the first quarter of fiscal year 2024 was $4.28 billion, up 14% from a year ago, led by growing demand for generative AI and large language models using GPUs based on our NVIDIA Hopper and Ampere architectures. The year-on-year increase reflects strong demand from large consumer internet customers and cloud service providers. We launched four AI inference platforms that combine our full-stack inference software with NVIDIA Ada, NVIDIA Hopper and NVIDIA Grace Hopper processors optimized for generative AI, large language model and other AI workloads. We announced that Google Cloud is the first cloud provider to offer the new NVIDIA L4 Tensor Core GPU to accelerate generative AI application. We introduced NVIDIA AI Foundations to help businesses create and operate custom large language models and generative AI models. We also partnered with ServiceNow, Inc. to build generative AI across enterprise IT; joined with Dell Technologies in Project Helix to deliver full-stack generative AI solutions to enterprises; announced a collaboration with Medtronic on an AI platform for medical devices; and unveiled the NVIDIA cuLitho software library for computational lithography.

[0001045810-23-000093:mdna:38]
Gaming revenue for the first quarter of fiscal year 2024 was $2.24 billion, down 38% from a year ago. The year-on-year decrease reflects weaker demand due to the macroeconomic slowdown and lower shipments to normalize channel inventory levels. We launched the GeForce RTX 4070 GPU based on the NVIDIA Ada Lovelace architecture.

[0001045810-23-000093:mdna:39]
Professional Visualization revenue for the first quarter of fiscal year 2024 was $295 million, down 53% from a year ago, on lower sell-in to partners to help reduce channel inventory levels. We announced six new GPUs based on the NVIDIA RTX Ada Lovelace architecture. We announced NVIDIA Omniverse Cloud, a fully managed service running in Microsoft Azure, for the development and deployment of industrial metaverse applications, and expanded our collaboration with Microsoft to connect Microsoft 365 applications with NVIDIA Omniverse.

[0001045810-23-000093:mdna:40]
Automotive revenue for the first quarter of fiscal year 2024 was $296 million, up 114% from a year ago on growth in sales of self-driving platforms and AI cockpit solutions. We announced that electric vehicle maker BYD Auto Co. Ltd. will extend its use of the NVIDIA DRIVE Orin centralized compute platform across more of its fleet.

[0001045810-23-000093:mdna:41]
[same as prior period, unchanged from 0001045810-22-000166:mdna:53]

[0001045810-23-000093:mdna:42]
[same as prior period, unchanged from 0001045810-22-000166:mdna:54]

[0001045810-23-000093:mdna:43]
[same as prior period, unchanged from 0001045810-22-000166:mdna:55]

[0001045810-23-000093:mdna:44]
Refer to Part II, Item 7, "Critical Accounting Policies and Estimates" of our Annual Report on Form 10-K for the fiscal year ended January 29, 2023. There have been no material changes to our Critical Accounting Policies and Estimates.

[0001045810-23-000093:mdna:45]
[same as prior period, unchanged from 0001045810-22-000166:mdna:32]

[0001045810-23-000093:mdna:46]
[same as prior period, unchanged from 0001045810-22-000166:mdna:57]

[0001045810-23-000093:mdna:47]
[same as prior period, unchanged from 0001045810-22-000166:mdna:58]

[0001045810-23-000093:mdna:48]
|  | Three Months Ended |  |  |
|  | April 30,2023 |  | May 1,2022 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 35.4 |  |  | 34.5 |  |  |  |  |  |
| Gross profit | 64.6 |  |  | 65.5 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 26.1 |  |  | 19.5 |  |  |  |  |  |
| Sales, general and administrative | 8.8 |  |  | 7.1 |  |  |  |  |  |
| Acquisition termination cost | — |  |  | 16.3 |  |  |  |  |  |
| Total operating expenses | 34.9 |  |  | 42.9 |  |  |  |  |  |
| Income from operations | 29.7 |  |  | 22.6 |  |  |  |  |  |
| Interest income | 2.1 |  |  | 0.2 |  |  |  |  |  |
| Interest expense | (0.9) |  |  | (0.8) |  |  |  |  |  |
| Other, net | (0.2) |  |  | (0.2) |  |  |  |  |  |
| Other income (expense), net | 1.0 |  |  | (0.8) |  |  |  |  |  |
| Income before income tax | 30.7 |  |  | 21.8 |  |  |  |  |  |
| Income tax expense | 2.3 |  |  | 2.3 |  |  |  |  |  |
| Net income | 28.4 | % |  | 19.5 | % |  |  |  |  |

[0001045810-23-000093:mdna:49]
[same as prior period, unchanged from 0001045810-22-000166:mdna:60]

[0001045810-23-000093:mdna:50]
[same as prior period, unchanged from 0001045810-22-000166:mdna:61]

[0001045810-23-000093:mdna:51]
|  | Three Months Ended |  |  |
|  | April 30,2023 |  | May 1,2022 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Compute & Networking | $ | 4,460 |  |  | $ | 3,672 |  |  | $ | 788 |  |  | 21 | % |  |  |  |  |  |  |  |  |
| Graphics | 2,732 |  |  | 4,616 |  |  | (1,884) |  |  | (41) | % |  |  |  |  |  |  |  |  |
| Total | $ | 7,192 |  |  | $ | 8,288 |  |  | $ | (1,096) |  |  | (13) | % |  |  |  |  |  |  |  |  |

[0001045810-23-000093:mdna:52]
Compute & Networking - The year-on-year increase was led by growing demand for generative AI and large language models using GPUs based on our Hopper and Ampere architectures. The revenue growth reflects strong demand from large consumer internet companies and cloud service providers. Enterprise demand for GPU platforms was strong, although general purpose networking solutions declined from a year ago. Self-driving platforms and AI cockpit solutions revenue also increased from a year ago.

[0001045810-23-000093:mdna:53]
Graphics - The year-on-year decrease primarily reflects weaker Gaming demand due to the macroeconomic slowdown and lower shipments to normalize channel inventory levels, and lower Professional Visualization sell-in to partners to help reduce channel inventory levels.

[0001045810-23-000093:mdna:54]
[same as prior period, unchanged from 0001045810-22-000166:mdna:65]

[0001045810-23-000093:mdna:55]
Revenue from sales to customers outside of the United States accounted for 67% and 77% of total revenue for the first quarter of fiscal years 2024 and 2023, respectively. Revenue by geographic region is allocated to countries based on the billed location even if the revenue may be attributable to end customers in a different location.

[0001045810-23-000093:mdna:56]
No direct customer represented 10% or more of total revenue for the first quarter of fiscal years 2024 and 2023. However, our estimated Compute & Networking end customer demand is concentrated among a few large cloud service providers and consumer internet companies. Some of these large companies do not purchase directly from us but often purchase through several system builders and channel partners. We expect this trend will continue.

[0001045810-23-000093:mdna:57]
[same as prior period, unchanged from 0001045810-22-000166:mdna:68]

[0001045810-23-000093:mdna:58]
Our overall gross margin decreased to 64.6% for the first quarter of fiscal year 2024 from 65.5% for the first quarter of fiscal year 2023, reflecting lower margins of GeForce GPUs within our Graphics segment partially offset by higher margins and increased contribution from compute products within our Compute & Networking segment.

[0001045810-23-000093:mdna:59]
Reserves for inventory and excess inventory purchase obligations totaled $134 million and $90 million for the first quarter of fiscal years 2024 and 2023, respectively. Sales of inventory that was previously written-off or down, or settlements of excess inventory purchase obligations, totaled $50 million and $15 million for the first quarter of fiscal years 2024 and 2023, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 1.2% and 0.9% in the first quarter of fiscal years 2024 and 2023, respectively.

[0001045810-23-000093:mdna:60]
Compute & Networking - Segment gross margin increased during the first quarter of fiscal year 2024 compared to the first quarter of fiscal year 2023, primarily due to higher margins and increased contribution from compute products.

[0001045810-23-000093:mdna:61]
Graphics - Segment gross margin decreased during the first quarter of fiscal year 2024 compared to the first quarter of fiscal year 2023 primarily due to lower margins of GeForce GPUs.

[0001045810-23-000093:mdna:62]
[same as prior period, unchanged from 0001045810-22-000166:mdna:74]

[0001045810-23-000093:mdna:63]
|  | Three Months Ended |  |  |
|  | April 30,2023 |  | May 1,2022 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Research and development expenses | $ | 1,875 |  |  | $ | 1,618 |  |  | $ | 257 |  |  | 16 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 26 | % |  | 20 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales, general and administrative expenses | 633 |  |  | 592 |  |  | 41 |  |  | 7 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 9 | % |  | 7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition termination cost | — |  |  | 1,353 |  |  | (1,353) |  |  | — | % |  |  |  |  |  |  |  |  |
| % of net revenue | — | % |  | 16 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 2,508 |  |  | $ | 3,563 |  |  | $ | (1,055) |  |  | (30) | % |  |  |  |  |  |  |  |  |
| % of net revenue | 34.9 | % |  | 42.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001045810-23-000093:mdna:64]
The increases in research and development expense and sales, general and administrative expense for the first quarter of fiscal year 2024 were primarily driven by employee growth and associated compensation and benefits.

[0001045810-23-000093:mdna:65]
We recorded an acquisition termination cost related to the Arm transaction of $1.35 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.

[0001045810-23-000093:mdna:66]
28

[0001045810-23-000093:mdna:67]
[same as prior period, unchanged from 0001045810-22-000166:mdna:79]

[0001045810-23-000093:mdna:68]
|  | Three Months Ended |  |  |
|  | April 30,2023 |  | May 1,2022 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Interest income | $ | 150 |  |  | $ | 18 |  |  | $ | 132 |  |  | 733 | % |  |  |  |  |  |  |  |  |
| Interest expense | (66) |  |  | (68) |  |  | 2 |  |  | (3) | % |  |  |  |  |  |  |  |  |
| Other, net | (15) |  |  | (13) |  |  | (2) |  |  | 15 | % |  |  |  |  |  |  |  |  |
| Other income (expense), net | $ | 69 |  |  | $ | (63) |  |  | $ | 132 |  |  | (210) | % |  |  |  |  |  |  |  |  |

[0001045810-23-000093:mdna:69]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. The increase in interest income was primarily due to higher yields earned on our investments.

[0001045810-23-000093:mdna:70]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our notes.

[0001045810-23-000093:mdna:71]
Other, net, consists primarily of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates.

[0001045810-23-000093:mdna:72]
[same as prior period, unchanged from 0001045810-22-000166:mdna:84]

[0001045810-23-000093:mdna:73]
Income tax expense was $166 million and $187 million for the first quarter of fiscal years 2024 and 2023, respectively. The income tax expense as a percentage of income before income tax was 7.5% and 10.3% for the first quarter of fiscal years 2024 and 2023, respectively.

[0001045810-23-000093:mdna:74]
The decrease in the effective tax rate was primarily due to the tax impact of the Arm acquisition termination cost recorded in the first quarter of fiscal year 2023, which did not result in a tax benefit, and the increased impact of tax benefits from stock-based compensation, partially offset by decreased tax benefits impact from the foreign-derived intangible income deduction and the U.S. federal research tax credit.

[0001045810-23-000093:mdna:75]
[same as prior period, unchanged from 0001045810-22-000166:mdna:87]

[0001045810-23-000093:mdna:76]
|  | April 30, 2023 |  | January 29, 2023 |
|  | (In millions) |
| Cash and cash equivalents | $ | 5,079 |  |  | $ | 3,389 |  |
| Marketable securities | 10,241 |  |  | 9,907 |  |
| Cash, cash equivalents and marketable securities | $ | 15,320 |  |  | $ | 13,296 |  |

[0001045810-23-000093:mdna:77]
|  | Three Months Ended |
|  | April 30, 2023 |  | May 1, 2022 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 2,911 |  |  | $ | 1,731 |  |
| Net cash provided by (used in) investing activities | $ | (841) |  |  | $ | 2,612 |  |
| Net cash used in financing activities | $ | (380) |  |  | $ | (2,446) |  |

[0001045810-23-000093:mdna:78]
As of April 30, 2023, we had $15.32 billion in cash, cash equivalents and marketable securities, an increase of $2.02 billion from the end of fiscal year 2023. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-23-000093:mdna:79]
Cash provided by operating activities increased in the first quarter of fiscal year 2024 compared to the first quarter of fiscal year 2023, primarily due to lower inventory prepayments and changes in inventory, partially offset by lower revenue.

[0001045810-23-000093:mdna:80]
Cash used in investing activities increased in the first quarter of fiscal year 2024 compared to the first quarter of fiscal year 2023, primarily driven by lower marketable securities sales and maturities, partially offset by lower purchases of marketable securities.

[0001045810-23-000093:mdna:81]
Cash used in financing activities decreased in the first quarter of fiscal year 2024 compared to the first quarter of fiscal year 2023, which primarily reflects share repurchases in the first quarter of fiscal year 2023.

[0001045810-23-000093:mdna:82]
[same as prior period, unchanged from 0001045810-22-000166:mdna:95]

[0001045810-23-000093:mdna:83]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of April 30, 2023, we had $15.32 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of debt securities issued by the USG and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations and potential supplier and service provider prepayments. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-23-000093:mdna:84]
Except for approximately $1.38 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of April 30, 2023 are available for use in the U.S. without incurring additional U.S. federal income taxes. We have deferred our federal income tax payments until October 2023 due to the disaster relief made available by the Internal Revenue Service.

[0001045810-23-000093:mdna:85]
During the first quarter of fiscal year 2024, we filed a Form S-3 shelf registration statement to replace the existing shelf that was expiring. We do not have any immediate plans to utilize this shelf once effective.

[0001045810-23-000093:mdna:86]
[same as prior period, unchanged from 0001045810-22-000166:mdna:99]

[0001045810-23-000093:mdna:87]
During the first quarter of fiscal year 2024, we returned $99 million in cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to the continuing determination by our Board of Directors that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

[0001045810-23-000093:mdna:88]
We did not repurchase any shares during the first quarter of fiscal year 2024. As of April 30, 2023, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.23 billion through December 2023.

[0001045810-23-000093:mdna:89]
[same as prior period, unchanged from 0001045810-22-000166:mdna:102]

[0001045810-23-000093:mdna:90]
Our aggregate debt maturities as of April 30, 2023, by year payable, are as follows:

[0001045810-23-000093:mdna:91]
|  |  | April 30, 2023 |
|  |  | (In millions) |
| Due in one year |  | $ | 1,250 |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 4,000 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (46) |  |
| Net carrying amount |  | 10,954 |  |
| Less short-term portion |  | (1,250) |  |
| Total long-term portion |  | $ | 9,704 |  |

[0001045810-23-000093:mdna:92]
We expect to repay $1.25 billion of debt due in the second quarter of fiscal year 2024.

[0001045810-23-000093:mdna:93]
We have a $575 million commercial paper program to support general corporate purposes. As of April 30, 2023, we had not issued any commercial paper.

[0001045810-23-000093:mdna:94]
Material Cash Requirements and Other Obligations

[0001045810-23-000093:mdna:95]
We have unrecognized tax benefits of $1.11 billion, which includes related interest and penalties of $109 million recorded in non-current income tax payable as of April 30, 2023. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-23-000093:mdna:96]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 29, 2023 for a description of our contractual obligations. For a description of our operating lease obligations, long-term debt, and purchase obligations, refer to Note 3, Note 12, and Note 13 of the Notes to Condensed Consolidated Financial Statements, respectively.

[0001045810-23-000093:mdna:97]
[same as prior period, unchanged from 0001045810-22-000166:mdna:117]

[0001045810-23-000093:mdna:98]
[same as prior period, unchanged from 0001045810-22-000166:mdna:118]

[0001045810-23-000093:mdna:99]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-23-000093:mdna:100]
There has been no adoption of any new and recently issued accounting pronouncements.
