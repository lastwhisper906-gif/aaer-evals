# NVDA note change history — 0001045810-17-000172 → 0001045810-18-000080


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-05-22):
[0001045810-18-000080:note_history:1]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM: 6,532,505; 7,124,325; 7,405,993; 7,886,122; 8,161,344; and 8,207,976. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

- changed (2018-05-22):
[0001045810-18-000080:note_history:2]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.
  (was, 2017-11-21, similarity 0.8563):
[0001045810-17-000172:note_history:2]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California. The California Court has not set a trial date.

- added (2018-05-22):
[0001045810-18-000080:note_history:3]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for U.S. Patent Nos. 6,532,505; 7,405,993; 7,886,122; and 8,161,344. The USPTO declined to institute IPRs on U.S. Patent Nos. 7,124,325 and 8,207,976.

- added (2018-05-22):
[0001045810-18-000080:note_history:4]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

- added (2018-05-22):
[0001045810-18-000080:note_history:5]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM: European Patent No. EP1428225, and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.

- added (2018-05-22):
[0001045810-18-000080:note_history:6]
An oral hearing is scheduled for February 21, 2019.

- added (2018-05-22):
[0001045810-18-000080:note_history:7]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

- added (2018-05-22):
[0001045810-18-000080:note_history:8]
ZiiLabs 1 Patents Lawsuit

- added (2018-05-22):
[0001045810-18-000080:note_history:9]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs: 6,683,615; 7,050,061; 7,710,425; and 9,098,943, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd. a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

- added (2018-05-22):
[0001045810-18-000080:note_history:10]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. Patent No. 6,977,649.

- added (2018-05-22):
[0001045810-18-000080:note_history:11]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the ITC investigation over the ZiiLabs 2 patents.

- added (2018-05-22):
[0001045810-18-000080:note_history:12]
ZiiLabs 2 Patents Lawsuits

- added (2018-05-22):
[0001045810-18-000080:note_history:13]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. Patents: 6,181,355; 6,900,800; 8,144,156; and 8,643,659, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

- added (2018-05-22):
[0001045810-18-000080:note_history:14]
On February 22, 2018, the Delaware Court stayed the district court action on the ZiiLabs 2 patents pending the resolution of the ITC Investigation over the ZiiLabs 2 patents.

- added (2018-05-22):
[0001045810-18-000080:note_history:15]
On December 29, 2017, ZiiLabs filed a request with the U.S. International Trade Commission, or USITC, to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

- added (2018-05-22):
[0001045810-18-000080:note_history:16]
On February 28, 2018, NVIDIA and the other respondents answered the ITC complaint and asserted various defenses including non-infringement and invalidity of the four asserted ZiiLabs 2 patents.

- added (2018-05-22):
[0001045810-18-000080:note_history:17]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 29, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2018-05-22):
[0001045810-17-000172:note_history:18]
Operating Lease Financing Arrangement

- removed (2018-05-22):
[0001045810-17-000172:note_history:19]
In November 2017, subsequent to the end of the third quarter of fiscal year 2018, we exercised the option to terminate the off-balance sheet, build-to-suit operating lease financing arrangement related to our new Santa Clara campus building. In the fourth quarter of fiscal year 2018, we expect to refinance and purchase the property for approximately $350 million.

- removed (2018-05-22):
[0001045810-17-000172:note_history:20]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint in the United States District Court for the Western District of Texas alleging that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory (DRAM). The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

- removed (2018-05-22):
[0001045810-17-000172:note_history:21]
On December 7, 2016, NVIDIA filed a petition for inter partes review with the United States Patent and Trademark Office (USPTO) challenging the validity of U.S. Patent No. 7,886,122, which is asserted by Polaris in that California district court litigation. On December 19, 2016, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 7,124,325, another patent asserted by Polaris. On May 5, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 8,161,344, another patent asserted by Polaris. On May 30, 2017, NVIDIA filed an inter partes review request with the USPTO challenging the validity of U.S. Patent No. 6,532,505, another patent asserted by Polaris. On June 22, 2017, the USPTO instituted inter partes review of U.S Patent No. 7,886,122. On June 23, 2017, the USPTO denied institution of inter partes review of U.S. Patent No. 7,124,325. On July 25, 2017, NVIDIA filed inter partes requests with the USPTO challenging the validity of U.S. Patent No. 8,207,976, another patent asserted by Polaris. Also on July 25, 2017, NVIDIA filed inter partes requests with the USPTO for U.S. Patent No. 8,161,344 challenging the validity of further claims and an additional inter partes request for U.S. Patent No. 7,124,325. All of the patents that Polaris has asserted in the U.S. litigation are now subject to requests for inter partes review, with institution decisions forthcoming.

- removed (2018-05-22):
[0001045810-17-000172:note_history:22]
On May 9, 2017, NVIDIA filed a Motion to Stay the California action pending final resolution of the inter partes review of U.S. Patents Nos. 7,886,122; 7,124,325; and 8,161,344.  On June 15, 2017, the Motion to Stay was granted. The action has now been stayed until December 14, 2017 pending the institution of the inter partes review of these patents.

- removed (2018-05-22):
[0001045810-17-000172:note_history:23]
On December 30, 2016, NVIDIA received notice that Polaris had filed a complaint for patent infringement in Germany. The German case alleges infringement of European Patent No. EP1428225 and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. An oral hearing has been scheduled for February 21, 2019.

- removed (2018-05-22):
[0001045810-17-000172:note_history:24]
On March 31, 2017, the German Patent Court acknowledged receipt of nullity actions filed by NVIDIA challenging the validity of EP1428225 and DE 1020066043668. On June 12, 2017, NVIDIA was notified that the nullity actions against EP1428225 and DE 1020066043668 were served on Polaris and that Polaris has filed a formal response opposing each nullity complaint. On July 14, 2017, the German Patent Court acknowledged receipt of a nullity action filed by NVIDIA challenging the validity of DE 10223167. On September 13, 2017, NVIDIA was notified that the nullity action against DE10223167 was served on Polaris. Polaris has not yet responded to this action.

- removed (2018-05-22):
[0001045810-17-000172:note_history:25]
While there can be no assurance of favorable outcomes, we believe the claims made by the other party in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 29, 2017, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-22):
[0001045810-18-000080:note_history:26]
Except for the accounting policy for revenue recognition, which was updated as a result of adopting a new accounting standard related to revenue recognition, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

- added (2018-05-22):
[0001045810-18-000080:note_history:27]
Revenue Recognition

- added (2018-05-22):
[0001045810-18-000080:note_history:28]
We derive our revenue primarily from product sales, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- added (2018-05-22):
[0001045810-18-000080:note_history:29]
Product Sales Revenue

- added (2018-05-22):
[0001045810-18-000080:note_history:30]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

- added (2018-05-22):
[0001045810-18-000080:note_history:31]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- added (2018-05-22):
[0001045810-18-000080:note_history:32]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- added (2018-05-22):
[0001045810-18-000080:note_history:33]
License and Development Arrangements

- added (2018-05-22):
[0001045810-18-000080:note_history:34]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

- added (2018-05-22):
[0001045810-18-000080:note_history:35]
Software Licensing

- added (2018-05-22):
[0001045810-18-000080:note_history:36]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.

- removed (2018-05-22):
[0001045810-17-000172:note_history:37]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-22):
[0001045810-18-000080:note_history:38]
Except for the accounting policy for revenue recognition, which was updated as a result of adopting a new accounting standard related to revenue recognition, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

- added (2018-05-22):
[0001045810-18-000080:note_history:39]
Revenue Recognition

- added (2018-05-22):
[0001045810-18-000080:note_history:40]
We derive our revenue primarily from product sales, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

- added (2018-05-22):
[0001045810-18-000080:note_history:41]
Product Sales Revenue

- added (2018-05-22):
[0001045810-18-000080:note_history:42]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

- added (2018-05-22):
[0001045810-18-000080:note_history:43]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

- added (2018-05-22):
[0001045810-18-000080:note_history:44]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

- added (2018-05-22):
[0001045810-18-000080:note_history:45]
License and Development Arrangements

- added (2018-05-22):
[0001045810-18-000080:note_history:46]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

- added (2018-05-22):
[0001045810-18-000080:note_history:47]
Software Licensing

- added (2018-05-22):
[0001045810-18-000080:note_history:48]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.

- changed (2018-05-22):
[0001045810-18-000080:note_history:49]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The first quarters of fiscal years 2019 and 2018 were both 13-week quarters.
  (was, 2017-11-21, similarity 0.9811):
[0001045810-17-000172:note_history:49]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2018 and 2017 are both 52-week years. The third quarter of fiscal years 2018 and 2017 were both 13-week quarters.

- changed (2018-05-22):
[0001045810-18-000080:note_history:50]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2017-11-21, similarity 0.9822):
[0001045810-17-000172:note_history:50]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- changed (2018-05-22):
[0001045810-18-000080:note_history:51]
Recently Adopted Accounting Pronouncements
  (was, 2017-11-21, similarity 0.988):
[0001045810-17-000172:note_history:51]
Recently Adopted Accounting Pronouncement

- added (2018-05-22):
[0001045810-18-000080:note_history:52]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We adopted this guidance on January 29, 2018 using the modified retrospective approach. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for additional information.

- added (2018-05-22):
[0001045810-18-000080:note_history:53]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We are now required to recognize changes in the fair value of our equity investments through net income rather than other comprehensive income. We adopted this guidance in the first quarter of fiscal year 2019 and applied it prospectively. The adoption of this guidance did not have a significant impact on our consolidated financial statements.

- changed (2018-05-22):
[0001045810-18-000080:note_history:54]
Recent Accounting Pronouncement Not Yet Adopted
  (was, 2017-11-21, similarity 0.9895):
[0001045810-17-000172:note_history:54]
Recent Accounting Pronouncements Not Yet Adopted

- changed (2018-05-22):
[0001045810-18-000080:note_history:55]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The update will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.
  (was, 2017-11-21, similarity 0.7019):
[0001045810-17-000172:note_history:55]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.

- removed (2018-05-22):
[0001045810-17-000172:note_history:56]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 29, 2017. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.

- removed (2018-05-22):
[0001045810-17-000172:note_history:57]
In October 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which requires the recognition of income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. We elected to early adopt this new guidance in the first quarter of fiscal year 2018, which required us to reflect any adjustments as of January 30, 2017. Upon adoption of this guidance, we recorded a cumulative-effect adjustment as of the first day of fiscal year 2018 to decrease retained earnings by $28 million, with a corresponding decrease to prepaid taxes that had not been previously recognized in income tax expense.

- removed (2018-05-22):
[0001045810-17-000172:note_history:58]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. Most prominent among the amendments is the requirement for changes in the fair value of our equity investments, with certain exceptions, to be recognized through net income rather than other comprehensive income. The update will be effective for us beginning in our first quarter of fiscal year 2019. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.

- removed (2018-05-22):
[0001045810-17-000172:note_history:59]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We expect to adopt this guidance beginning in our first quarter of fiscal year 2019 using the modified retrospective approach. Given the scope of work required to implement the recognition and disclosure requirements under the new guidance, we have made progress in and continue to assess changes in policies, processes, systems and controls necessary to meet the additional requirements of the guidance. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, we do not expect it to have a material impact on our consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2018-05-22):
[0001045810-17-000172:note_history:60]
The following table presents the carrying value of the Convertible Notes:

- removed (2018-05-22):
[0001045810-17-000172:note_history:61]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 24 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (1 | ) |  | (31 | ) |
| Net carrying amount | $ | 23 |  |  | $ | 796 |  |

- removed (2018-05-22):
[0001045810-17-000172:note_history:62]
(1) As of October 29, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.1 years.

- removed (2018-05-22):
[0001045810-17-000172:note_history:63]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

- removed (2018-05-22):
[0001045810-17-000172:note_history:64]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 10 |  |
| Amortization of debt discount |  | — |  |  | 5 |  |  | 2 |  |  | 20 |  |
| Total interest expense related to Convertible Notes |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 30 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0001045810-18-000080:note_history:65]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.
  (was, 2017-11-21, similarity 0.9331):
[0001045810-17-000172:note_history:65]
In the third quarter of fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable in March and September of each year, beginning in March 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 2021, or for redemptions of the Notes Due 2026 on or after June 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

- changed (2018-05-22):
[0001045810-18-000080:note_history:66]
The carrying value of the Notes and the associated interest rates were as follows:
  (was, 2017-11-21, similarity 0.8902):
[0001045810-17-000172:note_history:66]
The carrying value of our long-term debt and the associated interest rates were as follows:

- changed (2018-05-22):
[0001045810-18-000080:note_history:67]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (14 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,986 |  |  | $ | 1,985 |  |
  (was, 2017-11-21, similarity 0.9836):
[0001045810-17-000172:note_history:67]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (15 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,985 |  |  | $ | 1,983 |  |

- added (2018-05-22):
[0001045810-18-000080:note_history:68]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through the first quarter of fiscal year 2019, we had settled an aggregate of $1.49 billion of the Convertible Notes. The Convertible Notes are unsecured, unsubordinated obligations of the Company paying interest in cash semi-annually at a rate of 1.00% per annum and will mature on December 1, 2018 unless previously repurchased or converted. Upon conversion, we pay cash up to the aggregate principal amount and pay or deliver cash, shares of our common stock or a combination thereof, at our election, of our conversion obligation in excess of the aggregate principal amount being converted.

- added (2018-05-22):
[0001045810-18-000080:note_history:69]
Holders may convert all or any portion of their Convertible Notes at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition has been met, all outstanding Convertible Notes are convertible at the holders’ option through July 29, 2018.

- changed (2018-05-22):
[0001045810-18-000080:note_history:70]
During the first quarter of fiscal year 2019, we paid cash to settle an aggregate of $2 million in principal amount of the Convertible Notes and had $14 million in principal amount outstanding as of April 29, 2018. We also issued 74 thousand shares of our common stock for the excess conversion value and the related loss on early conversions was not significant. Based on the closing price of our common stock of $226.33 on the last trading day of the first quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $144 million. As of April 29, 2018, the conversion rate was 49.9261 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0296 per share of common stock).
  (was, 2017-11-21, similarity 0.8758):
[0001045810-17-000172:note_history:70]
During the third quarter of fiscal year 2018, we paid cash to settle an aggregate of $62 million in principal amount of the Convertible Notes and had $24 million in principal amount outstanding as of October 29, 2017. We also issued 3 million shares of our common stock for the excess conversion value and recognized a loss of $1 million on early conversions of the Convertible Notes. Based on the closing price of our common stock of $201.86 on the last trading day of the third quarter of fiscal year 2018, the if-converted value of the remaining outstanding Convertible Notes as of October 29, 2017 exceeded their principal amount by approximately $217 million. As of October 29, 2017, the conversion rate was 49.8977 shares of common stock per $1,000 principal amount of the Convertible Notes after adjusting for dividend increases (equivalent to an adjusted conversion price of $20.0410 per share of common stock).

- changed (2018-05-22):
[0001045810-18-000080:note_history:71]
Note Hedges
  (was, 2017-11-21, similarity 0.6286):
[0001045810-17-000172:note_history:71]
Note Hedges and Warrants

- added (2018-05-22):
[0001045810-18-000080:note_history:72]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.0296 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through April 29, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.49 billion in principal amount of the Convertible Notes.

- added (2018-05-22):
[0001045810-18-000080:note_history:73]
Revolving Credit Facility

- added (2018-05-22):
[0001045810-18-000080:note_history:74]
In fiscal year 2017, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of April 29, 2018, we had not borrowed any amounts and were in compliance with all related covenants under the Credit Agreement.

- added (2018-05-22):
[0001045810-18-000080:note_history:75]
Commercial Paper

- added (2018-05-22):
[0001045810-18-000080:note_history:76]
In fiscal year 2018, we established a commercial paper program to support general corporate purposes. Under the program, we can issue up to $575 million in commercial paper. As of April 29, 2018, we had not issued any commercial paper and there was no commercial paper outstanding.

- removed (2018-05-22):
[0001045810-17-000172:note_history:77]
Through the third quarter of fiscal year 2018, we settled an aggregate of $1.48 billion in principal amount of the Convertible Notes. Subsequently, we received additional conversion notices for an aggregate of $8 million in principal amount of the Convertible Notes. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2018. The actual number of shares issuable upon conversion will be determined based upon the terms of the Convertible Notes, and we expect to receive an equal number of shares of our common stock under the terms of the Note Hedges.

- removed (2018-05-22):
[0001045810-17-000172:note_history:78]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 under certain circumstances, determined on a quarterly basis.  All outstanding Convertible Notes are convertible at the holders’ option through January 28, 2018.

- removed (2018-05-22):
[0001045810-17-000172:note_history:79]
We separately accounted for the liability and equity components of the Convertible Notes at issuance, since our conversion obligation in excess of the aggregate principal could be fully or partially settled in cash. The liability component was assigned by estimating the fair value of a similar debt without the conversion feature. The difference between the net cash proceeds and the liability component was assigned as the equity component. The initial liability component of the Convertible Notes was valued at $1.35 billion and the initial carrying value of the equity component recorded in additional paid-in-capital was valued at $126 million. This equity component, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the initial aggregate unamortized debt discount of $148 million. The debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method and an interest rate of 3.15%.

- removed (2018-05-22):
[0001045810-17-000172:note_history:80]
As of October 29, 2017, the carrying value of the Convertible Notes was classified as a current liability and the difference between the principal amount and the carrying value of the Convertible Notes was classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet.

- removed (2018-05-22):
[0001045810-17-000172:note_history:81]
The following table presents the carrying value of the Convertible Notes:

- removed (2018-05-22):
[0001045810-17-000172:note_history:82]
|  | October 29, |  | January 29, |
|  | 2017 |  | 2017 |
|  | (In millions) |
| 1.00% Convertible Senior Notes | $ | 24 |  |  | $ | 827 |  |
| Unamortized debt discount (1) | (1 | ) |  | (31 | ) |
| Net carrying amount | $ | 23 |  |  | $ | 796 |  |

- removed (2018-05-22):
[0001045810-17-000172:note_history:83]
(1) As of October 29, 2017, the remaining period over which the unamortized debt discount will be amortized is 1.1 years.

- removed (2018-05-22):
[0001045810-17-000172:note_history:84]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

- removed (2018-05-22):
[0001045810-17-000172:note_history:85]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 10 |  |
| Amortization of debt discount |  | — |  |  | 5 |  |  | 2 |  |  | 20 |  |
| Total interest expense related to Convertible Notes |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 30 |  |

- removed (2018-05-22):
[0001045810-17-000172:note_history:86]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. During the third quarter of fiscal year 2018, we had received 3 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $62 million in principal amount of the Convertible Notes. Subsequently, we expect to receive additional shares of our common stock related to at least an additional $8 million in principal amount that is expected to settle during the fourth quarter of fiscal year 2018.

- removed (2018-05-22):
[0001045810-17-000172:note_history:87]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction. All outstanding Warrants were terminated by the second quarter of fiscal year 2018.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-05-22):
[0001045810-18-000080:note_history:88]
The carrying value of the Notes and the associated interest rates were as follows:

- changed (2018-05-22):
[0001045810-18-000080:note_history:89]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (14 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,986 |  |  | $ | 1,985 |  |
  (was, 2017-11-21, similarity 0.9836):
[0001045810-17-000172:note_history:89]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 29, 2017 |  | January 29, 2017 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (15 | ) |  | (17 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,985 |  |  | $ | 1,983 |  |
