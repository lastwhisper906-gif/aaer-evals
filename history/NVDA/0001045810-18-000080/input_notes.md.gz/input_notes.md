# NVDA notes — 0001045810-18-000080


## nvda:BalanceSheetComponentsTextBlock

[0001045810-18-000080:notes:1]
[same as prior period, unchanged from 0001045810-17-000172:notes:1]

[0001045810-18-000080:notes:2]
[same as prior period, unchanged from 0001045810-17-000172:notes:2]

[0001045810-18-000080:notes:3]
|  | April 29, |  | January 28, |
|  | 2018 |  | 2018 |
| Inventories: | (In millions) |
| Raw materials | $ | 214 |  |  | $ | 227 |  |
| Work in-process | 254 |  |  | 192 |  |
| Finished goods | 329 |  |  | 377 |  |
| Total inventories | $ | 797 |  |  | $ | 796 |  |

[0001045810-18-000080:notes:4]
As of April 29, 2018, we had outstanding inventory purchase obligations totaling $1.69 billion.

[0001045810-18-000080:notes:5]
|  | April 29, |  | January 28, |
|  | 2018 |  | 2018 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 182 |  |  | $ | 181 |  |
| Accrued payroll and related expenses | 94 |  |  | 172 |  |
| Deferred revenue (1) | 56 |  |  | 53 |  |
| Taxes payable | 38 |  |  | 33 |  |
| Accrued royalties | 17 |  |  | 17 |  |
| Professional service fees | 16 |  |  | 15 |  |
| Warranty accrual (2) | 15 |  |  | 15 |  |
| Coupon interest on debt obligations | 7 |  |  | 20 |  |
| Other | 44 |  |  | 36 |  |
| Total accrued and other current liabilities | $ | 469 |  |  | $ | 542 |  |

[0001045810-18-000080:notes:6]
| (1) | Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and PCS. |

[0001045810-18-000080:notes:7]
| (2) | Refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding warranties. |

[0001045810-18-000080:notes:8]
|  | April 29, |  | January 28, |
|  | 2018 |  | 2018 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 569 |  |  | $ | 559 |  |
| Deferred income tax liability | 19 |  |  | 18 |  |
| Employee benefits liability | 18 |  |  | 12 |  |
| Deferred revenue (2) | 18 |  |  | 15 |  |
| Deferred rent | 12 |  |  | 9 |  |
| Other | 15 |  |  | 19 |  |
| Total other long-term liabilities | $ | 651 |  |  | $ | 632 |  |

[0001045810-18-000080:notes:9]
| (1) | As of April 29, 2018, represents the long-term portion of the one-time transition tax payable of $369 million, as well as unrecognized tax benefits of $184 million and related interest and penalties of $16 million. |

[0001045810-18-000080:notes:10]
| (2) | Deferred revenue primarily includes deferrals related to license and development arrangements and PCS. |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-18-000080:notes:11]
|  | Three Months Ended |
|  | April 29, |  | April 30, |
|  | 2018 |  | 2017 |
|  | (In millions) |
| Revenue: |  |  |  |
| Gaming | $ | 1,723 |  |  | $ | 1,027 |  |
| Professional Visualization | 251 |  |  | 205 |  |
| Datacenter | 701 |  |  | 409 |  |
| Automotive | 145 |  |  | 140 |  |
| OEM & IP | 387 |  |  | 156 |  |
| Total revenue | $ | 3,207 |  |  | $ | 1,937 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-18-000080:notes:12]
|  | April 29, |  | January 28, |
|  | 2018 |  | 2018 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 1,103 |  |  | $ | 1,091 |  |
| Estimated weighted average remaining amortization period | (In years) |
| RSUs, PSUs, and market-based PSUs | 2.3 |  |  | 2.3 |  |
| ESPP | 1.0 |  |  | 0.7 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-18-000080:notes:13]
|  | April 29, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 2,741 |  |  | $ | — |  |  | $ | (4 | ) |  | $ | 2,737 |  |  | $ | 100 |  |  | $ | 2,637 |  |
| Corporate debt securities | 1,803 |  |  | — |  |  | (11 | ) |  | 1,792 |  |  | — |  |  | 1,792 |  |
| Debt securities of United States government agencies | 1,734 |  |  | — |  |  | (7 | ) |  | 1,727 |  |  | — |  |  | 1,727 |  |
| Money market funds | 460 |  |  | — |  |  | — |  |  | 460 |  |  | 460 |  |  | — |  |
| Asset-backed securities | 230 |  |  | — |  |  | (3 | ) |  | 227 |  |  | — |  |  | 227 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 119 |  |  | 2 |  |  | — |  |  | 121 |  |  | — |  |  | 121 |  |
| Foreign government bonds | 31 |  |  | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |
| Total | $ | 7,118 |  |  | $ | 2 |  |  | $ | (25 | ) |  | $ | 7,095 |  |  | $ | 560 |  |  | $ | 6,535 |  |

[0001045810-18-000080:notes:14]
|  | January 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 3,789 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,789 |  |  | $ | 3,789 |  |  | $ | — |  |
| Corporate debt securities | 1,304 |  |  | — |  |  | (9 | ) |  | 1,295 |  |  | — |  |  | 1,295 |  |
| Debt securities of United States government agencies | 822 |  |  | — |  |  | (7 | ) |  | 815 |  |  | — |  |  | 815 |  |
| Debt securities issued by the United States Treasury | 577 |  |  | — |  |  | (4 | ) |  | 573 |  |  | — |  |  | 573 |  |
| Asset-backed securities | 254 |  |  | — |  |  | (2 | ) |  | 252 |  |  | — |  |  | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 128 |  |  | 2 |  |  | — |  |  | 130 |  |  | — |  |  | 130 |  |
| Foreign government bonds | 42 |  |  | — |  |  | (1 | ) |  | 41 |  |  | — |  |  | 41 |  |
| Total | $ | 6,916 |  |  | $ | 2 |  |  | $ | (23 | ) |  | $ | 6,895 |  |  | $ | 3,789 |  |  | $ | 3,106 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-18-000080:notes:15]
[same as prior period, unchanged from 0001045810-17-000172:notes:16]

[0001045810-18-000080:notes:16]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 28, 2018 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

[0001045810-18-000080:notes:17]
[same as prior period, unchanged from 0001045810-17-000172:notes:18]

[0001045810-18-000080:notes:18]
Except for the accounting policy for revenue recognition, which was updated as a result of adopting a new accounting standard related to revenue recognition, there have been no material changes to our significant accounting policies in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

[0001045810-18-000080:notes:19]
Revenue Recognition

[0001045810-18-000080:notes:20]
We derive our revenue primarily from product sales, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-18-000080:notes:21]
Product Sales Revenue

[0001045810-18-000080:notes:22]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-18-000080:notes:23]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-18-000080:notes:24]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-18-000080:notes:25]
License and Development Arrangements

[0001045810-18-000080:notes:26]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-18-000080:notes:27]
Software Licensing

[0001045810-18-000080:notes:28]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-18-000080:notes:29]
Commitments and Contingencies

[0001045810-18-000080:notes:30]
Litigation

[0001045810-18-000080:notes:31]
Polaris Innovations Limited

[0001045810-18-000080:notes:32]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM: 6,532,505; 7,124,325; 7,405,993; 7,886,122; 8,161,344; and 8,207,976. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-18-000080:notes:33]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.

[0001045810-18-000080:notes:34]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for U.S. Patent Nos. 6,532,505; 7,405,993; 7,886,122; and 8,161,344. The USPTO declined to institute IPRs on U.S. Patent Nos. 7,124,325 and 8,207,976.

[0001045810-18-000080:notes:35]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

[0001045810-18-000080:notes:36]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM: European Patent No. EP1428225, and German Patent Nos. DE 10223167 and DE 1020066043668. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents.

[0001045810-18-000080:notes:37]
An oral hearing is scheduled for February 21, 2019.

[0001045810-18-000080:notes:38]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

[0001045810-18-000080:notes:39]
ZiiLabs 1 Patents Lawsuit

[0001045810-18-000080:notes:40]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs: 6,683,615; 7,050,061; 7,710,425; and 9,098,943, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd. a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

[0001045810-18-000080:notes:41]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. Patent No. 6,977,649.

[0001045810-18-000080:notes:42]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the ITC investigation over the ZiiLabs 2 patents.

[0001045810-18-000080:notes:43]
ZiiLabs 2 Patents Lawsuits

[0001045810-18-000080:notes:44]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. Patents: 6,181,355; 6,900,800; 8,144,156; and 8,643,659, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

[0001045810-18-000080:notes:45]
On February 22, 2018, the Delaware Court stayed the district court action on the ZiiLabs 2 patents pending the resolution of the ITC Investigation over the ZiiLabs 2 patents.

[0001045810-18-000080:notes:46]
On December 29, 2017, ZiiLabs filed a request with the U.S. International Trade Commission, or USITC, to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

[0001045810-18-000080:notes:47]
On February 28, 2018, NVIDIA and the other respondents answered the ITC complaint and asserted various defenses including non-infringement and invalidity of the four asserted ZiiLabs 2 patents.

[0001045810-18-000080:notes:48]
Accounting for Loss Contingencies

[0001045810-18-000080:notes:49]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 29, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-18-000080:notes:50]
[same as prior period, unchanged from 0001045810-17-000172:notes:33]

[0001045810-18-000080:notes:51]
[same as prior period, unchanged from 0001045810-17-000172:notes:34]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001045810-18-000080:notes:52]
|  | April 29, |
|  | 2018 |
|  | (In millions) |
| Balance as of January 28, 2018 | $ | 68 |  |
| Adjustment to retained earnings upon adoption of new revenue standard | (5 | ) |
| Balance as of January 29, 2018 | 63 |  |
| Deferred revenue added during the period | 86 |  |
| Revenue recognized during the period | (75 | ) |
| Balance as of April 29, 2018 | $ | 74 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-18-000080:notes:53]
Debt

[0001045810-18-000080:notes:54]
Long-Term Debt

[0001045810-18-000080:notes:55]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-18-000080:notes:56]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-18-000080:notes:57]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-18-000080:notes:58]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-18-000080:notes:59]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | April 29, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 3.4 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 8.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (14 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,986 |  |  | $ | 1,985 |  |

[0001045810-18-000080:notes:60]
Convertible Debt

[0001045810-18-000080:notes:61]
1.00% Convertible Senior Notes Due 2018

[0001045810-18-000080:notes:62]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. Through the first quarter of fiscal year 2019, we had settled an aggregate of $1.49 billion of the Convertible Notes. The Convertible Notes are unsecured, unsubordinated obligations of the Company paying interest in cash semi-annually at a rate of 1.00% per annum and will mature on December 1, 2018 unless previously repurchased or converted. Upon conversion, we pay cash up to the aggregate principal amount and pay or deliver cash, shares of our common stock or a combination thereof, at our election, of our conversion obligation in excess of the aggregate principal amount being converted.

[0001045810-18-000080:notes:63]
Holders may convert all or any portion of their Convertible Notes at any time prior to August 1, 2018 under certain circumstances. For example, during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day, the Convertible Notes become convertible at the holders' option. As this condition has been met, all outstanding Convertible Notes are convertible at the holders’ option through July 29, 2018.

[0001045810-18-000080:notes:64]
During the first quarter of fiscal year 2019, we paid cash to settle an aggregate of $2 million in principal amount of the Convertible Notes and had $14 million in principal amount outstanding as of April 29, 2018. We also issued 74 thousand shares of our common stock for the excess conversion value and the related loss on early conversions was not significant. Based on the closing price of our common stock of $226.33 on the last trading day of the first quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $144 million. As of April 29, 2018, the conversion rate was 49.9261 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0296 per share of common stock).

[0001045810-18-000080:notes:65]
Note Hedges

[0001045810-18-000080:notes:66]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.0296 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through April 29, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.49 billion in principal amount of the Convertible Notes.

[0001045810-18-000080:notes:67]
Revolving Credit Facility

[0001045810-18-000080:notes:68]
In fiscal year 2017, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of April 29, 2018, we had not borrowed any amounts and were in compliance with all related covenants under the Credit Agreement.

[0001045810-18-000080:notes:69]
Commercial Paper

[0001045810-18-000080:notes:70]
In fiscal year 2018, we established a commercial paper program to support general corporate purposes. Under the program, we can issue up to $575 million in commercial paper. As of April 29, 2018, we had not issued any commercial paper and there was no commercial paper outstanding.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-18-000080:notes:71]
[same as prior period, unchanged from 0001045810-17-000172:notes:57]

[0001045810-18-000080:notes:72]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of April 29, 2018 and January 28, 2018.

[0001045810-18-000080:notes:73]
We also enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-18-000080:notes:74]
The table below presents the notional value of our foreign currency forward contracts outstanding as of April 29, 2018 and January 28, 2018:

[0001045810-18-000080:notes:75]
|  | April 29, 2018 |  | January 28, 2018 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 216 |  |  | $ | 104 |  |
| Not designated for hedge accounting | $ | 76 |  |  | $ | 94 |  |

[0001045810-18-000080:notes:76]
As of April 29, 2018, all designated foreign currency forward contracts mature within twelve months. We expect to realize all gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months.

[0001045810-18-000080:notes:77]
During the first quarter of fiscal years 2019 and 2018, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-18-000080:notes:78]
[same as prior period, unchanged from 0001045810-17-000172:notes:67]

[0001045810-18-000080:notes:79]
[same as prior period, unchanged from 0001045810-17-000172:notes:68]

[0001045810-18-000080:notes:80]
[same as prior period, unchanged from 0001045810-17-000172:notes:69]

[0001045810-18-000080:notes:81]
|  | Three Months Ended |
|  | April 29, 2018 |  | April 30, 2017 |
|  | (In millions) |
| Cost of revenue | $ | 8 |  |  | $ | 4 |  |
| Research and development | 74 |  |  | 41 |  |
| Sales, general and administrative | 47 |  |  | 31 |  |
| Total | $ | 129 |  |  | $ | 76 |  |

[0001045810-18-000080:notes:82]
[same as prior period, unchanged from 0001045810-17-000172:notes:71]

[0001045810-18-000080:notes:83]
[same as prior period, unchanged from 0001045810-17-000172:notes:72]

[0001045810-18-000080:notes:84]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balances, January 28, 2018 | 22 |  |  | $ | 66.72 |  |
| Granted (1) (2) | 1 |  |  | $ | 235.59 |  |
| Vested restricted stock | (5 | ) |  | $ | 33.98 |  |
| Canceled and forfeited | — |  |  |  |  |
| Balances, April 29, 2018 | 18 |  |  | $ | 81.82 |  |

[0001045810-18-000080:notes:85]
| (1) | Includes PSUs that will be issued and eligible to vest if the maximum corporate financial performance goal for fiscal year 2019 is achieved. Depending on the actual level of the corporate performance achievement at the end of fiscal year 2019, the PSUs issued could be up to 0.3 million shares. |

[0001045810-18-000080:notes:86]
| (2) | Includes market-based PSUs that will be issued and eligible to vest if the maximum goal for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to those of the companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 45 thousand shares. |

[0001045810-18-000080:notes:87]
Of the total fair value of equity awards granted during the first quarters of fiscal years 2019 and 2018, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $18 million and $27 million, respectively.

[0001045810-18-000080:notes:88]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of April 29, 2018 and January 28, 2018:


## us-gaap:EarningsPerShareTextBlock

[0001045810-18-000080:notes:89]
[same as prior period, unchanged from 0001045810-17-000172:notes:78]

[0001045810-18-000080:notes:90]
[same as prior period, unchanged from 0001045810-17-000172:notes:79]

[0001045810-18-000080:notes:91]
|  | Three Months Ended |
|  | April 29, |  | April 30, |
|  | 2018 |  | 2017 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |
| Net income | $ | 1,244 |  |  | $ | 507 |  |
| Denominator: |  |  |  |
| Basic weighted average shares | 606 |  |  | 592 |  |
| Dilutive impact of outstanding securities: |  |  |  |
| Equity awards | 20 |  |  | 26 |  |
| 1.00% Convertible Senior Notes | 1 |  |  | 14 |  |
| Warrants issued with the 1.00% Convertible Senior Notes | — |  |  | 9 |  |
| Diluted weighted average shares | 627 |  |  | 641 |  |
| Net income per share: |  |  |  |
| Basic (1) | $ | 2.05 |  |  | $ | 0.86 |  |
| Diluted (2) | $ | 1.98 |  |  | $ | 0.79 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 1 |  |  | 2 |  |

[0001045810-18-000080:notes:92]
[same as prior period, unchanged from 0001045810-17-000172:notes:81]

[0001045810-18-000080:notes:93]
[same as prior period, unchanged from 0001045810-17-000172:notes:82]

[0001045810-18-000080:notes:94]
The 1.00% Convertible Senior Notes Due 2018, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0296 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding are also included in the calculation of diluted net income per share. As of April 29, 2018, there were no warrants outstanding.

[0001045810-18-000080:notes:95]
For the first quarter of fiscal year 2019, our average stock price was $235.10, which exceeded the adjusted conversion price, causing the Convertible Notes to have a dilutive impact.

[0001045810-18-000080:notes:96]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transactions, or the Note Hedges, that we entered into concurrently with the issuance of the Convertible Notes, as its effect would be anti-dilutive. In the event of conversion of the Convertible Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Convertible Notes.

[0001045810-18-000080:notes:97]
Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Convertible Notes and Note Hedges.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-18-000080:notes:98]
|  |  | Fair Value at |
|  | Pricing Category |  | April 29, 2018 |  | January 28, 2018 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 2,737 |  |  | $ | 573 |  |
| Corporate debt securities | Level 2 |  | $ | 1,792 |  |  | $ | 1,295 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 1,727 |  |  | $ | 815 |  |
| Money market funds | Level 1 |  | $ | 460 |  |  | $ | 3,789 |  |
| Asset-backed securities | Level 2 |  | $ | 227 |  |  | $ | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 121 |  |  | $ | 130 |  |
| Foreign government bonds | Level 2 |  | $ | 31 |  |  | $ | 41 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 159 |  |  | $ | 189 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 972 |  |  | $ | 982 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 954 |  |  | $ | 986 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-18-000080:notes:99]
[same as prior period, unchanged from 0001045810-17-000172:notes:90]

[0001045810-18-000080:notes:100]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 financial assets and liabilities for the first quarter of fiscal year 2019. Level 3 financial assets and liabilities are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances.

[0001045810-18-000080:notes:101]
| (1) | These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional information. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-18-000080:notes:102]
[same as prior period, unchanged from 0001045810-17-000172:notes:92]

[0001045810-18-000080:notes:103]
We recognized income tax expense of $67 million and $29 million for the first quarter of fiscal years 2019 and 2018, respectively. Income tax expense as a percentage of income before income tax was 5.1% and 5.5% for the first quarter of fiscal years 2019 and 2018, respectively.

[0001045810-18-000080:notes:104]
The decrease in our effective tax rate in the first quarter of fiscal year 2019 as compared to the same period in the prior fiscal year is primarily due to a decrease in the U.S. statutory tax rate from 35% to 21%, partially offset by a decrease in the impact of tax benefits from stock-based compensation.

[0001045810-18-000080:notes:105]
Our effective tax rates for the first quarter of fiscal years 2019 and 2018 of 5.1% and 5.5%, respectively, were lower than the U.S. federal statutory rates of 21% and 33.9%, for fiscal years 2019 and 2018, respectively, due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, and the benefit of the U.S. federal research tax credit.

[0001045810-18-000080:notes:106]
In December 2017, the SEC issued guidance that allows companies to record provisional amounts for the tax effects of the Tax Cuts and Job Acts, or TCJA, during a measurement period not to exceed one year. The TCJA was effective in the fourth quarter of fiscal year 2018 and we have recorded provisional amounts based on reasonable estimates for those tax effects. For the first quarter of fiscal year 2019, we have not recorded any adjustments to our provisional amounts. We will continue our analysis of these provisional amounts, which are still subject to change during the measurement period, and we anticipate further guidance on accounting interpretations from the FASB and application of the law from the U.S. Department of Treasury.

[0001045810-18-000080:notes:107]
The TCJA subjects a U.S. corporation to tax on its global intangible low-taxed income, or GILTI. Under U.S. GAAP, we can make an accounting policy election to either treat taxes due on the GILTI as a current period expense or factor such amounts into our measurement of deferred taxes. Given the complexity of the GILTI provisions, we are still evaluating its effects and have not yet determined our accounting policy. We expect to complete our analysis within the measurement period. For the first quarter of fiscal year 2019, because we are still evaluating the effects of the GILTI provisions, we have included tax expense related to GILTI for current-year operations in our estimated annual effective tax rate and have not provided for GILTI on deferred items.

[0001045810-18-000080:notes:108]
For the first quarter of fiscal year 2019, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 28, 2018.

[0001045810-18-000080:notes:109]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 29, 2018, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-18-000080:notes:110]
[same as prior period, unchanged from 0001045810-17-000172:notes:98]

[0001045810-18-000080:notes:111]
[same as prior period, unchanged from 0001045810-17-000172:notes:99]

[0001045810-18-000080:notes:112]
|  | April 29, 2018 |  | January 28, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (183 | ) |  | $ | 12 |  |  | $ | 195 |  |  | $ | (180 | ) |  | $ | 15 |  |
| Patents and licensed technology | 483 |  |  | (440 | ) |  | 43 |  |  | 469 |  |  | (432 | ) |  | 37 |  |
| Total intangible assets | $ | 678 |  |  | $ | (623 | ) |  | $ | 55 |  |  | $ | 664 |  |  | $ | (612 | ) |  | $ | 52 |  |

[0001045810-18-000080:notes:113]
The increase in gross carrying amount of intangible assets is primarily due to purchases of licensed technology during the first quarter of fiscal year 2019. Amortization expense associated with intangible assets was $11 million and $15 million for the first quarter of fiscal years 2019 and 2018, respectively. Future amortization expense related to the net carrying amount of intangible assets as of April 29, 2018 is estimated to be $18 million for the remainder of fiscal year 2019, $20 million in fiscal year 2020, $11 million in fiscal year 2021, $3 million in fiscal year 2022, and $3 million in fiscal year 2023 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-18-000080:notes:114]
|  | April 29, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,490 |  |  | $ | 5,481 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,593 |  |  | 1,578 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 35 |  |  | 36 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,118 |  |  | $ | 7,095 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-18-000080:notes:115]
[same as prior period, unchanged from 0001045810-17-000172:notes:103]

[0001045810-18-000080:notes:116]
All of our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-18-000080:notes:117]
The following is a summary of cash equivalents and marketable securities as of April 29, 2018 and January 28, 2018:

[0001045810-18-000080:notes:118]
The following table provides the breakdown of unrealized losses as of April 29, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-18-000080:notes:119]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by the United States Treasury | $ | 1,539 |  |  | $ | — |  |  | $ | 502 |  |  | $ | (4 | ) |  | $ | 2,041 |  |  | $ | (4 | ) |
| Debt securities issued by United States government agencies | 1,039 |  |  | (1 | ) |  | 687 |  |  | (6 | ) |  | 1,726 |  |  | (7 | ) |
| Corporate debt securities | 253 |  |  | (2 | ) |  | 835 |  |  | (9 | ) |  | 1,088 |  |  | (11 | ) |
| Asset-backed securities | 56 |  |  | (1 | ) |  | 172 |  |  | (2 | ) |  | 228 |  |  | (3 | ) |
|  | $ | 2,887 |  |  | $ | (4 | ) |  | $ | 2,196 |  |  | $ | (21 | ) |  | $ | 5,083 |  |  | $ | (25 | ) |

[0001045810-18-000080:notes:120]
The gross unrealized losses related to fixed income securities were primarily due to changes in interest rates, which we believe are temporary in nature. Currently, we have the intent and ability to hold our investments until maturity. For the first quarter of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.

[0001045810-18-000080:notes:121]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of April 29, 2018 and January 28, 2018 are shown below by contractual maturity.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-18-000080:notes:122]
New Revenue Accounting Standard

[0001045810-18-000080:notes:123]
Method and Impact of Adoption

[0001045810-18-000080:notes:124]
On January 29, 2018, we adopted the new revenue accounting standard using the modified retrospective method and applied it to contracts that were not completed as of that date. Upon adoption, we recognized the cumulative effect of the new standard as an increase to opening retained earnings of $7 million, net of tax. Comparative information for prior periods has not been adjusted. The impact of applying the new standard on our consolidated financial statements for the quarter ended April 29, 2018 was not significant.

[0001045810-18-000080:notes:125]
Deferred Revenue and Performance Obligations

[0001045810-18-000080:notes:126]
Deferred revenue is comprised mainly of customer advances and deferrals related to license and development arrangements and PCS related to software licenses. The following table shows the changes in deferred revenue during the first quarter of fiscal year 2019:

[0001045810-18-000080:notes:127]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of April 29, 2018, the amount of our remaining performance obligations that have not been recognized as revenue was $243 million, of which we expect to recognize approximately 50% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-18-000080:notes:128]
Refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for additional information, including disaggregated revenue disclosures.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-18-000080:notes:129]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000080:notes:130]
Recently Adopted Accounting Pronouncements

[0001045810-18-000080:notes:131]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We adopted this guidance on January 29, 2018 using the modified retrospective approach. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000080:notes:132]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We are now required to recognize changes in the fair value of our equity investments through net income rather than other comprehensive income. We adopted this guidance in the first quarter of fiscal year 2019 and applied it prospectively. The adoption of this guidance did not have a significant impact on our consolidated financial statements.

[0001045810-18-000080:notes:133]
Recent Accounting Pronouncement Not Yet Adopted

[0001045810-18-000080:notes:134]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The update will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-18-000080:notes:135]
[same as prior period, unchanged from 0001045810-17-000172:notes:118]

[0001045810-18-000080:notes:136]
[same as prior period, unchanged from 0001045810-17-000172:notes:119]

[0001045810-18-000080:notes:137]
[same as prior period, unchanged from 0001045810-17-000172:notes:120]

[0001045810-18-000080:notes:138]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product returns and estimated product warranty liabilities was $15 million as of April 29, 2018 and January 28, 2018.

[0001045810-18-000080:notes:139]
[same as prior period, unchanged from 0001045810-17-000172:notes:124]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-18-000080:notes:140]
|  | Three Months Ended |
|  | April 29, 2018 |  | April 30, 2017 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | 43 |  |
| Stock-based compensation expense | (129 | ) |  | (76 | ) |
| Unallocated cost of revenue and operating expenses | (63 | ) |  | (56 | ) |
| Acquisition-related costs | (2 | ) |  | (4 | ) |
| Legal settlement costs | (2 | ) |  | — |  |
| Contributions | — |  |  | (2 | ) |
| Total | $ | (196 | ) |  | $ | (95 | ) |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-18-000080:notes:141]
|  | Three Months Ended |
|  | April 29, |  | April 30, |
|  | 2018 |  | 2017 |
|  | (In millions) |
| Revenue: |  |  |  |
| Taiwan | $ | 967 |  |  | $ | 602 |  |
| China | 754 |  |  | 330 |  |
| Other Asia Pacific | 583 |  |  | 377 |  |
| United States | 434 |  |  | 353 |  |
| Europe | 235 |  |  | 182 |  |
| Other Americas | 234 |  |  | 93 |  |
| Total revenue | $ | 3,207 |  |  | $ | 1,937 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-18-000080:notes:142]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended April 29, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 2,765 |  |  | $ | 442 |  |  | $ | — |  |  | $ | 3,207 |  |
| Depreciation and amortization expense | $ | 40 |  |  | $ | 10 |  |  | $ | 7 |  |  | $ | 57 |  |
| Operating income (loss) | $ | 1,394 |  |  | $ | 97 |  |  | $ | (196 | ) |  | $ | 1,295 |  |
| Three Months Ended April 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,562 |  |  | $ | 332 |  |  | $ | 43 |  |  | $ | 1,937 |  |
| Depreciation and amortization expense | $ | 28 |  |  | $ | 9 |  |  | $ | 10 |  |  | $ | 47 |  |
| Operating income (loss) | $ | 602 |  |  | $ | 47 |  |  | $ | (95 | ) |  | $ | 554 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-18-000080:notes:143]
[same as prior period, unchanged from 0001045810-17-000172:notes:133]

[0001045810-18-000080:notes:144]
[same as prior period, unchanged from 0001045810-17-000172:notes:134]

[0001045810-18-000080:notes:145]
[same as prior period, unchanged from 0001045810-17-000172:notes:135]

[0001045810-18-000080:notes:146]
While our GPU and CUDA architecture is unified, our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for consoles and mobile gaming and entertainment devices.

[0001045810-18-000080:notes:147]
Under the single unifying graphics architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-18-000080:notes:148]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, contributions, restructuring and other charges, product warranty charge, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-18-000080:notes:149]
[same as prior period, unchanged from 0001045810-17-000172:notes:139]

[0001045810-18-000080:notes:150]
[same as prior period, unchanged from 0001045810-17-000172:notes:140]

[0001045810-18-000080:notes:151]
[same as prior period, unchanged from 0001045810-17-000172:notes:141]

[0001045810-18-000080:notes:152]
Revenue from significant customers, those representing 10% or more of total revenue, aggregated approximately 20% of our total revenue from two customers for the first quarter of fiscal year 2019, and was attributable primarily to the GPU business. No single customer represented 10% or more of total revenue for the first quarter of fiscal year 2018.

[0001045810-18-000080:notes:153]
Accounts receivable from significant customers, those representing more than 10% of total accounts receivable, aggregated approximately 18% of our accounts receivable balance from one customer as of April 29, 2018, and approximately 28% of our accounts receivable balance from two customers as of January 28, 2018.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-18-000080:notes:154]
[same as prior period, unchanged from 0001045810-17-000172:notes:143]

[0001045810-18-000080:notes:155]
[same as prior period, unchanged from 0001045810-17-000172:notes:144]

[0001045810-18-000080:notes:156]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The first quarters of fiscal years 2019 and 2018 were both 13-week quarters.

[0001045810-18-000080:notes:157]
[same as prior period, unchanged from 0001045810-17-000172:notes:146]

[0001045810-18-000080:notes:158]
[same as prior period, unchanged from 0001045810-17-000172:notes:147]

[0001045810-18-000080:notes:159]
[same as prior period, unchanged from 0001045810-17-000172:notes:148]

[0001045810-18-000080:notes:160]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-18-000080:notes:161]
[same as prior period, unchanged from 0001045810-17-000172:notes:150]

[0001045810-18-000080:notes:162]
[same as prior period, unchanged from 0001045810-17-000172:notes:151]

[0001045810-18-000080:notes:163]
Beginning August 2004, our Board of Directors authorized us to repurchase our stock.

[0001045810-18-000080:notes:164]
During the first quarter of fiscal year 2019, we repurchased a total of 3 million shares for $655 million and paid $91 million in cash dividends to our shareholders.

[0001045810-18-000080:notes:165]
Through April 29, 2018, we have repurchased an aggregate of 254 million shares under our share repurchase program for a total cost of $6.16 billion. All shares delivered from these repurchases have been placed into treasury stock. As of April 29, 2018, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $1.16 billion through December 2020.

[0001045810-18-000080:notes:166]
Preferred Stock

[0001045810-18-000080:notes:167]
As of April 29, 2018 and January 28, 2018, there were no shares of preferred stock outstanding.

[0001045810-18-000080:notes:168]
[same as prior period, unchanged from 0001045810-17-000172:notes:158]

[0001045810-18-000080:notes:169]
[same as prior period, unchanged from 0001045810-17-000172:notes:159]
