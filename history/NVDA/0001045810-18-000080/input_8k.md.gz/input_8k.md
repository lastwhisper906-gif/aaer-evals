# NVDA 8-K — 0001045810-18-000052 filed 2018-05-10

## item codes, every 8-K on or before 2018-05-22

- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2018-05-22

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-18-000052:8k_2_02:1]
EX-99.1
2
q1fy19pr.htm
Q1FY19 PRESS RELEASE

[0001045810-18-000052:8k_2_02:2]
Exhibit

[0001045810-18-000052:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-18-000052:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2019

[0001045810-18-000052:8k_2_02:5]
| • | Record revenue of $3.21 billion, up 66 percent from a year ago |

[0001045810-18-000052:8k_2_02:6]
| • | Record GAAP EPS of $1.98, up 151 percent from a year ago |

[0001045810-18-000052:8k_2_02:7]
| • | Record Datacenter revenue of $701 million, up 71 percent from a year earlier |

[0001045810-18-000052:8k_2_02:8]
SANTA CLARA, Calif.-May 10, 2018-NVIDIA (NASDAQ: NVDA) today reported record revenue for the first quarter ended April 29, 2018, of $3.21 billion, up 66 percent from $1.94 billion a year earlier, and up 10 percent from $2.91 billion in the previous quarter.

[0001045810-18-000052:8k_2_02:9]
GAAP earnings per diluted share for the quarter were a record $1.98, up 151 percent from $0.79 a year ago and up 11 percent from $1.78 in the previous quarter. Non-GAAP earnings per diluted share were $2.05, also a record, up 141 percent from $0.85 a year earlier and up 19 percent from $1.72 in the previous quarter.

[0001045810-18-000052:8k_2_02:10]
“We had a strong quarter with growth across every platform,” said Jensen Huang, founder and chief executive officer of NVIDIA. “Our datacenter business achieved another record and gaming remained strong.

[0001045810-18-000052:8k_2_02:11]
“At the heart of our opportunity is the incredible growth of computing demand of AI, just as traditional computing has slowed. The GPU computing approach we have pioneered is ideal for filling this vacuum. And our invention of the Tensor Core GPU has further enhanced our strong position to power the AI era,” he said.

[0001045810-18-000052:8k_2_02:12]
Capital Return

[0001045810-18-000052:8k_2_02:13]
During the first quarter of fiscal 2019, NVIDIA returned $746 million to shareholders through a combination of $655 million in share repurchases and $91 million in quarterly cash dividends.

[0001045810-18-000052:8k_2_02:14]
For fiscal 2019, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000052:8k_2_02:15]
NVIDIA will pay its next quarterly cash dividend of $0.15 per share on June 15, 2018, to all shareholders of record on May 24, 2018.

[0001045810-18-000052:8k_2_02:16]
Q1 Fiscal 2019 Summary

[0001045810-18-000052:8k_2_02:17]
| GAAP |
| ($ in millions except earnings per share) | Q1 FY19 | Q4 FY18 | Q1 FY18 | Q/Q | Y/Y |
| Revenue | $3,207 | $2,911 | $1,937 | Up 10% | Up 66% |
| Gross margin | 64.5% | 61.9% | 59.4% | Up 260 bps | Up 510 bps |
| Operating expenses | $773 | $728 | $596 | Up 6% | Up 30% |
| Operating income | $1,295 | $1,073 | $554 | Up 21% | Up 134% |
| Net income | $1,244 | $1,118 | $507 | Up 11% | Up 145% |
| Diluted earnings per share | $1.98 | $1.78 | $0.79 | Up 11% | Up 151% |

[0001045810-18-000052:8k_2_02:18]
| Non-GAAP |
| ($ in millions except earnings per share) | Q1 FY19 | Q4 FY18 | Q1 FY18 | Q/Q | Y/Y |
| Revenue | $3,207 | $2,911 | $1,937 | Up 10% | Up 66% |
| Gross margin | 64.7% | 62.1% | 59.6% | Up 260 bps | Up 510 bps |
| Operating expenses | $648 | $607 | $517 | Up 7% | Up 25% |
| Operating income | $1,428 | $1,202 | $637 | Up 19% | Up 124% |
| Net income | $1,285 | $1,081 | $533 | Up 19% | Up 141% |
| Diluted earnings per share | $2.05 | $1.72 | $0.85 | Up 19% | Up 141% |

[0001045810-18-000052:8k_2_02:19]
NVIDIA’s outlook for the second quarter of fiscal 2019 is as follows:

[0001045810-18-000052:8k_2_02:20]
| • | Revenue is expected to be $3.10 billion, plus or minus two percent. |

[0001045810-18-000052:8k_2_02:21]
| • | GAAP and non-GAAP gross margins are expected to be 63.3 percent and 63.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-18-000052:8k_2_02:22]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $810 million and $685 million, respectively. |

[0001045810-18-000052:8k_2_02:23]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $15 million. |

[0001045810-18-000052:8k_2_02:24]
| • | GAAP and non-GAAP tax rates are both expected to be 11.0 percent, plus or minus one percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-18-000052:8k_2_02:25]
First Quarter Fiscal 2019 Highlights

[0001045810-18-000052:8k_2_02:26]
During the first quarter, NVIDIA achieved progress in these areas:

[0001045810-18-000052:8k_2_02:27]
Gaming

[0001045810-18-000052:8k_2_02:28]
| • | Gaming revenue grew 68 percent from a year earlier to $1.72 billion. |

[0001045810-18-000052:8k_2_02:29]
| • | Announced NVIDIA RTX™, a groundbreaking computer graphics technology that produces movie-quality images in real time. |

[0001045810-18-000052:8k_2_02:30]
Datacenter

[0001045810-18-000052:8k_2_02:31]
| • | Datacenter revenue grew 71 percent from a year earlier to a record $701 million. |

[0001045810-18-000052:8k_2_02:32]
| • | Unveiled at the annual GPU Technology Conference, in San Jose, with nearly 8,500 registered attendees, advances to its deep learning computing platform - including NVIDIA® Tesla® V100 GPUs with 32GB memory, NVIDIA NVSwitch™ GPU interconnect fabric and NVIDIA DGX-2™, the first server with two petaflops of computational power. |

[0001045810-18-000052:8k_2_02:33]
| • | Announced TensorRT 4™, the latest version of the TensorRT AI inference accelerator software, expanding its reach in the inference market by accelerating deep learning across a much broader range of applications. |

[0001045810-18-000052:8k_2_02:34]
| • | Announced GPU acceleration for Kubernetes to facilitate enterprise inference deployment on multi-cloud GPU clusters. |

[0001045810-18-000052:8k_2_02:35]
Professional Visualization

[0001045810-18-000052:8k_2_02:36]
| • | Professional Visualization revenue grew 22 percent from a year earlier to $251 million. |

[0001045810-18-000052:8k_2_02:37]
| • | Announced the Quadro® GV100 GPU with RTX technology, making real-time ray tracing possible on professional design and content creation applications. |

[0001045810-18-000052:8k_2_02:38]
Automotive

[0001045810-18-000052:8k_2_02:39]
| • | Automotive revenue grew 4 percent from a year earlier to a record $145 million. |

[0001045810-18-000052:8k_2_02:40]
| • | Introduced the NVIDIA DRIVE Constellation™ server with DRIVE Sim™ software, a complete system to safely test drive autonomous vehicles over billions of miles in virtual reality by leveraging NVIDIA GPUs and NVIDIA DRIVE Pegasus™. |

[0001045810-18-000052:8k_2_02:41]
New Platforms

[0001045810-18-000052:8k_2_02:42]
| • | Introduced Project Clara, a medical imaging supercomputer, to revolutionize medical imaging. |

[0001045810-18-000052:8k_2_02:43]
| • | Announced the Isaac software development kit for robotics, offering a collection of libraries, drivers, APIs and other tools for researchers, developers and startups. |

[0001045810-18-000052:8k_2_02:44]
| • | Announced that Arm will integrate the open-source NVIDIA Deep Learning Accelerator to bring AI inference to mobile, consumer electronics and Internet of Things devices. |

[0001045810-18-000052:8k_2_02:45]
CFO Commentary

[0001045810-18-000052:8k_2_02:46]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-18-000052:8k_2_02:47]
Conference Call and Webcast Information

[0001045810-18-000052:8k_2_02:48]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2019 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 2387419. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2019.

[0001045810-18-000052:8k_2_02:49]
Non-GAAP Measures

[0001045810-18-000052:8k_2_02:50]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, contributions, gains from non-affiliated investments, interest expense related to amortization of debt discount, debt-related costs, the associated tax impact of these items, where applicable, and the provisional tax benefit from income tax reform. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-18-000052:8k_2_02:51]
Keep Current on NVIDIA

[0001045810-18-000052:8k_2_02:52]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-18-000052:8k_2_02:53]
About NVIDIA

[0001045810-18-000052:8k_2_02:54]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-18-000052:8k_2_02:55]
###

[0001045810-18-000052:8k_2_02:56]
For further information, contact:

[0001045810-18-000052:8k_2_02:57]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-18-000052:8k_2_02:58]
Certain statements in this press release including, but not limited to, statements as to: NVIDIA’s opportunities based on the growth of computing demand for AI;  NVIDIA’s GPU computing approach being ideal for filling a vacuum as traditional computing has slowed; NVIDIA’s invention of the Tensor Core GPU enhancing its strong position to power the AI era; NVIDIA’s intended capital return for fiscal 2019; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the second quarter of fiscal 2019; NVIDIA’s expected tax rates for the second quarter of fiscal 2019; our expectation to generate variability from excess tax benefits or deficiencies related to stock-based compensation; the benefits and impacts of advances in our deep learning platform including NVIDIA Tesla V100, NVIDIA NVSwitch, and NVIDIA DGX-2, the latest version of our TensorRT software and the expansion of NVIDIA in the inference market, our work with Kubernetes to facilitate enterprise inference deployment, Project Clara to revolutionize medical imaging, Arm integrating NVIDIA Deep Learning Accelerator and bringing inference to devices, and the offerings of the Isaac software development kit; and the benefits, impacts and performance of NVIDIA RTX, Quadro GV100 GPU making real-time ray tracing possible, and NVIDIA DRIVE Constellation server with DRIVE Sim software to safely test drive autonomous vehicles are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-K for the fiscal year ended January 28, 2018. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-18-000052:8k_2_02:59]
© 2018 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, Quadro, Tesla, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Constellation, NVIDIA DRIVE Sim, NVIDIA RTX, NVSwitch and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-18-000052:8k_2_02:60]
NVIDIA CORPORATION

[0001045810-18-000052:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-18-000052:8k_2_02:62]
(In millions, except per share data)

[0001045810-18-000052:8k_2_02:63]
(Unaudited)

[0001045810-18-000052:8k_2_02:64]
|  | Three Months Ended |
|  | April 29, |  | April 30, |
|  | 2018 |  | 2017 |
| Revenue | $ | 3,207 |  |  | $ | 1,937 |  |
| Cost of revenue | 1,139 |  |  | 787 |  |
| Gross profit | 2,068 |  |  | 1,150 |  |
| Operating expenses |  |  |  |
| Research and development | 542 |  |  | 411 |  |
| Sales, general and administrative | 231 |  |  | 185 |  |
| Total operating expenses | 773 |  |  | 596 |  |
| Income from operations | 1,295 |  |  | 554 |  |
| Interest income | 25 |  |  | 16 |  |
| Interest expense | (15 | ) |  | (16 | ) |
| Other, net | 6 |  |  | (18 | ) |
| Total other income (expense) | 16 |  |  | (18 | ) |
| Income before income tax | 1,311 |  |  | 536 |  |
| Income tax expense | 67 |  |  | 29 |  |
| Net income | $ | 1,244 |  |  | $ | 507 |  |
| Net income per share: |  |  |  |
| Basic | $ | 2.05 |  |  | $ | 0.86 |  |
| Diluted | $ | 1.98 |  |  | $ | 0.79 |  |
| Weighted average shares used in per share computation: |  |  |  |
| Basic | 606 |  |  | 592 |  |
| Diluted | 627 |  |  | 641 |  |

[0001045810-18-000052:8k_2_02:65]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | April 29, |  | January 28, |
|  |  |  | 2018 |  | 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 7,300 |  |  | $ | 7,108 |  |
|  | Accounts receivable, net |  | 1,220 |  |  | 1,265 |  |
|  | Inventories |  | 797 |  |  | 796 |  |
|  | Prepaid expenses and other current assets |  | 131 |  |  | 86 |  |
|  | Total current assets |  | 9,448 |  |  | 9,255 |  |
| Property and equipment, net |  | 1,066 |  |  | 997 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 55 |  |  | 52 |  |
| Other assets |  | 273 |  |  | 319 |  |
|  | Total assets |  | $ | 11,460 |  |  | $ | 11,241 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 623 |  |  | $ | 596 |  |
|  | Accrued and other current liabilities |  | 469 |  |  | 542 |  |
|  | Convertible short-term debt |  | 14 |  |  | 15 |  |
|  | Total current liabilities |  | 1,106 |  |  | 1,153 |  |
| Long-term debt |  | 1,986 |  |  | 1,985 |  |
| Other long-term liabilities |  | 651 |  |  | 632 |  |
|  | Total liabilities |  | 3,743 |  |  | 3,770 |  |
| Shareholders' equity |  | 7,717 |  |  | 7,471 |  |
|  | Total liabilities and shareholders' equity |  | $ | 11,460 |  |  | $ | 11,241 |  |

[0001045810-18-000052:8k_2_02:66]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |
|  |  | April 29, |  | January 28, |  | April 30, |
|  |  | 2018 |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 2,068 |  |  | $ | 1,801 |  |  | $ | 1,150 |  |
| GAAP gross margin |  | 64.5 | % |  | 61.9 | % |  | 59.4 | % |
| Stock-based compensation expense (A) |  | 8 |  |  | 7 |  |  | 4 |  |
| Legal settlement costs |  | — |  |  | 1 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 2,076 |  |  | $ | 1,809 |  |  | $ | 1,154 |  |
| Non-GAAP gross margin |  | 64.7 | % |  | 62.1 | % |  | 59.6 | % |
| GAAP operating expenses |  | $ | 773 |  |  | $ | 728 |  |  | $ | 596 |  |
| Stock-based compensation expense (A) |  | (121 | ) |  | (119 | ) |  | (73 | ) |
| Acquisition-related costs (B) |  | (2 | ) |  | (2 | ) |  | (4 | ) |
| Legal settlement costs |  | (2 | ) |  | — |  |  | — |  |
| Contributions |  | — |  |  | — |  |  | (2 | ) |
| Non-GAAP operating expenses |  | $ | 648 |  |  | $ | 607 |  |  | $ | 517 |  |
| GAAP income from operations |  | $ | 1,295 |  |  | $ | 1,073 |  |  | $ | 554 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 133 |  |  | 129 |  |  | 83 |  |
| Non-GAAP income from operations |  | $ | 1,428 |  |  | $ | 1,202 |  |  | $ | 637 |  |
| GAAP other income (expense) |  | $ | 16 |  |  | $ | 5 |  |  | $ | (18 | ) |
| Gains from non-affiliated investments (C) |  | (6 | ) |  | (2 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | 1 |  |  | — |  |  | 2 |  |
| Debt-related costs (D) |  | — |  |  | 2 |  |  | 14 |  |
| Non-GAAP other income (expense) |  | $ | 11 |  |  | $ | 5 |  |  | $ | (2 | ) |
| GAAP net income |  | $ | 1,244 |  |  | $ | 1,118 |  |  | $ | 507 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 128 |  |  | 129 |  |  | 99 |  |
| Income tax impact of non-GAAP adjustments (E) |  | (87 | ) |  | (33 | ) |  | (73 | ) |
| Provisional tax benefit from income tax reform |  | — |  |  | (133 | ) |  | — |  |
| Non-GAAP net income |  | $ | 1,285 |  |  | $ | 1,081 |  |  | $ | 533 |  |

[0001045810-18-000052:8k_2_02:67]
|  |  | Three Months Ended |
|  |  | April 29, |  | January 28, |  | April 30, |
|  |  | 2018 |  | 2018 |  | 2017 |
| Diluted net income per share |  |  |  |  |  |  |
| GAAP |  | $ | 1.98 |  |  | $ | 1.78 |  |  | $ | 0.79 |  |
| Non-GAAP |  | $ | 2.05 |  |  | $ | 1.72 |  |  | $ | 0.85 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |
| GAAP |  | 627 |  |  | 628 |  |  | 641 |  |
| Anti-dilution impact from note hedge (F) |  | (1 | ) |  | (1 | ) |  | (14 | ) |
| Non-GAAP |  | 626 |  |  | 627 |  |  | 627 |  |
| GAAP net cash provided by operating activities |  | $ | 1,445 |  |  | $ | 1,358 |  |  | $ | 282 |  |
| Purchase of property and equipment and intangible assets |  | (118 | ) |  | (416 | ) |  | (53 | ) |
| Free cash flow |  | $ | 1,327 |  |  | $ | 942 |  |  | $ | 229 |  |

[0001045810-18-000052:8k_2_02:68]
| (A) Stock-based compensation consists of the following: |  |  |  |  |
|  |  | Three Months Ended |
|  |  | April 29, |  | January 28, |  | April 30, |
|  |  | 2018 |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 8 |  |  | $ | 7 |  |  | $ | 4 |  |
| Research and development |  | $ | 74 |  |  | $ | 73 |  |  | $ | 41 |  |
| Sales, general and administrative |  | $ | 47 |  |  | $ | 46 |  |  | $ | 31 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Consists of realized and unrealized gains from non-affiliated investments. |
| (D) Consists of loss on early debt conversions and termination of interest rate swap. |
| (E) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (F) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-18-000052:8k_2_02:69]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2019 Outlook |
| GAAP gross margin |  | 63.3 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 63.5 | % |
|  |  |  | Q2 FY2019 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 810 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (125 | ) |
| Non-GAAP operating expenses |  | $ | 685 |  |
