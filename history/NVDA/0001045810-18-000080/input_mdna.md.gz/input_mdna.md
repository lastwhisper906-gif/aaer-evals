# NVDA MD&A — 0001045810-18-000080


## mdna

[0001045810-18-000080:mdna:1]
[same as prior period, unchanged from 0001045810-17-000172:mdna:1]

[0001045810-18-000080:mdna:2]
[same as prior period, unchanged from 0001045810-17-000172:mdna:2]

[0001045810-18-000080:mdna:3]
[same as prior period, unchanged from 0001045810-17-000172:mdna:3]

[0001045810-18-000080:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, Jetson, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Sim, NVIDIA GRID, NVIDIA Holodeck, NVIDIA NVSwitch, NVIDIA RTX, NVIDIA Volta and TensorRT are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-18-000080:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 6. Selected Financial Data” of our Annual Report on Form 10-K for the fiscal year ended January 28, 2018 and “Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and

[0001045810-18-000080:mdna:6]
related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-18-000080:mdna:7]
[same as prior period, unchanged from 0001045810-17-000172:mdna:7]

[0001045810-18-000080:mdna:8]
[same as prior period, unchanged from 0001045810-17-000172:mdna:8]

[0001045810-18-000080:mdna:9]
Starting with a focus on PC graphics, NVIDIA invented the GPU to solve some of the most complex problems in computer science. We have extended our focus in recent years to the revolutionary field of AI. Fueled by the sustained demand for better 3D graphics and the scale of the gaming market, NVIDIA has evolved the GPU into a computer brain at the intersection of virtual reality, high performance computing, or HPC, and artificial intelligence, or AI.

[0001045810-18-000080:mdna:10]
Our two reportable segments - GPU and Tegra Processor - are based on a single underlying architecture. From our proprietary processors, we have created platforms that address four large markets where our expertise is critical: Gaming, Professional Visualization, Datacenter, and Automotive.

[0001045810-18-000080:mdna:11]
While our GPU and CUDA architecture is unified, our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, and incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for consoles and mobile gaming and entertainment devices.

[0001045810-18-000080:mdna:12]
[same as prior period, unchanged from 0001045810-17-000172:mdna:12]

[0001045810-18-000080:mdna:13]
[same as prior period, unchanged from 0001045810-17-000172:mdna:13]

[0001045810-18-000080:mdna:14]
First Quarter of Fiscal Year 2019 Summary

[0001045810-18-000080:mdna:15]
|  | Three Months Ended |  |  |  |  |
|  | April 29, 2018 |  | January 28, 2018 |  | April 30, 2017 |  | Q/Q |  | Y/Y |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 3,207 |  |  | $ | 2,911 |  |  | $ | 1,937 |  |  | 10 | % |  | 66 | % |
| Gross margin | 64.5 | % |  | 61.9 | % |  | 59.4 | % |  | 260 bps |  |  | 510 bps |  |
| Operating expenses | $ | 773 |  |  | $ | 728 |  |  | $ | 596 |  |  | 6 | % |  | 30 | % |
| Income from operations | $ | 1,295 |  |  | $ | 1,073 |  |  | $ | 554 |  |  | 21 | % |  | 134 | % |
| Net income | $ | 1,244 |  |  | $ | 1,118 |  |  | $ | 507 |  |  | 11 | % |  | 145 | % |
| Net income per diluted share | $ | 1.98 |  |  | $ | 1.78 |  |  | $ | 0.79 |  |  | 11 | % |  | 151 | % |

[0001045810-18-000080:mdna:16]
Revenue for the first quarter of fiscal year 2019 increased 66% year over year and 10% sequentially. All of our market platforms - gaming, professional visualization, datacenter, and automotive - produced year-over-year growth.

[0001045810-18-000080:mdna:17]
GPU business revenue was $2.77 billion, up 77% from a year earlier and up 12% sequentially, led by gaming and datacenter. Gaming revenue was up 68% from a year ago and down 1% sequentially. Gaming GPU growth was fueled by demand from gamers playing eSports, momentum of the Battle Royale genre, and AAA cinematic games. Datacenter revenue was $701 million, up 71% from a year ago and up 16% sequentially, led by strong sales of our Volta architecture, including NVIDIA Tesla V100, new DGX systems, and HPC design wins. Professional visualization revenue was $251 million, up 22% from a year earlier and down 1% sequentially. OEM sales included $289 million related to GPUs for cryptocurrency mining.

[0001045810-18-000080:mdna:18]
Tegra processor business revenue, which includes SOC modules for the Nintendo Switch gaming console, was $442 million, up 33% from a year ago and down 2% sequentially. Also included was Automotive revenue of $145 million, which was up 4% from a year earlier and up 10% sequentially, incorporating infotainment modules, production DRIVE PX platforms, and development agreements with automotive companies.

[0001045810-18-000080:mdna:19]
[same as prior period, unchanged from 0001045810-17-000172:mdna:19]

[0001045810-18-000080:mdna:20]
We adopted the new accounting standard for revenue recognition in the first quarter of fiscal year 2019 using the modified retrospective approach. The impact of adopting the new revenue standard was not significant to our consolidated financial statements in the first quarter.

[0001045810-18-000080:mdna:21]
21

[0001045810-18-000080:mdna:22]
Gross margin for the first quarter of fiscal year 2019 was 64.5%, increasing from the prior year and the previous quarter due to strong growth in datacenter revenue and the mix within our GeForce gaming GPUs.

[0001045810-18-000080:mdna:23]
Operating expenses for the first quarter of fiscal year 2019 were $773 million, up 30% from a year earlier and up 6% sequentially, reflecting increased headcount and related costs for our growth initiatives - gaming, AI, and autonomous driving.

[0001045810-18-000080:mdna:24]
Income from operations for the first quarter of fiscal year 2019 was $1.29 billion, up 134% from a year earlier and up 21% sequentially. Net income and net income per diluted share for the first quarter of fiscal year 2019 were $1.24 billion and $1.98, respectively, up 145% and 151%, respectively, from a year earlier, fueled by strong revenue growth and improved gross and operating margins.

[0001045810-18-000080:mdna:25]
During the first quarter of fiscal year 2019, we returned to shareholders $655 million in share repurchases and $91 million in cash dividends. For fiscal year 2019, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000080:mdna:26]
Cash, cash equivalents and marketable securities were $7.30 billion as of April 29, 2018, compared with $7.11 billion at the end of the prior quarter. The sequential increase was primarily related to the increase in operating income, as well as strong collections of outstanding accounts receivable, and partially offset by an increase in share repurchases.

[0001045810-18-000080:mdna:27]
[same as prior period, unchanged from 0001045810-17-000172:mdna:26]

[0001045810-18-000080:mdna:28]
During the first quarter of fiscal year 2019, we announced NVIDIA RTX, a computer graphics technology that produces movie-quality images in real time. We also unveiled advances to our deep learning computing platform - including NVIDIA Tesla V100 GPUs with 32GB memory, NVIDIA NVSwitch GPU interconnect fabric, NVIDIA DGX-2, and TensorRT 4, the latest version of the TensorRT AI inference accelerator software. In addition, we announced GPU acceleration for Kubernetes to facilitate enterprise inference deployment on multi-cloud GPU clusters and the Quadro GV100 GPU with RTX technology, making real-time ray tracing possible on professional design and content creation applications.

[0001045810-18-000080:mdna:29]
[same as prior period, unchanged from 0001045810-17-000172:mdna:30]

[0001045810-18-000080:mdna:30]
During the first quarter of fiscal year 2019, we introduced the NVIDIA DRIVE Constellation server with DRIVE Sim software, a complete system to safely test drive autonomous vehicles over billions of miles in virtual reality by leveraging NVIDIA GPUs and NVIDIA DRIVE Pegasus.

[0001045810-18-000080:mdna:31]
[same as prior period, unchanged from 0001045810-17-000172:mdna:35]

[0001045810-18-000080:mdna:32]
Refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for disclosure regarding segment information.

[0001045810-18-000080:mdna:33]
[same as prior period, unchanged from 0001045810-17-000172:mdna:37]

[0001045810-18-000080:mdna:34]
[same as prior period, unchanged from 0001045810-17-000172:mdna:38]

[0001045810-18-000080:mdna:35]
|  | Three Months Ended |
|  | April 29, 2018 |  | April 30, 2017 |
| Revenue | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 35.5 |  |  | 40.6 |  |
| Gross profit | 64.5 |  |  | 59.4 |  |
| Operating expenses |  |  |  |
| Research and development | 16.9 |  |  | 21.2 |  |
| Sales, general and administrative | 7.2 |  |  | 9.6 |  |
| Total operating expenses | 24.1 |  |  | 30.8 |  |
| Income from operations | 40.4 |  |  | 28.6 |  |
| Interest income | 0.8 |  |  | 0.8 |  |
| Interest expense | (0.5 | ) |  | (0.8 | ) |
| Other, net | 0.2 |  |  | (0.9 | ) |
| Total other income (expense) | 0.5 |  |  | (0.9 | ) |
| Income before income tax | 40.9 |  |  | 27.7 |  |
| Income tax expense | 2.1 |  |  | 1.5 |  |
| Net income | 38.8 | % |  | 26.2 | % |

[0001045810-18-000080:mdna:36]
[same as prior period, unchanged from 0001045810-17-000172:mdna:41]

[0001045810-18-000080:mdna:37]
[same as prior period, unchanged from 0001045810-17-000172:mdna:42]

[0001045810-18-000080:mdna:38]
|  | Three Months Ended |
|  | April 29, 2018 |  | April 30, 2017 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,765 |  |  | $ | 1,562 |  |  | $ | 1,203 |  |  | 77 | % |
| Tegra Processor | 442 |  |  | 332 |  |  | 110 |  |  | 33 | % |
| All Other | — |  |  | 43 |  |  | (43 | ) |  | (100 | )% |
| Total | $ | 3,207 |  |  | $ | 1,937 |  |  | $ | 1,270 |  |  | 66 | % |

[0001045810-18-000080:mdna:39]
GPU Business. GPU business revenue increased by 77% for the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018. This increase was due primarily to increased revenue from sales of GeForce GPU products for gaming, which increased 70%, reflecting continued strong demand from gamers playing eSports, momentum of the Battle Royale genre, and AAA cinematic games. Datacenter revenue, including Tesla, GRID and DGX, increased 71%, reflecting strong sales of our Volta architecture, including NVIDIA Tesla V100, new DGX systems, and strong demand for HPC. Revenue from Quadro GPUs for professional visualization increased 22% due primarily to higher sales in overall desktop workstation products and mid-range mobile workstation products. Our PC OEM revenue increased by over 320% due primarily to strong demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-18-000080:mdna:40]
Tegra Processor Business. Tegra Processor business revenue increased by 33% for the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018. This was driven by an increase of over 85% in revenue from SOC modules for gaming platforms and development services, and an increase of 4% in automotive revenue, primarily from infotainment modules, DRIVE PX platforms and development agreements for self-driving cars.

[0001045810-18-000080:mdna:41]
All Other. Our patent license agreement with Intel concluded in the first quarter of fiscal year 2018.

[0001045810-18-000080:mdna:42]
[same as prior period, unchanged from 0001045810-17-000172:mdna:49]

[0001045810-18-000080:mdna:43]
Revenue from sales to customers outside of the United States and Other Americas accounted for 79% and 77% of total revenue for the first quarter of fiscal years 2019 and 2018, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-18-000080:mdna:44]
Revenue from significant customers, those representing 10% or more of total revenue, aggregated approximately 20% of our total revenue from two customers for the first quarter of fiscal year 2019. No single customer represented 10% or more of total revenue for the first quarter of fiscal year 2018.

[0001045810-18-000080:mdna:45]
[same as prior period, unchanged from 0001045810-17-000172:mdna:51]

[0001045810-18-000080:mdna:46]
Our overall gross margin increased to 64.5% for the first quarter of fiscal year 2019 from 59.4% for the first quarter of fiscal year 2018, primarily due to a favorable mix shift within our GPU segment.

[0001045810-18-000080:mdna:47]
Inventory provision costs totaled $33 million and $3 million for the first quarter of fiscal years 2019 and 2018, respectively. Sales of inventory that was previously written-off or written-down totaled $4 million and $13 million for the first quarter of fiscal years 2019 and 2018, respectively. As a result, the overall net effect on our gross margin from charges for inventory provision costs and sales of items previously written-off or written-down was a 0.9% unfavorable impact for the first quarter of fiscal year 2019 and a 0.6% favorable impact for the first quarter of fiscal year 2018.

[0001045810-18-000080:mdna:48]
[same as prior period, unchanged from 0001045810-17-000172:mdna:55]

[0001045810-18-000080:mdna:49]
GPU Business. The gross margin of our GPU business increased during the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018, primarily due to strong sales of high-end GeForce gaming GPU products.

[0001045810-18-000080:mdna:50]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018. The increase in Tegra margins was primarily due to a favorable mix shift and revenue growth in gaming development platforms.

[0001045810-18-000080:mdna:51]
[same as prior period, unchanged from 0001045810-17-000172:mdna:58]

[0001045810-18-000080:mdna:52]
|  | Three Months Ended |
|  | April 29, 2018 |  | April 30, 2017 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 542 |  |  | $ | 411 |  |  | $ | 131 |  |  | 32 | % |
| % of net revenue | 17 | % |  | 21 | % |  |  |  |  |
| Sales, general and administrative expenses | 231 |  |  | 185 |  |  | 46 |  |  | 25 | % |
| % of net revenue | 7 | % |  | 10 | % |  |  |  |  |
| Total operating expenses | $ | 773 |  |  | $ | 596 |  |  | $ | 177 |  |  | 30 | % |

[0001045810-18-000080:mdna:53]
[same as prior period, unchanged from 0001045810-17-000172:mdna:60]

[0001045810-18-000080:mdna:54]
Research and development expenses increased by 32% during the first quarter of fiscal year 2019, compared to the first quarter of fiscal year 2018, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000080:mdna:55]
[same as prior period, unchanged from 0001045810-17-000172:mdna:62]

[0001045810-18-000080:mdna:56]
Sales, general and administrative expenses increased by 25% during the first quarter of fiscal year 2019, compared to the first quarter of fiscal year 2018, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000080:mdna:57]
[same as prior period, unchanged from 0001045810-17-000172:mdna:67]

[0001045810-18-000080:mdna:58]
[same as prior period, unchanged from 0001045810-17-000172:mdna:68]

[0001045810-18-000080:mdna:59]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $25 million and $16 million during the first quarter of fiscal years 2019 and 2018, respectively. The increase in interest income

[0001045810-18-000080:mdna:60]
was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-18-000080:mdna:61]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016, and the 1.00% Convertible Notes Due 2018, or the Convertible Notes, issued in December 2013. Interest expense was $15 million and $16 million during the first quarter of fiscal years 2019 and 2018, respectively.

[0001045810-18-000080:mdna:62]
[same as prior period, unchanged from 0001045810-17-000172:mdna:71]

[0001045810-18-000080:mdna:63]
Other, net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, realized and unrealized gains and losses from non-affiliated investments, losses on early debt conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Other, net, was not significant during the first quarter of fiscal year 2019. Other, net, was an expense of $18 million during the first quarter of fiscal year 2018, consisting primarily of $14 million of losses recognized from early conversions of the Convertible Notes.

[0001045810-18-000080:mdna:64]
[same as prior period, unchanged from 0001045810-17-000172:mdna:73]

[0001045810-18-000080:mdna:65]
We recognized income tax expense of $67 million and $29 million for the first quarter of fiscal years 2019 and 2018, respectively. Income tax expense as a percentage of income before income tax was 5.1% and 5.5% for the first quarter of fiscal years 2019 and 2018, respectively.

[0001045810-18-000080:mdna:66]
The decrease in our effective tax rate in the first quarter of fiscal year 2019 as compared to the same period in the prior fiscal year is primarily due to a decrease in the U.S. statutory tax rate from 35% to 21%, partially offset by a decrease in the impact of tax benefits from stock-based compensation.

[0001045810-18-000080:mdna:67]
Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-18-000080:mdna:68]
[same as prior period, unchanged from 0001045810-17-000172:mdna:77]

[0001045810-18-000080:mdna:69]
|  | April 29, 2018 |  | January 28, 2018 |
|  | (In millions) |
| Cash and cash equivalents | $ | 765 |  |  | $ | 4,002 |  |
| Marketable securities | 6,535 |  |  | 3,106 |  |
| Cash, cash equivalents and marketable securities | $ | 7,300 |  |  | $ | 7,108 |  |

[0001045810-18-000080:mdna:70]
|  | Three Months Ended |
|  | April 29, 2018 |  | April 30, 2017 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,445 |  |  | $ | 282 |  |
| Net cash provided by (used in) investing activities | $ | (3,551 | ) |  | $ | 754 |  |
| Net cash used in financing activities | $ | (1,131 | ) |  | $ | (813 | ) |

[0001045810-18-000080:mdna:71]
As of April 29, 2018, we had $7.30 billion in cash, cash equivalents and marketable securities, an increase of $192 million from the end of fiscal year 2018. Our portfolio of cash equivalents and marketable securities is managed both internally as well as on our behalf by several financial institutions. Our portfolio managers are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-18-000080:mdna:72]
Cash provided by operating activities increased in the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018, primarily due to higher net income and changes in working capital.

[0001045810-18-000080:mdna:73]
Cash used in investing activities increased in the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018, primarily due to higher purchases of marketable securities and lower sales of marketable securities.

[0001045810-18-000080:mdna:74]
Cash used in financing activities increased in the first quarter of fiscal year 2019 compared to the first quarter of fiscal year 2018, primarily due to share repurchases and higher tax payments related to employee stock plans, partially offset by lower repayments of Convertible Notes.

[0001045810-18-000080:mdna:75]
[same as prior period, unchanged from 0001045810-17-000172:mdna:40]

[0001045810-18-000080:mdna:76]
[same as prior period, unchanged from 0001045810-17-000172:mdna:84]

[0001045810-18-000080:mdna:77]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of April 29, 2018 and January 28, 2018, we had $7.30 billion and $7.11 billion, respectively, in cash, cash equivalents and marketable securities. Our marketable securities consist of debt securities issued by the United States government and its agencies, highly rated corporations and financial institutions, asset-backed issuers, mortgage-backed securities by government-sponsored enterprises, and foreign government entities. These marketable securities are denominated in United States dollars. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000080:mdna:78]
As a result of the Tax Cuts and Job Acts that was signed into law in December 2017, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of April 29, 2018 are available for use in the U.S. without incurring additional U.S. federal income taxes. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000080:mdna:79]
[same as prior period, unchanged from 0001045810-17-000172:mdna:88]

[0001045810-18-000080:mdna:80]
During the first quarter of fiscal year 2019, we repurchased a total of 3 million shares for $655 million and paid $91 million in cash dividends to our shareholders.

[0001045810-18-000080:mdna:81]
For fiscal year 2019, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases.

[0001045810-18-000080:mdna:82]
Our cash dividend program and the payment of future cash dividends under that program are subject to our Board's continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders. Refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000080:mdna:83]
Notes Due 2021 and Notes Due 2026

[0001045810-18-000080:mdna:84]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026, collectively, the Notes. The net proceeds from the Notes were $1.98 billion, after deducting debt discounts and issuance costs.

[0001045810-18-000080:mdna:85]
[same as prior period, unchanged from 0001045810-17-000172:mdna:92]

[0001045810-18-000080:mdna:86]
As of April 29, 2018, we had $14 million of Convertible Notes outstanding. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-18-000080:mdna:87]
Revolving Credit Facility

[0001045810-18-000080:mdna:88]
In fiscal year 2017, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021. The Credit Agreement also permits us to obtain additional revolving loan commitments and/or commitments to issue letters of credit of up to $425 million, subject to certain conditions. As of April 29, 2018, there were no amounts outstanding.

[0001045810-18-000080:mdna:89]
Commercial Paper

[0001045810-18-000080:mdna:90]
In fiscal year 2018, we established a commercial paper program to support general corporate purposes. Under the program, we can issue up to $575 million in commercial paper. As of April 29, 2018, there was no commercial paper outstanding.

[0001045810-18-000080:mdna:91]
[same as prior period, unchanged from 0001045810-17-000172:mdna:95]

[0001045810-18-000080:mdna:92]
In the second quarter of fiscal 2019, we intend to begin construction on a 750,000 square foot building on our Santa Clara campus. We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating requirements for at least the next twelve months.

[0001045810-18-000080:mdna:93]
[same as prior period, unchanged from 0001045810-17-000172:mdna:97]

[0001045810-18-000080:mdna:94]
As of April 29, 2018, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-18-000080:mdna:95]
[same as prior period, unchanged from 0001045810-17-000172:mdna:99]

[0001045810-18-000080:mdna:96]
There were no material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018.

[0001045810-18-000080:mdna:97]
Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 28, 2018 for a description of our contractual obligations.

[0001045810-18-000080:mdna:98]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000080:mdna:99]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
