# NVDA 8-K — 0001045810-22-000073 filed 2022-05-25

## item codes, every 8-K on or before 2022-05-27

- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2022-05-27

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-22-000073:8k_2_02:1]
EX-99.1
2
q1fy23pr.htm
Q1FY23 PRESS RELEASE

[0001045810-22-000073:8k_2_02:2]
Document

[0001045810-22-000073:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-22-000073:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2023

[0001045810-22-000073:8k_2_02:5]
•Record quarterly revenue of $8.29 billion, up 46% from a year ago

[0001045810-22-000073:8k_2_02:6]
•Record quarterly revenue for Data Center and Gaming

[0001045810-22-000073:8k_2_02:7]
SANTA CLARA, Calif.-May 25, 2022- NVIDIA (NASDAQ: NVDA) today reported record revenue for the first quarter ended May 1, 2022, of $8.29 billion, up 46% from a year ago and up 8% from the previous quarter, with record revenue in Data Center and Gaming.

[0001045810-22-000073:8k_2_02:8]
GAAP earnings per diluted share for the quarter were $0.64, down 16% from a year ago and down 46% from the previous quarter, and include an after-tax impact of $0.52 related to the $1.35 billion Arm acquisition termination charge. Non-GAAP earnings per diluted share were $1.36, up 49% from a year ago and up 3% from the previous quarter.

[0001045810-22-000073:8k_2_02:9]
“We delivered record results in Data Center and Gaming against the backdrop of a challenging macro environment,” said Jensen Huang, founder and CEO of NVIDIA. “The effectiveness of deep learning to automate intelligence is driving companies across industries to adopt NVIDIA for AI computing. Data Center has become our largest platform, even as Gaming achieved a record quarter.

[0001045810-22-000073:8k_2_02:10]
“We are gearing up for the largest wave of new products in our history with new GPU, CPU, DPU and robotics processors ramping in the second half. Our new chips and systems will greatly advance AI, graphics, Omniverse, self-driving cars and robotics, as well as the many industries these technologies impact,” he said.

[0001045810-22-000073:8k_2_02:11]
During the first quarter of fiscal 2023, NVIDIA returned to shareholders $2.10 billion in share repurchases and cash dividends.

[0001045810-22-000073:8k_2_02:12]
On May 23, 2022, the board of directors increased and extended the company’s share repurchase program to repurchase additional common stock up to a total of $15 billion through December 2023.

[0001045810-22-000073:8k_2_02:13]
NVIDIA will pay its next quarterly cash dividend of $0.04 per share on July 1, 2022, to all shareholders of record on June 9, 2022.

[0001045810-22-000073:8k_2_02:14]
Q1 Fiscal 2023 Summary

[0001045810-22-000073:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY23 | Q4 FY22 | Q1 FY22 | Q/Q | Y/Y |
| Revenue | $8,288 | $7,643 | $5,661 | Up 8% | Up 46% |
| Gross margin | 65.5 | % | 65.4 | % | 64.1 | % | Up 10 bps | Up 140 bps |
| Operating expenses | $3,563 | $2,029 | $1,673 | Up 76% | Up 113% |
| Operating income | $1,868 | $2,970 | $1,956 | Down 37% | Down 4% |
| Net income | $1,618 | $3,003 | $1,912 | Down 46% | Down 15% |
| Diluted earnings per share | $0.64 | $1.18 | $0.76 | Down 46% | Down 16% |

[0001045810-22-000073:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY23 | Q4 FY22 | Q1 FY22 | Q/Q | Y/Y |
| Revenue | $8,288 | $7,643 | $5,661 | Up 8% | Up 46% |
| Gross margin | 67.1 | % | 67.0 | % | 66.2 | % | Up 10 bps | Up 90 bps |
| Operating expenses | $1,608 | $1,447 | $1,189 | Up 11% | Up 35% |
| Operating income | $3,955 | $3,677 | $2,557 | Up 8% | Up 55% |
| Net income | $3,443 | $3,350 | $2,313 | Up 3% | Up 49% |
| Diluted earnings per share | $1.36 | $1.32 | $0.91 | Up 3% | Up 49% |

[0001045810-22-000073:8k_2_02:17]
Outlook

[0001045810-22-000073:8k_2_02:18]
NVIDIA’s outlook for the second quarter of fiscal 2023 is as follows:

[0001045810-22-000073:8k_2_02:19]
•Revenue is expected to be $8.10 billion, plus or minus 2%. This includes an estimated reduction of approximately $500 million relating to Russia and the COVID lockdowns in China.

[0001045810-22-000073:8k_2_02:20]
•GAAP and non-GAAP gross margins are expected to be 65.1% and 67.1%, respectively, plus or minus 50 basis points.

[0001045810-22-000073:8k_2_02:21]
•GAAP and non-GAAP operating expenses are expected to be approximately $2.46 billion and $1.75 billion, respectively.

[0001045810-22-000073:8k_2_02:22]
•GAAP and non-GAAP other income and expense are expected to be an expense of approximately $40 million, excluding gains and losses from non-affiliated investments.

[0001045810-22-000073:8k_2_02:23]
•GAAP and non-GAAP tax rates are expected to be 12.5%, plus or minus 1%, excluding any discrete items.

[0001045810-22-000073:8k_2_02:24]
Highlights

[0001045810-22-000073:8k_2_02:25]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-22-000073:8k_2_02:26]
Data Center

[0001045810-22-000073:8k_2_02:27]
•First-quarter revenue was a record $3.75 billion, up 83% from a year ago and up 15% from the previous quarter.

[0001045810-22-000073:8k_2_02:28]
•Announced the NVIDIA Hopper™ GPU architecture, delivering an order of magnitude performance leap over its predecessor; the NVIDIA® H100 Tensor Core GPU, the first Hopper-based GPU, featuring 80 billion transistors; and the NVIDIA DGX™ H100 system, the fourth generation of this purpose-built AI infrastructure.

[0001045810-22-000073:8k_2_02:29]
•Announced the Arm®-based NVIDIA Grace™ CPU Superchip with two CPU chips connected coherently over NVLink®-C2C, a new high-speed, low-latency chip-to-chip interconnect.

[0001045810-22-000073:8k_2_02:30]
•Announced that Taiwan’s leading computer makers are set to release the first wave of systems powered by NVIDIA’s Grace Hopper and Grace CPU Superchips, on track to launch in the first half of 2023.

[0001045810-22-000073:8k_2_02:31]
•Unveiled NVIDIA Spectrum™-4, the world’s first 400Gbps end-to-end networking platform, enabling the extreme performance and robust security needed for data center infrastructure at scale.

[0001045810-22-000073:8k_2_02:32]
•Announced major updates to NVIDIA AI — which includes enterprise-ready software for advancing speech, recommender systems, hyperscale inference and more — as well as the new NVIDIA AI Accelerated program, to help ensure performance and reliability of AI applications from NVIDIA’s partners.

[0001045810-22-000073:8k_2_02:33]
•Announced NVIDIA OVX™ — a dedicated, scalable server reference design for creating industrial digital twins in Omniverse — combining high-performance GPU-accelerated compute, graphics and AI with high-speed storage access, low-latency networking and precision timing.

[0001045810-22-000073:8k_2_02:34]
•Unveiled 60+ updates to the NVIDIA CUDA-X™ collection of libraries, tools and technologies across a broad range of disciplines.

[0001045810-22-000073:8k_2_02:35]
•Unveiled NVIDIA Clara™ Holoscan MGX, a platform for the medical-device industry to develop and deploy real-time AI applications at the edge, designed to meet required regulatory standards.

[0001045810-22-000073:8k_2_02:36]
•Collaborated with Microsoft Azure to preview a scaled virtualized cloud offering using NVIDIA vGPU software and the NVIDIA A10 Tensor Core GPU.

[0001045810-22-000073:8k_2_02:37]
•Announced a strategic collaboration with The Kroger Co. to reimagine the shopping experience using AI-enabled applications and services.

[0001045810-22-000073:8k_2_02:38]
•Teamed with UF Health, the University of Florida’s academic health center, to develop a neural network that generates synthetic clinical data.

[0001045810-22-000073:8k_2_02:39]
Gaming

[0001045810-22-000073:8k_2_02:40]
•First-quarter revenue was a record $3.62 billion, up 31% from a year ago and up 6% from the previous quarter.

[0001045810-22-000073:8k_2_02:41]
•Introduced the GeForce RTX® 3090 Ti, the fastest-ever consumer GPU.

[0001045810-22-000073:8k_2_02:42]
•Announced 15 new game titles optimized for NVIDIA RTX — including Dying Light 2 Stay Human, Ghostwire: Tokyo and Shadow Warrior 3 — bringing the total to over 250 games and applications.

[0001045810-22-000073:8k_2_02:43]
•Announced that gamers can now access RTX 3080-class streaming with GeForce NOW™ monthly subscription plans.

[0001045810-22-000073:8k_2_02:44]
•Expanded the GeForce NOW library with over 100 games — including Lost Ark, Need for Speed: Heat and Life is Strange: Remastered — bringing the total to over 1,300.

[0001045810-22-000073:8k_2_02:45]
•Launched Fortnite on GeForce NOW with touch controls for mobile devices, streaming through the Safari web browser on iOS and the GeForce NOW Android app.

[0001045810-22-000073:8k_2_02:46]
Professional Visualization

[0001045810-22-000073:8k_2_02:47]
•First-quarter revenue was $622 million, up 67% from a year ago and down 3% from the previous quarter.

[0001045810-22-000073:8k_2_02:48]
•Added new NVIDIA Ampere architecture RTX GPUs for workstations, widening access to AI and ray-tracing technology.

[0001045810-22-000073:8k_2_02:49]
•Announced the Omniverse Cloud service for instant access to NVIDIA Omniverse™ — including by millions of Mac and Chromebook users — enabling the collaborative editing of large 3D scenes from anywhere when available next year.

[0001045810-22-000073:8k_2_02:50]
•Announced that Amazon Robotics is building AI-enabled digital twins of its warehouses, using Omniverse Enterprise, to optimize warehouse design and train more intelligent robotic solutions.

[0001045810-22-000073:8k_2_02:51]
Automotive and Robotics

[0001045810-22-000073:8k_2_02:52]
•First-quarter Automotive revenue was $138 million, down 10% from a year ago and up 10% from the previous quarter.

[0001045810-22-000073:8k_2_02:53]
•Started production of the NVIDIA DRIVE Orin™ autonomous vehicle computer, which has been chosen by over 35 automakers.

[0001045810-22-000073:8k_2_02:54]
•Announced wins with Lucid Motors and BYD, bringing its automotive design-win pipeline to over $11 billion over the next six years.

[0001045810-22-000073:8k_2_02:55]
•Introduced NVIDIA DRIVE™ Map, a multimodal mapping platform — based in part on DeepMap survey mapping technology — designed to enable the highest levels of autonomy while improving safety.

[0001045810-22-000073:8k_2_02:56]
•Set records in AI inference with NVIDIA Orin in its MLPerf benchmark debut, running up to 5x faster than its predecessor with an average of 2x better energy efficiency.

[0001045810-22-000073:8k_2_02:57]
•Announced availability of the NVIDIA Jetson™ AGX Orin developer kit, with production modules shipping in July, and Isaac Nova Orin, a state-of-the-art AI compute and sensor reference platform built to accelerate development of autonomous mobile robots.

[0001045810-22-000073:8k_2_02:58]
CFO Commentary

[0001045810-22-000073:8k_2_02:59]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-22-000073:8k_2_02:60]
Conference Call and Webcast Information

[0001045810-22-000073:8k_2_02:61]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2023 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2023.

[0001045810-22-000073:8k_2_02:62]
Non-GAAP Measures

[0001045810-22-000073:8k_2_02:63]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition termination costs, stock-based compensation expense, acquisition-related and other costs, IP-related costs, legal settlement costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, the associated tax impact of these items where applicable, domestication tax benefit, and foreign tax benefit. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-22-000073:8k_2_02:64]
About NVIDIA

[0001045810-22-000073:8k_2_02:65]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market and has redefined modern computer graphics, high performance computing and artificial intelligence. The company’s pioneering work in accelerated computing and AI is reshaping trillion-dollar industries, such as transportation, healthcare and manufacturing, and fueling the growth of many others. More information at https://nvidianews.nvidia.com/.

[0001045810-22-000073:8k_2_02:66]
###

[0001045810-22-000073:8k_2_02:67]
For further information, contact:

[0001045810-22-000073:8k_2_02:68]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-22-000073:8k_2_02:69]
Certain statements in this press release including, but not limited to, statements as to: the effectiveness of deep learning to automate intelligence driving companies across industries to adopt NVIDIA for AI computing; the largest wave of new products in our history with new GPU, CPU, DPU, and robotics processors ramping in the second half; our new chips and systems to advance AI, graphics, Omniverse, self-driving cars, and robotics, as well as the many industries these technologies impact; the benefits, performance, impact, and abilities of our products and technologies, including NVIDIA Hopper GPU architecture, NVIDIA H100 Tensor Core GPU, NVIDIA DGX H100 system, Arm-based NVIDIA Grace CPU Superchip, NVLink, NVIDIA Spectrum-4, the updated NVIDIA AI, the new NVIDIA AI Accelerated program, NVIDIA OVX, the NVIDIA CUDA-X collection, NVIDIA Clara Holoscan MGX,  NVIDIA vGPU software, NVIDIA A10 Tensor Core GPU, GeForce RTX 3090 Ti, NVIDIA RTX, GeForce NOW, NVIDIA Ampere architecture RTX GPUs, Omniverse Cloud, Omniverse Enterprise, the NVIDIA DRIVE Orin autonomous vehicle computer, NVIDIA DRIVE Map, NVIDIA Orin, NVIDIA Jetson AGX Orin, and Isaac Nova Orin; the release by Taiwan’s leading computer makers of the first wave of systems powered by NVIDIA’s Grace Hopper and Grace CPU Superchips; the collaboration with Microsoft Azure to preview a scaled virtualized cloud offering using NVIDIA vGPU software and the NVIDIA A10 Tensor Core GPU; the strategic collaboration with The Kroger Co.; our teaming with UF Health, the University of Florida’s academic health center, to develop a neural network that generates synthetic clinical data; NVIDIA’s share repurchase program; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the second quarter of fiscal 2023, including the estimated impact on revenue relating to Russia and the COVID lockdowns in China; and NVIDIA’s expected tax rates for the second quarter of fiscal 2023 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-22-000073:8k_2_02:70]
© 2022 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, GeForce RTX, NVIDIA Clara, NVIDIA CUDA-X, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE Orin, NVIDIA Grace, NVIDIA Hopper, NVIDIA Isaac, NVIDIA Jetson, NVIDIA Omniverse, NVIDIA OVX, NVIDIA Spectrum and NVLink are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000073:8k_2_02:71]
NVIDIA CORPORATION

[0001045810-22-000073:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-22-000073:8k_2_02:73]
(In millions, except per share data)

[0001045810-22-000073:8k_2_02:74]
(Unaudited)

[0001045810-22-000073:8k_2_02:75]
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 1, |  | May 2, |  |  |  |  |
|  |  |  | 2022 |  | 2021 |  |  |  |  |
| Revenue | $ | 8,288 |  |  | $ | 5,661 |  |  |  |  |  |
| Cost of revenue | 2,857 |  |  | 2,032 |  |  |  |  |  |
| Gross profit | 5,431 |  |  | 3,629 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,618 |  |  | 1,153 |  |  |  |  |  |
|  | Sales, general and administrative | 592 |  |  | 520 |  |  |  |  |  |
|  | Acquisition termination cost | 1,353 |  |  | — |  |  |  |  |  |
|  |  | Total operating expenses | 3,563 |  |  | 1,673 |  |  |  |  |  |
| Income from operations | 1,868 |  |  | 1,956 |  |  |  |  |  |
|  | Interest income | 18 |  |  | 6 |  |  |  |  |  |
|  | Interest expense | (68) |  |  | (53) |  |  |  |  |  |
|  | Other, net | (13) |  |  | 135 |  |  |  |  |  |
|  |  | Other income (expense), net | (63) |  |  | 88 |  |  |  |  |  |
| Income before income tax | 1,805 |  |  | 2,044 |  |  |  |  |  |
| Income tax expense | 187 |  |  | 132 |  |  |  |  |  |
| Net income | $ | 1,618 |  |  | $ | 1,912 |  |  |  |  |  |
| Net income per share (A): |  |  |  |  |  |  |  |
|  | Basic | $ | 0.65 |  |  | $ | 0.77 |  |  |  |  |  |
|  | Diluted | $ | 0.64 |  |  | $ | 0.76 |  |  |  |  |  |
| Weighted average shares used in per share computation (A): |  |  |  |  |  |  |  |
|  | Basic | 2,506 |  |  | 2,484 |  |  |  |  |  |
|  | Diluted | 2,537 |  |  | 2,528 |  |  |  |  |  |

[0001045810-22-000073:8k_2_02:76]
(A) Reflects a four-for-one stock split on July 19, 2021.

[0001045810-22-000073:8k_2_02:77]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | May 1, |  | January 30, |
|  |  |  |  | 2022 |  | 2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 20,338 |  |  | $ | 21,208 |  |
|  | Accounts receivable, net |  | 5,438 |  |  | 4,650 |  |
|  | Inventories |  | 3,163 |  |  | 2,605 |  |
|  | Prepaid expenses and other current assets |  | 636 |  |  | 366 |  |
|  |  | Total current assets |  | 29,575 |  |  | 28,829 |  |
| Property and equipment, net |  | 2,916 |  |  | 2,778 |  |
| Operating lease assets |  | 856 |  |  | 829 |  |
| Goodwill |  | 4,365 |  |  | 4,349 |  |
| Intangible assets, net |  | 2,211 |  |  | 2,339 |  |
| Deferred income tax assets |  | 1,784 |  |  | 1,222 |  |
| Other assets |  | 3,505 |  |  | 3,841 |  |
|  |  | Total assets |  | $ | 45,212 |  |  | $ | 44,187 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,999 |  |  | $ | 1,783 |  |
|  | Accrued and other current liabilities |  | 3,563 |  |  | 2,552 |  |
|  |  | Total current liabilities |  | 5,562 |  |  | 4,335 |  |
| Long-term debt |  | 10,947 |  |  | 10,946 |  |
| Long-term operating lease liabilities |  | 752 |  |  | 741 |  |
| Other long-term liabilities |  | 1,631 |  |  | 1,553 |  |
|  |  | Total liabilities |  | 18,892 |  |  | 17,575 |  |
| Shareholders' equity |  | 26,320 |  |  | 26,612 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 45,212 |  |  | $ | 44,187 |  |

[0001045810-22-000073:8k_2_02:78]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | May 1, |  | May 2, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,618 |  |  | $ | 1,912 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Acquisition termination cost | 1,353 |  |  | — |  |  |  |  |  |
| Stock-based compensation expense | 578 |  |  | 429 |  |  |  |  |  |
| Depreciation and amortization | 334 |  |  | 281 |  |  |  |  |  |
| Losses (gains) on investments in non affiliates, net | 17 |  |  | (133) |  |  |  |  |  |
| Deferred income taxes | (542) |  |  | 24 |  |  |  |  |  |
| Other | 23 |  |  | (3) |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (788) |  |  | (595) |  |  |  |  |  |
| Inventories | (560) |  |  | (159) |  |  |  |  |  |
| Prepaid expenses and other assets | (1,261) |  |  | 2 |  |  |  |  |  |
| Accounts payable | 255 |  |  | 36 |  |  |  |  |  |
| Accrued and other current liabilities | 634 |  |  | 33 |  |  |  |  |  |
| Other long-term liabilities | 70 |  |  | 47 |  |  |  |  |  |
| Net cash provided by operating activities | 1,731 |  |  | 1,874 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 5,947 |  |  | 3,140 |  |  |  |  |  |
| Proceeds from sales of marketable securities | 1,029 |  |  | 358 |  |  |  |  |  |
| Purchases of marketable securities | (3,932) |  |  | (4,470) |  |  |  |  |  |
| Purchases related to property and equipment and intangible assets | (361) |  |  | (298) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (36) |  |  | — |  |  |  |  |  |
| Investments and other, net | (35) |  |  | (2) |  |  |  |  |  |
| Net cash provided by (used in) investing activities | 2,612 |  |  | (1,272) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 204 |  |  | 126 |  |  |  |  |  |
| Payments related to repurchases of common stock | (1,996) |  |  | — |  |  |  |  |  |
| Payments related to tax on restricted stock units | (532) |  |  | (477) |  |  |  |  |  |
| Dividends paid | (100) |  |  | (99) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (22) |  |  | (19) |  |  |  |  |  |
| Other | — |  |  | (2) |  |  |  |  |  |
| Net cash used in financing activities | (2,446) |  |  | (471) |  |  |  |  |  |
| Change in cash and cash equivalents | 1,897 |  |  | 131 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 1,990 |  |  | 847 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 3,887 |  |  | $ | 978 |  |  |  |  |  |

[0001045810-22-000073:8k_2_02:79]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 1, |  | January 30, |  | May 2, |  |  |  |  |
|  |  |  | 2022 |  | 2022 |  | 2021 |  |  |  |  |
| GAAP gross profit |  | $ | 5,431 |  |  | $ | 4,999 |  |  | $ | 3,629 |  |  |  |  |  |
| GAAP gross margin |  | 65.5 | % |  | 65.4 | % |  | 64.1 | % |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | 94 |  |  | 86 |  |  | 87 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | 38 |  |  | 39 |  |  | 25 |  |  |  |  |  |
|  | IP-related costs |  | — |  |  | — |  |  | 5 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 5,563 |  |  | $ | 5,124 |  |  | $ | 3,746 |  |  |  |  |  |
| Non-GAAP gross margin |  | 67.1 | % |  | 67.0 | % |  | 66.2 | % |  |  |  |  |
| GAAP operating expenses |  | $ | 3,563 |  |  | $ | 2,029 |  |  | $ | 1,673 |  |  |  |  |  |
|  | Acquisition termination cost |  | (1,353) |  |  | — |  |  | — |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | (540) |  |  | (512) |  |  | (404) |  |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | (55) |  |  | (70) |  |  | (80) |  |  |  |  |  |
|  | Legal settlement costs |  | (7) |  |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 1,608 |  |  | $ | 1,447 |  |  | $ | 1,189 |  |  |  |  |  |
| GAAP income from operations |  | $ | 1,868 |  |  | $ | 2,970 |  |  | $ | 1,956 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 2,087 |  |  | 707 |  |  | 601 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 3,955 |  |  | $ | 3,677 |  |  | $ | 2,557 |  |  |  |  |  |
| GAAP other income (expense), net |  | $ | (63) |  |  | $ | (105) |  |  | $ | 88 |  |  |  |  |  |
|  | Losses (gains) from non-affiliated investments |  | 17 |  |  | 53 |  |  | (134) |  |  |  |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | — |  |  | 1 |  |  |  |  |  |
| Non-GAAP other income (expense), net |  | $ | (45) |  |  | $ | (52) |  |  | $ | (45) |  |  |  |  |  |
| GAAP net income |  | $ | 1,618 |  |  | $ | 3,003 |  |  | $ | 1,912 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 2,105 |  |  | 760 |  |  | 468 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (280) |  |  | (330) |  |  | (67) |  |  |  |  |  |
|  | Domestication tax adjustments |  | — |  |  | 7 |  |  | — |  |  |  |  |  |
|  | Foreign tax benefit |  | — |  |  | (90) |  |  | — |  |  |  |  |  |
| Non-GAAP net income |  | $ | 3,443 |  |  | $ | 3,350 |  |  | $ | 2,313 |  |  |  |  |  |

[0001045810-22-000073:8k_2_02:80]
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 1, |  | January 30, |  | May 2, |  |  |  |  |
|  |  |  | 2022 |  | 2022 |  | 2021 |  |  |  |  |
| Diluted net income per share (D) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.64 |  |  | $ | 1.18 |  |  | $ | 0.76 |  |  |  |  |  |
|  | Non-GAAP |  | $ | 1.36 |  |  | $ | 1.32 |  |  | $ | 0.91 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation (D) |  | 2,537 |  |  | 2,545 |  |  | 2,528 |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 1,731 |  |  | $ | 3,033 |  |  | $ | 1,874 |  |  |  |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (361) |  |  | (273) |  |  | (298) |  |  |  |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (22) |  |  | (21) |  |  | (19) |  |  |  |  |  |
| Free cash flow |  | $ | 1,348 |  |  | $ | 2,739 |  |  | $ | 1,557 |  |  |  |  |  |

[0001045810-22-000073:8k_2_02:81]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs and certain compensation charges presented in the following line items: |  |  |  |
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 1, |  | January 30, |  | May 2, |  |  |  |  |
|  |  |  | 2022 |  | 2022 |  | 2021 |  |  |  |  |
|  | Cost of revenue |  | $ | 94 |  |  | $ | 86 |  |  | $ | 87 |  |  |  |  |  |
|  | Research and development |  | $ | 9 |  |  | $ | 9 |  |  | $ | 1 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 46 |  |  | $ | 61 |  |  | $ | 79 |  |  |  |  |  |
| (B) Stock-based compensation consists of the following: |  |  |  |
|  |  |  | Three Months Ended |  |  |
|  |  |  | May 1, |  | January 30, |  | May 2, |  |  |  |  |
|  |  |  | 2022 |  | 2022 |  | 2021 |  |  |  |  |
|  | Cost of revenue |  | $ | 38 |  |  | $ | 39 |  |  | $ | 25 |  |  |  |  |  |
|  | Research and development |  | $ | 384 |  |  | $ | 362 |  |  | $ | 276 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 156 |  |  | $ | 150 |  |  | $ | 128 |  |  |  |  |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |  |  |
| (D) Reflects a four-for-one stock split on July 19, 2021. |  |  |  |

[0001045810-22-000073:8k_2_02:82]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2023 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 65.1 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 2.0 | % |
| Non-GAAP gross margin |  | 67.1 | % |
| GAAP operating expenses |  | $ | 2,460 |  |
|  | Stock-based compensation expense and acquisition-related costs | (710) |  |
| Non-GAAP operating expenses |  | $ | 1,750 |  |
