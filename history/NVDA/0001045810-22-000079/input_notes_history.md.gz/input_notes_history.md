# NVDA note change history — 0001045810-21-000163 → 0001045810-22-000079


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-27):
[0001045810-22-000079:note_history:1]
We have entered into several long-term supply agreements, under which we have made advance payments and have $1.02 billion remaining unpaid. As of May 1, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.59 billion, inclusive of the $1.02 billion. We also had other purchase obligations totaling $1.85 billion.
  (was, 2021-11-22, similarity 0.7982):
[0001045810-21-000163:note_history:1]
We recently entered into several long-term supply agreements, under which we have made advance payments and have $1.79 billion remaining unpaid. As of October 31, 2021, we had outstanding inventory purchase and long-term supply obligations totaling $6.90 billion, inclusive of the $1.79 billion, and other purchase obligations totaling $935 million.

- changed (2022-05-27):
[0001045810-22-000079:note_history:2]
Total future unconditional purchase commitments as of May 1, 2022, are as follows:
  (was, 2021-11-22, similarity 0.9367):
[0001045810-21-000163:note_history:2]
Total future unconditional purchase commitments as of October 31, 2021, are as follows:

- changed (2022-05-27):
[0001045810-22-000079:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first quarter of fiscal year 2023) | $ | 8,344 |  |
| 2024 | 2,238 |  |
| 2025 | 406 |  |
| 2026 | 48 |  |
| 2027 | 70 |  |
| 2028 and thereafter | 330 |  |
| Total | $ | 11,436 |  |
  (was, 2021-11-22, similarity 0.8917):
[0001045810-21-000163:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 (excluding first nine months of fiscal year 2022) | $ | 2,944 |  |
| 2023 | 4,637 |  |
| 2024 | 172 |  |
| 2025 | 52 |  |
| 2026 | 28 |  |
| Total | $ | 7,833 |  |

- changed (2022-05-27):
[0001045810-22-000079:note_history:4]
The estimated amount of product warranty liabilities was $55 million and $46 million as of May 1, 2022 and January 30, 2022, respectively, and the activities were not significant.
  (was, 2021-11-22, similarity 0.9704):
[0001045810-21-000163:note_history:4]
The estimated amount of product warranty liabilities was $32 million and $22 million as of October 31, 2021 and January 31, 2021, respectively, and the activities were not significant.

- changed (2022-05-27):
[0001045810-22-000079:note_history:5]
With certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.
  (was, 2021-11-22, similarity 0.9864):
[0001045810-21-000163:note_history:5]
In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

- changed (2022-05-27):
[0001045810-22-000079:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.
  (was, 2021-11-22, similarity 0.9775):
[0001045810-21-000163:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On August 11, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604.

- changed (2022-05-27):
[0001045810-22-000079:note_history:7]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.
  (was, 2021-11-22, similarity 0.7125):
[0001045810-21-000163:note_history:7]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

- changed (2022-05-27):
[0001045810-22-000079:note_history:8]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2021-11-22, similarity 0.6618):
[0001045810-21-000163:note_history:8]
cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2022-05-27):
[0001045810-22-000079:note_history:9]
Settlement

- added (2022-05-27):
[0001045810-22-000079:note_history:10]
In May 2022, NVIDIA entered into a settlement with the SEC relating to MD&A disclosures in our Forms 10-Q for the second and third quarters of fiscal year 2018 concerning the impact of cryptocurrency mining on year-over-year growth in revenue for our gaming specialized market during those periods. As part of the settlement, without admitting or denying the findings in the administrative order issued by the SEC, NVIDIA agreed to cease-and-desist from violating certain federal securities laws and paid a $5.5 million civil penalty.

- added (2022-05-27):
[0001045810-22-000079:note_history:11]
As of May 1, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2022-05-27):
[0001045810-21-000163:note_history:12]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-

- removed (2022-05-27):
[0001045810-21-000163:note_history:13]
As of October 31, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-05-27):
[0001045810-22-000079:note_history:14]
On July 19, 2021, we executed a four-for-one stock split of our common stock. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the stock split.

- added (2022-05-27):
[0001045810-22-000079:note_history:15]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The first quarters of fiscal years 2023 and 2022 were both 13-week quarters.

- removed (2022-05-27):
[0001045810-21-000163:note_history:16]
On May 21, 2021, our Board of Directors declared a four-for-one split of our common stock in the form of a stock dividend, or the Stock Split, which was conditioned upon obtaining stockholder approval to increase the number of our authorized shares of common stock from 2 billion to 4 billion. On June 3, 2021, at the 2021 Annual Meeting of Stockholders, our stockholders approved the amendment to our Amended and Restated Certificate of Incorporation to increase the number of authorized shares of common stock to 4 billion. As a result, each stockholder of record at the close of business on June 21, 2021 received a dividend of three additional shares of common stock for every share held on the record date, distributed after the close of trading on July 19, 2021. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the Stock Split.

- removed (2022-05-27):
[0001045810-21-000163:note_history:17]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2022 is a 52-week year and fiscal year 2021 was a 53-week year. The third quarters of fiscal years 2022 and 2021 were both 13-week quarters.

- removed (2022-05-27):
[0001045810-21-000163:note_history:18]
Use of Estimates

- removed (2022-05-27):
[0001045810-21-000163:note_history:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

- removed (2022-05-27):
[0001045810-21-000163:note_history:20]
Adoption of New and Recently Issued Accounting Pronouncement

- removed (2022-05-27):
[0001045810-21-000163:note_history:21]
Recently Adopted Accounting Pronouncement

- removed (2022-05-27):
[0001045810-21-000163:note_history:22]
In October 2021, the Financial Accounting Standards Board issued a new accounting standard to require that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers. We early adopted this accounting standard in the third quarter of fiscal year 2022 and the impact was immaterial.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-27):
[0001045810-22-000079:note_history:23]
The carrying values of our outstanding notes and their associated interest rates were as follows:
  (was, 2021-11-22, similarity 0.8939):
[0001045810-21-000163:note_history:23]
The carrying value of the Notes and the associated interest rates were as follows:

- changed (2022-05-27):
[0001045810-22-000079:note_history:24]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 1, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 1.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 2.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (53) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,947 |  |  | $ | 10,946 |  |
  (was, 2021-11-22, similarity 0.6288):
[0001045810-21-000163:note_history:24]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 31, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | — |  | 2.38% |  | $ | — |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.6 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.6 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 4.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.6 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.6 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (56) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 10,944 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,944 |  |  | $ | 5,964 |  |

- added (2022-05-27):
[0001045810-22-000079:note_history:25]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

- changed (2022-05-27):
[0001045810-22-000079:note_history:26]
As of May 1, 2022, we have complied with the required covenants under the notes.
  (was, 2021-11-22, similarity 0.8553):
[0001045810-21-000163:note_history:26]
As of October 31, 2021, we were in compliance with the required covenants under the Notes.

- changed (2022-05-27):
[0001045810-22-000079:note_history:27]
We have a $575 million commercial paper program to support general corporate purposes. As of May 1, 2022, we had not issued any commercial paper.
  (was, 2021-11-22, similarity 0.9643):
[0001045810-21-000163:note_history:27]
We have a $575 million commercial paper program to support general corporate purposes. As of October 31, 2021, we had not issued any commercial paper.

- removed (2022-05-27):
[0001045810-21-000163:note_history:28]
In June 2021, we issued $1.25 billion of the 0.309% Notes Due 2023, $1.25 billion of the 0.584% Notes Due 2024, $1.25 billion of the 1.55% Notes Due 2028, and $1.25 billion of the 2.00% Notes Due 2031, or collectively, the June 2021 Notes. Interest on the 0.584% Notes Due 2024 is payable on June 14 and December 14 of each year, beginning on

- removed (2022-05-27):
[0001045810-21-000163:note_history:29]
December 14, 2021. Interest on all other series of the June 2021 Notes is payable on June 15 and December 15 of each year, beginning on December 15, 2021. We may redeem the June 2021 Notes for cash prior to maturity. However, no make-whole premium will be paid for redemptions of the Notes Due 2023 on or after June 15, 2022, the Notes Due 2024 on or after June 14, 2023, the Notes Due 2028 on or after April 15, 2028, or the Notes Due 2031 on or after March 15, 2031. The net proceeds from the June 2021 Notes were $4.98 billion, after deducting debt discount and issuance costs.

- removed (2022-05-27):
[0001045810-21-000163:note_history:30]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year.

- removed (2022-05-27):
[0001045810-21-000163:note_history:31]
On August 16, 2021, we repaid the $1.00 billion of 2.20% Notes Due 2021. Interest on the $1.00 billion of the 3.20% Notes Due 2026, or September 2016 Notes, is payable on March 16 and September 16 of each year.

- removed (2022-05-27):
[0001045810-21-000163:note_history:32]
The September 2016 Notes, the March 2020 Notes, and the June 2021 Notes, or collectively, the Notes, are our unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-27):
[0001045810-22-000079:note_history:33]
The following is a summary of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022:
  (was, 2021-11-22, similarity 0.9524):
[0001045810-21-000163:note_history:33]
The following is a summary of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021:

- changed (2022-05-27):
[0001045810-22-000079:note_history:34]
|  | May 1, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,827 |  |  | $ | — |  |  | $ | (9) |  |  | $ | 9,818 |  |  | $ | 1,232 |  |  | $ | 8,586 |  |
| Debt securities issued by the United States Treasury | 6,157 |  |  | 3 |  |  | (38) |  |  | 6,122 |  |  | 1,324 |  |  | 4,798 |  |
| Debt securities issued by United States government agencies | 2,116 |  |  | — |  |  | — |  |  | 2,116 |  |  | 460 |  |  | 1,656 |  |
| Certificates of deposit | 1,302 |  |  | — |  |  | — |  |  | 1,302 |  |  | 41 |  |  | 1,261 |  |
| Money market funds | 419 |  |  | — |  |  | — |  |  | 419 |  |  | 419 |  |  | — |  |
| Foreign government bonds | 185 |  |  | — |  |  | — |  |  | 185 |  |  | 35 |  |  | 150 |  |
| Total | $ | 20,006 |  |  | $ | 3 |  |  | $ | (47) |  |  | $ | 19,962 |  |  | $ | 3,511 |  |  | $ | 16,451 |  |
  (was, 2021-11-22, similarity 0.9901):
[0001045810-21-000163:note_history:34]
|  | October 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,179 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 9,180 |  |  | $ | 135 |  |  | $ | 9,045 |  |
| Debt securities issued by the United States Treasury | 4,887 |  |  | — |  |  | (2) |  |  | 4,885 |  |  | 195 |  |  | 4,690 |  |
| Debt securities issued by United States government agencies | 2,861 |  |  | — |  |  | — |  |  | 2,861 |  |  | 307 |  |  | 2,554 |  |
| Certificates of deposit | 1,512 |  |  | — |  |  | — |  |  | 1,512 |  |  | 32 |  |  | 1,480 |  |
| Money market funds | 360 |  |  | — |  |  | — |  |  | 360 |  |  | 360 |  |  | — |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,040 |  |  | $ | 2 |  |  | $ | (3) |  |  | $ | 19,039 |  |  | $ | 1,029 |  |  | $ | 18,010 |  |

- added (2022-05-27):
[0001045810-22-000079:note_history:35]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

- added (2022-05-27):
[0001045810-22-000079:note_history:36]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022 are shown below by contractual maturity.

- added (2022-05-27):
[0001045810-22-000079:note_history:37]
|  | May 1, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,196 |  |  | $ | 15,185 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,810 |  |  | 4,777 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 20,006 |  |  | $ | 19,962 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2022-05-27):
[0001045810-21-000163:note_history:38]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-27):
[0001045810-22-000079:note_history:39]
The following is a summary of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022:
  (was, 2021-11-22, similarity 0.9524):
[0001045810-21-000163:note_history:39]
The following is a summary of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021:

- changed (2022-05-27):
[0001045810-22-000079:note_history:40]
|  | May 1, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,827 |  |  | $ | — |  |  | $ | (9) |  |  | $ | 9,818 |  |  | $ | 1,232 |  |  | $ | 8,586 |  |
| Debt securities issued by the United States Treasury | 6,157 |  |  | 3 |  |  | (38) |  |  | 6,122 |  |  | 1,324 |  |  | 4,798 |  |
| Debt securities issued by United States government agencies | 2,116 |  |  | — |  |  | — |  |  | 2,116 |  |  | 460 |  |  | 1,656 |  |
| Certificates of deposit | 1,302 |  |  | — |  |  | — |  |  | 1,302 |  |  | 41 |  |  | 1,261 |  |
| Money market funds | 419 |  |  | — |  |  | — |  |  | 419 |  |  | 419 |  |  | — |  |
| Foreign government bonds | 185 |  |  | — |  |  | — |  |  | 185 |  |  | 35 |  |  | 150 |  |
| Total | $ | 20,006 |  |  | $ | 3 |  |  | $ | (47) |  |  | $ | 19,962 |  |  | $ | 3,511 |  |  | $ | 16,451 |  |
  (was, 2021-11-22, similarity 0.9901):
[0001045810-21-000163:note_history:40]
|  | October 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,179 |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 9,180 |  |  | $ | 135 |  |  | $ | 9,045 |  |
| Debt securities issued by the United States Treasury | 4,887 |  |  | — |  |  | (2) |  |  | 4,885 |  |  | 195 |  |  | 4,690 |  |
| Debt securities issued by United States government agencies | 2,861 |  |  | — |  |  | — |  |  | 2,861 |  |  | 307 |  |  | 2,554 |  |
| Certificates of deposit | 1,512 |  |  | — |  |  | — |  |  | 1,512 |  |  | 32 |  |  | 1,480 |  |
| Money market funds | 360 |  |  | — |  |  | — |  |  | 360 |  |  | 360 |  |  | — |  |
| Foreign government bonds | 241 |  |  | — |  |  | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Total | $ | 19,040 |  |  | $ | 2 |  |  | $ | (3) |  |  | $ | 19,039 |  |  | $ | 1,029 |  |  | $ | 18,010 |  |

- added (2022-05-27):
[0001045810-22-000079:note_history:41]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

- added (2022-05-27):
[0001045810-22-000079:note_history:42]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

- added (2022-05-27):
[0001045810-22-000079:note_history:43]
|  | May 1, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 2,955 |  |  | $ | (38) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,955 |  |  | $ | (38) |  |
| Corporate debt securities | 2,594 |  |  | (9) |  |  | 19 |  |  | — |  |  | 2,613 |  |  | (9) |  |
| Total | $ | 5,549 |  |  | $ | (47) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 5,568 |  |  | $ | (47) |  |

- added (2022-05-27):
[0001045810-22-000079:note_history:44]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

- changed (2022-05-27):
[0001045810-22-000079:note_history:45]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and unrealized gains and losses were not significant for all periods presented.
  (was, 2021-11-22, similarity 0.6302):
[0001045810-21-000163:note_history:45]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

- changed (2022-05-27):
[0001045810-22-000079:note_history:46]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022 are shown below by contractual maturity.
  (was, 2021-11-22, similarity 0.9691):
[0001045810-21-000163:note_history:46]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 31, 2021 and January 31, 2021 are shown below by contractual maturity.

- added (2022-05-27):
[0001045810-22-000079:note_history:47]
|  | May 1, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,196 |  |  | $ | 15,185 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,810 |  |  | 4,777 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 20,006 |  |  | $ | 19,962 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |

- removed (2022-05-27):
[0001045810-21-000163:note_history:48]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

- removed (2022-05-27):
[0001045810-21-000163:note_history:49]
|  | October 31, 2021 |  | January 31, 2021 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 16,243 |  |  | $ | 16,244 |  |  | $ | 10,782 |  |  | $ | 10,783 |  |
| Due in 1 - 5 years | 2,797 |  |  | 2,795 |  |  | 566 |  |  | 568 |  |
| Total | $ | 19,040 |  |  | $ | 19,039 |  |  | $ | 11,348 |  |  | $ | 11,351 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-27):
[0001045810-22-000079:note_history:50]
The carrying values of our outstanding notes and their associated interest rates were as follows:
  (was, 2021-11-22, similarity 0.8939):
[0001045810-21-000163:note_history:50]
The carrying value of the Notes and the associated interest rates were as follows:

- changed (2022-05-27):
[0001045810-22-000079:note_history:51]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 1, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 1.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 2.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (53) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,947 |  |  | $ | 10,946 |  |
  (was, 2021-11-22, similarity 0.6288):
[0001045810-21-000163:note_history:51]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 31, 2021 |  | January 31, 2021 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | — |  | 2.38% |  | $ | — |  |  | $ | 1,000 |  |
| 0.309% Notes Due 2023 |  | 1.6 |  | 0.41% |  | 1,250 |  |  | — |  |
| 0.584% Notes Due 2024 |  | 2.6 |  | 0.66% |  | 1,250 |  |  | — |  |
| 3.20% Notes Due 2026 |  | 4.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.6 |  | 1.64% |  | 1,250 |  |  | — |  |
| 2.85% Notes Due 2030 |  | 8.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.6 |  | 2.09% |  | 1,250 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 18.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 28.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 38.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (56) |  |  | (37) |  |
| Net carrying amount |  |  |  |  |  | 10,944 |  |  | 6,963 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (999) |  |
| Total long-term portion |  |  |  |  |  | $ | 10,944 |  |  | $ | 5,964 |  |
