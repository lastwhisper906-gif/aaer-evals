# NVDA notes — 0001045810-22-000079


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-22-000079:notes:1]
[same as prior period, unchanged from 0001045810-21-000163:notes:1]

[0001045810-22-000079:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 30, 2022 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 30, 2022, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair statement of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 30, 2022.

[0001045810-22-000079:notes:3]
On July 19, 2021, we executed a four-for-one stock split of our common stock. All share, equity award, and per share amounts and related shareholders' equity balances presented herein have been retroactively adjusted to reflect the stock split.

[0001045810-22-000079:notes:4]
[same as prior period, unchanged from 0001045810-21-000163:notes:4]

[0001045810-22-000079:notes:5]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 30, 2022.

[0001045810-22-000079:notes:6]
[same as prior period, unchanged from 0001045810-21-000163:notes:6]

[0001045810-22-000079:notes:7]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2023 and 2022 are both 52-week years. The first quarters of fiscal years 2023 and 2022 were both 13-week quarters.

[0001045810-22-000079:notes:8]
[same as prior period, unchanged from 0001045810-21-000163:notes:8]

[0001045810-22-000079:notes:9]
[same as prior period, unchanged from 0001045810-21-000163:notes:9]

[0001045810-22-000079:notes:10]
[same as prior period, unchanged from 0001045810-21-000163:notes:10]

[0001045810-22-000079:notes:11]
[same as prior period, unchanged from 0001045810-21-000163:notes:11]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-22-000079:notes:12]
Business Combination
Termination of the Arm Share Purchase Agreement

[0001045810-22-000079:notes:13]
On February 8, 2022, NVIDIA and SoftBank Group Corp, or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing in September 2020.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-22-000079:notes:14]
Leases
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2023 and 2035.

[0001045810-22-000079:notes:15]
Future minimum lease payments under our non-cancelable operating leases as of May 1, 2022 are as follows:

[0001045810-22-000079:notes:16]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first quarter of fiscal year 2023) | $ | 121 |  |
| 2024 | 167 |  |
| 2025 | 144 |  |
| 2026 | 130 |  |
| 2027 | 119 |  |
| 2028 and thereafter | 318 |  |
| Total | 999 |  |
| Less imputed interest | 100 |  |
| Present value of net future minimum lease payments | 899 |  |
| Less short-term operating lease liabilities | 147 |  |
| Long-term operating lease liabilities | $ | 752 |  |

[0001045810-22-000079:notes:17]
In addition to our existing operating lease obligations, we have operating leases that are expected to commence between the second quarter of fiscal year 2023 and fiscal year 2024 with lease terms of 3 to 8 years for $755 million, consisting primarily of data center space.

[0001045810-22-000079:notes:18]
Operating lease expenses were $44 million and $39 million for the first quarter of fiscal years 2023 and 2022, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2023 and 2022 were not significant.

[0001045810-22-000079:notes:19]
[same as prior period, unchanged from 0001045810-21-000163:notes:33]

[0001045810-22-000079:notes:20]
|  | Three Months Ended |
|  | May 1, 2022 |  | May 2, 2021 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 45 |  |  | $ | 39 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 62 |  |  | $ | 54 |  |

[0001045810-22-000079:notes:21]
As of May 1, 2022, our operating leases had a weighted average remaining lease term of 7.2 years and a weighted average discount rate of 2.51%. As of January 30, 2022, our operating leases had a weighted average remaining lease term of 7.1 years and a weighted average discount rate of 2.51%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-22-000079:notes:22]
[same as prior period, unchanged from 0001045810-21-000163:notes:36]

[0001045810-22-000079:notes:23]
[same as prior period, unchanged from 0001045810-21-000163:notes:37]

[0001045810-22-000079:notes:24]
|  | Three Months Ended |  |  |
|  | May 1,2022 |  | May 2,2021 |  |  |  |  |
|  | (In millions) |
| Cost of revenue | $ | 38 |  |  | $ | 25 |  |  |  |  |  |
| Research and development | 384 |  |  | 276 |  |  |  |  |  |
| Sales, general and administrative | 156 |  |  | 128 |  |  |  |  |  |
| Total | $ | 578 |  |  | $ | 429 |  |  |  |  |  |

[0001045810-22-000079:notes:25]
[same as prior period, unchanged from 0001045810-21-000163:notes:39]

[0001045810-22-000079:notes:26]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-22-000079:notes:27]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |  |  |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  |  |  |  |
|  | (In millions, except per share data) |
| Balances, January 30, 2022 | 46 |  |  | $ | 114.19 |  |  |  |  |  |
| Granted | 3 |  |  | $ | 216.00 |  |  |  |  |  |
| Vested restricted stock | (7) |  |  | $ | 83.70 |  |  |  |  |  |
| Balances, May 1, 2022 | 42 |  |  | $ | 125.32 |  |  |  |  |  |

[0001045810-22-000079:notes:28]
As of May 1, 2022, there was $4.95 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.3 years for RSUs, PSUs, and market-based PSUs, and 1.1 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-22-000079:notes:29]
[same as prior period, unchanged from 0001045810-21-000163:notes:43]

[0001045810-22-000079:notes:30]
|  | Three Months Ended |  |  |
|  | May 1, |  | May 2, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 1,618 |  |  | $ | 1,912 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 2,506 |  |  | 2,484 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 31 |  |  | 44 |  |  |  |  |  |
| Diluted weighted average shares | 2,537 |  |  | 2,528 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.65 |  |  | $ | 0.77 |  |  |  |  |  |
| Diluted (2) | $ | 0.64 |  |  | $ | 0.76 |  |  |  |  |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 3 |  |  | 4 |  |  |  |  |  |

[0001045810-22-000079:notes:31]
[same as prior period, unchanged from 0001045810-21-000163:notes:45]

[0001045810-22-000079:notes:32]
[same as prior period, unchanged from 0001045810-21-000163:notes:46]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-22-000079:notes:33]
Income Taxes
We recognized an income tax expense of $187 million and $132 million for the first quarter of fiscal years 2023 and 2022, respectively. The income tax expense as a percentage of income before income tax was 10.3% and 6.5% for the first quarter of fiscal years 2023 and 2022, respectively.

[0001045810-22-000079:notes:34]
The increase in our effective tax rate was primarily due to an increase in the amount of earnings subject to U.S. tax, the Arm acquisition termination cost recorded in the first quarter of fiscal year 2023 which did not result in any material tax benefit, and a decreased impact of tax benefit from the U.S. federal research tax credit, partially offset by the increased benefits from the foreign-derived intangible income deduction and stock-based compensation.

[0001045810-22-000079:notes:35]
Our effective tax rate for the first quarter of fiscal year 2023 was lower than the U.S. federal statutory rate of 21% due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation and the U.S. federal research tax credit.

[0001045810-22-000079:notes:36]
Our effective tax rate for the first quarter of fiscal year 2022 was lower than the U.S. federal statutory rate of 21% due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate and tax benefits related to stock-based compensation and the U.S. federal research tax credit.

[0001045810-22-000079:notes:37]
For the first quarter of fiscal year 2023, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. We are currently under examination by the Internal Revenue Service for our fiscal years 2018 and 2019. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 30, 2022.
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of May 1, 2022, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next 12 months.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-22-000079:notes:38]
Cash Equivalents and Marketable Securities 
Our cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities.

[0001045810-22-000079:notes:39]
The following is a summary of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022:

[0001045810-22-000079:notes:40]
|  | May 1, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,827 |  |  | $ | — |  |  | $ | (9) |  |  | $ | 9,818 |  |  | $ | 1,232 |  |  | $ | 8,586 |  |
| Debt securities issued by the United States Treasury | 6,157 |  |  | 3 |  |  | (38) |  |  | 6,122 |  |  | 1,324 |  |  | 4,798 |  |
| Debt securities issued by United States government agencies | 2,116 |  |  | — |  |  | — |  |  | 2,116 |  |  | 460 |  |  | 1,656 |  |
| Certificates of deposit | 1,302 |  |  | — |  |  | — |  |  | 1,302 |  |  | 41 |  |  | 1,261 |  |
| Money market funds | 419 |  |  | — |  |  | — |  |  | 419 |  |  | 419 |  |  | — |  |
| Foreign government bonds | 185 |  |  | — |  |  | — |  |  | 185 |  |  | 35 |  |  | 150 |  |
| Total | $ | 20,006 |  |  | $ | 3 |  |  | $ | (47) |  |  | $ | 19,962 |  |  | $ | 3,511 |  |  | $ | 16,451 |  |

[0001045810-22-000079:notes:41]
|  | January 30, 2022 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 9,977 |  |  | $ | — |  |  | $ | (3) |  |  | $ | 9,974 |  |  | $ | 1,102 |  |  | $ | 8,872 |  |
| Debt securities issued by the United States Treasury | 7,314 |  |  | — |  |  | (14) |  |  | 7,300 |  |  | — |  |  | 7,300 |  |
| Debt securities issued by United States government agencies | 1,612 |  |  | — |  |  | — |  |  | 1,612 |  |  | 256 |  |  | 1,356 |  |
| Certificates of deposit | 1,561 |  |  | — |  |  | — |  |  | 1,561 |  |  | 21 |  |  | 1,540 |  |
| Money market funds | 316 |  |  | — |  |  | — |  |  | 316 |  |  | 316 |  |  | — |  |
| Foreign government bonds | 150 |  |  | — |  |  | — |  |  | 150 |  |  | — |  |  | 150 |  |
| Total | $ | 20,930 |  |  | $ | — |  |  | $ | (17) |  |  | $ | 20,913 |  |  | $ | 1,695 |  |  | $ | 19,218 |  |

[0001045810-22-000079:notes:42]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-22-000079:notes:43]
|  | May 1, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 2,955 |  |  | $ | (38) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,955 |  |  | $ | (38) |  |
| Corporate debt securities | 2,594 |  |  | (9) |  |  | 19 |  |  | — |  |  | 2,613 |  |  | (9) |  |
| Total | $ | 5,549 |  |  | $ | (47) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 5,568 |  |  | $ | (47) |  |

[0001045810-22-000079:notes:44]
|  | January 30, 2022 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |  |
| Debt securities issued by the United States Treasury | $ | 5,292 |  |  | $ | (14) |  |  | $ | — |  |  | $ | — |  |  | $ | 5,292 |  |  | $ | (14) |  |
| Corporate debt securities | 2,445 |  |  | (3) |  |  | 19 |  |  | — |  |  | 2,464 |  |  | (3) |  |
| Total | $ | 7,737 |  |  | $ | (17) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 7,756 |  |  | $ | (17) |  |

[0001045810-22-000079:notes:45]
The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-22-000079:notes:46]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of May 1, 2022 and January 30, 2022 are shown below by contractual maturity.

[0001045810-22-000079:notes:47]
|  | May 1, 2022 |  | January 30, 2022 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,196 |  |  | $ | 15,185 |  |  | $ | 16,346 |  |  | $ | 16,343 |  |
| Due in 1 - 5 years | 4,810 |  |  | 4,777 |  |  | 4,584 |  |  | 4,570 |  |
| Total | $ | 20,006 |  |  | $ | 19,962 |  |  | $ | 20,930 |  |  | $ | 20,913 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-22-000079:notes:48]
[same as prior period, unchanged from 0001045810-21-000163:notes:61]

[0001045810-22-000079:notes:49]
|  |  | Fair Value at |
|  | Pricing Category |  | May 1, 2022 |  | January 30, 2022 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 419 |  |  | $ | 316 |  |
| Corporate debt securities | Level 2 |  | $ | 9,818 |  |  | $ | 9,974 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 6,122 |  |  | $ | 7,300 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 2,116 |  |  | $ | 1,612 |  |
| Certificates of deposit | Level 2 |  | $ | 1,302 |  |  | $ | 1,561 |  |
| Foreign government bonds | Level 2 |  | $ | 185 |  |  | $ | 150 |  |
| Other assets (Investment in non-affiliated entities): |  |  |  |  |  |
| Publicly-held equity securities (1) | Level 1 |  | $ | 48 |  |  | $ | 58 |  |
| Privately-held equity securities | Level 3 |  | $ | 238 |  |  | $ | 208 |  |
| Liabilities (2) |  |  |  |  |  |
| 0.309% Notes Due 2023 | Level 2 |  | $ | 1,221 |  |  | $ | 1,236 |  |
| 0.584% Notes Due 2024 | Level 2 |  | $ | 1,191 |  |  | $ | 1,224 |  |
| 3.20% Notes Due 2026 | Level 2 |  | $ | 995 |  |  | $ | 1,055 |  |
| 1.55% Notes Due 2028 | Level 2 |  | $ | 1,100 |  |  | $ | 1,200 |  |
| 2.85% Notes Due 2030 | Level 2 |  | $ | 1,393 |  |  | $ | 1,542 |  |
| 2.00% Notes Due 2031 | Level 2 |  | $ | 1,071 |  |  | $ | 1,200 |  |
| 3.50% Notes Due 2040 | Level 2 |  | $ | 903 |  |  | $ | 1,066 |  |
| 3.50% Notes Due 2050 | Level 2 |  | $ | 1,756 |  |  | $ | 2,147 |  |
| 3.70% Notes Due 2060 | Level 2 |  | $ | 433 |  |  | $ | 551 |  |

[0001045810-22-000079:notes:50]
(1)    Unrealized losses of $24 million and an unrealized gain of $124 million from investments in publicly-traded equity securities were recorded in other income (expense), net, in the first quarter of fiscal years 2023 and 2022, respectively.

[0001045810-22-000079:notes:51]
(2)    These liabilities are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-22-000079:notes:52]
[same as prior period, unchanged from 0001045810-21-000163:notes:65]

[0001045810-22-000079:notes:53]
|  | May 1, 2022 |  | January 30, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,253 |  |  | $ | (1,260) |  |  | $ | 1,993 |  |  | $ | 3,418 |  |  | $ | (1,304) |  |  | $ | 2,114 |  |
| Patents and licensed technology | 719 |  |  | (501) |  |  | 218 |  |  | 717 |  |  | (492) |  |  | 225 |  |
| Total intangible assets | $ | 3,972 |  |  | $ | (1,761) |  |  | $ | 2,211 |  |  | $ | 4,135 |  |  | $ | (1,796) |  |  | $ | 2,339 |  |

[0001045810-22-000079:notes:54]
(1)    During the first quarter of fiscal year 2023, we commenced amortization of the $630 million in-process research and development intangible asset related to our acquisition of Mellanox.
Amortization expense associated with intangible assets was $155 million and $137 million for the first quarter of fiscal years 2023 and 2022, respectively. Future amortization expense related to the net carrying amount of intangible assets as of May 1, 2022 is estimated to be $541 million for the remainder of fiscal year 2023, $597 million in fiscal year 2024, $536 million in fiscal year 2025, $248 million in fiscal year 2026, $143 million in fiscal year 2027, and $146 million in fiscal year 2028 and thereafter.In the first quarter of fiscal year 2023, goodwill increased by $16 million and intangible assets increased by $25 million from acquisitions. We assigned $14 million of the increase in goodwill to our Compute & Networking segment and $2 million of the increase to our Graphics segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-22-000079:notes:55]
[same as prior period, unchanged from 0001045810-21-000163:notes:69]

[0001045810-22-000079:notes:56]
|  | May 1, |  | January 30, |
|  | 2022 |  | 2022 |
| Inventories: | (In millions) |
| Raw materials | $ | 1,119 |  |  | $ | 791 |  |
| Work in-process | 672 |  |  | 692 |  |
| Finished goods | 1,372 |  |  | 1,122 |  |
| Total inventories | $ | 3,163 |  |  | $ | 2,605 |  |

[0001045810-22-000079:notes:57]
|  | May 1, |  | January 30, |
|  | 2022 |  | 2022 |
| Other assets: | (In millions) |
| Prepaid supply agreements | $ | 2,752 |  |  | $ | 1,747 |  |
| Prepaid royalties | 405 |  |  | 409 |  |
| Investment in non-affiliated entities | 285 |  |  | 266 |  |
| Advanced consideration for acquisition (1) | — |  |  | 1,353 |  |
| Other | 63 |  |  | 66 |  |
| Total other assets | $ | 3,505 |  |  | $ | 3,841 |  |

[0001045810-22-000079:notes:58]
(1)    Refer to Note 2 - Business Combination for further details on the Arm acquisition.

[0001045810-22-000079:notes:59]
|  | May 1, |  | January 30, |
|  | 2022 |  | 2022 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 1,088 |  |  | $ | 1,000 |  |
| Taxes payable | 736 |  |  | 132 |  |
| Deferred revenue (1) | 334 |  |  | 300 |  |
| Accrued payroll and related expenses | 327 |  |  | 409 |  |
| Payables to brokers for unsettled investment trades | 325 |  |  | — |  |
| Excess inventory purchase obligations | 258 |  |  | 196 |  |
| Other | 495 |  |  | 515 |  |
| Total accrued and other current liabilities | $ | 3,563 |  |  | $ | 2,552 |  |

[0001045810-22-000079:notes:60]
(1)    Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements, support for hardware and software, and cloud services.

[0001045810-22-000079:notes:61]
|  | May 1, |  | January 30, |
|  | 2022 |  | 2022 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 1,051 |  |  | $ | 980 |  |
| Deferred income tax | 257 |  |  | 245 |  |
| Deferred revenue (2) | 203 |  |  | 202 |  |
| Other | 120 |  |  | 126 |  |
| Total other long-term liabilities | $ | 1,631 |  |  | $ | 1,553 |  |

[0001045810-22-000079:notes:62]
(1)    As of May 1, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, unrecognized tax benefits of $733 million, and related interest and penalties of $67 million. As of January 30, 2022, income tax payable represents the long-term portion of the one-time transition tax payable of $251 million, unrecognized tax benefits of $670 million, and related interest and penalties of $59 million.

[0001045810-22-000079:notes:63]
(2)    Deferred revenue primarily includes deferrals related to support for hardware and software.

[0001045810-22-000079:notes:64]
[same as prior period, unchanged from 0001045810-21-000163:notes:77]

[0001045810-22-000079:notes:65]
The following table shows the changes in deferred revenue during the first quarter of fiscal years 2023 and 2022:

[0001045810-22-000079:notes:66]
|  | May 1, |  | May 2, |
|  | 2022 |  | 2021 |
|  | (In millions) |
| Balance at beginning of period | $ | 502 |  |  | $ | 451 |  |
| Deferred revenue additions during the period | 212 |  |  | 178 |  |
| Revenue recognized during the period | (177) |  |  | (123) |  |
| Balance at end of period | $ | 537 |  |  | $ | 506 |  |

[0001045810-22-000079:notes:67]
Revenue related to remaining performance obligations represents the contracted license and development arrangements and support for hardware and software. This includes deferred revenue currently recorded and amounts that will be invoiced in future periods. As of May 1, 2022, $652 million of revenue related to performance obligations had not been recognized, of which we expect to recognize approximately 47% over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-22-000079:notes:68]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of May 1, 2022 and January 30, 2022.

[0001045810-22-000079:notes:69]
[same as prior period, unchanged from 0001045810-21-000163:notes:82]

[0001045810-22-000079:notes:70]
The table below presents the notional value of our foreign currency forward contracts outstanding as of May 1, 2022 and January 30, 2022:

[0001045810-22-000079:notes:71]
|  | May 1,2022 |  | January 30,2022 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 1,070 |  |  | $ | 1,023 |  |
| Not designated for hedge accounting | $ | 382 |  |  | $ | 408 |  |

[0001045810-22-000079:notes:72]
As of May 1, 2022, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-22-000079:notes:73]
During the first quarter of fiscal years 2023 and 2022, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant.


## us-gaap:DebtDisclosureTextBlock

[0001045810-22-000079:notes:74]
Debt
Long-Term Debt

[0001045810-22-000079:notes:75]
The carrying values of our outstanding notes and their associated interest rates were as follows:

[0001045810-22-000079:notes:76]
|  |  |  |  |  |  | Carrying Value at |
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | May 1, 2022 |  | January 30, 2022 |
|  |  |  |  |  |  | (In millions) |
| 0.309% Notes Due 2023 |  | 1.1 |  | 0.41% |  | $ | 1,250 |  |  | $ | 1,250 |  |
| 0.584% Notes Due 2024 |  | 2.1 |  | 0.66% |  | 1,250 |  |  | 1,250 |  |
| 3.20% Notes Due 2026 |  | 4.4 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 6.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 7.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 9.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 17.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 27.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 37.9 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (53) |  |  | (54) |  |
| Net carrying amount |  |  |  |  |  | $ | 10,947 |  |  | $ | 10,946 |  |

[0001045810-22-000079:notes:77]
All our notes are unsecured senior obligations. All existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium as defined in the applicable form of note.

[0001045810-22-000079:notes:78]
As of May 1, 2022, we have complied with the required covenants under the notes.

[0001045810-22-000079:notes:79]
Commercial Paper

[0001045810-22-000079:notes:80]
We have a $575 million commercial paper program to support general corporate purposes. As of May 1, 2022, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-22-000079:notes:81]
Commitments and Contingencies
Purchase Obligations

[0001045810-22-000079:notes:82]
Our purchase obligations primarily include our commitments to purchase components used to manufacture our products, including long-term supply agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-22-000079:notes:83]
We have entered into several long-term supply agreements, under which we have made advance payments and have $1.02 billion remaining unpaid. As of May 1, 2022, we had outstanding inventory purchase and long-term supply obligations totaling $9.59 billion, inclusive of the $1.02 billion. We also had other purchase obligations totaling $1.85 billion.

[0001045810-22-000079:notes:84]
Total future unconditional purchase commitments as of May 1, 2022, are as follows:

[0001045810-22-000079:notes:85]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2023 (excluding first quarter of fiscal year 2023) | $ | 8,344 |  |
| 2024 | 2,238 |  |
| 2025 | 406 |  |
| 2026 | 48 |  |
| 2027 | 70 |  |
| 2028 and thereafter | 330 |  |
| Total | $ | 11,436 |  |

[0001045810-22-000079:notes:86]
Accrual for Product Warranty Liabilities

[0001045810-22-000079:notes:87]
The estimated amount of product warranty liabilities was $55 million and $46 million as of May 1, 2022 and January 30, 2022, respectively, and the activities were not significant.

[0001045810-22-000079:notes:88]
With certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-22-000079:notes:89]
Litigation

[0001045810-22-000079:notes:90]
Securities Class Action and Derivative Lawsuits

[0001045810-22-000079:notes:91]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

[0001045810-22-000079:notes:92]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-22-000079:notes:93]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-22-000079:notes:94]
Settlement

[0001045810-22-000079:notes:95]
In May 2022, NVIDIA entered into a settlement with the SEC relating to MD&A disclosures in our Forms 10-Q for the second and third quarters of fiscal year 2018 concerning the impact of cryptocurrency mining on year-over-year growth in revenue for our gaming specialized market during those periods. As part of the settlement, without admitting or denying the findings in the administrative order issued by the SEC, NVIDIA agreed to cease-and-desist from violating certain federal securities laws and paid a $5.5 million civil penalty.

[0001045810-22-000079:notes:96]
Accounting for Loss Contingencies

[0001045810-22-000079:notes:97]
As of May 1, 2022, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-22-000079:notes:98]
[same as prior period, unchanged from 0001045810-21-000163:notes:114]

[0001045810-22-000079:notes:99]
[same as prior period, unchanged from 0001045810-21-000163:notes:115]

[0001045810-22-000079:notes:100]
During the first quarter of fiscal year 2023, we repurchased a total of 8.6 million shares for $2.00 billion. Through May 1, 2022, we have repurchased an aggregate of 1.05 billion shares under our share repurchase program for a total cost of $9.08 billion. On May 23, 2022, our Board of Directors increased and extended our share repurchase program to repurchase additional common stock up to a total of $15 billion through December 2023.

[0001045810-22-000079:notes:101]
During the first quarter of fiscal years 2023 and 2022, we paid $100 million and $99 million in cash dividends to our shareholders, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-22-000079:notes:102]
Segment Information
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance.

[0001045810-22-000079:notes:103]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation

[0001045810-22-000079:notes:104]
graphics; vGPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse software for building 3D designs and virtual worlds.

[0001045810-22-000079:notes:105]
Our Compute & Networking segment includes Data Center platforms and systems for artificial intelligence, or AI, high-performance computing, and accelerated computing; Mellanox networking and interconnect solutions; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; cryptocurrency mining processors, or CMP; Jetson for robotics and other embedded platforms; and NVIDIA AI Enterprise and other software.

[0001045810-22-000079:notes:106]
[same as prior period, unchanged from 0001045810-21-000163:notes:121]

[0001045810-22-000079:notes:107]
[same as prior period, unchanged from 0001045810-21-000163:notes:122]

[0001045810-22-000079:notes:108]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-22-000079:notes:109]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended May 1, 2022 |  |  |  |  |  |  |  |
| Revenue | $ | 4,616 |  |  | $ | 3,672 |  |  | $ | — |  |  | $ | 8,288 |  |
| Operating income (loss) | $ | 2,476 |  |  | $ | 1,606 |  |  | $ | (2,214) |  |  | $ | 1,868 |  |
| Three Months Ended May 2, 2021 |  |  |  |  |  |  |  |
| Revenue | $ | 3,451 |  |  | $ | 2,210 |  |  | $ | — |  |  | $ | 5,661 |  |
| Operating income (loss) | $ | 1,786 |  |  | $ | 861 |  |  | $ | (691) |  |  | $ | 1,956 |  |

[0001045810-22-000079:notes:110]
|  | Three Months Ended |  |  |
|  | May 1,2022 |  | May 2,2021 |  |  |  |  |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Acquisition termination cost | $ | (1,353) |  |  | $ | — |  |  |  |  |  |
| Stock-based compensation expense | (578) |  |  | (429) |  |  |  |  |  |
| Acquisition-related and other costs | (149) |  |  | (167) |  |  |  |  |  |
| Unallocated cost of revenue and operating expenses | (127) |  |  | (90) |  |  |  |  |  |
| IP-related and legal settlement costs | (7) |  |  | (5) |  |  |  |  |  |
| Total | $ | (2,214) |  |  | $ | (691) |  |  |  |  |  |

[0001045810-22-000079:notes:111]
[same as prior period, unchanged from 0001045810-21-000163:notes:127]

[0001045810-22-000079:notes:112]
|  | Three Months Ended |  |  |
|  | May 1, |  | May 2, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 2,777 |  |  | $ | 1,784 |  |  |  |  |  |
| China (including Hong Kong) | 2,081 |  |  | 1,391 |  |  |  |  |  |
| United States | 1,932 |  |  | 768 |  |  |  |  |  |
| Other countries | 1,498 |  |  | 1,718 |  |  |  |  |  |
| Total revenue | $ | 8,288 |  |  | $ | 5,661 |  |  |  |  |  |

[0001045810-22-000079:notes:113]
[same as prior period, unchanged from 0001045810-21-000163:notes:129]

[0001045810-22-000079:notes:114]
|  | Three Months Ended |  |  |
|  | May 1, |  | May 2, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 3,620 |  |  | $ | 2,760 |  |  |  |  |  |
| Data Center | 3,750 |  |  | 2,048 |  |  |  |  |  |
| Professional Visualization | 622 |  |  | 372 |  |  |  |  |  |
| Automotive | 138 |  |  | 154 |  |  |  |  |  |
| OEM and Other | 158 |  |  | 327 |  |  |  |  |  |
| Total revenue | $ | 8,288 |  |  | $ | 5,661 |  |  |  |  |  |

[0001045810-22-000079:notes:115]
No customer represented 10% or more of total revenue for the first quarter of fiscal years 2023 or 2022.

[0001045810-22-000079:notes:116]
One customer represented 12% of our accounts receivable balance as of May 1, 2022. Two customers each represented 10% or more of accounts receivable for a total of 22% as of January 30, 2022.
