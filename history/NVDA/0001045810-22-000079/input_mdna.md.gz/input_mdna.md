# NVDA MD&A — 0001045810-22-000079


## mdna

[0001045810-22-000079:mdna:1]
[same as prior period, unchanged from 0001045810-21-000163:mdna:1]

[0001045810-22-000079:mdna:2]
[same as prior period, unchanged from 0001045810-21-000163:mdna:2]

[0001045810-22-000079:mdna:3]
[same as prior period, unchanged from 0001045810-21-000163:mdna:3]

[0001045810-22-000079:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, GeForce NOW, Mellanox, NVIDIA AI Enterprise, NVIDIA DGX, NVIDIA DRIVE Orin, NVIDIA Grace, NVIDIA Hopper, NVIDIA Omniverse, NVIDIA OVX, NVIDIA RTX, NVIDIA Spectrum and Quadro, are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and/or other countries. MAXQ® is the registered trademark of Maxim Integrated Products, Inc. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-22-000079:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 30, 2022 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase or sell shares of our common stock.

[0001045810-22-000079:mdna:6]
[same as prior period, unchanged from 0001045810-21-000163:mdna:6]

[0001045810-22-000079:mdna:7]
[same as prior period, unchanged from 0001045810-21-000163:mdna:7]

[0001045810-22-000079:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, and augmented and virtual reality.

[0001045810-22-000079:mdna:9]
[same as prior period, unchanged from 0001045810-21-000163:mdna:9]

[0001045810-22-000079:mdna:10]
[same as prior period, unchanged from 0001045810-21-000163:mdna:10]

[0001045810-22-000079:mdna:11]
[same as prior period, unchanged from 0001045810-21-000163:mdna:11]

[0001045810-22-000079:mdna:12]
Termination of the Arm Share Purchase Agreement

[0001045810-22-000079:mdna:13]
On February 8, 2022, NVIDIA and SoftBank announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing in September 2020.

[0001045810-22-000079:mdna:14]
[same as prior period, unchanged from 0001045810-21-000163:mdna:18]

[0001045810-22-000079:mdna:15]
Demand for our products is based on many factors, including our product introductions and transitions, time to market, competitor product releases and announcements, competing technologies, and changes in macroeconomic conditions, including rising inflation, all of which can impact the timing and volume of our revenue. Product transitions are complex and can negatively impact our revenue as we manage shipments of prior architecture products and channel partners prepare and adjust to support new products. GPUs have use cases in addition to their designed and marketed use case, such as for digital currency mining, including blockchain-based platforms such as Ethereum. It is difficult for us to estimate with any reasonable degree of precision the past or current impact of cryptocurrency mining, or forecast the future impact of cryptocurrency mining, on demand for our products. Volatility in the cryptocurrency market, including new compute technologies, price changes in cryptocurrencies, government cryptocurrency policies and regulations, new cryptocurrency standards, and changes in the method of verifying blockchain transactions, have impacted and can in the future impact cryptocurrency mining and demand for our products and can further impact our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the pending Ethereum 2.0 standard may decrease the usage of GPUs for Ethereum mining as well as create increased aftermarket resales of our GPUs, impact retail prices for our GPUs, increase returns of our products in the distribution channel, and may reduce demand for our new GPUs. We have introduced Lite Hash Rate, or LHR, GeForce GPUs with limited Ethereum mining capability and provided CMP products in an effort to address demand from gamers and direct miners to CMP. Beginning in the second quarter of fiscal year 2022, most desktop NVIDIA Ampere architecture GeForce GPU shipments were LHR in our effort to direct GeForce to gamers. Attempts in the aftermarket to improve the hash rate capabilities of our LHR cards have been successful and our gaming cards may become more attractive to miners, increasing demand for our gaming GPUs and limiting our ability to supply our gaming cards to non-mining customers. We cannot predict whether our strategy of using LHR cards and CMP will achieve our desired outcome. Additionally, consumer and enterprise behavior during the COVID-19 pandemic has made it more difficult for us to estimate future demand and may have changed pre-pandemic behaviors. These challenges may be more pronounced or volatile in the future on both a global and regional basis and may continue in the future when the effects of the pandemic subside. Restrictions that may be imposed or reinstated as the pandemic continues may negatively impact customer demand for our products. Recent lockdown measures due to COVID-19 containment efforts in China, as well as the war in Ukraine, have impacted end customer sales in China and EMEA, respectively, and we expect this impact to continue into the second quarter of fiscal year 2023. During the first quarter of fiscal year 2023, we paused all direct sales in Russia. Direct sales to Russia in fiscal year 2022 were immaterial. Our revenue to partners that sell into Russia may be negatively impacted due to the war in Ukraine and we estimate that in fiscal year 2022, Russia accounted for approximately 2% of total end customer sales and 4% of Gaming end customer sales. In estimating demand and evaluating trends, we make multiple assumptions, any of which may prove to be incorrect.

[0001045810-22-000079:mdna:16]
[same as prior period, unchanged from 0001045810-21-000163:mdna:20]

[0001045810-22-000079:mdna:17]
Our manufacturing lead times are very long and in some cases extend twelve months or longer, which requires us to make estimates of customers’ future demand. These conditions could lead to a significant mismatch between supply and demand, giving rise to product shortages or excess inventory, and make our demand forecast more uncertain. To shorten shipment lead times and deliver more quickly to our customers, we may build finished products and maintain inventory for anticipated demand that does not materialize. During fiscal year 2022, we made substantial strides in broadening our supply base to scale our company and better serve customer demand. Recent COVID-19-related disruptions and lockdowns in China have created and are expected to continue to create supply and logistics constraints. The war in Ukraine has further strained global supply chains and could result in a shortage of key materials that our suppliers, including our foundry partners, require to satisfy our needs. We expect continued supply constraints for some of our products, such as Networking, through the end of the second quarter of fiscal year 2023 and potentially beyond. We have placed orders for certain supply in advance of our historical lead times, paid premiums and provided deposits to secure future supply and capacity, and may need to continue to do so in the future. Placing orders in advance of our historical lead times to secure supply and services in a constrained environment may result in excess inventory, cancellation penalties or other charges if there is a partial or complete reduction in long-term demand for our products. These actions may also increase our product costs, in addition to increased overall costs as a result of rising inflation. Increased costs for wafers, components, logistics, and other supply chain expenses, driven in part by inflation, have negatively impacted and may continue to impact our gross margin. Given our long lead times on inventory purchasing, we may order components before our product design is finalized and changes to the product design or to end demand, which may be perishable or may disappear, could trigger excess inventory. Our supply deliveries and production may be non-linear within a quarter or year which could cause changes to expected revenue or cash flows.

[0001045810-22-000079:mdna:18]
22

[0001045810-22-000079:mdna:19]
[same as prior period, unchanged from 0001045810-21-000163:mdna:24]

[0001045810-22-000079:mdna:20]
The COVID-19 pandemic continued during fiscal year 2023. Most of our employees continue to work remotely and we have paused most business travel. Our Professional Visualization market platform benefited from demand for workstations as enterprises support hybrid work environments. Recent COVID-19-related disruptions in China are creating supply and logistics constraints and impacting end customer sales. As our offices begin to reopen, we expect to incur incremental expenses as we resume onsite services and related in-office costs.

[0001045810-22-000079:mdna:21]
As the COVID-19 pandemic continues, the timing and overall demand from customers, and the limited availability of supply chain, logistical services and component supply may have a material net negative impact on our business and financial results.

[0001045810-22-000079:mdna:22]
[same as prior period, unchanged from 0001045810-21-000163:mdna:28]

[0001045810-22-000079:mdna:23]
First Quarter of Fiscal Year 2023 Summary

[0001045810-22-000079:mdna:24]
|  | Three Months Ended |  |  |  |  |
|  | May 1, 2022 |  | January 30, 2022 |  | May 2, 2021 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 8,288 |  |  | $ | 7,643 |  |  | $ | 5,661 |  |  | 8 | % |  | 46 | % |
| Gross margin | 65.5 | % |  | 65.4 | % |  | 64.1 | % |  | 10 bps |  | 140 bps |
| Operating expenses | $ | 3,563 |  |  | $ | 2,029 |  |  | $ | 1,673 |  |  | 76 | % |  | 113 | % |
| Income from operations | $ | 1,868 |  |  | $ | 2,970 |  |  | $ | 1,956 |  |  | (37) | % |  | (4) | % |
| Net income | $ | 1,618 |  |  | $ | 3,003 |  |  | $ | 1,912 |  |  | (46) | % |  | (15) | % |
| Net income per diluted share | $ | 0.64 |  |  | $ | 1.18 |  |  | $ | 0.76 |  |  | (46) | % |  | (16) | % |

[0001045810-22-000079:mdna:25]
[same as prior period, unchanged from 0001045810-21-000163:mdna:31]

[0001045810-22-000079:mdna:26]
Revenue for the first quarter of fiscal year 2023 was $8.29 billion, up 46% from a year ago and up 8% sequentially.

[0001045810-22-000079:mdna:27]
Gaming revenue was up 31% from a year ago and up 6% sequentially. The year-on-year increase reflects higher sales of GeForce GPUs based on our NVIDIA Ampere architecture. The sequential increase was driven by higher sales of GeForce GPUs for laptops and SOCs for game consoles.

[0001045810-22-000079:mdna:28]
Our GPUs are capable of cryptocurrency mining, though we have limited visibility into how much this impacts our overall GPU demand. Volatility in the cryptocurrency market – such as the recent declines in cryptocurrency prices or changes in method of verifying transactions, including proof of work or proof of stake - can impact demand for our products and our ability to accurately estimate it. Most desktop NVIDIA Ampere architecture GeForce GPU shipments were Lite Hash Rate to help direct GeForce GPUs to gamers.

[0001045810-22-000079:mdna:29]
Data Center revenue was up 83% from a year ago and up 15% sequentially. These increases were primarily driven by sales of NVIDIA Ampere architecture GPUs and DGX systems used across both training and inference. Growth was led by cloud computing and hyperscale customers for workloads such as natural language processing and deep recommenders.

[0001045810-22-000079:mdna:30]
Professional Visualization revenue was up 67% from a year ago and down 3% sequentially. The year-on-year increase was driven by sales of NVIDIA Ampere architecture products with growth in workstations as enterprises supported hybrid work environments. The sequential decrease was due to lower sales of desktop workstation GPUs, partially offset by higher sales of notebook workstations GPUs.

[0001045810-22-000079:mdna:31]
Automotive revenue was down 10% from a year ago and up 10% sequentially. The year-on-year decrease was due to automakers’ supply constraints and the decline of legacy cockpit revenue. The sequential increase was driven by AI cockpit revenue.

[0001045810-22-000079:mdna:32]
OEM and Other revenue was down 52% from a year ago and down 18% sequentially. The year-on-year decrease was due to a decline in CMP revenue, which was nominal in the quarter compared with $155 million from a year ago. The sequential decrease was driven by lower entry level notebook GPU sales.

[0001045810-22-000079:mdna:33]
GAAP gross margin was up 140 basis points from a year ago, primarily due to a higher-end mix of GeForce GPUs within Gaming and the reduced impact of acquisition-related costs. Sequentially, GAAP gross margin was up 10 basis points due to increased contribution of, and favorable product mix changes within, Data Center, partially offset by higher sales of SOCs for game consoles.

[0001045810-22-000079:mdna:34]
GAAP operating expenses were up 113% from a year ago and up 76% sequentially and include a $1.35 billion acquisition termination charge related to the Arm transaction. These increases were also driven by employee growth, compensation-related costs and engineering development costs. We have been successful in hiring this year and expect to slow hiring in the second half of fiscal year 2023 as we integrate our new employees.

[0001045810-22-000079:mdna:35]
Income from operations was $1.87 billion, down 4% from a year ago and down 37% sequentially. Net income was a $1.62 billion. Net income per diluted share was $0.64, down 16% from a year ago and down 46% sequentially.

[0001045810-22-000079:mdna:36]
Cash, cash equivalents and marketable securities were $20.34 billion, up from $12.67 billion a year ago and down from $21.21 billion a quarter ago. The year-on-year increase reflects operating cash flow generation and $5.00 billion of debt issuance proceeds. The sequential decrease reflects share repurchases and advanced payments on supply agreements.

[0001045810-22-000079:mdna:37]
During the first quarter of fiscal year 2023, we returned $2.10 billion to shareholders in the form of share repurchases and cash dividends.

[0001045810-22-000079:mdna:38]
On May 23, 2022, our board of directors increased and extended our share repurchase program to repurchase additional common stock up to a total of $15 billion through December 2023.

[0001045810-22-000079:mdna:39]
[same as prior period, unchanged from 0001045810-21-000163:mdna:43]

[0001045810-22-000079:mdna:40]
In our Data Center market platform, we announced the NVIDIA Hopper GPU architecture and its first products based on the architecture including the NVIDIA H100 Tensor Core GPU and the fourth-generation NVIDIA DGX system. Additionally, we announced the NVIDIA Grace CPU Superchip; unveiled the NVIDIA Spectrum-4 end-to-end 400Gbps networking platform; and announced NVIDIA OVX server reference design for digital twins and other Omniverse applications.

[0001045810-22-000079:mdna:41]
In our Gaming market platform, we introduced the GeForce RTX 3090 Ti enthusiast-class desktop GPU; announced that there are now over 180 laptop models featuring RTX 30-series GPUs and our energy efficient, thin & light Max-Q technologies; announced that 15 new game titles added support for NVIDIA RTX features, bringing the total to over 250 games and applications; and expanded the GeForce NOW cloud gaming service library with over 100 games, bringing the total to over 1,300.

[0001045810-22-000079:mdna:42]
In our Professional Visualization market platform, we added new NVIDIA Ampere architecture RTX GPUs for workstations and announced that Amazon Robotics is building AI-enabled digital twins of its warehouses using NVIDIA Omniverse Enterprise.

[0001045810-22-000079:mdna:43]
In our Automotive market platform, we started production of the NVIDIA DRIVE Orin autonomous vehicle SOC and announced wins with Lucid Motors and BYD.

[0001045810-22-000079:mdna:44]
[same as prior period, unchanged from 0001045810-21-000163:mdna:49]

[0001045810-22-000079:mdna:45]
[same as prior period, unchanged from 0001045810-21-000163:mdna:50]

[0001045810-22-000079:mdna:46]
Critical Accounting Policies and Estimates

[0001045810-22-000079:mdna:47]
Refer to Part II, Item 7, "Critical Accounting Policies and Estimates" of our Annual Report on Form 10-K for the fiscal year ended January 30, 2022. There have been no material changes to our Critical Accounting Policies and Estimates.

[0001045810-22-000079:mdna:48]
[same as prior period, unchanged from 0001045810-21-000163:mdna:51]

[0001045810-22-000079:mdna:49]
[same as prior period, unchanged from 0001045810-21-000163:mdna:52]

[0001045810-22-000079:mdna:50]
|  | Three Months Ended |  |  |
|  | May 1,2022 |  | May 2,2021 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 34.5 |  |  | 35.9 |  |  |  |  |  |
| Gross profit | 65.5 |  |  | 64.1 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 19.5 |  |  | 20.4 |  |  |  |  |  |
| Sales, general and administrative | 7.1 |  |  | 9.2 |  |  |  |  |  |
| Acquisition termination cost | 16.3 |  |  | — |  |  |  |  |  |
| Total operating expenses | 42.9 |  |  | 29.6 |  |  |  |  |  |
| Income from operations | 22.6 |  |  | 34.5 |  |  |  |  |  |
| Interest income | 0.2 |  |  | 0.1 |  |  |  |  |  |
| Interest expense | (0.8) |  |  | (0.9) |  |  |  |  |  |
| Other, net | (0.2) |  |  | 2.4 |  |  |  |  |  |
| Other income (expense), net | (0.8) |  |  | 1.6 |  |  |  |  |  |
| Income before income tax | 21.8 |  |  | 36.1 |  |  |  |  |  |
| Income tax expense | 2.3 |  |  | 2.3 |  |  |  |  |  |
| Net income | 19.5 | % |  | 33.8 | % |  |  |  |  |

[0001045810-22-000079:mdna:51]
[same as prior period, unchanged from 0001045810-21-000163:mdna:54]

[0001045810-22-000079:mdna:52]
[same as prior period, unchanged from 0001045810-21-000163:mdna:55]

[0001045810-22-000079:mdna:53]
|  | Three Months Ended |  |  |
|  | May 1,2022 |  | May 2,2021 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Graphics | $ | 4,616 |  |  | $ | 3,451 |  |  | $ | 1,165 |  |  | 34 | % |  |  |  |  |  |  |  |  |
| Compute & Networking | 3,672 |  |  | 2,210 |  |  | 1,462 |  |  | 66 | % |  |  |  |  |  |  |  |  |
| Total | $ | 8,288 |  |  | $ | 5,661 |  |  | $ | 2,627 |  |  | 46 | % |  |  |  |  |  |  |  |  |

[0001045810-22-000079:mdna:54]
Graphics - Graphics segment revenue increased by 34% in the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022. We continue to benefit from increased sales of our NVIDIA Ampere architecture products. The increase in Gaming revenue during the first quarter of fiscal year 2023 resulted from a combination of factors including: the ramp of new RTX 30 Series GPUs; the release of new games supporting ray tracing; the rising popularity of gaming, eSports, content creation and streaming; the demand for new and upgraded systems to support the increase in remote work; and the ability of end users to engage in cryptocurrency mining.

[0001045810-22-000079:mdna:55]
Compute & Networking - Compute & Networking segment revenue increased by 66% for the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, driven primarily by sales of NVIDIA Ampere architecture products to hyperscale customers for cloud computing and workloads such as natural language processing and deep recommender models, as well as to vertical industries. The increase also reflects an increase in sales of networking products. CMP contributed an insignificant amount in the first quarter of fiscal year 2023 compared to $155 million in the prior year.

[0001045810-22-000079:mdna:56]
[same as prior period, unchanged from 0001045810-21-000163:mdna:22]

[0001045810-22-000079:mdna:57]
[same as prior period, unchanged from 0001045810-21-000163:mdna:59]

[0001045810-22-000079:mdna:58]
Revenue from sales to customers outside of the United States accounted for 77% and 86% of total revenue for the first quarter of fiscal years 2023 and 2022, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-22-000079:mdna:59]
No customer represented 10% or more of total revenue for the first quarter of fiscal years 2023 or 2022.

[0001045810-22-000079:mdna:60]
[same as prior period, unchanged from 0001045810-21-000163:mdna:64]

[0001045810-22-000079:mdna:61]
Our overall gross margin increased to 65.5% for the first quarter of fiscal year 2023 from 64.1% for the first quarter of fiscal year 2022, reflecting a higher-end mix of GeForce GPUs within our Graphics segment and a reduced impact to gross margin for acquisition-related costs.

[0001045810-22-000079:mdna:62]
Inventory provisions totaled $90 million and $58 million for the first quarter of fiscal years 2023 and 2022, respectively. Sales of inventory that was previously written-off or down totaled $15 million and $21 million for the first quarter of fiscal years 2023 and 2022, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 0.9% and 0.6% in the first quarter of fiscal years 2023 and 2022, respectively.

[0001045810-22-000079:mdna:63]
Graphics - The gross margin of our Graphics segment increased during the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, primarily due to a higher-end mix within GeForce GPUs.

[0001045810-22-000079:mdna:64]
Compute & Networking - The gross margin of our Compute & Networking segment decreased during the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, primarily due to lower contribution of prior architecture boards compared to NVIDIA Ampere architecture systems.

[0001045810-22-000079:mdna:65]
[same as prior period, unchanged from 0001045810-21-000163:mdna:71]

[0001045810-22-000079:mdna:66]
|  | Three Months Ended |  |  |
|  | May 1,2022 |  | May 2,2021 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Research and development expenses | $ | 1,618 |  |  | $ | 1,153 |  |  | $ | 465 |  |  | 40 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 20 | % |  | 20 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales, general and administrative expenses | 592 |  |  | 520 |  |  | 72 |  |  | 14 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 7 | % |  | 9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition termination cost | 1,353 |  |  | — |  |  | 1,353 |  |  | 100 | % |  |  |  |  |  |  |  |  |
| % of net revenue | 16 | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 3,563 |  |  | $ | 1,673 |  |  | $ | 1,890 |  |  | 113 | % |  |  |  |  |  |  |  |  |

[0001045810-22-000079:mdna:67]
[same as prior period, unchanged from 0001045810-21-000163:mdna:73]

[0001045810-22-000079:mdna:68]
Research and development expenses increased by 40% during the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, primarily driven by compensation-related costs, including for employee growth and stock-based compensation, and engineering development costs.

[0001045810-22-000079:mdna:69]
[same as prior period, unchanged from 0001045810-21-000163:mdna:76]

[0001045810-22-000079:mdna:70]
Sales, general and administrative expenses increased by 14% during the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, primarily driven by compensation-related costs, associated with employee growth and stock-based compensation, partially offset by lower legal fees.

[0001045810-22-000079:mdna:71]
Acquisition Termination Cost

[0001045810-22-000079:mdna:72]
We recorded an acquisition termination cost related to the Arm transaction of $1.35 billion in the first quarter of fiscal year 2023 reflecting the write-off of the prepayment provided at signing in September 2020.

[0001045810-22-000079:mdna:73]
[same as prior period, unchanged from 0001045810-21-000163:mdna:79]

[0001045810-22-000079:mdna:74]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $18 million and $6 million for the first quarter of fiscal years 2023 and 2022, respectively. The increase in interest income was primarily due to higher interest rates earned on our investments and higher cash balances.

[0001045810-22-000079:mdna:75]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to our notes. Interest expense was $68 million and $53 million during the first quarter of fiscal years 2023 and 2022, respectively. The increase in expense reflects interest on the $5.00 billion note issued in June 2021.

[0001045810-22-000079:mdna:76]
Other, net, consists primarily of realized or unrealized gains and losses from investments in non-affiliated entities and the impact of changes in foreign currency rates. Other, net, was an expense of $13 million and income of $135 million during the first quarter of fiscal years 2023 and 2022, respectively. Changes in other, net, compared to the first quarter of fiscal year 2022 were primarily driven by mark-to-market impact from public trading equity investments and changes in value from our non-affiliated private investments. Refer to Note 8 of the Notes to Condensed Consolidated Financial Statements for additional information regarding our investments in non-affiliated entities.

[0001045810-22-000079:mdna:77]
[same as prior period, unchanged from 0001045810-21-000163:mdna:83]

[0001045810-22-000079:mdna:78]
We recognized an income tax expense of $187 million and $132 million for the first quarter of fiscal years 2023 and 2022, respectively. The income tax expense as a percentage of income before income tax was 10.3% and 6.5% for the first quarter of fiscal years 2023 and 2022, respectively.

[0001045810-22-000079:mdna:79]
The increase in our effective tax rate was primarily due to an increase in the amount of earnings subject to U.S. tax, the Arm acquisition termination cost recorded in the first quarter of fiscal year 2023 which did not result in any material tax benefit, and a decreased impact of tax benefit from the U.S. federal research tax credit, partially offset by the increased benefits from the foreign-derived intangible income deduction and stock-based compensation. If our stock price declines, the future tax benefits from stock-based compensation may decline, resulting in an increase in tax expense.

[0001045810-22-000079:mdna:80]
[same as prior period, unchanged from 0001045810-21-000163:mdna:86]

[0001045810-22-000079:mdna:81]
|  | May 1, 2022 |  | January 30, 2022 |
|  | (In millions) |
| Cash and cash equivalents | $ | 3,887 |  |  | $ | 1,990 |  |
| Marketable securities | 16,451 |  |  | 19,218 |  |
| Cash, cash equivalents and marketable securities | $ | 20,338 |  |  | $ | 21,208 |  |

[0001045810-22-000079:mdna:82]
|  | Three Months Ended |
|  | May 1, 2022 |  | May 2, 2021 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 1,731 |  |  | $ | 1,874 |  |
| Net cash provided by (used in) investing activities | $ | 2,612 |  |  | $ | (1,272) |  |
| Net cash used in financing activities | $ | (2,446) |  |  | $ | (471) |  |

[0001045810-22-000079:mdna:83]
As of May 1, 2022, we had $20.34 billion in cash, cash equivalents and marketable securities, a decrease of $0.87 billion from the end of fiscal year 2022. Our investment policy requires the purchase of highly rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-22-000079:mdna:84]
Cash provided by operating activities decreased in the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, primarily due to advanced payments on supply agreements in the first quarter of fiscal year 2023 partially offset by an increase in net income adjusted for certain non-cash items, such as the Arm acquisition termination cost of $1.35 billion during the first quarter of fiscal year 2023.

[0001045810-22-000079:mdna:85]
Cash provided by investing activities increased in the first quarter of fiscal year 2023 compared to cash used in the first quarter of fiscal year 2022, primarily driven by higher marketable securities sales and maturities and lower purchases of marketable securities.

[0001045810-22-000079:mdna:86]
Cash used in financing activities increased in the first quarter of fiscal year 2023 compared to the first quarter of fiscal year 2022, which primarily reflects share repurchases in the first quarter of fiscal year 2023.

[0001045810-22-000079:mdna:87]
[same as prior period, unchanged from 0001045810-21-000163:mdna:93]

[0001045810-22-000079:mdna:88]
Our primary sources of liquidity are our cash and cash equivalents, our marketable securities, and the cash generated by our operations. As of May 1, 2022, we had $20.34 billion in cash, cash equivalents, and marketable securities. Our marketable securities consist of debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to Condensed Consolidated Financial Statements for additional information. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months, and for the foreseeable future, including our future supply obligations and additional supply. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance our future capital requirements.

[0001045810-22-000079:mdna:89]
We have approximately $1.38 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S. Other than that, substantially all of our cash, cash equivalents and marketable securities held outside of the U.S. as of May 1, 2022 are available for use in the U.S. without incurring additional U.S. federal income taxes. We utilized almost all of our accumulated U.S. federal research tax credits during fiscal year 2022, resulting in higher cash tax payments starting in fiscal year 2023. In addition, beginning in fiscal year 2023, the 2017 Tax Cuts and Jobs Act requires taxpayers to capitalize research and development expenditures and to amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will impact cash flows from operations and will result in significantly higher cash tax payments starting in fiscal year 2023.

[0001045810-22-000079:mdna:90]
[same as prior period, unchanged from 0001045810-21-000163:mdna:96]

[0001045810-22-000079:mdna:91]
During the first quarter of fiscal year 2023, we returned $2.00 billion in share repurchases and $100 million in cash dividends. On May 23, 2022, our Board of Directors increased and extended our share repurchase program to repurchase additional common stock up to a total of $15 billion through December 2023.

[0001045810-22-000079:mdna:92]
Our cash dividend program and the payment of future cash dividends under that program are subject to the continuing determination by our Board of Directors that the dividend program and the declaration of dividends are in the best interests of our shareholders.

[0001045810-22-000079:mdna:93]
[same as prior period, unchanged from 0001045810-21-000163:mdna:99]

[0001045810-22-000079:mdna:94]
As of May 1, 2022, we had outstanding:

[0001045810-22-000079:mdna:95]
[same as prior period, unchanged from 0001045810-21-000163:mdna:101]

[0001045810-22-000079:mdna:96]
[same as prior period, unchanged from 0001045810-21-000163:mdna:102]

[0001045810-22-000079:mdna:97]
[same as prior period, unchanged from 0001045810-21-000163:mdna:103]

[0001045810-22-000079:mdna:98]
[same as prior period, unchanged from 0001045810-21-000163:mdna:104]

[0001045810-22-000079:mdna:99]
[same as prior period, unchanged from 0001045810-21-000163:mdna:105]

[0001045810-22-000079:mdna:100]
[same as prior period, unchanged from 0001045810-21-000163:mdna:106]

[0001045810-22-000079:mdna:101]
[same as prior period, unchanged from 0001045810-21-000163:mdna:107]

[0001045810-22-000079:mdna:102]
[same as prior period, unchanged from 0001045810-21-000163:mdna:108]

[0001045810-22-000079:mdna:103]
[same as prior period, unchanged from 0001045810-21-000163:mdna:109]

[0001045810-22-000079:mdna:104]
We have a $575 million commercial paper program to support general corporate purposes. As of May 1, 2022, we had not issued any commercial paper.

[0001045810-22-000079:mdna:105]
[same as prior period, unchanged from 0001045810-21-000163:mdna:112]

[0001045810-22-000079:mdna:106]
We have unrecognized tax benefits of $800 million, which includes related interest and penalties of $67 million recorded in non-current income tax payable as of May 1, 2022. We are unable to reasonably estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. We are currently under examination by the

[0001045810-22-000079:mdna:107]
Internal Revenue Service for our fiscal years 2018 and 2019. Refer to Note 6 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-22-000079:mdna:108]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 30, 2022. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 30, 2022 for a description of our contractual obligations. For a description of our operating lease obligations, long-term debt, and purchase obligations, refer to Note 3, Note 12, and Note 13 of the Notes to Condensed Consolidated Financial Statements, respectively.

[0001045810-22-000079:mdna:109]
[same as prior period, unchanged from 0001045810-21-000163:mdna:115]

[0001045810-22-000079:mdna:110]
To date, there has been no material impact to our results of operations associated with global sustainability regulations, compliance, costs from sourcing renewable energy or climate-related business trends. There are no material current climate change regulations impacting us, however, we are monitoring potential regulation changes in California, the United States, the United Kingdom, the European Union and other jurisdictions. We believe that climate change has not had a material impact to our revenue to date. We have not experienced any significant physical effects of climate change to date on our operations and results, nor any significant impacts on the cost or availability of insurance. In fiscal year 2024, we plan to launch Earth-2, an AI supercomputer dedicated to predicting the impacts of climate change.

[0001045810-22-000079:mdna:111]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-22-000079:mdna:112]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of a new and recently issued accounting pronouncement.
