# NVDA notes — 0001045810-20-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001045810-20-000010:notes:1]
Portions of the registrant's Proxy Statement for its 2020 Annual Meeting of Shareholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated by reference into Part III, Items 10-14 of this Annual Report on Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-20-000010:notes:2]
Organization and Summary of Significant Accounting Policies
Our Company

[0001045810-20-000010:notes:3]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-20-000010:notes:4]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-20-000010:notes:5]
Fiscal Year

[0001045810-20-000010:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2020, 2019 and 2018 were 52-week years. Fiscal year 2021 will be a 53-week year.

[0001045810-20-000010:notes:7]
Reclassifications

[0001045810-20-000010:notes:8]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-20-000010:notes:9]
Principles of Consolidation

[0001045810-20-000010:notes:10]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-20-000010:notes:11]
Use of Estimates

[0001045810-20-000010:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-20-000010:notes:13]
Revenue Recognition

[0001045810-20-000010:notes:14]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-20-000010:notes:15]
Product Sales Revenue

[0001045810-20-000010:notes:16]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-20-000010:notes:17]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-20-000010:notes:18]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-20-000010:notes:19]
License and Development Arrangements

[0001045810-20-000010:notes:20]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-20-000010:notes:21]
Software Licensing

[0001045810-20-000010:notes:22]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.

[0001045810-20-000010:notes:23]
Advertising Expenses

[0001045810-20-000010:notes:24]
We expense advertising costs in the period in which they are incurred. Advertising expenses for fiscal years 2020, 2019, and 2018 were $15 million, $21 million, and $25 million, respectively.

[0001045810-20-000010:notes:25]
Product Warranties

[0001045810-20-000010:notes:26]
We generally offer a limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-20-000010:notes:27]
Stock-based Compensation

[0001045810-20-000010:notes:28]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, we estimate forfeitures annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates.

[0001045810-20-000010:notes:29]
Litigation, Investigation and Settlement Costs

[0001045810-20-000010:notes:30]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-20-000010:notes:31]
Foreign Currency Remeasurement

[0001045810-20-000010:notes:32]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency

[0001045810-20-000010:notes:33]
remeasurement are included in other income or expense in our Consolidated Statements of Income and to date have not been significant.

[0001045810-20-000010:notes:34]
Income Taxes

[0001045810-20-000010:notes:35]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-20-000010:notes:36]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-20-000010:notes:37]
As of January 26, 2020, we had a valuation allowance of $621 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due to jurisdictional projections of future taxable income and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-20-000010:notes:38]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-20-000010:notes:39]
Net Income Per Share

[0001045810-20-000010:notes:40]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of equity awards outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive.

[0001045810-20-000010:notes:41]
Cash and Cash Equivalents

[0001045810-20-000010:notes:42]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents.

[0001045810-20-000010:notes:43]
Marketable Securities

[0001045810-20-000010:notes:44]
Marketable securities consist of highly liquid debt investments with maturities of greater than three months when purchased. We generally classify our marketable securities at the date of acquisition as available-for-sale. These debt securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. The fair value of interest-bearing debt securities includes accrued interest. Any unrealized losses which are considered to be other-than-temporary impairments are recorded in the other income or expense, net, section of our Consolidated Statements of Income. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income or expense, net, section of our Consolidated Statements of Income.

[0001045810-20-000010:notes:45]
All of our available-for-sale debt investments are subject to a periodic impairment review. We record a charge to earnings when a decline in fair value is significantly below cost basis and judged to be other-than-temporary or have other indicators of impairments. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) we intend to sell the instrument, (2) it is more likely than not that we will be required to sell the instrument before recovery of its amortized cost basis, or (3) a credit loss exists where we do not expect to recover the entire amortized cost basis of the instrument. In these situations, we recognize an

[0001045810-20-000010:notes:46]
other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if we do not intend to sell and it is not likely that we will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), we separate the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings while loss related to all other factors is recorded in accumulated other comprehensive income or loss.

[0001045810-20-000010:notes:47]
Fair Value of Financial Instruments

[0001045810-20-000010:notes:48]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 26, 2020 and January 27, 2019. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains or losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains or losses are recognized in earnings in the periods of change together with the offsetting losses or gains on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings.  For derivative instruments not designated for hedge accounting, changes in fair value are recognized in earnings.

[0001045810-20-000010:notes:49]
Concentration of Credit Risk

[0001045810-20-000010:notes:50]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio duration. Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, was approximately 21% of our accounts receivable balance from one customer as of January 26, 2020 and 19% of our accounts receivable balance from one customer as of January 27, 2019. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-20-000010:notes:51]
Accounts Receivable

[0001045810-20-000010:notes:52]
We maintain an allowance for doubtful accounts receivable for estimated losses resulting from the inability of our customers to make required payments. We determine this allowance by identifying amounts for specific customer issues as well as amounts based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.

[0001045810-20-000010:notes:53]
Inventories

[0001045810-20-000010:notes:54]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or net realizable value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.

[0001045810-20-000010:notes:55]
Property and Equipment

[0001045810-20-000010:notes:56]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization

[0001045810-20-000010:notes:57]
of assets recorded under capital leases. Leasehold improvements and assets recorded under capital leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.

[0001045810-20-000010:notes:58]
Leases

[0001045810-20-000010:notes:59]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

[0001045810-20-000010:notes:60]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0001045810-20-000010:notes:61]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

[0001045810-20-000010:notes:62]
Refer to Note 3 of these Notes to the Consolidated Financial Statements for additional information.

[0001045810-20-000010:notes:63]
Goodwill

[0001045810-20-000010:notes:64]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist.  For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-20-000010:notes:65]
Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting units.

[0001045810-20-000010:notes:66]
Our quantitative impairment test considers both the income approach and the market approach to estimate a reporting unit’s fair value. The income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business. Refer to Note 6 of these Notes to the Consolidated Financial Statements for additional information.

[0001045810-20-000010:notes:67]
Intangible Assets and Other Long-Lived Assets

[0001045810-20-000010:notes:68]
Intangible assets primarily represent rights acquired under technology licenses, patents, acquired intellectual property, trademarks and customer relationships. We currently amortize our intangible assets with definitive lives over periods ranging from three to ten years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method.

[0001045810-20-000010:notes:69]
Long-lived assets, such as property and equipment and intangible assets subject to amortization are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset, or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.

[0001045810-20-000010:notes:70]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-20-000010:notes:71]
Recently Adopted Accounting Pronouncements

[0001045810-20-000010:notes:72]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update regarding the accounting for leases under which lease assets and liabilities are recognized on the balance sheet. We adopted this guidance on January

[0001045810-20-000010:notes:73]
28, 2019 using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet. Refer to Note 3 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-20-000010:notes:74]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-20-000010:notes:75]
In June 2016, the FASB issued a new accounting standard to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. We will be required to use a forward-looking expected credit loss model for accounts receivable and other financial instruments, including available-for-sale debt securities. We plan to adopt the standard using the modified retrospective transition method beginning in the first quarter of fiscal year 2021. We do not currently believe it will have a material impact upon adoption.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-20-000010:notes:76]
Acquisition of Mellanox Technologies, Ltd.
On March 10, 2019, we entered into an Agreement and Plan of Merger, or the Merger Agreement, with Mellanox Technologies Ltd., or Mellanox, pursuant to which we will acquire all of the issued and outstanding common shares of Mellanox for $125 per share in cash, representing a total enterprise value of approximately $6.9 billion as of the date of the Merger Agreement. The Merger Agreement contains customary representations, warranties and covenants. The consummation of the merger is conditioned on the receipt of the approval of Mellanox shareholders, as well as the satisfaction of other customary closing conditions, including domestic and foreign regulatory approvals and performance in all material respects by each party of its obligations under the Merger Agreement. In June 2019, Mellanox shareholders approved the consummation of the merger and we received regulatory approvals for the deal from Mexico in July 2019 and from the European Commission in December 2019. In addition, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, in connection with the proposed acquisition expired in May 2019. Discussions with China's regulatory agency, the State Administration for Market Regulation, are progressing and we believe the acquisition will likely close in the early part of calendar 2020. If the Merger Agreement is terminated under certain circumstances involving the failure to obtain the required regulatory approvals, we could be obligated to pay Mellanox a termination fee of $350 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-20-000010:notes:77]
New Lease Accounting Standard
Method and Impact of Adoption

[0001045810-20-000010:notes:78]
On January 28, 2019, we adopted the new lease accounting standard using the optional transition method by recognizing a cumulative-effect adjustment to the consolidated balance sheet and not adjusting comparative information for prior periods. In addition, we elected the package of practical expedients permitted under the transition guidance, which allowed us not to reassess (1) whether any expired or existing contracts are or contain leases, (2) lease classification for any expired or existing leases, and (3) initial direct costs for any existing leases.

[0001045810-20-000010:notes:79]
The cumulative-effect adjustment upon adoption of the new lease accounting standard resulted in the recognition of $470 million of operating lease assets and $500 million of operating lease liabilities on our Consolidated Balance Sheet. The difference of $30 million represents deferred rent for leases that existed as of the date of adoption, which was an offset to the opening balance of operating lease assets.

[0001045810-20-000010:notes:80]
Lease Obligations

[0001045810-20-000010:notes:81]
Our lease obligations consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2021 and 2035.

[0001045810-20-000010:notes:82]
Future minimum lease payments under our operating leases as of January 26, 2020, are as follows:

[0001045810-20-000010:notes:83]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2021 | $ | 121 |  |
| 2022 | 117 |  |
| 2023 | 102 |  |
| 2024 | 79 |  |
| 2025 | 62 |  |
| 2026 and thereafter | 292 |  |
| Total | 773 |  |
| Less imputed interest | 121 |  |
| Present value of net future minimum lease payments | 652 |  |
| Less short-term operating lease liabilities | 91 |  |
| Long-term operating lease liabilities | $ | 561 |  |

[0001045810-20-000010:notes:84]
Future minimum lease payments under our non-cancelable operating leases as of January 27, 2019, based on the previous lease accounting standard, are as follows:

[0001045810-20-000010:notes:85]
|  | Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2020 | $ | 100 |  |
| 2021 | 97 |  |
| 2022 | 90 |  |
| 2023 | 77 |  |
| 2024 | 54 |  |
| 2025 and thereafter | 265 |  |
| Total | $ | 683 |  |

[0001045810-20-000010:notes:86]
Operating lease expense for fiscal years 2020, 2019, and 2018 was $114 million, $80 million, $54 million, respectively. Short-term and variable lease expenses for fiscal year 2020 were not significant.

[0001045810-20-000010:notes:87]
Other information related to leases was as follows:

[0001045810-20-000010:notes:88]
|  | Year Ended |
|  | January 26, 2020 |
|  | (In millions) |
| Supplemental cash flows information |  |
| Operating cash flows used for operating leases | $ | 103 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 238 |  |

[0001045810-20-000010:notes:89]
As of January 26, 2020, our operating leases had a weighted average remaining lease term of 8.3 years and a weighted average discount rate of 3.45%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-20-000010:notes:90]
Stock-Based Compensation
Our stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our ESPP.

[0001045810-20-000010:notes:91]
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts allocated to inventory, as follows:

[0001045810-20-000010:notes:92]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Cost of revenue | $ | 39 |  |  | $ | 27 |  |  | $ | 21 |  |
| Research and development | 540 |  |  | 336 |  |  | 219 |  |
| Sales, general and administrative | 265 |  |  | 194 |  |  | 151 |  |
| Total | $ | 844 |  |  | $ | 557 |  |  | $ | 391 |  |

[0001045810-20-000010:notes:93]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2020, 2019, and 2018.

[0001045810-20-000010:notes:94]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-20-000010:notes:95]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 7 |  |  | 4 |  |  | 6 |  |
| Estimated total grant-date fair value | $ | 1,282 |  |  | $ | 1,109 |  |  | $ | 929 |  |
| Weighted average grant-date fair value per share | $ | 184.47 |  |  | $ | 258.26 |  |  | $ | 145.91 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 1 |  |  | 1 |  |  | 5 |  |
| Weighted average price per share | $ | 148.76 |  |  | $ | 107.48 |  |  | $ | 21.24 |  |
| Weighted average grant-date fair value per share | $ | 64.87 |  |  | $ | 38.51 |  |  | $ | 7.12 |  |

[0001045810-20-000010:notes:96]
|  | January 26, 2020 |  | January 27, 2019 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense, net of forfeitures | $ | 1,803 |  |  | $ | 1,580 |  |
| Estimated weighted average remaining amortization period | (In years) |
| RSUs, PSUs and market-based PSUs | 2.5 |  |  | 2.2 |  |
| ESPP | 0.9 |  |  | 0.8 |  |

[0001045810-20-000010:notes:97]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-20-000010:notes:98]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.1-2.0 |  | 0.1-2.0 |  | 0.5-2.0 |
| Risk-free interest rate | 1.5%-2.6% |  | 1.6%-2.8% |  | 0.8%-1.4% |
| Volatility | 30%-82% |  | 24%-75% |  | 40%-54% |
| Dividend yield | 0.3%-0.4% |  | 0.3%-0.4% |  | 0.3%-0.5% |

[0001045810-20-000010:notes:99]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-20-000010:notes:100]
Additionally, for RSU, PSU, and market-based PSU awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-20-000010:notes:101]
Equity Incentive Program

[0001045810-20-000010:notes:102]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans.

[0001045810-20-000010:notes:103]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-20-000010:notes:104]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, as most recently amended and restated, the 2007 Plan.

[0001045810-20-000010:notes:105]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock units, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. Up to 230 million shares of our common stock may be issued pursuant to stock awards granted under the 2007 Plan. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 26, 2020, there were 29 million shares available for future issuance.

[0001045810-20-000010:notes:106]
Stock options previously granted to employees, subject to certain exceptions, vested over a four-year period, subject to continued service, with 25% vesting on the anniversary of the hire date in the case of new hires or the anniversary of the date of grant in the case of grants to existing employees and 6.25% vesting quarterly thereafter. These stock options generally expire ten years from the date of grant.

[0001045810-20-000010:notes:107]
Subject to certain exceptions, RSUs and PSUs granted to employees vest over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and (i) for grants made prior to May 18, 2016, 12.5% vesting semi-annually thereafter, and (ii) for grants made on or after May 18, 2016, 6.25% vesting quarterly thereafter. Market-based PSUs vest 100% on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-20-000010:notes:108]
Unless terminated sooner, the 2007 Plan is scheduled to terminate on March 21, 2022. Our Board may suspend or terminate the 2007 Plan at any time. No awards may be granted under the 2007 Plan while the 2007 Plan is suspended or after it is terminated. The Board may also amend the 2007 Plan at any time. However, if legal, regulatory or listing requirements require shareholder approval, the amendment will not go into effect until the shareholders have approved the amendment.

[0001045810-20-000010:notes:109]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-20-000010:notes:110]
In 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, as most recently amended and restated, the 2012 Plan, as the successor to the 1998 Employee Stock Purchase Plan.

[0001045810-20-000010:notes:111]
Up to 89 million shares of our common stock may be issued pursuant to purchases under the 2012 Plan. As of January 26, 2020, we had issued 30 million shares and reserved 59 million shares for future issuance under the 2012 Plan.

[0001045810-20-000010:notes:112]
The 2012 Plan is intended to qualify as an “employee stock purchase plan” under Section 423 of the Internal Revenue Code. Under the current offerings adopted pursuant to the 2012 Plan, each offering period is approximately 24 months, which is generally divided into four purchase periods of six months.

[0001045810-20-000010:notes:113]
Employees or those employed by an affiliate of ours are eligible to participate as designated by the Board. Employees who participate may have up to 10% of their earnings withheld to the purchase of shares of common stock. The Board may increase this percentage at its discretion, up to 15%. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the fair market value on each purchase date within the offering.

[0001045810-20-000010:notes:114]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-20-000010:notes:115]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
|  | (In millions, except years and per share data) |
| Balances, January 27, 2019 | 16 |  |  | $ | 129.92 |  |
| Granted (1)(2) | 7 |  |  | $ | 184.47 |  |
| Vested restricted stock | (8 | ) |  | $ | 92.70 |  |
| Canceled and forfeited | (1 | ) |  | $ | 185.46 |  |
| Balances, January 26, 2020 | 14 |  |  | $ | 176.72 |  |
| Vested and expected to vest after January 26, 2020 | 11 |  |  | $ | 176.46 |  |

[0001045810-20-000010:notes:116]
| (1) | Includes the number of PSUs that will be issued and eligible to vest based on the corporate financial performance level achieved for fiscal year 2020. |

[0001045810-20-000010:notes:117]
| (2) | Includes the number of market-based PSUs granted that will be issued and eligible to vest if the maximum goal for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to those companies comprising the Standard & Poor’s 500 Index during that period, the market-based PSUs issued could be up to 60 thousand shares. |

[0001045810-20-000010:notes:118]
As of January 26, 2020 and January 27, 2019, there were 29 million and 35 million shares, respectively, of common stock reserved for future issuance under our equity incentive plans.


## us-gaap:EarningsPerShareTextBlock

[0001045810-20-000010:notes:119]
Net Income Per Share
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-20-000010:notes:120]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 2,796 |  |  | $ | 4,141 |  |  | $ | 3,047 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 609 |  |  | 608 |  |  | 599 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |
| Equity awards | 9 |  |  | 17 |  |  | 24 |  |
| 1.00% Convertible Senior Notes | — |  |  | — |  |  | 5 |  |
| Warrants issued with the 1.00% Convertible Senior Notes | — |  |  | — |  |  | 4 |  |
| Diluted weighted average shares | 618 |  |  | 625 |  |  | 632 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 4.59 |  |  | $ | 6.81 |  |  | $ | 5.09 |  |
| Diluted (2) | $ | 4.52 |  |  | $ | 6.63 |  |  | $ | 4.82 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 11 |  |  | 5 |  |  | 4 |  |

[0001045810-20-000010:notes:121]
| (1) | Calculated as net income divided by basic weighted average shares. |

[0001045810-20-000010:notes:122]
(2)

[0001045810-20-000010:notes:123]
Calculated as net income divided by diluted weighted average shares.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-20-000010:notes:124]
GoodwillThe carrying amount of goodwill was $618 million, and the amount of goodwill allocated to our GPU and Tegra Processor reporting units was $210 million and $408 million, respectively, as of both January 26, 2020 and January 27, 2019. There were no changes to the carrying amount of goodwill during fiscal years 2020 and 2019. During the fourth quarters of fiscal years 2020, 2019, and 2018, we completed our annual impairment tests and concluded that goodwill was not impaired in any of these years.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-20-000010:notes:125]
Amortizable Intangible Assets
The components of our amortizable intangible assets are as follows:

[0001045810-20-000010:notes:126]
|  | January 26, 2020 |  | January 27, 2019 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (192 | ) |  | $ | 3 |  |  | $ | 195 |  |  | $ | (188 | ) |  | $ | 7 |  |
| Patents and licensed technology | 520 |  |  | (474 | ) |  | 46 |  |  | 491 |  |  | (453 | ) |  | 38 |  |
| Total intangible assets | $ | 715 |  |  | $ | (666 | ) |  | $ | 49 |  |  | $ | 686 |  |  | $ | (641 | ) |  | $ | 45 |  |

[0001045810-20-000010:notes:127]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during fiscal year 2020. Amortization expense associated with intangible assets for fiscal years 2020, 2019, and 2018 was $25 million, $29 million, and $55 million, respectively. Future amortization expense related to the net carrying amount of intangible assets as of

[0001045810-20-000010:notes:128]
January 26, 2020 is estimated to be $19 million in fiscal year 2021, $12 million in fiscal year 2022, $9 million in fiscal year 2023, $6 million in fiscal year 2024, and $3 million in fiscal year 2025 and thereafter until fully amortized.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-20-000010:notes:129]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-20-000010:notes:130]
The following is a summary of cash equivalents and marketable securities as of January 26, 2020 and January 27, 2019:

[0001045810-20-000010:notes:131]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

[0001045810-20-000010:notes:132]
|  | January 27, 2019 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,626 |  |  | $ | — |  |  | $ | (6 | ) |  | $ | 2,620 |  |  | $ | 25 |  |  | $ | 2,595 |  |
| Debt securities issued by United States government agencies | 2,284 |  |  | — |  |  | (4 | ) |  | 2,280 |  |  | — |  |  | 2,280 |  |
| Debt securities issued by the United States Treasury | 1,493 |  |  | — |  |  | (1 | ) |  | 1,492 |  |  | 176 |  |  | 1,316 |  |
| Money market funds | 483 |  |  | — |  |  | — |  |  | 483 |  |  | 483 |  |  | — |  |
| Foreign government bonds | 209 |  |  | — |  |  | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Asset-backed securities | 152 |  |  | — |  |  | (1 | ) |  | 151 |  |  | — |  |  | 151 |  |
| Mortgage backed securities issued by United States government-sponsored enterprises | 88 |  |  | 1 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total | $ | 7,335 |  |  | $ | 1 |  |  | $ | (12 | ) |  | $ | 7,324 |  |  | $ | 684 |  |  | $ | 6,640 |  |

[0001045810-20-000010:notes:133]
The unrealized losses as of January 26, 2020, aggregated by investment category and length of time that individual securities have been in a continuous loss position is not significant.

[0001045810-20-000010:notes:134]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For fiscal years 2020, 2019, and 2018, there were no other-than-temporary impairment losses, and net realized gains/losses were not significant.

[0001045810-20-000010:notes:135]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of January 26, 2020 and January 27, 2019 are shown below by contractual maturity.

[0001045810-20-000010:notes:136]
|  | January 26, 2020 |  | January 27, 2019 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 10,781 |  |  | $ | 10,781 |  |  | $ | 5,042 |  |  | $ | 5,034 |  |
| Due in 1 - 5 years | — |  |  | — |  |  | 2,271 |  |  | 2,268 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | — |  |  | — |  |  | 22 |  |  | 22 |  |
| Total | $ | 10,781 |  |  | $ | 10,781 |  |  | $ | 7,335 |  |  | $ | 7,324 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-20-000010:notes:137]
Fair Value of Financial Assets and Liabilities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 financial assets and liabilities for fiscal year 2020. Level 3 financial assets and liabilities are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances.

[0001045810-20-000010:notes:138]
|  |  | Fair Value at |
|  | Pricing Category |  | January 26, 2020 |  | January 27, 2019 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 7,507 |  |  | $ | 483 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 1,358 |  |  | $ | 1,492 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 1,096 |  |  | $ | 2,280 |  |
| Corporate debt securities | Level 2 |  | $ | 592 |  |  | $ | 2,620 |  |
| Foreign government bonds | Level 2 |  | $ | 200 |  |  | $ | 209 |  |
| Certificates of Deposit | Level 2 |  | $ | 27 |  |  | $ | — |  |
| Asset-backed securities | Level 2 |  | $ | 1 |  |  | $ | 151 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | — |  |  | $ | 89 |  |
| Liabilities |  |  |  |  |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 1,065 |  |  | $ | 961 |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 1,006 |  |  | $ | 978 |  |

[0001045810-20-000010:notes:139]
(1)

[0001045810-20-000010:notes:140]
These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to the Consolidated Financial Statements for additional information.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-20-000010:notes:141]
Balance Sheet Components
Certain balance sheet components are as follows:

[0001045810-20-000010:notes:142]
|  | January 26, 2020 |  | January 27, 2019 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 249 |  |  | $ | 613 |  |
| Work in-process | 265 |  |  | 238 |  |
| Finished goods | 465 |  |  | 724 |  |
| Total inventories | $ | 979 |  |  | $ | 1,575 |  |

[0001045810-20-000010:notes:143]
|  | January 26, 2020 |  | January 27, 2019 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Building | 340 |  |  | 339 |  |  | 25-30 |
| Test equipment | 532 |  |  | 516 |  |  | 3-5 |
| Computer equipment | 621 |  |  | 522 |  |  | 3-5 |
| Leasehold improvements | 293 |  |  | 291 |  |  | (B) |
| Software and licenses | 287 |  |  | 109 |  |  | 3-5 |
| Office furniture and equipment | 74 |  |  | 69 |  |  | 5 |
| Construction in process | 320 |  |  | 107 |  |  | (C) |
| Total property and equipment, gross | 2,685 |  |  | 2,171 |  |  |  |
| Accumulated depreciation and amortization | (1,011 | ) |  | (767 | ) |  |  |
| Total property and equipment, net | $ | 1,674 |  |  | $ | 1,404 |  |  |  |

[0001045810-20-000010:notes:144]
| (A) | Land is a non-depreciable asset. |

[0001045810-20-000010:notes:145]
| (B) | Leasehold improvements and capital leases are amortized based on the lesser of either the asset’s estimated useful life or the expected lease term. |

[0001045810-20-000010:notes:146]
| (C) | Construction in process represents assets that are not available for their intended use as of the balance sheet date. |

[0001045810-20-000010:notes:147]
Depreciation expense for fiscal years 2020, 2019, and 2018 was $355 million, $233 million, and $144 million, respectively.

[0001045810-20-000010:notes:148]
Accumulated amortization of leasehold improvements and capital leases was $216 million and $189 million as of January 26, 2020 and January 27, 2019, respectively.

[0001045810-20-000010:notes:149]
|  | January 26, 2020 |  | January 27, 2019 |
|  | (In millions) |
| Accrued and Other Current Liabilities: |  |  |  |
| Customer program accruals | $ | 462 |  |  | $ | 302 |  |
| Accrued payroll and related expenses | 185 |  |  | 186 |  |
| Deferred revenue (1) | 141 |  |  | 92 |  |
| Operating lease liabilities | 91 |  |  | — |  |
| Taxes payable | 61 |  |  | 91 |  |
| Licenses payable | 54 |  |  | 12 |  |
| Professional service fees | 18 |  |  | 14 |  |
| Other | 85 |  |  | 121 |  |
| Total accrued and other current liabilities | $ | 1,097 |  |  | $ | 818 |  |

[0001045810-20-000010:notes:150]
| (1) | Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and PCS. |

[0001045810-20-000010:notes:151]
|  | January 26, 2020 |  | January 27, 2019 |
|  | (In millions) |
| Other Long-Term Liabilities: |  |  |  |
| Income tax payable (1) | $ | 528 |  |  | $ | 513 |  |
| Licenses payable | 110 |  |  | 1 |  |
| Deferred revenue (2) | 60 |  |  | 46 |  |
| Deferred income tax liability | 29 |  |  | 19 |  |
| Employee benefits liability | 22 |  |  | 20 |  |
| Deferred rent | — |  |  | 21 |  |
| Other | 26 |  |  | 13 |  |
| Total other long-term liabilities | $ | 775 |  |  | $ | 633 |  |

[0001045810-20-000010:notes:152]
| (1) | As of January 26, 2020, income tax payable represents the long-term portion of the one-time transition tax payable of $317 million, as well as unrecognized tax benefits of $180 million and related interest and penalties of $31 million. |

[0001045810-20-000010:notes:153]
| (2) | Deferred revenue primarily includes deferrals related to PCS. |

[0001045810-20-000010:notes:154]
Deferred Revenue

[0001045810-20-000010:notes:155]
The following table shows the changes in deferred revenue during fiscal years 2020 and 2019.

[0001045810-20-000010:notes:156]
|  | January 26, |  | January 27, |
|  | 2020 |  | 2019 |
|  | (In millions) |
| Balance at beginning of period | $ | 138 |  |  | $ | 63 |  |
| Deferred revenue added during the period | 334 |  |  | 344 |  |
| Revenue recognized during the period | (271 | ) |  | (269 | ) |
| Balance at end of period | $ | 201 |  |  | $ | 138 |  |

[0001045810-20-000010:notes:157]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of January 26, 2020, the amount of our remaining performance that has not been recognized as revenue was $364 million, of which we expect to recognize approximately 46% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-20-000010:notes:158]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of January 26, 2020 and January 27, 2019.

[0001045810-20-000010:notes:159]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-20-000010:notes:160]
The table below presents the notional value of our foreign currency forward contracts outstanding as of January 26, 2020 and January 27, 2019:

[0001045810-20-000010:notes:161]
|  | January 26, 2020 |  | January 27, 2019 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 428 |  |  | $ | 408 |  |
| Not designated for hedge accounting | $ | 287 |  |  | $ | 241 |  |

[0001045810-20-000010:notes:162]
As of January 26, 2020, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-20-000010:notes:163]
During fiscal years 2020 and 2019, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-20-000010:notes:164]
Debt
Long-Term Debt

[0001045810-20-000010:notes:165]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-20-000010:notes:166]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or  collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-20-000010:notes:167]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-20-000010:notes:168]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-20-000010:notes:169]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | January 26, 2020 |  | January 27, 2019 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 1.6 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 6.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (9 | ) |  | (12 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,991 |  |  | $ | 1,988 |  |

[0001045810-20-000010:notes:170]
Revolving Credit Facility

[0001045810-20-000010:notes:171]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of January 26, 2020, we had not borrowed any amounts under this agreement.

[0001045810-20-000010:notes:172]
Commercial Paper

[0001045810-20-000010:notes:173]
We have a $575 million commercial paper program to support general corporate purposes. As of January 26, 2020, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-20-000010:notes:174]
Commitments and Contingencies
Purchase Obligations

[0001045810-20-000010:notes:175]
As of January 26, 2020, we had outstanding inventory purchase obligations totaling $1.16 billion and other purchase obligations totaling $186 million.

[0001045810-20-000010:notes:176]
Accrual for Product Warranty Liabilities

[0001045810-20-000010:notes:177]
The estimated amount of product returns and warranty liabilities was $15 million and $18 million as of January 26, 2020 and January 27, 2019, respectively.

[0001045810-20-000010:notes:178]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.

[0001045810-20-000010:notes:179]
Litigation

[0001045810-20-000010:notes:180]
Securities Class Action and Derivative Lawsuits

[0001045810-20-000010:notes:181]
On December 21, 2018, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, captioned Iron Workers Joint Funds v. Nvidia Corporation, et al. (Case No. 18-cv-7669), naming as defendants NVIDIA and certain of NVIDIA’s officers. On December 28, 2018, a substantially similar purported securities class action was commenced in the Northern District of California, captioned Oto v. Nvidia Corporation, et al. (Case No. 18-cv-07783), naming the same defendants, and seeking substantially similar relief. On February 19, 2019, a number of shareholders filed motions to consolidate the two cases and to be appointed lead plaintiff and for their respective counsel to be appointed lead counsel. On March 12, 2019, the two cases were consolidated under case number 4:18-cv-07669-HSG and titled In Re NVIDIA Corporation Securities Litigation. On May 2, 2019, the Court appointed lead plaintiffs and lead counsel. On June 21, 2019, the lead plaintiffs filed a consolidated class action complaint. The consolidated complaint asserts that the defendants violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. The plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. The plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On August 2, 2019, NVIDIA moved

[0001045810-20-000010:notes:182]
to dismiss the consolidated class action complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the named defendants.

[0001045810-20-000010:notes:183]
On January 18, 2019, a shareholder, purporting to act on behalf of NVIDIA, filed a derivative lawsuit in the Northern District of California, captioned Han v. Huang, et al. (Case No. 19-cv-00341), seeking to assert claims on behalf of NVIDIA against the members of NVIDIA’s board of directors and certain officers. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiff is seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures. On February 12, 2019, a substantially similar derivative lawsuit was filed in the Northern District of California captioned Yang v. Huang, et. al. (Case No. 19-cv-00766), naming the same named defendants, and seeking the same relief. On February 19, 2019, a third substantially similar derivative lawsuit was filed in the Northern District of California captioned The Booth Family Trust v. Huang, et. al. (Case No. 3:19-cv-00876), naming the same named defendants, and seeking substantially the same relief. On March 12, 2019, the three derivative actions were consolidated under case number 4:19-cv-00341-HSG, and titled In re NVIDIA Corporation Consolidated Derivative Litigation. The parties stipulated to stay the In Re NVIDIA Corporation Consolidated Derivative Litigation pending resolution of any motion to dismiss that NVIDIA may file in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-20-000010:notes:184]
On September 24, 2019, two shareholders, purporting to act on behalf of NVIDIA, filed two identical lawsuits in the District of Delaware. One is captioned Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and the other is captioned Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA). The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures. On December 11, 2019, the court approved the parties’ stipulation to stay the Lipchitz and Huang actions pending resolution of the motion to dismiss filed by NVIDIA in the In Re NVIDIA Corporation Securities Litigation.

[0001045810-20-000010:notes:185]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-20-000010:notes:186]
Accounting for Loss Contingencies

[0001045810-20-000010:notes:187]
We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position. As of January 26, 2020, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-20-000010:notes:188]
Income Taxes
The income tax expense (benefit) applicable to income before income taxes consists of the following:

[0001045810-20-000010:notes:189]
|  | Year Ended |
|  | January 26,2020 |  | January 27,2019 |  | January 28,2018 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 65 |  |  | $ | 1 |  |  | $ | 464 |  |
| State | 4 |  |  | — |  |  | 1 |  |
| Foreign | 87 |  |  | 69 |  |  | 43 |  |
| Total current | 156 |  |  | 70 |  |  | 508 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | 2 |  |  | (315 | ) |  | (376 | ) |
| State | — |  |  | — |  |  | — |  |
| Foreign | 16 |  |  | — |  |  | 17 |  |
| Total deferred | 18 |  |  | (315 | ) |  | (359 | ) |
| Income tax expense (benefit) | $ | 174 |  |  | $ | (245 | ) |  | $ | 149 |  |

[0001045810-20-000010:notes:190]
Income before income tax consists of the following:

[0001045810-20-000010:notes:191]
|  | Year Ended |
|  | January 26,2020 |  | January 27,2019 |  | January 28,2018 |
|  | (In millions) |
| Domestic | $ | 620 |  |  | $ | 1,843 |  |  | $ | 1,600 |  |
| Foreign | 2,350 |  |  | 2,053 |  |  | 1,596 |  |
| Income before income tax | $ | 2,970 |  |  | $ | 3,896 |  |  | $ | 3,196 |  |

[0001045810-20-000010:notes:192]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21%, 21%, and 33.9% for fiscal years 2020, 2019, and 2018, respectively, to income before income taxes as follows:

[0001045810-20-000010:notes:193]
|  | Year Ended |
|  | January 26,2020 |  | January 27,2019 |  | January 28,2018 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 624 |  |  | $ | 818 |  |  | $ | 1,084 |  |
| Expense (benefit) resulting from: |  |  |  |  |  |
| State income taxes, net of federal tax effect | 12 |  |  | 23 |  |  | 10 |  |
| Foreign tax rate differential | (301 | ) |  | (412 | ) |  | (545 | ) |
| Stock-based compensation | (60 | ) |  | (191 | ) |  | (181 | ) |
| Tax Cuts and Jobs Act of 2017 | — |  |  | (368 | ) |  | (133 | ) |
| U.S. federal R&D tax credit | (110 | ) |  | (141 | ) |  | (87 | ) |
| Other | 9 |  |  | 26 |  |  | 1 |  |
| Income tax expense (benefit) | $ | 174 |  |  | $ | (245 | ) |  | $ | 149 |  |

[0001045810-20-000010:notes:194]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-20-000010:notes:195]
|  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Deferred tax assets: |  |
| Net operating loss carryforwards | $ | 62 |  |  | $ | 70 |  |
| Accruals and reserves, not currently deductible for tax purposes | 39 |  |  | 41 |  |
| Property, equipment and intangible assets | 12 |  |  | 2 |  |
| Operating lease liabilities | 114 |  |  | — |  |
| Research and other tax credit carryforwards | 605 |  |  | 626 |  |
| Stock-based compensation | 28 |  |  | 25 |  |
| GILTI deferred tax assets | 428 |  |  | 376 |  |
| Gross deferred tax assets | 1,288 |  |  | 1,140 |  |
| Less valuation allowance | (621 | ) |  | (562 | ) |
| Total deferred tax assets | 667 |  |  | 578 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (1 | ) |  | (2 | ) |
| Unremitted earnings of foreign subsidiaries | (40 | ) |  | (35 | ) |
| Operating lease assets | (107 | ) |  | — |  |
| Gross deferred tax liabilities | (148 | ) |  | (37 | ) |
| Net deferred tax asset (1) | $ | 519 |  |  | $ | 541 |  |

[0001045810-20-000010:notes:196]
(1)  Net deferred tax asset includes long-term deferred tax assets of $548 million and $560 million and long-term deferred tax liabilities of $29 million  and $19 million for fiscal years 2020 and 2019, respectively. Long-term deferred tax assets are included in Other assets and long-term deferred tax liabilities are included in Other long-term liabilities on our Consolidated Balance Sheets.

[0001045810-20-000010:notes:197]
We recognized an income tax expense of $174 million and $149 million for fiscal years 2020 and 2018, respectively, and income tax benefit of $245 million for fiscal year 2019. Our annual effective tax rate was 5.9%, (6.3)%, and 4.7% for fiscal years 2020, 2019, and 2018, respectively. The increase in our effective tax rate in fiscal year 2020 as compared to fiscal years 2019 and 2018 was primarily due to a decrease of tax benefits from stock-based compensation and an absence of tax benefits related to the enactment of the TCJA.

[0001045810-20-000010:notes:198]
The decrease in our effective tax rate in fiscal year 2019 as compared to fiscal year 2018 was primarily due to a decrease in the U.S. statutory tax rate from 33.9% to 21%, the finalization of the enactment-date income tax effects of the TCJA, higher U.S federal research tax credits and excess tax benefits related to stock-based compensation in fiscal year 2019.

[0001045810-20-000010:notes:199]
Our effective tax rate for fiscal years 2020 and 2019 was lower than the U.S. federal statutory rate of 21% due primarily to income earned in jurisdictions, including the British Virgin Islands and Hong Kong, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition of U.S. federal research tax credits,  excess tax benefits related to stock-based compensation, and the finalization of the enactment-date income tax effects of the TCJA in 2019.

[0001045810-20-000010:notes:200]
Our effective tax rate for fiscal year 2018 was lower than the blended U.S. federal statutory rate of 33.9% due primarily to income earned in jurisdictions, including the British Virgin Islands, Hong Kong, China, Taiwan and United Kingdom, where the tax rate was lower than the U.S. federal statutory tax rates, favorable recognition of U.S. federal research tax credits, the provisional impact of the tax law changes, and excess tax benefits related to stock-based compensation.

[0001045810-20-000010:notes:201]
As of January 26, 2020 and January 27, 2019, we had a valuation allowance of $621 million and $562 million, respectively, related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to jurisdictional projections of future taxable income. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-20-000010:notes:202]
As of January 26, 2020, we had federal, state and foreign net operating loss carryforwards of $70 million, $153 million and $295 million, respectively. The federal and state carryforwards will begin to expire in fiscal year 2023 and 2021, respectively. The foreign net operating loss carryforwards of $295 million may be carried forward indefinitely. As of January 26, 2020, we had federal research tax credit carryforwards of $314 million that will begin to expire in fiscal year 2039. We have state research tax credit carryforwards of $814 million, of which $774 million is attributable to the State of California and may be carried over indefinitely, and $40 million is attributable to various other states and will begin to expire in fiscal year 2021. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, states, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-20-000010:notes:203]
As of January 26, 2020, we had $583 million of gross unrecognized tax benefits, of which $464 million would affect our effective tax rate if recognized. However, $104 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $464 million of unrecognized tax benefits as of January 26, 2020 consisted of $180 million recorded in non-current income taxes payable and $284 million reflected as a reduction to the related deferred tax assets.

[0001045810-20-000010:notes:204]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-20-000010:notes:205]
|  | January 26,2020 |  | January 27,2019 |  | January 28,2018 |
|  | (In millions) |
| Balance at beginning of period | $ | 477 |  |  | $ | 447 |  |  | $ | 224 |  |
| Increases in tax positions for prior years | 7 |  |  | 52 |  |  | 7 |  |
| Decreases in tax positions for prior years | — |  |  | (141 | ) |  | (1 | ) |
| Increases in tax positions for current year | 104 |  |  | 129 |  |  | 222 |  |
| Lapse in statute of limitations | (5 | ) |  | (10 | ) |  | (5 | ) |
| Balance at end of period | $ | 583 |  |  | $ | 477 |  |  | $ | 447 |  |

[0001045810-20-000010:notes:206]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-20-000010:notes:207]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 26, 2020, January 27, 2019, and January 28, 2018, we had accrued $31 million, $21 million, and $15 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 26, 2020, unrecognized tax benefits of $180 million and the related interest and penalties of $31 million are included in non-current income taxes payable.

[0001045810-20-000010:notes:208]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 26, 2020, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.

[0001045810-20-000010:notes:209]
We are subject to taxation by taxing authorities both in the United States and other countries. As of January 26, 2020, the significant tax jurisdictions that may be subject to examination include the United States, Hong Kong, Taiwan, China, United Kingdom, Germany, and India for fiscal years 2003 through 2019. As of January 26, 2020, the significant tax jurisdictions for which we are currently under examination include India, China, and United Kingdom for fiscal years 2003 through 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-20-000010:notes:210]
Shareholders’ Equity
Capital Return Program

[0001045810-20-000010:notes:211]
Beginning August 2004, our Board of Directors authorized us to repurchase our stock.

[0001045810-20-000010:notes:212]
Through January 26, 2020, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of January 26, 2020, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $7.24 billion through December 2022.

[0001045810-20-000010:notes:213]
During fiscal year 2020, we paid $390 million in cash dividends to our shareholders.

[0001045810-20-000010:notes:214]
Preferred Stock

[0001045810-20-000010:notes:215]
As of January 26, 2020 and January 27, 2019, there were no shares of preferred stock outstanding.

[0001045810-20-000010:notes:216]
Common Stock

[0001045810-20-000010:notes:217]
We are authorized to issue up to 2.00 billion shares of our common stock at $0.001 per share par value.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-20-000010:notes:218]
Employee Retirement Plans
We have a 401(k) retirement plan covering substantially all of our U.S. employees. Under the plan, participating employees may defer up to 80% of their pre-tax earnings, subject to the Internal Revenue Service annual contribution limits and we match a portion of the employee contributions. Our contribution expense for fiscal years 2020, 2019, and 2018 was $44 million, $39 million, and $23 million, respectively. We also have defined contribution retirement plans outside of the United States to which we contributed $32 million, $31 million, and $25 million for fiscal years 2020, 2019, and 2018, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-20-000010:notes:219]
Segment Information 
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments.

[0001045810-20-000010:notes:220]
We report our business in two primary reportable segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-20-000010:notes:221]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla and DGX for AI data scientists and big data researchers; and GRID for cloud-based visual computing users. Our Tegra brand incorporates GPUs and multi-core CPUs to drive supercomputing for autonomous robots, drones, and cars, as well as for game consoles and mobile gaming and entertainment devices.

[0001045810-20-000010:notes:222]
Under the single unifying architecture for our GPU and Tegra Processors, we leverage our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reportable segments, our CODM assigns 100% of those expenses to the reportable segment that benefits the most.

[0001045810-20-000010:notes:223]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue included in all other is Intel licensing revenue and the expenses include stock-based compensation expense, corporate infrastructure and support costs, legal settlement costs, acquisition-related and other costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-20-000010:notes:224]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record inter-segment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-20-000010:notes:225]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 26, 2020: |  |  |  |  |  |  |  |
| Revenue | $ | 9,465 |  |  | $ | 1,453 |  |  | $ | — |  |  | $ | 10,918 |  |
| Depreciation and amortization expense | $ | 322 |  |  | $ | 44 |  |  | $ | 15 |  |  | $ | 381 |  |
| Operating income (loss) | $ | 3,806 |  |  | $ | 196 |  |  | $ | (1,156 | ) |  | $ | 2,846 |  |
| Year Ended January 27, 2019: |  |  |  |  |  |  |  |
| Revenue | $ | 10,175 |  |  | $ | 1,541 |  |  | $ | — |  |  | $ | 11,716 |  |
| Depreciation and amortization expense | $ | 197 |  |  | $ | 47 |  |  | $ | 18 |  |  | $ | 262 |  |
| Operating income (loss) | $ | 4,443 |  |  | $ | 241 |  |  | $ | (880 | ) |  | $ | 3,804 |  |
| Year Ended January 28, 2018: |  |  |  |  |  |  |  |
| Revenue | $ | 8,137 |  |  | $ | 1,534 |  |  | $ | 43 |  |  | $ | 9,714 |  |
| Depreciation and amortization expense | $ | 123 |  |  | $ | 37 |  |  | $ | 39 |  |  | $ | 199 |  |
| Operating income (loss) | $ | 3,507 |  |  | $ | 303 |  |  | $ | (600 | ) |  | $ | 3,210 |  |

[0001045810-20-000010:notes:226]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | — |  |  | $ | 43 |  |
| Stock-based compensation expense | (844 | ) |  | (557 | ) |  | (391 | ) |
| Unallocated cost of revenue and operating expenses | (267 | ) |  | (277 | ) |  | (237 | ) |
| Acquisition-related and other costs | (30 | ) |  | (2 | ) |  | (15 | ) |
| Legal settlement costs | (15 | ) |  | (44 | ) |  | — |  |
| Total | $ | (1,156 | ) |  | $ | (880 | ) |  | $ | (600 | ) |

[0001045810-20-000010:notes:227]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-20-000010:notes:228]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
| Revenue: | (In millions) |
| Taiwan | $ | 3,025 |  |  | $ | 3,360 |  |  | $ | 2,991 |  |
| China (including Hong Kong) | 2,731 |  |  | 2,801 |  |  | 1,896 |  |
| Other Asia Pacific | 2,685 |  |  | 2,368 |  |  | 2,066 |  |
| Europe | 992 |  |  | 914 |  |  | 768 |  |
| United States | 886 |  |  | 1,506 |  |  | 1,274 |  |
| Other countries | 599 |  |  | 767 |  |  | 719 |  |
| Total revenue | $ | 10,918 |  |  | $ | 11,716 |  |  | $ | 9,714 |  |

[0001045810-20-000010:notes:229]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-20-000010:notes:230]
|  | Year Ended |
|  | January 26, 2020 |  | January 27, 2019 |  | January 28, 2018 |
| Revenue: | (In millions) |
| Gaming | $ | 5,518 |  |  | $ | 6,246 |  |  | $ | 5,513 |  |
| Professional Visualization | 1,212 |  |  | 1,130 |  |  | 934 |  |
| Data Center | 2,983 |  |  | 2,932 |  |  | 1,932 |  |
| Automotive | 700 |  |  | 641 |  |  | 558 |  |
| OEM & Other | 505 |  |  | 767 |  |  | 777 |  |
| Total revenue | $ | 10,918 |  |  | $ | 11,716 |  |  | $ | 9,714 |  |

[0001045810-20-000010:notes:231]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and deposits and other assets, and exclude operating lease assets, goodwill, and intangible assets.

[0001045810-20-000010:notes:232]
|  | January 26, 2020 |  | January 27, 2019 |
| Long-lived assets: | (In millions) |
| United States | $ | 1,568 |  |  | $ | 1,266 |  |
| Taiwan | 114 |  |  | 137 |  |
| India | 51 |  |  | 44 |  |
| China (including Hong Kong) | 28 |  |  | 38 |  |
| Europe | 28 |  |  | 26 |  |
| Other countries | 2 |  |  | 1 |  |
| Total long-lived assets | $ | 1,791 |  |  | $ | 1,512 |  |

[0001045810-20-000010:notes:233]
One customer represented 11% of our total revenue for fiscal year 2020 and was attributable to the GPU business. No customer represented 10% or more of total revenue for fiscal years 2019 and 2018.

[0001045810-20-000010:notes:234]
One customer represented 21% of our accounts receivable balance as of January 26, 2020, and one customer represented 19% of our accounts receivable balance as of January 27, 2019.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001045810-20-000010:notes:235]
Quarterly Summary (Unaudited)
The following table sets forth our unaudited consolidated financial results, for the last eight fiscal quarters:

[0001045810-20-000010:notes:236]
|  | Fiscal Year 2020 Quarters Ended |
|  | January 26, 2020 |  | October 27, 2019 |  | July 28, 2019 |  | April 28, 2019 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 3,105 |  |  | $ | 3,014 |  |  | $ | 2,579 |  |  | $ | 2,220 |  |
| Cost of revenue | $ | 1,090 |  |  | $ | 1,098 |  |  | $ | 1,038 |  |  | $ | 924 |  |
| Gross profit | $ | 2,015 |  |  | $ | 1,916 |  |  | $ | 1,541 |  |  | $ | 1,296 |  |
| Net income | $ | 950 |  |  | $ | 899 |  |  | $ | 552 |  |  | $ | 394 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.55 |  |  | $ | 1.47 |  |  | $ | 0.91 |  |  | $ | 0.65 |  |
| Diluted | $ | 1.53 |  |  | $ | 1.45 |  |  | $ | 0.90 |  |  | $ | 0.64 |  |

[0001045810-20-000010:notes:237]
|  | Fiscal Year 2019Quarters Ended |
|  | January 27, 2019 |  | October 28, 2018 |  | July 29,2018 |  | April 29, 2018 |
|  | (In millions, except per share data) |
| Statements of Income Data: |  |  |  |  |  |  |  |
| Revenue | $ | 2,205 |  |  | $ | 3,181 |  |  | $ | 3,123 |  |  | $ | 3,207 |  |
| Cost of revenue | $ | 998 |  |  | $ | 1,260 |  |  | $ | 1,148 |  |  | $ | 1,139 |  |
| Gross profit | $ | 1,207 |  |  | $ | 1,921 |  |  | $ | 1,975 |  |  | $ | 2,068 |  |
| Net income (1) | $ | 567 |  |  | $ | 1,230 |  |  | $ | 1,101 |  |  | $ | 1,244 |  |
| Net income per share (1): |  |  |  |  |  |  |  |
| Basic | $ | 0.93 |  |  | $ | 2.02 |  |  | $ | 1.81 |  |  | $ | 2.05 |  |
| Diluted | $ | 0.92 |  |  | $ | 1.97 |  |  | $ | 1.76 |  |  | $ | 1.98 |  |

[0001045810-20-000010:notes:238]
In the third and fourth quarters of fiscal year 2019, we recorded U.S. tax reform benefits of $138 million and $230 million, respectively, associated with the completion of our accounting for the enactment-date income tax effects of the TCJA.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-20-000010:notes:239]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-20-000010:notes:240]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2020 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 8 |  |  | $ | 18 |  | (2) | $ | (17 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 562 |  |  | $ | 59 |  | (3) | $ | — |  |  | $ | 621 |  |
| Fiscal year 2019 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | (2 | ) | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 21 |  | (2) | $ | (22 | ) | (4) | $ | 8 |  |
| Deferred tax valuation allowance |  | $ | 469 |  |  | $ | 93 |  | (3) | $ | — |  |  | $ | 562 |  |
| Fiscal year 2018 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3 |  |  | $ | 1 |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 10 |  |  | $ | 15 |  | (2) | $ | (16 | ) | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 353 |  |  | $ | 116 |  | (3) | $ | — |  |  | $ | 469 |  |

[0001045810-20-000010:notes:241]
| (1) | Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end. |

[0001045810-20-000010:notes:242]
| (2) | Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue. |

[0001045810-20-000010:notes:243]
| (3) | Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions. Refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information. |

[0001045810-20-000010:notes:244]
(4)

[0001045810-20-000010:notes:245]
Represents sales returns.
