# NVDA notes — 0001045810-21-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001045810-21-000010:notes:1]
Portions of the registrant's Proxy Statement for its 2021 Annual Meeting of Shareholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated by reference into Part III, Items 10-14 of this Annual Report on Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-21-000010:notes:2]
Organization and Summary of Significant Accounting Policies
Our Company

[0001045810-21-000010:notes:3]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-21-000010:notes:4]
All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

[0001045810-21-000010:notes:5]
Fiscal Year

[0001045810-21-000010:notes:6]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2021 is a 53-week year. Fiscal years 2020 and 2019 were both 52-week years.

[0001045810-21-000010:notes:7]
Reclassifications

[0001045810-21-000010:notes:8]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

[0001045810-21-000010:notes:9]
Principles of Consolidation

[0001045810-21-000010:notes:10]
Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

[0001045810-21-000010:notes:11]
Use of Estimates

[0001045810-21-000010:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. The inputs into our judgments and estimates consider the economic implications of COVID-19. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-21-000010:notes:13]
Revenue Recognition

[0001045810-21-000010:notes:14]
We derive our revenue from product sales, including hardware and systems, license and development arrangements, and software licensing. We determine revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract (where revenue is allocated on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation); and (5) recognition of revenue when, or as, we satisfy a performance obligation.

[0001045810-21-000010:notes:15]
Product Sales Revenue

[0001045810-21-000010:notes:16]
Revenue from product sales is recognized upon transfer of control of promised products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Certain products are sold along with support or extended warranty. Support and extended warranty revenue are recognized ratably over the service period, or as services are performed. Revenue is recognized net of allowances for returns, customer programs and any taxes collected from customers.

[0001045810-21-000010:notes:17]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

[0001045810-21-000010:notes:18]
Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

[0001045810-21-000010:notes:19]
License and Development Arrangements

[0001045810-21-000010:notes:20]
Our license and development arrangements with customers typically require significant customization of our intellectual property components. As a result, we recognize the revenue from the license and the revenue from the development services as a single performance obligation over the period in which the development services are performed. We measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. If a loss on an arrangement becomes probable during a period, we record a provision for such loss in that period.

[0001045810-21-000010:notes:21]
Software Licensing

[0001045810-21-000010:notes:22]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.

[0001045810-21-000010:notes:23]
Product Warranties

[0001045810-21-000010:notes:24]
We generally offer a limited warranty to end-users that ranges from one to three years for products in order to repair or replace products for any manufacturing defects or hardware component failures. Cost of revenue includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated.

[0001045810-21-000010:notes:25]
Stock-based Compensation

[0001045810-21-000010:notes:26]
We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model. We estimate the fair value of shares to be issued under our employee stock purchase plan, or ESPP, using the Black-Scholes model at the commencement of an offering period in March and September of each year. Stock-based compensation for our ESPP is expensed using an accelerated amortization model. Additionally, we estimate forfeitures annually based on historical experience and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates.

[0001045810-21-000010:notes:27]
Litigation, Investigation and Settlement Costs

[0001045810-21-000010:notes:28]
From time to time, we are involved in legal actions and/or investigations by regulatory bodies. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third-party claims against us will be resolved without litigation, fines and/or substantial settlement payments. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss in accordance with U.S. GAAP. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs.

[0001045810-21-000010:notes:29]
Foreign Currency Remeasurement

[0001045810-21-000010:notes:30]
We use the United States dollar as our functional currency for all of our subsidiaries. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property and equipment, and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at average exchange rates in effect during each period, except for those expenses related to the previously noted balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in other income or expense in our Consolidated Statements of Income and to date have not been significant.

[0001045810-21-000010:notes:31]
Income Taxes

[0001045810-21-000010:notes:32]
We recognize federal, state and foreign current tax liabilities or assets based on our estimate of taxes payable or refundable in the current fiscal year by tax jurisdiction. We recognize federal, state and foreign deferred tax assets or liabilities, as appropriate, for our estimate of future tax effects attributable to temporary differences and carryforwards; and we record a valuation allowance to reduce any deferred tax assets by the amount of any tax benefits that, based on available evidence and judgment, are not expected to be realized.

[0001045810-21-000010:notes:33]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the United States, or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential United States and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-21-000010:notes:34]
As of January 31, 2021, we had a valuation allowance of $728 million related to state and certain foreign deferred tax assets that management determined are not likely to be realized due to jurisdictional projections of future taxable income, tax attributes usage limitation by certain jurisdictions, and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as an income tax benefit during the period.

[0001045810-21-000010:notes:35]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-21-000010:notes:36]
Net Income Per Share

[0001045810-21-000010:notes:37]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of equity awards outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive.

[0001045810-21-000010:notes:38]
Cash and Cash Equivalents and Marketable Securities

[0001045810-21-000010:notes:39]
We consider all highly liquid investments that are readily convertible into cash and have an original maturity of three months or less at the time of purchase to be cash equivalents. Marketable securities consist of highly liquid debt investments with maturities of greater than three months when purchased. We currently classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0001045810-21-000010:notes:40]
We generally classify our cash equivalents and marketable securities related to debt securities at the date of acquisition as available-for-sale. These available-for-sale debt securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. The fair value of interest-bearing debt securities includes accrued interest. Realized gains and losses on the sale of marketable securities are determined using the specific-identification method and recorded in the other income (expense), net, section of our Consolidated Statements of Income.

[0001045810-21-000010:notes:41]
All of our available-for-sale debt investments are subject to a periodic impairment review. If the estimated fair value of an available-for-sale debt securities is less than its amortized cost basis, we determine if the difference, if any, is caused by expected credit losses and write-down the amortized cost basis of the securities if it is more likely than not we will be required or we intend to sell the securities before recovery of its amortized cost basis. Allowances for credit losses and write-downs are recognized in other income (expense), net section of our Consolidated Statements of Income.

[0001045810-21-000010:notes:42]
Fair Value of Financial Instruments

[0001045810-21-000010:notes:43]
The carrying value of cash equivalents, accounts receivable, accounts payable and accrued liabilities approximate their fair values due to their relatively short maturities as of January 31, 2021 and January 26, 2020. Marketable securities are comprised of available-for-sale securities that are reported at fair value with the related unrealized gains or losses

[0001045810-21-000010:notes:44]
included in accumulated other comprehensive income or loss, a component of shareholders’ equity, net of tax. Fair value of the marketable securities is determined based on quoted market prices. Derivative instruments are recognized as either assets or liabilities and are measured at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For derivative instruments designated as fair value hedges, the gains or losses are recognized in earnings in the periods of change together with the offsetting losses or gains on the hedged items attributed to the risk being hedged. For derivative instruments designated as cash-flow hedges, the effective portion of the gains or losses on the derivatives is initially reported as a component of other comprehensive income or loss and is subsequently recognized in earnings when the hedged exposure is recognized in earnings. For derivative instruments not designated for hedge accounting, changes in fair value are recognized in earnings.

[0001045810-21-000010:notes:45]
Concentration of Credit Risk

[0001045810-21-000010:notes:46]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio duration. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure. Our overall estimated exposure excludes amounts covered by credit insurance and letters of credit.

[0001045810-21-000010:notes:47]
Accounts Receivable

[0001045810-21-000010:notes:48]
We maintain an allowance for doubtful accounts receivable for expected losses resulting from the inability of our customers to make required payments. We determine this allowance by identifying amounts for specific customer issues as well as amounts based on overall estimated exposure. Factors impacting the allowance include the level of gross receivables, the financial condition of our customers and the extent to which balances are covered by credit insurance or letters of credit.

[0001045810-21-000010:notes:49]
Inventories

[0001045810-21-000010:notes:50]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory. Most of our inventory provisions relate to excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.

[0001045810-21-000010:notes:51]
Property and Equipment

[0001045810-21-000010:notes:52]
Property and equipment are stated at cost. Depreciation of property and equipment is computed using the straight-line method based on the estimated useful lives of the assets, generally three to five years. Once an asset is identified for retirement or disposition, the related cost and accumulated depreciation or amortization are removed, and a gain or loss is recorded. The estimated useful lives of our buildings are up to thirty years. Depreciation expense includes the amortization of assets recorded under finance leases. Leasehold improvements and assets recorded under finance leases are amortized over the shorter of the expected lease term or the estimated useful life of the asset.

[0001045810-21-000010:notes:53]
Leases

[0001045810-21-000010:notes:54]
We determine if an arrangement is or contains a lease at inception. Operating leases with lease terms of more than 12 months are included in operating lease assets, accrued and other current liabilities, and long-term operating lease liabilities on our consolidated balance sheet. Operating lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term.

[0001045810-21-000010:notes:55]
Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using our incremental borrowing rate. Operating lease assets also include initial direct costs incurred and prepaid lease payments, minus any lease incentives. Our lease terms include options to extend or terminate the lease

[0001045810-21-000010:notes:56]
when it is reasonably certain that we will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0001045810-21-000010:notes:57]
We combine the lease and non-lease components in determining the operating lease assets and liabilities.

[0001045810-21-000010:notes:58]
Goodwill

[0001045810-21-000010:notes:59]
Goodwill is subject to our annual impairment test during the fourth quarter of our fiscal year, or earlier if indicators of potential impairment exist. For the purposes of completing our impairment test, we perform either a qualitative or a quantitative analysis on a reporting unit basis.

[0001045810-21-000010:notes:60]
Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting units.

[0001045810-21-000010:notes:61]
Our quantitative impairment test considers both the income approach and the market approach to estimate a reporting unit’s fair value. The income and market valuation approaches consider a number of factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

[0001045810-21-000010:notes:62]
Intangible Assets and Other Long-Lived Assets

[0001045810-21-000010:notes:63]
Intangible assets primarily represent acquired intangible assets including developed technology, in-process research and development, or IPR&D, and customer relationships, as well as rights acquired under technology licenses, patents, and acquired intellectual property. We currently amortize our intangible assets with finite lives over periods ranging from two to twenty years using a method that reflects the pattern in which the economic benefits of the intangible asset are consumed or otherwise used up or, if that pattern cannot be reliably determined, using a straight-line amortization method. We initially capitalize the fair value of IPR&D as an intangible asset with an indefinite life. When IPR&D projects are completed, we reclassify the IPR&D as an amortizable purchased intangible asset and amortize over the asset’s estimated useful life.

[0001045810-21-000010:notes:64]
Long-lived assets, such as property and equipment and intangible assets subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset or asset group may not be recoverable. Recoverability of assets or asset groups to be held and used is measured by a comparison of the carrying amount of an asset or asset group to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset or asset group exceeds its estimated future cash flows, an impairment charge is recognized for the amount by which the carrying amount of the asset or asset group exceeds the estimated fair value of the asset or asset group. Fair value is determined based on the estimated discounted future cash flows expected to be generated by the asset or asset group. Assets and liabilities to be disposed of would be separately presented in the Consolidated Balance Sheet and the assets would be reported at the lower of the carrying amount or fair value less costs to sell, and would no longer be depreciated.

[0001045810-21-000010:notes:65]
Business Combination

[0001045810-21-000010:notes:66]
We allocate the fair value of the purchase price of an acquisition to the tangible assets acquired, liabilities assumed, and intangible assets acquired, including IPR&D, based on their estimated fair values. The excess of the fair value of the purchase price over the fair values of these net tangible and intangible assets acquired is recorded as goodwill. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but our estimates and assumptions are inherently uncertain and subject to refinement. The estimates and assumptions used in valuing intangible assets include, but are not limited to, the amount and timing of projected future cash flows, discount rate used to determine the present value of these cash flows and asset lives. These estimates are inherently uncertain and, therefore, actual results may differ from the estimates made. As a result, during the measurement period of up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the fair value of the purchase price of an acquisition, whichever comes first, any subsequent adjustments are recorded to our Consolidated Statements of Income.

[0001045810-21-000010:notes:67]
Acquisition-related expenses are recognized separately from the business combination and expensed as incurred.

[0001045810-21-000010:notes:68]
Investment in Non-Affiliated Entities

[0001045810-21-000010:notes:69]
Non-marketable equity investments in privately-held companies are recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. These investments are valued using observable and unobservable inputs or data in an inactive market and the valuation requires our judgment due to the absence of market prices and inherent lack of liquidity. The estimated fair value is based on quantitative and qualitative factors including subsequent financing activities by the investee.

[0001045810-21-000010:notes:70]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-21-000010:notes:71]
Recently Adopted Accounting Pronouncement

[0001045810-21-000010:notes:72]
In June 2016, the Financial Accounting Standards Board issued a new accounting standard to replace the existing incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates for accounts receivable and other financial instruments, including available-for-sale debt securities. We adopted the standard in the first quarter of fiscal year 2021 and the impact of the adoption was not material to our consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001045810-21-000010:notes:73]
Business Combination
Pending Acquisition of Arm Limited

[0001045810-21-000010:notes:74]
On September 13, 2020, we entered into a Purchase Agreement with Arm and SoftBank for us to acquire, from SoftBank all allotted and issued ordinary shares of Arm in a transaction valued at $40 billion. We paid $2 billion in Signing Consideration and will pay upon closing of the acquisition $10 billion in cash and issue to SoftBank 44.3 million shares of our common stock with an aggregate value of $21.5 billion. The transaction includes a potential earn out, which is contingent on the achievement of certain financial performance targets by Arm during the fiscal year ending March 31, 2022. If the financial targets are achieved, SoftBank can elect to receive either up to an additional $5 billion in cash or up to an additional 10.3 million shares of our common stock. We will issue up to $1.5 billion in restricted stock units to Arm employees after closing. The $2 billion paid upon signing was allocated between advanced consideration for the acquisition of $1.36 billion and the prepayment of intellectual property licenses from Arm of $0.17 billion and royalties of $0.47 billion, both with a 20-year term. The closing of the acquisition is subject to customary closing conditions, including receipt of specified governmental and regulatory consents and approvals and expiration of any related mandatory waiting period, and Arm's implementation of the reorganization and distribution of Arm’s IoT Services Group and certain other assets and liabilities. We are engaged with regulators in the United States, the United Kingdom, the European Union, China and other jurisdictions. If the Purchase Agreement is terminated under certain circumstances, we will be refunded $1.25 billion of the Signing Consideration. The $2 billion payment upon signing was allocated on a fair value basis and any refund of the Signing Consideration will use stated values in the Purchase Agreement. We believe the closing of the acquisition will likely occur in the first quarter of calendar year 2022.

[0001045810-21-000010:notes:75]
Acquisition of Mellanox Technologies, Ltd.

[0001045810-21-000010:notes:76]
On April 27, 2020, we completed the acquisition of all outstanding shares of Mellanox for a total purchase consideration of $7.13 billion. Mellanox is a supplier of high-performance interconnect products for computing, storage and communications applications. We acquired Mellanox to optimize data center workloads to scale across the entire computing, networking, and storage stack.

[0001045810-21-000010:notes:77]
Purchase Price Allocation

[0001045810-21-000010:notes:78]
The aggregate purchase consideration has been allocated as follows (in millions):

[0001045810-21-000010:notes:79]
| Purchase Price |  |  |
| Cash paid for outstanding Mellanox ordinary shares (1) |  | $ | 7,033 |  |
| Cash for Mellanox equity awards (2) |  | 16 |  |
| Total cash consideration |  | 7,049 |  |
| Fair value of Mellanox equity awards assumed by NVIDIA (3) |  | 85 |  |
| Total purchase consideration |  | $ | 7,134 |  |
| Allocation |  |  |
| Cash and cash equivalents |  | $ | 115 |  |
| Marketable securities |  | 699 |  |
| Accounts receivable, net |  | 216 |  |
| Inventories |  | 320 |  |
| Prepaid expenses and other assets |  | 179 |  |
| Property and equipment, net |  | 144 |  |
| Goodwill |  | 3,431 |  |
| Intangible assets |  | 2,970 |  |
| Accounts payable |  | (136) |  |
| Accrued and other current liabilities |  | (236) |  |
| Income tax liability |  | (191) |  |
| Deferred income tax liability |  | (258) |  |
| Other long-term liabilities |  | (119) |  |
|  |  | $ | 7,134 |  |

[0001045810-21-000010:notes:80]
(1)    Represents the cash consideration of $125.00 per share paid to Mellanox shareholders for approximately 56 million shares of outstanding Mellanox ordinary shares.

[0001045810-21-000010:notes:81]
(2)    Represents the cash consideration for the settlement of approximately 249 thousand Mellanox stock options held by employees and non-employee directors of Mellanox.

[0001045810-21-000010:notes:82]
(3)    Represents the fair value of Mellanox’s stock-based compensation awards attributable to pre-combination services.

[0001045810-21-000010:notes:83]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on the estimated fair values.

[0001045810-21-000010:notes:84]
The goodwill is primarily attributable to the planned growth in the combined business of NVIDIA and Mellanox. Goodwill is not amortized to earnings, but instead is reviewed for impairment at least annually, absent any interim indicators of impairment. Goodwill recognized in the acquisition is not expected to be deductible for foreign tax purposes. Goodwill arising from the Mellanox acquisition has been allocated to the Compute and Networking segment. Refer to Note 17 – Segment Information for further details on segments.

[0001045810-21-000010:notes:85]
The operating results of Mellanox have been included in our consolidated financial statements for fiscal year 2021 since the acquisition date of April 27, 2020. Revenue attributable to Mellanox was approximately 10% for fiscal year 2021. There is not a practical way to determine net income attributable to Mellanox due to integration. Acquisition-related costs attributable to Mellanox of $28 million were included in selling, general and administrative expense for fiscal year 2021.

[0001045810-21-000010:notes:86]
Intangible Assets

[0001045810-21-000010:notes:87]
The estimated fair value and useful life of the acquired intangible assets are as follows:

[0001045810-21-000010:notes:88]
|  | Fair Value |  | Useful Lives |
|  | (In millions) |  |  |
| Developed technology (1) | $ | 1,640 |  |  | 5 years |
| Customer relationships (2) | 440 |  |  | 3 years |
| Order backlog (3) | 190 |  |  | Based on actual shipments |
| Trade names (4) | 70 |  |  | 5 years |
| Total identified finite-lived intangible assets | 2,340 |  |  |  |
| IPR&D (5) | 630 |  |  | N/A |
| Total identified intangible assets | $ | 2,970 |  |  |  |

[0001045810-21-000010:notes:89]
(1)    The fair value of developed technology was identified using the Multi-Period Excess Earnings Method.

[0001045810-21-000010:notes:90]
(2)    Customer relationships represent the fair value of the existing relationships using the With and Without Method.

[0001045810-21-000010:notes:91]
(3)    Order backlog represents primarily the fair value of purchase arrangements with customers using the Multi-Period Excess Earnings Method. The intangible asset was fully amortized as of January 31, 2021.

[0001045810-21-000010:notes:92]
(4)    Trade names primarily relate to Mellanox trade names and fair value was determined by applying the Relief-from-Royalty Method under the income approach.

[0001045810-21-000010:notes:93]
(5)    The fair value of IPR&D was determined using the Multi-Period Excess Earnings Method.

[0001045810-21-000010:notes:94]
The fair value of the finite-lived intangible assets will be amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received to cost of revenue and operating expenses.

[0001045810-21-000010:notes:95]
Mellanox had an IPR&D project associated with the next generation interconnect product that had not yet reached technological feasibility as of the acquisition date. Accordingly, we recorded an indefinite-lived intangible asset of $630 million for the fair value of this project, which will initially not be amortized. Instead, the project will be tested for impairment annually and whenever events or changes in circumstances indicate that the project may be impaired or may have reached technological feasibility. Once the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life.

[0001045810-21-000010:notes:96]
Supplemental Unaudited Pro Forma Information

[0001045810-21-000010:notes:97]
The following unaudited pro forma financial information summarizes the combined results of operations for NVIDIA and Mellanox as if the companies were combined as of the beginning of fiscal year 2020:

[0001045810-21-000010:notes:98]
|  | Pro Forma |
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Revenue | $ | 17,104 |  |  | $ | 12,250 |  |
| Net income | $ | 4,757 |  |  | $ | 2,114 |  |

[0001045810-21-000010:notes:99]
The unaudited pro forma information includes adjustments related to amortization of acquired intangible assets, adjustments to stock-based compensation expense, fair value of acquired inventory, and transaction costs. The unaudited pro forma information presented above is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2020 or of the results of our future operations of the combined businesses.

[0001045810-21-000010:notes:100]
The pro forma results reflect the inventory step-up expense of $161 million in the fiscal year 2020 and were excluded from the pro forma results for fiscal year 2021. There were no other material nonrecurring adjustments.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-21-000010:notes:101]
Leases
On January 28, 2019, we adopted the new lease accounting standard using the optional transition method.

[0001045810-21-000010:notes:102]
Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2022 and 2035.

[0001045810-21-000010:notes:103]
Future minimum lease payments under our non-cancelable operating leases as of January 31, 2021, are as follows:

[0001045810-21-000010:notes:104]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2022 | $ | 152 |  |
| 2023 | 135 |  |
| 2024 | 115 |  |
| 2025 | 94 |  |
| 2026 | 86 |  |
| 2027 and thereafter | 288 |  |
| Total | 870 |  |
| Less imputed interest | 115 |  |
| Present value of net future minimum lease payments | 755 |  |
| Less short-term operating lease liabilities | 121 |  |
| Long-term operating lease liabilities | $ | 634 |  |

[0001045810-21-000010:notes:105]
Operating lease expense for fiscal years 2021, 2020, and 2019 was $145 million, $114 million, $80 million, respectively. Short-term and variable lease expenses for fiscal years 2021 and 2020 were not significant.

[0001045810-21-000010:notes:106]
Other information related to leases was as follows:

[0001045810-21-000010:notes:107]
|  | Year Ended |
|  | January 31, 2021 |  | January 26, 2020 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flows used for operating leases | $ | 141 |  |  | $ | 103 |  |
| Operating lease assets obtained in exchange for lease obligations (1) | $ | 200 |  |  | $ | 238 |  |

[0001045810-21-000010:notes:108]
(1)    Fiscal year 2021 includes $80 million of operating lease assets addition due to a business combination.

[0001045810-21-000010:notes:109]
As of January 31, 2021, our operating leases had a weighted average remaining lease term of 7.6 years and a weighted average discount rate of 2.87%. As of January 26, 2020, our operating leases had a weighted average remaining lease term of 8.3 years and a weighted average discount rate of 3.45%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-21-000010:notes:110]
Stock-Based CompensationOur stock-based compensation expense is associated with restricted stock units, or RSUs, performance stock units that are based on our corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our ESPP.
Our Consolidated Statements of Income include stock-based compensation expense, net of amounts allocated to inventory, as follows:

[0001045810-21-000010:notes:111]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Cost of revenue | $ | 88 |  |  | $ | 39 |  |  | $ | 27 |  |
| Research and development | 860 |  |  | 540 |  |  | 336 |  |
| Sales, general and administrative | 449 |  |  | 265 |  |  | 194 |  |
| Total | $ | 1,397 |  |  | $ | 844 |  |  | $ | 557 |  |

[0001045810-21-000010:notes:112]
Stock-based compensation capitalized in inventories was not significant during fiscal years 2021, 2020, and 2019.

[0001045810-21-000010:notes:113]
The following is a summary of equity awards granted under our equity incentive plans:

[0001045810-21-000010:notes:114]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions, except per share data) |
| RSUs, PSUs and Market-based PSUs |  |  |  |  |  |
| Awards granted | 9 |  |  | 7 |  |  | 4 |  |
| Estimated total grant-date fair value | $ | 2,764 |  |  | $ | 1,282 |  |  | $ | 1,109 |  |
| Weighted average grant-date fair value per share | $ | 307.25 |  |  | $ | 184.47 |  |  | $ | 258.26 |  |
| ESPP |  |  |  |  |  |
| Shares purchased | 1 |  |  | 1 |  |  | 1 |  |
| Weighted average price per share | $ | 139.19 |  |  | $ | 148.76 |  |  | $ | 107.48 |  |
| Weighted average grant-date fair value per share | $ | 67.65 |  |  | $ | 64.87 |  |  | $ | 38.51 |  |

[0001045810-21-000010:notes:115]
As of January 31, 2021, there was $3.17 billion of aggregate unearned stock-based compensation expense, net of forfeitures. This amount is expected to be recognized over a weighted average period of 2.5 years for RSUs, PSUs, and market-based PSUs, and 0.9 years for ESPP.

[0001045810-21-000010:notes:116]
The fair value of shares issued under our ESPP have been estimated with the following assumptions:

[0001045810-21-000010:notes:117]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (Using the Black-Scholes model) |
| ESPP |  |  |  |  |  |
| Weighted average expected life (in years) | 0.1-2.0 |  | 0.1-2.0 |  | 0.1-2.0 |
| Risk-free interest rate | 0.1%-1.6% |  | 1.5%-2.6% |  | 1.6%-2.8% |
| Volatility | 26%-89% |  | 30%-82% |  | 24%-75% |
| Dividend yield | 0.1%-0.3% |  | 0.3%-0.4% |  | 0.3%-0.4% |

[0001045810-21-000010:notes:118]
For ESPP shares, the expected term represents the average term from the first day of the offering period to the purchase date. The risk-free interest rate assumption used to value ESPP shares is based upon observed interest rates on Treasury bills appropriate for the expected term. Our expected stock price volatility assumption for ESPP is estimated using historical volatility. For awards granted, we use the dividend yield at grant date. Our RSU, PSU, and market-based PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair values of RSUs, PSUs, and market-based PSUs are discounted for the dividend yield.

[0001045810-21-000010:notes:119]
Additionally, for RSU, PSU, and market-based PSU awards, we estimate forfeitures semi-annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-21-000010:notes:120]
Equity Incentive Program

[0001045810-21-000010:notes:121]
We grant or have granted stock options, RSUs, PSUs, market-based PSUs, and stock purchase rights under the following equity incentive plans. In addition, in connection with our acquisitions of various companies, we have assumed the stock-based awards granted under their stock incentive plans and substituted them with our RSUs.

[0001045810-21-000010:notes:122]
Amended and Restated 2007 Equity Incentive Plan

[0001045810-21-000010:notes:123]
In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, as most recently amended and restated, the 2007 Plan.

[0001045810-21-000010:notes:124]
The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock units, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. As of January 31, 2021, up to 244 million shares of our common stock could be issued pursuant to stock awards granted under the 2007 Plan, of which 2 million shares were issuable upon the exercise of outstanding stock options. All options are fully vested, the last of which will expire by May 2024 if not exercised. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 31, 2021, there were 37 million shares available for future issuance.

[0001045810-21-000010:notes:125]
Subject to certain exceptions, RSUs and PSUs granted to employees either vest (A) over a four-year period, subject to continued service, with 25% vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25% vesting quarterly thereafter, or (B) over a three-year period, subject to continued service, with 40% vesting on a pre-determined date that is close to the anniversary of the date of grant and 7.5% vesting quarterly thereafter. Market-based PSUs vest 100% on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

[0001045810-21-000010:notes:126]
Amended and Restated 2012 Employee Stock Purchase Plan

[0001045810-21-000010:notes:127]
In 2012, our shareholders approved the 2012 Employee Stock Purchase Plan, as most recently amended and restated, the 2012 Plan.

[0001045810-21-000010:notes:128]
Employees who participate may have up to 10% of their earnings withheld to the purchase of shares of common stock. Starting in March 2021, employees who participate may have up to 15% of their earnings withheld to purchase shares of common stock. The Board may decrease this percentage at its discretion. Each offering period is approximately 24 months, which is generally divided into four purchase periods of six months. The price of common stock purchased under our 2012 Plan will be equal to 85% of the lower of the fair market value of the common stock on the commencement date of each offering period and the fair market value on each purchase date within the offering. As of January 31, 2021, we had 60 million shares reserved for future issuance under the 2012 Plan.

[0001045810-21-000010:notes:129]
Equity Award Activity

[0001045810-21-000010:notes:130]
The following is a summary of our equity award transactions under our equity incentive plans:

[0001045810-21-000010:notes:131]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
|  | (In millions, except years and per share data) |
| Balances, January 26, 2020 | 14 |  |  | $ | 176.72 |  |
| Granted | 9 |  |  | $ | 307.25 |  |
| Vested restricted stock | (7) |  |  | $ | 159.35 |  |
| Canceled and forfeited | (1) |  |  | $ | 193.83 |  |
| Balances, January 31, 2021 | 15 |  |  | $ | 264.69 |  |
| Vested and expected to vest after January 31, 2021 | 14 |  |  | $ | 264.13 |  |

[0001045810-21-000010:notes:132]
As of January 31, 2021 and January 26, 2020, there were 37 million and 29 million shares, respectively, of common stock reserved for future issuance under our equity incentive plans.

[0001045810-21-000010:notes:133]
As of January 31, 2021, the total intrinsic value of options currently exercisable and outstanding was $1.20 billion, with an average exercise price of $14.40 per share and an average remaining term of 1.7 years. The total intrinsic value of options exercised was $521 million, $84 million, and $180 million for fiscal years 2021, 2020, and 2019, respectively. Upon the exercise of an option, we issue new shares of stock.

[0001045810-21-000010:notes:134]
The total fair value of RSUs and PSUs, as of their respective vesting dates, during the years ended January 31, 2021, January 26, 2020, and January 27, 2019, was $2.67 billion, $1.45 billion, and $2.62 billion, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-21-000010:notes:135]
Net Income Per Share
The following is a reconciliation of the denominator of the basic and diluted net income per share computations for the periods presented:

[0001045810-21-000010:notes:136]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |
| Net income | $ | 4,332 |  |  | $ | 2,796 |  |  | $ | 4,141 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average shares | 617 |  |  | 609 |  |  | 608 |  |
| Dilutive impact of outstanding equity awards | 11 |  |  | 9 |  |  | 17 |  |
| Diluted weighted average shares | 628 |  |  | 618 |  |  | 625 |  |
| Net income per share: |  |  |  |  |  |
| Basic (1) | $ | 7.02 |  |  | $ | 4.59 |  |  | $ | 6.81 |  |
| Diluted (2) | $ | 6.90 |  |  | $ | 4.52 |  |  | $ | 6.63 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 3 |  |  | 11 |  |  | 5 |  |

[0001045810-21-000010:notes:137]
(1)    Calculated as net income divided by basic weighted average shares.

[0001045810-21-000010:notes:138]
(2)    Calculated as net income divided by diluted weighted average shares.


## us-gaap:GoodwillDisclosureTextBlock

[0001045810-21-000010:notes:139]
GoodwillWe changed our reportable segments to "Graphics" and "Compute & Networking" starting with the first quarter of fiscal year 2021, as discussed in Note 17 of these Notes to the Consolidated Financial Statements. As a result, our reporting units also changed, and we reassigned the goodwill balance to the new reporting units based on their relative fair values. Comparative periods presented reflect this change. We determined there was no goodwill impairment immediately prior to the reorganization. As of January 31, 2021, the total carrying amount of goodwill was $4.19 billion and the amount of goodwill allocated to our Graphics and Compute & Networking reporting units was $347 million and $3.85 billion, respectively. As of January 26, 2020, the total carrying amount of goodwill was $618 million and the amount of goodwill allocated to our Graphics and Compute & Networking reporting units was $347 million and $271 million, respectively. Goodwill increased by $3.57 billion in fiscal year 2021 due to goodwill of $3.43 billion arising from the Mellanox acquisition, and goodwill of $143 million from other acquisition activities, all of which were allocated to the Compute & Networking reporting unit. During the fourth quarters of fiscal years 2021, 2020, and 2019, we completed our annual impairment tests and concluded that goodwill was not impaired in any of these years.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-21-000010:notes:140]
Amortizable Intangible Assets
The components of our amortizable intangible assets are as follows:

[0001045810-21-000010:notes:141]
|  | January 31, 2021 |  | January 26, 2020 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets (1) | $ | 3,280 |  |  | $ | (774) |  |  | $ | 2,506 |  |  | $ | 195 |  |  | $ | (192) |  |  | $ | 3 |  |
| Patents and licensed technology | 706 |  |  | (475) |  |  | 231 |  |  | 520 |  |  | (474) |  |  | 46 |  |
| Total intangible assets | $ | 3,986 |  |  | $ | (1,249) |  |  | $ | 2,737 |  |  | $ | 715 |  |  | $ | (666) |  |  | $ | 49 |  |

[0001045810-21-000010:notes:142]
(1)    As of January 31, 2021, acquisition-related intangible assets include the fair value of a Mellanox IPR&D project of $630 million, which has not been amortized. Once the project reaches technological feasibility, we will begin to amortize the intangible asset over its estimated useful life. Refer to Note 2 of these Notes to the Consolidated Financial Statements for further details.

[0001045810-21-000010:notes:143]
Amortization expense associated with intangible assets for fiscal years 2021, 2020, and 2019 was $612 million, $25 million, and $29 million, respectively. Future amortization expense related to the net carrying amount of intangible assets as of January 31, 2021 is estimated to be $548 million in fiscal year 2022, $545 million in fiscal year 2023, $423 million in fiscal year 2024, $367 million in fiscal year 2025, $97 million in fiscal year 2026, and $757 million in fiscal year 2027 and thereafter.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-21-000010:notes:144]
Cash Equivalents and Marketable SecuritiesOur cash equivalents and marketable securities related to debt securities are classified as “available-for-sale” debt securities. 
The following is a summary of cash equivalents and marketable securities as of January 31, 2021 and January 26, 2020:

[0001045810-21-000010:notes:145]
|  | January 31, 2021 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 4,442 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4,444 |  |  | $ | 234 |  |  | $ | 4,210 |  |
| Debt securities issued by United States government agencies | 2,975 |  |  | 1 |  |  | — |  |  | 2,976 |  |  | 28 |  |  | 2,948 |  |
| Debt securities issued by the United States Treasury | 2,846 |  |  | — |  |  | — |  |  | 2,846 |  |  | 25 |  |  | 2,821 |  |
| Certificates of deposit | 705 |  |  | — |  |  | — |  |  | 705 |  |  | 37 |  |  | 668 |  |
| Money market funds | 313 |  |  | — |  |  | — |  |  | 313 |  |  | 313 |  |  | — |  |
| Foreign government bonds | 67 |  |  | — |  |  | — |  |  | 67 |  |  |  |  | 67 |  |
| Total | $ | 11,348 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 11,351 |  |  | $ | 637 |  |  | $ | 10,714 |  |

[0001045810-21-000010:notes:146]
|  | January 26, 2020 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Money market funds | $ | 7,507 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,507 |  |  | $ | 7,507 |  |  | $ | — |  |
| Debt securities issued by the United States Treasury | 1,358 |  |  | — |  |  | — |  |  | 1,358 |  |  | 1,358 |  |  | — |  |
| Debt securities issued by United States government agencies | 1,096 |  |  | — |  |  | — |  |  | 1,096 |  |  | 1,096 |  |  | — |  |
| Corporate debt securities | 592 |  |  | — |  |  | — |  |  | 592 |  |  | 592 |  |  | — |  |
| Foreign government bonds | 200 |  |  | — |  |  | — |  |  | 200 |  |  | 200 |  |  | — |  |
| Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |  | 27 |  |  | — |  |
| Asset-backed securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 10,781 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,781 |  |  | $ | 10,780 |  |  | $ | 1 |  |

[0001045810-21-000010:notes:147]
Net realized gains and unrealized gains and losses were not significant for all periods presented.

[0001045810-21-000010:notes:148]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of January 31, 2021 and January 26, 2020 are shown below by contractual maturity.

[0001045810-21-000010:notes:149]
|  | January 31, 2021 |  | January 26, 2020 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than one year | $ | 10,782 |  |  | $ | 10,783 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |
| Due in 1 - 5 years | 566 |  |  | 568 |  |  | — |  |  | — |  |
| Total | $ | 11,348 |  |  | $ | 11,351 |  |  | $ | 10,781 |  |  | $ | 10,781 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-21-000010:notes:150]
The following is a summary of cash equivalents and marketable securities as of January 31, 2021 and January 26, 2020:


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-21-000010:notes:151]
Fair Value of Financial Assets and Liabilities
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

[0001045810-21-000010:notes:152]
|  |  | Fair Value at |
|  | Pricing Category |  | January 31, 2021 |  | January 26, 2020 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 313 |  |  | $ | 7,507 |  |
| Corporate debt securities | Level 2 |  | $ | 4,444 |  |  | $ | 592 |  |
| Debt securities issued by United States government agencies | Level 2 |  | $ | 2,976 |  |  | $ | 1,096 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 2,846 |  |  | $ | 1,358 |  |
| Certificates of deposit | Level 2 |  | $ | 705 |  |  | $ | 27 |  |
| Foreign government bonds | Level 2 |  | $ | 67 |  |  | $ | 200 |  |
| Asset-backed securities | Level 2 |  | $ | — |  |  | $ | 1 |  |
| Other asset: |  |  |  |  |  |
| Investment in non-affiliated entities (1) | Level 3 |  | $ | 144 |  |  | $ | 77 |  |
| Liabilities |  |  |  |  |  |
| 2.20% Notes Due 2021 (2) | Level 2 |  | $ | 1,011 |  |  | $ | 1,006 |  |
| 3.20% Notes Due 2026 (2) | Level 2 |  | $ | 1,124 |  |  | $ | 1,065 |  |
| 2.85% Notes Due 2030 (2) | Level 2 |  | $ | 1,654 |  |  | $ | — |  |
| 3.50% Notes Due 2040 (2) | Level 2 |  | $ | 1,152 |  |  | $ | — |  |
| 3.50% Notes Due 2050 (2) | Level 2 |  | $ | 2,308 |  |  | $ | — |  |
| 3.70% Notes Due 2060 (2) | Level 2 |  | $ | 602 |  |  | $ | — |  |

[0001045810-21-000010:notes:153]
(1)Investment in private non-affiliated entities is recorded at fair value on a non-recurring basis only if an impairment or observable price adjustment occurs in the period with changes in fair value recorded through net income. The amount recorded as of January 31, 2021 has not been significant.
(2)    These liabilities are carried on our Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. Refer to Note 12 of these Notes to the Consolidated Financial Statements for additional information


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-21-000010:notes:154]
Balance Sheet Components
Certain balance sheet components are as follows:

[0001045810-21-000010:notes:155]
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials | $ | 632 |  |  | $ | 249 |  |
| Work in-process | 457 |  |  | 265 |  |
| Finished goods | 737 |  |  | 465 |  |
| Total inventories | $ | 1,826 |  |  | $ | 979 |  |

[0001045810-21-000010:notes:156]
|  | January 31,2021 |  | January 26,2020 |  | EstimatedUseful Life |
|  | (In millions) |  | (In years) |
| Property and Equipment: |  |  |  |  |  |
| Land | $ | 218 |  |  | $ | 218 |  |  | (A) |
| Building | 341 |  |  | 340 |  |  | 25-30 |
| Test equipment | 782 |  |  | 532 |  |  | 3-5 |
| Computer equipment and software | 1,187 |  |  | 908 |  |  | 3-5 |
| Leasehold improvements | 385 |  |  | 293 |  |  | (B) |
| Office furniture and equipment | 86 |  |  | 74 |  |  | 5 |
| Construction in process | 558 |  |  | 320 |  |  | (C) |
| Total property and equipment, gross | 3,557 |  |  | 2,685 |  |  |  |
| Accumulated depreciation and amortization | (1,408) |  |  | (1,011) |  |  |  |
| Total property and equipment, net | $ | 2,149 |  |  | $ | 1,674 |  |  |  |

[0001045810-21-000010:notes:157]
(A)Land is a non-depreciable asset.

[0001045810-21-000010:notes:158]
(B)Leasehold improvements and finance leases are amortized based on the lesser of either the asset’s estimated useful life or the expected lease term.

[0001045810-21-000010:notes:159]
(C)Construction in process represents assets that are not available for their intended use as of the balance sheet date.

[0001045810-21-000010:notes:160]
Depreciation expense for fiscal years 2021, 2020, and 2019 was $486 million, $355 million, and $233 million, respectively.

[0001045810-21-000010:notes:161]
Accumulated amortization of leasehold improvements and finance leases was $223 million and $216 million as of January 31, 2021 and January 26, 2020, respectively.

[0001045810-21-000010:notes:162]
|  | January 31,2021 |  | January 26,2020 |
| Other assets: | (In millions) |
| Advanced consideration for acquisition | $ | 1,357 |  |  | $ | — |  |
| Prepaid royalties | 440 |  |  | 1 |  |
| Investment in non-affiliated entities | 144 |  |  | 77 |  |
| Deposits | 136 |  |  | 8 |  |
| Other | 67 |  |  | 32 |  |
| Total other assets | $ | 2,144 |  |  | $ | 118 |  |

[0001045810-21-000010:notes:163]
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Accrued and Other Current Liabilities: |  |  |  |
| Customer program accruals | $ | 630 |  |  | $ | 462 |  |
| Accrued payroll and related expenses | 297 |  |  | 185 |  |
| Deferred revenue (1) | 288 |  |  | 141 |  |
| Licenses and royalties | 128 |  |  | 66 |  |
| Operating leases | 121 |  |  | 91 |  |
| Coupon interest on debt obligations | 74 |  |  | 20 |  |
| Taxes payable | 61 |  |  | 61 |  |
| Product warranty and return provisions | 39 |  |  | 24 |  |
| Professional service fees | 26 |  |  | 18 |  |
| Other | 61 |  |  | 29 |  |
| Total accrued and other current liabilities | $ | 1,725 |  |  | $ | 1,097 |  |

[0001045810-21-000010:notes:164]
(1)Deferred revenue primarily includes customer advances and deferrals related to license and development arrangements and PCS.

[0001045810-21-000010:notes:165]
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Other Long-Term Liabilities: |  |  |  |
| Income tax payable (1) | $ | 836 |  |  | $ | 528 |  |
| Deferred income tax | 241 |  |  | 29 |  |
| Deferred revenue (2) | 163 |  |  | 60 |  |
| Licenses payable | 56 |  |  | 110 |  |
| Employee benefits | 33 |  |  | 22 |  |
| Other | 46 |  |  | 26 |  |
| Total other long-term liabilities | $ | 1,375 |  |  | $ | 775 |  |

[0001045810-21-000010:notes:166]
(1)As of January 31, 2021, income tax payable represents the long-term portion of the one-time transition tax payable of $284 million, long-term portion of the unrecognized tax benefits of $352 million, related interest and penalties of $43 million, and other foreign long-term tax payable of $157 million.

[0001045810-21-000010:notes:167]
(2)Deferred revenue primarily includes deferrals related to PCS.

[0001045810-21-000010:notes:168]
Deferred Revenue

[0001045810-21-000010:notes:169]
The following table shows the changes in deferred revenue during fiscal years 2021 and 2020.

[0001045810-21-000010:notes:170]
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Balance at beginning of period | $ | 201 |  |  | $ | 138 |  |
| Deferred revenue added during the period | 536 |  |  | 334 |  |
| Addition due to business combinations | 75 |  |  | — |  |
| Revenue recognized during the period | (361) |  |  | (271) |  |
| Balance at end of period | $ | 451 |  |  | $ | 201 |  |

[0001045810-21-000010:notes:171]
Revenue related to remaining performance obligations represents the remaining contracted license, development arrangements and PCS that has not been recognized. This includes related deferred revenue currently recorded and amounts that will be invoiced in future periods. As of January 31, 2021, the amount of our remaining performance that has not been recognized as revenue was $683 million, of which we expect to recognize approximately 44% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-21-000010:notes:172]
Derivative Financial Instruments
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. These contracts are designated as cash flow hedges for hedge accounting treatment. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of January 31, 2021 and January 26, 2020.

[0001045810-21-000010:notes:173]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than U.S. dollar. These forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded in other income or expense and offsets the change in fair value of the hedged foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense.

[0001045810-21-000010:notes:174]
The table below presents the notional value of our foreign currency forward contracts outstanding as of January 31, 2021 and January 26, 2020:

[0001045810-21-000010:notes:175]
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 840 |  |  | $ | 428 |  |
| Not designated for hedge accounting | $ | 441 |  |  | $ | 287 |  |

[0001045810-21-000010:notes:176]
As of January 31, 2021, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-21-000010:notes:177]
During fiscal years 2021 and 2020, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DebtDisclosureTextBlock

[0001045810-21-000010:notes:178]
Debt
Long-Term Debt

[0001045810-21-000010:notes:179]
In March 2020, we issued $1.50 billion of the 2.85% Notes Due 2030, $1.00 billion of the 3.50% Notes Due 2040, $2.00 billion of the 3.50% Notes Due 2050, and $500 million of the 3.70% Notes Due 2060, or collectively, the March 2020 Notes. Interest on the March 2020 Notes is payable on April 1 and October 1 of each year, beginning on October 1, 2020. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2030 on or after January 1, 2030, the Notes Due 2040 on or after October 1, 2039, the Notes Due 2050 on or after October 1, 2049, or the Notes Due 2060 on or after October 1, 2059. The net proceeds from the March 2020 Notes were $4.97 billion, after deducting debt discount and issuance costs.

[0001045810-21-000010:notes:180]
In September 2016, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the September 2016 Notes. Interest on the September 2016 Notes is payable on March 16 and September 16 of each year. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the September 2016 Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-21-000010:notes:181]
Both the September 2016 Notes and the March 2020 Notes, or collectively, the Notes, are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-21-000010:notes:182]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-21-000010:notes:183]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | January 31,2021 |  | January 26,2020 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 0.6 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 5.6 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 2.85% Notes Due 2030 |  | 9.2 |  | 2.93% |  | 1,500 |  |  | — |  |
| 3.50% Notes Due 2040 |  | 19.2 |  | 3.54% |  | 1,000 |  |  | — |  |
| 3.50% Notes Due 2050 |  | 29.2 |  | 3.54% |  | 2,000 |  |  | — |  |
| 3.70% Notes Due 2060 |  | 39.2 |  | 3.73% |  | 500 |  |  | — |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (37) |  |  | (9) |  |
| Net carrying amount |  |  |  |  |  | 6,963 |  |  | 1,991 |  |
| Less short-term portion |  |  |  |  |  | (999) |  |  | — |  |
| Total long-term portion |  |  |  |  |  | $ | 5,964 |  |  | $ | 1,991 |  |

[0001045810-21-000010:notes:184]
As of January 31, 2021, we were in compliance with the required covenants under the Notes.

[0001045810-21-000010:notes:185]
Credit Facilities

[0001045810-21-000010:notes:186]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of January 31, 2021, we had not borrowed any amounts and were in compliance with the required covenants under this agreement. The Credit Agreement expires October 2021.

[0001045810-21-000010:notes:187]
We have a $575 million commercial paper program to support general corporate purposes. As of January 31, 2021, we had not issued any commercial paper.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-21-000010:notes:188]
Commitments and Contingencies
Purchase Obligations

[0001045810-21-000010:notes:189]
As of January 31, 2021, we had outstanding inventory purchase obligations totaling $2.54 billion, which are expected to occur over the next 12 months, and other purchase obligations totaling $317 million, which are primarily expected to occur over the next 18 months.

[0001045810-21-000010:notes:190]
Accrual for Product Warranty Liabilities

[0001045810-21-000010:notes:191]
The estimated amount of product warranty liabilities was $22 million and $15 million as of January 31, 2021 and January 26, 2020, respectively.

[0001045810-21-000010:notes:192]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability for such indemnifications.

[0001045810-21-000010:notes:193]
Litigation

[0001045810-21-000010:notes:194]
Securities Class Action and Derivative Lawsuits

[0001045810-21-000010:notes:195]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation

[0001045810-21-000010:notes:196]
Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserts that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also allege that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs seek class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On June 29, 2020, NVIDIA moved to dismiss the amended complaint on the basis that plaintiffs failed to state any claims for violations of the securities laws by NVIDIA or the individual defendants. As of September 14, 2020, the motion was fully briefed but the Court has not yet issued a decision.

[0001045810-21-000010:notes:197]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, remains stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action. The lawsuit asserts claims for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-21-000010:notes:198]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of NVIDIA’s motion to dismiss the complaint in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-21-000010:notes:199]
It is possible that additional suits will be filed, or allegations received from shareholders, with respect to these same or other matters, naming NVIDIA and/or its officers and directors as defendants.

[0001045810-21-000010:notes:200]
Accounting for Loss Contingencies

[0001045810-21-000010:notes:201]
As of January 31, 2021, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-21-000010:notes:202]
Income Taxes
The income tax expense (benefit) applicable to income before income taxes consists of the following:

[0001045810-21-000010:notes:203]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Current income taxes: |  |  |  |  |  |
| Federal | $ | 197 |  |  | $ | 65 |  |  | $ | 1 |  |
| State | 1 |  |  | 4 |  |  | — |  |
| Foreign | 161 |  |  | 87 |  |  | 69 |  |
| Total current | 359 |  |  | 156 |  |  | 70 |  |
| Deferred taxes: |  |  |  |  |  |
| Federal | (246) |  |  | 2 |  |  | (315) |  |
| Foreign | (36) |  |  | 16 |  |  | — |  |
| Total deferred | (282) |  |  | 18 |  |  | (315) |  |
| Income tax expense (benefit) | $ | 77 |  |  | $ | 174 |  |  | $ | (245) |  |

[0001045810-21-000010:notes:204]
Income before income tax consists of the following:

[0001045810-21-000010:notes:205]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Domestic | $ | 1,437 |  |  | $ | 620 |  |  | $ | 1,843 |  |
| Foreign | 2,972 |  |  | 2,350 |  |  | 2,053 |  |
| Income before income tax | $ | 4,409 |  |  | $ | 2,970 |  |  | $ | 3,896 |  |

[0001045810-21-000010:notes:206]
The income tax expense (benefit) differs from the amount computed by applying the U.S. federal statutory rate of 21% to income before income taxes as follows:

[0001045810-21-000010:notes:207]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Tax expense computed at federal statutory rate | $ | 926 |  |  | $ | 624 |  |  | $ | 818 |  |
| Expense (benefit) resulting from: |  |  |  |  |  |
| State income taxes, net of federal tax effect | 10 |  |  | 12 |  |  | 23 |  |
| Foreign tax rate differential | (561) |  |  | (301) |  |  | (412) |  |
| U.S. federal R&D tax credit | (173) |  |  | (110) |  |  | (141) |  |
| Stock-based compensation | (136) |  |  | (60) |  |  | (191) |  |
| Tax Cuts and Jobs Act of 2017 | — |  |  | — |  |  | (368) |  |
| Other | 11 |  |  | 9 |  |  | 26 |  |
| Income tax expense (benefit) | $ | 77 |  |  | $ | 174 |  |  | $ | (245) |  |

[0001045810-21-000010:notes:208]
The tax effect of temporary differences that gives rise to significant portions of the deferred tax assets and liabilities are presented below:

[0001045810-21-000010:notes:209]
|  | January 31,2021 |  | January 26,2020 |
|  | (In millions) |
| Deferred tax assets: |  |
| GILTI deferred tax assets | $ | 709 |  |  | $ | 428 |  |
| Research and other tax credit carryforwards | 650 |  |  | 605 |  |
| Operating lease liabilities | 120 |  |  | 114 |  |
| Net operating loss carryforwards | 100 |  |  | 62 |  |
| Accruals and reserves, not currently deductible for tax purposes | 59 |  |  | 39 |  |
| Stock-based compensation | 36 |  |  | 28 |  |
| Property, equipment and intangible assets | 32 |  |  | 12 |  |
| Gross deferred tax assets | 1,706 |  |  | 1,288 |  |
| Less valuation allowance | (728) |  |  | (621) |  |
| Total deferred tax assets | 978 |  |  | 667 |  |
| Deferred tax liabilities: |  |  |  |
| Acquired intangibles | (191) |  |  | (1) |  |
| Unremitted earnings of foreign subsidiaries | (111) |  |  | (40) |  |
| Operating lease assets | (111) |  |  | (107) |  |
| Gross deferred tax liabilities | (413) |  |  | (148) |  |
| Net deferred tax asset (1) | $ | 565 |  |  | $ | 519 |  |

[0001045810-21-000010:notes:210]
(1)  Net deferred tax asset includes long-term deferred tax assets of $806 million and $548 million and long-term deferred tax liabilities of $241 million and $29 million for fiscal years 2021 and 2020, respectively. Long-term deferred tax liabilities are included in other long-term liabilities on our Consolidated Balance Sheets.

[0001045810-21-000010:notes:211]
We recognized an income tax expense of $77 million and $174 million for fiscal years 2021 and 2020, respectively, and income tax benefit of $245 million for fiscal year 2019. Our annual effective tax rate was 1.7%, 5.9%, and (6.3)% for fiscal years 2021, 2020, and 2019, respectively. The decrease in our effective tax rate in fiscal year 2021 as compared to fiscal year 2020 was primarily due to a decrease in the proportional amount of earnings subject to United States tax and an increase of tax benefits from stock-based compensation. The increase in our effective tax rate in fiscal year 2021 and fiscal year 2020 as compared to fiscal year 2019 was primarily due to an absence of tax benefits related to the enactment of the TCJA and a decrease of tax benefits from stock-based compensation.

[0001045810-21-000010:notes:212]
Our effective tax rate for fiscal years 2021, 2020, and 2019 was lower than the U.S. federal statutory rate of 21% due primarily to income earned in jurisdictions, including the British Virgin Islands, Israel and Hong Kong, where the tax rate was lower than the U.S. federal statutory tax rate, recognition of U.S. federal research tax credits, excess tax benefits related to stock-based compensation, and the finalization of the enactment-date income tax effects of the TCJA in 2019.

[0001045810-21-000010:notes:213]
During the second quarter of fiscal year 2021, we completed the acquisition of Mellanox. As a result of the acquisition, we recorded $256 million of net deferred tax liabilities primarily on the excess of book basis over the tax basis of the acquired intangible assets and undistributed earnings in certain foreign subsidiaries. We also recorded $153 million of long-term tax liabilities related to tax basis differences in Mellanox. The net deferred tax liabilities and long-term tax liabilities are based upon certain assumptions underlying our purchase price allocation. As a result of the acquisition, as of January 31, 2021, we intend to indefinitely reinvest approximately $1.16 billion of cumulative undistributed earnings held by Mellanox non-U.S. subsidiaries. We have not provided the amount of unrecognized deferred tax liabilities for temporary differences related to investments in Mellanox non-U.S. subsidiaries as the determination of such amount is not practicable.

[0001045810-21-000010:notes:214]
As of January 31, 2021 and January 26, 2020, we had a valuation allowance of $728 million and $621 million, respectively, related to state and certain foreign deferred tax assets that management determined not likely to be realized due, in part, to jurisdictional projections of future taxable income. To the extent realization of the deferred tax

[0001045810-21-000010:notes:215]
assets becomes more-likely-than-not, we would recognize such deferred tax asset as an income tax benefit during the period.

[0001045810-21-000010:notes:216]
As of January 31, 2021, we had federal, state and foreign net operating loss carryforwards of $333 million, $308 million and $344 million, respectively. The federal and state carryforwards will begin to expire in fiscal year 2023 and 2022, respectively. The foreign net operating loss carryforwards of $344 million may be carried forward indefinitely. As of January 31, 2021, we had federal research tax credit carryforwards of $238 million that will begin to expire in fiscal year 2035. We have state research tax credit carryforwards of $987 million, of which $944 million is attributable to the State of California and may be carried over indefinitely, and $43 million is attributable to various other states and will begin to expire in fiscal year 2022. Our tax attributes, net operating loss and tax credit carryforwards, remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of federal, state, and foreign net operating losses and tax credit carryforwards may also be subject to limitations due to ownership changes and other limitations provided by the Internal Revenue Code and similar state and foreign tax provisions. If any such limitations apply, the federal, state, or foreign net operating loss and tax credit carryforwards, as applicable, may expire or be denied before utilization.

[0001045810-21-000010:notes:217]
As of January 31, 2021, we had $776 million of gross unrecognized tax benefits, of which $606 million would affect our effective tax rate if recognized. However, $132 million of the unrecognized tax benefits were related to state income tax positions taken, that, if recognized, would be in the form of a carryforward deferred tax asset that would likely attract a full valuation allowance. The $606 million of unrecognized tax benefits as of January 31, 2021 consisted of $352 million recorded in non-current income taxes payable, $5 million recorded in current income taxes payable, and $249 million reflected as a reduction to the related deferred tax assets.

[0001045810-21-000010:notes:218]
A reconciliation of gross unrecognized tax benefits is as follows:

[0001045810-21-000010:notes:219]
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Balance at beginning of period | $ | 583 |  |  | $ | 477 |  |  | $ | 447 |  |
| Increases in tax positions for current year | 158 |  |  | 104 |  |  | 129 |  |
| Increases in tax positions for prior years (1) | 60 |  |  | 7 |  |  | 52 |  |
| Decreases in tax positions for prior years | (11) |  |  | — |  |  | (141) |  |
| Settlements | (5) |  |  | — |  |  | — |  |
| Lapse in statute of limitations | (9) |  |  | (5) |  |  | (10) |  |
| Balance at end of period | $ | 776 |  |  | $ | 583 |  |  | $ | 477 |  |

[0001045810-21-000010:notes:220]
(1)  The fiscal year 2021 balance represents prior year gross unrecognized tax benefits recorded as a result of the Mellanox acquisition.

[0001045810-21-000010:notes:221]
We classify an unrecognized tax benefit as a current liability, or amount refundable, to the extent that we anticipate payment or receipt of cash for income taxes within one year. The amount is classified as a long-term liability, or reduction of long-term deferred tax assets or amount refundable if we anticipate payment or receipt of cash for income taxes during a period beyond a year.

[0001045810-21-000010:notes:222]
Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense. As of January 31, 2021, January 26, 2020, and January 27, 2019, we had accrued $44 million, $31 million, and $21 million, respectively, for the payment of interest and penalties related to unrecognized tax benefits, which is not included as a component of our unrecognized tax benefits. As of January 31, 2021, unrecognized tax benefits of $352 million and the related interest and penalties of $43 million are included in non-current income taxes payable, and unrecognized tax benefits of $5 million and the related interest and penalties of $1 million are included in current income taxes payable.

[0001045810-21-000010:notes:223]
While we believe that we have adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. As of January 31, 2021, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.
We are subject to taxation by taxing authorities both in the United States and other countries. As of January 31, 2021, the significant tax jurisdictions that may be subject to examination include the United States, Hong Kong, Taiwan, China, United Kingdom, Germany, Israel, and India for fiscal years 2005 through 2020. As of January 31, 2021, the significant tax jurisdictions for which we are currently under examination include the United States, United Kingdom, Germany, Israel and India, for fiscal years 2005 through 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-21-000010:notes:224]
Shareholders’ Equity
Capital Return Program

[0001045810-21-000010:notes:225]
Beginning August 2004, our Board of Directors authorized us to repurchase our stock.

[0001045810-21-000010:notes:226]
Through January 31, 2021, we have repurchased an aggregate of 260 million shares under our share repurchase program for a total cost of $7.08 billion. All shares delivered from these repurchases have been placed into treasury stock. As of January 31, 2021, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $7.24 billion through December 2022.

[0001045810-21-000010:notes:227]
During fiscal year 2021, we paid $395 million in cash dividends to our shareholders.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001045810-21-000010:notes:228]
Employee Retirement PlansWe provide tax-qualified defined contribution plans to eligible employees in the U.S. and certain other countries. Our contribution expense for fiscal years 2021, 2020, and 2019 was $120 million, $76 million, and $70 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-21-000010:notes:229]
Segment Information 
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. In the prior fiscal year, we had reported two operating segments: GPU and Tegra Processor. During the first quarter of fiscal year 2021, we changed our operating segments to be consistent with the revised manner in which our CODM reviews our financial performance and allocates resources. The two new operating segments are "Graphics" and "Compute & Networking". Comparative periods presented reflect this change. Our operating segments are equivalent to our reportable segments.

[0001045810-21-000010:notes:230]
Our Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise design; GRID software for cloud-based visual and virtual computing; and automotive platforms for infotainment systems. Our Compute & Networking segment includes Data Center platforms and systems for AI, HPC, and accelerated computing; Mellanox networking and interconnect solutions; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; and Jetson for robotics and other embedded platforms.

[0001045810-21-000010:notes:231]
Operating results by segment include costs or expenses that are directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

[0001045810-21-000010:notes:232]
The “All Other” category includes the expenses that our CODM does not assign to either Graphics or Compute & Networking for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related costs, legal settlement costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-21-000010:notes:233]
Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-21-000010:notes:234]
|  | Graphics |  | Compute & Networking |  | All Other |  | Consolidated |
|  | (In millions) |
| Year Ended January 31, 2021: |  |  |  |  |  |  |  |
| Revenue | $ | 9,834 |  |  | $ | 6,841 |  |  | $ | — |  |  | $ | 16,675 |  |
| Operating income (loss) | $ | 4,612 |  |  | $ | 2,548 |  |  | $ | (2,628) |  |  | $ | 4,532 |  |
| Year Ended January 26, 2020: |  |  |  |  |  |  |  |
| Revenue | $ | 7,639 |  |  | $ | 3,279 |  |  | $ | — |  |  | $ | 10,918 |  |
| Operating income (loss) | $ | 3,267 |  |  | $ | 751 |  |  | $ | (1,172) |  |  | $ | 2,846 |  |
| Year Ended January 27, 2019: |  |  |  |  |  |  |  |
| Revenue | $ | 8,159 |  |  | $ | 3,557 |  |  | $ | — |  |  | $ | 11,716 |  |
| Operating income (loss) | $ | 3,417 |  |  | $ | 1,251 |  |  | $ | (864) |  |  | $ | 3,804 |  |

[0001045810-21-000010:notes:235]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |
| Stock-based compensation expense | $ | (1,397) |  |  | $ | (844) |  |  | $ | (557) |  |
| Acquisition-related intangible asset amortization | (591) |  |  | (6) |  |  | (6) |  |
| Unallocated cost of revenue and operating expenses | (357) |  |  | (283) |  |  | (261) |  |
| Acquisition-related inventory step-up charge | (161) |  |  | — |  |  | — |  |
| Acquisition-related and other costs | (84) |  |  | (25) |  |  | 4 |  |
| IP-related costs | (38) |  |  | (14) |  |  | (35) |  |
| Legal settlement costs | — |  |  | — |  |  | (9) |  |
| Total | $ | (2,628) |  |  | $ | (1,172) |  |  | $ | (864) |  |

[0001045810-21-000010:notes:236]
Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if our customers’ revenue is attributable to end customers that are located in a different location. The following table summarizes information pertaining to our revenue from customers based on the invoicing address by geographic regions:

[0001045810-21-000010:notes:237]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
| Revenue: | (In millions) |
| Taiwan | $ | 4,531 |  |  | $ | 3,025 |  |  | $ | 3,360 |  |
| China (including Hong Kong) | 3,886 |  |  | 2,731 |  |  | 2,801 |  |
| United States | 3,214 |  |  | 886 |  |  | 1,506 |  |
| Other Asia Pacific | 3,093 |  |  | 2,685 |  |  | 2,368 |  |
| Europe | 1,118 |  |  | 992 |  |  | 914 |  |
| Other countries | 833 |  |  | 599 |  |  | 767 |  |
| Total revenue | $ | 16,675 |  |  | $ | 10,918 |  |  | $ | 11,716 |  |

[0001045810-21-000010:notes:238]
The following table summarizes information pertaining to our revenue by each of the specialized markets we serve:

[0001045810-21-000010:notes:239]
|  | Year Ended |
|  | January 31,2021 |  | January 26,2020 |  | January 27,2019 |
| Revenue: | (In millions) |
| Gaming | $ | 7,759 |  |  | $ | 5,518 |  |  | $ | 6,246 |  |
| Professional Visualization | 1,053 |  |  | 1,212 |  |  | 1,130 |  |
| Data Center | 6,696 |  |  | 2,983 |  |  | 2,932 |  |
| Automotive | 536 |  |  | 700 |  |  | 641 |  |
| OEM & Other | 631 |  |  | 505 |  |  | 767 |  |
| Total revenue | $ | 16,675 |  |  | $ | 10,918 |  |  | $ | 11,716 |  |

[0001045810-21-000010:notes:240]
The following table presents summarized information for long-lived assets by geographic region. Long-lived assets consist of property and equipment and exclude other assets, operating lease assets, goodwill, and intangible assets.

[0001045810-21-000010:notes:241]
|  | January 31,2021 |  | January 26,2020 |
| Long-lived assets: | (In millions) |
| United States | $ | 1,643 |  |  | $ | 1,451 |  |
| Taiwan | 183 |  |  | 114 |  |
| Israel | 147 |  |  | — |  |
| China (including Hong Kong) | 71 |  |  | 28 |  |
| India | 64 |  |  | 51 |  |
| Europe | 34 |  |  | 28 |  |
| Other countries | 7 |  |  | 2 |  |
| Total long-lived assets | $ | 2,149 |  |  | $ | 1,674 |  |

[0001045810-21-000010:notes:242]
No customer represented 10% or more of total revenue for fiscal years 2021 and 2019. One customer represented 11% of our total revenue for fiscal year 2020 and was attributable primarily to the Graphics segment.

[0001045810-21-000010:notes:243]
One customer represented 16% and 21% of our accounts receivable balance as of January 31, 2021 and January 26, 2020, respectively.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001045810-21-000010:notes:244]
SCHEDULE II – VALUATION AND QUALIFYING ACCOUNTS

[0001045810-21-000010:notes:245]
| Description |  | Balance atBeginning of Period |  | Additions |  | Deductions |  | Balance atEnd of Period |
|  |  | (In millions) |
| Fiscal year 2021 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | 2 |  | (1) | $ | — |  | (1) | $ | 4 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 30 |  | (2) | $ | (22) |  | (4) | $ | 17 |  |
| Deferred tax valuation allowance |  | $ | 621 |  |  | $ | 107 |  | (3) | $ | — |  |  | $ | 728 |  |
| Fiscal year 2020 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2 |  |  | $ | — |  | (1) | $ | — |  | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 8 |  |  | $ | 18 |  | (2) | $ | (17) |  | (4) | $ | 9 |  |
| Deferred tax valuation allowance |  | $ | 562 |  |  | $ | 59 |  | (3) | $ | — |  |  | $ | 621 |  |
| Fiscal year 2019 |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4 |  |  | $ | — |  | (1) | $ | (2) |  | (1) | $ | 2 |  |
| Sales return allowance |  | $ | 9 |  |  | $ | 21 |  | (2) | $ | (22) |  | (4) | $ | 8 |  |
| Deferred tax valuation allowance |  | $ | 469 |  |  | $ | 93 |  | (3) | $ | — |  |  | $ | 562 |  |

[0001045810-21-000010:notes:246]
(1)Additions represent allowance for doubtful accounts charged to expense and deductions represent amounts recorded as reduction to expense upon reassessment of allowance for doubtful accounts at period end.

[0001045810-21-000010:notes:247]
(2)Represents allowance for sales returns estimated at the time revenue is recognized primarily based on historical return rates and is charged as a reduction to revenue.

[0001045810-21-000010:notes:248]
(3)Represents change in valuation allowance primarily related to state and certain foreign deferred tax assets that management has determined not likely to be realized due, in part, to projections of future taxable income of the respective jurisdictions. Refer to Note 14 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-21-000010:notes:249]
(4)Represents sales returns.
