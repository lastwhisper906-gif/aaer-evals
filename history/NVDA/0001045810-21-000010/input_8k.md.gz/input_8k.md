# NVDA 8-K — 0001045810-21-000007 filed 2021-02-24

## item codes, every 8-K on or before 2021-02-26

- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2021-02-26

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-21-000007:8k_2_02:1]
EX-99.1
2
q4fy21pr.htm
Q4FY21 PRESS RELEASE

[0001045810-21-000007:8k_2_02:2]
Document

[0001045810-21-000007:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-21-000007:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2021

[0001045810-21-000007:8k_2_02:5]
•Record quarterly and full-year revenue for company, Gaming and Data Center

[0001045810-21-000007:8k_2_02:6]
•Company quarterly revenue of $5.00 billion, up 61 percent year on year

[0001045810-21-000007:8k_2_02:7]
•Company full-year revenue of $16.68 billion, up 53 percent

[0001045810-21-000007:8k_2_02:8]
SANTA CLARA, Calif.-Feb. 24, 2021- NVIDIA (NASDAQ: NVDA) today reported record revenue for the fourth quarter ended January 31, 2021, of $5.00 billion, up 61 percent from $3.11 billion a year earlier, and up 6 percent from $4.73 billion in the previous quarter. The company’s Gaming and Data Center platforms achieved record revenue for the quarter and year.

[0001045810-21-000007:8k_2_02:9]
GAAP earnings per diluted share for the quarter were a record $2.31, up 51 percent from $1.53 a year ago, and up 9 percent from $2.12 in the previous quarter. Non-GAAP earnings per diluted share were $3.10, up 64 percent from $1.89 a year earlier, and up 7 percent from $2.91 in the previous quarter.

[0001045810-21-000007:8k_2_02:10]
For fiscal 2021, revenue was a record $16.68 billion, up 53 percent from $10.92 billion a year earlier. GAAP earnings per diluted share were a record $6.90, up 53 percent from $4.52 a year earlier. Non-GAAP earnings per diluted share were $10.00, up 73 percent from $5.79 a year earlier.

[0001045810-21-000007:8k_2_02:11]
“Q4 was another record quarter, capping a breakout year for NVIDIA’s computing platforms,” said Jensen Huang, founder and CEO of NVIDIA. “Our pioneering work in accelerated computing has led to gaming becoming the world’s most popular entertainment, to supercomputing being democratized for all researchers, and to AI emerging as the most important force in technology.

[0001045810-21-000007:8k_2_02:12]
“Demand for GeForce RTX 30 Series GPUs is incredible. NVIDIA RTX has started a major upgrade cycle as gamers jump to ray tracing, DLSS and AI.

[0001045810-21-000007:8k_2_02:13]
“Our A100 universal AI data center GPUs are ramping strongly across cloud-service providers and vertical industries. Thousands of companies across the world are applying NVIDIA AI to create cloud-connected products with AI services that will transform the world’s largest industries. We are seeing the smartphone moment for every industry.

[0001045810-21-000007:8k_2_02:14]
“Mellanox has expanded our footprint across the data center. And we are making good progress toward acquiring Arm, which will create enormous new opportunities for the entire ecosystem,” he said.

[0001045810-21-000007:8k_2_02:15]
NVIDIA paid quarterly cash dividends of $99 million in the fourth quarter and $395 million in fiscal 2021. It will pay its next quarterly cash dividend of $0.16 per share on March 31, 2021, to all shareholders of record on March 10, 2021.

[0001045810-21-000007:8k_2_02:16]
Q4 Fiscal 2021 Summary

[0001045810-21-000007:8k_2_02:17]
| GAAP |
| ($ in millions, except earnings per share) | Q4 FY21 | Q3 FY21 | Q4 FY20 | Q/Q | Y/Y |
| Revenue | $5,003 | $4,726 | $3,105 | Up 6% | Up 61% |
| Gross margin | 63.1 | % | 62.6 | % | 64.9 | % | Up 50 bps | Down 180 bps |
| Operating expenses | $1,650 | $1,562 | $1,025 | Up 6% | Up 61% |
| Operating income | $1,507 | $1,398 | $990 | Up 8% | Up 52% |
| Net income | $1,457 | $1,336 | $950 | Up 9% | Up 53% |
| Diluted earnings per share | $2.31 | $2.12 | $1.53 | Up 9% | Up 51% |

[0001045810-21-000007:8k_2_02:18]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q4 FY21 | Q3 FY21 | Q4 FY20 | Q/Q | Y/Y |
| Revenue | $5,003 | $4,726 | $3,105 | Up 6% | Up 61% |
| Gross margin | 65.5 | % | 65.5 | % | 65.4 | % | -- | Up 10 bps |
| Operating expenses | $1,187 | $1,101 | $810 | Up 8% | Up 47% |
| Operating income | $2,089 | $1,993 | $1,220 | Up 5% | Up 71% |
| Net income | $1,957 | $1,834 | $1,172 | Up 7% | Up 67% |
| Diluted earnings per share | $3.10 | $2.91 | $1.89 | Up 7% | Up 64% |

[0001045810-21-000007:8k_2_02:19]
Fiscal 2021 Summary

[0001045810-21-000007:8k_2_02:20]
| GAAP |
| ($ in millions, except earnings per share) | FY21 | FY20 | Y/Y |
| Revenue | $16,675 | $10,918 | Up 53% |
| Gross margin | 62.3 | % | 62.0 | % | Up 30 bps |
| Operating expenses | $5,864 | $3,922 | Up 50% |
| Operating income | $4,532 | $2,846 | Up 59% |
| Net income | $4,332 | $2,796 | Up 55% |
| Diluted earnings per share | $6.90 | $4.52 | Up 53% |

[0001045810-21-000007:8k_2_02:21]
| Non-GAAP |
| ($ in millions, except earnings per share) | FY21 | FY20 | Y/Y |
| Revenue | $16,675 | $10,918 | Up 53% |
| Gross margin | 65.6 | % | 62.5 | % | Up 310 bps |
| Operating expenses | $4,144 | $3,086 | Up 34% |
| Operating income | $6,803 | $3,735 | Up 82% |
| Net income | $6,277 | $3,580 | Up 75% |
| Diluted earnings per share | $10.00 | $5.79 | Up 73% |

[0001045810-21-000007:8k_2_02:22]
NVIDIA’s outlook for the first quarter of fiscal 2022 is as follows:

[0001045810-21-000007:8k_2_02:23]
•Revenue is expected to be $5.30 billion, plus or minus 2 percent.

[0001045810-21-000007:8k_2_02:24]
•GAAP and non-GAAP gross margins are expected to be 63.8 percent and 66.0 percent, respectively, plus or minus 50 basis points.

[0001045810-21-000007:8k_2_02:25]
•GAAP and non-GAAP operating expenses are expected to be approximately $1.67 billion and $1.20 billion, respectively.

[0001045810-21-000007:8k_2_02:26]
•GAAP and non-GAAP other income and expense are both expected to be an expense of approximately $50 million.

[0001045810-21-000007:8k_2_02:27]
•GAAP and non-GAAP tax rates are both expected to be 10 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter-by-quarter basis.

[0001045810-21-000007:8k_2_02:28]
Highlights

[0001045810-21-000007:8k_2_02:29]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-21-000007:8k_2_02:30]
Data Center

[0001045810-21-000007:8k_2_02:31]
•Fourth-quarter revenue was a record $1.90 billion, slightly above the previous quarter and up 97 percent from a year earlier. Full-year revenue was a record $6.70 billion, up 124 percent.

[0001045810-21-000007:8k_2_02:32]
•Announced that the world’s leading OEMs unveiled the first wave of NVIDIA-Certified Systems™ with NVIDIA A100 Tensor Core GPUs — the industry’s only accelerated servers tested for machine learning and data analytics workloads.

[0001045810-21-000007:8k_2_02:33]
•Introduced support for Google Cloud’s Anthos on bare metal for NVIDIA DGX™ A100 systems, enabling enterprises to create hybrid cloud infrastructure more easily.

[0001045810-21-000007:8k_2_02:34]
•Enhanced the NVIDIA Clara™ application framework for AI-powered healthcare and life sciences with the launch of Clara Discovery for computational drug discovery, providing dozens of pre-trained models, the MONAI open-source medical AI training framework, and federated learning for the industry to collaborate on building models without sharing data.

[0001045810-21-000007:8k_2_02:35]
•Collaborated with Amazon Web Services to bring the NVIDIA NGC™ software hub to AWS Marketplace.

[0001045810-21-000007:8k_2_02:36]
Gaming

[0001045810-21-000007:8k_2_02:37]
•Fourth-quarter revenue was a record $2.50 billion, up 10 percent from the previous quarter and up 67 percent from a year earlier. Full-year revenue was a record $7.76 billion, up 41 percent.

[0001045810-21-000007:8k_2_02:38]
•Announced the company’s biggest-ever laptop launch, with 70+ new laptops for gamers and creators, powered by NVIDIA GeForce RTX™ 30 Series Laptop GPUs.

[0001045810-21-000007:8k_2_02:39]
•Expanded the GeForce RTX 30 Series GPUs with 60-class offerings — the most popular in the company’s gaming lineup — including the GeForce RTX 3060, starting at just $329, featuring NVIDIA RTX™ ray tracing, NVIDIA DLSS, NVIDIA Reflex and NVIDIA Broadcast.

[0001045810-21-000007:8k_2_02:40]
•Increased momentum for NVIDIA RTX adoption, now available in 36 new titles, including Minecraft, Fortnite, and Cyberpunk 2077.

[0001045810-21-000007:8k_2_02:41]
•Announced that Overwatch and Tom Clancy’s Rainbow Six Siege are adopting NVIDIA Reflex, bringing this low-latency technology to seven of the top 10 competitive-shooter games.

[0001045810-21-000007:8k_2_02:42]
•Announced GeForce NOW™ has come to iOS Safari, giving over 6 million GeForce NOW members access to the service through Safari on iPhone or iPad.

[0001045810-21-000007:8k_2_02:43]
Professional Visualization

[0001045810-21-000007:8k_2_02:44]
•Fourth-quarter revenue was $307 million, up 30 percent from the previous quarter and down 7 percent from a year earlier. Full-year revenue was $1.05 billion, down 13 percent.

[0001045810-21-000007:8k_2_02:45]
•Announced that NVIDIA Omniverse™ — a real-time simulation and collaboration platform for 3D production pipelines — is now in open beta.

[0001045810-21-000007:8k_2_02:46]
Automotive

[0001045810-21-000007:8k_2_02:47]
•Fourth-quarter revenue was $145 million, up 16 percent from the previous quarter and down 11 percent from a year earlier. Full-year revenue was $536 million, down 23 percent.

[0001045810-21-000007:8k_2_02:48]
•Announced that NVIDIA DRIVE™ autonomous driving technology is powering a range of next-gen electric vehicles from carmakers SAIC and Nio; robotaxi-maker Zoox; and cabless truck-maker Einride.

[0001045810-21-000007:8k_2_02:49]
•Announced that NVIDIA is powering the new Mercedes-Benz AI cockpit, featuring the MBUX Hyperscreen, which will debut in the all-electric Mercedes-Benz EQS in the first half of 2021.

[0001045810-21-000007:8k_2_02:50]
•Expanded the NVIDIA DRIVE sensor ecosystem with new solutions from lidar makers Baraja, Hesai, Innoviz, Magna and Ouster.

[0001045810-21-000007:8k_2_02:51]
CFO Commentary

[0001045810-21-000007:8k_2_02:52]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com/.

[0001045810-21-000007:8k_2_02:53]
Conference Call and Webcast Information

[0001045810-21-000007:8k_2_02:54]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2021 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2022.

[0001045810-21-000007:8k_2_02:55]
Non-GAAP Measures

[0001045810-21-000007:8k_2_02:56]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, IP-related costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases of property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-21-000007:8k_2_02:57]
About NVIDIA

[0001045810-21-000007:8k_2_02:58]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market and has redefined modern computer graphics, high performance computing and artificial intelligence. The company’s pioneering work in accelerated computing and AI is reshaping trillion-dollar industries, such as transportation, healthcare and manufacturing, and fueling the growth of many others. More information at https://nvidianews.nvidia.com/.

[0001045810-21-000007:8k_2_02:59]
###

[0001045810-21-000007:8k_2_02:60]
For further information, contact:

[0001045810-21-000007:8k_2_02:61]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-21-000007:8k_2_02:62]
Certain statements in this press release including, but not limited to, statements as to:  NVIDIA’s pioneering work in accelerated computing and its impacts; demand for our GPUs; the invention of RTX and it starting upgrade cycles; our GPU series expansion and shipping; our A100 GPUs ramping; our work with  and the number of companies across the world to applying NVIDIA AI and its impact; seeing the smartphone moment for every industry; expanding our footprint across the data center; our opportunities; our progress on the Arm acquisition, when it is expected to close and it creating new opportunities for the entire ecosystem; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the first quarter of fiscal 2022; NVIDIA’s expected tax rates for the first quarter of fiscal 2022; NVIDIA’s expectation to generate variability from excess tax benefits or deficiencies; NVIDIA-Certified Systems being offered from the world’s leading OEMs; support for Anthos and it enabling enterprises to more easily create hybrid cloud infrastructure; the benefits, performance and abilities of our products and technologies, including NVIDIA Clara application framework and NVIDIA GeForce RTX 30 Series GPUs; NVIDIA Clara Discovery providing pre-trained models, the MONAI framework, and federated learning for the industry without sharing data; bringing NGC software to the AWS Marketplace; the size of our laptop launch and number of laptops using NVIDIA GeForce RTX 30 Series Laptop GPUs; expanding our RTX 30 Series GPUs and their features; increasing momentum for RTX technologies and the number of titles using it; the games using NVIDIA Reflex technology; GeForce NOW’s availability and the number of members that can access it; NVIDIA Omniverse being in open beta; NVIDIA DRIVE powering a range of next-gen electric vehicles; NVIDIA powering the Mercedes-Benz AI cockpit and the cars and timing for its debut; and expanding the NVIDIA DRIVE ecosystem with new solutions from lidar makers are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-21-000007:8k_2_02:63]
© 2021 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, NVIDIA DGX, GeForce NOW, GeForce RTX, NGC, NVIDIA Clara, NVIDIA DRIVE, NVIDIA Omniverse, NVIDIA RTX and NVIDIA-Certified Systems are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-21-000007:8k_2_02:64]
NVIDIA CORPORATION

[0001045810-21-000007:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-21-000007:8k_2_02:66]
(In millions, except per share data)

[0001045810-21-000007:8k_2_02:67]
(Unaudited)

[0001045810-21-000007:8k_2_02:68]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 31, |  | January 26, |  | January 31, |  | January 26, |
|  |  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue | $ | 5,003 |  |  | $ | 3,105 |  |  | $ | 16,675 |  |  | $ | 10,918 |  |
| Cost of revenue | 1,846 |  |  | 1,090 |  |  | 6,279 |  |  | 4,150 |  |
| Gross profit | 3,157 |  |  | 2,015 |  |  | 10,396 |  |  | 6,768 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 1,147 |  |  | 738 |  |  | 3,924 |  |  | 2,829 |  |
|  | Sales, general and administrative | 503 |  |  | 287 |  |  | 1,940 |  |  | 1,093 |  |
|  |  | Total operating expenses | 1,650 |  |  | 1,025 |  |  | 5,864 |  |  | 3,922 |  |
| Income from operations | 1,507 |  |  | 990 |  |  | 4,532 |  |  | 2,846 |  |
|  | Interest income | 6 |  |  | 41 |  |  | 57 |  |  | 178 |  |
|  | Interest expense | (53) |  |  | (12) |  |  | (184) |  |  | (52) |  |
|  | Other, net | 10 |  |  | (3) |  |  | 4 |  |  | (2) |  |
|  |  | Other income (expense), net | (37) |  |  | 26 |  |  | (123) |  |  | 124 |  |
| Income before income tax | 1,470 |  |  | 1,016 |  |  | 4,409 |  |  | 2,970 |  |
| Income tax expense | 13 |  |  | 66 |  |  | 77 |  |  | 174 |  |
| Net income | $ | 1,457 |  |  | $ | 950 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 2.35 |  |  | $ | 1.55 |  |  | $ | 7.02 |  |  | $ | 4.59 |  |
|  | Diluted | $ | 2.31 |  |  | $ | 1.53 |  |  | $ | 6.90 |  |  | $ | 4.52 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 619 |  |  | 612 |  |  | 617 |  |  | 609 |  |
|  | Diluted | 631 |  |  | 621 |  |  | 628 |  |  | 618 |  |

[0001045810-21-000007:8k_2_02:69]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | January 31, |  | January 26, |
|  |  |  |  | 2021 |  | 2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 11,561 |  |  | $ | 10,897 |  |
|  | Accounts receivable, net |  | 2,429 |  |  | 1,657 |  |
|  | Inventories |  | 1,826 |  |  | 979 |  |
|  | Prepaid expenses and other current assets |  | 239 |  |  | 157 |  |
|  |  | Total current assets |  | 16,055 |  |  | 13,690 |  |
| Property and equipment, net |  | 2,149 |  |  | 1,674 |  |
| Operating lease assets |  | 707 |  |  | 618 |  |
| Goodwill |  | 4,193 |  |  | 618 |  |
| Intangible assets, net |  | 2,737 |  |  | 49 |  |
| Deferred income tax assets |  | 806 |  |  | 548 |  |
| Other assets |  | 2,144 |  |  | 118 |  |
|  |  | Total assets |  | $ | 28,791 |  |  | $ | 17,315 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 1,201 |  |  | $ | 687 |  |
|  | Accrued and other current liabilities |  | 1,725 |  |  | 1,097 |  |
|  | Short-term debt |  | 999 |  |  | — |  |
|  |  | Total current liabilities |  | 3,925 |  |  | 1,784 |  |
| Long-term debt |  | 5,964 |  |  | 1,991 |  |
| Long-term operating lease liabilities |  | 634 |  |  | 561 |  |
| Other long-term liabilities |  | 1,375 |  |  | 775 |  |
|  |  | Total liabilities |  | 11,898 |  |  | 5,111 |  |
| Shareholders' equity |  | 16,893 |  |  | 12,204 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 28,791 |  |  | $ | 17,315 |  |

[0001045810-21-000007:8k_2_02:70]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 31, |  | January 26, |  | January 31, |  | January 26, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,457 |  |  | $ | 950 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 287 |  |  | 106 |  |  | 1,098 |  |  | 381 |  |
| Stock-based compensation expense | 417 |  |  | 220 |  |  | 1,397 |  |  | 844 |  |
| Deferred income taxes | (164) |  |  | 23 |  |  | (282) |  |  | 18 |  |
| Other | (17) |  |  | — |  |  | (20) |  |  | 5 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | 117 |  |  | (202) |  |  | (550) |  |  | (233) |  |
| Inventories | (334) |  |  | 66 |  |  | (524) |  |  | 597 |  |
| Prepaid expenses and other assets | 15 |  |  | 22 |  |  | (394) |  |  | 77 |  |
| Accounts payable | 75 |  |  | 104 |  |  | 363 |  |  | 194 |  |
| Accrued and other current liabilities | 126 |  |  | 157 |  |  | 239 |  |  | 54 |  |
| Other long-term liabilities | 88 |  |  | 19 |  |  | 163 |  |  | 28 |  |
| Net cash provided by operating activities | 2,067 |  |  | 1,465 |  |  | 5,822 |  |  | 4,761 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 3,627 |  |  | — |  |  | 8,792 |  |  | 4,744 |  |
| Proceeds from sales of marketable securities | 25 |  |  | 2 |  |  | 527 |  |  | 3,365 |  |
| Purchases of marketable securities | (6,468) |  |  | — |  |  | (19,308) |  |  | (1,461) |  |
| Acquisitions, net of cash acquired | — |  |  | — |  |  | (8,524) |  |  | (4) |  |
| Purchases related to property and equipment and intangible assets | (283) |  |  | (144) |  |  | (1,128) |  |  | (489) |  |
| Investments and other, net | (30) |  |  | (9) |  |  | (34) |  |  | (10) |  |
| Net cash provided by (used in) investing activities | (3,129) |  |  | (151) |  |  | (19,675) |  |  | 6,145 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 4 |  |  | 2 |  |  | 194 |  |  | 149 |  |
| Payments related to tax on restricted stock units | (225) |  |  | (87) |  |  | (942) |  |  | (551) |  |
| Dividends paid | (99) |  |  | (98) |  |  | (395) |  |  | (390) |  |
| Issuance of debt, net of issuance costs | (3) |  |  | — |  |  | 4,968 |  |  | — |  |
| Principal payments on property and equipment | (17) |  |  | — |  |  | (17) |  |  | — |  |
| Other | (2) |  |  | — |  |  | (4) |  |  | — |  |
| Net cash provided by (used in) financing activities | (342) |  |  | (183) |  |  | 3,804 |  |  | (792) |  |
| Change in cash and cash equivalents | (1,404) |  |  | 1,131 |  |  | (10,049) |  |  | 10,114 |  |
| Cash and cash equivalents at beginning of period | 2,251 |  |  | 9,765 |  |  | 10,896 |  |  | 782 |  |
| Cash and cash equivalents at end of period | $ | 847 |  |  | $ | 10,896 |  |  | $ | 847 |  |  | $ | 10,896 |  |

[0001045810-21-000007:8k_2_02:71]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 31, |  | October 25, |  | January 26, |  | January 31, |  | January 26, |
|  |  |  | 2021 |  | 2020 |  | 2020 |  | 2021 |  | 2020 |
| GAAP gross profit |  | $ | 3,157 |  |  | $ | 2,960 |  |  | $ | 2,015 |  |  | $ | 10,396 |  |  | $ | 6,768 |  |
| GAAP gross margin |  | 63.1 | % |  | 62.6 | % |  | 64.9 | % |  | 62.3 | % |  | 62.0 | % |
|  | Acquisition-related and other costs (B) |  | 92 |  |  | 86 |  |  | — |  |  | 425 |  |  | — |  |
|  | Stock-based compensation expense (A) |  | 26 |  |  | 28 |  |  | 12 |  |  | 88 |  |  | 39 |  |
|  | IP-related costs |  | 1 |  |  | 21 |  |  | 3 |  |  | 38 |  |  | 14 |  |
| Non-GAAP gross profit |  | $ | 3,276 |  |  | $ | 3,095 |  |  | $ | 2,030 |  |  | $ | 10,947 |  |  | $ | 6,821 |  |
| Non-GAAP gross margin |  | 65.5 | % |  | 65.5 | % |  | 65.4 | % |  | 65.6 | % |  | 62.5 | % |
| GAAP operating expenses |  | $ | 1,650 |  |  | $ | 1,562 |  |  | $ | 1,025 |  |  | $ | 5,864 |  |  | $ | 3,922 |  |
|  | Stock-based compensation expense (A) |  | (391) |  |  | (355) |  |  | (208) |  |  | (1,309) |  |  | (805) |  |
|  | Acquisition-related and other costs (B) |  | (72) |  |  | (106) |  |  | (7) |  |  | (411) |  |  | (31) |  |
| Non-GAAP operating expenses |  | $ | 1,187 |  |  | $ | 1,101 |  |  | $ | 810 |  |  | $ | 4,144 |  |  | $ | 3,086 |  |
| GAAP income from operations |  | $ | 1,507 |  |  | $ | 1,398 |  |  | $ | 990 |  |  | $ | 4,532 |  |  | $ | 2,846 |  |
|  | Total impact of non-GAAP adjustments to income from operations |  | 582 |  |  | 595 |  |  | 230 |  |  | 2,271 |  |  | 889 |  |
| Non-GAAP income from operations |  | $ | 2,089 |  |  | $ | 1,993 |  |  | $ | 1,220 |  |  | $ | 6,803 |  |  | $ | 3,735 |  |
| GAAP other income (expense), net |  | $ | (37) |  |  | $ | (50) |  |  | $ | 26 |  |  | $ | (123) |  |  | $ | 124 |  |
|  | Losses (Gains) from non-affiliated investments |  | (9) |  |  | 4 |  |  | — |  |  | — |  |  | 1 |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | — |  |  | 3 |  |  | 2 |  |
| Non-GAAP other income (expense), net |  | $ | (45) |  |  | $ | (45) |  |  | $ | 26 |  |  | $ | (120) |  |  | $ | 127 |  |
| GAAP net income |  | $ | 1,457 |  |  | $ | 1,336 |  |  | $ | 950 |  |  | $ | 4,332 |  |  | $ | 2,796 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 574 |  |  | 600 |  |  | 230 |  |  | 2,274 |  |  | 890 |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (74) |  |  | (102) |  |  | (8) |  |  | (329) |  |  | (106) |  |
| Non-GAAP net income |  | $ | 1,957 |  |  | $ | 1,834 |  |  | $ | 1,172 |  |  | $ | 6,277 |  |  | $ | 3,580 |  |

[0001045810-21-000007:8k_2_02:72]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 31, |  | October 25, |  | January 26, |  | January 31, |  | January 26, |
|  |  |  | 2021 |  | 2020 |  | 2020 |  | 2021 |  | 2020 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 2.31 |  |  | $ | 2.12 |  |  | $ | 1.53 |  |  | $ | 6.90 |  |  | $ | 4.52 |  |
|  | Non-GAAP |  | $ | 3.10 |  |  | $ | 2.91 |  |  | $ | 1.89 |  |  | $ | 10.00 |  |  | $ | 5.79 |  |
| Weighted average shares used in diluted net income per share computation |  | 631 |  |  | 630 |  |  | 621 |  |  | 628 |  | 618 |
| GAAP net cash provided by operating activities |  | $ | 2,067 |  |  | $ | 1,279 |  |  | $ | 1,465 |  |  | $ | 5,822 |  |  | $ | 4,761 |  |
|  | Purchases related to property and equipment and intangible assets |  | (283) |  |  | (473) |  |  | (144) |  |  | (1,128) |  |  | (489) |  |
|  | Principal payments on property and equipment |  | (17) |  |  | — |  |  | — |  |  | (17) |  |  | — |  |
| Free cash flow |  | $ | 1,767 |  |  | $ | 806 |  |  | $ | 1,321 |  |  | $ | 4,677 |  |  | $ | 4,272 |  |

[0001045810-21-000007:8k_2_02:73]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 31, |  | October 25, |  | January 26, |  | January 31, |  | January 26, |
|  |  |  | 2021 |  | 2020 |  | 2020 |  | 2021 |  | 2020 |
|  | Cost of revenue |  | $ | 26 |  |  | $ | 28 |  |  | $ | 12 |  |  | $ | 88 |  |  | $ | 39 |  |
|  | Research and development |  | $ | 266 |  |  | $ | 232 |  |  | $ | 140 |  |  | $ | 860 |  |  | $ | 540 |  |
|  | Sales, general and administrative |  | $ | 125 |  |  | $ | 123 |  |  | $ | 68 |  |  | $ | 449 |  |  | $ | 265 |  |
| (B) Acquisition-related and other costs primarily include amortization of intangible assets, inventory step-up, transaction costs, and certain compensation charges presented as follows: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 31, |  | October 25, |  | January 26, |  | January 31, |  | January 26, |
|  |  |  | 2021 |  | 2020 |  | 2020 |  | 2021 |  | 2020 |
|  | Cost of revenue |  | $ | 92 |  |  | $ | 86 |  |  | $ | — |  |  | $ | 425 |  |  | $ | — |  |
|  | Research and development |  | $ | 2 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 9 |  |  | $ | 6 |  |
|  | Sales, general and administrative |  | $ | 70 |  |  | $ | 104 |  |  | $ | 6 |  |  | $ | 402 |  |  | $ | 25 |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |

[0001045810-21-000007:8k_2_02:74]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2022 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 63.8 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 2.2 | % |
| Non-GAAP gross margin |  | 66.0 | % |
| GAAP operating expenses |  | $ | 1,670 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (470) |  |
| Non-GAAP operating expenses |  | $ | 1,200 |  |
