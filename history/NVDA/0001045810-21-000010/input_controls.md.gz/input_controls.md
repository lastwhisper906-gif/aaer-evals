# NVDA 10-K controls and the auditor's report


## auditors_report

[0001045810-21-000010:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001045810-21-000010:auditors_report:2]
To the Board of Directors and Shareholders of NVIDIA Corporation

[0001045810-21-000010:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001045810-21-000010:auditors_report:4]
We have audited the accompanying consolidated balance sheets of NVIDIA Corporation and its subsidiaries (the "Company") as of January 31, 2021 and January 26, 2020, and the related consolidated statements of income, comprehensive income, shareholders’ equity and cash flows for each of the three years in the period ended January 31, 2021, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of January 31, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001045810-21-000010:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 31, 2021 and January 26, 2020, and the results of its operations and its cash flows for each of the three years in the period ended January 31, 2021 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of January 31, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001045810-21-000010:auditors_report:6]
Change in Accounting Principle

[0001045810-21-000010:auditors_report:7]
As discussed in Note 3 to the consolidated financial statements, the Company changed the manner in which it accounts for leases in fiscal year 2020.

[0001045810-21-000010:auditors_report:8]
Basis for Opinions

[0001045810-21-000010:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management's Annual Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001045810-21-000010:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001045810-21-000010:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001045810-21-000010:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001045810-21-000010:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of

[0001045810-21-000010:auditors_report:14]
management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001045810-21-000010:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001045810-21-000010:auditors_report:16]
Critical Audit Matters

[0001045810-21-000010:auditors_report:17]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001045810-21-000010:auditors_report:18]
Acquisition of Mellanox Technologies Ltd.- Valuation of Developed Technology and In-process Research and Development Intangible Assets Acquired

[0001045810-21-000010:auditors_report:19]
As described in Note 2 to the consolidated financial statements, in fiscal year 2021 the Company completed the acquisition of Mellanox Technologies Ltd. for consideration of approximately $7.13 billion, of which $1,640 million of developed technology and $630 million of in-process research and development intangible assets were recorded. The fair values of developed technology and in-process research and development intangible assets were determined using the multi-period excess earnings method. As disclosed by management, management applied significant judgment in estimating the fair value of the intangible assets acquired, which involved the use of certain estimates and assumptions, including future economic and market conditions, revenue growth, the technology migration curve, and risk-adjusted discount rates.

[0001045810-21-000010:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the valuation of the developed technology and in-process research and development intangible assets acquired in the acquisition of Mellanox Technologies Ltd. is a critical audit matter are (i) the high degree of auditor judgment and subjectivity in applying procedures relating to the fair value measurement of developed technology and in-process research and development intangible assets acquired due to the significant judgment by management when developing the estimate, (ii) significant audit effort in evaluating management’s assumptions relating to the estimate, such as revenue growth and the technology migration curve, and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001045810-21-000010:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the acquisition accounting, including controls over management’s valuation of the intangible assets and controls over development of the assumptions related to the revenue growth and the technology migration curve. These procedures also included, among others, reading the purchase agreement and testing management’s process for estimating the fair value of the developed technology and in-process research and development intangible assets acquired. Testing management’s process included evaluating the appropriateness of the valuation method and the reasonableness of management’s assumptions related to the revenue growth and the technology migration curve for the intangible assets acquired, and using professionals with specialized skill and knowledge to assist with the evaluation. Evaluating the reasonableness of the revenue growth involved considering the past performance of the acquired business as well as economic and industry forecasts. The technology migration curve was evaluated by considering the revenue attribution between existing technology and in-process research and development based on the assessment of the separation of forecasted future revenue between developed products and new generation products and the technology carryover rate.

[0001045810-21-000010:auditors_report:22]
Valuation of Inventories - Provisions for Excess or Obsolete Inventories

[0001045810-21-000010:auditors_report:23]
As described in Note 1 to the consolidated financial statements, the Company charges cost of sales for inventory provisions to write-down inventory to the lower of cost or net realizable value or for obsolete or excess inventory. Most of the Company’s inventory provisions relate to excess quantities of products, based on the Company’s inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. As

[0001045810-21-000010:auditors_report:24]
disclosed by management, the inventory provisions developed include assumptions about future demand and market conditions.  As of January 31, 2021, the Company’s consolidated inventories balance was $1,826 million.

[0001045810-21-000010:auditors_report:25]
The principal considerations for our determination that performing procedures relating to the valuation of inventories, specifically the provisions for excess or obsolete inventories, is a critical audit matter are the significant judgments by management when developing provisions for excess or obsolete inventories, including developing assumptions related to future demand and market conditions. This in turn led to significant auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s assumptions related to future demand and market conditions.

[0001045810-21-000010:auditors_report:26]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s provisions for excess or obsolete inventories, including controls over management’s assumptions related to future demand and market conditions. These procedures also included, among others, testing management’s process for developing the provisions for excess or obsolete inventories; evaluating the appropriateness of management’s approach; testing the completeness, accuracy, and relevance of underlying data used in the approach; and evaluating the reasonableness of management’s assumptions related to future demand and market conditions. Evaluating management’s assumptions related to future demand and market conditions involved evaluating whether the assumptions used by management were reasonable considering (i) current and past results, including historical product life cycle, (ii) the consistency with external market and industry data, (iii) changes in technology, and (iv) comparing prior period estimates to actual results of the same period.

[0001045810-21-000010:auditors_report:27]
/s/ PricewaterhouseCoopers LLP

[0001045810-21-000010:auditors_report:28]
San Jose, California

[0001045810-21-000010:auditors_report:29]
February 26, 2021

[0001045810-21-000010:auditors_report:30]
We have served as the Company’s auditor since 2004.

[0001045810-21-000010:auditors_report:31]
NVIDIA CORPORATION AND SUBSIDIARIES


## item_9a

[0001045810-21-000010:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001045810-21-000010:item_9a:2]
Controls and Procedures

[0001045810-21-000010:item_9a:3]
Disclosure Controls and Procedures

[0001045810-21-000010:item_9a:4]
Based on their evaluation as of January 31, 2021, our management, including our Chief Executive Officer and Chief Financial Officer, has concluded that our disclosure controls and procedures (as defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended, or the Exchange Act) were effective to provide reasonable assurance.

[0001045810-21-000010:item_9a:5]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001045810-21-000010:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 31, 2021 based on the criteria set forth in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on our evaluation under the criteria set forth in Internal Control — Integrated Framework, our management concluded that our internal control over financial reporting was effective as of January 31, 2021.

[0001045810-21-000010:item_9a:7]
The effectiveness of our internal control over financial reporting as of January 31, 2021 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in its report which is included herein.

[0001045810-21-000010:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001045810-21-000010:item_9a:9]
Other than the acquisition of Mellanox that occurred during the second quarter of fiscal year 2021, there were no changes in our internal control over financial reporting during our last fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting despite the fact that virtually all of our employees are working remotely due to the COVID-19 pandemic. We are continually monitoring and assessing the COVID-19 situation on our internal controls to minimize the impact on their operating effectiveness. We are in the process of integrating Mellanox into our systems and control environment. We believe that we have taken the necessary steps to monitor and maintain appropriate internal control over financial reporting during this integration.

[0001045810-21-000010:item_9a:10]
Inherent Limitations on Effectiveness of Controls

[0001045810-21-000010:item_9a:11]
Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.

[0001045810-21-000010:item_9a:12]
40
