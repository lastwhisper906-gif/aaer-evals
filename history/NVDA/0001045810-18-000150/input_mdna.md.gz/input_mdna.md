# NVDA MD&A — 0001045810-18-000150


## mdna

[0001045810-18-000150:mdna:1]
[same as prior period, unchanged from 0001045810-18-000114:mdna:1]

[0001045810-18-000150:mdna:2]
[same as prior period, unchanged from 0001045810-18-000114:mdna:2]

[0001045810-18-000150:mdna:3]
[same as prior period, unchanged from 0001045810-18-000114:mdna:3]

[0001045810-18-000150:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, G-SYNC, Jetson, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE AGX Xavier, NVIDIA DRIVE Constellation, NVIDIA DRIVE Pegasus, NVIDIA DRIVE Sim, NVIDIA GRID, NVIDIA Turing, NVSwitch, Pascal, TensorRT and Xavier are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-18-000150:mdna:5]
[same as prior period, unchanged from 0001045810-18-000114:mdna:5]

[0001045810-18-000150:mdna:6]
[same as prior period, unchanged from 0001045810-18-000114:mdna:6]

[0001045810-18-000150:mdna:7]
[same as prior period, unchanged from 0001045810-18-000114:mdna:7]

[0001045810-18-000150:mdna:8]
[same as prior period, unchanged from 0001045810-18-000114:mdna:8]

[0001045810-18-000150:mdna:9]
[same as prior period, unchanged from 0001045810-18-000114:mdna:9]

[0001045810-18-000150:mdna:10]
[same as prior period, unchanged from 0001045810-18-000114:mdna:10]

[0001045810-18-000150:mdna:11]
[same as prior period, unchanged from 0001045810-18-000114:mdna:11]

[0001045810-18-000150:mdna:12]
[same as prior period, unchanged from 0001045810-18-000114:mdna:13]

[0001045810-18-000150:mdna:13]
Third Quarter of Fiscal Year 2019 Summary

[0001045810-18-000150:mdna:14]
|  | Three Months Ended |  |  |  |  |
|  | October 28, 2018 |  | July 29, 2018 |  | October 29, 2017 |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 3,181 |  |  | $ | 3,123 |  |  | $ | 2,636 |  |  | 2 | % |  | 21 | % |
| Gross margin | 60.4 | % |  | 63.3 | % |  | 59.5 | % |  | (290) bps |  |  | 90 bps |  |
| Operating expenses | $ | 863 |  |  | $ | 818 |  |  | $ | 674 |  |  | 6 | % |  | 28 | % |
| Income from operations | $ | 1,058 |  |  | $ | 1,157 |  |  | $ | 895 |  |  | (9 | )% |  | 18 | % |
| Net income | $ | 1,230 |  |  | $ | 1,101 |  |  | $ | 838 |  |  | 12 | % |  | 47 | % |
| Net income per diluted share | $ | 1.97 |  |  | $ | 1.76 |  |  | $ | 1.33 |  |  | 12 | % |  | 48 | % |

[0001045810-18-000150:mdna:15]
Revenue for the third quarter of fiscal year 2019 increased 21% year over year and increased 2% sequentially. GPU business revenue was $2.77 billion, up 25% from a year earlier and up 4% sequentially, reflecting growth in professional visualization, datacenter, and gaming GPUs. Tegra Processor business revenue - which includes automotive, SOC modules for the Nintendo Switch gaming console, and other embedded edge AI platforms - was $407 million, down 3% from a year ago and down 13% sequentially.

[0001045810-18-000150:mdna:16]
Gaming revenue was $1.76 billion, up 13% from a year ago driven by growth in gaming GPUs, and down 2% sequentially as gaming GPU growth was more than offset by a seasonal decline in SOC modules for Nintendo Switch. Gaming GPU growth was fueled by Turing-based GPUs for desktops and by gaming notebooks based on our Max-Q technology.

[0001045810-18-000150:mdna:17]
Professional visualization revenue was $305 million, up 28% from a year earlier and up 9% sequentially driven by strength across both desktop and mobile workstation products.

[0001045810-18-000150:mdna:18]
Datacenter revenue was $792 million, up 58% from a year ago and up 4% sequentially, led by strong sales of our Volta architecture-based products, including NVIDIA Tesla V100 and DGX systems, with contribution from the new Turing T4 Cloud GPU.

[0001045810-18-000150:mdna:19]
Automotive revenue of $172 million was up 19% from a year earlier and up 7% sequentially, incorporating infotainment modules, production DRIVE PX platforms, and development agreements with automotive companies.

[0001045810-18-000150:mdna:20]
OEM and IP revenue was $148 million, down 23% from a year ago, due to the absence of cryptocurrency mining.

[0001045810-18-000150:mdna:21]
Gross margin for the third quarter of fiscal year 2019 was 60.4%. Gross margins increased from a year ago - reflecting our continued shift toward higher-value platforms, which more than offset the current quarter impact of $57 million in charges related to prior architecture components and chips following the sharp fall-off in cryptocurrency mining demand.

[0001045810-18-000150:mdna:22]
Operating expenses for the third quarter of fiscal year 2019 were $863 million, up 28% from a year earlier and up 6% sequentially, reflecting increased headcount and related costs for our growth initiatives - including gaming, professional visualization, AI, and autonomous driving.

[0001045810-18-000150:mdna:23]
Income from operations for the third quarter of fiscal year 2019 was $1.06 billion, up 18% from a year earlier and down 9% sequentially. Net income and net income per diluted share for the third quarter of fiscal year 2019 were $1.23 billion and $1.97, respectively, up 47% and 48%, respectively, from a year earlier, fueled by strong revenue growth and improved gross margin.

[0001045810-18-000150:mdna:24]
We previously announced our plan to return $1.25 billion to shareholders in fiscal year 2019. During the first nine months of fiscal year 2019, we returned $1.13 billion to shareholders through a combination of $855 million in share repurchases and $273 million in cash dividends. In November 2018, our board of directors authorized an additional $7.00 billion under our share repurchase program for a total of $7.94 billion available through the end of December 2022. We announced a 7% increase in our quarterly cash dividend to $0.16 per share from $0.15 per share, to be paid with our next quarterly cash dividend on December 21, 2018, to all shareholders of record on November 30, 2018. We intend to return an additional $3.00 billion to shareholders by the end of fiscal year 2020, which may begin in the fourth quarter of fiscal year 2019.

[0001045810-18-000150:mdna:25]
Cash, cash equivalents and marketable securities were $7.59 billion as of October 28, 2018, compared with $7.94 billion at the end of the prior quarter. The decrease was primarily related to third quarter stock repurchases, dividends and taxes paid related to restricted stock units, partially offset by operating income and changes in working capital.

[0001045810-18-000150:mdna:26]
[same as prior period, unchanged from 0001045810-18-000114:mdna:24]

[0001045810-18-000150:mdna:27]
During the third quarter of fiscal year 2019, we introduced RAPIDS, an open-source GPU-acceleration platform for data science and machine learning; launched the NVIDIA T4 cloud GPU and NVIDIA TensorRT Hyperscale Inference Platform to deliver advanced acceleration in hyperscale datacenters; launched the NVIDIA RTX Server; released the GeForce RTX series, the first gaming GPUs based on the Turing architecture; and unveiled the Quadro RTX series, which is designed to revolutionize the workflow of designers and artists on the desktop.

[0001045810-18-000150:mdna:28]
During the second quarter of fiscal year 2019, we marked the launch of the Summit supercomputer at Oak Ridge National Laboratory, powered by NVIDIA Volta Tensor Core GPUs; introduced NVIDIA HGX-2, a unified computing platform for both AI and high performance computing; announced that five of the world’s seven fastest supercomputers are powered by NVIDIA GPUs; introduced the NVIDIA HGX-2 platform for both AI and HPC; and launched AIRI Mini with Pure Storage and ONTAP AI with NetApp for implementing and scaling deep learning. We also announced a number of Max-Q GeForce gaming notebook designs offered by major OEMs, enabling high-end performance for thin and light notebooks; disclosed that next-generation NVIDIA G-SYNC HDR displays are being shipped, enabling stutter-free gaming; and announced NVIDIA’s role in VirtualLink, a consortium establishing an industry standard to enable next-gen VR headsets to connect with PCs using a single, high-bandwidth USB Type-C connector. In August 2018, we unveiled our first Turing-based GPUs -- NVIDIA Quadro RTX 8000, RTX 6000 and RTX 5000 -- which we believe will revolutionize the work of millions of designers and artists; and introduced the NVIDIA RTX Server, a ray-tracing global illumination rendering server for render farms.

[0001045810-18-000150:mdna:29]
[same as prior period, unchanged from 0001045810-18-000114:mdna:27]

[0001045810-18-000150:mdna:30]
[same as prior period, unchanged from 0001045810-18-000114:mdna:28]

[0001045810-18-000150:mdna:31]
During the third quarter of fiscal year 2019, we announced NVIDIA’s first level-2 autopilot design wins with Toyota, Volvo Cars and Isuzu Motors; announced the start of production of our Xavier single-chip autopilot SOC and started shipping the NVIDIA DRIVE AGX Xavier developer kit; and announced that Yamaha Motor Co. will use NVIDIA to power its upcoming lineup of autonomous machines.

[0001045810-18-000150:mdna:32]
[same as prior period, unchanged from 0001045810-18-000114:mdna:29]

[0001045810-18-000150:mdna:33]
[same as prior period, unchanged from 0001045810-18-000114:mdna:30]

[0001045810-18-000150:mdna:34]
[same as prior period, unchanged from 0001045810-18-000114:mdna:31]

[0001045810-18-000150:mdna:35]
[same as prior period, unchanged from 0001045810-18-000114:mdna:32]

[0001045810-18-000150:mdna:36]
25

[0001045810-18-000150:mdna:37]
[same as prior period, unchanged from 0001045810-18-000114:mdna:33]

[0001045810-18-000150:mdna:38]
[same as prior period, unchanged from 0001045810-18-000114:mdna:34]

[0001045810-18-000150:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2018 |  | October 29, 2017 |  | October 28, 2018 |  | October 29, 2017 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 39.6 |  |  | 40.5 |  |  | 37.3 |  |  | 40.9 |  |
| Gross profit | 60.4 |  |  | 59.5 |  |  | 62.7 |  |  | 59.1 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 19.0 |  |  | 17.5 |  |  | 18.2 |  |  | 19.0 |  |
| Sales, general and administrative | 8.1 |  |  | 8.0 |  |  | 7.6 |  |  | 8.7 |  |
| Total operating expenses | 27.1 |  |  | 25.5 |  |  | 25.8 |  |  | 27.7 |  |
| Income from operations | 33.3 |  |  | 34.0 |  |  | 36.9 |  |  | 31.4 |  |
| Interest income | 1.2 |  |  | 0.6 |  |  | 1.0 |  |  | 0.7 |  |
| Interest expense | (0.5 | ) |  | (0.6 | ) |  | (0.5 | ) |  | (0.7 | ) |
| Other, net | — |  |  | — |  |  | 0.1 |  |  | (0.3 | ) |
| Total other income (expense) | 0.7 |  |  | — |  |  | 0.6 |  |  | (0.3 | ) |
| Income before income tax | 34.0 |  |  | 34.0 |  |  | 37.5 |  |  | 31.1 |  |
| Income tax expense (benefit) | (4.7 | ) |  | 2.2 |  |  | — |  |  | 2.8 |  |
| Net income | 38.7 | % |  | 31.8 | % |  | 37.5 | % |  | 28.3 | % |

[0001045810-18-000150:mdna:40]
[same as prior period, unchanged from 0001045810-18-000114:mdna:36]

[0001045810-18-000150:mdna:41]
[same as prior period, unchanged from 0001045810-18-000114:mdna:37]

[0001045810-18-000150:mdna:42]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2018 |  | October 29, 2017 |  | $Change |  | %Change |  | October 28, 2018 |  | October 29, 2017 |  | $Change |  | %Change |
|  | ($ in millions) |
| GPU | $ | 2,774 |  |  | $ | 2,217 |  |  | $ | 557 |  |  | 25 | % |  | $ | 8,195 |  |  | $ | 5,676 |  |  | $ | 2,519 |  |  | 44 | % |
| Tegra Processor | 407 |  |  | 419 |  |  | (12 | ) |  | (3 | )% |  | 1,316 |  |  | 1,084 |  |  | 232 |  |  | 21 | % |
| All Other | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | 43 |  |  | (43 | ) |  | (100 | )% |
| Total | $ | 3,181 |  |  | $ | 2,636 |  |  | $ | 545 |  |  | 21 | % |  | $ | 9,511 |  |  | $ | 6,803 |  |  | $ | 2,708 |  |  | 40 | % |

[0001045810-18-000150:mdna:43]
26

[0001045810-18-000150:mdna:44]
GPU Business. GPU business revenue increased by 25% for the third quarter of fiscal year 2019 compared to the third quarter of fiscal year 2018. This increase was due primarily to 20% growth in sales of GeForce GPU products for gaming, driven by initial sales of Turing-based GPUs for desktops and by high-performance notebooks based on our Max-Q technology. Datacenter revenue, including Tesla, GRID and DGX, increased 58%, reflecting strong sales of our Volta architecture products, including NVIDIA Tesla V100 and DGX systems. Revenue from Quadro GPUs for professional visualization increased 28% due primarily to higher sales across desktop and mobile workstation products. Our PC OEM revenue decreased by almost 40% driven by lower demand for GPU products targeted for use in cryptocurrency mining.

[0001045810-18-000150:mdna:45]
GPU business revenue increased by 44% for the first nine months of fiscal year 2019 compared to the first nine months of fiscal year 2018. This increase was due primarily to over 40% growth in sales of GeForce GPU products for gaming, driven by initial sales of Turing-based GPUs for desktops, Pascal-based GPUs for desktops and by high-performance notebooks based on our Max-Q technology. Datacenter revenue, including Tesla, GRID and DGX, increased 70%, reflecting strong sales of our Volta architecture, including NVIDIA Tesla V100 and DGX systems. Revenue from Quadro GPUs for professional visualization increased 23% due primarily to higher sales across desktop and mobile workstation products. Our PC OEM revenue increased by almost 20% due primarily to sales of GPU products targeted for use in cryptocurrency mining in the first quarter of fiscal year 2019.

[0001045810-18-000150:mdna:46]
Tegra Processor Business. Tegra Processor business revenue decreased by 3% for the third quarter of fiscal year 2019 compared to the third quarter of fiscal year 2018. This was driven by a decrease of about 30% in revenue from SOC modules for gaming platforms, which was partially offset by an increase of 19% in automotive revenue, primarily from DRIVE PX platforms and development agreements with automotive companies, as well as from infotainment modules.

[0001045810-18-000150:mdna:47]
Tegra Processor business revenue increased by 21% for the first nine months of fiscal year 2019 compared to the first nine months of fiscal year 2018. This was driven by an increase of 30% in revenue from SOC modules for gaming platforms, and an increase of 12% in automotive revenue, primarily from DRIVE PX platforms and development agreements with automotive companies, as well as from infotainment modules.

[0001045810-18-000150:mdna:48]
[same as prior period, unchanged from 0001045810-18-000114:mdna:43]

[0001045810-18-000150:mdna:49]
[same as prior period, unchanged from 0001045810-18-000114:mdna:44]

[0001045810-18-000150:mdna:50]
Revenue from sales to customers outside of the United States and Other Americas accounted for 82% and 81% of total revenue for the third quarter and first nine months of fiscal year 2019, respectively. Revenue from sales to customers outside of the United States and Other Americas accounted for 83% and 80% of total revenue for the third quarter and first nine months of fiscal year 2018, respectively. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-18-000150:mdna:51]
No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal years 2019 and 2018.

[0001045810-18-000150:mdna:52]
[same as prior period, unchanged from 0001045810-18-000114:mdna:47]

[0001045810-18-000150:mdna:53]
Our overall gross margin increased to 60.4% for the third quarter of fiscal year 2019 from 59.5% for the third quarter of fiscal year 2018. Our overall gross margin increased to 62.7% for the first nine months of fiscal year 2019 from 59.1% for the first nine months of fiscal year 2018. These increases reflect our continued shift toward higher-value platforms, which more than offset a charge of $57 million we recorded during the third quarter of fiscal year 2019 related to prior architecture components and chips following the sharp fall-off in cryptocurrency mining demand.

[0001045810-18-000150:mdna:54]
Inventory provisions totaled $70 million and $14 million for the third quarter of fiscal years 2019 and 2018, respectively. Sales of inventory that was previously written-off or written-down totaled $13 million and $6 million for the third quarter of fiscal years 2019 and 2018, respectively. As a result, the overall net effect on our gross margin was an unfavorable impact of 1.8% for the third quarter of fiscal year 2019, and a nominal impact for the third quarter of fiscal year 2018.

[0001045810-18-000150:mdna:55]
Inventory provisions totaled $124 million and $30 million for the first nine months of fiscal years 2019 and 2018, respectively. Sales of inventory that was previously written-off or written-down totaled $29 million for each of the first nine months of fiscal years 2019 and 2018. As a result, the overall net effect on our gross margin was an unfavorable impact of 1.0% for the first nine months of fiscal year 2019 and a nominal impact for the first nine months of fiscal year 2018.

[0001045810-18-000150:mdna:56]
[same as prior period, unchanged from 0001045810-18-000114:mdna:51]

[0001045810-18-000150:mdna:57]
GPU Business. The gross margin of our GPU business was flat during the third quarter of fiscal year 2019 compared to the third quarter of fiscal year 2018. Gross margin of our GPU business increased during the first nine months of

[0001045810-18-000150:mdna:58]
fiscal year 2019 compared to the first nine months of fiscal year 2018, primarily due to strong sales of high-end GeForce gaming GPUs and revenue growth in Datacenter.

[0001045810-18-000150:mdna:59]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the third quarter and first nine months of fiscal year 2019 compared to the third quarter and first nine months of fiscal year 2018, primarily due to a favorable mix shift.

[0001045810-18-000150:mdna:60]
[same as prior period, unchanged from 0001045810-18-000114:mdna:54]

[0001045810-18-000150:mdna:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2018 |  | October 29, 2017 |  | $Change |  | %Change |  | October 28, 2018 |  | October 29, 2017 |  | $Change |  | %Change |
|  | ($ in millions) |  | ($ in millions) |
| Research and development expenses | $ | 605 |  |  | $ | 462 |  |  | $ | 143 |  |  | 31 | % |  | $ | 1,729 |  |  | $ | 1,290 |  |  | $ | 439 |  |  | 34 | % |
| % of net revenue | 19 | % |  | 18 | % |  |  |  |  |  | 18 | % |  | 19 | % |  |  |  |  |
| Sales, general and administrative expenses | 258 |  |  | 212 |  |  | 46 |  |  | 22 | % |  | 725 |  |  | 594 |  |  | 131 |  |  | 22 | % |
| % of net revenue | 8 | % |  | 8 | % |  |  |  |  |  | 8 | % |  | 9 | % |  |  |  |  |
| Total operating expenses | $ | 863 |  |  | $ | 674 |  |  | $ | 189 |  |  | 28 | % |  | $ | 2,454 |  |  | $ | 1,884 |  |  | $ | 570 |  |  | 30 | % |

[0001045810-18-000150:mdna:62]
[same as prior period, unchanged from 0001045810-18-000114:mdna:56]

[0001045810-18-000150:mdna:63]
Research and development expenses increased by 31% and 34% during the third quarter and first nine months of fiscal year 2019, compared to the third quarter and first nine months of fiscal year 2018, respectively, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000150:mdna:64]
[same as prior period, unchanged from 0001045810-18-000114:mdna:58]

[0001045810-18-000150:mdna:65]
Sales, general and administrative expenses increased by 22% during both the third quarter and first nine months of fiscal year 2019, compared to the third quarter and first nine months of fiscal year 2018, driven primarily by employee additions and increases in employee compensation and other related costs, including stock-based compensation expense.

[0001045810-18-000150:mdna:66]
[same as prior period, unchanged from 0001045810-18-000114:mdna:60]

[0001045810-18-000150:mdna:67]
[same as prior period, unchanged from 0001045810-18-000114:mdna:61]

[0001045810-18-000150:mdna:68]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest income was $37 million and $17 million during the third quarter of fiscal years 2019 and 2018, respectively, and $94 million and $48 million during the first nine months of fiscal years 2019 and 2018, respectively. The increase in interest income was primarily due to higher rates from our floating rate securities and the purchase of new securities.

[0001045810-18-000150:mdna:69]
Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 2.20% Notes Due 2021 and 3.20% Notes Due 2026 issued in September 2016, and the 1.00% Convertible Notes Due 2018, or the Convertible Notes, issued in December 2013. Interest expense was $15 million during each of the third quarters of fiscal years 2019 and 2018, and $44 million and $46 million during the first nine months of fiscal years 2019 and 2018, respectively.

[0001045810-18-000150:mdna:70]
[same as prior period, unchanged from 0001045810-18-000114:mdna:64]

[0001045810-18-000150:mdna:71]
Other, net, consists primarily of realized or unrealized gains and losses from non-affiliated investments, losses on early debt conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Other, net, was not significant during the third quarter and first nine months of fiscal year 2019. Other, net, was not significant during the third quarter of fiscal year 2018 and $22 million of expense during the first nine months of fiscal year 2018, consisting primarily of $19 million of losses recognized from early conversions of the Convertible Notes during the first nine months of fiscal year 2018.

[0001045810-18-000150:mdna:72]
28

[0001045810-18-000150:mdna:73]
[same as prior period, unchanged from 0001045810-18-000114:mdna:67]

[0001045810-18-000150:mdna:74]
We recognized income tax benefit of $149 million and $3 million for the third quarter and first nine months of fiscal year 2019, respectively, and income tax expense of $58 million and $189 million for the third quarter and first nine months of fiscal year 2018, respectively. Income tax benefit as a percentage of income before income tax was 13.8% and nominal for the third quarter and first nine months of fiscal year 2019, respectively, and income tax expense as a percentage of income before tax was 6.5% and 8.9% for the third quarter and first nine months of fiscal year 2018, respectively.

[0001045810-18-000150:mdna:75]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2019 as compared to the same periods in the prior fiscal year was primarily due to a decrease in the U.S. statutory tax rate from 35% to 21% as a result of U.S. tax reform, and a $138 million reduction in our provisional U.S. tax reform transition tax amount in the third quarter of fiscal year 2019, partially offset by a decrease in the impact of tax benefits from stock-based compensation.

[0001045810-18-000150:mdna:76]
[same as prior period, unchanged from 0001045810-18-000114:mdna:70]

[0001045810-18-000150:mdna:77]
[same as prior period, unchanged from 0001045810-18-000114:mdna:71]

[0001045810-18-000150:mdna:78]
|  | October 28, 2018 |  | January 28, 2018 |
|  | (In millions) |
| Cash and cash equivalents | $ | 721 |  |  | $ | 4,002 |  |
| Marketable securities | 6,870 |  |  | 3,106 |  |
| Cash, cash equivalents and marketable securities | $ | 7,591 |  |  | $ | 7,108 |  |

[0001045810-18-000150:mdna:79]
|  | Nine Months Ended |
|  | October 28, 2018 |  | October 29, 2017 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 2,845 |  |  | $ | 2,144 |  |
| Net cash provided by (used in) investing activities | $ | (4,137 | ) |  | $ | 1,302 |  |
| Net cash used in financing activities | $ | (1,989 | ) |  | $ | (2,410 | ) |

[0001045810-18-000150:mdna:80]
As of October 28, 2018, we had $7.59 billion in cash, cash equivalents and marketable securities, an increase of $483 million from the end of fiscal year 2018. Our portfolio of cash equivalents and marketable securities is managed internally. Our investment policy requires the purchase of high-grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-18-000150:mdna:81]
Cash provided by operating activities increased in the first nine months of fiscal year 2019 compared to the first nine months of fiscal year 2018, due to higher net income, partially offset by changes in working capital.

[0001045810-18-000150:mdna:82]
Cash used in investing activities increased in the first nine months of fiscal year 2019 compared to the first nine months of fiscal year 2018, due to higher purchases of marketable securities, partially offset by higher maturities of marketable securities.

[0001045810-18-000150:mdna:83]
Cash used in financing activities decreased in the first nine months of fiscal year 2019 compared to the first nine months of fiscal year 2018, due to lower repayments of Convertible Notes, partially offset by higher tax payments related to employee stock plans.

[0001045810-18-000150:mdna:84]
[same as prior period, unchanged from 0001045810-18-000114:mdna:78]

[0001045810-18-000150:mdna:85]
[same as prior period, unchanged from 0001045810-18-000114:mdna:79]

[0001045810-18-000150:mdna:86]
As a result of the Tax Cuts and Job Acts that was signed into law in December 2017, substantially all of our cash, cash equivalents and marketable securities held outside of the United States as of October 28, 2018 are available for use in the United States without incurring additional U.S. federal income taxes. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000150:mdna:87]
[same as prior period, unchanged from 0001045810-18-000114:mdna:81]

[0001045810-18-000150:mdna:88]
We previously announced our plan to return $1.25 billion to shareholders in fiscal year 2019. During the first nine months of fiscal year 2019, we returned $1.13 billion to shareholders through a combination of $855 million in share repurchases and $273 million in cash dividends. In November 2018, our board of directors authorized an additional $7.00 billion under our share repurchase program for a total of $7.94 billion available through the end of December 2022. We announced a 7% increase in our quarterly cash dividend to $0.16 per share from $0.15 per share, to be paid with our next quarterly cash dividend on December 21, 2018, to all shareholders of record on November 30, 2018. We intend to return an additional $3.00 billion to shareholders by the end of fiscal year 2020, which may begin in the fourth quarter of fiscal year 2019.

[0001045810-18-000150:mdna:89]
[same as prior period, unchanged from 0001045810-18-000114:mdna:84]

[0001045810-18-000150:mdna:90]
[same as prior period, unchanged from 0001045810-18-000114:mdna:85]

[0001045810-18-000150:mdna:91]
[same as prior period, unchanged from 0001045810-18-000114:mdna:86]

[0001045810-18-000150:mdna:92]
[same as prior period, unchanged from 0001045810-18-000114:mdna:87]

[0001045810-18-000150:mdna:93]
We had $3 million in principal of Convertible Notes outstanding as of October 28, 2018, which will mature on December 1, 2018. Holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date, regardless of conversion conditions. Refer to Note 12 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-18-000150:mdna:94]
Revolving Credit Facility

[0001045810-18-000150:mdna:95]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 28, 2018, we had not borrowed any amounts under this agreement.

[0001045810-18-000150:mdna:96]
[same as prior period, unchanged from 0001045810-18-000114:mdna:91]

[0001045810-18-000150:mdna:97]
We have a $575 million commercial paper program to support general corporate purposes. As of October 28, 2018, we had not issued any commercial paper.

[0001045810-18-000150:mdna:98]
[same as prior period, unchanged from 0001045810-18-000114:mdna:93]

[0001045810-18-000150:mdna:99]
[same as prior period, unchanged from 0001045810-18-000114:mdna:94]

[0001045810-18-000150:mdna:100]
[same as prior period, unchanged from 0001045810-18-000114:mdna:95]

[0001045810-18-000150:mdna:101]
As of October 28, 2018, we had no material off-balance sheet arrangements as defined by applicable SEC regulations.

[0001045810-18-000150:mdna:102]
[same as prior period, unchanged from 0001045810-18-000114:mdna:97]

[0001045810-18-000150:mdna:103]
[same as prior period, unchanged from 0001045810-18-000114:mdna:98]

[0001045810-18-000150:mdna:104]
[same as prior period, unchanged from 0001045810-18-000114:mdna:99]

[0001045810-18-000150:mdna:105]
30

[0001045810-18-000150:mdna:106]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000150:mdna:107]
Refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
