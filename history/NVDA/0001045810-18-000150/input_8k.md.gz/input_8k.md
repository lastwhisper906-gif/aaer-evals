# NVDA 8-K — 0001045810-18-000148 filed 2018-11-15

## item codes, every 8-K on or before 2018-11-15

- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2018-11-15

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-18-000148:8k_2_02:1]
EX-99.1
2
q3fy19pr.htm
Q3FY19 PRESS RELEASE

[0001045810-18-000148:8k_2_02:2]
Exhibit

[0001045810-18-000148:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-18-000148:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2019

[0001045810-18-000148:8k_2_02:5]
| • | Record revenue from Datacenter, Professional Visualization, Automotive platforms |

[0001045810-18-000148:8k_2_02:6]
| • | Quarterly cash dividend raised 7 percent to $0.16 per share |

[0001045810-18-000148:8k_2_02:7]
| • | Company intends to return an additional $3 billion to shareholders through fiscal 2020 |

[0001045810-18-000148:8k_2_02:8]
SANTA CLARA, Calif.-Nov. 15, 2018-NVIDIA (NASDAQ: NVDA) today reported revenue for the third quarter ended Oct. 28, 2018, of $3.18 billion, up 21 percent from $2.64 billion a year earlier, and up 2 percent from $3.12 billion in the previous quarter.

[0001045810-18-000148:8k_2_02:9]
GAAP earnings per diluted share for the quarter were $1.97, up 48 percent from $1.33 a year ago and up 12 percent from $1.76 in the previous quarter. Non-GAAP earnings per diluted share were $1.84, up 38 percent from $1.33 a year earlier and down 5 percent from $1.94 in the previous quarter.

[0001045810-18-000148:8k_2_02:10]
“AI is advancing at an incredible pace across the world, driving record revenues for our datacenter platforms,” said Jensen Huang, founder and CEO of NVIDIA. “Our introduction of Turing GPUs is a giant leap for computer graphics and AI, bringing the magic of real-time ray tracing to games and the biggest generational performance improvements we have ever delivered.

[0001045810-18-000148:8k_2_02:11]
“Our near-term results reflect excess channel inventory post the crypto-currency boom, which will be corrected. Our market position and growth opportunities are stronger than ever. During the quarter, we launched new platforms to extend our architecture into new growth markets - RAPIDS for machine learning, RTX Server for film rendering, and the T4 Cloud GPU for hyperscale and cloud.”

[0001045810-18-000148:8k_2_02:12]
Capital Return

[0001045810-18-000148:8k_2_02:13]
During the first nine months of fiscal 2019, NVIDIA returned $1.13 billion to shareholders through a combination of $855 million in share repurchases and $273 million in quarterly cash dividends.

[0001045810-18-000148:8k_2_02:14]
In November 2018, the board of directors authorized an additional $7 billion under the company’s share repurchase program for a total of $7.94 billion available through the end of December 2022.

[0001045810-18-000148:8k_2_02:15]
NVIDIA announced a 7 percent increase in its quarterly cash dividend to $0.16 per share from $0.15 per share, to be paid with its next quarterly cash dividend on December 21, 2018, to all shareholders of record on November 30, 2018.

[0001045810-18-000148:8k_2_02:16]
NVIDIA intends to return an additional $3 billion to shareholders by the end of fiscal 2020, which may begin in the fourth quarter of fiscal 2019.

[0001045810-18-000148:8k_2_02:17]
Q3 Fiscal 2019 Summary

[0001045810-18-000148:8k_2_02:18]
| GAAP |
| ($ in millions except earnings per share) | Q3 FY19 | Q2 FY19 | Q3 FY18 | Q/Q | Y/Y |
| Revenue | $3,181 | $3,123 | $2,636 | Up 2% | Up 21% |
| Gross margin | 60.4% | 63.3% | 59.5% | Down 290 bps | Up 90 bps |
| Operating expenses | $863 | $818 | $674 | Up 6% | Up 28% |
| Operating income | $1,058 | $1,157 | $895 | Down 9% | Up 18% |
| Net income | $1,230 | $1,101 | $838 | Up 12% | Up 47% |
| Diluted earnings per share | $1.97 | $1.76 | $1.33 | Up 12% | Up 48% |

[0001045810-18-000148:8k_2_02:19]
| Non-GAAP |
| ($ in millions except earnings per share) | Q3 FY19 | Q2 FY19 | Q3 FY18 | Q/Q | Y/Y |
| Revenue | $3,181 | $3,123 | $2,636 | Up 2% | Up 21% |
| Gross margin | 61.0% | 63.5% | 59.7% | Down 250 bps | Up 130 bps |
| Operating expenses | $730 | $692 | $570 | Up 5% | Up 28% |
| Operating income | $1,210 | $1,290 | $1,005 | Down 6% | Up 20% |
| Net income | $1,151 | $1,210 | $833 | Down 5% | Up 38% |
| Diluted earnings per share | $1.84 | $1.94 | $1.33 | Down 5% | Up 38% |

[0001045810-18-000148:8k_2_02:20]
NVIDIA’s outlook for the fourth quarter of fiscal 2019 is as follows:

[0001045810-18-000148:8k_2_02:21]
| • | Revenue is expected to be $2.70 billion, plus or minus 2 percent. |

[0001045810-18-000148:8k_2_02:22]
| • | GAAP and non-GAAP gross margins are expected to be 62.3 percent and 62.5 percent, respectively, plus or minus 50 basis points. |

[0001045810-18-000148:8k_2_02:23]
| • | GAAP and non-GAAP operating expenses are expected to be approximately $915 million and $755 million, respectively. |

[0001045810-18-000148:8k_2_02:24]
| • | GAAP and non-GAAP other income and expense are both expected to be income of approximately $21 million. |

[0001045810-18-000148:8k_2_02:25]
| • | GAAP and non-GAAP tax rates are both expected to be 8 percent, plus or minus 1 percent, excluding any discrete items. GAAP discrete items include excess tax benefits or deficiencies related to stock-based compensation, which are expected to generate variability on a quarter by quarter basis. |

[0001045810-18-000148:8k_2_02:26]
Third Quarter Fiscal 2019 Highlights

[0001045810-18-000148:8k_2_02:27]
Since its second quarter earnings release, NVIDIA has achieved progress in these areas:

[0001045810-18-000148:8k_2_02:28]
Company-wide

[0001045810-18-000148:8k_2_02:29]
| • | Launched the revolutionary NVIDIA Turing™ GPU architecture, with new RT Cores to accelerate ray tracing and new Tensor Cores for AI inferencing. |

[0001045810-18-000148:8k_2_02:30]
| • | Drew nearly 13,000 attendees to GPU Technology Conferences in Munich, Tel Aviv, Tokyo and Washington, following events in San Jose and Taipei. The company expects 30,000 total GTC attendees this year, up more than 30 percent from 2017. |

[0001045810-18-000148:8k_2_02:31]
Datacenter

[0001045810-18-000148:8k_2_02:32]
| • | Announced that the new TOP500 list of the world’s fastest supercomputers shows a 48 percent jump over last year in the number of systems using NVIDIA GPU accelerators, climbing to 127, including the fastest in the world, No. 1 in the U.S., No. 1 in Europe and No. 1 in Japan. |

[0001045810-18-000148:8k_2_02:33]
| • | Introduced RAPIDS™, an open-source GPU-acceleration platform for data science and machine learning, with broad adoption from industry leaders including Dell EMC, Hewlett Packard Enterprise, IBM, Oracle and SAP. |

[0001045810-18-000148:8k_2_02:34]
| • | Launched the NVIDIA T4 Cloud GPU and NVIDIA TensorRT™ Hyperscale Inference Platform to deliver advanced acceleration for voice, video, image and recommendation services in hyperscale datacenters. Within the first two months of its launch, the T4 received the fastest adoption of any server GPU, featuring in 57 separate designs from leading computer makers, and availability on Google Cloud Platform. |

[0001045810-18-000148:8k_2_02:35]
| • | Launched the NVIDIA RTX™ Server, opening a new market to GPUs for photo-real rendering in the datacenter. |

[0001045810-18-000148:8k_2_02:36]
| • | Unveiled the NVIDIA Clara™ platform, which brings AI to the next generation of medical instruments as a powerful tool for early detection, diagnosis and treatment of disease. |

[0001045810-18-000148:8k_2_02:37]
Gaming

[0001045810-18-000148:8k_2_02:38]
| • | Released the GeForce RTX™ series, the first gaming GPUs based on the Turing architecture and the NVIDIA RTX platform, which fuses next-generation shaders with real-time ray tracing and new AI capabilities, including Deep Learning Super-Sampling anti-aliasing. |

[0001045810-18-000148:8k_2_02:39]
Professional Visualization

[0001045810-18-000148:8k_2_02:40]
| • | Unveiled the Quadro RTX™ series, which is designed to revolutionize the workflow of millions of designers and artists on the desktop. |

[0001045810-18-000148:8k_2_02:41]
Automotive

[0001045810-18-000148:8k_2_02:42]
| • | Announced NVIDIA’s first Level-2 autopilot design wins with Toyota, Volvo Cars and Isuzu Motors. |

[0001045810-18-000148:8k_2_02:43]
| • | Announced that Continental and Veoneer, leading tier-1 suppliers, have each selected DRIVE AGX Xavier to power self-driving solutions to be offered early in the 2020s. |

[0001045810-18-000148:8k_2_02:44]
| • | Announced the start of production of Xavier™, the world’s first single-chip autopilot SOC, and started shipping the NVIDIA DRIVE AGX Xavier™ developer kit. |

[0001045810-18-000148:8k_2_02:45]
| • | Published NVIDIA’s Self-Driving Safety Report, detailing the company’s development processes and four fundamental pillars of safe autonomous driving. |

[0001045810-18-000148:8k_2_02:46]
Edge AI

[0001045810-18-000148:8k_2_02:47]
| • | Announced global availability of the NVIDIA Jetson™ AGX Xavier™ developer kit, with leading Japanese companies among the first to adopt the platform. |

[0001045810-18-000148:8k_2_02:48]
| • | Announced that Yamaha Motor Co. will use NVIDIA to power its upcoming lineup of autonomous machines. |

[0001045810-18-000148:8k_2_02:49]
CFO Commentary

[0001045810-18-000148:8k_2_02:50]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-18-000148:8k_2_02:51]
Conference Call and Webcast Information

[0001045810-18-000148:8k_2_02:52]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2019 financial results and current financial prospects today at 2:30 p.m. Pacific time (5:30 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 5485625. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its fourth quarter and fiscal 2019.

[0001045810-18-000148:8k_2_02:53]
Non-GAAP Measures

[0001045810-18-000148:8k_2_02:54]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, acquisition-related costs, restructuring and other, contributions, gains from non-affiliated investments, interest expense related to amortization of debt discount, debt-related costs, the associated tax impact of these items, where applicable, and the tax benefit from income tax reform. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-18-000148:8k_2_02:55]
Keep Current on NVIDIA

[0001045810-18-000148:8k_2_02:56]
Subscribe to the NVIDIA blog, follow us on Facebook, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-18-000148:8k_2_02:57]
About NVIDIA

[0001045810-18-000148:8k_2_02:58]
NVIDIA’s (NASDAQ: NVDA) invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-18-000148:8k_2_02:59]
###

[0001045810-18-000148:8k_2_02:60]
For further information, contact:

[0001045810-18-000148:8k_2_02:61]
| Simona Jankowski |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sjankowski@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-18-000148:8k_2_02:62]
Certain statements in this press release including, but not limited to, statements as to: AI advancing at an incredible pace across the world, driving record revenues for our datacenter platforms; NVIDIA’s introduction of Turing-based RTX GPUs making a giant leap in computer graphics and AI, bringing the magic of real-time ray tracing to games and bringing the biggest generation performance improvements NVIDIA has delivered; NVIDIA’s near-term results reflecting excess channel inventory post the crypto-currency boom and its correction; NVIDIA’s market position and growth opportunities being stronger than ever; the launch of new platforms to extend NVIDIA’s architecture into new growth markets; NVIDIA’s intended capital return for fiscal 2019 and through the end of fiscal 2020; NVIDIA’s next quarterly cash dividend; NVIDIA’s financial outlook for the fourth quarter of fiscal 2019; NVIDIA’s expected tax rates for the fourth quarter of fiscal 2019; our expectation to generate variability from excess tax benefits or deficiencies related to stock-based compensation; the expected number of attendees at GTC events this year; the impact, benefits, abilities and performance of NVIDIA RTX Server, RAPIDS, NVIDIA Turing GPU architecture, NVIDIA T4 Cloud GPU, NVIDIA Tensor RT Hyperscale Inference Platform, NVIDIA Clara platform, NVIDIA DRIVE AGX Xavier developer kit and GeForce RTX series fusing next-generation shaders with real-time ray tracing and new AI capabilities; NVIDIA T4 rapidly being adopted, it being featured in designs from leading computer makers and its availability on Google Cloud Platform; the NVIDIA Clara platform bringing AI to the next generation of medical instruments; the Quadro RTX series revolutionizing the workflow of millions of designers and artists; NVIDIA’s Level-2 autopilot designs being used

[0001045810-18-000148:8k_2_02:63]
by Toyota, Volvo cars and Isuzu Motors; Continental and Veoneer selecting DRIVE AGX Xavier to power self-driving solutions to be offered early in the 2020s; NVIDIA starting to produce Xavier and shipping the NVIDIA DRIVE AGX Xavier developer kit;  NVIDIA Jetson AGX Xavier developer kit being adopted by leading Japanese companies; and Yamaha Motor Co. using NVIDIA to power its lineup of autonomous machines are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-18-000148:8k_2_02:64]
© 2018 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce RTX, Quadro, Quadro RTX, Jetson, NVIDIA AGX, NVIDIA Clara, NVIDIA DRIVE, NVIDIA DRIVE AGX Xavier, NVIDIA DRIVE Hyperion, NVIDIA RTX, NVIDIA Turing, RAPIDS, TensorRT and Xavier are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-18-000148:8k_2_02:65]
NVIDIA CORPORATION

[0001045810-18-000148:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-18-000148:8k_2_02:67]
(In millions, except per share data)

[0001045810-18-000148:8k_2_02:68]
(Unaudited)

[0001045810-18-000148:8k_2_02:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue | $ | 3,181 |  |  | $ | 2,636 |  |  | $ | 9,511 |  |  | $ | 6,803 |  |
| Cost of revenue | 1,260 |  |  | 1,067 |  |  | 3,547 |  |  | 2,782 |  |
| Gross profit | 1,921 |  |  | 1,569 |  |  | 5,964 |  |  | 4,021 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 605 |  |  | 462 |  |  | 1,729 |  |  | 1,290 |  |
| Sales, general and administrative | 258 |  |  | 212 |  |  | 725 |  |  | 594 |  |
| Total operating expenses | 863 |  |  | 674 |  |  | 2,454 |  |  | 1,884 |  |
| Income from operations | 1,058 |  |  | 895 |  |  | 3,510 |  |  | 2,137 |  |
| Interest income | 37 |  |  | 17 |  |  | 94 |  |  | 48 |  |
| Interest expense | (15 | ) |  | (15 | ) |  | (44 | ) |  | (46 | ) |
| Other, net | 1 |  |  | (1 | ) |  | 12 |  |  | (22 | ) |
| Total other income (expense) | 23 |  |  | 1 |  |  | 62 |  |  | (20 | ) |
| Income before income tax | 1,081 |  |  | 896 |  |  | 3,572 |  |  | 2,117 |  |
| Income tax expense (benefit) | (149 | ) |  | 58 |  |  | (3 | ) |  | 189 |  |
| Net income | $ | 1,230 |  |  | $ | 838 |  |  | $ | 3,575 |  |  | $ | 1,928 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.02 |  |  | $ | 1.39 |  |  | $ | 5.88 |  |  | $ | 3.23 |  |
| Diluted | $ | 1.97 |  |  | $ | 1.33 |  |  | $ | 5.71 |  |  | $ | 3.05 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 609 |  |  | 603 |  |  | 608 |  |  | 597 |  |
| Diluted | 625 |  |  | 628 |  |  | 626 |  |  | 633 |  |

[0001045810-18-000148:8k_2_02:70]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | October 28, |  | January 28, |
|  |  |  | 2018 |  | 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 7,591 |  |  | $ | 7,108 |  |
|  | Accounts receivable, net |  | 2,219 |  |  | 1,265 |  |
|  | Inventories |  | 1,417 |  |  | 796 |  |
|  | Prepaid expenses and other current assets |  | 159 |  |  | 86 |  |
|  | Total current assets |  | 11,386 |  |  | 9,255 |  |
| Property and equipment, net |  | 1,292 |  |  | 997 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 49 |  |  | 52 |  |
| Other assets |  | 312 |  |  | 319 |  |
|  | Total assets |  | $ | 13,657 |  |  | $ | 11,241 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 902 |  |  | $ | 596 |  |
|  | Accrued and other current liabilities |  | 703 |  |  | 542 |  |
|  | Convertible short-term debt |  | 3 |  |  | 15 |  |
|  | Total current liabilities |  | 1,608 |  |  | 1,153 |  |
| Long-term debt |  | 1,987 |  |  | 1,985 |  |
| Other long-term liabilities |  | 587 |  |  | 632 |  |
|  | Total liabilities |  | 4,182 |  |  | 3,770 |  |
| Shareholders' equity |  | 9,475 |  |  | 7,471 |  |
|  | Total liabilities and shareholders' equity |  | $ | 13,657 |  |  | $ | 11,241 |  |

[0001045810-18-000148:8k_2_02:71]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 28, |  | July 29, |  | October 29, |  | October 28, |  | October 29, |
|  |  | 2018 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 1,921 |  |  | $ | 1,975 |  |  | $ | 1,569 |  |  | $ | 5,964 |  |  | $ | 4,021 |  |
| GAAP gross margin |  | 60.4 | % |  | 63.3 | % |  | 59.5 | % |  | 62.7 | % |  | 59.1 | % |
| Stock-based compensation expense (A) |  | 5 |  |  | 8 |  |  | 6 |  |  | 21 |  |  | 14 |  |
| Legal settlement costs |  | 14 |  |  | — |  |  | — |  |  | 14 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 1,940 |  |  | $ | 1,983 |  |  | $ | 1,575 |  |  | $ | 5,999 |  |  | $ | 4,035 |  |
| Non-GAAP gross margin |  | 61.0 | % |  | 63.5 | % |  | 59.7 | % |  | 63.1 | % |  | 59.3 | % |
| GAAP operating expenses |  | $ | 863 |  |  | $ | 818 |  |  | $ | 674 |  |  | $ | 2,454 |  |  | $ | 1,884 |  |
| Stock-based compensation expense (A) |  | (135 | ) |  | (124 | ) |  | (101 | ) |  | (379 | ) |  | (251 | ) |
| Acquisition-related costs (B) |  | (1 | ) |  | (2 | ) |  | (3 | ) |  | (5 | ) |  | (11 | ) |
| Legal settlement costs |  | (1 | ) |  | — |  |  | — |  |  | (3 | ) |  | — |  |
| Restructuring and other |  | 4 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |
| Contributions |  | — |  |  | — |  |  | — |  |  | — |  |  | (2 | ) |
| Non-GAAP operating expenses |  | $ | 730 |  |  | $ | 692 |  |  | $ | 570 |  |  | $ | 2,071 |  |  | $ | 1,620 |  |
| GAAP income from operations |  | $ | 1,058 |  |  | $ | 1,157 |  |  | $ | 895 |  |  | $ | 3,510 |  |  | $ | 2,137 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 152 |  |  | 133 |  |  | 110 |  |  | 418 |  |  | 278 |  |
| Non-GAAP income from operations |  | $ | 1,210 |  |  | $ | 1,290 |  |  | $ | 1,005 |  |  | $ | 3,928 |  |  | $ | 2,415 |  |
| GAAP other income (expense) |  | $ | 23 |  |  | $ | 23 |  |  | $ | 1 |  |  | $ | 62 |  |  | $ | (20 | ) |
| Gains from non-affiliated investments (C) |  | (2 | ) |  | (2 | ) |  | — |  |  | (11 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 3 |  |
| Debt-related costs (D) |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 19 |  |
| Non-GAAP other income (expense) |  | $ | 21 |  |  | $ | 21 |  |  | $ | 2 |  |  | $ | 52 |  |  | $ | 2 |  |
| GAAP net income |  | $ | 1,230 |  |  | $ | 1,101 |  |  | $ | 838 |  |  | $ | 3,575 |  |  | $ | 1,928 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 150 |  |  | 131 |  |  | 111 |  |  | 409 |  |  | 300 |  |
| Income tax impact of non-GAAP adjustments (E) |  | (91 | ) |  | (22 | ) |  | (116 | ) |  | (199 | ) |  | (224 | ) |
| Tax benefit from income tax reform |  | (138 | ) |  | — |  |  | — |  |  | (138 | ) |  | — |  |
| Non-GAAP net income |  | $ | 1,151 |  |  | $ | 1,210 |  |  | $ | 833 |  |  | $ | 3,647 |  |  | $ | 2,004 |  |

[0001045810-18-000148:8k_2_02:72]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 28, |  | July 29, |  | October 29, |  | October 28, |  | October 29, |
|  |  | 2018 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 1.97 |  |  | $ | 1.76 |  |  | $ | 1.33 |  |  | $ | 5.71 |  |  | $ | 3.05 |  |
| Non-GAAP |  | $ | 1.84 |  |  | $ | 1.94 |  |  | $ | 1.33 |  |  | $ | 5.83 |  |  | $ | 3.20 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 625 |  |  | 626 |  |  | 628 |  |  | 626 |  |  | 633 |  |
| Anti-dilution impact from note hedge (F) |  | — |  |  | (1 | ) |  | (2 | ) |  | — |  |  | (7 | ) |
| Non-GAAP |  | 625 |  |  | 625 |  |  | 626 |  |  | 626 |  |  | 626 |  |
| GAAP net cash provided by operating activities |  | $ | 487 |  |  | $ | 913 |  |  | $ | 1,157 |  |  | $ | 2,845 |  |  | $ | 2,144 |  |
| Purchase of property and equipment and intangible assets |  | (150 | ) |  | (128 | ) |  | (69 | ) |  | (397 | ) |  | (178 | ) |
| Free cash flow |  | $ | 337 |  |  | $ | 785 |  |  | $ | 1,088 |  |  | $ | 2,448 |  |  | $ | 1,966 |  |

[0001045810-18-000148:8k_2_02:73]
| (A) Stock-based compensation consists of the following: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 28, |  | July 29, |  | October 29, |  | October 28, |  | October 29, |
|  |  | 2018 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 5 |  |  | $ | 8 |  |  | $ | 6 |  |  | $ | 21 |  |  | $ | 14 |  |
| Research and development |  | $ | 88 |  |  | $ | 76 |  |  | $ | 61 |  |  | $ | 237 |  |  | $ | 146 |  |
| Sales, general and administrative |  | $ | 47 |  |  | $ | 48 |  |  | $ | 40 |  |  | $ | 142 |  |  | $ | 105 |  |
| (B) Consists of amortization of acquisition-related intangible assets and compensation charges. |
| (C) Consists of unrealized gains from non-affiliated investments. |
| (D) Consists of loss on early debt conversions. |
| (E) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |
| (F) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-18-000148:8k_2_02:74]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2019 Outlook |
| GAAP gross margin |  | 62.3 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 62.5 | % |
|  |  |  | Q4 FY2019 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 915 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (160 | ) |
| Non-GAAP operating expenses |  | $ | 755 |  |
