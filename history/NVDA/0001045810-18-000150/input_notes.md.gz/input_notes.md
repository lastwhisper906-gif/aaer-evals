# NVDA notes — 0001045810-18-000150


## nvda:BalanceSheetComponentsTextBlock

[0001045810-18-000150:notes:1]
[same as prior period, unchanged from 0001045810-18-000114:notes:1]

[0001045810-18-000150:notes:2]
[same as prior period, unchanged from 0001045810-18-000114:notes:2]

[0001045810-18-000150:notes:3]
|  | October 28, |  | January 28, |
|  | 2018 |  | 2018 |
| Inventories: | (In millions) |
| Raw materials | $ | 634 |  |  | $ | 227 |  |
| Work in-process | 259 |  |  | 192 |  |
| Finished goods | 524 |  |  | 377 |  |
| Total inventories | $ | 1,417 |  |  | $ | 796 |  |

[0001045810-18-000150:notes:4]
As of October 28, 2018, we had outstanding inventory purchase obligations totaling $1.56 billion.

[0001045810-18-000150:notes:5]
|  | October 28, |  | January 28, |
|  | 2018 |  | 2018 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer program accruals | $ | 319 |  |  | $ | 181 |  |
| Accrued payroll and related expenses | 151 |  |  | 172 |  |
| Deferred revenue (1) | 80 |  |  | 53 |  |
| Taxes payable | 40 |  |  | 33 |  |
| Accrued royalties | 19 |  |  | 17 |  |
| Warranty accrual (2) | 18 |  |  | 15 |  |
| Professional service fees | 15 |  |  | 15 |  |
| Coupon interest on debt obligations | 7 |  |  | 20 |  |
| Other | 54 |  |  | 36 |  |
| Total accrued and other current liabilities | $ | 703 |  |  | $ | 542 |  |

[0001045810-18-000150:notes:6]
[same as prior period, unchanged from 0001045810-18-000114:notes:6]

[0001045810-18-000150:notes:7]
[same as prior period, unchanged from 0001045810-18-000114:notes:7]

[0001045810-18-000150:notes:8]
|  | October 28, |  | January 28, |
|  | 2018 |  | 2018 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 469 |  |  | $ | 559 |  |
| Deferred revenue (2) | 40 |  |  | 15 |  |
| Deferred income tax liability | 23 |  |  | 18 |  |
| Employee benefits liability | 19 |  |  | 12 |  |
| Deferred rent | 17 |  |  | 9 |  |
| Other | 19 |  |  | 19 |  |
| Total other long-term liabilities | $ | 587 |  |  | $ | 632 |  |

[0001045810-18-000150:notes:9]
| (1) | As of October 28, 2018, represents the long-term portion of the one-time transition tax payable of $337 million, as well as unrecognized tax benefits of $116 million and related interest and penalties of $16 million. |

[0001045810-18-000150:notes:10]
[same as prior period, unchanged from 0001045810-18-000114:notes:10]


## nvda:DebtSecuritiesAvailableforsaleTableTextBlock

[0001045810-18-000150:notes:11]
The following is a summary of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018:

[0001045810-18-000150:notes:12]
|  | October 28, 2018 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 2,732 |  |  | $ | 1 |  |  | $ | (6 | ) |  | $ | 2,727 |  |  | $ | — |  |  | $ | 2,727 |  |
| Debt securities of United States government agencies | 2,140 |  |  | — |  |  | (5 | ) |  | $ | 2,135 |  |  | — |  |  | 2,135 |  |
| Debt securities issued by the United States Treasury | 1,544 |  |  | — |  |  | (2 | ) |  | 1,542 |  |  | — |  |  | 1,542 |  |
| Money market funds | 602 |  |  | — |  |  | — |  |  | 602 |  |  | 602 |  |  | — |  |
| Foreign government bonds | 191 |  |  | — |  |  | — |  |  | 191 |  |  | — |  |  | 191 |  |
| Asset-backed securities | 178 |  |  | — |  |  | (2 | ) |  | 176 |  |  | — |  |  | 176 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 98 |  |  | 1 |  |  | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 7,485 |  |  | $ | 2 |  |  | $ | (15 | ) |  | $ | 7,472 |  |  | $ | 602 |  |  | $ | 6,870 |  |

[0001045810-18-000150:notes:13]
[same as prior period, unchanged from 0001045810-18-000114:notes:13]

[0001045810-18-000150:notes:14]
The following table provides the breakdown of unrealized losses as of October 28, 2018, aggregated by investment category and length of time that individual securities have been in a continuous loss position:

[0001045810-18-000150:notes:15]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Debt securities issued by United States government agencies | $ | 1,584 |  |  | $ | (1 | ) |  | $ | 507 |  |  | $ | (4 | ) |  | $ | 2,091 |  |  | $ | (5 | ) |
| Debt securities issued by the United States Treasury | 1,253 |  |  | — |  |  | 289 |  |  | (2 | ) |  | 1,542 |  |  | (2 | ) |
| Corporate debt securities | 167 |  |  | — |  |  | 794 |  |  | (6 | ) |  | 961 |  |  | (6 | ) |
| Asset-backed securities | — |  |  | — |  |  | 176 |  |  | (2 | ) |  | 176 |  |  | (2 | ) |
| Total | $ | 3,004 |  |  | $ | (1 | ) |  | $ | 1,766 |  |  | $ | (14 | ) |  | $ | 4,770 |  |  | $ | (15 | ) |

[0001045810-18-000150:notes:16]
The amortized cost and estimated fair value of cash equivalents and marketable securities as of October 28, 2018 and January 28, 2018 are shown below by contractual maturity.

[0001045810-18-000150:notes:17]
|  | October 28, 2018 |  | January 28, 2018 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 5,537 |  |  | $ | 5,524 |  |  | $ | 5,381 |  |  | $ | 5,375 |  |
| Due in 1 - 5 years | 1,923 |  |  | 1,923 |  |  | 1,500 |  |  | 1,485 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 25 |  |  | 25 |  |  | 35 |  |  | 35 |  |
| Total | $ | 7,485 |  |  | $ | 7,472 |  |  | $ | 6,916 |  |  | $ | 6,895 |  |


## nvda:RevenueFromContractwithCustomerPolicyTextBlock

[0001045810-18-000150:notes:18]
[same as prior period, unchanged from 0001045810-18-000114:notes:18]

[0001045810-18-000150:notes:19]
[same as prior period, unchanged from 0001045810-18-000114:notes:19]

[0001045810-18-000150:notes:20]
[same as prior period, unchanged from 0001045810-18-000114:notes:20]

[0001045810-18-000150:notes:21]
[same as prior period, unchanged from 0001045810-18-000114:notes:21]

[0001045810-18-000150:notes:22]
[same as prior period, unchanged from 0001045810-18-000114:notes:22]

[0001045810-18-000150:notes:23]
[same as prior period, unchanged from 0001045810-18-000114:notes:23]

[0001045810-18-000150:notes:24]
[same as prior period, unchanged from 0001045810-18-000114:notes:24]

[0001045810-18-000150:notes:25]
[same as prior period, unchanged from 0001045810-18-000114:notes:25]

[0001045810-18-000150:notes:26]
[same as prior period, unchanged from 0001045810-18-000114:notes:26]

[0001045810-18-000150:notes:27]
Our software licenses provide our customers with a right to use the software when it is made available to the customer. Customers may purchase either perpetual licenses or subscriptions to licenses, which differ mainly in the duration over which the customer benefits from the software. Software licenses are frequently sold along with post-contract customer support, or PCS. For such arrangements, we allocate revenue to the software license and PCS on a relative standalone selling price basis by maximizing the use of observable inputs to determine the standalone selling price for each performance obligation. Revenue from software licenses is recognized up front when the software is made available to the customer. PCS revenue is recognized ratably over the service period, or as services are performed.


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-18-000150:notes:28]
[same as prior period, unchanged from 0001045810-18-000114:notes:28]

[0001045810-18-000150:notes:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,764 |  |  | $ | 1,561 |  |  | $ | 5,292 |  |  | $ | 3,774 |  |
| Professional Visualization | 305 |  |  | 239 |  |  | 837 |  |  | 679 |  |
| Datacenter | 792 |  |  | 501 |  |  | 2,253 |  |  | 1,326 |  |
| Automotive | 172 |  |  | 144 |  |  | 478 |  |  | 426 |  |
| OEM & IP | 148 |  |  | 191 |  |  | 651 |  |  | 598 |  |
| Total revenue | $ | 3,181 |  |  | $ | 2,636 |  |  | $ | 9,511 |  |  | $ | 6,803 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-18-000150:notes:30]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of October 28, 2018 and January 28, 2018:

[0001045810-18-000150:notes:31]
|  | October 28, |  | January 28, |
|  | 2018 |  | 2018 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 1,608 |  |  | $ | 1,091 |  |
| Estimated weighted average remaining amortization period | (In years) |
| RSUs, PSUs, and market-based PSUs | 2.4 |  |  | 2.3 |  |
| ESPP | 0.9 |  |  | 0.7 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001045810-18-000150:notes:32]
[same as prior period, unchanged from 0001045810-18-000114:notes:32]

[0001045810-18-000150:notes:33]
[same as prior period, unchanged from 0001045810-18-000114:notes:33]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-18-000150:notes:34]
Commitments and Contingencies

[0001045810-18-000150:notes:35]
Litigation

[0001045810-18-000150:notes:36]
Polaris Innovations Limited

[0001045810-18-000150:notes:37]
On May 16, 2016, Polaris Innovations Limited, or Polaris, a non-practicing entity and wholly-owned subsidiary of Quarterhill Inc. (formerly WiLAN Inc.), filed a complaint against NVIDIA for patent infringement in the United States District Court for the Western District of Texas. Polaris alleges that NVIDIA has infringed and is continuing to infringe six U.S. patents relating to the control of dynamic random-access memory, or DRAM. The complaint seeks unspecified monetary damages, enhanced damages, interest, fees, expenses, and costs against NVIDIA. On September 14, 2016, NVIDIA answered the Polaris Complaint and asserted various defenses including non-infringement and invalidity of the six Polaris patents.

[0001045810-18-000150:notes:38]
On December 5, 2016, the Texas Court granted NVIDIA’s motion to transfer and ordered the case transferred to the Northern District of California.

[0001045810-18-000150:notes:39]
Between December 7, 2016 and July 25, 2017, NVIDIA filed multiple petitions for inter partes review, or IPR, at the United States Patent and Trademark Office, or USPTO, challenging the validity of each of the patents asserted by Polaris in the U.S. litigation. The USPTO instituted IPRs for four U.S. patents and declined to institute IPRs on two U.S. patents. The USPTO issued a Final Written Decision on the IPR relating to one of the patents on June 19, 2018, finding claims 1-23 and 28 unpatentable but that claims 24-27 were not proved unpatentable.

[0001045810-18-000150:notes:40]
On June 15, 2017, the California Court granted NVIDIA’s motion to stay the district court litigation pending resolution of the petitions for IPR. The California Court has not set a trial date.

[0001045810-18-000150:notes:41]
On December 30, 2016, Polaris filed a complaint against NVIDIA for patent infringement in the Regional Court of Düsseldorf, Germany. Polaris alleges that NVIDIA has infringed and is continuing to infringe three patents relating to control of DRAM. On July 14, 2017, NVIDIA filed defenses to the infringement allegations including non-infringement with respect to each of the three asserted patents. On September 3, 2018, NVIDIA filed a rejoinder with additional noninfringement arguments.

[0001045810-18-000150:notes:42]
An oral hearing is scheduled for February 21, 2019.

[0001045810-18-000150:notes:43]
Between March 31, 2017 and June 12, 2017, NVIDIA filed nullity actions with the German Patent Court challenging the validity of each of the patents asserted by Polaris in the German litigation.

[0001045810-18-000150:notes:44]
ZiiLabs 1 Patents Lawsuit

[0001045810-18-000150:notes:45]
On October 2, 2017, ZiiLabs Inc., Ltd., or ZiiLabs, a non-practicing entity, filed a complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed and is continuing to infringe four U.S. patents relating to GPUs, or the ZiiLabs 1 Patents. ZiiLabs is a Bermuda corporation and a wholly-owned subsidiary of Creative Technology Asia Limited, a Hong Kong company which is itself is a wholly-owned subsidiary of Creative Technology Ltd., a publicly traded Singapore company. The complaint seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 1 Patents. On November 27, 2017, NVIDIA answered the ZiiLabs complaint and asserted various defenses including non-infringement and invalidity of the ZiiLabs 1 Patents.

[0001045810-18-000150:notes:46]
On January 10, 2018, ZiiLabs filed a first amended complaint asserting infringement of a fifth U.S. patent.

[0001045810-18-000150:notes:47]
On February 22, 2018, the Delaware Court stayed the ZiiLabs 1 case pending the resolution of the ITC investigation over the ZiiLabs 2 patents.

[0001045810-18-000150:notes:48]
ZiiLabs 2 Patents Lawsuits

[0001045810-18-000150:notes:49]
On December 27, 2017, ZiiLabs filed a second complaint in the United States District Court for the District of Delaware alleging that NVIDIA has infringed four additional U.S. patents, or the ZiiLabs 2 Patents. The second complaint also seeks unspecified monetary damages, enhanced damages, interest, costs, and fees against NVIDIA and an injunction against further direct or direct infringement of the ZiiLabs 2 Patents.

[0001045810-18-000150:notes:50]
On February 22, 2018, the Delaware Court stayed the district court action on the ZiiLabs 2 patents pending the resolution of the ITC Investigation over the ZiiLabs 2 patents.

[0001045810-18-000150:notes:51]
On December 29, 2017, ZiiLabs filed a request with the U.S. International Trade Commission, or USITC, to commence an Investigation pursuant to Section 337 of the Tariff Act of 1930 relating to the unlawful importation of certain graphics processors and products containing the same. ZiiLabs alleges that the unlawful importation results from the infringement of the ZiiLabs 2 Patents by products from respondents NVIDIA, ASUSTeK Computer Inc., ASUS Computer International, EVGA Corporation, Gigabyte Technology Co., Ltd., G.B.T. Inc., Micro-Star International Co., Ltd., MSI Computer Corp., Nintendo Co., Ltd., Nintendo of America Inc., PNY Technologies Inc., Zotac International (MCO) Ltd., and Zotac USA Inc.

[0001045810-18-000150:notes:52]
On February 28, 2018, NVIDIA and the other respondents answered the ITC complaint and asserted various defenses including non-infringement and invalidity of the four asserted ZiiLabs 2 patents.

[0001045810-18-000150:notes:53]
On May 10, 2018, the Administrative Law Judge presiding over the investigation issued an Initial Determination terminating the investigation with respect to one of the patents.  On July 17, 2018, the USITC affirmed this decision on modified grounds.

[0001045810-18-000150:notes:54]
On October 18, 2018, the Administrative Law Judge currently presiding over the investigation issued an order construing certain claims of the three remaining patents in the investigation.

[0001045810-18-000150:notes:55]
The hearing in the investigation is currently scheduled to begin January 25, 2019.  The target date for completion of the investigation is September 9, 2019.

[0001045810-18-000150:notes:56]
Accounting for Loss Contingencies

[0001045810-18-000150:notes:57]
While there can be no assurance of favorable outcomes, we believe the claims made by the other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of October 28, 2018, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-18-000150:notes:58]
[same as prior period, unchanged from 0001045810-18-000114:notes:56]

[0001045810-18-000150:notes:59]
[same as prior period, unchanged from 0001045810-18-000114:notes:57]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001045810-18-000150:notes:60]
The following table shows the changes in deferred revenue during the first nine months of fiscal year 2019:

[0001045810-18-000150:notes:61]
|  | October 28, |
|  | 2018 |
|  | (In millions) |
| Balance as of January 28, 2018 | $ | 68 |  |
| Adjustment to retained earnings upon adoption of new revenue standard | (5 | ) |
| Balance as of January 29, 2018 | 63 |  |
| Deferred revenue added during the period | 271 |  |
| Revenue recognized during the period | (214 | ) |
| Balance as of October 28, 2018 | $ | 120 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-18-000150:notes:62]
Debt

[0001045810-18-000150:notes:63]
Long-Term Debt

[0001045810-18-000150:notes:64]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-18-000150:notes:65]
In fiscal year 2017, we issued $1.00 billion of the 2.20% Notes Due 2021, and $1.00 billion of the 3.20% Notes Due 2026, or collectively, the Notes. Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the Notes Due 2021 on or after August 16, 2021, or for redemptions of the Notes Due 2026 on or after June 16, 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discount and issuance costs.

[0001045810-18-000150:notes:66]
The Notes are our unsecured senior obligations and rank equally in right of payment with all existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-18-000150:notes:67]
The carrying value of the Notes and the associated interest rates were as follows:

[0001045810-18-000150:notes:68]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 28, 2018 |  | January 28, 2018 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 2.9 |  | 2.38% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 7.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (13 | ) |  | (15 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,987 |  |  | $ | 1,985 |  |

[0001045810-18-000150:notes:69]
Convertible Debt

[0001045810-18-000150:notes:70]
1.00% Convertible Senior Notes Due 2018

[0001045810-18-000150:notes:71]
In fiscal year 2014, we issued $1.50 billion of 1.00% Convertible Senior Notes due 2018. The Convertible Notes will mature on December 1, 2018 and we had $3 million in principal amount outstanding as of October 28, 2018. Effective August 1, 2018, holders may convert all or any portion of their Convertible Notes before the close of business on the second scheduled trading day immediately preceding the maturity date of December 1, 2018 regardless of conversion conditions.

[0001045810-18-000150:notes:72]
During the third quarter of fiscal year 2019, we paid cash to settle an aggregate of $11 million in principal amount of the Convertible Notes and issued 485 thousand shares of our common stock for the excess conversion value. The related loss on early conversions was not significant. Based on the closing price of our common stock of $198.29 on the last trading day of the third quarter of fiscal year 2019, the if-converted value of the remaining outstanding Convertible Notes exceeded their principal amount by approximately $31 million. As of October 28, 2018, the conversion rate was 49.95 shares of common stock per $1,000 principal amount of the Convertible Notes.

[0001045810-18-000150:notes:73]
Note Hedges

[0001045810-18-000150:notes:74]
Concurrently with the issuance of the Convertible Notes, we entered into the Note Hedges. The Note Hedges have an adjusted strike price of $20.02 per share and allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through October 28, 2018, we had received 56 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of $1.50 billion in principal amount of the Convertible Notes.

[0001045810-18-000150:notes:75]
Revolving Credit Facility

[0001045810-18-000150:notes:76]
We have a Credit Agreement under which we may borrow up to $575 million for general corporate purposes and can obtain revolving loan commitments up to $425 million. As of October 28, 2018, we had not borrowed any amounts under this agreement.

[0001045810-18-000150:notes:77]
Commercial Paper

[0001045810-18-000150:notes:78]
We have a $575 million commercial paper program to support general corporate purposes. As of October 28, 2018, we had not issued any commercial paper.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-18-000150:notes:79]
[same as prior period, unchanged from 0001045810-18-000114:notes:77]

[0001045810-18-000150:notes:80]
We enter into foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts was not significant as of October 28, 2018 and January 28, 2018.

[0001045810-18-000150:notes:81]
[same as prior period, unchanged from 0001045810-18-000114:notes:79]

[0001045810-18-000150:notes:82]
The table below presents the notional value of our foreign currency forward contracts outstanding as of October 28, 2018 and January 28, 2018:

[0001045810-18-000150:notes:83]
|  | October 28, 2018 |  | January 28, 2018 |
|  | (In millions) |
| Designated as cash flow hedges | $ | 403 |  |  | $ | 104 |  |
| Not designated for hedge accounting | $ | 93 |  |  | $ | 94 |  |

[0001045810-18-000150:notes:84]
As of October 28, 2018, all designated foreign currency forward contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income (loss) related to foreign currency forward contracts within the next twelve months was not significant.

[0001045810-18-000150:notes:85]
During the third quarter and first nine months of fiscal years 2019 and 2018, the impact of derivative financial instruments designated for hedge accounting treatment on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective. Therefore, there were no gains or losses associated with ineffectiveness.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-18-000150:notes:86]
[same as prior period, unchanged from 0001045810-18-000114:notes:84]

[0001045810-18-000150:notes:87]
[same as prior period, unchanged from 0001045810-18-000114:notes:85]

[0001045810-18-000150:notes:88]
[same as prior period, unchanged from 0001045810-18-000114:notes:86]

[0001045810-18-000150:notes:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2018 |  | October 29, 2017 |  | October 28, 2018 |  | October 29, 2017 |
|  | (In millions) |
| Cost of revenue | $ | 5 |  |  | $ | 6 |  |  | $ | 21 |  |  | $ | 14 |  |
| Research and development | 88 |  |  | 61 |  |  | 237 |  |  | 146 |  |
| Sales, general and administrative | 47 |  |  | 40 |  |  | 142 |  |  | 105 |  |
| Total | $ | 140 |  |  | $ | 107 |  |  | $ | 400 |  |  | $ | 265 |  |

[0001045810-18-000150:notes:90]
[same as prior period, unchanged from 0001045810-18-000114:notes:88]

[0001045810-18-000150:notes:91]
[same as prior period, unchanged from 0001045810-18-000114:notes:89]

[0001045810-18-000150:notes:92]
|  | RSUs, PSUs, and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balances, January 28, 2018 | 22 |  |  | $ | 66.72 |  |
| Granted (1) (2) | 4 |  |  | $ | 262.44 |  |
| Vested restricted stock | (10 | ) |  | $ | 47.61 |  |
| Canceled and forfeited | — |  |  | $ | — |  |
| Balances, October 28, 2018 | 16 |  |  | $ | 127.89 |  |

[0001045810-18-000150:notes:93]
[same as prior period, unchanged from 0001045810-18-000114:notes:91]

[0001045810-18-000150:notes:94]
[same as prior period, unchanged from 0001045810-18-000114:notes:92]

[0001045810-18-000150:notes:95]
Of the total fair value of equity awards granted during the third quarter and first nine months of fiscal year 2019, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $73 million and $89 million, respectively. Of the total fair value of equity awards granted during the third quarter and first nine months of fiscal year 2018, we estimated that the stock-based compensation expense related to equity awards that are not expected to vest was $105 million and $144 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001045810-18-000150:notes:96]
[same as prior period, unchanged from 0001045810-18-000114:notes:94]

[0001045810-18-000150:notes:97]
[same as prior period, unchanged from 0001045810-18-000114:notes:95]

[0001045810-18-000150:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 1,230 |  |  | $ | 838 |  |  | $ | 3,575 |  |  | $ | 1,928 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 609 |  |  | 603 |  |  | 608 |  |  | 597 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards | 16 |  |  | 23 |  |  | 18 |  |  | 24 |  |
| 1.00% Convertible Senior Notes | — |  |  | 2 |  |  | — |  |  | 7 |  |
| Warrants issued with the 1.00% ConvertibleSenior Notes | — |  |  | — |  |  | — |  |  | 5 |  |
| Diluted weighted average shares | 625 |  |  | 628 |  |  | 626 |  |  | 633 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 2.02 |  |  | $ | 1.39 |  |  | $ | 5.88 |  |  | $ | 3.23 |  |
| Diluted (2) | $ | 1.97 |  |  | $ | 1.33 |  |  | $ | 5.71 |  |  | $ | 3.05 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 3 |  |  | 3 |  |  | 4 |  |  | 4 |  |

[0001045810-18-000150:notes:99]
[same as prior period, unchanged from 0001045810-18-000114:notes:97]

[0001045810-18-000150:notes:100]
[same as prior period, unchanged from 0001045810-18-000114:notes:98]

[0001045810-18-000150:notes:101]
The 1.00% Convertible Senior Notes Due 2018, or the Convertible Notes, were included in the calculation of diluted net income per share. The Convertible Notes had a dilutive impact on net income per share as our average stock price for the reporting period exceeded the adjusted conversion price of $20.02 per share. The warrants associated with our Convertible Notes, or the Warrants, outstanding were also included in the calculation of diluted net income per share. As of October 28, 2018, there were no warrants outstanding.

[0001045810-18-000150:notes:102]
Refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Convertible Notes.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-18-000150:notes:103]
|  |  | Fair Value at |
|  | Pricing Category |  | October 28, 2018 |  | January 28, 2018 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |
| Corporate debt securities | Level 2 |  | $ | 2,727 |  |  | $ | 1,295 |  |
| Debt securities of United States government agencies | Level 2 |  | $ | 2,135 |  |  | $ | 815 |  |
| Debt securities issued by the United States Treasury | Level 2 |  | $ | 1,542 |  |  | $ | 573 |  |
| Money market funds | Level 1 |  | $ | 602 |  |  | $ | 3,789 |  |
| Foreign government bonds | Level 2 |  | $ | 191 |  |  | $ | 41 |  |
| Asset-backed securities | Level 2 |  | $ | 176 |  |  | $ | 252 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | Level 2 |  | $ | 99 |  |  | $ | 130 |  |
| Liabilities |  |  |  |  |  |
| Current liability: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (1) | Level 2 |  | $ | 43 |  |  | $ | 189 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (1) | Level 2 |  | $ | 971 |  |  | $ | 982 |  |
| 3.20% Notes Due 2026 (1) | Level 2 |  | $ | 943 |  |  | $ | 986 |  |

[0001045810-18-000150:notes:104]
[same as prior period, unchanged from 0001045810-18-000114:notes:102]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-18-000150:notes:105]
[same as prior period, unchanged from 0001045810-18-000114:notes:103]

[0001045810-18-000150:notes:106]
The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 financial assets and liabilities for the third quarter of fiscal year 2019. Level 3 financial assets and liabilities are based on unobservable inputs to the valuation methodology and include our own data about assumptions market participants would use in pricing the asset or liability based on the best information available under the circumstances.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-18-000150:notes:107]
[same as prior period, unchanged from 0001045810-18-000114:notes:105]

[0001045810-18-000150:notes:108]
We recognized an income tax benefit of $149 million and $3 million for the third quarter and first nine months of fiscal year 2019, respectively, and income tax expense of $58 million and $189 million for the third quarter and first nine months of fiscal year 2018, respectively. Income tax benefit as a percentage of income before income tax was 13.8% and nominal for the third quarter and first nine months of fiscal year 2019, respectively, and income tax expense as a percentage of income before tax was 6.5% and 8.9% for the third quarter and first nine months of fiscal year 2018, respectively.

[0001045810-18-000150:notes:109]
The decrease in our effective tax rate for the third quarter and first nine months of fiscal year 2019 as compared to the same periods in the prior fiscal year was primarily due to a decrease in the U.S. statutory tax rate from 35% to 21% as a result of U.S. tax reform, and a $138 million reduction in our provisional U.S. tax reform transition tax amount in the third quarter of fiscal year 2019, partially offset by a decrease in the impact of tax benefits from stock-based compensation.

[0001045810-18-000150:notes:110]
Our effective tax rates for the first nine months of fiscal years 2019 and 2018 were nominal and 8.9%, respectively, and were lower than the U.S. federal statutory rates of 21% and 33.9%, for fiscal years 2019 and 2018, respectively, due to income earned in jurisdictions that are subject to taxes lower than the U.S. federal statutory tax rate, tax benefits related to stock-based compensation, the benefit of the U.S. federal research tax credit, and for fiscal year 2019, the reduction in our provisional U.S. tax reform transition tax amount.

[0001045810-18-000150:notes:111]
In December 2017, the SEC issued guidance that allows companies to record provisional amounts for the tax effects of the Tax Cuts and Job Acts, or TCJA, during a measurement period not to exceed one year. The TCJA was effective in the fourth quarter of fiscal year 2018 and we have recorded provisional amounts based on reasonable estimates for those tax effects. For the third quarter of fiscal year 2019, we reduced our provisional transition tax amount based on proposed regulations issued on August 1, 2018. We expect to complete our analysis of these provisional amounts in our fourth quarter of fiscal year 2019 based on further guidance on accounting interpretations from the FASB and application of the law from the U.S. Department of Treasury, which may further impact our provisional estimates.

[0001045810-18-000150:notes:112]
The TCJA subjects a U.S. corporation to tax on its global intangible low-taxed income, or GILTI. Under U.S. GAAP, we can make an accounting policy election to either treat taxes due on the GILTI as a current period expense or factor such amounts into our measurement of deferred taxes. Given the complexity of the GILTI provisions, we are still evaluating its effects and have not yet determined our accounting policy. We expect to complete our analysis in the fourth quarter of fiscal year 2019. For the third quarter of fiscal year 2019, as we are still evaluating the effects of the GILTI provisions, we have included tax expense related to GILTI for current-year operations in our estimated annual effective tax rate and have not provided for GILTI on deferred items.

[0001045810-18-000150:notes:113]
For the first nine months of fiscal year 2019, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 28, 2018, other than the aforementioned reduction in our provisional U.S. tax reform transition tax amount.

[0001045810-18-000150:notes:114]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 28, 2018, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-18-000150:notes:115]
[same as prior period, unchanged from 0001045810-18-000114:notes:114]

[0001045810-18-000150:notes:116]
[same as prior period, unchanged from 0001045810-18-000114:notes:115]

[0001045810-18-000150:notes:117]
|  | October 28, 2018 |  | January 28, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |  | (In millions) |
| Acquisition-related intangible assets | $ | 195 |  |  | $ | (186 | ) |  | $ | 9 |  |  | $ | 195 |  |  | $ | (180 | ) |  | $ | 15 |  |
| Patents and licensed technology | 490 |  |  | (450 | ) |  | 40 |  |  | 469 |  |  | (432 | ) |  | 37 |  |
| Total intangible assets | $ | 685 |  |  | $ | (636 | ) |  | $ | 49 |  |  | $ | 664 |  |  | $ | (612 | ) |  | $ | 52 |  |

[0001045810-18-000150:notes:118]
The increase in gross carrying amount of intangible assets is due to purchases of licensed technology during the first nine months of fiscal year 2019. Amortization expense associated with intangible assets was $7 million and $24 million for the third quarter and first nine months of fiscal year 2019, respectively, and $13 million and $42 million for the third quarter and first nine months of fiscal year 2018, respectively. Future amortization expense related to the net carrying amount of intangible assets as of October 28, 2018 is estimated to be $6 million for the remainder of fiscal year 2019, $21 million in fiscal year 2020, $12 million in fiscal year 2021, $5 million in fiscal year 2022, $4 million in fiscal year 2023, and $1 million in fiscal year 2024.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-18-000150:notes:119]
Marketable Securities

[0001045810-18-000150:notes:120]
Our cash equivalents and marketable securities are classified as “available-for-sale” debt securities.

[0001045810-18-000150:notes:121]
The gross unrealized losses are related to fixed income securities, temporary in nature, and driven primarily by changes in interest rates. We have the intent and ability to hold our investments until maturity. For the third quarter and first nine months of fiscal years 2019 and 2018, there were no other-than-temporary impairment losses and net realized gains were not significant.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-18-000150:notes:122]
New Revenue Accounting Standard

[0001045810-18-000150:notes:123]
Method and Impact of Adoption

[0001045810-18-000150:notes:124]
On January 29, 2018, we adopted the new revenue accounting standard using the modified retrospective method and applied it to contracts that were not completed as of that date. Upon adoption, we recognized the cumulative effect of the new standard as a $7 million increase to opening retained earnings, net of tax. Comparative information for prior periods has not been adjusted. The impact of the new standard on our consolidated financial statements for the third quarter and first nine months of fiscal year 2019 was not significant.

[0001045810-18-000150:notes:125]
Deferred Revenue and Performance Obligations

[0001045810-18-000150:notes:126]
Deferred revenue is comprised mainly of customer advances and deferrals related to license and development arrangements and PCS related to software licensing. The following table shows the changes in deferred revenue during the first nine months of fiscal year 2019:

[0001045810-18-000150:notes:127]
Revenue related to remaining performance obligations represents the amount of contracted license and development arrangements and PCS that has not been recognized. As of October 28, 2018, the amount of our remaining performance obligations that has not been recognized as revenue was $237 million, of which we expect to recognize approximately 50% as revenue over the next twelve months and the remainder thereafter. This amount excludes the value of remaining performance obligations for contracts with an original expected length of one year or less.

[0001045810-18-000150:notes:128]
Refer to Note 15 of these Notes to Condensed Consolidated Financial Statements for additional information, including disaggregated revenue disclosures.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-18-000150:notes:129]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-18-000150:notes:130]
Recently Adopted Accounting Pronouncements

[0001045810-18-000150:notes:131]
The Financial Accounting Standards Board, or FASB, issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. We adopted this guidance on January 29, 2018 using the modified retrospective approach. Refer to Note 2 of these Notes to Condensed Consolidated Financial Statements for additional information.

[0001045810-18-000150:notes:132]
In January 2016, the FASB issued an accounting standards update to amend certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We are now required to recognize changes in the fair value of our equity investments through net income rather than other comprehensive income. We adopted this guidance in the first quarter of fiscal year 2019 and applied it prospectively. The adoption of this guidance did not have a significant impact on our consolidated financial statements.

[0001045810-18-000150:notes:133]
Recent Accounting Pronouncement Not Yet Adopted

[0001045810-18-000150:notes:134]
In February 2016 and July 2018, the FASB issued accounting standards updates regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for lease terms of more than 12 months. The FASB also recently provided a practical expedient transition method to adopt the new lease accounting requirements. We are evaluating the impact of adopting the new lease accounting standards on our consolidated financial statements, systems and processes in conjunction with our review of lease agreements. The updates will be effective for us beginning in the first quarter of fiscal year 2020. We expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheets.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-18-000150:notes:135]
[same as prior period, unchanged from 0001045810-18-000114:notes:134]

[0001045810-18-000150:notes:136]
[same as prior period, unchanged from 0001045810-18-000114:notes:135]

[0001045810-18-000150:notes:137]
[same as prior period, unchanged from 0001045810-18-000114:notes:136]

[0001045810-18-000150:notes:138]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product returns and estimated product warranty liabilities was $18 million and $15 million as of October 28, 2018 and January 28, 2018, respectively.

[0001045810-18-000150:notes:139]
In connection with certain agreements that we have entered in the past, we have provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-18-000150:notes:140]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2018 |  | October 29, 2017 |  | October 28, 2018 |  | October 29, 2017 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Unallocated revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 43 |  |
| Stock-based compensation expense | (140 | ) |  | (107 | ) |  | (400 | ) |  | (265 | ) |
| Unallocated cost of revenue and operating expenses | (76 | ) |  | (61 | ) |  | (205 | ) |  | (176 | ) |
| Legal settlement costs | (15 | ) |  | — |  |  | (17 | ) |  | — |  |
| Acquisition-related costs | (1 | ) |  | (3 | ) |  | (5 | ) |  | (11 | ) |
| Restructuring and other | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Contributions | — |  |  | — |  |  | — |  |  | (2 | ) |
| Total | $ | (228 | ) |  | $ | (171 | ) |  | $ | (623 | ) |  | $ | (411 | ) |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-18-000150:notes:141]
[same as prior period, unchanged from 0001045810-18-000114:notes:140]

[0001045810-18-000150:notes:142]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, |  | October 29, |  | October 28, |  | October 29, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 929 |  |  | $ | 864 |  |  | $ | 2,739 |  |  | $ | 2,140 |  |
| Other Asia Pacific | 742 |  |  | 612 |  |  | 2,001 |  |  | 1,409 |  |
| China (including Hong Kong) | 704 |  |  | 515 |  |  | 2,218 |  |  | 1,325 |  |
| United States | 407 |  |  | 263 |  |  | 1,254 |  |  | 894 |  |
| Europe | 230 |  |  | 195 |  |  | 699 |  |  | 555 |  |
| Other Americas | 169 |  |  | 187 |  |  | 600 |  |  | 480 |  |
| Total revenue | $ | 3,181 |  |  | $ | 2,636 |  |  | $ | 9,511 |  |  | $ | 6,803 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-18-000150:notes:143]
[same as prior period, unchanged from 0001045810-18-000114:notes:142]

[0001045810-18-000150:notes:144]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 28, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 2,774 |  |  | $ | 407 |  |  | $ | — |  |  | $ | 3,181 |  |
| Depreciation and amortization expense | $ | 51 |  |  | $ | 13 |  |  | $ | 4 |  |  | $ | 68 |  |
| Operating income (loss) | $ | 1,214 |  |  | $ | 72 |  |  | $ | (228 | ) |  | $ | 1,058 |  |
| Three Months Ended October 29, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,217 |  |  | $ | 419 |  |  | $ | — |  |  | $ | 2,636 |  |
| Depreciation and amortization expense | $ | 32 |  |  | $ | 9 |  |  | $ | 9 |  |  | $ | 50 |  |
| Operating income (loss) | $ | 978 |  |  | $ | 88 |  |  | $ | (171 | ) |  | $ | 895 |  |
| Nine Months Ended October 28, 2018 |  |  |  |  |  |  |  |
| Revenue | $ | 8,195 |  |  | $ | 1,316 |  |  | $ | — |  |  | $ | 9,511 |  |
| Depreciation and amortization expense | $ | 134 |  |  | $ | 35 |  |  | $ | 15 |  |  | $ | 184 |  |
| Operating income (loss) | $ | 3,867 |  |  | $ | 266 |  |  | $ | (623 | ) |  | $ | 3,510 |  |
| Nine Months Ended October 29, 2017 |  |  |  |  |  |  |  |
| Revenue | $ | 5,676 |  |  | $ | 1,084 |  |  | $ | 43 |  |  | $ | 6,803 |  |
| Depreciation and amortization expense | $ | 88 |  |  | $ | 27 |  |  | $ | 30 |  |  | $ | 145 |  |
| Operating income (loss) | $ | 2,342 |  |  | $ | 206 |  |  | $ | (411 | ) |  | $ | 2,137 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-18-000150:notes:145]
[same as prior period, unchanged from 0001045810-18-000114:notes:144]

[0001045810-18-000150:notes:146]
[same as prior period, unchanged from 0001045810-18-000114:notes:145]

[0001045810-18-000150:notes:147]
[same as prior period, unchanged from 0001045810-18-000114:notes:146]

[0001045810-18-000150:notes:148]
[same as prior period, unchanged from 0001045810-18-000114:notes:147]

[0001045810-18-000150:notes:149]
[same as prior period, unchanged from 0001045810-18-000114:notes:148]

[0001045810-18-000150:notes:150]
[same as prior period, unchanged from 0001045810-18-000114:notes:149]

[0001045810-18-000150:notes:151]
Our CODM does not review any information regarding total assets on a reportable segment basis. Reportable segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-18-000150:notes:152]
[same as prior period, unchanged from 0001045810-18-000114:notes:151]

[0001045810-18-000150:notes:153]
No customer represented 10% or more of total revenue for the third quarter and first nine months of fiscal years 2019 and 2018.

[0001045810-18-000150:notes:154]
Accounts receivable from significant customers, those representing more than 10% of total accounts receivable, aggregated approximately 14% of our accounts receivable balance from one customer as of October 28, 2018, and approximately 28% of our accounts receivable balance from two customers as of January 28, 2018.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-18-000150:notes:155]
[same as prior period, unchanged from 0001045810-18-000114:notes:154]

[0001045810-18-000150:notes:156]
[same as prior period, unchanged from 0001045810-18-000114:notes:155]

[0001045810-18-000150:notes:157]
[same as prior period, unchanged from 0001045810-18-000114:notes:156]

[0001045810-18-000150:notes:158]
[same as prior period, unchanged from 0001045810-18-000114:notes:157]

[0001045810-18-000150:notes:159]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2019 and 2018 are both 52-week years. The third quarters of fiscal years 2019 and 2018 were both 13-week quarters.

[0001045810-18-000150:notes:160]
[same as prior period, unchanged from 0001045810-18-000114:notes:159]

[0001045810-18-000150:notes:161]
[same as prior period, unchanged from 0001045810-18-000114:notes:160]

[0001045810-18-000150:notes:162]
[same as prior period, unchanged from 0001045810-18-000114:notes:161]

[0001045810-18-000150:notes:163]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an ongoing basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-18-000150:notes:164]
[same as prior period, unchanged from 0001045810-18-000114:notes:163]

[0001045810-18-000150:notes:165]
[same as prior period, unchanged from 0001045810-18-000114:notes:164]

[0001045810-18-000150:notes:166]
[same as prior period, unchanged from 0001045810-18-000114:notes:165]

[0001045810-18-000150:notes:167]
During the third quarter and first nine months of fiscal year 2019, we repurchased a total of 1 million shares and 4 million shares, respectively, for $200 million and $855 million, respectively. During the third quarter and first nine months of fiscal year 2019, we also paid $91 million and $273 million, respectively, in cash dividends to our shareholders.

[0001045810-18-000150:notes:168]
In November 2018, we declared an increase in our quarterly cash dividend to $0.16 per share from $0.15 per share, to be paid with our next quarterly cash dividend on December 21, 2018, to all shareholders of record on November 30, 2018.

[0001045810-18-000150:notes:169]
Through October 28, 2018, we have repurchased an aggregate of 255 million shares under our share repurchase program for a total cost of $6.36 billion. All shares delivered from these repurchases have been placed into treasury stock. In November 2018, our board of directors authorized an additional $7.00 billion under our share repurchase program. As of November 5, 2018, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $7.94 billion through December 2022.

[0001045810-18-000150:notes:170]
[same as prior period, unchanged from 0001045810-18-000114:notes:168]

[0001045810-18-000150:notes:171]
As of October 28, 2018 and January 28, 2018, there were no shares of preferred stock outstanding.

[0001045810-18-000150:notes:172]
[same as prior period, unchanged from 0001045810-18-000114:notes:170]

[0001045810-18-000150:notes:173]
[same as prior period, unchanged from 0001045810-18-000114:notes:171]
