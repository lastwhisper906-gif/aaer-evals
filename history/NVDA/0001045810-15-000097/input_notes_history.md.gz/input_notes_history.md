# NVDA note change history — 0001045810-14-000188 → 0001045810-15-000097


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-20):
[0001045810-15-000097:note_history:1]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, or the Securities Exchange Act.
  (was, 2014-11-19, similarity 0.9671):
[0001045810-14-000188:note_history:1]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934.

- changed (2015-05-20):
[0001045810-15-000097:note_history:2]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.  On April 15, 2015, we filed an opposition to Plaintiffs’ petition.
  (was, 2014-11-19, similarity 0.9495):
[0001045810-14-000188:note_history:2]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014.  On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal.  On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal.  Plaintiffs’ request was denied on November 10, 2014. Plaintiffs have until February 9, 2015 to file a petition for writ of certiorari to the United States Supreme Court.

- changed (2015-05-20):
[0001045810-15-000097:note_history:3]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones,  tablets and smart TVs containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the patents at issue.  The hearing on NVIDIA’s patents in the ITC action is currently scheduled to begin on June 22, 2015.
  (was, 2014-11-19, similarity 0.8325):
[0001045810-14-000188:note_history:3]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing.  In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones and tablets containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures.  On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway.

- changed (2015-05-20):
[0001045810-15-000097:note_history:4]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action and NVIDIA did not oppose the motion. The court granted the motion to stay on October 23, 2014.
  (was, 2014-11-19, similarity 0.937):
[0001045810-14-000188:note_history:4]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement.  On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action. The court granted the motion to stay on October 23, 2014.

- added (2015-05-20):
[0001045810-15-000097:note_history:5]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, and then on April 10, 2015, Samsung filed amended, longer complaints, but which continued to assert the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement. On May 19, 2015, the court severed NVIDIA's counter-claims from the main action and set a trial date on those counter-claims for June 2016. On the same day, NVIDIA voluntarily dismissed its counter-claims from the case. Trial on Samsung’s claims is currently set to begin on January 11, 2016.

- added (2015-05-20):
[0001045810-15-000097:note_history:6]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents.  Samsung seeks to permanently bar several products purportedly relying on these allegedly infringed patents in the United States.  On December 23, 2014, the ITC initiated an investigation of Samsung’s claims. A hearing on Samsung’s patents is scheduled to begin on August 18, 2015.

- added (2015-05-20):
[0001045810-15-000097:note_history:7]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed three requests for inter partes review on three of Samsung’s asserted patents.  Samsung has filed three requests for inter partes review on three patents asserted by NVIDIA.  The United States Patent and Trademark Office has not yet decided whether to institute review as to any of the patents.

- changed (2015-05-20):
[0001045810-15-000097:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 26, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2014-11-19, similarity 0.9726):
[0001045810-14-000188:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. With the exception of the 3dfx case, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2015-05-20):
[0001045810-14-000188:note_history:9]
3dfx

- removed (2015-05-20):
[0001045810-14-000188:note_history:10]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx. The transaction closed on April 18, 2001. In October 2002, 3dfx filed for bankruptcy.

- removed (2015-05-20):
[0001045810-14-000188:note_history:11]
Following the bankruptcy, in March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us. The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which difference the Trustee estimated to exceed $50.0 million. The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.

- removed (2015-05-20):
[0001045810-14-000188:note_history:12]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process, and because the Trustee's case remains pending on appeal, we have not reversed the $30.6 million accrual - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx - that we recorded during the three months ended October 30, 2005.

- removed (2015-05-20):
[0001045810-14-000188:note_history:13]
In March 2007, a trial was held regarding certain valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.” This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending. On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment. That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008. The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.

- removed (2015-05-20):
[0001045810-14-000188:note_history:14]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. Oral argument on the appeal was held on October 8, 2014.  On November 6, 2014, the Ninth Circuit affirmed the District Court’s decision upholding the ruling of the Bankruptcy Court. The Trustee has until November 20, 2014 to seek a rehearing.

- removed (2015-05-20):
[0001045810-14-000188:note_history:15]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia. The complaint alleges that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA has not yet responded to the complaint.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-05-20):
[0001045810-15-000097:note_history:16]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

- removed (2015-05-20):
[0001045810-14-000188:note_history:17]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-05-20):
[0001045810-15-000097:note_history:18]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

- changed (2015-05-20):
[0001045810-15-000097:note_history:19]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 is a 52-week year. The first quarters of fiscal years 2016 and 2015 are both 13-week quarters.
  (was, 2014-11-19, similarity 0.9158):
[0001045810-14-000188:note_history:19]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The third quarters of fiscal years 2015 and 2014 are both 13-week quarters.

- added (2015-05-20):
[0001045810-15-000097:note_history:20]
In April 2015, the Financial Accounting Standards Board, or FASB, issued a new accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this standard update is not expected to have a material impact on our consolidated financial statements.

- added (2015-05-20):
[0001045810-15-000097:note_history:21]
In May 2014, the FASB issued a new accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On April 29, 2015, the FASB issued a proposed accounting standards update that would defer the effective date of this new revenue recognition standard by one year, but also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). Comments on the proposal are due by May 29, 2015. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.

- removed (2015-05-20):
[0001045810-14-000188:note_history:22]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014.

- removed (2015-05-20):
[0001045810-14-000188:note_history:23]
Reclassifications

- removed (2015-05-20):
[0001045810-14-000188:note_history:24]
Certain prior fiscal year balances have been reclassified to conform to the current fiscal year presentation.

- removed (2015-05-20):
[0001045810-14-000188:note_history:25]
In August 2014, the Financial Accounting Standards Board, or FASB, issued new guidance related to our responsibility to evaluate whether there is substantial doubt about our ability to continue ongoing business operations and to provide relevant footnote disclosures. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The adoption of this guidance is not expected to have a material impact on our financial statements.

- removed (2015-05-20):
[0001045810-14-000188:note_history:26]
In June 2014, the FASB issued new guidance related to stock-based compensation. The new guidance requires that a performance target that affects vesting, and that could be achieved after the requisite service period is rendered, be treated as a performance condition. The new guidance is effective for interim periods within and those fiscal years, beginning after December 15, 2015. We currently do not have awards with a performance target where the employee would be eligible to vest in the award regardless of whether the employee is rendering service on the date the performance target is achieved. Therefore, we believe, the adoption of this new accounting guidance will not have an impact on our consolidated financial statements.

- removed (2015-05-20):
[0001045810-14-000188:note_history:27]
In May 2014, the FASB issued a new accounting standard update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries. Under the new standard, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new guidance requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers, including significant judgments and estimates used. This new guidance is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period.  Early adoption is not permitted.  We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-20):
[0001045810-15-000097:note_history:28]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.
  (was, 2014-11-19, similarity 0.8769):
[0001045810-14-000188:note_history:28]
On December 2, 2013, we issued $1.50 billion of 1.00% convertible senior notes due 2018, or the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

- changed (2015-05-20):
[0001045810-15-000097:note_history:29]
As of April 26, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.
  (was, 2014-11-19, similarity 0.9865):
[0001045810-14-000188:note_history:29]
As of October 26, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

- changed (2015-05-20):
[0001045810-15-000097:note_history:30]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.
  (was, 2014-11-19, similarity 0.9987):
[0001045810-14-000188:note_history:30]
The initial debt component of the Notes was valued at $1,351.8 million based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $125.7 million and recorded as a debt discount. This amount, together with the $22.5 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $148.2 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

- changed (2015-05-20):
[0001045810-15-000097:note_history:31]
|  |  | April 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (109 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,391 |  |  | $ | 1,384 |  |
  (was, 2014-11-19, similarity 0.954):
[0001045810-14-000188:note_history:31]
|  |  | October 26, |  | January 26, |
|  |  | 2014 |  | 2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (122,741 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,377,259 |  |  | $ | 1,356,375 |  |

- changed (2015-05-20):
[0001045810-15-000097:note_history:32]
(1) As of April 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.6 years.
  (was, 2014-11-19, similarity 0.9519):
[0001045810-14-000188:note_history:32]
(1)   As of October 26, 2014, the unamortized debt discount will be amortized over a remaining period of 4.1 years.

- changed (2015-05-20):
[0001045810-15-000097:note_history:33]
|  |  | Three Months Ended |
|  |  | April 26, |  | April 27, |
|  |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |
  (was, 2014-11-19, similarity 0.6468):
[0001045810-14-000188:note_history:33]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 11,250 |  |  | $ | — |  |
| Amortization of debt discount |  | 7,010 |  |  | — |  |  | 20,884 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 146 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,809 |  |  | $ | — |  |  | $ | 32,280 |  |  | $ | — |  |

- removed (2015-05-20):
[0001045810-14-000188:note_history:34]
Holders may convert their notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter commencing after the fiscal quarter ended on  April 27, 2014 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their notes regardless of the foregoing conditions. Upon conversion, we will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

- removed (2015-05-20):
[0001045810-14-000188:note_history:35]
In accordance with ASC 470-20 Debt with Conversion and Other Options, all cash-settled convertible debt should be separated into debt and equity components at issuance and be assigned a fair value.   The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-20):
[0001045810-15-000097:note_history:36]
|  |  | April 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (109 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,391 |  |  | $ | 1,384 |  |
  (was, 2014-11-19, similarity 0.954):
[0001045810-14-000188:note_history:36]
|  |  | October 26, |  | January 26, |
|  |  | 2014 |  | 2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (122,741 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,377,259 |  |  | $ | 1,356,375 |  |

- changed (2015-05-20):
[0001045810-15-000097:note_history:37]
(1) As of April 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.6 years.
  (was, 2014-11-19, similarity 0.9519):
[0001045810-14-000188:note_history:37]
(1)   As of October 26, 2014, the unamortized debt discount will be amortized over a remaining period of 4.1 years.

- changed (2015-05-20):
[0001045810-15-000097:note_history:38]
|  |  | Three Months Ended |
|  |  | April 26, |  | April 27, |
|  |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |
  (was, 2014-11-19, similarity 0.6468):
[0001045810-14-000188:note_history:38]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 26, |  | October 27, |  | October 26, |  | October 27, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |  | $ | — |  |  | $ | 11,250 |  |  | $ | — |  |
| Amortization of debt discount |  | 7,010 |  |  | — |  |  | 20,884 |  |  | — |  |
| Amortization of debt issuance costs |  | 49 |  |  | — |  |  | 146 |  |  | — |  |
| Total interest expense related to Notes |  | $ | 10,809 |  |  | $ | — |  |  | $ | 32,280 |  |  | $ | — |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-05-20):
[0001045810-15-000097:note_history:39]
Subsequent Events

- added (2015-05-20):
[0001045810-15-000097:note_history:40]
On May 5, 2015, we announced our intent to wind-down our Icera modem operations and that we are open to a sale of the technology or operations. We estimate restructuring charges primarily during fiscal year 2016, in the range of $100 million to $125 million, consisting of severance and other employee termination benefits, tax expense items, and other costs associated with the wind-down, if we are unable to sell the Icera modem operations.

- added (2015-05-20):
[0001045810-15-000097:note_history:41]
On May 11, 2015, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we made an upfront payment of $400 million to purchase shares of our common stock and received an initial delivery of 14 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
