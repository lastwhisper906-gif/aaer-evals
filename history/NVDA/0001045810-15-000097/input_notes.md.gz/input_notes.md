# NVDA notes — 0001045810-15-000097


## nvda:Accountsreceivablefromsignificantcustomers10ormoreoftotalARTableTextBlock

[0001045810-15-000097:notes:1]
|  | April 26, 2015 |  | January 25, 2015 |
| Accounts Receivable: |  |  |  |
| Customer B | 22 | % |  | 20 | % |
| Customer C | 10 | % |  | 10 | % |


## nvda:BalanceSheetComponentsTextBlock

[0001045810-15-000097:notes:2]
[same as prior period, unchanged from 0001045810-14-000188:notes:141]

[0001045810-15-000097:notes:3]
[same as prior period, unchanged from 0001045810-14-000188:notes:142]

[0001045810-15-000097:notes:4]
|  | April 26, |  | January 25, |
|  | 2015 |  | 2015 |
| Inventories: | (In millions) |
| Raw materials | $ | 151 |  |  | $ | 157 |  |
| Work in-process | 73 |  |  | 92 |  |
| Finished goods | 214 |  |  | 234 |  |
| Total inventories | $ | 438 |  |  | $ | 483 |  |

[0001045810-15-000097:notes:5]
At April 26, 2015, we had outstanding inventory purchase obligations totaling $398 million.

[0001045810-15-000097:notes:6]
|  | April 26, |  | January 25, |
|  | 2015 |  | 2015 |
| Accrued and Other Current Liabilities: | (In millions) |
| Unearned revenue (1) | $ | 377 |  |  | $ | 296 |  |
| Customer related liabilities (2) | 127 |  |  | 143 |  |
| Accrued payroll and related expenses | 87 |  |  | 112 |  |
| Professional service fees | 26 |  |  | 17 |  |
| Warranty accrual (3) | 13 |  |  | 8 |  |
| Facilities related liabilities | 2 |  |  | 8 |  |
| Coupon interest on Notes | 6 |  |  | 3 |  |
| Taxes payable | 4 |  |  | 3 |  |
| Other | 19 |  |  | 13 |  |
| Total accrued and other current liabilities | $ | 661 |  |  | $ | 603 |  |

[0001045810-15-000097:notes:7]
| (1) | This primarily includes deferred revenue. |

[0001045810-15-000097:notes:8]
| (2) | This primarily includes accrued customer programs. Please refer to Note 1 of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, for discussion regarding the nature of accrued customer programs and their accounting treatment related to our revenue recognition policies and estimates. |

[0001045810-15-000097:notes:9]
| (3) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the warranty accrual. |

[0001045810-15-000097:notes:10]
|  | April 26, |  | January 25, |
|  | 2015 |  | 2015 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability | $ | 254 |  |  | $ | 232 |  |
| Income taxes payable | 121 |  |  | 121 |  |
| Deferred revenue | 42 |  |  | 108 |  |
| Asset retirement obligation | 7 |  |  | 7 |  |
| Other | 24 |  |  | 21 |  |
| Total other long-term liabilities | $ | 448 |  |  | $ | 489 |  |


## nvda:Revenuefromsignificantcustomers10ormoreoftotalrevenueTableTextBlock

[0001045810-15-000097:notes:11]
|  | Three Months Ended |
|  | April 26, |  | April 27, |
|  | 2015 |  | 2014 |
| Revenue: |  |  |  |
| Customer A | 10 | % |  | 10 | % |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-15-000097:notes:12]
|  | April 26, |  | January 25, |
|  | 2015 |  | 2015 |
|  | (In millions) |
| Aggregated unearned stock-based compensation expense | $331 |  | $291 |
| Estimated weighted average amortization period | (In years) |
| Stock options | 1.7 |  | 1.8 |
| RSUs, PSUs and market-based PSUs | 2.9 |  | 2.8 |
| ESPP | 0.7 |  | 0.5 |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-15-000097:notes:13]
|  | April 26, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,214 |  |  | $ | 4 |  |  | $ | (1 | ) |  | $ | 2,217 |  |
| Debt securities of United States government agencies | 968 |  |  | 1 |  |  | — |  |  | 969 |  |
| Asset-backed securities | 480 |  |  | — |  |  | — |  |  | 480 |  |
| Debt securities issued by United States Treasury | 415 |  |  | 1 |  |  | — |  |  | 416 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 260 |  |  | 4 |  |  | — |  |  | 264 |  |
| Foreign government bonds | 81 |  |  | — |  |  | — |  |  | 81 |  |
| Money market funds | 19 |  |  | — |  |  | — |  |  | 19 |  |
| Total | $ | 4,437 |  |  | $ | 10 |  |  | $ | (1 | ) |  | $ | 4,446 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 118 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 4,328 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,446 |  |

[0001045810-15-000097:notes:14]
|  | January 25, 2015 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,185 |  |  | $ | 2 |  |  | $ | (1 | ) |  | $ | 2,186 |  |
| Debt securities of United States government agencies | 750 |  |  | 1 |  |  | (1 | ) |  | 750 |  |
| Asset-backed securities | 453 |  |  | — |  |  | — |  |  | 453 |  |
| Debt securities issued by United States Treasury | 534 |  |  | 3 |  |  | — |  |  | 537 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 274 |  |  | 5 |  |  | (1 | ) |  | 278 |  |
| Foreign government bonds | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Money market funds | 132 |  |  | — |  |  | — |  |  | 132 |  |
| Total | $ | 4,413 |  |  | $ | 11 |  |  | $ | (3 | ) |  | $ | 4,421 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 295 |  |
| Marketable securities |  |  |  |  |  |  | 4,126 |  |
| Total |  |  |  |  |  |  | $ | 4,421 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-15-000097:notes:15]
Commitments and Contingencies

[0001045810-15-000097:notes:16]
Securities Cases

[0001045810-15-000097:notes:17]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, or the Securities Exchange Act.

[0001045810-15-000097:notes:18]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend. On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014. On October 2, 2014, the Ninth Circuit issued an order affirming the dismissal. On October 16, 2014, Plaintiffs requested a rehearing or en banc review of the Ninth Circuit’s opinion affirming the dismissal. Plaintiffs’ request was denied on November 10, 2014. On February 9, 2015, Plaintiffs filed a petition for writ of certiorari to the United States Supreme Court.  On April 15, 2015, we filed an opposition to Plaintiffs’ petition.

[0001045810-15-000097:notes:19]
Patent Infringement Cases

[0001045810-15-000097:notes:20]
On September 4, 2014, NVIDIA filed complaints against Qualcomm, Inc., or Qualcomm, and various Samsung entities with both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware for alleged infringement of seven patents relating to graphics processing. In the ITC action, NVIDIA seeks to block shipments of Samsung Galaxy mobile phones,  tablets and smart TVs containing Qualcomm’s Adreno, ARM’s Mali or Imagination’s PowerVR graphics architectures. On October 6, 2014, the ITC initiated an investigation of NVIDIA’s claim and the investigation is currently underway. On February 2 and 3, 2015, the court conducted a claim construction hearing on certain claim language from five of the patents at issue.  The hearing on NVIDIA’s patents in the ITC action is currently scheduled to begin on June 22, 2015.

[0001045810-15-000097:notes:21]
In the Delaware action, NVIDIA seeks unspecified damages for Samsung and Qualcomm’s alleged patent infringement. On October 22, 2014, Samsung and Qualcomm moved to stay the Delaware proceedings in light of the pending ITC action and NVIDIA did not oppose the motion. The court granted the motion to stay on October 23, 2014.

[0001045810-15-000097:notes:22]
On November 10, 2014, Samsung filed a complaint against NVIDIA and Velocity Micro, Inc., in the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed six patents and falsely advertised that the Tegra K1 processor is the world’s fastest mobile processor. On December 19, 2014, and then on April 10, 2015, Samsung filed amended, longer complaints, but which continued to assert the same claims against NVIDIA. Samsung seeks unspecified damages and an injunction prohibiting NVIDIA from any future violations. NVIDIA answered the second amended complaint on April 16, 2015, and asserted counter-claims against Samsung for infringing four of NVIDIA’s patents and for non-infringement and invalidity of the six patents asserted in Samsung’s second amended complaint. On April 24, 2015, Samsung moved to sever NVIDIA’s counter-claims for patent infringement. On May 19, 2015, the court severed NVIDIA's counter-claims from the main action and set a trial date on those counter-claims for June 2016. On the same day, NVIDIA voluntarily dismissed its counter-claims from the case. Trial on Samsung’s claims is currently set to begin on January 11, 2016.

[0001045810-15-000097:notes:23]
On November 23, 2014, Samsung filed a complaint against NVIDIA, among others, in the ITC claiming infringement of four United States patents.  Samsung seeks to permanently bar several products purportedly relying on these allegedly infringed patents in the United States.  On December 23, 2014, the ITC initiated an investigation of Samsung’s claims. A hearing on Samsung’s patents is scheduled to begin on August 18, 2015.

[0001045810-15-000097:notes:24]
NVIDIA and Samsung have also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office. NVIDIA has filed three requests for inter partes review on three of Samsung’s asserted patents.  Samsung has filed three requests for inter partes review on three patents asserted by NVIDIA.  The United States Patent and Trademark Office has not yet decided whether to institute review as to any of the patents.

[0001045810-15-000097:notes:25]
Accounting for Loss Contingencies

[0001045810-15-000097:notes:26]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. As of April 26, 2015, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-15-000097:notes:27]
[same as prior period, unchanged from 0001045810-14-000188:notes:23]

[0001045810-15-000097:notes:28]
[same as prior period, unchanged from 0001045810-14-000188:notes:24]


## us-gaap:DebtDisclosureTextBlock

[0001045810-15-000097:notes:29]
Long-Term Debt

[0001045810-15-000097:notes:30]
1.00 % Convertible Senior Notes Due 2018

[0001045810-15-000097:notes:31]
On December 2, 2013, we issued $1.50 billion in Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. Under the terms of the Notes, they may be converted based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-15-000097:notes:32]
As of April 26, 2015, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

[0001045810-15-000097:notes:33]
The initial debt component of the Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $149 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-15-000097:notes:34]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-15-000097:notes:35]
|  |  | April 26, |  | January 25, |
|  |  | 2015 |  | 2015 |
|  |  | (In millions) |
| Amount of the equity component |  | $ | 126 |  |  | $ | 126 |  |
| 1.00% Convertible Senior Notes Due 2018 |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) |  | (109 | ) |  | (116 | ) |
| Net carrying amount |  | $ | 1,391 |  |  | $ | 1,384 |  |

[0001045810-15-000097:notes:36]
(1) As of April 26, 2015, the unamortized debt discount will be amortized over a remaining period of 3.6 years.

[0001045810-15-000097:notes:37]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs:

[0001045810-15-000097:notes:38]
|  |  | Three Months Ended |
|  |  | April 26, |  | April 27, |
|  |  | 2015 |  | 2014 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 4 |  |  | $ | 4 |  |
| Amortization of debt discount and issuance costs |  | 7 |  |  | 7 |  |
| Total interest expense related to Notes |  | $ | 11 |  |  | $ | 11 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-15-000097:notes:39]
[same as prior period, unchanged from 0001045810-14-000188:notes:37]

[0001045810-15-000097:notes:40]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, performance stock units that are based on the Company’s corporate financial performance targets, or PSUs, performance stock units that are based on market conditions, or market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-15-000097:notes:41]
We estimate the fair value of employee stock options on the date of grant using a binomial model and recognize the expense using a straight-line attribution method over the requisite employee service period. We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of RSUs and PSUs, and we use a Monte Carlo simulation on the date of grant to estimate the fair value of market-based PSUs. We use a Black-Scholes valuation at the commencement of an offering period in March and September of each year to estimate the fair value of the shares to be issued under our ESPP.

[0001045810-15-000097:notes:42]
Stock-based compensation expense for stock options, RSUs and market-based PSUs is recognized using a straight-line attribution method over the requisite employee service period, while compensation expense for PSUs and ESPP is recognized using an accelerated amortization model.

[0001045810-15-000097:notes:43]
Our condensed consolidated statements of income include stock-based compensation expense, net of amounts capitalized as inventory, as follows:

[0001045810-15-000097:notes:44]
|  | Three Months Ended |
|  | April 26, 2015 |  | April 27, 2014 |
|  | (In millions) |
| Cost of revenue | $ | 2 |  |  | $ | 3 |  |
| Research and development | 27 |  |  | 21 |  |
| Sales, general and administrative | 16 |  |  | 12 |  |
| Total | $ | 45 |  |  | $ | 36 |  |

[0001045810-15-000097:notes:45]
[same as prior period, unchanged from 0001045810-14-000188:notes:42]

[0001045810-15-000097:notes:46]
The following summarizes the stock option, RSU, PSU and market-based PSU activity under our equity incentive plans:

[0001045810-15-000097:notes:47]
|  | Awards Outstanding |  | Weighted Average Exercise Price |
| Stock Options | (In millions) |  | (Per share) |
| Balances, January 25, 2015 | 21 |  |  | $14.61 |
| Granted | — |  |  | — |  |
| Exercised | (3 | ) |  | $13.87 |
| Cancelled | — |  |  | — |  |
| Balances, April 26, 2015 | 18 |  |  | $14.63 |

[0001045810-15-000097:notes:48]
|  | Awards Outstanding |  | Weighted Average Grant-Date Fair Value |
| RSUs, PSUs and Market-based PSUs | (In millions) |  | (Per share) |
| Balances, January 25, 2015 | 23 |  |  | $15.94 |
| Granted (1) (2) | 4 |  |  | $22.08 |
| Vested | (4 | ) |  | $14.99 |
| Cancelled | — |  |  | — |  |
| Balances, April 26, 2015 | 23 |  |  | $17.01 |

[0001045810-15-000097:notes:49]
| (1) | Includes the total PSUs issuable if the corporate financial performance maximum target level for fiscal year 2016 is achieved. Depending on the actual level of achievement of the corporate performance target at the end of fiscal year 2016, the PSUs issued could range from 0 to 2 million shares. We granted PSUs during the first quarter of fiscal year 2016 to our CEO and senior management as approved by our Compensation Committee. |

[0001045810-15-000097:notes:50]
| (2) | Includes the market-based PSUs issuable if the maximum target for total shareholder return, or TSR, over the 3-year measurement period is achieved. Depending on the ranking of our TSR compared to the respective TSRs of the companies comprising the Standard & Poor’s 500 Index during a 3-year measurement period, the market-based PSUs issued could range from 0 to 0.4 million shares. We granted market-based PSUs during the first quarter of fiscal year 2016 to our CEO and senior management as approved by our Compensation Committee. |

[0001045810-15-000097:notes:51]
Of the estimated total grant-date fair value, the stock-based compensation expense related to the equity awards that are not expected to vest was $5 million and $10 million for the three months ended April 26, 2015 and April 27, 2014, respectively.

[0001045810-15-000097:notes:52]
The following summarizes aggregated unearned stock-based compensation expense and estimated weighted average amortization period as of April 26, 2015 and January 25, 2015:


## us-gaap:EarningsPerShareTextBlock

[0001045810-15-000097:notes:53]
[same as prior period, unchanged from 0001045810-14-000188:notes:48]

[0001045810-15-000097:notes:54]
[same as prior period, unchanged from 0001045810-14-000188:notes:49]

[0001045810-15-000097:notes:55]
|  | Three Months Ended |
|  | April 26, |  | April 27, |
|  | 2015 |  | 2014 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |
| Net income | $ | 134 |  |  | $ | 137 |  |
| Denominator: |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 549 |  |  | 559 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Equity awards outstanding | 13 |  |  | 11 |  |
| Assumed conversion of 1% Convertible Senior Notes Due 2018 | 6 |  |  | — |  |
| Denominator for diluted net income per share, weighted average shares | 568 |  |  | 570 |  |
| Net income per share: |  |  |  |  |  |
| Basic net income per share | $ | 0.24 |  |  | $ | 0.24 |  |
| Diluted net income per share | $ | 0.24 |  |  | $ | 0.24 |  |
| Potentially dilutive securities excluded from diluted net income per share because their effect would have been anti-dilutive | 3 |  |  | 8 |  |

[0001045810-15-000097:notes:56]
The 1.00% Convertible Senior Notes, or the Notes, are included in the calculation of diluted net income per share if their inclusion is dilutive. The Notes will generally have a dilutive impact on net income per share if the Company's average stock price for the reporting period exceeds the conversion price of $20.16 per share.

[0001045810-15-000097:notes:57]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transaction, or the Note Hedges, that we entered into concurrently with the issuance of the Notes, as its effect would be anti-dilutive. In the event an actual conversion of any or all of the Notes occurs, the shares that would be delivered to us under the Note Hedges are designed to neutralize the dilutive effect of the shares that we would issue under the Notes.

[0001045810-15-000097:notes:58]
The denominator for diluted net income per share will not include any effect from the warrants, which we entered into concurrently with the issuance of the Notes, unless the Company's average stock price for the reporting period exceeds the strike price of $27.14 per share.

[0001045810-15-000097:notes:59]
Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Notes.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001045810-15-000097:notes:60]
|  |  |  | Fair Value Measurement as of April 26, 2015 Using |
|  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |
|  | April 26, 2015 |  | (Level 1) |  | (Level 2) |
|  | (In millions) |
| Corporate debt securities (1) | $ | 2,217 |  |  | $ | — |  |  | $ | 2,217 |  |
| Debt securities of United States government agencies (2) | 969 |  |  | — |  |  | 969 |  |
| Asset-backed securities (3) | 480 |  |  | — |  |  | 480 |  |
| Debt securities issued by United States Treasury (3) | 416 |  |  | — |  |  | 416 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (3) | 264 |  |  | — |  |  | 264 |  |
| Foreign government bonds (3) | 81 |  |  | — |  |  | 81 |  |
| Money market funds (4) | 19 |  |  | 19 |  |  | — |  |
| Total cash equivalents and marketable securities | $ | 4,446 |  |  | $ | 19 |  |  | $ | 4,427 |  |

[0001045810-15-000097:notes:61]
| (1) | Includes $95 million in cash equivalents and $2.12 billion in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000097:notes:62]
| (2) | Includes $4 million in cash equivalents and $965 million in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000097:notes:63]
| (3) | Included in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000097:notes:64]
| (4) | Included in cash equivalents on the Condensed Consolidated Balance Sheet |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-15-000097:notes:65]
[same as prior period, unchanged from 0001045810-14-000188:notes:57]

[0001045810-15-000097:notes:66]
[same as prior period, unchanged from 0001045810-14-000188:notes:58]

[0001045810-15-000097:notes:67]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets. Our available-for-sale securities are classified as having Level 2 inputs. Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian. We review the fair value hierarchy classification on a quarterly basis. Changes in the observability of valuation inputs may result in a reclassification of levels for certain securities within the fair value hierarchy.  There were no significant transfers between Levels 1 and 2 assets for the three months ended April 26, 2015.

[0001045810-15-000097:notes:68]
[same as prior period, unchanged from 0001045810-14-000188:notes:60]

[0001045810-15-000097:notes:69]
| (4) | Included in cash equivalents on the Condensed Consolidated Balance Sheets. |

[0001045810-15-000097:notes:70]
[same as prior period, unchanged from 0001045810-14-000188:notes:62]

[0001045810-15-000097:notes:71]
We issued $1.50 billion of Notes in December 2013. The Notes are carried at their original issuance value, net of unamortized debt discount, and are not marked to market each period. The estimated fair value of the Notes was $1.83 billion and $1.68 billion as of April 26, 2015 and January 25, 2015, respectively. The estimated fair value of the Notes was determined on the basis of market prices observable for similar instruments and is considered Level 2 in the fair value hierarchy. Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the Notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-15-000097:notes:72]
[same as prior period, unchanged from 0001045810-14-000188:notes:64]

[0001045810-15-000097:notes:73]
We recognized income tax expense of $38 million and $26 million for the three months ended April 26, 2015 and April 27, 2014, respectively.  Income tax expense as a percentage of income before taxes, or our effective tax rate, was 22.0% and 16.4% for the three months ended April 26, 2015 and April 27, 2014, respectively.

[0001045810-15-000097:notes:74]
The increase in our effective tax rate in the first quarter of fiscal year 2016 as compared to the same period in the prior fiscal year was primarily related to an increase in the amount of earnings subject to US tax and permanent tax differences related to stock-based compensation in the prior year's first three months.

[0001045810-15-000097:notes:75]
Our effective tax rate on income before tax for the first three months of fiscal year 2016 of 22.0% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate. Further, our effective tax rate for the first three months of fiscal year 2016 of 22.0% differs from our annual projected effective tax rate for the first three months of fiscal year 2016 of 24.0% due to discrete events that occurred in the first three months of fiscal year 2016 primarily attributable to the tax benefits recognized upon the expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-15-000097:notes:76]
Our effective tax rate on income before tax for the first three months of fiscal year 2015 of 16.4% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax.

[0001045810-15-000097:notes:77]
For the three months ended April 26, 2015, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 25, 2015, other than the recognition of tax benefits upon the expiration of statute of limitation in certain non-U.S. jurisdictions in the three months ended April 26, 2015.

[0001045810-15-000097:notes:78]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where it is believed not more-likely-than-not that the position will be sustained upon examination, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 26, 2015, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-15-000097:notes:79]
[same as prior period, unchanged from 0001045810-14-000188:notes:71]

[0001045810-15-000097:notes:80]
[same as prior period, unchanged from 0001045810-14-000188:notes:72]

[0001045810-15-000097:notes:81]
|  | April 26, 2015 |  | January 25, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | Accumulated Amortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 189 |  |  | $ | (139 | ) |  | $ | 50 |  |  | $ | 189 |  |  | $ | (134 | ) |  | $ | 55 |  |
| Patents and licensed technology | 451 |  |  | (296 | ) |  | 155 |  |  | 449 |  |  | (282 | ) |  | 167 |  |
| Total intangible assets | $ | 640 |  |  | $ | (435 | ) |  | $ | 205 |  |  | $ | 638 |  |  | $ | (416 | ) |  | $ | 222 |  |

[0001045810-15-000097:notes:82]
Amortization expense associated with intangible assets was $19 million for both the three months ended April 26, 2015 and April 27, 2014. Future amortization expense related to the net carrying amount of intangible assets at April 26, 2015 is estimated to be $53 million for the remainder of fiscal year 2016, $64 million in fiscal year 2017, $49 million in fiscal year 2018, $21 million in fiscal year 2019, $13 million in fiscal year 2020 and a total of $5 million in fiscal year 2021 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-15-000097:notes:83]
|  | April 26, 2015 |  | January 25, 2015 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 1,445 |  |  | $ | 1,445 |  |  | $ | 1,570 |  |  | $ | 1,571 |  |
| Due in 1 - 5 years | 2,866 |  |  | 2,872 |  |  | 2,720 |  |  | 2,726 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 126 |  |  | 129 |  |  | 123 |  |  | 124 |  |
| Total | $ | 4,437 |  |  | $ | 4,446 |  |  | $ | 4,413 |  |  | $ | 4,421 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-15-000097:notes:84]
[same as prior period, unchanged from 0001045810-14-000188:notes:77]

[0001045810-15-000097:notes:85]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value, with the related unrealized gains and losses included in accumulated other comprehensive income, a component of shareholders’ equity, net of tax, and net realized gains and losses recorded in other income, net, on the Condensed Consolidated Statements of Income.

[0001045810-15-000097:notes:86]
We performed an impairment review of our investment portfolio as of April 26, 2015. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio as of April 26, 2015.

[0001045810-15-000097:notes:87]
The following is a summary of cash equivalents and marketable securities at April 26, 2015 and January 25, 2015:

[0001045810-15-000097:notes:88]
The following table provides the breakdown of the investments with unrealized losses at April 26, 2015:

[0001045810-15-000097:notes:89]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 573 |  |  | $ | (1 | ) |  | $ | 13 |  |  | $ | — |  |  | $ | 586 |  |  | $ | (1 | ) |
| Debt securities of United States government agencies | 309 |  |  | — |  |  | 9 |  |  | — |  |  | 318 |  |  | — |  |
| Asset-backed securities | 257 |  |  | — |  |  | 3 |  |  | — |  |  | 260 |  |  | — |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 74 |  |  | — |  |  | 18 |  |  | — |  |  | 92 |  |  | — |  |
| Debt securities issued by United States Treasury | 58 |  |  | — |  |  | — |  |  | — |  |  | 58 |  |  | — |  |
| Foreign government bonds | 14 |  |  | — |  |  | — |  |  | — |  |  | 14 |  |  | — |  |
| Total | $ | 1,285 |  |  | $ | (1 | ) |  | $ | 43 |  |  | $ | — |  |  | $ | 1,328 |  |  | $ | (1 | ) |

[0001045810-15-000097:notes:90]
The gross unrealized losses related to fixed income securities were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at April 26, 2015 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-15-000097:notes:91]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale at April 26, 2015 and January 25, 2015 and are shown below by contractual maturity.

[0001045810-15-000097:notes:92]
Net realized gains for the three months ended April 26, 2015 were $3 million, and were not significant for the three months ended April 27, 2014.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001045810-15-000097:notes:93]
[same as prior period, unchanged from 0001045810-14-000188:notes:86]

[0001045810-15-000097:notes:94]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 25, 2015 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015.

[0001045810-15-000097:notes:95]
[same as prior period, unchanged from 0001045810-14-000188:notes:88]

[0001045810-15-000097:notes:96]
For a description of significant accounting policies, see Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 25, 2015. There have been no material changes to our significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-15-000097:notes:97]
[same as prior period, unchanged from 0001045810-14-000188:notes:92]

[0001045810-15-000097:notes:98]
[same as prior period, unchanged from 0001045810-14-000188:notes:93]

[0001045810-15-000097:notes:99]
[same as prior period, unchanged from 0001045810-14-000188:notes:94]

[0001045810-15-000097:notes:100]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product warranty liabilities for the three months ended April 26, 2015 and April 27, 2014 were as follows:

[0001045810-15-000097:notes:101]
|  | Three Months Ended |
|  | April 26, |  | April 27, |
|  | 2015 |  | 2014 |
|  | (In millions) |
| Balance at beginning of period | $ | 8 |  |  | $ | 7 |  |
| Additions | 6 |  |  | 2 |  |
| Deductions | (1 | ) |  | (1 | ) |
| Balance at end of period | $ | 13 |  |  | $ | 8 |  |

[0001045810-15-000097:notes:102]
In connection with certain agreements that we have executed in the past, we have at times provided indemnities to cover the indemnified party for matters such as tax, product, and employee liabilities. We have also on occasion included intellectual property indemnification provisions in our technology related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. As such, we have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-15-000097:notes:103]
|  | Three Months Ended |
|  | April 26, 2015 |  | April 27, 2014 |
|  | (In millions) |
| Reconciling items included in "All Other" category : |  |  |
| Unallocated revenue | $ | 66 |  |  | $ | 66 |  |
| Unallocated cost of revenue and operating expenses | (57 | ) |  | (43 | ) |
| Stock-based compensation | (45 | ) |  | (36 | ) |
| Acquisition-related costs | (9 | ) |  | (9 | ) |
| Total | $ | (45 | ) |  | $ | (22 | ) |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-15-000097:notes:104]
|  | Three Months Ended |
|  | April 26, |  | April 27, |
|  | 2015 |  | 2014 |
|  | (In millions) |
| Revenue: |  |  |  |
| Taiwan | $ | 388 |  |  | $ | 373 |  |
| Other Asia Pacific | 188 |  |  | 155 |  |
| United States | 180 |  |  | 173 |  |
| China | 173 |  |  | 223 |  |
| Europe | 119 |  |  | 87 |  |
| Other Americas | 103 |  |  | 92 |  |
| Total revenue | $ | 1,151 |  |  | $ | 1,103 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-15-000097:notes:105]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-15-000097:notes:106]
In April 2015, the Financial Accounting Standards Board, or FASB, issued a new accounting standards update that requires an entity to present debt issuance costs on the balance sheet as a direct deduction from the related debt liability as opposed to an asset. Amortization of the costs will continue to be reported as interest expense. The update is effective for annual reporting periods (including interim reporting periods within those periods) beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued, and the new guidance would be applied retrospectively to all prior periods presented. The update will be effective for us beginning in our first quarter of fiscal year 2017. The adoption of this standard update is not expected to have a material impact on our consolidated financial statements.

[0001045810-15-000097:notes:107]
In May 2014, the FASB issued a new accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. On April 29, 2015, the FASB issued a proposed accounting standards update that would defer the effective date of this new revenue recognition standard by one year, but also permit entities to adopt the standard one year earlier if they choose (i.e., the original effective date). Comments on the proposal are due by May 29, 2015. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-15-000097:notes:108]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended April 26, 2015 |  |  |  |  |  |  |  |
| Revenue | $ | 940 |  |  | $ | 145 |  |  | $ | 66 |  |  | $ | 1,151 |  |
| Depreciation and amortization expenses | $ | 28 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 54 |  |
| Operating income (loss) | $ | 278 |  |  | $ | (57 | ) |  | $ | (45 | ) |  | $ | 176 |  |
| Three Months Ended April 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 898 |  |  | $ | 139 |  |  | $ | 66 |  |  | $ | 1,103 |  |
| Depreciation and amortization expenses | $ | 30 |  |  | $ | 14 |  |  | $ | 11 |  |  | $ | 55 |  |
| Operating income (loss) | $ | 235 |  |  | $ | (62 | ) |  | $ | (22 | ) |  | $ | 151 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-15-000097:notes:109]
[same as prior period, unchanged from 0001045810-14-000188:notes:106]

[0001045810-15-000097:notes:110]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance.  Our operating segments are equivalent to our reportable segments.

[0001045810-15-000097:notes:111]
We report our business in two primary reporting segments - the GPU business and the Tegra Processor business - based on a single underlying graphics architecture.

[0001045810-15-000097:notes:112]
Our GPU product brands aimed at specialized markets include GeForce for gamers; Quadro for designers; Tesla for researchers, deep learning and big-data analysts; and GRID for cloud-based visual computing users.

[0001045810-15-000097:notes:113]
We also integrate our GPUs into mobile chips called system-on-a-chip (SOC) processors, which power tablets, and automotive infotainment and safety systems. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs with audio, video and input/output capabilities. They can also be integrated with baseband processors to add voice and data communication. Tegra conserves power while delivering state-of-the-art graphics and multimedia processing.

[0001045810-15-000097:notes:114]
We have a single unifying architecture for our GPU and Tegra Processors. This architecture unification leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reporting segments, our CODM assigns 100% of those expenses to the reporting segment that benefits the most. The revenue and cost of revenue of the reporting segments was not affected, and comparative periods presented below reflect the impact of this change.

[0001045810-15-000097:notes:115]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-15-000097:notes:116]
Our CODM does not review any information regarding total assets on a reporting segment basis. Reporting segments do not record intersegment revenue, and, accordingly, there is none to be reported. The accounting policies for segment reporting are the same as for NVIDIA as a whole. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-15-000097:notes:117]
[same as prior period, unchanged from 0001045810-14-000188:notes:113]

[0001045810-15-000097:notes:118]
Revenue from significant customers, those representing 10% or more of total revenue for the respective dates, is summarized as follows:

[0001045810-15-000097:notes:119]
Revenue from Customer A was attributable primarily to the GPU business for the three months ended April 26, 2015 and to both the GPU and Tegra Processor businesses for the three months ended April 27, 2014.

[0001045810-15-000097:notes:120]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable for the respective periods, is summarized as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-15-000097:notes:121]
[same as prior period, unchanged from 0001045810-14-000188:notes:119]

[0001045810-15-000097:notes:122]
[same as prior period, unchanged from 0001045810-14-000188:notes:120]

[0001045810-15-000097:notes:123]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2016 is a 53-week year and fiscal year 2015 is a 52-week year. The first quarters of fiscal years 2016 and 2015 are both 13-week quarters.

[0001045810-15-000097:notes:124]
[same as prior period, unchanged from 0001045810-14-000188:notes:124]

[0001045810-15-000097:notes:125]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-15-000097:notes:126]
Shareholders’ Equity

[0001045810-15-000097:notes:127]
Share Repurchase Program

[0001045810-15-000097:notes:128]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. Most recently, in May 2015, the Board extended the previously authorized repurchase program through December 2018 and authorized an additional $1.62 billion under the repurchase program.

[0001045810-15-000097:notes:129]
As part of our share repurchase program, we repurchased a total of 2.4 million shares of our common stock during the first three months of fiscal year 2016 for $53 million.

[0001045810-15-000097:notes:130]
Through April 26, 2015, we have repurchased an aggregate of 208 million shares under our share repurchase program for a total cost of $3.32 billion. All shares delivered from these repurchases have been placed into treasury stock. As of April 26, 2015, we were authorized, subject to certain specifications, to repurchase shares of our common stock up to $382 million. However, as noted above, in May 2015, the Board authorized an additional $1.62 billion under the repurchase program for an aggregate of $2.00 billion available for future repurchases.

[0001045810-15-000097:notes:131]
[same as prior period, unchanged from 0001045810-14-000188:notes:131]

[0001045810-15-000097:notes:132]
We paid $46 million in cash dividends to our common shareholders for each of the three months ended April 26, 2015 and April 27, 2014. These dividends were equivalent to $0.085 per share on a quarterly basis.

[0001045810-15-000097:notes:133]
[same as prior period, unchanged from 0001045810-14-000188:notes:133]

[0001045810-15-000097:notes:134]
[same as prior period, unchanged from 0001045810-14-000188:notes:134]

[0001045810-15-000097:notes:135]
[same as prior period, unchanged from 0001045810-14-000188:notes:135]

[0001045810-15-000097:notes:136]
We are authorized to issue up to 2.00 billion shares of our common stock at $0.001 per share par value.


## us-gaap:SubsequentEventsTextBlock

[0001045810-15-000097:notes:137]
Subsequent Events

[0001045810-15-000097:notes:138]
On May 5, 2015, we announced our intent to wind-down our Icera modem operations and that we are open to a sale of the technology or operations. We estimate restructuring charges primarily during fiscal year 2016, in the range of $100 million to $125 million, consisting of severance and other employee termination benefits, tax expense items, and other costs associated with the wind-down, if we are unable to sell the Icera modem operations.

[0001045810-15-000097:notes:139]
On May 11, 2015, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we made an upfront payment of $400 million to purchase shares of our common stock and received an initial delivery of 14 million shares. Upon final settlement of the ASR, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted earnings per share.
