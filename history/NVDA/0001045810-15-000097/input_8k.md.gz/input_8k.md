# NVDA 8-K — 0001045810-15-000087 filed 2015-05-07

## item codes, every 8-K on or before 2015-05-20

- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2015-05-20

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-15-000087:8k_2_02:1]
EX-99.1
2
q116pr.htm
Q1'16 PRESS RELEASE

[0001045810-15-000087:8k_2_02:2]
Q1'16 PR

[0001045810-15-000087:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-15-000087:8k_2_02:4]
NVIDIA Announces Financial Results for First Quarter Fiscal 2016

[0001045810-15-000087:8k_2_02:5]
| • | Revenue of $1.15 billion, up 4 percent from $1.10 billion a year earlier |

[0001045810-15-000087:8k_2_02:6]
| • | Record GAAP gross margin of 56.7 percent, up from 54.8 percent a year earlier |

[0001045810-15-000087:8k_2_02:7]
| • | Decision to wind down or sell Icera modem operations |

[0001045810-15-000087:8k_2_02:8]
| • | Company to return $800 million to shareholders in fiscal 2016, raises quarterly cash dividend 15 percent to $0.0975 per share |

[0001045810-15-000087:8k_2_02:9]
SANTA CLARA, Calif. - May 7, 2015 - NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 26, 2015, of $1.15 billion, up 4 percent from $1.10 billion a year earlier and down 8 percent from $1.25 billion the previous quarter.

[0001045810-15-000087:8k_2_02:10]
GAAP earnings per diluted share for the quarter were $0.24, unchanged from $0.24 a year earlier and down 31 percent from $0.35 in the previous quarter. Non-GAAP earnings per diluted share were $0.33, up 14 percent from $0.29 a year earlier and down 23 percent from $0.43 in the previous quarter.

[0001045810-15-000087:8k_2_02:11]
“The importance of visual computing is evident all around us,” said Jen-Hsun Huang, president and chief executive officer of NVIDIA. “Our expertise in this field enables us to take a leading position to advance  deep learning, virtual reality and self-driving cars.

[0001045810-15-000087:8k_2_02:12]
“Our singular focus on visual computing is aligned with some of the most exciting growth opportunities in computing today,” he said.

[0001045810-15-000087:8k_2_02:13]
IP Litigation

[0001045810-15-000087:8k_2_02:14]
The company is looking forward to its case against Samsung and Qualcomm, set to be heard in June at the U.S. International Trade Commission. Last month, NVIDIA received a favorable pretrial claim construction ruling in the case.

[0001045810-15-000087:8k_2_02:15]
Icera Modem Operations

[0001045810-15-000087:8k_2_02:16]
NVIDIA announced on May 5, 2015, that it will wind-down its Icera modem operations in the second quarter of fiscal 2016.  It is open to a sale of the technology or operations.

[0001045810-15-000087:8k_2_02:17]
The company estimates that it will recognize restructuring charges in the range of $100 million to $125 million, primarily during fiscal 2016.  These charges will consist of severance and other employee termination benefits, tax expense items and other costs associated with the wind-down, if the company is unable to sell the modem operations.

[0001045810-15-000087:8k_2_02:18]
The Icera wind-down or sale is expected to benefit non-GAAP operating expenses in the second half of the year and the company  will carefully invest in its growth initiatives of deep learning, self-driving cars and gaming.  Non-GAAP operating expenses in fiscal 2016 are expected to be approximately flat with the previous year, excluding litigation costs, which are anticipated to be in the range of $70 million to $90 million as the company defends its intellectual property.

[0001045810-15-000087:8k_2_02:19]
Capital Return

[0001045810-15-000087:8k_2_02:20]
During the first quarter, NVIDIA paid $46 million in cash dividends and repurchased 2.4 million shares. As a result, it returned an aggregate of $99 million to shareholders.

[0001045810-15-000087:8k_2_02:21]
It has announced a 15 percent increase in its quarterly cash dividend to $0.0975 per share, from $0.085 per share. NVIDIA will pay its next quarterly cash dividend of $0.0975 per share on June 12, 2015, to all stockholders of record on May 21, 2015.

[0001045810-15-000087:8k_2_02:22]
It also has announced an increase in its intended return to shareholders in fiscal 2016 to $800 million from the previously stated $600 million, through quarterly cash dividends and share repurchases.

[0001045810-15-000087:8k_2_02:23]
Further, the company’s board of directors has extended the previously authorized repurchase program through December 2018 and authorized an additional $1.62 billion, for an aggregate of $2.00 billion available for repurchase.

[0001045810-15-000087:8k_2_02:24]
| GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q1 FY16 | Q4 FY15 | Q1 FY15 | Q/Q | Y/Y |
| Revenue | $1,151 | $1,251 | $1,103 | down 8% | up 4% |
| Gross margin | 56.7% | 55.9% | 54.8% | up 80 bps | up 190 bps |
| Operating expenses | $477 | $468 | $453 | up 2% | up 5% |
| Net income | $134 | $193 | $137 | down 31% | down 2% |
| Diluted earnings per share | $0.24 | $0.35 | $0.24 | down 31% | -- |

[0001045810-15-000087:8k_2_02:25]
| Non-GAAP Quarterly Financial Comparison |
| ($ in millions except earnings per share) | Q1 FY16 | Q4 FY15 | Q1 FY15 | Q/Q | Y/Y |
| Revenue | $1,151 | $1,251 | $1,103 | down 8% | up 4% |
| Gross margin | 56.9% | 56.2% | 55.1% | up 70 bps | up 180 bps |
| Operating expenses | $425 | $420 | $411 | up 1% | up 3% |
| Net income | $187 | $241 | $166 | down 22% | up 13% |
| Diluted earnings per share | $0.33 | $0.43 | $0.29 | down 23% | up 14% |

[0001045810-15-000087:8k_2_02:26]
NVIDIA’s outlook for the second quarter of fiscal 2016 is as follows:

[0001045810-15-000087:8k_2_02:27]
| • | Revenue is expected to be $1.01 billion, plus or minus two percent. |

[0001045810-15-000087:8k_2_02:28]
| • | GAAP and non-GAAP gross margins are expected to be 55.7 percent and 56.0 percent, respectively, plus or minus 50 basis points. |

[0001045810-15-000087:8k_2_02:29]
| • | GAAP operating expenses are expected to be approximately $474 million; non-GAAP operating expenses are expected to be approximately $425 million. |

[0001045810-15-000087:8k_2_02:30]
| • | GAAP and non-GAAP tax rates for the second quarter of fiscal 2016 are expected to be 23 percent and 21 percent, respectively, plus or minus one percent. |

[0001045810-15-000087:8k_2_02:31]
| • | The above GAAP outlook amounts exclude restructuring charges, which are expected to be in the range of $100 million to $125 million, primarily during fiscal 2016. These charges will consist of severance and other employee termination benefits, tax expense items and other costs associated with the wind-down, if the company is unable to sell the modem operations. |

[0001045810-15-000087:8k_2_02:32]
| • | Capital expenditures are expected to be approximately $35 million to $45 million. |

[0001045810-15-000087:8k_2_02:33]
First Quarter Fiscal 2016 Highlights

[0001045810-15-000087:8k_2_02:34]
During the first quarter, NVIDIA achieved progress in each of its platforms.

[0001045810-15-000087:8k_2_02:35]
Gaming:

[0001045810-15-000087:8k_2_02:36]
| • | Launched NVIDIA® GeForce® GTX™ TITAN X GPU, the world’s fastest GPU. |

[0001045810-15-000087:8k_2_02:37]
| • | Introduced its first living-room entertainment device, NVIDIA SHIELD™, the world’s first 4K smart TV platform that uses the Internet to connect you to a world of media, games, and apps. |

[0001045810-15-000087:8k_2_02:38]
Enterprise Graphics:

[0001045810-15-000087:8k_2_02:39]
| • | Introduced its roadmap for physically based rendering - including Iray® 2015 rendering software; Quadro® M6000, the world’s most powerful professional GPU; and the Quadro Visual Computing Appliance, with eight M6000 GPUs. |

[0001045810-15-000087:8k_2_02:40]
HPC & Cloud:

[0001045810-15-000087:8k_2_02:41]
| • | Drew more than 4,000 guests to the sixth annual GPU Technology Conference, which focused on deep learning and self-driving cars, and featured talks by leaders in these industries. |

[0001045810-15-000087:8k_2_02:42]
| • | Major consumer web and cloud companies - including Baidu, Facebook, Flickr/Yahoo, Microsoft and Twitter - are using NVIDIA GPUs for deep learning. |

[0001045810-15-000087:8k_2_02:43]
| • | Announced that its next-generation Pascal™ GPU architecture will accelerate deep learning applications 10X beyond the speed of current-generation Maxwell™ processors. |

[0001045810-15-000087:8k_2_02:44]
Automotive:

[0001045810-15-000087:8k_2_02:45]
| • | Announced availability of NVIDIA DRIVE™ PX, a powerful car computer that utilizes deep learning to enable self-driving capabilities. |

[0001045810-15-000087:8k_2_02:46]
CFO Commentary

[0001045810-15-000087:8k_2_02:47]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-15-000087:8k_2_02:48]
Conference Call and Webcast Information

[0001045810-15-000087:8k_2_02:49]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2016 financial results and current financial prospects today at 2 p.m. Pacific Time (5 p.m. Eastern Time). To listen to the conference call, dial (303) 223-2696; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its second quarter fiscal 2016.

[0001045810-15-000087:8k_2_02:50]
Non-GAAP Measures

[0001045810-15-000087:8k_2_02:51]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow.  In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, acquisition-related costs, gains and losses from non-affiliated investments, interest expense related to amortization of debt discount, and the associated tax impact of these items, where applicable.  Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of our Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets.  NVIDIA believes the presentation of its non-GAAP financial measures enhances the user's overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and our non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-15-000087:8k_2_02:52]
To Keep Current on NVIDIA:

[0001045810-15-000087:8k_2_02:53]
| • | Keep up with the NVIDIA Blog, and follow us on Facebook, Google+, Twitter, LinkedIn and Instagram. |

[0001045810-15-000087:8k_2_02:54]
| • | View NVIDIA videos on YouTube and images on Flickr. |

[0001045810-15-000087:8k_2_02:55]
| • | Use the Pulse news reader to subscribe to the NVIDIA Daily News feed. |

[0001045810-15-000087:8k_2_02:56]
About NVIDIA

[0001045810-15-000087:8k_2_02:57]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-15-000087:8k_2_02:58]
###

[0001045810-15-000087:8k_2_02:59]
For further information, contact:

[0001045810-15-000087:8k_2_02:60]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-15-000087:8k_2_02:61]
Certain statements in this press release including, but not limited to statements as to: the importance of visual computing; the company’s leading position to advance deep learning, virtual reality and self-driving cars; the alignment of the company’s singular focus on visual computing; the timing of the company’s case against Samsung and Qualcomm; the timing of the wind-down of the Icera modem operations; the company’s openness to a sale of the technology or operations; the amount, timing and composition of estimated restructuring charges; the impact of the Icera wind-down or sale; the company’s investment in its growth initiatives of deep learning, self-driving cars and gaming; the amount of non-GAAP operating expenses in fiscal 2016; the amount of litigation costs; the company’s intended return to shareholders in fiscal 2016 of $800 million; the company’s financial outlook for the second quarter of fiscal 2016; the company’s tax rates for the second quarter of fiscal 2016; and the benefits and features of the Pascal GPU architecture and NVIDIA DRIVE PX are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-K for the fiscal period ended January 25, 2015. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-15-000087:8k_2_02:62]
© 2015 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GTX, Iray, Maxwell, NVIDIA DRIVE, Pascal, Quadro, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-15-000087:8k_2_02:63]
NVIDIA CORPORATION

[0001045810-15-000087:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-15-000087:8k_2_02:65]
(In millions, except per share data)

[0001045810-15-000087:8k_2_02:66]
(Unaudited)

[0001045810-15-000087:8k_2_02:67]
|  | Three Months Ended |
|  | April 26, |  | April 27, |
|  | 2015 |  | 2014 |
| Revenue | $ | 1,151 |  |  | $ | 1,103 |  |
| Cost of revenue | 498 |  |  | 499 |  |
| Gross profit | 653 |  |  | 604 |  |
| Operating expenses |  |  |  |
| Research and development | 339 |  |  | 334 |  |
| Sales, general and administrative | 138 |  |  | 119 |  |
| Total operating expenses | 477 |  |  | 453 |  |
| Operating income | 176 |  |  | 151 |  |
| Interest income | 9 |  |  | 6 |  |
| Interest expense | (12 | ) |  | (11 | ) |
| Other income (expense), net | (1 | ) |  | 17 |  |
| Income before income tax expense | 172 |  |  | 163 |  |
| Income tax expense | 38 |  |  | 26 |  |
| Net income | $ | 134 |  |  | $ | 137 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.24 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.24 |  |
| Weighted average shares used in per share computation: |  |  |  |
| Basic | 549 |  |  | 559 |  |
| Diluted | 568 |  |  | 570 |  |

[0001045810-15-000087:8k_2_02:68]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | April 26, |  | January 25, |
|  |  |  | 2015 |  | 2015 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,792 |  |  | $ | 4,623 |  |
|  | Accounts receivable, net |  | 455 |  |  | 474 |  |
|  | Inventories |  | 438 |  |  | 483 |  |
|  | Prepaid expenses and other current assets |  | 147 |  |  | 133 |  |
|  | Total current assets |  | 5,832 |  |  | 5,713 |  |
| Property and equipment, net |  | 547 |  |  | 557 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 205 |  |  | 222 |  |
| Other assets |  | 89 |  |  | 91 |  |
|  | Total assets |  | $ | 7,291 |  |  | $ | 7,201 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 222 |  |  | $ | 293 |  |
|  | Accrued liabilities and other current liabilities |  | 661 |  |  | 603 |  |
|  | Total current liabilities |  | 883 |  |  | 896 |  |
| Long-term debt |  | 1,391 |  |  | 1,384 |  |
| Other long-term liabilities |  | 448 |  |  | 489 |  |
| Capital lease obligations, long-term |  | 13 |  |  | 14 |  |
| Stockholders' equity |  | 4,556 |  |  | 4,418 |  |
|  | Total liabilities and stockholders' equity |  | $ | 7,291 |  |  | $ | 7,201 |  |

[0001045810-15-000087:8k_2_02:69]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |
|  |  | April 26, |  | January 25, |  | April 27, |
|  |  | 2015 |  | 2015 |  | 2014 |
| GAAP gross profit |  | $ | 653 |  |  | $ | 700 |  |  | $ | 604 |  |
| GAAP gross margin |  | 56.7 | % |  | 55.9 | % |  | 54.8 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 2 |  |  | 3 |  |  | 3 |  |
| Non-GAAP gross profit |  | $ | 655 |  |  | $ | 703 |  |  | $ | 607 |  |
| Non-GAAP gross margin |  | 56.9 | % |  | 56.2 | % |  | 55.1 | % |
| GAAP operating expenses |  | $ | 477 |  |  | $ | 468 |  |  | $ | 453 |  |
| Stock-based compensation expense included in operating expense (A) |  | (43 | ) |  | (39 | ) |  | (33 | ) |
| Acquisition-related costs (B) |  | (9 | ) |  | (9 | ) |  | (9 | ) |
| Non-GAAP operating expenses |  | $ | 425 |  |  | $ | 420 |  |  | $ | 411 |  |
| GAAP other income (expense), net | $ | (4 | ) |  | $ | (3 | ) |  | $ | 12 |  |
| Gains and losses from non-affiliated investments |  | — |  |  | — |  |  | (17 | ) |
| Interest expense related to amortization of debt discount |  | 7 |  |  | 7 |  |  | 7 |  |
| Non-GAAP other income (expense), net | $ | 3 |  |  | $ | 4 |  |  | $ | 2 |  |
| GAAP net income |  | $ | 134 |  |  | $ | 193 |  |  | $ | 137 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 63 |  |  | 58 |  |  | 35 |  |
| Income tax impact of non-GAAP adjustments |  | (10 | ) |  | (10 | ) |  | (6 | ) |
| Non-GAAP net income |  | $ | 187 |  |  | $ | 241 |  |  | $ | 166 |  |
| Diluted net income per share |  |  |  |  |  |  |
| GAAP |  | $ | 0.24 |  |  | $ | 0.35 |  |  | $ | 0.24 |  |
| Non-GAAP |  | $ | 0.33 |  |  | $ | 0.43 |  |  | $ | 0.29 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |
| GAAP |  | 568 |  |  | 557 |  |  | 570 |  |
| Anti-dilution impact from Note Hedge (C) |  | (6 | ) |  | — |  |  | — |  |
| Non-GAAP |  | 562 |  |  | 557 |  |  | 570 |  |
| Metrics: |  |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 246 |  |  | $ | 443 |  |  | $ | 151 |  |
| Purchase of property and equipment and intangible assets |  | (30 | ) |  | (31 | ) |  | (29 | ) |
| Free cash flow |  | $ | 216 |  |  | $ | 412 |  |  | $ | 122 |  |

[0001045810-15-000087:8k_2_02:70]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  |
|  |  | April 26, |  | January 25, |  | April 27, |  |
|  |  | 2015 |  | 2015 |  | 2014 |  |
| Cost of revenue |  | $ | 2 |  |  | $ | 3 |  |  | $ | 3 |  |  |
| Research and development |  | $ | 27 |  |  | $ | 24 |  |  | $ | 21 |  |  |
| Sales, general and administrative |  | $ | 16 |  |  | $ | 15 |  |  | $ | 12 |  |  |
| (B) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |  |
| (C) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-15-000087:8k_2_02:71]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2016 Outlook |
| GAAP gross margin |  | 55.7 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 56.0 | % |
|  |  |  | Q2 FY2016 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 474 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (49 | ) |
| Non-GAAP operating expenses |  | $ | 425 |  |
