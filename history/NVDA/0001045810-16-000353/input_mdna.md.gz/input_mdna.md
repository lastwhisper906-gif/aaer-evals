# NVDA MD&A — 0001045810-16-000353


## mdna

[0001045810-16-000353:mdna:1]
[same as prior period, unchanged from 0001045810-16-000300:mdna:1]

[0001045810-16-000353:mdna:2]
[same as prior period, unchanged from 0001045810-16-000300:mdna:2]

[0001045810-16-000353:mdna:3]
[same as prior period, unchanged from 0001045810-16-000300:mdna:3]

[0001045810-16-000353:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, Quadro, Tegra, Tesla, Ansel, GeForce NOW, Icera, Iray, NVIDIA DGX-1, NVIDIA DRIVE, NVIDIA DesignWorks, NVIDIA GRID, NVIDIA SHIELD, NVIDIA TensorRT, NVIDIA VRWorks, and Pascal are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-16-000353:mdna:5]
[same as prior period, unchanged from 0001045810-16-000300:mdna:5]

[0001045810-16-000353:mdna:6]
[same as prior period, unchanged from 0001045810-16-000300:mdna:6]

[0001045810-16-000353:mdna:7]
[same as prior period, unchanged from 0001045810-16-000300:mdna:7]

[0001045810-16-000353:mdna:8]
[same as prior period, unchanged from 0001045810-16-000300:mdna:8]

[0001045810-16-000353:mdna:9]
[same as prior period, unchanged from 0001045810-16-000300:mdna:9]

[0001045810-16-000353:mdna:10]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla for researchers and data scientists focused on artificial intelligence and big-data analytics; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs aimed at online gaming and entertainment devices, as well as autonomous robots, drones and cars.

[0001045810-16-000353:mdna:11]
[same as prior period, unchanged from 0001045810-16-000300:mdna:11]

[0001045810-16-000353:mdna:12]
[same as prior period, unchanged from 0001045810-16-000300:mdna:13]

[0001045810-16-000353:mdna:13]
Third Quarter of Fiscal Year 2017 Summary

[0001045810-16-000353:mdna:14]
|  | Three Months Ended |  |  |  |  |
|  | October 30, 2016 |  | July 31, 2016 |  | October 25, 2015 |  | Q/Q |  | Y/Y |
|  | (In millions, except per share data) |
| Revenue | $ | 2,004 |  |  | $ | 1,428 |  |  | $ | 1,305 |  |  | 40 | % |  | 54 | % |
| Gross margin | 59.0 | % |  | 57.9 | % |  | 56.3 | % |  | 110 bps |  |  | 270 bps |  |
| Operating expenses | $ | 544 |  |  | $ | 509 |  |  | $ | 489 |  |  | 7 | % |  | 11 | % |
| Income from operations | $ | 639 |  |  | $ | 317 |  |  | $ | 245 |  |  | 102 | % |  | 161 | % |
| Net income | $ | 542 |  |  | $ | 261 |  |  | $ | 246 |  |  | 108 | % |  | 120 | % |
| Net income per diluted share | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 0.44 |  |  | 102 | % |  | 89 | % |

[0001045810-16-000353:mdna:15]
Revenue for the third quarter of fiscal year 2017 increased 54% year over year and 40% sequentially to $2.00 billion. Growth from a year ago was driven by gaming, datacenter, professional visualization, and automotive systems. GPU business revenue was $1.70 billion, up 53% from a year earlier and up 42% sequentially, led by growth in GeForce gaming GPUs and datacenter. GeForce gaming GPU revenue was fueled by strong adoption of our recent Pascal architecture. Datacenter revenue (including Tesla, NVIDIA GRID and NVIDIA DGX-1) was $240 million, up 193% from a year earlier and up 59% sequentially. This reflects strong demand for deep learning and high performance computing, Tesla and GRID for cloud and virtualized computing, and initial DGX-1 sales. Tegra business revenue, which included gaming development platforms and services, was $241 million, up 87% from a year earlier and up 45% sequentially. Also included was automotive revenue of $127 million, primarily from infotainment modules, which was up 61% from a year earlier and up 7% sequentially.

[0001045810-16-000353:mdna:16]
Gross margin for the third quarter of fiscal year 2017 was 59.0%, reflecting the strength of our GeForce gaming GPUs, the success of our platform approach and strong demand for deep learning.

[0001045810-16-000353:mdna:17]
Operating expenses for the third quarter of fiscal year 2017 were $544 million, up 11% from a year earlier and up 7% sequentially. This reflects headcount related costs for our growth initiatives, as well as investments in sales and marketing.

[0001045810-16-000353:mdna:18]
Income from operations for the third quarter of fiscal year 2017 was $639 million, up 161% from a year earlier and up 102% sequentially. Net income and net income per diluted share for the third quarter of fiscal year 2017 were $542 million and $0.83, respectively, up 120% and 89%, respectively, from a year earlier, fueled by strong revenue growth and improved gross and operating margins. In the third quarter of fiscal 2017, we adopted a new accounting standard related to the simplification of certain aspects of stock-based compensation accounting. This accounting standard requires adjustments to be reflected beginning in fiscal year 2017, including all fiscal quarters within the year. Please refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-16-000353:mdna:19]
During the first nine months of fiscal year 2017, we paid $509 million for share repurchases and $185 million in cash dividends.  As a result, we have returned an aggregate of $694 million to shareholders in the first nine months of fiscal year 2017. For fiscal year 2018, we intend to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. Our board of directors has authorized an additional $2.00 billion under our stock repurchase program for a total of $2.96 billion available through the end of December 2020.

[0001045810-16-000353:mdna:20]
Cash, cash equivalents and marketable securities were $6.67 billion as of October 30, 2016, compared with $4.88 billion at the end of the prior quarter. The sequential increase was primarily related to cash received from our issuance of $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026 (collectively, the Notes) during the third quarter of fiscal year 2017.

[0001045810-16-000353:mdna:21]
[same as prior period, unchanged from 0001045810-16-000300:mdna:23]

[0001045810-16-000353:mdna:22]
During the third quarter of fiscal year 2017, we expanded our line of Pascal GPUs with NVIDIA GeForce GTX 1050 and GTX 1050 Ti and we introduced GeForce GTX 1080, 1070 and 1060 for notebooks. For our datacenter platform, we launched Tesla P40 and P4 GPUs and the NVIDIA TensorRT deep learning inferencing framework; began shipping the DGX-1 AI supercomputer to research organizations, universities, and multinationals.

[0001045810-16-000353:mdna:23]
During the second quarter of fiscal year 2017, we began shipping our Pascal architecture with a set of gaming GPUs: GeForce GTX 1080, 1070, 1060, and TITAN X, and released our first game, NVIDIA VR Funhouse. For our datacenter platform, we introduced the Tesla M10 for virtualizing enterprise applications, introduced Tesla P100 GPU accelerators, delivering substantial performance and value compared with CPU-based systems, and unveiled our Inception Program, which provides access to NVIDIA technology and expertise to support the growth of startups in deep learning and data science. For our professional virtualization platform, we unveiled Quadro P6000 to power advanced workstations, enabling designers to complete complex designs and refreshed NVIDIA DesignWorks and NVIDIA VRWorks with new updates and software development kits.

[0001045810-16-000353:mdna:24]
[same as prior period, unchanged from 0001045810-16-000300:mdna:26]

[0001045810-16-000353:mdna:25]
[same as prior period, unchanged from 0001045810-16-000300:mdna:27]

[0001045810-16-000353:mdna:26]
During the third quarter of fiscal year 2017, we announced that NVIDIA gaming technology will power the Nintendo Switch home gaming system. We also announced that our NVIDIA DRIVE PX 2 platform will power a new AutoPilot system in all of Tesla Motors’ factory produced vehicles – the Model S, Model X and upcoming Model 3.

[0001045810-16-000353:mdna:27]
[same as prior period, unchanged from 0001045810-16-000300:mdna:28]

[0001045810-16-000353:mdna:28]
[same as prior period, unchanged from 0001045810-16-000300:mdna:29]

[0001045810-16-000353:mdna:29]
[same as prior period, unchanged from 0001045810-16-000300:mdna:30]

[0001045810-16-000353:mdna:30]
[same as prior period, unchanged from 0001045810-16-000300:mdna:31]

[0001045810-16-000353:mdna:31]
[same as prior period, unchanged from 0001045810-16-000300:mdna:32]

[0001045810-16-000353:mdna:32]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla for researchers and data scientists focused on artificial intelligence and big-data analytics; and GRID for cloud-based visual computing users.

[0001045810-16-000353:mdna:33]
[same as prior period, unchanged from 0001045810-16-000300:mdna:34]

[0001045810-16-000353:mdna:34]
[same as prior period, unchanged from 0001045810-16-000300:mdna:35]

[0001045810-16-000353:mdna:35]
[same as prior period, unchanged from 0001045810-16-000300:mdna:36]

[0001045810-16-000353:mdna:36]
[same as prior period, unchanged from 0001045810-16-000300:mdna:38]

[0001045810-16-000353:mdna:37]
[same as prior period, unchanged from 0001045810-16-000300:mdna:39]

[0001045810-16-000353:mdna:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |  | October 30, 2016 |  | October 25, 2015 |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 41.0 |  |  | 43.7 |  |  | 41.7 |  |  | 44.0 |  |
| Gross profit | 59.0 |  |  | 56.3 |  |  | 58.3 |  |  | 56.0 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 18.6 |  |  | 25.2 |  |  | 22.6 |  |  | 27.3 |  |
| Sales, general and administrative | 8.5 |  |  | 11.6 |  |  | 10.3 |  |  | 12.2 |  |
| Restructuring and other charges | — |  |  | 0.6 |  |  | 0.1 |  |  | 2.7 |  |
| Total operating expenses | 27.1 |  |  | 37.4 |  |  | 33.0 |  |  | 42.2 |  |
| Income from operations | 31.9 |  |  | 18.9 |  |  | 25.3 |  |  | 13.8 |  |
| Interest income | 0.7 |  |  | 0.7 |  |  | 0.8 |  |  | 0.8 |  |
| Interest expense | (0.8 | ) |  | (0.9 | ) |  | (0.8 | ) |  | (1.0 | ) |
| Other income (expense), net | (0.8 | ) |  | 0.2 |  |  | (0.4 | ) |  | — |  |
| Income before income tax expense (benefit) | 31.0 |  |  | 18.9 |  |  | 24.9 |  |  | 13.6 |  |
| Income tax expense (benefit) | 3.9 |  |  | (0.1 | ) |  | 3.5 |  |  | 2.3 |  |
| Net income | 27.1 | % |  | 19.0 | % |  | 21.4 | % |  | 11.3 | % |

[0001045810-16-000353:mdna:39]
[same as prior period, unchanged from 0001045810-16-000300:mdna:41]

[0001045810-16-000353:mdna:40]
NVIDIA’s products and services are built for three computing platforms - PC, Datacenter/Cloud, and Mobile. For the first nine months of fiscal years 2017 and 2016, approximately 73% and 77% of our revenue, respectively, was associated with the PC computing platform, of which GPUs for the gaming and professional visualization markets comprised approximately 92% and 87%, respectively, while PC OEM represented approximately 8% and 13%, respectively.

[0001045810-16-000353:mdna:41]
[same as prior period, unchanged from 0001045810-16-000300:mdna:43]

[0001045810-16-000353:mdna:42]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |  | $Change |  | %Change |  | October 30, 2016 |  | October 25, 2015 |  | $Change |  | %Change |
|  | (In millions) |
| GPU | $ | 1,697 |  |  | $ | 1,110 |  |  | $ | 587 |  |  | 53 | % |  | $ | 3,972 |  |  | $ | 3,009 |  |  | $ | 963 |  |  | 32 | % |
| Tegra Processor | 241 |  |  | 129 |  |  | 112 |  |  | 87 | % |  | 567 |  |  | 402 |  |  | 165 |  |  | 41 | % |
| All Other | 66 |  |  | 66 |  |  | — |  |  | — | % |  | 198 |  |  | 198 |  |  | — |  |  | — | % |
| Total | $ | 2,004 |  |  | $ | 1,305 |  |  | $ | 699 |  |  | 54 | % |  | $ | 4,737 |  |  | $ | 3,609 |  |  | $ | 1,128 |  |  | 31 | % |

[0001045810-16-000353:mdna:43]
GPU Business. GPU business revenue increased by 53% for the third quarter of fiscal year 2017 compared to the third quarter of fiscal year 2016. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased 59%, reflecting a combination of continued strength in PC gaming and strong demand for our recent Pascal-based GPU products. Datacenter revenue, including Tesla, GRID and DGX-1, increased 193%, reflecting strong demand for deep learning training, Tesla and GRID for cloud and virtualized computing, and initial DGX-1 sales. Revenue from Quadro GPUs for professional visualization increased 9% due primarily to higher sales in both desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-16-000353:mdna:44]
31

[0001045810-16-000353:mdna:45]
GPU business revenue increased by 32% in the first nine months of fiscal year 2017 compared to the first nine months of fiscal year 2016. This increase was due primarily to increased revenue from sales of high-end GeForce GPU products for gaming, which increased 36%, reflecting a combination of continued strength in PC gaming and strong demand for our recent Pascal-based GPU products. Datacenter revenue, including Tesla and NVIDIA GRID and DGX-1, increased 120%, reflecting strong demand for deep learning training, Tesla and GRID for cloud and virtualized computing, and initial DGX-1 sales. Revenue from Quadro GPUs for professional visualization increased 11% due primarily to higher sales in both desktop and mobile workstation products. Revenue from GeForce GPU products for mainstream PC OEMs declined compared to last year.

[0001045810-16-000353:mdna:46]
Tegra Processor Business. Tegra Processor business revenue increased by 87% for the third quarter of fiscal year 2017 compared to the third quarter of fiscal year 2016. This was driven by an increase of 61% in sales of Tegra products serving automotive systems and an increase in gaming development platforms and services compared to last year.

[0001045810-16-000353:mdna:47]
Tegra Processor business revenue increased by 41% in the first nine months of fiscal year 2017 compared to the first nine months of fiscal year 2016. This was driven by an increase of 58% in sales of Tegra products serving automotive systems compared to last year.

[0001045810-16-000353:mdna:48]
All Other. We recognized $66 million in revenue during the third quarter of both fiscal years 2017 and 2016 and $198 million in revenue during the first nine months of both fiscal years 2017 and 2016, from the patent cross licensing arrangement with Intel.

[0001045810-16-000353:mdna:49]
[same as prior period, unchanged from 0001045810-16-000300:mdna:51]

[0001045810-16-000353:mdna:50]
Revenue from sales to customers outside of the United States and Other Americas accounted for 78% of total revenue for both the third quarter and the first nine months of fiscal year 2017. Revenue from sales to customers outside of the United States and Other Americas accounted for 80% of total revenue for the third quarter of fiscal year 2016 and 78% of total revenue for the first nine months of fiscal year 2016. Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-16-000353:mdna:51]
[same as prior period, unchanged from 0001045810-16-000300:mdna:53]

[0001045810-16-000353:mdna:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |  | October 30, 2016 |  | October 25, 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Customer A | 13 | % |  | 10 | % |  | 12 | % |  | 11 | % |

[0001045810-16-000353:mdna:53]
[same as prior period, unchanged from 0001045810-16-000300:mdna:55]

[0001045810-16-000353:mdna:54]
Gross profit consists of total revenue, net of allowances, less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions and shipping costs. Cost of revenue also includes development costs for license and service arrangements and stock-based compensation related to personnel associated with operations. Gross margin is the percentage of gross profit to revenue.

[0001045810-16-000353:mdna:55]
Our overall gross margin was 59.0% and 56.3% for the third quarter of fiscal years 2017 and 2016, respectively, and 58.3% and 56.0% for the first nine months of fiscal year 2017 and 2016, respectively. These increases were driven primarily by product mix in our GPU business, partially offset by lower gross margins in our Tegra business.

[0001045810-16-000353:mdna:56]
Charges to cost of sales for inventory provisions totaled $13 million and $40 million for the third quarter of fiscal years 2017 and 2016, respectively, unfavorably impacting our gross margin by 0.7% and 3.1%, respectively. Sales of inventory that was previously written-off or written-down totaled $19 million and $6 million for the third quarter of fiscal years 2017 and 2016, respectively, favorably impacting our gross margin by 0.9% and 0.5%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.2% favorable impact for the third quarter of fiscal year 2017 and a 2.6% unfavorable impact for the third quarter of fiscal year 2016.

[0001045810-16-000353:mdna:57]
32

[0001045810-16-000353:mdna:58]
Charges to cost of sales for inventory provisions totaled $40 million and $71 million for the first nine months of fiscal years 2017 and 2016, respectively, unfavorably impacting our gross margin by 0.9% and 2.0%, respectively. Sales of inventory that was previously written-off or written-down totaled $39 million and $26 million for the first nine months of fiscal years 2017 and 2016, respectively, favorably impacting our gross margin by 0.8% and 0.7%, respectively. As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.1% unfavorable impact for the first nine months of fiscal year 2017 and a 1.3% unfavorable impact for the first nine months of fiscal year 2016.

[0001045810-16-000353:mdna:59]
[same as prior period, unchanged from 0001045810-16-000300:mdna:61]

[0001045810-16-000353:mdna:60]
GPU Business. The gross margin of our GPU business increased during the third quarter and first nine months of fiscal year 2017 compared to the third quarter and first nine months of fiscal year 2016. GPU margins increased primarily due to strong demand for Tesla products for deep learning and high performance computing and the strength of our GeForce gaming GPUs.

[0001045810-16-000353:mdna:61]
Tegra Processor Business. The gross margin of our Tegra Processor business increased during the third quarter and first nine months of fiscal year 2017 compared to the third quarter and first nine months of fiscal year 2016. The increase in Tegra margins was primarily due to the inventory provisions we recorded during the third quarter of fiscal year 2016 related primarily to older generation Tegra products and the warranty charge we recorded during the first nine months of fiscal year 2016 associated with the SHIELD tablet product recall.

[0001045810-16-000353:mdna:62]
[same as prior period, unchanged from 0001045810-16-000300:mdna:64]

[0001045810-16-000353:mdna:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |  | $Change |  | %Change |  | October 30, 2016 |  | October 30, 2015 |  | $Change |  | %Change |
|  | (In millions) |
| Research and development expenses | $ | 373 |  |  | $ | 329 |  |  | $ | 44 |  |  | 13 | % |  | $ | 1,069 |  |  | $ | 987 |  |  | $ | 82 |  |  | 8 | % |
| Sales, general and administrative expenses | 171 |  |  | 152 |  |  | 19 |  |  | 13 | % |  | 487 |  |  | 441 |  |  | 46 |  |  | 10 | % |
| Restructuring and other charges | — |  |  | 8 |  |  | (8 | ) |  | (100 | )% |  | 3 |  |  | 97 |  |  | (94 | ) |  | (97 | )% |
| Total operating expenses | $ | 544 |  |  | $ | 489 |  |  | $ | 55 |  |  | 11 | % |  | $ | 1,559 |  |  | $ | 1,525 |  |  | $ | 34 |  |  | 2 | % |
| Research and development expenses as a percentage of net revenue | 19 | % |  | 25 | % |  |  |  |  |  |  |  | 23 | % |  | 27 | % |  |  |  |  |
| Sales, general and administrative expenses as a percentage of net revenue | 9 | % |  | 12 | % |  |  |  |  |  |  |  | 10 | % |  | 12 | % |  |  |  |  |
| Restructuring and other charges as a percentage of net revenue | — | % |  | 1 | % |  |  |  |  |  | — | % |  | 3 | % |  |  |  |  |

[0001045810-16-000353:mdna:64]
[same as prior period, unchanged from 0001045810-16-000300:mdna:66]

[0001045810-16-000353:mdna:65]
Research and development expenses increased by 13% during the third quarter of fiscal year 2017 compared to the third quarter of fiscal year 2016. Compensation and benefits increased by $38 million primarily driven by employee additions and an increase in related compensation and benefit costs, including stock-based compensation expense.

[0001045810-16-000353:mdna:66]
Research and development expenses increased by 8% during the first nine months of fiscal year 2017 compared to the first nine months of fiscal year 2016. Compensation and benefits increased by $68 million primarily driven by employee additions and an increase in related compensation and benefit costs, including stock-based compensation expense.

[0001045810-16-000353:mdna:67]
[same as prior period, unchanged from 0001045810-16-000300:mdna:69]

[0001045810-16-000353:mdna:68]
Sales, general and administrative expenses increased by 13% during the third quarter of fiscal year 2017 compared to the third quarter of fiscal year 2016. Compensation and benefits increased by $28 million primarily driven by employee additions and an increase in related compensation and benefit costs, including stock-based compensation expense. Offsetting this increase was a decrease in outside professional fees of $16 million resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-16-000353:mdna:69]
Sales, general and administrative expenses increased by 10% during the first nine months of fiscal year 2017 compared to the first nine months of fiscal year 2016. Compensation and benefits increased by $65 million primarily driven by employee additions and an increase in related compensation and benefit costs, including stock-based compensation expense. Marketing expense increased by $10 million mainly due to the introduction of our new Pascal family of GPUs. Offsetting these increases was a decrease in outside professional fees of $42 million resulting from the resolution of our intellectual property disputes with Samsung and Qualcomm.

[0001045810-16-000353:mdna:70]
[same as prior period, unchanged from 0001045810-16-000300:mdna:73]

[0001045810-16-000353:mdna:71]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera operations. Our operating expenses for the nine months ended July 31, 2016 included $3 million of restructuring and other charges. No restructuring charges were recorded during the third quarter of fiscal year 2017. Please refer to Note 15 of the Notes to Condensed Consolidated Financial Statements for further discussion.

[0001045810-16-000353:mdna:72]
[same as prior period, unchanged from 0001045810-16-000300:mdna:75]

[0001045810-16-000353:mdna:73]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest expense is primarily comprised of coupon interest and debt discount amortization related to the 1.00% Convertible Senior Notes due in 2018, or the Convertible Notes, issued in December 2013 and the Notes issued in September 2016.

[0001045810-16-000353:mdna:74]
Interest income was $14 million and $9 million during the third quarter of fiscal years 2017 and 2016, respectively, and $37 million and $28 million during the first nine months of fiscal years 2017 and 2016, respectively. The increase in interest income was primarily due to higher average cash balances invested in interest bearing securities, as well as higher purchased yields.

[0001045810-16-000353:mdna:75]
Interest expense was $16 million and $12 million during the third quarter of fiscal years 2017 and 2016, respectively, and $39 million and $35 million during the first nine months of fiscal years 2017 and 2016, respectively, consisting primarily of coupon interest and debt discount amortization related to the Convertible Notes issued in December 2013 and the Notes issued in September 2016.

[0001045810-16-000353:mdna:76]
[same as prior period, unchanged from 0001045810-16-000300:mdna:79]

[0001045810-16-000353:mdna:77]
Other income (expense), net, consists primarily of realized gains and losses from the sale of marketable securities, sales or impairments of investments in non-affiliated companies, losses on early debt conversions of the Convertible Notes, and the impact of changes in foreign currency rates. Other expense, net, was $16 million and $19 million during the third quarter and first nine months of fiscal year 2017 consisting primarily of $15 million of losses recognized from early conversions of the Convertible Notes. Other income (expense), net, was not significant during the third quarter or the first nine months of fiscal year 2016.

[0001045810-16-000353:mdna:78]
[same as prior period, unchanged from 0001045810-16-000300:mdna:81]

[0001045810-16-000353:mdna:79]
We recognized income tax expense of $79 million and $168 million for the third quarter and first nine months of fiscal year 2017, respectively, and $83 million for the first nine months of fiscal year 2016. We recognized income tax benefit of $1 million for the third quarter of fiscal year 2016. Income tax expense as a percentage of income before income tax was 12.8% and 14.2% for the third quarter and first nine months of fiscal year 2017, respectively, and was 16.9% for the first nine months of fiscal year 2016. Income tax benefit as a percentage of income before income tax was 0.5% for the third quarter of fiscal year 2016. Our income tax expense includes $42 million and $62 million of tax benefit for the third quarter and first nine months of fiscal year 2017, respectively, from the early adoption of an accounting standard related to stock-based compensation. Please refer to Note 1 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-16-000353:mdna:80]
34

[0001045810-16-000353:mdna:81]
The increase in our effective tax rate in the third quarter of fiscal year 2017 compared to the same period in the prior fiscal year was primarily due to the absence of the tax benefit related to the restructuring associated with the wind-down of our Icera operations. The decrease in our effective tax rate in the first nine months of fiscal year 2017 compared to the same period in the prior fiscal year was primarily due to the favorable benefit of the U.S. federal research tax credit, which was permanently enacted in the fourth quarter of fiscal year 2016, and early adoption of an accounting standard, partially offset by the absence of the Icera restructuring tax benefit and an increase in the amount of our earnings subject to U.S. tax.

[0001045810-16-000353:mdna:82]
Our effective tax rate for the first nine months of fiscal year 2017 of 14.2% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit, as well as tax benefits recognized in the period in which they occur for early adoption of an accounting standard and expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-16-000353:mdna:83]
[same as prior period, unchanged from 0001045810-16-000300:mdna:85]

[0001045810-16-000353:mdna:84]
[same as prior period, unchanged from 0001045810-16-000300:mdna:86]

[0001045810-16-000353:mdna:85]
|  | October 30, 2016 |  | January 31, 2016 |
|  | (In millions) |
| Cash and cash equivalents | $ | 1,940 |  |  | $ | 596 |  |
| Marketable securities | 4,731 |  |  | 4,441 |  |
| Cash, cash equivalents and marketable securities | $ | 6,671 |  |  | $ | 5,037 |  |

[0001045810-16-000353:mdna:86]
|  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 951 |  |  | $ | 664 |  |
| Net cash used in investing activities | $ | (420 | ) |  | $ | (187 | ) |
| Net cash provided by (used in) financing activities | $ | 813 |  |  | $ | (503 | ) |

[0001045810-16-000353:mdna:87]
As of October 30, 2016, we had $6.67 billion in cash, cash equivalents and marketable securities, an increase of $1.63 billion from the end of fiscal year 2016. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions. Our portfolio managers are required to follow our investment policy, which requires the purchase of high grade investment securities, the diversification of asset types, and certain limits on our portfolio duration.

[0001045810-16-000353:mdna:88]
Cash provided by operating activities increased in the first nine months of fiscal year 2017 compared to the first nine months of fiscal year 2016, primarily due to higher net income resulting from revenue growing at a faster rate than operating expenses and gross margin improvements.

[0001045810-16-000353:mdna:89]
Cash used by investing activities increased in the first nine months of fiscal year 2017 compared to the first nine months of fiscal year 2016, primarily due to higher purchases of marketable securities and property and equipment and intangible assets than proceeds from sales and maturities of marketable securities.

[0001045810-16-000353:mdna:90]
Cash was provided by financing activities in the first nine months of fiscal year 2017, primarily due to the $2.00 billion of Notes we issued in the third quarter of fiscal year 2017, partially offset by $444 million of repayments of convertible debt and $694 million of share repurchases and dividend payments. Cash was used in financing activities in the first nine months of fiscal year 2016, primarily due to $604 million of share repurchases and dividend payments.

[0001045810-16-000353:mdna:91]
[same as prior period, unchanged from 0001045810-16-000300:mdna:93]

[0001045810-16-000353:mdna:92]
Our primary source of liquidity is cash generated by our operations. Our investment portfolio consists principally of cash and cash equivalents, corporate debt securities, debt securities of United States government agencies, debt securities issued by United States Treasury, asset-backed securities, mortgage-backed securities issued by United States government-sponsored enterprises, foreign government bonds and money market funds. These investments are denominated in United States dollars. As of October 30, 2016, we did not have any investments in auction-rate preferred securities.

[0001045810-16-000353:mdna:93]
[same as prior period, unchanged from 0001045810-16-000300:mdna:95]

[0001045810-16-000353:mdna:94]
As of October 30, 2016 and January 31, 2016, we had $6.67 billion and $5.04 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of October 30, 2016, we were in compliance with our investment policy. As of October 30, 2016, our investments in government agencies and government-sponsored enterprises represented 39% of our total investment portfolio, while the financial sector accounted for 25% of our total investment portfolio.  All of our investments are in A/A3 or better rated securities.

[0001045810-16-000353:mdna:95]
[same as prior period, unchanged from 0001045810-16-000300:mdna:97]

[0001045810-16-000353:mdna:96]
Dividend payments and any share repurchases must be made from cash held in the United States. In the third quarter and first nine months of fiscal year 2017, we made total cash dividend payments of $61 million and $185 million, respectively, and repurchased $509 million of our common stock in the first nine months of fiscal year 2017, utilizing a significant amount of our U.S. cash balance previously taxed as of October 30, 2016. We did not enter into any structured share repurchase transactions during the third quarter of fiscal year 2017.

[0001045810-16-000353:mdna:97]
[same as prior period, unchanged from 0001045810-16-000300:mdna:99]

[0001045810-16-000353:mdna:98]
On December 2, 2013, we issued $1.50 billion of Convertible Notes and concurrently entered into separate note hedge and warrant transactions. The Convertible Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Convertible Notes were convertible during the first nine months of fiscal year 2017 and are currently convertible at the holders’ option in the fourth quarter of fiscal year 2017. During the third quarter of fiscal year 2017, we paid cash to settle $444 million in principal amount, issued 15 million shares of our common stock with respect to the conversion obligation in excess of the principal amount, and recognized a loss of $15 million on early conversions, of the Convertible Notes. We have received additional conversion notices for an aggregate of $229 million in principal amount of the Convertible Notes during the third quarter of fiscal year 2017. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2017.

[0001045810-16-000353:mdna:99]
Given the current price of our common stock, we expect to receive additional notices of early conversion, which could require us to use a substantial amount of our cash in the United States to settle. Please refer to Note 11 of the Notes to the Condensed Consolidated Financial Statements for further information.

[0001045810-16-000353:mdna:100]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-16-000353:mdna:101]
On September 16, 2016, we issued $1.00 billion of the 2.20% Notes Due 2021 and $1.00 billion of the 3.20% Notes Due 2026. The net proceeds from the Notes were $1.98 billion, after deducting debt discounts and issuance costs. We intend to use the net proceeds from the Notes to prefund the repayment of the principal amount of our Convertible Notes and for general corporate purposes such as dividend payments or share repurchases.

[0001045810-16-000353:mdna:102]
Revolving Credit Facility

[0001045810-16-000353:mdna:103]
On October 7, 2016, we entered into a Credit Agreement under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021, on which date all outstanding obligations would be due and payable. The Credit Agreement also permits us to obtain additional revolving loan commitments and/or commitments to issue letters of credit of up to $425 million, subject to certain conditions. As of October 30, 2016, we had not borrowed any amounts under the Credit Agreement.

[0001045810-16-000353:mdna:104]
[same as prior period, unchanged from 0001045810-16-000300:mdna:102]

[0001045810-16-000353:mdna:105]
[same as prior period, unchanged from 0001045810-16-000300:mdna:103]

[0001045810-16-000353:mdna:106]
During the third quarter and first nine months of fiscal year 2017, we also paid $61 million and $185 million, respectively, in cash dividends to our shareholders, equivalent to $0.1150 per share. As a result, we returned $61 million and $694 million to shareholders during the three and nine months ended October 30, 2016, respectively, in the form of share repurchases and dividend payments.

[0001045810-16-000353:mdna:107]
We intend to return $1.00 billion to our shareholders in fiscal year 2017 through a combination of share repurchases and cash dividends. For fiscal year 2018, we intend to return $1.25 billion to our shareholders through ongoing quarterly cash dividends and share repurchases. On November 7, 2016, the Board authorized an additional $2.00 billion under our repurchase program and extended it through December 2020. We also declared an increase in our quarterly cash dividend to $0.1400 per share from $0.1150 per share, to be paid with our next quarterly cash dividend on December 19, 2016, to all shareholders of record on November 28, 2016.

[0001045810-16-000353:mdna:108]
[same as prior period, unchanged from 0001045810-16-000300:mdna:106]

[0001045810-16-000353:mdna:109]
[same as prior period, unchanged from 0001045810-16-000300:mdna:107]

[0001045810-16-000353:mdna:110]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating requirements for at least the next twelve months.

[0001045810-16-000353:mdna:111]
[same as prior period, unchanged from 0001045810-16-000300:mdna:109]

[0001045810-16-000353:mdna:112]
[same as prior period, unchanged from 0001045810-16-000300:mdna:110]

[0001045810-16-000353:mdna:113]
[same as prior period, unchanged from 0001045810-16-000300:mdna:111]

[0001045810-16-000353:mdna:114]
As of October 30, 2016, we had outstanding inventory purchase obligations totaling $908 million. Except as described above with respect to the Convertible Notes and the Notes, there were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 31, 2016.

[0001045810-16-000353:mdna:115]
[same as prior period, unchanged from 0001045810-16-000300:mdna:113]

[0001045810-16-000353:mdna:116]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-16-000353:mdna:117]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.

[0001045810-16-000353:mdna:118]
38
