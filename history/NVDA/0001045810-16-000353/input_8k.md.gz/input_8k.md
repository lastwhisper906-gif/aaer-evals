# NVDA 8-K — 0001045810-16-000343 filed 2016-11-10

## item codes, every 8-K on or before 2016-11-22

- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2016-11-22

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-16-000343:8k_2_02:1]
EX-99.1
2
q3fy17pr.htm
Q3FY17 PRESS RELEASE

[0001045810-16-000343:8k_2_02:2]
Exhibit

[0001045810-16-000343:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-16-000343:8k_2_02:4]
NVIDIA Announces Financial Results for Third Quarter Fiscal 2017

[0001045810-16-000343:8k_2_02:5]
| • | Record revenue of $2.00 billion, up 54 percent from a year ago. |

[0001045810-16-000343:8k_2_02:6]
| • | Record GAAP EPS of $0.83, up 89 percent from a year ago, and non-GAAP EPS of $0.94, up 104 percent from a year ago. |

[0001045810-16-000343:8k_2_02:7]
| • | Record GAAP gross margin at 59.0 percent and non-GAAP gross margin at 59.2 percent. |

[0001045810-16-000343:8k_2_02:8]
| • | Quarterly cash dividend raised 22 percent to $0.14 per share. Company to return $1.25 billion to shareholders in fiscal 2018. |

[0001045810-16-000343:8k_2_02:9]
SANTA CLARA, Calif.-Nov. 10, 2016-NVIDIA (NASDAQ: NVDA) today reported revenue for the third quarter ended October 30, 2016, of $2.00 billion, up 54 percent from $1.30 billion a year earlier, and up 40 percent from $1.43 billion in the previous quarter.

[0001045810-16-000343:8k_2_02:10]
GAAP earnings per diluted share for the quarter were $0.83, up 89 percent from $0.44 a year ago and up 102 percent from $0.41 in the previous quarter. Non-GAAP earnings per diluted share were $0.94, up 104 percent from $0.46 a year earlier and up 77 percent from $0.53 in the previous quarter.

[0001045810-16-000343:8k_2_02:11]
“We had a breakout quarter - record revenue, record margins and record earnings were driven by strength across all product lines,” said Jen-Hsun Huang, founder and chief executive officer, NVIDIA. “Our new Pascal GPUs are fully ramped and enjoying great success in gaming, VR, self-driving cars and datacenter AI computing.

[0001045810-16-000343:8k_2_02:12]
“We have invested years of work and billions of dollars to advance deep learning. Our GPU deep learning platform runs every AI framework, and is available in cloud services from Amazon, IBM, Microsoft and Alibaba, and in servers from every OEM. GPU deep learning has sparked a wave of innovations that will usher in the next era of computing,” he said.

[0001045810-16-000343:8k_2_02:13]
Capital Return

[0001045810-16-000343:8k_2_02:14]
During the first nine months of fiscal 2017, NVIDIA paid $509 million in share repurchases and $185 million in cash dividends. As a result, the company has returned an aggregate of $694 million to shareholders in the first nine months of the fiscal year. The company intends to return $1.0 billion to shareholders in fiscal 2017.

[0001045810-16-000343:8k_2_02:15]
For fiscal 2018, NVIDIA intends to return $1.25 billion to shareholders through ongoing quarterly cash dividends and share repurchases. The company’s board of directors has authorized an additional $2.00 billion under the company’s stock repurchase program for a total of $2.96 billion available through the end of December 2020.

[0001045810-16-000343:8k_2_02:16]
The company announced a 22 percent increase in its quarterly cash dividend to $0.14 per share from $0.115 per share, to be paid with its next quarterly cash dividend on December 19, 2016, to all shareholders of record on November 28, 2016.

[0001045810-16-000343:8k_2_02:17]
Q3 FY2017 Summary

[0001045810-16-000343:8k_2_02:18]
| GAAP |
| ($ in millions except earnings per share) | Q3 FY17 | Q2 FY17 | Q3 FY16 | Q/Q | Y/Y |
| Revenue | $2,004 | $1,428 | $1,305 | Up 40 % | Up 54 % |
| Gross margin | 59.0% | 57.9% | 56.3% | Up 110 bps | Up 270 bps |
| Operating expenses | $544 | $509 | $489 | Up 7 % | Up 11 % |
| Operating income | $639 | $317 | $245 | Up 102 % | Up 161 % |
| Net income* | $542 | $261 | $246 | Up 108 % | Up 120 % |
| Diluted earnings per share* | $0.83 | $0.41 | $0.44 | Up 102 % | Up 89 % |

[0001045810-16-000343:8k_2_02:19]
| Non-GAAP |
| ($ in millions except earnings per share) | Q3 FY17 | Q2 FY17 | Q3 FY16 | Q/Q | Y/Y |
| Revenue | $2,004 | $1,428 | $1,305 | Up 40 % | Up 54 % |
| Gross margin | 59.2% | 58.1% | 56.5% | Up 110 bps | Up 270 bps |
| Operating expenses | $478 | $448 | $430 | Up 7 % | Up 11 % |
| Operating income | $708 | $382 | $308 | Up 85 % | Up 130 % |
| Net income | $570 | $313 | $255 | Up 82 % | Up 124 % |
| Diluted earnings per share | $0.94 | $0.53 | $0.46 | Up 77 % | Up 104 % |

[0001045810-16-000343:8k_2_02:20]
* In the third quarter of fiscal 2017, NVIDIA adopted a new accounting standard (ASU 2016-09), which requires adjustments to be reflected beginning in fiscal 2017, including all fiscal quarters within the year. The primary impact of adoption was the recognition of excess tax benefits in the provision for income taxes rather than paid-in capital on the balance sheet.  Adoption of the new standard resulted in a GAAP diluted earnings per share benefit of $0.02 and $0.01 for the first and second quarters of fiscal 2017, respectively.

[0001045810-16-000343:8k_2_02:21]
NVIDIA’s outlook for the fourth quarter of fiscal 2017 is as follows:

[0001045810-16-000343:8k_2_02:22]
| • | Revenue is expected to be $2.10 billion, plus or minus two percent. |

[0001045810-16-000343:8k_2_02:23]
| • | GAAP and non-GAAP gross margins are expected to be 59.0 percent and 59.2 percent, respectively, plus or minus 50 basis points. |

[0001045810-16-000343:8k_2_02:24]
| • | GAAP operating expenses are expected to be approximately $572 million. Non-GAAP operating expenses are expected to be approximately $500 million. |

[0001045810-16-000343:8k_2_02:25]
| • | GAAP and non-GAAP tax rates for the fourth quarter of fiscal 2017 are both expected to be 20 percent, plus or minus one percent. |

[0001045810-16-000343:8k_2_02:26]
| • | Capital expenditures are expected to be approximately $45 million to $55 million. |

[0001045810-16-000343:8k_2_02:27]
Third Quarter Fiscal 2017 Highlights

[0001045810-16-000343:8k_2_02:28]
Gaming:

[0001045810-16-000343:8k_2_02:29]
| • | Announced that NVIDIA® gaming technology will power the Nintendo Switch home gaming system. |

[0001045810-16-000343:8k_2_02:30]
| • | Expanded its line of Pascal™ GPUs with GeForce® GTX 1050 and GTX 1050 Ti, letting new gamers discover the joy of GeForce PC gaming. |

[0001045810-16-000343:8k_2_02:31]
| • | Introduced GeForce GTX 1080, 1070 and 1060 for notebooks, giving gamers a state-of-the-art gaming platform in beautifully designed notebooks. |

[0001045810-16-000343:8k_2_02:32]
Datacenter:

[0001045810-16-000343:8k_2_02:33]
| • | Expanded the GPU Technology Conference with a world tour of eight cities that broadened its reach this year to 18,000 developers, researchers, scientists and others. |

[0001045810-16-000343:8k_2_02:34]
| • | Launched Tesla® P40 and P4 GPUs, and the NVIDIA TensorRT deep learning inferencing framework. These expand NVIDIA’s deep learning platform beyond training to speed up AI inferencing production workloads in hyperscale datacenters. |

[0001045810-16-000343:8k_2_02:35]
| • | Began shipping the NVIDIA DGX-1™ AI supercomputer to research organizations, including OpenAI, Germany’s DFKI and Switzerland’s ITSIA; to universities, including Stanford, New York University and UC Berkeley; and to multinationals, such as SAP. |

[0001045810-16-000343:8k_2_02:36]
| • | Announced a collaboration with Japan’s FANUC to implement AI to increase robotics productivity and bring new capabilities to automated factories. |

[0001045810-16-000343:8k_2_02:37]
Automotive:

[0001045810-16-000343:8k_2_02:38]
| • | Announced that its NVIDIA DRIVE™ PX 2 platform will power a new AutoPilot system in all of Tesla Motors’ factory produced vehicles - the Model S, Model X and upcoming Model 3. |

[0001045810-16-000343:8k_2_02:39]
| • | Unveiled its next-generation Tegra® processor, codenamed Xavier, an AI supercomputer on a chip for self-driving cars. |

[0001045810-16-000343:8k_2_02:40]
| • | Partnered with China’s Baidu to develop a self-driving, artificially intelligent car and mapping system. |

[0001045810-16-000343:8k_2_02:41]
| • | Announced an AI partnership with Europe’s TomTom to create a cloud-to-car mapping system for self-driving cars using NVIDIA DRIVE PX 2. |

[0001045810-16-000343:8k_2_02:42]
CFO Commentary

[0001045810-16-000343:8k_2_02:43]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-16-000343:8k_2_02:44]
Conference Call and Webcast Information

[0001045810-16-000343:8k_2_02:45]
NVIDIA will conduct a conference call with analysts and investors to discuss its third quarter fiscal 2017 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). To listen to the conference call, dial (877) 223-3864 in the United States or (574) 990-1377 internationally, and provide the following conference ID: 945 459 89. A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, http://investor.nvidia.com, and at www.streetevents.com. The webcast will be recorded and available for replay until the company’s conference call to discuss its financial results for its fourth quarter and fiscal year 2017.

[0001045810-16-000343:8k_2_02:46]
Non-GAAP Measures

[0001045810-16-000343:8k_2_02:47]
To supplement NVIDIA’s Condensed Consolidated Statements of Income and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP other income (expense), net, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, non-GAAP diluted shares, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, legal settlement costs, product warranty charge, acquisition-related costs, contributions, restructuring and other charges, gains from non-affiliated investments, interest expense related to amortization of debt discount, loss on early debt conversions, and the associated tax impact of these items, where applicable. Weighted average shares used in the non-GAAP diluted net income per share computation includes the anti-dilution impact of the company’s Note Hedge. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and its non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-16-000343:8k_2_02:48]
Keep Current on NVIDIA

[0001045810-16-000343:8k_2_02:49]
Subscribe to the NVIDIA blog, follow us on Facebook, Google+, Twitter, LinkedIn and Instagram, and view NVIDIA videos on YouTube and images on Flickr.

[0001045810-16-000343:8k_2_02:50]
About NVIDIA

[0001045810-16-000343:8k_2_02:51]
NVIDIA (NASDAQ: NVDA) is the AI computing company. Its invention of the GPU in 1999 sparked the growth of the PC gaming market, redefined modern computer graphics and revolutionized parallel computing. More recently, GPU deep learning ignited modern AI - the next era of computing - with the GPU acting as the brain of computers, robots and self-driving cars that can perceive and understand the world. More information at http://nvidianews.nvidia.com/.

[0001045810-16-000343:8k_2_02:52]
###

[0001045810-16-000343:8k_2_02:53]
For further information, contact:

[0001045810-16-000343:8k_2_02:54]
| Arnab Chanda |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 566-6616 |  | (408) 566-5150 |
| achanda@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-16-000343:8k_2_02:55]
Certain statements in this press release including, but not limited to statements as to: strength across all product lines; Pascal GPUs enjoying great success; the availability of the company’s GPU deep learning platform; the impact of GPU deep learning; the company’s intended capital return for fiscal 2017 and fiscal 2018; the company’s next quarterly cash dividend; the company’s financial outlook for the fourth quarter of fiscal 2017; the company’s tax rates for the fourth quarter of fiscal 2017; and the impact and benefits of NVIDIA gaming technology, GeForce GTX GPUs, Tesla P40 and P4 GPUs, TensorRT, the collaboration with FANUC, DRIVE PX 2, the partnership with Baidu and the AI partnership with TomTom are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-Q for the fiscal period ended July 31, 2016. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-16-000343:8k_2_02:56]
© 2016 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, Tegra, Tesla, NVIDIA DGX-1, NVIDIA DRIVE, and Pascal are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-16-000343:8k_2_02:57]
NVIDIA CORPORATION

[0001045810-16-000343:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-16-000343:8k_2_02:59]
(In millions, except per share data)

[0001045810-16-000343:8k_2_02:60]
(Unaudited)

[0001045810-16-000343:8k_2_02:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue | $ | 2,004 |  |  | $ | 1,305 |  |  | $ | 4,737 |  |  | $ | 3,609 |  |
| Cost of revenue | 821 |  |  | 571 |  |  | 1,977 |  |  | 1,589 |  |
| Gross profit | 1,183 |  |  | 734 |  |  | 2,760 |  |  | 2,020 |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 373 |  |  | 329 |  |  | 1,069 |  |  | 987 |  |
| Sales, general and administrative | 171 |  |  | 152 |  |  | 487 |  |  | 441 |  |
| Restructuring and other charges | — |  |  | 8 |  |  | 3 |  |  | 97 |  |
| Total operating expenses | 544 |  |  | 489 |  |  | 1,559 |  |  | 1,525 |  |
| Income from operations | 639 |  |  | 245 |  |  | 1,201 |  |  | 495 |  |
| Interest income | 14 |  |  | 9 |  |  | 37 |  |  | 28 |  |
| Interest expense | (16 | ) |  | (12 | ) |  | (39 | ) |  | (35 | ) |
| Other income (expense), net | (16 | ) |  | 3 |  |  | (19 | ) |  | 1 |  |
| Income before income tax expense | 621 |  |  | 245 |  |  | 1,180 |  |  | 489 |  |
| Income tax expense (benefit) | 79 |  |  | (1 | ) |  | 168 |  |  | 83 |  |
| Net income | $ | 542 |  |  | $ | 246 |  |  | $ | 1,012 |  |  | $ | 406 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.01 |  |  | $ | 0.45 |  |  | $ | 1.89 |  |  | $ | 0.75 |  |
| Diluted | $ | 0.83 |  |  | $ | 0.44 |  |  | $ | 1.59 |  |  | $ | 0.72 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
| Basic | 538 |  |  | 542 |  |  | 536 |  |  | 544 |  |
| Diluted | 653 |  |  | 565 |  |  | 636 |  |  | 563 |  |

[0001045810-16-000343:8k_2_02:62]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  | October 30, |  | January 31, |
|  |  |  | 2016 |  | 2016 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 6,671 |  |  | $ | 5,037 |  |
|  | Accounts receivable, net |  | 833 |  |  | 505 |  |
|  | Inventories |  | 679 |  |  | 418 |  |
|  | Prepaid expenses and other current assets |  | 124 |  |  | 93 |  |
|  | Total current assets |  | 8,307 |  |  | 6,053 |  |
| Property and equipment, net |  | 503 |  |  | 466 |  |
| Goodwill |  | 618 |  |  | 618 |  |
| Intangible assets, net |  | 120 |  |  | 166 |  |
| Other assets |  | 64 |  |  | 67 |  |
|  | Total assets |  | $ | 9,612 |  |  | $ | 7,370 |  |
| LIABILITIES, CONVERTIBLE DEBT CONVERSION OBLIGATION AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 523 |  |  | $ | 296 |  |
|  | Accrued and other current liabilities |  | 507 |  |  | 642 |  |
|  | Convertible short-term debt |  | 1,011 |  |  | 1,413 |  |
|  | Total current liabilities |  | 2,041 |  |  | 2,351 |  |
| Long-term debt |  | 1,982 |  |  | — |  |
| Other long-term liabilities |  | 213 |  |  | 453 |  |
| Capital lease obligations, long-term |  | 7 |  |  | 10 |  |
|  | Total liabilities |  | 4,243 |  |  | 2,814 |  |
| Convertible debt conversion obligation |  | 45 |  |  | 87 |  |
| Shareholders' equity |  | 5,324 |  |  | 4,469 |  |
|  | Total liabilities, convertible debt conversion obligation and shareholders' equity |  | $ | 9,612 |  |  | $ | 7,370 |  |

[0001045810-16-000343:8k_2_02:63]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In millions, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | July 31, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP gross profit |  | $ | 1,183 |  |  | $ | 826 |  |  | $ | 734 |  |  | $ | 2,760 |  |  | $ | 2,020 |  |
| GAAP gross margin |  | 59.0 | % |  | 57.9 | % |  | 56.3 | % |  | 58.3 | % |  | 56.0 | % |
| Stock-based compensation expense (A) |  | 3 |  |  | 4 |  |  | 4 |  |  | 11 |  |  | 10 |  |
| Legal settlement costs (B) |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Product warranty charge (C) |  | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |
| Non-GAAP gross profit |  | $ | 1,186 |  |  | $ | 830 |  |  | $ | 738 |  |  | $ | 2,781 |  |  | $ | 2,045 |  |
| Non-GAAP gross margin |  | 59.2 | % |  | 58.1 | % |  | 56.5 | % |  | 58.7 | % |  | 56.7 | % |
| GAAP operating expenses |  | $ | 544 |  |  | $ | 509 |  |  | $ | 489 |  |  | $ | 1,559 |  |  | $ | 1,525 |  |
| Stock-based compensation expense (A) |  | (62 | ) |  | (54 | ) |  | (47 | ) |  | (166 | ) |  | (134 | ) |
| Legal settlement costs (B) |  | — |  |  | — |  |  | — |  |  | (6 | ) |  | — |  |
| Acquisition-related costs (D) |  | (4 | ) |  | (4 | ) |  | (4 | ) |  | (12 | ) |  | (18 | ) |
| Contributions |  | — |  |  | (1 | ) |  | — |  |  | (4 | ) |  | — |  |
| Restructuring and other charges |  | — |  |  | (2 | ) |  | (8 | ) |  | (3 | ) |  | (97 | ) |
| Non-GAAP operating expenses |  | $ | 478 |  |  | $ | 448 |  |  | $ | 430 |  |  | $ | 1,368 |  |  | $ | 1,276 |  |
| GAAP income from operations |  | $ | 639 |  |  | $ | 317 |  |  | $ | 245 |  |  | $ | 1,201 |  |  | $ | 495 |  |
| Total impact of non-GAAP adjustments to income from operations |  | 69 |  |  | 65 |  |  | 63 |  |  | 211 |  |  | 274 |  |
| Non-GAAP income from operations |  | $ | 708 |  |  | $ | 382 |  |  | $ | 308 |  |  | $ | 1,412 |  |  | $ | 769 |  |
| GAAP other income (expense), net |  | $ | (18 | ) |  | $ | — |  |  | $ | — |  |  | $ | (21 | ) |  | $ | (6 | ) |
| Gains from non-affiliated investments |  | — |  |  | — |  |  | (4 | ) |  | (3 | ) |  | (4 | ) |
| Interest expense related to amortization of debt discount |  | 6 |  |  | 7 |  |  | 7 |  |  | 20 |  |  | 21 |  |
| Loss on early debt conversions |  | 15 |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Non-GAAP other income (expense), net |  | $ | 3 |  |  | $ | 7 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 11 |  |
| GAAP net income* |  | $ | 542 |  |  | $ | 261 |  |  | $ | 246 |  |  | $ | 1,012 |  |  | $ | 406 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 90 |  |  | 72 |  |  | 66 |  |  | 243 |  |  | 291 |  |
| Income tax impact of non-GAAP adjustments |  | (62 | ) |  | (20 | ) |  | (57 | ) |  | (108 | ) |  | (65 | ) |
| Non-GAAP net income |  | $ | 570 |  |  | $ | 313 |  |  | $ | 255 |  |  | $ | 1,147 |  |  | $ | 632 |  |

[0001045810-16-000343:8k_2_02:64]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | July 31, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |  |
| GAAP* |  | $ | 0.83 |  |  | $ | 0.41 |  |  | $ | 0.44 |  |  | $ | 1.59 |  |  | $ | 0.72 |  |
| Non-GAAP |  | $ | 0.94 |  |  | $ | 0.53 |  |  | $ | 0.46 |  |  | $ | 1.93 |  |  | $ | 1.13 |  |
| Weighted average shares used in diluted net income per share computation |  |  |  |  |  |  |  |  |  |  |
| GAAP* |  | 653 |  |  | 634 |  |  | 565 |  |  | 636 |  |  | 563 |  |
| Anti-dilution impact from note hedge (E) |  | (45 | ) |  | (43 | ) |  | (10 | ) |  | (42 | ) |  | (6 | ) |
| Non-GAAP |  | 608 |  |  | 591 |  |  | 555 |  |  | 594 |  |  | 557 |  |
| GAAP net cash provided by operating activities* |  | $ | 432 |  |  | $ | 201 |  |  | $ | 255 |  |  | $ | 951 |  |  | $ | 664 |  |
| Purchase of property and equipment and intangible assets |  | (38 | ) |  | (33 | ) |  | (16 | ) |  | (125 | ) |  | (71 | ) |
| Free cash flow |  | $ | 394 |  |  | $ | 168 |  |  | $ | 239 |  |  | $ | 826 |  |  | $ | 593 |  |

[0001045810-16-000343:8k_2_02:65]
* In third quarter of fiscal 2017, NVIDIA adopted an accounting standard (ASU 2016-09), which requires adjustments to be reflected beginning in fiscal 2017, including all fiscal quarters within the year.

[0001045810-16-000343:8k_2_02:66]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | July 31, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenue |  | $ | 3 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 10 |  |
| Research and development |  | $ | 35 |  |  | $ | 30 |  |  | $ | 28 |  |  | $ | 95 |  |  | $ | 82 |  |
| Sales, general and administrative |  | $ | 27 |  |  | $ | 24 |  |  | $ | 19 |  |  | $ | 71 |  |  | $ | 53 |  |
| (B) Legal settlement with Advanced Silicon Technologies LLC and other settlement related costs. |
| (C) Represents warranty charge associated with a product recall. |
| (D) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (E) Represents the number of shares that would be delivered upon conversion of the currently outstanding 1.00% Convertible Senior Notes Due 2018. Under GAAP, shares delivered in hedge transactions are not considered offsetting shares in the fully diluted share calculation until actually delivered. |

[0001045810-16-000343:8k_2_02:67]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q4 FY2017 Outlook |
| GAAP gross margin |  | 59.0 | % |
|  | Impact of stock-based compensation expense |  | 0.2 | % |
| Non-GAAP gross margin |  | 59.2 | % |
|  |  |  | Q4 FY2017 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 572 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | (72 | ) |
| Non-GAAP operating expenses |  | $ | 500 |  |
