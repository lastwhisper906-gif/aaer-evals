# NVDA notes — 0001045810-16-000353


## nvda:BalanceSheetComponentsTextBlock

[0001045810-16-000353:notes:1]
[same as prior period, unchanged from 0001045810-16-000300:notes:1]

[0001045810-16-000353:notes:2]
[same as prior period, unchanged from 0001045810-16-000300:notes:2]

[0001045810-16-000353:notes:3]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
| Inventories: | (In millions) |
| Raw materials | $ | 203 |  |  | $ | 105 |  |
| Work in-process | 203 |  |  | 103 |  |
| Finished goods | 273 |  |  | 210 |  |
| Total inventories | $ | 679 |  |  | $ | 418 |  |

[0001045810-16-000353:notes:4]
As of October 30, 2016, we had outstanding inventory purchase obligations totaling $908 million.

[0001045810-16-000353:notes:5]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
| Accrued and Other Current Liabilities: | (In millions) |
| Customer related liabilities (1) | $ | 175 |  |  | $ | 160 |  |
| Deferred revenue | 170 |  |  | 322 |  |
| Accrued payroll and related expenses | 79 |  |  | 79 |  |
| Accrued restructuring and other charges (2) | 13 |  |  | 23 |  |
| Professional service fees | 13 |  |  | 23 |  |
| Coupon interest on notes | 12 |  |  | 3 |  |
| Income taxes payable | 9 |  |  | 2 |  |
| Warranty accrual (3) | 8 |  |  | 11 |  |
| Contributions payable | 4 |  |  | 3 |  |
| Leases payable | 4 |  |  | 4 |  |
| Accrued royalties | 4 |  |  | 1 |  |
| Other | 16 |  |  | 11 |  |
| Total accrued and other current liabilities | $ | 507 |  |  | $ | 642 |  |

[0001045810-16-000353:notes:6]
[same as prior period, unchanged from 0001045810-16-000300:notes:6]

[0001045810-16-000353:notes:7]
[same as prior period, unchanged from 0001045810-16-000300:notes:7]

[0001045810-16-000353:notes:8]
[same as prior period, unchanged from 0001045810-16-000300:notes:8]

[0001045810-16-000353:notes:9]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
| Other Long-Term Liabilities: | (In millions) |
| Deferred income tax liability (1) | $ | 88 |  |  | $ | 301 |  |
| Income taxes payable | 85 |  |  | 78 |  |
| Contributions payable | 13 |  |  | 13 |  |
| Interest rate swap (2) | 9 |  |  | 7 |  |
| Deferred revenue (3) | 2 |  |  | 44 |  |
| Other | 16 |  |  | 10 |  |
| Total other long-term liabilities | $ | 213 |  |  | $ | 453 |  |

[0001045810-16-000353:notes:10]
| (1) | Please refer to the “Recently Adopted Accounting Pronouncement” section of Note 1 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding the impact of a recently adopted accounting pronouncement on deferred taxes. |

[0001045810-16-000353:notes:11]
| (2) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |

[0001045810-16-000353:notes:12]
| (3) | Deferred revenue under our patent cross licensing agreement with Intel Corporation is now located in short term deferred revenue as less than twelve months remains on the agreement. |


## nvda:ScheduleofAccountReceivablefromMajorCustomersTableTextBlock

[0001045810-16-000353:notes:13]
|  |  | October 30, |  | January 31, |
|  |  | 2016 |  | 2016 |
| Accounts Receivable: |  |  |  |  |
| Customer B |  | 18 | % |  | 21 | % |
| Customer C |  | 12 | % |  | 3 | % |


## nvda:ScheduleofRevenuebyMajorMarketsTableTextBlock

[0001045810-16-000353:notes:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Gaming | $ | 1,244 |  |  | $ | 761 |  |  | $ | 2,712 |  |  | $ | 2,008 |  |
| Professional Visualization | 207 |  |  | 190 |  |  | 610 |  |  | 547 |  |
| Datacenter | 240 |  |  | 82 |  |  | 534 |  |  | 242 |  |
| Automotive | 127 |  |  | 79 |  |  | 359 |  |  | 227 |  |
| OEM & IP | 186 |  |  | 193 |  |  | 522 |  |  | 585 |  |
| Total revenue | $ | 2,004 |  |  | $ | 1,305 |  |  | $ | 4,737 |  |  | $ | 3,609 |  |


## nvda:SummaryofunearnedstockbasedcompensationexpenseTableTextBlock

[0001045810-16-000353:notes:15]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| Aggregate unearned stock-based compensation expense | $ | 662 |  |  | $ | 381 |  |
| Estimated weighted average amortization period | (In years) |
| Stock options | 0.7 |  |  | 1.1 |  |
| RSUs, PSUs and market-based PSUs | 2.8 |  |  | 2.7 |  |
| ESPP | 0.6 |  |  | 0.7 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-16-000353:notes:16]
|  | October 30, 2016 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In millions) |
| Corporate debt securities | $ | 2,239 |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 2,239 |  |
| Debt securities of United States government agencies | 1,152 |  |  | 1 |  |  | (1 | ) |  | 1,152 |  |
| Debt securities issued by United States Treasury | 770 |  |  | 1 |  |  | (1 | ) |  | 770 |  |
| Money market funds | 542 |  |  | — |  |  | — |  |  | 542 |  |
| Asset-backed securities | 436 |  |  | 1 |  |  | — |  |  | 437 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 162 |  |  | 2 |  |  | (1 | ) |  | 163 |  |
| Foreign government bonds | 68 |  |  | — |  |  | — |  |  | 68 |  |
| Total | $ | 5,369 |  |  | $ | 7 |  |  | $ | (5 | ) |  | $ | 5,371 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 640 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 4,731 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 5,371 |  |

[0001045810-16-000353:notes:17]
[same as prior period, unchanged from 0001045810-16-000300:notes:16]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001045810-16-000353:notes:18]
[same as prior period, unchanged from 0001045810-16-000300:notes:17]

[0001045810-16-000353:notes:19]
[same as prior period, unchanged from 0001045810-16-000300:notes:18]

[0001045810-16-000353:notes:20]
[same as prior period, unchanged from 0001045810-16-000300:notes:19]

[0001045810-16-000353:notes:21]
[same as prior period, unchanged from 0001045810-16-000300:notes:20]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-16-000353:notes:22]
Commitments and Contingencies

[0001045810-16-000353:notes:23]
Operating Lease Financing Arrangement

[0001045810-16-000353:notes:24]
In fiscal year 2016, we began to construct a new headquarters building in Santa Clara, California, which is currently targeted for completion in the fourth quarter of fiscal year 2018. We are financing this construction under an off-balance sheet, build-to-suit operating lease arrangement. As a part of this arrangement, we leased the real property we own where the building will be constructed under a 99 year ground lease to a syndicate of banks and concurrently leased back the building under a real property lease.

[0001045810-16-000353:notes:25]
Under the real property lease, we pay rent, taxes, maintenance costs, utilities, insurance and other property related costs. The lease has an initial 7.5 year term expiring on December 19, 2022, consisting of an approximately 2.5 year construction period followed by a 5 year lease term. We have the option to renew this lease for up to three additional 5 year periods, subject to approval by the banks.

[0001045810-16-000353:notes:26]
We will oversee the construction of the headquarters building. The banks have committed to fund up to $380 million of costs relating to construction. Advances will be made periodically to reimburse us for construction costs we incur. Once construction is complete, the lease balance will remain static at the completed cost for the remaining duration of the lease term. During construction, accrued interest will be capitalized into the lease balance. Following construction, we will pay rent in the form of interest. We have guaranteed the obligations under the lease held by our subsidiary.

[0001045810-16-000353:notes:27]
During the term of the lease, we may elect to purchase the headquarters building for the amount of the banks’ investment in the building and any accrued but unpaid rent. At the end of the lease term, we may elect to buy the building for the outstanding balance on the maturity date or arrange for the cash sale of the building to an unaffiliated third party. The aggregate guarantee made by us under the lease is no more than 87.5% of the costs incurred in connection with the construction of the building. However, under certain default circumstances, the lease guarantee may be 100% of the banks’ investment in the building plus any and all accrued but unpaid interest and all other rent due and payable under the operative agreements.

[0001045810-16-000353:notes:28]
The operative agreements are subject to customary default provisions, including, for example, those relating to payment and performance defaults, and events of bankruptcy. We are also subject to financial covenants including a covenant to maintain a maximum total leverage ratio not to exceed 3.0 to 1.0 and a minimum interest coverage ratio in excess of 3.5 to 1.0 during the term. If certain events of default occur and are continuing under the operative agreements, the banks may accelerate repayment of their investment under the lease.

[0001045810-16-000353:notes:29]
Patent Infringement Cases

[0001045810-16-000353:notes:30]
In September 2014, NVIDIA filed complaints against Qualcomm, Inc. and various Samsung entities in both the United States International Trade Commission, or ITC, and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing. In November 2014, Samsung filed complaints against NVIDIA in the ITC and the United States District Court for the Eastern District of Virginia, alleging that NVIDIA infringed certain patents.

[0001045810-16-000353:notes:31]
NVIDIA and Samsung, and NVIDIA and Qualcomm, also challenged the validity of certain of each other’s patents through inter partes review before the United States Patent and Trademark Office.

[0001045810-16-000353:notes:32]
On April 28, 2016, NVIDIA and Samsung entered a binding memorandum of understanding which resolved all existing intellectual property disputes between the parties, and requires the immediate dismissal of all pending litigation between them. As a result of this agreement, on May 5, 2016, Samsung filed a Stipulation of Dismissal in the United States District Court for the Eastern District of Virginia. On May 11, 2016, NVIDIA voluntarily dismissed its petition to the United States Court of Appeals for the Federal Circuit to review the ITC’s decision in Investigation No. 337-TA-932. On May 12, 2016, NVIDIA voluntarily dismissed its Complaint in the United States District Court for the District of Delaware. On May 19, 2016, Samsung filed a Corrected Joint Motion to Terminate Investigation No. 337-TA-941. On June 16, 2016, the ITC granted the joint motion and terminated the ITC investigation. The parties have also moved to dismiss all pending inter partes reviews. Also as part of this agreement, NVIDIA and Samsung each received a license to a small number of patents of the other, but no portfolio license was granted nor was any compensation paid by either party. On June 28, 2016, NVIDIA and Samsung executed a settlement agreement based on the April 28, 2016 memorandum of understanding.

[0001045810-16-000353:notes:33]
NVIDIA’s dismissals on May 11, 2016 and May 12, 2016 also terminated its claims against Qualcomm.

[0001045810-16-000353:notes:34]
In December 2015, Advanced Silicon Technologies LLC filed complaints in the ITC and the United States District Court for the District of Delaware alleging infringement of certain patents relating to graphics processing and memory management. NVIDIA and Advanced Silicon Technologies resolved this litigation on April 22, 2016 and NVIDIA agreed to license the patents asserted and other patents owned and controlled by Advanced Silicon Technologies and certain of its affiliates. On April 27, 2016, NVIDIA and Advanced Silicon Technologies jointly moved to terminate the investigation as to NVIDIA. The Office of Unfair Import Investigations supported the motion, and none of the other parties opposed it. On May 10, 2016, the Administrative Law Judge issued an Initial Determination granting the joint request to terminate the investigation as to NVIDIA. On June 1, 2016, the ITC issued a Notice determining not to review the Administrative Law Judge’s determination, thereby finalizing termination of the investigation as to NVIDIA. Pursuant to the license agreement, $10 million was recorded as a charge to cost of revenue during the three months ended May 1, 2016.

[0001045810-16-000353:notes:35]
Accounting for Loss Contingencies

[0001045810-16-000353:notes:36]
We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-16-000353:notes:37]
[same as prior period, unchanged from 0001045810-16-000300:notes:36]

[0001045810-16-000353:notes:38]
[same as prior period, unchanged from 0001045810-16-000300:notes:37]


## us-gaap:ConvertibleDebtTableTextBlock

[0001045810-16-000353:notes:39]
The following table presents the carrying value of the Convertible Notes:

[0001045810-16-000353:notes:40]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| 1.00% Convertible Senior Notes Due 2018 | $ | 1,056 |  |  | $ | 1,500 |  |
| Unamortized debt discount (1) | (45 | ) |  | (87 | ) |
| Net carrying amount | $ | 1,011 |  |  | $ | 1,413 |  |

[0001045810-16-000353:notes:41]
(1) As of October 30, 2016, the remaining period over which the unamortized debt discount will be amortized is 2.1 years.

[0001045810-16-000353:notes:42]
The following table presents interest expense for the contractual interest and the accretion of debt discount and issuance costs related to the Convertible Notes:

[0001045810-16-000353:notes:43]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (In millions) |
| Contractual coupon interest expense |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 11 |  |
| Amortization of debt discount and issuance costs |  | 5 |  |  | 7 |  |  | 20 |  |  | 22 |  |
| Total interest expense related to Convertible Notes |  | $ | 8 |  |  | $ | 11 |  |  | $ | 30 |  |  | $ | 33 |  |


## us-gaap:DebtDisclosureTextBlock

[0001045810-16-000353:notes:44]
Debt

[0001045810-16-000353:notes:45]
Convertible Debt

[0001045810-16-000353:notes:46]
1.00 % Convertible Senior Notes Due 2018

[0001045810-16-000353:notes:47]
On December 2, 2013, we issued $1.50 billion of 1.00% convertible senior notes, or the Convertible Notes, due 2018. The Convertible Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Convertible Notes will mature on December 1, 2018 unless repurchased or converted prior to such date. The Convertible Notes were initially convertible at a rate of 49.5958 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an initial conversion price of $20.1630 per share of common stock). The conversion rate and conversion price are adjusted upon the occurrence of certain events, including our cash dividends or distributions exceeding $0.085 per share. Accordingly, as of October 30, 2016, the conversion rate has been adjusted to 49.8058 shares of common stock per $1,000 principal amount of the Convertible Notes (equivalent to an adjusted conversion price of $20.0780 per share of common stock) for dividend increases.

[0001045810-16-000353:notes:48]
We separately accounted for the liability and equity components of the Convertible Notes at issuance and the value assigned to the debt component was the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value represented the value assigned to the equity component and was recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-16-000353:notes:49]
The initial debt component of the Convertible Notes was valued at $1.35 billion based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The initial carrying value of the permanent equity component reported in additional paid-in-capital was valued at $126 million and recorded as a debt discount. This amount, together with the $23 million purchaser's discount to the par value of the Convertible Notes, represented the total unamortized debt discount of $148 million we recorded at the time of issuance of the Convertible Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Convertible Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-16-000353:notes:50]
Holders may convert all or any portion of their Convertible Notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter, if the last reported sale price of the common stock for at least 20 trading days during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their Convertible Notes regardless of the foregoing conditions.

[0001045810-16-000353:notes:51]
The Convertible Notes first became convertible as of February 1, 2016. As of October 30, 2016, the Convertible Notes continued to be convertible at the holders’ option through January 29, 2017 as the price of our common stock was greater than or equal to 130% of the conversion price for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of our fiscal quarter ended October 30, 2016. As such, the $1,011 million carrying value of the Convertible Notes continued to be classified as a current liability and the $45 million difference between the principal amount and the carrying value of the Convertible Notes continued to be classified as convertible debt conversion obligation in the mezzanine equity section of our Condensed Consolidated Balance Sheet, and will remain there for as long as the Convertible Notes are convertible. The determination of whether or not the Convertible Notes are convertible must continue to be performed on a quarterly basis. Consequently, the Convertible Notes may be reclassified as long-term debt and the convertible debt conversion obligation may be reclassified within shareholders' equity if the conversion threshold is not met in future quarters.

[0001045810-16-000353:notes:52]
Upon conversion of the Convertible Notes, we will pay cash up to the aggregate principal amount of the Convertible Notes. We may pay or deliver cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the Convertible Notes being converted. Based on the closing price of our common stock on October 28, 2016 (the last trading day of the third quarter of fiscal year 2017) of $70.56, the if-converted value of our Convertible Notes exceeded their principal amount by approximately $2.66 billion.

[0001045810-16-000353:notes:53]
During both the three and nine months ended October 30, 2016, we paid cash to settle $444 million in principal amount, issued 15 million shares of our common stock with respect to the conversion obligation in excess of the principal amount, and recognized a loss of $15 million on early conversions, of the Convertible Notes. Further, we received additional conversion notices for an aggregate of $229 million in principal amount of the Convertible Notes during the third quarter of fiscal year 2017. Settlements of these conversion requests are expected to be completed in the fourth quarter of fiscal year 2017.

[0001045810-16-000353:notes:54]
Note Hedges and Warrants

[0001045810-16-000353:notes:55]
Concurrently with the issuance of the Convertible Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Convertible Notes, or $20.1630 per share. Adjusting for dividends paid through October 30, 2016, the strike price of the Note Hedges has been adjusted to $20.0780 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would deliver and/or pay, respectively, to the holders of the Convertible Notes upon conversion. Through October 30, 2016, we had received 15 million shares of our common stock from the exercise of a portion of the Note Hedges related to the settlement of an aggregate of $444 million in principal amount of the Convertible Notes.

[0001045810-16-000353:notes:56]
In addition, concurrent with the offering of the Convertible Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with an initial strike price to the holders of the Warrants of $27.1425 per share. Under the terms of the Warrants, the strike price is adjusted upon the occurrence of certain events, including our cash dividends or distributions that deviate from $0.085 per share. Accordingly, as of October 30, 2016, the strike price was adjusted to $27.0281 per share, reflecting adjustments for our dividend increases made to that date. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 75 million shares of our common stock. As of October 30, 2016, the Warrants had not been exercised and remained outstanding. The value of the Warrants was initially recorded in equity and continues to be classified as equity.

[0001045810-16-000353:notes:57]
Long-Term Debt

[0001045810-16-000353:notes:58]
2.20% Notes Due 2021 and 3.20% Notes Due 2026

[0001045810-16-000353:notes:59]
On September 16, 2016, we issued $1.00 billion of 2.20% notes due September 16, 2021 and $1.00 billion of 3.20% notes due September 16, 2026 (collectively, the Notes). Interest on the Notes is payable on March 16 and September 16 of each year, beginning on March 16, 2017. Upon 30 days' notice to holders of the Notes, we may redeem the Notes for cash prior to maturity, at redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2.20% Notes Due 2021 on or after August 16, 2021, or for redemptions of the 3.20% Notes Due 2026 on or after June 16, 2026.

[0001045810-16-000353:notes:60]
The Notes are our unsecured senior obligations and rank equally in right of payment with all of our existing and future unsecured and unsubordinated indebtedness. The Notes are structurally subordinated to the liabilities of our subsidiaries and are effectively subordinated to any secured indebtedness to the extent of the value of the assets securing such indebtedness. All existing and future liabilities of our subsidiaries will be effectively senior to the Notes.

[0001045810-16-000353:notes:61]
The net proceeds from the Notes were $1.99 billion, after deducting debt discount and issuance costs. We intend to use the net proceeds from the Notes to prefund the repayment of the principal amount of our Convertible Notes and for general corporate purposes such as dividend payments or share repurchases.

[0001045810-16-000353:notes:62]
The carrying value of our long-term debt and the associated interest rates were as follows:

[0001045810-16-000353:notes:63]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | October 30,2016 |
|  |  |  |  |  |  | (In millions) |
| 2.20% Notes Due 2021 |  | 4.9 |  | 2.38% |  | $ | 1,000 |  |
| 3.20% Notes Due 2026 |  | 9.9 |  | 3.31% |  | 1,000 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (18 | ) |
| Net carrying amount |  |  |  |  |  | $ | 1,982 |  |

[0001045810-16-000353:notes:64]
Revolving Credit Facility

[0001045810-16-000353:notes:65]
On October 7, 2016, we entered into a credit agreement, or the Credit Agreement, under which we may borrow, repay and re-borrow amounts from time to time, up to $575 million, for working capital and other general corporate purposes. The commitments under the Credit Agreement are available for a 5-year period ending on October 7, 2021, on which all outstanding obligations would be due and payable. The Credit Agreement also permits us to obtain additional revolving loan commitments up to $425 million, subject to certain conditions. As of October 30, 2016, we had not borrowed any amounts under the Credit Agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-16-000353:notes:66]
[same as prior period, unchanged from 0001045810-16-000300:notes:55]

[0001045810-16-000353:notes:67]
In August 2015 we entered into an interest rate swap for a portion of the operating lease financing arrangement for our new headquarters building that entitles us to pay amounts based on a fixed interest rate in exchange for receipt of amounts based on variable interest rates. The objective of this interest rate swap is to mitigate variability in the benchmark interest rate on the first $200 million of existing operating lease financing payments. This interest rate swap is designated as a cash flow hedge, will have settlements beginning in the second quarter of fiscal year 2019, and will terminate in the fourth quarter of fiscal year 2023. Gains or losses on this swap are recorded in accumulated other comprehensive income or loss and will subsequently be recorded in earnings at the point when the related operating lease financing expense begins to affect earnings or if ineffectiveness of the swap should occur.

[0001045810-16-000353:notes:68]
During the three and nine months ended October 30, 2016, we entered into foreign currency forward contracts with a total U.S. dollar equivalent notional value of $64 million and $160 million, respectively, to mitigate the impact of foreign currency exchange rate movements on our operating expenses. We designate these contracts as cash flow hedges and assess the effectiveness of the hedge relationships on a spot to spot basis. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings or ineffectiveness should occur. The fair value of the contracts as of October 30, 2016 was not significant.

[0001045810-16-000353:notes:69]
During the three and nine months ended October 30, 2016, we also entered into foreign currency forward contracts with a total U.S. dollar equivalent notional value of $54 million and $67 million, respectively, to mitigate the impact of foreign currency movements on monetary assets and liabilities that are denominated in currencies other than our reporting currency. These foreign currency forward contracts were not designated for hedge accounting treatment. Therefore, the change in fair value of these contracts is recorded as a component of other income or expense, net, and offsets the change in fair value of the foreign currency denominated monetary assets and liabilities, which is also recorded in other income or expense, net.

[0001045810-16-000353:notes:70]
[same as prior period, unchanged from 0001045810-16-000300:notes:59]

[0001045810-16-000353:notes:71]
As of October 30, 2016, the maturities of the designated foreign currency forward contracts were three months or less.

[0001045810-16-000353:notes:72]
We formally assess, both at inception and on an ongoing basis, whether derivative financial instruments designated for hedge accounting treatment are highly effective. For the three and nine months ended October 30, 2016, all derivative financial instruments designated for hedge accounting treatment were determined to be highly effective and there were no gains or losses associated with ineffectiveness.

[0001045810-16-000353:notes:73]
During the three and nine months ended October 30, 2016, we recognized a net change in unrealized gains (losses) on derivative financial instruments designated for hedge accounting treatment of $2 million and $(3) million, respectively, net of tax, in other comprehensive income.

[0001045810-16-000353:notes:74]
We expect to realize all gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months. However, we do not expect to reclassify any amount from accumulated other comprehensive income or loss into earnings related to the interest rate swap as the underlying operating lease financing payments for our new headquarters building will not start within the next twelve months.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-16-000353:notes:75]
[same as prior period, unchanged from 0001045810-16-000300:notes:64]

[0001045810-16-000353:notes:76]
[same as prior period, unchanged from 0001045810-16-000300:notes:65]

[0001045810-16-000353:notes:77]
[same as prior period, unchanged from 0001045810-16-000300:notes:66]

[0001045810-16-000353:notes:78]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |  | October 30, 2016 |  | October 25, 2015 |
|  | (In millions) |
| Cost of revenue | $ | 2 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 10 |  |
| Research and development | 36 |  |  | 28 |  |  | 95 |  |  | 82 |  |
| Sales, general and administrative | 27 |  |  | 19 |  |  | 71 |  |  | 53 |  |
| Total | $ | 65 |  |  | $ | 51 |  |  | $ | 176 |  |  | $ | 145 |  |

[0001045810-16-000353:notes:79]
[same as prior period, unchanged from 0001045810-16-000300:notes:68]

[0001045810-16-000353:notes:80]
[same as prior period, unchanged from 0001045810-16-000300:notes:69]

[0001045810-16-000353:notes:81]
|  | RSUs, PSUs and Market-based PSUs Outstanding |  | Options Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |  | Number of Shares |  | Weighted Average Exercise Price Per Share |
|  | (In millions, except per share data) |
| Balances, January 31, 2016 | 26 |  |  | $ | 19.12 |  |  | 13 |  |  | $ | 14.49 |  |
| Granted (1) (2) | 11 |  |  | $ | 48.88 |  |  | — |  |  | $ | — |  |
| Exercised | — |  |  | $ | — |  |  | (4 | ) |  | $ | 14.44 |  |
| Vested restricted stock | (9 | ) |  | $ | 17.84 |  |  | — |  |  | $ | — |  |
| Canceled and forfeited | (1 | ) |  | $ | 21.58 |  |  | — |  |  | $ | — |  |
| Balances, October 30, 2016 | 27 |  |  | $ | 31.76 |  |  | 9 |  |  | $ | 14.52 |  |

[0001045810-16-000353:notes:82]
[same as prior period, unchanged from 0001045810-16-000300:notes:71]

[0001045810-16-000353:notes:83]
[same as prior period, unchanged from 0001045810-16-000300:notes:72]

[0001045810-16-000353:notes:84]
Of the total fair value of equity awards granted during the three and nine months ended October 30, 2016, the stock-based compensation expense related to equity awards that are not expected to vest was $72 million and $89 million, respectively. Of the total fair value of equity awards granted during the three and nine months ended October 30, 2015, the stock-based compensation expense related to equity awards that are not expected to vest was $34 million and $43 million, respectively.

[0001045810-16-000353:notes:85]
The following summarizes the aggregate unearned stock-based compensation expense and estimated weighted average amortization period as of October 30, 2016 and January 31, 2016:


## us-gaap:EarningsPerShareTextBlock

[0001045810-16-000353:notes:86]
[same as prior period, unchanged from 0001045810-16-000300:notes:75]

[0001045810-16-000353:notes:87]
[same as prior period, unchanged from 0001045810-16-000300:notes:76]

[0001045810-16-000353:notes:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 542 |  |  | $ | 246 |  |  | $ | 1,012 |  |  | $ | 406 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 538 |  |  | 542 |  |  | 536 |  |  | 544 |  |
| Dilutive impact of outstanding securities: |  |  |  |  |  |  |  |
| Equity awards outstanding | 27 |  |  | 13 |  |  | 25 |  |  | 13 |  |
| 1% Convertible Senior Notes | 45 |  |  | 10 |  |  | 42 |  |  | 6 |  |
| Warrants issued with the 1% Convertible Senior Notes | 43 |  |  | — |  |  | 33 |  |  | — |  |
| Diluted weighted average shares | 653 |  |  | 565 |  |  | 636 |  |  | 563 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 1.01 |  |  | $ | 0.45 |  |  | $ | 1.89 |  |  | $ | 0.75 |  |
| Diluted (2) | $ | 0.83 |  |  | $ | 0.44 |  |  | $ | 1.59 |  |  | $ | 0.72 |  |
| Equity awards excluded from diluted net income per share because their effect would have been anti-dilutive | 7 |  |  | 9 |  |  | 9 |  |  | 13 |  |

[0001045810-16-000353:notes:89]
[same as prior period, unchanged from 0001045810-16-000300:notes:78]

[0001045810-16-000353:notes:90]
[same as prior period, unchanged from 0001045810-16-000300:notes:79]

[0001045810-16-000353:notes:91]
The 1.00% Convertible Senior Notes, or the Convertible Notes, are included in the calculation of diluted net income per share. The Convertible Notes have a dilutive impact on net income per share if our average stock price for the reporting period exceeds the adjusted conversion price of $20.0780 per share. The Warrants outstanding are included in the calculation of diluted net income per share. The Warrants have a dilutive impact on net income per share if our average stock price for the quarter exceeds the adjusted strike price of $27.0281 per share. For the three and nine months ended October 30, 2016, our average stock price was $63.83 and $47.82, respectively, which exceeded both the adjusted conversion price and the adjusted strike price, causing the Convertible Notes and the Warrants to have a dilutive impact for these periods.

[0001045810-16-000353:notes:92]
The denominator for diluted net income per share does not include any effect from the convertible note hedge transactions, or the Note Hedges, that we entered into concurrently with the issuance of the Convertible Notes, as its effect would be anti-dilutive. In the event of conversion of the Convertible Notes, the shares delivered to us under the Note Hedges will offset the dilutive effect of the shares that we would issue under the Convertible Notes. Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Convertible Notes.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001045810-16-000353:notes:93]
|  |  | Estimated Fair Value at |
|  | Pricing Category |  | October 30, 2016 |  | January 31, 2016 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Corporate debt securities (1) | Level 2 |  | $ | 2,239 |  |  | $ | 1,901 |  |
| Debt securities of United States government agencies (2) | Level 2 |  | $ | 1,152 |  |  | $ | 1,170 |  |
| Debt securities issued by United States Treasury (3) | Level 2 |  | $ | 770 |  |  | $ | 801 |  |
| Money market funds (4) | Level 1 |  | $ | 542 |  |  | $ | 43 |  |
| Asset-backed securities (5) | Level 2 |  | $ | 437 |  |  | $ | 435 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises (5) | Level 2 |  | $ | 163 |  |  | $ | 231 |  |
| Foreign government bonds (5) | Level 2 |  | $ | 68 |  |  | $ | 92 |  |
| Liabilities |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| 1.00% Convertible Senior Notes (6) | Level 2 |  | $ | 3,725 |  |  | $ | 2,273 |  |
| Other noncurrent liabilities: |  |  |  |  |  |
| 2.20% Notes Due 2021 (6) | Level 2 |  | $ | 997 |  |  | $ | — |  |
| 3.20% Notes Due 2026 (6) | Level 2 |  | $ | 997 |  |  | $ | — |  |
| Interest rate swap (7) | Level 2 |  | $ | 9 |  |  | $ | 7 |  |

[0001045810-16-000353:notes:94]
| (1) | Included $35 million and $51 million in cash equivalents as of October 30, 2016 and January 31, 2016, respectively, and $2.20 billion and $1.85 billion in marketable securities as of October 30, 2016 and January 31, 2016, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000353:notes:95]
| (2) | Included $38 million and $90 million in cash equivalents as of October 30, 2016 and January 31, 2016, respectively, and $1.11 billion and $1.08 billion in marketable securities as of October 30, 2016 and January 31, 2016, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000353:notes:96]
| (3) | Included $25 million in cash equivalents as of October 30, 2016 and $745 million and $801 million in marketable securities as of October 30, 2016 and January 31, 2016, respectively, on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000353:notes:97]
[same as prior period, unchanged from 0001045810-16-000300:notes:86]

[0001045810-16-000353:notes:98]
| (5) | Reported in marketable securities on the Condensed Consolidated Balance Sheets. |

[0001045810-16-000353:notes:99]
| (6) | The Convertible Notes, 2.20% Notes Due 2021, and 3.20% Notes Due 2026 are carried on our Condensed Consolidated Balance Sheets at their original issuance value, net of unamortized debt discount and issuance costs, and are not marked to fair value each period. See Note 11 of these Notes to Condensed Consolidated Financial Statements for additional information. |

[0001045810-16-000353:notes:100]
| (7) | Please refer to Note 9 of these Notes to Condensed Consolidated Financial Statements for a discussion regarding our interest rate swap. |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-16-000353:notes:101]
[same as prior period, unchanged from 0001045810-16-000300:notes:89]

[0001045810-16-000353:notes:102]
We measure our cash equivalents, marketable securities, and interest rate swap at fair value using quoted market prices of identical assets or similar assets from active markets. We review the fair value hierarchy classification on a quarterly basis. There were no significant transfers between Levels 1 and 2 assets or liabilities for the three months ended October 30, 2016, and we did not have any investments or liabilities classified as Level 3 as of October 30, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-16-000353:notes:103]
[same as prior period, unchanged from 0001045810-16-000300:notes:91]

[0001045810-16-000353:notes:104]
We recognized income tax expense of $79 million and $168 million for the three and nine months ended October 30, 2016, respectively, and $83 million for the nine months ended October 25, 2015. We recognized income tax benefit of $1 million for the three months ended October 25, 2015. Income tax expense as a percentage of income before income tax was 12.8% and 14.2% for the three and nine months ended October 30, 2016, respectively, and 16.9% for the nine months ended October 25, 2015. Income tax benefit as a percentage of income before income tax was 0.5% for the three months ended October 25, 2015. Our income tax expense includes $42 million and $62 million of tax benefit for the three and nine months ended October 30, 2016, respectively, from the early adoption of an accounting standard related to stock-based compensation. Please refer to Note 1 of these Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-16-000353:notes:105]
The increase in our effective tax rate in the three months ended October 30, 2016 compared to the same period in the prior fiscal year was primarily due to the absence of the tax benefit related to the restructuring associated with the wind-down of our Icera operations. The decrease in our effective tax rate in the nine months ended October 30, 2016 compared to the same period in the prior fiscal year was primarily due to the favorable benefit of the U.S. federal research tax credit, which was permanently enacted in the fourth quarter of fiscal year 2016, and our early adoption of an accounting standard, partially offset by the absence of the Icera restructuring tax benefit and an increase in the amount of our earnings subject to U.S. tax.

[0001045810-16-000353:notes:106]
Our effective tax rate for the nine months ended October 30, 2016 of 14.2% was lower than the U.S. federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the U.S. federal statutory tax rate, the benefit of the U.S. federal research tax credit, as well as tax benefits recognized in the period in which they occur for early adoption of an accounting standard and expiration of statutes of limitations in certain non-U.S. jurisdictions.

[0001045810-16-000353:notes:107]
For the nine months ended October 30, 2016, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no material changes to our unrecognized tax benefits and any related interest or penalties since the fiscal year ended January 31, 2016, other than the closure of our state income tax position in the three months ended July 31, 2016 and the aforementioned recognition of tax benefits upon the expiration of statutes of limitations in certain non-U.S. jurisdictions in the nine months ended October 30, 2016.

[0001045810-16-000353:notes:108]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of October 30, 2016, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-16-000353:notes:109]
[same as prior period, unchanged from 0001045810-16-000300:notes:97]

[0001045810-16-000353:notes:110]
[same as prior period, unchanged from 0001045810-16-000300:notes:98]

[0001045810-16-000353:notes:111]
|  | October 30, 2016 |  | January 31, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 193 |  |  | $ | (163 | ) |  | $ | 30 |  |  | $ | 193 |  |  | $ | (152 | ) |  | $ | 41 |  |
| Patents and licensed technology | 469 |  |  | (379 | ) |  | 90 |  |  | 462 |  |  | (337 | ) |  | 125 |  |
| Total intangible assets | $ | 662 |  |  | $ | (542 | ) |  | $ | 120 |  |  | $ | 655 |  |  | $ | (489 | ) |  | $ | 166 |  |

[0001045810-16-000353:notes:112]
Amortization expense associated with intangible assets was $18 million and $53 million for the three and nine months ended October 30, 2016, respectively, and $18 million and $56 million for the three and nine months ended October 25, 2015, respectively. Future amortization expense related to the net carrying amount of intangible assets as of October 30, 2016 is estimated to be $16 million for the remainder of fiscal year 2017, $54 million in fiscal year 2018, $26 million in fiscal year 2019, $16 million in fiscal year 2020, $7 million in fiscal year 2021 and a total of $1 million in fiscal year 2022 and beyond.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-16-000353:notes:113]
|  | October 30, 2016 |  | January 31, 2016 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In millions) |
| Less than 1 year | $ | 2,346 |  |  | $ | 2,347 |  |  | $ | 1,619 |  |  | $ | 1,619 |  |
| Due in 1 - 5 years | 2,967 |  |  | 2,968 |  |  | 3,019 |  |  | 3,020 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises not due at a single maturity date | 56 |  |  | 56 |  |  | 34 |  |  | 34 |  |
| Total | $ | 5,369 |  |  | $ | 5,371 |  |  | $ | 4,672 |  |  | $ | 4,673 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-16-000353:notes:114]
[same as prior period, unchanged from 0001045810-16-000300:notes:102]

[0001045810-16-000353:notes:115]
[same as prior period, unchanged from 0001045810-16-000300:notes:103]

[0001045810-16-000353:notes:116]
We performed an impairment review of our investment portfolio as of October 30, 2016. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and that no other-than-temporary impairment charges were necessary on our portfolio of available-for-sale investments as of October 30, 2016.

[0001045810-16-000353:notes:117]
The following is a summary of cash equivalents and marketable securities as of October 30, 2016 and January 31, 2016:

[0001045810-16-000353:notes:118]
The following table provides the breakdown of the investments with unrealized losses as of October 30, 2016:

[0001045810-16-000353:notes:119]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |  | Estimated Fair Value |  | GrossUnrealizedLosses |
|  | (In millions) |
| Corporate debt securities | $ | 977 |  |  | $ | (2 | ) |  | $ | 58 |  |  | $ | — |  |  | $ | 1,035 |  |  | $ | (2 | ) |
| Debt securities issued by United States government agencies | 536 |  |  | (1 | ) |  | 27 |  |  | — |  |  | 563 |  |  | (1 | ) |
| Debt securities issued by the US Treasury | 197 |  |  | (1 | ) |  | — |  |  | — |  |  | 197 |  |  | (1 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 43 |  |  | — |  |  | 36 |  |  | (1 | ) |  | 79 |  |  | (1 | ) |
|  | $ | 1,753 |  |  | $ | (4 | ) |  | $ | 121 |  |  | $ | (1 | ) |  | $ | 1,874 |  |  | $ | (5 | ) |

[0001045810-16-000353:notes:120]
The gross unrealized losses as of October 30, 2016 related to fixed income securities due to changes in interest rates and are temporary in nature. We have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-16-000353:notes:121]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale as of October 30, 2016 and January 31, 2016 and are shown below by contractual maturity:

[0001045810-16-000353:notes:122]
Net realized gains and losses were not significant for the three and nine months ended October 30, 2016 and October 25, 2015.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001045810-16-000353:notes:123]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-16-000353:notes:124]
Recently Adopted Accounting Pronouncement

[0001045810-16-000353:notes:125]
In March 2016, the Financial Accounting Standards Board, or FASB, issued an accounting standards update which simplifies certain aspects of stock-based compensation accounting. Among other elements, the new guidance eliminates additional paid in capital, or APIC, pools and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The new standard is effective for us beginning in our first quarter of fiscal year 2018 with early adoption permitted. We elected to early adopt this new guidance in the third quarter of fiscal year 2017, which required us to reflect any adjustments as of February 1, 2016.

[0001045810-16-000353:notes:126]
Early adoption of this guidance resulted in the following:

[0001045810-16-000353:notes:127]
| • | We recorded excess tax benefits within income tax expense, rather than in APIC, of $12 million, $8 million and $42 million for the first, second and third quarters of fiscal year 2017, respectively. |

[0001045810-16-000353:notes:128]
| • | We recorded a cumulative-effect adjustment as of February 1, 2016 to increase retained earnings by $353 million, with a corresponding increase to deferred tax assets, to recognize the net operating loss and federal research tax credit carryforwards attributable to excess tax benefits on stock-based compensation that had not been previously recognized in APIC. |

[0001045810-16-000353:notes:129]
| • | The excess tax benefits are now included in net operating cash rather than net financing cash in our Condensed Consolidated Statements of Cash Flows. We elected to apply this change in presentation prospectively and thus prior periods have not been adjusted. |

[0001045810-16-000353:notes:130]
We elected not to change our policy on accounting for forfeitures, although the new guidance provides an option for us to account for forfeitures as they occur, and thus continued to estimate forfeitures expected to occur to determine the amount of compensation cost to be recognized in each period.

[0001045810-16-000353:notes:131]
The adoption of this new guidance impacted our previously reported quarterly results for fiscal year 2017 as follows:

[0001045810-16-000353:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2016 |  | May 1, 2016 |  | July 31, 2016 |
|  | As reported |  | As adjusted |  | As reported |  | As adjusted |  | As reported |  | As adjusted |
|  | (In millions, except per share data) |
| Condensed Consolidated Statements of Income: |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | $ | 64 |  |  | $ | 56 |  |  | $ | 45 |  |  | $ | 33 |  |  | $ | 109 |  |  | $ | 89 |  |
| Net income | $ | 253 |  |  | $ | 261 |  |  | $ | 196 |  |  | $ | 208 |  |  | $ | 449 |  |  | $ | 469 |  |
| Basic net income per share | $ | 0.47 |  |  | $ | 0.49 |  |  | $ | 0.36 |  |  | $ | 0.39 |  |  | $ | 0.84 |  |  | $ | 0.88 |  |
| Diluted net income per share | $ | 0.40 |  |  | $ | 0.41 |  |  | $ | 0.33 |  |  | $ | 0.35 |  |  | $ | 0.73 |  |  | $ | 0.76 |  |
| Weighted average shares used in diluted net income per share computation | 631 |  |  | 634 |  |  | 597 |  |  | 599 |  |  | 617 |  |  | 620 |  |
| Condensed Consolidated Statements of Cash Flows: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 184 |  |  | $ | 201 |  |  | $ | 309 |  |  | $ | 318 |  |  | $ | 493 |  |  | $ | 519 |  |
| Net cash used in financing activities | $ | (35 | ) |  | $ | (52 | ) |  | $ | (534 | ) |  | $ | (545 | ) |  | $ | (570 | ) |  | $ | (597 | ) |

[0001045810-16-000353:notes:133]
Recent Accounting Pronouncements Not Yet Adopted

[0001045810-16-000353:notes:134]
In October 2016, the FASB issued an accounting standards update that requires the recognition of income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not currently expected to have a material impact on our consolidated financial statements.

[0001045810-16-000353:notes:135]
In August 2016, the FASB issued an accounting standards update that clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The update will be effective for us beginning in our first quarter of fiscal year 2019, with early adoption permitted. The adoption of this accounting guidance is not expected to have a material impact on our consolidated financial statements.

[0001045810-16-000353:notes:136]
In February 2016, the FASB issued an accounting standards update regarding the accounting for leases by which we will begin recognizing lease assets and liabilities on the balance sheet for leases with a lease term of more than 12 months. The update will require additional disclosures regarding key information about leasing arrangements. Under existing guidance, operating leases are not recorded as lease assets and lease liabilities on the balance sheet. The update will be effective for us beginning in our first quarter of fiscal year 2020, with early adoption permitted. We are currently evaluating the impact of the adoption of this accounting guidance on our consolidated financial statements. However, we expect the adoption of this accounting guidance to result in an increase in lease assets and a corresponding increase in lease liabilities on our Condensed Consolidated Balance Sheets.

[0001045810-16-000353:notes:137]
The FASB issued an accounting standards update that creates a single source of revenue guidance under U.S. GAAP for all companies, in all industries, effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. The new standard will be effective for us beginning in our first quarter of fiscal year 2019, although we are permitted to adopt the standard one year earlier. We will adopt this guidance either by using a full retrospective approach for all periods presented in the period of adoption, or a modified retrospective approach. We are currently evaluating the impact of this accounting guidance on our consolidated financial statements and have not yet determined which transition method we will apply.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-16-000353:notes:138]
[same as prior period, unchanged from 0001045810-16-000300:notes:115]

[0001045810-16-000353:notes:139]
[same as prior period, unchanged from 0001045810-16-000300:notes:116]

[0001045810-16-000353:notes:140]
[same as prior period, unchanged from 0001045810-16-000300:notes:117]

[0001045810-16-000353:notes:141]
[same as prior period, unchanged from 0001045810-16-000300:notes:118]

[0001045810-16-000353:notes:142]
[same as prior period, unchanged from 0001045810-16-000300:notes:119]

[0001045810-16-000353:notes:143]
The estimated product returns and estimated product warranty liabilities as of and for the nine and twelve months ended October 30, 2016 and January 31, 2016 were as follows:

[0001045810-16-000353:notes:144]
|  | October 30, |  | January 31, |
|  | 2016 |  | 2016 |
|  | (In millions) |
| Balance at beginning of period | $ | 11 |  |  | $ | 8 |  |
| Additions | 1 |  |  | 27 |  |
| Deductions | (5 | ) |  | (24 | ) |
| Balance at end of period | $ | 7 |  |  | $ | 11 |  |

[0001045810-16-000353:notes:145]
[same as prior period, unchanged from 0001045810-16-000300:notes:122]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-16-000353:notes:146]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2016 |  | October 25, 2015 |  | October 30, 2016 |  | October 25, 2015 |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Unallocated revenue | $ | 66 |  |  | $ | 66 |  |  | $ | 198 |  |  | $ | 198 |  |
| Stock-based compensation expense | (65 | ) |  | (51 | ) |  | (176 | ) |  | (145 | ) |
| Unallocated cost of revenue and operating expenses | (53 | ) |  | (60 | ) |  | (156 | ) |  | (181 | ) |
| Acquisition-related costs | (4 | ) |  | (4 | ) |  | (12 | ) |  | (18 | ) |
| Restructuring and other charges | — |  |  | (8 | ) |  | (3 | ) |  | (97 | ) |
| Contributions | — |  |  | — |  |  | (4 | ) |  | — |  |
| Product warranty charge | — |  |  | — |  |  | — |  |  | (15 | ) |
| Legal settlement costs | — |  |  | — |  |  | (16 | ) |  | — |  |
| Total | $ | (56 | ) |  | $ | (57 | ) |  | $ | (169 | ) |  | $ | (258 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001045810-16-000353:notes:147]
[same as prior period, unchanged from 0001045810-16-000300:notes:124]

[0001045810-16-000353:notes:148]
In the second quarter of fiscal year 2016, we began the wind-down of our Icera operations. Our operating expenses for the nine months ended October 30, 2016 included $3 million of restructuring and other charges. No restructuring charges were recorded during the three months ended October 30, 2016.

[0001045810-16-000353:notes:149]
The following table provides a summary of the restructuring activities and related liabilities recorded in accrued liabilities on our Condensed Consolidated Balance Sheets as of October 30, 2016 (in millions):

[0001045810-16-000353:notes:150]
| Balance as of January 31, 2016 | $ | 23 |  |
| Restructuring and other charges | 3 |  |
| Cash payments | (14 | ) |
| Non-cash adjustments | 1 |  |
| Balance as of October 30, 2016 | $ | 13 |  |

[0001045810-16-000353:notes:151]
The majority of the remaining balance of $13 million as of October 30, 2016 is expected to be paid during fiscal year 2018.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-16-000353:notes:152]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In millions) |
| Revenue: |  |  |  |  |  |  |  |
| Taiwan | $ | 747 |  |  | $ | 515 |  |  | $ | 1,696 |  |  | $ | 1,348 |  |
| China | 341 |  |  | 229 |  |  | 845 |  |  | 583 |  |
| Other Asia Pacific | 309 |  |  | 181 |  |  | 660 |  |  | 554 |  |
| United States | 282 |  |  | 156 |  |  | 682 |  |  | 474 |  |
| Europe | 171 |  |  | 116 |  |  | 494 |  |  | 341 |  |
| Other Americas | 154 |  |  | 108 |  |  | 360 |  |  | 309 |  |
| Total revenue | $ | 2,004 |  |  | $ | 1,305 |  |  | $ | 4,737 |  |  | $ | 3,609 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001045810-16-000353:notes:153]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, |  | October 25, |  | October 30, |  | October 25, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Customer A | 13 | % |  | 10 | % |  | 12 | % |  | 11 | % |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-16-000353:notes:154]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended October 30, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 1,697 |  |  | $ | 241 |  |  | $ | 66 |  |  | $ | 2,004 |  |
| Depreciation and amortization expense | $ | 30 |  |  | $ | 8 |  |  | $ | 10 |  |  | $ | 48 |  |
| Operating income (loss) | $ | 678 |  |  | $ | 17 |  |  | $ | (56 | ) |  | $ | 639 |  |
| Three Months Ended October 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 1,110 |  |  | $ | 129 |  |  | $ | 66 |  |  | $ | 1,305 |  |
| Depreciation and amortization expense | $ | 26 |  |  | $ | 11 |  |  | $ | 11 |  |  | $ | 48 |  |
| Operating income (loss) | $ | 367 |  |  | $ | (65 | ) |  | $ | (57 | ) |  | $ | 245 |  |
| Nine Months Ended October 30, 2016 |  |  |  |  |  |  |  |
| Revenue | $ | 3,972 |  |  | $ | 567 |  |  | $ | 198 |  |  | $ | 4,737 |  |
| Depreciation and amortization expense | $ | 87 |  |  | $ | 22 |  |  | $ | 31 |  |  | $ | 140 |  |
| Operating income (loss) | $ | 1,405 |  |  | $ | (35 | ) |  | $ | (169 | ) |  | $ | 1,201 |  |
| Nine Months Ended October 25, 2015 |  |  |  |  |  |  |  |
| Revenue | $ | 3,009 |  |  | $ | 402 |  |  | $ | 198 |  |  | $ | 3,609 |  |
| Depreciation and amortization expense | $ | 81 |  |  | $ | 36 |  |  | $ | 34 |  |  | $ | 151 |  |
| Operating income (loss) | $ | 917 |  |  | $ | (164 | ) |  | $ | (258 | ) |  | $ | 495 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-16-000353:notes:155]
[same as prior period, unchanged from 0001045810-16-000300:notes:132]

[0001045810-16-000353:notes:156]
[same as prior period, unchanged from 0001045810-16-000300:notes:133]

[0001045810-16-000353:notes:157]
[same as prior period, unchanged from 0001045810-16-000300:notes:134]

[0001045810-16-000353:notes:158]
Our GPU product brands are aimed at specialized markets including GeForce for gamers; Quadro for designers; Tesla for researchers and data scientists focused on artificial intelligence and big-data analytics; and GRID for cloud-based visual computing users. Our Tegra brand integrates an entire computer onto a single chip, incorporating GPUs and multi-core CPUs aimed at online gaming and entertainment devices, as well as autonomous robots, drones and cars.

[0001045810-16-000353:notes:159]
[same as prior period, unchanged from 0001045810-16-000300:notes:136]

[0001045810-16-000353:notes:160]
[same as prior period, unchanged from 0001045810-16-000300:notes:137]

[0001045810-16-000353:notes:161]
[same as prior period, unchanged from 0001045810-16-000300:notes:138]

[0001045810-16-000353:notes:162]
[same as prior period, unchanged from 0001045810-16-000300:notes:139]

[0001045810-16-000353:notes:163]
[same as prior period, unchanged from 0001045810-16-000300:notes:140]

[0001045810-16-000353:notes:164]
[same as prior period, unchanged from 0001045810-16-000300:notes:141]

[0001045810-16-000353:notes:165]
Revenue from Customer A was attributable to the GPU business.

[0001045810-16-000353:notes:166]
[same as prior period, unchanged from 0001045810-16-000300:notes:143]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-16-000353:notes:167]
[same as prior period, unchanged from 0001045810-16-000300:notes:144]

[0001045810-16-000353:notes:168]
[same as prior period, unchanged from 0001045810-16-000300:notes:145]

[0001045810-16-000353:notes:169]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal year 2017 is a 52-week year and fiscal year 2016 was a 53-week year. The third quarter of fiscal years 2017 and 2016 were both 13-week quarters.

[0001045810-16-000353:notes:170]
[same as prior period, unchanged from 0001045810-16-000300:notes:147]

[0001045810-16-000353:notes:171]
[same as prior period, unchanged from 0001045810-16-000300:notes:148]

[0001045810-16-000353:notes:172]
[same as prior period, unchanged from 0001045810-16-000300:notes:149]

[0001045810-16-000353:notes:173]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, litigation, investigation and settlement costs, restructuring and other charges, and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-16-000353:notes:174]
[same as prior period, unchanged from 0001045810-16-000300:notes:151]

[0001045810-16-000353:notes:175]
[same as prior period, unchanged from 0001045810-16-000300:notes:152]

[0001045810-16-000353:notes:176]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. On November 7, 2016, the Board authorized an additional $2.00 billion under our repurchase program and extended it through December 2020.

[0001045810-16-000353:notes:177]
[same as prior period, unchanged from 0001045810-16-000300:notes:154]

[0001045810-16-000353:notes:178]
During the three and nine months ended October 30, 2016, we also paid $61 million and $185 million, respectively, in cash dividends to our shareholders, equivalent to $0.1150 per share. As a result, we returned $61 million and $694 million to shareholders during the three and nine months ended October 30, 2016, respectively, in the form of share repurchases and dividend payments.

[0001045810-16-000353:notes:179]
Through October 30, 2016, we have repurchased an aggregate of 243 million shares under our share repurchase program for a total cost of $4.36 billion. All shares delivered from these repurchases have been placed into treasury stock. As of November 7, 2016, we were authorized, subject to certain specifications, to repurchase additional shares of our common stock up to $2.96 billion through December 2020.

[0001045810-16-000353:notes:180]
We intend to return $1.00 billion to our shareholders in fiscal year 2017 through a combination of share repurchases and cash dividends. For fiscal year 2018, we intend to return $1.25 billion to our shareholders through ongoing quarterly cash dividends and share repurchases. We also declared an increase in our quarterly cash dividend to $0.14 per share from $0.1150 per share, to be paid with our next quarterly cash dividend on December 19, 2016, to all shareholders of record on November 28, 2016.

[0001045810-16-000353:notes:181]
[same as prior period, unchanged from 0001045810-16-000300:notes:158]

[0001045810-16-000353:notes:182]
As of October 30, 2016 and January 31, 2016, there were no shares of preferred stock outstanding.

[0001045810-16-000353:notes:183]
[same as prior period, unchanged from 0001045810-16-000300:notes:160]

[0001045810-16-000353:notes:184]
[same as prior period, unchanged from 0001045810-16-000300:notes:161]
