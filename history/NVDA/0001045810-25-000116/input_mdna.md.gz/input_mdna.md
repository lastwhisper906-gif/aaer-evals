# NVDA MD&A — 0001045810-25-000116


## mdna

[0001045810-25-000116:mdna:1]
[same as prior period, unchanged from 0001045810-24-000316:mdna:1]

[0001045810-25-000116:mdna:2]
[same as prior period, unchanged from 0001045810-24-000316:mdna:2]

[0001045810-25-000116:mdna:3]
[same as prior period, unchanged from 0001045810-24-000316:mdna:3]

[0001045810-25-000116:mdna:4]
© 2025 NVIDIA Corporation. All rights reserved.

[0001045810-25-000116:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 26, 2025 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase, hold, or sell shares of our common stock.

[0001045810-25-000116:mdna:6]
[same as prior period, unchanged from 0001045810-24-000316:mdna:6]

[0001045810-25-000116:mdna:7]
[same as prior period, unchanged from 0001045810-24-000316:mdna:7]

[0001045810-25-000116:mdna:8]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, AV, robotics, and digital twin applications.

[0001045810-25-000116:mdna:9]
Our two operating segments are "Compute & Networking" and "Graphics," as described in Note 13 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001045810-25-000116:mdna:10]
[same as prior period, unchanged from 0001045810-24-000316:mdna:9]

[0001045810-25-000116:mdna:11]
[same as prior period, unchanged from 0001045810-24-000316:mdna:10]

[0001045810-25-000116:mdna:12]
Revenue growth in the first quarter of fiscal year 2026 was driven by data center compute and networking platforms for accelerated computing and AI solutions. Our Blackwell GPU revenue ramp continued during the quarter, extending beyond large cloud service providers to include consumer internet companies and regional cloud service providers.

[0001045810-25-000116:mdna:13]
On April 9, 2025, the U.S. government, or USG, informed us that it requires a license for export to China (including Hong Kong and Macau) and D:5 countries, or to companies headquartered or with an ultimate parent therein, of our H20 integrated circuits and any other circuits achieving the H20’s memory bandwidth, interconnect bandwidth, or combination thereof. As a result of these new requirements, we incurred a $4.5 billion charge in the first quarter of fiscal year 2026 associated with H20 excess inventory and purchase obligations as the demand for H20 products diminished. The $4.5 billion charge was less than what we initially anticipated as we were able to re-use certain materials. Sales of our H20 products were $4.6 billion for the first quarter of fiscal year 2026 prior to the new export licensing requirements. The H20 export licensing requirements have impacted our current revenue and will also negatively affect our future revenue. We are still evaluating our limited options to supply Data Center compute products compliant with the USG’s export control rules. The export controls applicable to China are complex and address a variety of parameters, including the total processing performance of a chip, the “performance density” of a chip, the interconnect bandwidth of a chip, and the memory bandwidth of a chip. We may be unable to create a competitive product for China’s data center market that receives approval from the USG. In that event, we would effectively be foreclosed from competing in China's data center computing/compute market, with a material and adverse impact on our business, operating results, and financial condition.

[0001045810-25-000116:mdna:14]
We believe the China AI market to be a significant opportunity and the existing and new export controls will greatly hinder our ability to address this opportunity and will continue to impact our revenue and operational results.

[0001045810-25-000116:mdna:15]
We continue to execute Data Center compute product introductions, bringing new advanced architectures on a one-year product cadence. We expect to begin shipping samples and production units of our new Blackwell Ultra platforms in the second quarter of fiscal year 2026. Our product transitions and sophisticated system configurations may create challenges in managing supply and demand. This could result in revenue volatility, quality or production issues, increased inventory provisions, warranty costs, or product delays. Customers may postpone purchasing existing products due to frequent new releases or may adopt new technologies more gradually than anticipated, affecting our revenue timing and supply chain expenses.

[0001045810-25-000116:mdna:16]
The recent rise of high-quality open-source foundation models is making advanced AI capabilities broadly accessible. Open-source AI is becoming increasingly important across the ecosystem and it is dependent on developer adoption. If the most widely adopted open-source models are developed or deployed on our competitors’ platforms, it could significantly weaken the influence of our platform, reduce developer engagement, and limit demand for our products and services. Future demand for our platform will depend on our ability to support, scale, and optimize the next generation of AI models—including open-source large language models—across our full stack of software and hardware offerings.

[0001045810-25-000116:mdna:17]
The availability of data centers, energy, and capital to support the buildout of NVIDIA AI infrastructure by our customers is crucial, and any shortage of these resources could impact our future revenue and financial performance.

[0001045810-25-000116:mdna:18]
In January 2025, the USG published the “AI Diffusion” IFR in the Federal Register. After a 120-day delayed compliance period, the IFR would have imposed a worldwide licensing requirement on all products classified under Export Control Classification Numbers, or ECCNs, 3A090.a, 4A090.a, or corresponding .z ECCNs, including all related software and technology. The licensing requirement would have applied to our most popular data center products, such as our H200 and GB200. In May 2025, the USG announced that it would rescind the AI Diffusion IFR and implement a replacement rule. The scope, timing, and requirements of the forthcoming rule remain uncertain. The replacement rule may impose new restrictions on our products or operations and/or add license requirements that could have a material impact on our business, operating results, and financial condition.

[0001045810-25-000116:mdna:19]
Changes in global trade policies, including the new export controls and tariffs, have increased the complexity and cost of our supply chain and may continue to do so. Ongoing uncertainty regarding the scope and application of such measures may adversely affect investment decisions by us and our partners, disrupt supply chain operations, and impact the timing and volume of customer purchases due to challenges in forecasting future costs and demand.

[0001045810-25-000116:mdna:20]
We plan to increase our U.S.-based manufacturing and invest in specialized equipment and processes to support domestic production. This move is expected to strengthen our supply chain, boost resiliency and redundancy, and meet the growing demand for AI infrastructure. Our ability to increase manufacturing capabilities will depend on the domestic manufacturing ecosystem's capacity to ramp production supply to the required volume and on a timely basis.

[0001045810-25-000116:mdna:21]
Macroeconomic factors, including tariffs, inflation, interest rate changes, capital market volatility, global supply chain constraints, and global economic and geopolitical developments, have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Our product and solution pricing generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-25-000116:mdna:22]
Refer to “Item 1A. Risk Factors” for a discussion of these factors and other risks.

[0001045810-25-000116:mdna:23]
First Quarter of Fiscal Year 2026 Summary

[0001045810-25-000116:mdna:24]
|  | Three Months Ended |  | Quarter-over-Quarter Change |  | Year-over-Year Change |
|  | Apr 27, 2025 |  | Jan 26, 2025 |  | Apr 28, 2024 |  |  |
|  | ($ in millions, except per share data) |  |  |  |  |
| Revenue | $ | 44,062 |  |  | $ | 39,331 |  |  | $ | 26,044 |  |  | 12 | % |  | 69 | % |
| Gross margin | 60.5 | % |  | 73.0 | % |  | 78.4 | % |  | (12.5) | pts |  | (17.9) | pts |
| Operating expenses | $ | 5,030 |  |  | $ | 4,689 |  |  | $ | 3,497 |  |  | 7 | % |  | 44 | % |
| Operating income | $ | 21,638 |  |  | $ | 24,034 |  |  | $ | 16,909 |  |  | (10) | % |  | 28 | % |
| Net income | $ | 18,775 |  |  | $ | 22,091 |  |  | $ | 14,881 |  |  | (15) | % |  | 26 | % |
| Net income per diluted share | $ | 0.76 |  |  | $ | 0.89 |  |  | $ | 0.60 |  |  | (15) | % |  | 27 | % |

[0001045810-25-000116:mdna:25]
On April 9, 2025, we were informed by the USG that a license is required for exports of our H20 products into the China market. As a result of these new requirements, we incurred a $4.5 billion charge in the first quarter of fiscal year 2026 associated with H20 excess inventory and purchase obligations as the demand for H20 products diminished. The $4.5 billion charge was less than what we initially anticipated as we were able to re-use certain materials. Sales of our H20 products were $4.6 billion for the first quarter of fiscal year 2026 prior to the new export licensing requirements. The H20 export licensing requirements have impacted our current revenue and will also negatively affect our future revenue.

[0001045810-25-000116:mdna:26]
Revenue was $44.1 billion, up 69% from a year ago and up 12% sequentially.

[0001045810-25-000116:mdna:27]
Data Center revenue was $39.1 billion, up 73% from a year ago and up 10% sequentially. The strong year-on-year and sequential growth was driven by demand for our accelerated computing platform used for large language models, recommendation engines, and generative and agentic AI applications. We saw our Blackwell architecture ramp expand to all customer categories, while large cloud service providers remained our largest at just under 50% of Data Center revenue. Data Center compute revenue was $34.2 billion, up 76% from a year ago and up 5% sequentially. Networking revenue was $5.0 billion, up 56% from a year ago and up 64% sequentially, driven by the growth of NVLink compute fabric in our GB200 systems and continued adoption of Ethernet for AI solutions at cloud service providers and consumer internet companies.

[0001045810-25-000116:mdna:28]
Gaming revenue was up 42% from a year ago and up 48% sequentially, driven by sales of our Blackwell architecture.

[0001045810-25-000116:mdna:29]
Professional Visualization revenue was up 19% from a year ago and flat sequentially. The increase from a year ago was driven by broader adoption of Ada RTX workstation GPUs, addressing workflows in AI acceleration, real-time graphics rendering and data simulation.

[0001045810-25-000116:mdna:30]
Automotive revenue was up 72% from a year ago and down 1% sequentially. The increase from a year ago was driven by sales of our self-driving platforms.

[0001045810-25-000116:mdna:31]
Gross margin decreased from a year ago and sequentially, primarily due to a $4.5 billion charge associated with H20 excess inventory and purchase obligations and the initial ramp of more sophisticated systems within Data Center.

[0001045810-25-000116:mdna:32]
Operating expenses were up 44% from a year ago and up 7% sequentially. The year-on-year increase was primarily driven by higher compensation and benefits expenses due to employee growth and compensation increases, and compute, infrastructure and engineering development costs for new product introductions. The sequential increase was primarily driven by higher compensation and benefits due to compensation increases and employee growth.

[0001045810-25-000116:mdna:33]
[same as prior period, unchanged from 0001045810-24-000316:mdna:40]

[0001045810-25-000116:mdna:34]
Refer to Note 13 of the Notes to the Condensed Consolidated Financial Statements for disclosure regarding segment information.

[0001045810-25-000116:mdna:35]
[same as prior period, unchanged from 0001045810-24-000316:mdna:42]

[0001045810-25-000116:mdna:36]
Refer to Part II, Item 7, "Critical Accounting Policies and Estimates" of our Annual Report on Form 10-K for the fiscal year ended January 26, 2025. There have been no material changes to our Critical Accounting Policies and Estimates.

[0001045810-25-000116:mdna:37]
[same as prior period, unchanged from 0001045810-24-000316:mdna:44]

[0001045810-25-000116:mdna:38]
[same as prior period, unchanged from 0001045810-24-000316:mdna:45]

[0001045810-25-000116:mdna:39]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
| Revenue | 100.0 | % |  | 100.0 | % |  |  |  |  |
| Cost of revenue | 39.5 |  |  | 21.6 |  |  |  |  |  |
| Gross profit | 60.5 |  |  | 78.4 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
| Research and development | 9.1 |  |  | 10.4 |  |  |  |  |  |
| Sales, general and administrative | 2.4 |  |  | 3.0 |  |  |  |  |  |
| Total operating expenses | 11.5 |  |  | 13.4 |  |  |  |  |  |
| Operating income | 49.0 |  |  | 65.0 |  |  |  |  |  |
| Interest income | 1.2 |  |  | 1.4 |  |  |  |  |  |
| Interest expense | (0.1) |  |  | (0.2) |  |  |  |  |  |
| Other income (expense), net | (0.4) |  |  | 0.3 |  |  |  |  |  |
| Total other income (expense), net | 0.7 |  |  | 1.5 |  |  |  |  |  |
| Income before income tax | 49.7 |  |  | 66.5 |  |  |  |  |  |
| Income tax expense | 7.1 |  |  | 9.2 |  |  |  |  |  |
| Net income | 42.6 | % |  | 57.3 | % |  |  |  |  |

[0001045810-25-000116:mdna:40]
[same as prior period, unchanged from 0001045810-24-000316:mdna:48]

[0001045810-25-000116:mdna:41]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Compute & Networking | $ | 39,589 |  |  | $ | 22,675 |  |  | $ | 16,914 |  |  | 75 | % |  |  |  |  |  |  |  |  |
| Graphics | 4,473 |  |  | 3,369 |  |  | 1,104 |  |  | 33 | % |  |  |  |  |  |  |  |  |
| Total | $ | 44,062 |  |  | $ | 26,044 |  |  | $ | 18,018 |  |  | 69 | % |  |  |  |  |  |  |  |  |

[0001045810-25-000116:mdna:42]
[same as prior period, unchanged from 0001045810-24-000316:mdna:50]

[0001045810-25-000116:mdna:43]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Compute & Networking | $ | 22,054 |  |  | $ | 17,047 |  |  | $ | 5,007 |  |  | 29 | % |  |  |  |  |  |  |  |  |
| Graphics | 1,640 |  |  | 1,241 |  |  | 399 |  |  | 32 | % |  |  |  |  |  |  |  |  |
| All Other | (2,056) |  |  | (1,379) |  |  | (677) |  |  | 49 | % |  |  |  |  |  |  |  |  |
| Total | $ | 21,638 |  |  | $ | 16,909 |  |  | $ | 4,729 |  |  | 28 | % |  |  |  |  |  |  |  |  |

[0001045810-25-000116:mdna:44]
Compute & Networking revenue – The year over year increase in the first quarter of fiscal year 2026 was driven by demand for our accelerated computing platform used for large language models, recommendation engines, and generative and agentic AI applications. Revenue from Data Center computing grew 76% year-on-year compared to the first quarter of fiscal year 2025, driven by demand for our Blackwell computing platform. Revenue from Data Center networking grew 56% year-on-year compared to the first quarter of fiscal year 2025 driven by the growth of NVLink compute fabric in our GB200 systems and continued adoption of Ethernet for AI solutions at cloud service providers and consumer internet companies.

[0001045810-25-000116:mdna:45]
Graphics revenue – The year over year increase in the first quarter of fiscal year 2026 was driven by sales of our Blackwell architecture.

[0001045810-25-000116:mdna:46]
25

[0001045810-25-000116:mdna:47]
Reportable segment operating income – The year over year increase in Compute & Networking segment operating income in the first quarter of fiscal year 2026 was driven by growth in revenue, partially offset by a $4.5 billion charge associated with H20 excess inventory and purchase obligations. The year over year increase in Graphics segment operating income in the first quarter of fiscal year 2026 was driven by growth in revenue.

[0001045810-25-000116:mdna:48]
All Other operating loss – The year over year increase in the first quarter of fiscal year 2026 was due to an increase in stock-based compensation expense reflecting employee growth.

[0001045810-25-000116:mdna:49]
[same as prior period, unchanged from 0001045810-24-000316:mdna:56]

[0001045810-25-000116:mdna:50]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, ODMs, OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. We also have indirect customers, who purchase products through our direct customers; indirect customers include CSPs, consumer internet companies, enterprises, and public sector entities.

[0001045810-25-000116:mdna:51]
Direct Customers – Sales to one direct customer, Customer A, represented 16% of total revenue and sales to a second direct customer, Customer B, represented 14% of total revenue for the first quarter of fiscal year 2026, both of which were attributable to the Compute & Networking segment. Sales to two direct customers represented 11% and 13% of total revenue for the first quarter of fiscal year 2025, both of which were attributable to the Compute & Networking segment.

[0001045810-25-000116:mdna:52]
Indirect Customers – Indirect customer revenue is an estimation based upon multiple factors including customer purchase order information, product specifications, internal sales data, and other sources. Actual indirect customer revenue may differ from our estimates. For the first quarter of fiscal year 2026, two indirect customers which primarily purchase our products through system integrators and distributors, including through Direct Customers A and B, are estimated to represent 10% or more of total revenue, attributable to the Compute & Networking segment.

[0001045810-25-000116:mdna:53]
We estimate that in the first quarter of fiscal year 2026, an AI research and deployment company contributed to a meaningful amount of our revenue, through one of the above indirect customers and through other indirect customers that provide cloud services.

[0001045810-25-000116:mdna:54]
[same as prior period, unchanged from 0001045810-24-000316:mdna:66]

[0001045810-25-000116:mdna:55]
Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to indirect customers in a different location. Revenue from sales to customers outside of the United States accounted for 53% and 48% of total revenue for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:mdna:56]
[same as prior period, unchanged from 0001045810-24-000316:mdna:67]

[0001045810-25-000116:mdna:57]
Gross profit consists of total net revenue less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions, memory and component costs, tariffs, and shipping costs. Cost of revenue also includes acquisition-related intangible amortization expense, costs for license and development and service arrangements, IP-related costs, and stock-based compensation related to personnel associated with manufacturing operations.

[0001045810-25-000116:mdna:58]
Gross margins decreased to 60.5% for the first quarter of fiscal year 2026 compared to 78.4% for the first quarter of fiscal year 2025, primarily due to a $4.5 billion charge associated with H20 excess inventory and purchase obligations and the initial ramp of more sophisticated systems within Data Center.

[0001045810-25-000116:mdna:59]
Provisions for inventory and excess inventory purchase obligations totaled $5.3 billion, including $4.5 billion associated with H20 excess inventory and purchase obligations, and $393 million for the first quarter of fiscal years 2026 and 2025, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $436 million and $114 million for the first quarter of fiscal years 2026 and 2025, respectively. The net effect of provisions for inventory and excess inventory purchase obligations on our gross margin was an unfavorable impact of 11.0% and 1.1% in the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:mdna:60]
26

[0001045810-25-000116:mdna:61]
[same as prior period, unchanged from 0001045810-24-000316:mdna:72]

[0001045810-25-000116:mdna:62]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  | $Change |  | %Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |
| Research and development expenses | $ | 3,989 |  |  | $ | 2,720 |  |  | $ | 1,269 |  |  | 47 | % |  |  |  |  |  |  |  |  |
| Sales, general and administrative expenses | 1,041 |  |  | 777 |  |  | 264 |  |  | 34 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 5,030 |  |  | $ | 3,497 |  |  | $ | 1,533 |  |  | 44 | % |  |  |  |  |  |  |  |  |

[0001045810-25-000116:mdna:63]
The increase in research and development expenses for the first quarter of fiscal year 2026 was driven by a 34% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, a 70% increase in compute and infrastructure, and a 182% increase in engineering development costs for new product introductions.

[0001045810-25-000116:mdna:64]
The increase in sales, general and administrative expenses for the first quarter of fiscal year 2026 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-25-000116:mdna:65]
Total Other Income (Expense), Net

[0001045810-25-000116:mdna:66]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  | $Change |  |  |  |  |  |  |
|  | ($ in millions) |
| Interest income | $ | 515 |  |  | $ | 359 |  |  | $ | 156 |  |  |  |  |  |  |  |
| Interest expense | (63) |  |  | (64) |  |  | 1 |  |  |  |  |  |  |  |
| Other income (expense), net | (180) |  |  | 75 |  |  | (255) |  |  |  |  |  |  |  |
| Total other income (expense), net | $ | 272 |  |  | $ | 370 |  |  | $ | (98) |  |  |  |  |  |  |  |

[0001045810-25-000116:mdna:67]
The increase in interest income for the first quarter of fiscal year 2026 was primarily due to growth in cash, cash equivalents, and debt securities.

[0001045810-25-000116:mdna:68]
[same as prior period, unchanged from 0001045810-24-000316:mdna:79]

[0001045810-25-000116:mdna:69]
Other income (expense), net consists of realized or unrealized gains and losses from investments in non-marketable equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other income (expense), net, compared to the first quarter of fiscal year 2025, was primarily driven by unrealized losses in our publicly-held equity securities due to fair value volatility in our investments, particularly CoreWeave and Arm, Inc. Refer to Notes 5 and 6 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding our investments in non-marketable equity securities and publicly-held equity securities.

[0001045810-25-000116:mdna:70]
[same as prior period, unchanged from 0001045810-24-000316:mdna:81]

[0001045810-25-000116:mdna:71]
Income tax expense was $3.1 billion and $2.4 billion for the first quarter of fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 14.3% and 13.9% for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:mdna:72]
The effective tax rate increased primarily due to a lower tax benefit from stock-based compensation, partially offset by an increase in tax benefit from the foreign-derived intangible income deduction.

[0001045810-25-000116:mdna:73]
[same as prior period, unchanged from 0001045810-24-000316:mdna:84]

[0001045810-25-000116:mdna:74]
Refer to Note 4 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-25-000116:mdna:75]
27

[0001045810-25-000116:mdna:76]
[same as prior period, unchanged from 0001045810-24-000316:mdna:86]

[0001045810-25-000116:mdna:77]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | (In millions) |
| Cash and cash equivalents | $ | 15,234 |  |  | $ | 8,589 |  |
| Marketable securities | 38,457 |  |  | 34,621 |  |
| Cash, cash equivalents and marketable securities | $ | 53,691 |  |  | $ | 43,210 |  |

[0001045810-25-000116:mdna:78]
|  | Three Months Ended |
|  | Apr 27, 2025 |  | Apr 28, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 27,414 |  |  | $ | 15,345 |  |
| Net cash used in investing activities | $ | (5,216) |  |  | $ | (5,693) |  |
| Net cash used in financing activities | $ | (15,553) |  |  | $ | (9,345) |  |

[0001045810-25-000116:mdna:79]
Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-25-000116:mdna:80]
Cash provided by operating activities increased in the first quarter of fiscal year 2026 compared to the first quarter of fiscal year 2025, due to higher revenue and timing of cash collections.

[0001045810-25-000116:mdna:81]
Cash used in investing activities decreased in the first quarter of fiscal year 2026 compared to the first quarter of fiscal year 2025, primarily driven by lower net purchases of marketable securities, partially offset by higher purchases of property and equipment.

[0001045810-25-000116:mdna:82]
Cash used in financing activities increased in the first quarter of fiscal year 2026 compared to the first quarter of fiscal year 2025, mainly due to higher share repurchases.

[0001045810-25-000116:mdna:83]
[same as prior period, unchanged from 0001045810-24-000316:mdna:94]

[0001045810-25-000116:mdna:84]
Our primary sources of liquidity include cash, cash equivalents, marketable securities, and cash generated by our operations. As of April 27, 2025, we had $53.7 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and thereafter for the foreseeable future, including our future supply obligations and share purchases. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-25-000116:mdna:85]
Our marketable securities consist of publicly-held equity securities, debt securities issued by the U.S. government and its agencies, highly-rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly-rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 5 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001045810-25-000116:mdna:86]
Except for approximately $1.7 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. at the end of the first quarter of fiscal year 2026 are available for use in the U.S. without incurring additional U.S. federal income taxes. We plan to make two estimated federal and state tax payments in the second quarter of fiscal year 2026, a substantial increase as compared with no estimated tax payments in the first quarter of fiscal year 2026.

[0001045810-25-000116:mdna:87]
[same as prior period, unchanged from 0001045810-24-000316:mdna:99]

[0001045810-25-000116:mdna:88]
We repurchased 126 million shares of our common stock for $14.5 billion during the first quarter of fiscal years 2026. As of April 27, 2025, we were authorized, subject to certain specifications, to repurchase up to $24.3 billion of our common stock.

[0001045810-25-000116:mdna:89]
From April 28, 2025 through May 23, 2025, we repurchased 19 million shares for $2.3 billion pursuant to a pre-established trading plan. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-25-000116:mdna:90]
We paid cash dividends to our shareholders of $244 million and $98 million during the first quarter of fiscal years 2026 and 2025, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.

[0001045810-25-000116:mdna:91]
[same as prior period, unchanged from 0001045810-24-000316:mdna:64]

[0001045810-25-000116:mdna:92]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for the first quarter of fiscal years 2026 and 2025.

[0001045810-25-000116:mdna:93]
[same as prior period, unchanged from 0001045810-24-000316:mdna:105]

[0001045810-25-000116:mdna:94]
Our aggregate debt maturities as of April 27, 2025, by year payable, are as follows:

[0001045810-25-000116:mdna:95]
|  |  | Apr 27, 2025 |
|  |  | (In millions) |
| Due in one to five years |  | $ | 3,750 |  |
| Due in five to ten years |  | 1,250 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (36) |  |
| Net long-term carrying amount |  | $ | 8,464 |  |

[0001045810-25-000116:mdna:96]
We have a $575 million commercial paper program to support general corporate purposes. As of April 27, 2025, we had no commercial paper outstanding.

[0001045810-25-000116:mdna:97]
Refer to Note 10 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for further discussion.

[0001045810-25-000116:mdna:98]
[same as prior period, unchanged from 0001045810-24-000316:mdna:110]

[0001045810-25-000116:mdna:99]
Unrecognized tax benefits were $2.5 billion, which includes related interest and penalties, were recorded in non-current income tax payable as of April 27, 2025. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 4 of the Notes to Condensed Consolidated Financial Statements for further information.

[0001045810-25-000116:mdna:100]
Other than the contractual obligations described above, there were no material changes outside the ordinary course of business in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025. Refer to Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025 for a description of our contractual obligations. For a description of our long-term debt, purchase obligations, and operating lease obligations, refer to Notes 10, 11, and 14 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q, respectively.

[0001045810-25-000116:mdna:101]
[same as prior period, unchanged from 0001045810-24-000316:mdna:113]

[0001045810-25-000116:mdna:102]
[same as prior period, unchanged from 0001045810-24-000316:mdna:114]

[0001045810-25-000116:mdna:103]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-25-000116:mdna:104]
There has been no adoption of any new and recently issued accounting pronouncements.
