# NVDA 8-K — 0001045810-25-000115 filed 2025-05-28

## item codes, every 8-K on or before 2025-05-28

- 2025-05-28 0001045810-25-000115 — 2.02, 9.01
- 2025-04-15 0001045810-25-000082 — 8.01
- 2025-03-07 0001045810-25-000039 — 5.02
- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2025-05-28

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-25-000115:8k_2_02:1]
EX-99.1
2
q1fy26pr.htm
EX-99.1

[0001045810-25-000115:8k_2_02:2]
Document

[0001045810-25-000115:8k_2_02:3]
NVIDIA Announces Financial Results for First Quarter Fiscal 2026

[0001045810-25-000115:8k_2_02:4]
•Revenue of $44.1 billion, up 12% from Q4 and up 69% from a year ago

[0001045810-25-000115:8k_2_02:5]
•Data Center revenue of $39.1 billion, up 10% from Q4 and up 73% from a year ago

[0001045810-25-000115:8k_2_02:6]
SANTA CLARA, Calif.—May 28, 2025―NVIDIA (NASDAQ: NVDA) today reported revenue for the first quarter ended April 27, 2025, of $44.1 billion, up 12% from the previous quarter and up 69% from a year ago.

[0001045810-25-000115:8k_2_02:7]
On April 9, 2025, NVIDIA was informed by the U.S. government that a license is required for exports of its H20 products into the China market. As a result of these new requirements, NVIDIA incurred a $4.5 billion charge in the first quarter of fiscal 2026 associated with H20 excess inventory and purchase obligations as the demand for H20 diminished.  Sales of H20 products were $4.6 billion for the first quarter of fiscal 2026 prior to the new export licensing requirements. NVIDIA was unable to ship an additional $2.5 billion of H20 revenue in the first quarter.

[0001045810-25-000115:8k_2_02:8]
For the quarter, GAAP and non-GAAP gross margins were 60.5% and 61.0%, respectively. Excluding the $4.5 billion charge, first quarter non-GAAP gross margin would have been 71.3%.

[0001045810-25-000115:8k_2_02:9]
For the quarter, GAAP and non-GAAP earnings per diluted share were $0.76 and $0.81, respectively. Excluding the $4.5 billion charge and related tax impact, first quarter non-GAAP diluted earnings per share would have been $0.96.

[0001045810-25-000115:8k_2_02:10]
“Our breakthrough Blackwell NVL72 AI supercomputer — a ‘thinking machine’ designed for reasoning— is now in full-scale production across system makers and cloud service providers,” said Jensen Huang, founder and CEO of NVIDIA. “Global demand for NVIDIA’s AI infrastructure is incredibly strong. AI inference token generation has surged tenfold in just one year, and as AI agents become mainstream, the demand for AI computing will accelerate. Countries around the world are recognizing AI as essential infrastructure — just like electricity and the internet — and NVIDIA stands at the center of this profound transformation.”

[0001045810-25-000115:8k_2_02:11]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on July 3, 2025, to all shareholders of record on June 11, 2025.

[0001045810-25-000115:8k_2_02:12]
Q1 Fiscal 2026 Summary

[0001045810-25-000115:8k_2_02:13]
| GAAP |
| ($ in millions, except earnings per share) | Q1 FY26 | Q4 FY25 | Q1 FY25 | Q/Q | Y/Y |
| Revenue | $44,062 | $39,331 | $26,044 | 12 | % | 69 | % |
| Gross margin | 60.5 | % | 73.0 | % | 78.4 | % | (12.5) pts | (17.9) pts |
| Operating expenses | $5,030 | $4,689 | $3,497 | 7 | % | 44 | % |
| Operating income | $21,638 | $24,034 | $16,909 | (10) | % | 28 | % |
| Net income | $18,775 | $22,091 | $14,881 | (15) | % | 26 | % |
| Diluted earnings per share* | $0.76 | $0.89 | $0.60 | (15) | % | 27 | % |

[0001045810-25-000115:8k_2_02:14]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q1 FY26 | Q4 FY25 | Q1 FY25 | Q/Q | Y/Y |
| Revenue | $44,062 | $39,331 | $26,044 | 12 | % | 69 | % |
| Gross margin | 61.0 | % | 73.5 | % | 78.9 | % | (12.5) pts | (17.9) pts |
| Gross margin excluding H20 charge | 71.3 | % |  |  |  |  |
| Operating expenses | $3,583 | $3,378 | $2,501 | 6 | % | 43 | % |
| Operating income | $23,275 | $25,516 | $18,059 | (9) | % | 29 | % |
| Net income | $19,894 | $22,066 | $15,238 | (10) | % | 31 | % |
| Diluted earnings per share* | $0.81 | $0.89 | $0.61 | (9) | % | 33 | % |
| Diluted earnings per share excluding H20 charge and related tax impact | $0.96 |  |  |  |  |

[0001045810-25-000115:8k_2_02:15]
*All per share amounts presented herein have been retroactively adjusted to reflect NVIDIA’s ten-for-one stock split, which was effective June 7, 2024.

[0001045810-25-000115:8k_2_02:16]
Outlook

[0001045810-25-000115:8k_2_02:17]
NVIDIA’s outlook for the second quarter of fiscal 2026 is as follows:

[0001045810-25-000115:8k_2_02:18]
•Revenue is expected to be $45.0 billion, plus or minus 2%. This outlook reflects a loss in H20 revenue of approximately $8.0 billion due to the recent export control limitations.

[0001045810-25-000115:8k_2_02:19]
•GAAP and non-GAAP gross margins are expected to be 71.8% and 72.0%, respectively, plus or minus 50 basis points.  The company is continuing to work toward achieving gross margins in the mid-70% range late this year.

[0001045810-25-000115:8k_2_02:20]
•GAAP and non-GAAP operating expenses are expected to be approximately $5.7 billion and $4.0 billion, respectively. Full year fiscal 2026 operating expense growth is expected to be in the mid-30% range.

[0001045810-25-000115:8k_2_02:21]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $450 million, excluding gains and losses from non-marketable and publicly-held equity securities.

[0001045810-25-000115:8k_2_02:22]
•GAAP and non-GAAP tax rates are expected to be 16.5%, plus or minus 1%, excluding any discrete items.

[0001045810-25-000115:8k_2_02:23]
Highlights

[0001045810-25-000115:8k_2_02:24]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-25-000115:8k_2_02:25]
Data Center

[0001045810-25-000115:8k_2_02:26]
•First-quarter revenue was $39.1 billion, up 10% from the previous quarter and up 73% from a year ago.

[0001045810-25-000115:8k_2_02:27]
•Announced that NVIDIA is building factories in the U.S. and working with its partners to produce NVIDIA AI supercomputers in the U.S.

[0001045810-25-000115:8k_2_02:28]
•Introduced NVIDIA Blackwell Ultra and NVIDIA Dynamo for accelerating and scaling AI reasoning models.

[0001045810-25-000115:8k_2_02:29]
•Announced partnership with HUMAIN to build AI factories in the Kingdom of Saudi Arabia to drive the next wave of artificial intelligence development.

[0001045810-25-000115:8k_2_02:30]
•Unveiled Stargate UAE, a next-generation AI infrastructure cluster in Abu Dhabi, United Arab Emirates, alongside strategic partners G42, OpenAI, Oracle, SoftBank Group and Cisco.

[0001045810-25-000115:8k_2_02:31]
•Revealed plans to work with Foxconn and the Taiwan government to build an AI factory supercomputer.

[0001045810-25-000115:8k_2_02:32]
•Announced NVIDIA is speeding the IT infrastructure transition to enterprise AI factories with NVIDIA RTX PRO™ Servers.

[0001045810-25-000115:8k_2_02:33]
•Unveiled NVLink Fusion™ for industry to build semi-custom AI infrastructure with NVIDIA’s partner ecosystem.

[0001045810-25-000115:8k_2_02:34]
•Announced NVIDIA Spectrum-X™ and NVIDIA Quantum-X silicon photonics networking switches to scale AI factories to millions of GPUs.

[0001045810-25-000115:8k_2_02:35]
•Introduced the NVIDIA DGX SuperPOD™ built with NVIDIA Blackwell Ultra GPUs to provide AI factory supercomputing for agentic AI reasoning.

[0001045810-25-000115:8k_2_02:36]
•Announced joint initiatives with Alphabet and Google to advance agentic AI solutions, robotics and drug discovery.

[0001045810-25-000115:8k_2_02:37]
•Announced integration between NVIDIA accelerated computing and inference software with Oracle’s AI infrastructure.

[0001045810-25-000115:8k_2_02:38]
•Revealed that NVIDIA Blackwell cloud instances are now available on AWS, Google Cloud, Microsoft Azure and Oracle Cloud Infrastructure.

[0001045810-25-000115:8k_2_02:39]
•Announced that the NVIDIA Blackwell platform set records in the latest MLPerf inference results, delivering up to 30x higher throughput.

[0001045810-25-000115:8k_2_02:40]
•Announced NVIDIA DGX Cloud Lepton™ to connect developers to NVIDIA’s global compute ecosystem.

[0001045810-25-000115:8k_2_02:41]
•Launched the open Llama Nemotron family of models with reasoning capabilities, providing a foundation for creating advanced AI agents.

[0001045810-25-000115:8k_2_02:42]
•Introduced the NVIDIA AI Data Platform, a customizable reference design for AI inference workloads.

[0001045810-25-000115:8k_2_02:43]
•Announced the opening of a research center in Japan that hosts the world’s largest quantum research supercomputer.

[0001045810-25-000115:8k_2_02:44]
Gaming and AI PC

[0001045810-25-000115:8k_2_02:45]
•First-quarter Gaming revenue was a record $3.8 billion, up 48% from the previous quarter and up 42% from a year ago.

[0001045810-25-000115:8k_2_02:46]
•Announced the NVIDIA GeForce RTX™ 5070 and RTX 5060, bringing Blackwell graphics to gamers at prices starting from $299 for desktops and $1,099 for laptops.

[0001045810-25-000115:8k_2_02:47]
•Unveiled NVIDIA DLSS 4 is now available in over 125 games, including Black Myth Wukong, DOOM: The Dark Ages, Indiana Jones and the Great Circle, Marvel Rivals and Star Wars Outlaws.

[0001045810-25-000115:8k_2_02:48]
•Announced the Nintendo Switch 2 is powered by an NVIDIA processor and AI-powered DLSS, delivering up to 4K gaming.

[0001045810-25-000115:8k_2_02:49]
•Launched the NVIDIA RTX Remix modding platform, attracting over 2 million gamers, alongside the release of the Half-Life 2 RTX demo.

[0001045810-25-000115:8k_2_02:50]
Professional Visualization

[0001045810-25-000115:8k_2_02:51]
•First-quarter revenue was $509 million, flat with the previous quarter and up 19% from a year ago.

[0001045810-25-000115:8k_2_02:52]
•Announced the NVIDIA RTX PRO™ Blackwell series for workstations and servers.

[0001045810-25-000115:8k_2_02:53]
•Unveiled NVIDIA DGX Spark and DGX Station™ personal AI supercomputers powered by the NVIDIA Grace Blackwell platform.

[0001045810-25-000115:8k_2_02:54]
•Announced that leading industrial software and service providers Accenture, Ansys, Databricks, SAP, Schneider Electric with ETAP, and Siemens are integrating the NVIDIA Omniverse™ platform into their solutions to accelerate industrial digitalization with physical AI.

[0001045810-25-000115:8k_2_02:55]
Automotive and Robotics

[0001045810-25-000115:8k_2_02:56]
•First-quarter Automotive revenue was $567 million, down 1% from the previous quarter and up 72% from a year ago.

[0001045810-25-000115:8k_2_02:57]
•Announced a collaboration with General Motors on next-generation vehicles, factories and robots using NVIDIA Omniverse, NVIDIA Cosmos™ and NVIDIA DRIVE AGX™.

[0001045810-25-000115:8k_2_02:58]
•Launched NVIDIA Halos, a unified safety system combining NVIDIA’s automotive hardware, software and advanced AV safety AI research.

[0001045810-25-000115:8k_2_02:59]
•Announced NVIDIA Isaac™ GR00T N1, the world’s first open humanoid robot foundation model, followed by NVIDIA Isaac™ GR00T N1.5; NVIDIA Isaac GR00T-Dreams, a blueprint for generating synthetic motion data; and NVIDIA Blackwell systems to accelerate humanoid robot development.

[0001045810-25-000115:8k_2_02:60]
•Released new NVIDIA Cosmos™ world foundation models and physical AI data tools.

[0001045810-25-000115:8k_2_02:61]
CFO Commentary

[0001045810-25-000115:8k_2_02:62]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-25-000115:8k_2_02:63]
Conference Call and Webcast Information

[0001045810-25-000115:8k_2_02:64]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2026 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its second quarter of fiscal 2026.

[0001045810-25-000115:8k_2_02:65]
Non-GAAP Measures

[0001045810-25-000115:8k_2_02:66]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains/losses from non-marketable and publicly-held equity securities, net, interest expense related to amortization of debt discount, H20 excess inventory and purchase obligation charges, and the associated tax impact of these items where applicable. The inclusion of H20 excess inventory and purchase obligation charges in the reconciliations to adjust the related GAAP financial measures was a result of the U.S. government informing NVIDIA on April 9, 2025 that it requires a license for export to China of H20 products. H20 products were designed primarily for the China market. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-25-000115:8k_2_02:67]
About NVIDIA

[0001045810-25-000115:8k_2_02:68]
NVIDIA (NASDAQ: NVDA) is the world leader in accelerated computing.

[0001045810-25-000115:8k_2_02:69]
###

[0001045810-25-000115:8k_2_02:70]
For further information, contact:

[0001045810-25-000115:8k_2_02:71]
| Toshiya Hari |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| toshiyah@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-25-000115:8k_2_02:72]
Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-25-000115:8k_2_02:73]
© 2025 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, DGX Cloud Lepton, DGX Station, GeForce RTX, NVIDIA Cosmos, NVIDIA DGX SuperPOD, NVIDIA Isaac, NVIDIA Omniverse, NVIDIA RTX PRO, NVIDIA Spectrum-X, and NVLink Fusion are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-25-000115:8k_2_02:74]
NVIDIA CORPORATION

[0001045810-25-000115:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-25-000115:8k_2_02:76]
(In millions, except per share data)

[0001045810-25-000115:8k_2_02:77]
(Unaudited)

[0001045810-25-000115:8k_2_02:78]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 27, |  | April 28, |  |  |  |  |
|  |  |  | 2025 |  | 2024 |  |  |  |  |
| Revenue | $ | 44,062 |  |  | $ | 26,044 |  |  |  |  |  |
| Cost of revenue | 17,394 |  |  | 5,638 |  |  |  |  |  |
| Gross profit | 26,668 |  |  | 20,406 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 3,989 |  |  | 2,720 |  |  |  |  |  |
|  | Sales, general and administrative | 1,041 |  |  | 777 |  |  |  |  |  |
|  |  | Total operating expenses | 5,030 |  |  | 3,497 |  |  |  |  |  |
| Operating income | 21,638 |  |  | 16,909 |  |  |  |  |  |
|  | Interest income | 515 |  |  | 359 |  |  |  |  |  |
|  | Interest expense | (63) |  |  | (64) |  |  |  |  |  |
|  | Other income (expense), net | (180) |  |  | 75 |  |  |  |  |  |
|  |  | Total other income (expense), net | 272 |  |  | 370 |  |  |  |  |  |
| Income before income tax | 21,910 |  |  | 17,279 |  |  |  |  |  |
| Income tax expense | 3,135 |  |  | 2,398 |  |  |  |  |  |
| Net income | $ | 18,775 |  |  | $ | 14,881 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.77 |  |  | $ | 0.60 |  |  |  |  |  |
|  | Diluted | $ | 0.76 |  |  | $ | 0.60 |  |  |  |  |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 24,441 |  |  | 24,620 |  |  |  |  |  |
|  | Diluted | 24,611 |  |  | 24,890 |  |  |  |  |  |

[0001045810-25-000115:8k_2_02:79]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | April 27, |  | January 26, |
|  |  |  |  | 2025 |  | 2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 53,691 |  |  | $ | 43,210 |  |
|  | Accounts receivable, net |  | 22,132 |  |  | 23,065 |  |
|  | Inventories |  | 11,333 |  |  | 10,080 |  |
|  | Prepaid expenses and other current assets |  | 2,779 |  |  | 3,771 |  |
|  |  | Total current assets |  | 89,935 |  |  | 80,126 |  |
| Property and equipment, net |  | 7,136 |  |  | 6,283 |  |
| Operating lease assets |  | 1,810 |  |  | 1,793 |  |
| Goodwill |  | 5,498 |  |  | 5,188 |  |
| Intangible assets, net |  | 769 |  |  | 807 |  |
| Deferred income tax assets |  | 13,318 |  |  | 10,979 |  |
| Other assets |  | 6,788 |  |  | 6,425 |  |
|  |  | Total assets |  | $ | 125,254 |  |  | $ | 111,601 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 7,331 |  |  | $ | 6,310 |  |
|  | Accrued and other current liabilities |  | 19,211 |  |  | 11,737 |  |
|  |  | Total current liabilities |  | 26,542 |  |  | 18,047 |  |
| Long-term debt |  | 8,464 |  |  | 8,463 |  |
| Long-term operating lease liabilities |  | 1,521 |  |  | 1,519 |  |
| Other long-term liabilities |  | 4,884 |  |  | 4,245 |  |
|  |  | Total liabilities |  | 41,411 |  |  | 32,274 |  |
| Shareholders' equity |  | 83,843 |  |  | 79,327 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 125,254 |  |  | $ | 111,601 |  |

[0001045810-25-000115:8k_2_02:80]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  |  |
|  | April 27, |  | April 28, |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 18,775 |  |  | $ | 14,881 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,474 |  |  | 1,011 |  |  |  |  |  |
| Depreciation and amortization | 611 |  |  | 410 |  |  |  |  |  |
| (Gains) losses on non-marketable equity securities and publicly-held equity securities, net | 175 |  |  | (69) |  |  |  |  |  |
| Deferred income taxes | (2,177) |  |  | (1,577) |  |  |  |  |  |
| Other | (98) |  |  | (145) |  |  |  |  |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | 933 |  |  | (2,366) |  |  |  |  |  |
| Inventories | (1,258) |  |  | (577) |  |  |  |  |  |
| Prepaid expenses and other assets | 560 |  |  | (726) |  |  |  |  |  |
| Accounts payable | 941 |  |  | (22) |  |  |  |  |  |
| Accrued and other current liabilities | 7,128 |  |  | 4,202 |  |  |  |  |  |
| Other long-term liabilities | 350 |  |  | 323 |  |  |  |  |  |
| Net cash provided by operating activities | 27,414 |  |  | 15,345 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 3,122 |  |  | 4,004 |  |  |  |  |  |
| Proceeds from sales of marketable securities | 467 |  |  | 149 |  |  |  |  |  |
| Proceeds from sales of non-marketable equity securities | — |  |  | 55 |  |  |  |  |  |
| Purchases of marketable securities | (6,546) |  |  | (9,303) |  |  |  |  |  |
| Purchase related to property and equipment and intangible assets | (1,227) |  |  | (369) |  |  |  |  |  |
| Purchases of non-marketable equity securities | (649) |  |  | (190) |  |  |  |  |  |
| Acquisitions, net of cash acquired | (383) |  |  | (39) |  |  |  |  |  |
| Net cash used in investing activities | (5,216) |  |  | (5,693) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | 370 |  |  | 285 |  |  |  |  |  |
| Payments related to repurchases of common stock | (14,095) |  |  | (7,740) |  |  |  |  |  |
| Payments related to employee stock plans taxes | (1,532) |  |  | (1,752) |  |  |  |  |  |
| Dividends paid | (244) |  |  | (98) |  |  |  |  |  |
| Principal payments on property and equipment and intangible assets | (52) |  |  | (40) |  |  |  |  |  |
| Net cash used in financing activities | (15,553) |  |  | (9,345) |  |  |  |  |  |
| Change in cash and cash equivalents | 6,645 |  |  | 307 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period | 8,589 |  |  | 7,280 |  |  |  |  |  |
| Cash and cash equivalents at end of period | $ | 15,234 |  |  | $ | 7,587 |  |  |  |  |  |

[0001045810-25-000115:8k_2_02:81]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 27, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2025 |  | 2025 |  | 2024 |  |  |  |  |
| GAAP cost of revenue |  | $ | 17,394 |  |  | $ | 10,608 |  |  | $ | 5,638 |  |  |  |  |  |
| GAAP gross profit |  | $ | 26,668 |  |  | $ | 28,723 |  |  | $ | 20,406 |  |  |  |  |  |
| GAAP gross margin |  | 60.5 | % |  | 73.0 | % |  | 78.4 | % |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | 123 |  |  | 118 |  |  | 119 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | 64 |  |  | 53 |  |  | 36 |  |  |  |  |  |
|  | Other |  | 3 |  |  | — |  |  | (1) |  |  |  |  |  |
| Non-GAAP cost of revenue |  | $ | 17,204 |  |  | $ | 10,437 |  |  | $ | 5,484 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 26,858 |  |  | $ | 28,894 |  |  | $ | 20,560 |  |  |  |  |  |
| Non-GAAP gross margin |  | 61.0 | % |  | 73.5 | % |  | 78.9 | % |  |  |  |  |
| GAAP operating expenses |  | $ | 5,030 |  |  | $ | 4,689 |  |  | $ | 3,497 |  |  |  |  |  |
|  | Stock-based compensation expense (B) |  | (1,410) |  |  | (1,268) |  |  | (975) |  |  |  |  |  |
|  | Acquisition-related and other costs (A) |  | (37) |  |  | (43) |  |  | (21) |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 3,583 |  |  | $ | 3,378 |  |  | $ | 2,501 |  |  |  |  |  |
| GAAP operating income |  | $ | 21,638 |  |  | $ | 24,034 |  |  | $ | 16,909 |  |  |  |  |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,637 |  |  | 1,482 |  |  | 1,150 |  |  |  |  |  |
| Non-GAAP operating income |  | $ | 23,275 |  |  | $ | 25,516 |  |  | $ | 18,059 |  |  |  |  |  |
| GAAP total other income (expense), net |  | $ | 272 |  |  | $ | 1,183 |  |  | $ | 370 |  |  |  |  |  |
|  | (Gains) losses from non-marketable equity securities and publicly-held equity securities, net |  | 175 |  |  | (727) |  |  | (69) |  |  |  |  |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  |  |  |  |
| Non-GAAP total other income (expense), net |  | $ | 448 |  |  | $ | 457 |  |  | $ | 302 |  |  |  |  |  |
| GAAP net income |  | $ | 18,775 |  |  | $ | 22,091 |  |  | $ | 14,881 |  |  |  |  |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 1,813 |  |  | 756 |  |  | 1,082 |  |  |  |  |  |
|  | Income tax impact of non-GAAP adjustments (C) |  | (694) |  |  | (781) |  |  | (725) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 19,894 |  |  | $ | 22,066 |  |  | $ | 15,238 |  |  |  |  |  |

[0001045810-25-000115:8k_2_02:82]
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 27, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2025 |  | 2025 |  | 2024 |  |  |  |  |
| Diluted net income per share (D) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.76 |  |  | $ | 0.89 |  |  | $ | 0.60 |  |  |  |  |  |
|  | Non-GAAP |  | $ | 0.81 |  |  | $ | 0.89 |  |  | $ | 0.61 |  |  |  |  |  |
| Weighted average shares used in diluted net income per share computation (D) |  | 24,611 |  |  | 24,706 |  |  | 24,890 |  |  |  |  |  |
| GAAP net cash provided by operating activities |  | $ | 27,414 |  |  | $ | 16,628 |  |  | $ | 15,345 |  |  |  |  |  |
|  | Purchases related to property and equipment and intangible assets |  | (1,227) |  |  | (1,077) |  |  | (369) |  |  |  |  |  |
|  | Principal payments on property and equipment and intangible assets |  | (52) |  |  | (32) |  |  | (40) |  |  |  |  |  |
| Free cash flow |  | $ | 26,135 |  |  | $ | 15,519 |  |  | $ | 14,936 |  |  |  |  |  |

[0001045810-25-000115:8k_2_02:83]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |  |  |  |  |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 27, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2025 |  | 2025 |  | 2024 |  |  |  |  |
|  | Cost of revenue |  | $ | 123 |  |  | $ | 118 |  |  | $ | 119 |  |  |  |  |  |
|  | Research and development |  | $ | 28 |  |  | $ | 27 |  |  | $ | 12 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 9 |  |  | $ | 16 |  |  | $ | 8 |  |  |  |  |  |
| (B) Stock-based compensation consists of the following: |  |  |  |  |
|  |  |  | Three Months Ended |  |  |
|  |  |  | April 27, |  | January 26, |  | April 28, |  |  |  |  |
|  |  |  | 2025 |  | 2025 |  | 2024 |  |  |  |  |
|  | Cost of revenue |  | $ | 64 |  |  | $ | 53 |  |  | $ | 36 |  |  |  |  |  |
|  | Research and development |  | $ | 1,063 |  |  | $ | 955 |  |  | $ | 727 |  |  |  |  |  |
|  | Sales, general and administrative |  | $ | 347 |  |  | $ | 313 |  |  | $ | 248 |  |  |  |  |  |
| (C) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard (ASU 2016-09). |  |  |  |  |
| (D) Reflects a ten-for-one stock split on June 7, 2024. |  |  |  |  |

[0001045810-25-000115:8k_2_02:84]
|  |  |  | Three MonthsEnded |
|  |  |  | April 27, |
|  |  |  | 2025 |
|  |  |  | ($ in millions) |
| GAAP gross profit |  | $ | 26,668 |  |
| GAAP gross margin |  | 60.5 | % |
|  | Stock-based compensation expense, acquisition-related costs, and other costs |  | 190 |  |
|  | H20 excess inventory and purchase obligation charges |  | 4,538 |  |
| Non-GAAP gross profit (as adjusted to exclude H20 excess inventory and purchase obligation charges) |  | $ | 31,396 |  |
| Non-GAAP gross margin (as adjusted to exclude H20 excess inventory and purchase obligation charges) |  | 71.3 | % |
| GAAP net income |  | $ | 18,775 |  |
|  | Total pre-tax impact of non-GAAP adjustments and H20 excess inventory and purchase obligation charges |  | 6,351 |  |
|  | Income tax impact of non-GAAP adjustments and H20 excess inventory and purchase obligation charges |  | (1,491) |  |
| Non-GAAP net income (as adjusted to exclude H20 excess inventory and purchase obligation charges) |  | $ | 23,635 |  |
| Diluted net income per share |  |  |
|  | GAAP |  | $ | 0.76 |  |
|  | Non-GAAP (as adjusted to exclude H20 excess inventory and purchase obligation charges) |  | $ | 0.96 |  |
| Weighted average shares used in diluted net income per share computation |  | 24,611 |  |

[0001045810-25-000115:8k_2_02:85]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2026 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 71.8 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.2 | % |
| Non-GAAP gross margin |  | 72.0 | % |
| GAAP operating expenses |  | $ | 5,700 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,700) |  |
| Non-GAAP operating expenses |  | $ | 4,000 |  |
