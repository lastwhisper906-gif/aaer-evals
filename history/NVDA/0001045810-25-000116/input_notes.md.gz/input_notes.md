# NVDA notes — 0001045810-25-000116


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-25-000116:notes:1]
[same as prior period, unchanged from 0001045810-24-000316:notes:1]

[0001045810-25-000116:notes:2]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. The January 26, 2025 consolidated balance sheet was derived from our audited consolidated financial statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025, as filed with the SEC, but does not include all disclosures required by U.S. GAAP. In the opinion of management, all adjustments, consisting only of normal recurring adjustments considered necessary for a fair presentation of results of operations and financial position, have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025.

[0001045810-25-000116:notes:3]
Certain balances from the prior fiscal year have been reclassified to conform to the current period presentation.

[0001045810-25-000116:notes:4]
In June 2024, we executed a ten-for-one stock split of our common stock. All share, equity award and per share amounts presented herein have been retrospectively adjusted to reflect the stock split.

[0001045810-25-000116:notes:5]
[same as prior period, unchanged from 0001045810-24-000316:notes:4]

[0001045810-25-000116:notes:6]
There have been no material changes to our significant accounting policies disclosed in Note 1 - Organization and Summary of Significant Accounting Policies, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2025.

[0001045810-25-000116:notes:7]
[same as prior period, unchanged from 0001045810-24-000316:notes:6]

[0001045810-25-000116:notes:8]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The first quarters of fiscal years 2026 and 2025 were both 13-week quarters.

[0001045810-25-000116:notes:9]
[same as prior period, unchanged from 0001045810-24-000316:notes:8]

[0001045810-25-000116:notes:10]
[same as prior period, unchanged from 0001045810-24-000316:notes:9]

[0001045810-25-000116:notes:11]
[same as prior period, unchanged from 0001045810-24-000316:notes:10]

[0001045810-25-000116:notes:12]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, non-marketable equity securities, other contingencies, property, plant, and equipment, restructuring and other charges, revenue recognition, and stock-based compensation. These estimates are based on historical facts and various other assumptions that we believe are reasonable.

[0001045810-25-000116:notes:13]
Recently Issued Accounting Pronouncements

[0001045810-25-000116:notes:14]
[same as prior period, unchanged from 0001045810-24-000316:notes:13]

[0001045810-25-000116:notes:15]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the year ending January 25, 2026.

[0001045810-25-000116:notes:16]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in our fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-25-000116:notes:17]
Stock-Based Compensation
Stock-based compensation expense includes restricted stock units, or RSUs, performance stock units, or PSUs, market-based PSUs, and our employee stock purchase plan, or ESPP.

[0001045810-25-000116:notes:18]
Condensed Consolidated Statements of Income include stock-based compensation expense, net of amounts capitalized into inventory, as follows:

[0001045810-25-000116:notes:19]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Cost of revenue | $ | 64 |  |  | $ | 36 |  |  |  |  |  |
| Research and development | 1,063 |  |  | 727 |  |  |  |  |  |
| Sales, general and administrative | 347 |  |  | 248 |  |  |  |  |  |
| Total | $ | 1,474 |  |  | $ | 1,011 |  |  |  |  |  |

[0001045810-25-000116:notes:20]
[same as prior period, unchanged from 0001045810-24-000316:notes:29]

[0001045810-25-000116:notes:21]
[same as prior period, unchanged from 0001045810-24-000316:notes:30]

[0001045810-25-000116:notes:22]
|  | RSUs, PSUs and Market-based PSUs Outstanding |
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value Per Share |
|  | (In millions, except per share data) |
| Balance as of Jan 26, 2025 | 274 |  |  | $ | 44.75 |  |
| Granted | 44 |  |  | $ | 106.43 |  |
| Vested | (39) |  |  | $ | 32.98 |  |
| Canceled and forfeited | (2) |  |  | $ | 48.26 |  |
| Balance as of Apr 27, 2025 | 277 |  |  | $ | 56.32 |  |

[0001045810-25-000116:notes:23]
As of April 27, 2025, aggregate unearned stock-based compensation expense was $15.3 billion, which is expected to be recognized over a weighted average period of 2.3 years for RSUs, PSUs, and market-based PSUs, and 1.1 years for ESPP.


## us-gaap:EarningsPerShareTextBlock

[0001045810-25-000116:notes:24]
Net Income Per Share
The following is the basic and diluted net income per share computations for the periods presented:

[0001045810-25-000116:notes:25]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 18,775 |  |  | $ | 14,881 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average shares | 24,441 |  |  | 24,620 |  |  |  |  |  |
| Dilutive impact of outstanding equity awards | 170 |  |  | 270 |  |  |  |  |  |
| Diluted weighted average shares | 24,611 |  |  | 24,890 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic (1) | $ | 0.77 |  |  | $ | 0.60 |  |  |  |  |  |
| Diluted (2) | $ | 0.76 |  |  | $ | 0.60 |  |  |  |  |  |
| Anti-dilutive equity awards excluded from diluted net income per share | 62 |  |  | 60 |  |  |  |  |  |

[0001045810-25-000116:notes:26]
[same as prior period, unchanged from 0001045810-24-000316:notes:35]

[0001045810-25-000116:notes:27]
[same as prior period, unchanged from 0001045810-24-000316:notes:36]

[0001045810-25-000116:notes:28]
[same as prior period, unchanged from 0001045810-24-000316:notes:37]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-25-000116:notes:29]
Income Taxes
Income tax expense was $3.1 billion and $2.4 billion for the first quarter of fiscal years 2026 and 2025, respectively. Income tax as a percentage of income before income tax was an expense of 14.3% and 13.9% for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:notes:30]
The effective tax rate increased primarily due to a lower tax benefit from stock-based compensation, partially offset by an increase in tax benefit from the foreign-derived intangible income deduction.

[0001045810-25-000116:notes:31]
Our effective tax rates for the first quarter of fiscal years 2026 and 2025 were lower than the U.S. federal statutory rate of 21% primarily due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, income earned in jurisdictions that are subject to taxes at rates lower than the U.S. federal statutory tax rate, and the U.S. federal research tax credit.

[0001045810-25-000116:notes:32]
[same as prior period, unchanged from 0001045810-24-000316:notes:42]

[0001045810-25-000116:notes:33]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where we believe it is not more-likely-than-not that the position will be sustained upon review, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001045810-25-000116:notes:34]
Cash Equivalents and Marketable Securities
The following is a summary of cash equivalents and marketable securities:

[0001045810-25-000116:notes:35]
|  | Apr 27, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 23,135 |  |  | $ | 120 |  |  | $ | (4) |  |  | $ | 23,251 |  |  | $ | 5,414 |  |  | $ | 17,837 |  |
| Corporate debt securities | 19,976 |  |  | 85 |  |  | (10) |  |  | 20,051 |  |  | 2,868 |  |  | 17,183 |  |
| Money market funds | 6,522 |  |  | — |  |  | — |  |  | 6,522 |  |  | 6,522 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,134 |  |  | 12 |  |  | (1) |  |  | 2,145 |  |  | — |  |  | 2,145 |  |
| Certificates of deposit | 126 |  |  | — |  |  | — |  |  | 126 |  |  | 126 |  |  | — |  |
| Foreign government bonds | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 51,933 |  |  | 218 |  |  | (15) |  |  | 52,136 |  |  | 14,930 |  |  | 37,206 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 1,251 |  |  | — |  |  | 1,251 |  |
| Total | $ | 51,933 |  |  | $ | 218 |  |  | $ | (15) |  |  | $ | 53,387 |  |  | $ | 14,930 |  |  | $ | 38,457 |  |

[0001045810-25-000116:notes:36]
(1)    The balance as of the first quarter of fiscal year 2026 includes an investment in CoreWeave, Inc., or CoreWeave, which was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of April 27, 2025 was $1 billion and is subject to a short-term restriction on the ability to sell.

[0001045810-25-000116:notes:37]
Net unrealized losses on investments in publicly-held equity securities held at period end were $222 million for the first quarter of fiscal year 2026. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for the first quarter of fiscal year 2025.

[0001045810-25-000116:notes:38]
|  | Jan 26, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |

[0001045810-25-000116:notes:39]
The following table provides the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

[0001045810-25-000116:notes:40]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 6,854 |  |  | $ | (4) |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 2,775 |  |  | (10) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 321 |  |  | (1) |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 9,950 |  |  | $ | (15) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

[0001045810-25-000116:notes:41]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater of $66 million and $213 million as of April 27, 2025 and January 26, 2025, respectively, were not significant.

[0001045810-25-000116:notes:42]
Gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates.

[0001045810-25-000116:notes:43]
The amortized cost and estimated fair value of debt securities included in cash equivalents and marketable securities are shown below by contractual maturity.

[0001045810-25-000116:notes:44]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 25,756 |  |  | $ | 25,781 |  |  | $ | 18,426 |  |  | $ | 18,450 |  |
| Due in 1 - 5 years | 26,177 |  |  | 26,355 |  |  | 23,636 |  |  | 23,656 |  |
| Total | $ | 51,933 |  |  | $ | 52,136 |  |  | $ | 42,062 |  |  | $ | 42,106 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001045810-25-000116:notes:45]
[same as prior period, unchanged from 0001045810-24-000316:notes:55]


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-25-000116:notes:46]
Fair Value of Financial Assets and Non-marketable Equity Securities
The fair values of our financial assets are determined using quoted market prices of identical assets or market prices of similar assets from active markets. We review fair value classification on a quarterly basis.

[0001045810-25-000116:notes:47]
|  | Pricing Category |  | Fair Value at |
|  |  | Apr 27, 2025 |  | Jan 26, 2025 |
|  |  |  | (In millions) |
| Assets |  |  |  |  |  |
| Cash equivalents and marketable securities: |  |  |  |  |  |
| Money market funds | Level 1 |  | $ | 6,522 |  |  | $ | 3,760 |  |
| Publicly-held equity securities | Level 1 |  | $ | 1,251 |  |  | $ | 381 |  |
| Debt securities issued by the U.S. Treasury | Level 2 |  | $ | 23,251 |  |  | $ | 16,769 |  |
| Corporate debt securities | Level 2 |  | $ | 20,051 |  |  | $ | 18,526 |  |
| Debt securities issued by U.S. government agencies | Level 2 |  | $ | 2,145 |  |  | $ | 2,777 |  |
| Certificates of deposit | Level 2 |  | $ | 126 |  |  | $ | 97 |  |
| Foreign government bonds | Level 2 |  | $ | 41 |  |  | $ | 177 |  |

[0001045810-25-000116:notes:48]
Non-marketable Equity Securities

[0001045810-25-000116:notes:49]
Our non-marketable equity securities are recorded in long-term other assets on our Condensed Consolidated Balance Sheets and valued under the measurement alternative. Gains and losses on these investments, realized and unrealized, are recognized in Other income (expense), net on our Condensed Consolidated Statements of Income.

[0001045810-25-000116:notes:50]
Adjustments to the carrying value of our non-marketable equity securities during the first quarter of fiscal years 2026 and 2025 were as follows:

[0001045810-25-000116:notes:51]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 3,387 |  |  | $ | 1,321 |  |  |  |  |  |
| Adjustments related to non-marketable equity securities: |  |  |  |  |  |  |  |
| Net additions | 649 |  |  | 127 |  |  |  |  |  |
| Unrealized gains | 63 |  |  | 15 |  |  |  |  |  |
| Reclassification (1) | (843) |  |  | — |  |  |  |  |  |
| Impairments and unrealized losses | (16) |  |  | — |  |  |  |  |  |
| Balance at end of period | $ | 3,240 |  |  | $ | 1,463 |  |  |  |  |  |

[0001045810-25-000116:notes:52]
(1)    In the first quarter of fiscal year 2026, our investment in CoreWeave was reclassified from non-marketable equity securities to marketable securities following public market trading.

[0001045810-25-000116:notes:53]
Non-marketable equity securities had cumulative gross unrealized gains of $396 million and $285 million, and cumulative gross unrealized losses and impairments of $110 million and $45 million on securities held as of April 27, 2025 and April 28, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001045810-25-000116:notes:54]
[same as prior period, unchanged from 0001045810-24-000316:notes:65]

[0001045810-25-000116:notes:55]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  | (In millions) |
| Acquisition-related intangible assets | $ | 3,008 |  |  | $ | (2,416) |  |  | $ | 592 |  |  | $ | 2,900 |  |  | $ | (2,264) |  |  | $ | 636 |  |
| Patents and licensed technology | 459 |  |  | (282) |  |  | 177 |  |  | 449 |  |  | (278) |  |  | 171 |  |
| Total intangible assets | $ | 3,467 |  |  | $ | (2,698) |  |  | $ | 769 |  |  | $ | 3,349 |  |  | $ | (2,542) |  |  | $ | 807 |  |

[0001045810-25-000116:notes:56]
Amortization expense associated with intangible assets was $159 million and $143 million for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:notes:57]
The following table outlines the estimated future amortization expense related to the net carrying amount of intangible assets as of April 27, 2025:

[0001045810-25-000116:notes:58]
|  | Future Amortization Expense |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first quarter of fiscal year 2026) | $ | 229 |  |
| 2027 | 276 |  |
| 2028 | 123 |  |
| 2029 | 38 |  |
| 2030 | 11 |  |
| 2031 and thereafter | 92 |  |
| Total | $ | 769 |  |

[0001045810-25-000116:notes:59]
In the first quarter of fiscal year 2026, goodwill increased by $310 million from acquisitions and was allocated to our Compute & Networking reporting unit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001045810-25-000116:notes:60]
Balance Sheet Components
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, original device manufacturers, or ODMs, original equipment manufacturers, or OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. Three direct customers accounted for 27%, 18% and 12% of our accounts receivable balance as of April 27, 2025. Two direct customers accounted for 17% and 16% of our accounts receivable balance as of January 26, 2025.

[0001045810-25-000116:notes:61]
[same as prior period, unchanged from 0001045810-24-000316:notes:72]

[0001045810-25-000116:notes:62]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
| Inventories: | (In millions) |
| Raw materials | $ | 2,525 |  |  | $ | 3,408 |  |
| Work in process | 5,339 |  |  | 3,399 |  |
| Finished goods | 3,469 |  |  | 3,273 |  |
| Total inventories (1) | $ | 11,333 |  |  | $ | 10,080 |  |

[0001045810-25-000116:notes:63]
(1)    We recorded an inventory provision of $2.3 billion in cost of revenue, including $1.9 billion for H20 product inventory for the first quarter of fiscal year 2026. The $1.9 billion inventory provision for H20 product inventory is part of the overall $4.5 billion charge associated with H20 product excess inventory and purchase obligations; the remaining portion is included in excess inventory purchase obligation liabilities. We recorded an inventory provision of $210 million in cost of revenue for the first quarter of fiscal year 2025.

[0001045810-25-000116:notes:64]
Property and Equipment:

[0001045810-25-000116:notes:65]
Property, equipment and intangible assets acquired by assuming related liabilities for the first quarter of fiscal years 2026 and 2025 were $408 million and $147 million, respectively.

[0001045810-25-000116:notes:66]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
| Other Assets (Long Term): | (In millions) |
| Non-marketable equity securities | $ | 3,240 |  |  | $ | 3,387 |  |
| Prepaid supply and capacity agreements (1) | 2,079 |  |  | 1,747 |  |
| Income tax receivable | 895 |  |  | 750 |  |
| Prepaid royalties | 334 |  |  | 340 |  |
| Other | 240 |  |  | 201 |  |
| Total other assets | $ | 6,788 |  |  | $ | 6,425 |  |

[0001045810-25-000116:notes:67]
(1)    Prepaid supply and capacity agreements of $2.1 billion and $3.3 billion were included in Prepaid expenses and other current assets as of April 27, 2025 and January 26, 2025, respectively.

[0001045810-25-000116:notes:68]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
| Accrued and Other Current Liabilities: | (In millions) |
| Taxes payable | $ | 5,672 |  |  | $ | 881 |  |
| Excess inventory purchase obligations (1) | 4,310 |  |  | 2,095 |  |
| Customer program accruals | 4,261 |  |  | 4,880 |  |
| Product warranty and return provisions | 2,168 |  |  | 1,373 |  |
| Deferred revenue (2) | 1,074 |  |  | 837 |  |
| Accrued payroll and related expenses | 748 |  |  | 848 |  |
| Unsettled share repurchases | 306 |  |  | 132 |  |
| Operating leases | 300 |  |  | 288 |  |
| Licenses and royalties | 144 |  |  | 175 |  |
| Other | 228 |  |  | 228 |  |
| Total accrued and other current liabilities | $ | 19,211 |  |  | $ | 11,737 |  |

[0001045810-25-000116:notes:69]
(1)    We recorded excess inventory purchase obligation charges of $3.0 billion in cost of revenue, including $2.6 billion for H20 product orders for the first quarter of fiscal year 2026. The $2.6 billion excess inventory purchase obligation charge for H20 product orders is part of the overall $4.5 billion charge associated with H20 product excess inventory and purchase obligations; the remaining portion is included in Inventories. We recorded excess inventory purchase obligation charges of $183 million in cost of revenue for the first quarter of fiscal year 2025.

[0001045810-25-000116:notes:70]
(2)    Includes customer advances and unearned revenue related to hardware support, software support, cloud services, and license and development arrangements. The balance as of April 27, 2025 and January 26, 2025 included $287 million and $81 million of customer advances, respectively.

[0001045810-25-000116:notes:71]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
| Other Long-Term Liabilities: | (In millions) |
| Income tax payable (1) | $ | 2,509 |  |  | $ | 2,188 |  |
| Deferred income tax | 1,082 |  |  | 886 |  |
| Deferred revenue (2) | 1,004 |  |  | 976 |  |
| Licenses payable | 112 |  |  | 116 |  |
| Other | 177 |  |  | 79 |  |
| Total other long-term liabilities | $ | 4,884 |  |  | $ | 4,245 |  |

[0001045810-25-000116:notes:72]
(1)    Income tax payable is comprised of unrecognized tax benefits and related interest and penalties.

[0001045810-25-000116:notes:73]
[same as prior period, unchanged from 0001045810-24-000316:notes:82]

[0001045810-25-000116:notes:74]
[same as prior period, unchanged from 0001045810-24-000316:notes:83]

[0001045810-25-000116:notes:75]
The following table shows the changes in short- and long-term deferred revenue during the first quarter of fiscal years 2026 and 2025:

[0001045810-25-000116:notes:76]
|  | Three Months Ended |
|  | Apr 27, 2025 |  | Apr 28, 2024 |
|  | (In millions) |
| Balance at beginning of period | $ | 1,813 |  |  | $ | 1,337 |  |
| Deferred revenue additions (1) | 6,493 |  |  | 553 |  |
| Revenue recognized (2) | (6,228) |  |  | (341) |  |
| Balance at end of period | $ | 2,078 |  |  | $ | 1,549 |  |

[0001045810-25-000116:notes:77]
(1)    Deferred revenue additions includes $6.2 billion and $157 million of customer advances for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:notes:78]
(2)    Revenue recognized includes $6.0 billion and $123 million related to customer advances for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:notes:79]
We recognized revenue of $265 million and $188 million in the first quarter of fiscal years 2026 and 2025, respectively, that were included in the prior year end deferred revenue balance.

[0001045810-25-000116:notes:80]
As of April 27, 2025, revenue related to remaining performance obligations from contracts greater than one year in length was $1.8 billion, which includes $1.6 billion from deferred revenue and $160 million which has not yet been billed nor recognized as revenue. Approximately 39% of revenue from contracts greater than one year in length will be recognized over the next twelve months.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001045810-25-000116:notes:81]
Derivative Financial Instruments
We utilize foreign currency forward contracts to mitigate the impact of foreign currency exchange rate movements on our operating expenses. The foreign currency forward contracts for operating expenses are designated as accounting hedges. Gains or losses on the contracts are recorded in accumulated other comprehensive income or loss and reclassified to operating expense when the related operating expenses are recognized in earnings. During the first quarter of fiscal years 2026 and 2025, the impact of foreign currency forward contracts designated as accounting hedges on other comprehensive income or loss was not significant and all such instruments were determined to be highly effective.

[0001045810-25-000116:notes:82]
[same as prior period, unchanged from 0001045810-24-000316:notes:89]

[0001045810-25-000116:notes:83]
[same as prior period, unchanged from 0001045810-24-000316:notes:90]

[0001045810-25-000116:notes:84]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | (In millions) |
| Designated as accounting hedges | $ | 1,477 |  |  | $ | 1,424 |  |
| Not designated as accounting hedges | $ | 988 |  |  | $ | 1,297 |  |

[0001045810-25-000116:notes:85]
The unrealized gains and losses or fair value of our foreign currency contracts were not significant as of April 27, 2025 and January 26, 2025.

[0001045810-25-000116:notes:86]
As of April 27, 2025, all foreign currency contracts mature within eighteen months. The expected realized gains and losses deferred into accumulated other comprehensive income or loss related to foreign currency forward contracts within the next twelve months were not significant.


## us-gaap:DebtDisclosureTextBlock

[0001045810-25-000116:notes:87]
Debt
Long-Term Debt

[0001045810-25-000116:notes:88]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (36) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,464 |  |  | $ | 8,463 |  |

[0001045810-25-000116:notes:89]
As of April 27, 2025 and January 26, 2025, the estimated fair value of debt was $7.3 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

[0001045810-25-000116:notes:90]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity of the notes is calendar year.

[0001045810-25-000116:notes:91]
As of April 27, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

[0001045810-25-000116:notes:92]
Commercial Paper

[0001045810-25-000116:notes:93]
We have a $575 million commercial paper program to support general corporate purposes. As of April 27, 2025, we had no commercial paper outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-25-000116:notes:94]
Commitments and Contingencies
Purchase Obligations

[0001045810-25-000116:notes:95]
Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

[0001045810-25-000116:notes:96]
As of April 27, 2025, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $29.8 billion, an increase from the prior year led by commitments, capacity and components for our Blackwell architecture. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $13.7 billion, including $10.6 billion of multi-year cloud service agreements. We expect our cloud service agreements to primarily be used to support our research and development efforts, as well as our DGX Cloud offerings.

[0001045810-25-000116:notes:97]
Total future purchase commitments as of April 27, 2025 are as follows:

[0001045810-25-000116:notes:98]
|  | Purchase Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first quarter of fiscal year 2026) | $ | 31,445 |  |
| 2027 | 5,923 |  |
| 2028 | 3,110 |  |
| 2029 | 2,072 |  |
| 2030 | 752 |  |
| 2031 and thereafter | 218 |  |
| Total | $ | 43,520 |  |

[0001045810-25-000116:notes:99]
Accrual for Product Warranty Liabilities

[0001045810-25-000116:notes:100]
The estimated amount of product warranty liabilities was $2.1 billion and $1.3 billion as of April 27, 2025 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:

[0001045810-25-000116:notes:101]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 1,290 |  |  | $ | 306 |  |  |  |  |  |
| Additions | 870 |  |  | 234 |  |  |  |  |  |
| Utilization | (80) |  |  | (8) |  |  |  |  |  |
| Balance at end of period | $ | 2,080 |  |  | $ | 532 |  |  |  |  |  |

[0001045810-25-000116:notes:102]
We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

[0001045810-25-000116:notes:103]
Litigation

[0001045810-25-000116:notes:104]
Securities Class Action and Derivative Lawsuits

[0001045810-25-000116:notes:105]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.

[0001045810-25-000116:notes:106]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

[0001045810-25-000116:notes:107]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 5, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Corporation Securities Litigation action, the district court extended the stay for 30 days while the parties discuss next steps and ordered the parties to file a joint status report by March 7, 2025. On March 7, 2025, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

[0001045810-25-000116:notes:108]
Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

[0001045810-25-000116:notes:109]
Accounting for Loss Contingencies

[0001045810-25-000116:notes:110]
As of April 27, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-25-000116:notes:111]
[same as prior period, unchanged from 0001045810-24-000316:notes:119]

[0001045810-25-000116:notes:112]
We repurchased 126 million and 99 million shares of our common stock for $14.5 billion and $8.0 billion during the first quarter of fiscal years 2026 and 2025, respectively. As of April 27, 2025, we were authorized, subject to certain specifications, to repurchase up to $24.3 billion of our common stock.

[0001045810-25-000116:notes:113]
From April 28, 2025 through May 23, 2025, we repurchased 19 million shares for $2.3 billion pursuant to a pre-established trading plan. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-25-000116:notes:114]
We paid cash dividends to our shareholders of $244 million and $98 million during the first quarter of fiscal years 2026 and 2025, respectively. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-25-000116:notes:115]
Segment Information
Our Chief Executive Officer is our chief operating decision maker, or CODM, and reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance. Our CODM assesses operating performance of each segment based on regularly provided segment revenue and segment operating income. Operating results by segment include costs or expenses directly attributable to each segment, and costs or

[0001045810-25-000116:notes:116]
expenses that are leveraged across our unified architecture and therefore allocated between our two segments. Our CODM reviews expenses on a consolidated basis, and expenses attributable to each segment are not regularly provided to our CODM.

[0001045810-25-000116:notes:117]
[same as prior period, unchanged from 0001045810-24-000316:notes:124]

[0001045810-25-000116:notes:118]
The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; virtual GPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating industrial AI and digital twin applications.

[0001045810-25-000116:notes:119]
The “All Other” category includes the expenses that are not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance. The expenses include stock-based compensation expense, corporate infrastructure and support costs, acquisition-related and other costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-25-000116:notes:120]
Our CODM does not review any information regarding total assets on a reportable segment basis. There are no intersegment transactions. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

[0001045810-25-000116:notes:121]
|  | Compute & Networking |  | Graphics |  | All Other |  | Consolidated |
|  | (In millions) |
| Three Months Ended Apr 27, 2025 |  |  |  |  |  |  |  |
| Revenue | $ | 39,589 |  |  | $ | 4,473 |  |  | $ | — |  |  | $ | 44,062 |  |
| Other segment items (1) | 17,535 |  |  | 2,833 |  |  |  |  |  |
| Operating income (loss) | $ | 22,054 |  |  | $ | 1,640 |  |  | $ | (2,056) |  |  | $ | 21,638 |  |
| Three Months Ended Apr 28, 2024 |  |  |  |  |  |  |  |
| Revenue | $ | 22,675 |  |  | $ | 3,369 |  |  | $ | — |  |  | $ | 26,044 |  |
| Other segment items (1) | 5,628 |  |  | 2,128 |  |  |  |  |  |
| Operating income (loss) | $ | 17,047 |  |  | $ | 1,241 |  |  | $ | (1,379) |  |  | $ | 16,909 |  |

[0001045810-25-000116:notes:122]
(1)    Other segment items for the Compute & Networking and Graphics reportable segments primarily include product costs and inventory provisions, compensation and benefits excluding stock-based compensation expense, compute and infrastructure expenses, and engineering development costs.

[0001045810-25-000116:notes:123]
Depreciation and amortization expense attributable to our Compute and Networking segment for the first quarter of fiscal years 2026 and 2025 was $296 million and $146 million, respectively. Depreciation and amortization expense attributable to our Graphics segment for the first quarter of fiscal years 2026 and 2025 was $109 million and $86 million, respectively. Acquisition-related intangible amortization expense is not allocated to either Compute & Networking or Graphics for purposes of making operating decisions or assessing financial performance and is included in “All Other”.

[0001045810-25-000116:notes:124]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Reconciling items included in "All Other" category: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | (1,474) |  |  | $ | (1,011) |  |  |  |  |  |
| Unallocated cost of revenue and operating expenses | (419) |  |  | (229) |  |  |  |  |  |
| Acquisition-related and other costs | (160) |  |  | (140) |  |  |  |  |  |
| Other | (3) |  |  | 1 |  |  |  |  |  |
| Total | $ | (2,056) |  |  | $ | (1,379) |  |  |  |  |  |

[0001045810-25-000116:notes:125]
Revenue by geographic area is based upon the billing location of the customer. The end customer and shipping location may be different from our customer’s billing location.

[0001045810-25-000116:notes:126]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Geographic Revenue based upon Customer Billing Location: |  |  |  |  |  |  |  |
| United States | $ | 20,739 |  |  | $ | 13,496 |  |  |  |  |  |
| Singapore (1) | 9,017 |  |  | 4,037 |  |  |  |  |  |
| Taiwan | 7,158 |  |  | 4,373 |  |  |  |  |  |
| China (including Hong Kong) | 5,522 |  |  | 2,491 |  |  |  |  |  |
| Other | 1,626 |  |  | 1,647 |  |  |  |  |  |
| Total revenue | $ | 44,062 |  |  | $ | 26,044 |  |  |  |  |  |

[0001045810-25-000116:notes:127]
(1)    Singapore represented 20% of the first quarter of fiscal year 2026 total revenue based upon customer billing location. Customers use Singapore to centralize invoicing while our products are almost always shipped elsewhere. Over 99% of controlled Data Center compute revenue billed to Singapore was for orders from U.S.-based customers. Controlled Data Center compute refers to the following NVIDIA products, and any others we develop that meet the characteristics of Export Control Classification Numbers 3A090.a or 4A090.a, including but not limited to: A100, A800, H100, H200, H800, B100, B200, GB200, L4, L40S, and RTX 6000 Ada.

[0001045810-25-000116:notes:128]
Revenue from sales to customers outside of the United States accounted for 53% and 48% of total revenue for the first quarter of fiscal years 2026 and 2025, respectively.

[0001045810-25-000116:notes:129]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as add-in board manufacturers, distributors, ODMs, OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. We also have indirect customers, who purchase products through our direct customers; indirect customers include cloud service providers, or CSPs, consumer internet companies, enterprises, and public sector entities.

[0001045810-25-000116:notes:130]
Sales to one direct customer, Customer A, represented 16% of total revenue and sales to a second direct customer, Customer B, represented 14% of total revenue for the first quarter of fiscal year 2026, both of which were attributable to the Compute & Networking segment. Sales to two direct customers represented 11% and 13% of total revenue for the first quarter of fiscal year 2025, both of which were attributable to the Compute & Networking segment.

[0001045810-25-000116:notes:131]
[same as prior period, unchanged from 0001045810-24-000316:notes:139]

[0001045810-25-000116:notes:132]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Revenue by End Market: |  |  |  |  |  |  |  |
| Data Center | $ | 39,112 |  |  | $ | 22,563 |  |  |  |  |  |
| Compute | 34,155 |  |  | 19,392 |  |  |  |  |  |
| Networking | 4,957 |  |  | 3,171 |  |  |  |  |  |
| Gaming | 3,763 |  |  | 2,647 |  |  |  |  |  |
| Professional Visualization | 509 |  |  | 427 |  |  |  |  |  |
| Automotive | 567 |  |  | 329 |  |  |  |  |  |
| OEM and Other | 111 |  |  | 78 |  |  |  |  |  |
| Total revenue | $ | 44,062 |  |  | $ | 26,044 |  |  |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-25-000116:notes:133]
The table below presents details of our reportable segments and the “All Other” category.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001045810-25-000116:notes:134]
Leases
Our lease obligations primarily consist of operating leases for our headquarters' campus and domestic and international offices and data centers, with lease periods expiring between fiscal years 2026 and 2041.

[0001045810-25-000116:notes:135]
Future minimum lease obligations under our non-cancelable lease agreements as of April 27, 2025 were as follows:

[0001045810-25-000116:notes:136]
|  | Operating Lease Obligations |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first quarter of fiscal year 2026) | $ | 274 |  |
| 2027 | 346 |  |
| 2028 | 349 |  |
| 2029 | 308 |  |
| 2030 | 233 |  |
| 2031 and thereafter | 611 |  |
| Total | 2,121 |  |
| Less imputed interest | 300 |  |
| Present value of net future minimum lease payments | 1,821 |  |
| Less short-term operating lease liabilities | 300 |  |
| Long-term operating lease liabilities | $ | 1,521 |  |

[0001045810-25-000116:notes:137]
Between the second quarter of fiscal year 2026 and fiscal year 2030, we expect to commence leases with future obligations of $7.4 billion primarily of data center and office operating leases, with lease terms of 2 to 15.5 years.

[0001045810-25-000116:notes:138]
Operating lease expenses were $101 million and $80 million for the first quarter of fiscal years 2026 and 2025, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2026 and 2025 were not significant.

[0001045810-25-000116:notes:139]
[same as prior period, unchanged from 0001045810-24-000316:notes:23]

[0001045810-25-000116:notes:140]
|  | Three Months Ended |
|  | Apr 27, 2025 |  | Apr 28, 2024 |
|  | (In millions) |
| Supplemental cash flows information |  |  |  |
| Operating cash flow used for operating leases | $ | 96 |  |  | $ | 69 |  |
| Operating lease assets obtained in exchange for lease obligations | $ | 98 |  |  | $ | 250 |  |

[0001045810-25-000116:notes:141]
As of April 27, 2025, our operating leases have a weighted average remaining lease term of 6.7 years and a weighted average discount rate of 4.27%. As of January 26, 2025, our operating leases had a weighted average remaining lease term of 6.5 years and a weighted average discount rate of 4.16%.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001045810-25-000116:notes:142]
| Name |  | Title of Director or Officer |  | Action |  | Date |  | Total Shares of Common Stock to be Sold |  | Expiration Date |
| Colette M. Kress |  | Executive Vice President and Chief Financial Officer |  | Adoption |  | March 4, 2025 |  | 500,000 |  | March 24, 2026 |
| A. Brooke Seawell |  | Director |  | Adoption |  | March 19, 2025 |  | 1,153,049* |  | July 31, 2025 |
| Jen-Hsun Huang |  | President, Chief Executive Officer and Director |  | Adoption |  | March 20, 2025 |  | 6,000,000 |  | December 31, 2025 |
