# NVDA note change history — 0001045810-24-000316 → 0001045810-25-000116


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-28):
[0001045810-25-000116:note_history:1]
As of April 27, 2025, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $29.8 billion, an increase from the prior year led by commitments, capacity and components for our Blackwell architecture. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $13.7 billion, including $10.6 billion of multi-year cloud service agreements. We expect our cloud service agreements to primarily be used to support our research and development efforts, as well as our DGX Cloud offerings.
  (was, 2024-11-20, similarity 0.923):
[0001045810-24-000316:note_history:1]
As of October 27, 2024, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $28.9 billion, an increase from the prior year primarily due to commitments for Blackwell capacity and components. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $13.2 billion, including $11.3 billion of multi-year cloud service agreements. We expect our cloud service agreements to primarily be used to support our research and development efforts, as well as our DGX Cloud offerings.

- changed (2025-05-28):
[0001045810-25-000116:note_history:2]
Total future purchase commitments as of April 27, 2025 are as follows:
  (was, 2024-11-20, similarity 0.9242):
[0001045810-24-000316:note_history:2]
Total future purchase commitments as of October 27, 2024 are as follows:

- changed (2025-05-28):
[0001045810-25-000116:note_history:3]
|  | Purchase Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2026 (excluding the first quarter of fiscal year 2026) | $ | 31,445 |  |
| 2027 | 5,923 |  |
| 2028 | 3,110 |  |
| 2029 | 2,072 |  |
| 2030 | 752 |  |
| 2031 and thereafter | 218 |  |
| Total | $ | 43,520 |  |
  (was, 2024-11-20, similarity 0.9388):
[0001045810-24-000316:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding the first nine months of fiscal year 2025) | $ | 14,178 |  |
| 2026 | 18,895 |  |
| 2027 | 3,381 |  |
| 2028 | 2,979 |  |
| 2029 | 1,990 |  |
| 2030 and thereafter | 621 |  |
| Total | $ | 42,044 |  |

- changed (2025-05-28):
[0001045810-25-000116:note_history:4]
The estimated amount of product warranty liabilities was $2.1 billion and $1.3 billion as of April 27, 2025 and January 26, 2025, respectively. The estimated product returns and product warranty activity consisted of the following:
  (was, 2024-11-20, similarity 0.9124):
[0001045810-24-000316:note_history:4]
The estimated amount of product warranty liabilities was $1.0 billion and $306 million as of October 27, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:

- added (2025-05-28):
[0001045810-25-000116:note_history:5]
|  | Three Months Ended |  |  |
|  | Apr 27, 2025 |  | Apr 28, 2024 |  |  |  |  |
|  | (In millions) |
| Balance at beginning of period | $ | 1,290 |  |  | $ | 306 |  |  |  |  |  |
| Additions | 870 |  |  | 234 |  |  |  |  |  |
| Utilization | (80) |  |  | (8) |  |  |  |  |  |
| Balance at end of period | $ | 2,080 |  |  | $ | 532 |  |  |  |  |  |

- changed (2025-05-28):
[0001045810-25-000116:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s final disposition of the matter. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. After briefing and argument, the Supreme Court dismissed NVIDIA’s writ of certiorari as improvidently granted on December 11, 2024, and issued judgment on January 13, 2025. On February 20, 2025, the Ninth Circuit’s judgment, entered August 25, 2023 and corrected August 28, 2023, took effect, and the case was remanded to the district court for further proceedings.
  (was, 2024-11-20, similarity 0.7781):
[0001045810-24-000316:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. Briefing concluded on October 25, 2024 and the Supreme Court heard oral arguments on November 13, 2024.

- changed (2025-05-28):
[0001045810-25-000116:note_history:7]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The case has not yet been reopened by the court. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.
  (was, 2024-11-20, similarity 0.9723):
[0001045810-24-000316:note_history:7]
The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The stay remains in place. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

- changed (2025-05-28):
[0001045810-25-000116:note_history:8]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-MN) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798-MN), were stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 5, 2025, after the Supreme Court issued its judgment dismissing the Company’s petition for writ of certiorari as improvidently granted in the In Re NVIDIA Corporation Securities Litigation action, the district court extended the stay for 30 days while the parties discuss next steps and ordered the parties to file a joint status report by March 7, 2025. On March 7, 2025, the district court adopted the parties' stipulation to extend the stay until the final and complete resolution of the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.
  (was, 2024-11-20, similarity 0.7754):
[0001045810-24-000316:note_history:8]
The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

- added (2025-05-28):
[0001045810-25-000116:note_history:9]
As of April 27, 2025, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while reasonably possible, are not probable. Further, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2025-05-28):
[0001045810-24-000316:note_history:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 741 |  |  | $ | 115 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 304 |  |  | 50 |  |  | 775 |  |  | 105 |  |
| Utilization | (36) |  |  | (23) |  |  | (72) |  |  | (45) |  |
| Balance at end of period | $ | 1,009 |  |  | $ | 142 |  |  | $ | 1,009 |  |  | $ | 142 |  |

- removed (2025-05-28):
[0001045810-24-000316:note_history:11]
As of October 27, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-05-28):
[0001045810-25-000116:note_history:12]
Certain balances from the prior fiscal year have been reclassified to conform to the current period presentation.

- added (2025-05-28):
[0001045810-25-000116:note_history:13]
In June 2024, we executed a ten-for-one stock split of our common stock. All share, equity award and per share amounts presented herein have been retrospectively adjusted to reflect the stock split.

- changed (2025-05-28):
[0001045810-25-000116:note_history:14]
Fiscal years 2026 and 2025 are both 52-week years ending on the last Sunday in January. The first quarters of fiscal years 2026 and 2025 were both 13-week quarters.
  (was, 2024-11-20, similarity 0.6548):
[0001045810-24-000316:note_history:14]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The third quarters of fiscal years 2025 and 2024 were both 13-week quarters.

- changed (2025-05-28):
[0001045810-25-000116:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, non-marketable equity securities, other contingencies, property, plant, and equipment, restructuring and other charges, revenue recognition, and stock-based compensation. These estimates are based on historical facts and various other assumptions that we believe are reasonable.
  (was, 2024-11-20, similarity 0.8601):
[0001045810-24-000316:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ materially from our estimates. On an on-going basis, we evaluate our estimates, including those related to accounts receivable, cash equivalents and marketable securities, goodwill, income taxes, inventories and product purchase commitments, investigation and settlement costs, litigation, other contingencies, property, plant, and equipment, revenue recognition, and stock-based compensation. These estimates are based on historical facts and other assumptions that we believe are reasonable.

- changed (2025-05-28):
[0001045810-25-000116:note_history:16]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of information in the rate reconciliation and income taxes paid. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the year ending January 25, 2026.
  (was, 2024-11-20, similarity 0.671):
[0001045810-24-000316:note_history:16]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. We expect to adopt this standard in our fiscal year 2026 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- added (2025-05-28):
[0001045810-25-000116:note_history:17]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory, employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We will adopt this standard in our fiscal year 2028 annual report. We do not expect the adoption of this standard to have a material impact on our Consolidated Financial Statements other than additional disclosures.

- removed (2025-05-28):
[0001045810-24-000316:note_history:18]
In May 2024, we announced a ten-for-one stock split, or the Stock Split, of our issued common stock, which was effected through the filing of an amendment to the Company's Restated Certificate of Incorporation, or the Amendment, with the Secretary of the State of Delaware. In June 2024, the Company filed the Amendment to effect the Stock Split and proportionately increased the number of shares of the Company’s authorized common stock from 8.0 billion to 80.0 billion. Shareholders of record at the close of market on June 6, 2024 received nine additional shares of common stock, distributed after the close of market on June 7, 2024. All share, equity award and per share amounts presented herein have been retrospectively adjusted to reflect the Stock Split.

- removed (2025-05-28):
[0001045810-24-000316:note_history:19]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of significant expenses in operating segments. We expect to adopt this standard in our fiscal year 2025 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- removed (2025-05-28):
[0001045810-24-000316:note_history:20]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory,

- removed (2025-05-28):
[0001045810-24-000316:note_history:21]
employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We expect to adopt this standard in our fiscal year 2028 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-28):
[0001045810-25-000116:note_history:22]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (36) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,464 |  |  | $ | 8,463 |  |
  (was, 2024-11-20, similarity 0.862):
[0001045810-24-000316:note_history:22]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 27, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 1.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (38) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,462 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,462 |  |  | $ | 8,459 |  |

- added (2025-05-28):
[0001045810-25-000116:note_history:23]
As of April 27, 2025 and January 26, 2025, the estimated fair value of debt was $7.3 billion and $7.2 billion, respectively. The estimated fair values are based on Level 2 inputs.

- changed (2025-05-28):
[0001045810-25-000116:note_history:24]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, subject to a make-whole premium. The maturity of the notes is calendar year.
  (was, 2024-11-20, similarity 0.7394):
[0001045810-24-000316:note_history:24]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes is calendar year.

- changed (2025-05-28):
[0001045810-25-000116:note_history:25]
As of April 27, 2025, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2024-11-20, similarity 0.9587):
[0001045810-24-000316:note_history:25]
As of October 27, 2024, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2025-05-28):
[0001045810-25-000116:note_history:26]
We have a $575 million commercial paper program to support general corporate purposes. As of April 27, 2025, we had no commercial paper outstanding.
  (was, 2024-11-20, similarity 0.9645):
[0001045810-24-000316:note_history:26]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2024, we had no commercial paper outstanding.

- removed (2025-05-28):
[0001045810-24-000316:note_history:27]
(1) We repaid the 0.584% Notes Due 2024 in the second quarter of fiscal year 2025.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-28):
[0001045810-25-000116:note_history:28]
|  | Apr 27, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 23,135 |  |  | $ | 120 |  |  | $ | (4) |  |  | $ | 23,251 |  |  | $ | 5,414 |  |  | $ | 17,837 |  |
| Corporate debt securities | 19,976 |  |  | 85 |  |  | (10) |  |  | 20,051 |  |  | 2,868 |  |  | 17,183 |  |
| Money market funds | 6,522 |  |  | — |  |  | — |  |  | 6,522 |  |  | 6,522 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,134 |  |  | 12 |  |  | (1) |  |  | 2,145 |  |  | — |  |  | 2,145 |  |
| Certificates of deposit | 126 |  |  | — |  |  | — |  |  | 126 |  |  | 126 |  |  | — |  |
| Foreign government bonds | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 51,933 |  |  | 218 |  |  | (15) |  |  | 52,136 |  |  | 14,930 |  |  | 37,206 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 1,251 |  |  | — |  |  | 1,251 |  |
| Total | $ | 51,933 |  |  | $ | 218 |  |  | $ | (15) |  |  | $ | 53,387 |  |  | $ | 14,930 |  |  | $ | 38,457 |  |
  (was, 2024-11-20, similarity 0.8971):
[0001045810-24-000316:note_history:28]
|  | Oct 27, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,629 |  |  | $ | 72 |  |  | $ | (12) |  |  | $ | 14,689 |  |  | $ | 1,795 |  |  | $ | 12,894 |  |
| Corporate debt securities | 14,221 |  |  | 74 |  |  | (17) |  |  | 14,278 |  |  | 1,154 |  |  | 13,124 |  |
| Money market funds | 5,147 |  |  | — |  |  | — |  |  | 5,147 |  |  | 5,147 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 3,542 |  |  | 11 |  |  | (4) |  |  | 3,549 |  |  | 759 |  |  | 2,790 |  |
| Certificates of deposit | 142 |  |  | — |  |  | — |  |  | 142 |  |  | 42 |  |  | 100 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 37,681 |  |  | 157 |  |  | (33) |  |  | 37,805 |  |  | 8,897 |  |  | 28,908 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 472 |  |  | — |  |  | 472 |  |
| Total | $ | 37,681 |  |  | $ | 157 |  |  | $ | (33) |  |  | $ | 38,277 |  |  | $ | 8,897 |  |  | $ | 29,380 |  |

- added (2025-05-28):
[0001045810-25-000116:note_history:29]
(1)    The balance as of the first quarter of fiscal year 2026 includes an investment in CoreWeave, Inc., or CoreWeave, which was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of April 27, 2025 was $1 billion and is subject to a short-term restriction on the ability to sell.

- changed (2025-05-28):
[0001045810-25-000116:note_history:30]
|  | Jan 26, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |
  (was, 2024-11-20, similarity 0.6991):
[0001045810-24-000316:note_history:30]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total debt securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

- changed (2025-05-28):
[0001045810-25-000116:note_history:31]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 25,756 |  |  | $ | 25,781 |  |  | $ | 18,426 |  |  | $ | 18,450 |  |
| Due in 1 - 5 years | 26,177 |  |  | 26,355 |  |  | 23,636 |  |  | 23,656 |  |
| Total | $ | 51,933 |  |  | $ | 52,136 |  |  | $ | 42,062 |  |  | $ | 42,106 |  |
  (was, 2024-11-20, similarity 0.9904):
[0001045810-24-000316:note_history:31]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,695 |  |  | $ | 17,715 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 19,986 |  |  | 20,090 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 37,681 |  |  | $ | 37,805 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |

- removed (2025-05-28):
[0001045810-24-000316:note_history:32]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. Beginning in the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-28):
[0001045810-25-000116:note_history:33]
|  | Apr 27, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 23,135 |  |  | $ | 120 |  |  | $ | (4) |  |  | $ | 23,251 |  |  | $ | 5,414 |  |  | $ | 17,837 |  |
| Corporate debt securities | 19,976 |  |  | 85 |  |  | (10) |  |  | 20,051 |  |  | 2,868 |  |  | 17,183 |  |
| Money market funds | 6,522 |  |  | — |  |  | — |  |  | 6,522 |  |  | 6,522 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,134 |  |  | 12 |  |  | (1) |  |  | 2,145 |  |  | — |  |  | 2,145 |  |
| Certificates of deposit | 126 |  |  | — |  |  | — |  |  | 126 |  |  | 126 |  |  | — |  |
| Foreign government bonds | 40 |  |  | 1 |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 51,933 |  |  | 218 |  |  | (15) |  |  | 52,136 |  |  | 14,930 |  |  | 37,206 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 1,251 |  |  | — |  |  | 1,251 |  |
| Total | $ | 51,933 |  |  | $ | 218 |  |  | $ | (15) |  |  | $ | 53,387 |  |  | $ | 14,930 |  |  | $ | 38,457 |  |
  (was, 2024-11-20, similarity 0.8971):
[0001045810-24-000316:note_history:33]
|  | Oct 27, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,629 |  |  | $ | 72 |  |  | $ | (12) |  |  | $ | 14,689 |  |  | $ | 1,795 |  |  | $ | 12,894 |  |
| Corporate debt securities | 14,221 |  |  | 74 |  |  | (17) |  |  | 14,278 |  |  | 1,154 |  |  | 13,124 |  |
| Money market funds | 5,147 |  |  | — |  |  | — |  |  | 5,147 |  |  | 5,147 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 3,542 |  |  | 11 |  |  | (4) |  |  | 3,549 |  |  | 759 |  |  | 2,790 |  |
| Certificates of deposit | 142 |  |  | — |  |  | — |  |  | 142 |  |  | 42 |  |  | 100 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 37,681 |  |  | 157 |  |  | (33) |  |  | 37,805 |  |  | 8,897 |  |  | 28,908 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 472 |  |  | — |  |  | 472 |  |
| Total | $ | 37,681 |  |  | $ | 157 |  |  | $ | (33) |  |  | $ | 38,277 |  |  | $ | 8,897 |  |  | $ | 29,380 |  |

- added (2025-05-28):
[0001045810-25-000116:note_history:34]
(1)    The balance as of the first quarter of fiscal year 2026 includes an investment in CoreWeave, Inc., or CoreWeave, which was reclassified from non-marketable equity securities to marketable securities following public market trading. The fair value of the investment as of April 27, 2025 was $1 billion and is subject to a short-term restriction on the ability to sell.

- changed (2025-05-28):
[0001045810-25-000116:note_history:35]
Net unrealized losses on investments in publicly-held equity securities held at period end were $222 million for the first quarter of fiscal year 2026. Net unrealized gains on investments in publicly-held equity securities held at period end were not significant for the first quarter of fiscal year 2025.
  (was, 2024-11-20, similarity 0.7695):
[0001045810-24-000316:note_history:35]
Net unrealized gains on investments in publicly-held equity securities were not significant and $195 million for the third quarter and first nine months of fiscal year 2025, respectively. Net unrealized gains on investments in publicly-held equity securities were not significant for the third quarter and first nine months of fiscal year 2024.

- changed (2025-05-28):
[0001045810-25-000116:note_history:36]
|  | Jan 26, 2025 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 18,504 |  |  | $ | 51 |  |  | $ | (29) |  |  | $ | 18,526 |  |  | $ | 2,071 |  |  | $ | 16,455 |  |
| Debt securities issued by the U.S. Treasury | 16,749 |  |  | 42 |  |  | (22) |  |  | 16,769 |  |  | 1,801 |  |  | 14,968 |  |
| Money market funds | 3,760 |  |  | — |  |  | — |  |  | 3,760 |  |  | 3,760 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,775 |  |  | 7 |  |  | (5) |  |  | 2,777 |  |  | — |  |  | 2,777 |  |
| Foreign government bonds | 177 |  |  | — |  |  | — |  |  | 177 |  |  | 137 |  |  | 40 |  |
| Certificates of deposit | 97 |  |  | — |  |  | — |  |  | 97 |  |  | 97 |  |  | — |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 42,062 |  |  | 100 |  |  | (56) |  |  | 42,106 |  |  | 7,866 |  |  | 34,240 |  |
| Publicly-held equity securities |  |  |  |  |  |  | 381 |  |  | — |  |  | 381 |  |
| Total | $ | 42,062 |  |  | $ | 100 |  |  | $ | (56) |  |  | $ | 42,487 |  |  | $ | 7,866 |  |  | $ | 34,621 |  |
  (was, 2024-11-20, similarity 0.6991):
[0001045810-24-000316:note_history:36]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total debt securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

- changed (2025-05-28):
[0001045810-25-000116:note_history:37]
The following table provides the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:
  (was, 2024-11-20, similarity 0.9947):
[0001045810-24-000316:note_history:37]
The following tables provide the breakdown of unrealized losses, aggregated by investment category and length of time that individual debt securities have been in a continuous loss position:

- added (2025-05-28):
[0001045810-25-000116:note_history:38]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Less than 12 Months |  |  |  |  |  | Less than 12 Months |  |  |  |  |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |  | Estimated Fair Value |  | Gross Unrealized Loss |  |  |  |  |  |  |  |  |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 6,854 |  |  | $ | (4) |  |  |  |  |  |  |  |  |  |  | $ | 6,315 |  |  | $ | (22) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 2,775 |  |  | (10) |  |  |  |  |  |  |  |  |  |  | 5,291 |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Debt securities issued by U.S. government agencies | 321 |  |  | (1) |  |  |  |  |  |  |  |  |  |  | 816 |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 9,950 |  |  | $ | (15) |  |  |  |  |  |  |  |  |  |  | $ | 12,422 |  |  | $ | (56) |  |  |  |  |  |  |  |  |  |

- added (2025-05-28):
[0001045810-25-000116:note_history:39]
Gross unrealized losses related to debt securities in a continuous loss position of twelve months or greater of $66 million and $213 million as of April 27, 2025 and January 26, 2025, respectively, were not significant.

- changed (2025-05-28):
[0001045810-25-000116:note_history:40]
|  | Apr 27, 2025 |  | Jan 26, 2025 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 25,756 |  |  | $ | 25,781 |  |  | $ | 18,426 |  |  | $ | 18,450 |  |
| Due in 1 - 5 years | 26,177 |  |  | 26,355 |  |  | 23,636 |  |  | 23,656 |  |
| Total | $ | 51,933 |  |  | $ | 52,136 |  |  | $ | 42,062 |  |  | $ | 42,106 |  |
  (was, 2024-11-20, similarity 0.9904):
[0001045810-24-000316:note_history:40]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,695 |  |  | $ | 17,715 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 19,986 |  |  | 20,090 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 37,681 |  |  | $ | 37,805 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |

- removed (2025-05-28):
[0001045810-24-000316:note_history:41]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. Beginning in the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

- removed (2025-05-28):
[0001045810-24-000316:note_history:42]
|  | Oct 27, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Corporate debt securities | $ | 2,967 |  |  | $ | (17) |  |  | $ | 105 |  |  | $ | — |  |  | $ | 3,072 |  |  | $ | (17) |  |
| Debt securities issued by the U.S. Treasury | 2,562 |  |  | (12) |  |  | 532 |  |  | — |  |  | 3,094 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,134 |  |  | (4) |  |  | 21 |  |  | — |  |  | 1,155 |  |  | (4) |  |
| Total | $ | 6,663 |  |  | $ | (33) |  |  | $ | 658 |  |  | $ | — |  |  | $ | 7,321 |  |  | $ | (33) |  |

- removed (2025-05-28):
[0001045810-24-000316:note_history:43]
|  | Jan 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 3,343 |  |  | $ | (5) |  |  | $ | 1,078 |  |  | $ | (5) |  |  | $ | 4,421 |  |  | $ | (10) |  |
| Corporate debt securities | 1,306 |  |  | (3) |  |  | 618 |  |  | (2) |  |  | 1,924 |  |  | (5) |  |
| Debt securities issued by U.S. government agencies | 670 |  |  | (1) |  |  | — |  |  | — |  |  | 670 |  |  | (1) |  |
| Total | $ | 5,319 |  |  | $ | (9) |  |  | $ | 1,696 |  |  | $ | (7) |  |  | $ | 7,015 |  |  | $ | (16) |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-28):
[0001045810-25-000116:note_history:44]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Apr 27, 2025 |  | Jan 26, 2025 |
|  |  |  |  |  |  | (In millions) |
| 3.20% Notes Due 2026 |  | 1.4 |  | 3.31% |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.1 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 4.9 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.1 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 14.9 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 24.9 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.0 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (36) |  |  | (37) |  |
| Net long-term carrying amount |  |  |  |  |  | $ | 8,464 |  |  | $ | 8,463 |  |
  (was, 2024-11-20, similarity 0.862):
[0001045810-24-000316:note_history:44]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 27, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 1.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (38) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,462 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,462 |  |  | $ | 8,459 |  |

- removed (2025-05-28):
[0001045810-24-000316:note_history:45]
(1) We repaid the 0.584% Notes Due 2024 in the second quarter of fiscal year 2025.
