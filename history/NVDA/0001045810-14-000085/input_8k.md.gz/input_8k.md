# NVDA 8-K — 0001045810-14-000076 filed 2014-05-08

## item codes, every 8-K on or before 2014-05-21

- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2014-05-21

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-14-000076:8k_2_02:1]
EX-99.1
2
q115pr.htm
Q1'15 PRESS RELEASE

[0001045810-14-000076:8k_2_02:2]
Q1'15 PR

[0001045810-14-000076:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-14-000076:8k_2_02:4]
NVIDIA Financial Results for First Quarter Fiscal 2015

[0001045810-14-000076:8k_2_02:5]
Adds Second Quarter Outlook and Dividend Dates to May 6 Release

[0001045810-14-000076:8k_2_02:6]
| • | Revenue of $1.103 billion. |

[0001045810-14-000076:8k_2_02:7]
| • | GAAP net income of $136.5 million, or $0.24 per diluted share. Non-GAAP net income of $166.1 million, or $0.29 per diluted share. |

[0001045810-14-000076:8k_2_02:8]
| • | GAAP and non-GAAP gross margins of 54.8 percent and 55.1 percent, respectively. |

[0001045810-14-000076:8k_2_02:9]
SANTA CLARA, Calif.-May 8, 2014-NVIDIA (NASDAQ: NVDA) has reported revenue for the first quarter of fiscal 2015, ended April 27, 2014, of $1.103 billion, up 16 percent from a year earlier  and down 4 percent from $1.144 billion in the previous quarter.

[0001045810-14-000076:8k_2_02:10]
NVIDIA reported its financial results earlier this week because a preliminary draft had been inadvertently emailed to an internal distribution list of about 100 individuals.  Figures contained in the May 6 release are unchanged in this release.

[0001045810-14-000076:8k_2_02:11]
GAAP earnings per diluted share were $0.24, up 85 percent from $0.13 a year earlier, and down 4 percent from $0.25 in the previous quarter.  Non-GAAP earnings per diluted share were $0.29, up 61 percent from $0.18 a year earlier and down 9 percent from $0.32 in the previous quarter.

[0001045810-14-000076:8k_2_02:12]
NVIDIA will pay its next quarterly cash dividend of $0.085 per share on June 13, 2014, to all stockholders of record on May 22, 2014.  NVIDIA expects that a portion of this dividend payment may be considered a return of capital for U.S. federal income tax purposes.

[0001045810-14-000076:8k_2_02:13]
“First quarter results benefited from gains in PC gaming and our continued progress in the data center and cloud,” said Jen-Hsun Huang, president and chief executive officer of NVIDIA.  “Nearly 600 enterprises worldwide are now evaluating GRID, our virtual GPU server platform.  VMware announced support for GRID to enable GPU-accelerated enterprise virtualization.  And with IBM, Dell and HP now selling our GPUs in their high-volume servers, we expect large-scale data centers to be a significant source of growth.”

[0001045810-14-000076:8k_2_02:14]
| GAAP Quarterly Financial Comparison |
| (in millions except per share data) | Q1 FY15 | Q4 FY14 | Q1 FY14 | Q/Q | Y/Y |
| Revenue | $1,102.8 | $1,144.2 | $954.7 | down 4% | up 16% |
| Gross margin | 54.8% | 54.1% | 54.3% | up 70 bps | up 50 bps |
| Operating expenses | $452.8 | $452.3 | $435.8 | flat | up 4% |
| Net income | $136.5 | $146.9 | $77.9 | down 7% | up 75% |
| Earnings per share | $0.24 | $0.25 | $0.13 | down 4% | up 85% |

[0001045810-14-000076:8k_2_02:15]
| Non-GAAP Quarterly Financial Comparison |
| (in millions except per share data) | Q1 FY15 | Q4 FY14 | Q1 FY14 | Q/Q | Y/Y |
| Revenue | $1,102.8 | $1,144.2 | $954.7 | down 4% | up 16% |
| Gross margin | 55.1% | 53.8% | 54.6% | up 130 bps | up 50 bps |
| Operating expenses | $410.8 | $407.8 | $396.2 | up 1% | up 4% |
| Net income | $166.1 | $187.5 | $113.8 | down 11% | up 46% |
| Earnings per share | $0.29 | $0.32 | $0.18 | down 9% | up 61% |

[0001045810-14-000076:8k_2_02:16]
Among highlights of the first quarter of fiscal 2015, NVIDIA:

[0001045810-14-000076:8k_2_02:17]
| • | Expanded its annual GPU Technology Conference, with 25 percent growth in attendees and sessions. |

[0001045810-14-000076:8k_2_02:18]
| • | Refreshed its notebook GPU line-up with new GeForce® GTX™ 800M series products, including its first Maxwell™-based products. |

[0001045810-14-000076:8k_2_02:19]
| • | Disclosed first details of its Pascal™ GPU architecture, which will succeed Maxwell. Pascal will feature NVLink™ interconnect technology, which will be incorporated in future POWER8 CPUs from IBM, and also 3D memory. |

[0001045810-14-000076:8k_2_02:20]
| • | Announced that NVIDIA GRID™ technology is available on the VMware Horizon DaaS Platform. |

[0001045810-14-000076:8k_2_02:21]
| • | Launched Jetson™ TK1, a development platform aimed at automotive, robotics and embedded applications. |

[0001045810-14-000076:8k_2_02:22]
| • | Joined with IBM, Google and others to launch the OpenPOWER Foundation, an initiative to bring IBM’s POWER CPU to mainstream servers. |

[0001045810-14-000076:8k_2_02:23]
NVIDIA’s outlook for the second quarter of fiscal 2015 is as follows:

[0001045810-14-000076:8k_2_02:24]
| • | Revenue is expected to be $1.1 billion, plus or minus two percent. |

[0001045810-14-000076:8k_2_02:25]
| • | GAAP and non-GAAP margins are expected to be approximately 53.7 percent and 54.0 percent, respectively. |

[0001045810-14-000076:8k_2_02:26]
| • | GAAP operating expenses are expected to be approximately $457 million; non-GAAP operating expenses are expected to be approximately $414 million. |

[0001045810-14-000076:8k_2_02:27]
| • | GAAP and non-GAAP tax rates for the second quarter and annual fiscal 2015 are both expected to be 20 percent, plus or minus one percent. These estimates exclude any discrete tax events that may occur during the quarter, which, if realized, may increase or decrease our actual effective tax rates. |

[0001045810-14-000076:8k_2_02:28]
| • | Capital expenditures are expected to be approximately $40 million for the second quarter of fiscal 2015. |

[0001045810-14-000076:8k_2_02:29]
CFO Commentary

[0001045810-14-000076:8k_2_02:30]
Commentary on the quarter by Colette Kress, NVIDIA chief financial officer, is available at http://investor.nvidia.com/.

[0001045810-14-000076:8k_2_02:31]
Conference Call and Webcast Information

[0001045810-14-000076:8k_2_02:32]
NVIDIA will conduct a conference call with analysts and investors to discuss its first quarter fiscal 2015 financial results and current financial prospects today at 2:00 p.m. Pacific Time (5:00 p.m. Eastern Time). To listen to the conference call, dial (303) 223-2684; no password is required. A live webcast (listen-only mode) of the conference call will be accessible at the NVIDIA investor relations web site http://investor.nvidia.com/ and at www.streetevents.com. The webcast will be recorded and available for replay until the company's conference call to discuss its financial results for its second quarter fiscal 2015.

[0001045810-14-000076:8k_2_02:33]
Non-GAAP Measures

[0001045810-14-000076:8k_2_02:34]
To supplement NVIDIA’s Condensed Consolidated Statements of Operations and Condensed Consolidated Balance Sheets presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP other income and expense, non-GAAP income tax expense, non-GAAP net income, non-GAAP net income, or earnings, per share, and free cash flow. In order for NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation, legal settlements, a credit related to a weak die/packaging material set, acquisition-related costs, other expenses, a gain on sale of a non-affiliated investment, interest expense related to the amortization of debt discount, and the associated tax impact of these items, where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less purchases of property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user's overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and our non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-14-000076:8k_2_02:35]
To Keep Current on NVIDIA:

[0001045810-14-000076:8k_2_02:36]
| • | Like NVIDIA on Facebook. |

[0001045810-14-000076:8k_2_02:37]
| • | Connect with NVIDIA on LinkedIn. |

[0001045810-14-000076:8k_2_02:38]
| • | Follow @NVIDIA on Twitter. |

[0001045810-14-000076:8k_2_02:39]
| • | View NVIDIA videos on YouTube. |

[0001045810-14-000076:8k_2_02:40]
| • | Keep up with the NVIDIA Blog. |

[0001045810-14-000076:8k_2_02:41]
| • | Use the Pulse news reader to subscribe to the NVIDIA Daily News feed. |

[0001045810-14-000076:8k_2_02:42]
About NVIDIA

[0001045810-14-000076:8k_2_02:43]
Since 1993, NVIDIA (NASDAQ: NVDA) has pioneered the art and science of visual computing. The company’s technologies are transforming a world of displays into a world of interactive discovery - for everyone from gamers to scientists, and consumers to enterprise customers. More information at http://nvidianews.nvidia.com and http://blogs.nvidia.com.

[0001045810-14-000076:8k_2_02:44]
Certain statements in this press release including, but not limited to statements as to: a portion of the company’s dividend payment being considered a return of capital; the company’s continued progress in the data center and cloud; enterprises evaluating GRID; large-scale data centers being a significant source of growth; the Pascal GPU architecture succeeding Maxwell; the features of Pascal; the company’s financial outlook for the second quarter of, and annual, fiscal 2015; and the company’s tax rate for the second quarter of fiscal 2015 are forward-looking statements that are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing product and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; as well as other factors detailed from time to time in the reports NVIDIA files with the Securities and Exchange Commission, or SEC, including its Form 10-K for the fiscal period ended January 26, 2014. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-14-000076:8k_2_02:45]
© 2014 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce, GeForce GTX, NVIDIA GRID, Jetson, NVLink, Maxwell, Pascal, and SHIELD are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.

[0001045810-14-000076:8k_2_02:46]
###

[0001045810-14-000076:8k_2_02:47]
For further information, contact:

[0001045810-14-000076:8k_2_02:48]
| Chris Evenden |  | Robert Sherbin |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| (408) 627-0608 |  | (408) 566-5150 |
| cevenden@nvidia.com |  | rsherbin@nvidia.com |

[0001045810-14-000076:8k_2_02:49]
NVIDIA CORPORATION

[0001045810-14-000076:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-14-000076:8k_2_02:51]
(In thousands, except per share data)

[0001045810-14-000076:8k_2_02:52]
(Unaudited)

[0001045810-14-000076:8k_2_02:53]
|  | Three Months Ended |
|  | April 27, |  | April 28, |
|  | 2014 |  | 2013 |
| Revenue | $ | 1,102,787 |  |  | $ | 954,739 |  |
| Cost of revenue | 498,585 |  |  | 436,171 |  |
| Gross profit | 604,202 |  |  | 518,568 |  |
| Operating expenses |  |  |  |
| Research and development | 334,263 |  |  | 327,161 |  |
| Sales, general and administrative | 118,580 |  |  | 108,626 |  |
| Total operating expenses | 452,843 |  |  | 435,787 |  |
| Operating income | 151,359 |  |  | 82,781 |  |
| Interest income | 5,710 |  |  | 5,076 |  |
| Interest expense | 11,471 |  |  | 853 |  |
| Other income, net | 17,684 |  |  | 1,058 |  |
| Income before income tax expense | 163,282 |  |  | 88,062 |  |
| Income tax expense | 26,766 |  |  | 10,171 |  |
| Net income | $ | 136,516 |  |  | $ | 77,891 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.13 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.13 |  |
| Weighted average shares used in per share computation: |  |  |  |
| Basic | 559,092 |  |  | 616,872 |  |
| Diluted | 570,422 |  |  | 619,302 |  |

[0001045810-14-000076:8k_2_02:54]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In thousands) |
| (Unaudited) |
|  |  |  | April 27, |  | January 26, |
|  |  |  | 2014 |  | 2014 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 4,347,817 |  |  | $ | 4,671,810 |  |
|  | Accounts receivable, net |  | 396,438 |  |  | 426,357 |  |
|  | Inventories |  | 393,280 |  |  | 387,765 |  |
|  | Prepaid expenses and other current assets |  | 136,263 |  |  | 138,779 |  |
|  | Total current assets |  | 5,273,798 |  |  | 5,624,711 |  |
| Property and equipment, net |  | 570,802 |  |  | 582,740 |  |
| Goodwill |  | 643,179 |  |  | 643,179 |  |
| Intangible assets, net |  | 277,530 |  |  | 296,012 |  |
| Other assets |  | 99,354 |  |  | 104,252 |  |
|  | Total assets |  | $ | 6,864,663 |  |  | $ | 7,250,894 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 309,008 |  |  | $ | 324,391 |  |
|  | Accrued liabilities and other current liabilities |  | 588,937 |  |  | 621,105 |  |
|  | Total current liabilities |  | 897,945 |  |  | 945,496 |  |
| Long-term debt |  | 1,363,276 |  |  | 1,356,375 |  |
| Other long-term liabilities |  | 419,774 |  |  | 475,125 |  |
| Capital lease obligations, long-term |  | 16,683 |  |  | 17,500 |  |
| Stockholders' equity |  | 4,166,985 |  |  | 4,456,398 |  |
|  | Total liabilities and stockholders' equity |  | $ | 6,864,663 |  |  | $ | 7,250,894 |  |

[0001045810-14-000076:8k_2_02:55]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
| (In thousands, except per share data) |
| (Unaudited) |
|  |  | Three Months Ended |
|  |  | April 27, |  | January 26, |  | April 28, |
|  |  | 2014 |  | 2014 |  | 2013 |
| GAAP gross profit |  | $ | 604,202 |  |  | $ | 619,242 |  |  | $ | 518,568 |  |
| GAAP gross margin |  | 54.8 | % |  | 54.1 | % |  | 54.3 | % |
| Stock-based compensation expense included in cost of revenue (A) |  | 2,919 |  |  | 2,777 |  |  | 2,653 |  |
| Legal settlement |  | — |  |  | 1,450 |  |  | — |  |
| Credit from a weak die/packaging material set (B) |  | — |  |  | (7,782 | ) |  | — |  |
| Non-GAAP gross profit |  | $ | 607,121 |  |  | $ | 615,687 |  |  | $ | 521,221 |  |
| Non-GAAP gross margin |  | 55.1 | % |  | 53.8 | % |  | 54.6 | % |
| GAAP operating expenses |  | $ | 452,843 |  |  | $ | 452,318 |  |  | $ | 435,787 |  |
| Stock-based compensation expense included in operating expense (A) |  | (32,602 | ) |  | (33,427 | ) |  | (30,744 | ) |
| Acquisition-related costs (C) |  | (9,441 | ) |  | (9,250 | ) |  | (8,861 | ) |
| Other expense (D) |  | — |  |  | (1,845 | ) |  | — |  |
| Non-GAAP operating expenses |  | $ | 410,800 |  |  | $ | 407,796 |  |  | $ | 396,182 |  |
| GAAP other income and expense | $ | 11,923 |  |  | $ | 1,964 |  |  | $ | 5,281 |  |
| Gain on sale of non-affiliated investments |  | (16,982 | ) |  | (3,074 | ) |  | — |  |
| Interest expense related to amortization of debt discount |  | 6,901 |  |  | 4,600 |  |  | — |  |
| Non-GAAP other income and expense | $ | 1,842 |  |  | $ | 3,490 |  |  | $ | 5,281 |  |
| GAAP net income |  | $ | 136,516 |  |  | $ | 146,917 |  |  | $ | 77,891 |  |
| Total pre-tax impact of non-GAAP adjustments |  | 34,881 |  |  | 42,493 |  |  | 42,258 |  |
| Income tax impact of non-GAAP adjustments |  | (5,342 | ) |  | (1,924 | ) |  | (6,348 | ) |
| Non-GAAP net income |  | $ | 166,055 |  |  | $ | 187,486 |  |  | $ | 113,801 |  |
| Diluted net income per share |  |  |  |  |  |  |
| GAAP |  | $ | 0.24 |  |  | $ | 0.25 |  |  | $ | 0.13 |  |
| Non-GAAP |  | $ | 0.29 |  |  | $ | 0.32 |  |  | $ | 0.18 |  |
| Shares used in diluted net income per share computation |  | 570,422 |  |  | 577,356 |  |  | 619,302 |  |
| Metrics: |  |  |  |  |  |  |
| GAAP net cash flow provided by operating activities |  | $ | 151,022 |  |  | $ | 400,712 |  |  | $ | 175,650 |  |
| Purchase of property and equipment and intangible assets |  | (29,068 | ) |  | (66,374 | ) |  | (65,667 | ) |
| Free cash flow |  | $ | 121,954 |  |  | $ | 334,338 |  |  | $ | 109,983 |  |

[0001045810-14-000076:8k_2_02:56]
| (A) Excludes stock-based compensation as follows: |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  |
|  |  | April 27, |  | January 26, |  | April 28, |  |
|  |  | 2014 |  | 2014 |  | 2013 |  |
| Cost of revenue |  | $ | 2,919 |  |  | $ | 2,777 |  |  | $ | 2,653 |  |  |
| Research and development |  | $ | 20,494 |  |  | $ | 21,548 |  |  | $ | 21,935 |  |  |
| Sales, general and administrative |  | $ | 12,108 |  |  | $ | 11,879 |  |  | $ | 8,809 |  |  |
| (B) Release of the remaining warranty reserve related to a weak die/packaging material set, as of January 26, 2014. |  |
| (C) Consists of amortization of acquisition-related intangible assets, transaction costs, compensation charges, and other credits related to acquisitions. |
| (D) Includes intangible asset write-off and legal settlement costs, net of credits. |

[0001045810-14-000076:8k_2_02:57]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q2 FY2015 Outlook |
| GAAP gross margin |  | 53.7 | % |
|  | Impact of stock-based compensation |  | 0.3 | % |
| Non-GAAP gross margin |  | 54.0 | % |
|  |  |  | Q2 FY2015 Outlook |
|  |  |  | (In millions) |
| GAAP operating expenses |  | $ | 457 |  |
|  | Stock-based compensation expense and acquisition-related costs |  | (43 | ) |
| Non-GAAP operating expenses |  | $ | 414 |  |
