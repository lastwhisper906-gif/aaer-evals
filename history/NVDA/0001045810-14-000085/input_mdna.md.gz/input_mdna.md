# NVDA MD&A — 0001045810-14-000085


## mdna

[0001045810-14-000085:mdna:1]
[same as prior period, unchanged from 0001045810-13-000109:mdna:1]

[0001045810-14-000085:mdna:2]
[same as prior period, unchanged from 0001045810-13-000109:mdna:2]

[0001045810-14-000085:mdna:3]
[same as prior period, unchanged from 0001045810-13-000109:mdna:3]

[0001045810-14-000085:mdna:4]
NVIDIA, the NVIDIA logo, GeForce, NVIDIA GRID, GTX, ICERA, Jetson, Kepler, NVIDIA Maxwell, NVLink, Pascal, Quadro, SHIELD, Tegra, and Tesla are trademarks and/or registered trademarks of NVIDIA Corporation in the United States and other countries. Other company and product names may be trademarks of the respective companies with which they are associated.

[0001045810-14-000085:mdna:5]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 6. Selected Financial Data” of our Annual Report on Form 10-K for the fiscal year ended January 26, 2014 and “Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q, before deciding to purchase, hold or sell shares of our common stock.

[0001045810-14-000085:mdna:6]
[same as prior period, unchanged from 0001045810-13-000109:mdna:6]

[0001045810-14-000085:mdna:7]
[same as prior period, unchanged from 0001045810-13-000109:mdna:7]

[0001045810-14-000085:mdna:8]
NVIDIA is a visual computing company. In a world increasingly filled with visual displays, our graphics technologies let our customers interact with the world of digital ideas, information and entertainment with an efficiency that no other communication medium can match.

[0001045810-14-000085:mdna:9]
Our strategy is to be the world leader in visual computing. We target applications in each of the major computing platforms - PC, cloud, mobile - where we can create value. Our target markets are gaming, design and visualization, high performance computing, or HPC, and data center, and automotive and smart devices. We deploy business models we believe are best suited for each application, whether IP, chips, systems, or NVIDIA-branded devices and services.

[0001045810-14-000085:mdna:10]
We have long been known for bringing video games to life with our PC graphics chips. With our invention of the GPU, we introduced the world to the power of programmable shading, which defines modern computer graphics. Today, we reach well beyond PC graphics and games. Our energy-efficient processors are at the heart of products ranging from smartphones to automobiles to supercomputers. We believe in leveraging our processors and visual computing expertise to create differentiated products.

[0001045810-14-000085:mdna:11]
PC gamers choose our GPUs to enjoy immersive fantasy worlds. Our Tegra system-on-a-chip, or SOC, processors power smartphones, tablets and automobile infotainment systems. Professional designers use our GPUs to create visual effects in movies and design everything from audio headsets to commercial aircraft. Supercomputers take advantage of the massively parallel processing capabilities of our GPUs to accelerate a wide range of important applications, from simulations of viruses to weather forecasting and global oil exploration.

[0001045810-14-000085:mdna:12]
NVIDIA's research and development in visual computing has yielded approximately 7,000 patent assets, including inventions essential to modern computing.

[0001045810-14-000085:mdna:13]
Our businesses are based on two technologies with a consistent underlying graphics architecture: the GPU and the Tegra processor.

[0001045810-14-000085:mdna:14]
GPUs, each with billions of transistors, are the engines of visual computing and among the world's most complex processors. We have GPU product brands aimed at specific users and applications: GeForce for gamers; Quadro for designers; Tesla for researchers; and GRID for cloud-based graphics.

[0001045810-14-000085:mdna:15]
| • | In gaming, GPUs enhance the gaming experience on PCs by improving the visual quality of graphics, increasing the frame rate for smoother gameplay and improving realism by replicating the behavior of light and physical objects. |

[0001045810-14-000085:mdna:16]
| • | For designers, GPUs improve productivity and introduce new capabilities. For example, an architect designing a new building in a CAD package can interact with the model in real time, the model can be more detailed, and photo realistic renderings can be generated for the client. |

[0001045810-14-000085:mdna:17]
| • | Researchers can use GPUs to run their simulations faster while consuming less power, increasing the accuracy of weather forecasts, or pricing financial derivatives more quickly. |

[0001045810-14-000085:mdna:18]
| • | GRID uses GPUs to deliver graphics performance remotely, from the cloud. Uses include gaming, professional applications provided as a service (SaaS) and improving Citrix and VMware installations. |

[0001045810-14-000085:mdna:19]
The Tegra processor is a SOC integrating an entire computer on a single chip. Tegra processors incorporate GPUs and multi-core CPUs together with audio, video and input/output capabilities. They can also be integrated with baseband processors to add voice and data communication. Our Tegra SOC conserves power while delivering state-of-the-art graphics and multimedia processing.

[0001045810-14-000085:mdna:20]
Tegra runs devices like smartphones, tablets and PCs; it can also be embedded into smart devices, such as televisions, monitors, set-top boxes, gaming devices and cars. SHIELD, our Android gaming device based on Tegra, contains proprietary NVIDIA-developed software and system technologies and leverages our deep partnerships with game developers.

[0001045810-14-000085:mdna:21]
Headquartered in Santa Clara, California, we were incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-14-000085:mdna:22]
[same as prior period, unchanged from 0001045810-13-000109:mdna:14]

[0001045810-14-000085:mdna:23]
[same as prior period, unchanged from 0001045810-13-000109:mdna:15]

[0001045810-14-000085:mdna:24]
During the first quarter of fiscal year 2015, we released our new GeForce GTX 750 and GeForce GTX 800M series products which include our NVIDIA Maxwell-based products, and disclosed the first details of our Pascal GPU architecture, which will succeed NVIDIA Maxwell.  Pascal is expected to feature 3D memory and NVLink interconnect technology. NVLink is planned to be incorporated in future POWER8 CPUs from IBM. We also announced that NVIDIA GRID™ technology will be available on the VMware Horizon DaaS Platform to deliver 3D graphics on virtualized desktops and applications delivered through the cloud.  In addition, we joined IBM, Google, and others to launch the OpenPOWER Foundation, an initiative to bring IBM’s POWER CPU to mainstream servers.

[0001045810-14-000085:mdna:25]
[same as prior period, unchanged from 0001045810-13-000109:mdna:19]

[0001045810-14-000085:mdna:26]
During the first quarter of fiscal year 2015, we launched Jetson™ TK1, a development platform aimed at automotive, robotics, defense and embedded applications.

[0001045810-14-000085:mdna:27]
Capital Return to Shareholders

[0001045810-14-000085:mdna:28]
During the first quarter of fiscal year 2015, as part of our stock repurchase program, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank. Under the terms of the ASR, we prepaid $500.0 million to purchase shares of our common stock and received 20.6 million shares on February 20, 2014. Upon final settlement of the ASR in the second quarter of fiscal year 2015, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. Additionally, we paid $46.7 million in cash dividends during the first quarter of fiscal year 2015.  As such, in the aggregate for the first quarter of fiscal year 2015, we executed a total of $546.7 million towards our intended capital return of $1.00 billion to shareholders during fiscal year 2015. Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding the ASR.

[0001045810-14-000085:mdna:29]
[same as prior period, unchanged from 0001045810-13-000109:mdna:26]

[0001045810-14-000085:mdna:30]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments. We report our business in two primary reporting segments - the GPU business and the Tegra Processor business.

[0001045810-14-000085:mdna:31]
Our GPU business leverages our GPU technology across multiple end markets. It comprises four primary product lines: GeForce for consumer desktop and notebook PCs; Quadro for professional workstations; Tesla for high-performance computing; and NVIDIA GRID to provide the power of NVIDIA graphics through the cloud. It also includes other related products, licenses and revenue supporting the GPU business, such as memory products.

[0001045810-14-000085:mdna:32]
Our Tegra Processor business comprises primarily product lines based on our Tegra SOC and modem processor technologies, including Tegra for tablets, smartphones and gaming devices; Icera baseband processors and RF transceivers; automotive computers, including infotainment and navigation systems; and gaming devices, such as SHIELD. It also includes embedded products and license and other revenue associated with game consoles.

[0001045810-14-000085:mdna:33]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-14-000085:mdna:34]
Our CODM does not review any information regarding total assets on a reporting segment basis. We do not have intersegment revenue. The accounting policies for segment reporting are the same as for NVIDIA as a whole. Please refer to Note 14 of the Notes to Condensed Consolidated Financial Statements for further disclosure regarding segment information.

[0001045810-14-000085:mdna:35]
[same as prior period, unchanged from 0001045810-13-000109:mdna:31]

[0001045810-14-000085:mdna:36]
[same as prior period, unchanged from 0001045810-13-000109:mdna:32]

[0001045810-14-000085:mdna:37]
|  | Three Months Ended |  |
|  | April 27, 2014 |  |  | April 28, 2013 |  |
| Revenue | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 45.2 |  |  | 45.7 |  |
| Gross profit | 54.8 |  |  | 54.3 |  |
| Operating expenses |  |  |  |  |  |
| Research and development | 30.3 |  |  | 34.3 |  |
| Sales, general and administrative | 10.8 |  |  | 11.4 |  |
| Total operating expenses | 41.1 |  |  | 45.7 |  |
| Operating income | 13.7 |  |  | 8.7 |  |
| Interest income | 0.5 |  |  | 0.5 |  |
| Interest expense | 1.0 |  |  | 0.1 |  |
| Other income, net | 1.6 |  |  | 0.2 |  |
| Income before income tax expense | 14.8 |  |  | 9.3 |  |
| Income tax expense | 2.4 |  |  | 1.1 |  |
| Net income | 12.4 | % |  | 8.2 | % |

[0001045810-14-000085:mdna:38]
Three months ended April 27, 2014 and April 28, 2013

[0001045810-14-000085:mdna:39]
[same as prior period, unchanged from 0001045810-13-000109:mdna:35]

[0001045810-14-000085:mdna:40]
|  | Three Months Ended |  |
|  | April 27, 2014 |  | April 28, 2013 |  | $Change |  | %Change |  |
|  | (In thousands) |  |  |  |
| GPU | $ | 897.4 |  |  | $ | 785.6 |  |  | $ | 111.8 |  |  | 14.2 | % |  |
| Tegra Processor | 139.4 |  |  | 103.1 |  |  | 36.3 |  |  | 35.2 | % |  |
| All Other | 66.0 |  |  | 66.0 |  |  | — |  |  | — | % |  |
| Total | $ | 1,102.8 |  |  | $ | 954.7 |  |  | $ | 148.1 |  |  | 15.5 | % |  |

[0001045810-14-000085:mdna:41]
Revenue increased by 16% for the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014.  A discussion of our revenue results for each of our operating segments is as follows:

[0001045810-14-000085:mdna:42]
GPU Business. GPU business revenue increased by 14% in the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014. This increase was due primarily to higher revenue from sales of high-end desktop GPU products, including our first Maxwell-based GPUs, and associated memory sales. Revenue from notebook GPU products decreased as overall notebook unit volumes contracted compared to the prior year; however, high-end notebook GPU unit volumes and revenue grew, reflecting increasing demand for gaming notebooks. Quadro and Tesla revenue both increased in the first quarter of fiscal year 2015 compared to the first quarter of fiscal year 2014. The increase in Quadro revenue was attributable primarily to increases in sales of our Kepler-based Quadro products, while the Tesla revenue increase was due primarily to large deals comprising an increasing percentage of the sales.

[0001045810-14-000085:mdna:43]
Tegra Processor Business. Tegra Processor business revenue increased by 35% in the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014.  This increase was driven by higher revenue from the sale of Tegra processors for automobiles and embedded products and higher unit shipments of Tegra 4-based products for smartphones. These increases were partially offset by decreased unit shipments of older generation Tegra 3-based products for tablets and lower license and royalty revenue associated with game consoles.

[0001045810-14-000085:mdna:44]
All Other. We recognized $66.0 million in revenue from the patent cross licensing arrangement with Intel during the first quarter of fiscal years 2015 and 2014.

[0001045810-14-000085:mdna:45]
[same as prior period, unchanged from 0001045810-13-000109:mdna:42]

[0001045810-14-000085:mdna:46]
Revenue from sales to customers outside of the United States and Other Americas accounted for 76% and 74% of total revenue for the first quarter of fiscal years 2015 and 2014, respectively.  Revenue by geographic region is allocated to individual countries based on the location to which the products are initially billed even if the revenue is attributable to end customers in a different location.

[0001045810-14-000085:mdna:47]
Revenue from significant customers, those representing 10% or more of total revenue, was 10% of our total revenue from one customer for the first quarter of fiscal year 2015 and 21% of our total revenue from two customers for the first quarter of fiscal year 2014.

[0001045810-14-000085:mdna:48]
[same as prior period, unchanged from 0001045810-13-000109:mdna:45]

[0001045810-14-000085:mdna:49]
[same as prior period, unchanged from 0001045810-13-000109:mdna:46]

[0001045810-14-000085:mdna:50]
[same as prior period, unchanged from 0001045810-13-000109:mdna:47]

[0001045810-14-000085:mdna:51]
Our overall gross margin was 54.8% and 54.3% for the first quarter of fiscal years 2015 and 2014, respectively.

[0001045810-14-000085:mdna:52]
Charges to cost of sales for inventory provisions totaled $10.3 million and $13.6 million for the first quarter of fiscal years 2015 and 2014, respectively, unfavorably impacting our gross margin by 0.9% and 1.4%, respectively. Sales of inventory that was previously written-off or written-down totaled $5.0 million and $17.1 million for the first quarter of fiscal years 2015 and 2014, respectively, favorably impacting our gross margin by 0.5% and 1.8%, respectively.  As a result, the overall net effect on our gross margin from charges to cost of sales for inventory provisions and sales of items previously written-off or written-down was a 0.4% unfavorable impact for the first quarter of fiscal year 2015 and a 0.4% favorable impact for the first quarter of fiscal year 2014.

[0001045810-14-000085:mdna:53]
[same as prior period, unchanged from 0001045810-13-000109:mdna:52]

[0001045810-14-000085:mdna:54]
GPU Business. The gross margin of our GPU business increased in the first quarter of fiscal year 2015 compared to the first quarter of fiscal year 2014.  GPU gross margins increased primarily due to a richer overall sales mix of our high-end Maxwell and Kepler-based GeForce desktop and notebook GPU products.

[0001045810-14-000085:mdna:55]
Tegra Processor Business. The gross margin of our Tegra Processor business decreased in the first quarter of fiscal year 2015 compared with the first quarter of fiscal year 2014. Tegra Processor gross margins decreased across most product categories and were also negatively impacted by the decline in license and royalty revenue associated with game consoles compared to the prior year.

[0001045810-14-000085:mdna:56]
[same as prior period, unchanged from 0001045810-13-000109:mdna:55]

[0001045810-14-000085:mdna:57]
|  | Three Months Ended |  |
|  | April 27, 2014 |  | April 28, 2013 |  | $Change |  | %Change |  |
|  | (In millions) |  |  |  |
| Research and development expenses | $ | 334.3 |  |  | $ | 327.2 |  |  | $ | 7.1 |  |  | 2.2 | % |
| Sales, general and administrative expenses | 118.6 |  |  | 108.6 |  |  | 10.0 |  |  | 9.2 | % |
| Total operating expenses | $ | 452.9 |  |  | $ | 435.8 |  |  | $ | 17.1 |  |  | 3.9 | % |
| Research and development as a percentage of net revenue | 30.3 |  | % | 34.3 |  | % |  |  |  |  |  |
| Sales, general and administrative as a percentage of net revenue | 10.8 |  | % | 11.4 |  | % |  |  |  |  |  |

[0001045810-14-000085:mdna:58]
[same as prior period, unchanged from 0001045810-13-000109:mdna:57]

[0001045810-14-000085:mdna:59]
Research and development expenses increased by 2% during the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014. This increase was primarily due to a $13.9 million increase in compensation, benefits and stock-based compensation expenses due to the growth in hiring of engineering talent during fiscal year 2014. That increase was partially offset by a $6.6 million decrease in development expenses during the first quarter of fiscal year 2015, as the first quarter of fiscal year 2014 included elevated bring-up costs to support Tegra, SHIELD and GRID products.

[0001045810-14-000085:mdna:60]
[same as prior period, unchanged from 0001045810-13-000109:mdna:60]

[0001045810-14-000085:mdna:61]
Sales, general and administrative expenses increased by 9% during the first quarter of fiscal year 2015 compared to the first quarter of fiscal year 2014. This increase was primarily due to an $11.9 million increase in compensation, benefits and stock-based compensation expenses due to the growth in hiring during fiscal year 2014, partially offset by a $4.6 million decrease in outside professional fees resulting from lower litigation-related costs during the first quarter of fiscal year 2015 compared to first quarter of fiscal year 2014.

[0001045810-14-000085:mdna:62]
Interest Income and Interest Expense

[0001045810-14-000085:mdna:63]
Interest income consists of interest earned on cash, cash equivalents and marketable securities. Interest expense is primarily comprised of coupon interest and debt discount amortization related to the convertible notes issued in December 2013.

[0001045810-14-000085:mdna:64]
Interest income was $5.7 million and $5.1 million during the first quarter of fiscal years 2015 and 2014, respectively. The increase was primarily due to higher average cash balances as we invested the proceeds from the convertible notes we issued in December 2013 in interest bearing securities.

[0001045810-14-000085:mdna:65]
Interest expense was $11.5 million and $0.9 million during the first quarter of fiscal years 2015 and 2014, respectively. The increase was primarily due to $3.8 million for coupon interest and $6.9 million for debt discount amortization related to the convertible notes we issued in December 2013.

[0001045810-14-000085:mdna:66]
Other Income, net

[0001045810-14-000085:mdna:67]
Other income, net consists primarily of realized gains and losses from the sale of marketable securities, sales of investments in non-affiliated companies, and the impact of changes in foreign currency rates. Other income, net was $17.7 million in the first quarter of fiscal year 2015 compared to $1.1 million in the first quarter of fiscal year 2014. The increase was primarily due to a gain of $17.0 million from the sale of non-affiliated investments in the first quarter of fiscal year 2015.

[0001045810-14-000085:mdna:68]
[same as prior period, unchanged from 0001045810-13-000109:mdna:68]

[0001045810-14-000085:mdna:69]
We recognized income tax expense of $26.8 million and $10.2 million during the first quarter of fiscal years 2015 and 2014, respectively. Income tax expense as a percentage of income before taxes, or our effective tax rate, was 16.4% and 11.6% for the first quarter of fiscal years 2015 and 2014, respectively.

[0001045810-14-000085:mdna:70]
The increase in our effective tax rate in the first quarter of fiscal year 2015 compared to the same period in the prior fiscal year was primarily due to the expiration of the U.S. federal research tax credit on December 31, 2013.

[0001045810-14-000085:mdna:71]
Our effective tax rate on income before tax for the first quarter of fiscal year 2015 of 16.4% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate.  Further, our annual projected effective tax rate as of the first quarter of fiscal year 2015 of 20% differs from our actual effective tax rate for the first quarter of fiscal year 2015 of 16.4% due to favorable discrete events that occurred in the first quarter of fiscal year 2015 primarily attributable to the expiration of statutes of limitations in certain non-U.S. jurisdictions for which we had not previously recognized related tax benefits.

[0001045810-14-000085:mdna:72]
Our effective tax rate on income before tax for the first quarter of fiscal year 2014 of 11.6% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax and the benefit of the U.S. federal research tax credit.

[0001045810-14-000085:mdna:73]
[same as prior period, unchanged from 0001045810-13-000109:mdna:72]

[0001045810-14-000085:mdna:74]
[same as prior period, unchanged from 0001045810-13-000109:mdna:73]

[0001045810-14-000085:mdna:75]
|  | As of April 27,2014 |  | As of January 26,2014 |
|  | (In millions) |
| Cash and cash equivalents | $ | 509.2 |  |  | $ | 1,151.6 |  |
| Marketable securities | 3,838.7 |  |  | 3,520.2 |  |
| Cash, cash equivalents, and marketable securities | $ | 4,347.9 |  |  | $ | 4,671.8 |  |

[0001045810-14-000085:mdna:76]
As of April 27, 2014, we had $4.35 billion in cash, cash equivalents and marketable securities, a decrease of $324.0 million from $4.67 billion as of January 26, 2014. This decrease was primarily due to the accelerated share repurchase transaction of $500.0 million that we entered into in February 2014, partially offset by cash generated from operations. Our portfolio of cash equivalents and marketable securities is managed on our behalf by several financial institutions that are required to follow our investment policy, which requires the purchase of high grade investment securities and the diversification of asset type and includes certain limits on our portfolio duration.

[0001045810-14-000085:mdna:77]
|  | Three Months Ended |
|  | April 27, |  | April 28, |
|  | 2014 |  | 2013 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 151.0 |  |  | $ | 175.7 |  |
| Net cash used in investing activities | $ | (330.3 | ) |  | $ | (230.8 | ) |
| Net cash used in financing activities | $ | (463.1 | ) |  | $ | (116.2 | ) |

[0001045810-14-000085:mdna:78]
[same as prior period, unchanged from 0001045810-13-000109:mdna:77]

[0001045810-14-000085:mdna:79]
Operating activities consist primarily of net income for the fiscal period, offset by the impact of non-cash expenses such as depreciation and amortization expense, stock-based compensation expense, and interest expense from the amortization of debt discount, as well as changes in operating assets and liabilities, such as accounts receivable, inventories and accounts payable.

[0001045810-14-000085:mdna:80]
Cash provided by operating activities decreased in the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014. The decrease was primarily due to higher accounts receivable from higher revenue and increased inventory balances for new architecture builds, partially offset by higher net income resulting from improved gross profit and contained operating expenses in the first quarter of fiscal year 2015 compared to the first quarter of fiscal year 2014.

[0001045810-14-000085:mdna:81]
[same as prior period, unchanged from 0001045810-13-000109:mdna:79]

[0001045810-14-000085:mdna:82]
Investing activities consist primarily of purchases, sales and maturities of marketable securities, acquisitions of businesses and purchases of property and equipment, including leasehold improvements for our facilities, and intangible assets.

[0001045810-14-000085:mdna:83]
Cash used in investing activities increased in the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014.  This was primarily due to higher purchases of marketable securities, partially offset by lower spending for property, plant and equipment and intangible asset purchases in the current year, compared to the first quarter of fiscal year 2014.

[0001045810-14-000085:mdna:84]
[same as prior period, unchanged from 0001045810-13-000109:mdna:81]

[0001045810-14-000085:mdna:85]
Financing activities consist primarily of borrowing activities, such as convertible debt issuances or capital leases, and equity-related activities such as proceeds from the issuance of common stock under employee stock plans, or stock repurchases and dividend payments.

[0001045810-14-000085:mdna:86]
Cash used in financing activities increased in the first quarter of fiscal year 2015, compared to the first quarter of fiscal year 2014.  This was primarily due to the $500.0 million accelerated share repurchase transaction that we entered into in February 2014, compared to $100.0 million of repurchases of our common stock in the first quarter of fiscal year 2014. This increase was partially offset by a $57.2 million increase in proceeds from common stock issued under employee stock plans in the first quarter of fiscal year 2015 compared to the prior year period.

[0001045810-14-000085:mdna:87]
[same as prior period, unchanged from 0001045810-13-000109:mdna:83]

[0001045810-14-000085:mdna:88]
[same as prior period, unchanged from 0001045810-13-000109:mdna:84]

[0001045810-14-000085:mdna:89]
All of the cash equivalents and marketable securities are treated as “available-for-sale”. Investments in both fixed and floating rate interest earning instruments carry a degree of interest rate risk. Fixed rate debt securities may have their market value adversely impacted due to a rise in interest rates, while floating rate securities may produce less income than expected if interest rates fall. Due in part to these factors, our future investment income may fall short of expectations due to changes in interest rates or if the decline in fair value of our publicly traded debt or equity investments is judged to be other-than-temporary. We may suffer losses in principal if we are forced to sell securities that decline in market value due to changes in interest rates. However, because any debt securities we hold are classified as “available-for-sale,” no gains or losses are realized in our statement of income due to changes in interest rates unless such securities are sold prior to maturity or unless declines in market values are determined to be other-than-temporary. These securities are reported at fair value with the related unrealized gains and losses included in accumulated other comprehensive income, a component of stockholders’ equity, net of tax.

[0001045810-14-000085:mdna:90]
As of April 27, 2014 and January 26, 2014, we had $4.35 billion and $4.67 billion, respectively, in cash, cash equivalents and marketable securities. Our investment policy requires the purchase of high grade investment securities and the diversification of asset types and includes certain limits on our portfolio duration, as specified in our investment policy guidelines. These guidelines also limit the amount of credit exposure to any one issue, issuer or type of instrument. As of April 27, 2014, we were in compliance with our investment policy.  As of April 27, 2014, our investments in government agencies and government-sponsored enterprises represented 38% of our total investment portfolio, while the financial sector accounted for 33% of our total investment portfolio.  All of our investments are with A/A3 or better rated securities.

[0001045810-14-000085:mdna:91]
We performed an impairment review of our investment portfolio as of April 27, 2014. Based on our quarterly impairment review, we concluded that our investments were appropriately valued and did not record any impairment during the first quarter of fiscal year 2015.

[0001045810-14-000085:mdna:92]
Net realized gains for the first quarter of fiscal years 2015 and 2014 were $0.3 million and $0.1 million, respectively. As of April 27, 2014, we had a net unrealized gain of $6.6 million, which was comprised of gross unrealized gains of $8.4 million, offset by gross unrealized losses of $1.7 million.  As of January 26, 2014, we had a net unrealized gain of $4.8 million, which was comprised of gross unrealized gains of $7.2 million, offset by $2.4 million of gross unrealized losses.

[0001045810-14-000085:mdna:93]
Our accounts receivable are highly concentrated. Two customers accounted for 33% of our accounts receivable balance at April 27, 2014. We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. This allowance consists of an amount identified for specific customers and an amount based on overall estimated exposure.

[0001045810-14-000085:mdna:94]
Our cash balances are held in numerous locations throughout the world, including substantial amounts held outside of the United States. Most of the amounts held outside the United States may be repatriated to the United States.  However, if we repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal income tax at rate of 35% less utilization of any net operating loss carry forwards, and further offset by any applicable research and foreign tax credits, plus any state income taxes on such income.  Repatriation of some foreign balances may be restricted by local laws.

[0001045810-14-000085:mdna:95]
Dividend payments and any stock repurchases must be made from cash held in the United States.  In the first quarter of fiscal year 2015, we made total cash dividend payments of $46.7 million and repurchased $500.0 million of our common stock, utilizing a significant amount of our U.S. cash balance previously taxed as of the end of the first quarter of fiscal year 2015.

[0001045810-14-000085:mdna:96]
[same as prior period, unchanged from 0001045810-13-000109:mdna:92]

[0001045810-14-000085:mdna:97]
Our Board of Directors has authorized us to repurchase up to $3.70 billion of our common stock through January 2016.  As of April 27, 2014, we had repurchased $2.95 billion of that amount, leaving up to $0.75 billion available under this authorization through January 2016. We have announced our intention to return $1.0 billion to shareholders in fiscal year 2015 in the form of share repurchases and dividends. As part of our stock repurchase program, during February 2014 we entered into an accelerated share repurchase agreement to purchase $500.0 million in shares of our common stock. Please refer to Note 13 of the Notes to Condensed Consolidated Financial Statements or further disclosure regarding the accelerated share repurchase agreement.

[0001045810-14-000085:mdna:98]
[same as prior period, unchanged from 0001045810-13-000109:mdna:97]

[0001045810-14-000085:mdna:99]
During the first quarter of fiscal year 2015, we paid $46.7 million in dividends to our common stockholders. This dividend was equivalent to $0.085 per share, or $0.34 per share on an annual basis.  We also declared that we would pay our next quarterly cash dividend of $0.085 per share on June 13, 2014, to all stockholders of record on May 22, 2014.

[0001045810-14-000085:mdna:100]
[same as prior period, unchanged from 0001045810-13-000109:mdna:99]

[0001045810-14-000085:mdna:101]
[same as prior period, unchanged from 0001045810-13-000109:mdna:100]

[0001045810-14-000085:mdna:102]
We believe that our existing cash balances and anticipated cash flows from operations will be sufficient to meet our operating, acquisition, stock repurchase, cash dividend and capital requirements for at least the next twelve months. However, there is no assurance that we will not need to raise additional equity or debt financing within this time frame. Additional financing may not be available on favorable terms or at all and may be dilutive to our then-current stockholders. We also may require additional capital for other purposes not presently contemplated. If we are unable to obtain sufficient capital, we could be required to curtail capital equipment purchases or research and development expenditures, which could harm our business. Factors that could affect our cash used or generated from operations and, as a result, our need to seek additional borrowings or capital include:

[0001045810-14-000085:mdna:103]
[same as prior period, unchanged from 0001045810-13-000109:mdna:102]

[0001045810-14-000085:mdna:104]
[same as prior period, unchanged from 0001045810-13-000109:mdna:103]

[0001045810-14-000085:mdna:105]
[same as prior period, unchanged from 0001045810-13-000109:mdna:104]

[0001045810-14-000085:mdna:106]
[same as prior period, unchanged from 0001045810-13-000109:mdna:105]

[0001045810-14-000085:mdna:107]
[same as prior period, unchanged from 0001045810-13-000109:mdna:106]

[0001045810-14-000085:mdna:108]
[same as prior period, unchanged from 0001045810-13-000109:mdna:107]

[0001045810-14-000085:mdna:109]
As of April 27, 2014, we had outstanding inventory purchase obligations totaling $414.2 million. There were no other material changes in our contractual obligations from those disclosed in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014.

[0001045810-14-000085:mdna:110]
[same as prior period, unchanged from 0001045810-13-000109:mdna:109]

[0001045810-14-000085:mdna:111]
[same as prior period, unchanged from 0001045810-13-000109:mdna:110]

[0001045810-14-000085:mdna:112]
As of April 27, 2014, we had no material off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii).

[0001045810-14-000085:mdna:113]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-14-000085:mdna:114]
Please see Note 1 of the Notes to Condensed Consolidated Financial Statements for a discussion of adoption of new and recently issued accounting pronouncements.
