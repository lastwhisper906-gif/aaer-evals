# NVDA note change history — 0001045810-13-000109 → 0001045810-14-000085


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-05-21):
[0001045810-14-000085:note_history:1]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx. The transaction closed on April 18, 2001. In October 2002, 3dfx filed for bankruptcy.

- changed (2014-05-21):
[0001045810-14-000085:note_history:2]
Following the bankruptcy, in March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us. The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which difference the Trustee estimated to exceed $50.0 million. The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.
  (was, 2013-11-19, similarity 0.9736):
[0001045810-13-000109:note_history:2]
In March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us.  The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which the Trustee estimated to exceed $50.0 million.  The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.

- changed (2014-05-21):
[0001045810-14-000085:note_history:3]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process.
  (was, 2013-11-19, similarity 0.9933):
[0001045810-13-000109:note_history:3]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of approximately $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx.  The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process.

- changed (2014-05-21):
[0001045810-14-000085:note_history:4]
In March 2007, a trial was held regarding certain valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.” This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending. On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment. That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008. The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.
  (was, 2013-11-19, similarity 0.9261):
[0001045810-13-000109:note_history:4]
On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.”  This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending.  On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment.  That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008.  The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.

- changed (2014-05-21):
[0001045810-14-000085:note_history:5]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The appeal is currently pending.
  (was, 2013-11-19, similarity 0.8406):
[0001045810-13-000109:note_history:5]
The District Court's hearing on the Trustee's appeal was held on June 10, 2009. On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor. On January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The appeal remains pending.

- added (2014-05-21):
[0001045810-14-000085:note_history:6]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934.

- added (2014-05-21):
[0001045810-14-000085:note_history:7]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014 and the appeal is currently under submission.

- changed (2014-05-21):
[0001045810-14-000085:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. With the exception of the 3dfx case, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2013-11-19, similarity 0.977):
[0001045810-13-000109:note_history:8]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. With the exception of the 3dfx and product defect litigation cases, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2014-05-21):
[0001045810-13-000109:note_history:9]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx.  The transaction closed on April 18, 2001.  That acquisition, and 3dfx's October 2002 bankruptcy filing, led to four lawsuits against NVIDIA: two brought by 3dfx's former landlords, one by 3dfx's bankruptcy trustee and the fourth by a committee of 3dfx's equity security holders in the bankruptcy estate.  The two landlord cases have been settled with payments from the landlords to NVIDIA, and the equity security holders lawsuit was dismissed with prejudice and no appeal was filed.  Accordingly, only the bankruptcy trustee suit remains outstanding as more fully explained below.

- removed (2014-05-21):
[0001045810-13-000109:note_history:10]
On October 13, 2005, the Bankruptcy Court heard the Trustee's motion for summary adjudication, and on December 23, 2005, denied that motion in all material respects and held that NVIDIA may not dispute that the value of the 3dfx transaction was less than $108.0 million. The Bankruptcy Court denied the Trustee's request to find that the value of the 3dfx assets conveyed to NVIDIA was at least $108.0 million.

- removed (2014-05-21):
[0001045810-13-000109:note_history:11]
On December 21, 2006, the Bankruptcy Court scheduled a trial for one portion of the Trustee's case against NVIDIA. On January 2, 2007, NVIDIA terminated the settlement agreement on grounds that the Bankruptcy Court had failed to proceed toward confirmation of the Creditors' Committee's plan. A non-jury trial began on March 21, 2007 on valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. Specifically, the Bankruptcy Court tried four questions: (1) what did 3dfx transfer to NVIDIA in the APA; (2) of what was transferred, what qualifies as “property” subject to the Bankruptcy Court's avoidance powers under the Uniform Fraudulent Transfer Act and relevant bankruptcy code provisions; (3) what is the fair market value of the “property” identified in answer to question (2); and (4) was the $70.0 million that NVIDIA paid “reasonably equivalent” to the fair market value of that property. The parties completed post-trial briefing on May 25, 2007.

- removed (2014-05-21):
[0001045810-13-000109:note_history:12]
Product Defect Litigation and Securities Cases

- removed (2014-05-21):
[0001045810-13-000109:note_history:13]
Product Defect Litigation

- removed (2014-05-21):
[0001045810-13-000109:note_history:14]
In September, October and November 2008, several putative consumer class action lawsuits were filed against us, asserting various claims arising from a weak die/packaging material set in certain versions of our previous generation products used in notebook configurations.   On February 26, 2009, the various lawsuits were consolidated in the United States District Court for the Northern District of California, San Jose Division, under the caption “The NVIDIA GPU Litigation.”  On March 2, 2009, several of the parties filed motions for appointment of lead counsel and briefs addressing certain related issues.  On April 10, 2009, the District Court appointed Milberg LLP lead counsel.  On May 6, 2009, the plaintiffs filed an Amended Consolidated Complaint, alleging claims for violations of California Business and Professions Code Section 17200, Breach of Implied Warranty under California Civil Code Section 1792, Breach of the Implied Warranty of Merchantability under the laws of 27 other states, Breach of Warranty under the Magnuson-Moss Warranty Act, Unjust Enrichment, violations of the New Jersey Consumer Fraud Act, Strict Liability and Negligence, and violation of California's Consumer Legal Remedies Act.

- removed (2014-05-21):
[0001045810-13-000109:note_history:15]
After extensive motion practice and litigation, plaintiffs on December 14, 2009 filed a Second Amended Consolidated Complaint seeking unspecified damages and asserting claims for violations of California Business and Professions Code Section 17200, Breach of Implied Warranty under California Civil Code Section 1792, Breach of Warranty under the Magnuson-Moss Warranty Act, violations of the New Jersey Consumer Fraud Act, Strict Liability and Negligence, and violation of California's Consumer Legal Remedies Act.

- removed (2014-05-21):
[0001045810-13-000109:note_history:16]
On July 16, 2010, the parties filed a stipulation with the District Court advising that, following mediation they had reached a settlement in principle in The NVIDIA GPU Litigation.  The settlement in principle was subject to certain approvals, including final approval by the court.  As a result of the settlement in principle, and the other estimated settlement, and offsetting insurance reimbursements, NVIDIA recorded a net charge of$12.7 million to sales, general and administrative expense during the second quarter of fiscal year 2011.  In addition, a portion of the $181.2 million of additional charges we recorded against cost of revenue related to the weak die/packaging set during the second quarter of fiscal year 2011, relates to estimated additional repair and replacement costs related to the implementation of these settlements. On August 12, 2010, the parties executed a Stipulation and Agreement of Settlement and Release. On September 15, 2010, the Court issued an order granting preliminary approval of the settlement and providing for notice to the potential class members. The Final Approval Hearing was held on December 20, 2010, and on that same day the Court approved the settlement and entered Final Judgment over several objections. In January 2011, several objectors filed Notices of Appeal of the Final Judgment to the United States Court of Appeals for the Ninth Circuit. The Ninth Circuit heard oral argument on August 13, 2013, and affirmed the District Court’s decision to approve the settlement on August 22, 2013.  This case is now over.

- removed (2014-05-21):
[0001045810-13-000109:note_history:17]
In September 2008, three putative securities class actions, or the Actions, were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The Actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, or the Securities Exchange Act.  On October 30, 2008, the Actions were consolidated under the caption In re NVIDIA Corporation Securities Litigation, Civil Action No. 08-CV-04260-JW (HRL). Lead Plaintiffs and Lead Plaintiffs' Counsel were appointed on December 23, 2008. On February 6, 2009, co-Lead Plaintiff filed a Writ of Mandamus with the Ninth Circuit Court of Appeals challenging the designation of co-Lead Plaintiffs' Counsel. On February 19, 2009, co-Lead Plaintiff filed with the District Court, a motion to stay the District Court proceedings pending resolution of the Writ of Mandamus by the Ninth Circuit. On February 24, 2009, Judge Ware granted the stay. On November 5, 2009, the Court of Appeals issued an opinion reversing the District Court's appointment of one of the lead plaintiffs' counsel, and remanding the matter for further proceedings.   On December 8, 2009, the District Court appointed Milberg LLP and Kahn Swick & Foti, LLC as co-lead counsel.

- removed (2014-05-21):
[0001045810-13-000109:note_history:18]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint for Violations of the Federal Securities Laws, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act.  The consolidated complaint sought unspecified compensatory damages.  We filed a motion to dismiss the consolidated complaint in March 2010 and a hearing was held on June 24, 2010 before Judge Seeborg. On October 19, 2010, Judge Seeborg granted our motion to dismiss with leave to amend. On December 2, 2010, co-Lead Plaintiffs filed a Second Consolidated Amended Complaint.  We moved to dismiss the Second Consolidated Amended Complaint on February 14, 2011.  Following oral argument, on October 12, 2011, Judge Seeborg granted our motion to dismiss without leave to amend, and on November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit.  The appeal has been fully briefed, and a hearing is currently scheduled for January 14, 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-21):
[0001045810-14-000085:note_history:19]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The first quarters of fiscal years 2015 and 2014 are both 13-week quarters.
  (was, 2013-11-19, similarity 0.9847):
[0001045810-13-000109:note_history:19]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2014 and fiscal year 2013 are both 52-week years. The third quarters of fiscal years 2014 and 2013 are both 13-week quarters.

- added (2014-05-21):
[0001045810-14-000085:note_history:20]
Our policy on sales to certain distributors with rights of return is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.

- added (2014-05-21):
[0001045810-14-000085:note_history:21]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with original equipment manufacturers, or OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. The OEMs are not our direct customers and the quantity and mix of demand they place on contract equipment manufacturers and original design manufacturers may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents approximately 0.5% of total revenue.

- changed (2014-05-21):
[0001045810-14-000085:note_history:22]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed. MDF amounts that have been previously recorded against revenue and subsequently expired unclaimed are reversed to revenue. Such amounts have not been significant.
  (was, 2013-11-19, similarity 0.6161):
[0001045810-13-000109:note_history:22]
Our customer programs also include marketing development funds, or MDFs. We account for MDFs as either a reduction of revenue or an operating expense, depending on the nature of the program. MDFs represent monies paid to retailers, system builders, original equipment manufacturers, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered.

- added (2014-05-21):
[0001045810-14-000085:note_history:23]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.

- added (2014-05-21):
[0001045810-14-000085:note_history:24]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to Condensed Consolidated Financial Statements. The potentially dilutive impact of the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted shares when their conversion features are exercisable. However, unless actually exercised, the note hedges will not be included in the calculation of diluted shares, as their pre-exercised effect would be anti-dilutive under the treasury stock method.

- changed (2014-05-21):
[0001045810-14-000085:note_history:25]
In July 2013, the Financial Accounting Standards Board issued updated guidance regarding the presentation of unrecognized tax benefits when a net operating loss carry forward, similar tax loss, or tax credit carry forward exists. The guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carry forward, a similar tax loss, or a tax credit carry forward when settlement in this manner is available under the tax law. We adopted this guidance in our interim period ended April 27, 2014. The adoption of this guidance did not impact our condensed consolidated financial statements, as the guidance was issued to reduce diversity in practice on presentation of unrecognized tax benefits.
  (was, 2013-11-19, similarity 0.6115):
[0001045810-13-000109:note_history:25]
In July 2013, the Financial Accounting Standards Board, or FASB, issued guidance regarding the presentation of unrecognized tax benefits when a net operating loss carryforward, similar tax loss, or tax credit carryforward exists. The new guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward when settlement in this manner is available under the tax law. This guidance is effective on a prospective basis for financial statements issued for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2013. Retrospective and early adoption is permitted.  We expect to adopt this guidance in our interim and annual periods beginning January 27, 2014.  We do not believe the adoption of this guidance will have a material impact on our consolidated financial statements.

- removed (2014-05-21):
[0001045810-13-000109:note_history:26]
Our policy on sales to certain distributors, with rights of return, is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.  Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We accrue for 100% of the potential rebates and do not apply a breakage factor.  We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate.  Unclaimed rebates are reversed to revenue.

- removed (2014-05-21):
[0001045810-13-000109:note_history:27]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory provisions and shipping costs. We write down our inventory to the lower of cost or estimated market value.  Excess, obsolete or unmarketable inventory is completely written off based upon assumptions about future demand, future product purchase commitments, estimated manufacturing yield levels and market conditions.  If actual market conditions are less favorable than those projected by management, or if our current inventory or future product purchase commitments to our suppliers exceed our forecasted future demand for such products, additional future inventory write-downs may be required that could adversely affect our operating results. Inventory reserves once established are not reversed until the related inventory has been sold or scrapped.  If actual market conditions are more favorable than expected and we sell products that we have previously written down, our reported gross margin would be favorably impacted.

- removed (2014-05-21):
[0001045810-13-000109:note_history:28]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of equity awards outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive.

- removed (2014-05-21):
[0001045810-13-000109:note_history:29]
In February 2013, the FASB issued updated guidance requiring entities to report the effect of significant reclassifications to accumulated other comprehensive income on the respective line items in net income. These reclassifications are reported, only if U.S. GAAP requires the entire amount to be reclassified  to net income.  For other amounts that are not required under U.S. GAAP to be reclassified in their entirety from accumulated other comprehensive income to net income in the same reporting period, an entity is required to cross-reference other disclosures required under U.S. GAAP that provide additional detail about those amounts. We adopted this guidance in our interim period ended April 28, 2013. The adoption of this guidance did not impact our financial statements, as the guidance is related to disclosure only, and we have not had significant reclassifications out of accumulated other comprehensive income.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-05-21):
[0001045810-14-000085:note_history:30]
Long-Term Debt

- added (2014-05-21):
[0001045810-14-000085:note_history:31]
1.00 % Convertible Senior Notes Due 2018

- added (2014-05-21):
[0001045810-14-000085:note_history:32]
On December 2, 2013, we issued $1.5 billion of 1.00% convertible senior notes due 2018, or the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

- added (2014-05-21):
[0001045810-14-000085:note_history:33]
Holders may convert their notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter commencing after the fiscal quarter ended on  April 27, 2014 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their notes regardless of the foregoing conditions. Upon conversion, we will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

- added (2014-05-21):
[0001045810-14-000085:note_history:34]
As of April 27, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

- added (2014-05-21):
[0001045810-14-000085:note_history:35]
In accordance with ASC 470-20 Debt with Conversion and Other Options, all cash-settled convertible debt should be separated into debt and equity components at issuance and be assigned a fair value.   The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

- added (2014-05-21):
[0001045810-14-000085:note_history:36]
The initial debt component of the Notes was valued at $1,351.8 million based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $125.7 million and recorded as a debt discount. This amount, together with the $22.5 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $148.2 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

- added (2014-05-21):
[0001045810-14-000085:note_history:37]
The following table presents the carrying amounts of the liability and equity components:

- added (2014-05-21):
[0001045810-14-000085:note_history:38]
|  |  | April 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (136,724 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,363,276 |  |  | $ | 1,356,375 |  |

- added (2014-05-21):
[0001045810-14-000085:note_history:39]
(1)   As of April 27, 2014, the remaining period over which the unamortized debt discount will be amortized is 4.6 years.

- added (2014-05-21):
[0001045810-14-000085:note_history:40]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

- added (2014-05-21):
[0001045810-14-000085:note_history:41]
|  |  | Three Months Ended |
|  |  | April 27, 2014 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |
| Amortization of debt discount |  | 6,901 |  |
| Amortization of debt issuance costs |  | 49 |  |
| Total interest expense related to Notes |  | $ | 10,700 |  |

- added (2014-05-21):
[0001045810-14-000085:note_history:42]
As of April 27, 2014, the fair value of the Notes was $1,692.3 million. The Notes are classified within Level 2 as they are not actively traded in markets.

- added (2014-05-21):
[0001045810-14-000085:note_history:43]
Note Hedges and Warrants

- added (2014-05-21):
[0001045810-14-000085:note_history:44]
The net proceeds from the Notes were $1,477.5 million after payment of the initials purchaser's discount.  Concurrently with the offering of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.16 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would pay to the holders of the Notes upon conversion.  We paid $167.1 million for the Note Hedges.

- added (2014-05-21):
[0001045810-14-000085:note_history:45]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with a strike price to the holders of the Warrants of $27.14 per share. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 74.4 million shares of our common stock. We received $59.1 million for the Warrants transaction.

- added (2014-05-21):
[0001045810-14-000085:note_history:46]
The $108.0 million net cost of the Note Hedges offset by the proceeds from the Warrants is included as a net reduction to additional paid-in capital in the stockholders’ equity section of our condensed consolidated balance sheets, in accordance with the guidance in ASC 815-40 Derivatives and Hedging-Contracts in Entity's Own Equity.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-05-21):
[0001045810-14-000085:note_history:47]
|  |  | April 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (136,724 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,363,276 |  |  | $ | 1,356,375 |  |

- added (2014-05-21):
[0001045810-14-000085:note_history:48]
(1)   As of April 27, 2014, the remaining period over which the unamortized debt discount will be amortized is 4.6 years.

- added (2014-05-21):
[0001045810-14-000085:note_history:49]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

- added (2014-05-21):
[0001045810-14-000085:note_history:50]
|  |  | Three Months Ended |
|  |  | April 27, 2014 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |
| Amortization of debt discount |  | 6,901 |  |
| Amortization of debt issuance costs |  | 49 |  |
| Total interest expense related to Notes |  | $ | 10,700 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2014-05-21):
[0001045810-14-000085:note_history:51]
Our policy on sales to certain distributors with rights of return is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.

- added (2014-05-21):
[0001045810-14-000085:note_history:52]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with original equipment manufacturers, or OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. The OEMs are not our direct customers and the quantity and mix of demand they place on contract equipment manufacturers and original design manufacturers may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents approximately 0.5% of total revenue.

- changed (2014-05-21):
[0001045810-14-000085:note_history:53]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed. MDF amounts that have been previously recorded against revenue and subsequently expired unclaimed are reversed to revenue. Such amounts have not been significant.
  (was, 2013-11-19, similarity 0.6161):
[0001045810-13-000109:note_history:53]
Our customer programs also include marketing development funds, or MDFs. We account for MDFs as either a reduction of revenue or an operating expense, depending on the nature of the program. MDFs represent monies paid to retailers, system builders, original equipment manufacturers, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered.

- removed (2014-05-21):
[0001045810-13-000109:note_history:54]
Our policy on sales to certain distributors, with rights of return, is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.  Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We accrue for 100% of the potential rebates and do not apply a breakage factor.  We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate.  Unclaimed rebates are reversed to revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-05-21):
[0001045810-13-000109:note_history:55]
Subsequent Event

- removed (2014-05-21):
[0001045810-13-000109:note_history:56]
On November 4, 2013, our Board of Directors' authorized an additional $1.0 billion under our share repurchase program and extended the program through January 2016.

- removed (2014-05-21):
[0001045810-13-000109:note_history:57]
On November 7, 2013, we announced a 13% increase in our quarterly cash dividend to $0.085 per share, or $0.34 per share on an annual basis from $0.075 per share, or $0.30 per share on an annual basis.  We also declared to pay our next quarterly cash dividend on December 13, 2013, to all stockholders of record on November 21, 2013.
