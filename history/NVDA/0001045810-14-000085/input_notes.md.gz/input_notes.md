# NVDA notes — 0001045810-14-000085


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001045810-14-000085:notes:1]
|  | April 27, |  | January 26, |
|  | 2014 |  | 2014 |
| Accrued Liabilities and Other: | (In thousands) |
| Deferred revenue, short-term | $ | 265,668 |  |  | $ | 265,616 |  |
| Accrued customer programs (1) | 139,139 |  |  | 157,840 |  |
| Accrued payroll and related expenses | 86,544 |  |  | 109,721 |  |
| Accrued legal settlement (2) | 30,600 |  |  | 30,600 |  |
| Professional service fees | 12,647 |  |  | 13,572 |  |
| Customer advances | 10,043 |  |  | 9,297 |  |
| Warranty accrual (3) | 8,250 |  |  | 7,571 |  |
| Office lease related liabilities | 7,756 |  |  | 3,139 |  |
| Coupon interest on Notes | 6,250 |  |  | 2,500 |  |
| Taxes payable, short-term | 4,497 |  |  | 2,378 |  |
| Other | 17,543 |  |  | 18,871 |  |
| Total accrued liabilities and other | $ | 588,937 |  |  | $ | 621,105 |  |

[0001045810-14-000085:notes:2]
[same as prior period, unchanged from 0001045810-13-000109:notes:2]

[0001045810-14-000085:notes:3]
(2)  Please refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the 3dfx litigation.

[0001045810-14-000085:notes:4]
(3)  Please refer to Note 10 of these Notes to Condensed Consolidated Financial Statements for discussion regarding the warranty accrual.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001045810-14-000085:notes:5]
|  | April 27, 2014 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 2,065,847 |  |  | $ | 2,671 |  |  | $ | (692 | ) |  | $ | 2,067,826 |  |
| Debt securities of United States government agencies | 732,145 |  |  | 684 |  |  | (98 | ) |  | 732,731 |  |
| Debt securities issued by United States Treasury | 584,036 |  |  | 884 |  |  | (40 | ) |  | 584,880 |  |
| Asset-backed securities | 357,216 |  |  | 239 |  |  | (124 | ) |  | 357,331 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 199,362 |  |  | 3,874 |  |  | (795 | ) |  | 202,441 |  |
| Money market funds | 103,396 |  |  | — |  |  | — |  |  | 103,396 |  |
| Total | $ | 4,042,002 |  |  | $ | 8,352 |  |  | $ | (1,749 | ) |  | $ | 4,048,605 |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  | $ | 209,953 |  |
| Marketable securities |  |  |  |  |  |  |  |  |  | 3,838,652 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 4,048,605 |  |

[0001045810-14-000085:notes:6]
|  | January 26, 2014 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |
|  | (In thousands) |
| Corporate debt securities | $ | 1,827,788 |  |  | $ | 1,857 |  |  | $ | (1,065 | ) |  | $ | 1,828,580 |  |
| Debt securities of United States government agencies | 1,012,740 |  |  | 848 |  |  | (261 | ) |  | 1,013,327 |  |
| Debt securities issued by United States Treasury | 495,889 |  |  | 621 |  |  | (57 | ) |  | 496,453 |  |
| Money market funds | 307,865 |  |  | — |  |  | — |  |  | 307,865 |  |
| Asset-backed securities | 258,017 |  |  | 15 |  |  | (315 | ) |  | 257,717 |  |
| Mortgage-backed securities issued by United States government-sponsored enterprises | 185,594 |  |  | 3,837 |  |  | (725 | ) |  | 188,706 |  |
| Total | $ | 4,087,893 |  |  | $ | 7,178 |  |  | $ | (2,423 | ) |  | $ | 4,092,648 |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  | $ | 572,425 |  |
| Marketable securities |  |  |  |  |  |  | 3,520,223 |  |
| Total |  |  |  |  |  |  | $ | 4,092,648 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001045810-14-000085:notes:7]
Commitments and Contingencies

[0001045810-14-000085:notes:8]
3dfx

[0001045810-14-000085:notes:9]
On December 15, 2000, NVIDIA and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or APA, to purchase certain graphics chip assets from 3dfx. The transaction closed on April 18, 2001. In October 2002, 3dfx filed for bankruptcy.

[0001045810-14-000085:notes:10]
Following the bankruptcy, in March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx's bankruptcy estate served a complaint on NVIDIA asserting claims for, among other things, successor liability and fraudulent transfer and seeking additional payments from us. The Trustee's fraudulent transfer theory alleged that NVIDIA had failed to pay reasonably equivalent value for 3dfx's assets, and sought recovery of the difference between the $70.0 million paid and the alleged fair value, which difference the Trustee estimated to exceed $50.0 million. The Trustee's successor liability theory alleged NVIDIA was effectively 3dfx's legal successor and therefore was responsible for all of 3dfx's unpaid liabilities.

[0001045810-14-000085:notes:11]
In early November 2005, after several months of mediation, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors' Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee's claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement. The conditional settlement never progressed substantially through the confirmation process.

[0001045810-14-000085:notes:12]
In March 2007, a trial was held regarding certain valuation issues in the Trustee's constructive fraudulent transfer claims against NVIDIA. On April 30, 2008, the Bankruptcy Court issued its Memorandum Decision After Trial, in which it provided a detailed summary of the trial proceedings and the parties' contentions and evidence and concluded that “the creditors of 3dfx were not injured by the Transaction.” This decision did not entirely dispose of the Trustee's action, however, as the Trustee's claims for successor liability and intentional fraudulent conveyance were still pending. On June 19, 2008, NVIDIA filed a motion for summary judgment to convert the Memorandum Decision After Trial to a final judgment. That motion was granted in its entirety and judgment was entered in NVIDIA's favor on September 11, 2008. The Trustee filed a Notice of Appeal from that judgment on September 22, 2008, and on September 25, 2008, NVIDIA exercised its election to have the appeal heard by the United States District Court.

[0001045810-14-000085:notes:13]
On December 20, 2010, the District Court issued an Order affirming the Bankruptcy Court's entry of summary judgment in NVIDIA's favor, and on January 19, 2011, the Trustee filed a Notice of Appeal to the United States Court of Appeals for the Ninth Circuit. The appeal is currently pending.

[0001045810-14-000085:notes:14]
While the conditional settlement reached in November 2005 never progressed through the confirmation process, the Trustee's case still remains pending on appeal. Accordingly, we have not reversed the accrual of $30.6 million - $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx - that we recorded during the three months ended October 30, 2005, pending resolution of the appeal of the Trustee's case.

[0001045810-14-000085:notes:15]
Securities Cases

[0001045810-14-000085:notes:16]
In September 2008, three putative securities class actions were filed in the United States District Court for the Northern District of California arising out of our announcements on July 2, 2008, that we would take a charge against cost of revenue to cover anticipated costs and expenses arising from a weak die/packaging material set in certain versions of our previous generation MCP and GPU products and that we were revising financial guidance for our second quarter of fiscal year 2009. The actions purport to be brought on behalf of purchasers of NVIDIA stock and assert claims for violations of Sections 10(b) and 20(a) of the Securities Exchange Act of 1934.

[0001045810-14-000085:notes:17]
On January 22, 2010, Plaintiffs filed a Consolidated Amended Class Action Complaint, asserting claims for violations of Section 10(b), Rule 10b-5, and Section 20(a) of the Securities Exchange Act and seeking unspecified compensatory damages. We moved to dismiss the consolidated complaint and on October 19, 2010, Judge Seeborg granted our motion with leave to amend. On December 2, 2010, Plaintiffs filed a Second Consolidated Amended Complaint. We again moved to dismiss and on October 12, 2011, Judge Seeborg again granted our motion to dismiss, this time denying Plaintiffs leave to amend.  On November 8, 2011, Plaintiffs filed a Notice of Appeal to the Ninth Circuit. Oral argument was held on January 14, 2014 and the appeal is currently under submission.

[0001045810-14-000085:notes:18]
Accounting for Loss Contingencies

[0001045810-14-000085:notes:19]
While there can be no assurance of favorable outcomes, we believe the claims made by other parties in the above ongoing matters are without merit and we intend to vigorously defend the actions. With the exception of the 3dfx case, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We are engaged in other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.


## us-gaap:ConsolidationPolicyTextBlock

[0001045810-14-000085:notes:20]
Principles of Consolidation

[0001045810-14-000085:notes:21]
Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and its wholly-owned subsidiaries. All material inter-company balances and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001045810-14-000085:notes:22]
Long-Term Debt

[0001045810-14-000085:notes:23]
1.00 % Convertible Senior Notes Due 2018

[0001045810-14-000085:notes:24]
On December 2, 2013, we issued $1.5 billion of 1.00% convertible senior notes due 2018, or the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.00% per annum. The Notes will mature on December 1, 2018 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 49.60 shares of common stock per $1,000 principal amount of Notes (equivalent to an initial conversion price of $20.16 per share of common stock), subject to adjustment as described in the indenture governing the Notes.

[0001045810-14-000085:notes:25]
Holders may convert their notes at their option at any time prior to August 1, 2018 only under the following circumstances: (1) during any fiscal quarter commencing after the fiscal quarter ended on  April 27, 2014 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price on each applicable trading day; (2) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after August 1, 2018 to the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert all or any portion of their notes regardless of the foregoing conditions. Upon conversion, we will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination of cash and shares of our common stock, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0001045810-14-000085:notes:26]
As of April 27, 2014, none of the conditions allowing holders of the Notes to convert had been met. The determination of whether or not the Notes are convertible must be performed quarterly. If the Notes become convertible at the option of the holder, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in the mezzanine equity section on our Condensed Consolidated Balance Sheets.

[0001045810-14-000085:notes:27]
In accordance with ASC 470-20 Debt with Conversion and Other Options, all cash-settled convertible debt should be separated into debt and equity components at issuance and be assigned a fair value.   The value assigned to the debt component is the estimated fair value, as of the issuance date, of a similar debt without the conversion feature. The difference between the net cash proceeds and this estimated fair value, represents the value assigned to the equity component and is recorded as a debt discount. The debt discount is amortized using the effective interest method from the origination date through its stated contractual maturity date.

[0001045810-14-000085:notes:28]
The initial debt component of the Notes was valued at $1,351.8 million based on the contractual cash flows discounted at an appropriate market rate for a non-convertible debt at the date of issuance, which was determined to be 3.15%. The carrying value of the permanent equity component reported in additional paid-in-capital was valued at $125.7 million and recorded as a debt discount. This amount, together with the $22.5 million purchaser's discount to the par value of the Notes represents the total unamortized debt discount of $148.2 million we recorded at the time of issuance of the Notes. The aggregate debt discount is amortized as interest expense over the contractual term of the Notes using the effective interest method using an interest rate of 3.15%.

[0001045810-14-000085:notes:29]
The following table presents the carrying amounts of the liability and equity components:

[0001045810-14-000085:notes:30]
|  |  | April 27,2014 |  | January 26,2014 |
|  |  | (In thousands) |
| Amount of the equity component |  | $ | 125,725 |  |  | $ | 125,725 |  |
| 1.00% convertible senior notes due 2018 |  | $ | 1,500,000 |  |  | $ | 1,500,000 |  |
| Unamortized debt discount (1) |  | (136,724 | ) |  | (143,625 | ) |
| Net carrying amount |  | $ | 1,363,276 |  |  | $ | 1,356,375 |  |

[0001045810-14-000085:notes:31]
(1)   As of April 27, 2014, the remaining period over which the unamortized debt discount will be amortized is 4.6 years.

[0001045810-14-000085:notes:32]
The following table presents the interest expense for the contractual interest and the accretion of debt discount:

[0001045810-14-000085:notes:33]
|  |  | Three Months Ended |
|  |  | April 27, 2014 |
|  |  | (In thousands) |
| Contractual coupon interest expense |  | $ | 3,750 |  |
| Amortization of debt discount |  | 6,901 |  |
| Amortization of debt issuance costs |  | 49 |  |
| Total interest expense related to Notes |  | $ | 10,700 |  |

[0001045810-14-000085:notes:34]
As of April 27, 2014, the fair value of the Notes was $1,692.3 million. The Notes are classified within Level 2 as they are not actively traded in markets.

[0001045810-14-000085:notes:35]
Note Hedges and Warrants

[0001045810-14-000085:notes:36]
The net proceeds from the Notes were $1,477.5 million after payment of the initials purchaser's discount.  Concurrently with the offering of the Notes, we entered into a convertible note hedge transaction, or the Note Hedges, with a strike price equal to the initial conversion price of the Notes, or $20.16 per share. The Note Hedges allow us to receive shares of our common stock and/or cash related to the excess conversion value that we would pay to the holders of the Notes upon conversion.  We paid $167.1 million for the Note Hedges.

[0001045810-14-000085:notes:37]
In addition, concurrent with the offering of the Notes and the purchase of the Note Hedges, we entered into a separate warrant transaction, or the Warrants, with a strike price to the holders of the Warrants of $27.14 per share. The Warrants are net share settled and cover, subject to customary anti-dilution adjustments, 74.4 million shares of our common stock. We received $59.1 million for the Warrants transaction.

[0001045810-14-000085:notes:38]
The $108.0 million net cost of the Note Hedges offset by the proceeds from the Warrants is included as a net reduction to additional paid-in capital in the stockholders’ equity section of our condensed consolidated balance sheets, in accordance with the guidance in ASC 815-40 Derivatives and Hedging-Contracts in Entity's Own Equity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001045810-14-000085:notes:39]
[same as prior period, unchanged from 0001045810-13-000109:notes:29]

[0001045810-14-000085:notes:40]
Our stock-based compensation expense is associated with stock options, restricted stock units, or RSUs, and performance stock units, or PSUs, and is measured based on the estimated fair value of equity awards at the grant date.

[0001045810-14-000085:notes:41]
We estimate the fair value of employee stock options on the date of grant using a binomial model and recognize the expense using a straight-line attribution method over the requisite employee service period. We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of RSUs and PSUs. The compensation expense for the RSUs is recognized using a straight-line attribution method over the requisite employee service period while compensation expense for PSUs is recognized using an accelerated amortization model.  We estimate the fair value of shares to be issued under our employee stock purchase plan using the Black-Scholes model at the commencement of an offering period in March and September of each year.  Stock-based compensation for our employee stock purchase plan is expensed using an accelerated amortization model.

[0001045810-14-000085:notes:42]
[same as prior period, unchanged from 0001045810-13-000109:notes:31]

[0001045810-14-000085:notes:43]
|  | Three Months Ended |
|  | April 27, 2014 |  | April 28, 2013 |
|  | (In thousands) |
| Cost of revenue | $ | 2,919 |  |  | $ | 2,653 |  |
| Research and development | 20,494 |  |  | 21,935 |  |
| Sales, general and administrative | 12,108 |  |  | 8,809 |  |
| Total | $ | 35,521 |  |  | $ | 33,397 |  |

[0001045810-14-000085:notes:44]
During the three months ended April 27, 2014, we granted 7,800 stock options, with a total grant-date fair value of $35,880 and a weighted average grant-date fair value of $4.60 per option. During the three months ended April 27, 2014, we granted 3.3 million RSUs and PSUs, with a total grant-date fair value of $55.7 million and a weighted average grant-date fair value of $17.13 per share.  The PSUs granted during the three months ended April 27, 2014, were granted to our CEO and senior management as approved by our Compensation Committee.

[0001045810-14-000085:notes:45]
During the three months ended April 28, 2013, we granted 2.8 million stock options, with a total grant-date fair value of $8.7 million and a weighted average grant-date fair value of $3.11 per option. During the three months ended April 28, 2013, we granted 4.9 million RSUs, with a total grant-date fair value of $57.4 million and a weighted average grant-date fair value of $11.72 per RSU.

[0001045810-14-000085:notes:46]
Of the total grant-date fair value, we estimated that the stock-based compensation expense related to the equity awards that were not expected to vest was $10.0 million and $11.8 million for the three months ended April 27, 2014 and April 28, 2013, respectively. As of April 27, 2014 and January 26, 2014, the aggregate amount of unearned stock-based compensation expense related to our equity awards was $259.6 million and $241.3 million, respectively, adjusted for estimated forfeitures.  As of April 27, 2014 and January 26, 2014, we expected to recognize the unearned stock-based compensation expense related to stock options over an estimated weighted average amortization period of 2.3 years and 2.5 years, respectively. As of April 27, 2014 and January 26, 2014, we expected to recognize the unearned stock-based compensation expense related to RSUs and PSUs over an estimated weighted average amortization period of 2.8 years and 2.7 years, respectively.

[0001045810-14-000085:notes:47]
[same as prior period, unchanged from 0001045810-13-000109:notes:36]

[0001045810-14-000085:notes:48]
We determine the fair value of stock option awards on the date of grant using an option-pricing model that is affected by our stock price as well as assumptions regarding a number of highly complex and subjective variables. These variables include, weighted average expected term, risk-free interest rate, expected stock price volatility, dividend yield, actual and projected employee stock option exercise behaviors, vesting schedules and death and disability probabilities. We segregate options into groups of employees with relatively homogeneous exercise behavior in order to calculate the best estimate of fair value using the binomial valuation model.

[0001045810-14-000085:notes:49]
The expected life of employee stock options is a derived output of our valuation model and is impacted by the underlying assumptions of our company. The risk-free interest rate assumption is based upon observed interest rates on Treasury bills appropriate for the term of our employee stock options. Our management has determined that the use of implied volatility is expected to be more reflective of market conditions and, therefore, can reasonably be expected to be a better indicator of our expected volatility than historical volatility. Dividend yield is based on history and expectation of dividend payouts. Our RSU and PSU awards are not eligible for cash dividends prior to vesting; therefore, the fair value of RSUs and PSUs is discounted by the dividend yield.

[0001045810-14-000085:notes:50]
We use a dividend yield at grant date based on the per share dividends declared during the most recent quarter.  Additionally, for all employee equity awards, we estimate forfeitures annually and revise the estimates of forfeiture in subsequent periods if actual forfeitures differ from those estimates. Forfeitures are estimated based on historical experience.

[0001045810-14-000085:notes:51]
The fair value of stock options granted under our equity incentive plan and shares issued under our employee stock purchase plan have been estimated at the date of grant with the following assumptions:

[0001045810-14-000085:notes:52]
|  | Three Months Ended |
|  | April 27, 2014 |  | April 28, 2013 |
| Stock Options | (Using a binomial model) |
| Expected life (in years) | 3.2 |  |  | 3.2 - 3.3 |
| Risk-free interest rate | 2.8 | % |  | 1.8% - 2.1% |
| Volatility | 31 | % |  | 32% - 37% |
| Dividend yield | 1.9 | % |  | 2.3% - 2.4% |

[0001045810-14-000085:notes:53]
|  | Three Months Ended |
|  | April 27, 2014 |  | April 28, 2013 |
| Employee Stock Purchase Plan | (Using a Black-Scholes model) |
| Expected life (in years) | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |
| Risk-free interest rate | 0.1% - 0.3% |  |  | 0.1% - 0.3% |  |
| Volatility | 31 | % |  | 37 | % |
| Dividend yield | 1.9 | % |  | 2.4 | % |

[0001045810-14-000085:notes:54]
[same as prior period, unchanged from 0001045810-13-000109:notes:43]

[0001045810-14-000085:notes:55]
The following summarizes the stock option, RSU and PSU activity under our equity incentive plans:

[0001045810-14-000085:notes:56]
|  | Options Outstanding |  | Weighted Average Exercise Price |
| Stock Options | (In thousands) |  | (Per share) |
| Balances, January 26, 2014 | 32,504 |  |  | $ | 14.22 |  |
| Granted | 8 |  |  | $ | 17.20 |  |
| Exercised | (4,801 | ) |  | $ | 13.14 |  |
| Cancelled | (486 | ) |  | $ | 20.31 |  |
| Balances, April 27, 2014 | 27,225 |  |  | $ | 14.30 |  |

[0001045810-14-000085:notes:57]
|  | RSUs and PSUs Outstanding |  | Weighted Average Grant-Date Fair Value |
| RSUs and PSUs | (In thousands) |  | (Per share) |
| Balances, January 26, 2014 | 18,852 |  |  | $ | 13.82 |  |
| Granted (1) | 3,254 |  |  | $ | 17.13 |  |
| Vested | (3,303 | ) |  | $ | 13.31 |  |
| Cancelled | (367 | ) |  | $ | 13.24 |  |
| Balances, April 27, 2014 | 18,436 |  |  | $ | 14.51 |  |

[0001045810-14-000085:notes:58]
(1)    Includes the total number of PSUs issuable if the maximum corporate financial performance target level for fiscal year 2015 is achieved. Depending on the actual level of achievement of the corporate performance goal at the end of fiscal year 2015, the range of PSUs issued could range from 0 to 2.5 million shares.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001045810-14-000085:notes:59]
[same as prior period, unchanged from 0001045810-13-000109:notes:47]

[0001045810-14-000085:notes:60]
Basic net income per share is computed using the weighted average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted average number of common and potentially dilutive shares outstanding during the period, using the treasury stock method. Under the treasury stock method, the effect of stock options outstanding is not included in the computation of diluted net income per share for periods when their effect is anti-dilutive. Additionally, we issued convertible notes with a net settlement feature that requires us, upon conversion, to settle the principal amount of debt for cash and the conversion premium for cash or shares of our common stock. Our convertible notes, note hedges, and related warrants contain various conversion features, which are further described in Note 11 of these Notes to Condensed Consolidated Financial Statements. The potentially dilutive impact of the convertible notes and warrants under the treasury stock method will be included in the calculation of diluted shares when their conversion features are exercisable. However, unless actually exercised, the note hedges will not be included in the calculation of diluted shares, as their pre-exercised effect would be anti-dilutive under the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001045810-14-000085:notes:61]
[same as prior period, unchanged from 0001045810-13-000109:notes:49]

[0001045810-14-000085:notes:62]
|  | Three Months Ended |
|  | April 27, |  | April 28, |
|  | 2014 |  | 2013 |
|  | (In thousands, except per share data) |
| Numerator: |  |  |  |
| Net income | $ | 136,516 |  |  | $ | 77,891 |  |
| Denominator: |  |  |  |  |  |
| Denominator for basic net income per share, weighted average shares | 559,092 |  |  | 616,872 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Equity awards outstanding | 11,330 |  |  | 2,430 |  |
| Denominator for diluted net income per share, weighted average shares | 570,422 |  |  | 619,302 |  |
| Net income per share: |  |  |  |  |  |
| Basic net income per share | $ | 0.24 |  |  | $ | 0.13 |  |
| Diluted net income per share | $ | 0.24 |  |  | $ | 0.13 |  |
| Potentially dilutive securities excluded from diluted net income per share because their effect would have been anti-dilutive | 8,338 |  |  | 26,112 |  |

[0001045810-14-000085:notes:63]
The denominator for diluted net income per share for the three months ended April 27, 2014 did not include any effect from the 1.00% Convertible Senior Notes due 2018, or the Notes. The calculation of the dilution impact is based on the treasury stock method in accordance with Accounting Standards Codification, or ASC 260, Earnings per Share.  Commencing after the fiscal quarter ended on April 27, 2014, the Notes will not impact the denominator for diluted net income per share unless the average price of our common stock, as calculated under the terms of the Notes, exceeds the conversion price of $20.16 per share. Likewise, the denominator for diluted net income per share will not include any effect from the warrants that were issued simultaneously with the Notes unless the average price of our common stock, as calculated under the terms of the warrants, exceeds $27.14 per share.

[0001045810-14-000085:notes:64]
The denominator for diluted net income per share for the three months ended April 27, 2014 also did not include any effect from the note hedges that were issued simultaneously with the Notes. In future periods, the denominator for diluted net income per share will exclude any effect of the note hedges, unless in the event an actual conversion of any or all of the Notes occurs, the shares that would be delivered to us under the note hedges are designed to neutralize the dilutive effect of the shares that the Company would issue under the Notes. Please refer to Note 11 of these Notes to Condensed Consolidated Financial Statements for additional discussion regarding the Notes.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001045810-14-000085:notes:65]
|  |  |  | Fair Value Measurement as of April 27, 2014 Using |
|  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |
|  | April 27, 2014 |  | (Level 1) |  | (Level 2) |
|  | (In thousands) |
| Corporate debt securities (1) | $ | 2,067,826 |  |  | $ | — |  |  | $ | 2,067,826 |  |
| Debt securities issued by United States government agencies (2) | 732,731 |  |  | — |  |  | 732,731 |  |
| Debt securities issued by United States Treasury (2) | 584,880 |  |  | — |  |  | 584,880 |  |
| Asset-backed securities (2) | 357,331 |  |  | — |  |  | 357,331 |  |
| Mortgage-backed securities issued by government-sponsored enterprises (2) | 202,441 |  |  | — |  |  | 202,441 |  |
| Money market funds (3) | 103,396 |  |  | 103,396 |  |  | — |  |
| Total cash equivalents and marketable securities | $ | 4,048,605 |  |  | $ | 103,396 |  |  | $ | 3,945,209 |  |

[0001045810-14-000085:notes:66]
| (1) | Includes $106.6 million in cash equivalents and $1.96 billion in marketable securities on the Condensed Consolidated Balance Sheet. |

[0001045810-14-000085:notes:67]
| (2) | Included in marketable securities on the Condensed Consolidated Balance Sheet. |

[0001045810-14-000085:notes:68]
| (3) | Included in cash equivalents on the Condensed Consolidated Balance Sheet. |


## us-gaap:FairValueDisclosuresTextBlock

[0001045810-14-000085:notes:69]
[same as prior period, unchanged from 0001045810-13-000109:notes:55]

[0001045810-14-000085:notes:70]
We measure our cash equivalents and marketable securities at fair value. The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets.  Our Level 1 assets consist of our money market funds. We classify securities within Level 1 assets when the fair value is obtained from real time quotes for transactions in active exchange markets involving identical assets.  Our available-for-sale securities are classified as having Level 2 inputs.  Our Level 2 assets are valued utilizing a market approach where the market prices of similar assets are provided by a variety of independent industry standard data providers to our investment custodian.  There were no significant transfers between Levels 1 and 2 assets for the three months ended April 27, 2014.

[0001045810-14-000085:notes:71]
[same as prior period, unchanged from 0001045810-13-000109:notes:57]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001045810-14-000085:notes:72]
[same as prior period, unchanged from 0001045810-13-000109:notes:58]

[0001045810-14-000085:notes:73]
We recognized income tax expense of $26.8 million and $10.2 million for the three months ended April 27, 2014 and April 28, 2013, respectively. Income tax expense as a percentage of income before taxes, or our effective tax rate, was 16.4% and 11.6% for the three months ended April 27, 2014 and April 28, 2013, respectively.

[0001045810-14-000085:notes:74]
The increase in our effective tax rate in fiscal year 2015 as compared to the same period in the prior fiscal year was primarily related to the expiration of the U.S. federal research tax credit on December 31, 2013 which resulted in no tax benefit in the three months ended April 27, 2014.

[0001045810-14-000085:notes:75]
Our effective tax rate on income before tax for the first three months of fiscal year 2015 of 16.4% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax rate.  Further, our annual projected effective tax rate as of the first three months of fiscal year 2015 of 20% differs from our actual effective tax rate for the first three months of fiscal year 2015 of 16.4% due to favorable discrete events that occurred in the first three months of fiscal year 2015 primarily attributable to the expiration of statutes of limitations in certain non-U.S. jurisdictions for which we had not previously recognized related tax benefits.

[0001045810-14-000085:notes:76]
Our effective tax rate on income before tax for the first three months of fiscal year 2014 of 11.6% was lower than the United States federal statutory rate of 35% due primarily to income earned in jurisdictions where the tax rate is lower than the United States federal statutory tax and the benefit of the U.S. federal research tax credit.

[0001045810-14-000085:notes:77]
For the three months ended April 27, 2014, there have been no material changes to our tax years that remain subject to examination by major tax jurisdictions. Additionally, there have been no other material changes to our unrecognized tax benefits and any related interest or penalties from our fiscal year ended January 26, 2014, other than the recognition of tax benefits related to the expiration of statute of limitation in certain non-U.S. jurisdictions in the three months ended April 27, 2014.

[0001045810-14-000085:notes:78]
While we believe that we have adequately provided for all uncertain tax positions, or tax positions where it is believed not more-likely-than-not that the position will be sustained upon examination, amounts asserted by tax authorities could be greater or less than our accrued position. Accordingly, our provisions on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved with the respective tax authorities. As of April 27, 2014, we do not believe that our estimates, as otherwise provided for, on such tax positions will significantly increase or decrease within the next twelve months.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001045810-14-000085:notes:79]
[same as prior period, unchanged from 0001045810-13-000109:notes:64]

[0001045810-14-000085:notes:80]
[same as prior period, unchanged from 0001045810-13-000109:notes:65]

[0001045810-14-000085:notes:81]
|  | April 27, 2014 |  | January 26, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | Accumulated Amortization |  | Net CarryingAmount |
|  | (In thousands) |
| Acquisition-related intangible assets | $ | 189,239 |  |  | $ | (119,094 | ) |  | $ | 70,145 |  |  | $ | 189,239 |  |  | $ | (114,104 | ) |  | $ | 75,135 |  |
| Patents and licensed technology | 446,853 |  |  | (239,468 | ) |  | 207,385 |  |  | 446,196 |  |  | (225,319 | ) |  | 220,877 |  |
| Total intangible assets | $ | 636,092 |  |  | $ | (358,562 | ) |  | $ | 277,530 |  |  | $ | 635,435 |  |  | $ | (339,423 | ) |  | $ | 296,012 |  |

[0001045810-14-000085:notes:82]
Amortization expense associated with intangible assets for the three months ended April 27, 2014 and April 28, 2013 was $19.1 million and $17.4 million, respectively. Amortization expense increased compared to the prior year primarily due to the addition of licensed technology, the purchase of certain assets of a business, and the addition of acquired in-process research and development technology that was determined to be complete.  Future amortization expense related to the net carrying amount of intangible assets at April 27, 2014 is estimated to be $57.6 million for the remainder of fiscal year 2015, $71.4 million in fiscal year 2016, $63.4 million in fiscal year 2017, $48.5 million in fiscal year 2018, $20.0 million in fiscal year 2019 and a total of $16.6 million in fiscal year 2020 and fiscal years subsequent to fiscal year 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001045810-14-000085:notes:83]
|  | April 27, |  | January 26, |
|  | 2014 |  | 2014 |
| Inventories: | (In thousands) |
| Raw materials | $ | 143,773 |  |  | $ | 126,896 |  |
| Work in-process | 83,767 |  |  | 94,844 |  |
| Finished goods | 165,740 |  |  | 166,025 |  |
| Total inventories | $ | 393,280 |  |  | $ | 387,765 |  |


## us-gaap:InventoryPolicyTextBlock

[0001045810-14-000085:notes:84]
[same as prior period, unchanged from 0001045810-13-000109:notes:70]

[0001045810-14-000085:notes:85]
Inventory cost is computed on an adjusted standard basis, which approximates actual cost on an average or first-in, first-out basis. Inventory costs consist primarily of the cost of semiconductors purchased from subcontractors, including wafer fabrication, assembly, testing and packaging, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, and shipping costs, as well as the cost of purchased memory products and other component parts. We charge cost of sales for inventory provisions to write down our inventory to the lower of cost or estimated market value or to completely write off obsolete or excess inventory. Most of our inventory provisions relate to the write-off of excess quantities of products, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions. Once inventory has been written-off or written-down, it creates a new cost basis for the inventory that is not subsequently written-up.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001045810-14-000085:notes:86]
|  | April 27, 2014 |  | January 26, 2014 |
|  | AmortizedCost |  | EstimatedFair Value |  | AmortizedCost |  | EstimatedFair Value |
|  | (In thousands) |
| Less than 1 year | $ | 1,536,890 |  |  | $ | 1,537,853 |  |  | $ | 1,883,132 |  |  | $ | 1,883,753 |  |
| Due in 1 - 5 years | 2,379,798 |  |  | 2,383,465 |  |  | 2,114,289 |  |  | 2,117,387 |  |
| Mortgage-backed securities issued by government-sponsored enterprises not due at a single maturity date | 125,314 |  |  | 127,287 |  |  | 90,472 |  |  | 91,508 |  |
| Total | $ | 4,042,002 |  |  | $ | 4,048,605 |  |  | $ | 4,087,893 |  |  | $ | 4,092,648 |  |


## us-gaap:MarketableSecuritiesTextBlock

[0001045810-14-000085:notes:87]
[same as prior period, unchanged from 0001045810-13-000109:notes:73]

[0001045810-14-000085:notes:88]
All of our cash equivalents and marketable securities are classified as “available-for-sale” securities. These securities are reported at fair value, with the related unrealized gains and losses included in accumulated other comprehensive income, a component of stockholders’ equity, net of tax, and net realized gains and losses recorded in other income, net, on the Condensed Consolidated Statement of Income.

[0001045810-14-000085:notes:89]
We performed an impairment review of our investment portfolio as of April 27, 2014. Based on our quarterly impairment review and having considered the guidance in the relevant accounting literature, we concluded that our investments were appropriately valued and that no other than temporary impairment charges were necessary on our portfolio as of April 27, 2014.

[0001045810-14-000085:notes:90]
The following is a summary of cash equivalents and marketable securities at April 27, 2014 and January 26, 2014:

[0001045810-14-000085:notes:91]
The following table provides the breakdown of the investments with unrealized losses at April 27, 2014:

[0001045810-14-000085:notes:92]
|  | Less than 12 months |  | 12 months or greater |  | Total |
|  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
|  | (In thousands) |
| Corporate debt securities | $ | 807,941 |  |  | $ | (41 | ) |  | $ | 1,259,885 |  |  | $ | (651 | ) |  | $ | 2,067,826 |  |  | $ | (692 | ) |
| Debt securities of United States government agencies | 408,621 |  |  | (9 | ) |  | 324,110 |  |  | (89 | ) |  | 732,731 |  |  | (98 | ) |
| Debt securities issued by United States Treasury | 64,259 |  |  | — |  |  | 520,621 |  |  | (40 | ) |  | 584,880 |  |  | (40 | ) |
| Asset-backed securities | 153,635 |  |  | (30 | ) |  | 203,696 |  |  | (94 | ) |  | 357,331 |  |  | (124 | ) |
| Mortgage-backed securities issued by United States government-sponsored enterprises | — |  |  | — |  |  | 202,441 |  |  | (795 | ) |  | 202,441 |  |  | (795 | ) |
| Total | $ | 1,434,456 |  |  | $ | (80 | ) |  | $ | 2,510,753 |  |  | $ | (1,669 | ) |  | $ | 3,945,209 |  |  | $ | (1,749 | ) |

[0001045810-14-000085:notes:93]
The gross unrealized losses related to fixed income securities and were due to changes in interest rates. We have determined that the gross unrealized losses on investment securities at April 27, 2014 are temporary in nature. Currently, we have the intent and ability to hold our investments with impairment indicators until maturity.

[0001045810-14-000085:notes:94]
The amortized cost and estimated fair value of cash equivalents and marketable securities, which are primarily debt instruments, are classified as available-for-sale at April 27, 2014 and January 26, 2014 and are shown below by contractual maturity.

[0001045810-14-000085:notes:95]
Net realized gains for the three months ended April 27, 2014 and April 28, 2013 were not significant.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001045810-14-000085:notes:96]
[same as prior period, unchanged from 0001045810-13-000109:notes:83]

[0001045810-14-000085:notes:97]
The accompanying unaudited condensed consolidated financial statements were prepared in accordance with accounting principles generally accepted in the United States of America, or U.S. GAAP, for interim financial information and with the instructions to Form 10-Q and Article 10 of Securities and Exchange Commission, or SEC, Regulation S-X. In the opinion of management, all adjustments, consisting only of normal recurring adjustments except as otherwise noted, considered necessary for a fair statement of results of operations and financial position have been included. The results for the interim periods presented are not necessarily indicative of the results expected for any future period. The following information should be read in conjunction with the audited financial statements and notes thereto included in our Annual Report on Form 10-K for the fiscal year ended January 26, 2014.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001045810-14-000085:notes:98]
|  | April 27, |  | January 26, |
|  | 2014 |  | 2014 |
| Other Long-Term Liabilities: | (In thousands) |
| Deferred income tax liability | $ | 175,236 |  |  | $ | 157,953 |  |
| Income taxes payable, long-term | 116,881 |  |  | 119,977 |  |
| Deferred revenue, long-term (1) | 106,169 |  |  | 172,199 |  |
| Asset retirement obligation | 7,365 |  |  | 11,056 |  |
| Other long-term liabilities | 14,123 |  |  | 13,940 |  |
| Total other long-term liabilities | $ | 419,774 |  |  | $ | 475,125 |  |

[0001045810-14-000085:notes:99]
(1)    Represents annual consideration received in advance of our performance obligation under our patent cross licensing agreement   with Intel Corporation entered into in January 2011. The decrease in deferred revenue, long-term, is a result of revenue recognized during the three months ended April 27, 2014.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001045810-14-000085:notes:100]
[same as prior period, unchanged from 0001045810-13-000109:notes:87]

[0001045810-14-000085:notes:101]
[same as prior period, unchanged from 0001045810-13-000109:notes:88]

[0001045810-14-000085:notes:102]
[same as prior period, unchanged from 0001045810-13-000109:notes:89]

[0001045810-14-000085:notes:103]
We record a reduction to revenue for estimated product returns at the time revenue is recognized primarily based on historical return rates. Cost of revenue includes the estimated cost of product warranties.  Under limited circumstances, we may offer an extended limited warranty to customers for certain products.  Additionally, we accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. The estimated product warranty liabilities for the three months ended April 27, 2014 and April 28, 2013 were as follows:

[0001045810-14-000085:notes:104]
|  | Three Months Ended |
|  | April 27, |  | April 28, |
|  | 2014 |  | 2013 |
|  | (In thousands) |
| Balance at beginning of period | $ | 7,571 |  |  | $ | 14,874 |  |
| Additions | 2,034 |  |  | 1,418 |  |
| Deductions | (1,355 | ) |  | (1,459 | ) |
| Balance at end of period | $ | 8,250 |  |  | $ | 14,833 |  |

[0001045810-14-000085:notes:105]
[same as prior period, unchanged from 0001045810-13-000109:notes:94]


## us-gaap:ReconciliationOfOtherSignificantReconcilingItemsFromSegmentsToConsolidatedTextBlock

[0001045810-14-000085:notes:106]
|  | Three Months Ended |
|  | April 27, 2014 |  | April 28, 2013 |
|  | (In thousands) |
| Reconciling items included in "All Other" category : |  |  |
| Revenue not allocated to reporting segments | $ | 66,000 |  |  | $ | 66,000 |  |
| Unallocated corporate operating expenses and other expenses | (43,436 | ) |  | (44,497 | ) |
| Stock-based compensation | (35,521 | ) |  | (33,397 | ) |
| Amortization of acquisition-related intangibles | (9,441 | ) |  | (8,861 | ) |
| Total | $ | (22,398 | ) |  | $ | (20,755 | ) |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001045810-14-000085:notes:107]
[same as prior period, unchanged from 0001045810-13-000109:notes:97]

[0001045810-14-000085:notes:108]
[same as prior period, unchanged from 0001045810-13-000109:notes:98]

[0001045810-14-000085:notes:109]
[same as prior period, unchanged from 0001045810-13-000109:notes:99]

[0001045810-14-000085:notes:110]
Our policy on sales to certain distributors with rights of return is to defer recognition of revenue and related cost of revenue until the distributors resell the product, as the level of returns cannot be reasonably estimated.

[0001045810-14-000085:notes:111]
Our customer programs primarily involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets. We account for rebates as a reduction of revenue and accrue for 100% of the potential rebates and do not apply a breakage factor. While we have a long history of rebate arrangements with original equipment manufacturers, or OEMs, we believe we are unable to apply our historical experience to reliably estimate the amount of rebates that will eventually be claimed by individual OEMs. The OEMs are not our direct customers and the quantity and mix of demand they place on contract equipment manufacturers and original design manufacturers may shift as we introduce new generations and iterations of products and as we experience changes in new competitor offerings. In addition, we typically find that approximately 95% of the rebates we accrue each year are eventually claimed, which is substantially close to 100%, and that this percentage varies by program and by customer. We recognize a liability for these rebates at the later of the date at which we record the related revenue or the date at which we offer the rebate. Rebates typically expire six months from the date of the original sale, unless we reasonably believe that the customer intends to claim the rebate. Unclaimed rebates are reversed to revenue, the amount of which typically represents approximately 0.5% of total revenue.

[0001045810-14-000085:notes:112]
Our customer programs also include marketing development funds, or MDFs. MDFs represent monies paid to retailers, system builders, OEMs, distributors and add-in card partners that are earmarked for market segment development and expansion and typically are designed to support our partners’ activities while also promoting NVIDIA products. Depending on market conditions, we may take actions to increase amounts offered under customer programs, possibly resulting in an incremental reduction of revenue at the time such programs are offered. We account for MDFs as a reduction of revenue and apply a breakage factor to certain types of MDF program accruals for which we believe we can make a reasonable and reliable estimate of the amount that will ultimately be unclaimed. MDF amounts that have been previously recorded against revenue and subsequently expired unclaimed are reversed to revenue. Such amounts have not been significant.

[0001045810-14-000085:notes:113]
[same as prior period, unchanged from 0001045810-13-000109:notes:102]

[0001045810-14-000085:notes:114]
[same as prior period, unchanged from 0001045810-13-000109:notes:103]

[0001045810-14-000085:notes:115]
[same as prior period, unchanged from 0001045810-13-000109:notes:104]

[0001045810-14-000085:notes:116]
[same as prior period, unchanged from 0001045810-13-000109:notes:105]

[0001045810-14-000085:notes:117]
Royalty revenue is recognized related to the distribution or sale of products that use our technologies under license agreements with third parties. We recognize royalty revenue upon receipt of a confirmation of earned royalties and when collectability is reasonably assured from the applicable licensee.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001045810-14-000085:notes:118]
[same as prior period, unchanged from 0001045810-13-000109:notes:107]


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001045810-14-000085:notes:119]
|  | Three Months Ended |
|  | April 27, |  | April 28, |
|  | 2014 |  | 2013 |
|  | (In thousands) |
| Revenue: |  |  |  |
| Taiwan | $ | 372,859 |  |  | $ | 289,881 |  |
| China | 223,462 |  |  | 175,044 |  |
| United States | 172,935 |  |  | 185,978 |  |
| Other Asia Pacific | 154,850 |  |  | 167,257 |  |
| Other Americas | 91,763 |  |  | 65,007 |  |
| Europe | 86,918 |  |  | 71,572 |  |
| Total revenue | $ | 1,102,787 |  |  | $ | 954,739 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001045810-14-000085:notes:120]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-14-000085:notes:121]
In July 2013, the Financial Accounting Standards Board issued updated guidance regarding the presentation of unrecognized tax benefits when a net operating loss carry forward, similar tax loss, or tax credit carry forward exists. The guidance requires that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carry forward, a similar tax loss, or a tax credit carry forward when settlement in this manner is available under the tax law. We adopted this guidance in our interim period ended April 27, 2014. The adoption of this guidance did not impact our condensed consolidated financial statements, as the guidance was issued to reduce diversity in practice on presentation of unrecognized tax benefits.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001045810-14-000085:notes:122]
|  | GPU |  | Tegra Processor |  | All Other |  | Consolidated |
|  | (In thousands) |
| Three Months Ended April 27, 2014 |  |  |  |  |  |  |  |
| Revenue | $ | 897,363 |  |  | $ | 139,424 |  |  | $ | 66,000 |  |  | $ | 1,102,787 |  |
| Depreciation and amortization expense | $ | 29,524 |  |  | $ | 14,168 |  |  | $ | 11,391 |  |  | $ | 55,083 |  |
| Operating income (loss) | $ | 235,197 |  |  | $ | (61,440 | ) |  | $ | (22,398 | ) |  | $ | 151,359 |  |
| Three Months Ended April 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Revenue | $ | 785,612 |  |  | $ | 103,127 |  |  | $ | 66,000 |  |  | $ | 954,739 |  |
| Depreciation and amortization expense | $ | 38,848 |  |  | $ | 10,671 |  |  | $ | 10,225 |  |  | $ | 59,744 |  |
| Operating income (loss) | $ | 158,526 |  |  | $ | (54,990 | ) |  | $ | (20,755 | ) |  | $ | 82,781 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001045810-14-000085:notes:123]
[same as prior period, unchanged from 0001045810-13-000109:notes:113]

[0001045810-14-000085:notes:124]
Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making operating decisions and assessing financial performance. Our operating segments are equivalent to our reportable segments. We report our business in two primary reporting segments - the GPU business and the Tegra Processor business.

[0001045810-14-000085:notes:125]
Our GPU business leverages our GPU technology across multiple end markets. It comprises four primary product lines: GeForce for consumer desktop and notebook PCs; Quadro for professional workstations; Tesla for high-performance computing; and NVIDIA GRID to provide the power of NVIDIA graphics through the cloud. It also includes other related products, licenses and revenue supporting the GPU business, such as memory products.

[0001045810-14-000085:notes:126]
Our Tegra Processor business comprises primarily product lines based on our Tegra SOC and modem processor technologies, including Tegra for tablets, smartphones and gaming devices; Icera baseband processors and RF transceivers; automotive computers, including infotainment and navigation systems; and gaming devices, such as SHIELD. It also includes embedded products and license and other revenue associated with game consoles.

[0001045810-14-000085:notes:127]
During the fourth quarter of fiscal year 2014, our CODM completed a refinement of the methodology utilized to assign expenses to the GPU and Tegra Processor businesses to align to the Company’s product architecture and roadmap. With the announcement of our Tegra K1 processor, we now have a single unifying architecture for our GPU and Tegra Processors. This architecture unification prompted a methodology change that leverages our visual computing expertise by charging the operating expenses of certain core engineering functions to the GPU business, while charging the Tegra Processor business for the incremental cost of the teams working directly for that business. In instances where the operating expenses of certain functions benefit both reporting segments, our CODM assigns 100% of those expenses to the reporting segment that benefits the most. The revenue and cost of revenue of the reporting segments was not affected, and comparative periods presented below reflect the impact of this change.

[0001045810-14-000085:notes:128]
The “All Other” category presented below represents the revenue and expenses that our CODM does not assign to either the GPU business or the Tegra Processor business for purposes of making operating decisions or assessing financial performance. The revenue includes primarily patent licensing revenue and the expenses include corporate infrastructure and support costs, stock-based compensation costs, amortization of acquisition-related intangible assets, other acquisition-related costs, and other non-recurring charges and benefits that our CODM deems to be enterprise in nature.

[0001045810-14-000085:notes:129]
Our CODM does not review any information regarding total assets on a reporting segment basis. We do not have intersegment revenue. The accounting policies for segment reporting are the same as for NVIDIA as a whole.

[0001045810-14-000085:notes:130]
[same as prior period, unchanged from 0001045810-13-000109:notes:118]

[0001045810-14-000085:notes:131]
For the three months ended April 27, 2014, revenue from significant customers, those representing 10% or more of total revenue, was 10% of our total revenue from one customer whose revenue was attributable to both the GPU and Tegra Processor businesses.  For the three months ended April 28, 2013, revenue from significant customers was 21% of our total revenue from two customers and was attributable primarily to the GPU business for the first customer and to both the GPU and Tegra Processor businesses for the second customer.

[0001045810-14-000085:notes:132]
Accounts receivable from significant customers, those representing 10% or more of total accounts receivable, was 33% of our accounts receivable balance from two customers at April 27, 2014 and 23% of our accounts receivable balance from one customer at January 26, 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001045810-14-000085:notes:133]
[same as prior period, unchanged from 0001045810-13-000109:notes:121]

[0001045810-14-000085:notes:134]
[same as prior period, unchanged from 0001045810-13-000109:notes:122]

[0001045810-14-000085:notes:135]
We operate on a 52- or 53-week year, ending on the last Sunday in January.  Fiscal year 2015 and fiscal year 2014 are both 52-week years. The first quarters of fiscal years 2015 and 2014 are both 13-week quarters.

[0001045810-14-000085:notes:136]
[same as prior period, unchanged from 0001045810-13-000109:notes:126]

[0001045810-14-000085:notes:137]
[same as prior period, unchanged from 0001045810-13-000109:notes:127]

[0001045810-14-000085:notes:138]
[same as prior period, unchanged from 0001045810-13-000109:notes:128]

[0001045810-14-000085:notes:139]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosures of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. Actual results could differ from those estimates. On an on-going basis, we evaluate our estimates, including those related to revenue recognition, cash equivalents and marketable securities, accounts receivable, inventories, income taxes, goodwill, stock-based compensation, warranty liabilities, litigation, investigation and settlement costs and other contingencies. These estimates are based on historical facts and various other assumptions that we believe are reasonable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001045810-14-000085:notes:140]
[same as prior period, unchanged from 0001045810-13-000109:notes:130]

[0001045810-14-000085:notes:141]
[same as prior period, unchanged from 0001045810-13-000109:notes:131]

[0001045810-14-000085:notes:142]
Beginning August 2004, our Board of Directors authorized us, subject to certain specifications, to repurchase shares of our common stock. Most recently, in November 2013, the Board extended the previously authorized repurchase program through January 2016 and authorized an additional $1.00 billion for an aggregate of $3.70 billion under the repurchase program. Through April 27, 2014, we have repurchased an aggregate of 181.8 million shares under our stock repurchase program for a total cost of $2.95 billion.  As of April 27, 2014, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $0.75 billion through January 2016.

[0001045810-14-000085:notes:143]
The repurchases will be made from time to time in the open market, in privately negotiated transactions, or in structured stock repurchase programs, and may be made in one or more larger repurchases, in compliance with Rule 10b-18 of the Exchange Act, subject to market conditions, applicable legal requirements, and other factors. The program does not obligate NVIDIA to acquire any particular amount of common stock and the program may be suspended at any time at our discretion. As part of our share repurchase program, we have entered into, and we may continue to enter into, structured share repurchase transactions with financial institutions. These agreements generally require that we make an up-front payment in exchange for the right to receive a fixed number of shares of our common stock upon execution of the agreement, and a potential incremental number of shares of our common stock, within a pre-determined range, at the end of the term of the agreement.

[0001045810-14-000085:notes:144]
In November 2013, we announced the intention to return $1.00 billion to shareholders in fiscal year 2015 in the form of share repurchases and cash dividends.  During February 2014, we entered into an accelerated share repurchase agreement, or ASR, with an investment bank, under which we prepaid $500.0 million to purchase shares of our common stock and received 20.6 million shares on February 20, 2014.  Upon final settlement of the ASR in the second quarter of fiscal year 2015, we may either (1) receive additional shares of our common stock, or (2) be required to deliver shares of our common stock or elect to make a cash payment to the investment bank, based on the terms and conditions under the ASR. The shares we receive result in a reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted net income per share.

[0001045810-14-000085:notes:145]
We accounted for the ASR program as two separate transactions: (i) the 20.6 million shares of common stock initially delivered to us, were accounted for as treasury stock transaction and (ii) the unsettled contract was determined to be a forward contract indexed to our own common stock. The initial delivery of 20.6 million shares resulted in an immediate reduction, on the delivery date, of the outstanding shares used to calculate the weighted-average common shares outstanding for basic and diluted net income per share. We have determined that the forward contract, indexed to our common stock, met all of the applicable criteria for equity classification.

[0001045810-14-000085:notes:146]
Therefore, we recorded $368.6 million as treasury stock and recorded $131.4 million, the implied value of the forward contract, in additional paid-in-capital, or APIC, in our Condensed Consolidated Balance Sheets as of April 27, 2014. As the remainder of the shares are delivered to us, anticipated to be in the second quarter of fiscal year 2015, the forward contract will be reclassified from APIC to treasury stock.

[0001045810-14-000085:notes:147]
Dividends

[0001045810-14-000085:notes:148]
During the first quarter of fiscal year 2015, we paid $46.7 million in dividends to our common stockholders. This dividend was equivalent to $0.085 per share, or $0.34 per share on an annual basis.

[0001045810-14-000085:notes:149]
[same as prior period, unchanged from 0001045810-13-000109:notes:136]

[0001045810-14-000085:notes:150]
[same as prior period, unchanged from 0001045810-13-000109:notes:137]

[0001045810-14-000085:notes:151]
[same as prior period, unchanged from 0001045810-13-000109:notes:138]

[0001045810-14-000085:notes:152]
[same as prior period, unchanged from 0001045810-13-000109:notes:139]


## nvda:AssetPurchaseDisclosureTextBlock

[0001045810-14-000085:notes:153]
During fiscal year 2002, we completed the purchase of certain assets from 3dfx Interactive, Inc., or 3dfx, for an aggregate purchase price of $74.2 million. On December 15, 2000, NVIDIA Corporation and one of our indirect subsidiaries entered into an Asset Purchase Agreement, or the APA, which closed on April 18, 2001, to purchase certain graphics chip assets from 3dfx.

[0001045810-14-000085:notes:154]
In October 2002, 3dfx filed for Chapter 11 bankruptcy protection in the United States Bankruptcy Court for the Northern District of California. In March 2003, the Trustee appointed by the Bankruptcy Court to represent 3dfx’s bankruptcy estate served his complaint on NVIDIA.  The Trustee’s complaint asserted claims for, among other things, successor liability and fraudulent transfer and sought additional payments from us. In early November 2005, NVIDIA and the Official Committee of Unsecured Creditors, or the Creditors’ Committee, agreed to a Plan of Liquidation of 3dfx, which included a conditional settlement of the Trustee’s claims against us. This conditional settlement was subject to a confirmation process through a vote of creditors and the review and approval of the Bankruptcy Court. The conditional settlement called for a payment by NVIDIA of $30.6 million to the 3dfx estate. Under the settlement, $5.6 million related to various administrative expenses and Trustee fees, and $25.0 million related to the satisfaction of debts and liabilities owed to the general unsecured creditors of 3dfx. Accordingly, during the three month period ended October 30, 2005, we recorded $5.6 million as a charge to settlement costs and $25.0 million as additional purchase price for 3dfx. The Trustee advised that he intended to object to the settlement.

[0001045810-14-000085:notes:155]
[same as prior period, unchanged from 0001045810-13-000109:notes:145]

[0001045810-14-000085:notes:156]
The 3dfx asset purchase price of $95.0 million and $4.2 million of direct transaction costs were allocated based on fair values presented below. The final allocation of the purchase price of the 3dfx assets is contingent upon the outcome of all of the 3dfx litigation. Please refer to Note 12 of these Notes to Condensed Consolidated Financial Statements for further information regarding this litigation.


## nvda:BalanceSheetComponentsTextBlock

[0001045810-14-000085:notes:157]
[same as prior period, unchanged from 0001045810-13-000109:notes:147]

[0001045810-14-000085:notes:158]
[same as prior period, unchanged from 0001045810-13-000109:notes:148]

[0001045810-14-000085:notes:159]
At April 27, 2014, we had outstanding inventory purchase obligations totaling $414.2 million.
