# NVDA note change history — 0001045810-24-000264 → 0001045810-24-000316


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-20):
[0001045810-24-000316:note_history:1]
As of October 27, 2024, we had outstanding inventory purchase and long-term supply and capacity obligations totaling $28.9 billion, an increase from the prior year primarily due to commitments for Blackwell capacity and components. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, or adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $13.2 billion, including $11.3 billion of multi-year cloud service agreements. We expect our cloud service agreements to primarily be used to support our research and development efforts, as well as our DGX Cloud offerings.
  (was, 2024-08-28, similarity 0.9341):
[0001045810-24-000264:note_history:1]
As of July 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $27.8 billion, an increase from the prior year due to commitments for Hopper and Blackwell capacity and components. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. Though, changes to these agreements may result in additional costs. Other non-inventory purchase obligations were $12.0 billion, including $9.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

- changed (2024-11-20):
[0001045810-24-000316:note_history:2]
Total future purchase commitments as of October 27, 2024 are as follows:
  (was, 2024-08-28, similarity 0.916):
[0001045810-24-000264:note_history:2]
Total future purchase commitments as of July 28, 2024 are as follows:

- added (2024-11-20):
[0001045810-24-000316:note_history:3]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding the first nine months of fiscal year 2025) | $ | 14,178 |  |
| 2026 | 18,895 |  |
| 2027 | 3,381 |  |
| 2028 | 2,979 |  |
| 2029 | 1,990 |  |
| 2030 and thereafter | 621 |  |
| Total | $ | 42,044 |  |

- changed (2024-11-20):
[0001045810-24-000316:note_history:4]
The estimated amount of product warranty liabilities was $1.0 billion and $306 million as of October 27, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:
  (was, 2024-08-28, similarity 0.97):
[0001045810-24-000264:note_history:4]
The estimated amount of product warranty liabilities was $741 million and $306 million as of July 28, 2024 and January 28, 2024, respectively. The estimated product returns and product warranty activity consisted of the following:

- added (2024-11-20):
[0001045810-24-000316:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | Oct 27, 2024 |  | Oct 29, 2023 |  | Oct 27, 2024 |  | Oct 29, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 741 |  |  | $ | 115 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 304 |  |  | 50 |  |  | 775 |  |  | 105 |  |
| Utilization | (36) |  |  | (23) |  |  | (72) |  |  | (45) |  |
| Balance at end of period | $ | 1,009 |  |  | $ | 142 |  |  | $ | 1,009 |  |  | $ | 142 |  |

- changed (2024-11-20):
[0001045810-24-000316:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. Briefing concluded on October 25, 2024 and the Supreme Court heard oral arguments on November 13, 2024.
  (was, 2024-08-28, similarity 0.9621):
[0001045810-24-000264:note_history:6]
The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. On June 17, 2024, the Supreme Court of the United States granted NVIDIA’s petition for a writ of certiorari. Four amicus briefs were filed in support of NVIDIA's petition. Oral arguments are scheduled for November 13, 2024.

- changed (2024-11-20):
[0001045810-24-000316:note_history:7]
As of October 27, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.
  (was, 2024-08-28, similarity 0.9912):
[0001045810-24-000264:note_history:7]
As of July 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

- removed (2024-11-20):
[0001045810-24-000264:note_history:8]
|  | Commitments |
|  | (In millions) |
| Fiscal Year: |  |
| 2025 (excluding first half of fiscal year 2025) | $ | 21,934 |  |
| 2026 | 10,671 |  |
| 2027 | 2,778 |  |
| 2028 | 2,436 |  |
| 2029 | 1,543 |  |
| 2030 and thereafter | 419 |  |
| Total | $ | 39,781 |  |

- removed (2024-11-20):
[0001045810-24-000264:note_history:9]
|  | Three Months Ended |  | Six Months Ended |
|  | Jul 28, 2024 |  | Jul 30, 2023 |  | Jul 28, 2024 |  | Jul 30, 2023 |
|  | (In millions) |
| Balance at beginning of period | $ | 532 |  |  | $ | 77 |  |  | $ | 306 |  |  | $ | 82 |  |
| Additions | 237 |  |  | 42 |  |  | 471 |  |  | 55 |  |
| Utilization | (28) |  |  | (4) |  |  | (36) |  |  | (22) |  |
| Balance at end of period | $ | 741 |  |  | $ | 115 |  |  | $ | 741 |  |  | $ | 115 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-20):
[0001045810-24-000316:note_history:10]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The third quarters of fiscal years 2025 and 2024 were both 13-week quarters.
  (was, 2024-08-28, similarity 0.9759):
[0001045810-24-000264:note_history:10]
We operate on a 52- or 53-week year, ending on the last Sunday in January. Fiscal years 2025 and 2024 are both 52-week years. The second quarters of fiscal years 2025 and 2024 were both 13-week quarters.

- changed (2024-11-20):
[0001045810-24-000316:note_history:11]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of significant expenses in operating segments. We expect to adopt this standard in our fiscal year 2025 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.
  (was, 2024-08-28, similarity 0.651):
[0001045810-24-000264:note_history:11]
In November 2023, the Financial Accounting Standards Board, or FASB, issued a new accounting standard requiring disclosures of significant expenses in operating segments. We expect to adopt this standard in our annual reporting starting with fiscal year 2025. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- changed (2024-11-20):
[0001045810-24-000316:note_history:12]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. We expect to adopt this standard in our fiscal year 2026 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.
  (was, 2024-08-28, similarity 0.6657):
[0001045810-24-000264:note_history:12]
In December 2023, the FASB issued a new accounting standard which includes new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.

- added (2024-11-20):
[0001045810-24-000316:note_history:13]
In November 2024, the FASB issued a new accounting standard requiring disclosures of certain additional expense information on an annual and interim basis, including, among other items, the amounts of purchases of inventory,

- added (2024-11-20):
[0001045810-24-000316:note_history:14]
employee compensation, depreciation and intangible asset amortization included within each income statement expense caption, as applicable. We expect to adopt this standard in our fiscal year 2028 annual report. We are currently evaluating the impact of this standard on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-20):
[0001045810-24-000316:note_history:15]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 27, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 1.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (38) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,462 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,462 |  |  | $ | 8,459 |  |
  (was, 2024-08-28, similarity 0.9962):
[0001045810-24-000264:note_history:15]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,461 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,461 |  |  | $ | 8,459 |  |

- changed (2024-11-20):
[0001045810-24-000316:note_history:16]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes is calendar year.
  (was, 2024-08-28, similarity 0.944):
[0001045810-24-000264:note_history:16]
Our notes are unsecured senior obligations. Existing and future liabilities of our subsidiaries will be effectively senior to the notes. Our notes pay interest semi-annually. We may redeem each of our notes prior to maturity, as defined in the applicable form of note. The maturity of the notes are calendar year.

- changed (2024-11-20):
[0001045810-24-000316:note_history:17]
As of October 27, 2024, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.
  (was, 2024-08-28, similarity 0.9544):
[0001045810-24-000264:note_history:17]
As of July 28, 2024, we complied with the required covenants, which are non-financial in nature, under the outstanding notes.

- changed (2024-11-20):
[0001045810-24-000316:note_history:18]
We have a $575 million commercial paper program to support general corporate purposes. As of October 27, 2024, we had no commercial paper outstanding.
  (was, 2024-08-28, similarity 0.9609):
[0001045810-24-000264:note_history:18]
We have a $575 million commercial paper program to support general corporate purposes. As of July 28, 2024, we had no commercial paper outstanding.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-20):
[0001045810-24-000316:note_history:19]
|  | Oct 27, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,629 |  |  | $ | 72 |  |  | $ | (12) |  |  | $ | 14,689 |  |  | $ | 1,795 |  |  | $ | 12,894 |  |
| Corporate debt securities | 14,221 |  |  | 74 |  |  | (17) |  |  | 14,278 |  |  | 1,154 |  |  | 13,124 |  |
| Money market funds | 5,147 |  |  | — |  |  | — |  |  | 5,147 |  |  | 5,147 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 3,542 |  |  | 11 |  |  | (4) |  |  | 3,549 |  |  | 759 |  |  | 2,790 |  |
| Certificates of deposit | 142 |  |  | — |  |  | — |  |  | 142 |  |  | 42 |  |  | 100 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 37,681 |  |  | 157 |  |  | (33) |  |  | 37,805 |  |  | 8,897 |  |  | 28,908 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 472 |  |  | — |  |  | 472 |  |
| Total | $ | 37,681 |  |  | $ | 157 |  |  | $ | (33) |  |  | $ | 38,277 |  |  | $ | 8,897 |  |  | $ | 29,380 |  |
  (was, 2024-08-28, similarity 0.9389):
[0001045810-24-000264:note_history:19]
|  | Jul 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,051 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | 14,083 |  |  | $ | 2,132 |  |  | $ | 11,951 |  |
| Corporate debt securities | 11,994 |  |  | 37 |  |  | (7) |  |  | 12,024 |  |  | 682 |  |  | 11,342 |  |
| Money market funds | 5,252 |  |  | — |  |  | — |  |  | 5,252 |  |  | 5,252 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,461 |  |  | 7 |  |  | (2) |  |  | 2,466 |  |  | 50 |  |  | 2,416 |  |
| Certificates of deposit | 141 |  |  | — |  |  | — |  |  | 141 |  |  | 32 |  |  | 109 |  |
| Total marketable securities with fair value adjustments recorded in other comprehensive income | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 33,966 |  |  | $ | 8,148 |  |  | $ | 25,818 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | $ | 419 |  |  | $ | — |  |  | $ | 419 |  |
| Total | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 34,385 |  |  | $ | 8,148 |  |  | $ | 26,237 |  |

- changed (2024-11-20):
[0001045810-24-000316:note_history:20]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. Beginning in the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.
  (was, 2024-08-28, similarity 0.9831):
[0001045810-24-000264:note_history:20]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. In the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

- changed (2024-11-20):
[0001045810-24-000316:note_history:21]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total debt securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |
  (was, 2024-08-28, similarity 0.9931):
[0001045810-24-000264:note_history:21]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total marketable securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

- added (2024-11-20):
[0001045810-24-000316:note_history:22]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,695 |  |  | $ | 17,715 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 19,986 |  |  | 20,090 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 37,681 |  |  | $ | 37,805 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |

- removed (2024-11-20):
[0001045810-24-000264:note_history:23]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,535 |  |  | $ | 15,532 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 18,364 |  |  | 18,434 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 33,899 |  |  | $ | 33,966 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-20):
[0001045810-24-000316:note_history:24]
|  | Oct 27, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,629 |  |  | $ | 72 |  |  | $ | (12) |  |  | $ | 14,689 |  |  | $ | 1,795 |  |  | $ | 12,894 |  |
| Corporate debt securities | 14,221 |  |  | 74 |  |  | (17) |  |  | 14,278 |  |  | 1,154 |  |  | 13,124 |  |
| Money market funds | 5,147 |  |  | — |  |  | — |  |  | 5,147 |  |  | 5,147 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 3,542 |  |  | 11 |  |  | (4) |  |  | 3,549 |  |  | 759 |  |  | 2,790 |  |
| Certificates of deposit | 142 |  |  | — |  |  | — |  |  | 142 |  |  | 42 |  |  | 100 |  |
| Total debt securities with fair value adjustments recorded in other comprehensive income | 37,681 |  |  | 157 |  |  | (33) |  |  | 37,805 |  |  | 8,897 |  |  | 28,908 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | 472 |  |  | — |  |  | 472 |  |
| Total | $ | 37,681 |  |  | $ | 157 |  |  | $ | (33) |  |  | $ | 38,277 |  |  | $ | 8,897 |  |  | $ | 29,380 |  |
  (was, 2024-08-28, similarity 0.9389):
[0001045810-24-000264:note_history:24]
|  | Jul 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Debt securities issued by the U.S. Treasury | $ | 14,051 |  |  | $ | 42 |  |  | $ | (10) |  |  | $ | 14,083 |  |  | $ | 2,132 |  |  | $ | 11,951 |  |
| Corporate debt securities | 11,994 |  |  | 37 |  |  | (7) |  |  | 12,024 |  |  | 682 |  |  | 11,342 |  |
| Money market funds | 5,252 |  |  | — |  |  | — |  |  | 5,252 |  |  | 5,252 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,461 |  |  | 7 |  |  | (2) |  |  | 2,466 |  |  | 50 |  |  | 2,416 |  |
| Certificates of deposit | 141 |  |  | — |  |  | — |  |  | 141 |  |  | 32 |  |  | 109 |  |
| Total marketable securities with fair value adjustments recorded in other comprehensive income | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 33,966 |  |  | $ | 8,148 |  |  | $ | 25,818 |  |
| Publicly-held equity securities (1) |  |  |  |  |  |  | $ | 419 |  |  | $ | — |  |  | $ | 419 |  |
| Total | $ | 33,899 |  |  | $ | 86 |  |  | $ | (19) |  |  | $ | 34,385 |  |  | $ | 8,148 |  |  | $ | 26,237 |  |

- changed (2024-11-20):
[0001045810-24-000316:note_history:25]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. Beginning in the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.
  (was, 2024-08-28, similarity 0.9831):
[0001045810-24-000264:note_history:25]
(1)    Fair value adjustments on publicly-held equity securities are recorded in net income. In the second quarter of fiscal year 2025, publicly-held equity securities from investments in non-affiliated entities were classified in marketable securities on our Condensed Consolidated Balance Sheets.

- added (2024-11-20):
[0001045810-24-000316:note_history:26]
Net unrealized gains on investments in publicly-held equity securities were not significant and $195 million for the third quarter and first nine months of fiscal year 2025, respectively. Net unrealized gains on investments in publicly-held equity securities were not significant for the third quarter and first nine months of fiscal year 2024.

- changed (2024-11-20):
[0001045810-24-000316:note_history:27]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total debt securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |
  (was, 2024-08-28, similarity 0.9931):
[0001045810-24-000264:note_history:27]
|  | Jan 28, 2024 |
|  | AmortizedCost |  | UnrealizedGain |  | UnrealizedLoss |  | EstimatedFair Value |  | Reported as |
|  |  |  |  |  | Cash Equivalents |  | Marketable Securities |
|  | (In millions) |
| Corporate debt securities | $ | 10,126 |  |  | $ | 31 |  |  | $ | (5) |  |  | $ | 10,152 |  |  | $ | 2,231 |  |  | $ | 7,921 |  |
| Debt securities issued by the U.S. Treasury | 9,517 |  |  | 17 |  |  | (10) |  |  | 9,524 |  |  | 1,315 |  |  | 8,209 |  |
| Money market funds | 3,031 |  |  | — |  |  | — |  |  | 3,031 |  |  | 3,031 |  |  | — |  |
| Debt securities issued by U.S. government agencies | 2,326 |  |  | 8 |  |  | (1) |  |  | 2,333 |  |  | 89 |  |  | 2,244 |  |
| Certificates of deposit | 510 |  |  | — |  |  | — |  |  | 510 |  |  | 294 |  |  | 216 |  |
| Foreign government bonds | 174 |  |  | — |  |  | — |  |  | 174 |  |  | 60 |  |  | 114 |  |
| Total marketable securities with fair value changes recorded in other comprehensive income | $ | 25,684 |  |  | $ | 56 |  |  | $ | (16) |  |  | $ | 25,724 |  |  | $ | 7,020 |  |  | $ | 18,704 |  |

- added (2024-11-20):
[0001045810-24-000316:note_history:28]
|  | Oct 27, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Corporate debt securities | $ | 2,967 |  |  | $ | (17) |  |  | $ | 105 |  |  | $ | — |  |  | $ | 3,072 |  |  | $ | (17) |  |
| Debt securities issued by the U.S. Treasury | 2,562 |  |  | (12) |  |  | 532 |  |  | — |  |  | 3,094 |  |  | (12) |  |
| Debt securities issued by U.S. government agencies | 1,134 |  |  | (4) |  |  | 21 |  |  | — |  |  | 1,155 |  |  | (4) |  |
| Total | $ | 6,663 |  |  | $ | (33) |  |  | $ | 658 |  |  | $ | — |  |  | $ | 7,321 |  |  | $ | (33) |  |

- added (2024-11-20):
[0001045810-24-000316:note_history:29]
|  | Oct 27, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 17,695 |  |  | $ | 17,715 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 19,986 |  |  | 20,090 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 37,681 |  |  | $ | 37,805 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |

- removed (2024-11-20):
[0001045810-24-000264:note_history:30]
For the second quarter and first half of fiscal year 2025, net unrealized gains on investments in publicly-held equity securities were $132 million and $181 million, respectively. For the second quarter and first half of fiscal year 2024, net unrealized gains on investments in publicly-held equity securities were not significant.

- removed (2024-11-20):
[0001045810-24-000264:note_history:31]
|  | Jul 28, 2024 |
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |  | Estimated Fair Value |  | Gross Unrealized Loss |
|  | (In millions) |
| Debt securities issued by U.S. government agencies | $ | 4,031 |  |  | $ | (8) |  |  | $ | 857 |  |  | $ | (2) |  |  | $ | 4,888 |  |  | $ | (10) |  |
| Corporate debt securities | 3,170 |  |  | (5) |  |  | 396 |  |  | (2) |  |  | 3,566 |  |  | (7) |  |
| Debt securities issued by the U.S. Treasury | 1,210 |  |  | (1) |  |  | 117 |  |  | (1) |  |  | 1,327 |  |  | (2) |  |
| Total | $ | 8,411 |  |  | $ | (14) |  |  | $ | 1,370 |  |  | $ | (5) |  |  | $ | 9,781 |  |  | $ | (19) |  |

- removed (2024-11-20):
[0001045810-24-000264:note_history:32]
|  | Jul 28, 2024 |  | Jan 28, 2024 |
|  | Amortized Cost |  | Estimated Fair Value |  | Amortized Cost |  | Estimated Fair Value |
|  | (In millions) |
| Less than one year | $ | 15,535 |  |  | $ | 15,532 |  |  | $ | 16,336 |  |  | $ | 16,329 |  |
| Due in 1 - 5 years | 18,364 |  |  | 18,434 |  |  | 9,348 |  |  | 9,395 |  |
| Total | $ | 33,899 |  |  | $ | 33,966 |  |  | $ | 25,684 |  |  | $ | 25,724 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-20):
[0001045810-24-000316:note_history:33]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Oct 27, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 1.9 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.6 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.4 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.6 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.4 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.4 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.4 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (38) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,462 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,462 |  |  | $ | 8,459 |  |
  (was, 2024-08-28, similarity 0.9962):
[0001045810-24-000264:note_history:33]
|  |  | ExpectedRemaining Term (years) |  | EffectiveInterest Rate |  | Carrying Value at |
|  |  |  |  | Jul 28, 2024 |  | Jan 28, 2024 |
|  |  |  |  |  |  | (In millions) |
| 0.584% Notes Due 2024 (1) |  | — |  | 0.66% |  | $ | — |  |  | $ | 1,250 |  |
| 3.20% Notes Due 2026 |  | 2.1 |  | 3.31% |  | 1,000 |  |  | 1,000 |  |
| 1.55% Notes Due 2028 |  | 3.9 |  | 1.64% |  | 1,250 |  |  | 1,250 |  |
| 2.85% Notes Due 2030 |  | 5.7 |  | 2.93% |  | 1,500 |  |  | 1,500 |  |
| 2.00% Notes Due 2031 |  | 6.9 |  | 2.09% |  | 1,250 |  |  | 1,250 |  |
| 3.50% Notes Due 2040 |  | 15.7 |  | 3.54% |  | 1,000 |  |  | 1,000 |  |
| 3.50% Notes Due 2050 |  | 25.7 |  | 3.54% |  | 2,000 |  |  | 2,000 |  |
| 3.70% Notes Due 2060 |  | 35.7 |  | 3.73% |  | 500 |  |  | 500 |  |
| Unamortized debt discount and issuance costs |  |  |  |  |  | (39) |  |  | (41) |  |
| Net carrying amount |  |  |  |  |  | 8,461 |  |  | 9,709 |  |
| Less short-term portion |  |  |  |  |  | — |  |  | (1,250) |  |
| Total long-term portion |  |  |  |  |  | $ | 8,461 |  |  | $ | 8,459 |  |
