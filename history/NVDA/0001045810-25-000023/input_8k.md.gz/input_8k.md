# NVDA 8-K — 0001045810-25-000021 filed 2025-02-26

## item codes, every 8-K on or before 2025-02-26

- 2025-02-26 0001045810-25-000021 — 2.02, 9.01
- 2025-01-17 0001045810-25-000007 — 8.01
- 2024-11-20 0001045810-24-000315 — 2.02, 9.01
- 2024-11-07 0001045810-24-000300 — 5.02
- 2024-08-28 0001045810-24-000262 — 2.02, 9.01
- 2024-07-02 0001045810-24-000206 — 5.07
- 2024-06-07 0001045810-24-000144 — 5.03
- 2024-05-22 0001045810-24-000113 — 2.02, 8.01, 9.01
- 2024-03-14 0001045810-24-000069 — 5.02, 5.03, 9.01
- 2024-02-21 0001045810-24-000028 — 2.02, 9.01
- 2023-11-21 0001045810-23-000225 — 2.02, 9.01
- 2023-10-24 0001045810-23-000221 — 8.01
- 2023-10-17 0001045810-23-000217 — 8.01
- 2023-08-23 0001045810-23-000171 — 2.02, 9.01
- 2023-07-24 0001045810-23-000164 — 5.02
- 2023-06-27 0001045810-23-000146 — 5.07
- 2023-05-24 0001045810-23-000087 — 2.02, 9.01
- 2023-03-08 0001045810-23-000039 — 5.02, 5.03, 9.01
- 2023-02-22 0001045810-23-000014 — 2.02, 9.01
- 2022-11-16 0001045810-22-000163 — 2.02, 9.01
- 2022-09-01 0001045810-22-000151 — 8.01
- 2022-08-31 0001045810-22-000146 — 8.01
- 2022-08-24 0001045810-22-000136 — 2.02, 9.01
- 2022-08-08 0001045810-22-000133 — 2.02, 9.01
- 2022-06-06 0001045810-22-000088 — 5.02, 5.03, 5.07, 9.01
- 2022-05-25 0001045810-22-000073 — 2.02, 9.01
- 2022-03-09 0001045810-22-000023 — 5.02, 5.03, 9.01
- 2022-02-16 0001045810-22-000008 — 2.02, 9.01
- 2022-02-08 0001045810-22-000005 — 1.02
- 2021-11-17 0001045810-21-000160 — 2.02, 9.01
- 2021-08-18 0001045810-21-000128 — 2.02, 9.01
- 2021-06-28 0001045810-21-000117 — 7.01, 8.01
- 2021-06-16 0001193125-21-192149 — 1.01, 2.03, 9.01
- 2021-06-07 0001045810-21-000075 — 5.03, 5.07, 9.01
- 2021-05-26 0001045810-21-000063 — 2.02, 9.01
- 2021-05-21 0001045810-21-000056 — 8.01, 9.01
- 2021-04-12 0001045810-21-000047 — 7.01, 9.01
- 2021-03-19 0001045810-21-000034 — 5.02, 9.01
- 2021-02-24 0001045810-21-000007 — 2.02, 9.01
- 2020-11-18 0001045810-20-000187 — 2.02, 9.01
- 2020-11-09 0001045810-20-000181 — 5.02
- 2020-09-14 0001193125-20-244601 — 1.01, 7.01, 9.01
- 2020-08-19 0001045810-20-000145 — 2.02, 9.01
- 2020-07-13 0001045810-20-000127 — 5.02
- 2020-07-01 0001045810-20-000120 — 2.01, 9.01 — amendment of 0001045810-20-000052
- 2020-06-15 0001045810-20-000103 — 5.02, 5.07, 9.01
- 2020-05-21 0001045810-20-000063 — 2.02, 9.01
- 2020-04-27 0001045810-20-000052 — 2.01, 9.01
- 2020-04-17 0001045810-20-000048 — 8.01
- 2020-03-31 0001193125-20-092939 — 1.01, 2.03, 9.01
- 2020-03-10 0001045810-20-000033 — 5.02, 9.01
- 2020-02-13 0001045810-20-000007 — 2.02, 9.01
- 2019-11-14 0001045810-19-000168 — 2.02, 9.01
- 2019-08-15 0001045810-19-000140 — 2.02, 9.01
- 2019-06-17 0001045810-19-000112 — 5.02, 9.01
- 2019-05-29 0001045810-19-000107 — 5.07
- 2019-05-16 0001045810-19-000077 — 2.02, 9.01
- 2019-04-01 0001045810-19-000060 — 5.02
- 2019-03-11 0001045810-19-000031 — 1.01, 8.01, 9.01
- 2019-03-11 0001045810-19-000029 — 5.02, 9.01
- 2019-02-14 0001045810-19-000007 — 2.02, 9.01
- 2019-01-28 0001045810-19-000004 — 2.02, 9.01
- 2018-11-15 0001045810-18-000148 — 2.02, 9.01
- 2018-08-16 0001045810-18-000113 — 2.02, 9.01
- 2018-05-21 0001045810-18-000058 — 5.02, 5.07, 9.01
- 2018-05-10 0001045810-18-000052 — 2.02, 9.01
- 2018-03-13 0001045810-18-000026 — 5.02, 9.01
- 2018-02-08 0001045810-18-000004 — 2.02, 9.01
- 2017-12-15 0001045810-17-000178 — 1.01, 2.03, 9.01
- 2017-11-09 0001045810-17-000164 — 1.02, 2.02, 9.01
- 2017-08-10 0001045810-17-000117 — 2.02, 9.01
- 2017-06-05 0001045810-17-000103 — 1.01, 3.02, 9.01
- 2017-05-30 0001045810-17-000097 — 5.07
- 2017-05-09 0001045810-17-000068 — 2.02, 9.01
- 2017-03-13 0001045810-17-000038 — 5.02, 9.01
- 2017-02-09 0001045810-17-000016 — 2.02, 9.01
- 2017-02-02 0001045810-17-000012 — 1.01
- 2017-01-19 0001045810-17-000006 — 5.02, 9.01
- 2016-12-13 0001045810-16-000358 — 1.01, 3.02, 9.01
- 2016-12-01 0001045810-16-000356 — 5.03, 9.01
- 2016-11-10 0001045810-16-000343 — 2.02, 9.01
- 2016-10-13 0001193125-16-737735 — 1.01, 2.03, 9.01
- 2016-09-16 0001193125-16-711700 — 1.01, 2.03, 9.01
- 2016-08-11 0001045810-16-000292 — 2.02, 9.01
- 2016-06-21 0001045810-16-000284 — 5.02
- 2016-05-23 0001045810-16-000268 — 5.02, 5.07, 9.01
- 2016-05-12 0001045810-16-000243 — 2.02, 9.01
- 2016-05-02 0001045810-16-000235 — 8.01
- 2016-03-23 0001045810-16-000220 — 8.01
- 2016-03-14 0001045810-16-000200 — 5.02, 9.01
- 2016-02-17 0001045810-16-000189 — 2.02, 9.01
- 2015-11-05 0001045810-15-000165 — 2.02, 9.01
- 2015-08-06 0001045810-15-000131 — 2.02, 9.01
- 2015-06-23 0001045810-15-000124 — 1.01, 2.03
- 2015-05-26 0001045810-15-000117 — 5.07
- 2015-05-07 0001045810-15-000087 — 2.02, 9.01
- 2015-04-10 0001045810-15-000070 — 5.02, 9.01
- 2015-03-11 0001045810-15-000033 — 5.02
- 2015-02-11 0001045810-15-000013 — 2.02, 9.01
- 2014-11-06 0001045810-14-000182 — 2.02, 9.01
- 2014-08-07 0001045810-14-000149 — 2.02, 9.01
- 2014-05-28 0001045810-14-000101 — 5.02, 5.07
- 2014-05-08 0001045810-14-000076 — 2.02, 9.01
- 2014-05-06 0001045810-14-000071 — 2.02, 9.01
- 2014-04-15 0001045810-14-000062 — 5.02, 9.01
- 2014-02-14 0001045810-14-000006 — 1.01
- 2014-02-12 0001045810-14-000004 — 2.02, 9.01
- 2013-12-02 0001193125-13-459385 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-11-14 0001045810-13-000106 — 5.03, 9.01
- 2013-11-07 0001045810-13-000104 — 2.02, 9.01
- 2013-09-16 0001045810-13-000080 — 5.02
- 2013-08-08 0001045810-13-000069 — 2.02, 9.01
- 2013-07-23 0001045810-13-000064 — 5.02, 9.01
- 2013-05-21 0001045810-13-000046 — 5.07
- 2013-05-14 0001045810-13-000031 — 1.01
- 2013-05-09 0001045810-13-000029 — 2.02, 9.01
- 2013-04-02 0001045810-13-000024 — 5.02, 9.01
- 2013-03-05 0001045810-13-000005 — 5.02
- 2013-02-13 0001045810-13-000003 — 2.02, 9.01
- 2012-11-08 0001045810-12-000055 — 2.02, 8.01, 9.01
- 2012-08-09 0001045810-12-000032 — 2.02, 9.01
- 2012-05-11 0001045810-12-000024 — 2.02, 9.01
- 2012-03-28 0001045810-12-000015 — 5.02, 9.01
- 2012-02-15 0001045810-12-000008 — 2.02, 9.01
- 2012-02-09 0001045810-12-000004 — 1.02
- 2011-12-14 0001045810-11-000060 — 5.02, 9.01
- 2011-11-10 0001045810-11-000052 — 2.02, 9.01
- 2011-10-14 0001193125-11-271734 — 5.07 — amendment, the index does not say of what
- 2011-08-11 0001045810-11-000039 — 2.02, 9.01
- 2011-05-24 0001193125-11-149200 — 5.03, 5.07, 9.01
- 2011-05-12 0001045810-11-000022 — 2.02, 9.01
- 2011-03-25 0001045810-11-000018 — 5.02, 9.01
- 2011-03-15 0001193125-11-067233 — 5.02, 9.01
- 2011-02-16 0001045810-11-000006 — 2.02, 9.01
- 2011-01-10 0001193125-11-005134 — 1.01, 9.01
- 2010-11-12 0001045810-10-000038 — 2.02, 9.01
- 2010-09-13 0001045810-10-000033 — 5.02, 9.01
- 2010-08-24 0001104659-10-045738 — 1.01
- 2010-08-13 0001045810-10-000024 — 1.01
- 2010-08-12 0001045810-10-000022 — 2.02, 9.01
- 2010-05-13 0001045810-10-000015 — 2.02, 9.01
- 2010-05-05 0001045810-10-000010 — 5.02, 9.01
- 2010-02-17 0001045810-10-000002 — 2.02, 9.01
- 2009-11-05 0001045810-09-000031 — 2.02, 9.01
- 2009-08-06 0001045810-09-000021 — 2.02, 9.01
- 2009-05-07 0001045810-09-000015 — 2.02, 9.01
- 2009-04-08 0001193125-09-075632 — 5.02, 8.01, 9.01
- 2009-02-27 0001193125-09-040147 — 5.02, 9.01
- 2009-02-19 0001193125-09-033113 — 5.03, 9.01
- 2009-02-11 0001045810-09-000007 — 5.02, 9.01
- 2009-02-10 0001045810-09-000005 — 2.02, 9.01
- 2009-01-16 0001045810-09-000002 — 5.02
- 2008-11-10 0001045810-08-000028 — 8.01
- 2008-11-06 0001045810-08-000027 — 2.02, 9.01
- 2008-10-16 0001045810-08-000025 — 8.01
- 2008-09-24 0001193125-08-200658 — 8.01
- 2008-09-22 0001193125-08-199382 — 8.01
- 2008-09-18 0001193125-08-198086 — 2.05, 5.02
- 2008-09-08 0001045810-08-000022 — 5.02
- 2008-08-12 0001045810-08-000018 — 2.02, 9.01
- 2008-07-02 0001193125-08-145974 — 8.01
- 2008-05-08 0001045810-08-000014 — 2.02, 9.01
- 2008-04-21 0001193125-08-085676 — 5.02, 9.01
- 2008-03-27 0001193125-08-066644 — 5.02, 9.01
- 2008-02-13 0001045810-08-000003 — 2.02, 9.01
- 2008-02-06 0001193125-08-021771 — 1.01
- 2007-11-08 0001045810-07-000050 — 2.02, 9.01
- 2007-10-31 0001193125-07-231042 — 8.01
- 2007-09-21 0001045810-07-000048 — 5.02
- 2007-08-09 0001045810-07-000042 — 8.01
- 2007-08-09 0001045810-07-000041 — 2.02
- 2007-06-27 0001193125-07-144216 — 5.02, 9.01
- 2007-06-19 0001193125-07-138462 — 8.01 — amendment, the index does not say of what
- 2007-06-18 0001193125-07-137575 — 8.01
- 2007-06-18 0001193125-07-137218 — 8.01
- 2007-06-08 0001045810-07-000025 — 8.01
- 2007-05-10 0001045810-07-000014 — 2.02, 9.01
- 2007-04-30 0001045810-07-000012 — 5.02
- 2007-04-05 0001045810-07-000010 — 5.02
- 2007-02-13 0001045810-07-000004 — 2.02, 9.01
- 2007-01-11 0001045810-07-000002 — 2.01
- 2006-12-04 0001045810-06-000032 — 8.01
- 2006-12-01 0001045810-06-000030 — 5.02
- 2006-11-09 0001193125-06-230621 — 1.01, 9.01
- 2006-11-09 0001193125-06-230536 — 2.02, 9.01
- 2006-11-06 0001193125-06-223958 — 4.02, 9.01
- 2006-09-12 0001193125-06-189092 — 2.02, 3.01, 8.01, 9.01
- 2006-08-10 0001045810-06-000027 — 2.02, 8.01, 9.01
- 2006-05-11 0001045810-06-000020 — 2.02, 9.01
- 2006-04-03 0001045810-06-000018 — 1.01, 9.01
- 2006-03-13 0001045810-06-000012 — 1.01, 5.03, 9.01
- 2006-03-07 0001045810-06-000010 — 1.01, 5.03, 8.01, 9.01
- 2006-02-24 0001045810-06-000007 — 8.01, 9.01
- 2006-02-16 0001045810-06-000004 — 2.02, 9.01
- 2005-12-22 0001045810-05-000032 — 1.01, 9.01
- 2005-12-15 0001045810-05-000030 — 8.01
- 2005-11-09 0001045810-05-000026 — 2.02, 9.01
- 2005-08-11 0001045810-05-000022 — 2.02, 9.01
- 2005-06-02 0001045810-05-000019 — 5.02 — amendment, the index does not say of what
- 2005-05-20 0001045810-05-000016 — 5.02, 9.01
- 2005-05-16 0001045810-05-000014 — 1.01, 9.01
- 2005-05-12 0001045810-05-000012 — 2.02, 9.01
- 2005-02-17 0001045810-05-000006 — 2.02, 9.01
- 2005-02-11 0001045810-05-000004 — 1.01
- 2005-02-02 0001045810-05-000002 — 2.02, 5.02, 9.01
- 2004-11-04 0001045810-04-000030 — 2.02, 9.01
- 2004-10-27 0001045810-04-000028 — 2.02, 9.01
- 2004-08-20 0001045810-04-000025 — 5
- 2004-08-11 0001045810-04-000021 — 5, 7
- 2004-08-05 0001045810-04-000020 — 12
- 2004-05-06 0001045810-04-000011 — 12
- 2004-04-26 0001045810-04-000009 — 4, 7
- 2004-02-12 0001045810-04-000005 — 12
- 2003-11-06 0001045810-03-000007 — 12
- 2003-09-17 0000891092-03-002498 — 5
- 2003-09-12 0000891092-03-002448 — 9
- 2003-08-22 0000891092-03-002251 — 9
- 2003-08-07 0000891092-03-002009 — 12
- 2003-08-05 0000891092-03-001967 — 9
- 2003-07-30 0000891092-03-001853 — 9
- 2003-05-08 0000891092-03-001003 — 9
- 2002-08-30 0001012870-02-003669 — 7, 9
- 2002-05-01 0001012870-02-002054 — 9
- 2002-04-29 0000950168-02-001118 — 5
- 2002-04-29 0000950168-02-001116 — 5, 7
- 2001-05-31 0001012870-01-501069 — 7 — amendment of 0001012870-01-500581
- 2001-05-03 0001012870-01-500581 — 2, 7
- 2000-10-05 0001012870-00-005147 — 7
- 2000-09-28 0001012870-00-005003 — 5

## late-filing notifications on or before 2025-02-26

- 2006-09-11 0001193125-06-188313 — NT 10-Q, for the period ended 2006-07-30
- 2002-04-29 0000950168-02-001121 — NT 10-K, for the period ended 2002-01-27

## item 2.02 — earnings release, exhibit 99.1

[0001045810-25-000021:8k_2_02:1]
EX-99.1
2
q4fy25pr.htm
Q4FY25 PRESS RELEASE

[0001045810-25-000021:8k_2_02:2]
Document

[0001045810-25-000021:8k_2_02:3]
FOR IMMEDIATE RELEASE:

[0001045810-25-000021:8k_2_02:4]
NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2025

[0001045810-25-000021:8k_2_02:5]
•Record quarterly revenue of $39.3 billion, up 12% from Q3 and up 78% from a year ago

[0001045810-25-000021:8k_2_02:6]
•Record quarterly Data Center revenue of $35.6 billion, up 16% from Q3 and up 93% from a year ago

[0001045810-25-000021:8k_2_02:7]
•Record full-year revenue of $130.5 billion, up 114%

[0001045810-25-000021:8k_2_02:8]
SANTA CLARA, Calif.—Feb. 26, 2025―NVIDIA (NASDAQ: NVDA) today reported revenue for the fourth quarter ended January 26, 2025, of $39.3 billion, up 12% from the previous quarter and up 78% from a year ago.

[0001045810-25-000021:8k_2_02:9]
For the quarter, GAAP earnings per diluted share was $0.89, up 14% from the previous quarter and up 82% from a year ago. Non-GAAP earnings per diluted share was $0.89, up 10% from the previous quarter and up 71% from a year ago.

[0001045810-25-000021:8k_2_02:10]
For fiscal 2025, revenue was $130.5 billion, up 114% from a year ago. GAAP earnings per diluted share was $2.94, up 147% from a year ago. Non-GAAP earnings per diluted share was $2.99, up 130% from a year ago.

[0001045810-25-000021:8k_2_02:11]
“Demand for Blackwell is amazing as reasoning AI adds another scaling law — increasing compute for training makes models smarter and increasing compute for long thinking makes the answer smarter,” said Jensen Huang, founder and CEO of NVIDIA.

[0001045810-25-000021:8k_2_02:12]
“We’ve successfully ramped up the massive-scale production of Blackwell AI supercomputers, achieving billions of dollars in sales in its first quarter. AI is advancing at light speed as agentic AI and physical AI set the stage for the next wave of AI to revolutionize the largest industries.”

[0001045810-25-000021:8k_2_02:13]
NVIDIA will pay its next quarterly cash dividend of $0.01 per share on April 2, 2025, to all shareholders of record on March 12, 2025.

[0001045810-25-000021:8k_2_02:14]
Q4 Fiscal 2025 Summary

[0001045810-25-000021:8k_2_02:15]
| GAAP |
| ($ in millions, except earnings per share) | Q4 FY25 | Q3 FY25 | Q4 FY24 | Q/Q | Y/Y |
| Revenue | $39,331 | $35,082 | $22,103 | Up 12% | Up 78% |
| Gross margin | 73.0 | % | 74.6 | % | 76.0 | % | Down 1.6 pts | Down 3.0 pts |
| Operating expenses | $4,689 | $4,287 | $3,176 | Up 9% | Up 48% |
| Operating income | $24,034 | $21,869 | $13,615 | Up 10% | Up 77% |
| Net income | $22,091 | $19,309 | $12,285 | Up 14% | Up 80% |
| Diluted earnings per share* | $0.89 | $0.78 | $0.49 | Up 14% | Up 82% |

[0001045810-25-000021:8k_2_02:16]
| Non-GAAP |
| ($ in millions, except earnings per share) | Q4 FY25 | Q3 FY25 | Q4 FY24 | Q/Q | Y/Y |
| Revenue | $39,331 | $35,082 | $22,103 | Up 12% | Up 78% |
| Gross margin | 73.5 | % | 75.0 | % | 76.7 | % | Down 1.5 pts | Down 3.2 pts |
| Operating expenses | $3,378 | $3,046 | $2,210 | Up 11% | Up 53% |
| Operating income | $25,516 | $23,276 | $14,749 | Up 10% | Up 73% |
| Net income | $22,066 | $20,010 | $12,839 | Up 10% | Up 72% |
| Diluted earnings per share* | $0.89 | $0.81 | $0.52 | Up 10% | Up 71% |

[0001045810-25-000021:8k_2_02:17]
Fiscal 2025 Summary

[0001045810-25-000021:8k_2_02:18]
| GAAP |
| ($ in millions, except earnings per share) | FY25 | FY24 | Y/Y |
| Revenue | $130,497 | $60,922 | Up 114% |
| Gross margin | 75.0 | % | 72.7 | % | Up 2.3 pts |
| Operating expenses | $16,405 | $11,329 | Up 45% |
| Operating income | $81,453 | $32,972 | Up 147% |
| Net income | $72,880 | $29,760 | Up 145% |
| Diluted earnings per share* | $2.94 | $1.19 | Up 147% |

[0001045810-25-000021:8k_2_02:19]
| Non-GAAP |
| ($ in millions, except earnings per share) | FY25 | FY24 | Y/Y |
| Revenue | $130,497 | $60,922 | Up 114% |
| Gross margin | 75.5 | % | 73.8 | % | Up 1.7 pts |
| Operating expenses | $11,716 | $7,825 | Up 50% |
| Operating income | $86,789 | $37,134 | Up 134% |
| Net income | $74,265 | $32,312 | Up 130% |
| Diluted earnings per share* | $2.99 | $1.30 | Up 130% |

[0001045810-25-000021:8k_2_02:20]
*All per share amounts presented herein have been retroactively adjusted to reflect the ten-for-one stock split, which was effective June 7, 2024.

[0001045810-25-000021:8k_2_02:21]
Outlook

[0001045810-25-000021:8k_2_02:22]
NVIDIA’s outlook for the first quarter of fiscal 2026 is as follows:

[0001045810-25-000021:8k_2_02:23]
•Revenue is expected to be $43.0 billion, plus or minus 2%.

[0001045810-25-000021:8k_2_02:24]
•GAAP and non-GAAP gross margins are expected to be 70.6% and 71.0%, respectively, plus or minus 50 basis points.

[0001045810-25-000021:8k_2_02:25]
•GAAP and non-GAAP operating expenses are expected to be approximately $5.2 billion and $3.6 billion, respectively.

[0001045810-25-000021:8k_2_02:26]
•GAAP and non-GAAP other income and expense are expected to be an income of approximately $400 million, excluding gains and losses from non-marketable and publicly-held equity securities.

[0001045810-25-000021:8k_2_02:27]
•GAAP and non-GAAP tax rates are expected to be 17.0%, plus or minus 1%, excluding any discrete items.

[0001045810-25-000021:8k_2_02:28]
Highlights

[0001045810-25-000021:8k_2_02:29]
NVIDIA achieved progress since its previous earnings announcement in these areas:

[0001045810-25-000021:8k_2_02:30]
Data Center

[0001045810-25-000021:8k_2_02:31]
•Fourth-quarter revenue was a record $35.6 billion, up 16% from the previous quarter and up 93% from a year ago. Full-year revenue rose 142% to a record $115.2 billion.

[0001045810-25-000021:8k_2_02:32]
•Announced that NVIDIA will serve as a key technology partner for the $500 billion Stargate Project.

[0001045810-25-000021:8k_2_02:33]
•Revealed that cloud service providers AWS, CoreWeave, Google Cloud Platform (GCP), Microsoft Azure and Oracle Cloud Infrastructure (OCI) are bringing NVIDIA® GB200 systems to cloud regions around the world to meet surging customer demand for AI.

[0001045810-25-000021:8k_2_02:34]
•Partnered with AWS to make the NVIDIA DGX™ Cloud AI computing platform and NVIDIA NIM™ microservices available through AWS Marketplace.

[0001045810-25-000021:8k_2_02:35]
•Revealed that Cisco will integrate NVIDIA Spectrum-X™ into its networking portfolio to help enterprises build AI infrastructure.

[0001045810-25-000021:8k_2_02:36]
•Revealed that more than 75% of the systems on the TOP500 list of the world’s most powerful supercomputers are powered by NVIDIA technologies.

[0001045810-25-000021:8k_2_02:37]
•Announced a collaboration with Verizon to integrate NVIDIA AI Enterprise, NIM and accelerated computing with Verizon’s private 5G network to power a range of edge enterprise AI applications and services.

[0001045810-25-000021:8k_2_02:38]
•Unveiled partnerships with industry leaders including IQVIA, Illumina, Mayo Clinic and Arc Institute to advance genomics, drug discovery and healthcare.

[0001045810-25-000021:8k_2_02:39]
•Launched NVIDIA AI Blueprints and Llama Nemotron model families for building AI agents and released NVIDIA NIM microservices to safeguard applications for agentic AI.

[0001045810-25-000021:8k_2_02:40]
•Announced the opening of NVIDIA’s first R&D center in Vietnam.

[0001045810-25-000021:8k_2_02:41]
•Revealed that Siemens Healthineers has adopted MONAI Deploy for medical imaging AI.

[0001045810-25-000021:8k_2_02:42]
Gaming and AI PC

[0001045810-25-000021:8k_2_02:43]
•Fourth-quarter Gaming revenue was $2.5 billion, down 22% from the previous quarter and down 11% from a year ago. Full-year revenue rose 9% to $11.4 billion.

[0001045810-25-000021:8k_2_02:44]
•Announced new GeForce RTX™ 50 Series graphics cards and laptops powered by the NVIDIA Blackwell architecture, delivering breakthroughs in AI-driven rendering to gamers, creators and developers.

[0001045810-25-000021:8k_2_02:45]
•Launched GeForce RTX 5090 and 5080 graphics cards, delivering up to a 2x performance improvement over the prior generation.

[0001045810-25-000021:8k_2_02:46]
•Introduced NVIDIA DLSS 4 with Multi Frame Generation and image quality enhancements, with 75 games and apps supporting it at launch, and unveiled NVIDIA Reflex 2 technology, which can reduce PC latency by up to 75%.

[0001045810-25-000021:8k_2_02:47]
•Unveiled NVIDIA NIM microservices, AI Blueprints and the Llama Nemotron family of open models for RTX AI PCs to help developers and enthusiasts build AI agents and creative workflows.

[0001045810-25-000021:8k_2_02:48]
Professional Visualization

[0001045810-25-000021:8k_2_02:49]
•Fourth-quarter revenue was $511 million, up 5% from the previous quarter and up 10% from a year ago. Full-year revenue rose 21% to $1.9 billion.

[0001045810-25-000021:8k_2_02:50]
•Unveiled NVIDIA Project DIGITS, a personal AI supercomputer that provides AI researchers, data scientists and students worldwide with access to the power of the NVIDIA Grace™ Blackwell platform.

[0001045810-25-000021:8k_2_02:51]
•Announced generative AI models and blueprints that expand NVIDIA Omniverse™ integration further into physical AI applications, including robotics, autonomous vehicles and vision AI.

[0001045810-25-000021:8k_2_02:52]
•Introduced NVIDIA Media2, an AI-powered initiative transforming content creation, streaming and live media experiences, built on NIM and AI Blueprints.

[0001045810-25-000021:8k_2_02:53]
Automotive and Robotics

[0001045810-25-000021:8k_2_02:54]
•Fourth-quarter Automotive revenue was $570 million, up 27% from the previous quarter and up 103% from a year ago. Full-year revenue rose 55% to $1.7 billion.

[0001045810-25-000021:8k_2_02:55]
•Announced that Toyota, the world’s largest automaker, will build its next-generation vehicles on NVIDIA DRIVE AGX Orin™ running the safety-certified NVIDIA DriveOS operating system.

[0001045810-25-000021:8k_2_02:56]
•Partnered with Hyundai Motor Group to create safer, smarter vehicles, supercharge manufacturing and deploy cutting-edge robotics with NVIDIA AI and NVIDIA Omniverse.

[0001045810-25-000021:8k_2_02:57]
•Announced that the NVIDIA DriveOS safe autonomous driving operating system received ASIL-D functional safety certification and launched the NVIDIA DRIVE™ AI Systems Inspection Lab.

[0001045810-25-000021:8k_2_02:58]
•Launched NVIDIA Cosmos™, a platform comprising state-of-the-art generative world foundation models, to accelerate physical AI development, with adoption by leading robotics and automotive companies 1X, Agile Robots, Waabi, Uber and others.

[0001045810-25-000021:8k_2_02:59]
•Unveiled the NVIDIA Jetson Orin Nano™ Super, which delivers up to a 1.7x gain in generative AI performance.

[0001045810-25-000021:8k_2_02:60]
CFO Commentary

[0001045810-25-000021:8k_2_02:61]
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.

[0001045810-25-000021:8k_2_02:62]
Conference Call and Webcast Information

[0001045810-25-000021:8k_2_02:63]
NVIDIA will conduct a conference call with analysts and investors to discuss its fourth quarter and fiscal 2025 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m.

[0001045810-25-000021:8k_2_02:64]
Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its first quarter of fiscal 2026.

[0001045810-25-000021:8k_2_02:65]
Non-GAAP Measures

[0001045810-25-000021:8k_2_02:66]
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude stock-based compensation expense, acquisition-related and other costs, other, gains from non-marketable and publicly-held equity securities, net, interest expense related to amortization of debt discount, and the associated tax impact of these items where applicable. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the user’s overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.

[0001045810-25-000021:8k_2_02:67]
About NVIDIA

[0001045810-25-000021:8k_2_02:68]
NVIDIA (NASDAQ: NVDA) is the world leader in accelerated computing.

[0001045810-25-000021:8k_2_02:69]
###

[0001045810-25-000021:8k_2_02:70]
For further information, contact:

[0001045810-25-000021:8k_2_02:71]
| Stewart Stecker |  | Mylene Mangalindan |
| Investor Relations |  | Corporate Communications |
| NVIDIA Corporation |  | NVIDIA Corporation |
| sstecker@nvidia.com |  | mmangalindan@nvidia.com |

[0001045810-25-000021:8k_2_02:72]
Certain statements in this press release including, but not limited to, statements as to: AI advancing at light speed as agentic AI and physical AI set the stage for the next wave of AI to revolutionize the largest industries; expectations with respect to growth, performance and benefits of NVIDIA’s products, services and technologies, including Blackwell, and related trends and drivers; expectations with respect to supply and demand for NVIDIA’s products, services and technologies, including Blackwell, and related matters including inventory, production and distribution; expectations with respect to NVIDIA’s third party arrangements, including with its collaborators and partners; expectations with respect to technology developments and related trends and drivers; future NVIDIA cash dividends or other returns to stockholders; NVIDIA’s financial and business outlook for the first quarter of fiscal 2026 and beyond; projected market growth and trends; expectations with respect to AI and related industries; and other statements that are not historical facts are risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic and political conditions; NVIDIA’s reliance on third parties to manufacture, assemble, package and test NVIDIA’s products; the impact of technological development and competition; development of new products and technologies or enhancements to NVIDIA’s existing product and technologies; market acceptance of NVIDIA’s products or NVIDIA’s partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of NVIDIA’s products or technologies when integrated into systems; and changes in applicable laws and regulations, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and,

[0001045810-25-000021:8k_2_02:73]
except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.

[0001045810-25-000021:8k_2_02:74]
© 2025 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, GeForce RTX, NVIDIA Cosmos, NVIDIA Spectrum-X, NVIDIA DGX, NVIDIA DRIVE, NVIDIA DRIVE AGX Orin, NVIDIA Grace, NVIDIA Jetson Orin Nano, NVIDIA NIM and NVIDIA Omniverse are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.

[0001045810-25-000021:8k_2_02:75]
NVIDIA CORPORATION

[0001045810-25-000021:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001045810-25-000021:8k_2_02:77]
(In millions, except per share data)

[0001045810-25-000021:8k_2_02:78]
(Unaudited)

[0001045810-25-000021:8k_2_02:79]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 26, |  | January 28, |  | January 26, |  | January 28, |
|  |  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue | $ | 39,331 |  |  | $ | 22,103 |  |  | $ | 130,497 |  |  | $ | 60,922 |  |
| Cost of revenue | 10,608 |  |  | 5,312 |  |  | 32,639 |  |  | 16,621 |  |
| Gross profit | 28,723 |  |  | 16,791 |  |  | 97,858 |  |  | 44,301 |  |
| Operating expenses |  |  |  |  |  |  |  |
|  | Research and development | 3,714 |  |  | 2,465 |  |  | 12,914 |  |  | 8,675 |  |
|  | Sales, general and administrative | 975 |  |  | 711 |  |  | 3,491 |  |  | 2,654 |  |
|  |  | Total operating expenses | 4,689 |  |  | 3,176 |  |  | 16,405 |  |  | 11,329 |  |
| Operating income | 24,034 |  |  | 13,615 |  |  | 81,453 |  |  | 32,972 |  |
|  | Interest income | 511 |  |  | 294 |  |  | 1,786 |  |  | 866 |  |
|  | Interest expense | (61) |  |  | (63) |  |  | (247) |  |  | (257) |  |
|  | Other, net | 733 |  |  | 260 |  |  | 1,034 |  |  | 237 |  |
|  |  | Other income (expense), net | 1,183 |  |  | 491 |  |  | 2,573 |  |  | 846 |  |
| Income before income tax | 25,217 |  |  | 14,106 |  |  | 84,026 |  |  | 33,818 |  |
| Income tax expense | 3,126 |  |  | 1,821 |  |  | 11,146 |  |  | 4,058 |  |
| Net income | $ | 22,091 |  |  | $ | 12,285 |  |  | $ | 72,880 |  |  | $ | 29,760 |  |
| Net income per share: |  |  |  |  |  |  |  |
|  | Basic | $ | 0.90 |  |  | $ | 0.51 |  |  | $ | 2.97 |  |  | $ | 1.21 |  |
|  | Diluted | $ | 0.89 |  |  | $ | 0.49 |  |  | $ | 2.94 |  |  | $ | 1.19 |  |
| Weighted average shares used in per share computation: |  |  |  |  |  |  |  |
|  | Basic | 24,489 |  |  | 24,660 |  |  | 24,555 |  |  | 24,690 |  |
|  | Diluted | 24,706 |  |  | 24,900 |  |  | 24,804 |  |  | 24,940 |  |

[0001045810-25-000021:8k_2_02:80]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  |  |  | January 26, |  | January 28, |
|  |  |  |  | 2025 |  | 2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
|  | Cash, cash equivalents and marketable securities |  | $ | 43,210 |  |  | $ | 25,984 |  |
|  | Accounts receivable, net |  | 23,065 |  |  | 9,999 |  |
|  | Inventories |  | 10,080 |  |  | 5,282 |  |
|  | Prepaid expenses and other current assets |  | 3,771 |  |  | 3,080 |  |
|  |  | Total current assets |  | 80,126 |  |  | 44,345 |  |
| Property and equipment, net |  | 6,283 |  |  | 3,914 |  |
| Operating lease assets |  | 1,793 |  |  | 1,346 |  |
| Goodwill |  | 5,188 |  |  | 4,430 |  |
| Intangible assets, net |  | 807 |  |  | 1,112 |  |
| Deferred income tax assets |  | 10,979 |  |  | 6,081 |  |
| Other assets |  | 6,425 |  |  | 4,500 |  |
|  |  | Total assets |  | $ | 111,601 |  |  | $ | 65,728 |  |
| LIABILITIES AND SHAREHOLDERS' EQUITY |
| Current liabilities: |  |  |  |  |
|  | Accounts payable |  | $ | 6,310 |  |  | $ | 2,699 |  |
|  | Accrued and other current liabilities |  | 11,737 |  |  | 6,682 |  |
|  | Short-term debt |  | — |  |  | 1,250 |  |
|  |  | Total current liabilities |  | 18,047 |  |  | 10,631 |  |
| Long-term debt |  | 8,463 |  |  | 8,459 |  |
| Long-term operating lease liabilities |  | 1,519 |  |  | 1,119 |  |
| Other long-term liabilities |  | 4,245 |  |  | 2,541 |  |
|  |  | Total liabilities |  | 32,274 |  |  | 22,750 |  |
| Shareholders' equity |  | 79,327 |  |  | 42,978 |  |
|  |  | Total liabilities and shareholders' equity |  | $ | 111,601 |  |  | $ | 65,728 |  |

[0001045810-25-000021:8k_2_02:81]
| NVIDIA CORPORATION |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |
|  | Three Months Ended |  | Twelve Months Ended |
|  | January 26, |  | January 28, |  | January 26, |  | January 28, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 22,091 |  |  | $ | 12,285 |  |  | $ | 72,880 |  |  | $ | 29,760 |  |
| Adjustments to reconcile net income to net cash |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,321 |  |  | 993 |  |  | 4,737 |  |  | 3,549 |  |
| Depreciation and amortization | 543 |  |  | 387 |  |  | 1,864 |  |  | 1,508 |  |
| Deferred income taxes | (598) |  |  | (78) |  |  | (4,477) |  |  | (2,489) |  |
| Gains on non-marketable equity securities and publicly-held equity securities, net | (727) |  |  | (260) |  |  | (1,030) |  |  | (238) |  |
| Other | (138) |  |  | (109) |  |  | (502) |  |  | (278) |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable | (5,370) |  |  | (1,690) |  |  | (13,063) |  |  | (6,172) |  |
| Inventories | (2,424) |  |  | (503) |  |  | (4,781) |  |  | (98) |  |
| Prepaid expenses and other assets | 331 |  |  | (1,184) |  |  | (395) |  |  | (1,522) |  |
| Accounts payable | 867 |  |  | 281 |  |  | 3,357 |  |  | 1,531 |  |
| Accrued and other current liabilities | 360 |  |  | 1,072 |  |  | 4,278 |  |  | 2,025 |  |
| Other long-term liabilities | 372 |  |  | 305 |  |  | 1,221 |  |  | 514 |  |
| Net cash provided by operating activities | 16,628 |  |  | 11,499 |  |  | 64,089 |  |  | 28,090 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities | 1,710 |  |  | 1,731 |  |  | 11,195 |  |  | 9,732 |  |
| Proceeds from sales of marketable securities | 177 |  |  | 50 |  |  | 495 |  |  | 50 |  |
| Proceeds from sales of non-marketable equity securities | — |  |  | — |  |  | 171 |  |  | 1 |  |
| Purchases of marketable securities | (7,010) |  |  | (7,524) |  |  | (26,575) |  |  | (18,211) |  |
| Purchase related to property and equipment and intangible assets | (1,077) |  |  | (253) |  |  | (3,236) |  |  | (1,069) |  |
| Purchases of non-marketable equity securities | (478) |  |  | (113) |  |  | (1,486) |  |  | (862) |  |
| Acquisitions, net of cash acquired | (542) |  |  | — |  |  | (1,007) |  |  | (83) |  |
| Other | 22 |  |  | — |  |  | 22 |  |  | (124) |  |
| Net cash used in investing activities | (7,198) |  |  | (6,109) |  |  | (20,421) |  |  | (10,566) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds related to employee stock plans | — |  |  | — |  |  | 490 |  |  | 403 |  |
| Payments related to repurchases of common stock | (7,810) |  |  | (2,660) |  |  | (33,706) |  |  | (9,533) |  |
| Payments related to tax on restricted stock units | (1,861) |  |  | (841) |  |  | (6,930) |  |  | (2,783) |  |
| Repayment of debt | — |  |  | — |  |  | (1,250) |  |  | (1,250) |  |

[0001045810-25-000021:8k_2_02:82]
| Dividends paid | (245) |  |  | (99) |  |  | (834) |  |  | (395) |  |
| Principal payments on property and equipment and intangible assets | (32) |  |  | (29) |  |  | (129) |  |  | (74) |  |
| Other | — |  |  | — |  |  | — |  |  | (1) |  |
| Net cash used in financing activities | (9,948) |  |  | (3,629) |  |  | (42,359) |  |  | (13,633) |  |
| Change in cash, cash equivalents, and restricted cash | (518) |  |  | 1,761 |  |  | 1,309 |  |  | 3,891 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 9,107 |  |  | 5,519 |  |  | 7,280 |  |  | 3,389 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 8,589 |  |  | $ | 7,280 |  |  | $ | 8,589 |  |  | $ | 7,280 |  |
| Supplemental disclosures of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for income taxes, net | $ | 4,129 |  |  | $ | 1,874 |  |  | $ | 15,118 |  |  | $ | 6,549 |  |
| Cash paid for interest | $ | 22 |  |  | $ | 26 |  |  | $ | 246 |  |  | $ | 252 |  |

[0001045810-25-000021:8k_2_02:83]
|  | NVIDIA CORPORATION |
|  | RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES |
|  | (In millions, except per share data) |
|  | (Unaudited) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 26, |  | October 27, |  | January 28, |  | January 26, |  | January 28, |
|  |  |  | 2025 |  | 2024 |  | 2024 |  | 2025 |  | 2024 |
| GAAP cost of revenue |  | $ | 10,608 |  |  | $ | 8,926 |  |  | $ | 5,312 |  |  | $ | 32,639 |  |  | $ | 16,621 |  |
| GAAP gross profit |  | $ | 28,723 |  |  | $ | 26,156 |  |  | $ | 16,791 |  |  | $ | 97,858 |  |  | $ | 44,301 |  |
| GAAP gross margin |  | 73.0 | % |  | 74.6 | % |  | 76.0 | % |  | 75.0 | % |  | 72.7 | % |
|  | Acquisition-related and other costs (A) |  | 118 |  |  | 116 |  |  | 119 |  |  | 472 |  |  | 477 |  |
|  | Stock-based compensation expense (B) |  | 53 |  |  | 50 |  |  | 45 |  |  | 178 |  |  | 141 |  |
|  | Other (C) |  | — |  |  | — |  |  | 4 |  |  | (3) |  |  | 40 |  |
| Non-GAAP cost of revenue |  | $ | 10,437 |  |  | $ | 8,759 |  |  | $ | 5,144 |  |  | $ | 31,992 |  |  | $ | 15,963 |  |
| Non-GAAP gross profit |  | $ | 28,894 |  |  | $ | 26,322 |  |  | $ | 16,959 |  |  | $ | 98,505 |  |  | $ | 44,959 |  |
| Non-GAAP gross margin |  | 73.5 | % |  | 75.0 | % |  | 76.7 | % |  | 75.5 | % |  | 73.8 | % |
| GAAP operating expenses |  | $ | 4,689 |  |  | $ | 4,287 |  |  | $ | 3,176 |  |  | $ | 16,405 |  |  | $ | 11,329 |  |
|  | Stock-based compensation expense (B) |  | (1,268) |  |  | (1,202) |  |  | (948) |  |  | (4,559) |  |  | (3,408) |  |
|  | Acquisition-related and other costs (A) |  | (43) |  |  | (39) |  |  | (18) |  |  | (130) |  |  | (106) |  |
|  | Other (C) |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Non-GAAP operating expenses |  | $ | 3,378 |  |  | $ | 3,046 |  |  | $ | 2,210 |  |  | $ | 11,716 |  |  | $ | 7,825 |  |
| GAAP operating income |  | $ | 24,034 |  |  | $ | 21,869 |  |  | $ | 13,615 |  |  | $ | 81,453 |  |  | $ | 32,972 |  |
|  | Total impact of non-GAAP adjustments to operating income |  | 1,482 |  |  | 1,407 |  |  | 1,134 |  |  | 5,336 |  |  | 4,162 |  |
| Non-GAAP operating income |  | $ | 25,516 |  |  | $ | 23,276 |  |  | $ | 14,749 |  |  | $ | 86,789 |  |  | $ | 37,134 |  |
| GAAP other income (expense), net |  | $ | 1,183 |  |  | $ | 447 |  |  | $ | 491 |  |  | $ | 2,573 |  |  | $ | 846 |  |
|  | Gains from non-marketable equity securities and publicly-held equity securities, net |  | (727) |  |  | (37) |  |  | (260) |  |  | (1,030) |  |  | (238) |  |
|  | Interest expense related to amortization of debt discount |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 4 |  |
| Non-GAAP other income (expense), net |  | $ | 457 |  |  | $ | 411 |  |  | $ | 232 |  |  | $ | 1,547 |  |  | $ | 612 |  |
| GAAP net income |  | $ | 22,091 |  |  | $ | 19,309 |  |  | $ | 12,285 |  |  | $ | 72,880 |  |  | $ | 29,760 |  |
|  | Total pre-tax impact of non-GAAP adjustments |  | 756 |  |  | 1,371 |  |  | 875 |  |  | 4,310 |  |  | 3,928 |  |
|  | Income tax impact of non-GAAP adjustments (D) |  | (781) |  |  | (670) |  |  | (321) |  |  | (2,925) |  |  | (1,376) |  |
| Non-GAAP net income |  | $ | 22,066 |  |  | $ | 20,010 |  |  | $ | 12,839 |  |  | $ | 74,265 |  |  | $ | 32,312 |  |

[0001045810-25-000021:8k_2_02:84]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 26, |  | October 27, |  | January 28, |  | January 26, |  | January 28, |
|  |  |  | 2025 |  | 2024 |  | 2024 |  | 2025 |  | 2024 |
| Diluted net income per share (E) |  |  |  |  |  |  |  |  |  |  |
|  | GAAP |  | $ | 0.89 |  |  | $ | 0.78 |  |  | $ | 0.49 |  |  | $ | 2.94 |  |  | $ | 1.19 |  |
|  | Non-GAAP |  | $ | 0.89 |  |  | $ | 0.81 |  |  | $ | 0.52 |  |  | $ | 2.99 |  |  | $ | 1.30 |  |
| Weighted average shares used in diluted net income per share computation (E) |  | 24,706 |  |  | 24,774 |  |  | 24,900 |  |  | 24,804 |  |  | 24,936 |  |
| GAAP net cash provided by operating activities |  | $ | 16,628 |  |  | $ | 17,629 |  |  | $ | 11,499 |  |  | $ | 64,089 |  |  | $ | 28,090 |  |
|  | Purchases related to property and equipment and intangible assets |  | (1,077) |  |  | (813) |  |  | (253) |  |  | (3,236) |  |  | (1,069) |  |
|  | Principal payments on property and equipment and intangible assets |  | (32) |  |  | (29) |  |  | (29) |  |  | (129) |  |  | (74) |  |
| Free cash flow |  | $ | 15,519 |  |  | $ | 16,787 |  |  | $ | 11,217 |  |  | $ | 60,724 |  |  | $ | 26,947 |  |

[0001045810-25-000021:8k_2_02:85]
| (A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 26, |  | October 27, |  | January 28, |  | January 26, |  | January 28, |
|  |  |  | 2025 |  | 2024 |  | 2024 |  | 2025 |  | 2024 |
|  | Cost of revenue |  | $ | 118 |  |  | $ | 116 |  |  | $ | 119 |  |  | $ | 472 |  |  | $ | 477 |  |
|  | Research and development |  | $ | 27 |  |  | $ | 23 |  |  | $ | 12 |  |  | $ | 79 |  |  | $ | 49 |  |
|  | Sales, general and administrative |  | $ | 16 |  |  | $ | 16 |  |  | $ | 6 |  |  | $ | 51 |  |  | $ | 57 |  |
| (B) Stock-based compensation consists of the following: |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | January 26, |  | October 27, |  | January 28, |  | January 26, |  | January 28, |
|  |  |  | 2025 |  | 2024 |  | 2024 |  | 2025 |  | 2024 |
|  | Cost of revenue |  | $ | 53 |  |  | $ | 50 |  |  | $ | 45 |  |  | $ | 178 |  |  | $ | 141 |  |
|  | Research and development |  | $ | 955 |  |  | $ | 910 |  |  | $ | 706 |  |  | $ | 3,423 |  |  | $ | 2,532 |  |
|  | Sales, general and administrative |  | $ | 313 |  |  | $ | 292 |  |  | $ | 242 |  |  | $ | 1,136 |  |  | $ | 876 |  |
| (C) Other consists of IP-related costs and assets held for sale related adjustments |
| (D) Income tax impact of non-GAAP adjustments, including the recognition of excess tax benefits or deficiencies related to stock-based compensation under GAAP accounting standard |
| (E) Reflects a ten-for-one stock split on June 7, 2024 |

[0001045810-25-000021:8k_2_02:86]
| NVIDIA CORPORATION |
| RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK |
|  |  |  | Q1 FY2026 Outlook |
|  |  |  | ($ in millions) |
| GAAP gross margin |  | 70.6 | % |
|  | Impact of stock-based compensation expense, acquisition-related costs, and other costs | 0.4 | % |
| Non-GAAP gross margin |  | 71.0 | % |
| GAAP operating expenses |  | $ | 5,150 |  |
|  | Stock-based compensation expense, acquisition-related costs, and other costs | (1,550) |  |
| Non-GAAP operating expenses |  | $ | 3,600 |  |
