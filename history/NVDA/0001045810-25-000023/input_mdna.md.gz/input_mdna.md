# NVDA MD&A — 0001045810-25-000023


## mdna

[0001045810-25-000023:mdna:1]
Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001045810-25-000023:mdna:2]
The following discussion and analysis of our financial condition and results of operations should be read in conjunction with “Item 1A. Risk Factors,” our Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Annual Report on Form 10-K, before deciding to purchase, hold, or sell shares of our common stock.

[0001045810-25-000023:mdna:3]
Overview

[0001045810-25-000023:mdna:4]
Our Company and Our Businesses

[0001045810-25-000023:mdna:5]
NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, AV, robotics, and digital twin applications.

[0001045810-25-000023:mdna:6]
Our two operating segments are "Compute & Networking" and "Graphics." Refer to Note 16 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-25-000023:mdna:7]
Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

[0001045810-25-000023:mdna:8]
Recent Developments, Future Objectives and Challenges

[0001045810-25-000023:mdna:9]
Demand and Supply

[0001045810-25-000023:mdna:10]
Revenue growth in fiscal year 2025 was driven by data center compute and networking platforms for accelerated computing and AI solutions. Demand for our Hopper architecture drove our significant growth for the full year. We began shipping production systems of the Blackwell architecture in the fourth quarter of fiscal year 2025.

[0001045810-25-000023:mdna:11]
Demand estimates for our products, applications, and services can be incorrect and create volatility in our revenue or supply levels. We may not be able to generate significant revenue from them. Advancements in accelerated computing and generative AI models, along with the growth in model complexity and scale, have driven increased demand for our Data Center systems.

[0001045810-25-000023:mdna:12]
We continue to increase our supply and capacity purchases with existing and new suppliers to support our demand projections and increasing complexity of our data center products. With these additions, we have also entered and may continue to enter into prepaid manufacturing and capacity agreements to supply both current and future products. The increased purchase volumes and integration of new suppliers and contract manufacturers into our supply chain creates more complexity in managing multiple suppliers with variations in production planning, execution and logistics. Our expanding product portfolio and varying component compatibility and quality may lead to increased inventory levels. We have incurred and may in the future incur inventory provisions or impairments if our inventory or supply or capacity commitments exceed demand for our products or demand declines.

[0001045810-25-000023:mdna:13]
Product Transitions and New Product Introductions

[0001045810-25-000023:mdna:14]
Product transitions are complex and we often ship both new and prior architecture products simultaneously as our channel partners prepare to ship and support new products. We are generally in various stages of transitioning the architectures of our Data Center, Gaming, Professional Visualization, and Automotive products. The computing industry is experiencing a broader and faster launch cadence of accelerated computing platforms to meet a growing and diverse set of AI opportunities. We have introduced a new product and architecture cadence of our Data Center solutions where we seek to complete new computing solutions each year and provide a greater variety of Data Center offerings. The increased frequency of these transitions and the larger number of products and product configurations may magnify the challenges associated with managing our supply and demand which may further create volatility in our revenue. The increased frequency and complexity of newly introduced products could result in quality or production issues that could increase inventory provisions, warranty, or other costs or result in product delays. We incur significant engineering development resources for new products, and changes to our product roadmap may impact our ability to develop other products or adequately manage our supply chain cost. Customers may delay purchasing existing products as we increase the frequency of new products or may not be able to adopt our new products as fast as forecasted, both impacting the timing of our revenue and supply chain cost. While we have managed prior product transitions and have sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and may cause us to incur additional costs.

[0001045810-25-000023:mdna:15]
Global Trade

[0001045810-25-000023:mdna:16]
In August 2022, the USG announced licensing requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits.

[0001045810-25-000023:mdna:17]
In July 2023, the USG informed us of an additional licensing requirement for a subset of A100 and H100 products destined to certain customers and other regions, including some countries in the Middle East.

[0001045810-25-000023:mdna:18]
In October 2023, the USG announced new and updated licensing requirements that became effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including, but not limited to, the A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us that the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products (removing the grace period granted by the official rule). Blackwell systems, such as GB200 NVL 72 and NVL 36 as well as B200 are also subject to these requirements and therefore require a license for any shipment to certain entities and to China and Country Groups D1, D4 and D5, excluding Israel. To date, we have not received licenses to ship these restricted products to China. Additionally, we understand that partners and customers have also not received a license to ship these restricted products.

[0001045810-25-000023:mdna:19]
We expanded our Data Center product portfolio to offer new solutions, including those for which the USG does not require a license or advance notice before each shipment. We ramped new products designed specifically for China that do not require an export control license. Our Data Center revenue in China grew in fiscal year 2025. As a percentage of total Data Center revenue, it remains well below levels seen prior to the onset of export controls in October 2023. The market in China for datacenter solutions remains competitive. We will continue to comply with export controls while serving our customers. To the extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer but have no assurance that the USG will grant such a license, or that the USG will act on the license application in a timely manner or at all.

[0001045810-25-000023:mdna:20]
On January 15, 2025, the USG published the “AI Diffusion” IFR in the Federal Register. After a 120-day delayed compliance period, the IFR will, unless modified, impose a worldwide licensing requirement on all products classified under Export Control Classification Numbers, or ECCNs, 3A090.a, 4A090.a, or corresponding .z ECCNs, including all related software and technology. Any system that incorporates one or more of the covered integrated circuits, or ICs, (including but not limited to NVIDIA DGX, HGX, and MGX systems) will be covered by the new licensing requirement. The licensing requirement will include future NVIDIA ICs, boards, or systems classified with ECCN 3A090.a or 4A090.a, or corresponding .z ECCNs, achieving certain total processing performance and/or performance density.

[0001045810-25-000023:mdna:21]
Unless a license exception is available, the worldwide licensing requirements will apply to the following NVIDIA products, and any others we develop that meet the characteristics of 3A090.a or 4A090.a, including but not limited to: A100, A800, H100, H200, H800, B100, B200, GB200, L4, L40S, and RTX 6000 Ada.

[0001045810-25-000023:mdna:22]
Our competitive position has been harmed by the existing export controls, and our competitive position and future results may be further harmed, over the long term, if there are further changes in the USG’s export controls. Given the increasing strategic importance of AI and rising geopolitical tensions, the USG has changed and may again change the export control rules at any time and further subject a wider range of our products to export restrictions and licensing requirements, negatively impacting our business and financial results. In the event of such change, we may be unable to sell our inventory of such products and may be unable to develop replacement products not subject to the licensing requirements, effectively excluding us from all or part of the China market, as well as other impacted markets, including the Middle East and countries designated “Tier 2” by the AI Diffusion IFR. In addition to export controls, the USG may impose restrictions on the import and sale of products that incorporate technologies developed or manufactured in whole or in part in China. For example, the USG is considering restrictions on the import and sale of certain automotive products in the United States, which if adopted and interpreted broadly, could impact our ability to develop and supply solutions for our automotive customers.

[0001045810-25-000023:mdna:23]
While we work to enhance the resiliency and redundancy of our supply chain, which is currently concentrated in the Asia-Pacific region, new and existing export controls or changes to existing export controls could limit alternative manufacturing locations and negatively impact our business. Refer to “Item 1A. Risk Factors – Risks Related to Regulatory, Legal, Our Stock and Other Matters” for a discussion of this potential impact.

[0001045810-25-000023:mdna:24]
Macroeconomic Factors

[0001045810-25-000023:mdna:25]
Macroeconomic factors, including inflation, interest rate changes, capital market volatility, global supply chain constraints, tariffs, and global economic and geopolitical developments, may have direct and indirect impacts on our results of operations, particularly demand for our products. While difficult to isolate and quantify, these macroeconomic factors impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Our product and solution pricing generally does not fluctuate with short-term changes in our costs. Within our supply chain, we continuously manage product availability and costs with our vendors.

[0001045810-25-000023:mdna:26]
Israel and Regional Conflicts

[0001045810-25-000023:mdna:27]
We are monitoring the impact of the geopolitical conflict in and around Israel on our operations, including the health and safety of our approximately 4,700 employees in the region who primarily support the research and development, operations, and sales and marketing of our networking products. Our global supply chain for our networking products has not experienced any significant impact. Some of our employees in the region have been on active military duty for an extended period and may continue to be absent, which may cause disruption to our product development or operations. We have not experienced significant impact or expense to our business; however, if the conflict is further extended or expanded, it could impact future product development, operations, and revenue or create other uncertainty for our business.

[0001045810-25-000023:mdna:28]
Fiscal Year 2025 Summary

[0001045810-25-000023:mdna:29]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |  | Change |
|  | ($ in millions, except per share data) |
| Revenue | $ | 130,497 |  |  | $ | 60,922 |  |  | Up 114% |
| Gross margin | 75.0 | % |  | 72.7 | % |  | Up 2.3 pts |
| Operating expenses | $ | 16,405 |  |  | $ | 11,329 |  |  | Up 45% |
| Operating income | $ | 81,453 |  |  | $ | 32,972 |  |  | Up 147% |
| Net income | $ | 72,880 |  |  | $ | 29,760 |  |  | Up 145% |
| Net income per diluted share | $ | 2.94 |  |  | $ | 1.19 |  |  | Up 147% |

[0001045810-25-000023:mdna:30]
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

[0001045810-25-000023:mdna:31]
Revenue for fiscal year 2025 was $130.5 billion, up 114% from a year ago.

[0001045810-25-000023:mdna:32]
Data Center revenue for fiscal year 2025 was up 142% from a year ago. The strong year-on-year growth was driven by demand for our Hopper architecture accelerated computing platform used for large language models, recommendation engines, and generative AI applications. We began shipping production systems of the Blackwell architecture in the fourth quarter of fiscal year 2025.

[0001045810-25-000023:mdna:33]
Gaming revenue for fiscal year 2025 was up 9% from a year ago, driven by sales of our GeForce RTX 40 Series GPUs.

[0001045810-25-000023:mdna:34]
Professional Visualization revenue for fiscal year 2025 was up 21% from a year ago, driven by the continued ramp of Ada RTX GPU workstations for use cases such as generative AI-powered design, simulation, and engineering.

[0001045810-25-000023:mdna:35]
Automotive revenue for fiscal year 2025 was up 55% from a year ago, driven by sales of our self-driving platforms.

[0001045810-25-000023:mdna:36]
Gross margin increased in fiscal year 2025 driven by a higher mix of Data Center revenue.

[0001045810-25-000023:mdna:37]
Operating expenses for fiscal year 2025 were up 45% from a year ago, driven by higher compensation and benefits expenses due to employee growth and compensation increases, and engineering development, compute and infrastructure costs for new product introductions.

[0001045810-25-000023:mdna:38]
Critical Accounting Estimates

[0001045810-25-000023:mdna:39]
Our consolidated financial statements are prepared in accordance with accounting principles generally accepted in the United States, or U.S. GAAP. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue, expenses and related disclosure of contingencies. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and could have a material impact on our financial condition or results of operations. We have critical accounting estimates in the areas of inventories, income taxes, and revenue recognition. Refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a summary of significant accounting policies.

[0001045810-25-000023:mdna:40]
Inventories

[0001045810-25-000023:mdna:41]
We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory, and for excess product purchase commitments. Most of our inventory provisions relate to excess quantities of products or components, based on our inventory levels and future product purchase

[0001045810-25-000023:mdna:42]
commitments compared to assumptions about future demand and market conditions, which requires management judgment.

[0001045810-25-000023:mdna:43]
Situations that may result in excess or obsolete inventory or excess product purchase commitments include changes in business and economic conditions, changes in market conditions, sudden and significant decreases in demand for our products, including potential cancellation or deferral of customer purchase orders, inventory obsolescence because of changing technology and customer requirements, new product introductions resulting in less demand for existing products or inconsistent spikes in demand, failure to estimate customer demand properly, ordering in advance of historical lead-times, government regulations and the impact of changes in future demand, or increase in demand for competitive products, including competitive actions.

[0001045810-25-000023:mdna:44]
The net effect on our gross margin from inventory provisions and sales of items previously written down was an unfavorable impact of 2.3% in fiscal year 2025 and 2.7% in fiscal year 2024. Our inventory and capacity purchase commitments are based on forecasts of future customer demand and consider our third-party manufacturers' lead times and constraints. Our manufacturing lead times can be and have been long, and in some cases, extended beyond twelve months for some products. We may place non-cancellable inventory orders for certain product components in advance of our historical lead times, pay premiums and provide deposits to secure future supply and capacity. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001045810-25-000023:mdna:45]
Refer to the Gross Profit and Gross Margin discussion below in this Management's Discussion and Analysis for further discussion.

[0001045810-25-000023:mdna:46]
Income Taxes

[0001045810-25-000023:mdna:47]
We are subject to income taxes in the U.S. and foreign jurisdictions. Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the U.S. or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential U.S. and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001045810-25-000023:mdna:48]
We record a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized based on all available evidence. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001045810-25-000023:mdna:49]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001045810-25-000023:mdna:50]
Revenue Recognition

[0001045810-25-000023:mdna:51]
Revenue Allowances

[0001045810-25-000023:mdna:52]
For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to reflect our estimated exposure for product returns. Return rights for certain stocking distributors for specific products are contractually limited based on a percentage of prior quarter shipments. For shipments to other customers, we do not allow returns, although we may approve returns for credit or refund based on applicable facts and circumstances.

[0001045810-25-000023:mdna:53]
We account for customer programs, which involve rebates and marketing development funds, or MDFs, as a reduction in revenue and accrue for such programs based on the amount we expect to be claimed by customers. Certain customer programs include distributor price incentives or other channel programs for specific products and customer classes which require judgement as to whether the applicable incentives will be attained. Estimates for customer program accruals include a combination of historical attainment and claim rates and may be adjusted based on relevant internal and external factors.

[0001045810-25-000023:mdna:54]
License and Development Arrangements

[0001045810-25-000023:mdna:55]
Revenue from License and Development Arrangements is recognized over the period in which the development services are performed. Each fiscal reporting period, we measure progress to completion based on actual cost incurred to date as a percentage of the estimated total cost required to complete each project. Estimated total cost for each project includes a forecast of internal engineer personnel time expected to be incurred and other third-party costs as applicable.

[0001045810-25-000023:mdna:56]
Contracts with Multiple Performance Obligations

[0001045810-25-000023:mdna:57]
Our contracts may contain more than one performance obligation. Judgement is required in determining whether each performance obligation within a customer contract is distinct. Except for License and Development Arrangements, NVIDIA products and services function on a standalone basis and do not require a significant amount of integration or interdependency. Therefore, multiple performance obligations contained within a customer contract are considered distinct and are not combined for revenue recognition purposes.

[0001045810-25-000023:mdna:58]
We allocate the total transaction price to each distinct performance obligation in an arrangement with multiple performance obligations on a relative standalone selling price basis. In certain cases, we can establish standalone selling price based on directly observable prices of products or services sold separately in comparable circumstances to similar customers. If standalone selling price is not directly observable, such as when we do not sell a product or service separately, we determine standalone selling price based on market data and other observable inputs.

[0001045810-25-000023:mdna:59]
Results of Operations

[0001045810-25-000023:mdna:60]
A discussion regarding our financial condition and results of operations for fiscal year 2025 compared to fiscal year 2024 is presented below. A discussion regarding our financial condition and results of operations for fiscal year 2024 compared to fiscal year 2023 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended January 28, 2024, filed with the SEC on February 21, 2024, which is available free of charge on the SEC’s website at http://www.sec.gov and at our investor relations website, http://investor.nvidia.com.

[0001045810-25-000023:mdna:61]
The following table sets forth, for the periods indicated, certain items in our Consolidated Statements of Income expressed as a percentage of revenue.

[0001045810-25-000023:mdna:62]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |
| Revenue | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 25.0 |  |  | 27.3 |  |
| Gross profit | 75.0 |  |  | 72.7 |  |
| Operating expenses |  |  |  |
| Research and development | 9.9 |  |  | 14.2 |  |
| Sales, general and administrative | 2.7 |  |  | 4.4 |  |
| Total operating expenses | 12.6 |  |  | 18.6 |  |
| Operating income | 62.4 |  |  | 54.1 |  |
| Interest income | 1.4 |  |  | 1.4 |  |
| Interest expense | (0.2) |  |  | (0.4) |  |
| Other, net | 0.8 |  |  | 0.4 |  |
| Other income (expense), net | 2.0 |  |  | 1.4 |  |
| Income before income tax | 64.4 |  |  | 55.5 |  |
| Income tax expense | 8.6 |  |  | 6.6 |  |
| Net income | 55.8 | % |  | 48.9 | % |

[0001045810-25-000023:mdna:63]
Reportable Segments

[0001045810-25-000023:mdna:64]
Revenue by Reportable Segments

[0001045810-25-000023:mdna:65]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 116,193 |  |  | $ | 47,405 |  |  | $ | 68,788 |  |  | 145 | % |
| Graphics | 14,304 |  |  | 13,517 |  |  | 787 |  |  | 6 | % |
| Total | $ | 130,497 |  |  | $ | 60,922 |  |  | $ | 69,575 |  |  | 114 | % |

[0001045810-25-000023:mdna:66]
Operating Income by Reportable Segments

[0001045810-25-000023:mdna:67]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Compute & Networking | $ | 82,875 |  |  | $ | 32,016 |  |  | $ | 50,859 |  |  | 159 | % |
| Graphics | 5,085 |  |  | 5,846 |  |  | (761) |  |  | (13) | % |
| All Other | (6,507) |  |  | (4,890) |  |  | (1,617) |  |  | 33 | % |
| Total | $ | 81,453 |  |  | $ | 32,972 |  |  | $ | 48,481 |  |  | 147 | % |

[0001045810-25-000023:mdna:68]
Compute & Networking revenue – The year over year increase was due to strong demand for our accelerated computing and AI solutions. Revenue from Data Center computing grew 162% driven primarily by demand for our Hopper computing platform used for large language models, recommendation engines, and generative AI applications. Revenue from Data Center networking grew 51% driven by Ethernet for AI revenue, which includes Spectrum-X end-to-end ethernet platform.

[0001045810-25-000023:mdna:69]
Graphics revenue – The year over year increase was driven by sales of our GeForce RTX 40 Series GPUs.

[0001045810-25-000023:mdna:70]
Reportable segment operating income – The year over year increase in Compute & Networking segment operating income was driven by growth in revenue. The year over year decrease in Graphics segment operating income was driven by an increase of 44% in segment operating expenses, partially offset by growth in revenue.

[0001045810-25-000023:mdna:71]
All Other operating loss – The year over year increase was due to an increase in stock-based compensation expense reflecting employee growth and compensation increases.

[0001045810-25-000023:mdna:72]
Concentration of Revenue

[0001045810-25-000023:mdna:73]
We refer to customers who purchase products directly from NVIDIA as direct customers, such as AIBs, distributors, ODMs, OEMs, and system integrators. We have certain customers that may purchase products directly from NVIDIA and may use either internal resources or third-party system integrators to complete their build. We also have indirect customers, who purchase products through our direct customers; indirect customers include CSPs, consumer internet companies, enterprises, and public sector entities.

[0001045810-25-000023:mdna:74]
Direct Customers – Sales to direct customers which represented 10% or more of total revenue, all of which were primarily attributable to the Compute & Networking segment, are presented in the following table:

[0001045810-25-000023:mdna:75]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |
| Direct Customer A | 12 | % |  | * |
| Direct Customer B | 11 | % |  | 13 | % |
| Direct Customer C | 11 | % |  | * |

[0001045810-25-000023:mdna:76]
* Less than 10% of total revenue.

[0001045810-25-000023:mdna:77]
No customer represented 10% or more of total revenue for fiscal year 2023.

[0001045810-25-000023:mdna:78]
Indirect Customers – Indirect customer revenue is an estimation based upon multiple factors including customer purchase order information, product specifications, internal sales data, and other sources. Actual indirect customer revenue may differ from our estimates. For fiscal year 2025, an indirect customer which primarily purchases our products through system integrators and distributors, including through Direct Customer B, is estimated to represent 10% or more of total revenue, attributable to the Compute & Networking segment.

[0001045810-25-000023:mdna:79]
We have experienced periods where we receive a significant amount of our revenue from a limited number of customers, and this trend may continue.

[0001045810-25-000023:mdna:80]
Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to indirect customers in a different location. Revenue from sales to customers outside of the United States accounted for 53% and 56% of total revenue for fiscal years 2025 and 2024, respectively.

[0001045810-25-000023:mdna:81]
Gross Profit and Gross Margin

[0001045810-25-000023:mdna:82]
Gross profit consists of total net revenue less cost of revenue. Cost of revenue consists primarily of the cost of semiconductors, including wafer fabrication, assembly, testing and packaging, board and device costs, manufacturing support costs, including labor and overhead associated with such purchases, final test yield fallout, inventory and warranty provisions, memory and component costs, tariffs, and shipping costs. Cost of revenue also includes acquisition-related intangible amortization expense, costs for license and development and service arrangements, IP-related costs, and stock-based compensation related to personnel associated with manufacturing operations.

[0001045810-25-000023:mdna:83]
Gross margins increased to 75.0% in fiscal year 2025 from 72.7% in fiscal year 2024. The year over year increase was primarily driven by a higher mix of Data Center revenue.

[0001045810-25-000023:mdna:84]
Provisions for inventory and excess inventory purchase obligations totaled $3.7 billion and $2.2 billion for fiscal years 2025 and 2024, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $689 million and $540 million for fiscal years 2025 and 2024, respectively. The net effect on our gross margin was an unfavorable impact of 2.3% and 2.7% in fiscal years 2025 and 2024, respectively.

[0001045810-25-000023:mdna:85]
Operating Expenses

[0001045810-25-000023:mdna:86]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |  | $Change |  | %Change |
|  | ($ in millions) |
| Research and development expenses | $ | 12,914 |  |  | $ | 8,675 |  |  | $ | 4,239 |  |  | 49 | % |
| % of net revenue | 9.9 | % |  | 14.2 | % |  |  |  |  |
| Sales, general and administrative expenses | 3,491 |  |  | 2,654 |  |  | 837 |  |  | 32 | % |
| % of net revenue | 2.7 | % |  | 4.4 | % |  |  |  |  |
| Total operating expenses | $ | 16,405 |  |  | $ | 11,329 |  |  | $ | 5,076 |  |  | 45 | % |
| % of net revenue | 12.6 | % |  | 18.6 | % |  |  |  |  |

[0001045810-25-000023:mdna:87]
The increases in research and development expenses for fiscal year 2025 were driven by a 32% increase in compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases, a 100% increase in compute and infrastructure, and a 234% increase in engineering development costs for new product introductions.

[0001045810-25-000023:mdna:88]
The increases in sales, general and administrative expenses for fiscal year 2025 were primarily driven by compensation and benefits, including stock-based compensation, reflecting employee growth and compensation increases.

[0001045810-25-000023:mdna:89]
Other Income (Expense), Net

[0001045810-25-000023:mdna:90]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |  | $Change |  |  |
|  | ($ in millions) |
| Interest income | $ | 1,786 |  |  | $ | 866 |  |  | $ | 920 |  |  |  |
| Interest expense | (247) |  |  | (257) |  |  | 10 |  |  |  |
| Other, net | 1,034 |  |  | 237 |  |  | 797 |  |  |  |
| Other income (expense), net | $ | 2,573 |  |  | $ | 846 |  |  | $ | 1,727 |  |  |  |

[0001045810-25-000023:mdna:91]
The increase in interest income was primarily due to growth in cash, cash equivalents, and marketable securities.

[0001045810-25-000023:mdna:92]
Interest expense is comprised of coupon interest and debt discount amortization related to our notes.

[0001045810-25-000023:mdna:93]
Other, net consists of realized or unrealized gains and losses from investments in non-marketable equity securities, publicly-held equity securities, and the impact of changes in foreign currency rates. The change in Other, net, compared to fiscal year 2024, was primarily driven by an increase in fair value of our non-marketable equity securities and publicly-held equity securities. Refer to Note 8 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information regarding our non-marketable equity securities.

[0001045810-25-000023:mdna:94]
Income Taxes

[0001045810-25-000023:mdna:95]
Income tax expense was $11.1 billion and $4.1 billion for fiscal years 2025 and 2024, respectively. Income tax as a percentage of income before income tax was an expense of 13.3% and 12.0% for fiscal years 2025 and 2024, respectively.

[0001045810-25-000023:mdna:96]
The effective tax rate increased primarily due to higher pre-tax income and a prior year discrete benefit due to an audit resolution.

[0001045810-25-000023:mdna:97]
Our effective tax rates for fiscal years 2025 and 2024 were lower than the U.S. federal statutory rate of 21% due primarily to tax benefits from the FDII deduction, stock-based compensation, the U.S. federal research tax credit, and income earned in jurisdictions that are subject to taxes at rates lower than the U.S. federal statutory tax rate. Our effective tax rate for fiscal year 2024 was additionally benefited by the audit resolution.

[0001045810-25-000023:mdna:98]
Given our current and possible future earnings, we believe that we may release the valuation allowance associated with certain state deferred tax assets in the near term, which would decrease our income tax expense for the period the release is recorded. The timing and amount of the valuation allowance release could vary based on our assessment of all available information.

[0001045810-25-000023:mdna:99]
Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-25-000023:mdna:100]
Liquidity and Capital Resources

[0001045810-25-000023:mdna:101]
|  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Cash and cash equivalents | $ | 8,589 |  |  | $ | 7,280 |  |
| Marketable securities | 34,621 |  |  | 18,704 |  |
| Cash, cash equivalents, and marketable securities | $ | 43,210 |  |  | $ | 25,984 |  |

[0001045810-25-000023:mdna:102]
|  | Year Ended |
|  | Jan 26, 2025 |  | Jan 28, 2024 |
|  | (In millions) |
| Net cash provided by operating activities | $ | 64,089 |  |  | $ | 28,090 |  |
| Net cash used in investing activities | $ | (20,421) |  |  | $ | (10,566) |  |
| Net cash used in financing activities | $ | (42,359) |  |  | $ | (13,633) |  |

[0001045810-25-000023:mdna:103]
Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment types and credit exposures, and certain maturity limits on our portfolio.

[0001045810-25-000023:mdna:104]
Cash provided by operating activities increased in fiscal year 2025 compared to fiscal year 2024, due to growth in revenue.

[0001045810-25-000023:mdna:105]
Cash used in investing activities increased in fiscal year 2025 compared to fiscal year 2024, primarily driven by net purchases of marketable securities, and purchase of land, property and equipment.

[0001045810-25-000023:mdna:106]
Cash used in financing activities increased in fiscal year 2025 compared to fiscal year 2024, mainly due to higher share repurchases and higher tax payments related to RSUs.

[0001045810-25-000023:mdna:107]
Liquidity

[0001045810-25-000023:mdna:108]
Our primary sources of liquidity include cash, cash equivalents, marketable securities, and cash generated by our operations. As of January 26, 2025, we had $43.2 billion in cash, cash equivalents, and marketable securities. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and thereafter for the foreseeable future, including our future supply obligations and share purchases. We continuously evaluate our liquidity and capital resources, including our access to external capital, to ensure we can finance future capital requirements.

[0001045810-25-000023:mdna:109]
Our marketable securities consist of publicly-held equity securities, debt securities issued by the U.S. government and its agencies, highly rated corporations and financial institutions, and foreign government entities, as well as certificates of deposit issued by highly rated financial institutions. These marketable securities are primarily denominated in U.S. dollars. Refer to Note 7 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

[0001045810-25-000023:mdna:110]
Except for approximately $1.7 billion of cash, cash equivalents, and marketable securities held outside the U.S. for which we have not accrued any related foreign or state taxes if we repatriate these amounts to the U.S., substantially all of our cash, cash equivalents and marketable securities held outside the U.S. at the end of fiscal year 2025 are available for use in the U.S. without incurring additional U.S. federal income taxes.

[0001045810-25-000023:mdna:111]
Capital Return to Shareholders

[0001045810-25-000023:mdna:112]
On August 26, 2024, our Board of Directors approved an additional $50 billion to our share repurchase authorization, without expiration. In fiscal year 2025, we repurchased 310 million shares of our common stock for $34.0 billion. As of January 26, 2025, we were authorized, subject to certain specifications, to repurchase up to $38.7 billion of our common stock.

[0001045810-25-000023:mdna:113]
From January 27, 2025 through February 21, 2025, we repurchased 29 million shares for $3.7 billion pursuant to a pre-established trading plan. Our share repurchase program aims to offset dilution from shares issued to employees while maintaining adequate liquidity to meet our operating requirements. We may pursue additional share repurchases as we weigh market factors and other investment opportunities.

[0001045810-25-000023:mdna:114]
In fiscal year 2025, we paid cash dividends to our shareholders of $834 million. The payment of future cash dividends is subject to our Board of Directors' continuing determination that the declaration of dividends is in the best interests of our shareholders.

[0001045810-25-000023:mdna:115]
The U.S. Inflation Reduction Act of 2022 requires a 1% excise tax on certain share repurchases in excess of shares issued for employee compensation made after December 31, 2022. The excise tax is included in our share repurchase cost and was not material for fiscal years 2025 and 2024.

[0001045810-25-000023:mdna:116]
Outstanding Indebtedness and Commercial Paper Program

[0001045810-25-000023:mdna:117]
Our aggregate debt maturities as of January 26, 2025, by year payable, are as follows:

[0001045810-25-000023:mdna:118]
|  |  | Jan 26, 2025 |
|  |  | (In millions) |
| Due in one year |  | $ | — |  |
| Due in one to five years |  | 2,250 |  |
| Due in five to ten years |  | 2,750 |  |
| Due in greater than ten years |  | 3,500 |  |
| Unamortized debt discount and issuance costs |  | (37) |  |
| Net long-term carrying amount |  | $ | 8,463 |  |

[0001045810-25-000023:mdna:119]
We have a $575 million commercial paper program to support general corporate purposes. As of January 26, 2025, we had no commercial paper outstanding.

[0001045810-25-000023:mdna:120]
Refer to Note 11 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further discussion.

[0001045810-25-000023:mdna:121]
Material Cash Requirements and Other Obligations

[0001045810-25-000023:mdna:122]
For a description of our long-term debt, purchase obligations, and operating lease obligations, refer to Note 11, Note 12, and Note 17 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K, respectively.

[0001045810-25-000023:mdna:123]
During fiscal year 2025 and fiscal year 2024, we spent $3.4 billion and $1.1 billion on capital expenditures, respectively. We expect to increase capital expenditures in fiscal year 2026 relative to fiscal year 2025 to support the future growth of our business.

[0001045810-25-000023:mdna:124]
Unrecognized tax benefits of $2.2 billion, which includes related interest and penalties of $251 million, were recorded in non-current income tax payable at the end of fiscal year 2025. We are unable to estimate the timing of any potential tax liability, interest payments, or penalties in individual years due to uncertainties in the underlying income tax positions and the timing of the effective settlement of such tax positions. Refer to Note 13 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for further information.

[0001045810-25-000023:mdna:125]
Climate Change

[0001045810-25-000023:mdna:126]
To date, there has been no material impact to our results of operations associated with global sustainability regulations, compliance, costs from sourcing renewable energy or climate-related business trends.

[0001045810-25-000023:mdna:127]
Adoption of New and Recently Issued Accounting Pronouncements

[0001045810-25-000023:mdna:128]
Refer to Note 1 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for a discussion of adoption of new and recently issued accounting pronouncements.
