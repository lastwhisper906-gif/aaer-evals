# DELL note change history — 0001571996-21-000026 → 0001571996-21-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-09-03):
[0001571996-21-000040:note_history:1]
Purchase Obligations

- added (2021-09-03):
[0001571996-21-000040:note_history:2]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of July 30, 2021, purchase obligations were $5.2 billion, $0.6 billion, and $0.9 billion for the remaining six month of Fiscal 2022, Fiscal 2023, and Fiscal 2024 and thereafter, respectively.

- changed (2021-09-03):
[0001571996-21-000040:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  As additional information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, the Company would record related impacts to accrued liabilities in the period in which a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.
  (was, 2021-06-07, similarity 0.8909):
[0001571996-21-000026:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- changed (2021-09-03):
[0001571996-21-000040:note_history:4]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors, Goldman Sachs & Co. LLC,  and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on December 5, 2022.
  (was, 2021-06-07, similarity 0.9892):
[0001571996-21-000026:note_history:4]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on May 3, 2022.

- changed (2021-09-03):
[0001571996-21-000040:note_history:5]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia alleging infringement of four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc.  Separately, VMware has filed challenges with the United States Patent and Trademark Office against each of the four patents that are subject of Cirba’s allegation.  To date, of the four challenges, two ex parte reexams have been granted and one Inter Partes Review has been instituted.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that it is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, the amount any damages that may be awarded.  VMware, Inc. intends to vigorously defend itself in this matter.
  (was, 2021-06-07, similarity 0.7878):
[0001571996-21-000026:note_history:5]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia for infringing four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc. Separately, in February 2021, the U.S. Patent and Trademark Office (“PTO”) granted VMware, Inc.’s ex parte reexamination request as to the ‘687 patent (which was at issue in the January 2020 trial and subject to the Court’s new trial order).  In addition, in May 2021, the PTO’s Patent Trial and Appeal Board instituted Inter Partes Review (“IPR”) of the ‘492 patent in response to VMware, Inc.’s IPR petition.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, what the damages may be. VMware, Inc. intends to vigorously defend itself in this matter.

- changed (2021-09-03):
[0001571996-21-000040:note_history:6]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A common stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  Trial is currently scheduled to begin on July 6, 2022.
  (was, 2021-06-07, similarity 0.9776):
[0001571996-21-000026:note_history:6]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

- changed (2021-09-03):
[0001571996-21-000040:note_history:7]
Other Litigation — Dell does not currently expect that any other proceedings or matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2021-06-07, similarity 0.9179):
[0001571996-21-000026:note_history:7]
Other Litigation — Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- changed (2021-09-03):
[0001571996-21-000040:note_history:8]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of July 30, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2021-06-07, similarity 0.992):
[0001571996-21-000026:note_history:8]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of April 30, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:9]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  As additional information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, the Company would record related impacts to accrued liabilities in the period in which a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.
  (was, 2021-06-07, similarity 0.9227):
[0001571996-21-000026:note_history:9]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:10]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $2.6 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $3.8 billion and $4.4 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.
  (was, 2021-06-07, similarity 0.8046):
[0001571996-21-000026:note_history:10]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.8 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.

- changed (2021-09-03):
[0001571996-21-000040:note_history:11]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.
  (was, 2021-06-07, similarity 0.9294):
[0001571996-21-000026:note_history:11]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

- changed (2021-09-03):
[0001571996-21-000040:note_history:12]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 726 |  |  | $ | 9,527 |  |  | $ | 10,253 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (126) |  |  | (161) |  |  | (287) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 600 |  |  | 9,366 |  |  | 9,966 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 319 |  |  | 319 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 600 |  |  | $ | 9,685 |  |  | $ | 10,285 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 600 |  |  | $ | 4,355 |  |  | $ | 4,955 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,330 |  |  | $ | 5,330 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |
  (was, 2021-06-07, similarity 0.9943):
[0001571996-21-000026:note_history:12]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 752 |  |  | $ | 9,438 |  |  | $ | 10,190 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (139) |  |  | (177) |  |  | (316) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 613 |  |  | 9,261 |  |  | 9,874 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 367 |  |  | 367 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 613 |  |  | $ | 9,628 |  |  | $ | 10,241 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 613 |  |  | $ | 4,367 |  |  | $ | 4,980 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,261 |  |  | $ | 5,261 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

- added (2021-09-03):
[0001571996-21-000040:note_history:13]
|  | Three Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |  | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (10) |  |  | (3) |  |  | (13) |  |  | (18) |  |  | (7) |  |  | (25) |  |
| Provision charged to income statement | (3) |  |  | (13) |  |  | (16) |  |  | 17 |  |  | 10 |  |  | 27 |  |
| Balances at end of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |

- added (2021-09-03):
[0001571996-21-000040:note_history:14]
|  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (23) |  |  | (5) |  |  | (28) |  |  | (38) |  |  | (16) |  |  | (54) |  |
| Provision charged to income statement | 1 |  |  | (7) |  |  | (6) |  |  | 71 |  |  | 46 |  |  | 117 |  |
| Balances at end of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:15]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 515 |  |  | $ | 32 |  |  | $ | 8 |  |  | $ | 555 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 155 |  |  | 13 |  |  | 3 |  |  | 171 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,264 |  |  | 238 |  |  | 25 |  |  | 9,527 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,934 |  |  | $ | 283 |  |  | $ | 36 |  |  | $ | 10,253 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |
  (was, 2021-06-07, similarity 0.9927):
[0001571996-21-000026:note_history:15]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 549 |  |  | $ | 21 |  |  | $ | 10 |  |  | $ | 580 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 158 |  |  | 11 |  |  | 3 |  |  | 172 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,035 |  |  | 346 |  |  | 57 |  |  | 9,438 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,742 |  |  | $ | 378 |  |  | $ | 70 |  |  | $ | 10,190 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:16]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:
  (was, 2021-06-07, similarity 0.9973):
[0001571996-21-000026:note_history:16]
The following tables presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:

- changed (2021-09-03):
[0001571996-21-000040:note_history:17]
|  | July 30, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,806 |  |  | $ | 2,362 |  |  | $ | 1,330 |  |  | $ | 373 |  |  | $ | 73 |  |  | $ | 8 |  |  | $ | 149 |  |  | $ | 45 |  |  | $ | 6,146 |  |
| Mid | 520 |  |  | 925 |  |  | 487 |  |  | 162 |  |  | 32 |  |  | 1 |  |  | 172 |  |  | 52 |  |  | 2,351 |  |
| Lower | 376 |  |  | 634 |  |  | 327 |  |  | 92 |  |  | 17 |  |  | 2 |  |  | 234 |  |  | 74 |  |  | 1,756 |  |
| Total | $ | 2,702 |  |  | $ | 3,921 |  |  | $ | 2,144 |  |  | $ | 627 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 555 |  |  | $ | 171 |  |  | $ | 10,253 |  |
  (was, 2021-06-07, similarity 0.9865):
[0001571996-21-000026:note_history:17]
|  | April 30, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 1,057 |  |  | $ | 2,597 |  |  | $ | 1,520 |  |  | $ | 486 |  |  | $ | 107 |  |  | $ | 13 |  |  | $ | 153 |  |  | $ | 45 |  |  | $ | 5,978 |  |
| Mid | 286 |  |  | 1,000 |  |  | 553 |  |  | 190 |  |  | 45 |  |  | 4 |  |  | 176 |  |  | 51 |  |  | 2,305 |  |
| Lower | 238 |  |  | 728 |  |  | 419 |  |  | 163 |  |  | 27 |  |  | 5 |  |  | 251 |  |  | 76 |  |  | 1,907 |  |
| Total | $ | 1,581 |  |  | $ | 4,325 |  |  | $ | 2,492 |  |  | $ | 839 |  |  | $ | 179 |  |  | $ | 22 |  |  | $ | 580 |  |  | $ | 172 |  |  | $ | 10,190 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:18]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |
  (was, 2021-06-07, similarity 0.9937):
[0001571996-21-000026:note_history:18]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:19]
Interest income on sales-type lease receivables was $63 million and $66 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $127 million and $131 million for the six months ended July 30, 2021, and July 31, 2020, respectively.
  (was, 2021-06-07, similarity 0.7278):
[0001571996-21-000026:note_history:19]
Interest income on sales-type lease receivables was $64 million and $65 million for the three months ended April 30, 2021 and May 1, 2020, respectively.

- changed (2021-09-03):
[0001571996-21-000040:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 194 |  |  | $ | 249 |  |  | $ | 424 |  |  | $ | 464 |  |
| Cost of net revenue — products | 142 |  |  | 174 |  |  | 305 |  |  | 333 |  |
| Gross margin — products | $ | 52 |  |  | $ | 75 |  |  | $ | 119 |  |  | $ | 131 |  |
  (was, 2021-06-07, similarity 0.7666):
[0001571996-21-000026:note_history:20]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Net revenue — products | $ | 230 |  |  | $ | 215 |  |  |  |  |  |
| Cost of net revenue — products | 163 |  |  | 159 |  |  |  |  |  |
| Gross margin — products | $ | 67 |  |  | $ | 56 |  |  |  |  |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:21]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 1,479 |  |
| Fiscal 2023 | 2,052 |  |
| Fiscal 2024 | 1,303 |  |
| Fiscal 2025 | 592 |  |
| Fiscal 2026 and beyond | 252 |  |
| Total undiscounted cash flows | 5,678 |  |
| Fixed-term loans | 4,493 |  |
| Revolving loans | 726 |  |
| Less: unearned income | (644) |  |
| Total customer receivables, gross | $ | 10,253 |  |
  (was, 2021-06-07, similarity 0.6855):
[0001571996-21-000026:note_history:21]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 525 |  |
| Fiscal 2023 | 516 |  |
| Fiscal 2024 | 261 |  |
| Fiscal 2025 | 59 |  |
| Fiscal 2026 and beyond | 9 |  |
| Total | $ | 1,370 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:22]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,094 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (657) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,437 |  |  | $ | 1,314 |  |
  (was, 2021-06-07, similarity 0.9806):
[0001571996-21-000026:note_history:22]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,921 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (541) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,380 |  |  | $ | 1,314 |  |

- added (2021-09-03):
[0001571996-21-000040:note_history:23]
Operating lease income relating to lease payments was $167 million and $103 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $323 million and $190 million for the six months ended July 30, 2021, and July 31, 2020, respectively.  Depreciation expense was $127 million and $74 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $243 million and $136 million for the six months ended July 30, 2021, and July 31, 2020, respectively.

- added (2021-09-03):
[0001571996-21-000040:note_history:24]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 371 |  |
| Fiscal 2023 | 600 |  |
| Fiscal 2024 | 338 |  |
| Fiscal 2025 | 109 |  |
| Fiscal 2026 and beyond | 17 |  |
| Total | $ | 1,435 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:25]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,182 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 2,929 |  |  | 2,961 |  |
| Other | 176 |  |  | 140 |  |
| Total DFS U.S. debt | 6,287 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 768 |  |  | 786 |  |
| Other borrowings | 1,063 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,189 |  |  | 1,212 |  |
| Total DFS international debt | 3,270 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,557 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,281 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,276 |  |  | $ | 4,778 |  |
  (was, 2021-06-07, similarity 0.9932):
[0001571996-21-000026:note_history:25]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,674 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,548 |  |  | 2,961 |  |
| Other | 198 |  |  | 140 |  |
| Total DFS U.S. debt | 6,420 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 784 |  |  | 786 |  |
| Other borrowings | 1,087 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,212 |  |  | 1,212 |  |
| Total DFS international debt | 3,333 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,753 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 4,673 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 5,080 |  |  | $ | 4,778 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:26]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 30, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2021-06-07, similarity 0.9951):
[0001571996-21-000026:note_history:26]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of April 30, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2021-09-03):
[0001571996-21-000040:note_history:27]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and July 26, 2022, respectively.
  (was, 2021-06-07, similarity 0.9414):
[0001571996-21-000026:note_history:27]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

- changed (2021-09-03):
[0001571996-21-000040:note_history:28]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 30, 2021, these criteria were met.
  (was, 2021-06-07, similarity 0.9919):
[0001571996-21-000026:note_history:28]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 30, 2021, these criteria were met.

- changed (2021-09-03):
[0001571996-21-000040:note_history:29]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $951 million as of July 30, 2021.
  (was, 2021-06-07, similarity 0.9575):
[0001571996-21-000026:note_history:29]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and has a total debt capacity of $970 million as of April 30, 2021.

- changed (2021-09-03):
[0001571996-21-000040:note_history:30]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 30, 2021, these criteria were met.
  (was, 2021-06-07, similarity 0.9916):
[0001571996-21-000026:note_history:30]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 30, 2021, these criteria were met.

- changed (2021-09-03):
[0001571996-21-000040:note_history:31]
Other Borrowings — In connection with the Company’s international financing operations, the Company enters into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $362 million as of July 30, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $713 million as of July 30, 2021, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $333 million as of July 30, 2021, and is effective through April 20, 2023.
  (was, 2021-06-07, similarity 0.675):
[0001571996-21-000026:note_history:31]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $366 million as of April 30, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $727 million as of April 30, 2021, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $349 million as of April 30, 2021, and is effective through April 20, 2023.

- added (2021-09-03):
[0001571996-21-000040:note_history:32]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of July 30, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

- changed (2021-09-03):
[0001571996-21-000040:note_history:33]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C., a wholly-owned subsidiary of Dell Technologies Inc., issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2021-06-07, similarity 0.9376):
[0001571996-21-000026:note_history:33]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2021-09-03):
[0001571996-21-000040:note_history:34]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 770 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,457 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,229 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 838 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,472 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,398 |  |  | $ | 2,841 |  |
  (was, 2021-06-07, similarity 0.991):
[0001571996-21-000026:note_history:34]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 874 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,478 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,267 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 827 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,055 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,938 |  |  | $ | 2,841 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:35]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $2.7 billion and $3.0 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.
  (was, 2021-06-07, similarity 0.7819):
[0001571996-21-000026:note_history:35]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.4 billion and $1.8 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.

- added (2021-09-03):
[0001571996-21-000040:note_history:36]
Customer Receivables Sales
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $101 million and $228 million for the six months ended July 30, 2021 and July 31, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.  The transactions are accounted for as sales and, accordingly, the customer receivables are derecognized from the Condensed Consolidated Statements of Financial Position at the time of sale.

- removed (2021-09-03):
[0001571996-21-000026:note_history:37]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (13) |  |  | (2) |  |  | (15) |  |  | (20) |  |  | (9) |  |  | (29) |  |
| Provision charged to income statement | 4 |  |  | 6 |  |  | 10 |  |  | 54 |  |  | 36 |  |  | 90 |  |
| Balances at end of period | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |  | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |

- removed (2021-09-03):
[0001571996-21-000026:note_history:38]
____________________

- removed (2021-09-03):
[0001571996-21-000026:note_history:39]
(a)    The Company adopted the current expected credit losses standard as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.

- removed (2021-09-03):
[0001571996-21-000026:note_history:40]
____________________

- removed (2021-09-03):
[0001571996-21-000026:note_history:41]
(a)    The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio.

- removed (2021-09-03):
[0001571996-21-000026:note_history:42]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 2,232 |  |
| Fiscal 2023 | 1,819 |  |
| Fiscal 2024 | 1,086 |  |
| Fiscal 2025 | 429 |  |
| Fiscal 2026 and beyond | 141 |  |
| Total undiscounted cash flows | 5,707 |  |
| Fixed-term loans | 4,399 |  |
| Revolving loans | 752 |  |
| Less: unearned income | (668) |  |
| Total customer receivables, gross | $ | 10,190 |  |

- removed (2021-09-03):
[0001571996-21-000026:note_history:43]
Operating lease income relating to lease payments was $156 million and $87 million for the three months ended April 30, 2021 and May 1, 2020, respectively.  Depreciation expense was $116 million and $62 million for the three months ended April 30, 2021 and May 1, 2020, respectively.

- removed (2021-09-03):
[0001571996-21-000026:note_history:44]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of April 30, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

- removed (2021-09-03):
[0001571996-21-000026:note_history:45]
Customer Receivables Sales

- removed (2021-09-03):
[0001571996-21-000026:note_history:46]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $101 million and $21 million for the three months ended April 30, 2021 and May 1, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:47]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,127 |  |  | $ | 3,143 |  |
| 1.86% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,557 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | 1,000 |  |  | 4,000 |  |
| Other | 392 |  |  | 235 |  |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
  (was, 2021-06-07, similarity 0.9967):
[0001571996-21-000026:note_history:47]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,135 |  |  | $ | 3,143 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,753 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 304 |  |  | 235 |  |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:48]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (174) |  |  | (194) |  |
| Debt issuance costs | (269) |  |  | (302) |  |
| Total debt, carrying value | $ | 43,594 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 6,427 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,167 |  |  | $ | 41,622 |  |
  (was, 2021-06-07, similarity 0.9887):
[0001571996-21-000026:note_history:48]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (185) |  |  | (194) |  |
| Debt issuance costs | (285) |  |  | (302) |  |
| Total debt, carrying value | $ | 46,683 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 8,748 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,935 |  |  | $ | 41,622 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:49]
During the six months ended July 30, 2021, the net decrease in the Company’s debt balance was primarily due to:
  (was, 2021-06-07, similarity 0.9296):
[0001571996-21-000026:note_history:49]
During the three months ended April 30, 2021, the net decrease in the Company’s debt balance was primarily due to:

- added (2021-09-03):
[0001571996-21-000040:note_history:50]
•repayment of $3.0 billion principal amount of the Margin Loan Facility due April 2022;

- changed (2021-09-03):
[0001571996-21-000040:note_history:51]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  The Revolving Credit Facility expires December 20, 2023.
  (was, 2021-06-07, similarity 0.9494):
[0001571996-21-000026:note_history:51]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

- changed (2021-09-03):
[0001571996-21-000040:note_history:52]
As of July 30, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2021-06-07, similarity 0.9844):
[0001571996-21-000026:note_history:52]
As of April 30, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- added (2021-09-03):
[0001571996-21-000040:note_history:53]
First Lien Notes — Dell International L.L.C. and EMC Corporation (collectively, the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) pursuant to Rule 144A and Regulation S. Various series of the First Lien Notes were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on an equal and ratable basis with the Senior Secured Credit Facilities by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- added (2021-09-03):
[0001571996-21-000040:note_history:54]
In June 2021, Dell International L.L.C and EMC Corporation completed the previously announced offers to exchange any and all outstanding First Lien Notes for registered first lien notes having terms substantially identical to the terms of the First Lien Notes.  The Issuers issued an aggregate $18.4 billion principal amount of registered first lien notes in exchange for the same principal amount of First Lien Notes.  As of July 30, 2021, the aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.  Following the exchange

- added (2021-09-03):
[0001571996-21-000040:note_history:55]
offer, such registered first lien notes, together with the remaining unregistered First Lien Notes, are collectively referred to as “First Lien Notes” in these Notes to the Condensed Consolidated Financial Statements.

- added (2021-09-03):
[0001571996-21-000040:note_history:56]
EMC Notes — On September 7, 2016, as result of the merger with EMC, Dell acquired multiple outstanding Notes (collectively, the “EMC Notes”), of which $1.0 billion aggregate principal amount of its 3.375% Note remains.  Interest on the outstanding borrowing is payable semiannually.

- changed (2021-09-03):
[0001571996-21-000040:note_history:57]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.  Subsequent to July 30, 2021, VMware, Inc. issued five series of unsecured senior notes (the “2021 VMware Notes”) in the aggregate principal amount of $6.0 billion pursuant to a public offering.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about issuance of the 2021 VMware Notes.
  (was, 2021-06-07, similarity 0.7608):
[0001571996-21-000026:note_history:57]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.

- changed (2021-09-03):
[0001571996-21-000040:note_history:58]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, expiring September 12, 2022 and may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of July 30, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2021-06-07, similarity 0.9824):
[0001571996-21-000026:note_history:58]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of April 30, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2021-09-03):
[0001571996-21-000040:note_history:59]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.  During the three months ended July 30, 2021, the Company repaid $3.0 billion principal amount of the Margin Loan Facility.  Subsequent to July 30, 2021, the Company repaid the remaining $1.0 billion principal amount of the Margin Loan Facility.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the Margin Loan Facility principal repayment, subsequent to July 30, 2021.
  (was, 2021-06-07, similarity 0.7258):
[0001571996-21-000026:note_history:59]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

- changed (2021-09-03):
[0001571996-21-000040:note_history:60]
The following table presents the aggregate future maturities of the Company’s debt as of July 30, 2021 for the periods indicated:
  (was, 2021-06-07, similarity 0.9719):
[0001571996-21-000026:note_history:60]
The following table presents the aggregate future maturities of the Company’s debt as of April 30, 2021 for the periods indicated:

- changed (2021-09-03):
[0001571996-21-000040:note_history:61]
|  | Maturities by Fiscal Year |
|  | 2022(remaining six months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 16 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,750 |  |  | $ | 24,761 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 2,752 |  |  | 4,463 |  |  | 1,454 |  |  | 851 |  |  | 37 |  |  | — |  |  | 9,557 |  |
| Margin Loan Facility | — |  |  | 1,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |
| Other | 27 |  |  | 33 |  |  | 190 |  |  | 94 |  |  | 24 |  |  | 24 |  |  | 392 |  |
| Total maturities, principal amount | 2,795 |  |  | 7,209 |  |  | 8,651 |  |  | 4,328 |  |  | 4,828 |  |  | 16,226 |  |  | 44,037 |  |
| Associated carrying value adjustments | (3) |  |  | (5) |  |  | (27) |  |  | (65) |  |  | (45) |  |  | (298) |  |  | (443) |  |
| Total maturities, carrying value amount | $ | 2,792 |  |  | $ | 7,204 |  |  | $ | 8,624 |  |  | $ | 4,263 |  |  | $ | 4,783 |  |  | $ | 15,928 |  |  | $ | 43,594 |  |
  (was, 2021-06-07, similarity 0.9967):
[0001571996-21-000026:note_history:61]
|  | Maturities by Fiscal Year |
|  | 2022(remaining nine months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,743 |  |  | $ | 24,769 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 3,844 |  |  | 4,249 |  |  | 774 |  |  | 850 |  |  | 36 |  |  | — |  |  | 9,753 |  |
| Margin Loan Facility | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 11 |  |  | 171 |  |  | 78 |  |  | 8 |  |  | 25 |  |  | 304 |  |
| Total maturities, principal amount | 3,886 |  |  | 9,973 |  |  | 7,952 |  |  | 4,311 |  |  | 4,811 |  |  | 16,220 |  |  | 47,153 |  |
| Associated carrying value adjustments | (6) |  |  | (15) |  |  | (32) |  |  | (71) |  |  | (47) |  |  | (299) |  |  | (470) |  |
| Total maturities, carrying value amount | $ | 3,880 |  |  | $ | 9,958 |  |  | $ | 7,920 |  |  | $ | 4,240 |  |  | $ | 4,764 |  |  | $ | 15,921 |  |  | $ | 46,683 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:62]
As of July 30, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of July 30, 2021.
  (was, 2021-06-07, similarity 0.9815):
[0001571996-21-000026:note_history:62]
As of April 30, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of April 30, 2021.

- changed (2021-09-03):
[0001571996-21-000040:note_history:63]
The Senior Secured Credit Facilities and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of July 30, 2021.
  (was, 2021-06-07, similarity 0.8962):
[0001571996-21-000026:note_history:63]
The Term Loan A-6 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of April 30, 2021.

- removed (2021-09-03):
[0001571996-21-000026:note_history:64]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- removed (2021-09-03):
[0001571996-21-000026:note_history:65]
The Company agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.  On April 15, 2021, Dell International L.L.C., EMC Corporation and the guarantors of the First Lien Notes (collectively, the “Registrants”)  filed a registration statement with the SEC relating to the proposed exchange offer of such registered notes.

- removed (2021-09-03):
[0001571996-21-000026:note_history:66]
Subsequent to the three months ended April 30, 2021, on May 13, 2021, the Registrants filed an amendment to the registration statement, which was declared effective on May 17, 2021.  In addition, on May 17, 2021, the Registrants filed a prospectus with the SEC and launched the exchange offer.  The exchange offer expires at 5:00 p.m., New York City time, on June 15, 2021, unless extended by Dell International L.L.C. and EMC Corporation. During this period holders of the First Lien Notes may elect to tender their unregistered outstanding notes for freely tradable exchange notes that have been registered under the Securities Act.  The Company does not currently intend to extend the expiration date.

- removed (2021-09-03):
[0001571996-21-000026:note_history:67]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on outstanding borrowings is payable semiannually.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:68]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 23.1 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
  (was, 2021-06-07, similarity 0.9926):
[0001571996-21-000026:note_history:68]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.7 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 4.7 |  |  | $ | 5.2 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:69]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,182 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 2,929 |  |  | 2,961 |  |
| Other | 176 |  |  | 140 |  |
| Total DFS U.S. debt | 6,287 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 768 |  |  | 786 |  |
| Other borrowings | 1,063 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,189 |  |  | 1,212 |  |
| Total DFS international debt | 3,270 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,557 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,281 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,276 |  |  | $ | 4,778 |  |
  (was, 2021-06-07, similarity 0.9932):
[0001571996-21-000026:note_history:69]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,674 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,548 |  |  | 2,961 |  |
| Other | 198 |  |  | 140 |  |
| Total DFS U.S. debt | 6,420 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 784 |  |  | 786 |  |
| Other borrowings | 1,087 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,212 |  |  | 1,212 |  |
| Total DFS international debt | 3,333 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,753 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 4,673 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 5,080 |  |  | $ | 4,778 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:70]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,127 |  |  | $ | 3,143 |  |
| 1.86% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,557 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | 1,000 |  |  | 4,000 |  |
| Other | 392 |  |  | 235 |  |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
  (was, 2021-06-07, similarity 0.9967):
[0001571996-21-000026:note_history:70]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,135 |  |  | $ | 3,143 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,753 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 304 |  |  | 235 |  |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |

- changed (2021-09-03):
[0001571996-21-000040:note_history:71]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (174) |  |  | (194) |  |
| Debt issuance costs | (269) |  |  | (302) |  |
| Total debt, carrying value | $ | 43,594 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 6,427 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,167 |  |  | $ | 41,622 |  |
  (was, 2021-06-07, similarity 0.9887):
[0001571996-21-000026:note_history:71]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (185) |  |  | (194) |  |
| Debt issuance costs | (285) |  |  | (302) |  |
| Total debt, carrying value | $ | 46,683 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 8,748 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,935 |  |  | $ | 41,622 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:72]
The following table presents the aggregate future maturities of the Company’s debt as of July 30, 2021 for the periods indicated:
  (was, 2021-06-07, similarity 0.9719):
[0001571996-21-000026:note_history:72]
The following table presents the aggregate future maturities of the Company’s debt as of April 30, 2021 for the periods indicated:

- changed (2021-09-03):
[0001571996-21-000040:note_history:73]
|  | Maturities by Fiscal Year |
|  | 2022(remaining six months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 16 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,750 |  |  | $ | 24,761 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 2,752 |  |  | 4,463 |  |  | 1,454 |  |  | 851 |  |  | 37 |  |  | — |  |  | 9,557 |  |
| Margin Loan Facility | — |  |  | 1,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |
| Other | 27 |  |  | 33 |  |  | 190 |  |  | 94 |  |  | 24 |  |  | 24 |  |  | 392 |  |
| Total maturities, principal amount | 2,795 |  |  | 7,209 |  |  | 8,651 |  |  | 4,328 |  |  | 4,828 |  |  | 16,226 |  |  | 44,037 |  |
| Associated carrying value adjustments | (3) |  |  | (5) |  |  | (27) |  |  | (65) |  |  | (45) |  |  | (298) |  |  | (443) |  |
| Total maturities, carrying value amount | $ | 2,792 |  |  | $ | 7,204 |  |  | $ | 8,624 |  |  | $ | 4,263 |  |  | $ | 4,783 |  |  | $ | 15,928 |  |  | $ | 43,594 |  |
  (was, 2021-06-07, similarity 0.9967):
[0001571996-21-000026:note_history:73]
|  | Maturities by Fiscal Year |
|  | 2022(remaining nine months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,743 |  |  | $ | 24,769 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 3,844 |  |  | 4,249 |  |  | 774 |  |  | 850 |  |  | 36 |  |  | — |  |  | 9,753 |  |
| Margin Loan Facility | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 11 |  |  | 171 |  |  | 78 |  |  | 8 |  |  | 25 |  |  | 304 |  |
| Total maturities, principal amount | 3,886 |  |  | 9,973 |  |  | 7,952 |  |  | 4,311 |  |  | 4,811 |  |  | 16,220 |  |  | 47,153 |  |
| Associated carrying value adjustments | (6) |  |  | (15) |  |  | (32) |  |  | (71) |  |  | (47) |  |  | (299) |  |  | (470) |  |
| Total maturities, carrying value amount | $ | 3,880 |  |  | $ | 9,958 |  |  | $ | 7,920 |  |  | $ | 4,240 |  |  | $ | 4,764 |  |  | $ | 15,921 |  |  | $ | 46,683 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:74]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,462 |  |  | $ | 4,196 |  |  | $ | 8,571 |  |  | $ | 7,954 |  |
| Storage | 3,970 |  |  | 4,011 |  |  | 7,772 |  |  | 7,822 |  |
| Total ISG net revenue | 8,432 |  |  | 8,207 |  |  | 16,343 |  |  | 15,776 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 10,573 |  |  | 8,039 |  |  | 20,376 |  |  | 16,673 |  |
| Consumer | 3,690 |  |  | 3,164 |  |  | 7,192 |  |  | 5,634 |  |
| Total CSG net revenue | 14,263 |  |  | 11,203 |  |  | 27,568 |  |  | 22,307 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 3,148 |  |  | 2,908 |  |  | 6,139 |  |  | 5,663 |  |
| Total segment net revenue | $ | 25,843 |  |  | $ | 22,318 |  |  | $ | 50,050 |  |  | $ | 43,746 |  |
  (was, 2021-06-07, similarity 0.8569):
[0001571996-21-000026:note_history:74]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,109 |  |  | $ | 3,758 |  |  |  |  |  |
| Storage | 3,802 |  |  | 3,811 |  |  |  |  |  |
| Total ISG net revenue | 7,911 |  |  | 7,569 |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 9,803 |  |  | 8,634 |  |  |  |  |  |
| Consumer | 3,502 |  |  | 2,470 |  |  |  |  |  |
| Total CSG net revenue | 13,305 |  |  | 11,104 |  |  |  |  |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,991 |  |  | 2,755 |  |  |  |  |  |
| Total segment net revenue | $ | 24,207 |  |  | $ | 21,428 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-09-03):
[0001571996-21-000040:note_history:75]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 31,376 |  |  | $ | 27,617 |  |  | $ | 30,801 |  |  | $ | 27,800 |  |
| Revenue deferrals | 6,674 |  |  | 6,550 |  |  | 13,154 |  |  | 12,095 |  |
| Revenue recognized | (6,052) |  |  | (5,376) |  |  | (11,957) |  |  | (10,843) |  |
| Other (a) | (155) |  |  | — |  |  | (155) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 31,843 |  |  | $ | 28,791 |  |  | $ | 31,843 |  |  | $ | 28,791 |  |
| Short-term deferred revenue | $ | 17,003 |  |  | $ | 15,341 |  |  | $ | 17,003 |  |  | $ | 15,341 |  |
| Long-term deferred revenue | $ | 14,840 |  |  | $ | 13,450 |  |  | $ | 14,840 |  |  | $ | 13,450 |  |
  (was, 2021-06-07, similarity 0.8151):
[0001571996-21-000026:note_history:75]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 30,801 |  |  | $ | 27,800 |  |  |  |  |  |
| Revenue deferrals | 6,480 |  |  | 5,423 |  |  |  |  |  |
| Revenue recognized | (5,905) |  |  | (5,356) |  |  |  |  |  |
| Other (a) | — |  |  | (250) |  |  |  |  |  |
| Deferred revenue at end of period | $ | 31,376 |  |  | $ | 27,617 |  |  |  |  |  |
| Short-term deferred revenue | $ | 16,835 |  |  | $ | 14,766 |  |  |  |  |  |
| Long-term deferred revenue | $ | 14,541 |  |  | $ | 12,851 |  |  |  |  |  |

- added (2021-09-03):
[0001571996-21-000040:note_history:76]
(a) For the three and six months ended July 30, 2021, Other represents the reclassification of Boomi deferred revenue to liabilities held for sale.  For the six months ended July 31, 2020, Other represents the reclassification of RSA Security deferred revenue to liabilities held for sale.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and of RSA Security.

- changed (2021-09-03):
[0001571996-21-000040:note_history:77]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 30, 2021 was approximately $46 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2021-06-07, similarity 0.993):
[0001571996-21-000026:note_history:77]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of April 30, 2021 was approximately $42 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- changed (2021-09-03):
[0001571996-21-000040:note_history:78]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancellable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized in the amount to which the Company has the right to invoice for services performed.
  (was, 2021-06-07, similarity 0.9954):
[0001571996-21-000026:note_history:78]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancellable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

- removed (2021-09-03):
[0001571996-21-000026:note_history:79]
(a) For the three months ended May 1, 2020, Other represents the reclassification of RSA Security deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-09-03):
[0001571996-21-000040:note_history:80]
SUBSEQUENT EVENTS 
VMware, Inc. Unsecured Senior Notes - Public Debt Offering

- added (2021-09-03):
[0001571996-21-000040:note_history:81]
On August 2, 2021, VMware, Inc. issued five series of unsecured senior notes pursuant to a public offering in the aggregate principal amount of $6.0 billion, consisting of outstanding principal due on the following dates:

- added (2021-09-03):
[0001571996-21-000040:note_history:82]
•$1.0 billion 0.60% Senior Note due August 15, 2023

- added (2021-09-03):
[0001571996-21-000040:note_history:83]
•$1.25 billion 1.00% Senior Note due August 15, 2024

- added (2021-09-03):
[0001571996-21-000040:note_history:84]
•$1.5 billion 1.40% Senior Note due August 15, 2026

- added (2021-09-03):
[0001571996-21-000040:note_history:85]
•$750 million 1.80% Senior Note due August 15, 2028

- added (2021-09-03):
[0001571996-21-000040:note_history:86]
•$1.5 billion 2.20% Senior Note due August 15, 2031

- added (2021-09-03):
[0001571996-21-000040:note_history:87]
The 2021 VMware Notes are payable semi annually on February 15 and August 15 of each year, commencing on February 15, 2022.

- added (2021-09-03):
[0001571996-21-000040:note_history:88]
The net proceeds from the 2021 VMware Notes are expected to be used by VMware, Inc. to fund a portion of the cash dividend payable in connection with the VMware Spin-off pursuant to the terms of the Separation and Distribution Agreement entered into on April 14, 2021 and, to the extent any proceeds remain, for general VMware, Inc. corporate purposes.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information related to the VMware Spin-off.

- added (2021-09-03):
[0001571996-21-000040:note_history:89]
VMware, Inc. Revolving Credit Facility and Term Loan Facilities

- added (2021-09-03):
[0001571996-21-000040:note_history:90]
On September 2, 2021, VMware, Inc. entered into an unsecured credit agreement establishing a revolving credit facility with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $1.5 billion for general corporate purposes (the “2021 VMware Revolving Credit Facility”).  The 2021 VMware Revolving Credit Facility will replace VMware, Inc.’s existing $1.0 billion revolving credit facility that is currently undrawn.

- added (2021-09-03):
[0001571996-21-000040:note_history:91]
In addition, VMware, Inc. received commitments from financial institutions for a 3-year senior unsecured term loan facility and a 5-year senior unsecured term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $4.0 billion, which, if funded, may be used to finance a portion of the Special Dividend and for VMware, Inc. general corporate purposes. VMware, Inc. may borrow against the term loan once up to its borrowing capacity of $4.0 billion until the earlier of (x) April 28, 2022 and (y) the date on which the Separation Agreement is terminated.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- added (2021-09-03):
[0001571996-21-000040:note_history:92]
Margin Loan Facility

- added (2021-09-03):
[0001571996-21-000040:note_history:93]
Subsequent to July 30, 2021, the Company repaid the remaining $1.0 billion principal amount of the Margin Loan Facility due April 2022.  Upon repayment, the VMware, Inc. common stock pledged to secure the Margin Loan Facility was released as collateral in accordance with the associated Margin Loan Facility agreement.

- added (2021-09-03):
[0001571996-21-000040:note_history:94]
Other than the matters identified above, there were no known events occurring after July 30, 2021 and up until the date of issuance of this report that would materially affect the information presented herein.

- removed (2021-09-03):
[0001571996-21-000026:note_history:95]
NOTE 18 — SUBSEQUENT EVENTS

- removed (2021-09-03):
[0001571996-21-000026:note_history:96]
Debt Repayment — Subsequent to April 30, 2021, the Company repaid $1 billion principal amount of the Margin Loan Facility due April 2022.

- removed (2021-09-03):
[0001571996-21-000026:note_history:97]
Boomi Divestiture — On May 1, 2021, Dell Technologies announced its entry into a definitive agreement with Francisco Partners and TPG Capital to sell Boomi and certain related assets from the Company in a cash transaction valued at $4 billion, subject to certain closing adjustments.  The transaction is expected to close by the end of calendar 2021, subject to customary closing conditions.  The transaction is intended to support the Company’s focus on fueling growth by continuing to modernize Dell Technologies’ core infrastructure and PC businesses and by expanding in high-priority areas, including hybrid and private cloud, edge, telecom and Apex.

- removed (2021-09-03):
[0001571996-21-000026:note_history:98]
Boomi is included within Other Businesses and does not meet the requirements for a reportable segment.

- removed (2021-09-03):
[0001571996-21-000026:note_history:99]
Other than the matters identified above, there were no known events occurring after April 30, 2021 and up until the date of the issuance of this report that would materially affect the information presented herein.
